import GoldC.QuillonRPiece
import GoldC.QuillonPartition
import GoldC.QuillonWBilinear

/-!
# Quillon CSC3 F7.5m: the R route, full bilinear form (fixed `r`)

`rowR` is the R normal form of a row, for fixed `r`, as a function of `s`:

    rowR(s) = Σ_{m∈𝒦} coef_m · ampC(j_m, L_m·s) · e(Y_m/s) · Γ_m(s mod Q).

* Main saw: `L = 1`, `Y = ±kH/r`, `Γ(σ) = e(∓kH·σ̄/r)` (by `eR_reciprocity`), `Q = r`.
* Class saw: `L = 6q`, `Y = kH/(6qr)`, and `Γ` collects `e(−kH σ̄/(6qr))` with the `6q`-rational part
  and the coefficient `Γ_class(b, rs mod 6q)`. Here `Q = 6qr`.

**`R_bilinear_full`**: for `𝒱 ⊆ (V₀, 2^{Kv}V₀]`, `‖a_v‖ ≤ A/v`, `‖b_u‖ ≤ A/u` (for `u ≤ S₁`):

    ‖Σ_u b_u Σ_v a_v 1[vu∈(S₀,S₁]] rowR(vu)‖ ≤ Ku·Kv·Σ_m ‖coef_m‖·A²·√(2·RPsi_m),

where `Ku = 2(log₂S₁+1)` and
`RPsi = 2/V₀ + 4C·e^{−c log³((Ulo−Q)/Q)/log²(|Y|/Q)} + 64C·S₁(1+log S₁)/|Y|`, with `Ulo = S₀/(2^{Kv}V₀)`.
The `u`-blocks are the near-geometric `tseq Ulo 2`, which gives `U₁ + 2Q ≤ 2U₀`. A block with
`V₁U₀ ≥ S₁` is empty after masking.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonRBilinear

open GoldC.QuillonR GoldC.QuillonCot GoldC.QuillonRPiece GoldC.QuillonPartition GoldC.QuillonWBilinear

/-- The R normal form of a row (fixed `r`), as a function of `s`. -/
noncomputable def rowR (𝒦 : Finset ℕ) (coef : ℕ → ℂ) (jm Lm : ℕ → ℕ) (Ym : ℕ → ℝ)
    (Γ : ℕ → ℕ → ℂ) (Q s : ℕ) : ℂ :=
  ∑ m ∈ 𝒦, coef m * (((ampC (jm m) (Lm m * s) : ℝ) : ℂ) * (eR (Ym m / (s : ℝ)) * Γ m (s % Q)))

/-- The R saving for one mode. -/
noncomputable def RPsi (c C : ℝ) (Q V₀ Ulo S₁ : ℕ) (Y : ℝ) : ℝ :=
  2 / (V₀ : ℝ) + 4 * C * Real.exp (-(c * Real.log (((Ulo - Q) / Q : ℕ) : ℝ) ^ 3 /
    Real.log (|Y| / Q) ^ 2)) + 64 * C * S₁ * (1 + Real.log S₁) / |Y|

lemma RPsi_nonneg (c C : ℝ) (hC : 0 ≤ C) (Q V₀ Ulo S₁ : ℕ) (Y : ℝ) : 0 ≤ RPsi c C Q V₀ Ulo S₁ Y := by
  unfold RPsi
  have h1 : 0 ≤ Real.log (S₁ : ℝ) := Real.log_natCast_nonneg S₁
  positivity

lemma norm_rowR_le (𝒦 : Finset ℕ) (coef : ℕ → ℂ) (jm Lm : ℕ → ℕ) (Ym : ℕ → ℝ)
    (Γ : ℕ → ℕ → ℂ) (Q s : ℕ) (hjm : ∀ m ∈ 𝒦, 1 ≤ jm m) (hLm : ∀ m ∈ 𝒦, 1 ≤ Lm m)
    (hΓ : ∀ m ∈ 𝒦, ∀ x, ‖Γ m x‖ ≤ 1) (hs : 1 ≤ s) :
    ‖rowR 𝒦 coef jm Lm Ym Γ Q s‖ ≤ ∑ m ∈ 𝒦, ‖coef m‖ := by
  unfold rowR
  refine (norm_sum_le _ _).trans (sum_le_sum fun m hm => ?_)
  rw [norm_mul, norm_mul, norm_mul, norm_eR, one_mul]
  have hLs : 1 ≤ Lm m * s := Nat.one_le_iff_ne_zero.2 (by
    have := hLm m hm; positivity)
  have hA := ampC_bounds (jm m) (Lm m * s) (hjm m hm) hLs
  rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg hA.1]
  calc ‖coef m‖ * (ampC (jm m) (Lm m * s) * ‖Γ m (s % Q)‖) ≤ ‖coef m‖ * (1 * 1) := by
        gcongr
        · exact hA.2
        · exact hΓ m hm _
    _ = ‖coef m‖ := by ring

/-- The masked row at `s = v·u`, rewritten in the `R_piece` shape. -/
lemma rowR_mask (𝒦 : Finset ℕ) (coef : ℕ → ℂ) (jm Lm : ℕ → ℕ) (Ym : ℕ → ℝ)
    (Γ : ℕ → ℕ → ℂ) (Q S₀ S₁ v u : ℕ) :
    (if v * u ∈ Ioc S₀ S₁ then rowR 𝒦 coef jm Lm Ym Γ Q (v * u) else 0) =
      ∑ m ∈ 𝒦, coef m * (ampI S₀ S₁ (jm m) (Lm m) v u *
        (eR (Ym m / ((v : ℝ) * u)) * Γ m ((v * (u % Q)) % Q))) := by
  unfold ampI rowR
  by_cases h : v * u ∈ Ioc S₀ S₁
  · rw [if_pos h]
    refine sum_congr rfl fun m _ => ?_
    rw [if_pos h]
    have e1 : Lm m * (v * u) = v * (Lm m * u) := by ring
    have e2 : (v * u) % Q = (v * (u % Q)) % Q := by
      rw [Nat.mul_mod, Nat.mul_mod v (u % Q), Nat.mod_mod]
    rw [e1, e2]; push_cast; rfl
  · rw [if_neg h]
    symm; refine sum_eq_zero fun m _ => ?_
    rw [if_neg h]; simp

lemma RPsi_ge (c C : ℝ) (hc : 0 < c) (hC : 0 ≤ C) (Q V₀ Ulo S₁ U₀ V₁ : ℕ) (Y : ℝ)
    (hQ : 1 ≤ Q) (hUlo : 4 * Q + 2 ≤ Ulo) (hU₀ : Ulo ≤ U₀) (hV₀ : 1 ≤ V₀) (hV₁ : V₀ ≤ V₁)
    (hS : V₁ * U₀ < S₁) (hY : 0 < |Y|) :
    2 / (V₁ : ℝ) + 4 * C * Real.exp (-(c * Real.log (((U₀ - Q) / Q : ℕ) : ℝ) ^ 3 /
        Real.log (|Y| / Q) ^ 2)) + 64 * C * U₀ * V₁ * (1 + Real.log V₁) / |Y| ≤
      RPsi c C Q V₀ Ulo S₁ Y := by
  unfold RPsi
  have hV₀R : (1 : ℝ) ≤ V₀ := by exact_mod_cast hV₀
  have hV₁R : (V₀ : ℝ) ≤ V₁ := by exact_mod_cast hV₁
  have h1 : 2 / (V₁ : ℝ) ≤ 2 / V₀ := div_le_div_of_nonneg_left (by norm_num) (by linarith) hV₁R
  have hnlo : 1 ≤ (Ulo - Q) / Q := by rw [Nat.le_div_iff_mul_le (by omega)]; omega
  have hn : (Ulo - Q) / Q ≤ (U₀ - Q) / Q := Nat.div_le_div_right (by omega)
  have hlog : Real.log (((Ulo - Q) / Q : ℕ) : ℝ) ≤ Real.log (((U₀ - Q) / Q : ℕ) : ℝ) :=
    Real.log_le_log (by exact_mod_cast (show 0 < (Ulo - Q) / Q by omega)) (by exact_mod_cast hn)
  have hlog0 : 0 ≤ Real.log (((Ulo - Q) / Q : ℕ) : ℝ) := Real.log_nonneg (by exact_mod_cast hnlo)
  have h2 : Real.exp (-(c * Real.log (((U₀ - Q) / Q : ℕ) : ℝ) ^ 3 / Real.log (|Y| / Q) ^ 2)) ≤
      Real.exp (-(c * Real.log (((Ulo - Q) / Q : ℕ) : ℝ) ^ 3 / Real.log (|Y| / Q) ^ 2)) := by
    apply Real.exp_le_exp.2
    apply neg_le_neg
    apply div_le_div_of_nonneg_right _ (sq_nonneg _)
    exact mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hlog0 hlog 3) hc.le
  have hS' : (U₀ : ℝ) * V₁ ≤ S₁ := by
    have : U₀ * V₁ ≤ S₁ := by rw [mul_comm]; omega
    exact_mod_cast this
  have hV₁1 : (1 : ℝ) ≤ V₁ := by linarith
  have hU₀1 : (1 : ℝ) ≤ U₀ := by exact_mod_cast (show 1 ≤ U₀ by omega)
  have hlogV : Real.log V₁ ≤ Real.log S₁ := Real.log_le_log (by linarith) (by nlinarith)
  have hlogV0 : 0 ≤ Real.log (V₁ : ℝ) := Real.log_nonneg hV₁1
  have h3 : (U₀ : ℝ) * V₁ * (1 + Real.log V₁) ≤ S₁ * (1 + Real.log S₁) :=
    mul_le_mul hS' (by linarith) (by linarith) (by positivity)
  have h3' : 64 * C * U₀ * V₁ * (1 + Real.log V₁) / |Y| ≤ 64 * C * S₁ * (1 + Real.log S₁) / |Y| := by
    apply div_le_div_of_nonneg_right _ hY.le
    calc 64 * C * U₀ * V₁ * (1 + Real.log V₁) = 64 * C * ((U₀ : ℝ) * V₁ * (1 + Real.log V₁)) := by ring
      _ ≤ 64 * C * (S₁ * (1 + Real.log S₁)) := mul_le_mul_of_nonneg_left h3 (by positivity)
      _ = 64 * C * S₁ * (1 + Real.log S₁) := by ring
  exact add_le_add (add_le_add h1 (mul_le_mul_of_nonneg_left h2 (by positivity))) h3'

/-- **R route, full bilinear form.** -/
theorem R_bilinear_full (c C : ℝ) (hc : 0 < c) (hC : 0 ≤ C)
    (hcab : ∀ (Q ρ N M : ℕ) (Y : ℝ) (A : ℕ → ℂ), 1 ≤ Q → ρ < Q → 1 ≤ N → N ≤ M → M ≤ 2 * N →
        2 * (Q : ℝ) ≤ |Y| →
        ‖∑ t ∈ Ioc N M, A t * eR (Y / ((ρ : ℝ) + Q * t))‖ ≤
          (‖A M‖ + ∑ n ∈ Ico (N + 1) M, ‖A (n + 1) - A n‖) *
            (C * ((N : ℝ) * Real.exp (-(c * Real.log (N : ℝ) ^ 3 / Real.log (|Y| / Q) ^ 2)) +
              (N : ℝ) ^ 2 / (|Y| / Q))))
    (𝒦 : Finset ℕ) (coef : ℕ → ℂ) (jm Lm : ℕ → ℕ) (Ym : ℕ → ℝ) (Γ : ℕ → ℕ → ℂ)
    (hjm : ∀ m ∈ 𝒦, 1 ≤ jm m) (hLm : ∀ m ∈ 𝒦, 1 ≤ Lm m) (hΓ : ∀ m ∈ 𝒦, ∀ x, ‖Γ m x‖ ≤ 1)
    (Q : ℕ) (hQ : 1 ≤ Q) (𝒰 𝒱 : Finset ℕ) (V₀ Kv S₀ S₁ : ℕ) (hV₀ : 1 ≤ V₀)
    (h𝒱 : 𝒱 ⊆ Ioc V₀ (2 ^ Kv * V₀))
    (hUlo : 4 * Q + 2 ≤ S₀ / (2 ^ Kv * V₀))
    (hY : ∀ m ∈ 𝒦, 8 * (Q : ℝ) * ((2 ^ Kv * V₀ : ℕ) : ℝ) ^ 2 ≤ |Ym m|)
    (a b : ℕ → ℂ) (A : ℝ) (hA : 0 ≤ A) (ha : ∀ v ∈ 𝒱, ‖a v‖ ≤ A / v)
    (hb : ∀ u ∈ 𝒰, u ≤ S₁ → ‖b u‖ ≤ A / u) :
    ‖∑ u ∈ 𝒰, b u * ∑ v ∈ 𝒱, a v *
        (if v * u ∈ Ioc S₀ S₁ then rowR 𝒦 coef jm Lm Ym Γ Q (v * u) else 0)‖ ≤
      ((((Nat.log 2 S₁ + 1) * 2) * Kv : ℕ) : ℝ) * ∑ m ∈ 𝒦, ‖coef m‖ *
        (A ^ 2 * Real.sqrt (2 * RPsi c C Q V₀ (S₀ / (2 ^ Kv * V₀)) S₁ (Ym m))) := by
  classical
  set Vt := 2 ^ Kv * V₀ with hVt
  set Ulo := S₀ / Vt with hUlo_def
  set Ku := (Nat.log 2 S₁ + 1) * 2 with hKu
  set F : ℕ → ℕ → ℂ := fun u v => a v *
    (if v * u ∈ Ioc S₀ S₁ then rowR 𝒦 coef jm Lm Ym Γ Q (v * u) else 0) with hF
  set RHSm : ℝ := ∑ m ∈ 𝒦, ‖coef m‖ * (A ^ 2 * Real.sqrt (2 * RPsi c C Q V₀ Ulo S₁ (Ym m)))
    with hRHSm
  have hRHS0 : 0 ≤ RHSm := sum_nonneg fun m _ => by positivity
  have e0 : ∑ u ∈ 𝒰, b u * ∑ v ∈ 𝒱, a v *
      (if v * u ∈ Ioc S₀ S₁ then rowR 𝒦 coef jm Lm Ym Γ Q (v * u) else 0) =
      ∑ u ∈ 𝒰, b u * ∑ v ∈ 𝒱, F u v := rfl
  rw [e0]
  -- step 1: restrict `u` to `(Ulo, S₁]`
  have hzero : ∀ u, u ∉ Ioc Ulo S₁ → ∑ v ∈ 𝒱, F u v = 0 := by
    intro u hu
    refine sum_eq_zero fun v hv => ?_
    have hvR := mem_Ioc.1 (h𝒱 hv)
    simp only [hF]
    rw [if_neg, mul_zero]
    intro hI
    rw [mem_Ioc] at hI hu
    rw [not_and_or, not_lt, not_le] at hu
    rcases hu with h | h
    · have h1 : v * u ≤ Vt * Ulo := Nat.mul_le_mul hvR.2 h
      have h2 : Vt * Ulo ≤ S₀ := by rw [hUlo_def, mul_comm]; exact Nat.div_mul_le_self S₀ Vt
      omega
    · have : u ≤ v * u := Nat.le_mul_of_pos_left u (by omega)
      omega
  set 𝒰' := 𝒰.filter (fun u => u ∈ Ioc Ulo S₁) with h𝒰'
  have e1 : ∑ u ∈ 𝒰, b u * ∑ v ∈ 𝒱, F u v = ∑ u ∈ 𝒰', b u * ∑ v ∈ 𝒱, F u v := by
    rw [h𝒰', sum_filter]
    refine sum_congr rfl fun u _ => ?_
    split_ifs with h
    · rfl
    · rw [hzero u h, mul_zero]
  rw [e1]
  -- step 2: `u`-blocks
  have htm : Monotone (tseq Ulo 2) := tseq_mono
  have htKu : S₁ < tseq Ulo 2 Ku := by
    have h1 := tseq_pow (U := Ulo) (T := 2) (by norm_num) (Nat.log 2 S₁ + 1)
    have h2 : S₁ < 2 ^ (Nat.log 2 S₁ + 1) := Nat.lt_pow_succ_log_self (by norm_num) S₁
    have h3 : 2 ^ (Nat.log 2 S₁ + 1) ≤ 2 ^ (Nat.log 2 S₁ + 1) * Ulo :=
      Nat.le_mul_of_pos_right _ (by omega)
    rw [hKu]; omega
  have h𝒰'sub : 𝒰' ⊆ Ioc (tseq Ulo 2 0) (tseq Ulo 2 Ku) := by
    intro u hu
    have := mem_Ioc.1 (mem_filter.1 hu).2
    rw [mem_Ioc]
    exact ⟨this.1, by omega⟩
  have e2 : ∑ u ∈ 𝒰', b u * ∑ v ∈ 𝒱, F u v = ∑ j ∈ range Ku,
      ∑ u ∈ 𝒰'.filter (fun u => u ∈ Ioc (tseq Ulo 2 j) (tseq Ulo 2 (j + 1))),
        b u * ∑ v ∈ 𝒱, F u v := sum_dyadic 𝒰' (tseq Ulo 2) htm Ku h𝒰'sub _
  rw [e2]
  -- step 3: `v`-blocks
  set tv : ℕ → ℕ := fun i => 2 ^ i * V₀ with htv
  have htvm : Monotone tv := fun x y hxy =>
    Nat.mul_le_mul_right _ (Nat.pow_le_pow_right (by norm_num) hxy)
  have h𝒱' : 𝒱 ⊆ Ioc (tv 0) (tv Kv) := by simpa [htv] using h𝒱
  have e3 : ∀ u, ∑ v ∈ 𝒱, F u v = ∑ i ∈ range Kv,
      ∑ v ∈ 𝒱.filter (fun v => v ∈ Ioc (tv i) (tv (i + 1))), F u v :=
    fun u => sum_dyadic 𝒱 tv htvm Kv h𝒱' _
  -- per piece
  have hpiece : ∀ j, ∀ i ∈ range Kv,
      ‖∑ u ∈ 𝒰'.filter (fun u => u ∈ Ioc (tseq Ulo 2 j) (tseq Ulo 2 (j + 1))), b u *
        ∑ v ∈ 𝒱.filter (fun v => v ∈ Ioc (tv i) (tv (i + 1))), F u v‖ ≤ RHSm := by
    intro j i hi
    have hi' : i < Kv := mem_range.1 hi
    have hU₀lo : Ulo ≤ tseq Ulo 2 j := tseq_ge j
    have hV₁ : V₀ ≤ tv i := Nat.le_mul_of_pos_left _ (by positivity)
    have hV₁t : tv i ≤ Vt := Nat.mul_le_mul_right _ (Nat.pow_le_pow_right (by norm_num) hi'.le)
    by_cases hcase : S₁ ≤ tv i * tseq Ulo 2 j
    · have h0 : ∑ u ∈ 𝒰'.filter (fun u => u ∈ Ioc (tseq Ulo 2 j) (tseq Ulo 2 (j + 1))), b u *
          ∑ v ∈ 𝒱.filter (fun v => v ∈ Ioc (tv i) (tv (i + 1))), F u v = 0 := by
        refine sum_eq_zero fun u hu => ?_
        have hu' := mem_Ioc.1 (mem_filter.1 hu).2
        rw [sum_eq_zero fun v hv => ?_, mul_zero]
        have hv' := mem_Ioc.1 (mem_filter.1 hv).2
        simp only [hF]
        rw [if_neg, mul_zero]
        intro hI
        have h1 := (mem_Ioc.1 hI).2
        have h2 : tv i * tseq Ulo 2 j < v * u := Nat.mul_lt_mul'' hv'.1 hu'.1
        omega
      rw [h0, norm_zero]; exact hRHS0
    · rw [not_le] at hcase
      set 𝒰j := 𝒰'.filter (fun u => u ∈ Ioc (tseq Ulo 2 j) (tseq Ulo 2 (j + 1))) with h𝒰j
      set 𝒱i := 𝒱.filter (fun v => v ∈ Ioc (tv i) (tv (i + 1))) with h𝒱i
      set X : ℕ → ℕ → ℕ → ℂ := fun m u v => ampI S₀ S₁ (jm m) (Lm m) v u *
        (eR (Ym m / ((v : ℝ) * u)) * Γ m ((v * (u % Q)) % Q)) with hX
      have hexp : ∑ u ∈ 𝒰j, b u * ∑ v ∈ 𝒱i, F u v =
          ∑ m ∈ 𝒦, coef m * ∑ u ∈ 𝒰j, b u * ∑ v ∈ 𝒱i, a v * X m u v := by
        have hrow : ∀ u v, F u v = ∑ m ∈ 𝒦, coef m * (a v * X m u v) := by
          intro u v
          simp only [hF, hX]
          rw [rowR_mask, mul_sum]
          exact sum_congr rfl fun m _ => by ring
        calc ∑ u ∈ 𝒰j, b u * ∑ v ∈ 𝒱i, F u v
            = ∑ u ∈ 𝒰j, ∑ v ∈ 𝒱i, ∑ m ∈ 𝒦, coef m * (b u * (a v * X m u v)) := by
              refine sum_congr rfl fun u _ => ?_
              rw [mul_sum]; refine sum_congr rfl fun v _ => ?_
              rw [hrow, mul_sum]; exact sum_congr rfl fun m _ => by ring
          _ = ∑ u ∈ 𝒰j, ∑ m ∈ 𝒦, ∑ v ∈ 𝒱i, coef m * (b u * (a v * X m u v)) :=
              sum_congr rfl fun u _ => sum_comm
          _ = ∑ m ∈ 𝒦, ∑ u ∈ 𝒰j, ∑ v ∈ 𝒱i, coef m * (b u * (a v * X m u v)) := sum_comm
          _ = _ := by
              refine sum_congr rfl fun m _ => ?_
              rw [mul_sum]; refine sum_congr rfl fun u _ => ?_
              rw [mul_sum, mul_sum]
      rw [hexp]
      refine (norm_sum_le _ _).trans (sum_le_sum fun m hm => ?_)
      rw [norm_mul]
      refine mul_le_mul_of_nonneg_left ?_ (norm_nonneg _)
      have hYm := hY m hm
      have hQR : (0 : ℝ) < Q := by exact_mod_cast hQ
      have hVtpos : (0 : ℝ) < ((2 ^ Kv * V₀ : ℕ) : ℝ) := by
        have : 0 < 2 ^ Kv * V₀ := by positivity
        exact_mod_cast this
      have hYpos : 0 < |Ym m| := lt_of_lt_of_le (by positivity) hYm
      have hYV₁ : 8 * (Q : ℝ) * ((tv i : ℕ) : ℝ) ^ 2 ≤ |Ym m| := by
        refine le_trans ?_ hYm
        have : ((tv i : ℕ) : ℝ) ≤ ((2 ^ Kv * V₀ : ℕ) : ℝ) := by exact_mod_cast hV₁t
        have h0 : (0 : ℝ) ≤ ((tv i : ℕ) : ℝ) := Nat.cast_nonneg _
        gcongr
      have hP := R_piece c C hc hC hcab Q hQ 𝒰j 𝒱i (tseq Ulo 2 j) (tseq Ulo 2 (j + 1)) (tv i)
        S₀ S₁ (jm m) (Lm m) (Ym m) (by omega)
        (by
          have := tseq_succ (U := Ulo) (T := 2) j
          rw [this]; omega)
        (fun u hu => (mem_filter.1 hu).2)
        (by
          intro v hv
          have := mem_Ioc.1 (mem_filter.1 hv).2
          rw [mem_Ioc]
          refine ⟨this.1, ?_⟩
          have e : tv (i + 1) = 2 * tv i := by simp only [htv]; ring
          omega)
        (by omega) hYV₁ (hjm m hm) (hLm m hm) a b A hA
        (fun v hv => ha v (mem_filter.1 hv).1)
        (fun u hu => by
          have hu1 := mem_filter.1 (mem_filter.1 hu).1
          exact hb u hu1.1 (mem_Ioc.1 hu1.2).2)
        (fun v ρ => Γ m ((v * ρ) % Q)) (fun v ρ => hΓ m hm _)
      have hmono := RPsi_ge c C hc hC Q V₀ Ulo S₁ (tseq Ulo 2 j) (tv i) (Ym m) hQ hUlo hU₀lo hV₀ hV₁
        hcase hYpos
      have hΨ0 := RPsi_nonneg c C hC Q V₀ Ulo S₁ (Ym m)
      have h2 : ‖∑ u ∈ 𝒰j, b u * ∑ v ∈ 𝒱i, a v * X m u v‖ ^ 2 ≤
          (A ^ 2 * Real.sqrt (2 * RPsi c C Q V₀ Ulo S₁ (Ym m))) ^ 2 := by
        rw [mul_pow, Real.sq_sqrt (by positivity)]
        refine le_trans hP ?_
        have := mul_le_mul_of_nonneg_left hmono (show (0 : ℝ) ≤ 2 * A ^ 4 by positivity)
        nlinarith [this]
      exact (pow_le_pow_iff_left₀ (norm_nonneg _) (by positivity) (by norm_num)).1 h2
  -- assemble
  calc ‖∑ j ∈ range Ku, ∑ u ∈ 𝒰'.filter (fun u => u ∈ Ioc (tseq Ulo 2 j) (tseq Ulo 2 (j + 1))),
        b u * ∑ v ∈ 𝒱, F u v‖
      ≤ ∑ j ∈ range Ku, ∑ i ∈ range Kv,
          ‖∑ u ∈ 𝒰'.filter (fun u => u ∈ Ioc (tseq Ulo 2 j) (tseq Ulo 2 (j + 1))), b u *
            ∑ v ∈ 𝒱.filter (fun v => v ∈ Ioc (tv i) (tv (i + 1))), F u v‖ := by
        refine (norm_sum_le _ _).trans (sum_le_sum fun j _ => ?_)
        have e4 : ∑ u ∈ 𝒰'.filter (fun u => u ∈ Ioc (tseq Ulo 2 j) (tseq Ulo 2 (j + 1))),
            b u * ∑ v ∈ 𝒱, F u v = ∑ i ∈ range Kv,
              ∑ u ∈ 𝒰'.filter (fun u => u ∈ Ioc (tseq Ulo 2 j) (tseq Ulo 2 (j + 1))), b u *
                ∑ v ∈ 𝒱.filter (fun v => v ∈ Ioc (tv i) (tv (i + 1))), F u v := by
          calc _ = ∑ u ∈ 𝒰'.filter (fun u => u ∈ Ioc (tseq Ulo 2 j) (tseq Ulo 2 (j + 1))),
                ∑ i ∈ range Kv, b u *
                  ∑ v ∈ 𝒱.filter (fun v => v ∈ Ioc (tv i) (tv (i + 1))), F u v :=
                sum_congr rfl fun u _ => by rw [e3 u, mul_sum]
            _ = _ := sum_comm
        rw [e4]
        exact norm_sum_le _ _
    _ ≤ ∑ _j ∈ range Ku, ∑ _i ∈ range Kv, RHSm :=
        sum_le_sum fun j _ => sum_le_sum fun i hi => hpiece j i hi
    _ = _ := by
        rw [sum_const, sum_const, card_range, card_range, nsmul_eq_mul, nsmul_eq_mul]
        push_cast; ring

end GoldC.QuillonRBilinear

#print axioms GoldC.QuillonRBilinear.norm_rowR_le
#print axioms GoldC.QuillonRBilinear.rowR_mask
#print axioms GoldC.QuillonRBilinear.RPsi_ge
#print axioms GoldC.QuillonRBilinear.R_bilinear_full
