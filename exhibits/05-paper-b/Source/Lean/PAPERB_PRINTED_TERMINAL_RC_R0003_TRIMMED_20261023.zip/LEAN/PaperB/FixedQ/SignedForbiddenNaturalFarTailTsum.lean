import PaperB.FixedQ.SignedForbiddenMainRate
import PaperB.FixedQ.SignedForbiddenNaturalFarTailRate

open scoped BigOperators

namespace PaperB.FixedQ

lemma summable_fixedQShiuReciprocalFarTailTerm
    (q : ℕ) {H : ℕ} (hH : 0 < H) :
    Summable (fun m : ℕ =>
      if H ^ 2 < m then fixedQShiuWeight q m / (m : ℝ) else 0) := by
  let f : ℕ → ℝ := fun m =>
    if H ^ 2 < m then fixedQShiuWeight q m / (m : ℝ) else 0
  let g : ℕ → ℝ := fun m =>
    (H : ℝ) ^ (-3 / 2 : ℝ) *
      (fixedQShiuWeight q m * (m : ℝ) ^ (-1 / 4 : ℝ))
  have hf0 : ∀ m, 0 ≤ f m := by
    intro m
    dsimp [f]
    by_cases hm : H ^ 2 < m
    · rw [if_pos hm]
      exact div_nonneg (fixedQShiuWeight_nonneg q m) (Nat.cast_nonneg m)
    · rw [if_neg hm]
  have hfg : ∀ m, f m ≤ g m := by
    intro m
    dsimp [f, g]
    by_cases hm : H ^ 2 < m
    · rw [if_pos hm]
      exact fixedQShiuWeight_div_le_quarter_rankin q hH hm
    · rw [if_neg hm]
      exact mul_nonneg
        (Real.rpow_nonneg (Nat.cast_nonneg H) _)
        (mul_nonneg (fixedQShiuWeight_nonneg q m)
          (Real.rpow_nonneg (Nat.cast_nonneg m) _))
  have hg : Summable g := by
    dsimp [g]
    exact (summable_fixedQShiuWeight_mul_quarter q).mul_left
      ((H : ℝ) ^ (-3 / 2 : ℝ))
  exact Summable.of_nonneg_of_le hf0 hfg hg

theorem abs_sourceForbiddenNaturalFarTail_tsum_le
    {q a H : ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2 : ¬ 2 ∣ q → 2 ∣ H)
    (d : Finset ℕ) :
    |∑' m : ℕ,
        if H ^ 2 < m then
          sourceForbiddenBooleanNaturalTerm
            q a H (primeSetProduct d) m
        else 0| ≤
      6 * (H : ℝ) * fixedQShiuReciprocalFarTail q H := by
  let S : Set ℕ := {m | H ^ 2 < m}
  let f : ℕ → ℝ := fun m =>
    if H ^ 2 < m then
      sourceForbiddenBooleanNaturalTerm q a H (primeSetProduct d) m
    else 0
  let g : ℕ → ℝ := fun m =>
    if H ^ 2 < m then fixedQShiuWeight q m / (m : ℝ) else 0
  have hsrc0 :=
    summable_sourceForbiddenBooleanNaturalTerm
      (q := q) (a := a) (H := H) hq hH h2 d
  have hf : Summable f := by
    have hind := hsrc0.indicator S
    exact hind.congr (fun m => by
      dsimp [f, S]
      by_cases hm : H ^ 2 < m <;> simp [Set.indicator, hm])
  have hg : Summable g := by
    dsimp [g]
    exact summable_fixedQShiuReciprocalFarTailTerm q hH
  have hmajor : ∀ m, |f m| ≤ 6 * (H : ℝ) * g m := by
    intro m
    dsimp [f, g]
    by_cases hm : H ^ 2 < m
    · rw [if_pos hm, if_pos hm]
      exact abs_sourceForbiddenBooleanNaturalTerm_far_le hH h2 hm
    · rw [if_neg hm, if_neg hm]
      simp
  have hgmul : Summable (fun m => 6 * (H : ℝ) * g m) :=
    hg.mul_left (6 * (H : ℝ))
  have hnormsum :
      (∑' m, |f m|) ≤ ∑' m, 6 * (H : ℝ) * g m := by
    exact hf.norm.tsum_le_tsum hmajor hgmul
  calc
    |∑' m, f m| ≤ ∑' m, |f m| := by
      simpa [Real.norm_eq_abs] using norm_tsum_le_tsum_norm hf.norm
    _ ≤ ∑' m, 6 * (H : ℝ) * g m := hnormsum
    _ = 6 * (H : ℝ) * (∑' m, g m) := by rw [tsum_mul_left]
    _ = 6 * (H : ℝ) * fixedQShiuReciprocalFarTail q H := by
      rfl

#print axioms summable_fixedQShiuReciprocalFarTailTerm
#print axioms abs_sourceForbiddenNaturalFarTail_tsum_le

end PaperB.FixedQ
