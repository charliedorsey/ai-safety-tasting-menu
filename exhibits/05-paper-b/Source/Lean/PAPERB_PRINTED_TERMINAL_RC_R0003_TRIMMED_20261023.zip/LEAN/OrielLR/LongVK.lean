import OrielLR.InnerB

/-!
# Oriel L/R — the long-variable estimate for a fixed short modulus

For a fixed short modulus `m` and the long variable `n ∈ (a, b]`:

`|∑ b_{F'}(n) ψ_n(X₀/n)| ≤ A_{3/4} (D^{3/4} · 2Q(P+1)B/a + D^{-1/4} (2P+2)B(1 + log(b/a)))
                             + A₁ (P+1) B Lb C (E₀ + bQ/X₀)`.
-/

open Finset

namespace OrielUpper

variable {P : ℕ} [NeZero P]

lemma sum_bW_psi_exchange {m H F : ℕ} {Λ : ZMod P → ℝ} {α β : ZMod P} {X0 : ℝ} {A Bn : ℕ}
    (hcopF : ∀ n, bW F n ≠ 0 → Nat.Coprime n (P * m)) :
    ∑ n ∈ Ioc A Bn, bW F n * psiR m H Λ α β (n : ZMod P) (n : ZMod m) (X0 / n) =
      ∑ e ∈ Icc 1 Bn, KW F e * innerS m H Λ α β X0 A Bn e := by
  set Q := P * m
  have hpt : ∀ n, bW F n * psiR m H Λ α β (n : ZMod P) (n : ZMod m) (X0 / n) =
      ∑ e ∈ n.divisors, (if Nat.Coprime n Q then
        KW F e * (psiR m H Λ α β (n : ZMod P) (n : ZMod m) (X0 / n) / n) else 0) := by
    intro n
    by_cases hc : Nat.Coprime n Q
    · simp only [if_pos hc]
      rw [← sum_mul, sum_divisors_KW, bW]; ring
    · simp only [if_neg hc, sum_const_zero]
      have : bW F n = 0 := by
        by_contra h; exact hc (hcopF n h)
      rw [this, zero_mul]
  rw [sum_congr rfl (fun n _ => hpt n), oriel_divisor_exchange]
  apply sum_congr rfl
  intro e _
  unfold innerS
  rw [mul_sum]
  apply sum_congr rfl
  intro k _
  split_ifs <;> simp [mul_div_assoc]

theorem long_vk {m H F : ℕ} [NeZero m] {Λ : ZMod P → ℝ} {B : ℝ} (hB : ∀ z, |Λ z| ≤ B)
    {α β : ZMod P} (hβ : IsUnit β) (hmP : Nat.Coprime m P) (hH : IsUnit (H : ZMod m))
    (hm1 : 1 < m) {cK Ck : ℝ} (hcK : 0 < cK) (hCk : 0 ≤ Ck) (hK : KarBound cK Ck)
    (hcopF : ∀ n, bW F n ≠ 0 → Nat.Coprime n (P * m))
    {X0 : ℝ} {a b D N0 Lb : ℕ} (ha : 1 ≤ a) (hab : a ≤ b) (hD : 1 ≤ D) (hN0 : 1 ≤ N0)
    (hA : (N0 + 1) * (P * m) * D ≤ a) (hX : 2 * (D : ℝ) * ((P * m : ℕ) : ℝ) ^ 2 ≤ X0)
    (hLb : b ≤ 2 ^ Lb) :
    |∑ n ∈ Ioc a b, bW F n * psiR m H Λ α β (n : ZMod P) (n : ZMod m) (X0 / n)| ≤
      Asig F b (3 / 4) * ((D : ℝ) ^ (3 / 4 : ℝ) * (2 * ((P * m : ℕ) : ℝ) * ((P : ℝ) + 1) * B / a) +
          (D : ℝ) ^ (-(1 / 4 : ℝ)) * ((2 * P + 2) * B * (1 + Real.log ((b : ℝ) / a)))) +
        Asig F b 1 * (((P : ℝ) + 1) * B * Lb * Ck * (karE cK N0 X0 + b * ((P * m : ℕ) : ℝ) / X0)) := by
  set Q := P * m with hQdef
  have hQ : 0 < Q := Nat.mul_pos (NeZero.pos P) (NeZero.pos m)
  have hB0 : 0 ≤ B := le_trans (abs_nonneg _) (hB 0)
  have har : (0 : ℝ) < a := by exact_mod_cast (show 0 < a by omega)
  have hDr : (1 : ℝ) ≤ D := by exact_mod_cast hD
  have hX0 : 0 ≤ X0 := le_trans (by positivity) hX
  set T1 : ℝ := 2 * (Q : ℝ) * ((P : ℝ) + 1) * B / a
  set T2 : ℝ := ((P : ℝ) + 1) * B * Lb * Ck * (karE cK N0 X0 + b * (Q : ℝ) / X0)
  set T3 : ℝ := (2 * P + 2) * B * (1 + Real.log ((b : ℝ) / a))
  have hT1 : 0 ≤ T1 := by positivity
  have hT2 : 0 ≤ T2 := by simp only [T2, karE]; positivity
  have hT3 : 0 ≤ T3 := by
    have := log_ratio_nonneg ha hab
    simp only [T3]; positivity
  rw [sum_bW_psi_exchange hcopF]
  refine (abs_sum_le_sum_abs _ _).trans ?_
  have hpt : ∀ e ∈ Icc 1 b, |KW F e * innerS m H Λ α β X0 a b e| ≤
      |KW F e| * (e : ℝ) ^ (-(3 / 4 : ℝ)) * ((D : ℝ) ^ (3 / 4 : ℝ) * T1 + (D : ℝ) ^ (-(1 / 4 : ℝ)) * T3) +
        |KW F e| * (e : ℝ) ^ (-(1 : ℝ)) * T2 := by
    intro e he
    have he1 : 1 ≤ e := (mem_Icc.mp he).1
    have heb : e ≤ b := (mem_Icc.mp he).2
    have her : (0 : ℝ) < e := by exact_mod_cast (show 0 < e by omega)
    have hKe := abs_nonneg (KW F e)
    rw [abs_mul]
    have hD34 : 0 < (D : ℝ) ^ (3 / 4 : ℝ) := by positivity
    have hDm : 0 < (D : ℝ) ^ (-(1 / 4 : ℝ)) := by positivity
    have he34 : 0 < (e : ℝ) ^ (-(3 / 4 : ℝ)) := by positivity
    have he1' : (e : ℝ) ^ (-(1 : ℝ)) = 1 / e := by rw [Real.rpow_neg_one, one_div]
    by_cases heD : e ≤ D
    · by_cases hcop : Nat.Coprime e Q
      · have hAe : (N0 + 1) * Q ≤ a / e := by
          apply (Nat.le_div_iff_mul_le (by omega)).mpr
          calc (N0 + 1) * Q * e ≤ (N0 + 1) * Q * D := Nat.mul_le_mul_left _ heD
            _ ≤ a := hA
        have hXe : 2 * (e : ℝ) * ((Q : ℕ) : ℝ) ^ 2 ≤ X0 := by
          have : (e : ℝ) ≤ D := by exact_mod_cast heD
          have : 2 * (e : ℝ) * ((Q : ℕ) : ℝ) ^ 2 ≤ 2 * (D : ℝ) * ((Q : ℕ) : ℝ) ^ 2 := by
            gcongr
          linarith
        have hin := inner_vk (H := H) (α := α) hB hβ hmP hH hm1 hcK hCk hK he1 hcop hN0 hAe hab
          hXe hLb
        -- e * (a/e) ≥ a/2
        have hea : (a : ℝ) ≤ 2 * e * ((a / e : ℕ) : ℝ) := by
          have := two_mul_div_ge (show 0 < e by omega) (show e ≤ a by
            have : e ≤ D := heD
            have : D ≤ a := le_trans (Nat.le_mul_of_pos_left D (by positivity)) hA
            omega)
          exact_mod_cast this
        have hae : (0 : ℝ) < ((a / e : ℕ) : ℝ) := by
          have : 1 ≤ a / e := le_trans (Nat.one_le_iff_ne_zero.mpr (by positivity)) hAe
          exact_mod_cast (show 0 < a / e by omega)
        have hfirst : (Q : ℝ) * ((P : ℝ) + 1) * B / ((a / e : ℕ) : ℝ) / e ≤ T1 := by
          simp only [T1]
          rw [div_div, div_le_div_iff₀ (by positivity) har]
          have h0 : 0 ≤ (Q : ℝ) * ((P : ℝ) + 1) * B := by positivity
          nlinarith
        have hge1 : 1 ≤ (e : ℝ) ^ (-(3 / 4 : ℝ)) * (D : ℝ) ^ (3 / 4 : ℝ) := by
          rw [Real.rpow_neg her.le, inv_mul_eq_div, one_le_div (by positivity)]
          exact Real.rpow_le_rpow her.le (by exact_mod_cast heD) (by norm_num)
        rw [← hQdef] at hin
        have hbound : |innerS m H Λ α β X0 a b e| ≤ T1 + T2 / e := by
          refine hin.trans ?_
          rw [add_div]
          simp only [T2]
          linarith [hfirst]
        calc |KW F e| * |innerS m H Λ α β X0 a b e| ≤ |KW F e| * (T1 + T2 / e) :=
              mul_le_mul_of_nonneg_left hbound hKe
          _ ≤ |KW F e| * ((e : ℝ) ^ (-(3 / 4 : ℝ)) * (D : ℝ) ^ (3 / 4 : ℝ)) * T1 +
              |KW F e| * (e : ℝ) ^ (-(1 : ℝ)) * T2 := by
              rw [he1']
              have : |KW F e| * T1 ≤ |KW F e| * ((e : ℝ) ^ (-(3 / 4 : ℝ)) * (D : ℝ) ^ (3 / 4 : ℝ)) * T1 := by
                have := mul_le_mul_of_nonneg_left hge1 hKe
                nlinarith
              have e2 : |KW F e| * (T1 + T2 / e) = |KW F e| * T1 + |KW F e| * (1 / e) * T2 := by ring
              linarith
          _ ≤ _ := by
              have : 0 ≤ |KW F e| * (e : ℝ) ^ (-(3 / 4 : ℝ)) * ((D : ℝ) ^ (-(1 / 4 : ℝ)) * T3) := by
                positivity
              nlinarith
      · rw [innerS_eq_zero_of_not_coprime hcop, abs_zero, mul_zero]
        positivity
    · push_neg at heD
      have htail := oriel_inner_tail (H := H) (α := α) hB hβ hmP hX0 ha hab he1
      have hsplit : 1 / (e : ℝ) ≤ (e : ℝ) ^ (-(3 / 4 : ℝ)) * (D : ℝ) ^ (-(1 / 4 : ℝ)) := by
        have h1 : (e : ℝ) ^ (-(3 / 4 : ℝ)) * (e : ℝ) ^ (-(1 / 4 : ℝ)) = 1 / e := by
          rw [← Real.rpow_add her]; norm_num; exact Real.rpow_neg_one _
        rw [← h1]
        apply mul_le_mul_of_nonneg_left _ he34.le
        exact Real.rpow_le_rpow_of_nonpos (by positivity) (by exact_mod_cast heD.le) (by norm_num)
      have hbound : |innerS m H Λ α β X0 a b e| ≤
          (e : ℝ) ^ (-(3 / 4 : ℝ)) * (D : ℝ) ^ (-(1 / 4 : ℝ)) * T3 := by
        refine htail.trans ?_
        rw [div_eq_mul_one_div, mul_comm]
        exact mul_le_mul_of_nonneg_right hsplit hT3
      have : 0 ≤ |KW F e| * (e : ℝ) ^ (-(3 / 4 : ℝ)) * ((D : ℝ) ^ (3 / 4 : ℝ) * T1) := by positivity
      have : 0 ≤ |KW F e| * (e : ℝ) ^ (-(1 : ℝ)) * T2 := by positivity
      have := mul_le_mul_of_nonneg_left hbound hKe
      nlinarith
  refine (sum_le_sum hpt).trans (le_of_eq ?_)
  rw [sum_add_distrib, ← sum_mul, ← sum_mul]
  unfold Asig
  ring

end OrielUpper
