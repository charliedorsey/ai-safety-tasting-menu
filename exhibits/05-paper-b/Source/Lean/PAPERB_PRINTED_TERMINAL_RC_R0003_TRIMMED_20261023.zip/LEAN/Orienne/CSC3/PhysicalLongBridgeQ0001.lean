import GoldC.QuillonLongFinal
import Orienne.CSC3.PhysicalCoreBridgeR0001
import Orienne.CSC3.WeilQuillonBridgeR0002
import Orienne.CSC3.CoreHighPaidConsumerR0002

/-!
Quillon LONG return Q0001 — PROPOSED court integration file (not compiled by Quillon: it imports
the Orienne court tree, which Quillon does not have). Mirrors `PhysicalCoreBridgeR0001`.

1. `quillon_weilHyp`: discharges the single named hypothesis of the LONG return with the
   already-GREEN `norm_quillon_K_weil` (identical statement, checked textually).
2. `signed_long_copy_eq_native`: copied `signedLongMiddle` = literal native one, by `rfl`
   (same body; the copied dependencies are the R0014 verbatim copies already bridged by `rfl`).
3. `long_source_native_sublog`: the literal native LONG premise.
4. `paperB_terminal_of_native_low`: the terminal statement from LOW alone.
No new analytic hypothesis, no custom axiom.
-/

open scoped BigOperators Classical
namespace Orienne.CSC3

theorem quillon_weilHyp : GoldC.QuillonLWeil.WeilHyp :=
  fun s _ a b => norm_quillon_K_weil s a b

theorem signed_long_copy_eq_native (Jlow Jhigh : ℕ → ℕ) (δ : ℝ) (q a h : ℕ) :
    GoldC.QuillonCopyM.signedLongMiddle Jlow Jhigh δ q a h =
      Merivelle.Central.signedLongMiddle Jlow Jhigh δ q a h := by
  rfl

theorem long_source_native_sublog (Jlow Jhigh : ℕ → ℕ) (δ : ℝ)
    (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    Merivelle.Central.SourceUniformSublog
      (Merivelle.Central.signedLongMiddle Jlow Jhigh δ) := by
  have h := GoldC.QuillonLongFinal.long_sublog quillon_weilHyp Jlow Jhigh δ hδ0 hδ1
  have e : Merivelle.Central.signedLongMiddle Jlow Jhigh δ =
      GoldC.QuillonCopyM.signedLongMiddle Jlow Jhigh δ := by
    funext q a x; exact (signed_long_copy_eq_native Jlow Jhigh δ q a x).symm
  have hcopy : GoldC.QuillonCopyM.SourceUniformSublog
      (Merivelle.Central.signedLongMiddle Jlow Jhigh δ) := by
    rw [e]; exact h
  exact copied_rate_to_native _ hcopy

/-- Paper B terminal statement from the LOW rate alone (CORE, HIGH, LONG paid). -/
theorem paperB_terminal_of_native_low
    (Jlow : ℕ → ℕ) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3)
    (hord : ∀ h, Jlow h ≤ GoldC.orienneCentralHighCut h)
    (hLow : Merivelle.Central.SourceUniformSublog (Merivelle.Central.lowSector Jlow)) :
    PaperB.Closure.PaperBTerminalStatement :=
  paperB_terminal_of_native_low_long Jlow δ hδ0 hδ1 hord hLow
    (long_source_native_sublog Jlow GoldC.orienneCentralHighCut δ hδ0 hδ1)

#print axioms quillon_weilHyp
#print axioms long_source_native_sublog
#print axioms paperB_terminal_of_native_low
end Orienne.CSC3
