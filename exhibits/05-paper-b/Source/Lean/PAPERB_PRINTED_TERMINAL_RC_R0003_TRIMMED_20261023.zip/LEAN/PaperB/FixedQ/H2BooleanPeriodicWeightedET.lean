import PaperB.FixedQ.H2BooleanAffineET
import PaperB.FixedQ.TwoDimensionalClosure
import Mathlib.Data.Int.CardIntervalMod
import Mathlib.Algebra.Order.Floor.Div

open scoped BigOperators ComplexConjugate
namespace PaperB.FixedQ


lemma nat_lt_ceilDiv_iff_mul_lt
    {a b n : ℕ} (hb : 0 < b) :
    n < a ⌈/⌉ b ↔ b * n < a := by
  rw [lt_iff_not_ge, ceilDiv_le_iff_le_mul hb]
  exact not_le

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def rangeResidueQuotientEquiv
    (P H : ℕ) (hP : 0 < P) :
    Fin H ≃ Σ c : Fin P, Fin ((H - c.1) ⌈/⌉ P) where
  toFun y := by
    let c : Fin P := ⟨y.1 % P, Nat.mod_lt _ hP⟩
    have hcH : c.1 < H := by
      have hyrem : y.1 % P ≤ y.1 := Nat.mod_le _ _
      exact lt_of_le_of_lt hyrem y.2
    have hydecomp : y.1 % P + P * (y.1 / P) = y.1 :=
      Nat.mod_add_div y.1 P
    have hmul : P * (y.1 / P) < H - c.1 := by
      dsimp [c]
      omega
    exact ⟨c, ⟨y.1 / P, (nat_lt_ceilDiv_iff_mul_lt hP).2 hmul⟩⟩
  invFun z := by
    let c := z.1
    let n := z.2
    have hmul : P * n.1 < H - c.1 :=
      (nat_lt_ceilDiv_iff_mul_lt hP).1 n.2
    have hcH : c.1 < H := by
      omega
    refine ⟨c.1 + P * n.1, ?_⟩
    omega
  left_inv y := by
    apply Fin.ext
    change y.1 % P + P * (y.1 / P) = y.1
    exact Nat.mod_add_div y.1 P
  right_inv z := by
    rcases z with ⟨c, n⟩
    have hcval : (c.1 + P * n.1) % P = c.1 := by
      rw [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt c.2]
    have hc :
        (⟨(c.1 + P * n.1) % P, Nat.mod_lt _ hP⟩ : Fin P) = c := by
      apply Fin.ext
      exact hcval
    apply Sigma.ext hc
    have hidx :
        (H - (⟨(c.1 + P * n.1) % P, Nat.mod_lt _ hP⟩ : Fin P).1) ⌈/⌉ P =
          (H - c.1) ⌈/⌉ P := by
      rw [hc]
    apply (Fin.heq_ext_iff hidx).2
    change (c.1 + P * n.1) / P = n.1
    rw [Nat.add_mul_div_left c.1 n.1 hP, Nat.div_eq_of_lt c.2, zero_add]

lemma sum_range_eq_sum_residue_quotient
    {R : Type} [AddCommMonoid R]
    (f : ℕ → R) (P H : ℕ) (hP : 0 < P) :
    (∑ y ∈ Finset.range H, f y) =
      ∑ c : Fin P, ∑ n : Fin ((H - c.1) ⌈/⌉ P),
        f (c.1 + P * n.1) := by
  rw [← Fin.sum_univ_eq_sum_range f H]
  let e := rangeResidueQuotientEquiv P H hP
  calc
    (∑ y : Fin H, f y.1) =
        ∑ z : (Σ c : Fin P, Fin ((H - c.1) ⌈/⌉ P)),
          f (z.1.1 + P * z.2.1) := by
            apply Fintype.sum_equiv e
            intro y
            have hy := congrArg Fin.val (e.symm_apply_apply y)
            simpa [e, rangeResidueQuotientEquiv] using congrArg f hy.symm
    _ = ∑ c : Fin P, ∑ n : Fin ((H - c.1) ⌈/⌉ P),
          f (c.1 + P * n.1) := by
            simpa using (Fintype.sum_sigma'
              (fun c : Fin P => fun n : Fin ((H - c.1) ⌈/⌉ P) =>
                f (c.1 + P * n.1)))

#print axioms sum_range_eq_sum_residue_quotient

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma residue_prefix_discrepancy_eq_indicator
    {m L t : ℕ} (hm : 0 < m) (ht : t < m) :
    (∑ n ∈ Finset.range L,
        if n ≡ t [MOD m] then (1 : ℝ) else 0) -
        (L : ℝ) / m =
      (if t < L % m then 1 else 0) -
        ((L % m : ℕ) : ℝ) / (m : ℝ) := by
  have hcount := Nat.count_modEq_card (b := L) (r := m) hm t
  rw [Nat.count_eq_card_filter_range] at hcount
  have hsum :
      (∑ n ∈ Finset.range L,
        if n ≡ t [MOD m] then (1 : ℝ) else 0) =
        (((Finset.range L).filter (fun n => n ≡ t [MOD m])).card : ℝ) := by
    exact Finset.sum_boole _ _
  rw [hsum]
  rw [hcount, Nat.mod_eq_of_lt ht]
  push_cast
  have hmR : (m : ℝ) ≠ 0 := by exact_mod_cast hm.ne'
  have hdecompR :
      (L : ℝ) = ((L % m : ℕ) : ℝ) +
        (m : ℝ) * ((L / m : ℕ) : ℝ) := by
    exact_mod_cast (Nat.mod_add_div L m).symm
  have hdiv :
      (L : ℝ) / (m : ℝ) =
        ((L / m : ℕ) : ℝ) + ((L % m : ℕ) : ℝ) / (m : ℝ) := by
    rw [hdecompR]
    field_simp [hmR]
    ring
  rw [hdiv]
  split_ifs <;> ring

#print axioms residue_prefix_discrepancy_eq_indicator

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma periodic_apply_add_mul
    {R : Type} {f : ℕ → R} {P c n : ℕ}
    (hper : Function.Periodic f P) :
    f (c + P * n) = f c := by
  simpa [Nat.mul_comm] using (hper.nat_mul n c)

#print axioms periodic_apply_add_mul

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma sum_Ioo_zero_eq_sum_range_pred_shift
    {R : Type} [AddCommMonoid R]
    (f : ℕ → R) (H : ℕ) :
    (∑ y ∈ Finset.Ioo 0 H, f y) =
      ∑ z ∈ Finset.range (H - 1), f (z + 1) := by
  classical
  have hset :
      Finset.Ioo 0 H =
        (Finset.range (H - 1)).image (fun z => z + 1) := by
    ext y
    simp only [Finset.mem_Ioo, Finset.mem_image, Finset.mem_range]
    constructor
    · intro hy
      refine ⟨y - 1, ?_, ?_⟩
      · omega
      · omega
    · rintro ⟨z, hz, rfl⟩
      omega
  rw [hset, Finset.sum_image]
  intro a ha b hb hab
  exact Nat.add_right_cancel hab

#print axioms sum_Ioo_zero_eq_sum_range_pred_shift

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma fixedQPeriod_pos (q : ℕ) (hq : 0 < q) : 0 < fixedQPeriod q := by
  unfold fixedQPeriod
  exact Nat.lcm_pos (by norm_num) hq

lemma activeHighPrime_coprime_fixedQPeriod
    {q p : ℕ} (hp : activeHighPrime q p) :
    p.Coprime (fixedQPeriod q) := by
  have hcop6q : p.Coprime (6 * q) := by
    rcases hp with ⟨hpPrime, hp5, hpq⟩
    rw [hpPrime.coprime_iff_not_dvd]
    intro hdiv
    rcases hpPrime.dvd_mul.mp hdiv with h6 | hq
    · have hpLe : p ≤ 6 := Nat.le_of_dvd (by norm_num : 0 < 6) h6
      have hp56 : p = 5 ∨ p = 6 := by omega
      rcases hp56 with rfl | rfl
      · norm_num at h6
      · norm_num at hpPrime
    · exact hpq hq
  have hdiv : fixedQPeriod q ∣ 6 * q := by
    unfold fixedQPeriod
    exact Nat.lcm_dvd_mul 6 q
  exact hcop6q.of_dvd_right hdiv

lemma activePrimeSetProduct_coprime_fixedQPeriod
    {q : ℕ} {S : Finset ℕ}
    (hActive : ∀ p ∈ S, activeHighPrime q p) :
    (primeSetProduct S).Coprime (fixedQPeriod q) := by
  unfold primeSetProduct
  apply Nat.Coprime.prod_left
  intro p hp
  exact activeHighPrime_coprime_fixedQPeriod (hActive p hp)

noncomputable def fixedProductBooleanPeriodicTwist
    (P H : ℕ) (S : Finset ℕ)
    (hP : P.Coprime (primeSetProduct S))
    (hH : H.Coprime (primeSetProduct S)) :
    (ZMod (primeSetProduct S))ˣ :=
  (ZMod.unitOfCoprime P hP)⁻¹ * ZMod.unitOfCoprime H hH

noncomputable def fixedProductBooleanPeriodicShift
    (P : ℕ) (S : Finset ℕ)
    (hP : P.Coprime (primeSetProduct S)) (c : ℕ) :
    ZMod (primeSetProduct S) :=
  -(((ZMod.unitOfCoprime P hP)⁻¹ :
      (ZMod (primeSetProduct S))ˣ) : ZMod (primeSetProduct S)) *
    ((c + 1 : ℕ) : ZMod (primeSetProduct S))

lemma periodic_progression_zmod_eq_affine
    {P H n c : ℕ} {S : Finset ℕ}
    (hm : 0 < primeSetProduct S)
    (hP : P.Coprime (primeSetProduct S))
    (hH : H.Coprime (primeSetProduct S))
    (e : ℕ) :
    ((c + 1 + P * n : ℕ) : ZMod (primeSetProduct S)) =
        ((H * e : ℕ) : ZMod (primeSetProduct S)) ↔
      (n : ZMod (primeSetProduct S)) =
        ((fixedProductBooleanPeriodicTwist P H S hP hH :
            (ZMod (primeSetProduct S))ˣ) : ZMod (primeSetProduct S)) *
            (e : ZMod (primeSetProduct S)) +
          fixedProductBooleanPeriodicShift P S hP c := by
  letI : NeZero (primeSetProduct S) := ⟨hm.ne'⟩
  let pU : (ZMod (primeSetProduct S))ˣ := ZMod.unitOfCoprime P hP
  let hU : (ZMod (primeSetProduct S))ˣ := ZMod.unitOfCoprime H hH
  have hp : (pU : ZMod (primeSetProduct S)) =
      (P : ZMod (primeSetProduct S)) := by
    simpa [pU] using ZMod.coe_unitOfCoprime P hP
  have hh : (hU : ZMod (primeSetProduct S)) =
      (H : ZMod (primeSetProduct S)) := by
    simpa [hU] using ZMod.coe_unitOfCoprime H hH
  constructor
  · intro h
    push_cast at h
    have h' := congrArg
      (fun z : ZMod (primeSetProduct S) =>
        ((pU⁻¹ : (ZMod (primeSetProduct S))ˣ) :
          ZMod (primeSetProduct S)) * z) h
    rw [← hp, ← hh] at h'
    simp only [mul_add, ← mul_assoc, Units.inv_mul, one_mul] at h'
    change (n : ZMod (primeSetProduct S)) =
      (((pU⁻¹ : (ZMod (primeSetProduct S))ˣ) : ZMod (primeSetProduct S)) *
          (hU : ZMod (primeSetProduct S)) * (e : ZMod (primeSetProduct S))) +
        (-((pU⁻¹ : (ZMod (primeSetProduct S))ˣ) : ZMod (primeSetProduct S)) *
          ((c + 1 : ℕ) : ZMod (primeSetProduct S)))
    push_cast
    linear_combination h'
  · intro h
    change (n : ZMod (primeSetProduct S)) =
      (((pU⁻¹ : (ZMod (primeSetProduct S))ˣ) : ZMod (primeSetProduct S)) *
          (hU : ZMod (primeSetProduct S)) * (e : ZMod (primeSetProduct S))) +
        (-((pU⁻¹ : (ZMod (primeSetProduct S))ˣ) : ZMod (primeSetProduct S)) *
          ((c + 1 : ℕ) : ZMod (primeSetProduct S))) at h
    have h' := congrArg
      (fun z : ZMod (primeSetProduct S) => (pU : ZMod (primeSetProduct S)) * z) h
    simp only [mul_add, mul_neg, ← mul_assoc, Units.mul_inv, one_mul,
      Units.val_mul] at h'
    push_cast at h'
    change ((c + 1 + P * n : ℕ) : ZMod (primeSetProduct S)) =
      ((H * e : ℕ) : ZMod (primeSetProduct S))
    push_cast
    rw [← hp, ← hh]
    linear_combination h'

lemma periodic_progression_modEq_iff_affine
    {P H n c : ℕ} {S : Finset ℕ}
    (hm : 0 < primeSetProduct S)
    (hP : P.Coprime (primeSetProduct S))
    (hH : H.Coprime (primeSetProduct S))
    (e : ℕ) :
    c + 1 + P * n ≡ H * e [MOD primeSetProduct S] ↔
      n ≡
        (((fixedProductBooleanPeriodicTwist P H S hP hH :
            (ZMod (primeSetProduct S))ˣ) : ZMod (primeSetProduct S)) *
            (e : ZMod (primeSetProduct S)) +
          fixedProductBooleanPeriodicShift P S hP c).val
        [MOD primeSetProduct S] := by
  letI : NeZero (primeSetProduct S) := ⟨hm.ne'⟩
  rw [← ZMod.natCast_eq_natCast_iff]
  rw [← ZMod.natCast_eq_natCast_iff]
  rw [ZMod.natCast_zmod_val]
  exact periodic_progression_zmod_eq_affine hm hP hH e

#print axioms periodic_progression_modEq_iff_affine

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma periodic_weighted_modEq_sum_decompose
    {f : ℕ → ℝ} {P H T m : ℕ}
    (hP : 0 < P) (hper : Function.Periodic f P) :
    (∑ y ∈ Finset.Ioo 0 H,
        if y ≡ T [MOD m] then f y else 0) =
      ∑ c : Fin P,
        f (c.1 + 1) *
          ∑ n : Fin (((H - 1) - c.1) ⌈/⌉ P),
            if c.1 + 1 + P * n.1 ≡ T [MOD m] then (1 : ℝ) else 0 := by
  rw [sum_Ioo_zero_eq_sum_range_pred_shift
    (fun y => if y ≡ T [MOD m] then f y else 0) H]
  rw [sum_range_eq_sum_residue_quotient
    (fun z => if z + 1 ≡ T [MOD m] then f (z + 1) else 0)
    P (H - 1) hP]
  apply Fintype.sum_congr
  intro c
  rw [Finset.mul_sum]
  apply Fintype.sum_congr
  intro n
  have hf :
      f (c.1 + P * n.1 + 1) = f (c.1 + 1) := by
    rw [show c.1 + P * n.1 + 1 = (c.1 + 1) + P * n.1 by omega]
    exact periodic_apply_add_mul hper
  rw [hf]
  by_cases hm : c.1 + P * n.1 + 1 ≡ T [MOD m]
  · rw [if_pos hm]
    have hm' : c.1 + 1 + P * n.1 ≡ T [MOD m] := by
      simpa [Nat.add_assoc, Nat.add_left_comm, Nat.add_comm] using hm
    rw [if_pos hm']
    ring
  · rw [if_neg hm]
    have hm' : ¬ c.1 + 1 + P * n.1 ≡ T [MOD m] := by
      intro h
      apply hm
      simpa [Nat.add_assoc, Nat.add_left_comm, Nat.add_comm] using h
    rw [if_neg hm']
    ring

lemma periodic_weight_sum_decompose
    {f : ℕ → ℝ} {P H : ℕ}
    (hP : 0 < P) (hper : Function.Periodic f P) :
    (∑ y ∈ Finset.Ioo 0 H, f y) =
      ∑ c : Fin P,
        f (c.1 + 1) *
          ((((H - 1) - c.1) ⌈/⌉ P : ℕ) : ℝ) := by
  rw [sum_Ioo_zero_eq_sum_range_pred_shift f H]
  rw [sum_range_eq_sum_residue_quotient
    (fun z => f (z + 1)) P (H - 1) hP]
  apply Fintype.sum_congr
  intro c
  calc
    (∑ n : Fin (((H - 1) - c.1) ⌈/⌉ P),
        f (c.1 + P * n.1 + 1)) =
      ∑ n : Fin (((H - 1) - c.1) ⌈/⌉ P), f (c.1 + 1) := by
        apply Fintype.sum_congr
        intro n
        rw [show c.1 + P * n.1 + 1 =
          (c.1 + 1) + P * n.1 by omega]
        exact periodic_apply_add_mul hper
    _ = f (c.1 + 1) *
        ((((H - 1) - c.1) ⌈/⌉ P : ℕ) : ℝ) := by
      simp
      ring

#print axioms periodic_weighted_modEq_sum_decompose
#print axioms periodic_weight_sum_decompose

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma finite_weighted_sum_swap
    {ι κ : Type} [Fintype κ] [DecidableEq ι]
    (s : Finset ι) (α : ℝ) (f : κ → ℝ) (g : ι → κ → ℝ) :
    (∑ i ∈ s, α * ∑ c : κ, f c * g i c) =
      ∑ c : κ, f c * (α * ∑ i ∈ s, g i c) := by
  rw [← Finset.mul_sum]
  calc
    α * (∑ i ∈ s, ∑ c : κ, f c * g i c) =
        α * (∑ c : κ, ∑ i ∈ s, f c * g i c) := by
          congr 1
          exact Finset.sum_comm
    _ = ∑ c : κ, α * (∑ i ∈ s, f c * g i c) := by
          rw [Finset.mul_sum]
    _ = ∑ c : κ, f c * (α * ∑ i ∈ s, g i c) := by
          apply Finset.sum_congr rfl
          intro c hc
          rw [← Finset.mul_sum]
          ring

#print axioms finite_weighted_sum_swap

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def periodicResidueLength (P H c : ℕ) : ℕ :=
  ((H - 1) - c) ⌈/⌉ P

lemma periodic_weighted_boolean_discrepancy_eq_affine_sum
    {f : ℕ → ℝ} {P H : ℕ} {S : Finset ℕ}
    (hPrime : ∀ p ∈ S, p.Prime)
    (hPpos : 0 < P)
    (hper : Function.Periodic f P)
    (hPcop : P.Coprime (primeSetProduct S))
    (hHcop : H.Coprime (primeSetProduct S)) :
    (((2 : ℝ) ^ S.card)⁻¹ *
        ∑ A ∈ S.powerset,
          (∑ y ∈ Finset.Ioo 0 H,
            if y ≡ H * fixedProductCRTIdempotentNat S A
                [MOD primeSetProduct S]
            then f y else 0) -
      (∑ y ∈ Finset.Ioo 0 H, f y) / (primeSetProduct S : ℝ)) =
      ∑ c : Fin P,
        f (c.1 + 1) *
          fixedProductBooleanAffineRootIntervalDiscrepancy
            S hPrime
            (fixedProductBooleanPeriodicTwist P H S hPcop hHcop)
            (fixedProductBooleanPeriodicShift P S hPcop c.1)
            (periodicResidueLength P H c.1 % primeSetProduct S) := by
  classical
  let m := primeSetProduct S
  have hmpos : 0 < m := primeSetProduct_pos hPrime
  letI : NeZero m := ⟨hmpos.ne'⟩
  have hmR : (m : ℝ) ≠ 0 := by exact_mod_cast hmpos.ne'
  have hpow : ((2 : ℝ) ^ S.card) ≠ 0 := by positivity
  let u := fixedProductBooleanPeriodicTwist P H S hPcop hHcop
  let v : Fin P → ZMod m :=
    fun c => fixedProductBooleanPeriodicShift P S hPcop c.1
  let L : Fin P → ℕ := fun c => periodicResidueLength P H c.1
  have hfiber : ∀ A ∈ S.powerset,
      (∑ y ∈ Finset.Ioo 0 H,
        if y ≡ H * fixedProductCRTIdempotentNat S A [MOD m]
        then f y else 0) =
      ∑ c : Fin P, f (c.1 + 1) *
        ∑ n : Fin (L c),
          if n.1 ≡
            (((u : (ZMod m)ˣ) : ZMod m) *
                (fixedProductCRTIdempotentNat S A : ZMod m) +
              v c).val [MOD m]
          then (1 : ℝ) else 0 := by
    intro A hA
    rw [periodic_weighted_modEq_sum_decompose hPpos hper]
    apply Fintype.sum_congr
    intro c
    congr 1
    apply Fintype.sum_congr
    intro n
    have hiff := periodic_progression_modEq_iff_affine
      (S := S) (n := n.1) (c := c.1) hmpos hPcop hHcop
      (fixedProductCRTIdempotentNat S A)
    dsimp [L, periodicResidueLength, u, v]
    by_cases hz :
        c.1 + 1 + P * n.1 ≡
          H * fixedProductCRTIdempotentNat S A [MOD m]
    · rw [if_pos hz, if_pos ((hiff).mp hz)]
    · rw [if_neg hz, if_neg (fun h => hz ((hiff).mpr h))]
  have hmass :
      (∑ y ∈ Finset.Ioo 0 H, f y) =
        ∑ c : Fin P, f (c.1 + 1) * (L c : ℝ) := by
    simpa [L, periodicResidueLength] using
      (periodic_weight_sum_decompose (f := f) (P := P) (H := H) hPpos hper)
  rw [show primeSetProduct S = m by rfl]
  rw [show fixedProductBooleanPeriodicTwist P H S hPcop hHcop = u by rfl]
  have hfibsum :
      (∑ A ∈ S.powerset,
        ∑ y ∈ Finset.Ioo 0 H,
          if y ≡ H * fixedProductCRTIdempotentNat S A [MOD m]
          then f y else 0) =
      ∑ A ∈ S.powerset,
        ∑ c : Fin P, f (c.1 + 1) *
          ∑ n : Fin (L c),
            if n.1 ≡
              (((u : (ZMod m)ˣ) : ZMod m) *
                  (fixedProductCRTIdempotentNat S A : ZMod m) +
                v c).val [MOD m]
            then (1 : ℝ) else 0 := by
    apply Finset.sum_congr rfl
    intro A hA
    exact hfiber A hA
  rw [hfibsum, hmass]
  rw [Finset.mul_sum]
  rw [finite_weighted_sum_swap
    S.powerset ((2 : ℝ) ^ S.card)⁻¹
    (fun c : Fin P => f (c.1 + 1))
    (fun A c =>
      ∑ n : Fin (L c),
        if n.1 ≡
          (((u : (ZMod m)ˣ) : ZMod m) *
              (fixedProductCRTIdempotentNat S A : ZMod m) +
            v c).val [MOD m]
        then (1 : ℝ) else 0)]
  rw [Finset.sum_div]
  rw [← Finset.sum_sub_distrib]
  apply Fintype.sum_congr
  intro c
  rw [show f (c.1 + 1) * (L c : ℝ) / (m : ℝ) =
      f (c.1 + 1) * ((L c : ℝ) / (m : ℝ)) by ring]
  rw [← mul_sub]
  unfold fixedProductBooleanAffineRootIntervalDiscrepancy
  dsimp [v, L, periodicResidueLength]
  congr 1
  have hswap :
      ((2 : ℝ) ^ S.card)⁻¹ *
          ∑ A ∈ S.powerset,
            (∑ n : Fin (((H - 1 - c.1) ⌈/⌉ P)),
              if n.1 ≡
                (((u : (ZMod m)ˣ) : ZMod m) *
                    (fixedProductCRTIdempotentNat S A : ZMod m) +
                  fixedProductBooleanPeriodicShift P S hPcop c.1).val
                  [MOD m]
              then (1 : ℝ) else 0)
        - ((((H - 1 - c.1) ⌈/⌉ P : ℕ) : ℝ) / (m : ℝ)) =
      ((2 : ℝ) ^ S.card)⁻¹ *
          ∑ A ∈ S.powerset,
            (if ((((u : (ZMod m)ˣ) : ZMod m) *
                    (fixedProductCRTIdempotentNat S A : ZMod m) +
                  fixedProductBooleanPeriodicShift P S hPcop c.1).val) <
                (((H - 1 - c.1) ⌈/⌉ P) % m)
             then 1 else 0)
        - ((((H - 1 - c.1) ⌈/⌉ P) % m : ℕ) : ℝ) / (m : ℝ) := by
    have hres : ∀ A ∈ S.powerset,
        (∑ n : Fin (((H - 1 - c.1) ⌈/⌉ P)),
          if n.1 ≡
            ((((u : (ZMod m)ˣ) : ZMod m) *
                (fixedProductCRTIdempotentNat S A : ZMod m) +
              fixedProductBooleanPeriodicShift P S hPcop c.1).val)
              [MOD m]
          then (1 : ℝ) else 0)
        - ((((H - 1 - c.1) ⌈/⌉ P : ℕ) : ℝ) / (m : ℝ)) =
        (if ((((u : (ZMod m)ˣ) : ZMod m) *
              (fixedProductCRTIdempotentNat S A : ZMod m) +
              fixedProductBooleanPeriodicShift P S hPcop c.1).val) <
            (((H - 1 - c.1) ⌈/⌉ P) % m)
         then 1 else 0)
        - ((((H - 1 - c.1) ⌈/⌉ P) % m : ℕ) : ℝ) / (m : ℝ) := by
      intro A hA
      rw [Fin.sum_univ_eq_sum_range
        (fun n : ℕ =>
          if n ≡
            ((((u : (ZMod m)ˣ) : ZMod m) *
                (fixedProductCRTIdempotentNat S A : ZMod m) +
              fixedProductBooleanPeriodicShift P S hPcop c.1).val)
              [MOD m]
          then (1 : ℝ) else 0)
        (((H - 1 - c.1) ⌈/⌉ P))]
      exact residue_prefix_discrepancy_eq_indicator hmpos
        (ZMod.val_lt _)
    have hsum :
        ∑ A ∈ S.powerset,
          ((∑ n : Fin (((H - 1 - c.1) ⌈/⌉ P)),
              if n.1 ≡
                ((((u : (ZMod m)ˣ) : ZMod m) *
                    (fixedProductCRTIdempotentNat S A : ZMod m) +
                  fixedProductBooleanPeriodicShift P S hPcop c.1).val)
                  [MOD m]
              then (1 : ℝ) else 0)
            - ((((H - 1 - c.1) ⌈/⌉ P : ℕ) : ℝ) / (m : ℝ))) =
        ∑ A ∈ S.powerset,
          ((if ((((u : (ZMod m)ˣ) : ZMod m) *
                  (fixedProductCRTIdempotentNat S A : ZMod m) +
                fixedProductBooleanPeriodicShift P S hPcop c.1).val) <
              (((H - 1 - c.1) ⌈/⌉ P) % m)
            then 1 else 0)
          - ((((H - 1 - c.1) ⌈/⌉ P) % m : ℕ) : ℝ) / (m : ℝ)) := by
      apply Finset.sum_congr rfl
      intro A hA
      exact hres A hA
    have hcard : (S.powerset.card : ℝ) = (2 : ℝ) ^ S.card := by
      norm_num [Finset.card_powerset]
    calc
      ((2 : ℝ) ^ S.card)⁻¹ *
          ∑ A ∈ S.powerset,
            (∑ n : Fin (((H - 1 - c.1) ⌈/⌉ P)),
              if n.1 ≡
                ((((u : (ZMod m)ˣ) : ZMod m) *
                    (fixedProductCRTIdempotentNat S A : ZMod m) +
                  fixedProductBooleanPeriodicShift P S hPcop c.1).val)
                  [MOD m]
              then (1 : ℝ) else 0)
        - ((((H - 1 - c.1) ⌈/⌉ P : ℕ) : ℝ) / (m : ℝ))
        = ((2 : ℝ) ^ S.card)⁻¹ *
          ∑ A ∈ S.powerset,
            ((∑ n : Fin (((H - 1 - c.1) ⌈/⌉ P)),
              if n.1 ≡
                ((((u : (ZMod m)ˣ) : ZMod m) *
                    (fixedProductCRTIdempotentNat S A : ZMod m) +
                  fixedProductBooleanPeriodicShift P S hPcop c.1).val)
                  [MOD m]
              then (1 : ℝ) else 0)
              - ((((H - 1 - c.1) ⌈/⌉ P : ℕ) : ℝ) / (m : ℝ))) := by
            rw [Finset.sum_sub_distrib, Finset.sum_const]
            simp only [nsmul_eq_mul]
            rw [hcard]
            field_simp [hpow]
      _ = ((2 : ℝ) ^ S.card)⁻¹ *
          ∑ A ∈ S.powerset,
            ((if ((((u : (ZMod m)ˣ) : ZMod m) *
                  (fixedProductCRTIdempotentNat S A : ZMod m) +
                fixedProductBooleanPeriodicShift P S hPcop c.1).val) <
              (((H - 1 - c.1) ⌈/⌉ P) % m)
            then 1 else 0)
          - ((((H - 1 - c.1) ⌈/⌉ P) % m : ℕ) : ℝ) / (m : ℝ)) := by rw [hsum]
      _ = ((2 : ℝ) ^ S.card)⁻¹ *
          ∑ A ∈ S.powerset,
            (if ((((u : (ZMod m)ˣ) : ZMod m) *
                    (fixedProductCRTIdempotentNat S A : ZMod m) +
                  fixedProductBooleanPeriodicShift P S hPcop c.1).val) <
                (((H - 1 - c.1) ⌈/⌉ P) % m)
             then 1 else 0)
        - ((((H - 1 - c.1) ⌈/⌉ P) % m : ℕ) : ℝ) / (m : ℝ) := by
            rw [Finset.sum_sub_distrib, Finset.sum_const]
            simp only [nsmul_eq_mul]
            rw [hcard]
            field_simp [hpow]
  convert hswap using 1 <;> rfl

#print axioms periodic_weighted_boolean_discrepancy_eq_affine_sum

end PaperB.FixedQ



namespace PaperB.FixedQ

lemma fixedQBooleanResidueFiberMass_eq_occupied
    {q a H : ℕ} {S A : Finset ℕ}
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H) :
    fixedQBooleanResidueFiberMass q a H S A =
      ∑ y ∈ Finset.Ioo 0 H,
        if y ≡ H * fixedProductCRTIdempotentNat S A
            [MOD primeSetProduct S]
        then occupiedFixedQLowWeight q a H y else 0 := by
  unfold fixedQBooleanResidueFiberMass
  apply Finset.sum_congr rfl
  intro y hy
  have hyI := Finset.mem_Ioo.mp hy
  by_cases hm :
      y ≡ H * fixedProductCRTIdempotentNat S A
        [MOD primeSetProduct S]
  · rw [if_pos hm, if_pos hm]
    exact fixedQLowWeight_eq_occupied (Nat.le_of_lt hyI.2) h2admissible
  · rw [if_neg hm, if_neg hm]

theorem fixedQWeightedBooleanIntervalDiscrepancy_eq_periodic_affine_sum
    {q a H : ℕ} {S : Finset ℕ}
    (hq : 0 < q)
    (hActive : ∀ p ∈ S, activeHighPrime q p)
    (hOrd : S ∈ ordinaryTwoDimensionalSet H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H) :
    fixedQWeightedBooleanIntervalDiscrepancy q a H S =
      ∑ c : Fin (fixedQPeriod q),
        occupiedFixedQLowWeight q a H (c.1 + 1) *
          fixedProductBooleanAffineRootIntervalDiscrepancy
            S (fun p hp => (hActive p hp).1)
            (fixedProductBooleanPeriodicTwist
              (fixedQPeriod q) H S
              (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
              ((ordinary_primeSetProduct_coprime_height_iff
                (fun p hp => (hActive p hp).1)).mp hOrd).symm)
            (fixedProductBooleanPeriodicShift
              (fixedQPeriod q) S
              (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm c.1)
            (periodicResidueLength (fixedQPeriod q) H c.1 %
              primeSetProduct S) := by
  have hPrime : ∀ p ∈ S, p.Prime := fun p hp => (hActive p hp).1
  have hPpos : 0 < fixedQPeriod q := by
    unfold fixedQPeriod
    exact Nat.lcm_pos (by norm_num) hq
  have hPcop :
      (fixedQPeriod q).Coprime (primeSetProduct S) :=
    (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
  have hHcop : H.Coprime (primeSetProduct S) :=
    ((ordinary_primeSetProduct_coprime_height_iff hPrime).mp hOrd).symm
  have hgeneric :=
    periodic_weighted_boolean_discrepancy_eq_affine_sum
      (f := occupiedFixedQLowWeight q a H)
      (P := fixedQPeriod q) (H := H) (S := S)
      hPrime hPpos (occupiedFixedQLowWeight_periodic q a H) hPcop hHcop
  calc
    fixedQWeightedBooleanIntervalDiscrepancy q a H S =
        ((2 : ℝ) ^ S.card)⁻¹ *
            ∑ A ∈ S.powerset,
              (∑ y ∈ Finset.Ioo 0 H,
                if y ≡ H * fixedProductCRTIdempotentNat S A
                    [MOD primeSetProduct S]
                then occupiedFixedQLowWeight q a H y else 0) -
          (∑ y ∈ Finset.Ioo 0 H,
            occupiedFixedQLowWeight q a H y) /
              (primeSetProduct S : ℝ) := by
      unfold fixedQWeightedBooleanIntervalDiscrepancy
      rw [rowWeightMass_fixedQLowWeight_eq_occupied h2admissible]
      unfold rowWeightMass
      congr 2
      apply Finset.sum_congr rfl
      intro A hA
      exact fixedQBooleanResidueFiberMass_eq_occupied h2admissible
    _ = _ := hgeneric

#print axioms fixedQBooleanResidueFiberMass_eq_occupied
#print axioms fixedQWeightedBooleanIntervalDiscrepancy_eq_periodic_affine_sum

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem fixedQWeightedBooleanIntervalDiscrepancy_erdosTuran
    {q a H : ℕ} {S : Finset ℕ}
    (hq : 0 < q)
    (hActive : ∀ p ∈ S, activeHighPrime q p)
    (hOrd : S ∈ ordinaryTwoDimensionalSet H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H)
    (J : ℕ) (hJ : 1 ≤ J) :
    |fixedQWeightedBooleanIntervalDiscrepancy q a H S| ≤
      6 * (fixedQPeriod q : ℝ) *
        (4 / (J : ℝ) +
          4 * ∑ j ∈ Finset.Icc 1 J,
            fixedProductBooleanTwistedFrequencyMass
              S (fun p hp => (hActive p hp).1)
              (fixedProductBooleanPeriodicTwist
                (fixedQPeriod q) H S
                (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
                ((ordinary_primeSetProduct_coprime_height_iff
                  (fun p hp => (hActive p hp).1)).mp hOrd).symm)
              j / (j : ℝ)) := by
  let P := fixedQPeriod q
  let hPrime : ∀ p ∈ S, p.Prime := fun p hp => (hActive p hp).1
  let hPcop : P.Coprime (primeSetProduct S) :=
    (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
  let hHcop : H.Coprime (primeSetProduct S) :=
    ((ordinary_primeSetProduct_coprime_height_iff hPrime).mp hOrd).symm
  let u := fixedProductBooleanPeriodicTwist P H S hPcop hHcop
  let B : ℝ :=
    4 / (J : ℝ) +
      4 * ∑ j ∈ Finset.Icc 1 J,
        fixedProductBooleanTwistedFrequencyMass S hPrime u j / (j : ℝ)
  have hPpos : 0 < P := by
    dsimp [P]
    unfold fixedQPeriod
    exact Nat.lcm_pos (by norm_num) hq
  have hmpos : 0 < primeSetProduct S := primeSetProduct_pos hPrime
  have hexact :=
    fixedQWeightedBooleanIntervalDiscrepancy_eq_periodic_affine_sum
      (q := q) (a := a) (H := H) (S := S)
      hq hActive hOrd h2admissible
  have hpoint : ∀ c : Fin P,
      |occupiedFixedQLowWeight q a H (c.1 + 1) *
          fixedProductBooleanAffineRootIntervalDiscrepancy
            S hPrime u
            (fixedProductBooleanPeriodicShift P S hPcop c.1)
            (periodicResidueLength P H c.1 % primeSetProduct S)| ≤
        6 * B := by
    intro c
    have hw :=
      abs_occupiedFixedQLowWeight_le_six q a H (c.1 + 1) h2admissible
    have hET :=
      fixedProductBooleanAffineRootInterval_erdosTuran
        S hPrime u
        (fixedProductBooleanPeriodicShift P S hPcop c.1)
        (periodicResidueLength P H c.1 % primeSetProduct S)
        J
        (Nat.mod_lt _ hmpos) hJ
    rw [abs_mul]
    exact mul_le_mul hw hET (abs_nonneg _) (by norm_num)
  rw [hexact]
  change |∑ c : Fin P,
      occupiedFixedQLowWeight q a H (c.1 + 1) *
        fixedProductBooleanAffineRootIntervalDiscrepancy
          S hPrime u
          (fixedProductBooleanPeriodicShift P S hPcop c.1)
          (periodicResidueLength P H c.1 % primeSetProduct S)| ≤ _
  calc
    |∑ c : Fin P,
        occupiedFixedQLowWeight q a H (c.1 + 1) *
          fixedProductBooleanAffineRootIntervalDiscrepancy
            S hPrime u
            (fixedProductBooleanPeriodicShift P S hPcop c.1)
            (periodicResidueLength P H c.1 % primeSetProduct S)|
      ≤ ∑ c : Fin P,
          |occupiedFixedQLowWeight q a H (c.1 + 1) *
            fixedProductBooleanAffineRootIntervalDiscrepancy
              S hPrime u
              (fixedProductBooleanPeriodicShift P S hPcop c.1)
              (periodicResidueLength P H c.1 % primeSetProduct S)| := by
        exact Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _c : Fin P, 6 * B := by
        apply Finset.sum_le_sum
        intro c hc
        exact hpoint c
    _ = 6 * (P : ℝ) * B := by
        simp
        ring
    _ = _ := by
        rfl

#print axioms fixedQWeightedBooleanIntervalDiscrepancy_erdosTuran

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma erdosTuran_square_after_scaled_boolean_average
    (D C : ℝ) (F : ℕ → ℝ) (J : ℕ)
    (hJ : 1 ≤ J) (hC : 0 < C)
    (hF : ∀ j ∈ Finset.Icc 1 J, 0 ≤ F j)
    (hET :
      |D| ≤ C * (4 / (J : ℝ) +
        4 * ∑ j ∈ Finset.Icc 1 J, F j / (j : ℝ))) :
    D ^ 2 ≤ C ^ 2 *
      (32 / ((J : ℝ) ^ 2) +
        32 * (1 + Real.log (J : ℝ)) *
          (∑ j ∈ Finset.Icc 1 J, (F j) ^ 2 / (j : ℝ))) := by
  have hnorm :
      |D / C| ≤ 4 / (J : ℝ) +
        4 * ∑ j ∈ Finset.Icc 1 J, F j / (j : ℝ) := by
    rw [abs_div, abs_of_pos hC]
    exact (div_le_iff₀ hC).2 (by simpa [mul_comm] using hET)
  have hsq := erdosTuran_square_after_boolean_average
    (D / C) F J hJ hF hnorm
  have hC0 : C ≠ 0 := ne_of_gt hC
  calc
    D ^ 2 = C ^ 2 * (D / C) ^ 2 := by
      field_simp [hC0]
    _ ≤ C ^ 2 *
        (32 / ((J : ℝ) ^ 2) +
          32 * (1 + Real.log (J : ℝ)) *
            (∑ j ∈ Finset.Icc 1 J, (F j) ^ 2 / (j : ℝ))) := by
      exact mul_le_mul_of_nonneg_left hsq (sq_nonneg C)

theorem fixedQWeightedBooleanIntervalDiscrepancy_erdosTuran_sq
    {q a H : ℕ} {S : Finset ℕ}
    (hq : 0 < q)
    (hActive : ∀ p ∈ S, activeHighPrime q p)
    (hOrd : S ∈ ordinaryTwoDimensionalSet H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H)
    (J : ℕ) (hJ : 1 ≤ J) :
    (fixedQWeightedBooleanIntervalDiscrepancy q a H S) ^ 2 ≤
      (6 * (fixedQPeriod q : ℝ)) ^ 2 *
        (32 / ((J : ℝ) ^ 2) +
          32 * (1 + Real.log (J : ℝ)) *
            (∑ j ∈ Finset.Icc 1 J,
              ‖fixedProductBooleanFourierCoeff S
                (fun p hp => (hActive p hp).1)
                ((j : ZMod (primeSetProduct S)) *
                  ((fixedProductBooleanPeriodicTwist
                    (fixedQPeriod q) H S
                    (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
                    ((ordinary_primeSetProduct_coprime_height_iff
                      (fun p hp => (hActive p hp).1)).mp hOrd).symm :
                      (ZMod (primeSetProduct S))ˣ) :
                    ZMod (primeSetProduct S)))‖ ^ 2 / (j : ℝ))) := by
  let hPrime : ∀ p ∈ S, p.Prime := fun p hp => (hActive p hp).1
  let hPcop : (fixedQPeriod q).Coprime (primeSetProduct S) :=
    (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
  let hHcop : H.Coprime (primeSetProduct S) :=
    ((ordinary_primeSetProduct_coprime_height_iff hPrime).mp hOrd).symm
  let u :=
    fixedProductBooleanPeriodicTwist
      (fixedQPeriod q) H S hPcop hHcop
  let F : ℕ → ℝ :=
    fun j => fixedProductBooleanTwistedFrequencyMass S hPrime u j
  have hPpos : 0 < fixedQPeriod q := by
    unfold fixedQPeriod
    exact Nat.lcm_pos (by norm_num) hq
  have hC : (0 : ℝ) < 6 * (fixedQPeriod q : ℝ) := by
    positivity
  have hF : ∀ j ∈ Finset.Icc 1 J, 0 ≤ F j := by
    intro j hj
    exact norm_nonneg _
  have hET :=
    fixedQWeightedBooleanIntervalDiscrepancy_erdosTuran
      (q := q) (a := a) (H := H) (S := S)
      hq hActive hOrd h2admissible J hJ
  have hsq := erdosTuran_square_after_scaled_boolean_average
    (fixedQWeightedBooleanIntervalDiscrepancy q a H S)
    (6 * (fixedQPeriod q : ℝ)) F J hJ hC hF (by
      simpa [F, u, hPrime, hPcop, hHcop] using hET)
  simpa [F, u, hPrime, hPcop, hHcop,
    fixedProductBooleanTwistedFrequencyMass] using hsq

#print axioms erdosTuran_square_after_scaled_boolean_average
#print axioms fixedQWeightedBooleanIntervalDiscrepancy_erdosTuran_sq

end PaperB.FixedQ
