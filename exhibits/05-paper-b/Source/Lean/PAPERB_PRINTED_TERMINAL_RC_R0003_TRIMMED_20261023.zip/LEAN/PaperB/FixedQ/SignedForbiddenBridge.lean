import PaperB.FixedQ.H3DecoratedBooleanClosureBridge

open scoped BigOperators

namespace PaperB.FixedQ

@[simp] theorem dForbiddenReducedBooleanCoreTerm_empty
    (q a H : ℕ) (n : Finset ℕ) :
    dForbiddenReducedBooleanCoreTerm q a H ∅ n =
      ordinaryBooleanCoreTerm q a H n := by
  simp [dForbiddenReducedBooleanCoreTerm]

theorem tsum_dForbidden_empty_eq_ordinaryBooleanCore
    (q a H : ℕ) :
    (∑' n : Finset ℕ,
      dForbiddenReducedBooleanCoreTerm q a H ∅ n) =
      ordinaryBooleanCore q a H := by
  unfold ordinaryBooleanCore
  apply tsum_congr
  intro n
  simp

noncomputable def decoratedHeightRestrictedSignedPairTerm
    (q a h : ℕ) (dn : Finset ℕ × Finset ℕ) : ℝ :=
  let d := dn.1
  let n := dn.2
  if hd : d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty then
    finiteVWeightReal h d *
      dForbiddenReducedBooleanCoreTerm q
        (decoratedReducedAnchor q a (primeSetProduct d))
        (h / primeSetProduct d) d n
  else 0

noncomputable def decoratedHeightRestrictedSignedReindexTerm
    (q a h : ℕ)
    (x : (Finset ℕ × Finset ℕ) ⊕ Finset ℕ) : ℝ :=
  match x with
  | Sum.inl dn => decoratedHeightRestrictedSignedPairTerm q a h dn
  | Sum.inr _ => 0

theorem decoratedAnalyticSignedReindexKey_union
    {q h : ℕ} {d n : Finset ℕ}
    (hd : d ⊆ decoratedHeightPrimeSet q h)
    (hn : n ∈ activeOrdinaryTwoDimensionalSet q
      (h / primeSetProduct d))
    (hdis : Disjoint d n) :
    decoratedAnalyticSignedReindexKey q h (d ∪ n) =
      Sum.inl (d, n) := by
  classical
  have hheight :=
    heightPrimePart_union_eq_left_of_reduced_ordinary hd hn hdis
  have hAall : ∀ p ∈ d ∪ n, activeHighPrime q p := by
    intro p hp
    rcases Finset.mem_union.mp hp with hpd | hpn
    · exact decoratedHeightPrimeSet_active hd p hpd
    · exact hn.2 p hpn
  have hnd : n \ d = n := by
    ext p
    simp only [Finset.mem_sdiff, and_iff_left_iff_imp]
    intro hpn hpd
    exact (Finset.disjoint_left.mp hdis hpd hpn).elim
  have hsdiff : (d ∪ n) \ d = n := by
    rw [Finset.union_sdiff_left, hnd]
  rw [decoratedAnalyticSignedReindexKey, if_pos hAall]
  simp [hheight, hsdiff]

theorem heightForbidden_indicator_eq_signedReindexTerm
    {q a h : ℕ} (hh : 0 < h) (e : Finset ℕ) :
    (ordinaryTwoDimensionalSet h)ᶜ.indicator
        (decoratedHeightForbiddenCoreTerm q a h) e =
      decoratedHeightRestrictedSignedReindexTerm q a h
        (decoratedAnalyticSignedReindexKey q h e) := by
  classical
  by_cases he : e ∈ (ordinaryTwoDimensionalSet h)ᶜ
  · rw [Set.indicator_of_mem he]
    by_cases hA : ∀ p ∈ e, activeHighPrime q p
    · let d := heightPrimePart h e
      let n := e \ d
      have hdsub : d ⊆ decoratedHeightPrimeSet q h := by
        dsimp [d]
        exact heightPrimePart_subset_decoratedHeightPrimeSet_of_active hh hA
      have hdmem : d ∈ (decoratedHeightPrimeSet q h).powerset :=
        Finset.mem_powerset.mpr hdsub
      have hdne : d.Nonempty := by
        dsimp [d]
        exact heightPrimePart_nonempty_of_forbidden he
      have hdis : Disjoint d n := by
        dsimp [n]
        exact Finset.disjoint_sdiff
      have hn : n ∈ activeOrdinaryTwoDimensionalSet q
          (h / primeSetProduct d) := by
        have h0 := decorated_nonheight_activeOrdinary
          (q := q) (h := h) (e := e) hA
        simpa [d, n, decoratedReducedHeight, decoratedHeightProduct] using h0
      have hrec := decoratedHeightForbiddenCoreTerm_union_reconstruct
        (q := q) (a := a) (h := h)
        (d := d) (n := n) hdsub hn hdis
      have hu : d ∪ n = e := by
        dsimp [d, n]
        exact Finset.union_sdiff_of_subset (Finset.filter_subset _ _)
      rw [hu] at hrec
      rw [hrec]
      rw [decoratedAnalyticSignedReindexKey, if_pos hA]
      simp only [decoratedHeightRestrictedSignedReindexTerm,
        decoratedHeightRestrictedSignedPairTerm]
      change
        finiteVWeightReal h d *
            ordinaryBooleanCoreTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) n =
          (if _ : d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty then
            finiteVWeightReal h d *
              dForbiddenReducedBooleanCoreTerm q
                (decoratedReducedAnchor q a (primeSetProduct d))
                (h / primeSetProduct d) d n
          else 0)
      simp [hdmem, hdne, dForbiddenReducedBooleanCoreTerm, hdis]
    · rw [decoratedAnalyticSignedReindexKey, if_neg hA]
      simp [decoratedHeightForbiddenCoreTerm,
        decoratedHeightRestrictedSignedReindexTerm, hA]
  · simp only [Set.indicator, he, if_false]
    by_cases hA : ∀ p ∈ e, activeHighPrime q p
    · have hOrd : e ∈ ordinaryTwoDimensionalSet h := by
        by_contra hnot
        apply he
        simpa [Set.mem_compl_iff] using hnot
      have hd0 : heightPrimePart h e = ∅ := hOrd
      rw [decoratedAnalyticSignedReindexKey, if_pos hA]
      simp [decoratedHeightRestrictedSignedReindexTerm,
        decoratedHeightRestrictedSignedPairTerm, hd0]
    · rw [decoratedAnalyticSignedReindexKey, if_neg hA]
      simp [decoratedHeightRestrictedSignedReindexTerm]

theorem abs_decoratedHeightRestrictedSignedPairTerm_eq
    (q a h : ℕ) (dn : Finset ℕ × Finset ℕ) :
    |decoratedHeightRestrictedSignedPairTerm q a h dn| =
      decoratedHeightRestrictedAbsPairTerm q a h dn := by
  classical
  rcases dn with ⟨d, n⟩
  unfold decoratedHeightRestrictedSignedPairTerm
    decoratedHeightRestrictedAbsPairTerm
  dsimp
  by_cases hd :
      d ⊆ decoratedHeightPrimeSet q h ∧ d.Nonempty
  · have hdmem : d ∈ (decoratedHeightPrimeSet q h).powerset :=
      Finset.mem_powerset.mpr hd.1
    have hv0 : 0 ≤ finiteVWeightReal h d := by
      apply finiteVWeightReal_nonneg_of_active
      exact decoratedHeightPrimeSet_active hd.1
    simp [decoratedHeightRestrictedSignedPairTerm,
      decoratedHeightRestrictedAbsPairTerm, hdmem, hd, abs_mul,
      abs_of_nonneg hv0]
  · have hdmem :
      ¬ (d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty) := by
      intro h
      exact hd ⟨Finset.mem_powerset.mp h.1, h.2⟩
    simp [decoratedHeightRestrictedSignedPairTerm,
      decoratedHeightRestrictedAbsPairTerm, hdmem, hd]

theorem summable_decoratedHeightRestrictedSignedPairTerm
    {q a h : ℕ}
    (hAbs : ∀ d ∈ (decoratedHeightPrimeSet q h).powerset,
      Summable (fun n : Finset ℕ =>
        |ordinaryBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) n|)) :
    Summable (decoratedHeightRestrictedSignedPairTerm q a h) := by
  apply Summable.of_norm
  have hPairAbs := summable_decoratedHeightRestrictedAbsPairTerm
    (q := q) (a := a) (h := h) hAbs
  exact hPairAbs.congr (fun dn => by
    rw [Real.norm_eq_abs,
      abs_decoratedHeightRestrictedSignedPairTerm_eq q a h dn])

theorem summable_decoratedHeightRestrictedSignedReindexTerm
    {q a h : ℕ}
    (hAbs : ∀ d ∈ (decoratedHeightPrimeSet q h).powerset,
      Summable (fun n : Finset ℕ =>
        |ordinaryBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) n|)) :
    Summable (decoratedHeightRestrictedSignedReindexTerm q a h) := by
  have hp := summable_decoratedHeightRestrictedSignedPairTerm
    (q := q) (a := a) (h := h) hAbs
  apply (Sum.inl_injective.summable_iff ?_).mp
  · simpa [Function.comp_def, decoratedHeightRestrictedSignedReindexTerm] using hp
  · intro x hx
    cases x with
    | inl dn => exact (hx ⟨dn, rfl⟩).elim
    | inr e => simp [decoratedHeightRestrictedSignedReindexTerm]

theorem tsum_signedReindex_eq_signedForbiddenSum
    {q a h : ℕ}
    (hAbs : ∀ d ∈ (decoratedHeightPrimeSet q h).powerset,
      Summable (fun n : Finset ℕ =>
        |ordinaryBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) n|)) :
    (∑' x, decoratedHeightRestrictedSignedReindexTerm q a h x) =
      ∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
        finiteVWeightReal h d *
          (∑' n : Finset ℕ,
            dForbiddenReducedBooleanCoreTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) d n) := by
  have hPair := summable_decoratedHeightRestrictedSignedPairTerm
    (q := q) (a := a) (h := h) hAbs
  have hInl : Summable
      (decoratedHeightRestrictedSignedReindexTerm q a h ∘ Sum.inl) := by
    simpa [Function.comp_def, decoratedHeightRestrictedSignedReindexTerm] using hPair
  have hInr : Summable
      (decoratedHeightRestrictedSignedReindexTerm q a h ∘ Sum.inr) := by
    simp [Function.comp_def, decoratedHeightRestrictedSignedReindexTerm]
  rw [Summable.tsum_sum hInl hInr]
  simp only [decoratedHeightRestrictedSignedReindexTerm, tsum_zero, add_zero]
  rw [hPair.tsum_prod]
  rw [tsum_eq_sum (s := (decoratedHeightPrimeSet q h).powerset.erase ∅)]
  · apply Finset.sum_congr rfl
    intro d hd
    have hdps : d ∈ (decoratedHeightPrimeSet q h).powerset :=
      (Finset.mem_erase.mp hd).2
    have hdne : d.Nonempty :=
      Finset.nonempty_iff_ne_empty.mpr (Finset.mem_erase.mp hd).1
    have hresAbs : Summable (fun n : Finset ℕ =>
        |dForbiddenReducedBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) d n|) :=
      (hAbs d hdps).of_nonneg_of_le
        (fun n => abs_nonneg _)
        (fun n => abs_dForbiddenReducedBooleanCoreTerm_le q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) d n)
    have hres : Summable (fun n : Finset ℕ =>
        dForbiddenReducedBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) d n) := by
      apply Summable.of_norm
      simpa [Real.norm_eq_abs] using hresAbs
    have hgate :
        d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty :=
      ⟨hdps, hdne⟩
    simpa [decoratedHeightRestrictedSignedPairTerm, hgate] using
      hres.tsum_mul_left (finiteVWeightReal h d)
  · intro d hd
    have hout :
        ¬(d ⊆ decoratedHeightPrimeSet q h ∧ d.Nonempty) := by
      intro hg
      apply hd
      apply Finset.mem_erase.mpr
      exact ⟨Finset.nonempty_iff_ne_empty.mp hg.2,
        Finset.mem_powerset.mpr hg.1⟩
    simp [decoratedHeightRestrictedSignedPairTerm, hout]

theorem signedReindexTerm_support_subset_range
    {q a h : ℕ} (hh : 0 < h) :
    Function.support (decoratedHeightRestrictedSignedReindexTerm q a h) ⊆
      Set.range (decoratedAnalyticSignedReindexKey q h) := by
  classical
  intro x hx
  cases x with
  | inr e =>
      exfalso
      exact hx (by simp [decoratedHeightRestrictedSignedReindexTerm])
  | inl dn =>
      rcases dn with ⟨d, n⟩
      by_cases hgate :
          d ⊆ decoratedHeightPrimeSet q h ∧ d.Nonempty
      · have hgateMem :
          d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty :=
          ⟨Finset.mem_powerset.mpr hgate.1, hgate.2⟩
        have hterm :
          dForbiddenReducedBooleanCoreTerm q
            (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d) d n ≠ 0 := by
          intro hz
          apply hx
          simp [decoratedHeightRestrictedSignedReindexTerm,
            decoratedHeightRestrictedSignedPairTerm, hgateMem, hz]
        have hdis : Disjoint d n := by
          by_contra hndis
          apply hterm
          simp [dForbiddenReducedBooleanCoreTerm, hndis]
        have hn : n ∈ activeOrdinaryTwoDimensionalSet q
            (h / primeSetProduct d) := by
          by_contra hnact
          apply hterm
          simp [dForbiddenReducedBooleanCoreTerm, hdis,
            ordinaryBooleanCoreTerm, Set.indicator, hnact]
        have hdsub : d ⊆ decoratedHeightPrimeSet q h :=
          hgate.1
        refine ⟨d ∪ n, ?_⟩
        exact decoratedAnalyticSignedReindexKey_union hdsub hn hdis
      · exfalso
        have hz :
            decoratedHeightRestrictedSignedReindexTerm q a h
              (Sum.inl (d, n)) = 0 := by
          change decoratedHeightRestrictedSignedPairTerm q a h (d, n) = 0
          unfold decoratedHeightRestrictedSignedPairTerm
          dsimp
          simp [Finset.mem_powerset, hgate]
        exact hx hz

theorem heightForbidden_tsum_eq_signedReindex_tsum
    {q a h : ℕ} (hh : 0 < h) :
    (∑' e : Finset ℕ,
      (ordinaryTwoDimensionalSet h)ᶜ.indicator
        (decoratedHeightForbiddenCoreTerm q a h) e) =
      ∑' x : (Finset ℕ × Finset ℕ) ⊕ Finset ℕ,
        decoratedHeightRestrictedSignedReindexTerm q a h x := by
  classical
  let f : Finset ℕ → ℝ :=
    (ordinaryTwoDimensionalSet h)ᶜ.indicator
      (decoratedHeightForbiddenCoreTerm q a h)
  let g : (Finset ℕ × Finset ℕ) ⊕ Finset ℕ → ℝ :=
    decoratedHeightRestrictedSignedReindexTerm q a h
  let key := decoratedAnalyticSignedReindexKey q h
  have hgrange : Function.support g ⊆ Set.range key := by
    simpa [g, key] using
      signedReindexTerm_support_subset_range
        (q := q) (a := a) hh
  let i : Function.support g → Finset ℕ :=
    fun x => Classical.choose (hgrange x.property)
  have hikey : ∀ x : Function.support g, key (i x) = x.1 := by
    intro x
    exact Classical.choose_spec (hgrange x.property)
  have hi : Function.Injective i := by
    intro x y hxy
    apply Subtype.ext
    have hk := congrArg key hxy
    rw [hikey x, hikey y] at hk
    exact hk
  have hpoint : ∀ e : Finset ℕ, f e = g (key e) := by
    intro e
    simpa [f, g, key] using
      heightForbidden_indicator_eq_signedReindexTerm
        (q := q) (a := a) hh e
  have hfsupp : Function.support f ⊆ Set.range i := by
    intro e he
    have hgne : g (key e) ≠ 0 := by
      intro hz
      exact he (by rw [hpoint e, hz])
    let x : Function.support g := ⟨key e, hgne⟩
    refine ⟨x, ?_⟩
    have hk : key (i x) = key e := by
      simpa [x] using hikey x
    exact decoratedAnalyticSignedReindexKey_injective q h hk
  have hfg : ∀ x : Function.support g, f (i x) = g x.1 := by
    intro x
    rw [hpoint]
    rw [hikey x]
  exact tsum_eq_tsum_of_ne_zero_bij i hi hfsupp hfg

theorem decoratedAnalyticRemainder_eq_signed_forbidden_sum
    {q a h : ℕ} (hh : 0 < h)
    (hAbs : ∀ d ∈ (decoratedHeightPrimeSet q h).powerset,
      Summable (fun n : Finset ℕ =>
        |ordinaryBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) n|)) :
    decoratedAnalyticRemainder q a h =
      ∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
        finiteVWeightReal h d *
          (∑' n : Finset ℕ,
            dForbiddenReducedBooleanCoreTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) d n) := by
  rw [decoratedAnalyticRemainder_eq_height_forbidden_core]
  rw [heightForbidden_tsum_eq_signedReindex_tsum hh]
  exact tsum_signedReindex_eq_signedForbiddenSum hAbs

#print axioms dForbiddenReducedBooleanCoreTerm_empty
#print axioms tsum_dForbidden_empty_eq_ordinaryBooleanCore
#print axioms decoratedAnalyticRemainder_eq_signed_forbidden_sum

end PaperB.FixedQ
