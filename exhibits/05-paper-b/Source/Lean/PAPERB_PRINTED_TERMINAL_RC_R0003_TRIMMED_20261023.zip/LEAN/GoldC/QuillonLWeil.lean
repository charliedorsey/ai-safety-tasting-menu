import GoldC.QuillonWCoupled

/-!
# Quillon LONG L5: the Weil-strength W′ supplier (squarefree modulus, coupled range)

**The single external input.** `WeilHyp` is, character for character, the statement of the
already-GREEN `Orienne.CSC3.norm_quillon_K_weil` (Weil–Estermann for the complete Quillon
Kloosterman sum `GoldC.QuillonKl.K`, general modulus, full gcd conductor). It is a *named
hypothesis*, never an axiom: every theorem that needs it takes `(hW : WeilHyp)` explicitly.

From it, for squarefree `s = ∏P`:
* `norm_K_le_KW`: `‖K_s(b,c)‖ ≤ KW(c) := 4^{|P|/2}·s^{1/2}·(∏_{p∈P, p∣c} p)^{1/2}`
  (`τ(s) = 2^{|P|}` and `gcd(gcd(b,c),s) ≤ gcd(c,s) = ∏_{p∈P,p∣c}p`);
* `KW_offdiag`: the off-diagonal frequency `c₀(ȳ−ȳ')` (via `prod_freq_le`);
* `gcd_moment_half`: Seravyn's half-power pair moment (ported verbatim);
* `W_cell_coupled_W`: the coupled W′ Cauchy bound with the Weil majorant. Equal-index pairs and
  distinct-but-congruent pairs are kept (`L·Σ‖α‖²` and `L·2(1+log Y)²/s`); `G₀ = ∏_{p∣c₀}p`
  stays explicit (no zero-mode deletion).

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonLWeil

open GoldC.QuillonKl GoldC.QuillonCompletion GoldC.QuillonW GoldC.QuillonWCell GoldC.QuillonWCoupled

/-- **The Weil–Estermann bound** for the complete Quillon Kloosterman sum, in exactly the form of
the GREEN `Orienne.CSC3.norm_quillon_K_weil`. -/
def WeilHyp : Prop :=
  ∀ (s : ℕ) [NeZero s] (a b : ZMod s),
    ‖GoldC.QuillonKl.K s a b‖ ≤
      (s.divisors.card : ℝ) * Real.sqrt (Nat.gcd (Nat.gcd a.val b.val) s * s)

lemma card_divisors_prod (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) :
    (∏ p ∈ P, p).divisors.card = 2 ^ P.card := by
  induction P using Finset.induction_on with
  | empty => simp
  | insert a P ha ih =>
    rw [prod_insert ha, card_insert_of_notMem ha, pow_succ]
    have hap : a.Prime := hP a (mem_insert_self _ _)
    have hP' : ∀ p ∈ P, p.Prime := fun p hp => hP p (mem_insert_of_mem hp)
    have hcop : a.Coprime (∏ p ∈ P, p) := by
      apply Nat.Coprime.prod_right
      intro p hp
      exact (Nat.coprime_primes hap (hP' p hp)).2 (fun h => ha (h ▸ hp))
    rw [Nat.Coprime.card_divisors_mul hcop, ih hP', Nat.Prime.divisors hap,
      card_pair (Nat.Prime.one_lt hap).ne]
    ring

lemma gcd_gcd_le (a b s : ℕ) (hs : 0 < s) : Nat.gcd (Nat.gcd a b) s ≤ Nat.gcd b s :=
  Nat.le_of_dvd (Nat.gcd_pos_of_pos_right _ hs)
    (Nat.gcd_dvd_gcd_of_dvd_left _ (Nat.gcd_dvd_right a b))

lemma gcd_le_filter_prod (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (s : ℕ) (hs : s = ∏ p ∈ P, p) (x : ℕ) :
    Nat.gcd x s ≤ ∏ p ∈ P.filter (fun p => p ∣ x), p := by
  classical
  have hpos : 0 < ∏ p ∈ P.filter (fun p => p ∣ x), p := prod_pos fun p hp => (hP p (mem_filter.1 hp).1).pos
  apply Nat.le_of_dvd hpos
  have hsplit : s = (∏ p ∈ P.filter (fun p => p ∣ x), p) * ∏ p ∈ P.filter (fun p => ¬ p ∣ x), p := by
    rw [hs, prod_filter_mul_prod_filter_not]
  have hcop : Nat.Coprime (Nat.gcd x s) (∏ p ∈ P.filter (fun p => ¬ p ∣ x), p) := by
    apply Nat.Coprime.prod_right
    intro p hp
    obtain ⟨hpP, hpx⟩ := mem_filter.1 hp
    apply Nat.Coprime.symm
    rw [Nat.Prime.coprime_iff_not_dvd (hP p hpP)]
    exact fun h => hpx (h.trans (Nat.gcd_dvd_left _ _))
  have hd : Nat.gcd x s ∣ (∏ p ∈ P.filter (fun p => p ∣ x), p) * ∏ p ∈ P.filter (fun p => ¬ p ∣ x), p := by
    rw [← hsplit]; exact Nat.gcd_dvd_right _ _
  exact hcop.dvd_of_dvd_mul_right hd

lemma filter_cast_eq (P : Finset ℕ) (s : ℕ) [NeZero s] (hs : s = ∏ p ∈ P, p) (c : ZMod s) :
    P.filter (fun p => p ∣ c.val) = P.filter (fun p => (ZMod.cast c : ZMod p) = 0) := by
  ext p
  simp only [mem_filter]
  constructor
  · rintro ⟨hp, hd⟩
    refine ⟨hp, ?_⟩
    rw [ZMod.cast_eq_val]; exact (ZMod.natCast_eq_zero_iff _ _).2 hd
  · rintro ⟨hp, hc⟩
    refine ⟨hp, ?_⟩
    rw [ZMod.cast_eq_val] at hc; exact (ZMod.natCast_eq_zero_iff _ _).1 hc

/-- The Weil majorant. -/
noncomputable def KW (P : Finset ℕ) {s : ℕ} [NeZero s] (c : ZMod s) : ℝ :=
  (4 : ℝ) ^ ((P.card : ℝ) / 2) * (s : ℝ) ^ ((1 : ℝ) / 2) *
    (∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 2)

lemma KW_nonneg (P : Finset ℕ) {s : ℕ} [NeZero s] (c : ZMod s) : 0 ≤ KW P c := by
  unfold KW
  have : (0 : ℝ) ≤ ∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) = 0), (p : ℝ) :=
    prod_nonneg fun _ _ => by positivity
  positivity

theorem norm_K_le_KW (hW : WeilHyp) (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (s : ℕ) (hs : s = ∏ p ∈ P, p)
    [NeZero s] (b c : ZMod s) : ‖K s b c‖ ≤ KW P c := by
  have h1 := hW s b c
  have hs0 : 0 < s := Nat.pos_of_ne_zero (NeZero.ne s)
  have hτ : (s.divisors.card : ℝ) = (4 : ℝ) ^ ((P.card : ℝ) / 2) := by
    rw [hs, card_divisors_prod P hP]
    push_cast
    rw [show (4 : ℝ) = 2 ^ (2 : ℝ) by norm_num, ← Real.rpow_mul (by norm_num),
      show (2 : ℝ) * ((P.card : ℝ) / 2) = ((P.card : ℕ) : ℝ) by ring, Real.rpow_natCast]
  have hg : (Nat.gcd (Nat.gcd b.val c.val) s : ℝ) ≤
      ∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) = 0), (p : ℝ) := by
    have a1 := gcd_gcd_le b.val c.val s hs0
    have a2 := gcd_le_filter_prod P hP s hs c.val
    rw [filter_cast_eq P s hs c] at a2
    have : Nat.gcd (Nat.gcd b.val c.val) s ≤ ∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) = 0), p :=
      a1.trans a2
    rw [← Nat.cast_prod]; exact_mod_cast this
  refine h1.trans ?_
  unfold KW
  rw [hτ, mul_assoc]
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  rw [Real.sqrt_eq_rpow, Real.mul_rpow (by positivity) (by positivity), mul_comm]
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  exact Real.rpow_le_rpow (by positivity) hg (by norm_num)

/-- Off-diagonal Weil majorant: `KW(c₀(ȳ−ȳ')) ≤ 4^{|P|/2}s^{1/2}G₀^{1/2}(∏_{p∣y−y'}p)^{1/2}`. -/
lemma KW_offdiag {s : ℕ} [NeZero s] (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hs : s = ∏ p ∈ P, p)
    (c₀ : ZMod s) (y y' : ℕ) (hy : IsUnit (y : ZMod s)) (hy' : IsUnit (y' : ZMod s)) :
    KW P (c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹)) ≤
      (4 : ℝ) ^ ((P.card : ℝ) / 2) * (s : ℝ) ^ ((1 : ℝ) / 2) *
        (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 2) *
        (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^ ((1 : ℝ) / 2) := by
  unfold KW
  have hx := Real.rpow_le_rpow (prod_nonneg fun p _ => by positivity)
    (prod_freq_le P hP hs c₀ y y' hy hy') (show (0 : ℝ) ≤ 1 / 2 by norm_num)
  rw [Real.mul_rpow (prod_nonneg fun p _ => by positivity) (prod_nonneg fun p _ => by positivity)] at hx
  calc _ ≤ (4 : ℝ) ^ ((P.card : ℝ) / 2) * (s : ℝ) ^ ((1 : ℝ) / 2) *
        ((∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 2) *
          (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^ ((1 : ℝ) / 2)) :=
        mul_le_mul_of_nonneg_left hx (by positivity)
    _ = _ := by ring

lemma prod_rpow_half_eq (S : Finset ℕ) :
    (∏ p ∈ S, (p : ℝ)) ^ ((1 : ℝ) / 2) =
      ∑ D ∈ S.powerset, ∏ p ∈ D, ((p : ℝ) ^ ((1 : ℝ) / 2) - 1) := by
  rw [← Real.finsetProd_rpow S _ (fun p _ => by positivity), ← Finset.prod_one_add]
  exact Finset.prod_congr rfl fun p _ => by ring

/-- Seravyn R0002 half-power gcd pair moment (ported verbatim). -/
theorem gcd_moment_half (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (Y : ℕ) :
    ∑ y ∈ Icc 1 Y, ∑ y' ∈ (Icc 1 Y).filter (fun y' => y ≠ y'),
      (1 / ((y : ℝ) * y')) *
        (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^ ((1 : ℝ) / 2)
    ≤ 2 * (1 + Real.log Y) ^ 2 * ∏ p ∈ P, (1 + (p : ℝ) ^ (-(1 : ℝ) / 2)) := by
  classical
  set a : Finset ℕ → ℝ := fun D => ∏ p ∈ D, ((p : ℝ) ^ ((1 : ℝ) / 2) - 1) with ha_def
  have hq : ∀ p ∈ P, (1 : ℝ) ≤ (p : ℝ) ^ ((1 : ℝ) / 2) := fun p hp =>
    Real.one_le_rpow (by exact_mod_cast (hP p hp).one_lt.le) (by norm_num)
  have ha : ∀ D ∈ P.powerset, 0 ≤ a D := fun D hD => prod_nonneg fun p hp => by
    have := hq p (mem_powerset.1 hD hp); linarith
  set ind : Finset ℕ → ℕ → ℕ → ℝ := fun D y y' =>
    if ((∏ p ∈ D, p : ℕ) : ℤ) ∣ (y : ℤ) - y' then 1 else 0 with hind
  have step1 : ∀ y y' : ℕ,
      (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^ ((1 : ℝ) / 2) ≤
        ∑ D ∈ P.powerset, a D * ind D y y' := by
    intro y y'
    rw [prod_rpow_half_eq]
    simp only [hind, mul_ite, mul_one, mul_zero]
    rw [← Finset.sum_filter]
    apply Finset.sum_le_sum_of_subset_of_nonneg
    · intro D hD
      rw [mem_powerset] at hD
      rw [mem_filter, mem_powerset]
      refine ⟨hD.trans (filter_subset _ _), ?_⟩
      apply prime_prod_dvd D (fun p hp => hP p (filter_subset _ _ (hD hp)))
      intro p hp; exact (mem_filter.1 (hD hp)).2
    · intro D hD _
      exact ha D (mem_filter.1 hD).1
  have hY := fun (D : Finset ℕ) (hD : D ∈ P.powerset) =>
    gcd_pair_sum_sym (∏ p ∈ D, p) Y
      (Nat.one_le_iff_ne_zero.2 (Finset.prod_ne_zero_iff.2 fun p hp =>
        (hP p (mem_powerset.1 hD hp)).ne_zero))
  calc _ ≤ ∑ y ∈ Icc 1 Y, ∑ y' ∈ (Icc 1 Y).filter (fun y' => y ≠ y'),
        ∑ D ∈ P.powerset, a D * ((1 / ((y : ℝ) * y')) * ind D y y') := by
        refine sum_le_sum fun y hy => sum_le_sum fun y' hy' => ?_
        have hpos : (0 : ℝ) ≤ 1 / ((y : ℝ) * y') := by positivity
        calc _ ≤ (1 / ((y : ℝ) * y')) * ∑ D ∈ P.powerset, a D * ind D y y' :=
              mul_le_mul_of_nonneg_left (step1 y y') hpos
          _ = _ := by rw [mul_sum]; exact sum_congr rfl fun D _ => by ring
    _ = ∑ D ∈ P.powerset, a D * ∑ y ∈ Icc 1 Y,
          ∑ y' ∈ (Icc 1 Y).filter (fun y' => y ≠ y' ∧
            ((∏ p ∈ D, p : ℕ) : ℤ) ∣ (y : ℤ) - y'), (1 / ((y : ℝ) * y')) := by
        rw [sum_congr rfl fun y _ => sum_comm, sum_comm]
        refine sum_congr rfl fun D _ => ?_
        rw [mul_sum]
        refine sum_congr rfl fun y _ => ?_
        rw [mul_sum, ← filter_filter,
          Finset.sum_filter (p := fun y' : ℕ => ((∏ p ∈ D, p : ℕ) : ℤ) ∣ (y : ℤ) - y')]
        refine sum_congr rfl fun y' _ => ?_
        simp only [hind]; split_ifs <;> simp
    _ ≤ ∑ D ∈ P.powerset, a D * (2 * (1 + Real.log Y) ^ 2 / ((∏ p ∈ D, p : ℕ) : ℝ)) :=
        sum_le_sum fun D hD => mul_le_mul_of_nonneg_left (hY D hD) (ha D hD)
    _ ≤ ∑ D ∈ P.powerset, 2 * (1 + Real.log Y) ^ 2 * ∏ p ∈ D, (p : ℝ) ^ (-(1 : ℝ) / 2) := by
        refine sum_le_sum fun D hD => ?_
        have hDP := mem_powerset.1 hD
        have hC : (0 : ℝ) ≤ 2 * (1 + Real.log Y) ^ 2 := by positivity
        have key : a D / ((∏ p ∈ D, p : ℕ) : ℝ) ≤ ∏ p ∈ D, (p : ℝ) ^ (-(1 : ℝ) / 2) := by
          rw [ha_def, Nat.cast_prod, ← prod_div_distrib]
          apply Finset.prod_le_prod₀
          · intro p hp
            have := hq p (hDP hp)
            have : (0 : ℝ) < p := by exact_mod_cast (hP p (hDP hp)).pos
            apply div_nonneg <;> linarith
          · intro p hp
            have hp0 : (0 : ℝ) < p := by exact_mod_cast (hP p (hDP hp)).pos
            calc ((p : ℝ) ^ ((1 : ℝ) / 2) - 1) / p ≤ (p : ℝ) ^ ((1 : ℝ) / 2) / p :=
                  div_le_div_of_nonneg_right (by linarith) hp0.le
              _ = (p : ℝ) ^ (-(1 : ℝ) / 2) := by
                  rw [← Real.rpow_sub_one hp0.ne']; norm_num
        calc a D * (2 * (1 + Real.log Y) ^ 2 / ((∏ p ∈ D, p : ℕ) : ℝ))
            = 2 * (1 + Real.log Y) ^ 2 * (a D / ((∏ p ∈ D, p : ℕ) : ℝ)) := by ring
          _ ≤ _ := mul_le_mul_of_nonneg_left key hC
    _ = _ := by rw [← mul_sum, ← Finset.prod_one_add]



open Classical in
/-- **W5, coupled.** Same bound as `W_cell`, with the coupled range `n ∈ (L_y, R_y]`. -/
theorem W_cell_coupled_W {s : ℕ} [NeZero s] (hs2 : 2 ≤ s) (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime)
    (hsP : s = ∏ p ∈ P, p) (hW : WeilHyp) (c₀ : ZMod s) (𝒴 𝒩 : Finset ℕ) (Y N M : ℕ) (hNM : N ≤ M)
    (h𝒩 : 𝒩 ⊆ Ioc N M) (h𝒴 : 𝒴 ⊆ Icc 1 Y) (hunit : ∀ y ∈ 𝒴, IsUnit (y : ZMod s))
    (α β : ℕ → ℂ) (A : ℝ) (hα : ∀ y ∈ 𝒴, ‖α y‖ ≤ A / y) (L R : ℕ → ℕ) :
    ‖∑ n ∈ 𝒩, β n * ∑ y ∈ 𝒴, α y * gI c₀ L R y n‖ ^ 2 ≤
      (∑ n ∈ 𝒩, ‖β n‖ ^ 2) * (((M - N : ℕ) : ℝ) * ∑ y ∈ 𝒴, ‖α y‖ ^ 2 +
        A ^ 2 * (((M - N : ℕ) : ℝ) * (2 * (1 + Real.log Y) ^ 2 / s) +
          (4 : ℝ) ^ ((P.card : ℝ) / 2) * (s : ℝ) ^ ((1 : ℝ) / 2) *
            (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 2) *
            (((M - N : ℕ) : ℝ) / s + 1 + Real.log s) *
            (2 * (1 + Real.log Y) ^ 2 * ∏ p ∈ P, (1 + (p : ℝ) ^ (-(1 : ℝ) / 2))))) := by
  classical
  refine (W_cauchy_coupled hs2 c₀ 𝒴 𝒩 hNM h𝒩 hunit α β L R (KW P)
    (fun c b => norm_K_le_KW hW P hP s hsP b c)).trans ?_
  apply mul_le_mul_of_nonneg_left _ (sum_nonneg fun n _ => by positivity)
  set L : ℝ := ((M - N : ℕ) : ℝ) with hL
  set G : ℝ := (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 2)
    with hG
  set Kc : ℝ := (4 : ℝ) ^ ((P.card : ℝ) / 2) * (s : ℝ) ^ ((1 : ℝ) / 2) * G *
    (L / s + 1 + Real.log s) with hKc
  have hL0 : 0 ≤ L := by positivity
  have hsR : (1 : ℝ) ≤ s := by exact_mod_cast (show 1 ≤ s by omega)
  have hlogs : 0 ≤ Real.log s := Real.log_nonneg hsR
  have hG0 : 0 ≤ G := by positivity
  have hKc0 : 0 ≤ Kc := by positivity
  have hA : ∀ y ∈ 𝒴, 0 ≤ A / y := fun y hy => (norm_nonneg _).trans (hα y hy)
  set T1 : ℕ → ℕ → ℝ := fun y y' => if y = y' then L * ‖α y‖ ^ 2 else 0 with hT1
  set T2 : ℕ → ℕ → ℝ := fun y y' =>
    if y ≠ y' ∧ ((s : ℕ) : ℤ) ∣ (y : ℤ) - y' then 1 / ((y : ℝ) * y') else 0 with hT2
  set T3 : ℕ → ℕ → ℝ := fun y y' => if y ≠ y' then (1 / ((y : ℝ) * y')) *
    (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^ ((1 : ℝ) / 2) else 0
    with hT3
  have hT2n : ∀ y y', 0 ≤ T2 y y' := fun y y' => by simp only [hT2]; split_ifs <;> positivity
  have hT3n : ∀ y y', 0 ≤ T3 y y' := fun y y' => by simp only [hT3]; split_ifs <;> positivity
  have hT1n : ∀ y y', 0 ≤ T1 y y' := fun y y' => by simp only [hT1]; split_ifs <;> positivity
  -- pointwise
  have hpt : ∀ y ∈ 𝒴, ∀ y' ∈ 𝒴, ‖α y‖ * ‖α y'‖ *
      (if (y : ZMod s) = y' then L else
        KW P (c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹)) * (L / s + 1 + Real.log s)) ≤
      T1 y y' + A ^ 2 * L * T2 y y' + A ^ 2 * Kc * T3 y y' := by
    intro y hy y' hy'
    have hy1 : 1 ≤ y := (mem_Icc.1 (h𝒴 hy)).1
    have hy1' : 1 ≤ y' := (mem_Icc.1 (h𝒴 hy')).1
    have hprod : ‖α y‖ * ‖α y'‖ ≤ A ^ 2 * (1 / ((y : ℝ) * y')) := by
      calc ‖α y‖ * ‖α y'‖ ≤ (A / y) * (A / y') :=
            mul_le_mul (hα y hy) (hα y' hy') (norm_nonneg _) (hA y hy)
        _ = _ := by ring
    have h2 := hT2n y y'; have h3 := hT3n y y'; have h1 := hT1n y y'
    have hA2 : 0 ≤ A ^ 2 := sq_nonneg A
    by_cases hyy : y = y'
    · subst hyy
      rw [if_pos rfl]
      have hT1v : T1 y y = L * ‖α y‖ ^ 2 := if_pos rfl
      have : ‖α y‖ * ‖α y‖ * L = L * ‖α y‖ ^ 2 := by ring
      rw [this, hT1v]
      have := mul_nonneg (mul_nonneg hA2 hL0) h2
      have := mul_nonneg (mul_nonneg hA2 hKc0) h3
      linarith
    · have hT1z : T1 y y' = 0 := by simp only [hT1, if_neg hyy]
      rw [hT1z, zero_add]
      split_ifs with hcong
      · -- congruent distinct pair
        have hdvd : ((s : ℕ) : ℤ) ∣ (y : ℤ) - y' := by
          have : ((y' : ℤ) : ZMod s) = ((y : ℤ) : ZMod s) := by push_cast; exact hcong.symm
          exact (ZMod.intCast_eq_intCast_iff_dvd_sub _ _ _).1 this
        have hT2v : T2 y y' = 1 / ((y : ℝ) * y') := if_pos (And.intro hyy hdvd)
        rw [hT2v]
        have := mul_nonneg (mul_nonneg hA2 hKc0) h3
        calc ‖α y‖ * ‖α y'‖ * L ≤ A ^ 2 * (1 / ((y : ℝ) * y')) * L :=
              mul_le_mul_of_nonneg_right hprod hL0
          _ = A ^ 2 * L * (1 / ((y : ℝ) * y')) := by ring
          _ ≤ _ := by linarith
      · have hT3v : T3 y y' = (1 / ((y : ℝ) * y')) *
            (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^ ((1 : ℝ) / 2) := by
          simp only [hT3, if_neg (not_not.2 hyy), if_pos hyy]
        rw [hT3v]
        have hKB := KW_offdiag P hP hsP c₀ y y' (hunit y hy) (hunit y' hy')
        have hLf : 0 ≤ L / s + 1 + Real.log s := by positivity
        have hKB0 : 0 ≤ KW P (c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹)) := by
          exact KW_nonneg P _
        have := mul_nonneg (mul_nonneg hA2 hL0) h2
        calc ‖α y‖ * ‖α y'‖ * (KW P (c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹)) *
              (L / s + 1 + Real.log s))
            ≤ A ^ 2 * (1 / ((y : ℝ) * y')) * ((4 : ℝ) ^ ((P.card : ℝ) / 2) *
                (s : ℝ) ^ ((1 : ℝ) / 2) * G *
                (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^ ((1 : ℝ) / 2) *
                (L / s + 1 + Real.log s)) :=
              mul_le_mul hprod (mul_le_mul_of_nonneg_right hKB hLf) (by positivity) (by positivity)
          _ = A ^ 2 * Kc * ((1 / ((y : ℝ) * y')) *
              (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^ ((1 : ℝ) / 2)) := by
              rw [hKc]; ring
          _ ≤ _ := by linarith
  -- sum the pointwise bound
  calc _ ≤ ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, (T1 y y' + A ^ 2 * L * T2 y y' + A ^ 2 * Kc * T3 y y') :=
        sum_le_sum fun y hy => sum_le_sum fun y' hy' => hpt y hy y' hy'
    _ = ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, T1 y y' + A ^ 2 * L * ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, T2 y y' +
          A ^ 2 * Kc * ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, T3 y y' := by
        simp only [sum_add_distrib, mul_sum]
    _ ≤ L * ∑ y ∈ 𝒴, ‖α y‖ ^ 2 + A ^ 2 * L * (2 * (1 + Real.log Y) ^ 2 / s) +
          A ^ 2 * Kc * (2 * (1 + Real.log Y) ^ 2 * ∏ p ∈ P, (1 + (p : ℝ) ^ (-(1 : ℝ) / 2))) := by
        have e1 : ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, T1 y y' = L * ∑ y ∈ 𝒴, ‖α y‖ ^ 2 := by
          rw [mul_sum]; refine sum_congr rfl fun y hy => ?_
          simp only [hT1]; rw [sum_ite_eq 𝒴 y (fun _ => L * ‖α y‖ ^ 2), if_pos hy]
        have e2 : ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, T2 y y' ≤ 2 * (1 + Real.log Y) ^ 2 / s := by
          calc _ ≤ ∑ y ∈ Icc 1 Y, ∑ y' ∈ Icc 1 Y, T2 y y' := by
                refine (sum_le_sum fun y _ => sum_le_sum_of_subset_of_nonneg h𝒴
                  fun y' _ _ => hT2n y y').trans ?_
                exact sum_le_sum_of_subset_of_nonneg h𝒴 fun y _ _ => sum_nonneg fun y' _ => hT2n y y'
            _ = ∑ y ∈ Icc 1 Y, ∑ y' ∈ (Icc 1 Y).filter (fun y' => y ≠ y' ∧
                  ((s : ℕ) : ℤ) ∣ (y : ℤ) - y'), (1 / ((y : ℝ) * y')) := by
                refine sum_congr rfl fun y _ => ?_
                rw [sum_filter]
            _ ≤ _ := gcd_pair_sum_sym s Y (by omega)
        have e3 : ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, T3 y y' ≤
            2 * (1 + Real.log Y) ^ 2 * ∏ p ∈ P, (1 + (p : ℝ) ^ (-(1 : ℝ) / 2)) := by
          calc _ ≤ ∑ y ∈ Icc 1 Y, ∑ y' ∈ Icc 1 Y, T3 y y' := by
                refine (sum_le_sum fun y _ => sum_le_sum_of_subset_of_nonneg h𝒴
                  fun y' _ _ => hT3n y y').trans ?_
                exact sum_le_sum_of_subset_of_nonneg h𝒴 fun y _ _ => sum_nonneg fun y' _ => hT3n y y'
            _ = ∑ y ∈ Icc 1 Y, ∑ y' ∈ (Icc 1 Y).filter (fun y' => y ≠ y'),
                  (1 / ((y : ℝ) * y')) *
                    (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^
                      ((1 : ℝ) / 2) := by
                refine sum_congr rfl fun y _ => ?_
                rw [sum_filter]
            _ ≤ _ := gcd_moment_half P hP Y
        rw [e1]
        have hAL : 0 ≤ A ^ 2 * L := by positivity
        have hAK : 0 ≤ A ^ 2 * Kc := by positivity
        have := mul_le_mul_of_nonneg_left e2 hAL
        have := mul_le_mul_of_nonneg_left e3 hAK
        linarith
    _ = _ := by rw [hKc]; ring

end GoldC.QuillonLWeil

#print axioms GoldC.QuillonLWeil.norm_K_le_KW
#print axioms GoldC.QuillonLWeil.gcd_moment_half
#print axioms GoldC.QuillonLWeil.W_cell_coupled_W
