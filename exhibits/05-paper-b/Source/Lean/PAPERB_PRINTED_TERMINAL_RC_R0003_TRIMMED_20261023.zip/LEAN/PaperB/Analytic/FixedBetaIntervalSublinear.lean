import PaperB.Analytic.FixedBetaIntervalMajorant
import PaperB.Analytic.FixedBetaConstSublinear

namespace PaperB.Analytic

open Real Finset Nat

theorem fixedBeta_sourceScale_interval_sublinear
    {beta eps : ℝ}
    (hb0 : 0 < beta) (hb1 : beta < 1) (heps : 0 < eps) :
    ∃ k : ℕ, 2 ≤ k ∧
      ∃ W0 : ℝ, ∀ (xi : ℝ) (W B : ℕ),
        W0 ≤ (W : ℝ) →
        k ≤ W → W ≤ B → B ≤ 2 * W →
        ‖∑ n ∈ Finset.Icc W B,
            eR (((W : ℝ) ^ beta⁻¹) / (n : ℝ) + xi * (n : ℝ))‖
          ≤ eps * (W : ℝ) := by
  obtain ⟨k, hk, hfirstExp, hsecondExp⟩ :=
    exists_fixedBeta_exponent_ledger hb0 hb1
  obtain ⟨C, hC1, hmaj⟩ :=
    fixedBeta_sourceScale_interval_majorant beta k hk
  have hC0 : 0 ≤ C := le_trans (by norm_num) hC1
  let D1 : ℝ := fixedBetaUpperConst k ^ fixedBetaA k
  let D2 : ℝ := fixedBetaLowerConst k ^ (-(fixedBetaA k))
  have hD1 : 0 ≤ D1 := by
    dsimp [D1]
    exact Real.rpow_nonneg (fixedBetaUpperConst_pos k).le _
  have hD2 : 0 ≤ D2 := by
    dsimp [D2]
    exact Real.rpow_nonneg (fixedBetaLowerConst_pos k).le _
  have he3 : 0 < eps / 3 := by positivity
  obtain ⟨W01, hW01⟩ :=
    const_mul_rpow_lt_one_is_sublinear
      (C := C * D1) (theta := fixedBetaFirstExponent beta k)
      (eps := eps / 3)
      (mul_nonneg hC0 hD1) hfirstExp he3
  obtain ⟨W02, hW02⟩ :=
    const_mul_rpow_lt_one_is_sublinear
      (C := C * D2) (theta := fixedBetaSecondExponent beta k)
      (eps := eps / 3)
      (mul_nonneg hC0 hD2) hsecondExp he3
  let Wlead : ℝ := 3 / eps
  let W0 : ℝ := max Wlead (max W01 W02)
  refine ⟨k, hk, W0, ?_⟩
  intro xi W B hW0 hkW hWB hB2
  have hWposNat : 0 < W := lt_of_lt_of_le (by omega : 0 < k) hkW
  have hW1Nat : 1 ≤ W := Nat.one_le_iff_ne_zero.mpr hWposNat.ne'
  have hW1 : (1 : ℝ) ≤ (W : ℝ) := by exact_mod_cast hW1Nat
  have hleadThreshold : Wlead ≤ (W : ℝ) :=
    (le_max_left Wlead (max W01 W02)).trans hW0
  have hW01' : W01 ≤ (W : ℝ) :=
    (le_max_left W01 W02).trans
      ((le_max_right Wlead (max W01 W02)).trans hW0)
  have hW02' : W02 ≤ (W : ℝ) :=
    (le_max_right W01 W02).trans
      ((le_max_right Wlead (max W01 W02)).trans hW0)
  have hp1 :=
    hW01 (W : ℝ) hW01' hW1
  have hp2 :=
    hW02 (W : ℝ) hW02' hW1
  have hlead : 1 ≤ (eps / 3) * (W : ℝ) := by
    dsimp [Wlead] at hleadThreshold
    have heps3 : 0 < eps / 3 := by positivity
    have hm := mul_le_mul_of_nonneg_left hleadThreshold heps3.le
    have hcalc : (eps / 3) * (3 / eps) = 1 := by
      field_simp [ne_of_gt heps]
    rw [hcalc] at hm
    exact hm
  have hraw := hmaj xi W B hWposNat hkW hWB hB2
  dsimp [D1, D2] at hp1 hp2 ⊢
  have hterms :
      C *
        ((fixedBetaUpperConst k ^ fixedBetaA k) *
            (W : ℝ) ^ fixedBetaFirstExponent beta k +
          (fixedBetaLowerConst k ^ (-(fixedBetaA k))) *
            (W : ℝ) ^ fixedBetaSecondExponent beta k)
        ≤ (2 * eps / 3) * (W : ℝ) := by
    calc
      C *
          ((fixedBetaUpperConst k ^ fixedBetaA k) *
              (W : ℝ) ^ fixedBetaFirstExponent beta k +
            (fixedBetaLowerConst k ^ (-(fixedBetaA k))) *
              (W : ℝ) ^ fixedBetaSecondExponent beta k)
        =
          (C * (fixedBetaUpperConst k ^ fixedBetaA k)) *
              (W : ℝ) ^ fixedBetaFirstExponent beta k +
          (C * (fixedBetaLowerConst k ^ (-(fixedBetaA k))) *
              (W : ℝ) ^ fixedBetaSecondExponent beta k) := by ring
      _ ≤ (eps / 3) * (W : ℝ) + (eps / 3) * (W : ℝ) :=
        add_le_add hp1 hp2
      _ = (2 * eps / 3) * (W : ℝ) := by ring
  calc
    ‖∑ n ∈ Finset.Icc W B,
        eR (((W : ℝ) ^ beta⁻¹) / (n : ℝ) + xi * (n : ℝ))‖
      ≤ 1 + C *
          ((fixedBetaUpperConst k ^ fixedBetaA k) *
              (W : ℝ) ^ fixedBetaFirstExponent beta k +
            (fixedBetaLowerConst k ^ (-(fixedBetaA k))) *
              (W : ℝ) ^ fixedBetaSecondExponent beta k) := hraw
    _ ≤ (eps / 3) * (W : ℝ) + (2 * eps / 3) * (W : ℝ) :=
      add_le_add hlead hterms
    _ = eps * (W : ℝ) := by ring

#print axioms fixedBeta_sourceScale_interval_sublinear

end PaperB.Analytic
