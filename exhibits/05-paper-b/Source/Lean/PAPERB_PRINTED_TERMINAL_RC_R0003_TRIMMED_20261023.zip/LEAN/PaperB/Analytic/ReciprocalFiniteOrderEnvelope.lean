import PaperB.Analytic.ReciprocalFiniteOrderNatIcc
import PaperB.FixedQ.FixedConductorCompletion

open scoped BigOperators

namespace PaperB.Analytic

open Real Finset Nat
open PaperB.FixedQ

noncomputable def reciprocalFiniteOrderConst (k : ℕ) : ℝ :=
  if hk : 2 ≤ k then
    Classical.choose (reciprocalFiniteOrderNatIcc_abs k hk)
  else 1

lemma reciprocalFiniteOrderConst_ge_one
    (k : ℕ) : 1 ≤ reciprocalFiniteOrderConst k := by
  by_cases hk : 2 ≤ k
  · rw [reciprocalFiniteOrderConst, dif_pos hk]
    exact (Classical.choose_spec (reciprocalFiniteOrderNatIcc_abs k hk)).1
  · rw [reciprocalFiniteOrderConst, dif_neg hk]

lemma reciprocalFiniteOrderConst_spec
    {k : ℕ} (hk : 2 ≤ k) :
    ∀ (A xi : ℝ) (V B : ℕ),
      A ≠ 0 → k ≤ V → V ≤ B → B ≤ 2 * V →
      let lam :=
        |A| * (k.factorial : ℝ) *
          (((2 * V + k : ℕ) : ℝ) ^ (k + 1))⁻¹
      ‖∑ n ∈ Finset.Icc V B,
          eR (A / (n : ℝ) + xi * (n : ℝ))‖
        ≤ 1 + reciprocalFiniteOrderConst k *
          (((B : ℝ) - (V : ℝ)) *
              lam ^ (1 / ((2 : ℝ) ^ k - 2))
            + ((B : ℝ) - (V : ℝ)) ^ (1 - 4 / (2 : ℝ) ^ k) *
              lam ^ (-(1 / ((2 : ℝ) ^ k - 2)))) := by
  rw [reciprocalFiniteOrderConst, dif_pos hk]
  exact (Classical.choose_spec (reciprocalFiniteOrderNatIcc_abs k hk)).2

noncomputable def reciprocalFiniteOrderEnvelope (K : ℕ) : ℝ :=
  1 + ∑ k ∈ Finset.Icc 2 K, reciprocalFiniteOrderConst k

lemma reciprocalFiniteOrderEnvelope_ge_one (K : ℕ) :
    1 ≤ reciprocalFiniteOrderEnvelope K := by
  unfold reciprocalFiniteOrderEnvelope
  have hsum : 0 ≤ ∑ k ∈ Finset.Icc 2 K, reciprocalFiniteOrderConst k := by
    exact Finset.sum_nonneg (fun k hk =>
      (le_trans (by norm_num) (reciprocalFiniteOrderConst_ge_one k)))
  linarith

lemma reciprocalFiniteOrderConst_le_envelope
    {k K : ℕ} (hk : 2 ≤ k) (hkK : k ≤ K) :
    reciprocalFiniteOrderConst k ≤ reciprocalFiniteOrderEnvelope K := by
  unfold reciprocalFiniteOrderEnvelope
  have hmem : k ∈ Finset.Icc 2 K := Finset.mem_Icc.mpr ⟨hk, hkK⟩
  have hnonneg :
      0 ≤ ∑ j ∈ (Finset.Icc 2 K).erase k,
        reciprocalFiniteOrderConst j := by
    exact Finset.sum_nonneg (fun j hj =>
      (le_trans (by norm_num) (reciprocalFiniteOrderConst_ge_one j)))
  rw [← Finset.sum_erase_add _ _ hmem]
  linarith

#print axioms reciprocalFiniteOrderConst_ge_one
#print axioms reciprocalFiniteOrderConst_spec
#print axioms reciprocalFiniteOrderEnvelope_ge_one
#print axioms reciprocalFiniteOrderConst_le_envelope

private lemma sum_range_shift_eq_Icc
    (f : ℕ → ℂ) (V B : ℕ) (hVB : V ≤ B) :
    (∑ j ∈ Finset.range (B - V + 1), f (V + j)) =
      ∑ n ∈ Finset.Icc V B, f n := by
  apply Finset.sum_bij (fun j _ => V + j)
  · intro j hj
    rw [Finset.mem_range] at hj
    rw [Finset.mem_Icc]
    constructor
    · omega
    · omega
  · intro j1 hj1 j2 hj2 h
    omega
  · intro n hn
    rw [Finset.mem_Icc] at hn
    refine ⟨n - V, ?_, ?_⟩
    · rw [Finset.mem_range]
      omega
    · omega
  · intro j hj
    rfl

theorem reciprocalFiniteOrderNatIcc_weighted
    (k : ℕ) (hk : 2 ≤ k) :
    ∀ (A xi : ℝ) (V B : ℕ),
      A ≠ 0 → k ≤ V → V ≤ B → B ≤ 2 * V →
      let lam :=
        |A| * (k.factorial : ℝ) *
          (((2 * V + k : ℕ) : ℝ) ^ (k + 1))⁻¹
      ‖∑ n ∈ Finset.Icc V B,
          ((((n : ℝ)⁻¹ : ℝ) : ℂ) *
            eR (A / (n : ℝ) + xi * (n : ℝ)))‖
        ≤
      2 * (1 + reciprocalFiniteOrderConst k *
        ((V : ℝ) * lam ^ (1 / ((2 : ℝ) ^ k - 2)) +
          (V : ℝ) ^ (1 - 4 / (2 : ℝ) ^ k) *
            lam ^ (-(1 / ((2 : ℝ) ^ k - 2))))) / V := by
  intro A xi V B hA hkV hVB hB2
  dsimp
  have hVpos : 0 < V := lt_of_lt_of_le (by omega : 0 < k) hkV
  let lam : ℝ :=
    |A| * (k.factorial : ℝ) *
      (((2 * V + k : ℕ) : ℝ) ^ (k + 1))⁻¹
  let Cpre : ℝ :=
    1 + reciprocalFiniteOrderConst k *
      ((V : ℝ) * lam ^ (1 / ((2 : ℝ) ^ k - 2)) +
        (V : ℝ) ^ (1 - 4 / (2 : ℝ) ^ k) *
          lam ^ (-(1 / ((2 : ℝ) ^ k - 2))))
  have hCpre0 : 0 ≤ Cpre := by
    dsimp [Cpre, lam]
    have hC0 : 0 ≤ reciprocalFiniteOrderConst k :=
      le_trans (by norm_num) (reciprocalFiniteOrderConst_ge_one k)
    positivity
  let c : ℕ → ℂ := fun j =>
    eR (A / ((V + j : ℕ) : ℝ) + xi * ((V + j : ℕ) : ℝ))
  have hprefix :
      ∀ t ≤ B - V + 1,
        ‖∑ j ∈ Finset.range t, c j‖ ≤ Cpre := by
    intro t ht
    by_cases ht0 : t = 0
    · subst t
      simpa [Cpre, lam, one_div] using hCpre0
    · have htpos : 0 < t := Nat.pos_of_ne_zero ht0
      let D := V + t - 1
      have hVD : V ≤ D := by
        dsimp [D]
        omega
      have hDB : D ≤ B := by
        dsimp [D]
        omega
      have hD2 : D ≤ 2 * V := hDB.trans hB2
      have hraw := reciprocalFiniteOrderConst_spec hk A xi V D
        hA hkV hVD hD2
      dsimp at hraw
      have hsum :
          (∑ j ∈ Finset.range t, c j) =
            ∑ n ∈ Finset.Icc V D,
              eR (A / (n : ℝ) + xi * (n : ℝ)) := by
        dsimp [c, D]
        have hEq : D - V + 1 = t := by
          dsimp [D]
          omega
        rw [← sum_range_shift_eq_Icc
          (fun n => eR (A / (n : ℝ) + xi * (n : ℝ))) V D hVD]
        rw [hEq]
      rw [hsum]
      let a : ℝ := 1 / ((2 : ℝ) ^ k - 2)
      let b : ℝ := 1 - 4 / (2 : ℝ) ^ k
      have ha0 : 0 ≤ a := by
        dsimp [a]
        have hpow4 : (4 : ℝ) ≤ (2 : ℝ) ^ k := by
          have hm := pow_le_pow_right₀ (a := (2 : ℝ)) (by norm_num) hk
          norm_num at hm ⊢
          exact hm
        have hden : 0 < (2 : ℝ) ^ k - 2 := by linarith
        positivity
      have hb0 : 0 ≤ b := by
        dsimp [b]
        have hpow4 : (4 : ℝ) ≤ (2 : ℝ) ^ k := by
          have := pow_le_pow_right₀ (a := (2 : ℝ)) (by norm_num) hk
          norm_num at this ⊢
          exact this
        have hp : 0 < (2 : ℝ) ^ k := by positivity
        rw [sub_nonneg, div_le_one hp]
        exact hpow4
      have hlen0 : 0 ≤ (D : ℝ) - (V : ℝ) := by
        exact sub_nonneg.mpr (by exact_mod_cast hVD)
      have hlenV : (D : ℝ) - (V : ℝ) ≤ (V : ℝ) := by
        have hD2R : (D : ℝ) ≤ 2 * (V : ℝ) := by exact_mod_cast hD2
        linarith
      have hlam0 : 0 ≤ lam := by
        dsimp [lam]
        positivity
      have hpow :
          ((D : ℝ) - (V : ℝ)) ^ b ≤ (V : ℝ) ^ b :=
        Real.rpow_le_rpow hlen0 hlenV hb0
      have hfirst :
          ((D : ℝ) - (V : ℝ)) * lam ^ a ≤
            (V : ℝ) * lam ^ a := by
        gcongr
      have hsecond :
          ((D : ℝ) - (V : ℝ)) ^ b * lam ^ (-a) ≤
            (V : ℝ) ^ b * lam ^ (-a) := by
        gcongr
      have hC0 : 0 ≤ reciprocalFiniteOrderConst k :=
        le_trans (by norm_num) (reciprocalFiniteOrderConst_ge_one k)
      have hmajor :
          1 + reciprocalFiniteOrderConst k *
              (((D : ℝ) - (V : ℝ)) * lam ^ a +
                ((D : ℝ) - (V : ℝ)) ^ b * lam ^ (-a))
            ≤ Cpre := by
        dsimp [Cpre]
        have hs := add_le_add hfirst hsecond
        have hm := mul_le_mul_of_nonneg_left hs hC0
        simpa [a, b, add_comm] using (add_le_add_left hm 1)
      exact hraw.trans (by simpa [lam, a, b] using hmajor)
  have hps := partialSummation_reciprocal_weight_le
    V (B - V + 1) hVpos c hCpre0 hprefix
  have hweighted :
      (∑ j ∈ Finset.range (B - V + 1),
        c j * reciprocalNatWeight V j) =
      ∑ n ∈ Finset.Icc V B,
        ((((n : ℝ)⁻¹ : ℝ) : ℂ) *
          eR (A / (n : ℝ) + xi * (n : ℝ))) := by
    calc
      (∑ j ∈ Finset.range (B - V + 1),
        c j * reciprocalNatWeight V j)
        =
      ∑ j ∈ Finset.range (B - V + 1),
        ((((V + j : ℕ) : ℝ)⁻¹ : ℝ) : ℂ) *
          eR (A / ((V + j : ℕ) : ℝ) +
            xi * ((V + j : ℕ) : ℝ)) := by
          apply Finset.sum_congr rfl
          intro j hj
          dsimp [c, reciprocalNatWeight]
          ring
      _ =
      ∑ n ∈ Finset.Icc V B,
        ((((n : ℝ)⁻¹ : ℝ) : ℂ) *
          eR (A / (n : ℝ) + xi * (n : ℝ))) := by
          exact sum_range_shift_eq_Icc
            (fun n => ((((n : ℝ)⁻¹ : ℝ) : ℂ) *
              eR (A / (n : ℝ) + xi * (n : ℝ)))) V B hVB
  rw [← hweighted]
  simpa [Cpre, lam, one_div] using hps

#print axioms reciprocalFiniteOrderNatIcc_weighted

end PaperB.Analytic
