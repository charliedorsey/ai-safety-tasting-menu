import OrielLR.AsymA
import OrielLR.MirrorLR

/-!
# Oriel L/R — the actual-cutoff parameter choice

`Y = 2^{6(⌊L^σ⌋+1)}` (so `Y³ ≤ Z(h) = 2^{20(⌊L^σ⌋+1)}`), `D = ⌈e^{40 L^{1/4}}⌉`,
`N₀ = Y/(6qD) - 1`, `L_b = log₂ h + 1`.
-/

open Filter Topology
open OrielUpper.Mirror

namespace OrielUpper

noncomputable def nC (h : ℕ) : ℕ := h2BooleanSourceCutoff h
noncomputable def Yv (h : ℕ) : ℕ := 2 ^ (6 * (nC h + 1))
noncomputable def Dv (h : ℕ) : ℕ := ⌈Dh h⌉₊
noncomputable def N0v (q h : ℕ) : ℕ := Yv h / (6 * q * Dv h) - 1
def Lbv (h : ℕ) : ℕ := Nat.log 2 h + 1

lemma Yv_cube (h : ℕ) : Yv h ^ 3 ≤ globalProperBooleanProductCutoff h := by
  unfold Yv globalProperBooleanProductCutoff globalProperBooleanBlockCount nC
  rw [← pow_mul]
  exact Nat.pow_le_pow_right (by norm_num) (by omega)

lemma Lbv_spec (h : ℕ) : h ≤ 2 ^ Lbv h :=
  (Nat.lt_pow_succ_log_self (by norm_num) h).le

lemma Dv_ge_one (h : ℕ) : 1 ≤ Dv h := by
  unfold Dv
  have := Dh_ge_one h
  exact Nat.one_le_iff_ne_zero.mpr (by
    intro h0; rw [Nat.ceil_eq_zero] at h0; linarith)

lemma Dh_le_Dv (h : ℕ) : Dh h ≤ (Dv h : ℝ) := Nat.le_ceil _

lemma Dv_le (h : ℕ) : (Dv h : ℝ) ≤ 2 * Real.exp (40 * tH h) := by
  have h1 : (Dv h : ℝ) < Dh h + 1 := Nat.ceil_lt_add_one (by linarith [Dh_ge_one h])
  have h2 := Dh_ge_one h
  rw [Dh_eq] at h1 h2
  linarith

lemma Yv_ge (h : ℕ) :
    Real.exp (4 * Real.log (h : ℝ) ^ h2BooleanSigma) ≤ (Yv h : ℝ) := by
  unfold Yv nC h2BooleanSourceCutoff
  set n := ⌊Real.log (h : ℝ) ^ h2BooleanSigma⌋₊
  have hn : Real.log (h : ℝ) ^ h2BooleanSigma < (n : ℝ) + 1 := Nat.lt_floor_add_one _
  have hl2 := Real.log_two_gt_d9
  have e : ((2 ^ (6 * (n + 1)) : ℕ) : ℝ) = Real.exp ((6 * ((n : ℝ) + 1)) * Real.log 2) := by
    have : (6 * ((n : ℝ) + 1)) = ((6 * (n + 1) : ℕ) : ℝ) := by push_cast; ring
    rw [this, Real.exp_nat_mul, Real.exp_log (by norm_num)]
    push_cast; ring
  rw [e]
  apply Real.exp_le_exp.mpr
  have : (0 : ℝ) ≤ n := Nat.cast_nonneg n
  nlinarith

/-- Nat-side conditions from one real inequality. -/
lemma nat_conds {q h : ℕ} (hq : 1 ≤ q)
    (hY : 200 * (q : ℝ) ^ 2 * Real.exp (40 * tH h) ≤ (Yv h : ℝ)) :
    (N0v q h + 1) * (6 * q) * Dv h ≤ Yv h ∧ 2 * Dv h * (6 * q) ^ 2 + 1 ≤ Yv h ∧
      1 ≤ N0v q h ∧ (Yv h : ℝ) / (12 * q * Dv h) ≤ (N0v q h : ℝ) := by
  have hD1 := Dv_ge_one h
  have hDle := Dv_le h
  have hq1 : (1 : ℝ) ≤ q := by exact_mod_cast hq
  have hD1r : (1 : ℝ) ≤ Dv h := by exact_mod_cast hD1
  have hE : 0 < Real.exp (40 * tH h) := Real.exp_pos _
  set k := 6 * q * Dv h with hk
  have hk0 : 0 < k := by positivity
  have hkr : (k : ℝ) = 6 * q * Dv h := by rw [hk]; push_cast; ring
  -- Y ≥ 16 k
  have h16r : 16 * (k : ℝ) ≤ Yv h := by
    rw [hkr]
    have : (Dv h : ℝ) * q ≤ 2 * Real.exp (40 * tH h) * q ^ 2 := by
      have : (q : ℝ) ≤ q ^ 2 := by nlinarith
      nlinarith
    nlinarith
  have h16 : 16 * k ≤ Yv h := by exact_mod_cast h16r
  have hdiv : 16 ≤ Yv h / k := (Nat.le_div_iff_mul_le hk0).mpr (by linarith)
  refine ⟨?_, ?_, ?_, ?_⟩
  · have e : N0v q h + 1 = Yv h / k := by unfold N0v; rw [← hk]; omega
    rw [e, mul_assoc, ← hk]
    exact Nat.div_mul_le_self _ _
  · have : 2 * (Dv h : ℝ) * (6 * q) ^ 2 + 1 ≤ Yv h := by
      have h1 : 1 ≤ (q : ℝ) ^ 2 * Real.exp (40 * tH h) := by
        have : 1 ≤ Real.exp (40 * tH h) := Real.one_le_exp (by linarith [tH_nonneg h])
        nlinarith
      nlinarith
    exact_mod_cast this
  · unfold N0v; rw [← hk]; omega
  · have e : (N0v q h : ℝ) = ((Yv h / k : ℕ) : ℝ) - 1 := by
      unfold N0v; rw [← hk]; rw [Nat.cast_sub (by omega)]; simp
    have hfl : (Yv h : ℝ) / k - 1 ≤ ((Yv h / k : ℕ) : ℝ) := by
      have := Nat.lt_div_mul_add (a := Yv h) hk0
      have h2 : (Yv h : ℝ) < ((Yv h / k : ℕ) : ℝ) * k + k := by exact_mod_cast this
      have hkpos : (0 : ℝ) < k := by exact_mod_cast hk0
      rw [div_sub_one hkpos.ne', div_le_iff₀ hkpos]
      linarith
    have hx : 16 ≤ (Yv h : ℝ) / k := by
      rw [le_div_iff₀ (by exact_mod_cast hk0)]; linarith
    have e2 : (Yv h : ℝ) / (12 * q * Dv h) = (Yv h : ℝ) / k / 2 := by
      rw [hkr, div_div]; ring_nf
    rw [e, e2]
    linarith

lemma E34_le {q h : ℕ} (hq : 1 ≤ q) (hh : 1 ≤ h) :
    envA34 (q * h ^ 3) ≤ k34 q * Real.exp (8 * tH h) := by
  have h1 := envA34_D_le hq hh
  rw [Dh_rpow] at h1
  have e : envA34 (q * h ^ 3) =
      envA34 (q * h ^ 3) * Real.exp (-(10 * tH h)) * Real.exp (10 * tH h) := by
    rw [mul_assoc, ← Real.exp_add]; simp
  rw [e]
  calc envA34 (q * h ^ 3) * Real.exp (-(10 * tH h)) * Real.exp (10 * tH h)
      ≤ k34 q * Real.exp (-(2 * tH h)) * Real.exp (10 * tH h) :=
        mul_le_mul_of_nonneg_right h1 (Real.exp_pos _).le
    _ = k34 q * Real.exp (8 * tH h) := by rw [mul_assoc, ← Real.exp_add]; ring_nf

lemma E34D_le {q h : ℕ} (hq : 1 ≤ q) (hh : 1 ≤ h) :
    envA34 (q * h ^ 3) * (Dv h : ℝ) ^ (-(1 / 4 : ℝ)) ≤ k34 q * Real.exp (-(2 * tH h)) := by
  refine le_trans ?_ (envA34_D_le hq hh)
  apply mul_le_mul_of_nonneg_left _ (envA34_nonneg _)
  exact Real.rpow_le_rpow_of_nonpos (by linarith [Dh_ge_one h]) (Dh_le_Dv h) (by norm_num)

lemma E1_le' {q h : ℕ} (hq : 1 ≤ q) (hh : 1 ≤ h) :
    envA1 (q * h ^ 3) ≤ kE1 q * (Real.log h + 2) := by
  refine (envA1_le hq hh).trans ?_
  have hk : 0 ≤ kE1 q := by
    unfold kE1
    exact mul_nonneg (by positivity) (pow_nonneg (by linarith [cq_pos hq]) 4)
  apply mul_le_mul_of_nonneg_left _ hk
  rw [← thH_pow64 hh]
  exact pow_le_pow_right₀ (thH_ge_one hh) (by norm_num)

lemma kE1_nonneg {q : ℕ} (hq : 1 ≤ q) : 0 ≤ kE1 q := by
  unfold kE1
  exact mul_nonneg (by positivity) (pow_nonneg (by linarith [cq_pos hq]) 4)

lemma k34_nonneg (q : ℕ) : 0 ≤ k34 q := by
  unfold k34
  exact mul_nonneg (mul_nonneg (by norm_num) (Real.exp_pos _).le) (Real.exp_pos _).le

lemma W_le {q h : ℕ} (hq : 1 ≤ q) (hh : 1 ≤ h) :
    envA1 (q * h ^ 3) * (1 + Real.log ((h ^ 2 : ℕ) : ℝ)) ≤
      2 * kE1 q * (Real.log h + 2) ^ 2 := by
  rw [log_h2]
  have hL := logh_nonneg hh
  have h1 := E1_le' hq hh
  have hk := kE1_nonneg hq
  calc envA1 (q * h ^ 3) * (1 + 2 * Real.log h)
      ≤ (kE1 q * (Real.log h + 2)) * (2 * (Real.log h + 2)) :=
        mul_le_mul h1 (by linarith) (by linarith) (by positivity)
    _ = 2 * kE1 q * (Real.log h + 2) ^ 2 := by ring

lemma Lbv_le (h : ℕ) (hh : 1 ≤ h) : (Lbv h : ℝ) ≤ 2 * (Real.log h + 2) := by
  unfold Lbv
  have := natlog2_le_two_log h
  have := logh_nonneg hh
  push_cast; linarith

/-- The single real growth condition. -/
def GrowCond (q h : ℕ) : Prop :=
  48 * Real.log (h : ℝ) ^ (1 / 4 : ℝ) + Real.log (200 * (q : ℝ) ^ 2) ≤
    Real.log (h : ℝ) ^ h2BooleanSigma

lemma grow_core {q h : ℕ} (hq : 1 ≤ q) (hc : GrowCond q h) :
    200 * (q : ℝ) ^ 2 * Real.exp (40 * tH h) ≤ Real.exp (Real.log (h : ℝ) ^ h2BooleanSigma) ∧
      48 * tH h ≤ Real.log (h : ℝ) ^ h2BooleanSigma := by
  have hq1 : (1 : ℝ) ≤ q := by exact_mod_cast hq
  have hpos : (0 : ℝ) < 200 * (q : ℝ) ^ 2 := by positivity
  have hlog : 0 ≤ Real.log (200 * (q : ℝ) ^ 2) := Real.log_nonneg (by nlinarith)
  have ht := tH_nonneg h
  unfold GrowCond at hc
  have htt : tH h = Real.log (h : ℝ) ^ (1 / 4 : ℝ) := rfl
  rw [← htt] at hc
  refine ⟨?_, by linarith⟩
  rw [← Real.exp_log hpos, ← Real.exp_add]
  exact Real.exp_le_exp.mpr (by linarith)

lemma sig_nonneg (h : ℕ) : 0 ≤ Real.log (h : ℝ) ^ h2BooleanSigma := by
  rcases Nat.eq_zero_or_pos h with h0 | hpos
  · subst h0; simp; unfold h2BooleanSigma; norm_num
  · exact Real.rpow_nonneg (logh_nonneg hpos) _

lemma Ycond {q h : ℕ} (hq : 1 ≤ q) (hc : GrowCond q h) :
    200 * (q : ℝ) ^ 2 * Real.exp (40 * tH h) ≤ (Yv h : ℝ) := by
  refine (grow_core hq hc).1.trans (le_trans ?_ (Yv_ge h))
  apply Real.exp_le_exp.mpr
  linarith [sig_nonneg h]

lemma invN0_le {q h : ℕ} (hq : 1 ≤ q) (hc : GrowCond q h) :
    1 / ((N0v q h : ℝ) + 1) ≤
      24 * q * Real.exp (40 * tH h) * Real.exp (-(4 * Real.log (h : ℝ) ^ h2BooleanSigma)) := by
  obtain ⟨-, -, hN1, hN⟩ := nat_conds hq (Ycond hq hc)
  have hq1 : (1 : ℝ) ≤ q := by exact_mod_cast hq
  have hD1 : (1 : ℝ) ≤ Dv h := by exact_mod_cast Dv_ge_one h
  have hY := Yv_ge h
  have hYp : 0 < (Yv h : ℝ) := lt_of_lt_of_le (Real.exp_pos _) hY
  have hN0p : (0 : ℝ) < Yv h / (12 * q * Dv h) := by positivity
  have h1 : 1 / ((N0v q h : ℝ) + 1) ≤ 1 / ((Yv h : ℝ) / (12 * q * Dv h)) :=
    one_div_le_one_div_of_le hN0p (by linarith)
  refine h1.trans ?_
  rw [one_div_div, div_le_iff₀ hYp]
  have hDle := Dv_le h
  have e : Real.exp (-(4 * Real.log (h : ℝ) ^ h2BooleanSigma)) *
      Real.exp (4 * Real.log (h : ℝ) ^ h2BooleanSigma) = 1 := by
    rw [← Real.exp_add]; simp
  have hE : 0 ≤ 24 * (q : ℝ) * Real.exp (40 * tH h) *
      Real.exp (-(4 * Real.log (h : ℝ) ^ h2BooleanSigma)) := by positivity
  calc 12 * (q : ℝ) * Dv h ≤ 12 * q * (2 * Real.exp (40 * tH h)) :=
        mul_le_mul_of_nonneg_left hDle (by positivity)
    _ = 24 * q * Real.exp (40 * tH h) * Real.exp (-(4 * Real.log (h : ℝ) ^ h2BooleanSigma)) *
        Real.exp (4 * Real.log (h : ℝ) ^ h2BooleanSigma) := by
        rw [mul_assoc (24 * (q : ℝ) * _), e]; ring
    _ ≤ _ := mul_le_mul_of_nonneg_left hY hE

lemma logN0_ge {q h : ℕ} (hq : 1 ≤ q) (hc : GrowCond q h) :
    3 * Real.log (h : ℝ) ^ h2BooleanSigma ≤ Real.log (N0v q h : ℝ) := by
  obtain ⟨-, -, hN1, hN⟩ := nat_conds hq (Ycond hq hc)
  obtain ⟨hg, -⟩ := grow_core hq hc
  set s := Real.log (h : ℝ) ^ h2BooleanSigma
  have hq1 : (1 : ℝ) ≤ q := by exact_mod_cast hq
  have hD1 : (1 : ℝ) ≤ Dv h := by exact_mod_cast Dv_ge_one h
  have hY := Yv_ge h
  have hDle := Dv_le h
  have hN0p : (0 : ℝ) < N0v q h := by exact_mod_cast hN1
  rw [Real.le_log_iff_exp_le hN0p]
  refine le_trans ?_ hN
  rw [le_div_iff₀ (by positivity)]
  -- 12 q D ≤ 24 q e^{40t} ≤ 200 q² e^{40t} ≤ e^{s}
  have h1 : 12 * (q : ℝ) * Dv h ≤ Real.exp s := by
    have : 12 * (q : ℝ) * Dv h ≤ 200 * (q : ℝ) ^ 2 * Real.exp (40 * tH h) := by
      have hE : 0 < Real.exp (40 * tH h) := Real.exp_pos _
      have a1 : 12 * (q : ℝ) * Dv h ≤ 12 * q * (2 * Real.exp (40 * tH h)) :=
        mul_le_mul_of_nonneg_left hDle (by positivity)
      have a2 : (q : ℝ) ≤ q ^ 2 := by nlinarith
      have a3 : 24 * (q : ℝ) * Real.exp (40 * tH h) ≤ 200 * q ^ 2 * Real.exp (40 * tH h) := by
        apply mul_le_mul_of_nonneg_right _ hE.le; nlinarith
      linarith
    linarith
  have e : Real.exp (3 * s) * Real.exp s = Real.exp (4 * s) := by rw [← Real.exp_add]; ring_nf
  calc Real.exp (3 * s) * (12 * q * Dv h) ≤ Real.exp (3 * s) * Real.exp s :=
        mul_le_mul_of_nonneg_left h1 (Real.exp_pos _).le
    _ = Real.exp (4 * s) := e
    _ ≤ Yv h := hY

lemma sig_cube {ℓ : ℝ} (hℓ : 0 < ℓ) : (ℓ ^ h2BooleanSigma) ^ 3 = ℓ ^ 2 * ℓ ^ (3 / 100 : ℝ) := by
  rw [← Real.rpow_natCast, ← Real.rpow_mul hℓ.le]
  have : h2BooleanSigma * ((3 : ℕ) : ℝ) = (2 : ℝ) + 3 / 100 := by
    unfold h2BooleanSigma; norm_num
  rw [this, Real.rpow_add hℓ]
  norm_num

lemma karE_le {q h : ℕ} (hq : 1 ≤ q) (hh : 2 ≤ h) (hc : GrowCond q h) {cK : ℝ} (hcK : 0 < cK) :
    karE cK (N0v q h) h ≤ Real.exp (-(27 * cK * Real.log (h : ℝ) ^ (3 / 100 : ℝ))) := by
  unfold karE
  apply Real.exp_le_exp.mpr
  have hℓ : 0 < Real.log (h : ℝ) := Real.log_pos (by exact_mod_cast (show 1 < h by omega))
  set ℓ := Real.log (h : ℝ)
  have hN := logN0_ge hq hc
  have hs : 0 ≤ ℓ ^ h2BooleanSigma := Real.rpow_nonneg hℓ.le _
  have h3 : (3 * ℓ ^ h2BooleanSigma) ^ 3 ≤ Real.log (N0v q h : ℝ) ^ 3 :=
    pow_le_pow_left₀ (by positivity) hN 3
  have e : (3 * ℓ ^ h2BooleanSigma) ^ 3 = 27 * (ℓ ^ 2 * ℓ ^ (3 / 100 : ℝ)) := by
    rw [mul_pow, sig_cube hℓ]; norm_num
  rw [e] at h3
  have hl2 : 0 < ℓ ^ 2 := by positivity
  have : 27 * cK * ℓ ^ (3 / 100 : ℝ) ≤ cK * Real.log (N0v q h : ℝ) ^ 3 / ℓ ^ 2 := by
    rw [le_div_iff₀ hl2]
    nlinarith
  linarith

lemma m2le {a b A B : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) (hA : a ≤ A) (hB : b ≤ B) : a * b ≤ A * B :=
  mul_le_mul hA hB hb (ha.trans hA)

lemma m4le {a b c d A B C D : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) (hd : 0 ≤ d)
    (hA : a ≤ A) (hB : b ≤ B) (hC : c ≤ C) (hD : d ≤ D) : a * b * c * d ≤ A * B * C * D :=
  m2le (by positivity) hd (m2le (by positivity) hc (m2le ha hb hA hB) hC) hD

lemma m5le {a b c d e A B C D E : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) (hd : 0 ≤ d)
    (he : 0 ≤ e) (hA : a ≤ A) (hB : b ≤ B) (hC : c ≤ C) (hD : d ≤ D) (hE : e ≤ E) :
    a * b * c * d * e ≤ A * B * C * D * E :=
  m2le (by positivity) he (m4le ha hb hc hd hA hB hC hD) hE

noncomputable def gPr (q : ℕ) : ℝ := ((6 * q : ℕ) : ℝ)
noncomputable def ga (q : ℕ) : ℝ := k34 q * (6 * (gPr q + 1)) * (24 * q) * (2 * kE1 q)
noncomputable def gb (q : ℕ) : ℝ := k34 q * (6 * (gPr q + 1)) * (2 * kE1 q)
noncomputable def gc (q : ℕ) (Ck : ℝ) : ℝ := kE1 q * ((gPr q + 1) * 3 * Ck) * 2 * (2 * kE1 q)
noncomputable def gd (q : ℕ) (Ck : ℝ) : ℝ := gc q Ck * (2 * gPr q)
noncomputable def g0 (q : ℕ) : ℝ :=
  (2 * gPr q + 1) * 3 * Real.exp (10 * Z32) * Real.exp (10 * Z32)

/-- The explicit majorant of the slice budget, as a function of `ℓ = log h`. -/
noncomputable def Gfun (q : ℕ) (Ck cK ℓ : ℝ) : ℝ :=
  ga q * ((ℓ + 2) ^ 2 * Real.exp (-(1 * ℓ ^ h2BooleanSigma))) +
  gb q * ((ℓ + 2) ^ 3 * Real.exp (-(2 * ℓ ^ (1 / 4 : ℝ)))) +
  gc q Ck * ((ℓ + 2) ^ 4 * Real.exp (-((27 * cK) * ℓ ^ (3 / 100 : ℝ)))) +
  gd q Ck * ((ℓ + 2) ^ 4 * Real.exp (-(1 * ℓ ^ (1 / 4 : ℝ)))) + g0 q

theorem slice_G {q h : ℕ} (hq : 1 ≤ q) (hh : 2 ≤ h) {cK Ck : ℝ} (hcK : 0 < cK) (hCk : 0 ≤ Ck)
    (hc : GrowCond q h) :
    sliceLR (6 * q) 3 (envA1 (q * h ^ 3)) (envA34 (q * h ^ 3)) Ck cK (Real.exp (10 * Z32))
      (Dv h) (N0v q h) (Lbv h) h ≤ Gfun q Ck cK (Real.log (h : ℝ)) := by
  have hh1 : 1 ≤ h := by omega
  have hW := W_le hq hh1
  have hE34 := E34_le hq hh1
  have hE34D := E34D_le hq hh1
  have hE1 := E1_le' hq hh1
  have hLb := Lbv_le h hh1
  have hinv := invN0_le hq hc
  have hkar := karE_le hq hh hc hcK
  obtain ⟨-, h48⟩ := grow_core hq hc
  have hk1 := kE1_nonneg hq
  have hk34 := k34_nonneg q
  have hL := logh_nonneg hh1
  have ht := tH_nonneg h
  have htt : tH h = Real.log (h : ℝ) ^ (1 / 4 : ℝ) := rfl
  have hs := sig_nonneg h
  unfold sliceLR phiLR Gfun
  rw [← htt]
  have hPr : (0 : ℝ) ≤ gPr q := Nat.cast_nonneg _
  have ePr : ((6 * q : ℕ) : ℝ) = gPr q := rfl
  rw [ePr]
  set E1 := envA1 (q * h ^ 3)
  set E34 := envA34 (q * h ^ 3)
  set ℓ := Real.log (h : ℝ)
  set W := E1 * (1 + Real.log ((h ^ 2 : ℕ) : ℝ))
  set t := tH h
  set σs := ℓ ^ h2BooleanSigma
  set kar := karE cK (N0v q h) (h : ℝ)
  set N0 := ((N0v q h : ℕ) : ℝ)
  set D := ((Dv h : ℕ) : ℝ)
  set Lb := ((Lbv h : ℕ) : ℝ)
  have hE1n : 0 ≤ E1 := envA1_nonneg _
  have hE34n : 0 ≤ E34 := envA34_nonneg _
  have hWn : 0 ≤ W := by
    have : 0 ≤ Real.log ((h ^ 2 : ℕ) : ℝ) :=
      Real.log_nonneg (by exact_mod_cast Nat.one_le_pow _ _ (by omega))
    positivity
  have hN0n : 0 ≤ N0 := Nat.cast_nonneg _
  have hDn : 0 ≤ D ^ (-(1 / 4 : ℝ)) := Real.rpow_nonneg (Nat.cast_nonneg _) _
  have hLbn : 0 ≤ Lb := Nat.cast_nonneg _
  have hkarn : 0 ≤ kar := (Real.exp_pos _).le
  have hvk : 2 * gPr q / vkM h = 2 * gPr q * Real.exp (-(1 * t)) := by
    rw [vkM_eq, one_mul, Real.exp_neg, div_eq_mul_inv]
  have e : (E34 * (2 * (gPr q + 1) * 3 / (N0 + 1) + D ^ (-(1 / 4 : ℝ)) * ((2 * gPr q + 2) * 3 * (1 + ℓ))) +
        E1 * ((gPr q + 1) * 3 * Lb * Ck * (kar + 2 * gPr q / vkM h))) * W +
        (2 * gPr q + 1) * 3 * Real.exp (10 * Z32) * Real.exp (10 * Z32) =
      E34 * (6 * (gPr q + 1)) * (1 / (N0 + 1)) * W +
      (E34 * D ^ (-(1 / 4 : ℝ))) * (6 * (gPr q + 1)) * (1 + ℓ) * W +
      E1 * ((gPr q + 1) * 3 * Ck) * Lb * kar * W +
      E1 * ((gPr q + 1) * 3 * Ck) * Lb * (2 * gPr q / vkM h) * W + g0 q := by
    unfold g0; ring
  rw [e]
  have hC3 : 0 ≤ (gPr q + 1) * 3 * Ck := by positivity
  -- term 1
  have b1 : E34 * (6 * (gPr q + 1)) * (1 / (N0 + 1)) * W ≤
      ga q * ((ℓ + 2) ^ 2 * Real.exp (-(1 * σs))) := by
    have s1 := m4le hE34n (by positivity) (by positivity) hWn hE34 (le_refl (6 * (gPr q + 1))) hinv hW
    refine s1.trans ?_
    calc k34 q * Real.exp (8 * t) * (6 * (gPr q + 1)) *
          (24 * ↑q * Real.exp (40 * t) * Real.exp (-(4 * σs))) * (2 * kE1 q * (ℓ + 2) ^ 2)
        = ga q * ((ℓ + 2) ^ 2 *
          (Real.exp (8 * t) * Real.exp (40 * t) * Real.exp (-(4 * σs)))) := by unfold ga; ring
      _ ≤ ga q * ((ℓ + 2) ^ 2 * Real.exp (-(1 * σs))) := by
        apply mul_le_mul_of_nonneg_left _ (by unfold ga; positivity)
        apply mul_le_mul_of_nonneg_left _ (by positivity)
        rw [← Real.exp_add, ← Real.exp_add]
        exact Real.exp_le_exp.mpr (by linarith)
  -- term 2
  have b2 : (E34 * D ^ (-(1 / 4 : ℝ))) * (6 * (gPr q + 1)) * (1 + ℓ) * W ≤
      gb q * ((ℓ + 2) ^ 3 * Real.exp (-(2 * t))) := by
    have s1 := m4le (by positivity) (by positivity) (by positivity) hWn hE34D (le_refl (6 * (gPr q + 1)))
      (show 1 + ℓ ≤ ℓ + 2 by linarith) hW
    refine s1.trans (le_of_eq ?_)
    unfold gb; ring
  -- term 3
  have b3 : E1 * ((gPr q + 1) * 3 * Ck) * Lb * kar * W ≤
      gc q Ck * ((ℓ + 2) ^ 4 * Real.exp (-((27 * cK) * ℓ ^ (3 / 100 : ℝ)))) := by
    have s1 := m5le hE1n hC3 hLbn hkarn hWn hE1 (le_refl ((gPr q + 1) * 3 * Ck)) hLb hkar hW
    refine s1.trans (le_of_eq ?_)
    unfold gc; ring
  -- term 4
  have b4 : E1 * ((gPr q + 1) * 3 * Ck) * Lb * (2 * gPr q / vkM h) * W ≤
      gd q Ck * ((ℓ + 2) ^ 4 * Real.exp (-(1 * t))) := by
    rw [hvk]
    have s1 := m5le hE1n hC3 hLbn (by positivity) hWn hE1 (le_refl ((gPr q + 1) * 3 * Ck)) hLb
      (le_refl (2 * gPr q * Real.exp (-(1 * t)))) hW
    refine s1.trans (le_of_eq ?_)
    unfold gd gc; ring
  linarith

end OrielUpper
