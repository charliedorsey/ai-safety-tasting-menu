import PaperB.FixedQ.SignedForbiddenThalenSourcePointwiseFinite

open scoped BigOperators

namespace PaperB.FixedQ

/-- Finite proper source packet prior to sharp outer cutoff.
The source support and proper oriented partitions are retained verbatim. -/
noncomputable def thalenFiniteProperSourcePacket
    (S : Finset ℕ) (H y : ℕ) : ℝ :=
  ∑ e ∈ S.powerset,
    (∏ p ∈ e, (1 / ((p : ℝ) - 3))) *
      (∑ A ∈ ((e.powerset.erase e).erase ∅),
        (∏ p ∈ A, (if p ∣ y then (1 : ℝ) else 0)) *
          (∏ p ∈ e \ A, (if p ∣ H-y then (1 : ℝ) else 0)))

/-- The proper source density after outer support reaggregation. -/
noncomputable def thalenFiniteProperSourceDensity (S : Finset ℕ) : ℝ :=
  (∏ p ∈ S, (1 + 2 / ((p : ℝ) * ((p : ℝ) - 3)))) -
    2 * thalenFiniteA S + 1

/-- An exact finite, source-weighted correlation.  Importantly, the source
weight lambda and its literal rowWeightMass are NOT exchanged for a generic
admissible count. This is before height decoration and sharp cutoff. -/
theorem thalen_weighted_finite_proper_source_eq_spectral
    (S : Finset ℕ) (H : ℕ) (lambda : ℕ → ℝ)
    (h5 : ∀ p ∈ S, 5 ≤ p)
    (hH : ∀ p ∈ S, ¬ p ∣ H) :
    (∑ y ∈ Finset.Ioo 0 H,
       lambda y * thalenFiniteProperSourcePacket S H y) -
        rowWeightMass lambda H * thalenFiniteProperSourceDensity S =
    (∑ y ∈ Finset.Ioo 0 H,
       lambda y *
         (thalenFiniteCenteredPacket S (thalenFiniteA S) y *
          thalenFiniteCenteredPacket S (thalenFiniteA S) (H-y))) -
        rowWeightMass lambda H *
          ((thalenFiniteA S - 1) ^ 2 +
           (thalenFiniteA S) ^ 2 *
             ((∏ p ∈ S, (1 - thalenPrimeDelta p ^ 2)) - 1)) := by
  have hd := thalen_finite_density_correction S h5
  have hsum :
      (∑ y ∈ Finset.Ioo 0 H,
         lambda y * thalenFiniteProperSourcePacket S H y) =
      (∑ y ∈ Finset.Ioo 0 H,
         lambda y *
           (thalenFiniteCenteredPacket S (thalenFiniteA S) y *
            thalenFiniteCenteredPacket S (thalenFiniteA S) (H-y))) := by
    apply Finset.sum_congr rfl
    intro y hy
    congr 1
    unfold thalenFiniteProperSourcePacket
    exact thalen_finite_source_proper_eq_spectral_pointwise S H y h5 hH
      (Finset.mem_Ioo.mp hy).2.le
  dsimp [thalenFiniteProperSourceDensity]
  rw [hsum, ← hd]

#print axioms thalen_weighted_finite_proper_source_eq_spectral

end PaperB.FixedQ
