import PaperB.FixedQ.SignedForbiddenThalenLiteralOuterRows

open scoped BigOperators

namespace PaperB.FixedQ

/-- The finite exterior at the literal sharp cutoff, expressed in the
original constrained-row and density coordinates. The small-support
source term remains signed, not normed or discarded. -/
theorem thalen_finite_exterior_eq_rows_sub_density_sub_small
    (q A H Z : ℕ) (S : Finset ℕ) :
    (∑ e ∈ S.powerset.filter (fun e => Z < primeSetProduct e),
       thalenFiniteOuterSourceTerm q A H e) =
      (∑ e ∈ S.powerset,
        finiteOmegaWeightReal e *
          (∑ B ∈ ((e.powerset.erase e).erase ∅),
            rowConstrainedMass (fixedQLowWeight q A H) H
              (primeSetProduct B) (primeSetProduct (e \ B)))) -
      rowWeightMass (fixedQLowWeight q A H) H *
        (∑ e ∈ S.powerset,
          finiteOmegaWeightReal e *
            (∑ B ∈ ((e.powerset.erase e).erase ∅),
              1 / ((primeSetProduct B : ℝ) *
                (primeSetProduct (e \ B) : ℝ)))) -
      (∑ e ∈ S.powerset.filter
        (fun e => primeSetProduct e ≤ Z),
        thalenFiniteOuterSourceTerm q A H e) := by
  rw [thalen_finite_exterior_eq_full_sub_small]
  rw [thalen_finite_outer_eq_constrained_sub_density]

#print axioms thalen_finite_exterior_eq_rows_sub_density_sub_small

end PaperB.FixedQ
