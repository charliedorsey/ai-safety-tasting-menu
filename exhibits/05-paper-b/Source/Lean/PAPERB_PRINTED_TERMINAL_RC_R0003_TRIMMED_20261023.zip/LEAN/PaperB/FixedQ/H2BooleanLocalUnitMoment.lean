import PaperB.FixedQ.H2BooleanUnitCRT
import PaperB.M3.BooleanCRTSecondMoment
import Mathlib.Algebra.GroupWithZero.Units.Basic
import Mathlib.Analysis.Fourier.ZMod
import Mathlib.Data.Nat.Totient

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def h2UnitsEquivNeZero
    (p : ℕ) [Fact p.Prime] [NeZero p] :
    (ZMod p)ˣ ≃ {x : ZMod p // x ≠ 0} where
  toFun u := ⟨(u : ZMod p), Units.ne_zero u⟩
  invFun x := Units.mk0 x.1 x.2
  left_inv u := by
    apply Units.ext
    rfl
  right_inv x := by
    apply Subtype.ext
    rfl

lemma h2_sum_units_stdAddChar_mul
    {p : ℕ} [NeZero p] (hp : p.Prime)
    (j : ZMod p) :
    (∑ a : (ZMod p)ˣ,
      ZMod.stdAddChar (j * (a : ZMod p))) =
      if j = 0 then (p - 1 : ℂ) else -1 := by
  letI : Fact p.Prime := ⟨hp⟩
  letI : NeZero p := ⟨hp.ne_zero⟩
  letI : Fintype (ZMod p)ˣ := h2FintypeZModUnits p
  by_cases hj : j = 0
  · subst j
    simp [ZMod.card_units_eq_totient, Nat.totient_prime hp]
    rw [Nat.cast_sub hp.one_le]
    norm_num
  · rw [if_neg hj]
    have htotal :
        (∑ x : ZMod p, ZMod.stdAddChar (j * x)) = 0 := by
      simpa [AddChar.mulShift_apply] using
        (AddChar.sum_eq_zero_of_ne_one
          (ZMod.isPrimitive_stdAddChar p hj))
    have hsplit :=
      Fintype.sum_eq_add_sum_subtype_ne
        (fun x : ZMod p => ZMod.stdAddChar (j * x)) 0
    have hnonzero :
        (∑ x : {x : ZMod p // x ≠ 0},
          ZMod.stdAddChar (j * (x : ZMod p))) = -1 := by
      rw [hsplit] at htotal
      simp at htotal
      rw [add_comm] at htotal
      exact eq_neg_of_add_eq_zero_left htotal
    calc
      (∑ a : (ZMod p)ˣ,
        ZMod.stdAddChar (j * (a : ZMod p))) =
        ∑ x : {x : ZMod p // x ≠ 0},
          ZMod.stdAddChar (j * (x : ZMod p)) := by
            exact Fintype.sum_equiv
              (h2UnitsEquivNeZero p)
              (fun a : (ZMod p)ˣ =>
                ZMod.stdAddChar (j * (a : ZMod p)))
              (fun x : {x : ZMod p // x ≠ 0} =>
                ZMod.stdAddChar (j * (x : ZMod p)))
              (fun a => rfl)
      _ = -1 := hnonzero

#print axioms h2_sum_units_stdAddChar_mul


noncomputable def h2BooleanPrimeLocalFactor
    {p : ℕ} [NeZero p] (j : ZMod p) (a : (ZMod p)ˣ) : ℂ :=
  (2 : ℂ)⁻¹ * (1 + ZMod.stdAddChar (j * (a : ZMod p)))

lemma h2BooleanPrimeLocalFactor_norm_sq
    {p : ℕ} [NeZero p] (j : ZMod p) (a : (ZMod p)ˣ) :
    ‖h2BooleanPrimeLocalFactor j a‖ ^ 2 =
      (1 / 2 : ℝ) +
        (ZMod.stdAddChar (j * (a : ZMod p))).re / 2 := by
  unfold h2BooleanPrimeLocalFactor
  rw [← Complex.normSq_eq_norm_sq]
  rw [Complex.normSq_mul, Complex.normSq_inv]
  have hz :
      Complex.normSq
        (ZMod.stdAddChar (j * (a : ZMod p))) = 1 := by
    rw [Complex.normSq_eq_norm_sq, norm_stdAddChar_eq_one]
    norm_num
  rw [Complex.normSq_add, Complex.normSq_one, hz]
  simp only [one_mul, Complex.conj_re, Complex.one_re]
  norm_num
  ring

lemma h2_sum_primeLocalFactor_norm_sq
    {p : ℕ} [NeZero p] (hp : p.Prime)
    (j : ZMod p) :
    (∑ a : (ZMod p)ˣ,
      ‖h2BooleanPrimeLocalFactor j a‖ ^ 2) =
      if j = 0 then (p - 1 : ℝ)
      else ((p : ℝ) - 2) / 2 := by
  letI : Fact p.Prime := ⟨hp⟩
  letI : Fintype (ZMod p)ˣ := h2FintypeZModUnits p
  simp_rw [h2BooleanPrimeLocalFactor_norm_sq]
  rw [Finset.sum_add_distrib]
  simp only [Finset.sum_const, nsmul_eq_mul]
  rw [← Finset.sum_div]
  have hchar := h2_sum_units_stdAddChar_mul hp j
  have hre := congrArg Complex.re hchar
  simp only [Complex.re_sum] at hre
  rw [hre]
  by_cases hj : j = 0
  · simp [hj, ZMod.card_units_eq_totient, Nat.totient_prime hp]
    rw [Nat.cast_sub hp.one_le]
    norm_num
    ring
  · simp [hj, ZMod.card_units_eq_totient, Nat.totient_prime hp]
    rw [Nat.cast_sub hp.one_le]
    norm_num
    ring

lemma h2_average_primeLocalFactor_norm_sq
    {p : ℕ} [NeZero p] (hp : p.Prime)
    (j : ZMod p) :
    ((Fintype.card (ZMod p)ˣ : ℝ)⁻¹) *
      (∑ a : (ZMod p)ˣ,
        ‖h2BooleanPrimeLocalFactor j a‖ ^ 2) =
      if j = 0 then 1
      else ((p : ℝ) - 2) / (2 * ((p : ℝ) - 1)) := by
  letI : Fact p.Prime := ⟨hp⟩
  letI : Fintype (ZMod p)ˣ := h2FintypeZModUnits p
  rw [h2_sum_primeLocalFactor_norm_sq hp j]
  have hcard :
      (Fintype.card (ZMod p)ˣ : ℝ) = (p : ℝ) - 1 := by
    rw [ZMod.card_units_eq_totient, Nat.totient_prime hp]
    rw [Nat.cast_sub hp.one_le]
    norm_num
  rw [hcard]
  have hp1 : (1 : ℝ) < p := by exact_mod_cast hp.one_lt
  by_cases hj : j = 0
  · simp [hj]
    field_simp [ne_of_gt (sub_pos.mpr hp1)]
  · simp [hj]
    field_simp [ne_of_gt (sub_pos.mpr hp1)]

#print axioms h2BooleanPrimeLocalFactor_norm_sq
#print axioms h2_average_primeLocalFactor_norm_sq


lemma h2_average_primeLocalFactor_eq_m3
    {p : ℕ} [NeZero p] (hp : p.Prime)
    (j : ℤ) :
    ((Fintype.card (ZMod p)ˣ : ℝ)⁻¹) *
      (∑ a : (ZMod p)ˣ,
        ‖h2BooleanPrimeLocalFactor (j : ZMod p) a‖ ^ 2) =
      (PaperB.Boolean.booleanLocalSecondMoment p j : ℝ) := by
  rw [h2_average_primeLocalFactor_norm_sq hp (j : ZMod p)]
  rw [PaperB.Boolean.booleanLocalSecondMoment_eq p j hp]
  by_cases hdiv : (p : ℤ) ∣ j
  · have hz : (j : ZMod p) = 0 :=
      (ZMod.intCast_zmod_eq_zero_iff_dvd j p).2 hdiv
    simp [hdiv, hz]
  · have hz : (j : ZMod p) ≠ 0 := by
      exact fun h => hdiv ((ZMod.intCast_zmod_eq_zero_iff_dvd j p).1 h)
    simp [hdiv, hz]

#print axioms h2_average_primeLocalFactor_eq_m3

end PaperB.FixedQ
