import GoldC.QuillonREv

/-!
# Quillon CSC3 F8.12: the **physical R theorem** (fixed `r`, VK along classes, integrated)

* `R_final`: for fixed `B` (`r = ∏B`), the R cell is `≤ 4Λ^{−90}`. The R cell's `s`-mask is:
  - the source mask;
  - not W′ (no prime of `B` in `[X, ⌊s^{u₀}⌋]`);
  - not region C (`r < s^{1+ε}`);
  - `r^{1+3ε} ≤ s`;
  - `C ∩ J_R ≠ ∅`, with `J_R = (T∖B) ∩ (X, 2^{Kv}X]`.
* `R_physical`: the R part of the actual CORE pair sum at decoration `d` is `≤ Λ^{−75}`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonRPhysical

open GoldC.QuillonEv GoldC.QuillonSetup GoldC.QuillonLam GoldC.QuillonCEv GoldC.QuillonCFinal
  GoldC.QuillonREv GoldC.QuillonWContext GoldC.QuillonRowNF

lemma Yp_mono (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) {a b : ℕ} (hab : a ≤ b) : Yp δ a ≤ Yp δ b := by
  unfold Yp
  apply Nat.floor_le_floor
  have hu : 0 ≤ u0 δ := by have := a0_pos hδ0 hδ1; unfold u0; linarith
  exact Real.rpow_le_rpow (by positivity) (by exact_mod_cast hab) hu

lemma coefR_main (q : ℕ) (μ : ℝ) (hμ : |μ| ≤ 4) :
    ∀ m, 1 ≤ m → ‖((-(2 * μ) : ℝ) : ℂ) * βk m‖ ≤ (600 * (q : ℝ) ^ 2 + 8) / m := by
  intro m hm
  rw [norm_mul, Complex.norm_real, Real.norm_eq_abs]
  have h1 := GoldC.QuillonCoef.norm_βk m hm
  have hm0 : (0 : ℝ) < m := by exact_mod_cast hm
  have h2 : |-(2 * μ)| ≤ 8 := by rw [abs_neg, abs_mul, abs_two]; linarith
  calc |-(2 * μ)| * ‖βk m‖ ≤ 8 * (1 / m) := mul_le_mul h2 h1 (norm_nonneg _) (by norm_num)
    _ ≤ (600 * (q : ℝ) ^ 2 + 8) / m := by
        rw [mul_one_div]; apply div_le_div_of_nonneg_right _ hm0.le; nlinarith [sq_nonneg (q : ℝ)]

lemma coefR_mainN (q : ℕ) (μ : ℝ) (hμ : |μ| ≤ 4) :
    ∀ m, 1 ≤ m → ‖-(((-(2 * μ) : ℝ) : ℂ) * βk m)‖ ≤ (600 * (q : ℝ) ^ 2 + 8) / m := by
  intro m hm; rw [norm_neg]; exact coefR_main q μ hμ m hm

lemma coefR_cls (q : ℕ) :
    ∀ m, 1 ≤ m → ‖(((2 * ((6 * q : ℕ) : ℝ) * (48 * q) + 1 : ℝ)) : ℂ) * βk m‖ ≤
      (600 * (q : ℝ) ^ 2 + 8) / m := by
  intro m hm
  rw [norm_mul, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (by positivity)]
  have h1 := GoldC.QuillonCoef.norm_βk m hm
  have hm0 : (0 : ℝ) < m := by exact_mod_cast hm
  calc (2 * ((6 * q : ℕ) : ℝ) * (48 * q) + 1) * ‖βk m‖ ≤ (2 * ((6 * q : ℕ) : ℝ) * (48 * q) + 1) * (1 / m) :=
        mul_le_mul_of_nonneg_left h1 (by positivity)
    _ ≤ (600 * (q : ℝ) ^ 2 + 8) / m := by
        rw [mul_one_div]; apply div_le_div_of_nonneg_right _ hm0.le; push_cast; nlinarith [sq_nonneg (q : ℝ)]

lemma coefR_clsN (q : ℕ) :
    ∀ m, 1 ≤ m → ‖(((2 * ((6 * q : ℕ) : ℝ) * (48 * q) + 1 : ℝ)) : ℂ) * -βk m‖ ≤
      (600 * (q : ℝ) ^ 2 + 8) / m := by
  intro m hm; rw [mul_neg, norm_neg]; exact coefR_cls q m hm

/-- the four `Ym` families satisfy the R-term window. -/
lemma Ym_facts (q h H r : ℕ) (hq : 1 ≤ q) (hr : 1 ≤ r) (hH : 36 * (q : ℝ) ^ 2 * r ^ 2 < H)
    (σ : ℤ) (hσ : σ = 1 ∨ σ = -1) (L : ℕ) (hL : L = 1 ∨ L = 6 * q) :
    ∀ m ∈ Icc 1 (6 * q * h), (H : ℝ) / (6 * q * r) ≤ |((σ * m * H : ℤ) : ℝ) / ((L * r : ℕ) : ℝ)| ∧
      |((σ * m * H : ℤ) : ℝ) / ((L * r : ℕ) : ℝ)| ≤ ((6 * q * h : ℕ) : ℝ) * H / r ∧
      ((6 * q * r : ℕ) : ℝ) < |((σ * m * H : ℤ) : ℝ) / ((L * r : ℕ) : ℝ)| := by
  intro m hm
  obtain ⟨hm1, hm2⟩ := mem_Icc.1 hm
  have hqR : (1 : ℝ) ≤ q := by exact_mod_cast hq
  have hrR : (1 : ℝ) ≤ r := by exact_mod_cast hr
  have hmR : (1 : ℝ) ≤ m := by exact_mod_cast hm1
  have hm2R : (m : ℝ) ≤ ((6 * q * h : ℕ) : ℝ) := by exact_mod_cast hm2
  have hH0 : (0 : ℝ) < H := lt_of_le_of_lt (by positivity) hH
  have habs : |((σ * m * H : ℤ) : ℝ)| = (m : ℝ) * H := by
    rcases hσ with rfl | rfl
    · push_cast; rw [one_mul]; exact abs_of_nonneg (by positivity)
    · push_cast; simp only [neg_mul, one_mul, abs_neg]; exact abs_of_nonneg (by positivity)
  have hLR : (1 : ℝ) ≤ L ∧ (L : ℝ) ≤ 6 * q := by
    rcases hL with rfl | rfl
    · push_cast; constructor <;> nlinarith
    · push_cast; constructor <;> nlinarith
  obtain ⟨hL1, hL6⟩ := hLR
  rw [abs_div, habs, abs_of_nonneg (by positivity : (0 : ℝ) ≤ ((L * r : ℕ) : ℝ))]
  push_cast
  have hLr : (0 : ℝ) < L * r := by positivity
  have hr0 : (0 : ℝ) < r := by linarith
  have hq0 : (0 : ℝ) < q := by linarith
  refine ⟨?_, ?_, ?_⟩
  · rw [div_le_div_iff₀ (by positivity) hLr]
    have a : (L : ℝ) * r ≤ 6 * q * r := mul_le_mul_of_nonneg_right hL6 hr0.le
    calc (H : ℝ) * (L * r) ≤ H * (6 * q * r) := mul_le_mul_of_nonneg_left a hH0.le
      _ = 1 * H * (6 * q * r) := by ring
      _ ≤ m * H * (6 * q * r) := by gcongr
  · rw [div_le_div_iff₀ hLr (by positivity)]
    have hm6 : (m : ℝ) ≤ 6 * q * h := by push_cast at hm2R; exact hm2R
    have a : (r : ℝ) ≤ L * r := le_mul_of_one_le_left hr0.le hL1
    calc (m : ℝ) * H * r ≤ (6 * q * h) * H * r := by gcongr
      _ ≤ (6 * q * h) * H * (L * r) := by gcongr
  · rw [lt_div_iff₀ hLr]
    have a : (6 * q * r : ℝ) * (L * r) ≤ 6 * q * r * (6 * q * r) := by
      apply mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right hL6 hr0.le) (by positivity)
    have b : (H : ℝ) ≤ m * H := le_mul_of_one_le_left hH0.le hmR
    nlinarith


/-- the R-cell `s`-mask for fixed `B`. -/
def GeoR (h H : ℕ) (δ : ℝ) (B : Finset ℕ) (s : ℕ) : Prop :=
  Geo0 h H δ (∏ p ∈ B, p) s ∧ (∀ p ∈ B, ¬ (Xp h ≤ p ∧ p ≤ Yp δ s)) ∧
    ¬ ((s : ℝ) ^ (1 + εp h) ≤ ((∏ p ∈ B, p : ℕ) : ℝ)) ∧ ((∏ p ∈ B, p : ℕ) : ℝ) ^ (1 + 3 * εp h) ≤ s

lemma geoR_convex (h H : ℕ) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) (B : Finset ℕ) :
    ∀ a b c, a ≤ b → b ≤ c → GeoR h H δ B a → GeoR h H δ B c → GeoR h H δ B b := by
  intro a b c hab hbc ha hc
  obtain ⟨ha1, ha2, ha3, ha4⟩ := ha
  obtain ⟨hc1, hc2, hc3, hc4⟩ := hc
  have habR : (a : ℝ) ≤ b := by exact_mod_cast hab
  refine ⟨geo0_convex_s h H δ hδ0.le _ a b c hab hbc ha1 hc1, ?_, ?_, le_trans ha4 habR⟩
  · intro p hp ⟨h1, h2⟩
    exact hc2 p hp ⟨h1, le_trans h2 (Yp_mono δ hδ0 hδ1 hbc)⟩
  · intro hcon
    apply ha3
    have hε : 0 ≤ 1 + εp h := by
      have : 0 ≤ εp h := by unfold εp; positivity
      linarith
    exact le_trans (Real.rpow_le_rpow (by positivity) habR hε) hcon

open Classical in
set_option maxHeartbeats 8000000 in
/-- **The R cell for a fixed `B` is `≤ 4Λ^{−90}`**, eventually in `h`, uniformly. -/
theorem R_final (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (a h H D : ℕ) (T B : Finset ℕ) (Kc : ℕ → Prop) [DecidablePred Kc],
      Λ₀ ≤ Real.log h → 2 ≤ h → H ≤ h →
      (∀ p ∈ T, p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q ∧ p.Coprime H ∧ p ≤ H ^ 2) → B ⊆ T →
      |∑ C ∈ (T \ B).powerset.filter (fun C => C ≠ ∅),
          (if (Kc C.card ∧ GeoR h H δ B (∏ p ∈ C, p)) ∧
              (C ∩ (T \ B).filter (fun p => Xp h < p ∧ p ≤ 2 ^ (Kvp h (∏ p ∈ B, p)) * Xp h)).Nonempty
            then ωR C * GoldC.QuillonCopyF.foldRow q a D H (∏ p ∈ B, p) (∏ p ∈ C, p) else 0)| ≤
        4 * (Real.log h) ^ (-(90 : ℝ)) := by
  obtain ⟨c, C, hc, hC, hcab⟩ := GoldC.QuillonR.class_amp_bound
  obtain ⟨Λ₁, hΛ₁, hRT⟩ := R_term_ev q hq c C hc hC
  obtain ⟨Λ₂, hΛ₂, hEΛ⟩ := GoldC.QuillonAsymp.rpow_le_exp_rpow 401 1 (1 / 4) (by norm_num) (by norm_num)
    (by norm_num)
  obtain ⟨Λ₃, hΛ₃, hsl⟩ := s_large 2
  obtain ⟨Λ₄, hΛ₄, hρev⟩ := GoldC.QuillonAsymp.rpow_le_exp_rpow 201 5 (σ₀ - 1 / 200) (by norm_num)
    (by norm_num) (by unfold σ₀; norm_num)
  refine ⟨max Λ₁ (max Λ₂ (max Λ₃ (max Λ₄ (18432 * q ^ 2 + 37 * q ^ 2 + 96 * q + 10)))),
    le_trans hΛ₁ (le_max_left _ _), ?_⟩
  intro a h H D T B Kc _ hΛ hh hHh hT hBT
  have L1 : Λ₁ ≤ Real.log h := le_trans (by simp) hΛ
  have L2 : Λ₂ ≤ Real.log h := le_trans (by simp) hΛ
  have L3 : Λ₃ ≤ Real.log h := le_trans (by simp) hΛ
  have L4 : Λ₄ ≤ Real.log h := le_trans (by simp) hΛ
  have L5 : (18432 * q ^ 2 + 37 * q ^ 2 + 96 * q + 10 : ℝ) ≤ Real.log h := le_trans (by simp) hΛ
  clear hΛ
  set Λ := Real.log h with hΛdef
  have hΛ2 : 2 ≤ Λ := le_trans hΛ₁ L1
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  set r := ∏ p ∈ B, p with hr
  have hpos4 : 0 ≤ 4 * Λ ^ (-(90 : ℝ)) := by positivity
  by_cases hex : ∃ s, GeoR h H δ B s
  swap
  · push_neg at hex
    rw [sum_eq_zero fun C _ => by rw [if_neg]; rintro ⟨⟨-, hg⟩, -⟩; exact hex _ hg, abs_zero]
    exact hpos4
  obtain ⟨s₀, hs₀⟩ := hex
  obtain ⟨-, hlogr, hr1, hs1, hrh, -, -, -, hrsH⟩ := adm h H r s₀ δ hδ0 hδ1 hh hHh hs₀.1
  have hrR : (1 : ℝ) ≤ r := by exact_mod_cast hr1
  have hr0 : (0 : ℝ) < r := by linarith
  have hrbig := hsl Λ L3 r hr0 hlogr
  have hr2 : 2 ≤ r := by
    have : (2 : ℝ) ≤ r := hrbig
    exact_mod_cast this
  have hBp : ∀ p ∈ B, p.Prime := fun p hp => (hT p (hBT hp)).1
  haveI : NeZero (6 * q) := ⟨by omega⟩
  set ε := εp h with hεdef
  obtain ⟨hε0, hε1⟩ := GoldC.QuillonCPhysical.εp_le_one (h := h) hΛ1
  set E := Eh h with hEdef
  have hE1 : 1 ≤ E := Real.one_le_exp (by positivity)
  have hEΛ' : Λ ^ (401 : ℝ) ≤ E := by
    have := hEΛ Λ L2; rw [one_mul] at this; exact this
  -- `E r r^{1+3ε} ≤ H`
  have hs₀R : ((r : ℕ) : ℝ) ^ (1 + 3 * ε) ≤ s₀ := hs₀.2.2.2
  have hEH : E * r * (r : ℝ) ^ (1 + 3 * ε) ≤ H := by
    calc E * r * (r : ℝ) ^ (1 + 3 * ε) ≤ E * r * s₀ := by gcongr
      _ = ((r : ℝ) * s₀) * E := by ring
      _ ≤ H := hrsH
  -- `Lw ≤ Nb`
  have hNb : ∀ s, GeoR h H δ B s → s ≤ NbR h H r := by
    intro s hg
    obtain ⟨⟨hZ, -, -, hg1, -, -⟩, -⟩ := hg
    apply Nat.le_floor
    rw [le_div_iff₀ (by positivity)]
    have := hg1
    rw [le_div_iff₀ (Real.exp_pos _)] at this
    have eE : E = Real.exp ((Real.log h) ^ (1 / 4 : ℝ)) := rfl
    calc (s : ℝ) * (E * r) = ((r : ℝ) * s) * E := by ring
      _ = ((r : ℝ) * s) * Real.exp ((Real.log h) ^ (1 / 4 : ℝ)) := by rw [eE]
      _ ≤ H := this
  have hLwlt : ∀ s, GeoR h H δ B s → LwR h r < s := by
    intro s hg
    have hs1' : 1 ≤ s := by
      have := hg.1.1
      rcases Nat.eq_zero_or_pos s with h0 | h0
      · rw [h0] at this; simp at this
      · exact h0
    have : ⌊(r : ℝ) ^ (1 + 3 * εp h)⌋₊ ≤ s := Nat.floor_le_of_le hg.2.2.2
    unfold LwR; omega
  have hLwNb : LwR h r ≤ NbR h H r := le_of_lt (lt_of_lt_of_le (hLwlt s₀ hs₀) (hNb s₀ hs₀))
  have hNbh : NbR h H r ≤ h := by
    have : (NbR h H r : ℝ) ≤ h := by
      have h1 : (NbR h H r : ℝ) ≤ (H : ℝ) / (E * r) := Nat.floor_le (by positivity)
      have h2 : (H : ℝ) / (E * r) ≤ H := div_le_self (by positivity) (by nlinarith)
      have h3 : (H : ℝ) ≤ h := by exact_mod_cast hHh
      linarith
    exact_mod_cast this
  -- `ρ`, `Kv`, `Lw/(2^{Kv}X)`
  set ρ := (r : ℝ) ^ ε with hρdef
  have hρ1 : (1 : ℝ) ≤ ρ := Real.one_le_rpow hrR hε0
  have hρbig : 48 * q * Xp h + 6 ≤ ρ := by
    have h1 : ρ = Real.exp (ε * Real.log r) := by rw [hρdef, Real.rpow_def_of_pos hr0]; ring_nf
    have h2 : 5 * Λ ^ (σ₀ - 1 / 200) ≤ ε * Real.log r := by
      have e : ε * (5 * Λ ^ σ₀) = 5 * Λ ^ (σ₀ - 1 / 200) := by
        rw [hεdef]; unfold εp; rw [mul_left_comm, rp hΛ0]; ring_nf
      rw [← e]; exact mul_le_mul_of_nonneg_left hlogr hε0
    have h3 : Λ ^ (201 : ℝ) ≤ ρ := by rw [h1]; exact le_trans (hρev Λ L4) (Real.exp_le_exp.2 h2)
    have h4 : (48 * q * Xp h + 6 : ℝ) ≤ Λ ^ (201 : ℝ) := by
      have hX := Xp_le (h := h) hΛ1
      have e : Λ ^ (201 : ℝ) = Λ * Λ ^ (200 : ℝ) := by
        rw [show Λ * Λ ^ (200 : ℝ) = Λ ^ (1 : ℝ) * Λ ^ (200 : ℝ) by rw [Real.rpow_one], rp hΛ0]; norm_num
      rw [e]
      have hp : 1 ≤ Λ ^ (200 : ℝ) := Real.one_le_rpow hΛ1 (by norm_num)
      have hq96 : (96 * q + 6 : ℝ) ≤ Λ := by
        have : (0 : ℝ) ≤ 18432 * q ^ 2 + 37 * q ^ 2 + 4 := by positivity
        linarith
      nlinarith
    linarith
  obtain ⟨hKv1, hKv2⟩ := Kv_bounds ρ hρ1 (Kvp h r) rfl
  have hX1 : 1 ≤ Xp h := by have := Xp_two (h := h) hΛ2; omega
  have hXle := Xp_le (h := h) hΛ1
  have hL := R_L_lower r ρ q (Xp h) (Kvp h r) (LwR h r) r rfl hq hX1 hrR hρbig hKv2 (R_Lw_ge h r hr0)
  have hUlo : 4 * (6 * q * r) + 2 ≤ LwR h r / (2 ^ Kvp h r * Xp h) := by
    set N1 := LwR h r / (2 ^ Kvp h r * Xp h)
    set Q := 6 * q * r
    have hQ1 : 1 ≤ Q := Nat.mul_pos (Nat.mul_pos (by norm_num) hq) (by omega)
    have h6ρ : (6 : ℝ) ≤ ρ := by
      have : (0 : ℝ) ≤ 48 * q * Xp h := by positivity
      linarith
    have hk6 : 6 ≤ (N1 - Q) / Q := by
      have : (6 : ℝ) ≤ (((N1 - Q) / Q : ℕ) : ℝ) := by linarith
      exact_mod_cast this
    have h1 : (N1 - Q) / Q * Q ≤ N1 - Q := Nat.div_mul_le_self _ _
    have h2 : 6 * Q ≤ N1 - Q := le_trans (Nat.mul_le_mul_right Q hk6) h1
    omega
  have hHY : 8 * ((6 * q * r : ℕ) : ℝ) * ((2 ^ Kvp h r * Xp h : ℕ) : ℝ) ^ 2 ≤
      (H : ℝ) / ((6 * q * r : ℕ) : ℝ) := by
    have hq1 : (1 : ℝ) ≤ q := by exact_mod_cast hq
    rw [le_div_iff₀ (by positivity)]
    push_cast
    have hD : (2 : ℝ) ^ Kvp h r * Xp h ≤ 4 * ρ * (2 * Λ ^ (200 : ℝ)) := by
      apply mul_le_mul hKv2 hXle (by positivity) (by positivity)
    have hD0 : (0 : ℝ) ≤ (2 : ℝ) ^ Kvp h r * Xp h := by positivity
    have hD2 : ((2 : ℝ) ^ Kvp h r * Xp h) ^ 2 ≤ 64 * ρ ^ 2 * (Λ ^ (200 : ℝ)) ^ 2 := by
      calc ((2 : ℝ) ^ Kvp h r * Xp h) ^ 2 ≤ (4 * ρ * (2 * Λ ^ (200 : ℝ))) ^ 2 := pow_le_pow_left₀ hD0 hD 2
        _ = 64 * ρ ^ 2 * (Λ ^ (200 : ℝ)) ^ 2 := by ring
    have hΛ400 : (Λ ^ (200 : ℝ)) ^ 2 = Λ ^ (400 : ℝ) := by
      rw [← Real.rpow_natCast, ← Real.rpow_mul hΛ0.le]; norm_num
    rw [hΛ400] at hD2
    -- `E ≥ 18432 q² Λ^{400}`
    have hEq : 18432 * (q : ℝ) ^ 2 * Λ ^ (400 : ℝ) ≤ E := by
      have e : Λ ^ (401 : ℝ) = Λ * Λ ^ (400 : ℝ) := by
        rw [show Λ * Λ ^ (400 : ℝ) = Λ ^ (1 : ℝ) * Λ ^ (400 : ℝ) by rw [Real.rpow_one], rp hΛ0]; norm_num
      have hqq : 18432 * (q : ℝ) ^ 2 ≤ Λ := by
        have : (0 : ℝ) ≤ 37 * q ^ 2 + 96 * q + 10 := by positivity
        linarith
      have hp : 0 ≤ Λ ^ (400 : ℝ) := by positivity
      rw [e] at hEΛ'
      calc 18432 * (q : ℝ) ^ 2 * Λ ^ (400 : ℝ) ≤ Λ * Λ ^ (400 : ℝ) := mul_le_mul_of_nonneg_right hqq hp
        _ ≤ E := hEΛ'
    -- `H ≥ E r ρ³ r`
    have hr3 : (r : ℝ) ^ (1 + 3 * ε) = r * ρ ^ 3 := by
      rw [hρdef, ← Real.rpow_natCast (_ : ℝ) 3, ← Real.rpow_mul hr0.le,
        show (r : ℝ) * (r : ℝ) ^ (ε * ((3 : ℕ) : ℝ)) = (r : ℝ) ^ (1 : ℝ) * (r : ℝ) ^ (ε * ((3 : ℕ) : ℝ))
          by rw [Real.rpow_one], rp hr0]
      push_cast; ring_nf
    rw [hr3] at hEH
    have hρ2 : ρ ^ 2 ≤ ρ ^ 3 := by nlinarith
    have hP : 0 ≤ Λ ^ (400 : ℝ) := by positivity
    calc 8 * (6 * (q : ℝ) * r) * ((2 : ℝ) ^ Kvp h r * Xp h) ^ 2 * (6 * q * r)
        ≤ 8 * (6 * (q : ℝ) * r) * (64 * ρ ^ 2 * Λ ^ (400 : ℝ)) * (6 * q * r) := by gcongr
      _ = (18432 * (q : ℝ) ^ 2 * Λ ^ (400 : ℝ)) * (r * r * ρ ^ 2) := by ring
      _ ≤ E * (r * r * ρ ^ 3) := by
          apply mul_le_mul hEq _ (by positivity) (by positivity)
          exact mul_le_mul_of_nonneg_left hρ2 (by positivity)
      _ = E * r * (r * ρ ^ 3) := by ring
      _ ≤ H := hEH
  -- source data
  have hTc : ∀ p ∈ T, p.Prime ∧ 5 ≤ p ∧ p.Coprime (6 * q) ∧ p.Coprime H := fun p hp =>
    ⟨(hT p hp).1, (hT p hp).2.1, GoldC.QuillonWFinal.coprime_6q (hT p hp).1 (hT p hp).2.1 (hT p hp).2.2.1,
      (hT p hp).2.2.2.1⟩
  have hrM : r.Coprime (6 * q) :=
    GoldC.QuillonWFinal.prod_coprime_of fun p hp => (hTc p (hBT hp)).2.2.1
  set μ := GoldC.QuillonCopyF.meanWeight q (GoldC.QuillonCopyF.reducedAnchor q a D) H with hμ
  set Γ := GoldC.QuillonCopyF.gammaClass q a D H with hΓ
  have hμb : |μ| ≤ 4 := by
    have := GoldC.QuillonCopyF.meanWeight_bounds q (GoldC.QuillonCopyF.reducedAnchor q a D) H
    rw [abs_le]; constructor <;> linarith
  have hΓb : ∀ b ν, |Γ b ν| ≤ 48 * q := fun b ν => by
    have := GoldC.QuillonCopyF.abs_gammaClass_le q a D H b ν hq
    have e : (8 : ℝ) * (6 * q) = 48 * q := by ring
    linarith
  have hcell := GoldC.QuillonRCellApp.R_cell c C hc hC hcab (6 * q) H μ Γ (by omega) (48 * q) hΓb T B hTc hBT
    r rfl hr2 ((T \ B).filter (fun p => Xp h < p ∧ p ≤ 2 ^ (Kvp h r) * Xp h)) (filter_subset _ _)
    (Xp h) (Kvp h r) (Xp_two hΛ2) (fun p hp => (mem_filter.1 hp).2) Kc (GeoR h H δ B) (NbR h H r) (LwR h r)
    hNb hLwlt (geoR_convex h H δ hδ0 hδ1 B) hUlo hHY
    (fun s => GoldC.QuillonCopyF.foldRow q a D H r s)
    (fun C' hC' hne _ => by
      have hCp : ∀ p ∈ C', p.Prime ∧ 5 ≤ p := fun p hp =>
        ⟨(hT p (sdiff_subset (hC' hp))).1, (hT p (sdiff_subset (hC' hp))).2.1⟩
      obtain ⟨p, hp⟩ := nonempty_iff_ne_empty.2 hne
      have hs2 : 2 ≤ ∏ p ∈ C', p := by
        have h1 : p ∣ ∏ p ∈ C', p := dvd_prod_of_mem _ hp
        have h2 : 0 < ∏ p ∈ C', p := prod_pos fun p hp => (hCp p hp).1.pos
        have := Nat.le_of_dvd h2 h1
        have := (hCp p hp).2; omega
      exact GoldC.QuillonBridge.foldRow_eq_rowAbs q a D H r _ hq hr2 hs2 hrM
        (GoldC.QuillonWFinal.prod_coprime_of fun p hp => (hTc p (sdiff_subset (hC' hp))).2.2.1))
    (6 * q * h) (by rw [max_eq_left hLwNb]; nlinarith)
  refine le_trans hcell ?_
  have hU : ∀ p ∈ T \ B, p.Prime ∧ 5 ≤ p ∧ p ≤ H ^ 2 := fun p hp =>
    ⟨(hT p (sdiff_subset hp)).1, (hT p (sdiff_subset hp)).2.1, (hT p (sdiff_subset hp)).2.2.2.2⟩
  have hHq : 36 * (q : ℝ) ^ 2 * (r : ℝ) ^ 2 < H := by
    have hr3 : (r : ℝ) ≤ (r : ℝ) ^ (1 + 3 * ε) :=
      le_trans (le_of_eq (Real.rpow_one _).symm) (Real.rpow_le_rpow_of_exponent_le hrR (by linarith))
    have hE37 : 37 * (q : ℝ) ^ 2 ≤ E := by
      have : 37 * (q : ℝ) ^ 2 ≤ Λ := by
        have : (0 : ℝ) ≤ 18432 * q ^ 2 + 96 * q + 10 := by positivity
        linarith
      have : Λ ≤ Λ ^ (401 : ℝ) := le_rpow_big Λ hΛ1 401 (by norm_num)
      linarith
    have hq1 : (1 : ℝ) ≤ q := by exact_mod_cast hq
    have hqr : 0 < (q : ℝ) ^ 2 * (r * r) := by positivity
    calc 36 * (q : ℝ) ^ 2 * (r : ℝ) ^ 2 < 37 * (q : ℝ) ^ 2 * (r * r) := by nlinarith
      _ ≤ E * r * r := by nlinarith
      _ ≤ E * r * (r : ℝ) ^ (1 + 3 * ε) := by gcongr
      _ ≤ H := hEH
  have w1 := hRT h H r L1 hHh hr1 hlogr hEH hLwNb (T \ B) hU (fun k => ((-(2 * μ) : ℝ) : ℂ) * βk k)
    (fun k => (((k : ℤ) * H : ℤ) : ℝ) / r) (coefR_main q μ hμb)
    (fun m hm => by
      have e : ((((m : ℤ) * H : ℤ)) : ℝ) / r = (((1 * m * H : ℤ)) : ℝ) / ((1 * r : ℕ) : ℝ) := by push_cast; ring
      rw [e]; exact Ym_facts q h H r hq hr1 hHq 1 (Or.inl rfl) 1 (Or.inl rfl) m hm)
  have w2 := hRT h H r L1 hHh hr1 hlogr hEH hLwNb (T \ B) hU (fun k => -(((-(2 * μ) : ℝ) : ℂ) * βk k))
    (fun k => (((-(k : ℤ)) * H : ℤ) : ℝ) / r) (coefR_mainN q μ hμb)
    (fun m hm => by
      have e : (((-(m : ℤ)) * H : ℤ) : ℝ) / r = (((-1 * m * H : ℤ)) : ℝ) / ((1 * r : ℕ) : ℝ) := by
        push_cast; ring
      rw [e]; exact Ym_facts q h H r hq hr1 hHq (-1) (Or.inr rfl) 1 (Or.inl rfl) m hm)
  have w3 := hRT h H r L1 hHh hr1 hlogr hEH hLwNb (T \ B) hU
    (fun k => (((2 * ((6 * q : ℕ) : ℝ) * (48 * q) + 1 : ℝ)) : ℂ) * βk k)
    (fun k => (((k : ℤ) * H : ℤ) : ℝ) / ((6 * q * r : ℕ) : ℝ)) (coefR_cls q)
    (fun m hm => by
      have e : ((((m : ℤ) * H : ℤ)) : ℝ) / ((6 * q * r : ℕ) : ℝ) =
          (((1 * m * H : ℤ)) : ℝ) / ((6 * q * r : ℕ) : ℝ) := by push_cast; ring
      rw [e]; exact Ym_facts q h H r hq hr1 hHq 1 (Or.inl rfl) (6 * q) (Or.inr rfl) m hm)
  have w4 := hRT h H r L1 hHh hr1 hlogr hEH hLwNb (T \ B) hU
    (fun k => (((2 * ((6 * q : ℕ) : ℝ) * (48 * q) + 1 : ℝ)) : ℂ) * -βk k)
    (fun k => (((-(k : ℤ)) * H : ℤ) : ℝ) / ((6 * q * r : ℕ) : ℝ)) (coefR_clsN q)
    (fun m hm => by
      have e : (((-(m : ℤ)) * H : ℤ) : ℝ) / ((6 * q * r : ℕ) : ℝ) =
          (((-1 * m * H : ℤ)) : ℝ) / ((6 * q * r : ℕ) : ℝ) := by push_cast; ring
      rw [e]; exact Ym_facts q h H r hq hr1 hHq (-1) (Or.inr rfl) (6 * q) (Or.inr rfl) m hm)
  linarith

end GoldC.QuillonRPhysical

namespace GoldC.QuillonRPhysical

open Classical
open GoldC.QuillonEv GoldC.QuillonSetup GoldC.QuillonLam GoldC.QuillonCEv GoldC.QuillonCFinal
  GoldC.QuillonREv GoldC.QuillonWContext
open GoldC.QuillonCopyS GoldC.QuillonCopyF GoldC.QuillonCopyM GoldC.QuillonWPhysical

/-- the Ramaré set of the R route for fixed `B`. -/
noncomputable def JR (h : ℕ) (T B : Finset ℕ) : Finset ℕ :=
  (T \ B).filter (fun p => Xp h < p ∧ p ≤ 2 ^ (Kvp h (∏ p ∈ B, p)) * Xp h)

/-- The R part of the CORE pair sum at decoration `d`. -/
noncomputable def RPart (Jlow Jhigh q a h : ℕ) (δ : ℝ) (d : Finset ℕ) : ℝ :=
  ∑ B ∈ (Tsrc q h d).powerset, ∑ C ∈ (Tsrc q h d).powerset,
    if B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C ∧
        (Mk0 Jlow Jhigh h (h / primeSetProduct d) δ B C ∧ ¬ WMask h δ (Tsrc q h d) B C ∧
          ¬ (((primeSetProduct C : ℕ) : ℝ) ^ (1 + εp h) ≤ ((primeSetProduct B : ℕ) : ℝ)) ∧
          ((primeSetProduct B : ℕ) : ℝ) ^ (1 + 3 * εp h) ≤ ((primeSetProduct C : ℕ) : ℝ) ∧
          (C ∩ JR h (Tsrc q h d) B).Nonempty) then
      omegaWeight B * omegaWeight C *
        foldRow q a (primeSetProduct d) (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct C)
    else 0

lemma notW_iff (h : ℕ) (δ : ℝ) (T B C : Finset ℕ) (hBT : B ⊆ T) (hCB : C ⊆ T \ B) :
    ¬ WMask h δ T B C ↔ ∀ p ∈ B, ¬ (Xp h ≤ p ∧ p ≤ Yp δ (∏ p ∈ C, p)) := by
  unfold WMask
  constructor
  · intro hW p hp hc
    apply hW
    refine ⟨p, mem_inter.2 ⟨hp, mem_filter.2 ⟨mem_sdiff.2 ⟨hBT hp, fun hpC => ?_⟩, hc⟩⟩⟩
    exact (mem_sdiff.1 (hCB hpC)).2 hp
  · rintro hall ⟨p, hp⟩
    obtain ⟨hpB, hpf⟩ := mem_inter.1 hp
    exact hall p hpB (mem_filter.1 hpf).2

set_option maxHeartbeats 4000000 in
/-- **Physical R theorem.** -/
theorem R_physical (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (Jlow Jhigh a h : ℕ) (d : Finset ℕ), Λ₀ ≤ Real.log h → 2 ≤ h →
      |RPart Jlow Jhigh q a h δ d| ≤ (Real.log h) ^ (-(75 : ℝ)) := by
  obtain ⟨Λ₁, hΛ₁, hRf⟩ := R_final q hq δ hδ0 hδ1
  set E : ℝ := Real.exp 10 * (2 * 2 + 1) ^ 10 with hE
  obtain ⟨Λ₂, hΛ₂, hKΛ⟩ := const_le_rpow (4 * E) 1 one_pos
  refine ⟨max Λ₁ Λ₂, le_trans hΛ₁ (le_max_left _ _), ?_⟩
  intro Jlow Jhigh a h d hΛ hh
  have hΛa : Λ₁ ≤ Real.log h := le_trans (le_max_left _ _) hΛ
  have hΛb : Λ₂ ≤ Real.log h := le_trans (le_max_right _ _) hΛ
  set Λ := Real.log h with hΛdef
  have hΛ2 : 2 ≤ Λ := le_trans hΛ₁ hΛa
  have hΛ0 : 0 < Λ := by linarith
  have hK := hKΛ Λ hΛb
  rw [Real.rpow_one] at hK
  set H := h / primeSetProduct d with hH
  set T := Tsrc q h d with hT
  have hTf := Tsrc_facts q h d
  have hHh : H ≤ h := Nat.div_le_self _ _
  unfold RPart
  rw [GoldC.QuillonCells.double_sum_fixB]
  have hinner : ∀ B ∈ T.powerset.filter (fun B => B ≠ ∅),
      |∑ C ∈ (T \ B).powerset.filter (fun C => C ≠ ∅),
        (if Mk0 Jlow Jhigh h H δ B C ∧ ¬ WMask h δ T B C ∧
            ¬ (((primeSetProduct C : ℕ) : ℝ) ^ (1 + εp h) ≤ ((primeSetProduct B : ℕ) : ℝ)) ∧
            ((primeSetProduct B : ℕ) : ℝ) ^ (1 + 3 * εp h) ≤ ((primeSetProduct C : ℕ) : ℝ) ∧
            (C ∩ JR h T B).Nonempty then
          omegaWeight B * omegaWeight C *
            foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0)| ≤
        ωR B * (4 * Λ ^ (-(90 : ℝ))) := by
    intro B hB
    have hBT : B ⊆ T := mem_powerset.1 (mem_filter.1 hB).1
    have hω0 : 0 ≤ ωR B := ωR_nonneg B fun p hp => (hTf p (hBT hp)).2.1
    have e : ∑ C ∈ (T \ B).powerset.filter (fun C => C ≠ ∅),
        (if Mk0 Jlow Jhigh h H δ B C ∧ ¬ WMask h δ T B C ∧
            ¬ (((primeSetProduct C : ℕ) : ℝ) ^ (1 + εp h) ≤ ((primeSetProduct B : ℕ) : ℝ)) ∧
            ((primeSetProduct B : ℕ) : ℝ) ^ (1 + 3 * εp h) ≤ ((primeSetProduct C : ℕ) : ℝ) ∧
            (C ∩ JR h T B).Nonempty then
          omegaWeight B * omegaWeight C *
            foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0) =
        ωR B * ∑ C ∈ (T \ B).powerset.filter (fun C => C ≠ ∅),
          (if ((Jlow ≤ B.card + C.card ∧ B.card + C.card < Jhigh) ∧ GeoR h H δ B (∏ p ∈ C, p)) ∧
              (C ∩ (T \ B).filter (fun p => Xp h < p ∧ p ≤ 2 ^ (Kvp h (∏ p ∈ B, p)) * Xp h)).Nonempty
            then ωR C * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p) else 0) := by
      rw [mul_sum]
      refine sum_congr rfl fun C hC => ?_
      have hCB : C ⊆ T \ B := mem_powerset.1 (mem_filter.1 hC).1
      have hW := notW_iff h δ T B C hBT hCB
      have hiff : (Mk0 Jlow Jhigh h H δ B C ∧ ¬ WMask h δ T B C ∧
            ¬ (((primeSetProduct C : ℕ) : ℝ) ^ (1 + εp h) ≤ ((primeSetProduct B : ℕ) : ℝ)) ∧
            ((primeSetProduct B : ℕ) : ℝ) ^ (1 + 3 * εp h) ≤ ((primeSetProduct C : ℕ) : ℝ) ∧
            (C ∩ JR h T B).Nonempty) ↔
          (((Jlow ≤ B.card + C.card ∧ B.card + C.card < Jhigh) ∧ GeoR h H δ B (∏ p ∈ C, p)) ∧
              (C ∩ (T \ B).filter (fun p => Xp h < p ∧ p ≤ 2 ^ (Kvp h (∏ p ∈ B, p)) * Xp h)).Nonempty) := by
        rw [hW]
        unfold Mk0 GeoR Geo0 JR primeSetProduct
        constructor
        · rintro ⟨⟨h1, h2, h3, h4, h5, h6⟩, hw, hb, hs, hj⟩
          exact ⟨⟨⟨h3, h4⟩, ⟨h1, h2, h5, h6⟩, hw, hb, hs⟩, hj⟩
        · rintro ⟨⟨⟨h3, h4⟩, ⟨h1, h2, h5, h6⟩, hw, hb, hs⟩, hj⟩
          exact ⟨⟨h1, h2, h3, h4, h5, h6⟩, hw, hb, hs, hj⟩
      split_ifs with h1 h2 h2
      · show ωR B * ωR C * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p) =
          ωR B * (ωR C * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p))
        ring
      · exact absurd (hiff.1 h1) h2
      · exact absurd (hiff.2 h2) h1
      · rw [mul_zero]
    rw [e, abs_mul, abs_of_nonneg hω0]
    exact mul_le_mul_of_nonneg_left (hRf a h H (primeSetProduct d) T B
      (fun k => Jlow ≤ B.card + k ∧ B.card + k < Jhigh) hΛa hh hHh hTf hBT) hω0
  calc _ ≤ ∑ B ∈ T.powerset.filter (fun B => B ≠ ∅),
        |∑ C ∈ (T \ B).powerset.filter (fun C => C ≠ ∅),
          (if Mk0 Jlow Jhigh h H δ B C ∧ ¬ WMask h δ T B C ∧
              ¬ (((primeSetProduct C : ℕ) : ℝ) ^ (1 + εp h) ≤ ((primeSetProduct B : ℕ) : ℝ)) ∧
              ((primeSetProduct B : ℕ) : ℝ) ^ (1 + 3 * εp h) ≤ ((primeSetProduct C : ℕ) : ℝ) ∧
              (C ∩ JR h T B).Nonempty then
            omegaWeight B * omegaWeight C *
              foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0)| :=
        abs_sum_le_sum_abs _ _
    _ ≤ ∑ B ∈ T.powerset.filter (fun B => B ≠ ∅), ωR B * (4 * Λ ^ (-(90 : ℝ))) := sum_le_sum hinner
    _ ≤ ∑ B ∈ T.powerset, ωR B * (4 * Λ ^ (-(90 : ℝ))) := by
        apply sum_le_sum_of_subset_of_nonneg (filter_subset _ _)
        intro B hB _
        have hBT : B ⊆ T := mem_powerset.1 hB
        have := ωR_nonneg B fun p hp => (hTf p (hBT hp)).2.1
        positivity
    _ = (∑ B ∈ T.powerset, ωR B) * (4 * Λ ^ (-(90 : ℝ))) := by rw [sum_mul]
    _ ≤ (E * Λ ^ (10 : ℝ)) * (4 * Λ ^ (-(90 : ℝ))) :=
        mul_le_mul_of_nonneg_right (outer_mass q h d (by linarith)) (by positivity)
    _ = (4 * E) * Λ ^ (-(80 : ℝ)) := by
        rw [show Λ ^ (-(80 : ℝ)) = Λ ^ (10 : ℝ) * Λ ^ (-(90 : ℝ)) by rw [rp hΛ0]; norm_num]; ring
    _ ≤ Λ * Λ ^ (-(80 : ℝ)) := mul_le_mul_of_nonneg_right hK (by positivity)
    _ = Λ ^ (-(79 : ℝ)) := by
        rw [show Λ * Λ ^ (-(80 : ℝ)) = Λ ^ (1 : ℝ) * Λ ^ (-(80 : ℝ)) by rw [Real.rpow_one], rp hΛ0]
        norm_num
    _ ≤ Λ ^ (-(75 : ℝ)) := Real.rpow_le_rpow_of_exponent_le (by linarith) (by norm_num)

end GoldC.QuillonRPhysical

#print axioms GoldC.QuillonRPhysical.Ym_facts
#print axioms GoldC.QuillonRPhysical.coefR_cls

#print axioms GoldC.QuillonRPhysical.R_final
#print axioms GoldC.QuillonRPhysical.R_physical
