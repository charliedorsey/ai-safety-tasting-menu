import PaperB.FixedQ.SignedForbiddenIthrenMarkedSourceCore

namespace PaperB.FixedQ

/-- The single analyst-facing full signed decorated packet at finite
ordinary-prime exhaustion N. The cutoff is evaluated at the ORIGINAL h. -/
noncomputable def ithrenFullMarkedDisjointPacketAt
    (q a h : ℕ) (Z : ℕ → ℕ) (N : ℕ) : ℝ :=
  ∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
    let H := h / primeSetProduct d
    let A := decoratedReducedAnchor q a (primeSetProduct d)
    let S := thalenActiveOrdinaryFiniteSupport q H d N
    finiteVWeightReal h d *
      (∑ y ∈ Finset.Ioo 0 H,
        fixedQLowWeight q A H y *
          ithrenLiteralDisjointModes S (Z h) H y)

/-- Full literal d-sum, without absolute values, with original Z(h),
real anchor, reduced height, and excluded d in each ordinary support. -/
theorem ithren_full_decorated_active_source_eq_marked_disjoint
    (q a h N : ℕ) (Z : ℕ → ℕ) :
    (∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
      finiteVWeightReal h d *
        (∑ e ∈ (thalenActiveOrdinaryFiniteSupport q
          (h / primeSetProduct d) d N).powerset.filter
            (fun e => Z h < primeSetProduct e),
          dForbiddenReducedBooleanCoreTerm q
            (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d) d e)) =
      ithrenFullMarkedDisjointPacketAt q a h Z N := by
  unfold ithrenFullMarkedDisjointPacketAt
  apply Finset.sum_congr rfl
  intro d hd
  dsimp
  let H := h / primeSetProduct d
  let A := decoratedReducedAnchor q a (primeSetProduct d)
  let S := thalenActiveOrdinaryFiniteSupport q H d N
  have hactive : ∀ p ∈ S, activeHighPrime q p := by
    intro p hp
    exact (Finset.mem_filter.mp hp).2.1
  have hprime : ∀ p ∈ S, p.Prime := by
    intro p hp
    exact (hactive p hp).1
  have h5 : ∀ p ∈ S, 5 ≤ p := by
    intro p hp
    exact (hactive p hp).2.1
  have hact : ∀ e ∈ S.powerset,
      e ∈ activeOrdinaryTwoDimensionalSet q H := by
    intro e he
    exact thalen_activeFiniteSupport_is_active q H N d e he
  have hdis : Disjoint d S :=
    thalen_activeFiniteSupport_disjoint q H N d
  have hsource :
      (∑ e ∈ S.powerset.filter (fun e => Z h < primeSetProduct e),
        dForbiddenReducedBooleanCoreTerm q A H d e) =
      (∑ e ∈ S.powerset.filter (fun e => Z h < primeSetProduct e),
        finiteOmegaWeightReal e *
          ordinaryBooleanInteriorDiscrepancy (fixedQLowWeight q A H) H e) := by
    apply Finset.sum_congr rfl
    intro e he
    have heS : e ∈ S.powerset := (Finset.mem_filter.mp he).1
    rw [thalen_dForbidden_eq_finiteOuterSourceTerm
      (Finset.disjoint_of_subset_right (Finset.mem_powerset.mp heS) hdis)
      (hact e heS)]
    rfl
  rw [hsource]
  exact ithren_literal_fixedQ_height_decorated_disjoint
    q A h (Z h) S d hprime h5

#print axioms ithren_full_decorated_active_source_eq_marked_disjoint
end PaperB.FixedQ

namespace PaperB.FixedQ

/-- The same full decorated identity in the canonical raw finite source
coordinates. Both the active gate and the original sharp cutoff survive. -/
theorem ithren_full_raw_decorated_source_eq_marked_disjoint
    (q a h N : ℕ) (Z : ℕ → ℕ) :
    (∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
      finiteVWeightReal h d *
        (∑ n ∈ (Finset.range N).powerset,
          if Z h < primeSetProduct n then
            dForbiddenReducedBooleanCoreTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) d n
          else 0)) =
      ithrenFullMarkedDisjointPacketAt q a h Z N := by
  rw [← ithren_full_decorated_active_source_eq_marked_disjoint]
  apply Finset.sum_congr rfl
  intro d hd
  congr 1
  exact thalen_reducedExterior_range_eq_activeFinite
    q (decoratedReducedAnchor q a (primeSetProduct d))
    (h / primeSetProduct d) (Z h) N d

/-- The analysts' disjoint marked packet is the already-established
source-compatible full signed finite exterior spectral approximation. -/
theorem ithren_full_marked_disjoint_eq_global_spectralAt
    (q a h N : ℕ) (Z : ℕ → ℕ) :
    ithrenFullMarkedDisjointPacketAt q a h Z N =
      thalenGlobalSpectralAt q a h (Z h) N := by
  rw [← ithren_full_decorated_active_source_eq_marked_disjoint]
  unfold thalenGlobalSpectralAt
  apply Finset.sum_congr rfl
  intro d hd
  let H := h / primeSetProduct d
  let A := decoratedReducedAnchor q a (primeSetProduct d)
  let S := thalenActiveOrdinaryFiniteSupport q H d N
  change finiteVWeightReal h d *
      (∑ n ∈ S.powerset.filter (fun n => Z h < primeSetProduct n),
        dForbiddenReducedBooleanCoreTerm q A H d n) =
      finiteVWeightReal h d * thalenReducedSpectralAt q A H (Z h) d N
  have hsource := thalen_decorated_finite_exterior_eq_spectral_sub_small
    q A H (Z h) d S
    (fun n hn => thalen_activeFiniteSupport_is_active q H N d n hn)
    (thalen_activeFiniteSupport_disjoint q H N d)
  rw [hsource]
  rfl

open Filter

/-- Exact full marked-packet exhaustion of the LITERAL global proper
exterior. No analytic saving or cutoff transfer is asserted. -/
theorem ithren_full_marked_disjoint_tendsto_literal_exterior
    {q a h : ℕ} (Z : ℕ → ℕ)
    (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    Tendsto
      (fun N : ℕ => ithrenFullMarkedDisjointPacketAt q a h Z N)
      atTop (nhds (globalProperExteriorAnalytic q a h (Z h))) := by
  have heq :
      (fun N : ℕ => ithrenFullMarkedDisjointPacketAt q a h Z N) =
        (fun N : ℕ => thalenGlobalSpectralAt q a h (Z h) N) := by
    funext N
    exact ithren_full_marked_disjoint_eq_global_spectralAt q a h N Z
  rw [heq]
  exact thalen_globalProperExterior_tendsto_signedSpectral
    (q := q) (a := a) (h := h) (Z := Z h) hq hh h2

#print axioms ithren_full_raw_decorated_source_eq_marked_disjoint
#print axioms ithren_full_marked_disjoint_eq_global_spectralAt
#print axioms ithren_full_marked_disjoint_tendsto_literal_exterior

end PaperB.FixedQ
