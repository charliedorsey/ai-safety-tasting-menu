import PaperB.FixedQ.SignedForbiddenTavrenQuarterExteriorSplit
import PaperB.FixedQ.SignedForbiddenTorvenDecoratedQuarterFarRate
import PaperB.FixedQ.SignedForbiddenNaturalBridge

open scoped BigOperators Classical
namespace PaperB.FixedQ

/-- The Torven proper natural term and Tavren's signed filtered prime-set
term agree exactly on squarefree coordinates, including the source D mask. -/
theorem iriam_torvenProperNatural_eq_dForbidden_of_prime
    {q A H D : ℕ} {n : Finset ℕ}
    (hp : ∀ p ∈ n, p.Prime) :
    torvenSourceProperNaturalTerm q A H D (primeSetProduct n) =
      (if (primeSetProduct n).Coprime (H * (6 * q) * D) ∧ n.Nonempty
       then ordinaryBooleanCoreTerm q A H n else 0) := by
  classical
  have hsq : Squarefree (primeSetProduct n) := primeSetProduct_squarefree hp
  have hpf : (primeSetProduct n).primeFactors = n := Nat.primeFactors_prod hp
  by_cases hn : n.Nonempty
  · obtain ⟨p, hpn⟩ := hn
    have hne : n.Nonempty := ⟨p, hpn⟩
    have hpp : p.Prime := hp p hpn
    have hpd : p ∣ primeSetProduct n := by
      unfold primeSetProduct
      exact Finset.dvd_prod_of_mem (fun z : ℕ => z) hpn
    have hpos := primeSetProduct_pos hp
    have hgt : 1 < primeSetProduct n :=
      lt_of_lt_of_le hpp.one_lt (Nat.le_of_dvd hpos hpd)
    by_cases hc : (primeSetProduct n).Coprime (H * (6*q) * D)
    · simp [torvenSourceProperNaturalTerm, hgt, hsq, hc, hne, hpf]
    · simp [torvenSourceProperNaturalTerm, hc]
  · have hz : n = ∅ := Finset.not_nonempty_iff_eq_empty.mp hn
    subst n
    simp [torvenSourceProperNaturalTerm, primeSetProduct]

#print axioms iriam_torvenProperNatural_eq_dForbidden_of_prime
end PaperB.FixedQ

namespace PaperB.FixedQ

/-- Exact source coprimality gate, on an admissible decorated-height set. -/
theorem iriam_dForbidden_eq_torvenProperNatural_of_prime
    {q A h H : ℕ} {d n : Finset ℕ}
    (hd : d ⊆ decoratedHeightPrimeSet q h)
    (hp : ∀ p ∈ n, p.Prime) :
    dForbiddenReducedBooleanCoreTerm q A H d n =
      torvenSourceProperNaturalTerm
        q A H (primeSetProduct d) (primeSetProduct n) := by
  classical
  rw [iriam_torvenProperNatural_eq_dForbidden_of_prime hp]
  by_cases hact : n ∈ activeOrdinaryTwoDimensionalSet q H
  · have hiff := dForbidden_source_coprime_iff hd hact
    by_cases hne : n.Nonempty
    · by_cases hdis : Disjoint d n
      · have hc := hiff.mp hdis
        simp [dForbiddenReducedBooleanCoreTerm, hdis, hc, hne]
      · have hc : ¬ (primeSetProduct n).Coprime
          (H * (6 * q) * primeSetProduct d) := by
          exact fun hh => hdis (hiff.mpr hh)
        simp [dForbiddenReducedBooleanCoreTerm, hdis, hc, hne]
    · have hz : n = ∅ := Finset.not_nonempty_iff_eq_empty.mp hne
      subst n
      simp [dForbiddenReducedBooleanCoreTerm, ordinaryBooleanCoreTerm,
        ordinaryBooleanInteriorDiscrepancy, primeSetProduct]
  · have hz : ordinaryBooleanCoreTerm q A H n = 0 := by
      simp [ordinaryBooleanCoreTerm, Set.indicator, hact]
    simp [dForbiddenReducedBooleanCoreTerm, hz]

/-- Unsupported nonprime sets vanish in the proper signed source. -/
theorem iriam_dForbidden_zero_of_nonprime
    {q A H : ℕ} {d n : Finset ℕ}
    (hn : ¬ ∀ p ∈ n, p.Prime) :
    dForbiddenReducedBooleanCoreTerm q A H d n = 0 := by
  have hnot : n ∉ activeOrdinaryTwoDimensionalSet q H := by
    intro hact
    exact hn (fun p hp => (hact.2 p hp).1)
  simp [dForbiddenReducedBooleanCoreTerm, ordinaryBooleanCoreTerm,
    Set.indicator, hnot]

#print axioms iriam_dForbidden_eq_torvenProperNatural_of_prime
#print axioms iriam_dForbidden_zero_of_nonprime

end PaperB.FixedQ

namespace PaperB.FixedQ

/-- Source-neutral signed prime-set to squarefree-natural tsum transport.
A pair of support-zero lemmas prevents a counterfeit extension of the
source to nonprime and nonsquarefree coordinates. -/
private theorem iriam_tsum_primeFinset_to_nat
    (f : Finset ℕ → ℝ) (g : ℕ → ℝ)
    (hprime : ∀ n : Finset ℕ,
      (∀ p ∈ n, p.Prime) → f n = g (primeSetProduct n))
    (hother : ∀ n : Finset ℕ,
      (¬ ∀ p ∈ n, p.Prime) → f n = 0)
    (hnonsq : ∀ m : ℕ, ¬ Squarefree m → g m = 0) :
    (∑' n : Finset ℕ, f n) = ∑' m : ℕ, g m := by
  classical
  let P : Set (Finset ℕ) := {n | ∀ p ∈ n, p.Prime}
  have hprimeRestr :
      (∑' n : Finset ℕ, f n) =
        (∑' n : PrimeFinset, f n.1) := by
    have hind :
        (∑' n : Finset ℕ, f n) =
          ∑' n : Finset ℕ, P.indicator f n := by
      apply tsum_congr
      intro n
      by_cases hn : n ∈ P
      · simp [Set.indicator, hn]
      · have hz : f n = 0 := hother n (by simpa [P] using hn)
        simp [Set.indicator, hn, hz]
    rw [hind, ← tsum_subtype]
    rfl
  have hnatRestr :
      (∑' m : SquarefreeNat, g m.1) =
        (∑' m : ℕ, g m) := by
    let S : Set ℕ := {m | Squarefree m}
    have hind :
        (∑' m : ℕ, S.indicator g m) =
          (∑' m : ℕ, g m) := by
      apply tsum_congr
      intro m
      by_cases hm : m ∈ S
      · simp [Set.indicator, hm]
      · have hz : g m = 0 := hnonsq m (by simpa [S] using hm)
        simp [Set.indicator, hm, hz]
    rw [← hind, ← tsum_subtype]
    rfl
  calc
    (∑' n : Finset ℕ, f n) =
        ∑' s : PrimeFinset, f s.1 := hprimeRestr
    _ = ∑' s : PrimeFinset, g (primeSetProduct s.1) := by
      apply tsum_congr
      intro s
      exact hprime s.1 s.2
    _ = ∑' m : SquarefreeNat, g m.1 := by
      symm
      calc
        (∑' m : SquarefreeNat, g m.1) =
          ∑' s : PrimeFinset, g (primeFinsetEquivSquarefreeNat s).1 :=
            (Equiv.tsum_eq primeFinsetEquivSquarefreeNat
              (fun m : SquarefreeNat => g m.1)).symm
        _ = ∑' s : PrimeFinset, g (primeSetProduct s.1) := by
          apply tsum_congr
          intro s
          rfl
    _ = ∑' m : ℕ, g m := hnatRestr

/-- UNCONDITIONAL exact bridge for one source height-division layer.
Both predicates are transported together, without exchanging H=h/D or Z. -/
theorem iriam_reducedQuarterFar_eq_torvenNatural
    {q A h H Z : ℕ} {d : Finset ℕ}
    (hd : d ⊆ decoratedHeightPrimeSet q h) :
    tavrenReducedExteriorQuarterFarCore q A H Z d =
      torvenReducedProperQuarterFarSigned
        q A H (primeSetProduct d) Z := by
  classical
  unfold tavrenReducedExteriorQuarterFarCore
    torvenReducedProperQuarterFarSigned
  apply iriam_tsum_primeFinset_to_nat
  · intro n hp
    have heq := iriam_dForbidden_eq_torvenProperNatural_of_prime
      (q := q) (A := A) (h := h) (H := H) (d := d) hd hp
    by_cases hfar : H ^ 2 < 4 * primeSetProduct n
    · by_cases hcut : Z < primeSetProduct n
      · simp [hfar, hcut, heq]
      · simp [hfar, hcut]
    · simp [hfar]
  · intro n hn
    simp [iriam_dForbidden_zero_of_nonprime (q := q) (A := A)
      (H := H) (d := d) hn]
  · intro m hm
    simp [torvenSourceProperNaturalTerm, hm]

#print axioms iriam_reducedQuarterFar_eq_torvenNatural

end PaperB.FixedQ

namespace PaperB.FixedQ

/-- The entire literal SIGNED decorated far sector is Torven's natural
proper far sector, with original Z(h), reduced H_d, and all d signs. -/
theorem iriam_globalQuarterFar_eq_torvenDecorated
    (q a h Z : ℕ) :
    tavrenGlobalExteriorQuarterFar q a h Z =
      torvenDecoratedProperQuarterFarNatural q a h Z := by
  unfold tavrenGlobalExteriorQuarterFar
    torvenDecoratedProperQuarterFarNatural
  apply Finset.sum_congr rfl
  intro d hd
  exact congrArg (fun x : ℝ => finiteVWeightReal h d * x)
    (iriam_reducedQuarterFar_eq_torvenNatural
      (q := q)
      (A := decoratedReducedAnchor q a (primeSetProduct d))
      (h := h) (H := h / primeSetProduct d) (Z := Z) (d := d)
      (Finset.mem_powerset.mp hd))

/-- Literal source-native signed far sector has unconditional o(log h),
not just a natural-modulus proxy. All decorated weights are paid. -/
theorem iriam_literalQuarterFar_sublog (q : ℕ) :
    ∀ ε : ℝ, 0 < ε →
      ∃ h0 : ℕ, ∀ a h : ℕ,
        (¬ 2 ∣ q → 2 ∣ h) →
        0 < h →
        h0 ≤ h →
        |tavrenGlobalExteriorQuarterFar q a h
          (globalProperBooleanProductCutoff h)| ≤
          ε * Real.log (h : ℝ) := by
  intro ε hε
  obtain ⟨h0, hbound⟩ :=
    torven_decoratedProperQuarterFarNatural_sublog q ε hε
  refine ⟨h0, ?_⟩
  intro a h h2 hh hlarge
  rw [iriam_globalQuarterFar_eq_torvenDecorated]
  exact hbound a h (globalProperBooleanProductCutoff h) h2 hh hlarge

/-- UNCONDITIONAL analytical source shrink: the entire literal exterior,
minus the signed quarter-middle, is already o(log h). The middle remains
unpaid; no conditional rate hypothesis is smuggled into this statement. -/
theorem iriam_globalExterior_sub_middle_sublog
    (q : ℕ) (hq : 0 < q) :
    ∀ ε : ℝ, 0 < ε →
      ∃ h0 : ℕ, ∀ a h : ℕ,
        (¬ 2 ∣ q → 2 ∣ h) →
        0 < h →
        h0 ≤ h →
        |globalProperExteriorAnalytic q a h
            (globalProperBooleanProductCutoff h) -
          tavrenGlobalExteriorQuarterMiddle q a h
            (globalProperBooleanProductCutoff h)| ≤
          ε * Real.log (h : ℝ) := by
  intro ε hε
  obtain ⟨h0, hbound⟩ := iriam_literalQuarterFar_sublog q ε hε
  refine ⟨h0, ?_⟩
  intro a h h2 hh hlarge
  rw [tavren_globalProperExterior_sourceCutoff_quarterSplit hq hh h2]
  convert hbound a h h2 hh hlarge using 1 <;> ring

#print axioms iriam_globalQuarterFar_eq_torvenDecorated
#print axioms iriam_literalQuarterFar_sublog
#print axioms iriam_globalExterior_sub_middle_sublog

end PaperB.FixedQ
