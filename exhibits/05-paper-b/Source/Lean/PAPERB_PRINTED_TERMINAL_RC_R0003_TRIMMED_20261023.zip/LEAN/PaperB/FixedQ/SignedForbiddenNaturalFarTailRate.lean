import PaperB.FixedQ.SignedForbiddenNaturalFarTail
import PaperB.FixedQ.SignedForbiddenShiuReciprocalFarTail

open scoped BigOperators

namespace PaperB.FixedQ

lemma abs_rowWeightMass_fixedQLowWeight_le_six_mul
    {q a H : ℕ}
    (h2 : ¬ 2 ∣ q → 2 ∣ H) :
    |rowWeightMass (fixedQLowWeight q a H) H| ≤ 6 * (H : ℝ) := by
  rw [rowWeightMass_fixedQLowWeight_eq_occupied h2]
  unfold rowWeightMass
  calc
    |∑ y ∈ Finset.Ioo 0 H, occupiedFixedQLowWeight q a H y|
      ≤ ∑ y ∈ Finset.Ioo 0 H,
          |occupiedFixedQLowWeight q a H y| := by
        exact Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _y ∈ Finset.Ioo 0 H, (6 : ℝ) := by
        apply Finset.sum_le_sum
        intro y hy
        exact abs_occupiedFixedQLowWeight_le_six q a H y h2
    _ = ((Finset.Ioo 0 H).card : ℝ) * 6 := by
        simp
    _ ≤ (H : ℝ) * 6 := by
        gcongr
        simp [Nat.card_Ioo]
    _ = 6 * (H : ℝ) := by ring

theorem abs_sourceForbiddenBooleanNaturalTerm_far_le
    {q a H D m : ℕ}
    (hH : 0 < H)
    (h2 : ¬ 2 ∣ q → 2 ∣ H)
    (hgt : H ^ 2 < m) :
    |sourceForbiddenBooleanNaturalTerm q a H D m| ≤
      6 * (H : ℝ) * (fixedQShiuWeight q m / (m : ℝ)) := by
  by_cases hcond : 1 < m ∧ Squarefree m ∧ m.Coprime (H * (6 * q) * D)
  · rcases hcond with ⟨hm1, hsq, hcop⟩
    have hPrime : ∀ p ∈ m.primeFactors, p.Prime := by
      intro p hp
      exact (Nat.mem_primeFactors.mp hp).1
    have hprod : primeSetProduct m.primeFactors = m :=
      Nat.prod_primeFactors_of_squarefree hsq
    have hdisc :=
      fixedProductBooleanDiscrepancy_eq_neg_density_of_product_gt_sq
        (fixedQLowWeight q a H) hPrime
        (by simpa [hprod] using hgt)
    rw [sourceForbiddenBooleanNaturalTerm, if_pos ⟨hm1, hsq, hcop⟩]
    rw [hdisc, hprod]
    have hw0 : 0 ≤ fixedQShiuWeight q m :=
      fixedQShiuWeight_nonneg q m
    have hmpos : 0 < (m : ℝ) := by
      exact_mod_cast (show 0 < m by omega)
    have hmass := abs_rowWeightMass_fixedQLowWeight_le_six_mul
      (q := q) (a := a) (H := H) h2
    rw [abs_mul, abs_div, abs_of_pos hmpos, abs_neg]
    calc
      |fixedQShiuWeight q m| *
          (|rowWeightMass (fixedQLowWeight q a H) H| / (m : ℝ))
        = fixedQShiuWeight q m *
          (|rowWeightMass (fixedQLowWeight q a H) H| / (m : ℝ)) := by
            rw [abs_of_nonneg hw0]
      _ ≤ fixedQShiuWeight q m *
          ((6 * (H : ℝ)) / (m : ℝ)) := by
            gcongr
      _ = 6 * (H : ℝ) * (fixedQShiuWeight q m / (m : ℝ)) := by
            field_simp
  · rw [sourceForbiddenBooleanNaturalTerm, if_neg hcond]
    have hright : 0 ≤
        6 * (H : ℝ) * (fixedQShiuWeight q m / (m : ℝ)) := by
      exact mul_nonneg
        (mul_nonneg (by norm_num) (Nat.cast_nonneg H))
        (div_nonneg (fixedQShiuWeight_nonneg q m) (Nat.cast_nonneg m))
    simpa using hright

#print axioms abs_rowWeightMass_fixedQLowWeight_le_six_mul
#print axioms abs_sourceForbiddenBooleanNaturalTerm_far_le

end PaperB.FixedQ
