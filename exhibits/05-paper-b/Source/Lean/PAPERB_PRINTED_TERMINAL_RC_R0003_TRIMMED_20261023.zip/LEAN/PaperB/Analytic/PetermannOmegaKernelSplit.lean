import PaperB.Analytic.PetermannCharacterExpansion
import PaperB.Analytic.PetermannOmegaSmoothExpansion
import PaperB.Analytic.PetermannOmegaAwayError

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset

noncomputable def petermannOmegaSmoothedKernel
    (q : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (T : ℝ) (X H : ℕ) (S : ℝ) : ℂ :=
  ∑ e ∈ Finset.Icc 1 X,
    (chi e) * (omegaCoeff q e : ℂ) *
      sawSmoothPartial S H
        ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
          (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
          AddCircle (1 : ℝ))

noncomputable def petermannOmegaSmoothingRemainder
    (q : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (T : ℝ) (X H : ℕ) (S : ℝ) : ℂ :=
  ∑ e ∈ Finset.Icc 1 X,
    (chi e) * (omegaCoeff q e : ℂ) *
      ((petermannSawtooth
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
        sawSmoothPartial S H
          ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
            AddCircle (1 : ℝ)))

theorem petermannBaseKernelSum_omega_eq_smoothed_add_remainder
    (q : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (T : ℝ) (X H : ℕ) (S : ℝ) :
    petermannBaseKernelSum q PetermannBase.omega chi r T X =
      petermannOmegaSmoothedKernel q chi r T X H S +
      petermannOmegaSmoothingRemainder q chi r T X H S := by
  unfold petermannBaseKernelSum
  unfold petermannOmegaSmoothedKernel petermannOmegaSmoothingRemainder
  simp only [petermannBaseCoeff]
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro e he
  ring

#print axioms petermannBaseKernelSum_omega_eq_smoothed_add_remainder

end PaperB.Analytic
