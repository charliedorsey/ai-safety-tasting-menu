import PaperB.Analytic.FixedBetaOrder

namespace PaperB.Analytic

open Real Nat

noncomputable def fixedBetaNaturalOrder (beta : ℝ) : ℕ :=
  ⌊beta⁻¹⌋₊ + 1

lemma fixedBetaNaturalOrder_ge_two
    {beta : ℝ} (hb0 : 0 < beta) (hb1 : beta < 1) :
    2 ≤ fixedBetaNaturalOrder beta := by
  let x : ℝ := beta⁻¹
  let n : ℕ := ⌊x⌋₊
  have hx0 : 0 ≤ x := by
    dsimp [x]
    positivity
  have hx1 : 1 < x := by
    dsimp [x]
    exact (one_lt_inv₀ hb0).2 hb1
  have hn1 : 1 ≤ n := by
    by_contra h
    have hn0 : n = 0 := by omega
    have hxlt : x < (n : ℝ) + 1 := by
      dsimp [n]
      simpa using (Nat.lt_floor_add_one x)
    rw [hn0] at hxlt
    norm_num at hxlt
    linarith
  change 2 ≤ n + 1
  omega

lemma fixedBetaNaturalOrder_inv_lt
    {beta : ℝ} (hb0 : 0 < beta) :
    beta⁻¹ < (fixedBetaNaturalOrder beta : ℝ) := by
  have hx0 : 0 ≤ beta⁻¹ := by positivity
  have h := Nat.lt_floor_add_one (beta⁻¹)
  simpa [fixedBetaNaturalOrder] using h

lemma fixedBetaNaturalOrder_floor_le_inv
    {beta : ℝ} (hb0 : 0 < beta) :
    ((fixedBetaNaturalOrder beta - 1 : ℕ) : ℝ) ≤ beta⁻¹ := by
  have hx0 : 0 ≤ beta⁻¹ := by positivity
  have h := Nat.floor_le hx0
  simpa [fixedBetaNaturalOrder] using h

lemma fixedBetaNaturalOrder_le_cap
    {beta0 beta : ℝ}
    (hb00 : 0 < beta0) (hbb : beta0 ≤ beta) :
    fixedBetaNaturalOrder beta ≤ fixedBetaNaturalOrder beta0 := by
  have hb0 : 0 < beta := lt_of_lt_of_le hb00 hbb
  have hinv : beta⁻¹ ≤ beta0⁻¹ :=
    (inv_le_inv₀ hb0 hb00).2 hbb
  have hfloor := Nat.floor_mono hinv
  simpa [fixedBetaNaturalOrder] using Nat.add_le_add_right hfloor 1

lemma fixedBetaNaturalOrder_gap_gt_one
    {beta : ℝ} (hb0 : 0 < beta) :
    1 < (fixedBetaNaturalOrder beta + 1 : ℕ) - beta⁻¹ := by
  have hlt := fixedBetaNaturalOrder_inv_lt hb0
  norm_num at hlt ⊢
  linarith

lemma fixedBetaNaturalOrder_gap_le_two
    {beta : ℝ} (hb0 : 0 < beta) :
    (fixedBetaNaturalOrder beta + 1 : ℕ) - beta⁻¹ ≤ 2 := by
  have hx0 : 0 ≤ beta⁻¹ := by positivity
  have hfloor : ((⌊beta⁻¹⌋₊ : ℕ) : ℝ) ≤ beta⁻¹ :=
    Nat.floor_le hx0
  change (((⌊beta⁻¹⌋₊ + 1 + 1 : ℕ) : ℝ) - beta⁻¹) ≤ 2
  push_cast
  linarith

lemma fixedBetaNaturalOrder_first_exponent_ceiling
    {beta : ℝ} (hb0 : 0 < beta) (hb1 : beta < 1) :
    fixedBetaFirstExponent beta (fixedBetaNaturalOrder beta)
      ≤ 1 - 1 / ((2 : ℝ) ^ (fixedBetaNaturalOrder beta) - 2) := by
  let k := fixedBetaNaturalOrder beta
  have hk : 2 ≤ k := fixedBetaNaturalOrder_ge_two hb0 hb1
  have hden := fixedBeta_denominator_pos hk
  have hgap := fixedBetaNaturalOrder_gap_gt_one hb0
  rw [fixedBetaFirstExponent]
  have hnum :
      beta⁻¹ - ((fixedBetaNaturalOrder beta + 1 : ℕ) : ℝ) ≤ -1 := by
    linarith
  have hdiv :
      (beta⁻¹ - ((fixedBetaNaturalOrder beta + 1 : ℕ) : ℝ)) /
          ((2 : ℝ) ^ fixedBetaNaturalOrder beta - 2)
        ≤ (-1) / ((2 : ℝ) ^ fixedBetaNaturalOrder beta - 2) :=
    (div_le_div_iff_of_pos_right hden).2 hnum
  norm_num at hdiv
  calc
    1 + (beta⁻¹ - ((fixedBetaNaturalOrder beta : ℝ) + 1)) /
          ((2 : ℝ) ^ fixedBetaNaturalOrder beta - 2)
      ≤ 1 + (-1) / ((2 : ℝ) ^ fixedBetaNaturalOrder beta - 2) := by
        have hs := add_le_add_right hdiv 1
        simpa [add_comm] using hs
    _ = 1 - 1 / ((2 : ℝ) ^ fixedBetaNaturalOrder beta - 2) := by
        simp [one_div]
        ring

lemma fixedBetaNaturalOrder_second_exponent_ceiling_of_three_le
    {beta : ℝ} (hb0 : 0 < beta)
    (hk3 : 3 ≤ fixedBetaNaturalOrder beta) :
    fixedBetaSecondExponent beta (fixedBetaNaturalOrder beta)
      ≤ 1 - 4 / (2 : ℝ) ^ (fixedBetaNaturalOrder beta) +
        2 / ((2 : ℝ) ^ (fixedBetaNaturalOrder beta) - 2) := by
  have hden := fixedBeta_denominator_pos (le_trans (by norm_num) hk3)
  have hgap := fixedBetaNaturalOrder_gap_le_two hb0
  rw [fixedBetaSecondExponent]
  have hnum :
      (fixedBetaNaturalOrder beta : ℝ) + 1 - beta⁻¹ ≤ 2 := by
    simpa [Nat.cast_add, Nat.cast_one] using hgap
  have hdiv :
      ((fixedBetaNaturalOrder beta : ℝ) + 1 - beta⁻¹) /
          ((2 : ℝ) ^ fixedBetaNaturalOrder beta - 2)
        ≤ 2 / ((2 : ℝ) ^ fixedBetaNaturalOrder beta - 2) :=
    (div_le_div_iff_of_pos_right hden).2 hnum
  have hre :
      -(beta⁻¹ - ((fixedBetaNaturalOrder beta : ℝ) + 1)) /
          ((2 : ℝ) ^ fixedBetaNaturalOrder beta - 2)
        ≤ 2 / ((2 : ℝ) ^ fixedBetaNaturalOrder beta - 2) := by
    convert hdiv using 1 <;> ring
  calc
    1 - 4 / (2 : ℝ) ^ fixedBetaNaturalOrder beta -
        (beta⁻¹ - ((fixedBetaNaturalOrder beta : ℝ) + 1)) /
          ((2 : ℝ) ^ fixedBetaNaturalOrder beta - 2)
      =
    (1 - 4 / (2 : ℝ) ^ fixedBetaNaturalOrder beta) +
      (-(beta⁻¹ - ((fixedBetaNaturalOrder beta : ℝ) + 1)) /
        ((2 : ℝ) ^ fixedBetaNaturalOrder beta - 2)) := by ring
    _ ≤ (1 - 4 / (2 : ℝ) ^ fixedBetaNaturalOrder beta) +
        2 / ((2 : ℝ) ^ fixedBetaNaturalOrder beta - 2) := by
      have hs := add_le_add_right hre
        (1 - 4 / (2 : ℝ) ^ fixedBetaNaturalOrder beta)
      simpa [add_comm] using hs
    _ = 1 - 4 / (2 : ℝ) ^ fixedBetaNaturalOrder beta +
        2 / ((2 : ℝ) ^ fixedBetaNaturalOrder beta - 2) := by ring

lemma fixedBetaNaturalOrder_second_exponent_ceiling_k2
    {beta : ℝ} (hb0 : 0 < beta) (hb34 : beta ≤ 3 / 4) 
    (hk2 : fixedBetaNaturalOrder beta = 2) :
    fixedBetaSecondExponent beta (fixedBetaNaturalOrder beta) ≤ 5 / 6 := by
  have hb34pos : (0 : ℝ) < 3 / 4 := by norm_num
  have hinv : (4 / 3 : ℝ) ≤ beta⁻¹ := by
    have h := (inv_le_inv₀ hb34pos hb0).2 hb34
    norm_num at h ⊢
    exact h
  rw [hk2, fixedBetaSecondExponent]
  norm_num
  linarith

lemma fixedBeta_second_gap_of_three_le
    {k : ℕ} (hk3 : 3 ≤ k) :
    1 / (2 : ℝ)^k ≤
      4 / (2 : ℝ)^k - 2 / ((2 : ℝ)^k - 2) := by
  have hpow8 : (8 : ℝ) ≤ (2 : ℝ)^k := by
    have hmono := pow_le_pow_right₀ (a := (2 : ℝ)) (by norm_num) hk3
    norm_num at hmono ⊢
    exact hmono
  have hp : 0 < (2 : ℝ)^k := by positivity
  have hpm2 : 0 < (2 : ℝ)^k - 2 := by linarith
  have hfrac :
      2 / ((2 : ℝ)^k - 2) ≤ 3 / (2 : ℝ)^k := by
    rw [div_le_div_iff₀ hpm2 hp]
    nlinarith
  calc
    1 / (2 : ℝ)^k
      ≤ 1 / (2 : ℝ)^k := le_rfl
    _ ≤ 4 / (2 : ℝ)^k - 2 / ((2 : ℝ)^k - 2) := by
      have hadd := add_le_add_left hfrac (1 / (2 : ℝ)^k)
      have hid : 3 / (2 : ℝ)^k + 1 / (2 : ℝ)^k =
          4 / (2 : ℝ)^k := by ring
      rw [hid] at hadd
      linarith

#print axioms fixedBetaNaturalOrder_ge_two
#print axioms fixedBetaNaturalOrder_le_cap
#print axioms fixedBetaNaturalOrder_first_exponent_ceiling
#print axioms fixedBetaNaturalOrder_second_exponent_ceiling_of_three_le
#print axioms fixedBetaNaturalOrder_second_exponent_ceiling_k2
#print axioms fixedBeta_second_gap_of_three_le

end PaperB.Analytic


namespace PaperB.Analytic

open Real Nat

noncomputable def fixedBetaUniformExponent (K : ℕ) : ℝ :=
  1 - 1 / (3 * (2 : ℝ)^K)

lemma fixedBetaUniformExponent_lt_one (K : ℕ) :
    fixedBetaUniformExponent K < 1 := by
  unfold fixedBetaUniformExponent
  have hp : 0 < (3 : ℝ) * (2 : ℝ)^K := by positivity
  have hi : 0 < 1 / ((3 : ℝ) * (2 : ℝ)^K) := one_div_pos.mpr hp
  linarith

lemma pow_two_mono_nat {k K : ℕ} (hkK : k ≤ K) :
    (2 : ℝ)^k ≤ (2 : ℝ)^K := by
  exact pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) hkK

lemma fixedBeta_first_exponent_le_uniform
    {beta0 beta : ℝ}
    (hb00 : 0 < beta0) (hb01 : beta0 < 1)
    (hbb : beta0 ≤ beta) (hb1 : beta < 1) :
    fixedBetaFirstExponent beta (fixedBetaNaturalOrder beta)
      ≤ fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) := by
  let k := fixedBetaNaturalOrder beta
  let K := fixedBetaNaturalOrder beta0
  have hk : 2 ≤ k := fixedBetaNaturalOrder_ge_two
    (lt_of_lt_of_le hb00 hbb) hb1
  have hkK : k ≤ K := fixedBetaNaturalOrder_le_cap hb00 hbb
  have hceil := fixedBetaNaturalOrder_first_exponent_ceiling
    (lt_of_lt_of_le hb00 hbb) hb1
  have hden : 0 < (2 : ℝ)^k - 2 := fixedBeta_denominator_pos hk
  have hpow : (2 : ℝ)^k ≤ (2 : ℝ)^K := pow_two_mono_nat hkK
  have hdenLe : (2 : ℝ)^k - 2 ≤ 3 * (2 : ℝ)^K := by
    have hKpos : 0 ≤ (2 : ℝ)^K := by positivity
    linarith
  have hinv :
      1 / (3 * (2 : ℝ)^K) ≤ 1 / ((2 : ℝ)^k - 2) :=
    one_div_le_one_div_of_le hden hdenLe
  have hinv' :
      1 / (3 * (2 : ℝ) ^ fixedBetaNaturalOrder beta0) ≤
        1 / ((2 : ℝ) ^ fixedBetaNaturalOrder beta - 2) := by
    simpa [k, K] using hinv
  unfold fixedBetaUniformExponent
  linarith

lemma fixedBeta_second_exponent_le_uniform
    {beta0 beta : ℝ}
    (hb00 : 0 < beta0) (hb01 : beta0 < 1)
    (hbb : beta0 ≤ beta) (hb34 : beta ≤ 3 / 4) :
    fixedBetaSecondExponent beta (fixedBetaNaturalOrder beta)
      ≤ fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) := by
  let k := fixedBetaNaturalOrder beta
  let K := fixedBetaNaturalOrder beta0
  have hb0 : 0 < beta := lt_of_lt_of_le hb00 hbb
  have hb1 : beta < 1 := lt_of_le_of_lt hb34 (by norm_num)
  have hk : 2 ≤ k := fixedBetaNaturalOrder_ge_two hb0 hb1
  have hkK : k ≤ K := fixedBetaNaturalOrder_le_cap hb00 hbb
  have hpow : (2 : ℝ)^k ≤ (2 : ℝ)^K := pow_two_mono_nat hkK
  have hsmall :
      1 / (3 * (2 : ℝ)^K) ≤ 1 / (2 : ℝ)^k := by
    have hkpowpos : 0 < (2 : ℝ)^k := by positivity
    have hdenLe : (2 : ℝ)^k ≤ 3 * (2 : ℝ)^K := by
      have hK0 : 0 ≤ (2 : ℝ)^K := by positivity
      linarith
    exact one_div_le_one_div_of_le hkpowpos hdenLe
  by_cases hk2 : k = 2
  · have hceil := fixedBetaNaturalOrder_second_exponent_ceiling_k2
      hb0 hb34 (by simpa [k] using hk2)
    have hK2 : 2 ≤ K := hk2 ▸ hkK
    have hpowK : (4 : ℝ) ≤ (2 : ℝ)^K := by
      have hm := pow_le_pow_right₀ (a := (2 : ℝ)) (by norm_num) hK2
      norm_num at hm ⊢
      exact hm
    have hfrac : 1 / (3 * (2 : ℝ)^K) ≤ 1 / 12 := by
      have h12 : (12 : ℝ) ≤ 3 * (2 : ℝ)^K := by nlinarith
      exact one_div_le_one_div_of_le (by norm_num) h12
    have hfrac' :
        1 / (3 * (2 : ℝ) ^ fixedBetaNaturalOrder beta0) ≤ 1 / 12 := by
      simpa [K] using hfrac
    unfold fixedBetaUniformExponent
    norm_num at hceil
    linarith
  · have hk3 : 3 ≤ k := by omega
    have hceil := fixedBetaNaturalOrder_second_exponent_ceiling_of_three_le
      hb0 (by simpa [k] using hk3)
    have hgap := fixedBeta_second_gap_of_three_le hk3
    have hto :
        1 - 4 / (2 : ℝ)^k + 2 / ((2 : ℝ)^k - 2)
          ≤ 1 - 1 / (2 : ℝ)^k := by
      linarith
    have hmain :
        fixedBetaSecondExponent beta (fixedBetaNaturalOrder beta)
          ≤ 1 - 1 / (2 : ℝ)^k := by
      exact hceil.trans (by simpa [k] using hto)
    have hsmall' :
        1 / (3 * (2 : ℝ)^fixedBetaNaturalOrder beta0) ≤
          1 / (2 : ℝ)^k := by
      simpa [K] using hsmall
    unfold fixedBetaUniformExponent
    exact hmain.trans (by linarith)

theorem fixedBetaNaturalOrder_uniform_exponents
    {beta0 beta : ℝ}
    (hb00 : 0 < beta0) (hb01 : beta0 < 1)
    (hbb : beta0 ≤ beta) (hb34 : beta ≤ 3 / 4) :
    let K := fixedBetaNaturalOrder beta0
    let k := fixedBetaNaturalOrder beta
    2 ≤ k ∧ k ≤ K ∧
      fixedBetaFirstExponent beta k ≤ fixedBetaUniformExponent K ∧
      fixedBetaSecondExponent beta k ≤ fixedBetaUniformExponent K ∧
      fixedBetaUniformExponent K < 1 := by
  dsimp
  have hb0 : 0 < beta := lt_of_lt_of_le hb00 hbb
  have hb1 : beta < 1 := lt_of_le_of_lt hb34 (by norm_num)
  exact ⟨fixedBetaNaturalOrder_ge_two hb0 hb1,
    fixedBetaNaturalOrder_le_cap hb00 hbb,
    fixedBeta_first_exponent_le_uniform hb00 hb01 hbb hb1,
    fixedBeta_second_exponent_le_uniform hb00 hb01 hbb hb34,
    fixedBetaUniformExponent_lt_one _⟩

#print axioms fixedBetaNaturalOrder_uniform_exponents

end PaperB.Analytic
