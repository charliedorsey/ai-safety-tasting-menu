import PaperB.FixedQ.EtaLinearMean
import PaperB.FixedQ.CharacterHarmonicLedger

open scoped BigOperators

namespace PaperB.FixedQ

theorem coprime_six_mul_iff_lcm
    (q m : ℕ) :
    m.Coprime (6 * q) ↔ m.Coprime (Nat.lcm 6 q) := by
  constructor
  · intro h
    exact Nat.Coprime.of_dvd_right (Nat.lcm_dvd_mul 6 q) h
  · intro h
    have h6 : m.Coprime 6 :=
      Nat.Coprime.of_dvd_right (Nat.dvd_lcm_left 6 q) h
    have hq : m.Coprime q :=
      Nat.Coprime.of_dvd_right (Nat.dvd_lcm_right 6 q) h
    exact Nat.coprime_mul_iff_right.mpr ⟨h6, hq⟩

theorem dirichletCharacter_mul_coprimeIndicator
    (q m : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (hm0 : m ≠ 0) :
    (chi m) * (coprimeIndicatorArithmetic q m : ℂ) = chi m := by
  rw [coprimeIndicatorArithmetic_apply]
  rw [coprimeIndicatorCoeff, if_neg hm0]
  by_cases hcop : m.Coprime (6 * q)
  · rw [if_pos hcop]
    simp
  · rw [if_neg hcop]
    have hnot : ¬ m.Coprime (Nat.lcm 6 q) := by
      intro h
      exact hcop ((coprime_six_mul_iff_lcm q m).mpr h)
    have hchi : chi m = 0 := by
      rw [MulChar.apply_eq_zero_iff, ZMod.isUnit_iff_coprime]
      exact hnot
    simp [hchi]

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def characterHarmonicIcc
    {L : ℕ} (chi : DirichletCharacter ℂ L) (X : ℕ) : ℂ :=
  ∑ m ∈ Finset.Icc 1 X,
    (chi m) * ((((m : ℕ) : ℝ)⁻¹ : ℝ) : ℂ)

theorem characterHarmonicIcc_eq_shifted
    {L : ℕ} (chi : DirichletCharacter ℂ L) (X : ℕ) :
    characterHarmonicIcc chi X =
      ∑ j ∈ Finset.range X,
        chi (j + 1) * reciprocalNatWeight 1 j := by
  unfold characterHarmonicIcc
  refine Finset.sum_bij
    (fun m hm => m - 1)
    ?_ ?_ ?_ ?_
  · intro m hm
    rw [Finset.mem_Icc] at hm
    rw [Finset.mem_range]
    omega
  · intro m1 hm1 m2 hm2 h
    rw [Finset.mem_Icc] at hm1 hm2
    omega
  · intro j hj
    rw [Finset.mem_range] at hj
    refine ⟨j + 1, ?_, ?_⟩
    · rw [Finset.mem_Icc]
      omega
    · omega
  · intro m hm
    rw [Finset.mem_Icc] at hm
    have hpos : 1 ≤ m := hm.1
    have hnat : m - 1 + 1 = m := Nat.sub_add_cancel hpos
    have hnat' : 1 + (m - 1) = m := by omega
    have hcast0 :=
      congrArg (fun n : ℕ => (n : ZMod L)) hnat
    have hcast :
        ((m - 1 : ℕ) : ZMod L) + 1 = (m : ZMod L) := by
      simpa [Nat.cast_add, Nat.cast_one] using hcast0
    unfold reciprocalNatWeight
    rw [hcast, hnat']


theorem norm_characterHarmonicIcc_le
    {L : ℕ} (hL : 0 < L)
    (chi : DirichletCharacter ℂ L)
    (hchi : chi ≠ 1)
    (X : ℕ) :
    ‖characterHarmonicIcc chi X‖ ≤ 2 * (L + 1) := by
  rw [characterHarmonicIcc_eq_shifted]
  exact norm_shifted_character_harmonic_sum_le hL chi hchi X

#print axioms norm_characterHarmonicIcc_le

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def etaCharacterPartialSum
    (q X : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q)) : ℂ :=
  ∑ n ∈ Finset.Icc 1 X, (chi n) * (etaCoeff q n : ℂ)

theorem characterEtaPartialSum_eq_correction_harmonic
    (q X : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q)) :
    etaCharacterPartialSum q X chi =
      ∑ d ∈ Finset.Icc 1 X,
        (chi d) * (etaCorrectionInvTerm q d : ℂ) *
          characterHarmonicIcc chi (X / d) := by
  classical
  unfold etaCharacterPartialSum
  calc
    (∑ n ∈ Finset.Icc 1 X, (chi n) * (etaCoeff q n : ℂ))
      = ∑ n ∈ Finset.Icc 1 X,
          ∑ ds ∈ n.divisorsAntidiagonal,
            (chi n) *
              ((etaCorrectionInvTerm q ds.2 : ℂ) *
                ((coprimeIndicatorArithmetic q ds.1 : ℝ) : ℂ) /
                  (ds.1 : ℂ)) := by
          apply Finset.sum_congr rfl
          intro n hn
          have hn0 : n ≠ 0 := by
            rw [Finset.mem_Icc] at hn
            omega
          rw [etaCoeff_eq_correction_divisor_sum q n hn0]
          push_cast
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro ds hds
          ring
    _ = ∑ n ∈ Finset.Icc 1 X,
          ∑ ds ∈ n.divisorsAntidiagonal,
            (chi ds.2) * (etaCorrectionInvTerm q ds.2 : ℂ) *
              ((chi ds.1) *
                ((coprimeIndicatorArithmetic q ds.1 : ℝ) : ℂ) /
                  (ds.1 : ℂ)) := by
          apply Finset.sum_congr rfl
          intro n hn
          apply Finset.sum_congr rfl
          intro ds hds
          have hprod : ds.1 * ds.2 = n :=
            (Nat.mem_divisorsAntidiagonal.mp hds).1
          have hcast0 :=
            congrArg (fun t : ℕ => (t : ZMod (Nat.lcm 6 q))) hprod
          have hcast :
              (ds.1 : ZMod (Nat.lcm 6 q)) *
                  (ds.2 : ZMod (Nat.lcm 6 q)) =
                (n : ZMod (Nat.lcm 6 q)) := by
            simpa [Nat.cast_mul] using hcast0
          rw [← hcast, map_mul]
          ring
    _ = ∑ x ∈ petermannDivisorSigma X,
          (chi x.2.2) * (etaCorrectionInvTerm q x.2.2 : ℂ) *
            ((chi x.2.1) *
              ((coprimeIndicatorArithmetic q x.2.1 : ℝ) : ℂ) /
                (x.2.1 : ℂ)) := by
          rw [petermannDivisorSigma, Finset.sum_sigma']
    _ = ∑ d ∈ Finset.Icc 1 X,
          ∑ m ∈ Finset.Icc 1 (X / d),
            (chi d) * (etaCorrectionInvTerm q d : ℂ) *
              ((chi m) *
                ((coprimeIndicatorArithmetic q m : ℝ) : ℂ) /
                  (m : ℂ)) := by
          exact sum_petermannDivisorSigma_eq_nested X
            (fun d m =>
              (chi d) * (etaCorrectionInvTerm q d : ℂ) *
                ((chi m) *
                  ((coprimeIndicatorArithmetic q m : ℝ) : ℂ) /
                    (m : ℂ)))
    _ = ∑ d ∈ Finset.Icc 1 X,
        (chi d) * (etaCorrectionInvTerm q d : ℂ) *
          characterHarmonicIcc chi (X / d) := by
          apply Finset.sum_congr rfl
          intro d hd
          rw [← Finset.mul_sum]
          congr 1
          unfold characterHarmonicIcc
          apply Finset.sum_congr rfl
          intro m hm
          have hm0 : m ≠ 0 := by
            rw [Finset.mem_Icc] at hm
            omega
          rw [dirichletCharacter_mul_coprimeIndicator q m chi hm0]
          have hmR : (m : ℂ) ≠ 0 := by
            exact_mod_cast hm0
          simp [div_eq_mul_inv, hmR, Complex.ofReal_inv, mul_assoc]

#print axioms characterEtaPartialSum_eq_correction_harmonic

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem norm_etaCharacterPartialSum_le
    (q X : ℕ) (hq : 0 < q)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (hchi : chi ≠ 1) :
    ‖etaCharacterPartialSum q X chi‖ ≤
      2 * ((Nat.lcm 6 q : ℕ) + 1) * etaRankinBound := by
  rw [characterEtaPartialSum_eq_correction_harmonic]
  let L := Nat.lcm 6 q
  have hL : 0 < L := Nat.lcm_pos (by norm_num) hq
  have hR0 : 0 ≤ etaRankinBound := by
    unfold etaRankinBound
    positivity
  calc
    ‖∑ d ∈ Finset.Icc 1 X,
        (chi d) * (etaCorrectionInvTerm q d : ℂ) *
          characterHarmonicIcc chi (X / d)‖
      ≤ ∑ d ∈ Finset.Icc 1 X,
          ‖(chi d) * (etaCorrectionInvTerm q d : ℂ) *
            characterHarmonicIcc chi (X / d)‖ := by
            exact norm_sum_le _ _
    _ ≤ ∑ d ∈ Finset.Icc 1 X,
          |etaCorrectionInvTerm q d| * (2 * (L + 1)) := by
            apply Finset.sum_le_sum
            intro d hd
            have hchi1 := chi.norm_le_one (d : ZMod L)
            have hharm :=
              norm_characterHarmonicIcc_le hL chi hchi (X / d)
            rw [norm_mul, norm_mul, Complex.norm_real]
            have hInv0 : 0 ≤ |etaCorrectionInvTerm q d| := abs_nonneg _
            have hH0 : 0 ≤ ‖characterHarmonicIcc chi (X / d)‖ :=
              norm_nonneg _
            calc
              ‖chi (d : ZMod L)‖ * |etaCorrectionInvTerm q d| *
                  ‖characterHarmonicIcc chi (X / d)‖
                  ≤ |etaCorrectionInvTerm q d| *
                      ‖characterHarmonicIcc chi (X / d)‖ := by
                    apply mul_le_mul_of_nonneg_right _ hH0
                    simpa using
                      mul_le_mul_of_nonneg_right hchi1 hInv0
              _ ≤ |etaCorrectionInvTerm q d| * (2 * (L + 1)) :=
                    mul_le_mul_of_nonneg_left hharm hInv0
    _ = (2 * (L + 1)) *
          ∑ d ∈ Finset.Icc 1 X, |etaCorrectionInvTerm q d| := by
            rw [Finset.mul_sum]
            apply Finset.sum_congr rfl
            intro d hd
            ring
    _ ≤ (2 * (L + 1)) * etaRankinBound := by
            apply mul_le_mul_of_nonneg_left _ (by positivity)
            calc
              (∑ d ∈ Finset.Icc 1 X, |etaCorrectionInvTerm q d|)
                  ≤ ∑' d : ℕ, |etaCorrectionInvTerm q d| := by
                    exact (summable_etaCorrectionInvTerm q).abs.sum_le_tsum
                      (Finset.Icc 1 X) (fun d hd => abs_nonneg _)
              _ ≤ etaRankinBound :=
                    tsum_abs_etaCorrectionInvTerm_le_bound q
    _ = 2 * ((Nat.lcm 6 q : ℕ) + 1) * etaRankinBound := by
            rfl

#print axioms norm_etaCharacterPartialSum_le

end PaperB.FixedQ
