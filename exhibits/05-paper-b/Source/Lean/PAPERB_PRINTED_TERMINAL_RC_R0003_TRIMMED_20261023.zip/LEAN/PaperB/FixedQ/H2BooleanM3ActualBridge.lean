import PaperB.FixedQ.H2BooleanCompleteUnitBridge
import PaperB.FixedQ.H2BooleanM3Grouping

open scoped BigOperators

namespace PaperB.FixedQ

theorem h2_weightedCompleteUnitFourierSecondMoment_eq_m3
    {q : ℕ} {S : Finset ℕ}
    (hA : ∀ p ∈ S, activeHighPrime q p)
    [NeZero (primeSetProduct S)]
    (j : ℤ) :
    finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
      (((Fintype.card (ZMod (primeSetProduct S))ˣ : ℝ)⁻¹) *
        (∑ u : (ZMod (primeSetProduct S))ˣ,
          ‖fixedProductBooleanFourierCoeff S
            (fun p hp => (hA p hp).1)
            ((j : ZMod (primeSetProduct S)) *
              (u : ZMod (primeSetProduct S)))‖ ^ 2)) =
      ∏ p ∈ S, h2BooleanM3LocalWeight q p j := by
  rw [h2_completeUnitFourierSecondMoment
    S (fun p hp => (hA p hp).1) j]
  exact (h2BooleanM3LocalWeight_prod_eq j hA).symm

theorem h2_weightedCompleteUnitFourierSecondMoment_eq_resonance_product
    {q : ℕ} {S : Finset ℕ}
    (hA : ∀ p ∈ S, activeHighPrime q p)
    [NeZero (primeSetProduct S)]
    (j : ℤ) :
    finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
      (((Fintype.card (ZMod (primeSetProduct S))ˣ : ℝ)⁻¹) *
        (∑ u : (ZMod (primeSetProduct S))ˣ,
          ‖fixedProductBooleanFourierCoeff S
            (fun p hp => (hA p hp).1)
            ((j : ZMod (primeSetProduct S)) *
              (u : ZMod (primeSetProduct S)))‖ ^ 2)) =
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
        (∏ p ∈ (S.filter (fun p : ℕ => ¬ ((p : ℤ) ∣ j))),
          (((p : ℝ) - 2) / (2 * ((p : ℝ) - 1)))) := by
  rw [h2_completeUnitFourierSecondMoment
    S (fun p hp => (hA p hp).1) j]
  rw [h2Boolean_completeUnitSecondMoment_real j
    (fun p hp => (hA p hp).1)
    (fun p hp => (hA p hp).2.1)]

#print axioms h2_weightedCompleteUnitFourierSecondMoment_eq_m3
#print axioms h2_weightedCompleteUnitFourierSecondMoment_eq_resonance_product

end PaperB.FixedQ
