import PaperB.FixedQ.H2BooleanShiuLift

namespace PaperB.FixedQ

noncomputable def h2BooleanTheta : ℝ := 99 / 100

noncomputable def h2BooleanSigma : ℝ := 2 / 3 + 1 / 100

lemma h2BooleanA0_eq_one_sub_theta_half :
    h2BooleanA0 = 1 - h2BooleanTheta / 2 := by
  norm_num [h2BooleanA0, h2BooleanTheta]

lemma h2BooleanV0_mul_A0 :
    h2BooleanV0 * h2BooleanA0 = h2BooleanX0 := by
  have ha0 : 0 < h2BooleanA0 := h2BooleanA0_pos
  have hspos : 0 < Real.sqrt h2BooleanA0 :=
    Real.sqrt_pos.2 ha0
  have hs2 : (Real.sqrt h2BooleanA0) ^ 2 = h2BooleanA0 := by
    rw [Real.sq_sqrt]
    exact ha0.le
  unfold h2BooleanV0 h2BooleanX0
  field_simp [hspos.ne']
  nlinarith

lemma h2Boolean_exponent_split :
    h2BooleanV0 * (1 - h2BooleanTheta) - 1 +
        h2BooleanV0 * (h2BooleanTheta / 2) =
      h2BooleanV0 * h2BooleanA0 - 1 := by
  rw [h2BooleanA0_eq_one_sub_theta_half]
  ring

lemma h2BooleanL2Exponent_eq_firstExponent :
    h2BooleanV0 * h2BooleanA0 - 1 =
      h2BooleanX0 - 1 := by
  rw [h2BooleanV0_mul_A0]

lemma h2BooleanSigma_eq :
    h2BooleanSigma = (203 / 300 : ℝ) := by
  norm_num [h2BooleanSigma]

lemma h2BooleanSigma_pos :
    0 < h2BooleanSigma := by
  rw [h2BooleanSigma_eq]
  norm_num

lemma h2BooleanX0_pos :
    0 < h2BooleanX0 := by
  unfold h2BooleanX0
  exact mul_pos (by norm_num) (Real.sqrt_pos.2 h2BooleanA0_pos)

lemma h2BooleanSigma_mul_X0_lt_one :
    h2BooleanSigma * h2BooleanX0 < 1 := by
  rw [h2BooleanSigma_eq]
  unfold h2BooleanX0
  have ha0 : 0 < h2BooleanA0 := h2BooleanA0_pos
  have hs0 : 0 ≤ Real.sqrt h2BooleanA0 := Real.sqrt_nonneg _
  have hs2 : (Real.sqrt h2BooleanA0) ^ 2 = h2BooleanA0 := by
    rw [Real.sq_sqrt]
    exact ha0.le
  have ha0val : h2BooleanA0 = (101 / 200 : ℝ) := rfl
  have hsq :
      (((203 / 150 : ℝ) * Real.sqrt h2BooleanA0)^2) < 1 := by
    rw [mul_pow, hs2, ha0val]
    norm_num
  have hnon :
      0 ≤ (203 / 150 : ℝ) * Real.sqrt h2BooleanA0 := by
    exact mul_nonneg (by norm_num) hs0
  have hlt :
      (203 / 150 : ℝ) * Real.sqrt h2BooleanA0 < 1 := by
    nlinarith
  convert hlt using 1 <;> ring

#print axioms h2BooleanV0_mul_A0
#print axioms h2BooleanSigma_mul_X0_lt_one

end PaperB.FixedQ
