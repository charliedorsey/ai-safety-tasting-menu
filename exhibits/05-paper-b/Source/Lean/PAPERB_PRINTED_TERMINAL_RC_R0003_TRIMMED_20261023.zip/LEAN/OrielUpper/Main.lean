import OrielUpper.AsympB

/-!
# Oriel Upper — the Gate 3 Upper sublog theorem

`OrielUpper.Mirror.virelleR0061CompleteRegionSublog Z OrielUpper.Mirror.virelleR0037Upper`
for EVERY cutoff function `Z : ℕ → ℕ`, in particular for Paper B's
`globalProperBooleanProductCutoff`.

Route: exact reduction of every decoration slice to a product window
(`slice_eq_pairWin`), dyadic shells with a three-sector split
(fixed-variable κ+BV estimates for small `r` or small `s`, trivial bound when both
are large), a far tail via the second moment of `∑_{r ∣ n} g(r)`, and the
decoration mass `∏ (1 + 1/(p-2))`.  The total is `O_q(θ^47)` with
`θ = (log h + 2)^{1/64}`, i.e. `O_q((log h)^{47/64}) = o(log h)`.
-/

open Finset
open OrielUpper.Mirror

namespace OrielUpper

lemma mul_le_mul4 {a b A B : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) (hA : a ≤ A) (hB : b ≤ B) :
    a * b ≤ A * B := mul_le_mul hA hB hb (le_trans ha hA)

/-- Pure arithmetic core of the final bound. -/
lemma total_arith {Pr e c34 Cτ kv θ E1 t J SH FAR V : ℝ}
    (hPr : 0 ≤ Pr) (he0 : 0 ≤ e) (hc34 : 0 ≤ c34) (hCτ : 0 ≤ Cτ) (hkv : 0 ≤ kv)
    (hθ : 1 ≤ θ) (hE1 : 1 ≤ E1) (hE1e : E1 ≤ e * θ ^ 4) (ht0 : 0 ≤ t) (ht : t ≤ θ ^ 16)
    (hJ0 : 0 ≤ J) (hJ : J ≤ 6405 * θ ^ 16) (hSH0 : 0 ≤ SH)
    (hSH : SH ≤ 2 * ((2 * Pr + 1) * 12 * E1 * (Cτ + 2 * E1) +
        c34 * E1 * (6 * Pr * (4 * Pr + 13) + (2 * Pr + 2) * 12)) +
      (4 * Pr + 3) * 12 * E1 * E1 * (8 + 41 * t))
    (hFAR : FAR ≤ 3 * Real.exp (225 / 4) * 2 ^ 45 + 27 * E1 ^ 2) (hFAR0 : 0 ≤ FAR)
    (hV0 : 0 ≤ V) (hV : V ≤ kv * θ ^ 7) :
    V * (J * SH + FAR) ≤
      kv * (6405 * (2 * ((2 * Pr + 1) * 12 * (Cτ + 2) * e ^ 2 +
          c34 * (6 * Pr * (4 * Pr + 13) + (2 * Pr + 2) * 12) * e) +
        (4 * Pr + 3) * 12 * 49 * e ^ 2) +
        (3 * Real.exp (225 / 4) * 2 ^ 45 + 27 * e ^ 2)) * θ ^ 47 := by
  set K1 : ℝ := 6 * Pr * (4 * Pr + 13) + (2 * Pr + 2) * 12 with hK1def
  have hK1 : 0 ≤ K1 := by rw [hK1def]; positivity
  set S : ℝ := 2 * ((2 * Pr + 1) * 12 * (Cτ + 2) * e ^ 2 + c34 * K1 * e) +
    (4 * Pr + 3) * 12 * 49 * e ^ 2 with hSdef
  set Fc : ℝ := 3 * Real.exp (225 / 4) * 2 ^ 45 + 27 * e ^ 2 with hFcdef
  have hθ0 : 0 ≤ θ := by linarith
  have hθ4 : (1 : ℝ) ≤ θ ^ 4 := one_le_pow₀ hθ
  have hθ8 : θ ^ 8 ≤ θ ^ 24 := pow_le_pow_right₀ hθ (by norm_num)
  have hθ4' : θ ^ 4 ≤ θ ^ 24 := pow_le_pow_right₀ hθ (by norm_num)
  have hE1sq : E1 ^ 2 ≤ e ^ 2 * θ ^ 8 := by
    have := pow_le_pow_left₀ (by linarith) hE1e 2
    calc E1 ^ 2 ≤ (e * θ ^ 4) ^ 2 := this
      _ = e ^ 2 * θ ^ 8 := by ring
  have hshell : SH ≤ S * θ ^ 24 := by
    refine hSH.trans ?_
    have hA : (2 * Pr + 1) * 12 * E1 * (Cτ + 2 * E1) ≤ (2 * Pr + 1) * 12 * (Cτ + 2) * e ^ 2 * θ ^ 24 := by
      have hEE : E1 ≤ E1 ^ 2 := by nlinarith
      have h1 : E1 * (Cτ + 2 * E1) ≤ (Cτ + 2) * E1 ^ 2 := by
        nlinarith [mul_le_mul_of_nonneg_left hEE hCτ]
      have h2 : (Cτ + 2) * E1 ^ 2 ≤ (Cτ + 2) * (e ^ 2 * θ ^ 24) := by
        apply mul_le_mul_of_nonneg_left _ (by linarith)
        exact hE1sq.trans (mul_le_mul_of_nonneg_left hθ8 (sq_nonneg e))
      have hc : 0 ≤ (2 * Pr + 1) * 12 := by positivity
      calc (2 * Pr + 1) * 12 * E1 * (Cτ + 2 * E1) = (2 * Pr + 1) * 12 * (E1 * (Cτ + 2 * E1)) := by ring
        _ ≤ (2 * Pr + 1) * 12 * ((Cτ + 2) * (e ^ 2 * θ ^ 24)) :=
            mul_le_mul_of_nonneg_left (h1.trans h2) hc
        _ = _ := by ring
    have hB : c34 * E1 * K1 ≤ c34 * K1 * e * θ ^ 24 := by
      have : E1 ≤ e * θ ^ 24 := hE1e.trans (mul_le_mul_of_nonneg_left hθ4' he0)
      have hc : 0 ≤ c34 * K1 := mul_nonneg hc34 hK1
      calc c34 * E1 * K1 = (c34 * K1) * E1 := by ring
        _ ≤ (c34 * K1) * (e * θ ^ 24) := mul_le_mul_of_nonneg_left this hc
        _ = _ := by ring
    have hC : (4 * Pr + 3) * 12 * E1 * E1 * (8 + 41 * t) ≤ (4 * Pr + 3) * 12 * 49 * e ^ 2 * θ ^ 24 := by
      have h16 : 8 + 41 * t ≤ 49 * θ ^ 16 := by
        have : (1 : ℝ) ≤ θ ^ 16 := one_le_pow₀ hθ
        linarith
      have h1 : E1 * E1 * (8 + 41 * t) ≤ (e ^ 2 * θ ^ 8) * (49 * θ ^ 16) := by
        rw [← pow_two]
        exact mul_le_mul4 (sq_nonneg _) (by linarith) hE1sq h16
      have hc : 0 ≤ (4 * Pr + 3) * 12 := by positivity
      calc (4 * Pr + 3) * 12 * E1 * E1 * (8 + 41 * t) = (4 * Pr + 3) * 12 * (E1 * E1 * (8 + 41 * t)) := by
            ring
        _ ≤ (4 * Pr + 3) * 12 * ((e ^ 2 * θ ^ 8) * (49 * θ ^ 16)) := mul_le_mul_of_nonneg_left h1 hc
        _ = _ := by ring
    rw [hSdef]
    have e2 : 2 * ((2 * Pr + 1) * 12 * (Cτ + 2) * e ^ 2 + c34 * K1 * e) * θ ^ 24 =
        2 * ((2 * Pr + 1) * 12 * (Cτ + 2) * e ^ 2 * θ ^ 24 + c34 * K1 * e * θ ^ 24) := by ring
    have e3 : (2 * ((2 * Pr + 1) * 12 * (Cτ + 2) * e ^ 2 + c34 * K1 * e) +
        (4 * Pr + 3) * 12 * 49 * e ^ 2) * θ ^ 24 =
        2 * ((2 * Pr + 1) * 12 * (Cτ + 2) * e ^ 2 * θ ^ 24 + c34 * K1 * e * θ ^ 24) +
        (4 * Pr + 3) * 12 * 49 * e ^ 2 * θ ^ 24 := by ring
    rw [e3]
    linarith
  have hFc : FAR ≤ Fc * θ ^ 8 := by
    rw [hFcdef]
    have h8 : (1 : ℝ) ≤ θ ^ 8 := one_le_pow₀ hθ
    have hc : 0 ≤ 3 * Real.exp (225 / 4) * 2 ^ 45 := by positivity
    have h1 : 3 * Real.exp (225 / 4) * 2 ^ 45 ≤ 3 * Real.exp (225 / 4) * 2 ^ 45 * θ ^ 8 := by
      nlinarith
    have h2 : 27 * E1 ^ 2 ≤ 27 * (e ^ 2 * θ ^ 8) := by linarith
    nlinarith
  have hFc0 : 0 ≤ Fc := by rw [hFcdef]; positivity
  have hW : J * SH + FAR ≤ (6405 * S + Fc) * θ ^ 40 := by
    have h1 : J * SH ≤ (6405 * θ ^ 16) * (S * θ ^ 24) := mul_le_mul4 hJ0 hSH0 hJ hshell
    have h2 : θ ^ 8 ≤ θ ^ 40 := pow_le_pow_right₀ hθ (by norm_num)
    have h3 : Fc * θ ^ 8 ≤ Fc * θ ^ 40 := mul_le_mul_of_nonneg_left h2 hFc0
    have e1 : (6405 * θ ^ 16) * (S * θ ^ 24) = 6405 * S * θ ^ 40 := by ring
    have e2 : (6405 * S + Fc) * θ ^ 40 = 6405 * S * θ ^ 40 + Fc * θ ^ 40 := by ring
    rw [e2]
    linarith
  have hW0 : 0 ≤ J * SH + FAR := by positivity
  calc V * (J * SH + FAR) ≤ (kv * θ ^ 7) * ((6405 * S + Fc) * θ ^ 40) := mul_le_mul4 hV0 hW0 hV hW
    _ = kv * (6405 * S + Fc) * θ ^ 47 := by ring

theorem total_le {q : ℕ} (hq : 1 ≤ q) :
    ∃ K : ℝ, ∀ h : ℕ, 1 ≤ h → Vb h * Wq q h ≤ K * thH h ^ 47 := by
  refine ⟨kV q * (6405 * (2 * ((2 * ((6 * q : ℕ) : ℝ) + 1) * 12 * (Real.exp (10 * Z32) + 2) * kE1 q ^ 2 +
          (4 * k34 q) * (6 * ((6 * q : ℕ) : ℝ) * (4 * ((6 * q : ℕ) : ℝ) + 13) +
            (2 * ((6 * q : ℕ) : ℝ) + 2) * 12) * kE1 q) +
        (4 * ((6 * q : ℕ) : ℝ) + 3) * 12 * 49 * kE1 q ^ 2) +
        (3 * Real.exp (225 / 4) * 2 ^ 45 + 27 * kE1 q ^ 2)), ?_⟩
  intro h hh
  have hk34 : 0 ≤ k34 q := by
    unfold k34
    exact mul_nonneg (mul_nonneg (by norm_num) (Real.exp_pos _).le) (Real.exp_pos _).le
  have hkE1 : 0 ≤ kE1 q := by
    unfold kE1
    exact mul_nonneg (by positivity) (pow_nonneg (by linarith [cq_pos hq]) 4)
  have hkV : 0 ≤ kV q := by
    unfold kV
    exact mul_nonneg (Real.exp_pos _).le (pow_nonneg (by linarith [cq_pos hq]) 7)
  have hE1 : 1 ≤ envA1 (q * h ^ 3) := envA1_ge_one _
  have hCτ : 0 ≤ Real.exp (10 * Z32) := (Real.exp_pos _).le
  have h34 : envA34 (q * h ^ 3) * Dh h ^ (-(1 / 4 : ℝ)) * (1 + Real.log ((h ^ 2 : ℕ) : ℝ)) ≤
      4 * k34 q := by
    have h1 := envA34_D_le hq hh
    have h2 := poly_exp_le hh
    have hl : 0 ≤ 1 + Real.log ((h ^ 2 : ℕ) : ℝ) := by
      have : 0 ≤ Real.log ((h ^ 2 : ℕ) : ℝ) :=
        Real.log_nonneg (by exact_mod_cast Nat.one_le_pow _ _ (by omega))
      linarith
    calc envA34 (q * h ^ 3) * Dh h ^ (-(1 / 4 : ℝ)) * (1 + Real.log ((h ^ 2 : ℕ) : ℝ))
        ≤ k34 q * Real.exp (-(2 * tH h)) * (1 + Real.log ((h ^ 2 : ℕ) : ℝ)) :=
          mul_le_mul_of_nonneg_right h1 hl
      _ = k34 q * ((1 + Real.log ((h ^ 2 : ℕ) : ℝ)) * Real.exp (-(2 * tH h))) := by ring
      _ ≤ k34 q * 4 := mul_le_mul_of_nonneg_left h2 hk34
      _ = 4 * k34 q := by ring
  have hsh := shellU_explicit (P := 6 * q) (Cτ := Real.exp (10 * Z32)) hE1 (envA34_nonneg _)
    hCτ h34 hh
  have hsh0 : 0 ≤ shellU (6 * q) 3 (envA1 (q * h ^ 3)) (envA34 (q * h ^ 3)) (Real.exp (10 * Z32))
      (vkM h) (Dh h) (h ^ 2) :=
    shellU_nonneg (by norm_num) (by linarith) (envA34_nonneg _) hCτ (vkM_ge_one h)
      (Dh_ge_one h) (Nat.one_le_pow _ _ (by omega))
  have hfar := far_le hh hE1
  have hfar0 : 0 ≤ 3 / Lf h * (PiH h + (1 + envA1 (q * h ^ 3) *
      (1 + Real.log ((h ^ 2 : ℕ) : ℝ))) ^ 2) := by
    have := PiH_pos h
    have := Lf_pos hh
    have : 0 ≤ Real.log ((h ^ 2 : ℕ) : ℝ) :=
      Real.log_nonneg (by exact_mod_cast Nat.one_le_pow _ _ (by omega))
    positivity
  have hV0 : 0 ≤ Vb h := by unfold Vb; positivity
  unfold Wq
  exact total_arith (Nat.cast_nonneg _) hkE1 (by linarith) hCτ hkV (thH_ge_one hh) hE1
    (envA1_le hq hh) (tH_nonneg h) (tH_le hh) (Nat.cast_nonneg _) (Jh_le hh) hsh0 hsh hfar hfar0
    hV0 (Vb_le hq hh)

/-- **Gate 3, Upper region**: for every cutoff `Z`, the complete signed decorated
Upper quarter is `o(log h)` uniformly in `a`. -/
theorem upper_sublog (Z : ℕ → ℕ) :
    virelleR0061CompleteRegionSublog Z virelleR0037Upper := by
  intro q hq _ eps heps
  obtain ⟨K, hK⟩ := total_le (q := q) hq
  have hK0 : 0 ≤ K := by
    have h1 := hK 1 le_rfl
    have : 0 ≤ Vb 1 * Wq q 1 := by
      have hV0 : 0 ≤ Vb 1 := by unfold Vb; positivity
      exact mul_nonneg hV0 (by
        have hd : (∅ : Finset ℕ) ⊆ decoratedHeightPrimeSet q 1 := empty_subset _
        exact le_trans (abs_nonneg _) (slice_bound (fun _ => 0) (a := 0) hq le_rfl hd))
    have hθ : 0 < thH 1 ^ 47 := by have := thH_ge_one (le_refl 1); positivity
    by_contra hneg
    push_neg at hneg
    have : K * thH 1 ^ 47 < 0 := mul_neg_of_neg_of_pos hneg hθ
    linarith
  set N : ℝ := 2 * K / eps + 1
  have hN : 1 ≤ N := by
    have : 0 ≤ 2 * K / eps := by positivity
    linarith
  refine ⟨⌈Real.exp (N ^ 64 + 2)⌉₊ + 1, ?_⟩
  intro a h _ _ _ hH0
  have hh : 1 ≤ h := by omega
  refine (master_bound Z hq a hh).trans ((hK h hh).trans ?_)
  set θ := thH h
  have hθ := thH_ge_one hh
  have hθ64 := thH_pow64 hh
  have hhr : Real.exp (N ^ 64 + 2) ≤ (h : ℝ) := by
    have := Nat.le_ceil (Real.exp (N ^ 64 + 2))
    have : ((⌈Real.exp (N ^ 64 + 2)⌉₊ : ℕ) : ℝ) ≤ h := by exact_mod_cast (by omega : ⌈Real.exp (N ^ 64 + 2)⌉₊ ≤ h)
    linarith
  have hL : N ^ 64 + 2 ≤ Real.log h := by
    rw [Real.le_log_iff_exp_le (by linarith [Real.exp_pos (N ^ 64 + 2)])]
    exact hhr
  -- θ ≥ N
  have hθN : N ≤ θ := by
    have : N ^ 64 ≤ θ ^ 64 := by rw [hθ64]; linarith
    exact (pow_le_pow_iff_left₀ (by linarith) (by linarith) (by norm_num)).mp this
  -- log h ≥ θ^64 / 2
  have hLθ : θ ^ 64 / 2 ≤ Real.log h := by
    have : (1 : ℝ) ≤ N ^ 64 := one_le_pow₀ hN
    rw [hθ64]; linarith
  -- K θ^47 ≤ eps θ^64 / 2
  have h17 : 2 * K / eps ≤ θ ^ 17 := by
    have : θ ≤ θ ^ 17 := by
      calc θ = θ ^ 1 := (pow_one _).symm
        _ ≤ θ ^ 17 := pow_le_pow_right₀ hθ (by norm_num)
    linarith
  have hkey : K * θ ^ 47 ≤ eps * (θ ^ 64 / 2) := by
    have h1 : 2 * K ≤ eps * θ ^ 17 := by
      rw [div_le_iff₀ heps] at h17; linarith
    have hθ47 : 0 ≤ θ ^ 47 := by positivity
    have : θ ^ 64 = θ ^ 17 * θ ^ 47 := by ring
    rw [this]
    nlinarith
  calc K * θ ^ 47 ≤ eps * (θ ^ 64 / 2) := hkey
    _ ≤ eps * Real.log h := mul_le_mul_of_nonneg_left hLθ heps.le

end OrielUpper
