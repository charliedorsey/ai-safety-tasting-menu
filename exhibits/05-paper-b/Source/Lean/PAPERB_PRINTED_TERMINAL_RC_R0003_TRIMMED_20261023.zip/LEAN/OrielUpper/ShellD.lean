import OrielUpper.ShellC

/-!
# Oriel Upper — the shell bound

For a product window `a < r s ≤ b` with `1 ≤ a ≤ b ≤ 2a`, a cut `R` with
`R² M D ≤ a < (R+1)² M D` (or `R = 1`), and envelopes `E1, E34, Cτ`,

`|∑_{window} b(r) b_r(s) Δ(r,s)| ≤ 2 S₁₂ + S₃`.
-/

open Finset

namespace OrielUpper

variable {P : ℕ} [NeZero P]

/-- The window pair sum. -/
noncomputable def pairWin (F H : ℕ) (w : ℕ → ℝ) (a b : ℕ) : ℝ :=
  ∑ r ∈ Icc 1 b, ∑ s ∈ Icc 1 b, if winC a b r s then pairTerm F H w r s else 0

/-- Sector 1/2 budget. -/
noncomputable def budget12 (P : ℕ) (B E1 E34 Cτ M D : ℝ) (a R : ℕ) : ℝ :=
  (2 * P + 1) * B * (1 + Real.log 4) * E1 * (Cτ + 2 * E1 * (1 + Real.log R) / a) +
    E34 * E1 * (1 + Real.log R) *
      (2 * P * B * (8 * M + 4 * P + 5) / M + (2 * P + 2) * B * (1 + Real.log 4)) *
        D ^ (-(1 / 4 : ℝ))

/-- Sector 3 budget. -/
noncomputable def budget3 (P : ℕ) (B E1 M D : ℝ) : ℝ :=
  (4 * P + 3) * B * (1 + Real.log 4) * E1 * E1 * (1 + Real.log (8 * M * D))

lemma sum_bW_Ioc_one_le {F R : ℕ} {E1 : ℝ} (hR : 1 ≤ R) (hE1 : Asig F R 1 ≤ E1) :
    ∑ r ∈ Ioc 1 R, bW F r ≤ E1 * (1 + Real.log R) := by
  have h := oriel_band_sum F (le_refl 1) hR
  simp only [Nat.cast_one, div_one] at h
  have hl : 0 ≤ Real.log R := Real.log_nonneg (by exact_mod_cast hR)
  calc _ ≤ _ := h
    _ ≤ E1 * (1 + Real.log R) := mul_le_mul_of_nonneg_right hE1 (by linarith)

theorem sum_innerBound_le {F : ℕ} {B E1 E34 Cτ M D : ℝ} {a R : ℕ} (hB : 0 ≤ B)
    (hE1 : ∀ N, Asig F N 1 ≤ E1) (hE34 : 0 ≤ E34) (hM : 1 ≤ M) (hD : 0 < D) (ha : 1 ≤ a)
    (hR1 : 1 ≤ R) (hRup : 1 < R → (R : ℝ) ^ 2 * (M * D) ≤ a)
    (hτ : ∀ N, ∑ r ∈ Icc 1 N, bW F r * ((r.divisors.card : ℝ) / r) ≤ Cτ) :
    ∑ r ∈ Ioc 1 R, bW F r * innerBound P B E1 E34 M D a r ≤
      budget12 P B E1 E34 Cτ M D a R := by
  have hE1' : 0 ≤ E1 := le_trans (Asig_nonneg F 0 1) (hE1 0)
  have hl4 : 0 ≤ Real.log 4 := Real.log_nonneg (by norm_num)
  have hlR : 0 ≤ Real.log R := Real.log_nonneg (by exact_mod_cast hR1)
  have har : (0 : ℝ) < a := by exact_mod_cast (show 0 < a by omega)
  have hDm : 0 < D ^ (-(1 / 4 : ℝ)) := by positivity
  have hτ0 : 0 ≤ Cτ := le_trans (by simp) (hτ 0)
  have hbud : 0 ≤ budget12 P B E1 E34 Cτ M D a R := by
    unfold budget12
    have : 0 < M := by linarith
    positivity
  rcases Nat.lt_or_ge 1 R with hR2 | hR2
  swap
  · rw [Ioc_eq_empty (by omega), sum_empty]; exact hbud
  have hRMD := hRup hR2
  set K1 := (2 * (P : ℝ) + 1) * B * (1 + Real.log 4) * E1
  set C0 := K1 * (2 / a) + E34 * (2 * P * B * (8 * M + 4 * P + 5)) * (D ^ (-(1 / 4 : ℝ)) / M) +
    E34 * ((2 * P + 2) * B * (1 + Real.log 4) * D ^ (-(1 / 4 : ℝ)))
  have hK1 : 0 ≤ K1 := by positivity
  have hD34 : D ^ (3 / 4 : ℝ) = D ^ (-(1 / 4 : ℝ)) * D := by
    rw [← Real.rpow_add_one hD.ne']; norm_num
  have hpt : ∀ r ∈ Ioc 1 R, bW F r * innerBound P B E1 E34 M D a r ≤
      K1 * (bW F r * ((r.divisors.card : ℝ) / r)) + C0 * bW F r := by
    intro r hr
    have hrR : r ≤ R := (mem_Ioc.mp hr).2
    have hr2 : ((r : ℝ) ^ 2 / a) * D ^ (3 / 4 : ℝ) ≤ D ^ (-(1 / 4 : ℝ)) / M := by
      have h1 : (r : ℝ) ^ 2 ≤ (R : ℝ) ^ 2 := by
        have : (r : ℝ) ≤ R := by exact_mod_cast hrR
        exact pow_le_pow_left₀ (by positivity) this 2
      rw [hD34, div_mul_eq_mul_div, div_le_div_iff₀ har (by linarith)]
      have hMD : 0 < M * D := by have : 0 < M := by linarith
                                 positivity
      calc (r : ℝ) ^ 2 * (D ^ (-(1 / 4 : ℝ)) * D) * M
          = (r : ℝ) ^ 2 * (M * D) * D ^ (-(1 / 4 : ℝ)) := by ring
        _ ≤ (R : ℝ) ^ 2 * (M * D) * D ^ (-(1 / 4 : ℝ)) := by gcongr
        _ ≤ a * D ^ (-(1 / 4 : ℝ)) := by gcongr
        _ = D ^ (-(1 / 4 : ℝ)) * a := by ring
    have hb0 := bW_nonneg F r
    unfold innerBound
    have hc : 0 ≤ E34 * (2 * P * B * (8 * M + 4 * P + 5)) := by
      have : 0 < M := by linarith
      positivity
    have key : E34 * (2 * P * B * (8 * M + 4 * P + 5) * ((r : ℝ) ^ 2 / a) * D ^ (3 / 4 : ℝ)) ≤
        E34 * (2 * P * B * (8 * M + 4 * P + 5)) * (D ^ (-(1 / 4 : ℝ)) / M) := by
      calc E34 * (2 * P * B * (8 * M + 4 * P + 5) * ((r : ℝ) ^ 2 / a) * D ^ (3 / 4 : ℝ))
          = E34 * (2 * P * B * (8 * M + 4 * P + 5)) * (((r : ℝ) ^ 2 / a) * D ^ (3 / 4 : ℝ)) := by
            ring
        _ ≤ _ := mul_le_mul_of_nonneg_left hr2 hc
    have e : bW F r * ((2 * P + 1) * B * (1 + Real.log 4) * E1 *
        ((r.divisors.card : ℝ) / r + 2 / a) +
        E34 * (2 * P * B * (8 * M + 4 * P + 5) * ((r : ℝ) ^ 2 / a) * D ^ (3 / 4 : ℝ) +
          (2 * P + 2) * B * (1 + Real.log 4) * D ^ (-(1 / 4 : ℝ)))) =
        K1 * (bW F r * ((r.divisors.card : ℝ) / r)) +
          bW F r * (K1 * (2 / a) +
            E34 * (2 * P * B * (8 * M + 4 * P + 5) * ((r : ℝ) ^ 2 / a) * D ^ (3 / 4 : ℝ)) +
            E34 * ((2 * P + 2) * B * (1 + Real.log 4) * D ^ (-(1 / 4 : ℝ)))) := by
      simp only [K1]; ring
    rw [e, mul_comm C0]
    apply add_le_add le_rfl
    apply mul_le_mul_of_nonneg_left _ hb0
    simp only [C0]
    linarith
  refine (sum_le_sum hpt).trans ?_
  rw [sum_add_distrib, ← mul_sum, ← mul_sum]
  have hS1 : ∑ r ∈ Ioc 1 R, bW F r * ((r.divisors.card : ℝ) / r) ≤ Cτ := by
    refine le_trans ?_ (hτ R)
    apply sum_le_sum_of_subset_of_nonneg
    · intro r hr; simp only [mem_Ioc, mem_Icc] at hr ⊢; omega
    · intro r _ _; exact mul_nonneg (bW_nonneg F r) (by positivity)
  have hS2 := sum_bW_Ioc_one_le (F := F) hR1 (hE1 R)
  have hC0 : 0 ≤ C0 := by
    simp only [C0]
    have : 0 < M := by linarith
    positivity
  calc K1 * ∑ r ∈ Ioc 1 R, bW F r * ((r.divisors.card : ℝ) / r) + C0 * ∑ r ∈ Ioc 1 R, bW F r
      ≤ K1 * Cτ + C0 * (E1 * (1 + Real.log R)) := by
        gcongr
    _ = budget12 P B E1 E34 Cτ M D a R := by
        simp only [C0, K1, budget12]
        have : M ≠ 0 := by linarith
        field_simp
        ring

theorem shell_bound {F H : ℕ} {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {B : ℝ}
    (hR : RowHyp P F H w Λ B) {a b R : ℕ} (ha : 1 ≤ a) (hab : a ≤ b) (hb2 : b ≤ 2 * a)
    (hR1 : 1 ≤ R) (hRa : R * R ≤ a) {M D E1 E34 Cτ : ℝ} (hHM : (H : ℝ) ≤ 2 * M * a)
    (hM : 1 ≤ M) (hD : 1 ≤ D)
    (hRup : 1 < R → (R : ℝ) ^ 2 * (M * D) ≤ a) (hRlow : (a : ℝ) < ((R : ℝ) + 1) ^ 2 * (M * D))
    (hE1 : ∀ m N, 1 ≤ m → m ≤ b → Asig (F * m) N 1 ≤ E1)
    (hE34 : ∀ m N, 1 ≤ m → m ≤ b → Asig (F * m) N (3 / 4) ≤ E34)
    (hτ : ∀ N, ∑ r ∈ Icc 1 N, bW F r * ((r.divisors.card : ℝ) / r) ≤ Cτ) :
    |pairWin F H w a b| ≤ 2 * budget12 P B E1 E34 Cτ M D a R + budget3 P B E1 M D := by
  have hD0 : 0 < D := by linarith
  have hM0 : 0 ≤ M := by linarith
  have hB0 := hR.B_nonneg
  have hE1F : ∀ N, Asig F N 1 ≤ E1 := by
    intro N; have := hE1 1 N le_rfl (by omega); rwa [mul_one] at this
  have hE1' : 0 ≤ E1 := le_trans (Asig_nonneg F 0 1) (hE1F 0)
  have hE34' : 0 ≤ E34 := by
    have := hE34 1 0 le_rfl (by omega); exact le_trans (Asig_nonneg _ _ _) this
  have hRb : R ≤ b := by nlinarith
  -- split
  have hsplit : pairWin F H w a b =
      ∑ r ∈ Icc 1 b, ∑ s ∈ Icc 1 b,
        (if winC a b r s ∧ r ≤ R then pairTerm F H w r s else 0) +
      ∑ r ∈ Icc 1 b, ∑ s ∈ Icc 1 b,
        (if winC a b r s ∧ R < r ∧ s ≤ R then pairTerm F H w r s else 0) +
      ∑ r ∈ Icc 1 b, ∑ s ∈ Icc 1 b,
        (if winC a b r s ∧ R < r ∧ R < s then pairTerm F H w r s else 0) := by
    unfold pairWin
    rw [← sum_add_distrib, ← sum_add_distrib]
    apply sum_congr rfl; intro r _
    rw [← sum_add_distrib, ← sum_add_distrib]
    apply sum_congr rfl; intro s _
    by_cases hc : winC a b r s
    · by_cases h1 : r ≤ R
      · rw [if_pos hc, if_pos ⟨hc, h1⟩, if_neg (by omega), if_neg (by omega)]; ring
      · by_cases h2 : s ≤ R
        · rw [if_pos hc, if_neg (by tauto), if_pos ⟨hc, by omega, h2⟩, if_neg (by omega)]; ring
        · rw [if_pos hc, if_neg (by tauto), if_neg (by omega), if_pos ⟨hc, by omega, by omega⟩]
          ring
    · rw [if_neg hc, if_neg (by tauto), if_neg (by tauto), if_neg (by tauto)]; ring
  rw [hsplit, sector_one _ hR1 hRa hab, sector_two _ hR1 hRa hab]
  -- sector 1
  have hT1 : |∑ r ∈ Ioc 1 R, ∑ s ∈ Ioc (a / r) (b / r), pairTerm F H w r s| ≤
      budget12 P B E1 E34 Cτ M D a R := by
    refine (abs_sum_le_sum_abs _ _).trans ?_
    refine le_trans ?_ (sum_innerBound_le hB0 hE1F hE34' hM hD0 ha hR1 hRup hτ)
    apply sum_le_sum
    intro r hr
    have hr1 : 1 ≤ r := by have := (mem_Ioc.mp hr).1; omega
    have hrR : r ≤ R := (mem_Ioc.mp hr).2
    have hra : r ≤ a := by nlinarith
    have e : ∑ s ∈ Ioc (a / r) (b / r), pairTerm F H w r s =
        bW F r * ∑ s ∈ Ioc (a / r) (b / r), bW (F * r) s * rowDisc w H r s := by
      rw [mul_sum]; apply sum_congr rfl; intro s _; unfold pairTerm; ring
    rw [e, abs_mul, abs_of_nonneg (bW_nonneg F r)]
    by_cases hW : bW F r = 0
    · rw [hW]; simp
    apply mul_le_mul_of_nonneg_left _ (bW_nonneg F r)
    exact s1_inner hR hr1 hra hb2 hW hHM hM0 hD0 (hE1 r _ hr1 (by omega))
      (hE34 r _ hr1 (by omega))
  -- sector 2
  have hT2 : |∑ s ∈ Ioc 1 R, ∑ r ∈ Ioc (max (a / s) R) (b / s), pairTerm F H w r s| ≤
      budget12 P B E1 E34 Cτ M D a R := by
    refine (abs_sum_le_sum_abs _ _).trans ?_
    refine le_trans ?_ (sum_innerBound_le hB0 hE1F hE34' hM hD0 ha hR1 hRup hτ)
    apply sum_le_sum
    intro s hs
    have hs1 : 1 ≤ s := by have := (mem_Ioc.mp hs).1; omega
    have hsR : s ≤ R := (mem_Ioc.mp hs).2
    have hsa : s ≤ a := by nlinarith
    have e : ∑ r ∈ Ioc (max (a / s) R) (b / s), pairTerm F H w r s =
        bW F s * ∑ r ∈ Ioc (max (a / s) R) (b / s), bW (F * s) r * rowDisc w H r s := by
      rw [mul_sum]; apply sum_congr rfl; intro r _; unfold pairTerm
      rw [bW_pair_symm]; ring
    rw [e, abs_mul, abs_of_nonneg (bW_nonneg F s)]
    by_cases hW : bW F s = 0
    · rw [hW]; simp
    apply mul_le_mul_of_nonneg_left _ (bW_nonneg F s)
    exact s2_inner hR hs1 hsa hb2 (le_max_left _ _) hW hHM hM0 hD0 (hE1 s _ hs1 (by omega))
      (hE34 s _ hs1 (by omega))
  -- sector 3
  set K := (4 * (P : ℝ) + 3) * B
  have hK : 0 ≤ K := by positivity
  have hT3 := sector_three (a := a) (b := b) (fun r s => pairTerm F H w r s)
    (fun r s => bW F r * bW F s * K)
    (fun r s => (abs_pairTerm_le hR r s).trans (by
      apply mul_le_mul_of_nonneg_right _ hK
      exact mul_le_mul_of_nonneg_left (bW_mul_le F r s) (bW_nonneg F r)))
    (fun r s => by have := bW_nonneg F r; have := bW_nonneg F s; positivity) hR1
  have hinner : ∀ r ∈ Ioc R (b / (R + 1)),
      ∑ s ∈ Ioc (max (a / r) 1) (b / r), bW F r * bW F s * K ≤
        bW F r * (K * (E1 * (1 + Real.log 4))) := by
    intro r hr
    have hr0 : 0 < r := by have := (mem_Ioc.mp hr).1; omega
    rw [← sum_mul, ← mul_sum, mul_assoc]
    apply mul_le_mul_of_nonneg_left _ (bW_nonneg F r)
    rw [mul_comm]
    apply mul_le_mul_of_nonneg_left _ hK
    by_cases hAB : max (a / r) 1 ≤ b / r
    · refine (oriel_band_sum F (le_max_right _ _) hAB).trans ?_
      apply mul_le_mul (hE1F _) (log_ratio_le (le_max_right _ _) _)
        (log_ratio_nonneg (le_max_right _ _) hAB) hE1'
      have := div_le_three_max (a := a) (b := b) hr0 hb2; omega
    · rw [Ioc_eq_empty (by omega), sum_empty]; positivity
  have hT3' : ∑ r ∈ Ioc R (b / (R + 1)), ∑ s ∈ Ioc (max (a / r) 1) (b / r),
      bW F r * bW F s * K ≤ budget3 P B E1 M D := by
    refine (sum_le_sum hinner).trans ?_
    rw [← sum_mul]
    have hl8 : 0 ≤ Real.log (8 * M * D) := Real.log_nonneg (by nlinarith)
    have hout : ∑ r ∈ Ioc R (b / (R + 1)), bW F r ≤ E1 * (1 + Real.log (8 * M * D)) := by
      by_cases hAB : R ≤ b / (R + 1)
      · refine (oriel_band_sum F hR1 hAB).trans ?_
        apply mul_le_mul (hE1F _) _ (log_ratio_nonneg hR1 hAB) hE1'
        have hRr : (0 : ℝ) < R := by exact_mod_cast (show 0 < R by omega)
        have hq : (((b / (R + 1) : ℕ) : ℝ)) ≤ (b : ℝ) / ((R : ℝ) + 1) := by
          have := Nat.cast_div_le (α := ℝ) (m := b) (n := R + 1); push_cast at this; exact this
        rcases Nat.eq_zero_or_pos (b / (R + 1)) with h0 | h0
        · rw [h0]; simp only [Nat.cast_zero, zero_div, Real.log_zero]; linarith
        have hpos : (0 : ℝ) < ((b / (R + 1) : ℕ) : ℝ) / R := by
          have : (0 : ℝ) < ((b / (R + 1) : ℕ) : ℝ) := by exact_mod_cast h0
          positivity
        have : ((b / (R + 1) : ℕ) : ℝ) / R ≤ 8 * M * D := by
          rw [div_le_iff₀ hRr]
          have hb2r : (b : ℝ) ≤ 2 * a := by exact_mod_cast hb2
          have hR1r : (1 : ℝ) ≤ R := by exact_mod_cast hR1
          have : (b : ℝ) / ((R : ℝ) + 1) ≤ 8 * M * D * R := by
            rw [div_le_iff₀ (by linarith)]
            have hMD : 0 ≤ M * D := by positivity
            nlinarith
          linarith
        have := Real.log_le_log hpos this
        linarith
      · rw [Ioc_eq_empty (by omega), sum_empty]
        have : 0 ≤ E1 * (1 + Real.log (8 * M * D)) := by positivity
        exact this
    unfold budget3
    calc (∑ r ∈ Ioc R (b / (R + 1)), bW F r) * (K * (E1 * (1 + Real.log 4)))
        ≤ (E1 * (1 + Real.log (8 * M * D))) * (K * (E1 * (1 + Real.log 4))) := by
          apply mul_le_mul_of_nonneg_right hout
          have : 0 ≤ Real.log 4 := Real.log_nonneg (by norm_num)
          positivity
      _ = _ := by simp only [K]; ring
  calc _ ≤ |∑ r ∈ Ioc 1 R, ∑ s ∈ Ioc (a / r) (b / r), pairTerm F H w r s +
        ∑ s ∈ Ioc 1 R, ∑ r ∈ Ioc (max (a / s) R) (b / s), pairTerm F H w r s| +
      |∑ r ∈ Icc 1 b, ∑ s ∈ Icc 1 b,
        (if winC a b r s ∧ R < r ∧ R < s then pairTerm F H w r s else 0)| := abs_add_le _ _
    _ ≤ (|∑ r ∈ Ioc 1 R, ∑ s ∈ Ioc (a / r) (b / r), pairTerm F H w r s| +
        |∑ s ∈ Ioc 1 R, ∑ r ∈ Ioc (max (a / s) R) (b / s), pairTerm F H w r s|) +
      budget3 P B E1 M D := add_le_add (abs_add_le _ _) (hT3.trans hT3')
    _ ≤ (budget12 P B E1 E34 Cτ M D a R + budget12 P B E1 E34 Cτ M D a R) +
      budget3 P B E1 M D := by gcongr
    _ = _ := by ring

end OrielUpper
