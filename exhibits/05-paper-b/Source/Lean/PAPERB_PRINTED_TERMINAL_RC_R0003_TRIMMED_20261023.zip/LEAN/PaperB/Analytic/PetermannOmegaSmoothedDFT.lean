import PaperB.Analytic.PetermannOmegaKernelSplit
import PaperB.Analytic.CharacterAdditiveTwist
import PaperB.Analytic.PetermannOmegaSmoothExpansion
import PaperB.Analytic.PetermannOmegaMovingFourierBand

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset

noncomputable def petermannOmegaSmoothedAdditiveKernel
    (q H X : ℕ) (S xi T : ℝ) (r : ℤ) : ℂ :=
  ∑ e ∈ Finset.Icc 1 X,
    (omegaCoeff q e : ℂ) *
      (eR (xi * (e : ℝ)) *
        sawSmoothPartial S H
          ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
            AddCircle (1 : ℝ)))

theorem petermannOmegaSmoothedKernel_eq_additive_dft
    (q : ℕ) [NeZero (Nat.lcm 6 q)]
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (T : ℝ) (X H : ℕ) (S : ℝ) :
    petermannOmegaSmoothedKernel q chi r T X H S =
      ((Nat.lcm 6 q : ℕ) : ℂ)⁻¹ *
        ∑ h : ZMod (Nat.lcm 6 q),
          ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h *
            petermannOmegaSmoothedAdditiveKernel q H X S
              ((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) T r := by
  unfold petermannOmegaSmoothedKernel
  unfold petermannOmegaSmoothedAdditiveKernel
  calc
    (∑ e ∈ Finset.Icc 1 X,
      (chi e) * (omegaCoeff q e : ℂ) *
        sawSmoothPartial S H
          ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
            AddCircle (1 : ℝ)))
      =
    ∑ e ∈ Finset.Icc 1 X,
      ((((Nat.lcm 6 q : ℕ) : ℂ)⁻¹ *
        ∑ h : ZMod (Nat.lcm 6 q),
          eR (((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) * (e : ℝ)) *
            ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h) *
        (omegaCoeff q e : ℂ) *
        sawSmoothPartial S H
          ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
            AddCircle (1 : ℝ))) := by
        apply Finset.sum_congr rfl
        intro e he
        rw [dirichletCharacter_additive_eR_inversion]
    _ =
      ((Nat.lcm 6 q : ℕ) : ℂ)⁻¹ *
        ∑ h : ZMod (Nat.lcm 6 q),
          ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h *
            (∑ e ∈ Finset.Icc 1 X,
              (omegaCoeff q e : ℂ) *
                (eR (((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) *
                  (e : ℝ)) *
                  sawSmoothPartial S H
                    ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
                      (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
                      AddCircle (1 : ℝ)))) := by
        classical
        simp_rw [Finset.mul_sum, Finset.sum_mul]
        rw [Finset.sum_comm]
        apply Finset.sum_congr rfl
        intro h hh
        apply Finset.sum_congr rfl
        intro e he
        ring

theorem petermannOmegaSmoothedAdditiveKernel_expansion
    {S : ℝ} (hS : 1 < S)
    (q H X : ℕ) (xi T : ℝ) (r : ℤ) :
    petermannOmegaSmoothedAdditiveKernel q H X S xi T r =
      ∑ k ∈ Finset.range H,
        (sawSmoothCoeff S (k + 1 : ℕ) *
            eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) /
              ((Nat.lcm 6 q : ℕ) : ℝ)) *
            (∑ e ∈ Finset.Icc 1 X,
              (omegaCoeff q e : ℂ) *
                eR (((((k + 1 : ℕ) : ℝ) * T) /
                    ((Nat.lcm 6 q : ℕ) : ℝ)) / (e : ℝ) +
                  xi * (e : ℝ))) +
          sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
            eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) /
              ((Nat.lcm 6 q : ℕ) : ℝ)) *
            (∑ e ∈ Finset.Icc 1 X,
              (omegaCoeff q e : ℂ) *
                eR (((-((k + 1 : ℕ) : ℤ) : ℝ) * T) /
                    ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
                  xi * (e : ℝ)))) := by
  unfold petermannOmegaSmoothedAdditiveKernel
  exact omega_smoothed_additive_kernel_expansion hS q H X xi T r

#print axioms petermannOmegaSmoothedKernel_eq_additive_dft
#print axioms petermannOmegaSmoothedAdditiveKernel_expansion

end PaperB.Analytic
