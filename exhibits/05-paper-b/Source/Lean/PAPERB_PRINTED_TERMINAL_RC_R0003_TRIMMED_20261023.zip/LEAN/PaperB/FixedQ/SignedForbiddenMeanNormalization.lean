import PaperB.FixedQ.DivisorExpansion

open scoped BigOperators

namespace PaperB.FixedQ

lemma tsum_normalizationWeightMass_mul
    (q h : ℕ) (X : ℝ) :
    (∑' e : Finset ℕ, normalizationWeightMass q h e * X) =
      (∑' e : Finset ℕ, normalizationWeightMass q h e) * X := by
  rw [tsum_mul_right]

lemma cStar_mul_normalizationWeightMass_principal
    (q h : ℕ) (X : ℝ) :
    cStarReal q h *
        (∑' e : Finset ℕ, normalizationWeightMass q h e * X) = X := by
  rw [tsum_normalizationWeightMass_mul]
  rw [← mul_assoc, infiniteNormalizationWeightMass]
  simp

lemma cStar_mul_pairBaseline_principal
    (q h : ℕ) (X : ℝ) :
    cStarReal q h *
        (∑' e : Finset ℕ,
          (∑ e1 ∈ e.powerset,
            pairCoefficient q h e e1 / pairDenominator e e1) * X) = X := by
  have h := cStar_mul_normalizationWeightMass_principal q h X
  simpa only [normalizationWeightMass_eq_pairBaselineSum] using h

#print axioms cStar_mul_normalizationWeightMass_principal
#print axioms cStar_mul_pairBaseline_principal

end PaperB.FixedQ
