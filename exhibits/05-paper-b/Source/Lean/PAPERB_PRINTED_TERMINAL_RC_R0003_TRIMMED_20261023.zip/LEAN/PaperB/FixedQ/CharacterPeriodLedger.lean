import PaperB.FixedQ.PetermannInterface
import Mathlib.NumberTheory.DirichletCharacter.Orthogonality
import Mathlib.NumberTheory.DirichletCharacter.Bounds
import Mathlib.Algebra.BigOperators.Module

open scoped BigOperators

namespace PaperB.FixedQ

theorem dirichletCharacter_sum_one_period_eq_zero
    {L : ℕ} (hL : 0 < L)
    (chi : DirichletCharacter ℂ L)
    (hchi : chi ≠ 1) :
    (∑ n ∈ Finset.range L, chi n) = 0 := by
  cases L with
  | zero => omega
  | succ m =>
      letI : NeZero (m + 1) := ⟨by omega⟩
      have hsumZ : (∑ a : ZMod (m + 1), chi a) = 0 :=
        MulChar.sum_eq_zero_of_ne_one hchi
      have hfin :
          (∑ i : Fin (m + 1), chi ((ZMod.finEquiv (m + 1)) i)) =
            ∑ a : ZMod (m + 1), chi a :=
        (ZMod.finEquiv (m + 1)).toEquiv.sum_comp chi
      rw [← hfin] at hsumZ
      have hpoint :
          ∀ i : Fin (m + 1),
            chi (i.val : ZMod (m + 1)) =
              chi ((ZMod.finEquiv (m + 1)) i) := by
        intro i
        apply congrArg chi
        apply ZMod.val_injective
        rw [ZMod.val_natCast_of_lt i.isLt]
        rfl
      have hsumFin :
          (∑ i : Fin (m + 1), chi (i.val : ZMod (m + 1))) = 0 := by
        calc
          (∑ i : Fin (m + 1), chi (i.val : ZMod (m + 1)))
              = ∑ i : Fin (m + 1), chi ((ZMod.finEquiv (m + 1)) i) := by
                  apply Finset.sum_congr rfl
                  intro i hi
                  exact hpoint i
          _ = 0 := hsumZ
      rw [Finset.sum_fin_eq_sum_range] at hsumFin
      calc
        (∑ n ∈ Finset.range (m + 1), chi (n : ZMod (m + 1)))
            = ∑ n ∈ Finset.range (m + 1),
                if h : n < m + 1
                then chi (((Fin.mk n h : Fin (m + 1)).val : ℕ) : ZMod (m + 1))
                else 0 := by
                  apply Finset.sum_congr rfl
                  intro n hn
                  rw [dif_pos (Finset.mem_range.mp hn)]
        _ = 0 := hsumFin

theorem dirichletCharacter_nat_periodic
    {L : ℕ} (chi : DirichletCharacter ℂ L)
    (n : ℕ) :
    chi (n + L) = chi n := by
  apply congrArg chi
  rw [ZMod.natCast_self, add_zero]

theorem dirichletCharacter_sum_block_eq_zero
    {L : ℕ} (hL : 0 < L)
    (chi : DirichletCharacter ℂ L)
    (hchi : chi ≠ 1)
    (k : ℕ) :
    (∑ n ∈ Finset.Ico (k * L) ((k + 1) * L), chi n) = 0 := by
  rw [show (k + 1) * L = k * L + L by ring]
  rw [Finset.sum_Ico_eq_sum_range]
  have hlen : k * L + L - k * L = L := by omega
  rw [hlen]
  have hper : ∀ j : ℕ,
      chi (((k * L + j : ℕ) : ZMod L)) =
        chi ((j : ℕ) : ZMod L) := by
    intro j
    apply congrArg chi
    rw [Nat.cast_add, Nat.cast_mul, ZMod.natCast_self, mul_zero, zero_add]
  calc
    (∑ j ∈ Finset.range L, chi (((k * L + j : ℕ) : ZMod L)))
        = ∑ j ∈ Finset.range L, chi ((j : ℕ) : ZMod L) := by
            apply Finset.sum_congr rfl
            intro j hj
            exact hper j
    _ = 0 := dirichletCharacter_sum_one_period_eq_zero hL chi hchi

#print axioms dirichletCharacter_sum_one_period_eq_zero
#print axioms dirichletCharacter_sum_block_eq_zero

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem dirichletCharacter_sum_range_mul_period_eq_zero
    {L : ℕ} (hL : 0 < L)
    (chi : DirichletCharacter ℂ L)
    (hchi : chi ≠ 1)
    (k : ℕ) :
    (∑ n ∈ Finset.range (k * L), chi n) = 0 := by
  induction k with
  | zero => simp
  | succ k ih =>
      have hle : k * L ≤ (k + 1) * L := by
        exact Nat.mul_le_mul_right L (Nat.le_succ k)
      rw [← Finset.sum_range_add_sum_Ico _ hle]
      rw [ih, dirichletCharacter_sum_block_eq_zero hL chi hchi k]
      simp

theorem norm_dirichletCharacter_sum_range_le_period
    {L : ℕ} (hL : 0 < L)
    (chi : DirichletCharacter ℂ L)
    (hchi : chi ≠ 1)
    (X : ℕ) :
    ‖∑ n ∈ Finset.range X, chi n‖ ≤ L := by
  let k := X / L
  have hbase : k * L ≤ X := by
    dsimp [k]
    exact Nat.div_mul_le_self X L
  have hsplit :
      (∑ n ∈ Finset.range X, chi n) =
        ∑ n ∈ Finset.Ico (k * L) X, chi n := by
    rw [← Finset.sum_range_add_sum_Ico _ hbase]
    rw [dirichletCharacter_sum_range_mul_period_eq_zero hL chi hchi k]
    simp
  rw [hsplit]
  calc
    ‖∑ n ∈ Finset.Ico (k * L) X, chi n‖
        ≤ ∑ n ∈ Finset.Ico (k * L) X, ‖chi n‖ := norm_sum_le _ _
    _ ≤ ∑ _n ∈ Finset.Ico (k * L) X, (1 : ℝ) := by
          apply Finset.sum_le_sum
          intro n hn
          exact chi.norm_le_one n
    _ = (X - k * L : ℕ) := by simp
    _ ≤ L := by
      have hmod : X % L < L := Nat.mod_lt X hL
      have hdivmod : X / L * L + X % L = X := by
        simpa [mul_comm] using Nat.div_add_mod X L
      have hrem : X - (X / L) * L = X % L := by
        omega
      dsimp [k]
      rw [hrem]
      exact_mod_cast hmod.le

#print axioms norm_dirichletCharacter_sum_range_le_period

end PaperB.FixedQ
