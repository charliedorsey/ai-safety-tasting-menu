import OrielLR.MirrorLR
import OrielLR.LongVK

/-!
# Oriel L/R — exact reduction of a decoration slice for an arbitrary region

Same bijection `(e, B) ↦ (∏B, ∏(e∖B))` as for Upper, for any source region
predicate `R h H r s` (decided classically, as in R0056).
-/

open Finset
open OrielUpper.Mirror

namespace OrielUpper

section
open scoped Classical

/-- Region window condition. -/
def regC (Z : ℕ → ℕ) (R : ℕ → ℕ → ℕ → ℕ → Prop) (h H U r s : ℕ) : Prop :=
  1 < r ∧ 1 < s ∧ Z h < r * s ∧ r * s ≤ U ∧ R h H r s

/-- Region pair sum in the box `[1, U]²`. -/
noncomputable def regWin (F H : ℕ) (w : ℕ → ℝ) (Z : ℕ → ℕ) (R : ℕ → ℕ → ℕ → ℕ → Prop)
    (h U : ℕ) : ℝ :=
  ∑ r ∈ Icc 1 U, ∑ s ∈ Icc 1 U, if regC Z R h H U r s then pairTerm F H w r s else 0

theorem slice_eq_region (Z : ℕ → ℕ) (R : ℕ → ℕ → ℕ → ℕ → Prop) {q a h : ℕ} (hq : 0 < q)
    (hh : 0 < h) {d : Finset ℕ} (hd : d ⊆ decoratedHeightPrimeSet q h) :
    (∑ e ∈ edrinR0051QuarterParents Z q h
        (h / primeSetProduct d) d ((h / primeSetProduct d) ^ 2 + 1),
      ∑ B ∈ ((e.powerset.erase e).erase ∅),
        @ite ℝ (R h (h / primeSetProduct d)
          (primeSetProduct B) (primeSetProduct (e \ B)))
          (Classical.propDecidable _)
        (edrinParentPairRow q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) e B) 0) =
      regWin (q * (h / primeSetProduct d) * primeSetProduct d) (h / primeSetProduct d)
        (fixedQLowWeight q (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d)) Z R h ((h / primeSetProduct d) ^ 2 / 4) := by
  set H := h / primeSetProduct d with hHdef
  set A := decoratedReducedAnchor q a (primeSetProduct d)
  set F := q * H * primeSetProduct d with hFdef
  set w := fixedQLowWeight q A H
  set U := H ^ 2 / 4
  have hdP : ∀ p ∈ d, p.Prime := fun p hp => (mem_decorated (hd hp)).1
  have hdpos : 0 < primeSetProduct d := primeSetProduct_pos' hdP
  have hd_dvd : primeSetProduct d ∣ h := by
    unfold primeSetProduct
    apply Finset.prod_primes_dvd
    · intro p hp; exact (hdP p hp).prime
    · intro p hp; exact (mem_decorated (hd hp)).2.1
  have hH : 0 < H := Nat.div_pos (Nat.le_of_dvd hh hd_dvd) hdpos
  -- membership in parents
  have hE : ∀ e, e ∈ edrinR0051QuarterParents Z q h H d (H ^ 2 + 1) ↔
      (∀ p ∈ e, p < H ^ 2 + 1 ∧ p.Prime ∧ allowedP F p) ∧
        Z h < primeSetProduct e ∧ 4 * primeSetProduct e ≤ H ^ 2 := by
    intro e
    unfold edrinR0051QuarterParents thalenActiveOrdinaryFiniteSupport
    rw [mem_filter, mem_powerset]
    constructor
    · rintro ⟨hsub, h1, h2⟩
      refine ⟨fun p hp => ?_, h1, h2⟩
      have := hsub hp
      rw [mem_filter, mem_range] at this
      obtain ⟨hlt, ⟨hpp, h5, hpq⟩, hpH, hpd⟩ := this
      exact ⟨hlt, hpp, (allowed_slice_iff hdP hq hH hpp).mpr ⟨⟨h5, hpq⟩, hpH, hpd⟩⟩
    · rintro ⟨hall, h1, h2⟩
      refine ⟨fun p hp => ?_, h1, h2⟩
      obtain ⟨hlt, hpp, hal⟩ := hall p hp
      have := (allowed_slice_iff hdP hq hH hpp).mp hal
      rw [mem_filter, mem_range]
      exact ⟨hlt, ⟨hpp, this.1.1, this.1.2⟩, this.2.1, this.2.2⟩
  have hBmem : ∀ e B : Finset ℕ, B ∈ ((e.powerset.erase e).erase ∅) ↔ B ⊆ e ∧ B ≠ e ∧ B ≠ ∅ := by
    intro e B
    rw [mem_erase, mem_erase, mem_powerset]
    tauto
  -- weight identity
  have hweight : ∀ e B : Finset ℕ, (∀ p ∈ e, p.Prime ∧ allowedP F p) → B ⊆ e →
      bW F (primeSetProduct B) * bW (F * primeSetProduct B) (primeSetProduct (e \ B)) =
        finiteOmegaWeightReal e := by
    intro e B he hB
    have hBp : ∀ p ∈ B, p.Prime ∧ allowedP F p := fun p hp => he p (hB hp)
    have hCp : ∀ p ∈ e \ B, p.Prime ∧ allowedP F p := fun p hp => he p (mem_sdiff.mp hp).1
    rw [bW_mul_left F (primeSetProduct B), if_pos (coprime_primeSetProduct_disjoint (fun p hp => (hBp p hp).1)
      (fun p hp => (hCp p hp).1) disjoint_sdiff)]
    unfold primeSetProduct finiteOmegaWeightReal
    rw [bW_prod_primes F hBp, bW_prod_primes F hCp, mul_comm, prod_sdiff hB]
  -- reorganize both sides as single sums
  rw [sum_sigma']
  unfold regWin
  rw [← sum_product']
  apply Finset.sum_bij_ne_zero (fun x _ _ => (primeSetProduct x.2, primeSetProduct (x.1 \ x.2)))
  · -- lands in the box
    rintro ⟨e, B⟩ hx hf
    rw [mem_sigma] at hx
    dsimp only at hx
    obtain ⟨he, hB⟩ := hx
    rw [hE] at he
    rw [hBmem] at hB
    have hep : ∀ p ∈ e, p.Prime := fun p hp => (he.1 p hp).2.1
    have hmul := primeSetProduct_sdiff_mul hB.1
    have h1 := primeSetProduct_pos' (fun p hp => hep p (hB.1 hp))
    have h2 := primeSetProduct_pos' (s := e \ B) (fun p hp => hep p (mem_sdiff.mp hp).1)
    have hU : primeSetProduct e ≤ U := by
      show primeSetProduct e ≤ H ^ 2 / 4
      rw [Nat.le_div_iff_mul_le (by norm_num)]; linarith [he.2.2]
    rw [mem_product, mem_Icc, mem_Icc]
    refine ⟨⟨h1, ?_⟩, ⟨h2, ?_⟩⟩
    · calc primeSetProduct B ≤ primeSetProduct B * primeSetProduct (e \ B) :=
            Nat.le_mul_of_pos_right _ h2
        _ ≤ U := hmul ▸ hU
    · calc primeSetProduct (e \ B) ≤ primeSetProduct B * primeSetProduct (e \ B) :=
            Nat.le_mul_of_pos_left _ h1
        _ ≤ U := hmul ▸ hU
  · -- injective
    rintro ⟨e1, B1⟩ hx1 _ ⟨e2, B2⟩ hx2 _ heq
    rw [mem_sigma, hE, hBmem] at hx1 hx2
    dsimp only at hx1 hx2
    simp only [Prod.mk.injEq] at heq
    have hp1 : ∀ p ∈ e1, p.Prime := fun p hp => (hx1.1.1 p hp).2.1
    have hp2 : ∀ p ∈ e2, p.Prime := fun p hp => (hx2.1.1 p hp).2.1
    have hB : B1 = B2 := by
      have := congrArg Nat.primeFactors heq.1
      unfold primeSetProduct at this
      rwa [Nat.primeFactors_prod (fun p hp => hp1 p (hx1.2.1 hp)),
        Nat.primeFactors_prod (fun p hp => hp2 p (hx2.2.1 hp))] at this
    have hC : e1 \ B1 = e2 \ B2 := by
      have := congrArg Nat.primeFactors heq.2
      unfold primeSetProduct at this
      rwa [Nat.primeFactors_prod (fun p hp => hp1 p (mem_sdiff.mp hp).1),
        Nat.primeFactors_prod (fun p hp => hp2 p (mem_sdiff.mp hp).1)] at this
    have he : e1 = e2 := by
      rw [← union_sdiff_of_subset hx1.2.1, ← union_sdiff_of_subset hx2.2.1, hC, hB]
    subst he; subst hB; rfl
  · -- surjective onto the nonzero terms
    rintro ⟨r, s⟩ hrs hg
    rw [mem_product, mem_Icc, mem_Icc] at hrs
    simp only at hg
    have hc : regC Z R h H U r s := by by_contra hc; exact hg (if_neg hc)
    rw [if_pos hc] at hg
    unfold pairTerm at hg
    have hrW : bW F r ≠ 0 := fun h0 => hg (by rw [h0]; ring)
    have hsW' : bW (F * r) s ≠ 0 := fun h0 => hg (by rw [h0]; ring)
    obtain ⟨hsW, hcop⟩ := bW_mul_ne_zero hsW'
    obtain ⟨hr0, hrsq, hrall⟩ := bW_ne_zero_imp hrW
    obtain ⟨hs0, hssq, hsall⟩ := bW_ne_zero_imp hsW
    have hrprod : primeSetProduct r.primeFactors = r := Nat.prod_primeFactors_of_squarefree hrsq
    have hsprod : primeSetProduct s.primeFactors = s := Nat.prod_primeFactors_of_squarefree hssq
    have hdisj : Disjoint r.primeFactors s.primeFactors := hcop.disjoint_primeFactors
    have hsd : (r.primeFactors ∪ s.primeFactors) \ r.primeFactors = s.primeFactors := by
      rw [union_sdiff_left, sdiff_eq_self_of_disjoint hdisj.symm]
    have heprod : primeSetProduct (r.primeFactors ∪ s.primeFactors) = r * s := by
      unfold primeSetProduct at hrprod hsprod ⊢
      rw [prod_union hdisj, hrprod, hsprod]
    obtain ⟨hr1, hs1, hT, hUb, hRrs⟩ := hc
    have hmemE : r.primeFactors ∪ s.primeFactors ∈
        edrinR0051QuarterParents Z q h H d (H ^ 2 + 1) := by
      rw [hE]
      refine ⟨fun p hp => ?_, ?_, ?_⟩
      · have hpp : p.Prime := by
          rcases mem_union.mp hp with h' | h'
          · exact Nat.prime_of_mem_primeFactors h'
          · exact Nat.prime_of_mem_primeFactors h'
        have hal : allowedP F p := by
          rcases mem_union.mp hp with h' | h'
          · exact hrall p h'
          · exact hsall p h'
        have hle : p ≤ r * s := by
          rcases mem_union.mp hp with h' | h'
          · exact (Nat.le_of_dvd hr0.bot_lt (Nat.dvd_of_mem_primeFactors h')).trans
              (Nat.le_mul_of_pos_right _ hs0.bot_lt)
          · exact (Nat.le_of_dvd hs0.bot_lt (Nat.dvd_of_mem_primeFactors h')).trans
              (Nat.le_mul_of_pos_left _ hr0.bot_lt)
        have : U ≤ H ^ 2 := Nat.div_le_self _ _
        exact ⟨by omega, hpp, hal⟩
      · rw [heprod]; exact hT
      · rw [heprod]
        have := (Nat.le_div_iff_mul_le (by norm_num : 0 < 4)).mp hUb
        linarith
    have hBm : r.primeFactors ∈ (((r.primeFactors ∪ s.primeFactors).powerset.erase
        (r.primeFactors ∪ s.primeFactors)).erase ∅) := by
      rw [hBmem]
      refine ⟨subset_union_left, ?_, ?_⟩
      · intro heq
        have hne : s.primeFactors.Nonempty := Nat.nonempty_primeFactors.mpr hs1
        obtain ⟨p, hp⟩ := hne
        have : p ∈ r.primeFactors := heq ▸ mem_union_right _ hp
        exact disjoint_left.mp hdisj this hp
      · intro h0
        have hne : r.primeFactors.Nonempty := Nat.nonempty_primeFactors.mpr hr1
        rw [h0] at hne; exact not_nonempty_empty hne
    refine ⟨⟨r.primeFactors ∪ s.primeFactors, r.primeFactors⟩, mem_sigma.mpr ⟨hmemE, hBm⟩, ?_, ?_⟩
    · simp only
      have hup : R h H (primeSetProduct r.primeFactors)
          (primeSetProduct ((r.primeFactors ∪ s.primeFactors) \ r.primeFactors)) := by
        rw [hsd, hrprod, hsprod]; exact hRrs
      rw [if_pos hup]
      unfold edrinParentPairRow
      rw [hsd, hrprod, hsprod]
      have hall : ∀ p ∈ r.primeFactors ∪ s.primeFactors, p.Prime ∧ allowedP F p := by
        intro p hp
        rcases mem_union.mp hp with h' | h'
        · exact ⟨Nat.prime_of_mem_primeFactors h', hrall p h'⟩
        · exact ⟨Nat.prime_of_mem_primeFactors h', hsall p h'⟩
      have hw := hweight _ _ hall subset_union_left
      rw [hsd, hrprod, hsprod] at hw
      rw [← hw]
      show bW F r * bW (F * r) s * rowDisc w H r s ≠ 0
      exact hg
    · simp only [Prod.mk.injEq]
      rw [hsd, hrprod, hsprod]; exact ⟨rfl, rfl⟩
  · -- values agree
    rintro ⟨e, B⟩ hx hf
    rw [mem_sigma, hE, hBmem] at hx
    dsimp only at hx hf
    simp only
    have hup : R h H (primeSetProduct B) (primeSetProduct (e \ B)) := by
      by_contra hu; exact hf (if_neg hu)
    rw [if_pos hup]
    have hep : ∀ p ∈ e, p.Prime := fun p hp => (hx.1.1 p hp).2.1
    have hBne : B.Nonempty := nonempty_iff_ne_empty.mpr hx.2.2.2
    have hCne : (e \ B).Nonempty := by
      rw [sdiff_nonempty]
      intro hsub; exact hx.2.2.1 (Subset.antisymm hx.2.1 hsub)
    have hmul := primeSetProduct_sdiff_mul hx.2.1
    have hwin : regC Z R h H U (primeSetProduct B) (primeSetProduct (e \ B)) := by
      refine ⟨one_lt_primeSetProduct (fun p hp => hep p (hx.2.1 hp)) hBne,
        one_lt_primeSetProduct (fun p hp => hep p (mem_sdiff.mp hp).1) hCne, ?_, ?_, hup⟩
      · rw [hmul]; exact hx.1.2.1
      · show _ ≤ H ^ 2 / 4
        rw [hmul, Nat.le_div_iff_mul_le (by norm_num)]; linarith [hx.1.2.2]
    rw [if_pos hwin]
    unfold edrinParentPairRow pairTerm
    rw [hweight e B (fun p hp => ⟨(hx.1.1 p hp).2.1, (hx.1.1 p hp).2.2⟩) hx.2.1]
    rfl

end

end OrielUpper
