import PaperB.FixedQ.SourceBridge
import PaperB.FixedQ.OneDimensionalBracket
import PaperB.FixedQ.PrincipalOneDimensionalCancellation
import PaperB.FixedQ.TwoDimensionalClosure
import PaperB.FixedQ.DecoratedTerminalSpine

/-!
# Paper B closure root

Source binding:
* canonical manuscript:
  `paper_b_frozen.canonical.tex`
* frozen source SHA-256:
  `9004c20d63218b529ea392d13914c17a347c485fd43814eb88bf8612a8512070`
* public theorem:
  `thm:fixed-q` / `eq:main-theorem`

This file is intentionally a minimal staging root.  It states the exact
manuscript-facing terminal proposition but does not claim it proved until the
final assembly is actually wired.

Manuscript theorem:
for every fixed squarefree q, uniformly over compatible admissible reduced
endpoint pairs (a,b),

  A_{1,q}(a,b;h) - B_{1,q}(a,b;h) = o_q(log h)

as h tends to infinity through positive compatible heights.

The epsilon form below gives the threshold to fixed q and epsilon only; it is
uniform in the finitely many endpoint residue pairs.
-/

open scoped BigOperators

namespace PaperB.Closure

open PaperB.FixedQ

/-- Canonical natural representative of the residue class `-b (mod q)`. -/
def reflectedResidue (q b : ℕ) : ℕ :=
  (q - b % q) % q

lemma reflectedResidue_lt
    {q b : ℕ} (hq : 0 < q) :
    reflectedResidue q b < q := by
  unfold reflectedResidue
  exact Nat.mod_lt _ hq

lemma coprime_reflectedResidue
    {q b : ℕ} (hq : 0 < q) (hb : q.Coprime b) :
    q.Coprime (reflectedResidue q b) := by
  have hrlt : b % q < q := Nat.mod_lt b hq
  have hrle : b % q ≤ q := Nat.le_of_lt hrlt
  have hr : (b % q).Coprime q :=
    (ZMod.coprime_mod_iff_coprime b q).2 hb.symm
  have hsub : (q - b % q).Coprime q :=
    (Nat.coprime_self_sub_left hrle).2 hr
  have hmod : ((q - b % q) % q).Coprime q :=
    (ZMod.coprime_mod_iff_coprime (q - b % q) q).2 hsub
  exact hmod.symm

private lemma dvd_add_reflectedResidue
    {q b : ℕ} (hq : 0 < q) :
    q ∣ b + reflectedResidue q b := by
  rw [Nat.dvd_iff_mod_eq_zero]
  unfold reflectedResidue
  rw [Nat.add_mod]
  by_cases hs : b % q = 0
  · simp [hs]
  · have hslt : b % q < q := Nat.mod_lt b hq
    have hsub_lt : q - b % q < q := by omega
    simp only [Nat.mod_eq_of_lt hsub_lt]
    have hsum : b % q + (q - b % q) = q := by omega
    rw [hsum, Nat.mod_self]

private lemma coprime_right_of_add_dvd
    {q x y : ℕ} (h : q ∣ x + y) (hx : q.Coprime x) :
    q.Coprime y := by
  rw [Nat.coprime_iff_gcd_eq_one]
  have hdq : q.gcd y ∣ q := Nat.gcd_dvd_left q y
  have hdy : q.gcd y ∣ y := Nat.gcd_dvd_right q y
  have hdsum : q.gcd y ∣ x + y := hdq.trans h
  have hdx : q.gcd y ∣ x := (Nat.dvd_add_iff_left hdy).2 hdsum
  have hdg : q.gcd y ∣ q.gcd x := Nat.dvd_gcd hdq hdx
  rw [hx.gcd_eq_one] at hdg
  exact Nat.dvd_one.mp hdg

private lemma coprime_right_iff_of_add_dvd
    {q x y : ℕ} (h : q ∣ x + y) :
    q.Coprime x ↔ q.Coprime y := by
  constructor
  · exact coprime_right_of_add_dvd h
  · intro hy
    have h' : q ∣ y + x := by simpa [Nat.add_comm] using h
    exact coprime_right_of_add_dvd h' hy

lemma reflected_coprime_equiv
    {q a b h : ℕ} (hq : 0 < q)
    (hcompat : Nat.ModEq q (a + h) b) :
    ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔
        q.Coprime (reflectedResidue q b + z) := by
  intro z hz
  have hzI := Finset.mem_Ioo.mp hz
  have hdbr : q ∣ b + reflectedResidue q b :=
    dvd_add_reflectedResidue hq
  have hbr0 : Nat.ModEq q (b + reflectedResidue q b) 0 :=
    Nat.modEq_zero_iff_dvd.mpr hdbr
  have har0 : Nat.ModEq q ((a + h) + reflectedResidue q b) 0 :=
    (hcompat.add_right (reflectedResidue q b)).trans hbr0
  have hdahr : q ∣ (a + h) + reflectedResidue q b :=
    Nat.modEq_zero_iff_dvd.mp har0
  have hsumEq :
      (a + (h - z)) + (reflectedResidue q b + z) =
        (a + h) + reflectedResidue q b := by
    omega
  have hsumDvd :
      q ∣ (a + (h - z)) + (reflectedResidue q b + z) := by
    rw [hsumEq]
    exact hdahr
  exact coprime_right_iff_of_add_dvd hsumDvd

lemma admissibleInteriorCount_reflected
    {q a b h : ℕ} (hq : 0 < q)
    (hcompat : Nat.ModEq q (a + h) b) :
    admissibleInteriorCount q a h =
      admissibleInteriorCount q (reflectedResidue q b) h := by
  exact admissibleInteriorCount_reflect_of_coprime
    (reflected_coprime_equiv hq hcompat)

lemma fixedQRowDelta_reflected
    {q a b h e1 e2 : ℕ} (hq : 0 < q)
    (hcompat : Nat.ModEq q (a + h) b) :
    fixedQRowDelta q a h e1 e2 =
      fixedQRowDelta q (reflectedResidue q b) h e2 e1 := by
  exact fixedQRowDelta_reflect_of_coprime
    (reflected_coprime_equiv hq hcompat)

/-- Frozen-paper `Delta^F_{q,r}(h;e)` from `eq:exact-Sq`.

This is the exact free one-anchor constrained mass centered by the exact
admissible interior count, not by an asymptotic density replacement. -/
noncomputable def manuscriptFreeBoundaryDelta
    (q r h e : ℕ) : ℝ :=
  rowConstrainedMass (freeFixedQLowWeight q r) h e 1 -
    (admissibleInteriorCount q r h : ℝ) / (e : ℝ)

/-- Frozen-paper `S_{q,r}(h)` from `eq:Sqa` / `eq:exact-Sq`,
represented by its exact high-prime Euler expansion. -/
noncomputable def manuscriptS1Kernel
    (q r h : ℕ) : ℝ :=
  freeHighBaseline q *
    ∑' e : ℕ,
      etaCoeff q e * manuscriptFreeBoundaryDelta q r h e

/-- Frozen-paper `B_{1,q}(a,b;h)`.

By `eq:B1q-simple` and the exact reflection `eq:reflection-q`,
`B_{1,q} = S_{q,a} + S_{q,-b}`. -/
noncomputable def manuscriptB1Kernel
    (q a b h : ℕ) : ℝ :=
  manuscriptS1Kernel q a h +
    manuscriptS1Kernel q (reflectedResidue q b) h

/-- Exact manuscript-facing terminal proposition, in epsilon form.

Source: `thm:fixed-q` / `eq:main-theorem`.

* q is fixed, positive, squarefree;
* a,b are reduced endpoint representatives;
* `a+h = b (mod q)` is the compatible-height condition;
* `¬ 2 ∣ q -> 2 ∣ h` is the exact level-one endpoint-admissibility
  condition used by the source bridge;
* h is positive;
* the eventual threshold depends only on q and epsilon, hence is uniform in
  the compatible admissible endpoint pair.
-/
def PaperBTerminalStatement : Prop :=
  ∀ q : ℕ,
    0 < q →
    Squarefree q →
    ∀ ε : ℝ, 0 < ε →
      ∃ h0 : ℕ,
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          h0 ≤ h →
          |manuscriptA1Kernel q a h -
              manuscriptB1Kernel q a b h| ≤
            ε * Real.log (h : ℝ)

/-- Exact consumer contract for Quoin's completed one-dimensional bracket
assembly.  Both manuscript boundary families are required under one uniform
threshold, with the exact fixed-q normalization used by the divisor expansion. -/
def OneDimensionalBracketsContract : Prop :=
  ∀ q : ℕ,
    0 < q →
    Squarefree q →
    ∀ ε : ℝ, 0 < ε →
      ∃ h0 : ℕ,
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          h0 ≤ h →
          |cStarReal q h * pureLeftFamily q a h -
              manuscriptS1Kernel q a h| ≤
            ε * Real.log (h : ℝ) ∧
          |cStarReal q h * heightBoundaryFamily q a h -
              manuscriptS1Kernel q (reflectedResidue q b) h| ≤
            ε * Real.log (h : ℝ)

lemma exists_nat_threshold_const_le_eps_log
    {B ε : ℝ} (_hB : 0 ≤ B) (hε : 0 < ε) :
    ∃ h0 : ℕ, ∀ h : ℕ, h0 ≤ h → B ≤ ε * Real.log (h : ℝ) := by
  obtain ⟨h0, hh0⟩ := exists_nat_gt (Real.exp (B / ε))
  refine ⟨h0, ?_⟩
  intro h hlarge
  have hexp_lt_h0 : Real.exp (B / ε) < (h0 : ℝ) := by
    exact_mod_cast hh0
  have hh0_le_h : (h0 : ℝ) ≤ (h : ℝ) := by exact_mod_cast hlarge
  have hexp_lt_h : Real.exp (B / ε) < (h : ℝ) :=
    lt_of_lt_of_le hexp_lt_h0 hh0_le_h
  have hhpos : 0 < (h : ℝ) := lt_trans (Real.exp_pos _) hexp_lt_h
  have hlog : B / ε < Real.log (h : ℝ) := by
    have hlogexp : Real.log (Real.exp (B / ε)) = B / ε := Real.log_exp _
    rw [← hlogexp]
    exact Real.strictMonoOn_log (Real.exp_pos _) hhpos hexp_lt_h
  have hmul := mul_lt_mul_of_pos_left hlog hε
  have hεne : ε ≠ 0 := ne_of_gt hε
  exact le_of_lt (by
    calc
      B = ε * (B / ε) := by field_simp [hεne]
      _ < ε * Real.log (h : ℝ) := hmul)

/-- The genuinely analytic ordinary 2D target after the exact periodic-density
correction has been removed. -/
def OrdinaryBooleanCoreContract : Prop :=
  ∀ q : ℕ,
    0 < q →
    Squarefree q →
    ∀ ε : ℝ, 0 < ε →
      ∃ h0 : ℕ,
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          h0 ≤ h →
          |cStarReal q h * ordinaryBooleanCore q a h| ≤
            ε * Real.log (h : ℝ)

/-- Exact terminal target for the ordinary, undecorated two-dimensional
family. -/
def OrdinaryTwoDimensionalContract : Prop :=
  ∀ q : ℕ,
    0 < q →
    Squarefree q →
    ∀ ε : ℝ, 0 < ε →
      ∃ h0 : ℕ,
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          h0 ≤ h →
          |cStarReal q h * ordinaryTwoDimensionalRemainder q a h| ≤
            ε * Real.log (h : ℝ)

theorem ordinaryTwoDimensionalContract_of_booleanCore
    (hBoolean : OrdinaryBooleanCoreContract) :
    OrdinaryTwoDimensionalContract := by
  intro q hq hsq ε hε
  let δ : ℝ := ε / 2
  have hδ : 0 < δ := by
    dsimp [δ]
    positivity
  obtain ⟨hB, hBspec⟩ := hBoolean q hq hsq δ hδ
  have hC0 : 0 ≤ fixedQDensityDefectUniformBound q := by
    unfold fixedQDensityDefectUniformBound
    positivity
  obtain ⟨hC, hCspec⟩ :=
    exists_nat_threshold_const_le_eps_log hC0 hδ
  refine ⟨max hB hC, ?_⟩
  intro a b h ha hb hcompat h2admissible hh hlarge
  have hBh : hB ≤ h := (le_max_left hB hC).trans hlarge
  have hCh : hC ≤ h := (le_max_right hB hC).trans hlarge
  have hBest := hBspec a b h ha hb hcompat h2admissible hh hBh
  have hCest := hCspec h hCh
  have hreflect := reflected_coprime_equiv hq hcompat
  rw [ordinaryTwoDimensionalRemainder_eq_cores hq hh h2admissible hreflect]
  rw [mul_add]
  calc
    |cStarReal q h * ordinaryBooleanCore q a h +
        cStarReal q h * ordinaryDensityCore q a h| ≤
      |cStarReal q h * ordinaryBooleanCore q a h| +
        |cStarReal q h * ordinaryDensityCore q a h| := abs_add_le _ _
    _ ≤ δ * Real.log (h : ℝ) + fixedQDensityDefectUniformBound q := by
      exact add_le_add hBest
        (abs_cStar_mul_ordinaryDensityCore_le hq hh h2admissible)
    _ ≤ δ * Real.log (h : ℝ) + δ * Real.log (h : ℝ) := by
      exact add_le_add (le_refl _) hCest
    _ = ε * Real.log (h : ℝ) := by
      dsimp [δ]
      ring

/-- Exact terminal target for the decorated two-dimensional family. -/
def DecoratedTwoDimensionalContract : Prop :=
  ∀ q : ℕ,
    0 < q →
    Squarefree q →
    ∀ ε : ℝ, 0 < ε →
      ∃ h0 : ℕ,
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          h0 ≤ h →
          |cStarReal q h * decoratedTwoDimensionalRemainder q a h| ≤
            ε * Real.log (h : ℝ)

/-- Consumer-facing analytic branch of the decorated two-dimensional remainder. -/
def DecoratedAnalyticContract : Prop :=
  ∀ q : ℕ,
    0 < q →
    Squarefree q →
    ∀ ε : ℝ, 0 < ε →
      ∃ h0 : ℕ,
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          h0 ≤ h →
          |cStarReal q h * decoratedAnalyticRemainder q a h| ≤
            ε * Real.log (h : ℝ)

/-- Consumer-facing density branch of the decorated two-dimensional remainder. -/
def DecoratedDensityContract : Prop :=
  ∀ q : ℕ,
    0 < q →
    Squarefree q →
    ∀ ε : ℝ, 0 < ε →
      ∃ h0 : ℕ,
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          h0 ≤ h →
          |cStarReal q h * decoratedDensityRemainder q a h| ≤
            ε * Real.log (h : ℝ)


theorem decoratedDensityContract :
    DecoratedDensityContract := by
  intro q hq hsq ε hε
  obtain ⟨h0, hspec⟩ :=
    decoratedDensityRemainder_sublog q hq ε hε
  refine ⟨h0, ?_⟩
  intro a b h ha hb hcompat h2admissible hh hlarge
  exact hspec a h h2admissible hh hlarge


theorem decoratedTwoDimensionalContract_of_analytic_density
    (hAnalytic : DecoratedAnalyticContract)
    (hDensity : DecoratedDensityContract) :
    DecoratedTwoDimensionalContract := by
  intro q hq hsq ε hε
  let δ : ℝ := ε / 2
  have hδ : 0 < δ := by
    dsimp [δ]
    positivity
  obtain ⟨hA, hAspec⟩ := hAnalytic q hq hsq δ hδ
  obtain ⟨hD, hDspec⟩ := hDensity q hq hsq δ hδ
  refine ⟨max hA hD, ?_⟩
  intro a b h ha hb hcompat h2admissible hh hlarge
  have hAh : hA ≤ h := (le_max_left hA hD).trans hlarge
  have hDh : hD ≤ h := (le_max_right hA hD).trans hlarge
  have hAest := hAspec a b h ha hb hcompat h2admissible hh hAh
  have hDest := hDspec a b h ha hb hcompat h2admissible hh hDh
  have hreflect := reflected_coprime_equiv hq hcompat
  rw [decoratedTwoDimensionalRemainder_eq_analytic_add_density
    hq hh h2admissible hreflect]
  rw [mul_add]
  calc
    |cStarReal q h * decoratedAnalyticRemainder q a h +
        cStarReal q h * decoratedDensityRemainder q a h| ≤
      |cStarReal q h * decoratedAnalyticRemainder q a h| +
        |cStarReal q h * decoratedDensityRemainder q a h| :=
          abs_add_le _ _
    _ ≤ δ * Real.log (h : ℝ) + δ * Real.log (h : ℝ) :=
          add_le_add hAest hDest
    _ = ε * Real.log (h : ℝ) := by
          dsimp [δ]
          ring

/-- Exact terminal target for the ordinary plus decorated two-dimensional
families after the two one-dimensional boundary families have been removed. -/
def TwoDimensionalRemainderContract : Prop :=
  ∀ q : ℕ,
    0 < q →
    Squarefree q →
    ∀ ε : ℝ, 0 < ε →
      ∃ h0 : ℕ,
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          h0 ≤ h →
          |cStarReal q h * twoDimensionalFamilyRemainder q a h| ≤
            ε * Real.log (h : ℝ)

theorem twoDimensionalRemainderContract_of_parts
    (hOrdinary : OrdinaryTwoDimensionalContract)
    (hDecorated : DecoratedTwoDimensionalContract) :
    TwoDimensionalRemainderContract := by
  intro q hq hsq ε hε
  let δ : ℝ := ε / 2
  have hδ : 0 < δ := by
    dsimp [δ]
    positivity
  obtain ⟨hO, hOspec⟩ := hOrdinary q hq hsq δ hδ
  obtain ⟨hD, hDspec⟩ := hDecorated q hq hsq δ hδ
  refine ⟨max hO hD, ?_⟩
  intro a b h ha hb hcompat h2admissible hh hlarge
  have hOh : hO ≤ h := (le_max_left hO hD).trans hlarge
  have hDh : hD ≤ h := (le_max_right hO hD).trans hlarge
  have hOest := hOspec a b h ha hb hcompat h2admissible hh hOh
  have hDest := hDspec a b h ha hb hcompat h2admissible hh hDh
  have hreflect := reflected_coprime_equiv hq hcompat
  rw [twoDimensionalFamilyRemainder_eq_ordinary_add_decorated hreflect]
  rw [mul_add]
  calc
    |cStarReal q h * ordinaryTwoDimensionalRemainder q a h +
        cStarReal q h * decoratedTwoDimensionalRemainder q a h| ≤
      |cStarReal q h * ordinaryTwoDimensionalRemainder q a h| +
        |cStarReal q h * decoratedTwoDimensionalRemainder q a h| :=
          abs_add_le _ _
    _ ≤ δ * Real.log (h : ℝ) + δ * Real.log (h : ℝ) :=
          add_le_add hOest hDest
    _ = ε * Real.log (h : ℝ) := by
          dsimp [δ]
          ring

/-- Once the one-dimensional bracket contract and the genuinely
 two-dimensional remainder contract are delivered, the exact manuscript
 theorem is a triangle-inequality assembly with no further mathematics. -/
theorem paperBTerminal_of_contracts
    (hBracket : OneDimensionalBracketsContract)
    (hTwoDim : TwoDimensionalRemainderContract) :
    PaperBTerminalStatement := by
  intro q hq hsq ε hε
  let δ : ℝ := ε / 3
  have hδ : 0 < δ := by
    dsimp [δ]
    positivity
  obtain ⟨hB, hBspec⟩ := hBracket q hq hsq δ hδ
  obtain ⟨hD, hDspec⟩ := hTwoDim q hq hsq δ hδ
  refine ⟨max hB hD, ?_⟩
  intro a b h ha hb hcompat h2admissible hh hlarge
  have hBh : hB ≤ h := (le_max_left hB hD).trans hlarge
  have hDh : hD ≤ h := (le_max_right hB hD).trans hlarge
  obtain ⟨hleft, hright⟩ :=
    hBspec a b h ha hb hcompat h2admissible hh hBh
  have htwo :=
    hDspec a b h ha hb hcompat h2admissible hh hDh
  have hA := manuscriptA1Kernel_eq_boundary_families_add_twoDimensional
    (q := q) (a := a) (h := h) h2admissible
  unfold manuscriptB1Kernel
  rw [hA]
  have hdecomp :
      cStarReal q h *
          (pureLeftFamily q a h +
            heightBoundaryFamily q a h +
            twoDimensionalFamilyRemainder q a h) -
          (manuscriptS1Kernel q a h +
            manuscriptS1Kernel q (reflectedResidue q b) h) =
        (cStarReal q h * pureLeftFamily q a h -
          manuscriptS1Kernel q a h) +
        (cStarReal q h * heightBoundaryFamily q a h -
          manuscriptS1Kernel q (reflectedResidue q b) h) +
        cStarReal q h * twoDimensionalFamilyRemainder q a h := by
    ring
  rw [hdecomp]
  calc
    |(cStarReal q h * pureLeftFamily q a h -
          manuscriptS1Kernel q a h) +
        (cStarReal q h * heightBoundaryFamily q a h -
          manuscriptS1Kernel q (reflectedResidue q b) h) +
        cStarReal q h * twoDimensionalFamilyRemainder q a h|
      ≤ |cStarReal q h * pureLeftFamily q a h -
          manuscriptS1Kernel q a h| +
        |cStarReal q h * heightBoundaryFamily q a h -
          manuscriptS1Kernel q (reflectedResidue q b) h| +
        |cStarReal q h * twoDimensionalFamilyRemainder q a h| := by
          exact (abs_add_le
            ((cStarReal q h * pureLeftFamily q a h -
              manuscriptS1Kernel q a h) +
              (cStarReal q h * heightBoundaryFamily q a h -
                manuscriptS1Kernel q (reflectedResidue q b) h))
            (cStarReal q h * twoDimensionalFamilyRemainder q a h)).trans
            (add_le_add
              (abs_add_le
                (cStarReal q h * pureLeftFamily q a h -
                  manuscriptS1Kernel q a h)
                (cStarReal q h * heightBoundaryFamily q a h -
                  manuscriptS1Kernel q (reflectedResidue q b) h))
              (le_refl _))
    _ ≤ δ * Real.log (h : ℝ) +
          δ * Real.log (h : ℝ) +
          δ * Real.log (h : ℝ) := by
          exact add_le_add (add_le_add hleft hright) htwo
    _ = ε * Real.log (h : ℝ) := by
          dsimp [δ]
          ring

theorem paperBTerminal_of_split_contracts
    (hBracket : OneDimensionalBracketsContract)
    (hOrdinary : OrdinaryTwoDimensionalContract)
    (hDecorated : DecoratedTwoDimensionalContract) :
    PaperBTerminalStatement :=
  paperBTerminal_of_contracts hBracket
    (twoDimensionalRemainderContract_of_parts hOrdinary hDecorated)

theorem paperBTerminal_of_reduced_contracts
    (hBracket : OneDimensionalBracketsContract)
    (hBoolean : OrdinaryBooleanCoreContract)
    (hDecorated : DecoratedTwoDimensionalContract) :
    PaperBTerminalStatement :=
  paperBTerminal_of_split_contracts hBracket
    (ordinaryTwoDimensionalContract_of_booleanCore hBoolean)
    hDecorated

#print axioms decoratedDensityContract
#print axioms decoratedTwoDimensionalContract_of_analytic_density
#print axioms ordinaryTwoDimensionalContract_of_booleanCore
#print axioms twoDimensionalRemainderContract_of_parts
#print axioms paperBTerminal_of_contracts
#print axioms paperBTerminal_of_split_contracts
#print axioms paperBTerminal_of_reduced_contracts

end PaperB.Closure
