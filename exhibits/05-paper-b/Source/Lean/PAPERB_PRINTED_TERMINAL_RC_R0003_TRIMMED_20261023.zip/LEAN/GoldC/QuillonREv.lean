import GoldC.QuillonCPhysical
import GoldC.QuillonREst

/-!
# Quillon CSC3 F8.11: parameters and eventual bounds for the R cell (fixed `r`)

**Parameters**, with `E = e^{Λ^{1/4}}` and `ε = Λ^{−1/200}`:
* `Lw_R(r) = ⌊r^{1+3ε}⌋ − 1`;
* `Kv(r) = log₂⌈r^ε⌉ + 1`, so that `X r^ε ≤ 2^{Kv}X ≤ 4X r^ε`;
* `Nb_R(r) = ⌊H/(E r)⌋`.

**Lemmas.**
* `R_exp_ev`: the VK saving `exp(−c L³/(2 L_max²)) ≤ Λ^{−200}` once `L ≥ 5Λ^{σ−1/200}` and `L_max ≤ 3Λ`.
  This uses `3σ − 2 − 3/200 = 0.015 > 0`.
* `R_diag_ev`: `128C·Sb(1+log Sb)/Ymin ≤ Λ^{−400}` when `Sb/Ymin ≤ M/E`.
* `R_combine`: the final real combination.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonREv

open GoldC.QuillonEv GoldC.QuillonSetup GoldC.QuillonLam GoldC.QuillonCEv GoldC.QuillonCFinal

noncomputable def LwR (h r : ℕ) : ℕ := ⌊(r : ℝ) ^ (1 + 3 * εp h)⌋₊ - 1
noncomputable def Kvp (h r : ℕ) : ℕ := Nat.log 2 ⌈(r : ℝ) ^ (εp h)⌉₊ + 1
noncomputable def Eh (h : ℕ) : ℝ := Real.exp ((Real.log h) ^ (1 / 4 : ℝ))
noncomputable def NbR (h H r : ℕ) : ℕ := ⌊(H : ℝ) / (Eh h * r)⌋₊

/-- the VK saving. -/
theorem R_exp_ev (c : ℝ) (hc : 0 < c) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ Λ : ℝ, Λ₀ ≤ Λ → ∀ L Lm : ℝ, 5 * Λ ^ (σ₀ - 1 / 200) ≤ L → 0 < Lm →
      Lm ≤ 3 * Λ → Real.exp (-(c * L ^ 3 / Lm ^ 2) / 2) ≤ Λ ^ (-(200 : ℝ)) := by
  have hτ : 0 < 3 * σ₀ - 3 / 200 - 2 := by unfold σ₀; norm_num
  obtain ⟨Λ₀, hΛ₀, hd⟩ := decay 0 200 (125 * c / 18) (3 * σ₀ - 3 / 200 - 2) (by norm_num) (by positivity) hτ
  refine ⟨max 2 Λ₀, le_max_left _ _, fun Λ hΛ L Lm hL hLm0 hLm => ?_⟩
  have hΛ2 : 2 ≤ Λ := le_trans (le_max_left _ _) hΛ
  have hΛ0 : 0 < Λ := by linarith
  have h1 := hd Λ (le_trans (le_max_right _ _) hΛ)
  rw [Real.rpow_zero, one_mul] at h1
  refine le_trans (Real.exp_le_exp.2 ?_) h1
  -- `c L³/Lm² ≥ (125c/9) Λ^τ`
  have hL0 : 0 ≤ 5 * Λ ^ (σ₀ - 1 / 200) := by positivity
  have hL3 : (5 * Λ ^ (σ₀ - 1 / 200)) ^ 3 ≤ L ^ 3 := pow_le_pow_left₀ hL0 hL 3
  have hLm2 : Lm ^ 2 ≤ (3 * Λ) ^ 2 := pow_le_pow_left₀ hLm0.le hLm 2
  have e1 : (5 * Λ ^ (σ₀ - 1 / 200)) ^ 3 = 125 * Λ ^ (3 * σ₀ - 3 / 200) := by
    rw [mul_pow, ← Real.rpow_natCast (Λ ^ (σ₀ - 1 / 200)) 3, ← Real.rpow_mul hΛ0.le]; norm_num; ring_nf
  have e2 : Λ ^ (3 * σ₀ - 3 / 200) = Λ ^ (3 * σ₀ - 3 / 200 - 2) * Λ ^ 2 := by
    rw [← Real.rpow_natCast, rp hΛ0]; norm_num
  have hkey : 125 * c / 18 * Λ ^ (3 * σ₀ - 3 / 200 - 2) ≤ c * L ^ 3 / Lm ^ 2 / 2 := by
    rw [le_div_iff₀ (by norm_num), le_div_iff₀ (by positivity)]
    have hp : 0 ≤ Λ ^ (3 * σ₀ - 3 / 200 - 2) := by positivity
    calc 125 * c / 18 * Λ ^ (3 * σ₀ - 3 / 200 - 2) * 2 * Lm ^ 2
        ≤ 125 * c / 18 * Λ ^ (3 * σ₀ - 3 / 200 - 2) * 2 * (3 * Λ) ^ 2 := by gcongr
      _ = c * (125 * (Λ ^ (3 * σ₀ - 3 / 200 - 2) * Λ ^ 2)) := by ring
      _ = c * (5 * Λ ^ (σ₀ - 1 / 200)) ^ 3 := by rw [e1, e2]
      _ ≤ c * L ^ 3 := by gcongr
  have : -(c * L ^ 3 / Lm ^ 2) / 2 = -(c * L ^ 3 / Lm ^ 2 / 2) := by ring
  rw [this]; linarith

/-- the near-diagonal term. -/
theorem R_diag_ev (K : ℝ) (hK : 0 ≤ K) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ Λ : ℝ, Λ₀ ≤ Λ → ∀ x : ℝ, 0 ≤ x →
      x ≤ K * Λ * Real.exp (-(Λ ^ (1 / 4 : ℝ))) → x ≤ Λ ^ (-(400 : ℝ)) := by
  obtain ⟨Λ₁, hΛ₁, hd⟩ := decay 1 401 1 (1 / 4) (by norm_num) (by norm_num) (by norm_num)
  obtain ⟨Λ₂, hΛ₂, hc⟩ := const_le_rpow K 1 one_pos
  refine ⟨max 2 (max Λ₁ Λ₂), le_max_left _ _, fun Λ hΛ x hx0 hx => ?_⟩
  have hΛ2 : 2 ≤ Λ := le_trans (le_max_left _ _) hΛ
  have hΛ0 : 0 < Λ := by linarith
  have h1 := hd Λ (le_trans (le_trans (le_max_left _ _) (le_max_right _ _)) hΛ)
  have h2 := hc Λ (le_trans (le_trans (le_max_right _ _) (le_max_right _ _)) hΛ)
  rw [one_mul] at h1
  rw [Real.rpow_one] at h1 h2
  calc x ≤ K * Λ * Real.exp (-(Λ ^ (1 / 4 : ℝ))) := hx
    _ = K * (Λ * Real.exp (-(Λ ^ (1 / 4 : ℝ)))) := by ring
    _ ≤ Λ * Λ ^ (-(401 : ℝ)) := by
        apply mul_le_mul h2 h1 (by positivity) hΛ0.le
    _ = Λ ^ (-(400 : ℝ)) := by
        rw [show Λ * Λ ^ (-(401 : ℝ)) = Λ ^ (1 : ℝ) * Λ ^ (-(401 : ℝ)) by rw [Real.rpow_one], rp hΛ0]
        norm_num

/-- the final real combination for one `RTerm`. -/
lemma R_combine (Λ Kf Cb F4 Aw Br WU Xi E : ℝ) (hΛ2 : 2 ≤ Λ) (hCb : 0 ≤ Cb) (hKf0 : 0 ≤ Kf)
    (hKf : Kf ≤ 18 * Λ ^ 2) (hF40 : 0 ≤ F4) (hF4 : F4 ≤ 2 * Λ) (hAw0 : 0 ≤ Aw) (hAw : Aw ≤ Λ)
    (hBr0 : 0 ≤ Br) (hBr : Br ≤ 3 * Λ ^ (-(100 : ℝ))) (hWU0 : 0 ≤ WU) (hWU : WU ≤ E * Λ ^ (10 : ℝ))
    (hXi0 : 0 ≤ Xi) (hXi : Xi ≤ 12.5 * Λ ^ (-(200 : ℝ))) (hE : 0 ≤ E)
    (hK : 18 * Cb * 2 * 3 + Cb * 2 * E * 12.5 ≤ Λ) :
    Kf * (Cb * F4) * Aw * Br + Cb * F4 * WU * Xi ≤ Λ ^ (-(90 : ℝ)) := by
  have hΛ1 : 1 ≤ Λ := by linarith
  have hΛ0 : 0 < Λ := by linarith
  have t1 : Kf * (Cb * F4) * Aw * Br ≤ (18 * Cb * 2 * 3) * Λ ^ (-(96 : ℝ)) := by
    calc Kf * (Cb * F4) * Aw * Br ≤ (18 * Λ ^ 2) * (Cb * (2 * Λ)) * Λ * (3 * Λ ^ (-(100 : ℝ))) := by
          gcongr
      _ = (18 * Cb * 2 * 3) * (Λ ^ (4 : ℕ) * Λ ^ (-(100 : ℝ))) := by ring
      _ = (18 * Cb * 2 * 3) * Λ ^ (-(96 : ℝ)) := by
          rw [mul_comm (Λ ^ (4 : ℕ)), GoldC.QuillonWFinal.rpow_shift hΛ0]; norm_num
  have t2 : Cb * F4 * WU * Xi ≤ (Cb * 2 * E * 12.5) * Λ ^ (-(96 : ℝ)) := by
    calc Cb * F4 * WU * Xi ≤ Cb * (2 * Λ) * (E * Λ ^ (10 : ℝ)) * (12.5 * Λ ^ (-(200 : ℝ))) := by gcongr
      _ = (Cb * 2 * E * 12.5) * (Λ ^ (1 : ℝ) * Λ ^ (10 : ℝ) * Λ ^ (-(200 : ℝ))) := by
          rw [Real.rpow_one]; ring
      _ = (Cb * 2 * E * 12.5) * Λ ^ (-(189 : ℝ)) := by rw [rp hΛ0, rp hΛ0]; norm_num
      _ ≤ (Cb * 2 * E * 12.5) * Λ ^ (-(96 : ℝ)) :=
          mul_le_mul_of_nonneg_left (Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)) (by positivity)
  have p96 : 0 ≤ Λ ^ (-(96 : ℝ)) := by positivity
  calc Kf * (Cb * F4) * Aw * Br + Cb * F4 * WU * Xi
      ≤ (18 * Cb * 2 * 3 + Cb * 2 * E * 12.5) * Λ ^ (-(96 : ℝ)) := by linarith
    _ ≤ Λ * Λ ^ (-(96 : ℝ)) := mul_le_mul_of_nonneg_right hK p96
    _ = Λ ^ (-(95 : ℝ)) := by
        rw [show Λ * Λ ^ (-(96 : ℝ)) = Λ ^ (1 : ℝ) * Λ ^ (-(96 : ℝ)) by rw [Real.rpow_one], rp hΛ0]
        norm_num
    _ ≤ Λ ^ (-(90 : ℝ)) := Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)


lemma natsub_ge (a b : ℕ) : (a : ℝ) - b ≤ ((a - b : ℕ) : ℝ) := by
  rcases le_total b a with h | h
  · rw [Nat.cast_sub h]
  · rw [Nat.sub_eq_zero_of_le h]; push_cast; linarith [(Nat.cast_le (α := ℝ)).2 h]

lemma Kv_bounds (ρ : ℝ) (hρ : 1 ≤ ρ) (Kv : ℕ) (hKv : Kv = Nat.log 2 ⌈ρ⌉₊ + 1) :
    ρ ≤ (2 : ℝ) ^ Kv ∧ (2 : ℝ) ^ Kv ≤ 4 * ρ := by
  set n := ⌈ρ⌉₊ with hn
  have hn1 : ρ ≤ n := Nat.le_ceil ρ
  have hn2 : (n : ℝ) < ρ + 1 := Nat.ceil_lt_add_one (by linarith)
  have hn0 : n ≠ 0 := by
    intro h0; rw [h0] at hn1; push_cast at hn1; linarith
  have h1 : n < 2 ^ Kv := by rw [hKv]; exact Nat.lt_pow_succ_log_self (by norm_num) n
  have h2 : 2 ^ (Kv - 1) ≤ n := by rw [hKv]; simpa using Nat.pow_log_le_self 2 hn0
  have hKv1 : 1 ≤ Kv := by omega
  constructor
  · have : (n : ℝ) < (2 : ℝ) ^ Kv := by exact_mod_cast h1
    linarith
  · have h2R : (2 : ℝ) ^ (Kv - 1) ≤ n := by exact_mod_cast h2
    have e : (2 : ℝ) ^ Kv = 2 * (2 : ℝ) ^ (Kv - 1) := by
      rw [← pow_succ']; congr 1; omega
    rw [e]; linarith

/-- the VK log lower bound: `ρ ≤ (⌊Lw/(2^{Kv}X)⌋ − Q)/Q`. -/
lemma R_L_lower (r ρ : ℝ) (q X Kv Lw : ℕ) (rn : ℕ) (hrn : (rn : ℝ) = r) (hq : 1 ≤ q) (hX : 1 ≤ X)
    (hr : 1 ≤ r) (hρ : 48 * q * X + 6 ≤ ρ) (hKv : (2 : ℝ) ^ Kv ≤ 4 * ρ)
    (hLw : r * ρ ^ 3 - 2 ≤ (Lw : ℝ)) :
    ρ ≤ (((Lw / (2 ^ Kv * X) - 6 * q * rn) / (6 * q * rn) : ℕ) : ℝ) := by
  have hX1 : (1 : ℝ) ≤ X := by exact_mod_cast hX
  have hq1 : (1 : ℝ) ≤ q := by exact_mod_cast hq
  have hρ1 : 6 ≤ ρ := by
    have : (0 : ℝ) ≤ 48 * q * X := by positivity
    linarith
  have hD : 1 ≤ 2 ^ Kv * X := Nat.one_le_iff_ne_zero.2 (Nat.mul_ne_zero (by positivity) (by omega))
  have hQ : 1 ≤ 6 * q * rn := by
    have : (1 : ℝ) ≤ 6 * q * rn := by rw [hrn]; nlinarith
    exact_mod_cast this
  have hN1 := natdiv_ge Lw (2 ^ Kv * X) hD
  have hDR : ((2 ^ Kv * X : ℕ) : ℝ) ≤ 4 * ρ * X := by
    push_cast; exact mul_le_mul_of_nonneg_right hKv (by positivity)
  have hDpos : (0 : ℝ) < ((2 ^ Kv * X : ℕ) : ℝ) := by exact_mod_cast hD
  -- `N1 ≥ rρ²/(4X) − 2`
  have hN1' : r * ρ ^ 2 / (4 * X) - 2 ≤ ((Lw / (2 ^ Kv * X) : ℕ) : ℝ) := by
    have h1 : (r * ρ ^ 3 - 2) / (4 * ρ * X) ≤ (Lw : ℝ) / ((2 ^ Kv * X : ℕ) : ℝ) := by
      rcases le_or_gt (r * ρ ^ 3 - 2) 0 with hneg | hpos
      · have : (r * ρ ^ 3 - 2) / (4 * ρ * X) ≤ 0 := div_nonpos_of_nonpos_of_nonneg hneg (by positivity)
        exact le_trans this (by positivity)
      · exact div_le_div₀ (by positivity) hLw hDpos hDR
    have e : (r * ρ ^ 3 - 2) / (4 * ρ * X) = r * ρ ^ 2 / (4 * X) - 1 / (2 * ρ * X) := by
      field_simp; ring
    have h2 : 1 / (2 * ρ * X) ≤ 1 := by
      rw [div_le_one (by positivity)]; nlinarith
    linarith
  set N1 := Lw / (2 ^ Kv * X)
  set Q := 6 * q * rn
  have hQR : (Q : ℝ) = 6 * q * r := by simp [Q, hrn]
  have hsub := natsub_ge N1 Q
  have hdiv := natdiv_ge (N1 - Q) Q hQ
  have hQpos : (0 : ℝ) < Q := by exact_mod_cast hQ
  -- `(N1 − Q)/Q ≥ ρ²/(24qX) − 3`
  have h3 : ρ ^ 2 / (24 * q * X) - 3 ≤ (((N1 - Q) / Q : ℕ) : ℝ) := by
    have h4 : ((N1 - Q : ℕ) : ℝ) / Q ≥ (r * ρ ^ 2 / (4 * X) - 2 - Q) / Q := by
      apply div_le_div_of_nonneg_right _ hQpos.le; linarith
    have e : (r * ρ ^ 2 / (4 * X) - 2 - Q) / Q = ρ ^ 2 / (24 * q * X) - 2 / (6 * q * r) - 1 := by
      rw [hQR]; field_simp; ring
    have h5 : 2 / (6 * q * r) ≤ 1 := by rw [div_le_one (by positivity)]; nlinarith
    linarith
  have h6 : ρ + 3 ≤ ρ ^ 2 / (24 * q * X) := by
    rw [le_div_iff₀ (by positivity)]
    have : 48 * q * X ≤ ρ := by linarith
    nlinarith
  linarith


lemma R_Lw_ge (h r : ℕ) (hr0 : (0 : ℝ) < r) :
    (r : ℝ) * ((r : ℝ) ^ εp h) ^ 3 - 2 ≤ (LwR h r : ℝ) := by
  have e : (r : ℝ) ^ (1 + 3 * εp h) = r * ((r : ℝ) ^ εp h) ^ 3 := by
    rw [← Real.rpow_natCast (_ : ℝ) 3, ← Real.rpow_mul hr0.le,
      show (r : ℝ) * (r : ℝ) ^ (εp h * ((3 : ℕ) : ℝ)) = (r : ℝ) ^ (1 : ℝ) * (r : ℝ) ^ (εp h * ((3 : ℕ) : ℝ))
        by rw [Real.rpow_one], rp hr0]
    push_cast; ring_nf
  unfold LwR
  have hfl := Nat.lt_floor_add_one ((r : ℝ) ^ (1 + 3 * εp h))
  rcases Nat.eq_zero_or_pos ⌊(r : ℝ) ^ (1 + 3 * εp h)⌋₊ with h0 | hpos
  · rw [h0] at hfl ⊢; rw [Nat.zero_sub]; push_cast at hfl ⊢; linarith
  · rw [Nat.cast_sub hpos]; push_cast; linarith

lemma R_Ymax_facts (Λ : ℝ) (h H r q : ℕ) (hΛ : Λ = Real.log h) (hΛ2 : 2 ≤ Λ) (hq : 1 ≤ q) (hr : 1 ≤ r)
    (hrrH : (r : ℝ) * r ≤ H) (hHh : (H : ℝ) ≤ h) :
    0 < Real.log (((6 * q * h : ℕ) : ℝ) * H / r / ((6 * q * r : ℕ) : ℝ)) ∧
      Real.log (((6 * q * h : ℕ) : ℝ) * H / r / ((6 * q * r : ℕ) : ℝ)) ≤ 3 * Λ := by
  have hrR : (1 : ℝ) ≤ r := by exact_mod_cast hr
  have hqR : (1 : ℝ) ≤ q := by exact_mod_cast hq
  have hh2 : (2 : ℝ) ≤ h := by
    by_contra hc'; push_neg at hc'
    have hh0 : (0 : ℝ) < h := by
      rcases Nat.eq_zero_or_pos h with h0 | h0
      · rw [hΛ, h0] at hΛ2; simp at hΛ2; linarith
      · exact_mod_cast h0
    have : Real.log h < Real.log 2 := Real.log_lt_log hh0 hc'
    have : Real.log 2 < 1 := by have := Real.log_two_lt_d9; linarith
    linarith
  have hH1 : (1 : ℝ) ≤ H := le_trans (by nlinarith) hrrH
  have e : ((6 * q * h : ℕ) : ℝ) * H / r / ((6 * q * r : ℕ) : ℝ) = (h : ℝ) * H / (r * r) := by
    push_cast; field_simp
  rw [e]
  constructor
  · apply Real.log_pos
    rw [lt_div_iff₀ (by positivity)]
    nlinarith
  · have hpos : (0 : ℝ) < (h : ℝ) * H / (r * r) := by positivity
    have hle : (h : ℝ) * H / (r * r) ≤ (h : ℝ) ^ 2 := by
      rw [div_le_iff₀ (by positivity)]
      have : (1 : ℝ) ≤ r * r := by nlinarith
      nlinarith
    have := Real.log_le_log hpos hle
    rw [Real.log_pow, ← hΛ] at this; push_cast at this; linarith

lemma R_diag_bound (C : ℝ) (hC : 0 ≤ C) (Λ : ℝ) (hΛ : 0 < Λ) (H Sb r q : ℕ) (hH0 : (0 : ℝ) < H) (hr0 : (0 : ℝ) < r)
    (Eh0 : ℝ) (hEh : Eh0 = Real.exp (Λ ^ (1 / 4 : ℝ)))
    (hSbR : (Sb : ℝ) ≤ (H : ℝ) / (Eh0 * r)) (hlogSb : Real.log Sb ≤ Λ) (hΛ1 : 1 ≤ Λ) :
    128 * C * Sb * (1 + Real.log Sb) / ((H : ℝ) / (6 * q * r)) ≤
      1536 * C * q * Λ * Real.exp (-(Λ ^ (1 / 4 : ℝ))) := by
  have hE0 : 0 < Eh0 := by rw [hEh]; exact Real.exp_pos _
  have hq0 : (0 : ℝ) ≤ q := by positivity
  rcases Nat.eq_zero_or_pos q with hq | hq
  · subst hq; simp
  have hqR : (0 : ℝ) < q := by exact_mod_cast hq
  rw [div_div_eq_mul_div, div_le_iff₀ hH0]
  have hSbH : (Sb : ℝ) * (Eh0 * r) ≤ H := by rwa [le_div_iff₀ (by positivity)] at hSbR
  have hEexp : Real.exp (-(Λ ^ (1 / 4 : ℝ))) * Eh0 = 1 := by
    rw [hEh, ← Real.exp_add]; simp
  have h1 : 1 + Real.log Sb ≤ 2 * Λ := by linarith
  have hlogSb0 : 0 ≤ Real.log (Sb : ℝ) := Real.log_natCast_nonneg _
  have hSb0 : (0 : ℝ) ≤ Sb := by positivity
  have key : 128 * C * Sb * (1 + Real.log Sb) * (6 * q * r) ≤
      1536 * C * q * Λ * Real.exp (-(Λ ^ (1 / 4 : ℝ))) * (Sb * (Eh0 * r)) := by
    have hx : (128 * C * Sb * (1 + Real.log Sb) * (6 * q * r)) =
        768 * C * q * (1 + Real.log Sb) * (Sb * r) := by ring
    have hy : 1536 * C * q * Λ * Real.exp (-(Λ ^ (1 / 4 : ℝ))) * (Sb * (Eh0 * r)) =
        768 * C * q * (2 * Λ) * (Sb * r) * (Real.exp (-(Λ ^ (1 / 4 : ℝ))) * Eh0) := by ring
    rw [hx, hy, hEexp, mul_one]
    gcongr
  calc 128 * C * Sb * (1 + Real.log Sb) * (6 * q * r)
      ≤ 1536 * C * q * Λ * Real.exp (-(Λ ^ (1 / 4 : ℝ))) * (Sb * (Eh0 * r)) := key
    _ ≤ 1536 * C * q * Λ * Real.exp (-(Λ ^ (1 / 4 : ℝ))) * H := by gcongr

lemma R_Kf_bound (Λ : ℝ) (hΛ1 : 3 ≤ Λ) (Sb r : ℕ) (ε : ℝ) (hε0 : 0 ≤ ε) (hε1 : ε ≤ 1) (hr : (1 : ℝ) ≤ r)
    (hlogr : Real.log r ≤ Λ) (hlogSb : Real.log Sb ≤ Λ) :
    ((((Nat.log 2 Sb + 1) * 2) * (Nat.log 2 ⌈(r : ℝ) ^ ε⌉₊ + 1) : ℕ) : ℝ) ≤ 18 * Λ ^ 2 := by
  have hΛ0 : 0 < Λ := by linarith
  set ρ := (r : ℝ) ^ ε
  have hρ1 : 1 ≤ ρ := Real.one_le_rpow hr hε0
  have h1 : (Nat.log 2 Sb : ℝ) + 1 ≤ 3 * Λ := by
    have := natlog_le_of Sb Λ hlogSb
    rw [max_eq_left hΛ0.le] at this; linarith
  have h2 : (Nat.log 2 ⌈ρ⌉₊ : ℝ) + 1 ≤ 3 * Λ := by
    have hc1 : (⌈ρ⌉₊ : ℝ) ≤ 2 * ρ := by
      have := Nat.ceil_lt_add_one (show 0 ≤ ρ by linarith); linarith
    have hlog : Real.log (⌈ρ⌉₊ : ℝ) ≤ 1 + Λ := by
      have hp : (0 : ℝ) < (⌈ρ⌉₊ : ℝ) := by
        have := Nat.le_ceil ρ; linarith
      have h3 : Real.log (⌈ρ⌉₊ : ℝ) ≤ Real.log (2 * ρ) := Real.log_le_log hp hc1
      rw [Real.log_mul (by norm_num) (by linarith), Real.log_rpow (by linarith)] at h3
      have : Real.log 2 < 1 := by have := Real.log_two_lt_d9; linarith
      have : ε * Real.log r ≤ Λ := by
        calc ε * Real.log r ≤ 1 * Real.log r := mul_le_mul_of_nonneg_right hε1 (Real.log_nonneg hr)
          _ ≤ Λ := by linarith
      linarith
    have := natlog_le_of ⌈ρ⌉₊ (1 + Λ) hlog
    rw [max_eq_left (by linarith)] at this
    linarith
  push_cast
  calc ((Nat.log 2 Sb : ℝ) + 1) * 2 * ((Nat.log 2 ⌈ρ⌉₊ : ℝ) + 1) ≤ (3 * Λ) * 2 * (3 * Λ) := by gcongr
    _ = 18 * Λ ^ 2 := by ring

set_option maxHeartbeats 4000000 in
/-- **Each R-cell `RTerm` is `≤ Λ^{−90}`**, eventually in `h`, uniformly in admissible `r`. -/
theorem R_term_ev (q : ℕ) (hq : 0 < q) (c C : ℝ) (hc : 0 < c) (hC : 0 ≤ C) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (h H r : ℕ), Λ₀ ≤ Real.log h → H ≤ h → 1 ≤ r →
      5 * (Real.log h) ^ σ₀ ≤ Real.log (r : ℝ) →
      Eh h * r * (r : ℝ) ^ (1 + 3 * εp h) ≤ H → LwR h r ≤ NbR h H r →
      ∀ (U : Finset ℕ), (∀ p ∈ U, p.Prime ∧ 5 ≤ p ∧ p ≤ H ^ 2) →
      ∀ (coef : ℕ → ℂ) (Ym : ℕ → ℝ), (∀ m, 1 ≤ m → ‖coef m‖ ≤ (600 * (q : ℝ) ^ 2 + 8) / m) →
        (∀ m ∈ Icc 1 (6 * q * h), (H : ℝ) / (6 * q * r) ≤ |Ym m| ∧
          |Ym m| ≤ ((6 * q * h : ℕ) : ℝ) * H / r ∧ ((6 * q * r : ℕ) : ℝ) < |Ym m|) →
        GoldC.QuillonRCellApp.RTerm c C (Icc 1 (6 * q * h)) coef Ym (6 * q * r) U (Xp h) (Kvp h r)
          (LwR h r) (max (NbR h H r) (LwR h r)) ≤ (Real.log h) ^ (-(90 : ℝ)) := by
  set Cb : ℝ := 600 * (q : ℝ) ^ 2 + 8 with hCb
  set E : ℝ := Real.exp 10 * (2 * 2 + 1) ^ 10 with hE
  have hτ : 0 < σ₀ - 1 / 200 := by unfold σ₀; norm_num
  obtain ⟨Λ₁, hΛ₁, hexp⟩ := R_exp_ev c hc
  obtain ⟨Λ₂, hΛ₂, hdiag⟩ := R_diag_ev (1536 * C * q) (by positivity)
  obtain ⟨Λ₃, hΛ₃, hAω⟩ := Aω_le 5 (1 / 2) (by norm_num) (by norm_num)
  obtain ⟨Λ₄, hΛ₄, hρev⟩ := GoldC.QuillonAsymp.rpow_le_exp_rpow 201 5 (σ₀ - 1 / 200) (by norm_num)
    (by norm_num) hτ
  obtain ⟨Λ₅, hΛ₅, hK⟩ := const_le_rpow (18 * Cb * 2 * 3 + Cb * 2 * E * 12.5 + 96 * q + 10) 1 one_pos
  obtain ⟨Λ₆, hΛ₆, hK2⟩ := const_le_rpow (Real.sqrt (8 * C) + 1) 100 (by norm_num)
  refine ⟨max Λ₁ (max Λ₂ (max Λ₃ (max Λ₄ (max Λ₅ (max Λ₆ (1 + Real.log (6 * q))))))),
    le_trans hΛ₁ (le_max_left _ _), ?_⟩
  intro h H r hΛ hHh hr1 hlogr hEH hLwNb U hU coef Ym hcoef hY
  have L1 : Λ₁ ≤ Real.log h := le_trans (by simp) hΛ
  have L2 : Λ₂ ≤ Real.log h := le_trans (by simp) hΛ
  have L3 : Λ₃ ≤ Real.log h := le_trans (by simp) hΛ
  have L4 : Λ₄ ≤ Real.log h := le_trans (by simp) hΛ
  have L5 : Λ₅ ≤ Real.log h := le_trans (by simp) hΛ
  have L6 : Λ₆ ≤ Real.log h := le_trans (by simp) hΛ
  have L7 : 1 + Real.log (6 * q) ≤ Real.log h := le_trans (by simp) hΛ
  clear hΛ
  set Λ := Real.log h with hΛdef
  have hΛ2 : 2 ≤ Λ := le_trans hΛ₁ L1
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  have hKΛ := hK Λ L5
  rw [Real.rpow_one] at hKΛ
  have hΛq : (96 * q + 10 : ℝ) ≤ Λ := by
    have : 0 ≤ 18 * Cb * 2 * 3 + Cb * 2 * E * 12.5 := by positivity
    linarith
  have hKfin : 18 * Cb * 2 * 3 + Cb * 2 * E * 12.5 ≤ Λ := by
    have : (0 : ℝ) ≤ 96 * q + 10 := by positivity
    linarith
  have hh1n : 1 ≤ h := by
    rcases Nat.eq_zero_or_pos h with h0 | h0
    · exfalso
      have : Real.log (h : ℝ) = 0 := by rw [h0]; simp
      linarith
    · exact h0
  have hh0 : (0 : ℝ) < h := by exact_mod_cast hh1n
  have hrR : (1 : ℝ) ≤ r := by exact_mod_cast hr1
  have hr0 : (0 : ℝ) < r := by linarith
  have hq1 : (1 : ℝ) ≤ q := by exact_mod_cast hq
  have hq0 : (0 : ℝ) < q := by linarith
  obtain ⟨hε0, hε1⟩ := GoldC.QuillonCPhysical.εp_le_one (h := h) hΛ1
  set ε := εp h with hεdef
  have hEh1 : 1 ≤ Eh h := Real.one_le_exp (by positivity)
  have hEh0 : 0 < Eh h := by linarith
  -- `r ≤ h`, `log r ≤ Λ`
  have hρ1 : (1 : ℝ) ≤ (r : ℝ) ^ ε := Real.one_le_rpow hrR hε0
  have hr3 : (r : ℝ) ≤ (r : ℝ) ^ (1 + 3 * ε) :=
    le_trans (le_of_eq (Real.rpow_one _).symm) (Real.rpow_le_rpow_of_exponent_le hrR (by linarith))
  have hHR : (H : ℝ) ≤ h := by exact_mod_cast hHh
  have hrh : (r : ℝ) ≤ h := by
    have : (r : ℝ) ≤ Eh h * r * (r : ℝ) ^ (1 + 3 * ε) := by
      have h1 : (r : ℝ) ≤ Eh h * r := le_mul_of_one_le_left hr0.le hEh1
      have h2 : 1 ≤ (r : ℝ) ^ (1 + 3 * ε) := le_trans hrR hr3
      calc (r : ℝ) ≤ Eh h * r := h1
        _ ≤ Eh h * r * (r : ℝ) ^ (1 + 3 * ε) := le_mul_of_one_le_right (by positivity) h2
    linarith
  have hlogr_le : Real.log r ≤ Λ := Real.log_le_log hr0 hrh
  set ρ := (r : ℝ) ^ ε with hρdef
  -- `ρ` is large
  have hρbig : 48 * q * Xp h + 6 ≤ ρ := by
    have h1 : ρ = Real.exp (ε * Real.log r) := by rw [hρdef, Real.rpow_def_of_pos hr0]; ring_nf
    have h2 : 5 * Λ ^ (σ₀ - 1 / 200) ≤ ε * Real.log r := by
      have e : ε * (5 * Λ ^ σ₀) = 5 * Λ ^ (σ₀ - 1 / 200) := by
        rw [hεdef]; unfold εp; rw [mul_left_comm, rp hΛ0]; ring_nf
      rw [← e]; exact mul_le_mul_of_nonneg_left hlogr hε0
    have h3 : Λ ^ (201 : ℝ) ≤ ρ := by
      rw [h1]; exact le_trans (hρev Λ L4) (Real.exp_le_exp.2 h2)
    have h4 : (48 * q * Xp h + 6 : ℝ) ≤ Λ ^ (201 : ℝ) := by
      have hX := Xp_le (h := h) hΛ1
      have e : Λ ^ (201 : ℝ) = Λ * Λ ^ (200 : ℝ) := by
        rw [show Λ * Λ ^ (200 : ℝ) = Λ ^ (1 : ℝ) * Λ ^ (200 : ℝ) by rw [Real.rpow_one], rp hΛ0]; norm_num
      rw [e]
      have hp : 1 ≤ Λ ^ (200 : ℝ) := Real.one_le_rpow hΛ1 (by norm_num)
      nlinarith
    linarith
  -- `Kv`
  obtain ⟨hKv1, hKv2⟩ := Kv_bounds ρ hρ1 (Kvp h r) rfl
  have hLwge : (r : ℝ) * ρ ^ 3 - 2 ≤ (LwR h r : ℝ) := R_Lw_ge h r hr0
  have hX1 : 1 ≤ Xp h := by have := Xp_two (h := h) hΛ2; omega
  have hL := R_L_lower r ρ q (Xp h) (Kvp h r) (LwR h r) r rfl hq hX1 hrR hρbig hKv2 hLwge
  -- `Sb`
  rw [max_eq_left hLwNb]
  set Sb := NbR h H r with hSb
  have hSbR : (Sb : ℝ) ≤ (H : ℝ) / (Eh h * r) := Nat.floor_le (by positivity)
  have hSbh : (Sb : ℝ) ≤ h := by
    have : (H : ℝ) / (Eh h * r) ≤ H := div_le_self (by positivity) (by nlinarith)
    linarith
  have hlogSb : Real.log Sb ≤ Λ := by
    rcases Nat.eq_zero_or_pos Sb with h0 | hpos
    · rw [h0]; simp; linarith
    · exact Real.log_le_log (by exact_mod_cast hpos) hSbh
  have hlogSb0 : 0 ≤ Real.log (Sb : ℝ) := Real.log_natCast_nonneg _
  -- the closed form
  set Ymin : ℝ := (H : ℝ) / (6 * q * r) with hYmin
  set Ymax : ℝ := ((6 * q * h : ℕ) : ℝ) * H / r with hYmax
  have hH0 : (0 : ℝ) < H := by
    have : 0 < Eh h * r * (r : ℝ) ^ (1 + 3 * ε) := by positivity
    linarith
  have hYmin0 : 0 < Ymin := by positivity
  have hQ1 : 1 ≤ 6 * q * r := by
    have : 1 ≤ 6 * q := by omega
    nlinarith
  have hRT := GoldC.QuillonREst.RTerm_le c C hc hC (6 * q * h) coef Cb (by positivity) hcoef Ym (6 * q * r)
    hQ1 U (fun p hp => (hU p hp).2.1) (Xp h) (Kvp h r) (LwR h r) Sb hX1 Ymin Ymax hYmin0 hY
  refine le_trans hRT ?_
  have hKf := R_Kf_bound Λ (by linarith) Sb r ε hε0 hε1 hrR hlogr_le hlogSb
  have hF4 : 1 + Real.log ((6 * q * h : ℕ) : ℝ) ≤ 2 * Λ := by
    push_cast; rw [Real.log_mul (by positivity) hh0.ne']; linarith
  have hAw : (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 Sb) : ℝ) ^ 30) ^ 2 ≤ Λ := by
    have h1 := hAω Λ L3 Sb (by linarith)
    have h0 : 0 ≤ Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 Sb) : ℝ) ^ 30 := by positivity
    calc _ ≤ (Λ ^ (1 / 2 : ℝ)) ^ 2 := pow_le_pow_left₀ h0 h1 2
      _ = Λ := by rw [← Real.rpow_natCast, ← Real.rpow_mul hΛ0.le]; norm_num
  have hXge := Xp_ge (h := h) hΛ1
  have hXpos : (0 : ℝ) < Xp h := lt_of_lt_of_le (by positivity) hXge
  have hsqX : 2 / Real.sqrt (Xp h) ≤ 2 * Λ ^ (-(100 : ℝ)) := by
    have hsq : Λ ^ (100 : ℝ) ≤ Real.sqrt (Xp h) := by
      rw [Real.le_sqrt (by positivity) hXpos.le]
      calc (Λ ^ (100 : ℝ)) ^ 2 = Λ ^ (200 : ℝ) := by
            rw [← Real.rpow_natCast, ← Real.rpow_mul hΛ0.le]; norm_num
        _ ≤ Xp h := hXge
    exact inv_rpow_le hΛ0 100 2 hsq (by norm_num)
  have hrrH : (r : ℝ) * r ≤ H := by
    have h1 : (r : ℝ) * r ≤ Eh h * r * r := by
      calc (r : ℝ) * r = 1 * (r * r) := by ring
        _ ≤ Eh h * (r * r) := mul_le_mul_of_nonneg_right hEh1 (by positivity)
        _ = Eh h * r * r := by ring
    have h2 : Eh h * r * r ≤ Eh h * r * (r : ℝ) ^ (1 + 3 * ε) :=
      mul_le_mul_of_nonneg_left hr3 (by positivity)
    linarith
  obtain ⟨hLm0, hLm⟩ := R_Ymax_facts Λ h H r q hΛdef hΛ2 hq hr1 hrrH hHR
  have hLlow : 5 * Λ ^ (σ₀ - 1 / 200) ≤
      Real.log ((((LwR h r / (2 ^ Kvp h r * Xp h) - 6 * q * r) / (6 * q * r) : ℕ)) : ℝ) := by
    have h1 : 5 * Λ ^ (σ₀ - 1 / 200) ≤ Real.log ρ := by
      rw [hρdef, Real.log_rpow hr0]
      have e : ε * (5 * Λ ^ σ₀) = 5 * Λ ^ (σ₀ - 1 / 200) := by
        rw [hεdef]; unfold εp; rw [mul_left_comm, rp hΛ0]; ring_nf
      rw [← e]; exact mul_le_mul_of_nonneg_left hlogr hε0
    exact le_trans h1 (Real.log_le_log (by linarith) hL)
  have hexpT := hexp Λ L1 _ _ hLlow hLm0 hLm
  have hdiagT : Real.sqrt (128 * C * Sb * (1 + Real.log Sb) / Ymin) ≤ Λ ^ (-(200 : ℝ)) := by
    apply sqrt_le_of (by positivity)
    have e : (Λ ^ (-(200 : ℝ))) ^ 2 = Λ ^ (-(400 : ℝ)) := by
      rw [← Real.rpow_natCast, ← Real.rpow_mul hΛ0.le]; norm_num
    rw [e]
    exact hdiag Λ L2 _ (by positivity)
      (R_diag_bound C hC Λ hΛ0 H Sb r q hH0 hr0 (Eh h) rfl hSbR hlogSb hΛ1)
  have hBr : 2 / Real.sqrt (Xp h) +
      Real.sqrt (8 * C) * Real.exp (-(c * Real.log ((((LwR h r / (2 ^ Kvp h r * Xp h) - 6 * q * r) /
        (6 * q * r) : ℕ)) : ℝ) ^ 3 / Real.log (Ymax / ((6 * q * r : ℕ) : ℝ)) ^ 2) / 2) +
      Real.sqrt (128 * C * Sb * (1 + Real.log Sb) / Ymin) ≤ 3 * Λ ^ (-(100 : ℝ)) := by
    have hk := hK2 Λ L6
    have e : Λ ^ (100 : ℝ) * Λ ^ (-(200 : ℝ)) = Λ ^ (-(100 : ℝ)) := by rw [rp hΛ0]; norm_num
    have hp : 0 ≤ Λ ^ (-(200 : ℝ)) := by positivity
    have h1 : Real.sqrt (8 * C) * Real.exp (-(c * Real.log ((((LwR h r / (2 ^ Kvp h r * Xp h) - 6 * q * r) /
        (6 * q * r) : ℕ)) : ℝ) ^ 3 / Real.log (Ymax / ((6 * q * r : ℕ) : ℝ)) ^ 2) / 2) ≤
        Real.sqrt (8 * C) * Λ ^ (-(200 : ℝ)) := mul_le_mul_of_nonneg_left hexpT (Real.sqrt_nonneg _)
    have h2 : (Real.sqrt (8 * C) + 1) * Λ ^ (-(200 : ℝ)) ≤ Λ ^ (-(100 : ℝ)) := by
      rw [← e]; exact mul_le_mul_of_nonneg_right hk hp
    linarith
  have hWU := prodU_le_pow U (fun p hp => ⟨(hU p hp).1, (hU p hp).2.1⟩) (h ^ 2)
    (fun p hp => le_trans (hU p hp).2.2 (Nat.pow_le_pow_left hHh 2)) 2 Λ (by norm_num) hΛ1
    (by push_cast; rw [Real.log_pow]; push_cast; linarith)
  have hXi : (12.5 : ℝ) / Xp h ≤ 12.5 * Λ ^ (-(200 : ℝ)) := inv_rpow_le hΛ0 200 12.5 hXge (by norm_num)
  have hWU0 : 0 ≤ ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) := prod_nonneg fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast (hU p hp).2.1
    have : 0 ≤ 1 / ((p : ℝ) - 3) := div_nonneg zero_le_one (by linarith)
    linarith
  exact R_combine Λ _ Cb _ _ _ _ _ E hΛ2 (by positivity) (by positivity) hKf
    (by have := Real.log_natCast_nonneg (6 * q * h); linarith) hF4 (by positivity) hAw (by positivity) hBr
    hWU0 hWU (by positivity) hXi (by positivity) hKfin

end GoldC.QuillonREv

#print axioms GoldC.QuillonREv.R_exp_ev
#print axioms GoldC.QuillonREv.R_diag_ev
#print axioms GoldC.QuillonREv.R_combine
#print axioms GoldC.QuillonREv.Kv_bounds
#print axioms GoldC.QuillonREv.R_L_lower
#print axioms GoldC.QuillonREv.R_term_ev
