import PaperB.FixedQ.PetermannMovingTransfer
import PaperB.Analytic.CharacterAdditiveTwist

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ

theorem petermannBaseKernelSum_eq_additive_eR
    (q : ℕ) [NeZero (Nat.lcm 6 q)] (base : PetermannBase)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (T : ℝ) (X : ℕ) :
    petermannBaseKernelSum q base chi r T X =
      ((Nat.lcm 6 q : ℕ) : ℂ)⁻¹ *
        ∑ h : ZMod (Nat.lcm 6 q),
          ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h *
            ∑ e ∈ Finset.Icc 1 X,
              eR (((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) * (e : ℝ)) *
              (petermannBaseCoeff q base e : ℂ) *
              (petermannSawtooth
                (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
                  (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) := by
  unfold petermannBaseKernelSum
  calc
    (∑ e ∈ Finset.Icc 1 X,
      (chi e) * (petermannBaseCoeff q base e : ℂ) *
        (petermannSawtooth
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ))
      =
    ∑ e ∈ Finset.Icc 1 X,
      ((((Nat.lcm 6 q : ℕ) : ℂ)⁻¹ *
        ∑ h : ZMod (Nat.lcm 6 q),
          eR (((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) * (e : ℝ)) *
            ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h) *
        (petermannBaseCoeff q base e : ℂ) *
        (petermannSawtooth
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ)) := by
        apply Finset.sum_congr rfl
        intro e he
        rw [dirichletCharacter_additive_eR_inversion]
    _ =
      ((Nat.lcm 6 q : ℕ) : ℂ)⁻¹ *
        ∑ h : ZMod (Nat.lcm 6 q),
          ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h *
            ∑ e ∈ Finset.Icc 1 X,
              eR (((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) * (e : ℝ)) *
              (petermannBaseCoeff q base e : ℂ) *
              (petermannSawtooth
                (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
                  (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) := by
        classical
        simp_rw [Finset.mul_sum, Finset.sum_mul]
        rw [Finset.sum_comm]
        apply Finset.sum_congr rfl
        intro h hh
        apply Finset.sum_congr rfl
        intro e he
        ring

#print axioms petermannBaseKernelSum_eq_additive_eR

end PaperB.Analytic
