import PaperB.FixedQ.PrincipalOneDimensionalCancellation
import PaperB.FixedQ.PairRowBridge
import PaperB.FixedQ.FixedQReflection

open scoped BigOperators

namespace PaperB.FixedQ

theorem finiteVWeightReal_union_height_nonheight
    {h : ℕ} {d e : Finset ℕ}
    (hdis : Disjoint d e)
    (hd : ∀ p ∈ d, p ∣ h)
    (he : ∀ p ∈ e, ¬ p ∣ h) :
    finiteVWeightReal h (d ∪ e) =
      finiteVWeightReal h d * finiteOmegaWeightReal e := by
  unfold finiteVWeightReal finiteOmegaWeightReal
  have hdprod :
      (∏ p ∈ d,
        if p ∣ h then 1 / ((p : ℝ) - 2)
        else 1 / ((p : ℝ) - 3)) =
      ∏ p ∈ d, 1 / ((p : ℝ) - 2) := by
    apply Finset.prod_congr rfl
    intro p hp
    rw [if_pos (hd p hp)]
  have heprod :
      (∏ p ∈ e,
        if p ∣ h then 1 / ((p : ℝ) - 2)
        else 1 / ((p : ℝ) - 3)) =
      ∏ p ∈ e, 1 / ((p : ℝ) - 3) := by
    apply Finset.prod_congr rfl
    intro p hp
    rw [if_neg (he p hp)]
  rw [Finset.prod_union hdis, hdprod, heprod]

theorem pairCoefficient_height_union_eq_pureLeft
    {q h : ℕ} {d e : Finset ℕ}
    (hdis : Disjoint d e)
    (hdA : ∀ p ∈ d, activeHighPrime q p)
    (heA : ∀ p ∈ e, activeHighPrime q p)
    (hdH : ∀ p ∈ d, p ∣ h)
    (heH : ∀ p ∈ e, ¬ p ∣ h) :
    pairCoefficient q h (d ∪ e) d =
      pairCoefficient q h (d ∪ e) (d ∪ e) := by
  unfold pairCoefficient
  have hleftUnion : ∀ p ∈ d ∪ e, activeHighPrime q p := by
    intro p hp
    rcases Finset.mem_union.mp hp with hp | hp
    · exact hdA p hp
    · exact heA p hp
  have hrightE :
      ∀ p ∈ e, activeHighPrime q p ∧ ¬ p ∣ h := by
    intro p hp
    exact ⟨heA p hp, heH p hp⟩
  have hsdiff := Finset.union_sdiff_cancel_left hdis
  rw [hsdiff]
  simp only [if_pos hdA, if_pos hrightE, if_pos hleftUnion,
    Finset.sdiff_self]
  rw [finiteVWeightReal_union_height_nonheight hdis hdH heH]
  simp [finiteOmegaWeightReal]

#print axioms pairCoefficient_height_union_eq_pureLeft

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem rowConstrainedMass_absorb_height_right
    (lambda : ℕ → ℝ) {h d e : ℕ}
    (hdh : d ∣ h) (hcop : d.Coprime e) :
    rowConstrainedMass lambda h e d =
      rowConstrainedMass lambda h (d * e) 1 := by
  unfold rowConstrainedMass
  apply Finset.sum_congr rfl
  intro z hz
  have hzle : z ≤ h := Nat.le_of_lt (Finset.mem_Ioo.mp hz).2
  have hiff :
      (e ∣ z ∧ d ∣ h - z) ↔
        d * e ∣ z ∧ 1 ∣ h - z := by
    constructor
    · rintro ⟨hez, hdsub⟩
      have hdz0 : d ∣ h - (h - z) :=
        Nat.dvd_sub hdh hdsub
      have hdz : d ∣ z := by
        simpa [Nat.sub_sub_self hzle] using hdz0
      exact ⟨hcop.mul_dvd_of_dvd_of_dvd hdz hez, by simp⟩
    · rintro ⟨hdez, _⟩
      have hdz : d ∣ z :=
        (dvd_mul_right d e).trans hdez
      have hez : e ∣ z :=
        (dvd_mul_left e d).trans (by simpa [Nat.mul_comm] using hdez)
      have hdsub : d ∣ h - z :=
        Nat.dvd_sub hdh hdz
      exact ⟨hez, hdsub⟩
  simp only [hiff]

theorem fixedQRowDelta_absorb_height_right
    {q r h d e : ℕ}
    (hdh : d ∣ h) (hcop : d.Coprime e) :
    fixedQRowDelta q r h e d =
      fixedQRowDelta q r h (d * e) 1 := by
  unfold fixedQRowDelta
  rw [rowConstrainedMass_absorb_height_right
    (fixedQLowWeight q r h) hdh hcop]
  congr 1
  push_cast
  ring

#print axioms fixedQRowDelta_absorb_height_right

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem pairDelta_height_union_reflect_to_pureLeft
    {q a r h : ℕ} {d e : Finset ℕ}
    (hdis : Disjoint d e)
    (hdA : ∀ p ∈ d, activeHighPrime q p)
    (heA : ∀ p ∈ e, activeHighPrime q p)
    (hdH : ∀ p ∈ d, p ∣ h)
    (heH : ∀ p ∈ e, ¬ p ∣ h)
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    pairDelta q h (fixedQLowWeight q a h)
        (admissibleInteriorCount q a h : ℝ)
        (d ∪ e) d =
      pairDelta q h (fixedQLowWeight q r h)
        (admissibleInteriorCount q r h : ℝ)
        (d ∪ e) (d ∪ e) := by
  have hL : ∀ p ∈ d, activeHighPrime q p := hdA
  have hR :
      ∀ p ∈ ((d ∪ e) \ d),
        activeHighPrime q p ∧ ¬ p ∣ h := by
    rw [Finset.union_sdiff_cancel_left hdis]
    intro p hp
    exact ⟨heA p hp, heH p hp⟩
  rw [pairDelta_eq_fixedQRowDelta hL hR]
  have hrow :=
    fixedQRowDelta_reflect_of_coprime
      (q := q) (a := a) (r := r) (h := h)
      (e1 := pairLeftModulus d)
      (e2 := pairRightModulus (d ∪ e) d)
      hreflect
  rw [hrow]
  have hsdiff : ((d ∪ e) \ d) = e :=
    Finset.union_sdiff_cancel_left hdis
  have hdPrime : ∀ p ∈ d, p.Prime := by
    intro p hp
    exact (hdA p hp).1
  have hePrime : ∀ p ∈ e, p.Prime := by
    intro p hp
    exact (heA p hp).1
  have hdProdH : pairLeftModulus d ∣ h := by
    exact (primeSetProduct_dvd_iff hdPrime).2 hdH
  have hrightMod :
      pairRightModulus (d ∪ e) d = primeSetProduct e := by
    unfold pairRightModulus
    rw [hsdiff]
  have hcopProd :
      (pairLeftModulus d).Coprime (pairRightModulus (d ∪ e) d) := by
    rw [hrightMod]
    unfold pairLeftModulus
    apply Nat.Coprime.prod_left
    intro p hp
    apply Nat.Coprime.prod_right
    intro s hs
    have hpPrime := hdPrime p hp
    exact hpPrime.coprime_iff_not_dvd.mpr (by
      intro hps
      have hcases := (Nat.dvd_prime (hePrime s hs)).mp hps
      rcases hcases with h1 | heq
      · exact hpPrime.ne_one h1
      · exact (Finset.disjoint_left.mp hdis) hp (heq ▸ hs))
  rw [fixedQRowDelta_absorb_height_right hdProdH hcopProd]
  have hProdUnion :
      pairLeftModulus d * pairRightModulus (d ∪ e) d =
        pairLeftModulus (d ∪ e) := by
    rw [hrightMod]
    unfold pairLeftModulus primeSetProduct
    rw [Finset.prod_union hdis]
  rw [hProdUnion]
  have hLall : ∀ p ∈ d ∪ e, activeHighPrime q p := by
    intro p hp
    rcases Finset.mem_union.mp hp with hp | hp
    · exact hdA p hp
    · exact heA p hp
  have hRempty :
      ∀ p ∈ ((d ∪ e) \ (d ∪ e)),
        activeHighPrime q p ∧ ¬ p ∣ h := by
    simp
  have hrightOne :
      pairRightModulus (d ∪ e) (d ∪ e) = 1 := by
    simp [pairRightModulus, primeSetProduct]
  calc
    fixedQRowDelta q r h (pairLeftModulus (d ∪ e)) 1 =
        fixedQRowDelta q r h (pairLeftModulus (d ∪ e))
          (pairRightModulus (d ∪ e) (d ∪ e)) := by rw [hrightOne]
    _ = pairDelta q h (fixedQLowWeight q r h)
          (admissibleInteriorCount q r h : ℝ)
          (d ∪ e) (d ∪ e) :=
      (pairDelta_eq_fixedQRowDelta hLall hRempty).symm

#print axioms pairDelta_height_union_reflect_to_pureLeft

end PaperB.FixedQ

namespace PaperB.FixedQ

def heightPrimePart (h : ℕ) (e : Finset ℕ) : Finset ℕ :=
  e.filter fun p => p ∣ h

def nonheightPrimePart (h : ℕ) (e : Finset ℕ) : Finset ℕ :=
  e.filter fun p => ¬ p ∣ h

theorem height_nonheight_disjoint
    (h : ℕ) (e : Finset ℕ) :
    Disjoint (heightPrimePart h e) (nonheightPrimePart h e) := by
  refine Finset.disjoint_left.mpr ?_
  intro p hpH hpN
  exact (Finset.mem_filter.mp hpN).2 (Finset.mem_filter.mp hpH).2

theorem height_union_nonheight
    (h : ℕ) (e : Finset ℕ) :
    heightPrimePart h e ∪ nonheightPrimePart h e = e := by
  ext p
  simp [heightPrimePart, nonheightPrimePart]
  tauto

theorem active_height_part
    {q h : ℕ} {e : Finset ℕ}
    (hA : ∀ p ∈ e, activeHighPrime q p) :
    ∀ p ∈ heightPrimePart h e, activeHighPrime q p := by
  intro p hp
  exact hA p (Finset.mem_filter.mp hp).1

theorem active_nonheight_part
    {q h : ℕ} {e : Finset ℕ}
    (hA : ∀ p ∈ e, activeHighPrime q p) :
    ∀ p ∈ nonheightPrimePart h e, activeHighPrime q p := by
  intro p hp
  exact hA p (Finset.mem_filter.mp hp).1

theorem height_part_dvd
    {h : ℕ} {e : Finset ℕ} :
    ∀ p ∈ heightPrimePart h e, p ∣ h := by
  intro p hp
  exact (Finset.mem_filter.mp hp).2

theorem nonheight_part_not_dvd
    {h : ℕ} {e : Finset ℕ} :
    ∀ p ∈ nonheightPrimePart h e, ¬ p ∣ h := by
  intro p hp
  exact (Finset.mem_filter.mp hp).2

theorem pairTerm_reflect_height_partition
    {q a r h : ℕ} {e : Finset ℕ}
    (hA : ∀ p ∈ e, activeHighPrime q p)
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    pairCoefficient q h e (heightPrimePart h e) *
        pairDelta q h (fixedQLowWeight q a h)
          (admissibleInteriorCount q a h : ℝ)
          e (heightPrimePart h e) =
      pairCoefficient q h e e *
        pairDelta q h (fixedQLowWeight q r h)
          (admissibleInteriorCount q r h : ℝ)
          e e := by
  let d := heightPrimePart h e
  let n := nonheightPrimePart h e
  have hdis : Disjoint d n := by
    exact height_nonheight_disjoint h e
  have hunion : d ∪ n = e := by
    exact height_union_nonheight h e
  have hdA : ∀ p ∈ d, activeHighPrime q p :=
    active_height_part hA
  have hnA : ∀ p ∈ n, activeHighPrime q p :=
    active_nonheight_part hA
  have hdH : ∀ p ∈ d, p ∣ h :=
    height_part_dvd
  have hnH : ∀ p ∈ n, ¬ p ∣ h :=
    nonheight_part_not_dvd
  have hc :=
    pairCoefficient_height_union_eq_pureLeft
      hdis hdA hnA hdH hnH
  have hd :=
    pairDelta_height_union_reflect_to_pureLeft
      (q := q) (a := a) (r := r) (h := h)
      hdis hdA hnA hdH hnH hreflect
  rw [hunion] at hc hd
  rw [hc, hd]

#print axioms pairTerm_reflect_height_partition

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def pureLeftCountTerm
    (q a h : ℕ) (e : Finset ℕ) : ℝ :=
  pairCoefficient q h e e *
    pairCount q h (fixedQLowWeight q a h) e e

noncomputable def pureLeftBaselineTerm
    (q h : ℕ) (N : ℝ) (e : Finset ℕ) : ℝ :=
  N * (pairCoefficient q h e e / pairDenominator e e)

noncomputable def pureLeftPairTerm
    (q a h : ℕ) (e : Finset ℕ) : ℝ :=
  pairCoefficient q h e e *
    pairDelta q h (fixedQLowWeight q a h)
      (admissibleInteriorCount q a h : ℝ) e e

theorem pureLeftPairTerm_eq_count_sub_baseline
    (q a h : ℕ) (e : Finset ℕ) :
    pureLeftPairTerm q a h e =
      pureLeftCountTerm q a h e -
        pureLeftBaselineTerm q h
          (admissibleInteriorCount q a h : ℝ) e := by
  unfold pureLeftPairTerm pureLeftCountTerm pureLeftBaselineTerm pairDelta
  ring

theorem pureLeftCountTerm_eq_zero_of_not_subset_Icc
    {q a h : ℕ} {e : Finset ℕ}
    (he : ¬ e ⊆ Finset.Icc 5 h) :
    pureLeftCountTerm q a h e = 0 := by
  classical
  obtain ⟨p, hpe, hpnot⟩ := Finset.not_subset.mp he
  unfold pureLeftCountTerm pairCoefficient
  by_cases hA : ∀ x ∈ e, activeHighPrime q x
  · have hpA := hA p hpe
    have hp5 : 5 ≤ p := hpA.2.1
    have hph : h < p := by
      have hnotIcc : p ∉ Finset.Icc 5 h := hpnot
      simp only [Finset.mem_Icc, not_and_or] at hnotIcc
      rcases hnotIcc with hlt5 | hnle
      · omega
      · omega
    have hcount :
        pairCount q h (fixedQLowWeight q a h) e e = 0 := by
      unfold pairCount
      apply Finset.sum_eq_zero
      intro y hy
      have hylt : y < h := (Finset.mem_Ioo.mp hy).2
      have hypos : 0 < y := (Finset.mem_Ioo.mp hy).1
      have hpnoty : ¬ p ∣ y := by
        intro hpdy
        have hple : p ≤ y := Nat.le_of_dvd hypos hpdy
        omega
      have hnotleft :
          ¬ (∀ x ∈ e, activeHighPrime q x ∧ x ∣ y) := by
        intro hc
        exact hpnoty (hc p hpe).2
      simp [hnotleft]
    rw [if_pos hA]
    simp [hcount]
  · rw [if_neg hA]
    simp

theorem summable_pureLeftCountTerm
    (q a h : ℕ) :
    Summable (pureLeftCountTerm q a h) := by
  apply summable_of_hasFiniteSupport
  refine (Finset.Icc 5 h).powerset.finite_toSet.subset ?_
  intro e he
  by_contra hemem
  have hnotSub : ¬ e ⊆ Finset.Icc 5 h := by
    exact fun hs => hemem (Finset.mem_powerset.mpr hs)
  exact he (pureLeftCountTerm_eq_zero_of_not_subset_Icc hnotSub)

#print axioms summable_pureLeftCountTerm

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem finiteVWeightReal_nonneg_of_active
    {q h : ℕ} {s : Finset ℕ}
    (hs : ∀ p ∈ s, activeHighPrime q p) :
    0 ≤ finiteVWeightReal h s := by
  unfold finiteVWeightReal
  apply Finset.prod_nonneg
  intro p hp
  have hp5 : 5 ≤ p := (hs p hp).2.1
  have hpR : (5 : ℝ) ≤ (p : ℝ) := by
    exact_mod_cast hp5
  by_cases hph : p ∣ h
  · rw [if_pos hph]
    exact one_div_nonneg.mpr (by linarith)
  · rw [if_neg hph]
    exact one_div_nonneg.mpr (by linarith)

theorem finiteOmegaWeightReal_nonneg_of_active
    {q : ℕ} {s : Finset ℕ}
    (hs : ∀ p ∈ s, activeHighPrime q p) :
    0 ≤ finiteOmegaWeightReal s := by
  unfold finiteOmegaWeightReal
  apply Finset.prod_nonneg
  intro p hp
  have hp5 : 5 ≤ p := (hs p hp).2.1
  have hpR : (5 : ℝ) ≤ (p : ℝ) := by
    exact_mod_cast hp5
  exact one_div_nonneg.mpr (by linarith)

theorem pairCoefficient_nonneg
    (q h : ℕ) (e e1 : Finset ℕ) :
    0 ≤ pairCoefficient q h e e1 := by
  unfold pairCoefficient
  by_cases hL : ∀ p ∈ e1, activeHighPrime q p
  · rw [if_pos hL]
    by_cases hR :
        ∀ p ∈ e \ e1, activeHighPrime q p ∧ ¬ p ∣ h
    · rw [if_pos hR]
      exact mul_nonneg
        (finiteVWeightReal_nonneg_of_active hL)
        (finiteOmegaWeightReal_nonneg_of_active
          (fun p hp => (hR p hp).1))
    · rw [if_neg hR]
      simp
  · rw [if_neg hL]
    simp

theorem pairDenominator_nonneg
    (e e1 : Finset ℕ) :
    0 ≤ pairDenominator e e1 := by
  unfold pairDenominator
  apply mul_nonneg
  · apply Finset.prod_nonneg
    intro p hp
    positivity
  · apply Finset.prod_nonneg
    intro p hp
    positivity

theorem pairBaseline_nonneg
    (q h : ℕ) (e e1 : Finset ℕ) :
    0 ≤ pairCoefficient q h e e1 / pairDenominator e e1 := by
  exact div_nonneg
    (pairCoefficient_nonneg q h e e1)
    (pairDenominator_nonneg e e1)

noncomputable def pureLeftBaselineMass
    (q h : ℕ) (e : Finset ℕ) : ℝ :=
  pairCoefficient q h e e / pairDenominator e e

theorem pureLeftBaselineMass_nonneg
    (q h : ℕ) (e : Finset ℕ) :
    0 ≤ pureLeftBaselineMass q h e :=
  pairBaseline_nonneg q h e e

theorem pureLeftBaselineMass_le_normalizationWeightMass
    (q h : ℕ) (e : Finset ℕ) :
    pureLeftBaselineMass q h e ≤ normalizationWeightMass q h e := by
  rw [normalizationWeightMass_eq_pairBaselineSum]
  unfold pureLeftBaselineMass
  have hepow : e ∈ e.powerset := Finset.mem_powerset.mpr (by intro x hx; exact hx)
  exact Finset.single_le_sum
    (fun e1 he1 => pairBaseline_nonneg q h e e1)
    hepow

theorem summable_pureLeftBaselineMass
    (q h : ℕ) :
    Summable (pureLeftBaselineMass q h) := by
  exact Summable.of_nonneg_of_le
    (pureLeftBaselineMass_nonneg q h)
    (pureLeftBaselineMass_le_normalizationWeightMass q h)
    (summable_normalizationWeightMass q h)

theorem summable_pureLeftBaselineTerm
    (q h : ℕ) (N : ℝ) :
    Summable (pureLeftBaselineTerm q h N) := by
  have hs := Summable.mul_left N (summable_pureLeftBaselineMass q h)
  exact hs.congr (fun e => by
    unfold pureLeftBaselineTerm pureLeftBaselineMass
    ring)

theorem summable_pureLeftPairTerm
    (q a h : ℕ) :
    Summable (pureLeftPairTerm q a h) := by
  have hc := summable_pureLeftCountTerm q a h
  have hb := summable_pureLeftBaselineTerm q h
    (admissibleInteriorCount q a h : ℝ)
  exact (hc.add hb.neg).congr (fun e => by
    rw [pureLeftPairTerm_eq_count_sub_baseline]
    ring)

#print axioms summable_pureLeftPairTerm

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem primeSetProduct_squarefree
    {s : Finset ℕ} (hs : ∀ p ∈ s, p.Prime) :
    Squarefree (primeSetProduct s) := by
  induction s using Finset.induction_on with
  | empty =>
      simp [primeSetProduct]
  | @insert a s ha ih =>
      have haPrime : a.Prime := hs a (Finset.mem_insert_self a s)
      have hsPrime : ∀ p ∈ s, p.Prime := by
        intro p hp
        exact hs p (Finset.mem_insert_of_mem hp)
      have hsqS := ih hsPrime
      have hcop : a.Coprime (primeSetProduct s) := by
        unfold primeSetProduct
        apply Nat.Coprime.prod_right
        intro p hp
        exact haPrime.coprime_iff_not_dvd.mpr (by
          intro hap
          have hcases := (Nat.dvd_prime (hsPrime p hp)).mp hap
          rcases hcases with h1 | heq
          · exact haPrime.ne_one h1
          · exact ha (heq ▸ hp))
      unfold primeSetProduct
      rw [Finset.prod_insert ha]
      rw [squarefree_mul_iff]
      exact ⟨Nat.coprime_iff_isRelPrime.mp hcop, haPrime.squarefree, hsqS⟩

def PrimeFinset := {s : Finset ℕ // ∀ p ∈ s, p.Prime}

def SquarefreeNat := {n : ℕ // Squarefree n}

noncomputable def primeFinsetEquivSquarefreeNat :
    PrimeFinset ≃ SquarefreeNat where
  toFun s :=
    ⟨primeSetProduct s.1, primeSetProduct_squarefree s.2⟩
  invFun n :=
    ⟨n.1.primeFactors, fun p hp =>
      (Nat.mem_primeFactors.mp hp).1⟩
  left_inv s := by
    apply Subtype.ext
    exact Nat.primeFactors_prod s.2
  right_inv n := by
    apply Subtype.ext
    exact Nat.prod_primeFactors_of_squarefree n.2

#print axioms primeFinsetEquivSquarefreeNat

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem activePrimeSetProduct_coprime
    {q : ℕ} {s : Finset ℕ}
    (hs : ∀ p ∈ s, activeHighPrime q p) :
    (primeSetProduct s).Coprime (6 * q) := by
  unfold primeSetProduct
  apply Nat.Coprime.prod_left
  intro p hp
  have hA := hs p hp
  have hpPrime := hA.1
  apply hpPrime.coprime_iff_not_dvd.mpr
  intro hd
  rcases hpPrime.dvd_mul.mp hd with h6 | hq
  · have h23 : p ∣ 2 * 3 := by simpa using h6
    rcases hpPrime.dvd_mul.mp h23 with h2 | h3
    · rcases (Nat.dvd_prime Nat.prime_two).mp h2 with hp1 | hp2
      · exact hpPrime.ne_one hp1
      · subst p
        have h5 : 5 ≤ 2 := hA.2.1
        omega
    · rcases (Nat.dvd_prime Nat.prime_three).mp h3 with hp1 | hp3
      · exact hpPrime.ne_one hp1
      · subst p
        have h5 : 5 ≤ 3 := hA.2.1
        omega
  · exact hA.2.2 hq

theorem not_activePrimeSetProduct_not_coprime
    {q : ℕ} {s : Finset ℕ}
    (hsPrime : ∀ p ∈ s, p.Prime)
    (hnot : ¬ ∀ p ∈ s, activeHighPrime q p) :
    ¬ (primeSetProduct s).Coprime (6 * q) := by
  push Not at hnot
  obtain ⟨p, hpS, hpNotA⟩ := hnot
  have hpPrime := hsPrime p hpS
  have hpDivProd : p ∣ primeSetProduct s := by
    unfold primeSetProduct
    exact Finset.dvd_prod_of_mem (fun x : ℕ => x) hpS
  have hpDiv6q : p ∣ 6 * q := by
    by_cases hp5 : 5 ≤ p
    · have hpq : p ∣ q := by
        by_contra hpq
        exact hpNotA ⟨hpPrime, hp5, hpq⟩
      exact dvd_mul_of_dvd_right hpq 6
    · have hpLt : p < 5 := Nat.lt_of_not_ge hp5
      have hp2 : 2 ≤ p := hpPrime.two_le
      have hp234 : p = 2 ∨ p = 3 ∨ p = 4 := by omega
      have hp23 : p = 2 ∨ p = 3 := by
        rcases hp234 with hp2eq | hp3eq | hp4eq
        · exact Or.inl hp2eq
        · exact Or.inr hp3eq
        · subst p
          exact False.elim ((by decide : ¬ Nat.Prime 4) hpPrime)
      rcases hp23 with rfl | rfl
      · exact dvd_mul_of_dvd_left (by norm_num : 2 ∣ 6) q
      · exact dvd_mul_of_dvd_left (by norm_num : 3 ∣ 6) q
  intro hcop
  have hpcop : p.Coprime (6 * q) :=
    Nat.Coprime.of_dvd_left hpDivProd hcop
  exact (hpPrime.coprime_iff_not_dvd.mp hpcop) hpDiv6q

theorem pureLeftPairTerm_eq_moving_nat
    (q a h : ℕ) (s : PrimeFinset) :
    pureLeftPairTerm q a h s.1 =
      movingVCoeff q h (primeSetProduct s.1) *
        fixedQRowDelta q a h (primeSetProduct s.1) 1 := by
  have hsq : Squarefree (primeSetProduct s.1) :=
    primeSetProduct_squarefree s.2
  have hn0 : primeSetProduct s.1 ≠ 0 :=
    Nat.ne_of_gt (primeSetProduct_pos s.2)
  by_cases hA : ∀ p ∈ s.1, activeHighPrime q p
  · have hcop := activePrimeSetProduct_coprime hA
    have hRempty :
        ∀ p ∈ s.1 \ s.1,
          activeHighPrime q p ∧ ¬ p ∣ h := by
      simp
    have hdelta :=
      pairDelta_eq_fixedQRowDelta
        (q := q) (a := a) (h := h)
        (e := s.1) (e1 := s.1)
        hA hRempty
    have hmove :=
      movingVCoeff_eq_finiteVWeightReal
        (q := q) (h := h) (e := primeSetProduct s.1)
        hn0 hsq hcop
    have hpf : (primeSetProduct s.1).primeFactors = s.1 := by
      unfold primeSetProduct
      exact Nat.primeFactors_prod s.2
    rw [hpf] at hmove
    have hleft :
        pairLeftModulus s.1 = primeSetProduct s.1 := by
      rfl
    have hright :
        pairRightModulus s.1 s.1 = 1 := by
      simp [pairRightModulus, primeSetProduct]
    unfold pureLeftPairTerm
    rw [hdelta, hmove, hleft, hright]
    unfold pairCoefficient
    rw [if_pos hA]
    have hempty : s.1 \ s.1 = ∅ := Finset.sdiff_self s.1
    rw [hempty]
    simp [finiteOmegaWeightReal]
  · have hnotcop :=
      not_activePrimeSetProduct_not_coprime s.2 hA
    have hmove :
        movingVCoeff q h (primeSetProduct s.1) = 0 := by
      unfold movingVCoeff
      rw [if_neg hn0]
      rw [if_neg (by
        intro hc
        exact hnotcop hc.2)]
    unfold pureLeftPairTerm pairCoefficient
    rw [if_neg hA]
    simp [hmove]

#print axioms pureLeftPairTerm_eq_moving_nat

end PaperB.FixedQ
