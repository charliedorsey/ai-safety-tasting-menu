import PaperB.FixedQ.SignedForbiddenThalenFiniteRowIndicators
import PaperB.FixedQ.SignedForbiddenThalenFiniteDensityRows

open scoped BigOperators

namespace PaperB.FixedQ

private theorem thalen_weighted_three_sum_comm
    {α β γ : Type*} [DecidableEq α] [DecidableEq β] [DecidableEq γ]
    (E : Finset α) (B : α → Finset β) (Y : Finset γ)
    (w : α → ℝ) (lambda : γ → ℝ) (f : α → β → γ → ℝ) :
    (∑ e ∈ E, w e * (∑ b ∈ B e, ∑ y ∈ Y, lambda y * f e b y)) =
      ∑ y ∈ Y, lambda y * (∑ e ∈ E, w e * (∑ b ∈ B e, f e b y)) := by
  classical
  calc
    _ = ∑ e ∈ E, ∑ b ∈ B e, ∑ y ∈ Y, w e * (lambda y * f e b y) := by
      simp_rw [Finset.mul_sum]
    _ = ∑ e ∈ E, ∑ y ∈ Y, ∑ b ∈ B e, w e * (lambda y * f e b y) := by
      apply Finset.sum_congr rfl
      intro e he
      rw [Finset.sum_comm]
    _ = ∑ y ∈ Y, ∑ e ∈ E, ∑ b ∈ B e, w e * (lambda y * f e b y) := by
      rw [Finset.sum_comm]
    _ = ∑ y ∈ Y, lambda y * (∑ e ∈ E, w e * (∑ b ∈ B e, f e b y)) := by
      apply Finset.sum_congr rfl
      intro y hy
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro e he
      calc
        _ = w e * (lambda y * (∑ b ∈ B e, f e b y)) := by
          rw [Finset.mul_sum, Finset.mul_sum]
        _ = lambda y * (w e * (∑ b ∈ B e, f e b y)) := by ring

/-- This is the literal finite constrained row mass of all proper Boolean
partitions, exchanged into Thalen's finite source packet. -/
theorem thalen_finite_rowMass_eq_weighted_sourcePacket
    (S : Finset ℕ) (H : ℕ) (lambda : ℕ → ℝ)
    (hp : ∀ p ∈ S, p.Prime) :
    (∑ e ∈ S.powerset,
      finiteOmegaWeightReal e *
        (∑ B ∈ ((e.powerset.erase e).erase ∅),
          rowConstrainedMass lambda H (primeSetProduct B)
            (primeSetProduct (e \ B)))) =
      ∑ y ∈ Finset.Ioo 0 H,
        lambda y * thalenFiniteProperSourcePacket S H y := by
  have hprime (e : Finset ℕ) (he : e ∈ S.powerset) :
      ∀ p ∈ e, p.Prime := by
    intro p hpe
    exact hp p ((Finset.mem_powerset.mp he) hpe)
  have hmass :
      (∑ e ∈ S.powerset,
        finiteOmegaWeightReal e *
          (∑ B ∈ ((e.powerset.erase e).erase ∅),
            rowConstrainedMass lambda H (primeSetProduct B)
              (primeSetProduct (e \ B)))) =
      (∑ e ∈ S.powerset,
        finiteOmegaWeightReal e *
          (∑ B ∈ ((e.powerset.erase e).erase ∅),
            ∑ y ∈ Finset.Ioo 0 H,
              lambda y *
              ((∏ p ∈ B, if p ∣ y then (1 : ℝ) else 0) *
               (∏ p ∈ e \ B, if p ∣ H-y then (1 : ℝ) else 0)))) := by
    apply Finset.sum_congr rfl
    intro e he
    congr 1
    apply Finset.sum_congr rfl
    intro B hB
    have hsub : B ⊆ e :=
      Finset.mem_powerset.mp
        (Finset.mem_of_mem_erase (Finset.mem_of_mem_erase hB))
    exact thalen_rowConstrainedMass_eq_local_indicators lambda H B (e \ B)
      (fun p hpB => hprime e he p (hsub hpB))
      (fun p hpB => hprime e he p (Finset.mem_sdiff.mp hpB).1)
  rw [hmass]
  have hswap := thalen_weighted_three_sum_comm
    S.powerset
    (fun e => ((e.powerset.erase e).erase ∅))
    (Finset.Ioo 0 H) finiteOmegaWeightReal lambda
    (fun e B y =>
       (∏ p ∈ B, if p ∣ y then (1 : ℝ) else 0) *
       (∏ p ∈ e \ B, if p ∣ H-y then (1 : ℝ) else 0))
  rw [hswap]
  rfl

#print axioms thalen_finite_rowMass_eq_weighted_sourcePacket

end PaperB.FixedQ
