import GoldC.QuillonDecorationGronwall
import GoldC.QuillonPrimeSum

/-!
# Quillon CSC3 F7.5b: pointwise source weights and the `1/y²` tail

* `omega_pointwise`: for a set `B` of primes `≥ 5` with `∏B ≤ R`,
  `∏_{p∈B} 1/(p−3) ≤ e^{37.5}·(1 + log₂log₂R)^{30} / ∏B`, i.e. `ω(y) ≤ A(R)/y` with `A = L^{O(1)}`.
* `sum_inv_sq_tail`: `Σ_{y∈S, y≥X} 1/y² ≤ 2/X` for `X ≥ 2`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonOmega

lemma inv_sub3_le (p : ℕ) (hp : 5 ≤ p) : 3 / ((p : ℝ) - 3) ≤ 7.5 * (1 / (p : ℝ)) := by
  have hpR : (5 : ℝ) ≤ p := by exact_mod_cast hp
  rw [div_le_iff₀ (by linarith), mul_one_div, div_mul_eq_mul_div, le_div_iff₀ (by linarith)]
  nlinarith

lemma sum_inv_split (B : Finset ℕ) (hB : ∀ p ∈ B, p.Prime) (K : ℕ) :
    ∑ p ∈ B, (1 / (p : ℝ)) ≤ 4 * (harmonic K : ℝ) + (B.card : ℝ) / 2 ^ (K + 1) := by
  classical
  rw [← sum_filter_add_sum_filter_not B (fun p => p < 2 ^ (K + 1))]
  apply add_le_add
  · refine (sum_le_sum_of_subset_of_nonneg ?_ fun _ _ _ => by positivity).trans
      (GoldC.QuillonCopyG.sum_inv_primes_below_two_pow K)
    intro p hp
    simp only [mem_filter] at hp
    simp only [GoldC.QuillonCopyG.primesBelowPow, mem_filter, mem_range]
    exact ⟨hp.2, hB p hp.1⟩
  · calc ∑ p ∈ B.filter (fun p => ¬ p < 2 ^ (K + 1)), (1 / (p : ℝ))
        ≤ ∑ _p ∈ B.filter (fun p => ¬ p < 2 ^ (K + 1)), (1 / (2 : ℝ) ^ (K + 1)) := by
          refine sum_le_sum fun p hp => ?_
          simp only [mem_filter, not_lt] at hp
          have : (2 : ℝ) ^ (K + 1) ≤ p := by exact_mod_cast hp.2
          exact one_div_le_one_div_of_le (by positivity) this
      _ ≤ ∑ _p ∈ B, (1 / (2 : ℝ) ^ (K + 1)) :=
          sum_le_sum_of_subset_of_nonneg (filter_subset _ _) fun _ _ _ => by positivity
      _ = (B.card : ℝ) / 2 ^ (K + 1) := by rw [sum_const, nsmul_eq_mul]; ring

lemma card_le_log (B : Finset ℕ) (hB : ∀ p ∈ B, p.Prime) :
    B.card ≤ Nat.log 2 (∏ p ∈ B, p) := by
  apply Nat.le_log_of_pow_le (by norm_num)
  calc 2 ^ B.card = ∏ _p ∈ B, 2 := by rw [prod_const]
    _ ≤ ∏ p ∈ B, p := prod_le_prod' fun p hp => (hB p hp).two_le

theorem omega_pointwise (B : Finset ℕ) (hB : ∀ p ∈ B, p.Prime ∧ 5 ≤ p) (R : ℕ)
    (hR : ∏ p ∈ B, p ≤ R) :
    ∏ p ∈ B, (1 / ((p : ℝ) - 3)) ≤
      Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 R) : ℝ) ^ 30 / (∏ p ∈ B, (p : ℝ)) := by
  set K := Nat.log 2 (Nat.log 2 R) with hK
  have hBp : ∀ p ∈ B, p.Prime := fun p hp => (hB p hp).1
  have hprodpos : (0 : ℝ) < ∏ p ∈ B, (p : ℝ) :=
    prod_pos fun p hp => by have := (hB p hp).1.pos; exact_mod_cast this
  -- ∏ p/(p-3) = ∏ (1 + 3/(p-3)) ≤ exp(Σ 3/(p-3)) ≤ exp(7.5 Σ 1/p)
  have h1 : (∏ p ∈ B, (p : ℝ)) * ∏ p ∈ B, (1 / ((p : ℝ) - 3)) = ∏ p ∈ B, (1 + 3 / ((p : ℝ) - 3)) := by
    rw [← prod_mul_distrib]
    refine prod_congr rfl fun p hp => ?_
    have h5 : (5 : ℝ) ≤ p := by exact_mod_cast (hB p hp).2
    have hne : (p : ℝ) - 3 ≠ 0 := by linarith
    field_simp; ring
  have h2 : ∏ p ∈ B, (1 + 3 / ((p : ℝ) - 3)) ≤ Real.exp (∑ p ∈ B, 3 / ((p : ℝ) - 3)) :=
    GoldC.QuillonCopyG.prod_one_add_le_exp_sum B _ fun p hp => by
      have h5 : (5 : ℝ) ≤ p := by exact_mod_cast (hB p hp).2
      apply div_nonneg (by norm_num); linarith
  have h3 : ∑ p ∈ B, 3 / ((p : ℝ) - 3) ≤ 7.5 * ∑ p ∈ B, (1 / (p : ℝ)) := by
    rw [mul_sum]; exact sum_le_sum fun p hp => inv_sub3_le p (hB p hp).2
  have h4 := sum_inv_split B hBp K
  have hcard : (B.card : ℝ) / 2 ^ (K + 1) ≤ 1 := by
    rw [div_le_one (by positivity)]
    have hc := card_le_log B hBp
    have hlog : Nat.log 2 (∏ p ∈ B, p) ≤ Nat.log 2 R := Nat.log_mono_right hR
    have : Nat.log 2 R < 2 ^ (K + 1) := Nat.lt_pow_succ_log_self (by norm_num) _
    exact_mod_cast (hc.trans hlog).trans this.le
  have hH : (harmonic K : ℝ) ≤ 1 + Real.log K := by exact_mod_cast harmonic_le_one_add_log K
  have hlogK : Real.log K ≤ Real.log (1 + K) := by
    rcases Nat.eq_zero_or_pos K with h | h
    · simp [h]
    · exact Real.log_le_log (by exact_mod_cast h) (by linarith)
  have hexp : Real.exp (∑ p ∈ B, 3 / ((p : ℝ) - 3)) ≤ Real.exp 37.5 * (1 + (K : ℝ)) ^ 30 := by
    have hK1 : (0 : ℝ) < 1 + K := by positivity
    rw [← Real.exp_log (pow_pos hK1 30), ← Real.exp_add, Real.log_pow]
    apply Real.exp_le_exp.2
    push_cast
    nlinarith
  rw [le_div_iff₀ hprodpos, mul_comm, h1]
  exact h2.trans (by push_cast at hexp ⊢; exact hexp)

lemma sum_inv_sq_tail (S : Finset ℕ) (X : ℕ) (hX : 2 ≤ X) :
    ∑ y ∈ S.filter (fun y => X ≤ y), (1 / ((y : ℝ) ^ 2)) ≤ (2 : ℝ) / X := by
  classical
  set Y := S.sup id
  have hsub : S.filter (fun y => X ≤ y) ⊆ Ioc (X - 1) (max Y X) := by
    intro y hy
    simp only [mem_filter] at hy
    simp only [mem_Ioc]
    refine ⟨by omega, ?_⟩
    exact (le_sup (f := id) hy.1).trans (le_max_left _ _)
  have hXR : (2 : ℝ) ≤ X := by exact_mod_cast hX
  calc _ ≤ ∑ n ∈ Ioc (X - 1) (max Y X), (1 / ((n : ℝ) * ((n : ℝ) - 1))) := by
        refine (sum_le_sum fun y hy => ?_).trans (sum_le_sum_of_subset_of_nonneg hsub fun n hn _ => ?_)
        · have hyX : (X : ℝ) ≤ y := by exact_mod_cast (mem_filter.1 hy).2
          apply one_div_le_one_div_of_le (by nlinarith)
          nlinarith
        · have : (X : ℝ) ≤ n := by
            have := (mem_Ioc.1 hn).1; exact_mod_cast (show X ≤ n by omega)
          apply div_nonneg zero_le_one; nlinarith
    _ = 1 / ((X - 1 : ℕ) : ℝ) - 1 / ((max Y X : ℕ) : ℝ) :=
        GoldC.QuillonPrimeSum.telescope_inv (X - 1) (by omega) _ (by omega)
    _ ≤ 1 / ((X - 1 : ℕ) : ℝ) := by
        have : (0 : ℝ) ≤ 1 / ((max Y X : ℕ) : ℝ) := by positivity
        linarith
    _ ≤ (2 : ℝ) / X := by
        have hX1 : ((X - 1 : ℕ) : ℝ) = (X : ℝ) - 1 := by push_cast [Nat.cast_sub (by omega : 1 ≤ X)]; ring
        rw [hX1, div_le_div_iff₀ (by linarith) (by linarith)]
        linarith

end GoldC.QuillonOmega

#print axioms GoldC.QuillonOmega.omega_pointwise
#print axioms GoldC.QuillonOmega.sum_inv_sq_tail
