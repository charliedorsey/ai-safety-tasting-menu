import GoldC.QuillonRPhysical

/-!
# Quillon CSC3 F8.13: residue A and the band (crude sieve, REVISION 2a), physical

* `rough_ev`: the rough-set mass `Σ_{B rough} ω(B) ≤ Λ^{1/4000}(1 + u^{−5})`, eventually.
* `ResA_physical`: residue A (R-cell mask with `C ∩ J_R = ∅`) is `≤ Λ^{1/10}`.
* `Band_physical`: the band (`r < s^{1+ε}`, `s < r^{1+3ε}`, not W′) is `≤ Λ^{0.998}`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonResPhysical

open GoldC.QuillonEv GoldC.QuillonSetup GoldC.QuillonLam GoldC.QuillonCEv GoldC.QuillonCFinal
  GoldC.QuillonREv GoldC.QuillonWContext

/-- the rough-set mass, eventually. -/
theorem rough_ev :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ h : ℕ, Λ₀ ≤ Real.log h → ∀ (T : Finset ℕ), (∀ p ∈ T, p.Prime ∧ 5 ≤ p) →
      ∀ (Xt : ℕ), (Xt : ℝ) ≤ 3 * (Real.log h) ^ (200 : ℝ) →
      ∀ (u : ℝ), 0 < u → u ≤ 1 → 16 * Real.log h ≤ Real.exp (5 * u * (Real.log h) ^ σ₀) →
      ∑ B ∈ T.powerset, (if ⌈Real.exp (5 * (Real.log h) ^ σ₀)⌉₊ ≤ ∏ p ∈ B, p ∧ ∏ p ∈ B, p ≤ h ∧
          ∀ p ∈ B, p < Xt ∨ ((∏ q ∈ B, q : ℕ) : ℝ) ^ u < p then ωR B else 0) ≤
        (Real.log h) ^ (1 / 4000 : ℝ) * (1 + 1 / u ^ 5) := by
  obtain ⟨Λ₁, hΛ₁, hpl⟩ := polylog_le 11 (1 / 8000) (by norm_num)
  obtain ⟨Λ₂, hΛ₂, hc⟩ := const_le_rpow (Real.exp 15 * 403 ^ 10 * 8748) (1 / 8000) (by norm_num)
  refine ⟨max 16 (max Λ₁ Λ₂), by norm_num, ?_⟩
  intro h hΛ T hT Xt hXt u hu0 hu1 hub
  have L1 : Λ₁ ≤ Real.log h := le_trans (by simp) hΛ
  have L2 : Λ₂ ≤ Real.log h := le_trans (by simp) hΛ
  have L0 : (16 : ℝ) ≤ Real.log h := le_trans (by simp) hΛ
  set Λ := Real.log h with hΛdef
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  have hlogΛ : 0 ≤ Real.log Λ := Real.log_nonneg hΛ1
  -- `h ≥ 8`, `m = log₂ h ≥ 3`
  have hh0 : (0 : ℝ) < h := by
    rcases Nat.eq_zero_or_pos h with h0 | h0
    · exfalso; rw [hΛdef, h0] at L0; simp at L0; linarith
    · exact_mod_cast h0
  set m := Nat.log 2 h with hm
  have hm2Λ : (m : ℝ) ≤ 2 * Λ := by
    have := natlog_le_of h Λ le_rfl
    rw [max_eq_left hΛ0.le] at this; exact this
  have hm3 : 3 ≤ m := by
    have h8 : 8 ≤ h := by
      by_contra hc'; push_neg at hc'
      have : (h : ℝ) ≤ 7 := by exact_mod_cast (by omega : h ≤ 7)
      have : Real.log h ≤ Real.log 7 := Real.log_le_log hh0 this
      have : Real.log 7 < 7 := lt_of_le_of_lt (Real.log_le_sub_one_of_pos (by norm_num)) (by norm_num)
      linarith
    have : Nat.log 2 8 ≤ Nat.log 2 h := Nat.log_mono_right h8
    have h83 : Nat.log 2 8 = 3 := by decide
    omega
  set k₀ := Nat.log 2 m + 3 with hk₀
  have hpow1 : 2 ^ Nat.log 2 m ≤ m := Nat.pow_log_le_self 2 (by omega)
  have hpow2 : m < 2 ^ (Nat.log 2 m + 1) := Nat.lt_pow_succ_log_self (by norm_num) m
  have e8 : 2 ^ k₀ = 8 * 2 ^ Nat.log 2 m := by rw [hk₀, pow_add]; ring
  have e2 : 2 ^ (Nat.log 2 m + 1) = 2 * 2 ^ Nat.log 2 m := by rw [pow_succ]; ring
  have hk₀le : (2 : ℝ) ^ k₀ ≤ 16 * Λ := by
    have : 2 ^ k₀ ≤ 8 * m := by rw [e8]; omega
    have : ((2 ^ k₀ : ℕ) : ℝ) ≤ 8 * m := by exact_mod_cast this
    push_cast at this; linarith
  have hk₀ge : 3 * (m : ℝ) ≤ (2 : ℝ) ^ k₀ - 3 := by
    have : 4 * m < 2 ^ k₀ := by rw [e8]; rw [e2] at hpow2; omega
    have : ((4 * m : ℕ) : ℝ) < ((2 ^ k₀ : ℕ) : ℝ) := by exact_mod_cast this
    push_cast at this
    have : (3 : ℝ) ≤ m := by exact_mod_cast hm3
    linarith
  -- `R₀^u ≥ exp(5uΛ^σ)`
  set R₀ := ⌈Real.exp (5 * Λ ^ σ₀)⌉₊ with hR₀
  have hR₀u : Real.exp (5 * u * Λ ^ σ₀) ≤ (R₀ : ℝ) ^ u := by
    have h1 : Real.exp (5 * Λ ^ σ₀) ≤ R₀ := Nat.le_ceil _
    calc Real.exp (5 * u * Λ ^ σ₀) = (Real.exp (5 * Λ ^ σ₀)) ^ u := by
          rw [← Real.exp_mul]; ring_nf
      _ ≤ (R₀ : ℝ) ^ u := Real.rpow_le_rpow (by positivity) h1 hu0.le
  have hK₀ : 3 ≤ k₀ := by omega
  set K := Nat.log 2 Xt with hK
  have hXK : ∀ p ∈ T, p < Xt → p < 2 ^ (K + 1) := fun p _ hp =>
    lt_trans hp (Nat.lt_pow_succ_log_self (by norm_num) Xt)
  have hrt := GoldC.QuillonResidue.rough_total T hT Xt u hu0 hu1 R₀ h k₀ K m hK₀
    (le_trans hk₀le (le_trans hub hR₀u)) hXK (Nat.lt_pow_succ_log_self (by norm_num) h)
  refine le_trans hrt ?_
  -- `κ ≤ e`
  have hκ : Real.exp (3 * (Nat.log 2 h : ℝ) / ((2 : ℝ) ^ k₀ - 3)) ≤ Real.exp 1 := by
    apply Real.exp_le_exp.2
    have h3m : (3 : ℝ) ≤ m := by exact_mod_cast hm3
    have hpos : 0 < (2 : ℝ) ^ k₀ - 3 := by linarith
    rw [div_le_one hpos]
    linarith
  -- `K + 1 ≤ 403(1 + log Λ)`
  have hKb : (K : ℝ) + 1 ≤ 403 * (1 + Real.log Λ) := by
    rcases Nat.eq_zero_or_pos Xt with h0 | hpos
    · rw [hK, h0]; simp; linarith
    · have hXt0 : (0 : ℝ) < Xt := by exact_mod_cast hpos
      have hlogX : Real.log Xt ≤ 2 + 200 * Real.log Λ := by
        have := Real.log_le_log hXt0 hXt
        rw [Real.log_mul (by norm_num) (by positivity), Real.log_rpow hΛ0] at this
        have : Real.log 3 ≤ 2 := by
          have := Real.log_le_sub_one_of_pos (show (0 : ℝ) < 3 by norm_num); linarith
        linarith
      have := natlog_le_of Xt (2 + 200 * Real.log Λ) hlogX
      rw [max_eq_left (by positivity)] at this
      linarith
  have hIb : 1 + Real.log ((m : ℝ) + 1) ≤ 3 * (1 + Real.log Λ) := by
    have h1 : (m : ℝ) + 1 ≤ 3 * Λ := by linarith
    have := Real.log_le_log (by positivity) h1
    rw [Real.log_mul (by norm_num) hΛ0.ne'] at this
    have : Real.log 3 ≤ 2 := by
      have := Real.log_le_sub_one_of_pos (show (0 : ℝ) < 3 by norm_num); linarith
    linarith
  have hP := hpl Λ L1
  have hC := hc Λ L2
  set P := 1 + Real.log Λ with hPdef
  have hP1 : 1 ≤ P := by rw [hPdef]; linarith
  have hu5 : 0 < u ^ 5 := by positivity
  have hK0 : (0 : ℝ) ≤ (K : ℝ) + 1 := by positivity
  have hKp : ((K : ℝ) + 1) ^ 10 ≤ 403 ^ 10 * P ^ 10 := by
    rw [← mul_pow]; exact pow_le_pow_left₀ hK0 hKb 10
  have hP10 : P ^ 10 ≤ P ^ 11 := pow_le_pow_right₀ hP1 (by norm_num)
  have hc8 : Real.exp 15 * 403 ^ 10 * 8748 * P ^ 11 ≤ Λ ^ (1 / 4000 : ℝ) := by
    calc Real.exp 15 * 403 ^ 10 * 8748 * P ^ 11 ≤ Λ ^ (1 / 8000 : ℝ) * Λ ^ (1 / 8000 : ℝ) :=
          mul_le_mul hC hP (by positivity) (by positivity)
      _ = Λ ^ (1 / 4000 : ℝ) := by rw [rp hΛ0]; norm_num
  have hlogI0 : 0 ≤ 1 + Real.log ((m : ℝ) + 1) := by
    have := Real.log_nonneg (show (1 : ℝ) ≤ m + 1 by linarith); linarith
  have hκ0 : 0 ≤ Real.exp (3 * (Nat.log 2 h : ℝ) / ((2 : ℝ) ^ k₀ - 3)) := (Real.exp_pos _).le
  have e5 : Real.exp 1 * Real.exp 4 = Real.exp 5 := by rw [← Real.exp_add]; norm_num
  have e15 : Real.exp 10 * Real.exp 5 = Real.exp 15 := by rw [← Real.exp_add]; norm_num
  calc Real.exp 10 * ((K : ℝ) + 1) ^ 10 *
        (1 + Real.exp (3 * (Nat.log 2 h : ℝ) / ((2 : ℝ) ^ k₀ - 3)) * Real.exp 4 * 2916 *
          (1 + Real.log ((m : ℝ) + 1)) / u ^ 5)
      ≤ Real.exp 10 * (403 ^ 10 * P ^ 10) *
        (1 + Real.exp 1 * Real.exp 4 * 2916 * (3 * P) / u ^ 5) := by
        gcongr
    _ = Real.exp 10 * 403 ^ 10 * P ^ 10 + Real.exp 15 * 403 ^ 10 * 8748 * P ^ 11 * (1 / u ^ 5) := by
        rw [e5, ← e15]; field_simp; ring
    _ ≤ Real.exp 15 * 403 ^ 10 * 8748 * P ^ 11 + Real.exp 15 * 403 ^ 10 * 8748 * P ^ 11 * (1 / u ^ 5) := by
        have h10 : Real.exp 10 ≤ Real.exp 15 * 8748 := by
          have := Real.exp_le_exp.2 (show (10 : ℝ) ≤ 15 by norm_num)
          nlinarith [Real.exp_pos 15]
        have hp10 : 0 ≤ P ^ 10 := by positivity
        apply add_le_add _ le_rfl
        calc Real.exp 10 * 403 ^ 10 * P ^ 10 ≤ (Real.exp 15 * 8748) * 403 ^ 10 * P ^ 10 := by gcongr
          _ = Real.exp 15 * 403 ^ 10 * 8748 * P ^ 10 := by ring
          _ ≤ Real.exp 15 * 403 ^ 10 * 8748 * P ^ 11 := by gcongr
    _ ≤ Λ ^ (1 / 4000 : ℝ) + Λ ^ (1 / 4000 : ℝ) * (1 / u ^ 5) := by gcongr
    _ = Λ ^ (1 / 4000 : ℝ) * (1 + 1 / u ^ 5) := by ring


/-- generic absolute bound for a masked double sum. -/
lemma dsum_bound (T : Finset ℕ) (hT : ∀ p ∈ T, 5 ≤ p) (c : Finset ℕ → Finset ℕ → Prop)
    [∀ B C, Decidable (c B C)] (cB : Finset ℕ → Prop) [DecidablePred cB]
    (cC : Finset ℕ → Finset ℕ → Prop) [∀ B C, Decidable (cC B C)]
    (hc : ∀ B ∈ T.powerset, ∀ C ∈ T.powerset, c B C → cB B ∧ cC B C)
    (F : Finset ℕ → Finset ℕ → ℝ) (Fm : ℝ) (hFm : 0 ≤ Fm)
    (hF : ∀ B C, c B C → |F B C| ≤ Fm) (IM : ℝ)
    (hIM : ∀ B ∈ T.powerset, cB B → ∑ C ∈ T.powerset, (if cC B C then ωR C else 0) ≤ IM) :
    |∑ B ∈ T.powerset, ∑ C ∈ T.powerset, (if c B C then ωR B * ωR C * F B C else 0)| ≤
      Fm * ((∑ B ∈ T.powerset, (if cB B then ωR B else 0)) * IM) := by
  have hω : ∀ B ∈ T.powerset, 0 ≤ ωR B := fun B hB =>
    ωR_nonneg B fun p hp => hT p (mem_powerset.1 hB hp)
  calc _ ≤ ∑ B ∈ T.powerset, |∑ C ∈ T.powerset, (if c B C then ωR B * ωR C * F B C else 0)| :=
        abs_sum_le_sum_abs _ _
    _ ≤ ∑ B ∈ T.powerset, (if cB B then ωR B else 0) * (Fm * IM) := by
        refine sum_le_sum fun B hB => ?_
        by_cases hcB : cB B
        · rw [if_pos hcB]
          calc |∑ C ∈ T.powerset, (if c B C then ωR B * ωR C * F B C else 0)|
              ≤ ∑ C ∈ T.powerset, |(if c B C then ωR B * ωR C * F B C else 0)| := abs_sum_le_sum_abs _ _
            _ ≤ ∑ C ∈ T.powerset, ωR B * Fm * (if cC B C then ωR C else 0) := by
                refine sum_le_sum fun C hC => ?_
                by_cases hcc : c B C
                · rw [if_pos hcc, if_pos (hc B hB C hC hcc).2, abs_mul, abs_mul,
                    abs_of_nonneg (hω B hB), abs_of_nonneg (hω C hC)]
                  have h1 := hF B C hcc
                  have h2 := hω B hB; have h3 := hω C hC
                  calc ωR B * ωR C * |F B C| ≤ ωR B * ωR C * Fm :=
                        mul_le_mul_of_nonneg_left h1 (mul_nonneg h2 h3)
                    _ = ωR B * Fm * ωR C := by ring
                · rw [if_neg hcc, abs_zero]
                  have : 0 ≤ (if cC B C then ωR C else 0) := by
                    split_ifs; exact hω C hC; exact le_rfl
                  have := hω B hB
                  positivity
            _ = ωR B * Fm * ∑ C ∈ T.powerset, (if cC B C then ωR C else 0) := by rw [mul_sum]
            _ ≤ ωR B * Fm * IM := by
                apply mul_le_mul_of_nonneg_left (hIM B hB hcB)
                have := hω B hB; positivity
            _ = ωR B * (Fm * IM) := by ring
        · rw [if_neg hcB, zero_mul]
          rw [sum_eq_zero fun C hC => by rw [if_neg]; exact fun h => hcB (hc B hB C hC h).1, abs_zero]
    _ = Fm * ((∑ B ∈ T.powerset, (if cB B then ωR B else 0)) * IM) := by rw [← sum_mul]; ring

end GoldC.QuillonResPhysical

namespace GoldC.QuillonResPhysical

open Classical
open GoldC.QuillonEv GoldC.QuillonSetup GoldC.QuillonLam GoldC.QuillonCEv GoldC.QuillonCFinal
  GoldC.QuillonREv GoldC.QuillonWContext GoldC.QuillonRPhysical
open GoldC.QuillonCopyS GoldC.QuillonCopyF GoldC.QuillonCopyM GoldC.QuillonWPhysical

/-- residue A: the R-cell mask with `C ∩ J_R(B) = ∅`. -/
noncomputable def ResAPart (Jlow Jhigh q a h : ℕ) (δ : ℝ) (d : Finset ℕ) : ℝ :=
  ∑ B ∈ (Tsrc q h d).powerset, ∑ C ∈ (Tsrc q h d).powerset,
    if B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C ∧
        (Mk0 Jlow Jhigh h (h / primeSetProduct d) δ B C ∧ ¬ WMask h δ (Tsrc q h d) B C ∧
          ¬ (((primeSetProduct C : ℕ) : ℝ) ^ (1 + εp h) ≤ ((primeSetProduct B : ℕ) : ℝ)) ∧
          ((primeSetProduct B : ℕ) : ℝ) ^ (1 + 3 * εp h) ≤ ((primeSetProduct C : ℕ) : ℝ) ∧
          ¬ (C ∩ JR h (Tsrc q h d) B).Nonempty) then
      omegaWeight B * omegaWeight C *
        foldRow q a (primeSetProduct d) (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct C)
    else 0

/-- the band: not W′, `r < s^{1+ε}`, `s < r^{1+3ε}`. -/
noncomputable def BandPart (Jlow Jhigh q a h : ℕ) (δ : ℝ) (d : Finset ℕ) : ℝ :=
  ∑ B ∈ (Tsrc q h d).powerset, ∑ C ∈ (Tsrc q h d).powerset,
    if B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C ∧
        (Mk0 Jlow Jhigh h (h / primeSetProduct d) δ B C ∧ ¬ WMask h δ (Tsrc q h d) B C ∧
          ¬ (((primeSetProduct C : ℕ) : ℝ) ^ (1 + εp h) ≤ ((primeSetProduct B : ℕ) : ℝ)) ∧
          ¬ (((primeSetProduct B : ℕ) : ℝ) ^ (1 + 3 * εp h) ≤ ((primeSetProduct C : ℕ) : ℝ))) then
      omegaWeight B * omegaWeight C *
        foldRow q a (primeSetProduct d) (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct C)
    else 0

lemma ceil_le_of_log {Λ : ℝ} {n : ℕ} (hn : 5 * Λ ^ σ₀ ≤ Real.log n) (hn1 : 1 ≤ n) :
    ⌈Real.exp (5 * Λ ^ σ₀)⌉₊ ≤ n := by
  apply Nat.ceil_le.2
  have hn0 : (0 : ℝ) < n := by exact_mod_cast hn1
  calc Real.exp (5 * Λ ^ σ₀) ≤ Real.exp (Real.log n) := Real.exp_le_exp.2 hn
    _ = n := Real.exp_log hn0

lemma gt_floor_real {y : ℝ} (hy : 0 ≤ y) {p : ℕ} (hp : ⌊y⌋₊ < p) : y < p := by
  have h1 := Nat.lt_floor_add_one y
  have : (⌊y⌋₊ : ℝ) + 1 ≤ p := by exact_mod_cast hp
  linarith

set_option maxHeartbeats 4000000 in
/-- **Residue A is `≤ Λ^{1/10}`.** -/
theorem ResA_physical (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (Jlow Jhigh a h : ℕ) (d : Finset ℕ), Λ₀ ≤ Real.log h → 2 ≤ h →
      |ResAPart Jlow Jhigh q a h δ d| ≤ (Real.log h) ^ (1 / 10 : ℝ) := by
  have hu0 : 0 < u0 δ := by have := a0_pos hδ0 hδ1; unfold u0; linarith
  have hu1 : u0 δ ≤ 1 / 8 := by have := a0_le hδ0; unfold u0; linarith
  set Fm : ℝ := 4 + 48 * q with hFm
  set K : ℝ := 33 * Fm * (1 + 1 / u0 δ ^ 5) with hK
  obtain ⟨Λ₁, hΛ₁, hro⟩ := rough_ev
  obtain ⟨Λ₂, hΛ₂, hE1⟩ := GoldC.QuillonAsymp.rpow_le_exp_rpow 2 (5 * u0 δ) σ₀ (by norm_num) (by positivity)
    σ₀_pos
  obtain ⟨Λ₃, hΛ₃, hE2⟩ := GoldC.QuillonAsymp.rpow_le_exp_rpow 2 (5 / 2) (σ₀ - 1 / 200) (by norm_num)
    (by norm_num) (by unfold σ₀; norm_num)
  obtain ⟨Λ₄, hΛ₄, hKc⟩ := const_le_rpow K (1 / 10 - 1 / 40 - 1 / 2000) (by norm_num)
  refine ⟨max 16 (max Λ₁ (max Λ₂ (max Λ₃ Λ₄))), by norm_num, ?_⟩
  intro Jlow Jhigh a h d hΛ hh
  have L0 : (16 : ℝ) ≤ Real.log h := le_trans (by simp) hΛ
  have L1 : Λ₁ ≤ Real.log h := le_trans (by simp) hΛ
  have L2 : Λ₂ ≤ Real.log h := le_trans (by simp) hΛ
  have L3 : Λ₃ ≤ Real.log h := le_trans (by simp) hΛ
  have L4 : Λ₄ ≤ Real.log h := le_trans (by simp) hΛ
  clear hΛ
  set Λ := Real.log h with hΛdef
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  set H := h / primeSetProduct d with hH
  set T := Tsrc q h d with hT
  have hTf := Tsrc_facts q h d
  have hHh : H ≤ h := Nat.div_le_self _ _
  obtain ⟨hε0, hε1⟩ := GoldC.QuillonCPhysical.εp_le_one (h := h) hΛ1
  set ε := εp h with hεdef
  have hεpos : 0 < ε := by rw [hεdef]; unfold εp; positivity
  set R₀ := ⌈Real.exp (5 * Λ ^ σ₀)⌉₊ with hR₀
  have hX1 : 1 ≤ Xp h := by have := Xp_two (h := h) (by linarith); omega
  have hXle := Xp_le (h := h) hΛ1
  -- the mask implications
  have hc : ∀ B ∈ T.powerset, ∀ C ∈ T.powerset,
      (B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C ∧
        (Mk0 Jlow Jhigh h H δ B C ∧ ¬ WMask h δ T B C ∧
          ¬ (((primeSetProduct C : ℕ) : ℝ) ^ (1 + ε) ≤ ((primeSetProduct B : ℕ) : ℝ)) ∧
          ((primeSetProduct B : ℕ) : ℝ) ^ (1 + 3 * ε) ≤ ((primeSetProduct C : ℕ) : ℝ) ∧
          ¬ (C ∩ JR h T B).Nonempty)) →
      (R₀ ≤ ∏ p ∈ B, p ∧ ∏ p ∈ B, p ≤ h ∧
          ∀ p ∈ B, p < Xp h ∨ ((∏ q ∈ B, q : ℕ) : ℝ) ^ u0 δ < p) ∧
        (R₀ ≤ ∏ p ∈ C, p ∧ ∏ p ∈ C, p ≤ h ∧
          ∀ p ∈ C, p < Xp h + 1 ∨ ((∏ q ∈ C, q : ℕ) : ℝ) ^ (ε / 2) < p) := by
    intro B hB C hC ⟨_, _, hdisj, hMk, hW, _, hSm, hJR⟩
    have hBT : B ⊆ T := mem_powerset.1 hB
    have hCT : C ⊆ T := mem_powerset.1 hC
    have hCB : C ⊆ T \ B := fun p hp => mem_sdiff.2 ⟨hCT hp, fun hpB => disjoint_left.1 hdisj hpB hp⟩
    have hG : Geo0 h H δ (∏ p ∈ B, p) (∏ p ∈ C, p) := by
      obtain ⟨h1, h2, -, -, h5, h6⟩ := hMk; exact ⟨h1, h2, h5, h6⟩
    obtain ⟨hlogs, hlogr, hr1, hs1, hrh, hsh, hrs, hsr, -⟩ := adm h H _ _ δ hδ0 hδ1 hh hHh hG
    set r := ∏ p ∈ B, p
    set s := ∏ p ∈ C, p
    have hrR : (1 : ℝ) ≤ r := by exact_mod_cast hr1
    have hsR : (1 : ℝ) ≤ s := by exact_mod_cast hs1
    have hr0 : (0 : ℝ) < r := by linarith
    have hs0 : (0 : ℝ) < s := by linarith
    have hrs' : (r : ℝ) ≤ s := by
      have : (r : ℝ) ≤ (r : ℝ) ^ (1 + 3 * ε) :=
        le_trans (le_of_eq (Real.rpow_one _).symm) (Real.rpow_le_rpow_of_exponent_le hrR (by linarith))
      exact le_trans this hSm
    refine ⟨⟨ceil_le_of_log hlogr hr1, by exact_mod_cast hrh, ?_⟩,
      ⟨ceil_le_of_log hlogs hs1, by exact_mod_cast hsh, ?_⟩⟩
    · intro p hp
      have hnot := (notW_iff h δ T B C hBT hCB).1 hW p hp
      by_cases hpX : p < Xp h
      · exact Or.inl hpX
      · right
        have hpY : Yp δ s < p := by push_neg at hpX; by_contra hc'; push_neg at hc'; exact hnot ⟨hpX, hc'⟩
        have h1 : (s : ℝ) ^ u0 δ < p := gt_floor_real (by positivity) hpY
        exact lt_of_le_of_lt (Real.rpow_le_rpow hr0.le hrs' hu0.le) h1
    · intro p hp
      have hpJ : ¬ (Xp h < p ∧ p ≤ 2 ^ Kvp h r * Xp h) := by
        intro hJ
        exact hJR ⟨p, mem_inter.2 ⟨hp, mem_filter.2 ⟨hCB hp, hJ⟩⟩⟩
      by_cases hpX : p ≤ Xp h
      · exact Or.inl (by omega)
      · right
        push_neg at hpX
        have hp2 : 2 ^ Kvp h r * Xp h < p := by
          by_contra hc'; push_neg at hc'; exact hpJ ⟨hpX, hc'⟩
        have hρ1 : (1 : ℝ) ≤ (r : ℝ) ^ ε := Real.one_le_rpow hrR hε0
        obtain ⟨hKv1, -⟩ := Kv_bounds ((r : ℝ) ^ ε) hρ1 (Kvp h r) rfl
        have hX1R : (1 : ℝ) ≤ Xp h := by exact_mod_cast hX1
        have h3 : (r : ℝ) ^ ε < p := by
          have : ((2 ^ Kvp h r * Xp h : ℕ) : ℝ) < p := by exact_mod_cast hp2
          push_cast at this
          nlinarith
        -- `s^{ε/2} ≤ r^ε` since `s ≤ r²`
        have hsr2 : (s : ℝ) ≤ (r : ℝ) ^ (2 : ℝ) :=
          le_trans hsr (Real.rpow_le_rpow_of_exponent_le hrR (by linarith))
        have h4 : (s : ℝ) ^ (ε / 2) ≤ (r : ℝ) ^ ε := by
          calc (s : ℝ) ^ (ε / 2) ≤ ((r : ℝ) ^ (2 : ℝ)) ^ (ε / 2) :=
                Real.rpow_le_rpow hs0.le hsr2 (by positivity)
            _ = (r : ℝ) ^ ε := by rw [← Real.rpow_mul hr0.le]; ring_nf
        exact lt_of_le_of_lt h4 h3
  have hTf5 : ∀ p ∈ T, 5 ≤ p := fun p hp => (hTf p hp).2.1
  have hTp : ∀ p ∈ T, p.Prime ∧ 5 ≤ p := fun p hp => ⟨(hTf p hp).1, (hTf p hp).2.1⟩
  -- the two rough masses
  have hubB : 16 * Λ ≤ Real.exp (5 * u0 δ * Λ ^ σ₀) := by
    have := hE2 Λ L3
    have h2 := hE1 Λ L2
    have : 16 * Λ ≤ Λ ^ (2 : ℝ) := by
      rw [show Λ ^ (2 : ℝ) = Λ * Λ by rw [show (2 : ℝ) = (2 : ℕ) by norm_num, Real.rpow_natCast]; ring]
      nlinarith
    linarith
  have hubC : 16 * Λ ≤ Real.exp (5 * (ε / 2) * Λ ^ σ₀) := by
    have h2 := hE2 Λ L3
    have e : 5 * (ε / 2) * Λ ^ σ₀ = 5 / 2 * Λ ^ (σ₀ - 1 / 200) := by
      rw [hεdef]; unfold εp
      rw [show 5 * (Λ ^ (-(1 / 200 : ℝ)) / 2) * Λ ^ σ₀ = 5 / 2 * (Λ ^ (-(1 / 200 : ℝ)) * Λ ^ σ₀) by ring,
        rp hΛ0]; ring_nf
    have : 16 * Λ ≤ Λ ^ (2 : ℝ) := by
      rw [show Λ ^ (2 : ℝ) = Λ * Λ by rw [show (2 : ℝ) = (2 : ℕ) by norm_num, Real.rpow_natCast]; ring]
      nlinarith
    rw [e]; linarith
  have hmB := hro h L1 T hTp (Xp h) (by linarith [hXle, show (0:ℝ) ≤ Λ ^ (200 : ℝ) by positivity])
    (u0 δ) hu0 (by linarith) hubB
  have hmC := hro h L1 T hTp (Xp h + 1)
    (by push_cast; have : (1 : ℝ) ≤ Λ ^ (200 : ℝ) := Real.one_le_rpow hΛ1 (by norm_num); linarith)
    (ε / 2) (by positivity) (by linarith) hubC
  unfold ResAPart
  have hmain := dsum_bound T hTf5 _ _ _ hc
    (fun B C => foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C)) Fm
    (by positivity) (fun B C _ => GoldC.QuillonBridge.abs_foldRow_le q a _ H _ _ hq) _
    (fun B _ _ => hmC)
  refine le_trans hmain ?_
  -- arithmetic
  have hε5 : 1 / (ε / 2) ^ 5 = 32 * Λ ^ (1 / 40 : ℝ) := by
    rw [hεdef]; unfold εp
    rw [div_pow, ← Real.rpow_natCast (Λ ^ (-(1 / 200 : ℝ))) 5, ← Real.rpow_mul hΛ0.le]
    have : Λ ^ (-(1 / 200 : ℝ) * ((5 : ℕ) : ℝ)) * Λ ^ (1 / 40 : ℝ) = 1 := by rw [rp hΛ0]; norm_num
    field_simp
    linarith
  rw [hε5] at hmC ⊢
  have hA0 : 0 ≤ ∑ B ∈ T.powerset, (if R₀ ≤ ∏ p ∈ B, p ∧ ∏ p ∈ B, p ≤ h ∧
      ∀ p ∈ B, p < Xp h ∨ ((∏ q ∈ B, q : ℕ) : ℝ) ^ u0 δ < p then ωR B else 0) :=
    sum_nonneg fun B hB => by
      split_ifs
      · exact ωR_nonneg B fun p hp => hTf5 p (mem_powerset.1 hB hp)
      · exact le_rfl
  have hKΛ := hKc Λ L4
  have h40 : 1 + 32 * Λ ^ (1 / 40 : ℝ) ≤ 33 * Λ ^ (1 / 40 : ℝ) := by
    have : 1 ≤ Λ ^ (1 / 40 : ℝ) := Real.one_le_rpow hΛ1 (by norm_num); linarith
  calc Fm * ((∑ B ∈ T.powerset, (if R₀ ≤ ∏ p ∈ B, p ∧ ∏ p ∈ B, p ≤ h ∧
        ∀ p ∈ B, p < Xp h ∨ ((∏ q ∈ B, q : ℕ) : ℝ) ^ u0 δ < p then ωR B else 0)) *
        (Λ ^ (1 / 4000 : ℝ) * (1 + 32 * Λ ^ (1 / 40 : ℝ))))
      ≤ Fm * ((Λ ^ (1 / 4000 : ℝ) * (1 + 1 / u0 δ ^ 5)) * (Λ ^ (1 / 4000 : ℝ) * (33 * Λ ^ (1 / 40 : ℝ)))) := by
        gcongr
    _ = K * (Λ ^ (1 / 4000 : ℝ) * Λ ^ (1 / 4000 : ℝ) * Λ ^ (1 / 40 : ℝ)) := by rw [hK]; ring
    _ = K * Λ ^ (1 / 2000 + 1 / 40 : ℝ) := by rw [rp hΛ0, rp hΛ0]; norm_num
    _ ≤ Λ ^ (1 / 10 - 1 / 40 - 1 / 2000 : ℝ) * Λ ^ (1 / 2000 + 1 / 40 : ℝ) :=
        mul_le_mul_of_nonneg_right hKΛ (by positivity)
    _ = Λ ^ (1 / 10 : ℝ) := by rw [rp hΛ0]; norm_num


set_option maxHeartbeats 4000000 in
/-- **The band is `≤ Λ^{0.998}`** (it saves `ε = Λ^{−1/200}` against the trivial `Λ`). -/
theorem Band_physical (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (Jlow Jhigh a h : ℕ) (d : Finset ℕ), Λ₀ ≤ Real.log h → 2 ≤ h →
      |BandPart Jlow Jhigh q a h δ d| ≤ (Real.log h) ^ (998 / 1000 : ℝ) := by
  have hu0 : 0 < u0 δ := by have := a0_pos hδ0 hδ1; unfold u0; linarith
  have hu1 : u0 δ ≤ 1 / 8 := by have := a0_le hδ0; unfold u0; linarith
  set Fm : ℝ := 4 + 48 * q with hFm
  set K : ℝ := 6 * Fm * (1 + 1 / (u0 δ / 2) ^ 5) with hK
  obtain ⟨Λ₁, hΛ₁, hro⟩ := rough_ev
  obtain ⟨Λ₂, hΛ₂, hE1⟩ := GoldC.QuillonAsymp.rpow_le_exp_rpow 2 (5 * (u0 δ / 2)) σ₀ (by norm_num)
    (by positivity) σ₀_pos
  obtain ⟨Λ₃, hΛ₃, hAω⟩ := Aω_le 5 (1 / 4000) (by norm_num) (by norm_num)
  obtain ⟨Λ₄, hΛ₄, hKc⟩ := const_le_rpow K (998 / 1000 - 1 / 2000 - 199 / 200) (by norm_num)
  obtain ⟨Λ₅, hΛ₅, hsl⟩ := s_large 4
  refine ⟨max 16 (max Λ₁ (max Λ₂ (max Λ₃ (max Λ₄ Λ₅)))), by norm_num, ?_⟩
  intro Jlow Jhigh a h d hΛ hh
  have L0 : (16 : ℝ) ≤ Real.log h := le_trans (by simp) hΛ
  have L1 : Λ₁ ≤ Real.log h := le_trans (by simp) hΛ
  have L2 : Λ₂ ≤ Real.log h := le_trans (by simp) hΛ
  have L3 : Λ₃ ≤ Real.log h := le_trans (by simp) hΛ
  have L4 : Λ₄ ≤ Real.log h := le_trans (by simp) hΛ
  have L5 : Λ₅ ≤ Real.log h := le_trans (by simp) hΛ
  clear hΛ
  set Λ := Real.log h with hΛdef
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  set H := h / primeSetProduct d with hH
  set T := Tsrc q h d with hT
  have hTf := Tsrc_facts q h d
  have hHh : H ≤ h := Nat.div_le_self _ _
  obtain ⟨hε0, hε1⟩ := GoldC.QuillonCPhysical.εp_le_one (h := h) hΛ1
  set ε := εp h with hεdef
  set R₀ := ⌈Real.exp (5 * Λ ^ σ₀)⌉₊ with hR₀
  have hX1 : 1 ≤ Xp h := by have := Xp_two (h := h) (by linarith); omega
  have hXle := Xp_le (h := h) hΛ1
  have hc : ∀ B ∈ T.powerset, ∀ C ∈ T.powerset,
      (B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C ∧
        (Mk0 Jlow Jhigh h H δ B C ∧ ¬ WMask h δ T B C ∧
          ¬ (((primeSetProduct C : ℕ) : ℝ) ^ (1 + ε) ≤ ((primeSetProduct B : ℕ) : ℝ)) ∧
          ¬ (((primeSetProduct B : ℕ) : ℝ) ^ (1 + 3 * ε) ≤ ((primeSetProduct C : ℕ) : ℝ)))) →
      (R₀ ≤ ∏ p ∈ B, p ∧ ∏ p ∈ B, p ≤ h ∧
          ∀ p ∈ B, p < Xp h ∨ ((∏ q ∈ B, q : ℕ) : ℝ) ^ (u0 δ / 2) < p) ∧
        (∏ p ∈ C, p) ∈ Ioc ⌊((∏ p ∈ B, p : ℕ) : ℝ) ^ (1 / (1 + ε))⌋₊ ⌊((∏ p ∈ B, p : ℕ) : ℝ) ^ (1 + 3 * ε)⌋₊ := by
    intro B hB C hC ⟨_, _, hdisj, hMk, hW, hBg, hSm⟩
    have hBT : B ⊆ T := mem_powerset.1 hB
    have hCT : C ⊆ T := mem_powerset.1 hC
    have hCB : C ⊆ T \ B := fun p hp => mem_sdiff.2 ⟨hCT hp, fun hpB => disjoint_left.1 hdisj hpB hp⟩
    have hG : Geo0 h H δ (∏ p ∈ B, p) (∏ p ∈ C, p) := by
      obtain ⟨h1, h2, -, -, h5, h6⟩ := hMk; exact ⟨h1, h2, h5, h6⟩
    obtain ⟨hlogs, hlogr, hr1, hs1, hrh, hsh, -, -, -⟩ := adm h H _ _ δ hδ0 hδ1 hh hHh hG
    set r := ∏ p ∈ B, p
    set s := ∏ p ∈ C, p
    have hrR : (1 : ℝ) ≤ r := by exact_mod_cast hr1
    have hsR : (1 : ℝ) ≤ s := by exact_mod_cast hs1
    have hr0 : (0 : ℝ) < r := by linarith
    have hs0 : (0 : ℝ) < s := by linarith
    have hBg' : (r : ℝ) < (s : ℝ) ^ (1 + ε) := by push_neg at hBg; exact hBg
    have hSm' : (s : ℝ) < (r : ℝ) ^ (1 + 3 * ε) := by push_neg at hSm; exact hSm
    have hrs : (r : ℝ) ^ (1 / (1 + ε)) < s := by
      calc (r : ℝ) ^ (1 / (1 + ε)) < ((s : ℝ) ^ (1 + ε)) ^ (1 / (1 + ε)) :=
            Real.rpow_lt_rpow hr0.le hBg' (by positivity)
        _ = s := by rw [← Real.rpow_mul hs0.le]; field_simp; simp
    refine ⟨⟨ceil_le_of_log hlogr hr1, by exact_mod_cast hrh, ?_⟩, ?_⟩
    · intro p hp
      have hnot := (notW_iff h δ T B C hBT hCB).1 hW p hp
      by_cases hpX : p < Xp h
      · exact Or.inl hpX
      · right
        have hpY : Yp δ s < p := by push_neg at hpX; by_contra hc'; push_neg at hc'; exact hnot ⟨hpX, hc'⟩
        have h1 : (s : ℝ) ^ u0 δ < p := gt_floor_real (by positivity) hpY
        have h2 : (r : ℝ) ^ (u0 δ / 2) ≤ (s : ℝ) ^ u0 δ := by
          calc (r : ℝ) ^ (u0 δ / 2) ≤ (r : ℝ) ^ (1 / (1 + ε) * u0 δ) := by
                apply Real.rpow_le_rpow_of_exponent_le hrR
                have : 1 / 2 ≤ 1 / (1 + ε) := by
                  rw [div_le_div_iff₀ (by norm_num) (by linarith)]; linarith
                nlinarith
            _ = ((r : ℝ) ^ (1 / (1 + ε))) ^ u0 δ := by rw [Real.rpow_mul hr0.le]
            _ ≤ (s : ℝ) ^ u0 δ := Real.rpow_le_rpow (by positivity) hrs.le hu0.le
        exact lt_of_le_of_lt h2 h1
    · rw [mem_Ioc]
      constructor
      · have : (⌊(r : ℝ) ^ (1 / (1 + ε))⌋₊ : ℝ) < s := lt_of_le_of_lt (Nat.floor_le (by positivity)) hrs
        exact_mod_cast this
      · exact Nat.le_floor hSm'.le
  have hTf5 : ∀ p ∈ T, 5 ≤ p := fun p hp => (hTf p hp).2.1
  have hTp : ∀ p ∈ T, p.Prime ∧ 5 ≤ p := fun p hp => ⟨(hTf p hp).1, (hTf p hp).2.1⟩
  have hubB : 16 * Λ ≤ Real.exp (5 * (u0 δ / 2) * Λ ^ σ₀) := by
    have h2 := hE1 Λ L2
    have : 16 * Λ ≤ Λ ^ (2 : ℝ) := by
      rw [show Λ ^ (2 : ℝ) = Λ * Λ by rw [show (2 : ℝ) = (2 : ℕ) by norm_num, Real.rpow_natCast]; ring]
      nlinarith
    linarith
  have hmB := hro h L1 T hTp (Xp h) (by linarith [hXle, show (0:ℝ) ≤ Λ ^ (200 : ℝ) by positivity])
    (u0 δ / 2) (by positivity) (by linarith) hubB
  -- the interval mass for each admissible `B`
  set IM : ℝ := Λ ^ (1 / 4000 : ℝ) * (6 * Λ ^ (199 / 200 : ℝ)) with hIM
  have hIMb : ∀ B ∈ T.powerset, (R₀ ≤ ∏ p ∈ B, p ∧ ∏ p ∈ B, p ≤ h ∧
        ∀ p ∈ B, p < Xp h ∨ ((∏ q ∈ B, q : ℕ) : ℝ) ^ (u0 δ / 2) < p) →
      ∑ C ∈ T.powerset, (if (∏ p ∈ C, p) ∈ Ioc ⌊((∏ p ∈ B, p : ℕ) : ℝ) ^ (1 / (1 + ε))⌋₊
        ⌊((∏ p ∈ B, p : ℕ) : ℝ) ^ (1 + 3 * ε)⌋₊ then ωR C else 0) ≤ IM := by
    intro B _ ⟨hR, hrh, _⟩
    set r := ∏ p ∈ B, p
    have hrR : Real.exp (5 * Λ ^ σ₀) ≤ r := le_trans (Nat.le_ceil _) (by exact_mod_cast hR)
    have hr0 : (0 : ℝ) < r := lt_of_lt_of_le (Real.exp_pos _) hrR
    have hr4 : (4 : ℝ) ≤ r := hsl Λ L5 r hr0 (by
      rw [← Real.log_exp (5 * Λ ^ σ₀)]; exact Real.log_le_log (Real.exp_pos _) hrR)
    have hr1 : (1 : ℝ) ≤ r := by linarith
    have hrh' : (r : ℝ) ≤ h := by exact_mod_cast hrh
    have hlogr : Real.log r ≤ Λ := Real.log_le_log hr0 hrh'
    set A := (r : ℝ) ^ (1 / (1 + ε))
    set Bb := (r : ℝ) ^ (1 + 3 * ε)
    have hA2 : 2 ≤ A := by
      calc (2 : ℝ) = (4 : ℝ) ^ (1 / 2 : ℝ) := by
            rw [show (4 : ℝ) = 2 ^ (2 : ℝ) by norm_num, ← Real.rpow_mul (by norm_num)]; norm_num
        _ ≤ (r : ℝ) ^ (1 / 2 : ℝ) := Real.rpow_le_rpow (by norm_num) hr4 (by norm_num)
        _ ≤ A := Real.rpow_le_rpow_of_exponent_le hr1 (by
            rw [div_le_div_iff₀ (by norm_num) (by linarith)]; linarith)
    have hAB : A ≤ Bb := Real.rpow_le_rpow_of_exponent_le hr1 (by
      rw [div_le_iff₀ (by linarith)]; nlinarith)
    have ha1 : 1 ≤ ⌊A⌋₊ := Nat.le_floor (by push_cast; linarith)
    have hab : ⌊A⌋₊ ≤ ⌊Bb⌋₊ := Nat.floor_le_floor hAB
    have hint := GoldC.QuillonResidue.interval_mass T hTp ⌊A⌋₊ ⌊Bb⌋₊ ha1 hab
    refine le_trans hint ?_
    have hb0 : (0 : ℝ) < (⌊Bb⌋₊ : ℝ) := by exact_mod_cast lt_of_lt_of_le ha1 hab
    have hBbr : Bb ≤ (r : ℝ) ^ (4 : ℝ) := Real.rpow_le_rpow_of_exponent_le hr1 (by linarith)
    have hlogb : Real.log (⌊Bb⌋₊ : ℝ) ≤ 5 * Λ := by
      have h1 : (⌊Bb⌋₊ : ℝ) ≤ (r : ℝ) ^ (4 : ℝ) := le_trans (Nat.floor_le (by positivity)) hBbr
      have := Real.log_le_log hb0 h1
      rw [Real.log_rpow hr0] at this; linarith
    have hAωb := hAω Λ L3 _ hlogb
    -- `log(b/a) ≤ 1 + 4εΛ`
    have hafl : A / 2 ≤ (⌊A⌋₊ : ℝ) := by have := Nat.lt_floor_add_one A; linarith
    have hratio : (⌊Bb⌋₊ : ℝ) / ⌊A⌋₊ ≤ 2 * (r : ℝ) ^ (4 * ε) := by
      have hA0 : (0 : ℝ) < ⌊A⌋₊ := by exact_mod_cast ha1
      rw [div_le_iff₀ hA0]
      have h1 : (⌊Bb⌋₊ : ℝ) ≤ Bb := Nat.floor_le (by positivity)
      have h2 : Bb ≤ (r : ℝ) ^ (4 * ε) * A := by
        rw [show (r : ℝ) ^ (4 * ε) * A = (r : ℝ) ^ (4 * ε + 1 / (1 + ε)) by rw [rp hr0]]
        apply Real.rpow_le_rpow_of_exponent_le hr1
        have : 1 - ε ≤ 1 / (1 + ε) := by
          rw [le_div_iff₀ (by linarith)]; nlinarith
        linarith
      have : 0 ≤ (r : ℝ) ^ (4 * ε) := by positivity
      nlinarith
    have hlogratio : Real.log ((⌊Bb⌋₊ : ℝ) / ⌊A⌋₊) ≤ 1 + 4 * ε * Λ := by
      have hpos : 0 < (⌊Bb⌋₊ : ℝ) / ⌊A⌋₊ := by
        have hA0 : (0 : ℝ) < ⌊A⌋₊ := by exact_mod_cast ha1
        positivity
      have := Real.log_le_log hpos hratio
      rw [Real.log_mul (by norm_num) (by positivity), Real.log_rpow hr0] at this
      have : Real.log 2 < 1 := by have := Real.log_two_lt_d9; linarith
      have : 4 * ε * Real.log r ≤ 4 * ε * Λ := by
        apply mul_le_mul_of_nonneg_left hlogr (by positivity)
      linarith
    have hεΛ : ε * Λ = Λ ^ (199 / 200 : ℝ) := by
      rw [hεdef]; unfold εp
      rw [show Λ ^ (-(1 / 200 : ℝ)) * Λ = Λ ^ (-(1 / 200 : ℝ)) * Λ ^ (1 : ℝ) by rw [Real.rpow_one], rp hΛ0]
      norm_num
    have h199 : 1 ≤ Λ ^ (199 / 200 : ℝ) := Real.one_le_rpow hΛ1 (by norm_num)
    have hlogpos : 0 ≤ 1 + Real.log ((⌊Bb⌋₊ : ℝ) / ⌊A⌋₊) := by
      have : 1 ≤ (⌊Bb⌋₊ : ℝ) / ⌊A⌋₊ := by
        have hA0 : (0 : ℝ) < ⌊A⌋₊ := by exact_mod_cast ha1
        rw [le_div_iff₀ hA0]; simp; exact_mod_cast hab
      have := Real.log_nonneg this; linarith
    calc Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 ⌊Bb⌋₊) : ℝ) ^ 30 * (1 + Real.log ((⌊Bb⌋₊ : ℝ) / ⌊A⌋₊))
        ≤ Λ ^ (1 / 4000 : ℝ) * (2 + 4 * (ε * Λ)) := by
          apply mul_le_mul hAωb (by linarith) hlogpos (by positivity)
      _ ≤ IM := by
          rw [hIM, hεΛ]; gcongr; linarith
  unfold BandPart
  have hmain := dsum_bound T hTf5 _ _ _ hc
    (fun B C => foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C)) Fm
    (by positivity) (fun B C _ => GoldC.QuillonBridge.abs_foldRow_le q a _ H _ _ hq) IM hIMb
  refine le_trans hmain ?_
  have hKΛ := hKc Λ L4
  calc Fm * ((∑ B ∈ T.powerset, (if R₀ ≤ ∏ p ∈ B, p ∧ ∏ p ∈ B, p ≤ h ∧
        ∀ p ∈ B, p < Xp h ∨ ((∏ q ∈ B, q : ℕ) : ℝ) ^ (u0 δ / 2) < p then ωR B else 0)) * IM)
      ≤ Fm * ((Λ ^ (1 / 4000 : ℝ) * (1 + 1 / (u0 δ / 2) ^ 5)) * IM) := by
        gcongr
    _ = K * (Λ ^ (1 / 4000 : ℝ) * Λ ^ (1 / 4000 : ℝ) * Λ ^ (199 / 200 : ℝ)) := by rw [hK, hIM]; ring
    _ = K * Λ ^ (1 / 2000 + 199 / 200 : ℝ) := by rw [rp hΛ0, rp hΛ0]; norm_num
    _ ≤ Λ ^ (998 / 1000 - 1 / 2000 - 199 / 200 : ℝ) * Λ ^ (1 / 2000 + 199 / 200 : ℝ) :=
        mul_le_mul_of_nonneg_right hKΛ (by positivity)
    _ = Λ ^ (998 / 1000 : ℝ) := by rw [rp hΛ0]; norm_num

end GoldC.QuillonResPhysical

#print axioms GoldC.QuillonResPhysical.rough_ev
#print axioms GoldC.QuillonResPhysical.dsum_bound
#print axioms GoldC.QuillonResPhysical.ResA_physical
#print axioms GoldC.QuillonResPhysical.Band_physical
