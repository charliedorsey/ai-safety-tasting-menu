import PaperB.FixedQ.SignedForbiddenNaturalBridge
import PaperB.FixedQ.OneDimensionalBracket

open Filter Real Asymptotics
open scoped BigOperators

namespace PaperB.FixedQ

lemma omegaCoeff_coprime_fixedQPeriod_of_ne_zero
    {q e : ℕ} (he : omegaCoeff q e ≠ 0) :
    e.Coprime (fixedQPeriod q) := by
  unfold omegaCoeff at he
  by_cases he0 : e = 0
  · simp [he0] at he
  · rw [if_neg he0] at he
    by_cases hs : Squarefree e ∧ e.Coprime (6 * q)
    · have hdiv : fixedQPeriod q ∣ 6 * q := by
        unfold fixedQPeriod
        exact Nat.lcm_dvd_mul 6 q
      exact hs.2.of_dvd_right hdiv
    · rw [if_neg hs] at he
      simp at he

theorem supportedSawtoothSum_omega_sublog_of_r0002
    (q : ℕ) (hq : 0 < q) [NeZero (fixedQPeriod q)]
    (hbase : PetermannMinimalConsumerR0002Spec q PetermannBase.omega) :
    ∀ ε : ℝ, 0 < ε →
      ∃ T0 : ℝ, ∀
        (w : ℕ → ℝ),
          (∀ c ∈ Finset.Icc 1 (fixedQPeriod q), |w c| ≤ 6) →
        ∀ (T : ℝ) (X : ℕ),
          T0 ≤ T →
          (2 * fixedQPeriod q : ℝ) ≤ T →
          1 ≤ X →
          (X : ℝ) ≤ T →
          |supportedSawtoothSum
              (fixedQPeriod q) w (omegaCoeff q) T X|
            ≤ ε * Real.log T := by
  intro ε hε
  let Cn : ℝ :=
    (Fintype.card
      (DirichletCharacter ℂ (fixedQPeriod q)) : ℝ)
  let D : ℝ := Cn * (6 * (fixedQPeriod q : ℝ))
  have hCn0 : 0 ≤ Cn := by
    dsimp [Cn]
    positivity
  have hD0 : 0 ≤ D := by
    dsimp [D]
    positivity
  let δ : ℝ := ε / (D + 1)
  have hδ : 0 < δ := by
    dsimp [δ]
    positivity
  obtain ⟨T0, hT0⟩ := hbase δ hδ
  refine ⟨T0, ?_⟩
  intro w hw T X hT0' h2 hX1 hXT
  have hLpos : 0 < fixedQPeriod q := by
    unfold fixedQPeriod
    exact Nat.lcm_pos (by norm_num) hq
  have hT1 : 1 ≤ T := by
    have hLR : (1 : ℝ) ≤ fixedQPeriod q := by exact_mod_cast hLpos
    linarith
  have hlog0 : 0 ≤ Real.log T := Real.log_nonneg hT1
  have hsupp :
      ∀ e : ℕ, omegaCoeff q e ≠ 0 →
        e.Coprime (fixedQPeriod q) :=
    fun e he => omegaCoeff_coprime_fixedQPeriod_of_ne_zero he
  have hexp :=
    supportedSawtoothSum_character_expansion
      (fixedQPeriod q) w (omegaCoeff q) T X hsupp
  have hkernel :
      ∀ (chi : DirichletCharacter ℂ (fixedQPeriod q)) (r : ℤ),
        ‖genericPetermannKernelSum
            (fixedQPeriod q) (omegaCoeff q) chi r T X‖
          ≤ δ * Real.log T := by
    intro chi r
    change ‖petermannBaseKernelSum q PetermannBase.omega chi r T X‖ ≤
      δ * Real.log T
    exact hT0 chi r T X hT0'
      (by simpa [fixedQPeriod] using h2) hX1 hXT
  have hsum :
      ‖∑ chi : DirichletCharacter ℂ (fixedQPeriod q),
          sawtoothWeightedCharacterSum
            (fixedQPeriod q) w (omegaCoeff q) chi T X‖
        ≤ Cn * (6 * (fixedQPeriod q : ℝ) *
          (δ * Real.log T)) := by
    calc
      ‖∑ chi : DirichletCharacter ℂ (fixedQPeriod q),
          sawtoothWeightedCharacterSum
            (fixedQPeriod q) w (omegaCoeff q) chi T X‖
        ≤ ∑ chi : DirichletCharacter ℂ (fixedQPeriod q),
            ‖sawtoothWeightedCharacterSum
              (fixedQPeriod q) w (omegaCoeff q) chi T X‖ :=
          norm_sum_le _ _
      _ ≤ ∑ _chi : DirichletCharacter ℂ (fixedQPeriod q),
            (6 * (fixedQPeriod q : ℝ) *
              (δ * Real.log T)) := by
        apply Finset.sum_le_sum
        intro chi hchi
        exact norm_sawtoothWeightedCharacterSum_le_kernel
          (fixedQPeriod q) w (omegaCoeff q) hw chi T X
          (δ * Real.log T) (mul_nonneg hδ.le hlog0)
          (hkernel chi)
      _ = Cn * (6 * (fixedQPeriod q : ℝ) *
            (δ * Real.log T)) := by
        simp [Cn]
  have hden : 0 < Cn * (6 * (fixedQPeriod q : ℝ)) + 1 := by
    positivity
  have hcoeff : Cn * (6 * (fixedQPeriod q : ℝ)) * δ ≤ ε := by
    dsimp [δ, D]
    rw [show
      Cn * (6 * (fixedQPeriod q : ℝ)) *
          (ε / (Cn * (6 * (fixedQPeriod q : ℝ)) + 1)) =
        ε * (Cn * (6 * (fixedQPeriod q : ℝ)) /
          (Cn * (6 * (fixedQPeriod q : ℝ)) + 1)) by ring]
    apply mul_le_of_le_one_right hε.le
    exact (div_le_one hden).2 (by linarith)
  have hsum' :
      ‖∑ chi : DirichletCharacter ℂ (fixedQPeriod q),
          sawtoothWeightedCharacterSum
            (fixedQPeriod q) w (omegaCoeff q) chi T X‖
        ≤ ε * Real.log T := by
    calc
      _ ≤ Cn * (6 * (fixedQPeriod q : ℝ) *
          (δ * Real.log T)) := hsum
      _ = (Cn * (6 * (fixedQPeriod q : ℝ)) * δ) *
          Real.log T := by ring
      _ ≤ ε * Real.log T :=
        mul_le_mul_of_nonneg_right hcoeff hlog0
  have hcast :
      ((supportedSawtoothSum
          (fixedQPeriod q) w (omegaCoeff q) T X : ℝ) : ℂ) =
        ∑ chi : DirichletCharacter ℂ (fixedQPeriod q),
          sawtoothWeightedCharacterSum
            (fixedQPeriod q) w (omegaCoeff q) chi T X := by
    simpa [sawtoothWeightedCharacterSum] using hexp
  have hn :
      ‖((supportedSawtoothSum
          (fixedQPeriod q) w (omegaCoeff q) T X : ℝ) : ℂ)‖
        ≤ ε * Real.log T := by
    rw [hcast]
    exact hsum'
  simpa [Complex.norm_real, Real.norm_eq_abs] using hn


theorem omegaPrincipalLogMeanSpec
    (q : ℕ) (hq : 0 < q) :
    PrincipalLogMeanSpec
      (omegaCoeff q)
      (logarithmicEulerResidue (omegaCoeff q))
      ((2 * (6 * q) + 9) * omegaRankinBound) := by
  constructor
  · have hR0 : 0 ≤ omegaRankinBound := by
      unfold omegaRankinBound
      positivity
    positivity
  · intro X hX
    simpa [coefficientPartialSum, omegaPartialSum] using
      omegaPrincipalLogMean_bound q X hq hX

theorem omegaNonprincipalCharacterBoundSpec
    (q : ℕ) (hq : 0 < q) :
    CharacterBoundSpec q
      (omegaCoeff q)
      (2 * ((Nat.lcm 6 q : ℕ) + 1) * omegaRankinBound) := by
  constructor
  · have hR0 : 0 ≤ omegaRankinBound := by
      unfold omegaRankinBound
      positivity
    positivity
  · intro chi hchi X hX
    simpa [characterCoefficientPartialSum, omegaCharacterPartialSum] using
      norm_omegaCharacterPartialSum_le q X hq chi hchi

theorem principalCharacterPartialSum_omega
    (q X : ℕ) :
    characterCoefficientPartialSum
        (1 : DirichletCharacter ℂ (fixedQPeriod q))
        (omegaCoeff q) X =
      (coefficientPartialSum (omegaCoeff q) X : ℂ) := by
  unfold characterCoefficientPartialSum coefficientPartialSum
  push_cast
  apply Finset.sum_congr rfl
  intro e heI
  by_cases hc : omegaCoeff q e = 0
  · simp [hc]
  · have hcop := omegaCoeff_coprime_fixedQPeriod_of_ne_zero hc
    have hunit : IsUnit (e : ZMod (fixedQPeriod q)) := by
      exact (ZMod.isUnit_iff_coprime e (fixedQPeriod q)).2 hcop
    rw [MulChar.one_apply hunit]
    ring

#print axioms omegaPrincipalLogMeanSpec
#print axioms omegaNonprincipalCharacterBoundSpec
#print axioms principalCharacterPartialSum_omega

#print axioms omegaCoeff_coprime_fixedQPeriod_of_ne_zero
#print axioms supportedSawtoothSum_omega_sublog_of_r0002

end PaperB.FixedQ
