import Mathlib

/-!
# `GoldC.Sieve` — explicit Bonferroni sieve coefficients on numeric divisors

Stage A of the sieve hunt: the upper **and lower** arithmetic divisor sandwich, for every finite
set `P` of primes and every even `K` (including `K = 0`), stated with actual integer
divisibility and coprimality.

* `lamPlus P K d  = μ(d)` if `d ∣ ∏P` and `ω(d) ≤ K`, else `0`;
* `lamMinus P K d = μ(d)` if `d ∣ ∏P` and `ω(d) < K`, else `0`.

Main results:
* `sum_lamPlus_eq` and `sum_lamMinus_eq` : the divisor sums equal `Σ_{j ≤ K} (-1)^j C(b,j)` and
  `Σ_{j < K} (-1)^j C(b,j)`, where `b = #{p ∈ P : p ∣ n}`;
* `bonferroni_sandwich` : `Σ_{d∣n} lamMinus ≤ 1[gcd(n, ∏P) = 1] ≤ Σ_{d∣n} lamPlus` for even `K`;
* support, `|λ| ≤ 1`, and the explicit gap `Σ_{d∣n} (lamPlus - lamMinus) = (-1)^K C(b, K)`.
-/

open scoped BigOperators ArithmeticFunction.Moebius
open Finset

namespace GoldC

/-- Upper Bonferroni coefficient. -/
def lamPlus (P : Finset ℕ) (K d : ℕ) : ℤ :=
  if d ∣ ∏ p ∈ P, p ∧ d.primeFactors.card ≤ K then μ d else 0

/-- Lower Bonferroni coefficient. -/
def lamMinus (P : Finset ℕ) (K d : ℕ) : ℤ :=
  if d ∣ ∏ p ∈ P, p ∧ d.primeFactors.card < K then μ d else 0

/-! ## Divisors of `∏P` are products of subsets -/

lemma squarefree_prod_primes {P : Finset ℕ} (hP : ∀ p ∈ P, p.Prime) :
    Squarefree (∏ p ∈ P, p) := by
  refine Finset.squarefree_prod_of_pairwise_isCoprime ?_ fun p hp => (hP p hp).squarefree
  intro p hp p' hp' hne
  exact Nat.coprime_iff_isRelPrime.1 ((Nat.coprime_primes (hP p hp) (hP p' hp')).2 hne)

lemma moebius_prod_primes {S : Finset ℕ} (hS : ∀ p ∈ S, p.Prime) :
    μ (∏ p ∈ S, p) = (-1) ^ S.card := by
  rw [ArithmeticFunction.IsMultiplicative.map_prod_of_prime
    ArithmeticFunction.isMultiplicative_moebius S hS]
  rw [Finset.prod_congr rfl fun p hp => ArithmeticFunction.moebius_apply_prime (hS p hp)]
  simp

/-- **Core bijection.** For `n ≠ 0` and a set of primes `P`, a divisor sum of
`1[d ∣ ∏P ∧ J(ω d)] μ(d)` is the signed count of subsets `S` of `F = {p ∈ P : p ∣ n}`
with `J(#S)`. -/
theorem sum_divisors_bonf (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (n : ℕ) (hn : n ≠ 0)
    (J : ℕ → Prop) [DecidablePred J] :
    ∑ d ∈ n.divisors, (if d ∣ ∏ p ∈ P, p ∧ J d.primeFactors.card then μ d else 0) =
      ∑ S ∈ (P.filter (· ∣ n)).powerset, (if J S.card then (-1 : ℤ) ^ S.card else 0) := by
  set F := P.filter (· ∣ n) with hF
  have hFP : ∀ p ∈ F, p.Prime := fun p hp => hP p (Finset.mem_filter.1 hp).1
  have hPne : (∏ p ∈ P, p) ≠ 0 := Finset.prod_ne_zero_iff.2 fun p hp => (hP p hp).ne_zero
  rw [← Finset.sum_filter_add_sum_filter_not n.divisors (fun d => d ∣ ∏ p ∈ P, p)]
  have hzero : ∑ d ∈ n.divisors.filter (fun d => ¬ d ∣ ∏ p ∈ P, p),
      (if d ∣ ∏ p ∈ P, p ∧ J d.primeFactors.card then μ d else 0) = 0 :=
    Finset.sum_eq_zero fun d hd => by
      rw [Finset.mem_filter] at hd
      have hn' : ¬ (d ∣ ∏ p ∈ P, p ∧ J d.primeFactors.card) := fun h => hd.2 h.1
      simp only [hn', ↓reduceIte]
  rw [hzero, add_zero]
  refine Finset.sum_nbij' (fun d => d.primeFactors) (fun S => ∏ p ∈ S, p) ?_ ?_ ?_ ?_ ?_
  · intro d hd
    simp only [Finset.mem_filter, Nat.mem_divisors] at hd
    rw [Finset.mem_powerset]
    intro p hp
    have hpd : p ∣ d := Nat.dvd_of_mem_primeFactors hp
    have hpP : p ∈ P := by
      have := Nat.primeFactors_mono hd.2 hPne hp
      rwa [Nat.primeFactors_prod hP] at this
    exact Finset.mem_filter.2 ⟨hpP, hpd.trans hd.1.1⟩
  · intro S hS
    rw [Finset.mem_powerset] at hS
    simp only [Finset.mem_filter, Nat.mem_divisors]
    refine ⟨⟨?_, hn⟩, Finset.prod_dvd_prod_of_subset _ _ _ fun p hp => (Finset.mem_filter.1 (hS hp)).1⟩
    exact Finset.prod_primes_dvd n (fun p hp => (hFP p (hS hp)).prime)
      (fun p hp => (Finset.mem_filter.1 (hS hp)).2)
  · intro d hd
    simp only [Finset.mem_filter, Nat.mem_divisors] at hd
    exact Nat.prod_primeFactors_of_squarefree ((squarefree_prod_primes hP).squarefree_of_dvd hd.2)
  · intro S hS
    rw [Finset.mem_powerset] at hS
    exact Nat.primeFactors_prod fun p hp => hFP p (hS hp)
  · intro d hd
    simp only [Finset.mem_filter, Nat.mem_divisors] at hd
    have hsq : Squarefree d := (squarefree_prod_primes hP).squarefree_of_dvd hd.2
    have hprime : ∀ p ∈ d.primeFactors, p.Prime := fun p hp => Nat.prime_of_mem_primeFactors hp
    have hμ : μ d = (-1) ^ d.primeFactors.card := by
      conv_lhs => rw [← Nat.prod_primeFactors_of_squarefree hsq]
      exact moebius_prod_primes hprime
    simp only [hd.2, true_and, hμ]

/-- The signed subset count as a binomial sum. -/
lemma sum_powerset_card_pred (F : Finset ℕ) (J : ℕ → Prop) [DecidablePred J] :
    ∑ S ∈ F.powerset, (if J S.card then (-1 : ℤ) ^ S.card else 0) =
      ∑ j ∈ Finset.range (F.card + 1), (if J j then (-1 : ℤ) ^ j * F.card.choose j else 0) := by
  rw [Finset.sum_powerset_apply_card (fun m => if J m then (-1 : ℤ) ^ m else 0)]
  refine Finset.sum_congr rfl fun j _ => ?_
  split_ifs <;> simp [mul_comm]

/-- Truncated alternating binomial sums, extended past `b` by zeros. -/
lemma sum_range_le_eq (b K : ℕ) :
    ∑ j ∈ Finset.range (b + 1), (if j ≤ K then (-1 : ℤ) ^ j * b.choose j else 0) =
      ∑ j ∈ Finset.range (K + 1), (-1 : ℤ) ^ j * b.choose j := by
  rw [← Finset.sum_filter]
  apply Finset.sum_subset
  · intro j hj
    simp only [Finset.mem_filter, Finset.mem_range] at hj ⊢; omega
  · intro j hj hj'
    simp only [Finset.mem_filter, Finset.mem_range, not_and, not_le] at hj hj'
    have : b < j := by
      by_contra h; exact absurd (hj' (by omega)) (by omega)
    rw [Nat.choose_eq_zero_of_lt this]; simp

/-- `upperB b K = Σ_{j ≤ K} (-1)^j C(b, j)`. -/
def upperB (b K : ℕ) : ℤ := ∑ j ∈ Finset.range (K + 1), (-1 : ℤ) ^ j * b.choose j

/-- `lowerB b K = Σ_{j < K} (-1)^j C(b, j)`. -/
def lowerB (b K : ℕ) : ℤ := ∑ j ∈ Finset.range K, (-1 : ℤ) ^ j * b.choose j

lemma lowerB_succ (b K : ℕ) : lowerB b (K + 1) = upperB b K := rfl

lemma lowerB_zero (b : ℕ) : lowerB b 0 = 0 := by simp [lowerB]

/-- **Actual divisor upper sum.** -/
theorem sum_lamPlus_eq (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (K n : ℕ) (hn : n ≠ 0) :
    ∑ d ∈ n.divisors, lamPlus P K d = upperB (P.filter (· ∣ n)).card K := by
  unfold lamPlus upperB
  rw [sum_divisors_bonf P hP n hn (· ≤ K)]
  rw [sum_powerset_card_pred _ (· ≤ K), sum_range_le_eq]

/-- **Actual divisor lower sum** (R0014 lower bridge), including `K = 0`. -/
theorem sum_lamMinus_eq (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (K n : ℕ) (hn : n ≠ 0) :
    ∑ d ∈ n.divisors, lamMinus P K d = lowerB (P.filter (· ∣ n)).card K := by
  rcases K with _ | K
  · unfold lamMinus; rw [lowerB_zero]; simp
  · have : ∀ d, lamMinus P (K + 1) d = lamPlus P K d := by
      intro d; unfold lamMinus lamPlus; simp only [Nat.lt_succ_iff]
    simp only [this]
    rw [sum_lamPlus_eq P hP K n hn, lowerB_succ]

/-! ## The binomial Bonferroni inequalities -/

lemma upperB_succ (b K : ℕ) : upperB (b + 1) K = (-1) ^ K * b.choose K := by
  unfold upperB; exact Int.alternating_sum_range_choose_eq_choose

lemma upperB_zero_left (K : ℕ) : upperB 0 K = 1 := by
  unfold upperB
  rw [Finset.sum_range_succ']
  simp only [pow_zero, Nat.choose_zero_right, Nat.cast_one, mul_one]
  rw [Finset.sum_eq_zero fun j _ => by simp [Nat.choose_eq_zero_of_lt (Nat.succ_pos j)]]
  simp

theorem bonferroni_binomial (b K : ℕ) (hK : Even K) :
    lowerB b K ≤ (if b = 0 then 1 else 0) ∧ (if b = 0 then 1 else 0) ≤ upperB b K := by
  rcases b with _ | b
  · simp only [↓reduceIte]
    refine ⟨?_, (upperB_zero_left K).ge⟩
    rcases K with _ | K
    · rw [lowerB_zero]; norm_num
    · rw [lowerB_succ, upperB_zero_left]
  · simp only [Nat.succ_ne_zero, ↓reduceIte]
    refine ⟨?_, ?_⟩
    · rcases K with _ | K
      · rw [lowerB_zero]
      · rw [lowerB_succ, upperB_succ]
        have hodd : Odd K := by
          rcases hK with ⟨m, hm⟩; exact ⟨m - 1, by omega⟩
        rw [hodd.neg_one_pow]
        have : (0 : ℤ) ≤ b.choose K := by positivity
        linarith
    · rw [upperB_succ, hK.neg_one_pow, one_mul]; positivity

lemma filter_dvd_eq_empty_iff (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (n : ℕ) :
    (P.filter (· ∣ n)).card = 0 ↔ n.Coprime (∏ p ∈ P, p) := by
  rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff, Nat.coprime_prod_right_iff]
  refine forall₂_congr fun p hp => ?_
  rw [Nat.coprime_comm, Nat.Prime.coprime_iff_not_dvd (hP p hp)]

/-- **Arithmetic Bonferroni sandwich** (Stage A). For a finite set of primes `P`, an even `K`
(including `0`) and `n ≠ 0`:
`Σ_{d∣n} λ⁻(d) ≤ 1[gcd(n, ∏P) = 1] ≤ Σ_{d∣n} λ⁺(d)`. -/
theorem bonferroni_sandwich (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (K : ℕ) (hK : Even K)
    (n : ℕ) (hn : n ≠ 0) :
    ∑ d ∈ n.divisors, lamMinus P K d ≤ (if n.Coprime (∏ p ∈ P, p) then 1 else 0) ∧
      (if n.Coprime (∏ p ∈ P, p) then 1 else 0) ≤ ∑ d ∈ n.divisors, lamPlus P K d := by
  rw [sum_lamMinus_eq P hP K n hn, sum_lamPlus_eq P hP K n hn]
  have h := bonferroni_binomial (P.filter (· ∣ n)).card K hK
  have hiff := filter_dvd_eq_empty_iff P hP n
  by_cases hc : n.Coprime (∏ p ∈ P, p)
  · have hb := hiff.2 hc
    rw [ite_eq_left_of_eq_true (1 : ℤ) 0 (eq_true hc)]
    rw [ite_eq_left_of_eq_true (1 : ℤ) 0 (eq_true hb)] at h; exact h
  · have hb : ¬ (P.filter (· ∣ n)).card = 0 := fun h' => hc (hiff.1 h')
    rw [ite_eq_right_of_eq_false (1 : ℤ) 0 (eq_false hc)]
    rw [ite_eq_right_of_eq_false (1 : ℤ) 0 (eq_false hb)] at h; exact h

/-- The gap between the two divisor sums is a single binomial layer. -/
theorem sum_lamPlus_sub_lamMinus (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (K n : ℕ) (hn : n ≠ 0) :
    ∑ d ∈ n.divisors, (lamPlus P K d - lamMinus P K d) =
      (-1) ^ K * ((P.filter (· ∣ n)).card.choose K : ℤ) := by
  rw [Finset.sum_sub_distrib, sum_lamPlus_eq P hP K n hn, sum_lamMinus_eq P hP K n hn]
  unfold upperB lowerB
  rw [Finset.sum_range_succ]; ring

/-! ## Coefficient support and size -/

lemma lamPlus_abs_le (P : Finset ℕ) (K d : ℕ) : |lamPlus P K d| ≤ 1 := by
  unfold lamPlus; split_ifs
  · exact ArithmeticFunction.abs_moebius_le_one
  · simp

lemma lamMinus_abs_le (P : Finset ℕ) (K d : ℕ) : |lamMinus P K d| ≤ 1 := by
  unfold lamMinus; split_ifs
  · exact ArithmeticFunction.abs_moebius_le_one
  · simp

/-- Support: a supported `d` is a product of at most `K` primes of `P`, each `≤ w`, so `d ≤ w^K`. -/
theorem lamPlus_support_le (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (w : ℕ) (hw1 : 1 ≤ w)
    (hw : ∀ p ∈ P, p ≤ w) (K d : ℕ) (hd : lamPlus P K d ≠ 0) :
    d ≤ w ^ K ∧ d ∣ ∏ p ∈ P, p := by
  unfold lamPlus at hd
  split_ifs at hd with h
  · refine ⟨?_, h.1⟩
    have hPne : (∏ p ∈ P, p) ≠ 0 := Finset.prod_ne_zero_iff.2 fun p hp => (hP p hp).ne_zero
    have hsq : Squarefree d := (squarefree_prod_primes hP).squarefree_of_dvd h.1
    have hsub : d.primeFactors ⊆ P := by
      have := Nat.primeFactors_mono h.1 hPne
      rwa [Nat.primeFactors_prod hP] at this
    calc d = ∏ p ∈ d.primeFactors, p := (Nat.prod_primeFactors_of_squarefree hsq).symm
      _ ≤ ∏ _p ∈ d.primeFactors, w := Finset.prod_le_prod fun p hp => hw p (hsub hp)
      _ = w ^ d.primeFactors.card := Finset.prod_const w
      _ ≤ w ^ K := Nat.pow_le_pow_right hw1 h.2
  · exact absurd rfl hd

lemma lamMinus_ne_zero_imp (P : Finset ℕ) (K d : ℕ) (hd : lamMinus P K d ≠ 0) :
    lamPlus P K d = lamMinus P K d := by
  by_cases h1 : d ∣ ∏ p ∈ P, p ∧ d.primeFactors.card < K
  · have h2 : d ∣ ∏ p ∈ P, p ∧ d.primeFactors.card ≤ K := ⟨h1.1, h1.2.le⟩
    unfold lamPlus lamMinus
    rw [ite_eq_left_of_eq_true _ _ (eq_true h1), ite_eq_left_of_eq_true _ _ (eq_true h2)]
  · exfalso; apply hd; unfold lamMinus
    rw [ite_eq_right_of_eq_false _ _ (eq_false h1)]

/-! ## Stage B: the reciprocal coefficient main term -/

/-- Weighted form of the core bijection (real weights `g`). -/
theorem sum_divisors_bonf_weighted (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (n : ℕ) (hn : n ≠ 0)
    (J : ℕ → Prop) [DecidablePred J] (g : ℕ → ℝ) :
    ∑ d ∈ n.divisors, (if d ∣ ∏ p ∈ P, p ∧ J d.primeFactors.card then (μ d : ℝ) * g d else 0) =
      ∑ S ∈ (P.filter (· ∣ n)).powerset,
        (if J S.card then (-1 : ℝ) ^ S.card * g (∏ p ∈ S, p) else 0) := by
  set F := P.filter (· ∣ n) with hF
  have hFP : ∀ p ∈ F, p.Prime := fun p hp => hP p (Finset.mem_filter.1 hp).1
  have hPne : (∏ p ∈ P, p) ≠ 0 := Finset.prod_ne_zero_iff.2 fun p hp => (hP p hp).ne_zero
  rw [← Finset.sum_filter_add_sum_filter_not n.divisors (fun d => d ∣ ∏ p ∈ P, p)]
  have hzero : ∑ d ∈ n.divisors.filter (fun d => ¬ d ∣ ∏ p ∈ P, p),
      (if d ∣ ∏ p ∈ P, p ∧ J d.primeFactors.card then (μ d : ℝ) * g d else 0) = 0 :=
    Finset.sum_eq_zero fun d hd => by
      rw [Finset.mem_filter] at hd
      have hn' : ¬ (d ∣ ∏ p ∈ P, p ∧ J d.primeFactors.card) := fun h => hd.2 h.1
      simp only [hn', ↓reduceIte]
  rw [hzero, add_zero]
  refine Finset.sum_nbij' (fun d => d.primeFactors) (fun S => ∏ p ∈ S, p) ?_ ?_ ?_ ?_ ?_
  · intro d hd
    simp only [Finset.mem_filter, Nat.mem_divisors] at hd
    rw [Finset.mem_powerset]
    intro p hp
    have hpd : p ∣ d := Nat.dvd_of_mem_primeFactors hp
    have hpP : p ∈ P := by
      have := Nat.primeFactors_mono hd.2 hPne hp
      rwa [Nat.primeFactors_prod hP] at this
    exact Finset.mem_filter.2 ⟨hpP, hpd.trans hd.1.1⟩
  · intro S hS
    rw [Finset.mem_powerset] at hS
    simp only [Finset.mem_filter, Nat.mem_divisors]
    refine ⟨⟨?_, hn⟩, Finset.prod_dvd_prod_of_subset _ _ _ fun p hp => (Finset.mem_filter.1 (hS hp)).1⟩
    exact Finset.prod_primes_dvd n (fun p hp => (hFP p (hS hp)).prime)
      (fun p hp => (Finset.mem_filter.1 (hS hp)).2)
  · intro d hd
    simp only [Finset.mem_filter, Nat.mem_divisors] at hd
    exact Nat.prod_primeFactors_of_squarefree ((squarefree_prod_primes hP).squarefree_of_dvd hd.2)
  · intro S hS
    rw [Finset.mem_powerset] at hS
    exact Nat.primeFactors_prod fun p hp => hFP p (hS hp)
  · intro d hd
    simp only [Finset.mem_filter, Nat.mem_divisors] at hd
    have hsq : Squarefree d := (squarefree_prod_primes hP).squarefree_of_dvd hd.2
    have hprime : ∀ p ∈ d.primeFactors, p.Prime := fun p hp => Nat.prime_of_mem_primeFactors hp
    have hμ : μ d = (-1) ^ d.primeFactors.card := by
      conv_lhs => rw [← Nat.prod_primeFactors_of_squarefree hsq]
      exact moebius_prod_primes hprime
    have hprod : ∏ p ∈ d.primeFactors, p = d := Nat.prod_primeFactors_of_squarefree hsq
    simp only [hd.2, true_and, hμ, hprod]
    push_cast; rfl

lemma lamPlus_sub_lamMinus (P : Finset ℕ) (K d : ℕ) :
    lamPlus P K d - lamMinus P K d =
      if d ∣ ∏ p ∈ P, p ∧ d.primeFactors.card = K then μ d else 0 := by
  unfold lamPlus lamMinus
  by_cases h1 : d ∣ ∏ p ∈ P, p
  · rcases lt_trichotomy d.primeFactors.card K with h | h | h
    · rw [ite_eq_left_of_eq_true _ _ (eq_true ⟨h1, h.le⟩), ite_eq_left_of_eq_true _ _ (eq_true ⟨h1, h⟩),
        ite_eq_right_of_eq_false _ _ (eq_false fun hh => h.ne hh.2), sub_self]
    · rw [ite_eq_left_of_eq_true _ _ (eq_true ⟨h1, h.le⟩),
        ite_eq_right_of_eq_false _ _ (eq_false fun hh => (lt_irrefl _) (h ▸ hh.2)),
        ite_eq_left_of_eq_true _ _ (eq_true ⟨h1, h⟩), sub_zero]
    · rw [ite_eq_right_of_eq_false _ _ (eq_false fun hh => (not_le.2 h) hh.2),
        ite_eq_right_of_eq_false _ _ (eq_false fun hh => (not_lt.2 h.le) hh.2),
        ite_eq_right_of_eq_false _ _ (eq_false fun hh => h.ne' hh.2), sub_zero]
  · rw [ite_eq_right_of_eq_false _ _ (eq_false fun hh => h1 hh.1),
      ite_eq_right_of_eq_false _ _ (eq_false fun hh => h1 hh.1),
      ite_eq_right_of_eq_false _ _ (eq_false fun hh => h1 hh.1), sub_zero]

/-- The reciprocal coefficient gap `Σ_d (λ⁺(d) - λ⁻(d))/d`, summed over all divisors of `∏P`
(the support of both coefficient families). -/
noncomputable def coefGap (P : Finset ℕ) (K : ℕ) : ℝ :=
  ∑ d ∈ (∏ p ∈ P, p).divisors, ((lamPlus P K d - lamMinus P K d : ℤ) : ℝ) / d

/-- The coefficient gap is exactly a signed elementary symmetric sum of reciprocals. -/
theorem coefGap_eq (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (K : ℕ) :
    coefGap P K = (-1) ^ K * ∑ S ∈ P.powersetCard K, ∏ p ∈ S, (1 / (p : ℝ)) := by
  have hPne : (∏ p ∈ P, p) ≠ 0 := Finset.prod_ne_zero_iff.2 fun p hp => (hP p hp).ne_zero
  unfold coefGap
  have h1 : ∀ d, ((lamPlus P K d - lamMinus P K d : ℤ) : ℝ) / d =
      if d ∣ ∏ p ∈ P, p ∧ d.primeFactors.card = K then (μ d : ℝ) * (1 / (d : ℝ)) else 0 := by
    intro d
    rw [lamPlus_sub_lamMinus]
    split_ifs
    · ring
    · simp
  simp only [h1]
  rw [sum_divisors_bonf_weighted P hP _ hPne (· = K) (fun d => 1 / (d : ℝ))]
  have hF : P.filter (· ∣ ∏ p ∈ P, p) = P := Finset.filter_true_of_mem fun p hp =>
    Finset.dvd_prod_of_mem _ hp
  rw [hF, Finset.powersetCard_eq_filter, Finset.sum_filter, Finset.mul_sum]
  refine Finset.sum_congr rfl fun S _ => ?_
  split_ifs with hS
  · rw [hS]; push_cast; rw [Finset.prod_div_distrib, Finset.prod_const_one]
  · simp

/-- `e_{K+1}` double counting: `(K+1)·e_{K+1} ≤ e_K · p₁` for nonnegative weights. -/
lemma esymm_succ_le (P : Finset ℕ) (x : ℕ → ℝ) (hx : ∀ p ∈ P, 0 ≤ x p) (K : ℕ) :
    (K + 1) * ∑ T ∈ P.powersetCard (K + 1), ∏ p ∈ T, x p ≤
      (∑ S ∈ P.powersetCard K, ∏ p ∈ S, x p) * ∑ p ∈ P, x p := by
  have hcount : (K + 1 : ℝ) * ∑ T ∈ P.powersetCard (K + 1), ∏ p ∈ T, x p =
      ∑ T ∈ P.powersetCard (K + 1), ∑ _p ∈ T, ∏ q ∈ T, x q := by
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun T hT => ?_
    rw [Finset.sum_const, (Finset.mem_powersetCard.1 hT).2, nsmul_eq_mul]; push_cast; ring
  have hbij : ∑ T ∈ P.powersetCard (K + 1), ∑ _p ∈ T, ∏ q ∈ T, x q =
      ∑ S ∈ P.powersetCard K, ∑ p ∈ P \ S, x p * ∏ q ∈ S, x q := by
    rw [Finset.sum_sigma', Finset.sum_sigma']
    refine Finset.sum_nbij' (fun z => ⟨z.1.erase z.2, z.2⟩) (fun z => ⟨insert z.2 z.1, z.2⟩)
      ?_ ?_ ?_ ?_ ?_
    · rintro ⟨T, p⟩ h
      simp only [Finset.mem_sigma, Finset.mem_powersetCard] at h ⊢
      refine ⟨⟨(Finset.erase_subset _ _).trans h.1.1, ?_⟩, ?_⟩
      · rw [Finset.card_erase_of_mem h.2, h.1.2]; rfl
      · exact Finset.mem_sdiff.2 ⟨h.1.1 h.2, Finset.notMem_erase _ _⟩
    · rintro ⟨S, p⟩ h
      simp only [Finset.mem_sigma, Finset.mem_powersetCard, Finset.mem_sdiff] at h ⊢
      refine ⟨⟨Finset.insert_subset h.2.1 h.1.1, ?_⟩, Finset.mem_insert_self _ _⟩
      rw [Finset.card_insert_of_notMem h.2.2, h.1.2]
    · rintro ⟨T, p⟩ h
      simp only [Finset.mem_sigma] at h
      simp only [Finset.insert_erase h.2]
    · rintro ⟨S, p⟩ h
      simp only [Finset.mem_sigma, Finset.mem_sdiff] at h
      simp only [Finset.erase_insert h.2.2]
    · rintro ⟨T, p⟩ h
      simp only [Finset.mem_sigma] at h
      simp only
      rw [← Finset.mul_prod_erase T x h.2]
  rw [hcount, hbij, Finset.sum_mul]
  refine Finset.sum_le_sum fun S hS => ?_
  rw [Finset.mul_sum]
  have hSnn : 0 ≤ ∏ q ∈ S, x q :=
    Finset.prod_nonneg fun q hq => hx q ((Finset.mem_powersetCard.1 hS).1 hq)
  calc ∑ p ∈ P \ S, x p * ∏ q ∈ S, x q ≤ ∑ p ∈ P, x p * ∏ q ∈ S, x q :=
        Finset.sum_le_sum_of_subset_of_nonneg Finset.sdiff_subset fun p hp _ =>
          mul_nonneg (hx p hp) hSnn
    _ = ∑ p ∈ P, (∏ q ∈ S, x q) * x p := Finset.sum_congr rfl fun p _ => mul_comm _ _
    _ = ∑ p ∈ P, (∏ p ∈ S, x p) * x p := rfl

/-- `K! · e_K ≤ p₁^K` for nonnegative weights. -/
theorem factorial_mul_esymm_le (P : Finset ℕ) (x : ℕ → ℝ) (hx : ∀ p ∈ P, 0 ≤ x p) (K : ℕ) :
    (K.factorial : ℝ) * ∑ S ∈ P.powersetCard K, ∏ p ∈ S, x p ≤ (∑ p ∈ P, x p) ^ K := by
  induction K with
  | zero => simp
  | succ K ih =>
    have hA : 0 ≤ ∑ p ∈ P, x p := Finset.sum_nonneg hx
    have h := esymm_succ_le P x hx K
    calc ((K + 1).factorial : ℝ) * ∑ T ∈ P.powersetCard (K + 1), ∏ p ∈ T, x p
        = (K.factorial : ℝ) * ((K + 1) * ∑ T ∈ P.powersetCard (K + 1), ∏ p ∈ T, x p) := by
          push_cast [Nat.factorial_succ]; ring
      _ ≤ (K.factorial : ℝ) * ((∑ S ∈ P.powersetCard K, ∏ p ∈ S, x p) * ∑ p ∈ P, x p) :=
          mul_le_mul_of_nonneg_left h (by positivity)
      _ = ((K.factorial : ℝ) * ∑ S ∈ P.powersetCard K, ∏ p ∈ S, x p) * ∑ p ∈ P, x p := by ring
      _ ≤ (∑ p ∈ P, x p) ^ K * ∑ p ∈ P, x p := mul_le_mul_of_nonneg_right ih hA
      _ = (∑ p ∈ P, x p) ^ (K + 1) := (pow_succ _ _).symm

/-- Prime reciprocals up to `w` are bounded by the harmonic number: `Σ_{p∈P} 1/p ≤ 1 + log w`. -/
lemma sum_inv_primes_le (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (w : ℕ) (hw : ∀ p ∈ P, p ≤ w) :
    ∑ p ∈ P, (1 / (p : ℝ)) ≤ 1 + Real.log w := by
  have hsub : P ⊆ Finset.Icc 1 w := fun p hp =>
    Finset.mem_Icc.2 ⟨(hP p hp).one_lt.le, hw p hp⟩
  calc ∑ p ∈ P, (1 / (p : ℝ)) ≤ ∑ p ∈ Finset.Icc 1 w, (1 / (p : ℝ)) :=
        Finset.sum_le_sum_of_subset_of_nonneg hsub fun _ _ _ => by positivity
    _ = (harmonic w : ℝ) := by
        rw [harmonic_eq_sum_Icc]; push_cast; simp [one_div]
    _ ≤ 1 + Real.log w := harmonic_le_one_add_log w

/-- **Stage B (coefficient gap).** For primes `P ≤ w` and any `K`:
`|coefGap P K| ≤ (1 + log w)^K / K!`; and if `e²(1 + log w) ≤ K` then `|coefGap P K| ≤ e^{-K}`. -/
theorem coefGap_abs_le (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (w : ℕ) (hw : ∀ p ∈ P, p ≤ w)
    (K : ℕ) : |coefGap P K| ≤ (1 + Real.log w) ^ K / K.factorial := by
  rw [coefGap_eq P hP K, abs_mul, abs_pow, abs_neg, abs_one, one_pow, one_mul]
  have hx : ∀ p ∈ P, 0 ≤ 1 / (p : ℝ) := fun _ _ => by positivity
  have hnn : 0 ≤ ∑ S ∈ P.powersetCard K, ∏ p ∈ S, (1 / (p : ℝ)) :=
    Finset.sum_nonneg fun S _ => Finset.prod_nonneg fun p hp => by positivity
  rw [abs_of_nonneg hnn, le_div_iff₀ (by positivity), mul_comm]
  calc (K.factorial : ℝ) * ∑ S ∈ P.powersetCard K, ∏ p ∈ S, (1 / (p : ℝ))
      ≤ (∑ p ∈ P, (1 / (p : ℝ))) ^ K := factorial_mul_esymm_le P _ hx K
    _ ≤ (1 + Real.log w) ^ K :=
        pow_le_pow_left₀ (Finset.sum_nonneg hx) (sum_inv_primes_le P hP w hw) K

theorem coefGap_abs_le_exp (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (w : ℕ) (hw1 : 1 ≤ w)
    (hw : ∀ p ∈ P, p ≤ w) (K : ℕ) (hK : Real.exp 2 * (1 + Real.log w) ≤ K) :
    |coefGap P K| ≤ Real.exp (-(K : ℝ)) := by
  refine (coefGap_abs_le P hP w hw K).trans ?_
  have hA : 0 ≤ 1 + Real.log w := by
    have : 0 ≤ Real.log w := Real.log_nonneg (by exact_mod_cast hw1)
    linarith
  rcases Nat.eq_zero_or_pos K with rfl | hKpos
  · exfalso
    have : 0 < Real.exp 2 * (1 + Real.log w) := by positivity
    push_cast at hK; linarith
  -- `K! ≥ K^K e^{-K}` and `(1 + log w) ≤ K e^{-2}`
  have hKr : (0 : ℝ) < K := by exact_mod_cast hKpos
  have hfact : (K : ℝ) ^ K / K.factorial ≤ Real.exp K := Real.pow_div_factorial_le_exp (K : ℝ) hKr.le K
  have hAle : 1 + Real.log w ≤ K * Real.exp (-2) := by
    rw [Real.exp_neg, ← div_eq_mul_inv, le_div_iff₀ (Real.exp_pos 2)]; linarith
  have hfpos : (0 : ℝ) < K.factorial := by exact_mod_cast Nat.factorial_pos K
  calc (1 + Real.log w) ^ K / K.factorial ≤ (K * Real.exp (-2)) ^ K / K.factorial :=
        div_le_div_of_nonneg_right (pow_le_pow_left₀ hA hAle K) hfpos.le
    _ = ((K : ℝ) ^ K / K.factorial) * Real.exp (-2) ^ K := by rw [mul_pow]; ring
    _ ≤ Real.exp K * Real.exp (-2) ^ K :=
        mul_le_mul_of_nonneg_right hfact (by positivity)
    _ = Real.exp (-(K : ℝ)) := by
        rw [← Real.exp_nat_mul, ← Real.exp_add]; congr 1; ring

/-! ## Stage B parameters as functions of `h` -/

/-- Sifting range `w(h) = ⌈(log h)^20⌉`. -/
noncomputable def sieveW (h : ℕ) : ℕ := ⌈(Real.log h) ^ 20⌉₊

/-- Even Bonferroni depth `K(h) = 2⌈e²(2 + 20 log log h)/2⌉`. -/
noncomputable def sieveK (h : ℕ) : ℕ :=
  2 * ⌈Real.exp 2 * (2 + 20 * Real.log (Real.log h)) / 2⌉₊

/-- Sieve level `D(h) = w(h)^K(h)`; every coefficient is supported on `d ≤ D(h)`. -/
noncomputable def sieveD (h : ℕ) : ℕ := sieveW h ^ sieveK h

lemma sieveK_even (h : ℕ) : Even (sieveK h) := ⟨_, (two_mul _)⟩

lemma one_le_sieveW {h : ℕ} (hh : 3 ≤ h) : 1 ≤ sieveW h := by
  have hl : 1 < Real.log h := by
    rw [Real.lt_log_iff_exp_lt (by positivity)]
    have : Real.exp 1 < 3 := Real.exp_one_lt_d9.trans (by norm_num)
    exact this.trans_le (by exact_mod_cast hh)
  unfold sieveW
  apply Nat.one_le_iff_ne_zero.2
  intro h0
  rw [Nat.ceil_eq_zero] at h0
  have : 0 < Real.log h ^ 20 := by positivity
  linarith

/-- **Stage B, instantiated.** For `h ≥ 3` and any set of primes `P ≤ w(h)`,
`|coefGap P K(h)| ≤ (log h)^{-20}`. The only analytic input is `harmonic_le_one_add_log`;
no Mertens estimate is used. -/
theorem coefGap_param (h : ℕ) (hh : 3 ≤ h) (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime)
    (hw : ∀ p ∈ P, p ≤ sieveW h) :
    |coefGap P (sieveK h)| ≤ (Real.log h ^ 20)⁻¹ := by
  set L := Real.log h with hL
  have hL1 : 1 < L := by
    rw [hL, Real.lt_log_iff_exp_lt (by positivity)]
    have : Real.exp 1 < 3 := Real.exp_one_lt_d9.trans (by norm_num)
    exact this.trans_le (by exact_mod_cast hh)
  have hLL : 0 < Real.log L := Real.log_pos hL1
  have hw1 := one_le_sieveW hh
  -- `1 + log w ≤ 2 + 20 log L`
  have hlogw : 1 + Real.log (sieveW h) ≤ 2 + 20 * Real.log L := by
    have hwle : (sieveW h : ℝ) ≤ 2 * L ^ 20 := by
      unfold sieveW
      have h1 : (1 : ℝ) ≤ L ^ 20 := one_le_pow₀ hL1.le
      have := Nat.ceil_lt_add_one (show 0 ≤ L ^ 20 by positivity)
      linarith
    have hwpos : (0 : ℝ) < sieveW h := by exact_mod_cast hw1
    have : Real.log (sieveW h) ≤ Real.log 2 + 20 * Real.log L := by
      calc Real.log (sieveW h) ≤ Real.log (2 * L ^ 20) := Real.log_le_log hwpos hwle
        _ = Real.log 2 + 20 * Real.log L := by
            rw [Real.log_mul (by norm_num) (by positivity), Real.log_pow]; push_cast; ring
    have : Real.log 2 < 1 := Real.log_two_lt_d9.trans (by norm_num)
    linarith
  have hKbig : Real.exp 2 * (2 + 20 * Real.log L) ≤ sieveK h := by
    unfold sieveK
    have hc := Nat.le_ceil (Real.exp 2 * (2 + 20 * Real.log L) / 2)
    push_cast
    linarith
  have hK : Real.exp 2 * (1 + Real.log (sieveW h)) ≤ sieveK h := by
    have : Real.exp 2 * (1 + Real.log (sieveW h)) ≤ Real.exp 2 * (2 + 20 * Real.log L) :=
      mul_le_mul_of_nonneg_left hlogw (Real.exp_pos 2).le
    linarith
  refine (coefGap_abs_le_exp P hP _ hw1 hw _ hK).trans ?_
  -- `e^{-K} ≤ e^{-20 log L} = L^{-20}`
  have hK20 : 20 * Real.log L ≤ sieveK h := by
    have he : (1 : ℝ) ≤ Real.exp 2 := Real.one_le_exp (by norm_num)
    have h0 : 0 ≤ 2 + 20 * Real.log L := by linarith
    nlinarith
  calc Real.exp (-(sieveK h : ℝ)) ≤ Real.exp (-(20 * Real.log L)) := Real.exp_le_exp.2 (by linarith)
    _ = (L ^ 20)⁻¹ := by
        rw [Real.exp_neg, ← Real.log_rpow (by linarith), Real.exp_log (by positivity)]
        norm_cast

end GoldC
