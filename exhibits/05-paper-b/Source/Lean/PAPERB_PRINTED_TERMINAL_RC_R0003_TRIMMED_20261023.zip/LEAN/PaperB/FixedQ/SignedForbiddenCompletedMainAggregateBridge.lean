import PaperB.FixedQ.SignedForbiddenEndpointOuterAssembly
import PaperB.FixedQ.GlobalProperAnalyticBridge
import PaperB.FixedQ.SignedForbiddenMainRate

open scoped BigOperators

namespace PaperB.FixedQ

theorem completedBooleanMainTerm_eq_analytic_add_endpoints
    {q a h : ℕ} (e : Finset ℕ) :
    completedBooleanMainTerm q a h e =
      decoratedAnalyticPerE q a h e +
      (completedBooleanSupport q h).indicator
        (fun e => decoratedAnalyticPairTerm q a h e e) e +
      (completedBooleanSupport q h).indicator
        (fun e => decoratedAnalyticPairTerm q a h e (heightPrimePart h e)) e := by
  classical
  by_cases hc : e ∈ completedBooleanSupport q h
  · rw [completedBooleanMainTerm, Set.indicator_of_mem hc,
      Set.indicator_of_mem hc, Set.indicator_of_mem hc]
    rcases hc with ⟨hA, hne⟩
    let d := heightPrimePart h e
    let n := e \ d
    let D := decoratedHeightProduct h e
    let H := decoratedReducedHeight h e
    let aD := decoratedReducedAnchor q a D
    have hdsub : d ⊆ e := by
      dsimp [d]
      exact Finset.filter_subset _ _
    have hnne : n.Nonempty := by
      rw [Finset.nonempty_iff_ne_empty]
      intro hn0
      apply hne
      apply Finset.Subset.antisymm hdsub
      intro p hp
      by_contra hpnot
      have hpN : p ∈ n := Finset.mem_sdiff.mpr ⟨hp, hpnot⟩
      simp [hn0] at hpN
    have hAnalytic :=
      decoratedAnalyticPerE_eq_height_weight_mul_boolean
        (q := q) (a := a) (h := h) (e := e) hA
    have hBool :=
      ordinaryBooleanInteriorDiscrepancy_eq_full_sub_endpoints
        (fixedQLowWeight q aD H) H hnne
    have hFull :=
      decoratedAnalyticPairTerm_eq_partition
        (q := q) (a := a) (h := h) (e := e) (e1 := e)
        (fun _ hp => hp) hA hdsub
    have hEmpty :=
      decoratedAnalyticPairTerm_eq_partition
        (q := q) (a := a) (h := h) (e := e)
        (e1 := heightPrimePart h e)
        (Finset.filter_subset _ _) hA (fun _ hp => hp)
    dsimp [d, n, D, H, aD] at hAnalytic hBool hFull hEmpty ⊢
    simp at hEmpty
    rw [hAnalytic, hBool, hFull, hEmpty]
    ring
  · simp [completedBooleanMainTerm, Set.indicator, hc]
    by_cases hA : ∀ p ∈ e, activeHighPrime q p
    · have hall : heightPrimePart h e = e := by
        by_contra hh
        exact hc ⟨hA, hh⟩
      have hAnalytic :=
        decoratedAnalyticPerE_eq_height_weight_mul_boolean
          (q := q) (a := a) (h := h) (e := e) hA
      rw [hall] at hAnalytic
      simpa [ordinaryBooleanInteriorDiscrepancy] using hAnalytic.symm
    · exact (decoratedAnalyticPerE_eq_zero_of_not_all_active hA).symm

theorem summable_completedFullAnalytic
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    Summable (fun e : Finset ℕ =>
      (completedBooleanSupport q h).indicator
        (fun e => decoratedAnalyticPairTerm q a h e e) e) := by
  have hc := summable_combinedBooleanFullEndpointTerm
    (q := q) (a := a) (h := h) hq
  have hd := summable_completedBooleanFullDensityTerm
    (q := q) (a := a) (h := h) hq hh h2
  exact (hc.sub hd).congr (fun e => by
    have he := combinedFullEndpoint_eq_completedAnalytic_add_density
      (q := q) (a := a) (h := h) e
    rw [he]
    ring)

theorem summable_completedEmptyAnalytic
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    Summable (fun e : Finset ℕ =>
      (completedBooleanSupport q h).indicator
        (fun e => decoratedAnalyticPairTerm q a h e (heightPrimePart h e)) e) := by
  let r := PaperB.Closure.reflectedResidue q (a + h)
  have hreflect :
      ∀ z ∈ Finset.Ioo 0 h,
        q.Coprime (a + (h - z)) ↔ q.Coprime (r + z) := by
    dsimp [r]
    exact PaperB.Closure.reflected_coprime_equiv hq
      (Nat.ModEq.refl (a + h))
  have hc := summable_combinedBooleanEmptyEndpointTerm
    (q := q) (a := a) (r := r) (h := h) hq hreflect
  have hd := summable_completedBooleanEmptyDensityTerm
    (q := q) (a := a) (h := h) hq hh h2
  exact (hc.sub hd).congr (fun e => by
    have he := combinedEmptyEndpoint_eq_completedAnalytic_add_density
      (q := q) (a := a) (h := h) e
    rw [he]
    ring)

theorem completedBooleanMain_eq_globalAnalytic_add_endpoints
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    completedBooleanMain q a h =
      (ordinaryBooleanCore q a h + decoratedAnalyticRemainder q a h) +
      (∑' e : Finset ℕ,
        (completedBooleanSupport q h).indicator
          (fun e => decoratedAnalyticPairTerm q a h e e) e) +
      (∑' e : Finset ℕ,
        (completedBooleanSupport q h).indicator
          (fun e => decoratedAnalyticPairTerm q a h e (heightPrimePart h e)) e) := by
  let r := PaperB.Closure.reflectedResidue q (a + h)
  have hreflect :
      ∀ z ∈ Finset.Ioo 0 h,
        q.Coprime (a + (h - z)) ↔ q.Coprime (r + z) := by
    dsimp [r]
    exact PaperB.Closure.reflected_coprime_equiv hq
      (Nat.ModEq.refl (a + h))
  have ha := summable_global_decoratedAnalyticPerE
    (q := q) (a := a) (r := r) (h := h) hq hh h2 hreflect
  have hf := summable_completedFullAnalytic
    (q := q) (a := a) (h := h) hq hh h2
  have he := summable_completedEmptyAnalytic
    (q := q) (a := a) (h := h) hq hh h2
  unfold completedBooleanMain
  calc
    (∑' e : Finset ℕ, completedBooleanMainTerm q a h e) =
      ∑' e : Finset ℕ,
        (decoratedAnalyticPerE q a h e +
          (completedBooleanSupport q h).indicator
            (fun e => decoratedAnalyticPairTerm q a h e e) e +
          (completedBooleanSupport q h).indicator
            (fun e => decoratedAnalyticPairTerm q a h e (heightPrimePart h e)) e) := by
              apply tsum_congr
              intro e
              exact completedBooleanMainTerm_eq_analytic_add_endpoints e
    _ = (∑' e : Finset ℕ, decoratedAnalyticPerE q a h e) +
        (∑' e : Finset ℕ,
          (completedBooleanSupport q h).indicator
            (fun e => decoratedAnalyticPairTerm q a h e e) e) +
        (∑' e : Finset ℕ,
          (completedBooleanSupport q h).indicator
            (fun e => decoratedAnalyticPairTerm q a h e (heightPrimePart h e)) e) := by
              rw [(ha.add hf).tsum_add he, ha.tsum_add hf]
    _ = (ordinaryBooleanCore q a h + decoratedAnalyticRemainder q a h) +
        (∑' e : Finset ℕ,
          (completedBooleanSupport q h).indicator
            (fun e => decoratedAnalyticPairTerm q a h e e) e) +
        (∑' e : Finset ℕ,
          (completedBooleanSupport q h).indicator
            (fun e => decoratedAnalyticPairTerm q a h e (heightPrimePart h e)) e) := by
              rw [tsum_decoratedAnalyticPerE_eq_globalProperAnalytic
                hq hh h2 hreflect]

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma dForbiddenBooleanMainTerm_anchor_mod
    (q a H : ℕ) (d n : Finset ℕ) :
    dForbiddenBooleanMainTerm q a H d n =
      dForbiddenBooleanMainTerm q (a % q) H d n := by
  have hw : fixedQLowWeight q a H = fixedQLowWeight q (a % q) H := by
    funext y
    exact fixedQLowWeight_anchor_mod q a H y
  unfold dForbiddenBooleanMainTerm
  rw [hw]

lemma dForbiddenBooleanLeftEndpointTerm_anchor_mod
    (q a H : ℕ) (d n : Finset ℕ) :
    dForbiddenBooleanLeftEndpointTerm q a H d n =
      dForbiddenBooleanLeftEndpointTerm q (a % q) H d n := by
  have hw : fixedQLowWeight q a H = fixedQLowWeight q (a % q) H := by
    funext y
    exact fixedQLowWeight_anchor_mod q a H y
  unfold dForbiddenBooleanLeftEndpointTerm
  rw [hw]

lemma dForbiddenBooleanRightEndpointTerm_anchor_mod
    (q a H : ℕ) (d n : Finset ℕ) :
    dForbiddenBooleanRightEndpointTerm q a H d n =
      dForbiddenBooleanRightEndpointTerm q (a % q) H d n := by
  have hw : fixedQLowWeight q a H = fixedQLowWeight q (a % q) H := by
    funext y
    exact fixedQLowWeight_anchor_mod q a H y
  unfold dForbiddenBooleanRightEndpointTerm
  rw [hw]

noncomputable def signedForbiddenCompletedMainAggregate
    (q a h : ℕ) : ℝ :=
  (∑' n : Finset ℕ,
    dForbiddenBooleanMainTerm q a h ∅ n) +
  ∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
    finiteVWeightReal h d *
      (∑' n : Finset ℕ,
        dForbiddenBooleanMainTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) d n)

theorem completedBooleanMain_eq_signedForbiddenCompletedMainAggregate
    {q a h : ℕ} (hq : 0 < q) (ha : q.Coprime a)
    (hh : 0 < h) (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    completedBooleanMain q a h =
      signedForbiddenCompletedMainAggregate q a h := by
  let P := (decoratedHeightPrimeSet q h).powerset.erase ∅
  let M0 : ℝ := ∑' n : Finset ℕ,
    dForbiddenBooleanMainTerm q a h ∅ n
  let L0 : ℝ := ∑' n : Finset ℕ,
    dForbiddenBooleanLeftEndpointTerm q a h ∅ n
  let R0 : ℝ := ∑' n : Finset ℕ,
    dForbiddenBooleanRightEndpointTerm q a h ∅ n
  let M : ℝ := ∑ d ∈ P,
    finiteVWeightReal h d *
      (∑' n : Finset ℕ,
        dForbiddenBooleanMainTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) d n)
  let L : ℝ := ∑ d ∈ P,
    finiteVWeightReal h d *
      (∑' n : Finset ℕ,
        dForbiddenBooleanLeftEndpointTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) d n)
  let R : ℝ := ∑ d ∈ P,
    finiteVWeightReal h d *
      (∑' n : Finset ℕ,
        dForbiddenBooleanRightEndpointTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) d n)
  have hsmSrc := summable_sourceForbiddenBooleanMainTerm
    (q := q) (a := a) (H := h) hq hh h2 ∅
  have hsm0 : Summable (dForbiddenBooleanMainTerm q a h ∅) := by
    exact hsmSrc.congr (fun n => by
      symm
      exact dForbiddenBooleanMainTerm_eq_source_signed
        (q := q) (a := a) (h := h) (H := h)
        (d := ∅) (n := n) (by simp))
  have hsl0 := summable_dForbiddenBooleanLeftEndpointTerm
    (q := q) (a := a) (H := h) hq hh h2 ∅
  have hsr0 := summable_dForbiddenBooleanRightEndpointTerm
    (q := q) (a := a) (H := h) hq hh h2 ∅
  have hOrdSplit : ordinaryBooleanCore q a h = M0 - L0 - R0 := by
    rw [← tsum_dForbidden_empty_eq_ordinaryBooleanCore q a h]
    have hsml := hsm0.sub hsl0
    dsimp [M0, L0, R0]
    rw [← hsm0.tsum_sub hsl0, ← hsml.tsum_sub hsr0]
    apply tsum_congr
    intro n
    exact dForbiddenReducedBooleanCoreTerm_split q a h ∅ n
  have hAbs : ∀ d ∈ (decoratedHeightPrimeSet q h).powerset,
      Summable (fun n : Finset ℕ =>
        |ordinaryBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) n|) := by
    intro d hd
    have hp := decoratedReducedOrdinaryParameters hq ha hh h2 hd
    exact summable_abs_ordinaryBooleanCoreTerm hq hp.1 hp.2.2.1
  have hSigned := decoratedAnalyticRemainder_eq_signed_forbidden_sum
    (q := q) (a := a) hh hAbs
  have hInnerSplit : ∀ d ∈ P,
      (∑' n : Finset ℕ,
        dForbiddenReducedBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) d n) =
      (∑' n : Finset ℕ,
        dForbiddenBooleanMainTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) d n) -
      (∑' n : Finset ℕ,
        dForbiddenBooleanLeftEndpointTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) d n) -
      (∑' n : Finset ℕ,
        dForbiddenBooleanRightEndpointTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) d n) := by
    intro d hdP
    have hdps : d ∈ (decoratedHeightPrimeSet q h).powerset :=
      (Finset.mem_erase.mp hdP).2
    have hdsub := Finset.mem_powerset.mp hdps
    have hp := decoratedReducedOrdinaryParameters hq ha hh h2 hdps
    have hsmSrcD := summable_sourceForbiddenBooleanMainTerm
      (q := q)
      (a := decoratedReducedAnchor q a (primeSetProduct d))
      (H := h / primeSetProduct d) hq hp.1 hp.2.2.1 d
    have hsm : Summable (dForbiddenBooleanMainTerm q
        (decoratedReducedAnchor q a (primeSetProduct d))
        (h / primeSetProduct d) d) := by
      exact hsmSrcD.congr (fun n => by
        symm
        exact dForbiddenBooleanMainTerm_eq_source_signed
          (q := q)
          (a := decoratedReducedAnchor q a (primeSetProduct d))
          (h := h) (H := h / primeSetProduct d)
          (d := d) (n := n) hdsub)
    have hsl := summable_dForbiddenBooleanLeftEndpointTerm
      (q := q)
      (a := decoratedReducedAnchor q a (primeSetProduct d))
      (H := h / primeSetProduct d) hq hp.1 hp.2.2.1 d
    have hsr := summable_dForbiddenBooleanRightEndpointTerm
      (q := q)
      (a := decoratedReducedAnchor q a (primeSetProduct d))
      (H := h / primeSetProduct d) hq hp.1 hp.2.2.1 d
    have hsml := hsm.sub hsl
    rw [← hsm.tsum_sub hsl, ← hsml.tsum_sub hsr]
    apply tsum_congr
    intro n
    exact dForbiddenReducedBooleanCoreTerm_split q
      (decoratedReducedAnchor q a (primeSetProduct d))
      (h / primeSetProduct d) d n
  have hDecSplit : decoratedAnalyticRemainder q a h = M - L - R := by
    rw [hSigned]
    dsimp [M, L, R, P]
    calc
      (∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
        finiteVWeightReal h d *
          (∑' n : Finset ℕ,
            dForbiddenReducedBooleanCoreTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) d n)) =
      ∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
        finiteVWeightReal h d *
          ((∑' n : Finset ℕ,
            dForbiddenBooleanMainTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) d n) -
           (∑' n : Finset ℕ,
            dForbiddenBooleanLeftEndpointTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) d n) -
           (∑' n : Finset ℕ,
            dForbiddenBooleanRightEndpointTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) d n)) := by
                apply Finset.sum_congr rfl
                intro d hd
                rw [hInnerSplit d hd]
      _ = _ := by
        simp_rw [mul_sub]
        rw [Finset.sum_sub_distrib, Finset.sum_sub_distrib]
  have hFull := completedFullAnalytic_tsum_eq_ordinary_add_mixed
    (q := q) (a := a) (h := h) hq hh h2
  have hEmpty := completedEmptyAnalytic_tsum_eq_ordinary_add_mixed
    (q := q) (a := a) (h := h) hq hh h2
  have ha1 : decoratedReducedAnchor q a 1 = a % q :=
    decoratedReducedAnchor_one hq
  have hL0mod :
      (∑' n : Finset ℕ,
        dForbiddenBooleanLeftEndpointTerm q
          (decoratedReducedAnchor q a 1) h ∅ n) = L0 := by
    dsimp [L0]
    rw [ha1]
    apply tsum_congr
    intro n
    exact (dForbiddenBooleanLeftEndpointTerm_anchor_mod q a h ∅ n).symm
  have hR0mod :
      (∑' n : Finset ℕ,
        dForbiddenBooleanRightEndpointTerm q
          (decoratedReducedAnchor q a 1) h ∅ n) = R0 := by
    dsimp [R0]
    rw [ha1]
    apply tsum_congr
    intro n
    exact (dForbiddenBooleanRightEndpointTerm_anchor_mod q a h ∅ n).symm
  rw [completedBooleanMain_eq_globalAnalytic_add_endpoints hq hh h2]
  rw [hOrdSplit, hDecSplit]
  rw [hFull, hEmpty]
  rw [hL0mod, hR0mod]
  dsimp [M0, M, L0, L, R0, R, P,
    signedForbiddenCompletedMainAggregate]
  ring

end PaperB.FixedQ
