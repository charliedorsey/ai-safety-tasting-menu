import OrielUpper.FarTail2

/-!
# Oriel Upper — the full window `(T, U]`: dyadic shells plus far tail
-/

open Finset

namespace OrielUpper

variable {P : ℕ} [NeZero P]

/-- Window sum inside a fixed box `[1, U]²`. -/
noncomputable def pairBox (F H : ℕ) (w : ℕ → ℝ) (U a b : ℕ) : ℝ :=
  ∑ r ∈ Icc 1 U, ∑ s ∈ Icc 1 U, if winC a b r s then pairTerm F H w r s else 0

lemma pairBox_eq {F H : ℕ} {w : ℕ → ℝ} {U a b : ℕ} (hb : b ≤ U) :
    pairBox F H w U a b = pairWin F H w a b := by
  unfold pairBox pairWin
  have hsub : Icc 1 b ⊆ Icc 1 U := Icc_subset_Icc le_rfl hb
  symm
  rw [← sum_subset hsub]
  · apply sum_congr rfl; intro r _
    rw [← sum_subset hsub]
    intro s hs hsn
    rw [if_neg]
    rintro ⟨_, _, _, hle⟩
    apply hsn
    simp only [mem_Icc] at hs ⊢
    refine ⟨hs.1, le_trans ?_ hle⟩
    exact Nat.le_mul_of_pos_left s (by omega)
  · intro r hr hrn
    apply sum_eq_zero; intro s hs
    rw [if_neg]
    rintro ⟨_, _, _, hle⟩
    apply hrn
    simp only [mem_Icc] at hr hs ⊢
    refine ⟨hr.1, le_trans ?_ hle⟩
    exact Nat.le_mul_of_pos_right r (by omega)

lemma winC_split {x y U r s : ℕ} (hxy : x ≤ y) (f : ℝ) :
    (if winC x U r s then f else 0) =
      (if winC x (min y U) r s then f else 0) + (if winC y U r s then f else 0) := by
  by_cases h1 : winC x U r s
  · have h1' : 1 < r ∧ 1 < s ∧ x < r * s ∧ r * s ≤ U := h1
    rw [if_pos h1]
    by_cases h2 : r * s ≤ y
    · rw [if_pos (show winC x (min y U) r s from
          ⟨h1'.1, h1'.2.1, h1'.2.2.1, le_min h2 h1'.2.2.2⟩),
        if_neg (show ¬ winC y U r s from fun h => absurd h.2.2.1 (not_lt.mpr h2))]
      ring
    · rw [if_neg (show ¬ winC x (min y U) r s from
          fun h => h2 (h.2.2.2.trans (min_le_left y U))),
        if_pos (show winC y U r s from ⟨h1'.1, h1'.2.1, not_le.mp h2, h1'.2.2.2⟩)]
      ring
  · rw [if_neg h1, if_neg (show ¬ winC x (min y U) r s from
        fun h => h1 ⟨h.1, h.2.1, h.2.2.1, h.2.2.2.trans (min_le_right _ _)⟩),
      if_neg (show ¬ winC y U r s from
        fun h => h1 ⟨h.1, h.2.1, lt_of_le_of_lt hxy h.2.2.1, h.2.2.2⟩)]
    ring

lemma pairBox_telescope (F H : ℕ) (w : ℕ → ℝ) (U a0 : ℕ) (J : ℕ) :
    pairBox F H w U a0 U =
      ∑ j ∈ range J, pairBox F H w U (a0 * 2 ^ j) (min (a0 * 2 ^ (j + 1)) U) +
        pairBox F H w U (a0 * 2 ^ J) U := by
  induction J with
  | zero => simp
  | succ J ih =>
    rw [ih, sum_range_succ, add_assoc]
    congr 1
    unfold pairBox
    rw [← sum_add_distrib]
    apply sum_congr rfl; intro r _
    rw [← sum_add_distrib]
    apply sum_congr rfl; intro s _
    exact winC_split (Nat.mul_le_mul_left _ (Nat.pow_le_pow_right (by norm_num) (by omega))) _

/-- The uniform shell budget. -/
noncomputable def shellU (P : ℕ) (B E1 E34 Cτ M D : ℝ) (U : ℕ) : ℝ :=
  2 * ((2 * P + 1) * B * (1 + Real.log 4) * E1 * (Cτ + 2 * E1) +
    E34 * E1 * (1 + Real.log U) *
      (2 * P * B * (8 * M + 4 * P + 5) / M + (2 * P + 2) * B * (1 + Real.log 4)) *
        D ^ (-(1 / 4 : ℝ))) + budget3 P B E1 M D

/-- Choice of the sector cut. -/
noncomputable def cutR (a : ℕ) (M D : ℝ) : ℕ := max 1 (Nat.sqrt ⌊(a : ℝ) / (M * D)⌋₊)

lemma cutR_spec {a : ℕ} {M D : ℝ} (ha : 1 ≤ a) (hMD : 1 ≤ M * D) :
    1 ≤ cutR a M D ∧ cutR a M D * cutR a M D ≤ a ∧
      (1 < cutR a M D → ((cutR a M D : ℕ) : ℝ) ^ 2 * (M * D) ≤ a) ∧
      (a : ℝ) < (((cutR a M D : ℕ) : ℝ) + 1) ^ 2 * (M * D) := by
  unfold cutR
  have hMD0 : 0 < M * D := by linarith
  set x := (a : ℝ) / (M * D)
  have hx0 : 0 ≤ x := by positivity
  have hxa : x ≤ a := by
    rw [div_le_iff₀ hMD0]; have : (0 : ℝ) ≤ a := by positivity
    nlinarith
  set n := ⌊x⌋₊
  set s := Nat.sqrt n
  have hs1 : s * s ≤ n := Nat.sqrt_le n
  have hs2 : n < (s + 1) * (s + 1) := Nat.lt_succ_sqrt n
  have hnx : (n : ℝ) ≤ x := Nat.floor_le hx0
  have hxn : x < (n : ℝ) + 1 := Nat.lt_floor_add_one x
  rcases Nat.eq_zero_or_pos s with h0 | hpos
  · rw [h0, max_eq_left (by norm_num)]
    have hn0 : n = 0 := by rw [h0] at hs2; omega
    refine ⟨le_rfl, by omega, fun h => absurd h (lt_irrefl 1), ?_⟩
    rw [hn0] at hxn
    have : (a : ℝ) < M * D := by
      have := (div_lt_iff₀ hMD0).mp (by simpa using hxn); linarith
    push_cast; nlinarith
  · rw [max_eq_right hpos]
    have hsn : ((s * s : ℕ) : ℝ) ≤ x := le_trans (by exact_mod_cast hs1) hnx
    refine ⟨hpos, ?_, ?_, ?_⟩
    · have : ((s * s : ℕ) : ℝ) ≤ a := hsn.trans hxa
      exact_mod_cast this
    · intro _
      have := (le_div_iff₀ hMD0).mp (show ((s * s : ℕ) : ℝ) ≤ x from hsn)
      push_cast at this; nlinarith
    · have h1 : x < (((s + 1) * (s + 1) : ℕ) : ℝ) := by
        have : (n : ℝ) + 1 ≤ (((s + 1) * (s + 1) : ℕ) : ℝ) := by exact_mod_cast hs2
        linarith
      have := (div_lt_iff₀ hMD0).mp h1
      push_cast at this; nlinarith

theorem window_bound {F H : ℕ} {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {B : ℝ}
    (hR : RowHyp P F H w Λ B) {T U J : ℕ} {M D Λf E1 E34 Cτ : ℝ}
    (hM : 1 ≤ M) (hD : 1 ≤ D) (hΛf : 0 < Λf)
    (hHM : (H : ℝ) ≤ 2 * M * (max T 1 : ℕ))
    (hJ : Λf * H ≤ ((max T 1 : ℕ) : ℝ) * 2 ^ J)
    (hE1 : ∀ m N, 1 ≤ m → m ≤ U → Asig (F * m) N 1 ≤ E1)
    (hE34 : ∀ m N, 1 ≤ m → m ≤ U → Asig (F * m) N (3 / 4) ≤ E34)
    (hτ : ∀ N, ∑ r ∈ Icc 1 N, bW F r * ((r.divisors.card : ℝ) / r) ≤ Cτ)
    (hE1n : 0 ≤ E1) (hE34n : 0 ≤ E34) :
    |pairWin F H w T U| ≤
      J * shellU P B E1 E34 Cτ M D U + B / Λf * (PiH H + (1 + E1 * (1 + Real.log U)) ^ 2) := by
  have hB0 := hR.B_nonneg
  have hMD : 1 ≤ M * D := by nlinarith
  set a0 := max T 1 with ha0
  have ha01 : 1 ≤ a0 := le_max_right _ _
  -- trivial window
  rcases Nat.eq_zero_or_pos U with hU0 | hU1
  · subst hU0
    have : pairWin F H w T 0 = 0 := by unfold pairWin; simp
    rw [this, abs_zero]
    have hτ0 : 0 ≤ Cτ := le_trans (by simp) (hτ 0)
    have hM0 : 0 < M := by linarith
    have : 0 ≤ Real.log 4 := Real.log_nonneg (by norm_num)
    have : 0 ≤ Real.log (8 * M * D) := Real.log_nonneg (by nlinarith)
    have := PiH_pos H
    unfold shellU budget3
    simp only [Nat.cast_zero, Real.log_zero, add_zero]
    positivity
  have hE1F : ∀ N, Asig F N 1 ≤ E1 := by
    intro N; have := hE1 1 N le_rfl hU1; rwa [mul_one] at this
  have hE1' : 0 ≤ E1 := le_trans (Asig_nonneg F 0 1) (hE1F 0)
  have hE34' : 0 ≤ E34 := le_trans (Asig_nonneg _ _ _) (hE34 1 0 le_rfl hU1)
  -- replace T by a0
  have hT : pairWin F H w T U = pairWin F H w a0 U := by
    unfold pairWin
    apply sum_congr rfl; intro r _; apply sum_congr rfl; intro s _
    have : winC T U r s ↔ winC a0 U r s := by
      unfold winC
      constructor
      · rintro ⟨h1, h2, h3, h4⟩
        refine ⟨h1, h2, max_lt h3 ?_, h4⟩
        have : 2 * 2 ≤ r * s := Nat.mul_le_mul h1 h2
        omega
      · rintro ⟨h1, h2, h3, h4⟩; exact ⟨h1, h2, lt_of_le_of_lt (le_max_left _ _) h3, h4⟩
    by_cases h : winC T U r s
    · rw [if_pos h, if_pos (this.mp h)]
    · rw [if_neg h, if_neg (fun h' => h (this.mpr h'))]
  rw [hT, ← pairBox_eq le_rfl, pairBox_telescope F H w U a0 J]
  refine (abs_add_le _ _).trans (add_le_add ?_ ?_)
  · -- the shells
    refine (abs_sum_le_sum_abs _ _).trans ?_
    have hshell : ∀ j ∈ range J,
        |pairBox F H w U (a0 * 2 ^ j) (min (a0 * 2 ^ (j + 1)) U)| ≤
          shellU P B E1 E34 Cτ M D U := by
      intro j _
      set a := a0 * 2 ^ j
      set b := min (a0 * 2 ^ (j + 1)) U
      have hbU : b ≤ U := min_le_right _ _
      rw [pairBox_eq hbU]
      have ha1 : 1 ≤ a := Nat.one_le_iff_ne_zero.mpr (by positivity)
      have hshU : 0 ≤ shellU P B E1 E34 Cτ M D U := by
        unfold shellU budget3
        have : 0 ≤ Real.log 4 := Real.log_nonneg (by norm_num)
        have : 0 ≤ Real.log U := Real.log_nonneg (by exact_mod_cast hU1)
        have : 0 ≤ Real.log (8 * M * D) := Real.log_nonneg (by nlinarith)
        have : 0 < M := by linarith
        have : 0 ≤ Cτ := le_trans (by simp) (hτ 0)
        positivity
      by_cases hab : a ≤ b
      swap
      · have : pairWin F H w a b = 0 := by
          unfold pairWin
          apply sum_eq_zero; intro r _; apply sum_eq_zero; intro s _
          rw [if_neg]; rintro ⟨_, _, h3, h4⟩; omega
        rw [this, abs_zero]; exact hshU
      have hb2 : b ≤ 2 * a := by
        have : a0 * 2 ^ (j + 1) = 2 * a := by rw [pow_succ]; ring
        omega
      obtain ⟨hR1, hRa, hRup, hRlow⟩ := cutR_spec (M := M) (D := D) ha1 hMD
      have hHa : (H : ℝ) ≤ 2 * M * a := by
        refine hHM.trans ?_
        apply mul_le_mul_of_nonneg_left _ (by linarith)
        exact_mod_cast Nat.le_mul_of_pos_right a0 (by positivity)
      have hsb := shell_bound hR ha1 hab hb2 hR1 hRa hHa hM hD hRup hRlow
        (fun m N h1 h2 => hE1 m N h1 (h2.trans hbU))
        (fun m N h1 h2 => hE34 m N h1 (h2.trans hbU)) hτ
      refine hsb.trans ?_
      unfold shellU budget12
      set R := cutR a M D
      have hRr : (1 : ℝ) ≤ R := by exact_mod_cast hR1
      have hlR : 0 ≤ Real.log R := Real.log_nonneg hRr
      have har : (1 : ℝ) ≤ a := by exact_mod_cast ha1
      have hRa' : (R : ℝ) ≤ a := by
        have : R ≤ a := le_trans (Nat.le_mul_self R) hRa
        exact_mod_cast this
      have hRU : (R : ℝ) ≤ U := by
        have : R ≤ U := le_trans (le_trans (Nat.le_mul_self R) hRa) (hab.trans hbU)
        exact_mod_cast this
      have hlRa : 1 + Real.log R ≤ a := by
        have := Real.log_le_sub_one_of_pos (show (0 : ℝ) < R by linarith)
        linarith
      have h1 : 2 * E1 * (1 + Real.log R) / a ≤ 2 * E1 := by
        rw [div_le_iff₀ (by linarith)]
        nlinarith
      have h2 : 1 + Real.log R ≤ 1 + Real.log U := by
        have := Real.log_le_log (by linarith) hRU; linarith
      have hl4 : 0 ≤ Real.log 4 := Real.log_nonneg (by norm_num)
      have hM0 : 0 < M := by linarith
      have hc : 0 ≤ (2 * P * B * (8 * M + 4 * P + 5) / M + (2 * P + 2) * B * (1 + Real.log 4)) *
          D ^ (-(1 / 4 : ℝ)) := by positivity
      have hτ0 : 0 ≤ Cτ := le_trans (by simp) (hτ 0)
      have k1 : (2 * (P : ℝ) + 1) * B * (1 + Real.log 4) * E1 *
            (Cτ + 2 * E1 * (1 + Real.log R) / a) ≤
          (2 * (P : ℝ) + 1) * B * (1 + Real.log 4) * E1 * (Cτ + 2 * E1) := by
        apply mul_le_mul_of_nonneg_left _ (by positivity); linarith
      have k2 : E34 * E1 * (1 + Real.log R) *
            (2 * P * B * (8 * M + 4 * P + 5) / M + (2 * P + 2) * B * (1 + Real.log 4)) *
            D ^ (-(1 / 4 : ℝ)) ≤
          E34 * E1 * (1 + Real.log U) *
            (2 * P * B * (8 * M + 4 * P + 5) / M + (2 * P + 2) * B * (1 + Real.log 4)) *
            D ^ (-(1 / 4 : ℝ)) := by
        have e1 : ∀ X : ℝ, E34 * E1 * X *
            (2 * P * B * (8 * M + 4 * P + 5) / M + (2 * P + 2) * B * (1 + Real.log 4)) *
            D ^ (-(1 / 4 : ℝ)) = (E34 * E1) * X *
            ((2 * P * B * (8 * M + 4 * P + 5) / M + (2 * P + 2) * B * (1 + Real.log 4)) *
            D ^ (-(1 / 4 : ℝ))) := fun X => by ring
        rw [e1, e1]
        apply mul_le_mul_of_nonneg_right _ hc
        apply mul_le_mul_of_nonneg_left h2 (by positivity)
      linarith
    refine (sum_le_sum hshell).trans ?_
    rw [sum_const, card_range, nsmul_eq_mul]
  · -- the far tail
    have hY : 1 ≤ a0 * 2 ^ J := Nat.one_le_iff_ne_zero.mpr (by positivity)
    rw [pairBox_eq le_rfl]
    refine (far_tail hR hY hU1 hE1F).trans ?_
    have hYr : (0 : ℝ) < ((a0 * 2 ^ J : ℕ) : ℝ) := by exact_mod_cast hY
    have hpos : 0 ≤ PiH H + (1 + E1 * (1 + Real.log U)) ^ 2 := by
      have := PiH_pos H; positivity
    apply mul_le_mul_of_nonneg_right _ hpos
    rw [div_le_div_iff₀ hYr hΛf]
    push_cast
    nlinarith

end OrielUpper
