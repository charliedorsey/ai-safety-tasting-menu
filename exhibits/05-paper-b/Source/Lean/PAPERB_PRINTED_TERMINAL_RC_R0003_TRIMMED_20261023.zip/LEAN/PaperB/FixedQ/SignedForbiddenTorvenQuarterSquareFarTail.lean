import PaperB.FixedQ.SignedForbiddenNaturalFarTailRate
import PaperB.FixedQ.H2BooleanGlobalSourceSplit

open scoped BigOperators
namespace PaperB.FixedQ

/-- Proper two-sided divisors fit inside y(H-y) <= H^2/4. -/
lemma torven_rowConstrainedMass_eq_zero_of_quad_product_gt_sq
    (lambda : ℕ → ℝ) {H e1 e2 : ℕ}
    (hgt : H ^ 2 < 4 * (e1 * e2)) :
    rowConstrainedMass lambda H e1 e2 = 0 := by
  unfold rowConstrainedMass
  apply Finset.sum_eq_zero
  intro y hy
  have hyI := Finset.mem_Ioo.mp hy
  by_cases hc : e1 ∣ y ∧ e2 ∣ H - y
  · have hypos : 0 < y := hyI.1
    have hzpos : 0 < H - y := Nat.sub_pos_of_lt hyI.2
    have he1 : e1 ≤ y := Nat.le_of_dvd hypos hc.1
    have he2 : e2 ≤ H - y := Nat.le_of_dvd hzpos hc.2
    have hsum : y + (H - y) = H := Nat.add_sub_of_le (Nat.le_of_lt hyI.2)
    have hmul : e1 * e2 ≤ y * (H - y) := Nat.mul_le_mul he1 he2
    have hsumR : (y : ℝ) + (((H - y : ℕ) : ℝ)) = (H : ℝ) := by
      exact_mod_cast hsum
    have hmulR : (e1 : ℝ) * (e2 : ℝ) ≤
        (y : ℝ) * ((H - y : ℕ) : ℝ) := by
      exact_mod_cast hmul
    have hgtR : (H : ℝ) ^ 2 < 4 * ((e1 : ℝ) * (e2 : ℝ)) := by
      exact_mod_cast hgt
    have hsq : 0 ≤ ((y : ℝ) - (((H - y : ℕ) : ℝ))) ^ 2 := sq_nonneg _
    exfalso
    nlinarith
  · rw [if_neg hc]

/-- Exact row discrepancy after the improved geometric cutoff. -/
lemma torven_rowDiscrepancy_eq_neg_density_of_quad_product_gt_sq
    (lambda : ℕ → ℝ) {H e1 e2 : ℕ}
    (hgt : H ^ 2 < 4 * (e1 * e2)) :
    rowDiscrepancy lambda H e1 e2 =
      - rowWeightMass lambda H / ((e1 : ℝ) * (e2 : ℝ)) := by
  unfold rowDiscrepancy
  rw [torven_rowConstrainedMass_eq_zero_of_quad_product_gt_sq lambda hgt]
  ring
/-- Every source Boolean partition is pure density when 4m > H^2. -/
theorem torven_fixedProductPartitionDiscrepancy_eq_neg_density_quad_gt_sq
    (lambda : ℕ → ℝ) {H : ℕ} {S A : Finset ℕ}
    (hPrime : ∀ p ∈ S, p.Prime)
    (hA : A ⊆ S)
    (hgt : H ^ 2 < 4 * primeSetProduct S) :
    fixedProductPartitionDiscrepancy lambda H S A =
      - rowWeightMass lambda H / (primeSetProduct S : ℝ) := by
  let e1 := primeSetProduct A
  let e2 := primeSetProduct (S \ A)
  have hprod : e1 * e2 = primeSetProduct S := by
    simpa [e1, e2, fixedProductModulus] using
      pair_moduli_product_eq_fixedProduct hA hPrime
  have hgt' : H ^ 2 < 4 * (e1 * e2) := by
    simpa [hprod] using hgt
  unfold fixedProductPartitionDiscrepancy
  rw [torven_rowDiscrepancy_eq_neg_density_of_quad_product_gt_sq lambda hgt']
  rw [← Nat.cast_mul, hprod]

/-- Improving the paid H^2 far-product formula to the sharp H^2/4
    geometric vanishing threshold, with no positivity requirement on lambda. -/
theorem torven_fixedProductBooleanDiscrepancy_eq_neg_density_quad_gt_sq
    (lambda : ℕ → ℝ) {H : ℕ} {S : Finset ℕ}
    (hPrime : ∀ p ∈ S, p.Prime)
    (hgt : H ^ 2 < 4 * primeSetProduct S) :
    fixedProductBooleanDiscrepancy lambda H S =
      - rowWeightMass lambda H / (primeSetProduct S : ℝ) := by
  have hpow0 : (2 : ℝ) ^ S.card ≠ 0 := by positivity
  unfold fixedProductBooleanDiscrepancy
  have hsum :
      (∑ A ∈ S.powerset,
        fixedProductPartitionDiscrepancy lambda H S A) =
      (S.powerset.card : ℝ) *
        (- rowWeightMass lambda H / (primeSetProduct S : ℝ)) := by
    calc
      (∑ A ∈ S.powerset,
        fixedProductPartitionDiscrepancy lambda H S A)
        = ∑ A ∈ S.powerset,
            (- rowWeightMass lambda H / (primeSetProduct S : ℝ)) := by
              apply Finset.sum_congr rfl
              intro A hA
              exact torven_fixedProductPartitionDiscrepancy_eq_neg_density_quad_gt_sq
                lambda hPrime (Finset.mem_powerset.mp hA) hgt
      _ = (S.powerset.card : ℝ) *
          (- rowWeightMass lambda H / (primeSetProduct S : ℝ)) := by
            rw [Finset.sum_const, nsmul_eq_mul]
  rw [hsum, Finset.card_powerset]
  norm_cast
  field_simp [hpow0]

/-- Exact proper signed core density for moduli above H^2/4. -/
theorem torven_ordinaryBooleanInteriorDiscrepancy_eq_neg_density_quad_gt_sq
    (lambda : ℕ → ℝ) {H : ℕ} {S : Finset ℕ}
    (hPrime : ∀ p ∈ S, p.Prime)
    (hne : S.Nonempty)
    (hgt : H ^ 2 < 4 * primeSetProduct S) :
    ordinaryBooleanInteriorDiscrepancy lambda H S =
      - (((2 : ℝ) ^ S.card - 2) * rowWeightMass lambda H /
          (primeSetProduct S : ℝ)) := by
  rw [ordinaryBooleanInteriorDiscrepancy_eq_full_sub_endpoints lambda H hne,
    torven_fixedProductBooleanDiscrepancy_eq_neg_density_quad_gt_sq
      lambda hPrime hgt,
    torven_fixedProductPartitionDiscrepancy_eq_neg_density_quad_gt_sq
      lambda hPrime (by simp) hgt,
    torven_fixedProductPartitionDiscrepancy_eq_neg_density_quad_gt_sq
      lambda hPrime (by simp) hgt]
  ring

#print axioms torven_ordinaryBooleanInteriorDiscrepancy_eq_neg_density_quad_gt_sq
#print axioms torven_rowConstrainedMass_eq_zero_of_quad_product_gt_sq
#print axioms torven_fixedProductBooleanDiscrepancy_eq_neg_density_quad_gt_sq

end PaperB.FixedQ

namespace PaperB.FixedQ

/-- Source core bound on the new H^2/4 far-product sector. -/
theorem torven_abs_ordinaryBooleanCoreTerm_quad_far_le_shiu
    {q A H : ℕ}
    (h2 : ¬ 2 ∣ q → 2 ∣ H)
    (hH : 2 ≤ H)
    (S : Finset ℕ)
    (hgt : H ^ 2 < 4 * primeSetProduct S) :
    |ordinaryBooleanCoreTerm q A H S| ≤
      6 * (H : ℝ) *
        (fixedQShiuWeight q (primeSetProduct S) /
          (primeSetProduct S : ℝ)) := by
  classical
  have hR : 0 ≤ 6 * (H : ℝ) *
      (fixedQShiuWeight q (primeSetProduct S) /
        (primeSetProduct S : ℝ)) := by
    exact mul_nonneg
      (mul_nonneg (by norm_num) (Nat.cast_nonneg H))
      (div_nonneg (fixedQShiuWeight_nonneg q _) (Nat.cast_nonneg _))
  by_cases hact : S ∈ activeOrdinaryTwoDimensionalSet q H
  · have hPrime : ∀ p ∈ S, p.Prime := fun p hp => (hact.2 p hp).1
    have hne : S.Nonempty := by
      by_contra hn
      have hS : S = ∅ := Finset.not_nonempty_iff_eq_empty.mp hn
      subst S
      simp [primeSetProduct] at hgt
      have hHsq : 4 ≤ H ^ 2 := by
        nlinarith [sq_nonneg ((H : ℝ) - 2)]
      omega
    have hcpos : 1 ≤ S.card := Finset.card_pos.mpr hne
    have hpow : (2 : ℝ) ≤ (2 : ℝ) ^ S.card := by
      simpa using (pow_le_pow_right₀
        (a := (2 : ℝ)) (by norm_num : (1 : ℝ) ≤ 2) hcpos)
    have hcoef : |(2 : ℝ) ^ S.card - 2| ≤ (2 : ℝ) ^ S.card := by
      rw [abs_of_nonneg (sub_nonneg.mpr hpow)]
      linarith
    have hm : (0 : ℝ) < primeSetProduct S := by
      exact_mod_cast primeSetProduct_pos hPrime
    have hω : 0 ≤ finiteOmegaWeightReal S :=
      finiteOmegaWeightReal_nonneg_of_active hact.2
    have hmass := abs_rowWeightMass_fixedQLowWeight_le_six_mul
      (q := q) (a := A) (H := H) h2
    have hdisc := torven_ordinaryBooleanInteriorDiscrepancy_eq_neg_density_quad_gt_sq
      (fixedQLowWeight q A H) hPrime hne hgt
    rw [ordinaryBooleanCoreTerm, Set.indicator_of_mem hact, hdisc]
    have hshiu :=
      fixedQShiuWeight_primeSetProduct_eq_card_mul_finiteOmegaWeightReal
        (q := q) (n := S) hact.2
    rw [hshiu]
    simp only [abs_mul, abs_div, abs_neg, abs_of_pos hm,
      abs_of_nonneg hω]
    calc
      finiteOmegaWeightReal S *
          (|(2 : ℝ) ^ S.card - 2| *
            |rowWeightMass (fixedQLowWeight q A H) H| /
              (primeSetProduct S : ℝ))
        ≤ finiteOmegaWeightReal S *
          ((2 : ℝ) ^ S.card *
            ((6 * (H : ℝ)) / (primeSetProduct S : ℝ))) := by
              have hnumer :
                  |(2 : ℝ) ^ S.card - 2| *
                      |rowWeightMass (fixedQLowWeight q A H) H| ≤
                    (2 : ℝ) ^ S.card * (6 * (H : ℝ)) :=
                mul_le_mul hcoef hmass (abs_nonneg _) (by positivity)
              have hquot := div_le_div_of_nonneg_right hnumer hm.le
              have hmulq := mul_le_mul_of_nonneg_left hquot hω
              convert hmulq using 1 <;> ring
      _ = 6 * (H : ℝ) *
            (((2 : ℝ) ^ S.card * finiteOmegaWeightReal S) /
              (primeSetProduct S : ℝ)) := by ring
  · simpa [ordinaryBooleanCoreTerm, Set.indicator, hact] using hR

#print axioms torven_abs_ordinaryBooleanCoreTerm_quad_far_le_shiu

end PaperB.FixedQ

namespace PaperB.FixedQ

/-- The literal natural-modulus Boolean source also has the stronger
    geometric far-tail Shiu majorant, at 4*m > H^2. -/
theorem torven_abs_sourceForbiddenBooleanNaturalTerm_quad_far_le
    {q a H D m : ℕ}
    (h2 : ¬ 2 ∣ q → 2 ∣ H)
    (hgt : H ^ 2 < 4 * m) :
    |sourceForbiddenBooleanNaturalTerm q a H D m| ≤
      6 * (H : ℝ) * (fixedQShiuWeight q m / (m : ℝ)) := by
  by_cases hcond : 1 < m ∧ Squarefree m ∧ m.Coprime (H * (6 * q) * D)
  · rcases hcond with ⟨hm1, hsq, hcop⟩
    have hPrime : ∀ p ∈ m.primeFactors, p.Prime := by
      intro p hp
      exact (Nat.mem_primeFactors.mp hp).1
    have hprod : primeSetProduct m.primeFactors = m :=
      Nat.prod_primeFactors_of_squarefree hsq
    have hdisc :=
      torven_fixedProductBooleanDiscrepancy_eq_neg_density_quad_gt_sq
        (fixedQLowWeight q a H) hPrime
        (by simpa [hprod] using hgt)
    rw [sourceForbiddenBooleanNaturalTerm, if_pos ⟨hm1, hsq, hcop⟩]
    rw [hdisc, hprod]
    have hw0 : 0 ≤ fixedQShiuWeight q m := fixedQShiuWeight_nonneg q m
    have hmpos : 0 < (m : ℝ) := by exact_mod_cast (show 0 < m by omega)
    have hmass := abs_rowWeightMass_fixedQLowWeight_le_six_mul
      (q := q) (a := a) (H := H) h2
    rw [abs_mul, abs_div, abs_of_pos hmpos, abs_neg]
    calc
      |fixedQShiuWeight q m| *
          (|rowWeightMass (fixedQLowWeight q a H) H| / (m : ℝ))
        = fixedQShiuWeight q m *
          (|rowWeightMass (fixedQLowWeight q a H) H| / (m : ℝ)) := by
            rw [abs_of_nonneg hw0]
      _ ≤ fixedQShiuWeight q m *
          ((6 * (H : ℝ)) / (m : ℝ)) := by
            gcongr
      _ = 6 * (H : ℝ) * (fixedQShiuWeight q m / (m : ℝ)) := by
            field_simp
  · rw [sourceForbiddenBooleanNaturalTerm, if_neg hcond]
    have hright : 0 ≤
        6 * (H : ℝ) * (fixedQShiuWeight q m / (m : ℝ)) := by
      exact mul_nonneg
        (mul_nonneg (by norm_num) (Nat.cast_nonneg H))
        (div_nonneg (fixedQShiuWeight_nonneg q m) (Nat.cast_nonneg m))
    simpa using hright

#print axioms torven_abs_sourceForbiddenBooleanNaturalTerm_quad_far_le

end PaperB.FixedQ
