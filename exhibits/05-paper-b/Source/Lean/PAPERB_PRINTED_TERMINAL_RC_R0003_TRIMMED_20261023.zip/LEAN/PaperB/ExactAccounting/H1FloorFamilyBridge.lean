import PaperB.Closure

open scoped BigOperators

namespace PaperB.ExactAccounting

open PaperB.FixedQ

lemma periodicWeightMass_eq_rowPrefixMass
    {L : ℕ} {w : ℕ → ℝ}
    (hper : Function.Periodic w L) :
    periodicWeightMass L w = rowPrefixMass w L := by
  unfold periodicWeightMass rowPrefixMass
  have hshift :
      (∑ a ∈ Finset.Icc 1 L, w a) =
        ∑ k ∈ Finset.range L, w (k + 1) := by
    refine Finset.sum_bij (fun a ha => a - 1) ?_ ?_ ?_ ?_
    · intro a ha
      rw [Finset.mem_Icc] at ha
      rw [Finset.mem_range]
      omega
    · intro a1 ha1 a2 ha2 heq
      rw [Finset.mem_Icc] at ha1 ha2
      omega
    · intro k hk
      rw [Finset.mem_range] at hk
      refine ⟨k + 1, ?_, ?_⟩
      · rw [Finset.mem_Icc]
        omega
      · omega
    · intro a ha
      rw [Finset.mem_Icc] at ha
      congr 1
      omega
  rw [hshift]
  have hs := Finset.sum_range_succ' w L
  have ht := Finset.sum_range_succ w L
  have hp := hper 0
  simp only [zero_add] at hp
  rw [ht] at hs
  linarith

lemma rowConstrainedMass_reduced_eq_occupied
    (q a H e : ℕ) :
    rowConstrainedMass (reducedFixedQLowWeight q a H) H e 1 =
      rowConstrainedMass (occupiedReducedFixedQLowWeight q a H) H e 1 := by
  unfold rowConstrainedMass
  apply Finset.sum_congr rfl
  intro y hy
  by_cases hc : e ∣ y
  · simp [hc]
    have hylt := (Finset.mem_Ioo.mp hy).2
    exact reducedFixedQLowWeight_eq_occupied
      (Nat.le_of_lt hylt) (fun _ => dvd_mul_right 2 H)
  · simp [hc]

lemma moving_row_delta_eq_reduced_centered
    {q a H e : ℕ}
    (ha : q.Coprime a)
    (hec : movingVCoeff q (2 * H) e ≠ 0) :
    fixedQRowDelta q a (2 * H) e 1 =
      rowConstrainedMass (occupiedReducedFixedQLowWeight q a H) H e 1 -
        (admissibleInteriorCount q a (2 * H) : ℝ) / (e : ℝ) := by
  have he0 : e ≠ 0 := by
    intro h
    subst e
    simp [movingVCoeff] at hec
  have he : 0 < e := Nat.pos_of_ne_zero he0
  have heP := movingVCoeff_coprime_fixedQPeriod_of_ne_zero hec
  have h2P : 2 ∣ fixedQPeriod q := by
    unfold fixedQPeriod
    exact (show 2 ∣ 6 by norm_num).trans (Nat.dvd_lcm_left 6 q)
  have he2 : e.Coprime 2 := Nat.Coprime.of_dvd_right h2P heP
  have hred := fixedQRowReduction_exact
    (q := q) (a := a) (aD := a) (d := 1) (H := H)
    (r := e) (e2 := 1)
    ha (by simpa using (Nat.ModEq.refl a : a ≡ a [MOD q])) (by norm_num) he (by norm_num)
    (by norm_num) (by norm_num) (by norm_num) he2 (by norm_num)
  have hmass := rowConstrainedMass_reduced_eq_occupied q a H e
  simp only [one_mul, mul_one, Nat.cast_one] at hred
  unfold rowDiscrepancy fixedQRowPeriodicDensityDelta at hred
  rw [hmass] at hred
  norm_num at hred
  have heR : (e : ℝ) ≠ 0 := by exact_mod_cast he0
  field_simp [heR] at hred ⊢
  linarith

lemma occupied_periodic_mean
    {q a H : ℕ} (hq : 0 < q) (ha : q.Coprime a)
    [NeZero (fixedQPeriod q)] :
    periodicWeightMass (fixedQPeriod q)
        (occupiedReducedFixedQLowWeight q a H) /
        (fixedQPeriod q : ℝ) =
      fixedQRowMean q := by
  have hp := periodicWeightMass_eq_rowPrefixMass
    (occupiedReducedFixedQLowWeight_periodic q a H)
  rw [hp, rowPrefixMass_occupiedReduced_period q a H hq ha]
  have hP : (fixedQPeriod q : ℝ) ≠ 0 := by
    exact_mod_cast (NeZero.ne (fixedQPeriod q))
  field_simp [hP]

lemma moving_row_delta_floor
    {q a H e : ℕ} [NeZero (fixedQPeriod q)]
    (hq : 0 < q) (ha : q.Coprime a) (hH : 2 ≤ H)
    (hec : movingVCoeff q (2 * H) e ≠ 0)
    (heX : e ≤ H - 1) :
    movingVCoeff q (2 * H) e * fixedQRowDelta q a (2 * H) e 1 =
      oneDimensionalDensityCoeff q a H * movingVReciprocalTerm q (2 * H) e +
      movingVCoeff q (2 * H) e *
        manuscriptBoundaryTerm (fixedQPeriod q)
          (occupiedReducedFixedQLowWeight q a H)
          (ZMod.unitOfCoprime e
            (movingVCoeff_coprime_fixedQPeriod_of_ne_zero hec)) -
      movingVCoeff q (2 * H) e *
        manuscriptSawtoothTerm (fixedQPeriod q)
          (occupiedReducedFixedQLowWeight q a H)
          (ZMod.unitOfCoprime e
            (movingVCoeff_coprime_fixedQPeriod_of_ne_zero hec))
          (((H - 1 : ℕ) : ℝ) / (e : ℝ)) := by
  have he0 : e ≠ 0 := by
    intro h
    subst e
    simp [movingVCoeff] at hec
  have he : 0 < e := Nat.pos_of_ne_zero he0
  have hcenter := moving_row_delta_eq_reduced_centered ha hec
  rw [hcenter]
  have hmass := rowConstrainedMass_one_eq_dilate_prefix
    (occupiedReducedFixedQLowWeight q a H) H e (by omega) he
  rw [hmass]
  have hfloor := exactManuscriptPeriodicFloorDecomposition_realDiv
    (w := occupiedReducedFixedQLowWeight q a H)
    (L := fixedQPeriod q) (e := e) (X := H - 1)
    (movingVCoeff_coprime_fixedQPeriod_of_ne_zero hec)
    (by omega) (occupiedReducedFixedQLowWeight_periodic q a H)
  rw [hfloor]
  rw [occupied_periodic_mean hq ha]
  unfold oneDimensionalDensityCoeff movingVReciprocalTerm
  have heR : (e : ℝ) ≠ 0 := by exact_mod_cast he0
  field_simp [heR]
  ring

lemma moving_row_delta_tail
    {q a H e : ℕ}
    (ha : q.Coprime a) (hH : 2 ≤ H)
    (hec : movingVCoeff q (2 * H) e ≠ 0)
    (heX : H - 1 < e) :
    movingVCoeff q (2 * H) e * fixedQRowDelta q a (2 * H) e 1 =
      -(admissibleInteriorCount q a (2 * H) : ℝ) *
        movingVReciprocalTerm q (2 * H) e := by
  have he0 : e ≠ 0 := by
    intro h
    subst e
    simp [movingVCoeff] at hec
  have he : 0 < e := Nat.pos_of_ne_zero he0
  rw [moving_row_delta_eq_reduced_centered ha hec]
  have hmass := rowConstrainedMass_one_eq_dilate_prefix
    (occupiedReducedFixedQLowWeight q a H) H e (by omega) he
  rw [hmass]
  have hdiv : (H - 1) / e = 0 := Nat.div_eq_of_lt heX
  rw [hdiv]
  simp
  unfold movingVReciprocalTerm
  have heR : (e : ℝ) ≠ 0 := by exact_mod_cast he0
  field_simp [heR]

end PaperB.ExactAccounting

namespace PaperB.ExactAccounting

open PaperB.FixedQ

lemma summable_moving_source_family
    {q a H : ℕ} (ha : q.Coprime a) (hH : 2 ≤ H) :
    Summable (fun e : ℕ =>
      movingVCoeff q (2 * H) e * fixedQRowDelta q a (2 * H) e 1) := by
  let f : ℕ → ℝ := fun e =>
    movingVCoeff q (2 * H) e * fixedQRowDelta q a (2 * H) e 1
  have hs : Summable (fun j : ℕ =>
      f (j + ((H - 1) + 1))) := by
    have ht := (summable_movingVReciprocalTail q (2 * H) (H - 1)).mul_left
      (-(admissibleInteriorCount q a (2 * H) : ℝ))
    apply ht.congr
    intro j
    dsimp [f]
    by_cases hc : movingVCoeff q (2 * H) (j + ((H - 1) + 1)) = 0
    · rw [hc]
      have hcTail : movingVCoeff q (2 * H) (((H - 1) + 1) + j) = 0 := by
        simpa [Nat.add_comm, Nat.add_left_comm, Nat.add_assoc] using hc
      simp [movingVReciprocalTerm, hcTail]
    · have htail := moving_row_delta_tail
        (q := q) (a := a) (H := H) (e := j + ((H - 1) + 1))
        ha hH hc (by omega)
      simpa [Nat.add_comm, Nat.add_left_comm, Nat.add_assoc] using htail.symm
  exact (summable_nat_add_iff (f := f) ((H - 1) + 1)).1 hs

lemma moving_source_prefix_eq_floor_prefix
    {q a H : ℕ} [NeZero (fixedQPeriod q)]
    (hq : 0 < q) (ha : q.Coprime a) (hH : 2 ≤ H) :
    (∑ e ∈ Finset.range ((H - 1) + 1),
      movingVCoeff q (2 * H) e * fixedQRowDelta q a (2 * H) e 1) =
      oneDimensionalDensityCoeff q a H *
        movingVReciprocalPrefix q (2 * H) (H - 1) +
      supportedBoundarySum (fixedQPeriod q)
        (occupiedReducedFixedQLowWeight q a H)
        (movingVCoeff q (2 * H)) (H - 1) -
      supportedSawtoothSum (fixedQPeriod q)
        (occupiedReducedFixedQLowWeight q a H)
        (movingVCoeff q (2 * H))
        (((H - 1 : ℕ) : ℝ)) (H - 1) := by
  have hsplit :
      (∑ e ∈ Finset.range ((H - 1) + 1),
        movingVCoeff q (2 * H) e * fixedQRowDelta q a (2 * H) e 1) =
      ∑ e ∈ Finset.Icc 1 (H - 1),
        movingVCoeff q (2 * H) e * fixedQRowDelta q a (2 * H) e 1 := by
    rw [Finset.sum_range_succ']
    simp [movingVCoeff]
    apply Finset.sum_bij (fun e he => e + 1) ?_ ?_ ?_ ?_
    · intro e he
      rw [Finset.mem_range] at he
      rw [Finset.mem_Icc]
      omega
    · intro e1 h1 e2 h2 h
      omega
    · intro y hy
      rw [Finset.mem_Icc] at hy
      refine ⟨y - 1, ?_, ?_⟩
      · rw [Finset.mem_range]
        omega
      · omega
    · intro e he
      rfl
  rw [hsplit]
  unfold movingVReciprocalPrefix supportedBoundarySum supportedSawtoothSum
  rw [Finset.mul_sum, ← Finset.sum_add_distrib, ← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro e heI
  have he := (Finset.mem_Icc.mp heI).1
  have heX := (Finset.mem_Icc.mp heI).2
  by_cases hc : movingVCoeff q (2 * H) e = 0
  · simp [hc, movingVReciprocalTerm]
  · have hcop := movingVCoeff_coprime_fixedQPeriod_of_ne_zero hc
    rw [dif_pos hcop, dif_pos hcop]
    have hrow := moving_row_delta_floor
      (q := q) (a := a) (H := H) (e := e) hq ha hH hc heX
    simpa [mul_assoc, mul_left_comm, mul_comm] using hrow

lemma moving_source_tail_eq_floor_tail
    {q a H : ℕ} (ha : q.Coprime a) (hH : 2 ≤ H) :
    (∑' j : ℕ,
      movingVCoeff q (2 * H) (j + ((H - 1) + 1)) *
        fixedQRowDelta q a (2 * H) (j + ((H - 1) + 1)) 1) =
      -(admissibleInteriorCount q a (2 * H) : ℝ) *
        movingVReciprocalTail q (2 * H) (H - 1) := by
  unfold movingVReciprocalTail
  rw [← tsum_mul_left]
  apply tsum_congr
  intro j
  by_cases hc : movingVCoeff q (2 * H) (j + ((H - 1) + 1)) = 0
  · rw [hc]
    have hcTail : movingVCoeff q (2 * H) (((H - 1) + 1) + j) = 0 := by
      simpa [Nat.add_comm, Nat.add_left_comm, Nat.add_assoc] using hc
    simp [movingVReciprocalTerm, hcTail]
  · have hrow := moving_row_delta_tail
      (q := q) (a := a) (H := H) (e := j + ((H - 1) + 1))
      ha hH hc (by omega)
    simpa [Nat.add_comm, Nat.add_left_comm, Nat.add_assoc] using hrow

theorem cStar_mul_pureLeftFamily_eq_manuscriptQ1FloorKernel
    {q a H : ℕ} [NeZero (fixedQPeriod q)]
    (hq : 0 < q) (ha : q.Coprime a) (hH : 2 ≤ H) :
    cStarReal q (2 * H) * pureLeftFamily q a (2 * H) =
      manuscriptQ1FloorKernel q a H := by
  rw [pureLeftFamily_eq_movingNat]
  have hs := summable_moving_source_family (q := q) (a := a) (H := H) ha hH
  have hdecomp := hs.sum_add_tsum_nat_add ((H - 1) + 1)
  rw [moving_source_prefix_eq_floor_prefix hq ha hH] at hdecomp
  rw [moving_source_tail_eq_floor_tail ha hH] at hdecomp
  unfold manuscriptQ1FloorKernel
  dsimp
  rw [← hdecomp]
  ring

end PaperB.ExactAccounting

namespace PaperB.ExactAccounting

open PaperB.FixedQ

lemma free_row_delta_eq_reduced_centered
    {q r H e : ℕ}
    (hr : q.Coprime r)
    (hec : etaCoeff q e ≠ 0) :
    PaperB.Closure.manuscriptFreeBoundaryDelta q r (2 * H) e =
      rowConstrainedMass (freeReducedFixedQLowWeight q r) H e 1 -
        (admissibleInteriorCount q r (2 * H) : ℝ) / (e : ℝ) := by
  have he0 : e ≠ 0 := by
    intro h
    subst e
    simp [etaCoeff] at hec
  have he : 0 < e := Nat.pos_of_ne_zero he0
  have heP := etaCoeff_coprime_fixedQPeriod_of_ne_zero hec
  have h2P : 2 ∣ fixedQPeriod q := by
    unfold fixedQPeriod
    exact (show 2 ∣ 6 by norm_num).trans (Nat.dvd_lcm_left 6 q)
  have he2 : e.Coprime 2 := Nat.Coprime.of_dvd_right h2P heP
  have hred := exactRowReduction
    (freeFixedQLowWeight q r)
    (freeFixedQLowWeight q r)
    (freeReducedFixedQLowWeight q r)
    1 H e 1
    (admissibleInteriorCount q r (2 * H) : ℝ)
    (by norm_num) he (by norm_num)
    (by norm_num) he2 (by norm_num)
    (by
      intro z hz
      simp)
    (by
      intro z hz hodd
      exact freeFixedQLowWeight_odd_zero hr hodd)
    (by
      intro x hx
      rfl)
  unfold PaperB.Closure.manuscriptFreeBoundaryDelta
  simp only [one_mul, mul_one, Nat.cast_one] at hred
  unfold rowDiscrepancy rowPeriodicDensityDelta at hred
  norm_num at hred
  have heR : (e : ℝ) ≠ 0 := by exact_mod_cast he0
  field_simp [heR] at hred ⊢
  linarith

lemma free_periodic_mean
    {q r : ℕ} (hq : 0 < q) (hr : q.Coprime r)
    [NeZero (fixedQPeriod q)] :
    periodicWeightMass (fixedQPeriod q)
        (freeReducedFixedQLowWeight q r) /
        (fixedQPeriod q : ℝ) =
      fixedQRowMean q := by
  have hp := periodicWeightMass_eq_rowPrefixMass
    (freeReducedFixedQLowWeight_periodic q r)
  rw [hp, rowPrefixMass_freeReduced_period q r hq hr]
  have hP : (fixedQPeriod q : ℝ) ≠ 0 := by
    exact_mod_cast (NeZero.ne (fixedQPeriod q))
  field_simp [hP]

lemma eta_row_delta_floor
    {q r H e : ℕ} [NeZero (fixedQPeriod q)]
    (hq : 0 < q) (hr : q.Coprime r) (hH : 2 ≤ H)
    (hec : etaCoeff q e ≠ 0)
    (heX : e ≤ H - 1) :
    etaCoeff q e * PaperB.Closure.manuscriptFreeBoundaryDelta q r (2 * H) e =
      oneDimensionalDensityCoeff q r H * etaReciprocalTerm q e +
      etaCoeff q e *
        manuscriptBoundaryTerm (fixedQPeriod q)
          (freeReducedFixedQLowWeight q r)
          (ZMod.unitOfCoprime e
            (etaCoeff_coprime_fixedQPeriod_of_ne_zero hec)) -
      etaCoeff q e *
        manuscriptSawtoothTerm (fixedQPeriod q)
          (freeReducedFixedQLowWeight q r)
          (ZMod.unitOfCoprime e
            (etaCoeff_coprime_fixedQPeriod_of_ne_zero hec))
          (((H - 1 : ℕ) : ℝ) / (e : ℝ)) := by
  have he0 : e ≠ 0 := by
    intro h
    subst e
    simp [etaCoeff] at hec
  have he : 0 < e := Nat.pos_of_ne_zero he0
  rw [free_row_delta_eq_reduced_centered hr hec]
  have hmass := rowConstrainedMass_one_eq_dilate_prefix
    (freeReducedFixedQLowWeight q r) H e (by omega) he
  rw [hmass]
  have hfloor := exactManuscriptPeriodicFloorDecomposition_realDiv
    (w := freeReducedFixedQLowWeight q r)
    (L := fixedQPeriod q) (e := e) (X := H - 1)
    (etaCoeff_coprime_fixedQPeriod_of_ne_zero hec)
    (by omega) (freeReducedFixedQLowWeight_periodic q r)
  rw [hfloor]
  rw [free_periodic_mean hq hr]
  unfold oneDimensionalDensityCoeff
  rw [etaReciprocalTerm_eq_etaCoeff_div]
  have heR : (e : ℝ) ≠ 0 := by exact_mod_cast he0
  field_simp [heR]
  ring

lemma eta_row_delta_tail
    {q r H e : ℕ}
    (hr : q.Coprime r) (hH : 2 ≤ H)
    (hec : etaCoeff q e ≠ 0)
    (heX : H - 1 < e) :
    etaCoeff q e * PaperB.Closure.manuscriptFreeBoundaryDelta q r (2 * H) e =
      -(admissibleInteriorCount q r (2 * H) : ℝ) *
        etaReciprocalTerm q e := by
  have he0 : e ≠ 0 := by
    intro h
    subst e
    simp [etaCoeff] at hec
  have he : 0 < e := Nat.pos_of_ne_zero he0
  rw [free_row_delta_eq_reduced_centered hr hec]
  have hmass := rowConstrainedMass_one_eq_dilate_prefix
    (freeReducedFixedQLowWeight q r) H e (by omega) he
  rw [hmass]
  have hdiv : (H - 1) / e = 0 := Nat.div_eq_of_lt heX
  rw [hdiv]
  simp
  rw [etaReciprocalTerm_eq_etaCoeff_div]
  have heR : (e : ℝ) ≠ 0 := by exact_mod_cast he0
  field_simp [heR]

lemma summable_eta_source_family
    {q r H : ℕ} (hr : q.Coprime r) (hH : 2 ≤ H) :
    Summable (fun e : ℕ =>
      etaCoeff q e * PaperB.Closure.manuscriptFreeBoundaryDelta q r (2 * H) e) := by
  let f : ℕ → ℝ := fun e =>
    etaCoeff q e * PaperB.Closure.manuscriptFreeBoundaryDelta q r (2 * H) e
  have hs : Summable (fun j : ℕ => f (j + ((H - 1) + 1))) := by
    have ht := (summable_etaReciprocalTail q (H - 1)).mul_left
      (-(admissibleInteriorCount q r (2 * H) : ℝ))
    apply ht.congr
    intro j
    dsimp [f]
    by_cases hc : etaCoeff q (j + ((H - 1) + 1)) = 0
    · rw [hc]
      have hcTail : etaCoeff q (((H - 1) + 1) + j) = 0 := by
        simpa [Nat.add_comm, Nat.add_left_comm, Nat.add_assoc] using hc
      simp [etaReciprocalTerm, hcTail]
    · have htail := eta_row_delta_tail
        (q := q) (r := r) (H := H) (e := j + ((H - 1) + 1))
        hr hH hc (by omega)
      simpa [Nat.add_comm, Nat.add_left_comm, Nat.add_assoc] using htail.symm
  exact (summable_nat_add_iff (f := f) ((H - 1) + 1)).1 hs

lemma eta_source_prefix_eq_floor_prefix
    {q r H : ℕ} [NeZero (fixedQPeriod q)]
    (hq : 0 < q) (hr : q.Coprime r) (hH : 2 ≤ H) :
    (∑ e ∈ Finset.range ((H - 1) + 1),
      etaCoeff q e * PaperB.Closure.manuscriptFreeBoundaryDelta q r (2 * H) e) =
      oneDimensionalDensityCoeff q r H * etaReciprocalPrefix q (H - 1) +
      supportedBoundarySum (fixedQPeriod q)
        (freeReducedFixedQLowWeight q r) (etaCoeff q) (H - 1) -
      supportedSawtoothSum (fixedQPeriod q)
        (freeReducedFixedQLowWeight q r) (etaCoeff q)
        (((H - 1 : ℕ) : ℝ)) (H - 1) := by
  have hsplit :
      (∑ e ∈ Finset.range ((H - 1) + 1),
        etaCoeff q e * PaperB.Closure.manuscriptFreeBoundaryDelta q r (2 * H) e) =
      ∑ e ∈ Finset.Icc 1 (H - 1),
        etaCoeff q e * PaperB.Closure.manuscriptFreeBoundaryDelta q r (2 * H) e := by
    rw [Finset.sum_range_succ']
    simp [etaCoeff]
    apply Finset.sum_bij (fun e he => e + 1) ?_ ?_ ?_ ?_
    · intro e he
      rw [Finset.mem_range] at he
      rw [Finset.mem_Icc]
      omega
    · intro e1 h1 e2 h2 h
      omega
    · intro y hy
      rw [Finset.mem_Icc] at hy
      refine ⟨y - 1, ?_, ?_⟩
      · rw [Finset.mem_range]
        omega
      · omega
    · intro e he
      rfl
  rw [hsplit]
  unfold etaReciprocalPrefix supportedBoundarySum supportedSawtoothSum
  rw [Finset.mul_sum, ← Finset.sum_add_distrib, ← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro e heI
  have heX := (Finset.mem_Icc.mp heI).2
  by_cases hc : etaCoeff q e = 0
  · simp [hc, etaReciprocalTerm]
  · have hcop := etaCoeff_coprime_fixedQPeriod_of_ne_zero hc
    rw [dif_pos hcop, dif_pos hcop]
    have hrow := eta_row_delta_floor
      (q := q) (r := r) (H := H) (e := e) hq hr hH hc heX
    simpa [mul_assoc, mul_left_comm, mul_comm] using hrow

lemma eta_source_tail_eq_floor_tail
    {q r H : ℕ} (hr : q.Coprime r) (hH : 2 ≤ H) :
    (∑' j : ℕ,
      etaCoeff q (j + ((H - 1) + 1)) *
        PaperB.Closure.manuscriptFreeBoundaryDelta q r (2 * H)
          (j + ((H - 1) + 1))) =
      -(admissibleInteriorCount q r (2 * H) : ℝ) *
        etaReciprocalTail q (H - 1) := by
  unfold etaReciprocalTail
  rw [← tsum_mul_left]
  apply tsum_congr
  intro j
  by_cases hc : etaCoeff q (j + ((H - 1) + 1)) = 0
  · rw [hc]
    have hcTail : etaCoeff q (((H - 1) + 1) + j) = 0 := by
      simpa [Nat.add_comm, Nat.add_left_comm, Nat.add_assoc] using hc
    simp [etaReciprocalTerm, hcTail]
  · have hrow := eta_row_delta_tail
      (q := q) (r := r) (H := H) (e := j + ((H - 1) + 1))
      hr hH hc (by omega)
    simpa [Nat.add_comm, Nat.add_left_comm, Nat.add_assoc] using hrow

theorem manuscriptS1Kernel_eq_manuscriptS1FloorKernel
    {q r H : ℕ} [NeZero (fixedQPeriod q)]
    (hq : 0 < q) (hr : q.Coprime r) (hH : 2 ≤ H) :
    PaperB.Closure.manuscriptS1Kernel q r (2 * H) =
      manuscriptS1FloorKernel q r H := by
  unfold PaperB.Closure.manuscriptS1Kernel
  have hs := summable_eta_source_family (q := q) (r := r) (H := H) hr hH
  have hdecomp := hs.sum_add_tsum_nat_add ((H - 1) + 1)
  rw [eta_source_prefix_eq_floor_prefix hq hr hH] at hdecomp
  rw [eta_source_tail_eq_floor_tail hr hH] at hdecomp
  unfold manuscriptS1FloorKernel
  dsimp
  rw [← hdecomp]
  ring

theorem source_family_floor_sub_bridge
    {q r H : ℕ} [NeZero (fixedQPeriod q)]
    (hq : 0 < q) (hr : q.Coprime r) (hH : 2 ≤ H) :
    cStarReal q (2 * H) * pureLeftFamily q r (2 * H) -
        PaperB.Closure.manuscriptS1Kernel q r (2 * H) =
      manuscriptQ1FloorKernel q r H -
        manuscriptS1FloorKernel q r H := by
  rw [cStar_mul_pureLeftFamily_eq_manuscriptQ1FloorKernel hq hr hH,
      manuscriptS1Kernel_eq_manuscriptS1FloorKernel hq hr hH]

end PaperB.ExactAccounting
