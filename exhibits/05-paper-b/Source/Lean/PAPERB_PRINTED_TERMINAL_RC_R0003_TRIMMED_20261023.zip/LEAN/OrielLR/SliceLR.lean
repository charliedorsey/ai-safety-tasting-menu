import OrielLR.ConeBlock

/-!
# Oriel L/R — one decoration slice: Left (fixed short `r`) and Right (fixed short `s`)

Each orientation is derived from its own source CRT/row identity
(`oriel_rowDisc_left` with `α = H, β = -1`; `oriel_rowDisc_right` with `α = 0, β = 1`);
no reflection between Left and Right is used.
-/

open Finset
open OrielUpper.Mirror

namespace OrielUpper

variable {P : ℕ} [NeZero P]

/-- Summing the per-short-variable bound against `b(m)`. -/
lemma cone_sum {F U : ℕ} {T : ℕ → ℝ} {Φ c E1 Cτ : ℝ} (hΦ : 0 ≤ Φ) (hc : 0 ≤ c)
    (hU : 1 ≤ U) (hE1 : Asig F U 1 ≤ E1)
    (hτ : ∀ N, ∑ r ∈ Icc 1 N, bW F r * ((r.divisors.card : ℝ) / r) ≤ Cτ)
    (hT : ∀ m ∈ Ioc 1 U, |T m| ≤ bW F m * (Φ + c / m)) :
    |∑ m ∈ Ioc 1 U, T m| ≤ Φ * (E1 * (1 + Real.log U)) + c * Cτ := by
  refine (abs_sum_le_sum_abs _ _).trans ((sum_le_sum hT).trans ?_)
  have e : ∑ m ∈ Ioc 1 U, bW F m * (Φ + c / m) =
      Φ * ∑ m ∈ Ioc 1 U, bW F m + c * ∑ m ∈ Ioc 1 U, bW F m / m := by
    rw [mul_sum, mul_sum, ← sum_add_distrib]
    apply sum_congr rfl; intro m _; ring
  rw [e]
  apply add_le_add
  · exact mul_le_mul_of_nonneg_left (sum_bW_Ioc_one_le hU hE1) hΦ
  · exact mul_le_mul_of_nonneg_left (sum_bW_div_le hτ) hc

/-- The common hypotheses of a slice. -/
structure SliceHyp (P : ℕ) [NeZero P] (F H : ℕ) (w : ℕ → ℝ) (Λ : ZMod P → ℝ) (B : ℝ)
    (Z : ℕ → ℕ) (h Y D N0 Lb : ℕ) (E1 E34 Cτ : ℝ) : Prop where
  row : RowHyp P F H w Λ B
  Hh : H ≤ h
  h1 : 1 ≤ h
  Y3 : Y ^ 3 ≤ Z h
  YN : (N0 + 1) * P * D ≤ Y
  YD : 2 * D * P ^ 2 + 1 ≤ Y
  D1 : 1 ≤ D
  N01 : 1 ≤ N0
  Lb : h ≤ 2 ^ Lb
  E1 : ∀ m N, 1 ≤ m → m ≤ h ^ 2 → Asig (F * m) N 1 ≤ E1
  E34 : ∀ m N, 1 ≤ m → m ≤ h ^ 2 → Asig (F * m) N (3 / 4) ≤ E34
  τ : ∀ N, ∑ r ∈ Icc 1 N, bW F r * ((r.divisors.card : ℝ) / r) ≤ Cτ

/-- Slice envelope. -/
noncomputable def sliceLR (P : ℕ) (B E1 E34 Ck cK Cτ : ℝ) (D N0 Lb h : ℕ) : ℝ :=
  phiLR P B E1 E34 Ck cK D N0 Lb h * (E1 * (1 + Real.log ((h ^ 2 : ℕ) : ℝ))) +
    (2 * P + 1) * B * Cτ * Cτ

section
open scoped Classical

lemma sliceLR_nonneg {F H : ℕ} {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {B : ℝ} {Z : ℕ → ℕ}
    {h Y D N0 Lb : ℕ} {E1 E34 Cτ Ck cK : ℝ}
    (hS : SliceHyp P F H w Λ B Z h Y D N0 Lb E1 E34 Cτ) (hCk : 0 ≤ Ck) :
    0 ≤ sliceLR P B E1 E34 Ck cK Cτ D N0 Lb h := by
  have hB0 := hS.row.B_nonneg
  have hE1 : 0 ≤ E1 := le_trans (Asig_nonneg _ _ _) (hS.E1 1 0 le_rfl (Nat.one_le_pow _ _ hS.h1))
  have hE34 : 0 ≤ E34 := le_trans (Asig_nonneg _ _ _) (hS.E34 1 0 le_rfl (Nat.one_le_pow _ _ hS.h1))
  have hτ0 : 0 ≤ Cτ := le_trans (by simp) (hS.τ 0)
  have := phiLR_nonneg (P := P) (D := D) (N0 := N0) (Lb := Lb) (cK := cK) hB0 hE1 hE34 hCk hS.h1
  have : 0 ≤ Real.log ((h ^ 2 : ℕ) : ℝ) :=
    Real.log_nonneg (by exact_mod_cast Nat.one_le_pow _ _ hS.h1)
  unfold sliceLR; positivity

theorem left_slice {F H : ℕ} {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {B : ℝ} {Z : ℕ → ℕ}
    {h Y D N0 Lb : ℕ} {E1 E34 Cτ : ℝ}
    (hS : SliceHyp P F H w Λ B Z h Y D N0 Lb E1 E34 Cτ)
    {cK Ck : ℝ} (hcK : 0 < cK) (hCk : 0 ≤ Ck) (hK : KarBound cK Ck) :
    |regWin F H w Z virelleR0037Left h (H ^ 2 / 4)| ≤
      sliceLR P B E1 E34 Ck cK Cτ D N0 Lb h := by
  have hR := hS.row
  have hB0 := hR.B_nonneg
  set U := H ^ 2 / 4
  have hUh : U ≤ h ^ 2 := le_trans (Nat.div_le_self _ _) (Nat.pow_le_pow_left hS.Hh 2)
  rcases Nat.eq_zero_or_pos U with hU0 | hU1
  · unfold regWin
    rw [Finset.Icc_eq_empty (by omega), sum_empty, abs_zero]
    exact sliceLR_nonneg hS hCk
  -- the r-structure
  have hinner : ∀ r ∈ Icc 1 U, ∑ s ∈ Icc 1 U,
      (if regC Z virelleR0037Left h H U r s then pairTerm F H w r s else 0) =
      if 1 < r then ∑ s ∈ Ioc (max (Z h / r) (r ^ 2)) (Wc H h / r), pairTerm F H w r s else 0 := by
    intro r hr
    by_cases hr1 : 1 < r
    · rw [if_pos hr1]
      have hr0 : 0 < r := by omega
      apply sum_ite_iff
      intro s
      simp only [mem_Icc, mem_Ioc, regC, virelleR0037Left, max_lt_iff]
      rw [lowProd_iff, lt_mul_iff_div_lt hr0]
      have hWc : r * s ≤ Wc H h ↔ r * s ≤ U ∧ r * s ≤ ⌊(H : ℝ) / vkM h⌋₊ := by
        unfold Wc; exact le_min_iff
      rw [← mul_le_iff_le_div hr0, hWc]
      have hWU : Wc H h ≤ U := min_le_left _ _
      have hr2 : 4 ≤ r ^ 2 := by nlinarith
      constructor
      · rintro ⟨_, _, _, h1, h2, h3, h4⟩; exact ⟨⟨h1, h4⟩, h2, h3⟩
      · rintro ⟨⟨h1, h4⟩, h2, h3⟩
        refine ⟨⟨by omega, ?_⟩, hr1, by omega, h1, h2, h3, h4⟩
        have : s ≤ r * s := Nat.le_mul_of_pos_left s hr0
        omega
    · rw [if_neg hr1]
      apply sum_eq_zero; intro s _
      rw [if_neg]; rintro ⟨h1, _⟩; exact hr1 h1
  unfold regWin
  rw [sum_congr rfl hinner]
  rw [sum_ite_iff (s := Icc 1 U) (t := Ioc 1 U) (p := fun r => 1 < r) _ (by
    intro r; simp only [mem_Icc, mem_Ioc]; omega)]
  have hE1F : Asig F U 1 ≤ E1 := by
    have := hS.E1 1 U le_rfl (Nat.one_le_pow _ _ hS.h1); rwa [mul_one] at this
  have hE34F : 0 ≤ E34 := le_trans (Asig_nonneg _ _ _) (hS.E34 1 0 le_rfl (Nat.one_le_pow _ _ hS.h1))
  have hΦ0 := phiLR_nonneg (P := P) (D := D) (N0 := N0) (Lb := Lb) (cK := cK) hB0
    (le_trans (Asig_nonneg _ _ _) hE1F) hE34F hCk hS.h1 (E1 := E1) (E34 := E34) (Ck := Ck)
  have hτ0 : 0 ≤ Cτ := le_trans (by simp) (hS.τ 0)
  have hcone : ∀ r ∈ Ioc 1 U,
      |∑ s ∈ Ioc (max (Z h / r) (r ^ 2)) (Wc H h / r), pairTerm F H w r s| ≤
        bW F r * (phiLR P B E1 E34 Ck cK D N0 Lb h + (2 * P + 1) * B * Cτ / r) := by
    intro r hr
    have hr1 : 1 < r := (mem_Ioc.mp hr).1
    have hrU : r ≤ U := (mem_Ioc.mp hr).2
    have hr0 : 0 < r := by omega
    have e1 : ∑ s ∈ Ioc (max (Z h / r) (r ^ 2)) (Wc H h / r), pairTerm F H w r s =
        bW F r * ∑ s ∈ Ioc (max (Z h / r) (r ^ 2)) (Wc H h / r), bW (F * r) s *
          (psiR r H Λ (H : ZMod P) (-1) (s : ZMod P) (s : ZMod r) (((H - 1 : ℕ) : ℝ) / s) +
            cZero H w Λ / ((r : ℝ) * s)) := by
      rw [mul_sum]; apply sum_congr rfl; intro s hs
      have hs0 : 0 < s := by
        have := (mem_Ioc.mp hs).1; have := le_max_right (Z h / r) (r ^ 2)
        have : 0 < r ^ 2 := by positivity
        omega
      unfold pairTerm
      rw [oriel_rowDisc_left hR.hw hr0 hs0]
      unfold cZero; ring
    rw [e1, abs_mul, abs_of_nonneg (bW_nonneg _ _)]
    by_cases hW : bW F r = 0
    · rw [hW]; simp
    apply mul_le_mul_of_nonneg_left _ (bW_nonneg _ _)
    exact cone_block hR hr1 hW isUnit_one.neg hcK hCk hK hS.Hh hS.Y3 hS.YN hS.YD hS.D1 hS.N01
      hS.Lb hS.h1 (fun N => hS.E1 r N hr0 (hrU.trans hUh))
      (fun N => hS.E34 r N hr0 (hrU.trans hUh)) hS.τ
  refine (cone_sum (c := (2 * (P : ℝ) + 1) * B * Cτ) hΦ0 (by positivity) hU1 hE1F hS.τ
    hcone).trans ?_
  · unfold sliceLR
    have hlog : Real.log U ≤ Real.log ((h ^ 2 : ℕ) : ℝ) :=
      Real.log_le_log (by exact_mod_cast hU1) (by exact_mod_cast hUh)
    have hΦ := phiLR_nonneg (P := P) (D := D) (N0 := N0) (Lb := Lb) (cK := cK) hB0
      (le_trans (Asig_nonneg _ _ _) hE1F)
      (le_trans (Asig_nonneg _ _ _) (hS.E34 1 0 le_rfl (Nat.one_le_pow _ _ hS.h1))) hCk hS.h1 (E1 := E1)
      (E34 := E34) (Ck := Ck)
    have hE1n : 0 ≤ E1 := le_trans (Asig_nonneg _ _ _) hE1F
    have : phiLR P B E1 E34 Ck cK D N0 Lb h * (E1 * (1 + Real.log U)) ≤
        phiLR P B E1 E34 Ck cK D N0 Lb h * (E1 * (1 + Real.log ((h ^ 2 : ℕ) : ℝ))) := by
      apply mul_le_mul_of_nonneg_left _ hΦ
      apply mul_le_mul_of_nonneg_left _ hE1n
      linarith
    have e : (2 * (P : ℝ) + 1) * B * Cτ * Cτ = (2 * P + 1) * B * Cτ * Cτ := rfl
    linarith


theorem right_slice {F H : ℕ} {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {B : ℝ} {Z : ℕ → ℕ}
    {h Y D N0 Lb : ℕ} {E1 E34 Cτ : ℝ}
    (hS : SliceHyp P F H w Λ B Z h Y D N0 Lb E1 E34 Cτ)
    {cK Ck : ℝ} (hcK : 0 < cK) (hCk : 0 ≤ Ck) (hK : KarBound cK Ck) :
    |regWin F H w Z virelleR0037Right h (H ^ 2 / 4)| ≤
      sliceLR P B E1 E34 Ck cK Cτ D N0 Lb h := by
  have hR := hS.row
  have hB0 := hR.B_nonneg
  set U := H ^ 2 / 4
  have hUh : U ≤ h ^ 2 := le_trans (Nat.div_le_self _ _) (Nat.pow_le_pow_left hS.Hh 2)
  rcases Nat.eq_zero_or_pos U with hU0 | hU1
  · unfold regWin
    rw [Finset.Icc_eq_empty (by omega), sum_empty, abs_zero]
    exact sliceLR_nonneg hS hCk
  have hinner : ∀ s ∈ Icc 1 U, ∑ r ∈ Icc 1 U,
      (if regC Z virelleR0037Right h H U r s then pairTerm F H w r s else 0) =
      if 1 < s then ∑ r ∈ Ioc (max (Z h / s) (s ^ 2)) (Wc H h / s), pairTerm F H w r s else 0 := by
    intro s hs
    by_cases hs1 : 1 < s
    · rw [if_pos hs1]
      have hs0 : 0 < s := by omega
      apply sum_ite_iff
      intro r
      simp only [mem_Icc, mem_Ioc, regC, virelleR0037Right, max_lt_iff]
      rw [lowProd_iff, mul_comm r s, lt_mul_iff_div_lt hs0]
      have hWc : s * r ≤ Wc H h ↔ s * r ≤ U ∧ s * r ≤ ⌊(H : ℝ) / vkM h⌋₊ := by
        unfold Wc; exact le_min_iff
      rw [← mul_le_iff_le_div hs0, hWc]
      have hs2 : 4 ≤ s ^ 2 := by nlinarith
      constructor
      · rintro ⟨_, _, _, h1, h2, h3, h4⟩; exact ⟨⟨h1, h4⟩, h2, h3⟩
      · rintro ⟨⟨h1, h4⟩, h2, h3⟩
        refine ⟨⟨by omega, ?_⟩, by omega, hs1, h1, h2, h3, h4⟩
        have : r ≤ s * r := Nat.le_mul_of_pos_left r hs0
        omega
    · rw [if_neg hs1]
      apply sum_eq_zero; intro r _
      rw [if_neg]; rintro ⟨_, h1, _⟩; exact hs1 h1
  unfold regWin
  rw [sum_comm, sum_congr rfl hinner]
  rw [sum_ite_iff (s := Icc 1 U) (t := Ioc 1 U) (p := fun s => 1 < s) _ (by
    intro r; simp only [mem_Icc, mem_Ioc]; omega)]
  have hE1F : Asig F U 1 ≤ E1 := by
    have := hS.E1 1 U le_rfl (Nat.one_le_pow _ _ hS.h1); rwa [mul_one] at this
  have hE34F : 0 ≤ E34 := le_trans (Asig_nonneg _ _ _) (hS.E34 1 0 le_rfl (Nat.one_le_pow _ _ hS.h1))
  have hΦ0 := phiLR_nonneg (P := P) (D := D) (N0 := N0) (Lb := Lb) (cK := cK) hB0
    (le_trans (Asig_nonneg _ _ _) hE1F) hE34F hCk hS.h1 (E1 := E1) (E34 := E34) (Ck := Ck)
  have hτ0 : 0 ≤ Cτ := le_trans (by simp) (hS.τ 0)
  have hcone : ∀ s ∈ Ioc 1 U,
      |∑ r ∈ Ioc (max (Z h / s) (s ^ 2)) (Wc H h / s), pairTerm F H w r s| ≤
        bW F s * (phiLR P B E1 E34 Ck cK D N0 Lb h + (2 * P + 1) * B * Cτ / s) := by
    intro s hs
    have hs1 : 1 < s := (mem_Ioc.mp hs).1
    have hsU : s ≤ U := (mem_Ioc.mp hs).2
    have hs0 : 0 < s := by omega
    have e1 : ∑ r ∈ Ioc (max (Z h / s) (s ^ 2)) (Wc H h / s), pairTerm F H w r s =
        bW F s * ∑ r ∈ Ioc (max (Z h / s) (s ^ 2)) (Wc H h / s), bW (F * s) r *
          (psiR s H Λ 0 1 (r : ZMod P) (r : ZMod s) (((H - 1 : ℕ) : ℝ) / r) +
            cZero H w Λ / ((s : ℝ) * r)) := by
      rw [mul_sum]; apply sum_congr rfl; intro r hr
      have hr0 : 0 < r := by
        have := (mem_Ioc.mp hr).1; have := le_max_right (Z h / s) (s ^ 2)
        have : 0 < s ^ 2 := by positivity
        omega
      unfold pairTerm
      rw [bW_pair_symm, oriel_rowDisc_right hR.hw hr0 hs0]
      unfold cZero; ring
    rw [e1, abs_mul, abs_of_nonneg (bW_nonneg _ _)]
    by_cases hW : bW F s = 0
    · rw [hW]; simp
    apply mul_le_mul_of_nonneg_left _ (bW_nonneg _ _)
    exact cone_block hR hs1 hW isUnit_one hcK hCk hK hS.Hh hS.Y3 hS.YN hS.YD hS.D1 hS.N01
      hS.Lb hS.h1 (fun N => hS.E1 s N hs0 (hsU.trans hUh))
      (fun N => hS.E34 s N hs0 (hsU.trans hUh)) hS.τ
  refine (cone_sum (c := (2 * (P : ℝ) + 1) * B * Cτ) hΦ0 (by positivity) hU1 hE1F hS.τ
    hcone).trans ?_
  unfold sliceLR
  have hlog : Real.log U ≤ Real.log ((h ^ 2 : ℕ) : ℝ) :=
    Real.log_le_log (by exact_mod_cast hU1) (by exact_mod_cast hUh)
  have hE1n : 0 ≤ E1 := le_trans (Asig_nonneg _ _ _) hE1F
  have : phiLR P B E1 E34 Ck cK D N0 Lb h * (E1 * (1 + Real.log U)) ≤
      phiLR P B E1 E34 Ck cK D N0 Lb h * (E1 * (1 + Real.log ((h ^ 2 : ℕ) : ℝ))) := by
    apply mul_le_mul_of_nonneg_left _ hΦ0
    apply mul_le_mul_of_nonneg_left _ hE1n
    linarith
  linarith

end

end OrielUpper
