import PaperB.Analytic.PetermannOmegaNearJumpMass
import PaperB.Analytic.PetermannOmegaRemainderSublog
import PaperB.Analytic.PetermannOmegaLowMovingCutoff
import PaperB.Analytic.PetermannOmegaHighCoprimeDFT
import PaperB.Analytic.PetermannFixedBetaMiddleWindow
import PaperB.Analytic.PetermannOmegaReciprocalConvolution
import PaperB.Analytic.PetermannOmegaSmoothedDFT
import PaperB.Analytic.PetermannOmegaKernelSplit
import PaperB.Analytic.PetermannSmoothExpansion
import PaperB.FixedQ.HarmonicLogTail
import Mathlib.Analysis.PSeries

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

lemma sawSmoothPartial_norm_le_pair_uniform
    {S : ℝ} (hS : 1 < S) (H : ℕ) (y : ℝ) :
    ‖sawSmoothPartial S H (y : AddCircle (1 : ℝ))‖ ≤ 12 / Real.pi := by
  rw [sawSmoothPartial_eq_pair_sum hS]
  simpa using
    (omega_low_transition_moving_fourier_band_uniform
      hS y 0 H (Nat.zero_le H))

lemma omega_smoothing_point_norm_le_near_uniform
    {S : ℝ} (hS : 1 < S)
    (q : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (T : ℝ) (r : ℤ) (H e : ℕ) :
    ‖(chi e) * (omegaCoeff q e : ℂ) *
      ((petermannSawtooth
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
        sawSmoothPartial S H
          ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
            AddCircle (1 : ℝ)))‖
      ≤ omegaCoeff q e * (1 / 2 + 12 / Real.pi) := by
  have hchi := norm_dirichletCharacter_nat_le_one (q := q) (e := e) chi
  have homega := omegaCoeff_nonneg q e
  have hsaw := abs_petermannSawtooth_le_half
    (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
      (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))
  have hsmooth := sawSmoothPartial_norm_le_pair_uniform hS H
    (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
      (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))
  rw [norm_mul, norm_mul, Complex.norm_real,
    Real.norm_eq_abs, abs_of_nonneg homega]
  have hdiff :
      ‖((petermannSawtooth
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
        sawSmoothPartial S H
          ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
            AddCircle (1 : ℝ)))‖
        ≤ 1 / 2 + 12 / Real.pi := by
    calc
      _ ≤ ‖(petermannSawtooth
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ)‖ +
          ‖sawSmoothPartial S H
            ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
              (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
              AddCircle (1 : ℝ))‖ := norm_sub_le _ _
      _ ≤ 1 / 2 + 12 / Real.pi := by
        rw [Complex.norm_real, Real.norm_eq_abs]
        exact _root_.add_le_add hsaw hsmooth
  have hnon : 0 ≤ 1 / 2 + 12 / Real.pi := by positivity
  calc
    ‖chi (e : ZMod (Nat.lcm 6 q))‖ * omegaCoeff q e *
        ‖((petermannSawtooth
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
          sawSmoothPartial S H
            ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
              (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
              AddCircle (1 : ℝ)))‖
      ≤ 1 * omegaCoeff q e * (1 / 2 + 12 / Real.pi) := by
        gcongr
    _ = omegaCoeff q e * (1 / 2 + 12 / Real.pi) := by ring

theorem petermannOmegaSmoothingRemainder_le_away_add_near_uniform
    {S : ℝ} (hS : 1 < S) {H : ℕ} (hH : 1 ≤ H)
    (q X : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (T : ℝ) :
    ‖petermannOmegaSmoothingRemainder q chi r T X H S‖
      ≤
    (S / (Real.pi ^ 2 * H)) * omegaPartialSum q X +
      (1 / 2 + 12 / Real.pi) *
        petermannOmegaNearJumpMass q T r X S := by
  classical
  let E := Finset.Icc 1 X
  let away : ℕ → Prop := fun e => petermannOmegaAwayFromJump q T r S e
  let f : ℕ → ℂ := fun e =>
    (chi e) * (omegaCoeff q e : ℂ) *
      ((petermannSawtooth
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
        sawSmoothPartial S H
          ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
            AddCircle (1 : ℝ)))
  unfold petermannOmegaSmoothingRemainder
  change ‖∑ e ∈ E, f e‖ ≤ _
  rw [← Finset.sum_filter_add_sum_filter_not E away f]
  calc
    ‖(∑ e ∈ E.filter away, f e) +
        (∑ e ∈ E.filter (fun e => ¬ away e), f e)‖
      ≤ ‖∑ e ∈ E.filter away, f e‖ +
          ‖∑ e ∈ E.filter (fun e => ¬ away e), f e‖ := norm_add_le _ _
    _ ≤
      (S / (Real.pi ^ 2 * H)) *
          (∑ e ∈ E.filter away, omegaCoeff q e) +
        (1 / 2 + 12 / Real.pi) *
          (∑ e ∈ E.filter (fun e => ¬ away e), omegaCoeff q e) := by
      apply _root_.add_le_add
      · calc
          ‖∑ e ∈ E.filter away, f e‖
            ≤ ∑ e ∈ E.filter away, ‖f e‖ := norm_sum_le _ _
          _ ≤ ∑ e ∈ E.filter away,
              omegaCoeff q e * (S / (Real.pi ^ 2 * H)) := by
            apply Finset.sum_le_sum
            intro e he
            have heAway : away e := (Finset.mem_filter.mp he).2
            have herr := petermannSawtooth_partial_error_le hS hH
              heAway.1 heAway.2
            dsimp [f]
            rw [norm_mul, norm_mul, Complex.norm_real,
              Real.norm_eq_abs, abs_of_nonneg (omegaCoeff_nonneg q e)]
            have hchi := norm_dirichletCharacter_nat_le_one (q := q) (e := e) chi
            have homega : 0 ≤ omegaCoeff q e := omegaCoeff_nonneg q e
            have hR : 0 ≤ S / (Real.pi ^ 2 * H) := by positivity
            calc
              ‖chi (e : ZMod (Nat.lcm 6 q))‖ * omegaCoeff q e *
                  ‖((petermannSawtooth
                    (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
                      (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
                    sawSmoothPartial S H
                      ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
                        (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
                        AddCircle (1 : ℝ)))‖
                ≤ 1 * omegaCoeff q e * (S / (Real.pi ^ 2 * H)) := by
                  gcongr
              _ = omegaCoeff q e * (S / (Real.pi ^ 2 * H)) := by ring
          _ = (S / (Real.pi ^ 2 * H)) *
              (∑ e ∈ E.filter away, omegaCoeff q e) := by
            rw [Finset.mul_sum]
            apply Finset.sum_congr rfl
            intro e he
            ring
      · calc
          ‖∑ e ∈ E.filter (fun e => ¬ away e), f e‖
            ≤ ∑ e ∈ E.filter (fun e => ¬ away e), ‖f e‖ := norm_sum_le _ _
          _ ≤ ∑ e ∈ E.filter (fun e => ¬ away e),
              omegaCoeff q e * (1 / 2 + 12 / Real.pi) := by
            apply Finset.sum_le_sum
            intro e he
            exact omega_smoothing_point_norm_le_near_uniform
              hS q chi T r H e
          _ = (1 / 2 + 12 / Real.pi) *
              (∑ e ∈ E.filter (fun e => ¬ away e), omegaCoeff q e) := by
            rw [Finset.mul_sum]
            apply Finset.sum_congr rfl
            intro e he
            ring
    _ ≤
      (S / (Real.pi ^ 2 * H)) * omegaPartialSum q X +
        (1 / 2 + 12 / Real.pi) *
          petermannOmegaNearJumpMass q T r X S := by
      have hAwaySum :
          (∑ e ∈ E.filter away, omegaCoeff q e) ≤ omegaPartialSum q X := by
        unfold omegaPartialSum E
        exact Finset.sum_le_sum_of_subset_of_nonneg
          (Finset.filter_subset _ _)
          (fun e he hnot => omegaCoeff_nonneg q e)
      have hfac : 0 ≤ S / (Real.pi ^ 2 * H) := by positivity
      have hnearEq :
          (∑ e ∈ E.filter (fun e => ¬ away e), omegaCoeff q e) =
            petermannOmegaNearJumpMass q T r X S := by
        rfl
      rw [hnearEq]
      gcongr

#print axioms sawSmoothPartial_norm_le_pair_uniform
#print axioms omega_smoothing_point_norm_le_near_uniform
#print axioms petermannOmegaSmoothingRemainder_le_away_add_near_uniform

end PaperB.Analytic
