import GoldC.SignedSupplier

/-!
# `GoldC.C2Fold` — the digit boundary telescopes; the debt folds onto one CRT residue

All results are exact identities, with no analytic input.

* **Potential** (`pot_step`). Let `g` be `M`-periodic, and let `n` be coprime to `M` with
  `Σ_{t<M} g(t n) = 0`. Then `pot g M n y := Σ_{t < (y · n⁻¹ mod M)} g(t n)` satisfies
  `pot(y + n) - pot(y) = g(y)`.
* **Telescoping** (`digitAP_eq_pot`). The constrained digit sum of a source row is
  `pot(H + n - c(s,r)) - pot(c(r,s))`, where `n = rs`, `c(r,s) = crtResidue H r s`, and
  `H + n - c(s,r)` is the first progression point `≥ H`.
* **Orientation fold** (`centralSum_swap`). The involution `B ↦ e \ B` of the source index gives
  `centralSum F = centralSum (F with r, s swapped)` for **every** row functional `F`.
  This is an exact relabelling of the summation index, not an antisymmetry claim.
-/

open scoped BigOperators Classical
open Finset

namespace GoldC

/-! ## Periodic sequences -/

lemma periodic_mod (g : ℕ → ℝ) (M : ℕ) (hper : ∀ y, g (y + M) = g y) (y : ℕ) :
    g y = g (y % M) := by
  have key : ∀ k x, g (x + M * k) = g x := by
    intro k; induction k with
    | zero => intro x; simp
    | succ k ih => intro x; rw [Nat.mul_succ, ← add_assoc, hper, ih]
  conv_lhs => rw [← Nat.mod_add_div y M]
  exact key _ _

lemma periodic_modEq (g : ℕ → ℝ) (M : ℕ) (hper : ∀ y, g (y + M) = g y) {x y : ℕ}
    (h : x ≡ y [MOD M]) : g x = g y := by
  rw [periodic_mod g M hper x, periodic_mod g M hper y, h]

/-- The potential of `g` along steps of size `n`, modulo `M`. -/
noncomputable def pot (g : ℕ → ℝ) (M n y : ℕ) : ℝ :=
  ∑ t ∈ Finset.range ((y * invMod n M) % M), g (t * n)

lemma pot_congr (g : ℕ → ℝ) (M n : ℕ) {x y : ℕ} (h : x ≡ y [MOD M]) :
    pot g M n x = pot g M n y := by
  unfold pot
  have : (x * invMod n M) % M = (y * invMod n M) % M := Nat.ModEq.mul_right _ h
  rw [this]

/-- **The potential step**: `pot(y + n) - pot(y) = g(y)`. -/
theorem pot_step (g : ℕ → ℝ) (M n : ℕ) (hM : 2 ≤ M) (hn : n.Coprime M)
    (hper : ∀ y, g (y + M) = g y) (hcyc : ∑ t ∈ Finset.range M, g (t * n) = 0) (y : ℕ) :
    pot g M n (y + n) - pot g M n y = g y := by
  unfold pot
  set u := invMod n M with hu
  have hnu : n * u ≡ 1 [MOD M] := mul_invMod_modEq hM hn
  set m := (y * u) % M with hm
  have hmlt : m < M := Nat.mod_lt _ (by omega)
  -- `m · n ≡ y`, so `g(m n) = g(y)`
  have hmn : m * n ≡ y [MOD M] := by
    calc m * n ≡ (y * u) * n [MOD M] := Nat.ModEq.mul_right _ (Nat.mod_modEq _ _)
      _ = y * (n * u) := by ring
      _ ≡ y * 1 [MOD M] := Nat.ModEq.mul_left _ hnu
      _ = y := mul_one y
  have hg : g (m * n) = g y := periodic_modEq g M hper hmn
  -- `(y + n) u ≡ m + 1`
  have hstep : ((y + n) * u) % M = (m + 1) % M := by
    have : (y + n) * u ≡ m + 1 [MOD M] := by
      calc (y + n) * u = y * u + n * u := by ring
        _ ≡ m + 1 [MOD M] := Nat.ModEq.add (Nat.mod_modEq _ _).symm hnu
    exact this
  rw [hstep]
  rcases Nat.lt_or_ge (m + 1) M with hlt | hge
  · rw [Nat.mod_eq_of_lt hlt, Finset.sum_range_succ, hg]; ring
  · have hm1 : m + 1 = M := by omega
    rw [hm1, Nat.mod_self, Finset.range_zero, Finset.sum_empty]
    rw [← hm1, Finset.sum_range_succ, hg] at hcyc
    linarith

/-! ## Telescoping over one residue class -/

lemma window_unique {n Y x z c : ℕ} (hx : Y ≤ x ∧ x < Y + n) (hz : Y ≤ z ∧ z < Y + n)
    (hxc : x % n = c) (hzc : z % n = c) : x = z := by
  have ex := Nat.mod_add_div x n
  have ez := Nat.mod_add_div z n
  rw [hxc] at ex; rw [hzc] at ez
  have hq : x / n = z / n := by
    by_contra hne
    rcases Nat.lt_or_gt_of_ne hne with hlt | hlt
    · have : n * (x / n) + n ≤ n * (z / n) := by
        rw [← Nat.mul_succ]; exact Nat.mul_le_mul_left _ hlt
      omega
    · have : n * (z / n) + n ≤ n * (x / n) := by
        rw [← Nat.mul_succ]; exact Nat.mul_le_mul_left _ hlt
      omega
  rw [← ex, ← ez, hq]

lemma window_sum (P : ℕ → ℝ) {n c Y x : ℕ} (hx : Y ≤ x ∧ x < Y + n) (hxc : x % n = c) :
    ∑ y ∈ Finset.Ico Y (Y + n), (if y % n = c then P y else 0) = P x := by
  rw [Finset.sum_eq_single x]
  · simp [hxc]
  · intro y hy hyx
    rw [Finset.mem_Ico] at hy
    have hyc : ¬ y % n = c := fun hyc => hyx (window_unique hy hx hyc hxc)
    simp [hyc]
  · intro hx'
    exact absurd (Finset.mem_Ico.2 hx) hx'

/-- **Telescoping**: summing `P(y+n) - P(y)` over the class `y ≡ c (mod n)`, `y < Y`, leaves
the first class point `x ≥ Y` minus the first class point `c`. -/
theorem class_telescope (P : ℕ → ℝ) {n c Y x : ℕ} (hc : c < n)
    (hx : Y ≤ x ∧ x < Y + n) (hxc : x % n = c) :
    ∑ y ∈ Finset.range Y, (if y % n = c then P (y + n) - P y else 0) = P x - P c := by
  set F : ℕ → ℝ := fun y => if y % n = c then P y else 0 with hF
  have hsplit : ∀ y, (if y % n = c then P (y + n) - P y else 0) = F (y + n) - F y := by
    intro y
    simp only [hF, Nat.add_mod_right]
    split_ifs <;> ring
  simp only [hsplit]
  rw [Finset.sum_sub_distrib]
  have hshift : ∑ y ∈ Finset.range Y, F (y + n) = ∑ y ∈ Finset.Ico n (n + Y), F y := by
    rw [Finset.sum_Ico_eq_sum_range]
    simp only [show n + Y - n = Y by omega]
    exact Finset.sum_congr rfl fun y _ => by rw [add_comm]
  have h1 := Finset.sum_range_add_sum_Ico F (show n ≤ n + Y by omega)
  have h2 := Finset.sum_range_add_sum_Ico F (show Y ≤ n + Y by omega)
  have hw1 : ∑ y ∈ Finset.Ico Y (n + Y), F y = P x := by
    rw [add_comm n Y]; exact window_sum P hx hxc
  have hw0 : ∑ y ∈ Finset.range n, F y = P c := by
    rw [Finset.range_eq_Ico, show n = 0 + n by ring]
    exact window_sum P ⟨Nat.zero_le _, by omega⟩ (Nat.mod_eq_of_lt hc)
  rw [hshift]
  linarith

/-! ## A complete cycle along a unit step is a permutation -/

lemma sum_range_mul_mod_perm (f : ℕ → ℝ) (M n : ℕ) (hM : 2 ≤ M) (hn : n.Coprime M) :
    ∑ t ∈ Finset.range M, f ((t * n) % M) = ∑ t ∈ Finset.range M, f t := by
  have hnu : n * invMod n M ≡ 1 [MOD M] := mul_invMod_modEq hM hn
  refine Finset.sum_nbij' (fun t => (t * n) % M) (fun u => (u * invMod n M) % M) ?_ ?_ ?_ ?_ ?_
  · intro t _; simp only [Finset.mem_range]; exact Nat.mod_lt _ (by omega)
  · intro t _; simp only [Finset.mem_range]; exact Nat.mod_lt _ (by omega)
  · intro t ht
    simp only [Finset.mem_range] at ht
    have : ((t * n) % M) * invMod n M ≡ t [MOD M] :=
      calc ((t * n) % M) * invMod n M ≡ (t * n) * invMod n M [MOD M] :=
            Nat.ModEq.mul_right _ (Nat.mod_modEq _ _)
        _ = t * (n * invMod n M) := by ring
        _ ≡ t * 1 [MOD M] := Nat.ModEq.mul_left _ hnu
        _ = t := mul_one t
    show (((t * n) % M) * invMod n M) % M = t
    rw [this]; exact Nat.mod_eq_of_lt ht
  · intro u hu
    simp only [Finset.mem_range] at hu
    have : ((u * invMod n M) % M) * n ≡ u [MOD M] :=
      calc ((u * invMod n M) % M) * n ≡ (u * invMod n M) * n [MOD M] :=
            Nat.ModEq.mul_right _ (Nat.mod_modEq _ _)
        _ = u * (n * invMod n M) := by ring
        _ ≡ u * 1 [MOD M] := Nat.ModEq.mul_left _ hnu
        _ = u := mul_one u
    show (((u * invMod n M) % M) * n) % M = u
    rw [this]; exact Nat.mod_eq_of_lt hu
  · intro t _; rfl

/-- The centred source weight `g = λ - μ`. -/
noncomputable def srcG (q a' H : ℕ) (y : ℕ) : ℝ :=
  occupiedWeight q a' H y - meanWeight q a' H

lemma srcG_periodic (q a' H y : ℕ) : srcG q a' H (y + 6 * q) = srcG q a' H y := by
  unfold srcG; rw [occupiedWeight_periodic]

lemma srcG_bound (q a' H y : ℕ) : |srcG q a' H y| ≤ 4 := by
  unfold srcG
  have h1 := occupiedWeight_bounds q a' H y
  have h2 := meanWeight_bounds q a' H
  rw [abs_le]; constructor <;> linarith

/-- The full source cycle along any step coprime to `6q` has zero sum. -/
theorem srcG_cycle_zero (q a' H n : ℕ) (hq : 0 < q) (hn : n.Coprime (6 * q)) :
    ∑ t ∈ Finset.range (6 * q), srcG q a' H (t * n) = 0 := by
  have hper := srcG_periodic q a' H
  have h1 : ∑ t ∈ Finset.range (6 * q), srcG q a' H (t * n) =
      ∑ t ∈ Finset.range (6 * q), srcG q a' H ((t * n) % (6 * q)) :=
    Finset.sum_congr rfl fun t _ => periodic_mod _ _ hper _
  rw [h1, sum_range_mul_mod_perm (srcG q a' H) (6 * q) n (by omega) hn]
  unfold srcG meanWeight
  rw [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_range, nsmul_eq_mul]
  have : (6 * q : ℝ) ≠ 0 := by positivity
  push_cast
  field_simp
  ring

/-- `|pot| ≤ 4M` for the source potential. -/
lemma pot_srcG_bound (q a' H n y : ℕ) (hq : 0 < q) :
    |pot (srcG q a' H) (6 * q) n y| ≤ 4 * (6 * q) := by
  unfold pot
  calc |∑ t ∈ Finset.range ((y * invMod n (6 * q)) % (6 * q)), srcG q a' H (t * n)|
      ≤ ∑ t ∈ Finset.range ((y * invMod n (6 * q)) % (6 * q)), |srcG q a' H (t * n)| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ t ∈ Finset.range ((y * invMod n (6 * q)) % (6 * q)), (4 : ℝ) :=
        Finset.sum_le_sum fun t _ => srcG_bound _ _ _ _
    _ = ((y * invMod n (6 * q)) % (6 * q) : ℕ) * 4 := by
        rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
    _ ≤ ((6 * q : ℕ) : ℝ) * 4 := by
        gcongr; exact_mod_cast (Nat.mod_lt _ (by omega)).le
    _ = 4 * (6 * q) := by push_cast; ring

/-! ## The exit point of a constrained progression -/

/-- The first progression point `≥ H` is `H + rs - c(s,r)`: it lies in `[H, H + rs)` and is
`≡ c(r,s) (mod rs)`. -/
theorem exit_point {H r s : ℕ} (hr : 2 ≤ r) (hs : 2 ≤ s) (hrs : r.Coprime s)
    (hrH : r.Coprime H) :
    0 < crtResidue H s r ∧ crtResidue H s r < r * s ∧
    (H + r * s - crtResidue H s r) % (r * s) = crtResidue H r s := by
  have hc0 : 0 < crtResidue H s r := crtResidue_pos hr hrs.symm hrH (by omega)
  have hc1 : crtResidue H s r < r * s := by
    rw [mul_comm]; exact crtResidue_lt hr (by omega)
  refine ⟨hc0, hc1, ?_⟩
  have hcrs_lt : crtResidue H r s < r * s := crtResidue_lt hs (by omega)
  set x := H + r * s - crtResidue H s r with hx
  have hxc : x + crtResidue H s r = H + r * s := by omega
  -- mod r
  have hA : crtResidue H s r ≡ H [MOD r] := crtResidue_modEq_s hr hrs.symm
  have hB : r ∣ crtResidue H r s := crtResidue_dvd_r
  have hC : crtResidue H r s ≡ H [MOD s] := crtResidue_modEq_s hs hrs
  have hD : s ∣ crtResidue H s r := crtResidue_dvd_r
  have mr : x ≡ crtResidue H r s [MOD r] := by
    rw [Nat.modEq_iff_dvd] at hA ⊢
    obtain ⟨k, hk⟩ := hB
    have hx' : (x : ℤ) = H + r * s - crtResidue H s r := by
      have := congrArg (fun t : ℕ => (t : ℤ)) hxc; push_cast at this; linarith
    rw [hx', hk]; push_cast
    obtain ⟨m, hm⟩ := hA
    exact ⟨k - s - m, by linear_combination -hm⟩
  have ms : x ≡ crtResidue H r s [MOD s] := by
    rw [Nat.modEq_iff_dvd] at hC ⊢
    obtain ⟨k, hk⟩ := hD
    have hx' : (x : ℤ) = H + r * s - crtResidue H s r := by
      have := congrArg (fun t : ℕ => (t : ℤ)) hxc; push_cast at this; linarith
    rw [hx', hk]; push_cast
    obtain ⟨m, hm⟩ := hC
    exact ⟨k - r - m, by linear_combination -hm⟩
  have hmod : x ≡ crtResidue H r s [MOD r * s] :=
    (Nat.modEq_and_modEq_iff_modEq_mul hrs).1 ⟨mr, ms⟩
  rw [hmod]; exact Nat.mod_eq_of_lt hcrs_lt

/-- **The constrained digit telescopes**: `digitAP = pot(H + rs - c(s,r)) - pot(c(r,s))`. -/
theorem digitAP_eq_pot (q a' H r s : ℕ) (hq : 0 < q) (hH : 1 ≤ H) (hr : 2 ≤ r) (hs : 2 ≤ s)
    (hrs : r.Coprime s) (hrH : r.Coprime H) (hsH : s.Coprime H)
    (hnM : (r * s).Coprime (6 * q)) :
    digitAP (occupiedWeight q a' H) (meanWeight q a' H) H r s =
      pot (srcG q a' H) (6 * q) (r * s) (H + r * s - crtResidue H s r) -
        pot (srcG q a' H) (6 * q) (r * s) (crtResidue H r s) := by
  obtain ⟨hc0', hc1', hexit⟩ := exit_point hr hs hrs hrH
  have hn : 0 < r * s := by positivity
  have hc0 : 0 < crtResidue H r s := crtResidue_pos hs hrs hsH (by omega)
  have hc1 : crtResidue H r s < r * s := crtResidue_lt hs (by omega)
  have hstep := pot_step (srcG q a' H) (6 * q) (r * s) (by omega) hnM (srcG_periodic q a' H)
    (srcG_cycle_zero q a' H (r * s) hq hnM)
  -- rewrite the digit sum as a class sum over `range H`
  have hrow : digitAP (occupiedWeight q a' H) (meanWeight q a' H) H r s =
      ∑ y ∈ Finset.range H, (if y % (r * s) = crtResidue H r s then
        pot (srcG q a' H) (6 * q) (r * s) (y + r * s) -
          pot (srcG q a' H) (6 * q) (r * s) y else 0) := by
    unfold digitAP
    have hR : Finset.range H = insert 0 (Finset.Ioo 0 H) := by
      ext y; simp only [Finset.mem_range, Finset.mem_insert, Finset.mem_Ioo]; omega
    rw [hR, Finset.sum_insert (by simp)]
    have h0 : ¬ (0 % (r * s) = crtResidue H r s) := by rw [Nat.zero_mod]; omega
    simp only [h0, ↓reduceIte, zero_add]
    refine Finset.sum_congr rfl fun y hy => ?_
    rw [Finset.mem_Ioo] at hy
    have hiff : (r ∣ y ∧ s ∣ H - y) ↔ y % (r * s) = crtResidue H r s := by
      rw [constraint_iff hs hrs hy.2.le]
      unfold Nat.ModEq; rw [Nat.mod_eq_of_lt hc1]
    by_cases hc : y % (r * s) = crtResidue H r s
    · simp only [hiff.2 hc, hc, and_self, ↓reduceIte]; rw [hstep]; rfl
    · have hn' : ¬ (r ∣ y ∧ s ∣ H - y) := fun h => hc (hiff.1 h)
      simp only [hn', hc, ↓reduceIte]
  rw [hrow]
  exact class_telescope _ hc1 ⟨by omega, by omega⟩ hexit

/-! ## Source gates -/

lemma centralGate_swap (h H r s : ℕ) : centralGate h H r s ↔ centralGate h H s r := by
  unfold centralGate
  rw [mul_comm (r : ℝ)]
  tauto

/-- **Orientation fold**: the involution `B ↦ e \ B` of the source index. Exact for every `F`. -/
theorem centralSum_swap (q h : ℕ) (F : ℕ → ℕ → ℕ → ℕ → ℝ) :
    centralSum q h F = centralSum q h (fun D H r s => F D H s r) := by
  unfold centralSum
  refine Finset.sum_congr rfl fun d _ => ?_
  congr 1
  refine Finset.sum_congr rfl fun e he => ?_
  have hmem : ∀ B ∈ ((e.powerset.erase e).erase ∅), e \ B ∈ ((e.powerset.erase e).erase ∅) ∧
      e \ (e \ B) = B := by
    intro B hB
    simp only [Finset.mem_erase, Finset.mem_powerset] at hB ⊢
    obtain ⟨hB0, hBe, hBsub⟩ := hB
    refine ⟨⟨?_, ?_, Finset.sdiff_subset⟩, Finset.sdiff_sdiff_eq_self hBsub⟩
    · intro h0
      apply hBe
      exact le_antisymm hBsub (Finset.sdiff_eq_empty_iff_subset.1 h0)
    · intro h1
      apply hB0
      have : e \ (e \ B) = e \ e := by rw [h1]
      rw [Finset.sdiff_sdiff_eq_self hBsub, Finset.sdiff_self] at this
      exact this
  refine Finset.sum_nbij' (fun B => e \ B) (fun B => e \ B) ?_ ?_ ?_ ?_ ?_
  · intro B hB; exact (hmem B hB).1
  · intro B hB; exact (hmem B hB).1
  · intro B hB; exact (hmem B hB).2
  · intro B hB; exact (hmem B hB).2
  · intro B hB
    have hinv := (hmem B hB).2
    simp only
    rw [hinv]
    by_cases hg : centralGate h (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct (e \ B))
    · have hg' := (centralGate_swap _ _ _ _).1 hg
      simp only [hg, hg', ↓reduceIte]
    · have hg' : ¬ centralGate h (h / primeSetProduct d) (primeSetProduct (e \ B)) (primeSetProduct B) :=
        fun h' => hg ((centralGate_swap _ _ _ _).2 h')
      simp only [hg, hg', ↓reduceIte]

/-! ## Source facts used by the fold -/

lemma source_n_coprime {q h : ℕ} {d e B : Finset ℕ} (hidx : SourceIndex q h d e B) :
    (primeSetProduct B * primeSetProduct (e \ B)).Coprime (6 * q) := by
  obtain ⟨-, he, hB⟩ := hidx
  have heS : e ⊆ ordinaryFiniteSupport q (h / primeSetProduct d) d ((h / primeSetProduct d) ^ 2 + 1) :=
    Finset.mem_powerset.1 (Finset.mem_filter.1 he).1
  have hfac : ∀ p ∈ e, p.Prime ∧ ¬ p ∣ 6 * q := by
    intro p hp
    obtain ⟨hpp, hp5, hpq, -, -⟩ := prime_of_mem_support (heS hp)
    refine ⟨hpp, fun hdvd => ?_⟩
    rcases (Nat.Prime.dvd_mul hpp).1 hdvd with h6 | hq
    · have : p ≤ 6 := Nat.le_of_dvd (by norm_num) h6
      interval_cases p <;> revert hpp h6 <;> norm_num
    · exact hpq hq
  simp only [Finset.mem_erase, Finset.mem_powerset] at hB
  exact Nat.Coprime.mul_left (coprime_prod_of_forall fun p hp => hfac p (hB.2.2 hp))
    (coprime_prod_of_forall fun p hp => hfac p (Finset.sdiff_subset hp))

/-! ## The folded debt -/

/-- The folded row: twice the oriented sawtooth plus the entry/exit potential difference.
It depends on the pair only through the CRT residue `c(r,s)` and `n = rs`. -/
noncomputable def foldRow (q a : ℕ) (D H r s : ℕ) : ℝ :=
  -(2 * meanWeight q (reducedAnchor q a D) H) * saw ((H : ℝ) * invMod r s / s) +
    (pot (srcG q (reducedAnchor q a D) H) (6 * q) (r * s) (H + r * s - crtResidue H r s) -
      pot (srcG q (reducedAnchor q a D) H) (6 * q) (r * s) (crtResidue H r s))

/-- **Exact fold of the debt.** No analytic input; both orientations are summed (the fold is the
relabelling `B ↦ e \ B`), and every source mask and weight is untouched. -/
theorem debt_fold (q a h : ℕ) (hq : 0 < q) :
    SawPart q a h + DigitAPPart q a h = centralSum q h (foldRow q a) := by
  set A : ℕ → ℕ → ℕ → ℕ → ℝ := fun D H r s =>
    -(meanWeight q (reducedAnchor q a D) H * saw ((H : ℝ) * invMod r s / s)) -
      pot (srcG q (reducedAnchor q a D) H) (6 * q) (r * s) (crtResidue H r s) with hA
  set Bf : ℕ → ℕ → ℕ → ℕ → ℝ := fun D H r s =>
    -(meanWeight q (reducedAnchor q a D) H * saw ((H : ℝ) * invMod s r / r)) +
      pot (srcG q (reducedAnchor q a D) H) (6 * q) (r * s) (H + r * s - crtResidue H s r) with hBf
  have h1 : SawPart q a h + DigitAPPart q a h = centralSum q h A + centralSum q h Bf := by
    rw [SawPart, DigitAPPart, ← centralSum_add, ← centralSum_add]
    refine centralSum_congr fun d e B hidx => ?_
    obtain ⟨hH, hr, hs, hrs, hrH, hsH⟩ := source_pair_facts hidx
    rw [digitAP_eq_pot q _ _ _ _ hq hH hr hs hrs hrH hsH (source_n_coprime hidx)]
    simp only [hA, hBf]
    ring
  rw [h1, centralSum_swap q h Bf, ← centralSum_add]
  refine centralSum_congr fun d e B _ => ?_
  simp only [hA, hBf, foldRow]
  rw [mul_comm (primeSetProduct (e \ B)) (primeSetProduct B)]
  ring

/-! ## Pair sums at a fixed decoration, and the two anchor-free equidistribution sums -/

/-- The active decorations. -/
noncomputable def activeDecorations (q h : ℕ) : Finset (Finset ℕ) :=
  (decoratedHeightPrimeSet q h).powerset.filter (fun d => activeDecoration h (h / primeSetProduct d))

/-- The gated, `ω`-weighted sum over source pairs `(e, B)` at a fixed decoration `d`. -/
noncomputable def pairSum (q h : ℕ) (d : Finset ℕ) (G : ℕ → ℕ → ℕ → ℝ) : ℝ :=
  ∑ e ∈ quarterParents q h (h / primeSetProduct d) d ((h / primeSetProduct d) ^ 2 + 1),
    ∑ B ∈ ((e.powerset.erase e).erase ∅),
      if centralGate h (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct (e \ B)) then
        omegaWeight e * G (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct (e \ B))
      else 0

lemma centralSum_eq_pairSum (q h : ℕ) (F : ℕ → ℕ → ℕ → ℕ → ℝ) :
    centralSum q h F = ∑ d ∈ activeDecorations q h,
      decorationWeight h d * pairSum q h d (F (primeSetProduct d)) := rfl

lemma pairSum_sum {ι : Type*} (q h : ℕ) (d : Finset ℕ) (I : Finset ι) (G : ι → ℕ → ℕ → ℕ → ℝ) :
    pairSum q h d (fun H r s => ∑ i ∈ I, G i H r s) = ∑ i ∈ I, pairSum q h d (G i) := by
  unfold pairSum
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun e _ => ?_
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun B _ => ?_
  split_ifs
  · rw [Finset.mul_sum]
  · simp

lemma pairSum_const_mul (q h : ℕ) (d : Finset ℕ) (c : ℝ) (G : ℕ → ℕ → ℕ → ℝ) :
    pairSum q h d (fun H r s => c * G H r s) = c * pairSum q h d G := by
  unfold pairSum
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun e _ => ?_
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun B _ => ?_
  split_ifs <;> ring

lemma pairSum_add (q h : ℕ) (d : Finset ℕ) (F G : ℕ → ℕ → ℕ → ℝ) :
    pairSum q h d (fun H r s => F H r s + G H r s) = pairSum q h d F + pairSum q h d G := by
  unfold pairSum
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun e _ => ?_
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun B _ => ?_
  split_ifs <;> ring

/-- **Anchor-free sawtooth moment** at decoration `d`: `Σ ω(e) ψ(H r̄/s)` over gated source pairs.
Note `ψ(H r̄/s) = c(r,s)/(rs) - 1/2`. -/
noncomputable def sawMoment (q h : ℕ) (d : Finset ℕ) : ℝ :=
  pairSum q h d (fun H r s => saw ((H : ℝ) * invMod r s / s))

/-- **Anchor-free class mass**: the `ω`-mass of gated source pairs with `c(r,s) ≡ b` and
`rs ≡ ν (mod 6q)`. -/
noncomputable def classMass (q h : ℕ) (d : Finset ℕ) (b ν : ℕ) : ℝ :=
  pairSum q h d (fun H r s =>
    if crtResidue H r s % (6 * q) = b ∧ (r * s) % (6 * q) = ν then 1 else 0)

/-- Class discrepancy: class mass minus its equidistributed share `1/(6q)` of the `ν`-column. -/
noncomputable def classDisc (q h : ℕ) (d : Finset ℕ) (b ν : ℕ) : ℝ :=
  classMass q h d b ν - (∑ b' ∈ Finset.range (6 * q), classMass q h d b' ν) / (6 * q)

/-! ## Class expansion of the folded row -/

lemma pot_mod_n (g : ℕ → ℝ) (M n y : ℕ) (hper : ∀ y, g (y + M) = g y) :
    pot g M n y = pot g M (n % M) y := by
  unfold pot
  have hinv : invMod n M = invMod (n % M) M := by
    unfold invMod; rw [ZMod.natCast_mod]
  rw [hinv]
  refine Finset.sum_congr rfl fun t _ => periodic_modEq g M hper ?_
  exact Nat.ModEq.mul_left t (Nat.mod_modEq n M).symm

/-- The class value of the entry/exit potential difference: `c ≡ b`, `rs ≡ ν (mod 6q)`. -/
noncomputable def gammaClass (q a D H b ν : ℕ) : ℝ :=
  pot (srcG q (reducedAnchor q a D) H) (6 * q) ν (H + ν + 6 * q - b) -
    pot (srcG q (reducedAnchor q a D) H) (6 * q) ν b

lemma pot_diff_eq_gammaClass (q a D H n c : ℕ) (hq : 0 < q) (hc : c < n) :
    pot (srcG q (reducedAnchor q a D) H) (6 * q) n (H + n - c) -
      pot (srcG q (reducedAnchor q a D) H) (6 * q) n c =
    gammaClass q a D H (c % (6 * q)) (n % (6 * q)) := by
  unfold gammaClass
  have hper := srcG_periodic q (reducedAnchor q a D) H
  rw [pot_mod_n _ _ n _ hper, pot_mod_n _ _ n c hper]
  congr 1
  · apply pot_congr
    rw [Nat.modEq_iff_dvd]
    have hb : c % (6 * q) ≤ 6 * q := (Nat.mod_lt _ (by omega)).le
    have e1 := Nat.mod_add_div n (6 * q)
    have e2 := Nat.mod_add_div c (6 * q)
    push_cast [Nat.cast_sub (show c ≤ H + n by omega),
      Nat.cast_sub (show c % (6 * q) ≤ H + n % (6 * q) + 6 * q by omega)]
    have e1' : ((n % (6 * q) : ℕ) : ℤ) = n - 6 * q * (n / (6 * q) : ℕ) := by
      have := congrArg (fun t : ℕ => (t : ℤ)) e1; push_cast at this ⊢; linarith
    have e2' : ((c % (6 * q) : ℕ) : ℤ) = c - 6 * q * (c / (6 * q) : ℕ) := by
      have := congrArg (fun t : ℕ => (t : ℤ)) e2; push_cast at this ⊢; linarith
    push_cast at e1' e2'
    rw [e1', e2']
    exact ⟨1 - (n / (6 * q) : ℕ) + (c / (6 * q) : ℕ), by push_cast; ring⟩
  · exact pot_congr _ _ _ (Nat.mod_modEq c (6 * q)).symm

lemma sum_sum_ite_eq (M x y : ℕ) (hx : x < M) (hy : y < M) (f : ℕ → ℕ → ℝ) :
    ∑ b ∈ Finset.range M, ∑ ν ∈ Finset.range M, f b ν * (if x = b ∧ y = ν then 1 else 0) =
      f x y := by
  rw [Finset.sum_eq_single x]
  · rw [Finset.sum_eq_single y]
    · simp
    · intro ν _ hν; simp [Ne.symm hν]
    · intro h; exact absurd (Finset.mem_range.2 hy) h
  · intro b _ hb
    exact Finset.sum_eq_zero fun ν _ => by simp [Ne.symm hb]
  · intro h; exact absurd (Finset.mem_range.2 hx) h

/-- The folded row on source pairs, expanded over the classes `(c mod 6q, rs mod 6q)`. -/
noncomputable def foldRowClass (q a : ℕ) (D H r s : ℕ) : ℝ :=
  -(2 * meanWeight q (reducedAnchor q a D) H) * saw ((H : ℝ) * invMod r s / s) +
    ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
      gammaClass q a D H b ν *
        (if crtResidue H r s % (6 * q) = b ∧ (r * s) % (6 * q) = ν then 1 else 0)

theorem centralSum_foldRow_class (q a h : ℕ) (hq : 0 < q) :
    centralSum q h (foldRow q a) = centralSum q h (foldRowClass q a) := by
  refine centralSum_congr fun d e B hidx => ?_
  obtain ⟨-, hr, hs, -, -, -⟩ := source_pair_facts hidx
  unfold foldRow foldRowClass
  congr 1
  rw [pot_diff_eq_gammaClass _ _ _ _ _ _ hq (crtResidue_lt hs (by omega)),
    sum_sum_ite_eq _ _ _ (Nat.mod_lt _ (by omega)) (Nat.mod_lt _ (by omega))]

lemma sum_gammaClass_zero (q a D H ν : ℕ) :
    ∑ b ∈ Finset.range (6 * q), gammaClass q a D H b ν = 0 := by
  unfold gammaClass
  rw [Finset.sum_sub_distrib, sub_eq_zero]
  set f := pot (srcG q (reducedAnchor q a D) H) (6 * q) ν with hf
  have hfper : ∀ y, f (y + 6 * q) = f y := fun y =>
    pot_congr _ _ _ (Nat.add_modEq_right)
  rw [← Finset.sum_range_reflect (fun b => f (H + ν + 6 * q - b))]
  have : ∀ j ∈ Finset.range (6 * q), f (H + ν + 6 * q - (6 * q - 1 - j)) = f ((H + ν + 1) + j) := by
    intro j hj
    rw [Finset.mem_range] at hj
    congr 1; omega
  rw [Finset.sum_congr rfl this]
  exact sum_shift_period f (6 * q) hfper (H + ν + 1)

lemma abs_gammaClass_le (q a D H b ν : ℕ) (hq : 0 < q) :
    |gammaClass q a D H b ν| ≤ 8 * (6 * q) := by
  unfold gammaClass
  have h1 := pot_srcG_bound q (reducedAnchor q a D) H ν (H + ν + 6 * q - b) hq
  have h2 := pot_srcG_bound q (reducedAnchor q a D) H ν b hq
  calc _ ≤ |pot (srcG q (reducedAnchor q a D) H) (6 * q) ν (H + ν + 6 * q - b)| +
        |pot (srcG q (reducedAnchor q a D) H) (6 * q) ν b| := abs_sub _ _
    _ ≤ 4 * (6 * q) + 4 * (6 * q) := add_le_add h1 h2
    _ = 8 * (6 * q) := by ring

lemma centering_sum (M : ℕ) (γ m : ℕ → ℕ → ℝ) (hγ : ∀ ν, ∑ b ∈ Finset.range M, γ b ν = 0) :
    ∑ b ∈ Finset.range M, ∑ ν ∈ Finset.range M, γ b ν * m b ν =
      ∑ b ∈ Finset.range M, ∑ ν ∈ Finset.range M,
        γ b ν * (m b ν - (∑ b' ∈ Finset.range M, m b' ν) / M) := by
  simp_rw [mul_sub, Finset.sum_sub_distrib]
  have : ∑ b ∈ Finset.range M, ∑ ν ∈ Finset.range M,
      γ b ν * ((∑ b' ∈ Finset.range M, m b' ν) / M) = 0 := by
    rw [Finset.sum_comm]
    refine Finset.sum_eq_zero fun ν _ => ?_
    rw [← Finset.sum_mul, hγ ν, zero_mul]
  rw [this, sub_zero]

lemma classMass_eq (q h : ℕ) (d : Finset ℕ) (H b ν : ℕ) (hH : H = h / primeSetProduct d) :
    (pairSum q h d fun _ r s =>
      if crtResidue H r s % (6 * q) = b ∧ r * s % (6 * q) = ν then (1 : ℝ) else 0) =
      classMass q h d b ν := by
  subst hH; rfl

lemma sawMoment_eq (q h : ℕ) (d : Finset ℕ) (H : ℕ) (hH : H = h / primeSetProduct d) :
    (pairSum q h d fun _ r s => saw ((H : ℝ) * invMod r s / s)) = sawMoment q h d := by
  subst hH; rfl

lemma pairSum_fixH (q h : ℕ) (d : Finset ℕ) (G : ℕ → ℕ → ℕ → ℝ) :
    pairSum q h d G = pairSum q h d (fun _ r s => G (h / primeSetProduct d) r s) := by
  unfold pairSum; rfl

lemma pairSum_foldRowClass (q a h : ℕ) (d : Finset ℕ) :
    pairSum q h d (foldRowClass q a (primeSetProduct d)) =
      -(2 * meanWeight q (reducedAnchor q a (primeSetProduct d)) (h / primeSetProduct d)) *
          sawMoment q h d +
        ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
          gammaClass q a (primeSetProduct d) (h / primeSetProduct d) b ν * classDisc q h d b ν := by
  rw [pairSum_fixH]
  unfold foldRowClass
  rw [pairSum_add, pairSum_const_mul, pairSum_sum]
  simp_rw [pairSum_sum, pairSum_const_mul]
  rw [sawMoment_eq q h d _ rfl]
  congr 1
  simp_rw [classMass_eq q h d _ _ _ rfl]
  unfold classDisc
  have hc := centering_sum (6 * q) (gammaClass q a (primeSetProduct d) (h / primeSetProduct d))
    (classMass q h d) fun ν => sum_gammaClass_zero q a _ _ ν
  push_cast at hc
  exact hc

/-- **Exact reduction of the debt to anchor-free sums.** At every active decoration `d`, the
folded debt is `-2μ_d · sawMoment_d + Σ_{b,ν} Γ_d(b,ν) · classDisc_d(b,ν)`. -/
theorem debt_eq_equidist_form (q a h : ℕ) (hq : 0 < q) :
    SawPart q a h + DigitAPPart q a h =
      ∑ d ∈ activeDecorations q h, decorationWeight h d *
        (-(2 * meanWeight q (reducedAnchor q a (primeSetProduct d)) (h / primeSetProduct d)) *
            sawMoment q h d +
          ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
            gammaClass q a (primeSetProduct d) (h / primeSetProduct d) b ν *
              classDisc q h d b ν) := by
  rw [debt_fold q a h hq, centralSum_foldRow_class q a h hq, centralSum_eq_pairSum]
  exact Finset.sum_congr rfl fun d _ => by rw [pairSum_foldRowClass q a h d]

/-! ## The bound, and the debt from the two anchor-free equidistribution statements -/

lemma decorationWeight_nonneg_active {q h : ℕ} {d : Finset ℕ} (hd : d ∈ activeDecorations q h) :
    0 ≤ decorationWeight h d :=
  decorationWeight_nonneg (Finset.mem_powerset.1 (Finset.mem_filter.1 hd).1)

/-- Absolute values are taken **only after** the exact reduction: the signed debt is bounded by
the anchor-free sawtooth moments and class discrepancies, with constants `8` and `8·6q`. -/
theorem debt_abs_le (q a h : ℕ) (hq : 0 < q) :
    |SawPart q a h + DigitAPPart q a h| ≤
      8 * ∑ d ∈ activeDecorations q h, decorationWeight h d * |sawMoment q h d| +
        8 * (6 * q) * ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
          ∑ d ∈ activeDecorations q h, decorationWeight h d * |classDisc q h d b ν| := by
  rw [debt_eq_equidist_form q a h hq]
  have hterm : ∀ d ∈ activeDecorations q h,
      |decorationWeight h d *
        (-(2 * meanWeight q (reducedAnchor q a (primeSetProduct d)) (h / primeSetProduct d)) *
            sawMoment q h d +
          ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
            gammaClass q a (primeSetProduct d) (h / primeSetProduct d) b ν * classDisc q h d b ν)| ≤
      8 * (decorationWeight h d * |sawMoment q h d|) +
        8 * (6 * q) * ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
          decorationWeight h d * |classDisc q h d b ν| := by
    intro d hd
    have hV := decorationWeight_nonneg_active hd
    have hμ := meanWeight_bounds q (reducedAnchor q a (primeSetProduct d)) (h / primeSetProduct d)
    rw [abs_mul, abs_of_nonneg hV]
    have h1 : |-(2 * meanWeight q (reducedAnchor q a (primeSetProduct d)) (h / primeSetProduct d)) *
        sawMoment q h d| ≤ 8 * |sawMoment q h d| := by
      rw [abs_mul]
      have : |-(2 * meanWeight q (reducedAnchor q a (primeSetProduct d)) (h / primeSetProduct d))| ≤ 8 := by
        rw [abs_neg, abs_of_nonneg (by linarith)]; linarith
      exact mul_le_mul_of_nonneg_right this (abs_nonneg _)
    have h2 : |∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
        gammaClass q a (primeSetProduct d) (h / primeSetProduct d) b ν * classDisc q h d b ν| ≤
        ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
          8 * (6 * q) * |classDisc q h d b ν| := by
      refine (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun b _ => ?_)
      refine (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun ν _ => ?_)
      rw [abs_mul]
      exact mul_le_mul_of_nonneg_right (abs_gammaClass_le q a _ _ b ν hq) (abs_nonneg _)
    calc decorationWeight h d * |_| ≤ decorationWeight h d *
          (8 * |sawMoment q h d| + ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
            8 * (6 * q) * |classDisc q h d b ν|) :=
          mul_le_mul_of_nonneg_left ((abs_add_le _ _).trans (add_le_add h1 h2)) hV
      _ = _ := by
          rw [mul_add, Finset.mul_sum, Finset.mul_sum]
          simp_rw [Finset.mul_sum]
          congr 1
          · ring
          · refine Finset.sum_congr rfl fun b _ => Finset.sum_congr rfl fun ν _ => ?_
            ring
  refine (Finset.abs_sum_le_sum_abs _ _).trans ((Finset.sum_le_sum hterm).trans (le_of_eq ?_))
  rw [Finset.sum_add_distrib, ← Finset.mul_sum, ← Finset.mul_sum]
  congr 2
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun b _ => ?_
  rw [Finset.sum_comm]

/-- **Unpaid analytic input 1 (anchor-free).** The `V_d`-weighted sawtooth moments
`Σ ω(e) ψ(H_d r̄/s)` over gated source pairs are `o(log h)`. -/
def SawEquidist : Prop :=
  ∀ q : ℕ, 0 < q → Squarefree q →
    ∀ eps : ℝ, 0 < eps →
      ∃ H0 : ℕ, ∀ h : ℕ, 0 < h → (¬ 2 ∣ q → 2 ∣ h) → H0 ≤ h →
        ∑ d ∈ activeDecorations q h, decorationWeight h d * |sawMoment q h d| ≤
          eps * Real.log (h : ℝ)

/-- **Unpaid analytic input 2 (anchor-free).** For every class pair `(b, ν)` mod `6q`, the
`V_d`-weighted class discrepancies of the CRT residue are `o(log h)`. -/
def ClassEquidist : Prop :=
  ∀ q : ℕ, 0 < q → Squarefree q →
    ∀ eps : ℝ, 0 < eps →
      ∃ H0 : ℕ, ∀ h : ℕ, 0 < h → (¬ 2 ∣ q → 2 ∣ h) → H0 ≤ h →
        ∀ b < 6 * q, ∀ ν < 6 * q,
          ∑ d ∈ activeDecorations q h, decorationWeight h d * |classDisc q h d b ν| ≤
            eps * Real.log (h : ℝ)

/-- **The remaining debt follows from the two anchor-free equidistribution statements.** -/
theorem centralRoundingDebt_of_equidist (hS : SawEquidist) (hC : ClassEquidist) :
    CentralRoundingDebt := by
  intro q hq hsq eps heps
  set M : ℝ := 6 * q with hM
  have hM0 : 0 < M := by positivity
  set K : ℝ := 8 + 8 * M * (M * M) with hK
  have hK0 : 0 < K := by positivity
  obtain ⟨H1, hH1⟩ := hS q hq hsq (eps / K) (by positivity)
  obtain ⟨H2, hH2⟩ := hC q hq hsq (eps / K) (by positivity)
  refine ⟨max H1 H2, fun a h _ hh hpar hH => ?_⟩
  have hL : 0 ≤ Real.log (h : ℝ) := Real.log_natCast_nonneg h
  have hs := hH1 h hh hpar (le_of_max_le_left hH)
  have hc := hH2 h hh hpar (le_of_max_le_right hH)
  have hcsum : ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
      ∑ d ∈ activeDecorations q h, decorationWeight h d * |classDisc q h d b ν| ≤
      ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q), eps / K * Real.log (h : ℝ) :=
    Finset.sum_le_sum fun b hb => Finset.sum_le_sum fun ν hν =>
      hc b (Finset.mem_range.1 hb) ν (Finset.mem_range.1 hν)
  simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul] at hcsum
  calc |SawPart q a h + DigitAPPart q a h|
      ≤ 8 * ∑ d ∈ activeDecorations q h, decorationWeight h d * |sawMoment q h d| +
          8 * (6 * q) * ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
            ∑ d ∈ activeDecorations q h, decorationWeight h d * |classDisc q h d b ν| :=
        debt_abs_le q a h hq
    _ ≤ 8 * (eps / K * Real.log h) +
          8 * (6 * q) * (((6 * q : ℕ) : ℝ) * (((6 * q : ℕ) : ℝ) * (eps / K * Real.log h))) := by
        gcongr
    _ = eps * Real.log (h : ℝ) := by
        rw [hK]; push_cast; field_simp; ring

/-- Consequently the original target follows from the two anchor-free statements. -/
theorem signedActiveCentralSublog_of_equidist (hS : SawEquidist) (hC : ClassEquidist) :
    SignedActiveCentralSublog :=
  signedActiveCentralSublog_of_debt (centralRoundingDebt_of_equidist hS hC)

end GoldC
