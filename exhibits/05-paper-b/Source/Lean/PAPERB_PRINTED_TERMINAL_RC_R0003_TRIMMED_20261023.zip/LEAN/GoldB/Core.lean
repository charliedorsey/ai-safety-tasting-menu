import GoldB.Params

/-!
# GoldB.Core — the order-uniform bound for the Vinogradov double sum

With `Q = ⌊P^{c1/2-η}⌋ + 1`, real `B_j` and a set `S` of at least `c0 k` selected
orders with `P^{-c2 s} ≤ |B_{s-1}| ≤ P^{-c3 s}`:

`|∑_{y,z<Q} e(∑_j B_j (yz)^{j+1})| ≤ Kc · Q² · P^{-γ1/(2k²)}`

with `Kc, γ1` depending only on `c0..c3`.
-/

open Finset

namespace GoldB

/-- `r` distinct orders in `{1..k}` have sum at least `r²/4` -/
lemma sel_sum_ge {k : ℕ} (S : Finset (Fin k)) :
    ((S.card : ℝ)) ^ 2 / 4 ≤ ∑ j ∈ S, ((j : ℕ) + 1 : ℝ) := by
  classical
  set r : ℝ := (S.card : ℝ)
  set H : ℝ := r / 2
  set T1 := S.filter fun j : Fin k => ((j : ℕ) + 1 : ℝ) ≤ H
  set T2 := S.filter fun j : Fin k => ¬ (((j : ℕ) + 1 : ℝ) ≤ H)
  have hT1 : (T1.card : ℝ) ≤ H := by
    have hsub : T1.image (fun j : Fin k => (j : ℕ) + 1) ⊆ Icc 1 ⌊H⌋₊ := by
      intro n hn
      obtain ⟨j, hj, rfl⟩ := mem_image.mp hn
      rw [mem_Icc]
      refine ⟨by omega, Nat.le_floor ?_⟩
      have := (mem_filter.mp hj).2; push_cast; exact this
    have hinj : Set.InjOn (fun j : Fin k => (j : ℕ) + 1) T1 := by
      intro a _ b _ h; simp only at h; exact Fin.ext (by omega)
    have := card_le_card hsub
    rw [card_image_of_injOn hinj, Nat.card_Icc] at this
    have h2 : ((⌊H⌋₊ + 1 - 1 : ℕ) : ℝ) ≤ H := by
      rw [Nat.add_sub_cancel]; exact Nat.floor_le (by positivity)
    calc (T1.card : ℝ) ≤ ((⌊H⌋₊ + 1 - 1 : ℕ) : ℝ) := by exact_mod_cast this
      _ ≤ H := h2
  have hsplit : (T1.card : ℝ) + T2.card = r := by
    have h : T1.card + T2.card = S.card := card_filter_add_card_filter_not _
    simp only [r]; exact_mod_cast h
  have hT2 : H ≤ T2.card := by simp only [H] at hT1 ⊢; linarith
  have hsum2 : (T2.card : ℝ) * H ≤ ∑ j ∈ T2, ((j : ℕ) + 1 : ℝ) := by
    rw [← nsmul_eq_mul, ← sum_const]
    apply sum_le_sum; intro j hj
    have := (mem_filter.mp hj).2; push_neg at this; exact this.le
  have hsub : ∑ j ∈ T2, ((j : ℕ) + 1 : ℝ) ≤ ∑ j ∈ S, ((j : ℕ) + 1 : ℝ) :=
    sum_le_sum_of_subset_of_nonneg (filter_subset _ _) (fun _ _ _ => by positivity)
  have hH : 0 ≤ H := by positivity
  calc r ^ 2 / 4 = H * H := by simp only [H]; ring
    _ ≤ T2.card * H := mul_le_mul_of_nonneg_right hT2 hH
    _ ≤ _ := hsum2.trans hsub

lemma Jc_Zr_eq (k b Q : ℕ) : Jc k b (Zr Q) = Jc k b (Icc (1 : ℤ) Q) := by
  have : (Zr Q).image (fun x => 1 + 1 * x) = Icc (1 : ℤ) Q := by
    ext x; simp only [Zr, mem_image, mem_Ico, mem_Icc]
    constructor
    · rintro ⟨y, ⟨h1, h2⟩, rfl⟩; omega
    · intro h; exact ⟨x - 1, by omega, by ring⟩
  rw [← this, Jc_affine _ _ _ _ one_ne_zero]

lemma Jc_pos (k b : ℕ) (A : Finset ℤ) (hA : A.Nonempty) : 1 ≤ Jc k b A := by
  obtain ⟨a, ha⟩ := hA
  unfold Jc
  apply card_pos.mpr
  refine ⟨((fun _ => a), (fun _ => a)), ?_⟩
  simp only [mem_filter, mem_product, Fintype.mem_piFinset]
  exact ⟨⟨fun _ => ha, fun _ => ha⟩, trivial⟩

lemma one_add_log_le (P δ : ℝ) (hP : 1 ≤ P) (hδ : 0 < δ) (hδ1 : δ ≤ 1) :
    Real.log (1 + Real.log P) ≤ Real.log (1 / δ) + δ * Real.log P := by
  have hlog : 0 ≤ Real.log P := Real.log_nonneg hP
  have h1 : 1 + Real.log P ≤ (1 / δ) * Real.exp (δ * Real.log P) := by
    have := Real.add_one_le_exp (δ * Real.log P)
    rw [div_mul_eq_mul_div, one_mul, le_div_iff₀ hδ]
    nlinarith
  calc Real.log (1 + Real.log P) ≤ Real.log ((1 / δ) * Real.exp (δ * Real.log P)) :=
        Real.log_le_log (by positivity) h1
    _ = Real.log (1 / δ) + δ * Real.log P := by
        rw [Real.log_mul (by positivity) (Real.exp_pos _).ne', Real.log_exp]

end GoldB
