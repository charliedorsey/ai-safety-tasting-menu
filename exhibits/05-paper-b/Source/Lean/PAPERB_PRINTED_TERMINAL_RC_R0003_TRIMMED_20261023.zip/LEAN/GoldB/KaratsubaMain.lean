import GoldB.Karatsuba

/-!
# GoldB.KaratsubaMain — Taylor step, left-aligned bound, and the final theorem
-/

open Finset Set

namespace GoldB

/-- Taylor replacement inside the double sum -/
lemma W_taylor (f : ℝ → ℝ) (k : ℕ) (a : ℝ) (Q : ℕ) (hQ : 1 ≤ Q) (C : ℝ) (hC0 : 0 ≤ C)
    (hf : ∀ x ∈ Set.Icc a (a + ((Q : ℝ) - 1) ^ 2), ContDiffAt ℝ (k + 1) f x)
    (hA : ∀ x ∈ Set.Icc a (a + ((Q : ℝ) - 1) ^ 2),
      |iteratedDeriv (k + 1) f x| / (k + 1).factorial ≤ C) :
    ‖∑ y ∈ Zr Q, ∑ z ∈ Zr Q, ee (f (a + (y : ℝ) * z))‖ ≤
      ‖∑ y ∈ Zr Q, ∑ z ∈ Zr Q, ee (∑ j : Fin k,
          (iteratedDeriv ((j : ℕ) + 1) f a / ((j : ℕ) + 1).factorial) *
            ((y : ℝ) * z) ^ ((j : ℕ) + 1))‖ +
        2 * Real.pi * (Q : ℝ) ^ 2 * (C * (((Q : ℝ) - 1) ^ 2) ^ (k + 1)) := by
  set B : Fin k → ℝ := fun j => iteratedDeriv ((j : ℕ) + 1) f a / ((j : ℕ) + 1).factorial
  have hQr : (1 : ℝ) ≤ Q := by exact_mod_cast hQ
  have hzr : ∀ y ∈ Zr Q, (0 : ℝ) ≤ y ∧ (y : ℝ) ≤ (Q : ℝ) - 1 := by
    intro y hy; simp [Zr] at hy
    constructor
    · exact_mod_cast hy.1
    · have : y ≤ (Q : ℤ) - 1 := by omega
      exact_mod_cast this
  -- the pointwise Taylor estimate
  have hpt : ∀ y ∈ Zr Q, ∀ z ∈ Zr Q,
      ‖ee (f (a + (y : ℝ) * z)) - ee (f a) * ee (∑ j : Fin k, B j * ((y : ℝ) * z) ^ ((j : ℕ) + 1))‖ ≤
        2 * Real.pi * (C * (((Q : ℝ) - 1) ^ 2) ^ (k + 1)) := by
    intro y hy z hz
    obtain ⟨hy0, hy1⟩ := hzr y hy
    obtain ⟨hz0, hz1⟩ := hzr z hz
    set t := (y : ℝ) * z
    have ht0 : 0 ≤ t := mul_nonneg hy0 hz0
    have htQ : t ≤ ((Q : ℝ) - 1) ^ 2 := by simp only [t]; rw [sq]; nlinarith
    have hsub : Set.Icc a (a + t) ⊆ Set.Icc a (a + ((Q : ℝ) - 1) ^ 2) := by
      intro x hx; exact ⟨hx.1, by linarith [hx.2]⟩
    have hT := taylor_iteratedDeriv_bound f k a t C ht0 (fun x hx => hf x (hsub hx))
      (fun x hx => hA x (hsub hx))
    have hpoly : ∑ s ∈ Finset.range (k + 1), iteratedDeriv s f a / s.factorial * t ^ s =
        f a + ∑ j : Fin k, B j * t ^ ((j : ℕ) + 1) := by
      rw [Finset.sum_range_succ', Fin.sum_univ_eq_sum_range
        (fun j => iteratedDeriv (j + 1) f a / (j + 1).factorial * t ^ (j + 1)) k]
      simp [B, add_comm]
    rw [hpoly] at hT
    rw [← ee_add]
    refine (norm_ee_sub_ee_le _ _).trans ?_
    apply mul_le_mul_of_nonneg_left _ (by positivity)
    refine hT.trans ?_
    apply mul_le_mul_of_nonneg_left _ hC0
    exact pow_le_pow_left₀ ht0 htQ _
  set W := ∑ y ∈ Zr Q, ∑ z ∈ Zr Q, ee (f (a + (y : ℝ) * z))
  set W1 := ∑ y ∈ Zr Q, ∑ z ∈ Zr Q, ee (∑ j : Fin k, B j * ((y : ℝ) * z) ^ ((j : ℕ) + 1))
  have hdiff : ‖W - ee (f a) * W1‖ ≤ (Q : ℝ) ^ 2 * (2 * Real.pi * (C * (((Q : ℝ) - 1) ^ 2) ^ (k + 1))) := by
    have e : W - ee (f a) * W1 = ∑ y ∈ Zr Q, ∑ z ∈ Zr Q,
        (ee (f (a + (y : ℝ) * z)) - ee (f a) * ee (∑ j : Fin k, B j * ((y : ℝ) * z) ^ ((j : ℕ) + 1))) := by
      simp only [W, W1, mul_sum, ← sum_sub_distrib]
    rw [e]
    calc ‖∑ y ∈ Zr Q, ∑ z ∈ Zr Q, (ee (f (a + (y : ℝ) * z)) - ee (f a) *
          ee (∑ j : Fin k, B j * ((y : ℝ) * z) ^ ((j : ℕ) + 1)))‖
        ≤ ∑ y ∈ Zr Q, ∑ z ∈ Zr Q, ‖ee (f (a + (y : ℝ) * z)) - ee (f a) *
            ee (∑ j : Fin k, B j * ((y : ℝ) * z) ^ ((j : ℕ) + 1))‖ :=
          (norm_sum_le _ _).trans (sum_le_sum (fun y _ => norm_sum_le _ _))
      _ ≤ ∑ _y ∈ Zr Q, ∑ _z ∈ Zr Q, 2 * Real.pi * (C * (((Q : ℝ) - 1) ^ 2) ^ (k + 1)) :=
          sum_le_sum (fun y hy => sum_le_sum (fun z hz => hpt y hy z hz))
      _ = _ := by rw [sum_const, sum_const, card_Zr, nsmul_eq_mul, nsmul_eq_mul]; ring
  calc ‖W‖ ≤ ‖ee (f a) * W1‖ + ‖W - ee (f a) * W1‖ := by
        have := norm_add_le (ee (f a) * W1) (W - ee (f a) * W1)
        simpa using this
    _ ≤ ‖W1‖ + (Q : ℝ) ^ 2 * (2 * Real.pi * (C * (((Q : ℝ) - 1) ^ 2) ^ (k + 1))) := by
        rw [norm_mul, norm_ee, one_mul]; linarith
    _ = _ := by ring

namespace KParams

variable (K : KParams)

noncomputable def γ : ℝ := min (K.γ1 / 2) (min (min 1 (K.c1 - K.c2)) (1 - K.c1))

lemma γ_pos : 0 < K.γ := by
  unfold γ
  have hg1 := K.γ1_pos; have hgap := K.gap_pos; have hc1 := K.h1
  apply lt_min (by positivity); exact lt_min (lt_min one_pos hgap) (by linarith)

lemma γ_le_one : K.γ ≤ 1 :=
  (min_le_right _ _).trans ((min_le_left _ _).trans (min_le_left _ _))
lemma γ_le_γ1 : K.γ ≤ K.γ1 / 2 := min_le_left _ _
lemma γ_le_gap : K.γ ≤ min 1 (K.c1 - K.c2) := (min_le_right _ _).trans (min_le_left _ _)
lemma γ_le_c1 : K.γ ≤ 1 - K.c1 := (min_le_right _ _).trans (min_le_right _ _)

/-- the Taylor-error exponent -/
lemma eta_bound (k : ℕ) (hk : 1 ≤ k) : K.γ / (k : ℝ) ^ 2 ≤ 2 * K.eta k * (k + 1) := by
  have hkr : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hg := K.γ_le_gap
  unfold eta
  rcases min_cases (1 / (2 * (k : ℝ) ^ 2 * (k + 1))) ((K.c1 - K.c2) / 4) with ⟨h, _⟩ | ⟨h, _⟩
  · rw [h]
    have : 2 * (1 / (2 * (k : ℝ) ^ 2 * (k + 1))) * (k + 1) = 1 / (k : ℝ) ^ 2 := by
      field_simp
    rw [this, div_le_div_iff_of_pos_right (by positivity)]
    exact hg.trans (min_le_left _ _)
  · rw [h]
    have h1 : K.γ ≤ K.c1 - K.c2 := hg.trans (min_le_right _ _)
    have h2 : K.γ / (k : ℝ) ^ 2 ≤ K.γ := div_le_self K.γ_pos.le (by nlinarith)
    have h3 : K.c1 - K.c2 ≤ 2 * ((K.c1 - K.c2) / 4) * (k + 1) := by
      have := K.gap_pos; nlinarith
    linarith

/-- the bound for a left-aligned integer interval -/
theorem left_bound (k : ℕ) (hk : 1 ≤ k) (X P : ℝ) (hP1 : 1 < P) (hPc3 : 2 ≤ P ^ K.c3)
    (hPc1 : 2 ≤ P ^ (1 - K.c1)) (f : ℝ → ℝ)
    (hf : ∀ x ∈ Set.Icc X (X + P), ContDiffAt ℝ (k + 1) f x)
    (hA : ∀ x ∈ Set.Icc X (X + P),
      |iteratedDeriv (k + 1) f x| / (k + 1).factorial ≤ P ^ (-(K.c1 * (k + 1))))
    (S : Finset (Fin k)) (hS : K.c0 * k ≤ S.card)
    (hB : ∀ j ∈ S, ∀ x ∈ Set.Icc X (X + P),
      P ^ (-(K.c2 * ((j : ℕ) + 1))) ≤ |iteratedDeriv ((j : ℕ) + 1) f x| / ((j : ℕ) + 1).factorial ∧
      |iteratedDeriv ((j : ℕ) + 1) f x| / ((j : ℕ) + 1).factorial ≤ P ^ (-(K.c3 * ((j : ℕ) + 1))))
    (u v : ℤ) (huv : ∀ a ∈ Finset.Icc u v, X ≤ a ∧ (a : ℝ) ≤ X + P / 2) :
    ‖∑ a ∈ Finset.Icc u v, ee (f a)‖ ≤ (K.Kc + 2 * Real.pi + 2) * P ^ (1 - K.γ / (k : ℝ) ^ 2) := by
  set Q := K.QQ k P
  have hP0 : 0 < P := by linarith
  have hQ1 : 1 ≤ Q := by simp [Q, QQ]
  have hQr : (1 : ℝ) ≤ Q := by exact_mod_cast hQ1
  have hP2Q : ((Q : ℝ) - 1) = K.P2 k P := by simp [Q, QQ]
  have hu := K.P2_le_uu k hP1.le
  have hu1 := K.uu_ge_one k hP1.le
  -- (Q-1)² ≤ P^{c1} ≤ P/2
  have hQsq : ((Q : ℝ) - 1) ^ 2 ≤ P ^ K.c1 := by
    rw [hP2Q]
    calc (K.P2 k P : ℝ) ^ 2 ≤ (K.uu k P) ^ 2 := pow_le_pow_left₀ (by positivity) hu 2
      _ = P ^ (2 * K.aexp k) := by
          unfold uu; rw [← Real.rpow_natCast, ← Real.rpow_mul hP0.le]; ring_nf
      _ ≤ P ^ K.c1 := Real.rpow_le_rpow_of_exponent_le hP1.le (by
          have := K.eta_nonneg k; unfold aexp; linarith)
  have hc1P : P ^ K.c1 ≤ P / 2 := by
    have : P = P ^ K.c1 * P ^ (1 - K.c1) := by rw [← Real.rpow_add hP0]; simp
    have hpos : 0 < P ^ K.c1 := Real.rpow_pos_of_pos hP0 _
    nlinarith
  -- averaging
  have havg := avg_shift f u v Q hQ1
  -- per-point bound
  have hper : ∀ a ∈ Finset.Icc u v,
      (1 / (Q : ℝ) ^ 2) * ‖∑ y ∈ Zr Q, ∑ z ∈ Zr Q, ee (f (a + (y : ℝ) * z))‖ ≤
        (K.Kc + 2 * Real.pi) * P ^ (-(K.γ / (k : ℝ) ^ 2)) := by
    intro a ha
    obtain ⟨ha1, ha2⟩ := huv a ha
    have hsub : Set.Icc (a : ℝ) (a + ((Q : ℝ) - 1) ^ 2) ⊆ Set.Icc X (X + P) := by
      intro x hx; exact ⟨by linarith [hx.1], by linarith [hx.2]⟩
    have hW := W_taylor f k a Q hQ1 (P ^ (-(K.c1 * (k + 1)))) (by positivity)
      (fun x hx => hf x (hsub hx)) (fun x hx => hA x (hsub hx))
    have hcore := K.core_bound k hk P hP1 hPc3
      (fun j => iteratedDeriv ((j : ℕ) + 1) f a / ((j : ℕ) + 1).factorial) S hS
      (by
        intro j hj
        have := hB j hj a ⟨ha1, by linarith⟩
        rwa [abs_div, abs_of_pos (by positivity : (0 : ℝ) < ((j : ℕ) + 1).factorial)])
    -- Taylor error exponent
    have herr : P ^ (-(K.c1 * (k + 1))) * (((Q : ℝ) - 1) ^ 2) ^ (k + 1) ≤
        P ^ (-(K.γ / (k : ℝ) ^ 2)) := by
      rw [hP2Q]
      calc P ^ (-(K.c1 * (k + 1))) * ((K.P2 k P : ℝ) ^ 2) ^ (k + 1)
          ≤ P ^ (-(K.c1 * (k + 1))) * ((K.uu k P) ^ 2) ^ (k + 1) := by
            gcongr
          _ = P ^ (-(2 * K.eta k * (k + 1))) := by
            unfold uu aexp
            rw [← Real.rpow_mul_natCast hP0.le, ← Real.rpow_mul_natCast hP0.le,
              ← Real.rpow_add hP0]
            congr 1; push_cast; ring
          _ ≤ P ^ (-(K.γ / (k : ℝ) ^ 2)) := Real.rpow_le_rpow_of_exponent_le hP1.le (by
            have := K.eta_bound k hk; linarith)
    have hγ1 : P ^ (-(K.γ1 / (2 * (k : ℝ) ^ 2))) ≤ P ^ (-(K.γ / (k : ℝ) ^ 2)) := by
      apply Real.rpow_le_rpow_of_exponent_le hP1.le
      have := K.γ_le_γ1
      have hk2 : (0 : ℝ) < (k : ℝ) ^ 2 := by positivity
      rw [neg_le_neg_iff, div_le_div_iff₀ hk2 (by positivity)]
      nlinarith
    have hQ2 : (0 : ℝ) < (Q : ℝ) ^ 2 := by positivity
    calc (1 / (Q : ℝ) ^ 2) * ‖∑ y ∈ Zr Q, ∑ z ∈ Zr Q, ee (f (a + (y : ℝ) * z))‖
        ≤ (1 / (Q : ℝ) ^ 2) * (K.Kc * (Q : ℝ) ^ 2 * P ^ (-(K.γ1 / (2 * (k : ℝ) ^ 2))) +
            2 * Real.pi * (Q : ℝ) ^ 2 * (P ^ (-(K.c1 * (k + 1))) * (((Q : ℝ) - 1) ^ 2) ^ (k + 1))) := by
          apply mul_le_mul_of_nonneg_left _ (by positivity)
          exact hW.trans (add_le_add (by simpa [Q] using hcore) le_rfl)
      _ = K.Kc * P ^ (-(K.γ1 / (2 * (k : ℝ) ^ 2))) +
            2 * Real.pi * (P ^ (-(K.c1 * (k + 1))) * (((Q : ℝ) - 1) ^ 2) ^ (k + 1)) := by
          field_simp
      _ ≤ K.Kc * P ^ (-(K.γ / (k : ℝ) ^ 2)) + 2 * Real.pi * P ^ (-(K.γ / (k : ℝ) ^ 2)) := by
          have := K.Kc_pos
          gcongr
      _ = (K.Kc + 2 * Real.pi) * P ^ (-(K.γ / (k : ℝ) ^ 2)) := by ring
  -- the number of points
  have hcard : ((Finset.Icc u v).card : ℝ) ≤ P := by
    rcases (Finset.Icc u v).eq_empty_or_nonempty with he | hne
    · rw [he]; simp; linarith
    · have hu' := huv u (Finset.mem_Icc.mpr ⟨le_rfl, (Finset.nonempty_Icc.mp hne)⟩)
      have hv' := huv v (Finset.mem_Icc.mpr ⟨Finset.nonempty_Icc.mp hne, le_rfl⟩)
      rw [Int.card_Icc]
      have huv' : u ≤ v := Finset.nonempty_Icc.mp hne
      have : ((v + 1 - u).toNat : ℝ) = (v : ℝ) + 1 - u := by
        rw [show (v + 1 - u).toNat = ((v + 1 - u).toNat : ℤ).toNat from rfl]
        have : (0 : ℤ) ≤ v + 1 - u := by omega
        exact_mod_cast Int.toNat_of_nonneg this
      rw [this]
      have : (2 : ℝ) ≤ P := by
        have h := hPc1
        by_contra hlt; push_neg at hlt
        have : P ^ (1 - K.c1) < 2 := by
          calc P ^ (1 - K.c1) ≤ P ^ (1 : ℝ) := Real.rpow_le_rpow_of_exponent_le hP1.le
                (by linarith [K.c1_pos])
            _ = P := Real.rpow_one P
            _ < 2 := hlt
        linarith
      linarith [hu'.1, hv'.2]
  have hexp : P ^ (1 - K.γ / (k : ℝ) ^ 2) = P * P ^ (-(K.γ / (k : ℝ) ^ 2)) := by
    rw [sub_eq_add_neg, Real.rpow_add hP0, Real.rpow_one]
  have hc1 : P ^ K.c1 ≤ P ^ (1 - K.γ / (k : ℝ) ^ 2) := by
    apply Real.rpow_le_rpow_of_exponent_le hP1.le
    have h1 := K.γ_le_c1
    have h2 : K.γ / (k : ℝ) ^ 2 ≤ K.γ := div_le_self K.γ_pos.le (by
      have : (1 : ℝ) ≤ k := by exact_mod_cast hk
      nlinarith)
    linarith
  calc ‖∑ a ∈ Finset.Icc u v, ee (f a)‖
      ≤ (1 / (Q : ℝ) ^ 2) * ∑ a ∈ Finset.Icc u v,
          ‖∑ y ∈ Zr Q, ∑ z ∈ Zr Q, ee (f (a + (y : ℝ) * z))‖ + 2 * ((Q : ℝ) - 1) ^ 2 := havg
    _ ≤ ∑ _a ∈ Finset.Icc u v, (K.Kc + 2 * Real.pi) * P ^ (-(K.γ / (k : ℝ) ^ 2)) +
          2 * P ^ K.c1 := by
        rw [mul_sum]
        exact add_le_add (sum_le_sum hper) (by linarith)
    _ = ((Finset.Icc u v).card : ℝ) * ((K.Kc + 2 * Real.pi) * P ^ (-(K.γ / (k : ℝ) ^ 2))) +
          2 * P ^ K.c1 := by rw [sum_const, nsmul_eq_mul]
    _ ≤ P * ((K.Kc + 2 * Real.pi) * P ^ (-(K.γ / (k : ℝ) ^ 2))) +
          2 * P ^ (1 - K.γ / (k : ℝ) ^ 2) := by
        have := K.Kc_pos
        gcongr
    _ = (K.Kc + 2 * Real.pi + 2) * P ^ (1 - K.γ / (k : ℝ) ^ 2) := by
        rw [hexp]; ring

end KParams

end GoldB
