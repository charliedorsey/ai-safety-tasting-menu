import GoldC.RowRounding
import GoldC.Target
import Mathlib.Data.Nat.GCD.BigOperators

/-!
# `GoldC.CentralDecomp` — exact source-native decomposition of `activeCentral`

`activeCentral q a h = InvPart + SawPart + DigitPart` (theorem `activeCentral_decomp`), where, for
every source index `(d, e, B)` with `D = ∏ d`, `H = h / D`, `r = ∏ B`, `s = ∏ (e \ B)` and
`μ = meanWeight` (the period-`6q` mean of the source weight):

* `InvPart`   collects `μ / (rs)`;
* `SawPart`   collects `-μ · (ψ(H r̄/s) + ψ(H s̄/r))`;
* `DigitPart` collects the mean-zero digit remainder `digitTerm`.

Nothing is assumed: every source index satisfies the hypotheses of `rowDiscrepancy_decomp`
(`source_pair_facts`).
-/

open scoped BigOperators Classical
open Finset

namespace GoldC

/-- The active Central source sum with an arbitrary row functional `F D H r s`
(same masks, gates, decoration and Euler weights as `activeCentral`). -/
noncomputable def centralSum (q h : ℕ) (F : ℕ → ℕ → ℕ → ℕ → ℝ) : ℝ :=
  ∑ d ∈ ((decoratedHeightPrimeSet q h).powerset.filter
      (fun d => activeDecoration h (h / primeSetProduct d))),
    decorationWeight h d *
      (∑ e ∈ quarterParents q h (h / primeSetProduct d) d ((h / primeSetProduct d) ^ 2 + 1),
        ∑ B ∈ ((e.powerset.erase e).erase ∅),
          if centralGate h (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct (e \ B)) then
            omegaWeight e * F (primeSetProduct d) (h / primeSetProduct d)
              (primeSetProduct B) (primeSetProduct (e \ B))
          else 0)

lemma activeCentral_eq_centralSum (q a h : ℕ) :
    activeCentral q a h = centralSum q h (fun D H r s =>
      rowDiscrepancy (occupiedWeight q (reducedAnchor q a D) H) H r s) := rfl

/-- The source index predicate: `(d, e, B)` occurs in the active Central sum. -/
def SourceIndex (q h : ℕ) (d e B : Finset ℕ) : Prop :=
  d ∈ ((decoratedHeightPrimeSet q h).powerset.filter
      (fun d => activeDecoration h (h / primeSetProduct d))) ∧
  e ∈ quarterParents q h (h / primeSetProduct d) d ((h / primeSetProduct d) ^ 2 + 1) ∧
  B ∈ ((e.powerset.erase e).erase ∅)

lemma centralSum_congr {q h : ℕ} {F G : ℕ → ℕ → ℕ → ℕ → ℝ}
    (hFG : ∀ d e B, SourceIndex q h d e B →
      F (primeSetProduct d) (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct (e \ B)) =
      G (primeSetProduct d) (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct (e \ B))) :
    centralSum q h F = centralSum q h G := by
  unfold centralSum
  refine Finset.sum_congr rfl fun d hd => ?_
  congr 1
  refine Finset.sum_congr rfl fun e he => Finset.sum_congr rfl fun B hB => ?_
  split_ifs
  · rw [hFG d e B ⟨hd, he, hB⟩]
  · rfl

lemma centralSum_add (q h : ℕ) (F G : ℕ → ℕ → ℕ → ℕ → ℝ) :
    centralSum q h (fun D H r s => F D H r s + G D H r s) = centralSum q h F + centralSum q h G := by
  unfold centralSum
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun d _ => ?_
  rw [← mul_add, ← Finset.sum_add_distrib]
  congr 1
  refine Finset.sum_congr rfl fun e _ => ?_
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun B _ => ?_
  split_ifs <;> ring

/-! ## The source indices satisfy the rounding hypotheses -/

lemma prime_of_mem_support {q H : ℕ} {d : Finset ℕ} {N p : ℕ}
    (hp : p ∈ ordinaryFiniteSupport q H d N) :
    p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q ∧ ¬ p ∣ H ∧ p ∉ d := by
  unfold ordinaryFiniteSupport activeHighPrime at hp
  simp only [Finset.mem_filter, Finset.mem_range] at hp
  exact ⟨hp.2.1.1, hp.2.1.2.1, hp.2.1.2.2, hp.2.2.1, hp.2.2.2⟩

lemma five_le_prod {T : Finset ℕ} (hT : T.Nonempty) (h5 : ∀ p ∈ T, 5 ≤ p) :
    5 ≤ primeSetProduct T := by
  unfold primeSetProduct
  obtain ⟨p, hp⟩ := hT
  have hpos : ∀ x ∈ T, 0 < x := fun x hx => by have := h5 x hx; omega
  calc 5 ≤ p := h5 p hp
    _ ≤ ∏ x ∈ T, x := Finset.single_le_prod (fun x hx => le_trans (by norm_num) (h5 x hx)) hp

lemma coprime_prod_of_forall {T : Finset ℕ} {m : ℕ} (h : ∀ p ∈ T, p.Prime ∧ ¬ p ∣ m) :
    (primeSetProduct T).Coprime m := by
  unfold primeSetProduct
  exact Nat.Coprime.prod_left fun p hp => (Nat.Prime.coprime_iff_not_dvd (h p hp).1).2 (h p hp).2

lemma coprime_prod_prod {T U : Finset ℕ} (hT : ∀ p ∈ T, p.Prime) (hU : ∀ p ∈ U, p.Prime)
    (hdisj : Disjoint T U) : (primeSetProduct T).Coprime (primeSetProduct U) := by
  unfold primeSetProduct
  refine Nat.Coprime.prod_left fun p hp => Nat.Coprime.prod_right fun p' hp' => ?_
  rw [Nat.coprime_primes (hT p hp) (hU p' hp')]
  rintro rfl
  exact Finset.disjoint_left.1 hdisj hp hp'

/-- Every source index satisfies the hypotheses of the rounding identity. -/
theorem source_pair_facts {q h : ℕ} {d e B : Finset ℕ} (hidx : SourceIndex q h d e B) :
    1 ≤ h / primeSetProduct d ∧ 2 ≤ primeSetProduct B ∧ 2 ≤ primeSetProduct (e \ B) ∧
    (primeSetProduct B).Coprime (primeSetProduct (e \ B)) ∧
    (primeSetProduct B).Coprime (h / primeSetProduct d) ∧
    (primeSetProduct (e \ B)).Coprime (h / primeSetProduct d) := by
  obtain ⟨hd, he, hB⟩ := hidx
  set H := h / primeSetProduct d
  have hdact : activeDecoration h H := (Finset.mem_filter.1 hd).2
  have heS : e ⊆ ordinaryFiniteSupport q H d (H ^ 2 + 1) :=
    Finset.mem_powerset.1 (Finset.mem_filter.1 he).1
  have hfac : ∀ p ∈ e, p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q ∧ ¬ p ∣ H ∧ p ∉ d :=
    fun p hp => prime_of_mem_support (heS hp)
  simp only [Finset.mem_erase, Finset.mem_powerset] at hB
  obtain ⟨hBne, hBe, hBsub⟩ := hB
  have hBn : B.Nonempty := Finset.nonempty_iff_ne_empty.2 hBne
  have hCn : (e \ B).Nonempty := by
    rw [Finset.sdiff_nonempty]
    intro hsub; exact hBe (le_antisymm hBsub hsub)
  -- `H ≥ 1` from the active-decoration inequality
  have hH : 1 ≤ H := by
    unfold activeDecoration at hdact
    have hZ : (1 : ℝ) ≤ (originalZ h : ℝ) := by
      unfold originalZ; exact_mod_cast Nat.one_le_two_pow
    have hE : (1 : ℝ) ≤ Real.exp ((Real.log (h : ℝ)) ^ (1 / 4 : ℝ)) :=
      Real.one_le_exp (Real.rpow_nonneg (Real.log_natCast_nonneg h) _)
    have : (1 : ℝ) < (H : ℝ) := lt_of_le_of_lt (one_le_mul_of_one_le_of_one_le hZ hE) hdact
    have : 1 < H := by exact_mod_cast this
    omega
  refine ⟨hH, ?_, ?_, ?_, ?_, ?_⟩
  · have := five_le_prod hBn fun p hp => (hfac p (hBsub hp)).2.1; omega
  · have := five_le_prod hCn fun p hp => (hfac p (Finset.sdiff_subset hp)).2.1; omega
  · exact coprime_prod_prod (fun p hp => (hfac p (hBsub hp)).1)
      (fun p hp => (hfac p (Finset.sdiff_subset hp)).1) Finset.disjoint_sdiff
  · exact coprime_prod_of_forall fun p hp => ⟨(hfac p (hBsub hp)).1, (hfac p (hBsub hp)).2.2.2.1⟩
  · exact coprime_prod_of_forall fun p hp =>
      ⟨(hfac p (Finset.sdiff_subset hp)).1, (hfac p (Finset.sdiff_subset hp)).2.2.2.1⟩

/-! ## The three parts -/

/-- The period-`6q` mean `μ` of the source weight `y ↦ occupiedWeight q a' H y`. -/
noncomputable def meanWeight (q a' H : ℕ) : ℝ :=
  (∑ y ∈ Finset.range (6 * q), occupiedWeight q a' H y) / (6 * q : ℝ)

/-- `Σ V_d ω(e) μ/(rs)`: the density-diagonal part. -/
noncomputable def InvPart (q a h : ℕ) : ℝ :=
  centralSum q h (fun D H r s => meanWeight q (reducedAnchor q a D) H / ((r : ℝ) * s))

/-- `-Σ V_d ω(e) μ (ψ(H r̄/s) + ψ(H s̄/r))`: the Kloosterman-fraction sawtooth part. -/
noncomputable def SawPart (q a h : ℕ) : ℝ :=
  centralSum q h (fun D H r s => -(meanWeight q (reducedAnchor q a D) H *
    (saw ((H : ℝ) * invMod r s / s) + saw ((H : ℝ) * invMod s r / r))))

/-- `Σ V_d ω(e) digit(r,s)`: the mean-zero digit part. -/
noncomputable def DigitPart (q a h : ℕ) : ℝ :=
  centralSum q h (fun D H r s =>
    digitTerm (occupiedWeight q (reducedAnchor q a D) H)
      (meanWeight q (reducedAnchor q a D) H) H r s)

/-- **Exact decomposition** of the active Central covariance. -/
theorem activeCentral_decomp (q a h : ℕ) :
    activeCentral q a h = InvPart q a h + SawPart q a h + DigitPart q a h := by
  rw [activeCentral_eq_centralSum, InvPart, SawPart, DigitPart, ← centralSum_add,
    ← centralSum_add]
  refine centralSum_congr fun d e B hidx => ?_
  obtain ⟨hH, hr, hs, hrs, hrH, hsH⟩ := source_pair_facts hidx
  rw [rowDiscrepancy_decomp _ (meanWeight q (reducedAnchor q a (primeSetProduct d))
    (h / primeSetProduct d)) hH hr hs hrs hrH hsH]
  ring

end GoldC
