import GoldB.Vino

/-!
# GoldB.VinoMain — the induction proving the mean value theorem
-/

open Finset

namespace GoldB

/-- real bookkeeping for the ill-conditioned branch -/
lemma B_part (k τ : ℕ) (hk : 2 ≤ k) (N p N1 D J1 : ℝ) (hN : (N0 k : ℝ) ≤ N)
    (hrp : N ^ ((k : ℝ)⁻¹) ≤ p) (hN1 : 0 < N1) (hN1le : N1 ≤ 2 * N / p)
    (hD : 0 ≤ D) (hJ1 : J1 ≤ D * N1 ^ (Eexp k (τ + 1))) :
    (4 * ((k : ℝ) ^ 4 * p * p)) ^ (((k * τ + k : ℕ) : ℝ) / 2) * J1 ≤
      D / 2 * N ^ (Eexp k (τ + 1)) := by
  set E := Eexp k (τ + 1)
  set T : ℝ := ((k * τ + k : ℕ) : ℝ)
  have hk' : (2 : ℝ) ≤ k := by exact_mod_cast hk
  have hN0pos : (1 : ℝ) ≤ N0 k := by
    unfold N0; push_cast
    have : (1 : ℝ) ≤ (8 * (k : ℝ) ^ 2) ^ (4 * k) := one_le_pow₀ (by nlinarith)
    nlinarith
  have hNpos : 0 < N := by linarith
  have hN1' : 1 ≤ N := by linarith
  have hr0 : 0 < N ^ ((k : ℝ)⁻¹) := Real.rpow_pos_of_pos hNpos _
  have hp0 : 0 < p := lt_of_lt_of_le hr0 hrp
  have hT : T = (k : ℝ) * (τ + 1) := by simp only [T]; push_cast; ring
  have hE0 : 0 ≤ E := Eexp_nonneg k (τ + 1) (by omega)
  have hET : (k : ℝ) * (τ + 1) / 4 ≤ E - T := by rw [hT]; exact_mod_cast Eexp_succ_sub k τ hk
  have hE2T : E ≤ 2 * T := by
    have := Eexp_le_twoT k (τ + 1) (by omega); rw [hT]; push_cast at this; linarith
  -- (4 k^4 p^2)^{T/2} = (2 k^2 p)^T
  have hsq : (4 * ((k : ℝ) ^ 4 * p * p)) ^ (T / 2) = (2 * (k : ℝ) ^ 2 * p) ^ T := by
    have : (4 * ((k : ℝ) ^ 4 * p * p)) = (2 * (k : ℝ) ^ 2 * p) ^ (2 : ℝ) := by
      rw [Real.rpow_two]; ring
    rw [this, ← Real.rpow_mul (by positivity)]; congr 1; ring
  -- N1^E ≤ (2N/p)^E
  have hN1E : N1 ^ E ≤ (2 * N / p) ^ E := Real.rpow_le_rpow hN1.le hN1le hE0
  have hsplit : (2 * N / p) ^ E = 2 ^ E * N ^ E * p ^ (-E) := by
    rw [Real.div_rpow (by positivity) hp0.le, Real.mul_rpow (by norm_num) hNpos.le,
      Real.rpow_neg hp0.le]
    ring
  -- p^{T-E} ≤ N^{(T-E)/k}
  have hpTE : p ^ (T - E) ≤ N ^ ((T - E) / k) := by
    have h1 : p ^ (T - E) ≤ (N ^ ((k : ℝ)⁻¹)) ^ (T - E) :=
      Real.rpow_le_rpow_of_nonpos hr0 hrp (by linarith)
    rw [← Real.rpow_mul hNpos.le] at h1
    convert h1 using 2; field_simp
  have hNexp : N ^ ((T - E) / k) ≤ N ^ (-((τ + 1 : ℝ) / 4)) := by
    apply Real.rpow_le_rpow_of_exponent_le hN1'
    have hkpos : (0 : ℝ) < k := by linarith
    rw [div_le_iff₀ hkpos]
    nlinarith
  -- N^{(τ+1)/4} ≥ 2 (8k²)^T
  have hbig : 2 * (8 * (k : ℝ) ^ 2) ^ T ≤ N ^ ((τ + 1 : ℝ) / 4) := by
    have h1 : (N0 k : ℝ) ^ ((τ + 1 : ℝ) / 4) ≤ N ^ ((τ + 1 : ℝ) / 4) :=
      Real.rpow_le_rpow (by positivity) hN (by positivity)
    refine le_trans ?_ h1
    have e : (N0 k : ℝ) = (2 : ℝ) ^ (4 : ℝ) * ((8 * (k : ℝ) ^ 2) ^ (4 * (k : ℝ))) := by
      unfold N0; push_cast
      rw [show (2 : ℝ) ^ (4 : ℝ) = 16 by norm_num, ← Real.rpow_natCast]; push_cast; ring_nf
    rw [e, Real.mul_rpow (by positivity : (0 : ℝ) ≤ (2 : ℝ) ^ (4 : ℝ))
        (by positivity : (0 : ℝ) ≤ (8 * (k : ℝ) ^ 2) ^ (4 * (k : ℝ))),
      ← Real.rpow_mul (by norm_num : (0 : ℝ) ≤ 2),
      ← Real.rpow_mul (by positivity : (0 : ℝ) ≤ 8 * (k : ℝ) ^ 2)]
    have e2 : (4 : ℝ) * ((τ + 1 : ℝ) / 4) = τ + 1 := by ring
    have e3 : 4 * (k : ℝ) * ((τ + 1 : ℝ) / 4) = T := by rw [hT]; ring
    rw [e2, e3]
    have : (2 : ℝ) ≤ 2 ^ ((τ : ℝ) + 1) := by
      calc (2 : ℝ) = 2 ^ (1 : ℝ) := by norm_num
        _ ≤ 2 ^ ((τ : ℝ) + 1) := Real.rpow_le_rpow_of_exponent_le (by norm_num) (by
            have : (0 : ℝ) ≤ τ := by positivity
            linarith)
    have hpos : 0 ≤ (8 * (k : ℝ) ^ 2) ^ T := by positivity
    nlinarith
  -- assemble
  have hJ1' : J1 ≤ D * (2 ^ E * N ^ E * p ^ (-E)) := by
    rw [← hsplit]; exact hJ1.trans (mul_le_mul_of_nonneg_left hN1E hD)
  rw [hsq]
  have h2E : (2 : ℝ) ^ E ≤ (2 : ℝ) ^ (2 * T) :=
    Real.rpow_le_rpow_of_exponent_le (by norm_num) hE2T
  have hfac : (2 * (k : ℝ) ^ 2 * p) ^ T * (2 ^ E * p ^ (-E)) ≤
      (8 * (k : ℝ) ^ 2) ^ T * N ^ (-((τ + 1 : ℝ) / 4)) := by
    rw [Real.mul_rpow (by positivity) hp0.le]
    have : p ^ T * p ^ (-E) = p ^ (T - E) := by
      rw [← Real.rpow_add hp0]; ring_nf
    calc (2 * (k : ℝ) ^ 2) ^ T * p ^ T * (2 ^ E * p ^ (-E))
        = (2 * (k : ℝ) ^ 2) ^ T * 2 ^ E * (p ^ T * p ^ (-E)) := by ring
      _ ≤ (2 * (k : ℝ) ^ 2) ^ T * 2 ^ (2 * T) * N ^ (-((τ + 1 : ℝ) / 4)) := by
          rw [this]
          apply mul_le_mul (mul_le_mul_of_nonneg_left h2E (by positivity))
            (hpTE.trans hNexp) (by positivity) (by positivity)
      _ = (8 * (k : ℝ) ^ 2) ^ T * N ^ (-((τ + 1 : ℝ) / 4)) := by
          rw [Real.rpow_mul (by norm_num), show ((2 : ℝ) ^ (2 : ℝ)) = 4 by norm_num,
            ← Real.mul_rpow (by positivity) (by norm_num)]
          ring_nf
  have hhalf : (8 * (k : ℝ) ^ 2) ^ T * N ^ (-((τ + 1 : ℝ) / 4)) ≤ 1 / 2 := by
    rw [Real.rpow_neg hNpos.le]
    have hpos : 0 < N ^ ((τ + 1 : ℝ) / 4) := Real.rpow_pos_of_pos hNpos _
    rw [← div_eq_mul_inv, div_le_iff₀ hpos]
    linarith
  calc (2 * (k : ℝ) ^ 2 * p) ^ T * J1
      ≤ (2 * (k : ℝ) ^ 2 * p) ^ T * (D * (2 ^ E * N ^ E * p ^ (-E))) :=
        mul_le_mul_of_nonneg_left hJ1' (by positivity)
    _ = D * N ^ E * ((2 * (k : ℝ) ^ 2 * p) ^ T * (2 ^ E * p ^ (-E))) := by ring
    _ ≤ D * N ^ E * (1 / 2) := by
        apply mul_le_mul_of_nonneg_left (hfac.trans hhalf) (by positivity)
    _ = D / 2 * N ^ E := by ring
/-- real bookkeeping for the well-conditioned branch -/
lemma A_part (k τ : ℕ) (hk : 2 ≤ k) (N p N1 Js : ℝ) (hN : 1 ≤ N)
    (hp2r : p ≤ 2 * N ^ ((k : ℝ)⁻¹)) (hp0 : 0 < p) (hN1 : 0 < N1) (hN1le : N1 ≤ 2 * N / p)
    (hJs : Js ≤ Dv k τ * N1 ^ (Eexp k τ)) :
    4 * (p ^ (2 * (k * τ)) * (N ^ k * ((k.factorial : ℝ) * p ^ (k * (k - 1) / 2)) * Js)) ≤
      Dv k (τ + 1) / 2 * N ^ (Eexp k (τ + 1)) := by
  set e1 := Eexp k τ
  set E := Eexp k (τ + 1)
  have hNpos : 0 < N := by linarith
  have hk1 : 1 ≤ k := by omega
  have hk' : (2 : ℝ) ≤ k := by exact_mod_cast hk
  have he1 : 0 ≤ e1 := Eexp_nonneg k τ hk1
  have he1le : e1 ≤ 2 * (k * τ : ℝ) := Eexp_le_twoT k τ hk1
  have hDel0 := Del_nonneg k τ hk1
  have hDelk := Del_le_kap k τ hk1
  have hkapk := kap_le_sq k hk1
  -- the exponent of p
  have hq : ((k * (k - 1) / 2 : ℕ) : ℝ) = (k : ℝ) * (k - 1) / 2 := by
    rw [Nat.cast_div (Nat.even_mul_pred_self k).two_dvd (by norm_num)]
    rw [Nat.cast_mul, Nat.cast_sub hk1]; push_cast; ring
  set X : ℝ := (k : ℝ) ^ 2 - Del k τ
  have hX0 : 0 ≤ X := by simp only [X]; linarith
  have hXk : X ≤ (k : ℝ) ^ 2 := by simp only [X]; linarith
  have hpX : p ^ (2 * (k * τ)) * p ^ (k * (k - 1) / 2) * p ^ (-e1) = p ^ X := by
    rw [← Real.rpow_natCast, ← Real.rpow_natCast p (k * (k - 1) / 2), ← Real.rpow_add hp0,
      ← Real.rpow_add hp0, hq]
    congr 1
    simp only [X, e1, Eexp, kap]; push_cast; ring
  have hpXle : p ^ X ≤ 2 ^ ((k : ℝ) ^ 2) * N ^ (X / k) := by
    calc p ^ X ≤ (2 * N ^ ((k : ℝ)⁻¹)) ^ X := Real.rpow_le_rpow hp0.le hp2r hX0
      _ = 2 ^ X * N ^ (X / k) := by
          rw [Real.mul_rpow (by norm_num) (by positivity), ← Real.rpow_mul hNpos.le]
          congr 2; field_simp
      _ ≤ 2 ^ ((k : ℝ) ^ 2) * N ^ (X / k) := by
          apply mul_le_mul_of_nonneg_right _ (by positivity)
          exact Real.rpow_le_rpow_of_exponent_le (by norm_num) hXk
  have hNexp : (k : ℝ) + e1 + X / k = E := by
    simp only [X, e1, E, Eexp]
    rw [Del_succ]
    field_simp
    push_cast
    ring
  have hJs' : Js ≤ Dv k τ * (2 ^ e1 * N ^ e1 * p ^ (-e1)) := by
    calc Js ≤ Dv k τ * N1 ^ e1 := hJs
      _ ≤ Dv k τ * (2 * N / p) ^ e1 := by
          apply mul_le_mul_of_nonneg_left (Real.rpow_le_rpow hN1.le hN1le he1)
          unfold Dv; positivity
      _ = Dv k τ * (2 ^ e1 * N ^ e1 * p ^ (-e1)) := by
          rw [Real.div_rpow (by positivity) hp0.le, Real.mul_rpow (by norm_num) hNpos.le,
            Real.rpow_neg hp0.le]; ring
  have hfact := factorial_le_two_pow_sq k
  have h2e1 : (2 : ℝ) ^ e1 ≤ 2 ^ (2 * (k * τ : ℝ)) :=
    Real.rpow_le_rpow_of_exponent_le (by norm_num) he1le
  have hDv0 : 0 ≤ Dv k τ := by unfold Dv; positivity
  have hconst : 4 * (k.factorial : ℝ) * Dv k τ * 2 ^ e1 * 2 ^ ((k : ℝ) ^ 2) ≤ Dv k (τ + 1) / 2 := by
    have h1 : 4 * (k.factorial : ℝ) * Dv k τ * 2 ^ e1 * 2 ^ ((k : ℝ) ^ 2) ≤
        4 * (2 : ℝ) ^ (k ^ 2) * Dv k τ * 2 ^ (2 * (k * τ : ℝ)) * 2 ^ ((k : ℝ) ^ 2) := by
      gcongr
    refine h1.trans (le_of_eq_of_le (b := (2 : ℝ) ^ (2 + 2 * k ^ 2 + 2 * k * τ + Dexp k τ)) ?_ ?_)
    · rw [show (2 : ℝ) ^ (2 * (k * τ : ℝ)) = (2 : ℝ) ^ (2 * k * τ) by
            rw [show (2 * (k * τ : ℝ)) = ((2 * k * τ : ℕ) : ℝ) by push_cast; ring,
              Real.rpow_natCast],
          show (2 : ℝ) ^ ((k : ℝ) ^ 2) = (2 : ℝ) ^ (k ^ 2) by
            rw [show ((k : ℝ)) ^ 2 = ((k ^ 2 : ℕ) : ℝ) by push_cast; ring, Real.rpow_natCast]]
      unfold Dv
      rw [show (4 : ℝ) = 2 ^ 2 by norm_num]
      rw [← pow_add, ← pow_add, ← pow_add, ← pow_add]
      ring_nf
    · unfold Dv Dexp
      rw [div_eq_mul_inv, show ((2 : ℝ))⁻¹ = 2 ^ (-1 : ℤ) by norm_num, ← zpow_natCast,
        ← zpow_natCast, ← zpow_add₀ (by norm_num)]
      apply zpow_le_zpow_right₀ (by norm_num)
      push_cast
      nlinarith
  calc 4 * (p ^ (2 * (k * τ)) * (N ^ k * ((k.factorial : ℝ) * p ^ (k * (k - 1) / 2)) * Js))
      ≤ 4 * (p ^ (2 * (k * τ)) * (N ^ k * ((k.factorial : ℝ) * p ^ (k * (k - 1) / 2)) *
          (Dv k τ * (2 ^ e1 * N ^ e1 * p ^ (-e1))))) := by gcongr
    _ = 4 * (k.factorial : ℝ) * Dv k τ * 2 ^ e1 * (N ^ k * N ^ e1) *
          (p ^ (2 * (k * τ)) * p ^ (k * (k - 1) / 2) * p ^ (-e1)) := by ring
    _ = 4 * (k.factorial : ℝ) * Dv k τ * 2 ^ e1 * (N ^ k * N ^ e1) * p ^ X := by rw [hpX]
    _ ≤ 4 * (k.factorial : ℝ) * Dv k τ * 2 ^ e1 * (N ^ k * N ^ e1) *
          (2 ^ ((k : ℝ) ^ 2) * N ^ (X / k)) := by
        apply mul_le_mul_of_nonneg_left hpXle (by positivity)
    _ = (4 * (k.factorial : ℝ) * Dv k τ * 2 ^ e1 * 2 ^ ((k : ℝ) ^ 2)) *
          (N ^ (k : ℝ) * N ^ e1 * N ^ (X / k)) := by rw [Real.rpow_natCast]; ring
    _ = (4 * (k.factorial : ℝ) * Dv k τ * 2 ^ e1 * 2 ^ ((k : ℝ) ^ 2)) * N ^ E := by
        rw [← Real.rpow_add hNpos, ← Real.rpow_add hNpos, hNexp]
    _ ≤ Dv k (τ + 1) / 2 * N ^ E :=
        mul_le_mul_of_nonneg_right hconst (by positivity)

/-- **Vinogradov's mean value theorem** with explicit `k`-uniform constant. -/
theorem vmvt (k : ℕ) (hk : 1 ≤ k) (τ N : ℕ) (hN : 1 ≤ N) :
    (Jc k (k * τ) (Icc (1 : ℤ) N) : ℝ) ≤ Dv k τ * (N : ℝ) ^ (Eexp k τ) := by
  rcases eq_or_lt_of_le hk with h1 | hk2
  · subst h1; exact vmvt_one τ N hN
  replace hk2 : 2 ≤ k := hk2
  induction τ generalizing N with
  | zero =>
    simp only [mul_zero, Jc_zero, Nat.cast_one]
    have : Eexp k 0 = 0 := by unfold Eexp Del; simp
    rw [this, Real.rpow_zero, mul_one]
    unfold Dv; exact one_le_pow₀ (by norm_num)
  | succ τ ih =>
    induction N using Nat.strong_induction_on with
    | _ N ihN =>
    have hNr : (1 : ℝ) ≤ N := by exact_mod_cast hN
    have hNpos : (0 : ℝ) < N := by linarith
    set E := Eexp k (τ + 1)
    have hE0 : 0 ≤ E := Eexp_nonneg k (τ + 1) hk
    have hDv1 : (2 : ℝ) ^ (24 * k ^ 4) ≤ Dv k (τ + 1) := by
      unfold Dv Dexp; exact pow_le_pow_right₀ (by norm_num) (by omega)
    by_cases hsmall : N < N0 k
    · -- trivial bound
      have htriv : (Jc k (k * (τ + 1)) (Icc (1 : ℤ) N) : ℝ) ≤ (N : ℝ) ^ (2 * (k * (τ + 1))) := by
        have := Jc_le_card_pow (k := k) (k * (τ + 1)) (Icc (1 : ℤ) N)
        rw [Int.card_Icc, show ((N : ℤ) + 1 - 1).toNat = N by omega] at this
        exact_mod_cast this
      have hsplit : (N : ℝ) ^ (2 * (k * (τ + 1))) = (N : ℝ) ^ E * (N : ℝ) ^ (kap k - Del k (τ + 1)) := by
        rw [← Real.rpow_add hNpos, ← Real.rpow_natCast]
        congr 1; simp only [E, Eexp]; push_cast; ring
      have hx0 : 0 ≤ kap k - Del k (τ + 1) := by linarith [Del_le_kap k (τ + 1) hk]
      have hxk : kap k - Del k (τ + 1) ≤ (k : ℝ) ^ 2 := by
        linarith [kap_le_sq k hk, Del_nonneg k (τ + 1) hk]
      have hN0 : (N : ℝ) ≤ N0 k := by exact_mod_cast hsmall.le
      have hN01 : (1 : ℝ) ≤ N0 k := le_trans hNr hN0
      have hbound : (N : ℝ) ^ (kap k - Del k (τ + 1)) ≤ 2 ^ (24 * k ^ 4) := by
        calc (N : ℝ) ^ (kap k - Del k (τ + 1)) ≤ (N0 k : ℝ) ^ (kap k - Del k (τ + 1)) :=
              Real.rpow_le_rpow hNpos.le hN0 hx0
          _ ≤ (N0 k : ℝ) ^ ((k : ℝ) ^ 2) := Real.rpow_le_rpow_of_exponent_le hN01 hxk
          _ = (N0 k : ℝ) ^ (k ^ 2) := by
              rw [show ((k : ℝ)) ^ 2 = ((k ^ 2 : ℕ) : ℝ) by push_cast; ring, Real.rpow_natCast]
          _ ≤ 2 ^ (24 * k ^ 4) := N0_pow_le k hk
      calc (Jc k (k * (τ + 1)) (Icc (1 : ℤ) N) : ℝ) ≤ (N : ℝ) ^ (2 * (k * (τ + 1))) := htriv
        _ = (N : ℝ) ^ (kap k - Del k (τ + 1)) * (N : ℝ) ^ E := by rw [hsplit, mul_comm]
        _ ≤ Dv k (τ + 1) * (N : ℝ) ^ E :=
            mul_le_mul_of_nonneg_right (hbound.trans hDv1) (by positivity)
    · push_neg at hsmall
      have hN0r : (N0 k : ℝ) ≤ N := by exact_mod_cast hsmall
      set r : ℝ := (N : ℝ) ^ ((k : ℝ)⁻¹)
      have hr0 : 0 < r := Real.rpow_pos_of_pos hNpos _
      have hrk : r ^ k = N := Real.rpow_inv_natCast_pow hNpos.le (by omega)
      have hkkN0 : (k : ℝ) ^ k ≤ N0 k := by
        have : k ^ k ≤ N0 k := by
          unfold N0
          calc k ^ k ≤ (8 * k ^ 2) ^ k := Nat.pow_le_pow_left (by nlinarith) k
            _ ≤ (8 * k ^ 2) ^ (4 * k) := Nat.pow_le_pow_right (by positivity) (by omega)
            _ ≤ 16 * (8 * k ^ 2) ^ (4 * k) := Nat.le_mul_of_pos_left _ (by norm_num)
        exact_mod_cast this
      have hkr : (k : ℝ) ≤ r := by
        by_contra hlt; push_neg at hlt
        have : r ^ k < (k : ℝ) ^ k := pow_lt_pow_left₀ hlt hr0.le (by omega)
        rw [hrk] at this; linarith
      set m := ⌊r⌋₊
      have hkm : k ≤ m := Nat.le_floor hkr
      have hmr : (m : ℝ) ≤ r := Nat.floor_le hr0.le
      have hrm : r < m + 1 := Nat.lt_floor_add_one r
      obtain ⟨p, hpp, hmp, hp2m⟩ := Nat.exists_prime_lt_and_le_two_mul m (by omega)
      haveI : Fact p.Prime := ⟨hpp⟩
      have hkp : k < p := lt_of_le_of_lt hkm hmp
      have hrp : r ≤ p := by
        have : (m : ℝ) + 1 ≤ p := by exact_mod_cast hmp
        linarith
      have hp2r : (p : ℝ) ≤ 2 * r := by
        have : (p : ℝ) ≤ 2 * m := by exact_mod_cast hp2m
        linarith
      have hp0 : (0 : ℝ) < p := by exact_mod_cast hpp.pos
      have hNp : N < p ^ k := by
        have : (N : ℝ) < (p : ℝ) ^ k := by
          rw [← hrk]
          have hm1 : (m : ℝ) + 1 ≤ p := by exact_mod_cast hmp
          exact pow_lt_pow_left₀ (by linarith : r < (p : ℝ)) hr0.le (by omega)
        exact_mod_cast this
      have hr2 : (2 : ℝ) ≤ r := by
        have : (2 : ℝ) ≤ k := by exact_mod_cast hk2
        linarith
      have hpN : (p : ℝ) ≤ N := by
        rw [← hrk]
        calc (p : ℝ) ≤ 2 * r := hp2r
          _ ≤ r * r := by nlinarith
          _ = r ^ 2 := by ring
          _ ≤ r ^ k := pow_le_pow_right₀ (by linarith) hk2
      have hpNn : p ≤ N := by exact_mod_cast hpN
      have hp2 : 2 ≤ p := hpp.two_le
      set N1 := N / p + 1
      have hN1 : 1 ≤ N1 := Nat.le_add_left 1 _
      have hN1N : N1 < N := by
        have h1 : N / p ≤ N / 2 := Nat.div_le_div_left hp2 (by norm_num)
        have h2 : (16 : ℕ) ≤ N := by
          have : 16 ≤ N0 k := by
            unfold N0; apply Nat.le_mul_of_pos_right; positivity
          omega
        omega
      have hN1r : (N1 : ℝ) ≤ 2 * N / p := by
        have h1 : ((N / p : ℕ) : ℝ) ≤ (N : ℝ) / p := Nat.cast_div_le
        have h2 : (1 : ℝ) ≤ (N : ℝ) / p := by rw [le_div_iff₀ hp0]; linarith
        simp only [N1]; push_cast
        rw [show 2 * (N : ℝ) / p = (N : ℝ) / p + (N : ℝ) / p by ring]
        linarith
      have hN1pos : (0 : ℝ) < N1 := by exact_mod_cast hN1
      -- the step
      have hstep := vstep k p N (k * τ) hk2 hkp hN hNp
      rw [show k * τ + k = k * (τ + 1) by ring] at hstep
      -- bound both branches
      have hA := A_part k τ hk2 N p N1 _ hNr hp2r hp0 hN1pos hN1r (ih N1 hN1)
      have hB := B_part k τ hk2 N p N1 (Dv k (τ + 1)) _ hN0r hrp hN1pos hN1r
        (by unfold Dv; positivity) (ihN N1 hN1N hN1)
      rw [show k * τ + k = k * (τ + 1) by ring] at hB
      calc (Jc k (k * (τ + 1)) (Icc (1 : ℤ) N) : ℝ) ≤ _ := hstep
        _ ≤ max (Dv k (τ + 1) / 2 * (N : ℝ) ^ E) (Dv k (τ + 1) / 2 * (N : ℝ) ^ E) := by
            apply max_le_max
            · simpa [N1] using hA
            · simpa [N1] using hB
        _ ≤ Dv k (τ + 1) * (N : ℝ) ^ E := by
            rw [max_self]
            have : 0 ≤ Dv k (τ + 1) * (N : ℝ) ^ E := by unfold Dv; positivity
            linarith

end GoldB
