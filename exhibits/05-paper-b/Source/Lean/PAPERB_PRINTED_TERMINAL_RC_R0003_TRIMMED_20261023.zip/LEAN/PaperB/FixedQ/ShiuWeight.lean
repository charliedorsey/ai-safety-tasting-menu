import PaperB.FixedQ.SourceBridge
import PaperB.M4B.ShiuProgression

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def fixedQShiuPrimeFactor (p : ℕ) : ℝ :=
  if 5 ≤ p then 2 / ((p : ℝ) - 3) else 0

noncomputable def fixedQShiuWeightNat (q n : ℕ) : ℝ :=
  if n = 0 then 0
  else if Squarefree n ∧ n.Coprime (6 * q) then
    ∏ p ∈ n.primeFactors, fixedQShiuPrimeFactor p
  else 0

noncomputable def fixedQShiuWeight (q : ℕ) : ArithmeticFunction ℝ :=
  ⟨fixedQShiuWeightNat q, by simp [fixedQShiuWeightNat]⟩

@[simp] theorem fixedQShiuWeight_apply (q n : ℕ) :
    fixedQShiuWeight q n = fixedQShiuWeightNat q n := rfl

lemma fixedQShiuPrimeFactor_nonneg (p : ℕ) :
    0 ≤ fixedQShiuPrimeFactor p := by
  unfold fixedQShiuPrimeFactor
  by_cases hp : 5 ≤ p
  · rw [if_pos hp]
    have hpR : (5 : ℝ) ≤ (p : ℝ) := by exact_mod_cast hp
    have hden : (0 : ℝ) < (p : ℝ) - 3 := by linarith
    positivity
  · rw [if_neg hp]

lemma fixedQShiuPrimeFactor_le_one (p : ℕ) :
    fixedQShiuPrimeFactor p ≤ 1 := by
  unfold fixedQShiuPrimeFactor
  by_cases hp : 5 ≤ p
  · rw [if_pos hp]
    have hpR : (5 : ℝ) ≤ (p : ℝ) := by exact_mod_cast hp
    have hden : (0 : ℝ) < (p : ℝ) - 3 := by linarith
    apply (div_le_iff₀ hden).2
    linarith
  · rw [if_neg hp]
    norm_num

theorem fixedQShiuWeight_multiplicative (q : ℕ) :
    (fixedQShiuWeight q).IsMultiplicative := by
  constructor
  · change fixedQShiuWeightNat q 1 = 1
    simp [fixedQShiuWeightNat]
  · intro m n hcop
    change fixedQShiuWeightNat q (m * n) =
      fixedQShiuWeightNat q m * fixedQShiuWeightNat q n
    by_cases hm0 : m = 0
    · subst m
      have hn1 : n = 1 := by simpa using hcop
      subst n
      simp [fixedQShiuWeightNat]
    · by_cases hn0 : n = 0
      · subst n
        have hm1 : m = 1 := by simpa using hcop
        subst m
        simp [fixedQShiuWeightNat]
      · have hmn0 : m * n ≠ 0 := mul_ne_zero hm0 hn0
        have hsq := Nat.squarefree_mul hcop
        have hunit : (m * n).Coprime (6 * q) ↔
            m.Coprime (6 * q) ∧ n.Coprime (6 * q) :=
          Nat.coprime_mul_iff_left
        have hpf : (m * n).primeFactors =
            m.primeFactors ∪ n.primeFactors :=
          Nat.primeFactors_mul hm0 hn0
        have hdisj : Disjoint m.primeFactors n.primeFactors := by
          rw [Finset.disjoint_left]
          intro p hpm hpn
          have hpd : p ∣ m.gcd n :=
            Nat.dvd_gcd (Nat.dvd_of_mem_primeFactors hpm)
              (Nat.dvd_of_mem_primeFactors hpn)
          rw [hcop.gcd_eq_one] at hpd
          exact (Nat.prime_of_mem_primeFactors hpm).not_dvd_one hpd
        by_cases hm : Squarefree m ∧ m.Coprime (6 * q)
        · by_cases hn : Squarefree n ∧ n.Coprime (6 * q)
          · have hmn : Squarefree (m * n) ∧ (m * n).Coprime (6 * q) :=
              ⟨hsq.mpr ⟨hm.1, hn.1⟩, hunit.mpr ⟨hm.2, hn.2⟩⟩
            rw [fixedQShiuWeightNat, if_neg hmn0, if_pos hmn,
              fixedQShiuWeightNat, if_neg hm0, if_pos hm,
              fixedQShiuWeightNat, if_neg hn0, if_pos hn, hpf,
              Finset.prod_union hdisj]
          · have hmn : ¬ (Squarefree (m * n) ∧
                (m * n).Coprime (6 * q)) := by
              intro h
              apply hn
              exact ⟨(hsq.mp h.1).2, (hunit.mp h.2).2⟩
            rw [fixedQShiuWeightNat, if_neg hmn0, if_neg hmn,
              fixedQShiuWeightNat, if_neg hm0, if_pos hm,
              fixedQShiuWeightNat, if_neg hn0, if_neg hn]
            ring
        · have hmn : ¬ (Squarefree (m * n) ∧
              (m * n).Coprime (6 * q)) := by
            intro h
            apply hm
            exact ⟨(hsq.mp h.1).1, (hunit.mp h.2).1⟩
          rw [fixedQShiuWeightNat, if_neg hmn0, if_neg hmn,
            fixedQShiuWeightNat, if_neg hm0, if_neg hm]
          ring

lemma prod_fixedQShiuPrimeFactor_le_one (s : Finset ℕ) :
    (∏ p ∈ s, fixedQShiuPrimeFactor p) ≤ 1 := by
  induction s using Finset.induction_on with
  | empty =>
      simp
  | @insert a s ha ih =>
      rw [Finset.prod_insert ha]
      have ha0 : 0 ≤ fixedQShiuPrimeFactor a :=
        fixedQShiuPrimeFactor_nonneg a
      have ha1 : fixedQShiuPrimeFactor a ≤ 1 :=
        fixedQShiuPrimeFactor_le_one a
      have hs0 : 0 ≤ ∏ p ∈ s, fixedQShiuPrimeFactor p :=
        Finset.prod_nonneg fun p hp => fixedQShiuPrimeFactor_nonneg p
      nlinarith

theorem fixedQShiuWeight_nonneg (q n : ℕ) :
    0 ≤ fixedQShiuWeight q n := by
  rw [fixedQShiuWeight_apply, fixedQShiuWeightNat]
  split_ifs
  · norm_num
  · exact Finset.prod_nonneg fun p hp => fixedQShiuPrimeFactor_nonneg p
  · norm_num

theorem fixedQShiuWeight_le_one (q n : ℕ) :
    fixedQShiuWeight q n ≤ 1 := by
  rw [fixedQShiuWeight_apply, fixedQShiuWeightNat]
  split_ifs
  · norm_num
  · exact prod_fixedQShiuPrimeFactor_le_one n.primeFactors
  · norm_num

theorem fixedQShiuWeight_squarefree_support (q n : ℕ)
    (hn : ¬ Squarefree n) :
    fixedQShiuWeight q n = 0 := by
  rw [fixedQShiuWeight_apply, fixedQShiuWeightNat]
  by_cases hn0 : n = 0
  · rw [if_pos hn0]
  · rw [if_neg hn0]
    simp [hn]

theorem fixedQShiuWeight_prime_le (q p : ℕ) (_hp : p.Prime) :
    fixedQShiuWeight q p ≤ 1 :=
  fixedQShiuWeight_le_one q p

theorem fixedQShiuWeight_growth (q n : ℕ) :
    fixedQShiuWeight q n ≤
      (n : ℝ) ^ (1 / 1280 : ℝ) := by
  by_cases hn0 : n = 0
  · subst n
    simp [fixedQShiuWeightNat]
  · have hn1 : (1 : ℝ) ≤ n := by
      exact_mod_cast (Nat.one_le_iff_ne_zero.mpr hn0)
    have hr : (1 : ℝ) ≤ (n : ℝ) ^ (1 / 1280 : ℝ) := by
      exact Real.one_le_rpow hn1 (by norm_num)
    exact (fixedQShiuWeight_le_one q n).trans hr

theorem fixedQShiuWeight_envelope (q : ℕ) :
    PaperB.M4B.FixedQuarterEnvelope (fixedQShiuWeight q) 1 1 := by
  refine ⟨fixedQShiuWeight_multiplicative q,
    fixedQShiuWeight_nonneg q,
    fixedQShiuWeight_squarefree_support q,
    fixedQShiuWeight_prime_le q,
    by norm_num, by norm_num, ?_⟩
  intro n
  simpa using fixedQShiuWeight_growth q n

theorem fixedQShiu_progression (q : ℕ) :
    ∃ C : ℝ, ∃ X0 : ℕ, ∀ x y k a : ℕ,
      X0 ≤ x →
      (x : ℝ) ^ (1 / 4 : ℝ) < (y : ℝ) →
      y ≤ x →
      (k : ℝ) < (y : ℝ) ^ (3 / 4 : ℝ) →
      0 < a → a < k → a.Coprime k →
      PaperB.M4B.progressionSum (fixedQShiuWeight q) x y k a ≤
        C * ((y : ℝ) / ((k.totient : ℝ) * Real.log (x : ℝ))) *
          Real.exp (PaperB.M4B.primeMass (fixedQShiuWeight q) x k) :=
  PaperB.M4B.shiuFixedQuarter_progression (fixedQShiuWeight_envelope q)

#print axioms fixedQShiuWeight_envelope
#print axioms fixedQShiu_progression

end PaperB.FixedQ
