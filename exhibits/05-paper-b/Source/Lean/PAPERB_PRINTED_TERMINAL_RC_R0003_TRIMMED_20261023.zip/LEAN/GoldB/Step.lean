import GoldB.Congruence
import GoldB.RealAux

/-!
# GoldB.Step — the p-adic step of Vinogradov's mean value theorem

For `k ≥ 2`, a prime `p > k`, `1 ≤ N < p^k`, `T = s + k`, with `A = [1,N]` and
`N₁ = ⌊N/p⌋ + 1`:

`J_{T,k}(A) ≤ max (4 p^{2s} N^k k! p^{k(k-1)/2} J_{s,k}(N₁)) ((2k²p)^T J_{T,k}(N₁))`.

The well-conditioned part uses the congruence counting lemma; the ill-conditioned
part is bounded with Hölder on the finite grid.
-/

open Finset Complex

namespace GoldB

/-- residue class mod `p` of a finset of integers -/
def resc (A : Finset ℤ) (p h : ℕ) : Finset ℤ := A.filter fun x => (x % (p : ℤ)).toNat = h

lemma resc_emod {A : Finset ℤ} {p h : ℕ} (hp : 0 < p) {x : ℤ} (hx : x ∈ resc A p h) :
    x % (p : ℤ) = h := by
  have h1 := (mem_filter.mp hx).2
  have h2 : 0 ≤ x % (p : ℤ) := Int.emod_nonneg _ (by exact_mod_cast hp.ne')
  rw [← h1]; exact (Int.toNat_of_nonneg h2).symm

lemma resc_eq {A : Finset ℤ} {p h : ℕ} (hp : 0 < p) {x : ℤ} (hx : x ∈ resc A p h) :
    x + -(h : ℤ) = p * (x / p) := by
  have h3 := resc_emod hp hx
  have := Int.emod_add_mul_ediv x p
  linarith

lemma sum_resc {β : Type*} [AddCommMonoid β] (A : Finset ℤ) (p : ℕ) (hp : 0 < p)
    (g : ℤ → β) : ∑ x ∈ A, g x = ∑ h ∈ range p, ∑ x ∈ resc A p h, g x := by
  unfold resc
  rw [Finset.sum_fiberwise_of_maps_to]
  intro x _
  rw [mem_range]
  have hpz : (0 : ℤ) < p := by exact_mod_cast hp
  have h1 := Int.emod_nonneg x hpz.ne'
  have h2 := Int.emod_lt_of_pos x hpz
  omega

lemma Jc_resc_le (k n p h N : ℕ) (hp : 0 < p) :
    Jc k n (resc (Icc (1 : ℤ) N) p h) ≤ Jc k n (Icc (1 : ℤ) ((N / p + 1 : ℕ) : ℤ)) := by
  have hpz : (0 : ℤ) < p := by exact_mod_cast hp
  have hsub : resc (Icc (1 : ℤ) N) p h ⊆
      (Icc (0 : ℤ) ((N / p : ℕ) : ℤ)).image fun b => (h : ℤ) + p * b := by
    intro x hx
    have hx1 := mem_Icc.mp (mem_filter.mp hx).1
    rw [mem_image]
    refine ⟨x / p, ?_, ?_⟩
    · rw [mem_Icc]
      constructor
      · exact Int.ediv_nonneg (by omega) hpz.le
      · rw [Int.natCast_div]; exact Int.ediv_le_ediv hpz hx1.2
    · have := resc_eq hp hx; linarith
  calc Jc k n (resc (Icc (1 : ℤ) N) p h)
      ≤ Jc k n ((Icc (0 : ℤ) ((N / p : ℕ) : ℤ)).image fun b => (h : ℤ) + p * b) :=
        Jc_mono n hsub
    _ = Jc k n (Icc (0 : ℤ) ((N / p : ℕ) : ℤ)) := Jc_affine n _ _ _ (by omega)
    _ ≤ Jc k n (Icc (1 : ℤ) ((N / p + 1 : ℕ) : ℤ)) := by
        apply Jc_le_of_subset_interval n _ 0
        intro a ha; rw [mem_Icc] at ha; push_cast; omega

/-- power sums of tuples from `[1,N]` lie in `[0, n N^k]` -/
lemma psv_range {k n N : ℕ} (hN : 1 ≤ N) (x : Fin n → ℤ) (hx : ∀ i, x i ∈ Icc (1 : ℤ) N)
    (j : Fin k) : 0 ≤ psv k x j ∧ psv k x j ≤ n * (N : ℤ) ^ k := by
  unfold psv
  constructor
  · exact Finset.sum_nonneg (fun i _ => by have := (mem_Icc.mp (hx i)).1; positivity)
  · calc ∑ i, x i ^ ((j : ℕ) + 1) ≤ ∑ _i : Fin n, (N : ℤ) ^ k := by
          apply Finset.sum_le_sum; intro i _
          have hi := mem_Icc.mp (hx i)
          calc x i ^ ((j : ℕ) + 1) ≤ (N : ℤ) ^ ((j : ℕ) + 1) :=
                pow_le_pow_left₀ (by omega) hi.2 _
            _ ≤ (N : ℤ) ^ k := pow_le_pow_right₀ (by exact_mod_cast hN) (by omega)
      _ = n * (N : ℤ) ^ k := by simp

lemma psv_shift_append {k m n : ℕ} (x : Fin m → ℤ) (u : Fin n → ℤ) (c : ℤ) :
    psv k (fun i => Fin.append x u i + c) = psv k (fun i => x i + c) + psv k (fun i => u i + c) := by
  ext j; simp [psv, Fin.sum_univ_add]

/-- well-conditioned tuples -/
def wcd (p : ℕ) {k : ℕ} (x : Fin k → ℤ) : Prop := ∀ i i', i ≠ i' → ¬ ((p : ℤ) ∣ x i - x i')

instance (p : ℕ) {k : ℕ} (x : Fin k → ℤ) : Decidable (wcd p x) := by unfold wcd; infer_instance

/-- the well-conditioned count -/
theorem NW_le (k p N s h : ℕ) [hp : Fact p.Prime] (hk : k < p) (hNp : N < p ^ k)
    (hN : 1 ≤ N) :
    let A := Icc (1 : ℤ) N
    let W := (tup k A).filter (wcd p)
    (((W ×ˢ tup s (resc A p h)) ×ˢ (W ×ˢ tup s (resc A p h))).filter fun q =>
        psv k q.1.1 + psv k q.1.2 = psv k q.2.1 + psv k q.2.2).card ≤
      N ^ k * (k.factorial * p ^ (k * (k - 1) / 2)) *
        Jc k s (Icc (1 : ℤ) ((N / p + 1 : ℕ) : ℤ)) := by
  classical
  intro A W
  have hp0 : 0 < p := hp.out.pos
  set B := resc A p h
  set S := ((W ×ˢ tup s B) ×ˢ (W ×ˢ tup s B)).filter fun q =>
        psv k q.1.1 + psv k q.1.2 = psv k q.2.1 + psv k q.2.2
  set cong : (Fin k → ℤ) × (Fin k → ℤ) → Prop := fun xy => ∀ j : Fin k,
    (p : ℤ) ^ ((j : ℕ) + 1) ∣ psv k (fun i => xy.1 i - h) j - psv k (fun i => xy.2 i - h) j
  set J1 := Jc k s B
  -- fibres over (x, y)
  have hfib : ∀ xy ∈ W ×ˢ W,
      (S.filter fun q => (q.1.1, q.2.1) = xy).card ≤ if cong xy then J1 else 0 := by
    intro xy hxy
    split_ifs with hc
    · -- inject into the representation set
      calc (S.filter fun q => (q.1.1, q.2.1) = xy).card ≤ Rc k s B (psv k xy.2 - psv k xy.1) := by
            unfold Rc
            apply card_le_card_of_injOn (fun q => (q.1.2, q.2.2))
            · intro q hq
              simp only [coe_filter, Set.mem_setOf_eq, S, mem_filter, mem_product, Finset.mem_coe] at hq
              simp only [Finset.mem_coe, mem_filter, mem_product]
              obtain ⟨⟨⟨⟨_, hu⟩, ⟨_, hv⟩⟩, heq⟩, hq2⟩ := hq
              refine ⟨⟨hu, hv⟩, ?_⟩
              rw [← hq2]
              rw [show psv k q.2.2 + (psv k q.2.1 - psv k q.1.1) =
                psv k q.2.1 + psv k q.2.2 - psv k q.1.1 by ring, ← heq]; ring
            · intro q1 hq1 q2 hq2 he
              simp only [coe_filter, Set.mem_setOf_eq, S, mem_filter, Finset.mem_coe] at hq1 hq2
              obtain ⟨_, h1⟩ := hq1
              obtain ⟨_, h2⟩ := hq2
              have h12 := h1.trans h2.symm
              simp only [Prod.mk.injEq] at he h12
              ext <;> simp_all
        _ ≤ J1 := Rc_le_Jc s B _
    · -- no fibre
      rw [Nat.le_zero, card_eq_zero, filter_eq_empty_iff]
      intro q hq hqe
      apply hc
      simp only [S, mem_filter, mem_product] at hq
      obtain ⟨⟨⟨_, hu⟩, ⟨_, hv⟩⟩, heq⟩ := hq
      rw [← hqe]
      intro j
      -- shift the full equation by -h
      have happ : psv k (Fin.append q.1.1 q.1.2) = psv k (Fin.append q.2.1 q.2.2) := by
        rw [psv_append, psv_append, heq]
      have hs := psv_shift (k := k) _ _ (-(h : ℤ)) happ
      rw [psv_shift_append, psv_shift_append] at hs
      have hu' : (fun i => q.1.2 i + -(h : ℤ)) = fun i => (p : ℤ) * (q.1.2 i / p) := by
        ext i; exact resc_eq hp0 (Fintype.mem_piFinset.mp hu i)
      have hv' : (fun i => q.2.2 i + -(h : ℤ)) = fun i => (p : ℤ) * (q.2.2 i / p) := by
        ext i; exact resc_eq hp0 (Fintype.mem_piFinset.mp hv i)
      rw [hu', hv'] at hs
      have hj := congrFun hs j
      simp only [Pi.add_apply] at hj
      rw [psv_smul, psv_smul] at hj
      refine ⟨psv k (fun i => q.2.2 i / p) j - psv k (fun i => q.1.2 i / p) j, ?_⟩
      simp only [sub_eq_add_neg] at hj ⊢
      linear_combination hj
  -- sum over fibres
  have hS : S.card ≤ ((W ×ˢ W).filter cong).card * J1 := by
    rw [card_eq_sum_card_fiberwise (f := fun q => (q.1.1, q.2.1)) (t := W ×ˢ W)]
    · calc ∑ xy ∈ W ×ˢ W, (S.filter fun q => (q.1.1, q.2.1) = xy).card
          ≤ ∑ xy ∈ W ×ˢ W, if cong xy then J1 else 0 := sum_le_sum hfib
        _ = ((W ×ˢ W).filter cong).card * J1 := by rw [← sum_filter]; simp
    · intro q hq
      simp only [S, Finset.mem_coe, mem_filter, mem_product] at hq
      exact Finset.mem_coe.mpr (mem_product.mpr ⟨hq.1.1.1, hq.1.2.1⟩)
  -- count congruent pairs with the congruence lemma
  have hA : ∀ a ∈ A, ∀ b ∈ A, |a - b| < (p : ℤ) ^ k := by
    intro a ha b hb
    rw [mem_Icc] at ha hb
    have : (N : ℤ) < (p : ℤ) ^ k := by exact_mod_cast hNp
    rw [abs_lt]; constructor <;> omega
  have hpairs : ((W ×ˢ W).filter cong).card ≤ N ^ k * (k.factorial * p ^ (k * (k - 1) / 2)) := by
    rw [card_eq_sum_card_fiberwise (f := fun xy => xy.2) (t := W)]
    · calc ∑ y ∈ W, (((W ×ˢ W).filter cong).filter fun xy => xy.2 = y).card
          ≤ ∑ _y ∈ W, k.factorial * p ^ (k * (k - 1) / 2) := by
            apply sum_le_sum; intro y _
            calc (((W ×ˢ W).filter cong).filter fun xy => xy.2 = y).card
                ≤ ((tup k A).filter (fun x => (∀ i i', i ≠ i' → ¬ ((p : ℤ) ∣ x i - x i')) ∧
                    ∀ j : Fin k, (p : ℤ) ^ ((j : ℕ) + 1) ∣
                      psv k (fun i => x i - h) j - psv k (fun i => y i - h) j)).card := by
                  apply card_le_card_of_injOn (fun xy => xy.1)
                  · intro xy hxy
                    simp only [coe_filter, mem_filter, mem_product, Set.mem_setOf_eq,
                      Finset.mem_coe] at hxy
                    obtain ⟨⟨⟨hx, _⟩, hc⟩, he⟩ := hxy
                    simp only [W, mem_filter] at hx
                    simp only [Finset.mem_coe, mem_filter]
                    refine ⟨hx.1, hx.2, ?_⟩
                    rw [← he]; exact hc
                  · intro a ha b hb hab
                    simp only [coe_filter, mem_filter, Set.mem_setOf_eq, Finset.mem_coe] at ha hb
                    exact Prod.ext hab (ha.2.trans hb.2.symm)
              _ ≤ k.factorial * p ^ (k * (k - 1) / 2) :=
                  cong_count p k hk A hA h (psv k fun i => y i - h)
        _ = W.card * (k.factorial * p ^ (k * (k - 1) / 2)) := by rw [sum_const, smul_eq_mul]
        _ ≤ N ^ k * (k.factorial * p ^ (k * (k - 1) / 2)) := by
            apply Nat.mul_le_mul_right
            calc W.card ≤ (tup k A).card := card_filter_le _ _
              _ = N ^ k := by rw [card_tup]; simp [A]
    · intro xy hxy
      exact (mem_product.mp (mem_filter.mp hxy).1).2
  have hJ1 : J1 ≤ Jc k s (Icc (1 : ℤ) ((N / p + 1 : ℕ) : ℤ)) := Jc_resc_le k s p h N hp0
  calc S.card ≤ ((W ×ˢ W).filter cong).card * J1 := hS
    _ ≤ (N ^ k * (k.factorial * p ^ (k * (k - 1) / 2))) *
          Jc k s (Icc (1 : ℤ) ((N / p + 1 : ℕ) : ℤ)) := Nat.mul_le_mul hpairs hJ1

end GoldB
