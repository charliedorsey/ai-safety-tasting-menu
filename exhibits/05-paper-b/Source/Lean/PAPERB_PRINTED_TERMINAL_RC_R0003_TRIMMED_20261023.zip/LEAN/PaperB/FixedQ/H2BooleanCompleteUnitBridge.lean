import PaperB.FixedQ.H2BooleanGenericLocalMoment
import PaperB.FixedQ.H2BooleanUnitCRT

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def h2BooleanPrimeComponentAddChar
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (q : S) : AddChar (ZMod (q : ℕ)) ℂ := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  exact (ZMod.stdAddChar (N := primeSetProduct S)).compAddMonoidHom
    (h2BooleanPrimeComponentEmbedding S hPrime q)

lemma h2BooleanPrimeComponentAddChar_ne_one
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (q : S) :
    h2BooleanPrimeComponentAddChar S hPrime q ≠ 1 := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  letI : NeZero (q : ℕ) := ⟨(hPrime q q.property).ne_zero⟩
  intro h
  have hfun := congr_fun (congr_arg (↑) h) (1 : ZMod (q : ℕ))
  have hval :
      ZMod.stdAddChar
        (h2BooleanPrimeBasis S q.1 :
          ZMod (primeSetProduct S)) = 1 := by
    simpa [h2BooleanPrimeComponentAddChar,
      h2BooleanPrimeComponentEmbedding_one] using hfun
  have hbasis0 :
      (h2BooleanPrimeBasis S q.1 :
        ZMod (primeSetProduct S)) = 0 := by
    apply ZMod.injective_stdAddChar
    simpa using hval
  have hcoord := congrArg
    (fun x : ZMod (primeSetProduct S) =>
      h2BooleanRingCRTEquiv S hPrime x q) hbasis0
  rw [h2BooleanRingCRTEquiv_primeBasis_self S hPrime q.property] at hcoord
  have h10 : (1 : ZMod (q : ℕ)) ≠ 0 := by
    intro h10
    exact (hPrime q q.property).ne_one (ZMod.one_eq_zero_iff.mp h10)
  exact h10 (by simpa using hcoord)

#print axioms h2BooleanPrimeComponentAddChar_ne_one


lemma h2Boolean_mul_primeBasis_eq_componentEmbedding
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (q : S) (x : ZMod (primeSetProduct S)) :
    x * (h2BooleanPrimeBasis S q.1 :
      ZMod (primeSetProduct S)) =
      h2BooleanPrimeComponentEmbedding S hPrime q
        (h2BooleanRingCRTEquiv S hPrime x q) := by
  apply (h2BooleanRingCRTEquiv S hPrime).injective
  ext r
  rw [map_mul]
  rw [h2BooleanRingCRTEquiv_primeBasis]
  by_cases hrq : r = q
  · subst r
    simp [h2BooleanPrimeComponentEmbedding]
  · have hrqv : r.1 ≠ q.1 := by
      intro h
      apply hrq
      exact Subtype.ext h
    simp [h2BooleanPrimeComponentEmbedding, Pi.single, hrq, hrqv]

lemma h2BooleanLocalFourierFactor_unitCRT
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (j : ℤ) (u : (ZMod (primeSetProduct S))ˣ) (q : S)
    [NeZero (q : ℕ)] :
    h2BooleanLocalFourierFactor S hPrime
      ((j : ZMod (primeSetProduct S)) * (u : ZMod (primeSetProduct S))) q.1 =
      h2BooleanGenericPrimeLocalFactor
        (h2BooleanPrimeComponentAddChar S hPrime q)
        (j : ZMod (q : ℕ))
        ((h2BooleanUnitsCRTEquiv S hPrime u) q) := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  letI : NeZero (q : ℕ) := ⟨(hPrime q q.property).ne_zero⟩
  unfold h2BooleanLocalFourierFactor
  unfold h2BooleanGenericPrimeLocalFactor
  unfold h2BooleanPrimeComponentAddChar
  congr 2
  apply congrArg ZMod.stdAddChar
  rw [h2Boolean_mul_primeBasis_eq_componentEmbedding S hPrime q]
  congr 1
  rw [map_mul]
  rw [map_intCast]
  rw [h2BooleanUnitsCRTEquiv_val]
  rfl

#print axioms h2Boolean_mul_primeBasis_eq_componentEmbedding
#print axioms h2BooleanLocalFourierFactor_unitCRT


theorem h2_completeUnitFourierSecondMoment
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (j : ℤ) :
    ((Fintype.card (ZMod (primeSetProduct S))ˣ : ℝ)⁻¹) *
      (∑ u : (ZMod (primeSetProduct S))ˣ,
        ‖fixedProductBooleanFourierCoeff S hPrime
          ((j : ZMod (primeSetProduct S)) *
            (u : ZMod (primeSetProduct S)))‖ ^ 2) =
      (PaperB.Boolean.booleanCRTSecondMoment S j : ℝ) := by
  classical
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  letI (q : S) : NeZero (q : ℕ) :=
    ⟨(hPrime q q.property).ne_zero⟩
  have hrow :
      ∀ u : (ZMod (primeSetProduct S))ˣ,
        ‖fixedProductBooleanFourierCoeff S hPrime
          ((j : ZMod (primeSetProduct S)) *
            (u : ZMod (primeSetProduct S)))‖ ^ 2 =
          ∏ q : S,
            ‖h2BooleanGenericPrimeLocalFactor
              (h2BooleanPrimeComponentAddChar S hPrime q)
              (j : ZMod (q : ℕ))
              ((h2BooleanUnitsCRTEquiv S hPrime u) q)‖ ^ 2 := by
    intro u
    rw [fixedProductBooleanFourierCoeff_eq_prod_local]
    rw [norm_prod]
    rw [← Finset.prod_pow]
    rw [← Finset.prod_coe_sort S
      (fun p : ℕ =>
        ‖h2BooleanLocalFourierFactor S hPrime
          ((j : ZMod (primeSetProduct S)) *
            (u : ZMod (primeSetProduct S))) p‖ ^ 2)]
    apply Fintype.prod_congr
    intro q
    rw [h2BooleanLocalFourierFactor_unitCRT S hPrime j u q]
  simp_rw [hrow]
  rw [h2Boolean_sum_units_prod_local S hPrime
    (fun q a =>
      ‖h2BooleanGenericPrimeLocalFactor
        (h2BooleanPrimeComponentAddChar S hPrime q)
        (j : ZMod (q : ℕ)) a‖ ^ 2)]
  have hcardNat :
      Fintype.card (ZMod (primeSetProduct S))ˣ =
        ∏ q : S, Fintype.card (ZMod (q : ℕ))ˣ := by
    calc
      Fintype.card (ZMod (primeSetProduct S))ˣ =
          Fintype.card (∀ q : S, (ZMod (q : ℕ))ˣ) :=
        Fintype.card_congr (h2BooleanUnitsCRTEquiv S hPrime).toEquiv
      _ = ∏ q : S, Fintype.card (ZMod (q : ℕ))ˣ := Fintype.card_pi
  have hcard :
      (Fintype.card (ZMod (primeSetProduct S))ˣ : ℝ) =
        ∏ q : S, (Fintype.card (ZMod (q : ℕ))ˣ : ℝ) := by
    exact_mod_cast hcardNat
  rw [hcard]
  rw [← Finset.prod_inv_distrib]
  rw [← Finset.prod_mul_distrib]
  have hlocal :
      ∀ q : S,
        ((Fintype.card (ZMod (q : ℕ))ˣ : ℝ)⁻¹) *
          (∑ a : (ZMod (q : ℕ))ˣ,
            ‖h2BooleanGenericPrimeLocalFactor
              (h2BooleanPrimeComponentAddChar S hPrime q)
              (j : ZMod (q : ℕ)) a‖ ^ 2) =
          (PaperB.Boolean.booleanLocalSecondMoment q.1 j : ℝ) := by
    intro q
    exact h2_average_genericPrimeLocalFactor_eq_m3
      (hPrime q q.property)
      (h2BooleanPrimeComponentAddChar S hPrime q)
      (h2BooleanPrimeComponentAddChar_ne_one S hPrime q)
      j
  simp_rw [hlocal]
  unfold PaperB.Boolean.booleanCRTSecondMoment
  rw [Finset.prod_coe_sort S
    (fun p : ℕ => (PaperB.Boolean.booleanLocalSecondMoment p j : ℝ))]
  push_cast
  rfl

#print axioms h2_completeUnitFourierSecondMoment

end PaperB.FixedQ
