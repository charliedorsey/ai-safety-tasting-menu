import GoldB.Step

/-!
# GoldB.StepMain — assembling the p-adic step
-/

open Finset Complex

namespace GoldB

/-- the exponential sums of the step, at grid size `M` -/
noncomputable def fS (k M : ℕ) (A : Finset ℤ) (a : Fin k → Fin M) : ℂ := esum M A (pw k) a

lemma grid_bound_aux {k N : ℕ} (hN : 1 ≤ N) (M T : ℕ) (hM : T * N ^ k < M)
    {α : Type*} (X : Finset α) (φ : α → Fin k → ℤ)
    (hφ : ∀ x ∈ X, ∀ j, 0 ≤ φ x j ∧ φ x j ≤ T * (N : ℤ) ^ k) :
    ∀ x ∈ X, ∀ y ∈ X, ∀ j, |φ x j - φ y j| < M := by
  intro x hx y hy j
  have h1 := hφ x hx j
  have h2 := hφ y hy j
  have : (T : ℤ) * (N : ℤ) ^ k < M := by exact_mod_cast hM
  rw [abs_lt]; constructor <;> linarith [h1.1, h1.2, h2.1, h2.2]

/-- range of the combined phase on `tup k A' × tup s A''` with entries in `[1,N]` -/
lemma phase_range {k N : ℕ} (hN : 1 ≤ N) (m s : ℕ) (X : Finset ((Fin m → ℤ) × (Fin s → ℤ)))
    (hX : ∀ q ∈ X, (∀ i, q.1 i ∈ Icc (1 : ℤ) N) ∧ (∀ i, q.2 i ∈ Icc (1 : ℤ) N)) :
    ∀ q ∈ X, ∀ j : Fin k, 0 ≤ (psv k q.1 + psv k q.2) j ∧
      (psv k q.1 + psv k q.2) j ≤ ((s + m : ℕ) : ℤ) * (N : ℤ) ^ k := by
  intro q hq j
  have h1 := psv_range hN q.1 (hX q hq).1 j
  have h2 := psv_range hN q.2 (hX q hq).2 j
  simp only [Pi.add_apply]
  push_cast
  constructor <;> nlinarith

lemma norm_sq_add_le (a b : ℂ) : ‖a + b‖ ^ 2 ≤ 2 * (‖a‖ ^ 2 + ‖b‖ ^ 2) := by
  have := norm_add_le a b
  have h2 : ‖a + b‖ ^ 2 ≤ (‖a‖ + ‖b‖) ^ 2 := pow_le_pow_left₀ (norm_nonneg _) this 2
  nlinarith [norm_nonneg a, norm_nonneg b, sq_nonneg (‖a‖ - ‖b‖)]

/-- the ill-conditioned count, bounded on the grid -/
theorem NI_grid_le (k p N s : ℕ) [hp : Fact p.Prime] (hk2 : 2 ≤ k) (hN : 1 ≤ N) (M : ℕ)
    (hM : (s + k) * N ^ k < M) :
    let A := Icc (1 : ℤ) N
    let I := (tup k A).filter fun x => ¬ wcd p x
    (M : ℝ) ^ k * ((((I ×ˢ tup s A) ×ˢ (I ×ˢ tup s A)).filter fun q =>
        psv k q.1.1 + psv k q.1.2 = psv k q.2.1 + psv k q.2.2).card : ℝ) ≤
      ((k : ℝ) ^ 4 * p) * ∑ h ∈ range p, ∑ a : Fin k → Fin M,
        ‖fS k M (resc A p h) a‖ ^ 4 * ‖fS k M A a‖ ^ (2 * (s + k) - 4) := by
  classical
  intro A I
  have hp0 : 0 < p := hp.out.pos
  have hM0 : 0 < M := lt_of_le_of_lt (Nat.zero_le _) hM
  set pairs : Finset (Fin k × Fin k) := univ.filter fun ii => ii.1 ≠ ii.2
  set Ei := pairs ×ˢ range p
  let Ef : (Fin k × Fin k) × ℕ → Finset (Fin k → ℤ) := fun e =>
    Fintype.piFinset fun m => if m = e.1.1 ∨ m = e.1.2 then resc A p e.2 else A
  let φ : (Fin k → ℤ) × (Fin s → ℤ) → Fin k → ℤ := fun q => psv k q.1 + psv k q.2
  have hEf_sub : ∀ e, ∀ x ∈ Ef e, ∀ i, x i ∈ A := by
    intro e x hx i
    have := Fintype.mem_piFinset.mp hx i
    split_ifs at this
    · exact (mem_filter.mp this).1
    · exact this
  -- covering
  have hcover : I ⊆ Ei.biUnion Ef := by
    intro x hx
    rw [mem_filter] at hx
    obtain ⟨hxA, hnw⟩ := hx
    unfold wcd at hnw
    push_neg at hnw
    obtain ⟨i, i', hne, hd⟩ := hnw
    rw [mem_biUnion]
    refine ⟨((i, i'), (x i % (p : ℤ)).toNat), ?_, ?_⟩
    · rw [mem_product, mem_range]
      refine ⟨by simp [pairs, hne], ?_⟩
      have hpz : (0 : ℤ) < p := by exact_mod_cast hp0
      have h1 := Int.emod_nonneg (x i) hpz.ne'
      have h2 := Int.emod_lt_of_pos (x i) hpz
      omega
    · rw [Fintype.mem_piFinset]
      intro m
      have hxm := Fintype.mem_piFinset.mp hxA m
      split_ifs with hm
      · rw [resc, mem_filter]
        refine ⟨hxm, ?_⟩
        rcases hm with hm | hm
        · rw [hm]
        · rw [hm]
          congr 1
          apply Int.emod_eq_emod_iff_emod_sub_eq_zero.mpr
          apply Int.emod_eq_zero_of_dvd
          have : (p : ℤ) ∣ -(x i - x i') := dvd_neg.mpr hd
          simpa using this
      · exact hxm
  -- count subadditivity
  set NIset := ((I ×ˢ tup s A) ×ˢ (I ×ˢ tup s A)).filter fun q => φ q.1 = φ q.2
  set Pset : (Fin k × Fin k) × ℕ → (Fin k × Fin k) × ℕ → Finset _ := fun e e' =>
    ((Ef e ×ˢ tup s A) ×ˢ (Ef e' ×ˢ tup s A)).filter fun q => φ q.1 = φ q.2
  have hsubadd : (NIset.card : ℝ) ≤ ∑ e ∈ Ei, ∑ e' ∈ Ei, ((Pset e e').card : ℝ) := by
    have : NIset ⊆ (Ei ×ˢ Ei).biUnion fun ee => Pset ee.1 ee.2 := by
      intro q hq
      simp only [NIset, mem_filter, mem_product] at hq
      obtain ⟨⟨⟨hq1, hq2⟩, ⟨hq3, hq4⟩⟩, heq⟩ := hq
      obtain ⟨e, he, hxe⟩ := mem_biUnion.mp (hcover hq1)
      obtain ⟨e', he', hxe'⟩ := mem_biUnion.mp (hcover hq3)
      rw [mem_biUnion]
      exact ⟨(e, e'), mem_product.mpr ⟨he, he'⟩, by
        simp only [Pset, mem_filter, mem_product]; exact ⟨⟨⟨hxe, hq2⟩, ⟨hxe', hq4⟩⟩, heq⟩⟩
    calc (NIset.card : ℝ) ≤ (((Ei ×ˢ Ei).biUnion fun ee => Pset ee.1 ee.2).card : ℝ) := by
          exact_mod_cast card_le_card this
      _ ≤ ∑ ee ∈ Ei ×ˢ Ei, ((Pset ee.1 ee.2).card : ℝ) := by exact_mod_cast card_biUnion_le
      _ = ∑ e ∈ Ei, ∑ e' ∈ Ei, ((Pset e e').card : ℝ) := by rw [sum_product]
  -- each piece on the grid
  set f := fS k M A
  set gE : (Fin k × Fin k) × ℕ → (Fin k → Fin M) → ℂ := fun e a => esum M (Ef e) (psv k) a
  have hrange : ∀ e, ∀ q ∈ Ef e ×ˢ tup s A, ∀ j : Fin k, 0 ≤ φ q j ∧
      φ q j ≤ ((s + k : ℕ) : ℤ) * (N : ℤ) ^ k := by
    intro e
    apply phase_range hN k s
    intro q hq
    rw [mem_product] at hq
    exact ⟨hEf_sub e q.1 hq.1, fun i => Fintype.mem_piFinset.mp hq.2 i⟩
  have hpiece : ∀ e e', (M : ℝ) ^ k * ((Pset e e').card : ℝ) ≤
      ∑ a : Fin k → Fin M, ‖gE e a‖ * ‖gE e' a‖ * ‖f a‖ ^ (2 * s) := by
    intro e e'
    have hb : ∀ x ∈ Ef e ×ˢ tup s A, ∀ y ∈ Ef e' ×ˢ tup s A, ∀ j, |φ x j - φ y j| < M := by
      intro x hx y hy j
      have h1 := hrange e x hx j
      have h2 := hrange e' y hy j
      have : ((s + k : ℕ) : ℤ) * (N : ℤ) ^ k < M := by exact_mod_cast hM
      rw [abs_lt]; constructor <;> linarith [h1.1, h1.2, h2.1, h2.2]
    have hg := grid_count M hM0 (Ef e ×ˢ tup s A) (Ef e' ×ˢ tup s A) φ φ hb
    have hprod : ∀ e'' a, esum M (Ef e'' ×ˢ tup s A) φ a = gE e'' a * f a ^ s := by
      intro e'' a
      rw [esum_product M (Ef e'') (tup s A) (psv k) (psv k) a, esum_tup]
      rfl
    simp_rw [hprod] at hg
    have := congrArg norm hg
    rw [norm_mul, norm_pow, Complex.norm_natCast, Complex.norm_natCast] at this
    calc (M : ℝ) ^ k * ((Pset e e').card : ℝ) =
          ‖∑ a : Fin k → Fin M, gE e a * f a ^ s * (starRingEnd ℂ) (gE e' a * f a ^ s)‖ := by
            rw [this]
      _ ≤ ∑ a : Fin k → Fin M, ‖gE e a * f a ^ s * (starRingEnd ℂ) (gE e' a * f a ^ s)‖ :=
          norm_sum_le _ _
      _ = ∑ a : Fin k → Fin M, ‖gE e a‖ * ‖gE e' a‖ * ‖f a‖ ^ (2 * s) := by
          apply sum_congr rfl; intro a _
          rw [norm_mul, Complex.norm_conj, norm_mul, norm_mul, norm_pow]; ring
  -- norm of a pair-restricted sum
  have hgE : ∀ e ∈ Ei, ∀ a, ‖gE e a‖ ≤ ‖fS k M (resc A p e.2) a‖ ^ 2 * ‖f a‖ ^ (k - 2) := by
    intro e he a
    have hne : e.1.1 ≠ e.1.2 := by
      simp only [Ei, pairs, mem_product, mem_filter] at he; exact he.1.2
    simp only [gE, Ef]
    rw [esum_pi, norm_prod]
    have hite : ∀ b : Fin k,
        ‖esum M (if b = e.1.1 ∨ b = e.1.2 then resc A p e.2 else A) (pw k) a‖ =
          if b = e.1.1 ∨ b = e.1.2 then ‖esum M (resc A p e.2) (pw k) a‖
          else ‖esum M A (pw k) a‖ := by
      intro b; split_ifs <;> rfl
    rw [Finset.prod_congr rfl (fun b _ => hite b), Finset.prod_ite]
    have hc1 : (univ.filter fun m : Fin k => m = e.1.1 ∨ m = e.1.2).card = 2 := by
      have : (univ.filter fun m : Fin k => m = e.1.1 ∨ m = e.1.2) = {e.1.1, e.1.2} := by
        ext m; simp
      rw [this, card_pair hne]
    have hc2 : (univ.filter fun m : Fin k => ¬ (m = e.1.1 ∨ m = e.1.2)).card = k - 2 := by
      have := card_filter_add_card_filter_not (s := (univ : Finset (Fin k)))
        (fun m : Fin k => m = e.1.1 ∨ m = e.1.2)
      rw [hc1, card_univ, Fintype.card_fin] at this
      omega
    rw [prod_const, prod_const, hc1, hc2]
    rfl
  have hpairs : (pairs.card : ℝ) ≤ (k : ℝ) ^ 2 := by
    have : pairs.card ≤ k ^ 2 := by
      calc pairs.card ≤ (univ : Finset (Fin k × Fin k)).card := card_filter_le _ _
        _ = k ^ 2 := by rw [card_univ, Fintype.card_prod, Fintype.card_fin, sq]
    exact_mod_cast this
  have hEi : (Ei.card : ℝ) = pairs.card * p := by
    simp [Ei, card_product, card_range]
  -- the pointwise estimate
  have hpt : ∀ a : Fin k → Fin M,
      (∑ e ∈ Ei, ∑ e' ∈ Ei, ‖gE e a‖ * ‖gE e' a‖ * ‖f a‖ ^ (2 * s)) ≤
        ((k : ℝ) ^ 4 * p) * ∑ h ∈ range p,
          ‖fS k M (resc A p h) a‖ ^ 4 * ‖f a‖ ^ (2 * (s + k) - 4) := by
    intro a
    have e1 : (∑ e ∈ Ei, ∑ e' ∈ Ei, ‖gE e a‖ * ‖gE e' a‖ * ‖f a‖ ^ (2 * s)) =
        (∑ e ∈ Ei, ‖gE e a‖) ^ 2 * ‖f a‖ ^ (2 * s) := by
      rw [sq, sum_mul_sum, sum_mul]
      apply sum_congr rfl; intro e _; rw [sum_mul]
    rw [e1]
    have h1 := sq_sum_le_card_mul_sum_sq (s := Ei) (f := fun e => ‖gE e a‖)
    have h2 : ∑ e ∈ Ei, ‖gE e a‖ ^ 2 ≤
        ∑ e ∈ Ei, ‖fS k M (resc A p e.2) a‖ ^ 4 * ‖f a‖ ^ (2 * k - 4) := by
      apply sum_le_sum; intro e he
      have := hgE e he a
      calc ‖gE e a‖ ^ 2 ≤ (‖fS k M (resc A p e.2) a‖ ^ 2 * ‖f a‖ ^ (k - 2)) ^ 2 :=
            pow_le_pow_left₀ (norm_nonneg _) this 2
        _ = ‖fS k M (resc A p e.2) a‖ ^ 4 * ‖f a‖ ^ (2 * k - 4) := by
            rw [mul_pow, ← pow_mul, ← pow_mul]
            congr 2; omega
    have h3 : ∑ e ∈ Ei, ‖fS k M (resc A p e.2) a‖ ^ 4 * ‖f a‖ ^ (2 * k - 4) =
        pairs.card * ∑ h ∈ range p, ‖fS k M (resc A p h) a‖ ^ 4 * ‖f a‖ ^ (2 * k - 4) := by
      simp only [Ei]; rw [sum_product]; simp
    have hfa : 0 ≤ ‖f a‖ ^ (2 * s) := by positivity
    have hS0 : 0 ≤ ∑ h ∈ range p, ‖fS k M (resc A p h) a‖ ^ 4 * ‖f a‖ ^ (2 * k - 4) :=
      sum_nonneg (fun _ _ => by positivity)
    calc (∑ e ∈ Ei, ‖gE e a‖) ^ 2 * ‖f a‖ ^ (2 * s)
        ≤ (Ei.card * ∑ e ∈ Ei, ‖gE e a‖ ^ 2) * ‖f a‖ ^ (2 * s) :=
          mul_le_mul_of_nonneg_right (by exact_mod_cast h1) hfa
      _ ≤ (Ei.card * (pairs.card * ∑ h ∈ range p,
            ‖fS k M (resc A p h) a‖ ^ 4 * ‖f a‖ ^ (2 * k - 4))) * ‖f a‖ ^ (2 * s) := by
          rw [← h3]; gcongr
      _ = ((pairs.card : ℝ) * p * pairs.card) * ∑ h ∈ range p,
            ‖fS k M (resc A p h) a‖ ^ 4 * (‖f a‖ ^ (2 * k - 4) * ‖f a‖ ^ (2 * s)) := by
          rw [hEi]; simp only [mul_sum, sum_mul]
          apply sum_congr rfl; intro h _; ring
      _ ≤ ((k : ℝ) ^ 2 * p * (k : ℝ) ^ 2) * ∑ h ∈ range p,
            ‖fS k M (resc A p h) a‖ ^ 4 * (‖f a‖ ^ (2 * k - 4) * ‖f a‖ ^ (2 * s)) := by
          apply mul_le_mul_of_nonneg_right _ (sum_nonneg (fun _ _ => by positivity))
          gcongr
      _ = ((k : ℝ) ^ 4 * p) * ∑ h ∈ range p,
            ‖fS k M (resc A p h) a‖ ^ 4 * ‖f a‖ ^ (2 * (s + k) - 4) := by
          rw [show (k : ℝ) ^ 2 * p * (k : ℝ) ^ 2 = (k : ℝ) ^ 4 * p by ring]
          congr 1; apply sum_congr rfl; intro h _
          rw [← pow_add]; congr 2; omega
  calc (M : ℝ) ^ k * (NIset.card : ℝ)
      ≤ (M : ℝ) ^ k * ∑ e ∈ Ei, ∑ e' ∈ Ei, ((Pset e e').card : ℝ) :=
        mul_le_mul_of_nonneg_left hsubadd (by positivity)
    _ = ∑ e ∈ Ei, ∑ e' ∈ Ei, (M : ℝ) ^ k * ((Pset e e').card : ℝ) := by
        rw [mul_sum]; apply sum_congr rfl; intro e _; rw [mul_sum]
    _ ≤ ∑ e ∈ Ei, ∑ e' ∈ Ei, ∑ a : Fin k → Fin M, ‖gE e a‖ * ‖gE e' a‖ * ‖f a‖ ^ (2 * s) :=
        sum_le_sum (fun e _ => sum_le_sum (fun e' _ => hpiece e e'))
    _ = ∑ a : Fin k → Fin M, ∑ e ∈ Ei, ∑ e' ∈ Ei, ‖gE e a‖ * ‖gE e' a‖ * ‖f a‖ ^ (2 * s) := by
        rw [Finset.sum_congr rfl (fun e _ => Finset.sum_comm), Finset.sum_comm]
    _ ≤ ∑ a : Fin k → Fin M, ((k : ℝ) ^ 4 * p) * ∑ h ∈ range p,
          ‖fS k M (resc A p h) a‖ ^ 4 * ‖f a‖ ^ (2 * (s + k) - 4) := sum_le_sum (fun a _ => hpt a)
    _ = ((k : ℝ) ^ 4 * p) * ∑ h ∈ range p, ∑ a : Fin k → Fin M,
          ‖fS k M (resc A p h) a‖ ^ 4 * ‖fS k M A a‖ ^ (2 * (s + k) - 4) := by
        rw [← mul_sum, sum_comm]

end GoldB
