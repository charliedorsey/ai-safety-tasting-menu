import PaperB.FixedQ.MovingCoefficientLedger
import PaperB.FixedQ.PureLeftTsumBridge
import PaperB.FixedQ.PrincipalOneDimensionalCancellation
import PaperB.FixedQ.PeriodicFloorDecomposition
import PaperB.FixedQ.CStarBound

open scoped BigOperators

namespace PaperB.FixedQ

theorem rowConstrainedMass_one_eq_dilate_prefix
    (w : ℕ → ℝ) (H e : ℕ)
    (hH : 0 < H) (he : 0 < e) :
    rowConstrainedMass w H e 1 =
      ∑ n ∈ Finset.Icc 1 ((H - 1) / e), w (e * n) := by
  rw [rowConstrainedMass_eq_sum_set]
  refine Finset.sum_bij
    (fun y hy => y / e)
    ?_ ?_ ?_ ?_
  · intro y hy
    simp only [rowConstrainedSet, Finset.mem_filter, Finset.mem_Ioo] at hy
    rcases hy with ⟨⟨hy0, hyH⟩, hey, _⟩
    have heY : e ≤ y := Nat.le_of_dvd hy0 hey
    have hn1 : 1 ≤ y / e := (Nat.one_le_div_iff he).2 heY
    have hyle : y ≤ H - 1 := by omega
    have hdiv : y / e ≤ (H - 1) / e := Nat.div_le_div_right hyle
    exact Finset.mem_Icc.mpr ⟨hn1, hdiv⟩
  · intro y1 hy1 y2 hy2 hEq
    simp only [rowConstrainedSet, Finset.mem_filter, Finset.mem_Ioo] at hy1 hy2
    have hd1 : e ∣ y1 := hy1.2.1
    have hd2 : e ∣ y2 := hy2.2.1
    calc
      y1 = e * (y1 / e) := (Nat.mul_div_cancel' hd1).symm
      _ = e * (y2 / e) := by rw [hEq]
      _ = y2 := Nat.mul_div_cancel' hd2
  · intro n hn
    rw [Finset.mem_Icc] at hn
    refine ⟨e * n, ?_, ?_⟩
    · simp only [rowConstrainedSet, Finset.mem_filter, Finset.mem_Ioo]
      have hy0 : 0 < e * n := Nat.mul_pos he (by omega)
      have hmul : e * n ≤ H - 1 := by
        simpa [mul_comm] using (Nat.le_div_iff_mul_le he).mp hn.2
      have hyH : e * n < H := by omega
      exact ⟨⟨hy0, hyH⟩, ⟨dvd_mul_right e n, by simp⟩⟩
    · exact Nat.mul_div_cancel_left n he
  · intro y hy
    simp only [rowConstrainedSet, Finset.mem_filter, Finset.mem_Ioo] at hy
    have hd : e ∣ y := hy.2.1
    rw [Nat.mul_div_cancel' hd]

theorem rowDiscrepancy_one_floor_decomposition
    {L H e : ℕ} [NeZero L]
    (w : ℕ → ℝ)
    (hH : 0 < H) (he : 0 < e)
    (heL : e.Coprime L)
    (hper : Function.Periodic w L) :
    rowDiscrepancy w H e 1 =
      periodicWeightMass L w / L * ((H - 1) / e : ℕ) +
        manuscriptBoundaryTerm L w (ZMod.unitOfCoprime e heL) -
        manuscriptSawtoothTerm L w (ZMod.unitOfCoprime e heL)
          (((H - 1) / e : ℕ) : ℝ) -
        rowWeightMass w H / (e : ℝ) := by
  unfold rowDiscrepancy
  rw [rowConstrainedMass_one_eq_dilate_prefix w H e hH he]
  rw [exactManuscriptPeriodicFloorDecomposition
    (w := w) (L := L) (e := e) (Y := (H - 1) / e)
    heL (by omega) hper]
  simp

#print axioms rowConstrainedMass_one_eq_dilate_prefix
#print axioms rowDiscrepancy_one_floor_decomposition

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma floor_natDiv_scaled_eq_realDiv
    {X e L a : ℕ}
    (he : 0 < e) (hL : 0 < L)
    (ha1 : 1 ≤ a) (haL : a ≤ L) :
    ⌊(((X / e : ℕ) : ℝ) / L + 1 - (a : ℝ) / L)⌋ =
      ⌊(X : ℝ) / ((e : ℝ) * L) + 1 - (a : ℝ) / L⌋ := by
  let k := X / e
  let r := X % e
  let m := k / L
  let s := k % L
  have hrlt : r < e := by
    dsimp [r]
    exact Nat.mod_lt _ he
  have hslt : s < L := by
    dsimp [s]
    exact Nat.mod_lt _ hL
  have hX : X = k * e + r := by
    dsimp [k, r]
    simpa [Nat.mul_comm, Nat.add_comm] using (Nat.mod_add_div X e).symm
  have hk : k = m * L + s := by
    dsimp [m, s]
    simpa [Nat.mul_comm, Nat.add_comm] using (Nat.mod_add_div k L).symm
  have heR : (0 : ℝ) < e := by exact_mod_cast he
  have hLR : (0 : ℝ) < L := by exact_mod_cast hL
  have hden : (0 : ℝ) < (e : ℝ) * L := mul_pos heR hLR
  have hrR : (0 : ℝ) ≤ r := by positivity
  have hrltR : (r : ℝ) < e := by exact_mod_cast hrlt
  have hsR : (0 : ℝ) ≤ s := by positivity
  have hsltR : (s : ℝ) < L := by exact_mod_cast hslt
  have ha1R : (1 : ℝ) ≤ a := by exact_mod_cast ha1
  have haLR : (a : ℝ) ≤ L := by exact_mod_cast haL
  have hleft :
      (((X / e : ℕ) : ℝ) / L + 1 - (a : ℝ) / L) =
        (m : ℝ) + (((s : ℝ) + (L : ℝ) - (a : ℝ)) / L) := by
    change (k : ℝ) / L + 1 - (a : ℝ) / L =
      (m : ℝ) + ((s : ℝ) + (L : ℝ) - (a : ℝ)) / L
    rw [hk]
    push_cast
    field_simp
    ring
  have hright :
      (X : ℝ) / ((e : ℝ) * L) + 1 - (a : ℝ) / L =
        (m : ℝ) +
          (((s : ℝ) + (L : ℝ) - (a : ℝ)) / L +
            (r : ℝ) / ((e : ℝ) * L)) := by
    rw [hX, hk]
    push_cast
    field_simp
    ring
  by_cases hsa : s < a
  · have hsaR : (s : ℝ) < a := by exact_mod_cast hsa
    have hbase0 :
        0 ≤ ((s : ℝ) + (L : ℝ) - (a : ℝ)) / L := by
      apply div_nonneg
      · linarith
      · exact hLR.le
    have hbase1 :
        ((s : ℝ) + (L : ℝ) - (a : ℝ)) / L < 1 := by
      rw [div_lt_one hLR]
      linarith
    have hdelta0 :
        0 ≤ (r : ℝ) / ((e : ℝ) * L) := div_nonneg hrR hden.le
    have hdeltaStep :
        (r : ℝ) / ((e : ℝ) * L) < 1 / (L : ℝ) := by
      rw [div_lt_div_iff₀ hden hLR]
      nlinarith
    have hsum1 :
        ((s : ℝ) + (L : ℝ) - (a : ℝ)) / L +
            (r : ℝ) / ((e : ℝ) * L) < 1 := by
      have hnumGap : (s : ℝ) + 1 ≤ (a : ℝ) := by exact_mod_cast hsa
      have hbaseStrong :
          ((s : ℝ) + (L : ℝ) - (a : ℝ)) / L ≤
            1 - 1 / (L : ℝ) := by
        rw [show (1 : ℝ) - 1 / (L : ℝ) =
          ((L : ℝ) - 1) / L by field_simp]
        apply (div_le_div_iff_of_pos_right hLR).2
        linarith
      linarith
    rw [hleft, hright]
    have hf1 :
        ⌊(m : ℝ) +
          ((s : ℝ) + (L : ℝ) - (a : ℝ)) / L⌋ = (m : ℤ) := by
      apply Int.floor_eq_iff.mpr
      constructor
      · simpa using (le_add_of_nonneg_right hbase0 : (m : ℝ) ≤
          (m : ℝ) + ((s : ℝ) + (L : ℝ) - (a : ℝ)) / L)
      · have : (m : ℝ) +
            ((s : ℝ) + (L : ℝ) - (a : ℝ)) / L < (m : ℝ) + 1 := by
          linarith
        simpa using this
    have hf2 :
        ⌊(m : ℝ) +
          (((s : ℝ) + (L : ℝ) - (a : ℝ)) / L +
            (r : ℝ) / ((e : ℝ) * L))⌋ = (m : ℤ) := by
      apply Int.floor_eq_iff.mpr
      constructor
      · have : 0 ≤
            ((s : ℝ) + (L : ℝ) - (a : ℝ)) / L +
              (r : ℝ) / ((e : ℝ) * L) := add_nonneg hbase0 hdelta0
        simpa using (le_add_of_nonneg_right this : (m : ℝ) ≤
          (m : ℝ) + (((s : ℝ) + (L : ℝ) - (a : ℝ)) / L +
            (r : ℝ) / ((e : ℝ) * L)))
      · have : (m : ℝ) +
            (((s : ℝ) + (L : ℝ) - (a : ℝ)) / L +
              (r : ℝ) / ((e : ℝ) * L)) < (m : ℝ) + 1 := by
          linarith
        simpa using this
    rw [hf1, hf2]
  · have has : a ≤ s := by omega
    have hasR : (a : ℝ) ≤ s := by exact_mod_cast has
    have hbase1 :
        1 ≤ ((s : ℝ) + (L : ℝ) - (a : ℝ)) / L := by
      rw [le_div_iff₀ hLR]
      linarith
    have hbase2 :
        ((s : ℝ) + (L : ℝ) - (a : ℝ)) / L < 2 := by
      rw [div_lt_iff₀ hLR]
      linarith
    have hdelta0 :
        0 ≤ (r : ℝ) / ((e : ℝ) * L) := div_nonneg hrR hden.le
    have hdeltaStep :
        (r : ℝ) / ((e : ℝ) * L) < 1 / (L : ℝ) := by
      rw [div_lt_div_iff₀ hden hLR]
      nlinarith
    have hsum2 :
        ((s : ℝ) + (L : ℝ) - (a : ℝ)) / L +
            (r : ℝ) / ((e : ℝ) * L) < 2 := by
      have hsSucc : (s : ℝ) + 1 ≤ (L : ℝ) := by
        exact_mod_cast (show s + 1 ≤ L by omega)
      have hsaGap : (s : ℝ) ≤ (L : ℝ) - 1 := by
        linarith
      have hbaseStrong :
          ((s : ℝ) + (L : ℝ) - (a : ℝ)) / L ≤
            2 - 2 / (L : ℝ) := by
        rw [show (2 : ℝ) - 2 / (L : ℝ) =
          (2 * (L : ℝ) - 2) / L by field_simp]
        apply (div_le_div_iff_of_pos_right hLR).2
        linarith [ha1R]
      have hLone : 1 / (L : ℝ) ≤ 2 / (L : ℝ) := by
        exact (div_le_div_iff_of_pos_right hLR).2 (by norm_num)
      linarith
    rw [hleft, hright]
    have hf1 :
        ⌊(m : ℝ) +
          ((s : ℝ) + (L : ℝ) - (a : ℝ)) / L⌋ = ((m + 1 : ℕ) : ℤ) := by
      apply Int.floor_eq_iff.mpr
      constructor
      · have : (m : ℝ) + 1 ≤
            (m : ℝ) + ((s : ℝ) + (L : ℝ) - (a : ℝ)) / L := by linarith
        exact_mod_cast this
      · have : (m : ℝ) +
            ((s : ℝ) + (L : ℝ) - (a : ℝ)) / L < (m : ℝ) + 2 := by
          linarith
        exact_mod_cast this
    have hf2 :
        ⌊(m : ℝ) +
          (((s : ℝ) + (L : ℝ) - (a : ℝ)) / L +
            (r : ℝ) / ((e : ℝ) * L))⌋ = ((m + 1 : ℕ) : ℤ) := by
      apply Int.floor_eq_iff.mpr
      constructor
      · have : (m : ℝ) + 1 ≤
            (m : ℝ) +
              (((s : ℝ) + (L : ℝ) - (a : ℝ)) / L +
                (r : ℝ) / ((e : ℝ) * L)) := by
          linarith
        exact_mod_cast this
      · have : (m : ℝ) +
            (((s : ℝ) + (L : ℝ) - (a : ℝ)) / L +
              (r : ℝ) / ((e : ℝ) * L)) < (m : ℝ) + 2 := by
          linarith
        exact_mod_cast this
    rw [hf1, hf2]

#print axioms floor_natDiv_scaled_eq_realDiv

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem exactManuscriptPeriodicFloorDecomposition_realDiv
    {w : ℕ → ℝ} {L e X : ℕ} [NeZero L]
    (he : e.Coprime L) (he1 : 1 ≤ e)
    (hper : Function.Periodic w L) :
    (∑ n ∈ Finset.Icc 1 (X / e), w (e * n)) =
      periodicWeightMass L w / L * ((X : ℝ) / (e : ℝ)) +
        manuscriptBoundaryTerm L w (ZMod.unitOfCoprime e he) -
        manuscriptSawtoothTerm L w (ZMod.unitOfCoprime e he)
          ((X : ℝ) / (e : ℝ)) := by
  have hL : 0 < L := NeZero.pos L
  have hepos : 0 < e := lt_of_lt_of_le Nat.zero_lt_one he1
  rw [exactManuscriptPeriodicFloorDecomposition
    (w := w) (L := L) (e := e) (Y := X / e)
    he he1 hper]
  unfold periodicWeightMass manuscriptBoundaryTerm manuscriptSawtoothTerm
  have hLR : (0 : ℝ) < L := by exact_mod_cast hL
  have heR : (0 : ℝ) < e := by exact_mod_cast hepos
  have hcore :
      (∑ c ∈ Finset.Icc 1 L, w c) / (L : ℝ) * ((X / e : ℕ) : ℝ) -
          ∑ c ∈ Finset.Icc 1 L,
            w c *
              petermannSawtooth
                ((((X / e : ℕ) : ℝ)) / L + 1 -
                  (periodicAlpha L (ZMod.unitOfCoprime e he) c : ℝ) / L)
        =
      (∑ c ∈ Finset.Icc 1 L, w c) / (L : ℝ) *
          ((X : ℝ) / (e : ℝ)) -
          ∑ c ∈ Finset.Icc 1 L,
            w c *
              petermannSawtooth
                (((X : ℝ) / (e : ℝ)) / L + 1 -
                  (periodicAlpha L (ZMod.unitOfCoprime e he) c : ℝ) / L) := by
    rw [show
      (∑ c ∈ Finset.Icc 1 L, w c) / (L : ℝ) * ((X / e : ℕ) : ℝ) =
        ∑ c ∈ Finset.Icc 1 L,
          w c * ((((X / e : ℕ) : ℝ)) / L) by
      calc
        (∑ c ∈ Finset.Icc 1 L, w c) / (L : ℝ) * ((X / e : ℕ) : ℝ)
            = (∑ c ∈ Finset.Icc 1 L, w c) *
                ((((X / e : ℕ) : ℝ)) / L) := by ring
        _ = ∑ c ∈ Finset.Icc 1 L,
              w c * ((((X / e : ℕ) : ℝ)) / L) := by
              rw [Finset.sum_mul]]
    rw [show
      (∑ c ∈ Finset.Icc 1 L, w c) / (L : ℝ) *
          ((X : ℝ) / (e : ℝ)) =
        ∑ c ∈ Finset.Icc 1 L,
          w c * (((X : ℝ) / (e : ℝ)) / L) by
      calc
        (∑ c ∈ Finset.Icc 1 L, w c) / (L : ℝ) *
            ((X : ℝ) / (e : ℝ))
            = (∑ c ∈ Finset.Icc 1 L, w c) *
                (((X : ℝ) / (e : ℝ)) / L) := by ring
        _ = ∑ c ∈ Finset.Icc 1 L,
              w c * (((X : ℝ) / (e : ℝ)) / L) := by
              rw [Finset.sum_mul]]
    rw [← Finset.sum_sub_distrib, ← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro c hc
    have halpha := periodicAlpha_mem_Icc L (ZMod.unitOfCoprime e he) c
    have ha1 := (Finset.mem_Icc.mp halpha).1
    have haL := (Finset.mem_Icc.mp halpha).2
    have hfloor := floor_natDiv_scaled_eq_realDiv
      (X := X) (e := e) (L := L)
      (a := periodicAlpha L (ZMod.unitOfCoprime e he) c)
      hepos hL ha1 haL
    unfold petermannSawtooth
    rw [hfloor]
    ring
  linarith

#print axioms exactManuscriptPeriodicFloorDecomposition_realDiv

end PaperB.FixedQ



namespace PaperB.FixedQ

theorem abs_freeLocalFactorRatio_three_le
    (y : ℕ) :
    |freeLocalFactorRatio 3 y| ≤ 3 := by
  have hy : y % 3 = 0 ∨ y % 3 = 1 ∨ y % 3 = 2 := by omega
  rcases hy with hy | hy | hy <;>
    norm_num [freeLocalFactorRatio, endpointOccupiedCount, hy]

theorem abs_freeLowPrimeFactor_le_six
    (q y : ℕ) :
    |freeLowPrimeFactor q y| ≤ 6 := by
  by_cases h2q : 2 ∣ q
  · by_cases h3q : 3 ∣ q
    · simp [freeLowPrimeFactor, lowPrimeSet, h2q, h3q]
    · have h3b := abs_freeLocalFactorRatio_three_le y
      simp [freeLowPrimeFactor, lowPrimeSet, h2q, h3q]
      linarith
  · by_cases h2y : 2 ∣ y
    · have h2v := freeLocalFactorRatio_two_even h2y
      by_cases h3q : 3 ∣ q
      · simp [freeLowPrimeFactor, lowPrimeSet, h2q, h3q, h2v]
        norm_num
      · have h3b := abs_freeLocalFactorRatio_three_le y
        unfold freeLowPrimeFactor lowPrimeSet
        norm_num [Finset.prod_insert]
        simp only [h2q, h3q, if_false, h2v, abs_mul]
        rw [abs_of_nonneg (by norm_num : (0 : ℝ) ≤ 2)]
        nlinarith
    · have h2v := freeLocalFactorRatio_two_odd h2y
      simp [freeLowPrimeFactor, lowPrimeSet, h2q, h2v]

theorem abs_freeFixedQLowWeight_le_six
    (q r y : ℕ) :
    |freeFixedQLowWeight q r y| ≤ 6 := by
  rw [freeFixedQLowWeight_eq_indicator_mul_factor]
  by_cases hc : q.Coprime (r + y)
  · rw [if_pos hc, one_mul]
    exact abs_freeLowPrimeFactor_le_six q y
  · rw [if_neg hc, zero_mul, abs_zero]
    norm_num

theorem abs_freeReducedFixedQLowWeight_le_six
    (q r z : ℕ) :
    |freeReducedFixedQLowWeight q r z| ≤ 6 := by
  unfold freeReducedFixedQLowWeight
  exact abs_freeFixedQLowWeight_le_six q r (2 * z)

#print axioms abs_freeReducedFixedQLowWeight_le_six

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma abs_boundary_factor_le_one
    {L a : ℕ} [NeZero L]
    (ha : a ∈ Finset.Icc 1 L) :
    |(1 / 2 : ℝ) - (a : ℝ) / L| ≤ 1 := by
  have hL : 0 < L := NeZero.pos L
  have haI := Finset.mem_Icc.mp ha
  have ha0 : (0 : ℝ) ≤ a := by positivity
  have haL : (a : ℝ) ≤ L := by exact_mod_cast haI.2
  have hLR : (0 : ℝ) < L := by exact_mod_cast hL
  have hfrac0 : 0 ≤ (a : ℝ) / L := div_nonneg ha0 hLR.le
  have hfrac1 : (a : ℝ) / L ≤ 1 := by
    rw [div_le_one hLR]
    exact haL
  rw [abs_le]
  constructor <;> linarith

theorem abs_manuscriptBoundaryTerm_le
    (L : ℕ) [NeZero L]
    (w : ℕ → ℝ)
    (hw : ∀ c ∈ Finset.Icc 1 L, |w c| ≤ 6)
    (u : (ZMod L)ˣ) :
    |manuscriptBoundaryTerm L w u| ≤ 6 * L := by
  unfold manuscriptBoundaryTerm
  calc
    |∑ c ∈ Finset.Icc 1 L,
        w c * (1 / 2 - (periodicAlpha L u c : ℝ) / L)|
      ≤ ∑ c ∈ Finset.Icc 1 L,
          |w c * (1 / 2 - (periodicAlpha L u c : ℝ) / L)| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ c ∈ Finset.Icc 1 L, (6 : ℝ) := by
      apply Finset.sum_le_sum
      intro c hc
      rw [abs_mul]
      have ha := periodicAlpha_mem_Icc L u c
      have hf := abs_boundary_factor_le_one (L := L) ha
      nlinarith [hw c hc, abs_nonneg (w c)]
    _ = 6 * L := by
      have hL : 0 < L := NeZero.pos L
      simp [Nat.card_Icc, hL]
      ring

theorem abs_manuscriptSawtoothTerm_le
    (L : ℕ) [NeZero L]
    (w : ℕ → ℝ)
    (hw : ∀ c ∈ Finset.Icc 1 L, |w c| ≤ 6)
    (u : (ZMod L)ˣ) (t : ℝ) :
    |manuscriptSawtoothTerm L w u t| ≤ 3 * L := by
  unfold manuscriptSawtoothTerm
  calc
    |∑ c ∈ Finset.Icc 1 L,
        w c *
          petermannSawtooth
            (t / L + 1 - (periodicAlpha L u c : ℝ) / L)|
      ≤ ∑ c ∈ Finset.Icc 1 L,
          |w c *
            petermannSawtooth
              (t / L + 1 - (periodicAlpha L u c : ℝ) / L)| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ c ∈ Finset.Icc 1 L, (3 : ℝ) := by
      apply Finset.sum_le_sum
      intro c hc
      rw [abs_mul]
      have hs := abs_petermannSawtooth_le_half
        (t / L + 1 - (periodicAlpha L u c : ℝ) / L)
      nlinarith [hw c hc, abs_nonneg (w c)]
    _ = 3 * L := by
      have hL : 0 < L := NeZero.pos L
      simp [Nat.card_Icc, hL]
      ring

theorem norm_boundaryCharacterCoeff_le
    (L : ℕ) [NeZero L]
    (w : ℕ → ℝ)
    (hw : ∀ c ∈ Finset.Icc 1 L, |w c| ≤ 6)
    (chi : DirichletCharacter ℂ L) :
    ‖boundaryCharacterCoeff L w chi‖ ≤ 6 * L := by
  unfold boundaryCharacterCoeff periodicUnitFourierCoeff
  have hL : 0 < L := NeZero.pos L
  have hphiPos : 0 < L.totient := Nat.totient_pos.mpr hL
  rw [norm_mul]
  have hinv :
      ‖(1 / (L.totient : ℂ))‖ = 1 / (L.totient : ℝ) := by
    rw [norm_div, norm_one]
    simp [show (0 : ℝ) ≤ L.totient by positivity]
  rw [hinv]
  have hsum :
      ‖∑ u : (ZMod L)ˣ,
          (manuscriptBoundaryTerm L w u : ℂ) *
            chi ((u : ZMod L)⁻¹)‖
        ≤ (L.totient : ℝ) * (6 * L) := by
    calc
      ‖∑ u : (ZMod L)ˣ,
          (manuscriptBoundaryTerm L w u : ℂ) *
            chi ((u : ZMod L)⁻¹)‖
        ≤ ∑ u : (ZMod L)ˣ,
            ‖(manuscriptBoundaryTerm L w u : ℂ) *
              chi ((u : ZMod L)⁻¹)‖ := norm_sum_le _ _
      _ ≤ ∑ u : (ZMod L)ˣ, (6 * L : ℝ) := by
        apply Finset.sum_le_sum
        intro u hu
        rw [norm_mul, Complex.norm_real]
        have hb := abs_manuscriptBoundaryTerm_le L w hw u
        have hc := chi.norm_le_one ((u : ZMod L)⁻¹)
        calc
          |manuscriptBoundaryTerm L w u| *
              ‖chi ((u : ZMod L)⁻¹)‖
              ≤ (6 * (L : ℝ)) * 1 := by
                exact mul_le_mul hb hc (norm_nonneg _)
                  (by positivity : (0 : ℝ) ≤ 6 * L)
          _ = 6 * L := by ring
      _ = (L.totient : ℝ) * (6 * L) := by simp
  have hphiR : (0 : ℝ) < L.totient := by exact_mod_cast hphiPos
  calc
    (1 / (L.totient : ℝ)) *
        ‖∑ u : (ZMod L)ˣ,
          (manuscriptBoundaryTerm L w u : ℂ) *
            chi ((u : ZMod L)⁻¹)‖
      ≤ (1 / (L.totient : ℝ)) *
          ((L.totient : ℝ) * (6 * L)) :=
        mul_le_mul_of_nonneg_left hsum (by positivity)
    _ = 6 * L := by field_simp

theorem norm_sawtoothCharacterCoeff_le
    (L : ℕ) [NeZero L]
    (w : ℕ → ℝ)
    (hw : ∀ c ∈ Finset.Icc 1 L, |w c| ≤ 6)
    (t : ℝ)
    (chi : DirichletCharacter ℂ L) :
    ‖sawtoothCharacterCoeff L w t chi‖ ≤ 3 * L := by
  unfold sawtoothCharacterCoeff periodicUnitFourierCoeff
  have hL : 0 < L := NeZero.pos L
  have hphiPos : 0 < L.totient := Nat.totient_pos.mpr hL
  rw [norm_mul]
  have hinv :
      ‖(1 / (L.totient : ℂ))‖ = 1 / (L.totient : ℝ) := by
    rw [norm_div, norm_one]
    simp [show (0 : ℝ) ≤ L.totient by positivity]
  rw [hinv]
  have hsum :
      ‖∑ u : (ZMod L)ˣ,
          (manuscriptSawtoothTerm L w u t : ℂ) *
            chi ((u : ZMod L)⁻¹)‖
        ≤ (L.totient : ℝ) * (3 * L) := by
    calc
      ‖∑ u : (ZMod L)ˣ,
          (manuscriptSawtoothTerm L w u t : ℂ) *
            chi ((u : ZMod L)⁻¹)‖
        ≤ ∑ u : (ZMod L)ˣ,
            ‖(manuscriptSawtoothTerm L w u t : ℂ) *
              chi ((u : ZMod L)⁻¹)‖ := norm_sum_le _ _
      _ ≤ ∑ u : (ZMod L)ˣ, (3 * L : ℝ) := by
        apply Finset.sum_le_sum
        intro u hu
        rw [norm_mul, Complex.norm_real]
        have hb := abs_manuscriptSawtoothTerm_le L w hw u t
        have hc := chi.norm_le_one ((u : ZMod L)⁻¹)
        calc
          |manuscriptSawtoothTerm L w u t| *
              ‖chi ((u : ZMod L)⁻¹)‖
              ≤ (3 * (L : ℝ)) * 1 := by
                exact mul_le_mul hb hc (norm_nonneg _)
                  (by positivity : (0 : ℝ) ≤ 3 * L)
          _ = 3 * L := by ring
      _ = (L.totient : ℝ) * (3 * L) := by simp
  have hphiR : (0 : ℝ) < L.totient := by exact_mod_cast hphiPos
  calc
    (1 / (L.totient : ℝ)) *
        ‖∑ u : (ZMod L)ˣ,
          (manuscriptSawtoothTerm L w u t : ℂ) *
            chi ((u : ZMod L)⁻¹)‖
      ≤ (1 / (L.totient : ℝ)) *
          ((L.totient : ℝ) * (3 * L)) :=
        mul_le_mul_of_nonneg_left hsum (by positivity)
    _ = 3 * L := by field_simp

#print axioms norm_boundaryCharacterCoeff_le
#print axioms norm_sawtoothCharacterCoeff_le

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem boundaryCharacterCoeff_one_eq_principalBoundaryAverage
    (L : ℕ) [NeZero L] (w : ℕ → ℝ) :
    boundaryCharacterCoeff L w (1 : DirichletCharacter ℂ L) =
      (principalBoundaryAverage L w : ℂ) := by
  unfold boundaryCharacterCoeff periodicUnitFourierCoeff principalBoundaryAverage
  push_cast
  simp

#print axioms boundaryCharacterCoeff_one_eq_principalBoundaryAverage

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma etaCoeff_coprime_fixedQPeriod_of_ne_zero
    {q e : ℕ} (he : etaCoeff q e ≠ 0) :
    e.Coprime (fixedQPeriod q) := by
  unfold etaCoeff at he
  by_cases he0 : e = 0
  · simp [he0] at he
  · rw [if_neg he0] at he
    by_cases hs : Squarefree e ∧ e.Coprime (6 * q)
    · have hdiv : fixedQPeriod q ∣ 6 * q := by
        unfold fixedQPeriod
        exact Nat.lcm_dvd_mul 6 q
      exact hs.2.of_dvd_right hdiv
    · rw [if_neg hs] at he
      simp at he

lemma movingVCoeff_coprime_fixedQPeriod_of_ne_zero
    {q h e : ℕ} (he : movingVCoeff q h e ≠ 0) :
    e.Coprime (fixedQPeriod q) := by
  unfold movingVCoeff at he
  by_cases he0 : e = 0
  · simp [he0] at he
  · rw [if_neg he0] at he
    by_cases hs : Squarefree e ∧ e.Coprime (6 * q)
    · have hdiv : fixedQPeriod q ∣ 6 * q := by
        unfold fixedQPeriod
        exact Nat.lcm_dvd_mul 6 q
      exact hs.2.of_dvd_right hdiv
    · rw [if_neg hs] at he
      simp at he

#print axioms etaCoeff_coprime_fixedQPeriod_of_ne_zero
#print axioms movingVCoeff_coprime_fixedQPeriod_of_ne_zero

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem principalCharacterPartialSum_eta
    (q X : ℕ) :
    characterCoefficientPartialSum
        (1 : DirichletCharacter ℂ (fixedQPeriod q))
        (etaCoeff q) X =
      (coefficientPartialSum (etaCoeff q) X : ℂ) := by
  unfold characterCoefficientPartialSum coefficientPartialSum
  push_cast
  apply Finset.sum_congr rfl
  intro e heI
  by_cases hc : etaCoeff q e = 0
  · simp [hc]
  · have hcop := etaCoeff_coprime_fixedQPeriod_of_ne_zero hc
    have hunit : IsUnit (e : ZMod (fixedQPeriod q)) := by
      exact (ZMod.isUnit_iff_coprime e (fixedQPeriod q)).2 hcop
    rw [MulChar.one_apply hunit]
    ring

theorem principalCharacterPartialSum_moving
    (q h X : ℕ) :
    characterCoefficientPartialSum
        (1 : DirichletCharacter ℂ (fixedQPeriod q))
        (movingVCoeff q h) X =
      (coefficientPartialSum (movingVCoeff q h) X : ℂ) := by
  unfold characterCoefficientPartialSum coefficientPartialSum
  push_cast
  apply Finset.sum_congr rfl
  intro e heI
  by_cases hc : movingVCoeff q h e = 0
  · simp [hc]
  · have hcop := movingVCoeff_coprime_fixedQPeriod_of_ne_zero hc
    have hunit : IsUnit (e : ZMod (fixedQPeriod q)) := by
      exact (ZMod.isUnit_iff_coprime e (fixedQPeriod q)).2 hcop
    rw [MulChar.one_apply hunit]
    ring

#print axioms principalCharacterPartialSum_eta
#print axioms principalCharacterPartialSum_moving

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def supportedBoundarySum
    (L : ℕ) [NeZero L] (w u : ℕ → ℝ) (X : ℕ) : ℝ :=
  ∑ e ∈ Finset.Icc 1 X,
    u e *
      if he : e.Coprime L then
        manuscriptBoundaryTerm L w (ZMod.unitOfCoprime e he)
      else 0

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem supportedBoundarySum_character_expansion
    (L : ℕ) [NeZero L] (w u : ℕ → ℝ) (X : ℕ)
    (hsupport : ∀ e : ℕ, u e ≠ 0 → e.Coprime L) :
    (supportedBoundarySum L w u X : ℂ) =
      ∑ chi : DirichletCharacter ℂ L,
        boundaryCharacterCoeff L w chi *
          characterCoefficientPartialSum chi u X := by
  classical
  unfold supportedBoundarySum characterCoefficientPartialSum
  push_cast
  calc
    (∑ e ∈ Finset.Icc 1 X,
      (u e : ℂ) *
        ((if he : e.Coprime L then
          manuscriptBoundaryTerm L w (ZMod.unitOfCoprime e he)
        else 0 : ℝ) : ℂ))
      = ∑ e ∈ Finset.Icc 1 X,
          ∑ chi : DirichletCharacter ℂ L,
            boundaryCharacterCoeff L w chi *
              (chi e) * (u e : ℂ) := by
          apply Finset.sum_congr rfl
          intro e heI
          by_cases hu : u e = 0
          · simp [hu]
          · have hcop := hsupport e hu
            rw [dif_pos hcop]
            rw [manuscriptBoundaryTerm_character_expansion]
            rw [Finset.mul_sum]
            apply Finset.sum_congr rfl
            intro chi hchi
            rw [ZMod.coe_unitOfCoprime]
            ring
    _ = ∑ chi : DirichletCharacter ℂ L,
          boundaryCharacterCoeff L w chi *
            (∑ e ∈ Finset.Icc 1 X, (chi e) * (u e : ℂ)) := by
          rw [Finset.sum_comm]
          apply Finset.sum_congr rfl
          intro chi hchi
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro e heI
          ring

#print axioms supportedBoundarySum_character_expansion

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def supportedSawtoothSum
    (L : ℕ) [NeZero L] (w u : ℕ → ℝ)
    (T : ℝ) (X : ℕ) : ℝ :=
  ∑ e ∈ Finset.Icc 1 X,
    u e *
      if he : e.Coprime L then
        manuscriptSawtoothTerm L w (ZMod.unitOfCoprime e he)
          (T / (e : ℝ))
      else 0

noncomputable def genericPetermannKernelSum
    (L : ℕ) (u : ℕ → ℝ)
    (chi : DirichletCharacter ℂ L)
    (r : ℤ) (T : ℝ) (X : ℕ) : ℂ :=
  ∑ e ∈ Finset.Icc 1 X,
    (chi e) * (u e : ℂ) *
      (petermannSawtooth
        (T / (L : ℝ) / (e : ℝ) + (r : ℝ) / (L : ℝ)) : ℂ)

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem supportedSawtoothSum_character_expansion
    (L : ℕ) [NeZero L] (w u : ℕ → ℝ)
    (T : ℝ) (X : ℕ)
    (hsupport : ∀ e : ℕ, u e ≠ 0 → e.Coprime L) :
    (supportedSawtoothSum L w u T X : ℂ) =
      ∑ chi : DirichletCharacter ℂ L,
        ∑ e ∈ Finset.Icc 1 X,
          sawtoothCharacterCoeff L w (T / (e : ℝ)) chi *
            (chi e) * (u e : ℂ) := by
  classical
  unfold supportedSawtoothSum
  push_cast
  calc
    (∑ e ∈ Finset.Icc 1 X,
      (u e : ℂ) *
        ((if he : e.Coprime L then
          manuscriptSawtoothTerm L w (ZMod.unitOfCoprime e he)
            (T / (e : ℝ))
        else 0 : ℝ) : ℂ))
      = ∑ e ∈ Finset.Icc 1 X,
          ∑ chi : DirichletCharacter ℂ L,
            sawtoothCharacterCoeff L w (T / (e : ℝ)) chi *
              (chi e) * (u e : ℂ) := by
          apply Finset.sum_congr rfl
          intro e heI
          by_cases hu : u e = 0
          · simp [hu]
          · have hcop := hsupport e hu
            rw [dif_pos hcop]
            rw [manuscriptSawtoothTerm_character_expansion]
            rw [Finset.mul_sum]
            apply Finset.sum_congr rfl
            intro chi hchi
            rw [ZMod.coe_unitOfCoprime]
            ring
    _ = ∑ chi : DirichletCharacter ℂ L,
          ∑ e ∈ Finset.Icc 1 X,
            sawtoothCharacterCoeff L w (T / (e : ℝ)) chi *
              (chi e) * (u e : ℂ) := by
          rw [Finset.sum_comm]

#print axioms supportedSawtoothSum_character_expansion

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma manuscriptSawtooth_phase_eq_kernel
    {L e a : ℕ} (T : ℝ)
    (hL : 0 < L) (he : 0 < e) (haL : a ≤ L) :
    petermannSawtooth
        ((T / (e : ℝ)) / (L : ℝ) + 1 - (a : ℝ) / (L : ℝ)) =
      petermannSawtooth
        (T / (L : ℝ) / (e : ℝ) +
          ((L - a : ℕ) : ℝ) / (L : ℝ)) := by
  congr 1
  have hLR : (L : ℝ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hL)
  have heR : (e : ℝ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt he)
  rw [Nat.cast_sub haL]
  field_simp [hLR, heR]
  ring

#print axioms manuscriptSawtooth_phase_eq_kernel

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def sawtoothWeightedCharacterSum
    (L : ℕ) [NeZero L] (w u : ℕ → ℝ)
    (chi : DirichletCharacter ℂ L)
    (T : ℝ) (X : ℕ) : ℂ :=
  ∑ e ∈ Finset.Icc 1 X,
    sawtoothCharacterCoeff L w (T / (e : ℝ)) chi *
      (chi e) * (u e : ℂ)

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem sawtoothWeightedCharacterSum_eq_genericKernel
    (L : ℕ) [NeZero L] (w u : ℕ → ℝ)
    (chi : DirichletCharacter ℂ L)
    (T : ℝ) (X : ℕ) :
    sawtoothWeightedCharacterSum L w u chi T X =
      (1 / (L.totient : ℂ)) *
        ∑ v : (ZMod L)ˣ,
          ∑ c ∈ Finset.Icc 1 L,
            (w c : ℂ) * chi ((v : ZMod L)⁻¹) *
              genericPetermannKernelSum L u chi
                (Int.ofNat (L - periodicAlpha L v c)) T X := by
  classical
  rw [show sawtoothWeightedCharacterSum L w u chi T X =
      (1 / (L.totient : ℂ)) *
        ∑ e ∈ Finset.Icc 1 X,
          (∑ v : (ZMod L)ˣ,
            ((∑ c ∈ Finset.Icc 1 L,
              w c * petermannSawtooth
                ((T / (e : ℝ)) / L + 1 -
                  (periodicAlpha L v c : ℝ) / L)) : ℂ) *
              chi ((v : ZMod L)⁻¹)) *
            (chi e) * (u e : ℂ) by
    unfold sawtoothWeightedCharacterSum
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro e he
    rw [sawtoothCharacterCoeff_eq_fixed_shifts]
    ring]
  congr 1
  let A : ℕ → (ZMod L)ˣ → ℂ := fun e v =>
    ((∑ c ∈ Finset.Icc 1 L,
      (w c : ℂ) *
        (petermannSawtooth
          ((T / (e : ℝ)) / L + 1 -
            (periodicAlpha L v c : ℝ) / L) : ℂ)) *
      chi ((v : ZMod L)⁻¹))
  have hdist (e : ℕ) :
      (∑ v : (ZMod L)ˣ, A e v) * (chi e) * (u e : ℂ) =
        (∑ v : (ZMod L)ˣ, A e v * (chi e) * (u e : ℂ)) := by
    rw [Finset.sum_mul, Finset.sum_mul]
  change
    (∑ e ∈ Finset.Icc 1 X,
      (∑ v : (ZMod L)ˣ, A e v) * (chi e) * (u e : ℂ)) =
      _
  simp_rw [hdist]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro v hv
  dsimp [A]
  calc
    (∑ e ∈ Finset.Icc 1 X,
        ((∑ c ∈ Finset.Icc 1 L,
            w c * petermannSawtooth
              ((T / (e : ℝ)) / L + 1 -
                (periodicAlpha L v c : ℝ) / L)) : ℂ) *
          chi ((v : ZMod L)⁻¹) * (chi e) * (u e : ℂ))
      = ∑ e ∈ Finset.Icc 1 X,
          ∑ c ∈ Finset.Icc 1 L,
            (w c : ℂ) * chi ((v : ZMod L)⁻¹) *
              (chi e) * (u e : ℂ) *
              (petermannSawtooth
                ((T / (e : ℝ)) / L + 1 -
                  (periodicAlpha L v c : ℝ) / L) : ℂ) := by
        apply Finset.sum_congr rfl
        intro e he
        push_cast
        rw [Finset.sum_mul, Finset.sum_mul, Finset.sum_mul]
        apply Finset.sum_congr rfl
        intro c hc
        ring
      _ = ∑ c ∈ Finset.Icc 1 L,
          ∑ e ∈ Finset.Icc 1 X,
            (w c : ℂ) * chi ((v : ZMod L)⁻¹) *
              (chi e) * (u e : ℂ) *
              (petermannSawtooth
                ((T / (e : ℝ)) / L + 1 -
                  (periodicAlpha L v c : ℝ) / L) : ℂ) := by
        rw [Finset.sum_comm]
      _ = ∑ c ∈ Finset.Icc 1 L,
          (w c : ℂ) * chi ((v : ZMod L)⁻¹) *
            genericPetermannKernelSum L u chi
              (Int.ofNat (L - periodicAlpha L v c)) T X := by
        apply Finset.sum_congr rfl
        intro c hc
        unfold genericPetermannKernelSum
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro e he
        have hepos : 0 < e := by
          exact (Finset.mem_Icc.mp he).1
        have ha := periodicAlpha_mem_Icc L v c
        have hphase := manuscriptSawtooth_phase_eq_kernel
          (L := L) (e := e)
          (a := periodicAlpha L v c) T
          (NeZero.pos L) hepos (Finset.mem_Icc.mp ha).2
        push_cast
        rw [hphase]
        simp
        ring

#print axioms sawtoothWeightedCharacterSum_eq_genericKernel

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem norm_sawtoothWeightedCharacterSum_le_kernel
    (L : ℕ) [NeZero L] (w u : ℕ → ℝ)
    (hw : ∀ c ∈ Finset.Icc 1 L, |w c| ≤ 6)
    (chi : DirichletCharacter ℂ L)
    (T : ℝ) (X : ℕ) (K : ℝ) (hK0 : 0 ≤ K)
    (hK : ∀ r : ℤ,
      ‖genericPetermannKernelSum L u chi r T X‖ ≤ K) :
    ‖sawtoothWeightedCharacterSum L w u chi T X‖ ≤
      6 * (L : ℝ) * K := by
  rw [sawtoothWeightedCharacterSum_eq_genericKernel]
  have hL : 0 < L := NeZero.pos L
  have hphi : 0 < L.totient := Nat.totient_pos.mpr hL
  have hphiR : (0 : ℝ) < L.totient := by exact_mod_cast hphi
  rw [norm_mul]
  have hinv :
      ‖(1 / (L.totient : ℂ))‖ = 1 / (L.totient : ℝ) := by
    rw [norm_div, norm_one]
    simp
  rw [hinv]
  have houter :
      ‖∑ v : (ZMod L)ˣ,
          ∑ c ∈ Finset.Icc 1 L,
            (w c : ℂ) * chi ((v : ZMod L)⁻¹) *
              genericPetermannKernelSum L u chi
                (Int.ofNat (L - periodicAlpha L v c)) T X‖
        ≤ (L.totient : ℝ) * ((L : ℝ) * (6 * K)) := by
    calc
      ‖∑ v : (ZMod L)ˣ,
          ∑ c ∈ Finset.Icc 1 L,
            (w c : ℂ) * chi ((v : ZMod L)⁻¹) *
              genericPetermannKernelSum L u chi
                (Int.ofNat (L - periodicAlpha L v c)) T X‖
        ≤ ∑ v : (ZMod L)ˣ,
            ‖∑ c ∈ Finset.Icc 1 L,
              (w c : ℂ) * chi ((v : ZMod L)⁻¹) *
                genericPetermannKernelSum L u chi
                  (Int.ofNat (L - periodicAlpha L v c)) T X‖ :=
          norm_sum_le _ _
      _ ≤ ∑ v : (ZMod L)ˣ, ((L : ℝ) * (6 * K)) := by
        apply Finset.sum_le_sum
        intro v hv
        calc
          ‖∑ c ∈ Finset.Icc 1 L,
              (w c : ℂ) * chi ((v : ZMod L)⁻¹) *
                genericPetermannKernelSum L u chi
                  (Int.ofNat (L - periodicAlpha L v c)) T X‖
            ≤ ∑ c ∈ Finset.Icc 1 L,
                ‖(w c : ℂ) * chi ((v : ZMod L)⁻¹) *
                  genericPetermannKernelSum L u chi
                    (Int.ofNat (L - periodicAlpha L v c)) T X‖ :=
              norm_sum_le _ _
          _ ≤ ∑ c ∈ Finset.Icc 1 L, (6 * K) := by
            apply Finset.sum_le_sum
            intro c hc
            rw [norm_mul, norm_mul, Complex.norm_real]
            have hwc := hw c hc
            have hchi := chi.norm_le_one ((v : ZMod L)⁻¹)
            have hk := hK (Int.ofNat (L - periodicAlpha L v c))
            have h6 : (0 : ℝ) ≤ 6 := by norm_num
            calc
              |w c| * ‖chi ((v : ZMod L)⁻¹)‖ *
                    ‖genericPetermannKernelSum L u chi
                      (Int.ofNat (L - periodicAlpha L v c)) T X‖
                  ≤ 6 * 1 * K := by
                    exact mul_le_mul
                      (mul_le_mul hwc hchi (norm_nonneg _) h6)
                      hk (norm_nonneg _) (mul_nonneg h6 (by norm_num))
              _ = 6 * K := by ring
          _ = (L : ℝ) * (6 * K) := by
            simp [Nat.card_Icc, hL]
      _ = (L.totient : ℝ) * ((L : ℝ) * (6 * K)) := by
        simp [ZMod.card_units_eq_totient]
  calc
    (1 / (L.totient : ℝ)) *
        ‖∑ v : (ZMod L)ˣ,
          ∑ c ∈ Finset.Icc 1 L,
            (w c : ℂ) * chi ((v : ZMod L)⁻¹) *
              genericPetermannKernelSum L u chi
                (Int.ofNat (L - periodicAlpha L v c)) T X‖
      ≤ (1 / (L.totient : ℝ)) *
          ((L.totient : ℝ) * ((L : ℝ) * (6 * K))) :=
        mul_le_mul_of_nonneg_left houter (by positivity)
    _ = 6 * (L : ℝ) * K := by
      field_simp

#print axioms norm_sawtoothWeightedCharacterSum_le_kernel

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem supportedSawtoothSum_moving_sublog_of_r0002
    (q : ℕ) (hq : 0 < q) [NeZero (fixedQPeriod q)]
    (hbase : PetermannMinimalConsumerR0002Spec q PetermannBase.omega) :
    ∀ ε : ℝ, 0 < ε →
      ∃ T0 : ℝ, ∀
        (h : ℕ), h ≠ 0 →
        ∀ (w : ℕ → ℝ),
          (∀ c ∈ Finset.Icc 1 (fixedQPeriod q), |w c| ≤ 6) →
        ∀ (T : ℝ) (X : ℕ),
          T0 ≤ T →
          (2 * fixedQPeriod q : ℝ) ≤ T →
          1 ≤ X →
          (X : ℝ) ≤ T →
          |supportedSawtoothSum
              (fixedQPeriod q) w (movingVCoeff q h) T X|
            ≤ ε * Real.log T := by
  intro ε hε
  have hmove := petermannMovingSublog_of_r0002 q hq hbase
  let Cn : ℝ :=
    (Fintype.card
      (DirichletCharacter ℂ (fixedQPeriod q)) : ℝ)
  let D : ℝ := Cn * (6 * (fixedQPeriod q : ℝ))
  have hCn0 : 0 ≤ Cn := by
    dsimp [Cn]
    positivity
  have hD0 : 0 ≤ D := by
    dsimp [D]
    positivity
  let δ : ℝ := ε / (D + 1)
  have hδ : 0 < δ := by
    dsimp [δ]
    positivity
  obtain ⟨T0, hT0⟩ := hmove δ hδ
  refine ⟨T0, ?_⟩
  intro h hh w hw T X hT0' h2 hX1 hXT
  have hLpos : 0 < fixedQPeriod q := by
    unfold fixedQPeriod
    exact Nat.lcm_pos (by norm_num) hq
  have hT1 : 1 ≤ T := by
    have hLR : (1 : ℝ) ≤ fixedQPeriod q := by exact_mod_cast hLpos
    linarith
  have hlog0 : 0 ≤ Real.log T := Real.log_nonneg hT1
  have hsupp :
      ∀ e : ℕ, movingVCoeff q h e ≠ 0 →
        e.Coprime (fixedQPeriod q) :=
    fun e he => movingVCoeff_coprime_fixedQPeriod_of_ne_zero he
  have hexp :=
    supportedSawtoothSum_character_expansion
      (fixedQPeriod q) w (movingVCoeff q h) T X hsupp
  have hkernel :
      ∀ (chi : DirichletCharacter ℂ (fixedQPeriod q)) (r : ℤ),
        ‖genericPetermannKernelSum
            (fixedQPeriod q) (movingVCoeff q h) chi r T X‖
          ≤ δ * Real.log T := by
    intro chi r
    change ‖petermannMovingKernelSum q h chi r T X‖ ≤
      δ * Real.log T
    exact hT0 h hh chi r T X hT0'
      (by simpa [fixedQPeriod] using h2) hX1 hXT
  have hsum :
      ‖∑ chi : DirichletCharacter ℂ (fixedQPeriod q),
          sawtoothWeightedCharacterSum
            (fixedQPeriod q) w (movingVCoeff q h) chi T X‖
        ≤ Cn * (6 * (fixedQPeriod q : ℝ) *
          (δ * Real.log T)) := by
    calc
      ‖∑ chi : DirichletCharacter ℂ (fixedQPeriod q),
          sawtoothWeightedCharacterSum
            (fixedQPeriod q) w (movingVCoeff q h) chi T X‖
        ≤ ∑ chi : DirichletCharacter ℂ (fixedQPeriod q),
            ‖sawtoothWeightedCharacterSum
              (fixedQPeriod q) w (movingVCoeff q h) chi T X‖ :=
          norm_sum_le _ _
      _ ≤ ∑ _chi : DirichletCharacter ℂ (fixedQPeriod q),
            (6 * (fixedQPeriod q : ℝ) *
              (δ * Real.log T)) := by
        apply Finset.sum_le_sum
        intro chi hchi
        exact norm_sawtoothWeightedCharacterSum_le_kernel
          (fixedQPeriod q) w (movingVCoeff q h) hw chi T X
          (δ * Real.log T) (mul_nonneg hδ.le hlog0)
          (hkernel chi)
      _ = Cn * (6 * (fixedQPeriod q : ℝ) *
            (δ * Real.log T)) := by
        simp [Cn]
  have hcoeff : Cn * (6 * (fixedQPeriod q : ℝ)) * δ ≤ ε := by
    dsimp [δ, D]
    have hden : 0 < Cn * (6 * (fixedQPeriod q : ℝ)) + 1 := by
      positivity
    rw [show
      Cn * (6 * (fixedQPeriod q : ℝ)) *
          (ε / (Cn * (6 * (fixedQPeriod q : ℝ)) + 1)) =
        ε * (Cn * (6 * (fixedQPeriod q : ℝ)) /
          (Cn * (6 * (fixedQPeriod q : ℝ)) + 1)) by ring]
    apply mul_le_of_le_one_right hε.le
    exact (div_le_one hden).2 (by linarith)
  have hsum' :
      ‖∑ chi : DirichletCharacter ℂ (fixedQPeriod q),
          sawtoothWeightedCharacterSum
            (fixedQPeriod q) w (movingVCoeff q h) chi T X‖
        ≤ ε * Real.log T := by
    calc
      _ ≤ Cn * (6 * (fixedQPeriod q : ℝ) *
          (δ * Real.log T)) := hsum
      _ = (Cn * (6 * (fixedQPeriod q : ℝ)) * δ) *
          Real.log T := by ring
      _ ≤ ε * Real.log T :=
        mul_le_mul_of_nonneg_right hcoeff hlog0
  have hcast :
      ((supportedSawtoothSum
          (fixedQPeriod q) w (movingVCoeff q h) T X : ℝ) : ℂ) =
        ∑ chi : DirichletCharacter ℂ (fixedQPeriod q),
          sawtoothWeightedCharacterSum
            (fixedQPeriod q) w (movingVCoeff q h) chi T X := by
    simpa [sawtoothWeightedCharacterSum] using hexp
  have hn :
      ‖((supportedSawtoothSum
          (fixedQPeriod q) w (movingVCoeff q h) T X : ℝ) : ℂ)‖
        ≤ ε * Real.log T := by
    rw [hcast]
    exact hsum'
  simpa [Complex.norm_real, Real.norm_eq_abs] using hn

#print axioms supportedSawtoothSum_moving_sublog_of_r0002

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem supportedSawtoothSum_eta_sublog_of_r0002
    (q : ℕ) (hq : 0 < q) [NeZero (fixedQPeriod q)]
    (hbase : PetermannMinimalConsumerR0002Spec q PetermannBase.eta) :
    ∀ ε : ℝ, 0 < ε →
      ∃ T0 : ℝ, ∀
        (w : ℕ → ℝ),
          (∀ c ∈ Finset.Icc 1 (fixedQPeriod q), |w c| ≤ 6) →
        ∀ (T : ℝ) (X : ℕ),
          T0 ≤ T →
          (2 * fixedQPeriod q : ℝ) ≤ T →
          1 ≤ X →
          (X : ℝ) ≤ T →
          |supportedSawtoothSum
              (fixedQPeriod q) w (etaCoeff q) T X|
            ≤ ε * Real.log T := by
  intro ε hε
  let Cn : ℝ :=
    (Fintype.card
      (DirichletCharacter ℂ (fixedQPeriod q)) : ℝ)
  let D : ℝ := Cn * (6 * (fixedQPeriod q : ℝ))
  have hCn0 : 0 ≤ Cn := by
    dsimp [Cn]
    positivity
  have hD0 : 0 ≤ D := by
    dsimp [D]
    positivity
  let δ : ℝ := ε / (D + 1)
  have hδ : 0 < δ := by
    dsimp [δ]
    positivity
  obtain ⟨T0, hT0⟩ := hbase δ hδ
  refine ⟨T0, ?_⟩
  intro w hw T X hT0' h2 hX1 hXT
  have hLpos : 0 < fixedQPeriod q := by
    unfold fixedQPeriod
    exact Nat.lcm_pos (by norm_num) hq
  have hT1 : 1 ≤ T := by
    have hLR : (1 : ℝ) ≤ fixedQPeriod q := by exact_mod_cast hLpos
    linarith
  have hlog0 : 0 ≤ Real.log T := Real.log_nonneg hT1
  have hsupp :
      ∀ e : ℕ, etaCoeff q e ≠ 0 →
        e.Coprime (fixedQPeriod q) :=
    fun e he => etaCoeff_coprime_fixedQPeriod_of_ne_zero he
  have hexp :=
    supportedSawtoothSum_character_expansion
      (fixedQPeriod q) w (etaCoeff q) T X hsupp
  have hkernel :
      ∀ (chi : DirichletCharacter ℂ (fixedQPeriod q)) (r : ℤ),
        ‖genericPetermannKernelSum
            (fixedQPeriod q) (etaCoeff q) chi r T X‖
          ≤ δ * Real.log T := by
    intro chi r
    change ‖petermannBaseKernelSum q PetermannBase.eta chi r T X‖ ≤
      δ * Real.log T
    exact hT0 chi r T X hT0'
      (by simpa [fixedQPeriod] using h2) hX1 hXT
  have hsum :
      ‖∑ chi : DirichletCharacter ℂ (fixedQPeriod q),
          sawtoothWeightedCharacterSum
            (fixedQPeriod q) w (etaCoeff q) chi T X‖
        ≤ Cn * (6 * (fixedQPeriod q : ℝ) *
          (δ * Real.log T)) := by
    calc
      ‖∑ chi : DirichletCharacter ℂ (fixedQPeriod q),
          sawtoothWeightedCharacterSum
            (fixedQPeriod q) w (etaCoeff q) chi T X‖
        ≤ ∑ chi : DirichletCharacter ℂ (fixedQPeriod q),
            ‖sawtoothWeightedCharacterSum
              (fixedQPeriod q) w (etaCoeff q) chi T X‖ :=
          norm_sum_le _ _
      _ ≤ ∑ _chi : DirichletCharacter ℂ (fixedQPeriod q),
            (6 * (fixedQPeriod q : ℝ) *
              (δ * Real.log T)) := by
        apply Finset.sum_le_sum
        intro chi hchi
        exact norm_sawtoothWeightedCharacterSum_le_kernel
          (fixedQPeriod q) w (etaCoeff q) hw chi T X
          (δ * Real.log T) (mul_nonneg hδ.le hlog0)
          (hkernel chi)
      _ = Cn * (6 * (fixedQPeriod q : ℝ) *
            (δ * Real.log T)) := by
        simp [Cn]
  have hden : 0 < Cn * (6 * (fixedQPeriod q : ℝ)) + 1 := by
    positivity
  have hcoeff : Cn * (6 * (fixedQPeriod q : ℝ)) * δ ≤ ε := by
    dsimp [δ, D]
    rw [show
      Cn * (6 * (fixedQPeriod q : ℝ)) *
          (ε / (Cn * (6 * (fixedQPeriod q : ℝ)) + 1)) =
        ε * (Cn * (6 * (fixedQPeriod q : ℝ)) /
          (Cn * (6 * (fixedQPeriod q : ℝ)) + 1)) by ring]
    apply mul_le_of_le_one_right hε.le
    exact (div_le_one hden).2 (by linarith)
  have hsum' :
      ‖∑ chi : DirichletCharacter ℂ (fixedQPeriod q),
          sawtoothWeightedCharacterSum
            (fixedQPeriod q) w (etaCoeff q) chi T X‖
        ≤ ε * Real.log T := by
    calc
      _ ≤ Cn * (6 * (fixedQPeriod q : ℝ) *
          (δ * Real.log T)) := hsum
      _ = (Cn * (6 * (fixedQPeriod q : ℝ)) * δ) *
          Real.log T := by ring
      _ ≤ ε * Real.log T :=
        mul_le_mul_of_nonneg_right hcoeff hlog0
  have hcast :
      ((supportedSawtoothSum
          (fixedQPeriod q) w (etaCoeff q) T X : ℝ) : ℂ) =
        ∑ chi : DirichletCharacter ℂ (fixedQPeriod q),
          sawtoothWeightedCharacterSum
            (fixedQPeriod q) w (etaCoeff q) chi T X := by
    simpa [sawtoothWeightedCharacterSum] using hexp
  have hn :
      ‖((supportedSawtoothSum
          (fixedQPeriod q) w (etaCoeff q) T X : ℝ) : ℂ)‖
        ≤ ε * Real.log T := by
    rw [hcast]
    exact hsum'
  simpa [Complex.norm_real, Real.norm_eq_abs] using hn

#print axioms supportedSawtoothSum_eta_sublog_of_r0002

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem admissibleInteriorCount_le_height
    (q a h : ℕ) :
    admissibleInteriorCount q a h ≤ h := by
  unfold admissibleInteriorCount
  calc
    ((Finset.Ioo a (a + h)).filter fun x => q.Coprime x).card
      ≤ (Finset.Ioo a (a + h)).card := Finset.card_filter_le _ _
    _ = h - 1 := by simp
    _ ≤ h := Nat.sub_le _ _

theorem sourceDensityCoeff_eq_fixed_error
    {q a b H n : ℕ}
    (hq : 0 < q)
    (hcompat :
      2 * H = positiveGapRepresentative q a b + n * q) :
    ((H - 1 : ℕ) : ℝ) * fixedQRowMean q -
        (admissibleInteriorCount q a (2 * H) : ℝ) =
      - fixedQRowMean q - (periodicError q a b : ℝ) := by
  have hcount := exactPeriodicCount_real
    (q := q) (a := a) (b := b) hq n
  rw [hcompat, hcount]
  have hH : 1 ≤ H := by
    have hp := positiveGapRepresentative_pos (q := q) (a := a) (b := b) hq
    omega
  have hcompatR :
      (2 : ℝ) * (H : ℝ) =
        (positiveGapRepresentative q a b : ℝ) +
          (n : ℝ) * (q : ℝ) := by
    exact_mod_cast hcompat
  rw [← hcompatR]
  rw [Nat.cast_sub hH]
  unfold fixedQRowMean
  have hqR : (q : ℝ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hq)
  field_simp [hqR]
  ring

#print axioms admissibleInteriorCount_le_height
#print axioms sourceDensityCoeff_eq_fixed_error

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def movingBoundaryRemainderBound (q : ℕ) : ℝ :=
  (Fintype.card (DirichletCharacter ℂ (fixedQPeriod q)) : ℝ) *
    (6 * (fixedQPeriod q : ℝ)) *
    ((((2 * (6 * q) + 9) * omegaRankinBound) *
        petermannCorrectionL1UniformBound +
      omegaRankinBound *
        (petermannCorrectionConvolutionMomentBound +
          petermannCorrectionLogUniformBound)) +
      (2 * ((Nat.lcm 6 q : ℕ) + 1) * omegaRankinBound) *
        petermannCorrectionL1UniformBound)

theorem abs_movingBoundary_remainder_le
    (q r H : ℕ) (hq : 0 < q) (hr : q.Coprime r)
    (hH : 2 ≤ H) [NeZero (fixedQPeriod q)] :
    |cStarReal q (2 * H) *
        supportedBoundarySum
          (fixedQPeriod q)
          (occupiedReducedFixedQLowWeight q r H)
          (movingVCoeff q (2 * H)) (H - 1) -
      cStarReal q (2 * H) *
        principalBoundaryAverage (fixedQPeriod q)
          (occupiedReducedFixedQLowWeight q r H) *
        logarithmicEulerResidue (movingVCoeff q (2 * H)) *
        Real.log ((H - 1 : ℕ) : ℝ)| ≤
      movingBoundaryRemainderBound q := by
  classical
  let L := fixedQPeriod q
  let w := occupiedReducedFixedQLowWeight q r H
  let u := movingVCoeff q (2 * H)
  let X := H - 1
  let c := cStarReal q (2 * H)
  let F := logarithmicEulerResidue (movingVCoeff q (2 * H))
  let Bbar := principalBoundaryAverage L w
  let CP : ℝ :=
    ((2 * (6 * q) + 9) * omegaRankinBound) *
        petermannCorrectionL1UniformBound +
      omegaRankinBound *
        (petermannCorrectionConvolutionMomentBound +
          petermannCorrectionLogUniformBound)
  let CN : ℝ :=
    (2 * ((Nat.lcm 6 q : ℕ) + 1) * omegaRankinBound) *
      petermannCorrectionL1UniformBound
  have hX : 1 ≤ X := by dsimp [X]; omega
  have hh : 2 * H ≠ 0 := by omega
  have hw :
      ∀ z ∈ Finset.Icc 1 L, |w z| ≤ 6 := by
    intro z hz
    dsimp [w]
    exact abs_occupiedReducedFixedQLowWeight_le_six q r H z
  have hsupp :
      ∀ e : ℕ, u e ≠ 0 → e.Coprime L := by
    intro e he
    dsimp [u, L] at he ⊢
    exact movingVCoeff_coprime_fixedQPeriod_of_ne_zero he
  have hexp :=
    supportedBoundarySum_character_expansion L w u X hsupp
  have hPspec := movingVPrincipalLogMeanSpec q (2 * H) hq hh
  have hP := hPspec.2 X hX
  have hNspec := movingVNonprincipalCharacterBoundSpec q (2 * H) hq hh
  have hCP0 : 0 ≤ CP := by
    simpa [CP] using hPspec.1
  have hCN0 : 0 ≤ CN := by
    simpa [CN] using hNspec.1
  have hc : |c| ≤ 1 := by
    dsimp [c]
    exact abs_cStarReal_le_one q (2 * H)
  have hsum :
      ‖(supportedBoundarySum L w u X : ℂ) -
          ((Bbar * F * Real.log (X : ℝ) : ℝ) : ℂ)‖
        ≤ (Fintype.card (DirichletCharacter ℂ L) : ℝ) *
            (6 * (L : ℝ)) * (CP + CN) := by
    rw [hexp]
    let M : ℂ :=
      boundaryCharacterCoeff L w
          (1 : DirichletCharacter ℂ L) *
        ((F * Real.log (X : ℝ) : ℝ) : ℂ)
    have hM :
        M = ((Bbar * F * Real.log (X : ℝ) : ℝ) : ℂ) := by
      dsimp [M, Bbar]
      rw [boundaryCharacterCoeff_one_eq_principalBoundaryAverage]
      push_cast
      ring
    rw [← hM]
    have hmain :
        M = ∑ chi : DirichletCharacter ℂ L,
          if chi = 1 then M else 0 := by
      classical
      simp
    rw [hmain, ← Finset.sum_sub_distrib]
    calc
      ‖∑ chi : DirichletCharacter ℂ L,
          (boundaryCharacterCoeff L w chi *
              characterCoefficientPartialSum chi u X -
            if chi = 1 then M else 0)‖
        ≤ ∑ chi : DirichletCharacter ℂ L,
            ‖boundaryCharacterCoeff L w chi *
                characterCoefficientPartialSum chi u X -
              if chi = 1 then M else 0‖ := norm_sum_le _ _
      _ ≤ ∑ _chi : DirichletCharacter ℂ L,
            ((6 * (L : ℝ)) * (CP + CN)) := by
        apply Finset.sum_le_sum
        intro chi hchi
        by_cases hprincipal : chi = 1
        · subst chi
          simp only [if_pos rfl]
          dsimp [M]
          rw [← mul_sub]
          rw [norm_mul]
          have hb := norm_boundaryCharacterCoeff_le L w hw
            (1 : DirichletCharacter ℂ L)
          have hchar := principalCharacterPartialSum_moving q (2 * H) X
          rw [hchar]
          have hp' : |coefficientPartialSum u X -
              F * Real.log (X : ℝ)| ≤ CP := by
            simpa [u, F, CP] using hP
          let Ereal : ℝ :=
            coefficientPartialSum u X - F * Real.log (X : ℝ)
          have hpC : ‖(Ereal : ℂ)‖ ≤ CP := by
            rw [Complex.norm_real]
            exact hp'
          have hdiff :
              ((coefficientPartialSum u X : ℂ) -
                ((F * Real.log (X : ℝ) : ℝ) : ℂ)) =
                (Ereal : ℂ) := by
            dsimp [Ereal]
            exact (map_sub Complex.ofRealHom _ _).symm
          rw [hdiff]
          calc
            ‖boundaryCharacterCoeff L w
                (1 : DirichletCharacter ℂ L)‖ *
                ‖(Ereal : ℂ)‖
              ≤ (6 * (L : ℝ)) * CP :=
                mul_le_mul hb hpC (norm_nonneg _) (by positivity)
            _ ≤ (6 * (L : ℝ)) * (CP + CN) := by
              exact mul_le_mul_of_nonneg_left
                (le_add_of_nonneg_right hCN0) (by positivity)
        · simp only [if_neg hprincipal, sub_zero]
          rw [norm_mul]
          have hb := norm_boundaryCharacterCoeff_le L w hw chi
          have hn := hNspec.2 chi hprincipal X hX
          have hn' :
              ‖characterCoefficientPartialSum chi u X‖ ≤ CN := by
            dsimp [u, CN]
            exact hn
          calc
            ‖boundaryCharacterCoeff L w chi‖ *
                ‖characterCoefficientPartialSum chi u X‖
              ≤ (6 * (L : ℝ)) * CN := by
                exact mul_le_mul hb hn'
                  (norm_nonneg _) (by positivity)
            _ ≤ (6 * (L : ℝ)) * (CP + CN) := by
              exact mul_le_mul_of_nonneg_left
                (le_add_of_nonneg_left hCP0) (by positivity)
      _ = (Fintype.card (DirichletCharacter ℂ L) : ℝ) *
            (6 * (L : ℝ)) * (CP + CN) := by
        simp
        ring
  let Dreal : ℝ :=
    supportedBoundarySum L w u X -
      Bbar * F * Real.log (X : ℝ)
  have hdiffR :
      (supportedBoundarySum L w u X : ℂ) -
        ((Bbar * F * Real.log (X : ℝ) : ℝ) : ℂ) =
        (Dreal : ℂ) := by
    dsimp [Dreal]
    exact (map_sub Complex.ofRealHom _ _).symm
  have hsumR :
      |supportedBoundarySum L w u X -
        Bbar * F * Real.log (X : ℝ)| ≤
        (Fintype.card (DirichletCharacter ℂ L) : ℝ) *
          (6 * (L : ℝ)) * (CP + CN) := by
    rw [hdiffR] at hsum
    rw [Complex.norm_real] at hsum
    simpa [Dreal] using hsum
  have hscaled :
      |c * supportedBoundarySum L w u X -
        c * Bbar * F * Real.log (X : ℝ)| ≤
        (Fintype.card (DirichletCharacter ℂ L) : ℝ) *
          (6 * (L : ℝ)) * (CP + CN) := by
    rw [show c * supportedBoundarySum L w u X -
        c * Bbar * F * Real.log (X : ℝ) =
      c * (supportedBoundarySum L w u X -
        Bbar * F * Real.log (X : ℝ)) by ring, abs_mul]
    calc
      |c| * |supportedBoundarySum L w u X -
          Bbar * F * Real.log (X : ℝ)|
        ≤ 1 * ((Fintype.card (DirichletCharacter ℂ L) : ℝ) *
            (6 * (L : ℝ)) * (CP + CN)) := by
          exact mul_le_mul hc hsumR (abs_nonneg _) (by norm_num)
      _ = _ := by ring
  simpa [movingBoundaryRemainderBound, L, w, u, X, c, F, Bbar, CP, CN]
    using hscaled

#print axioms abs_movingBoundary_remainder_le

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def etaBoundaryRemainderBound (q : ℕ) : ℝ :=
  (Fintype.card (DirichletCharacter ℂ (fixedQPeriod q)) : ℝ) *
    (6 * (fixedQPeriod q : ℝ)) *
    (((2 * (6 * q) + 9) * etaRankinBound) +
      (2 * ((Nat.lcm 6 q : ℕ) + 1) * etaRankinBound))

theorem abs_etaBoundary_remainder_le
    (q r H : ℕ) (hq : 0 < q) (hr : q.Coprime r)
    (hH : 2 ≤ H) [NeZero (fixedQPeriod q)] :
    |freeHighBaseline q *
        supportedBoundarySum
          (fixedQPeriod q)
          (freeReducedFixedQLowWeight q r)
          (etaCoeff q) (H - 1) -
      freeHighBaseline q *
        principalBoundaryAverage (fixedQPeriod q)
          (freeReducedFixedQLowWeight q r) *
        logarithmicEulerResidue (etaCoeff q) *
        Real.log ((H - 1 : ℕ) : ℝ)| ≤
      etaBoundaryRemainderBound q := by
  classical
  let L := fixedQPeriod q
  let w := freeReducedFixedQLowWeight q r
  let u := etaCoeff q
  let X := H - 1
  let c := freeHighBaseline q
  let F := logarithmicEulerResidue (etaCoeff q)
  let Bbar := principalBoundaryAverage L w
  let CP : ℝ := (2 * (6 * q) + 9) * etaRankinBound
  let CN : ℝ :=
    2 * ((Nat.lcm 6 q : ℕ) + 1) * etaRankinBound
  have hX : 1 ≤ X := by dsimp [X]; omega
  have hw :
      ∀ z ∈ Finset.Icc 1 L, |w z| ≤ 6 := by
    intro z hz
    dsimp [w]
    exact abs_freeReducedFixedQLowWeight_le_six q r z
  have hsupp :
      ∀ e : ℕ, u e ≠ 0 → e.Coprime L := by
    intro e he
    dsimp [u, L] at he ⊢
    exact etaCoeff_coprime_fixedQPeriod_of_ne_zero he
  have hexp :=
    supportedBoundarySum_character_expansion L w u X hsupp
  have hPspec := etaPrincipalLogMeanSpec q hq
  have hP := hPspec.2 X hX
  have hNspec := etaNonprincipalCharacterBoundSpec q hq
  have hCP0 : 0 ≤ CP := by
    simpa [CP] using hPspec.1
  have hCN0 : 0 ≤ CN := by
    simpa [CN] using hNspec.1
  have hc : |c| ≤ 1 := by
    dsimp [c, freeHighBaseline]
    exact abs_cStarReal_le_one q 0
  have hsum :
      ‖(supportedBoundarySum L w u X : ℂ) -
          ((Bbar * F * Real.log (X : ℝ) : ℝ) : ℂ)‖
        ≤ (Fintype.card (DirichletCharacter ℂ L) : ℝ) *
            (6 * (L : ℝ)) * (CP + CN) := by
    rw [hexp]
    let M : ℂ :=
      boundaryCharacterCoeff L w
          (1 : DirichletCharacter ℂ L) *
        ((F * Real.log (X : ℝ) : ℝ) : ℂ)
    have hM :
        M = ((Bbar * F * Real.log (X : ℝ) : ℝ) : ℂ) := by
      dsimp [M, Bbar]
      rw [boundaryCharacterCoeff_one_eq_principalBoundaryAverage]
      push_cast
      ring
    rw [← hM]
    have hmain :
        M = ∑ chi : DirichletCharacter ℂ L,
          if chi = 1 then M else 0 := by
      simp
    rw [hmain, ← Finset.sum_sub_distrib]
    calc
      ‖∑ chi : DirichletCharacter ℂ L,
          (boundaryCharacterCoeff L w chi *
              characterCoefficientPartialSum chi u X -
            if chi = 1 then M else 0)‖
        ≤ ∑ chi : DirichletCharacter ℂ L,
            ‖boundaryCharacterCoeff L w chi *
                characterCoefficientPartialSum chi u X -
              if chi = 1 then M else 0‖ := norm_sum_le _ _
      _ ≤ ∑ _chi : DirichletCharacter ℂ L,
            ((6 * (L : ℝ)) * (CP + CN)) := by
        apply Finset.sum_le_sum
        intro chi hchi
        by_cases hprincipal : chi = 1
        · subst chi
          simp only [if_pos rfl]
          dsimp [M]
          rw [← mul_sub]
          rw [norm_mul]
          have hb := norm_boundaryCharacterCoeff_le L w hw
            (1 : DirichletCharacter ℂ L)
          have hchar := principalCharacterPartialSum_eta q X
          rw [hchar]
          have hp' : |coefficientPartialSum u X -
              F * Real.log (X : ℝ)| ≤ CP := by
            simpa [u, F, CP] using hP
          let Ereal : ℝ :=
            coefficientPartialSum u X - F * Real.log (X : ℝ)
          have hpC : ‖(Ereal : ℂ)‖ ≤ CP := by
            rw [Complex.norm_real]
            exact hp'
          have hdiff :
              ((coefficientPartialSum u X : ℂ) -
                ((F * Real.log (X : ℝ) : ℝ) : ℂ)) =
                (Ereal : ℂ) := by
            dsimp [Ereal]
            exact (map_sub Complex.ofRealHom _ _).symm
          rw [hdiff]
          calc
            ‖boundaryCharacterCoeff L w
                (1 : DirichletCharacter ℂ L)‖ *
                ‖(Ereal : ℂ)‖
              ≤ (6 * (L : ℝ)) * CP :=
                mul_le_mul hb hpC (norm_nonneg _) (by positivity)
            _ ≤ (6 * (L : ℝ)) * (CP + CN) := by
              exact mul_le_mul_of_nonneg_left
                (le_add_of_nonneg_right hCN0) (by positivity)
        · simp only [if_neg hprincipal, sub_zero]
          rw [norm_mul]
          have hb := norm_boundaryCharacterCoeff_le L w hw chi
          have hn := hNspec.2 chi hprincipal X hX
          have hn' :
              ‖characterCoefficientPartialSum chi u X‖ ≤ CN := by
            dsimp [u, CN]
            exact hn
          calc
            ‖boundaryCharacterCoeff L w chi‖ *
                ‖characterCoefficientPartialSum chi u X‖
              ≤ (6 * (L : ℝ)) * CN := by
                exact mul_le_mul hb hn'
                  (norm_nonneg _) (by positivity)
            _ ≤ (6 * (L : ℝ)) * (CP + CN) := by
              exact mul_le_mul_of_nonneg_left
                (le_add_of_nonneg_left hCP0) (by positivity)
      _ = (Fintype.card (DirichletCharacter ℂ L) : ℝ) *
            (6 * (L : ℝ)) * (CP + CN) := by
        simp
        ring
  let Dreal : ℝ :=
    supportedBoundarySum L w u X -
      Bbar * F * Real.log (X : ℝ)
  have hdiffR :
      (supportedBoundarySum L w u X : ℂ) -
        ((Bbar * F * Real.log (X : ℝ) : ℝ) : ℂ) =
        (Dreal : ℂ) := by
    dsimp [Dreal]
    exact (map_sub Complex.ofRealHom _ _).symm
  have hsumR :
      |supportedBoundarySum L w u X -
        Bbar * F * Real.log (X : ℝ)| ≤
        (Fintype.card (DirichletCharacter ℂ L) : ℝ) *
          (6 * (L : ℝ)) * (CP + CN) := by
    rw [hdiffR] at hsum
    rw [Complex.norm_real] at hsum
    simpa [Dreal] using hsum
  have hscaled :
      |c * supportedBoundarySum L w u X -
        c * Bbar * F * Real.log (X : ℝ)| ≤
        (Fintype.card (DirichletCharacter ℂ L) : ℝ) *
          (6 * (L : ℝ)) * (CP + CN) := by
    rw [show c * supportedBoundarySum L w u X -
        c * Bbar * F * Real.log (X : ℝ) =
      c * (supportedBoundarySum L w u X -
        Bbar * F * Real.log (X : ℝ)) by ring, abs_mul]
    calc
      |c| * |supportedBoundarySum L w u X -
          Bbar * F * Real.log (X : ℝ)|
        ≤ 1 * ((Fintype.card (DirichletCharacter ℂ L) : ℝ) *
            (6 * (L : ℝ)) * (CP + CN)) := by
          exact mul_le_mul hc hsumR (abs_nonneg _) (by norm_num)
      _ = _ := by ring
  simpa [etaBoundaryRemainderBound, L, w, u, X, c, F, Bbar, CP, CN]
    using hscaled

#print axioms abs_etaBoundary_remainder_le

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem positiveGapRepresentative_le_modulus
    {q a b : ℕ} (hq : 0 < q) :
    positiveGapRepresentative q a b ≤ q := by
  unfold positiveGapRepresentative
  by_cases hr : (b % q + q - a % q) % q = 0
  · rw [if_pos hr]
  · rw [if_neg hr]
    exact Nat.le_of_lt (Nat.mod_lt _ hq)

theorem abs_periodicError_real_le_two_q
    {q a b : ℕ} (hq : 0 < q) :
    |((periodicError q a b : ℚ) : ℝ)| ≤ 2 * (q : ℝ) := by
  let h0 := positiveGapRepresentative q a b
  have hh0 : 0 < h0 := by
    dsimp [h0]
    exact positiveGapRepresentative_pos hq
  have hh0q : h0 ≤ q := by
    dsimp [h0]
    exact positiveGapRepresentative_le_modulus hq
  have hN :=
    admissibleInteriorCount_le_height q a h0
  have hNq : (admissibleInteriorCount q a h0 : ℝ) ≤ (q : ℝ) := by
    exact_mod_cast hN.trans hh0q
  have hphi : Nat.totient q ≤ q := Nat.totient_le q
  have hqR : (0 : ℝ) < q := by exact_mod_cast hq
  have hh0R : (0 : ℝ) ≤ h0 := by positivity
  have hdensity0 :
      0 ≤ (Nat.totient q : ℝ) / (q : ℝ) * (h0 : ℝ) := by
    positivity
  have hdensity1 :
      (Nat.totient q : ℝ) / (q : ℝ) * (h0 : ℝ) ≤ (q : ℝ) := by
    have hratio :
        (Nat.totient q : ℝ) / (q : ℝ) ≤ 1 := by
      rw [div_le_one hqR]
      exact_mod_cast hphi
    have hh0qR : (h0 : ℝ) ≤ (q : ℝ) := by exact_mod_cast hh0q
    calc
      (Nat.totient q : ℝ) / (q : ℝ) * (h0 : ℝ)
          ≤ 1 * (h0 : ℝ) :=
        mul_le_mul_of_nonneg_right hratio hh0R
      _ ≤ q := by simpa using hh0qR
  unfold periodicError
  dsimp [h0]
  push_cast
  calc
    |(admissibleInteriorCount q a
          (positiveGapRepresentative q a b) : ℝ) -
        (Nat.totient q : ℝ) / (q : ℝ) *
          (positiveGapRepresentative q a b : ℝ)|
      ≤ |(admissibleInteriorCount q a
          (positiveGapRepresentative q a b) : ℝ)| +
        |(Nat.totient q : ℝ) / (q : ℝ) *
          (positiveGapRepresentative q a b : ℝ)| :=
        abs_sub _ _
    _ = (admissibleInteriorCount q a
          (positiveGapRepresentative q a b) : ℝ) +
        ((Nat.totient q : ℝ) / (q : ℝ) *
          (positiveGapRepresentative q a b : ℝ)) := by
          rw [abs_of_nonneg (by positivity), abs_of_nonneg hdensity0]
    _ ≤ (q : ℝ) + q := add_le_add hNq hdensity1
    _ = 2 * q := by ring

noncomputable def etaReciprocalPrefix
    (q X : ℕ) : ℝ :=
  ∑ e ∈ Finset.Icc 1 X, etaReciprocalTerm q e

theorem etaReciprocalPrefix_eq_shifted
    (q X : ℕ) :
    etaReciprocalPrefix q X =
      ∑ j ∈ Finset.range X, etaReciprocalTerm q (j + 1) := by
  unfold etaReciprocalPrefix
  refine Finset.sum_bij
    (fun e he => e - 1)
    ?_ ?_ ?_ ?_
  · intro e he
    rw [Finset.mem_Icc] at he
    rw [Finset.mem_range]
    omega
  · intro e1 he1 e2 he2 heq
    rw [Finset.mem_Icc] at he1 he2
    omega
  · intro j hj
    rw [Finset.mem_range] at hj
    refine ⟨j + 1, ?_, ?_⟩
    · rw [Finset.mem_Icc]
      omega
    · omega
  · intro e he
    rw [Finset.mem_Icc] at he
    rw [Nat.sub_add_cancel he.1]

theorem etaReciprocalPrefix_nonneg
    (q X : ℕ) :
    0 ≤ etaReciprocalPrefix q X := by
  unfold etaReciprocalPrefix
  exact Finset.sum_nonneg fun e he =>
    etaReciprocalTerm_nonneg q e

theorem etaReciprocalPrefix_le
    (q X : ℕ) :
    etaReciprocalPrefix q X ≤ 1 + 4 * etaRankinBound := by
  rw [etaReciprocalPrefix_eq_shifted]
  exact shifted_etaReciprocal_sum_range_le q X

theorem movingVReciprocalPrefix_nonneg
    (q h X : ℕ) :
    0 ≤ movingVReciprocalPrefix q h X := by
  unfold movingVReciprocalPrefix
  exact Finset.sum_nonneg fun e he =>
    movingVReciprocalTerm_nonneg q h e

theorem movingVReciprocalPrefix_le_omega
    (q h X : ℕ) :
    movingVReciprocalPrefix q h X ≤
      omegaReciprocalPrefix q X := by
  unfold movingVReciprocalPrefix omegaReciprocalPrefix
  exact Finset.sum_le_sum fun e he =>
    movingVReciprocalTerm_le_omega q h e

theorem movingVReciprocalPrefix_le
    (q h X : ℕ) :
    movingVReciprocalPrefix q h X ≤
      1 + 4 * omegaRankinBound := by
  exact (movingVReciprocalPrefix_le_omega q h X).trans
    (omegaReciprocalPrefix_le q X)

#print axioms abs_periodicError_real_le_two_q
#print axioms etaReciprocalPrefix_le
#print axioms movingVReciprocalPrefix_le

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def oneDimensionalDensityCoeff
    (q r H : ℕ) : ℝ :=
  ((H - 1 : ℕ) : ℝ) * fixedQRowMean q -
    (admissibleInteriorCount q r (2 * H) : ℝ)

noncomputable def manuscriptQ1FloorKernel
    (q r H : ℕ) [NeZero (fixedQPeriod q)] : ℝ :=
  let X := H - 1
  let N := admissibleInteriorCount q r (2 * H)
  let w := occupiedReducedFixedQLowWeight q r H
  let u := movingVCoeff q (2 * H)
  cStarReal q (2 * H) *
    (oneDimensionalDensityCoeff q r H *
        movingVReciprocalPrefix q (2 * H) X +
      supportedBoundarySum (fixedQPeriod q) w u X -
      supportedSawtoothSum (fixedQPeriod q) w u (X : ℝ) X -
      (N : ℝ) * movingVReciprocalTail q (2 * H) X)

noncomputable def manuscriptS1FloorKernel
    (q r H : ℕ) [NeZero (fixedQPeriod q)] : ℝ :=
  let X := H - 1
  let N := admissibleInteriorCount q r (2 * H)
  let w := freeReducedFixedQLowWeight q r
  let u := etaCoeff q
  freeHighBaseline q *
    (oneDimensionalDensityCoeff q r H *
        etaReciprocalPrefix q X +
      supportedBoundarySum (fixedQPeriod q) w u X -
      supportedSawtoothSum (fixedQPeriod q) w u (X : ℝ) X -
      (N : ℝ) * etaReciprocalTail q X)

noncomputable def oneDimensionalDensityCoeffBound
    (q : ℕ) : ℝ :=
  |fixedQRowMean q| + 2 * (q : ℝ)

theorem abs_oneDimensionalDensityCoeff_le
    {q a b H n : ℕ}
    (hq : 0 < q)
    (hcompat :
      2 * H = positiveGapRepresentative q a b + n * q) :
    |oneDimensionalDensityCoeff q a H| ≤
      oneDimensionalDensityCoeffBound q := by
  have hEq := sourceDensityCoeff_eq_fixed_error
    (q := q) (a := a) (b := b) (H := H) (n := n)
    hq hcompat
  have hper := abs_periodicError_real_le_two_q
    (q := q) (a := a) (b := b) hq
  unfold oneDimensionalDensityCoeff oneDimensionalDensityCoeffBound
  rw [hEq]
  calc
    |-fixedQRowMean q - ((periodicError q a b : ℚ) : ℝ)|
      = |fixedQRowMean q + ((periodicError q a b : ℚ) : ℝ)| := by
          rw [show -fixedQRowMean q -
              ((periodicError q a b : ℚ) : ℝ) =
            -(fixedQRowMean q +
              ((periodicError q a b : ℚ) : ℝ)) by ring,
            abs_neg]
    _ ≤ |fixedQRowMean q| +
        |((periodicError q a b : ℚ) : ℝ)| := abs_add_le _ _
    _ ≤ |fixedQRowMean q| + 2 * (q : ℝ) :=
      add_le_add (le_refl _) hper

#print axioms abs_oneDimensionalDensityCoeff_le

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def oneDimensionalDensityBracketBound
    (q : ℕ) : ℝ :=
  oneDimensionalDensityCoeffBound q *
    ((1 + 4 * omegaRankinBound) +
      (1 + 4 * etaRankinBound))

theorem abs_oneDimensionalDensity_difference_le
    {q a b H n : ℕ}
    (hq : 0 < q)
    (hcompat :
      2 * H = positiveGapRepresentative q a b + n * q) :
    |cStarReal q (2 * H) *
          oneDimensionalDensityCoeff q a H *
          movingVReciprocalPrefix q (2 * H) (H - 1) -
      freeHighBaseline q *
          oneDimensionalDensityCoeff q a H *
          etaReciprocalPrefix q (H - 1)| ≤
      oneDimensionalDensityBracketBound q := by
  let D := oneDimensionalDensityCoeff q a H
  let M := movingVReciprocalPrefix q (2 * H) (H - 1)
  let E := etaReciprocalPrefix q (H - 1)
  let BD := oneDimensionalDensityCoeffBound q
  let BM := 1 + 4 * omegaRankinBound
  let BE := 1 + 4 * etaRankinBound
  have hD : |D| ≤ BD := by
    dsimp [D, BD]
    exact abs_oneDimensionalDensityCoeff_le hq hcompat
  have hBD0 : 0 ≤ BD := by
    dsimp [BD, oneDimensionalDensityCoeffBound]
    positivity
  have hM0 : 0 ≤ M := by
    dsimp [M]
    exact movingVReciprocalPrefix_nonneg q (2 * H) (H - 1)
  have hE0 : 0 ≤ E := by
    dsimp [E]
    exact etaReciprocalPrefix_nonneg q (H - 1)
  have hM : M ≤ BM := by
    dsimp [M, BM]
    exact movingVReciprocalPrefix_le q (2 * H) (H - 1)
  have hE : E ≤ BE := by
    dsimp [E, BE]
    exact etaReciprocalPrefix_le q (H - 1)
  have hBM0 : 0 ≤ BM := hM0.trans hM
  have hBE0 : 0 ≤ BE := hE0.trans hE
  have hc : |cStarReal q (2 * H)| ≤ 1 :=
    abs_cStarReal_le_one q (2 * H)
  have hf : |freeHighBaseline q| ≤ 1 := by
    unfold freeHighBaseline
    exact abs_cStarReal_le_one q 0
  have hleft :
      |cStarReal q (2 * H) * D * M| ≤ BD * BM := by
    rw [abs_mul, abs_mul, abs_of_nonneg hM0]
    have hcmD :
        |cStarReal q (2 * H)| * |D| ≤ BD := by
      calc
        |cStarReal q (2 * H)| * |D|
            ≤ 1 * |D| :=
          mul_le_mul_of_nonneg_right hc (abs_nonneg D)
        _ = |D| := one_mul _
        _ ≤ BD := hD
    exact (mul_le_mul_of_nonneg_right hcmD hM0).trans
      (mul_le_mul_of_nonneg_left hM hBD0)
  have hright :
      |freeHighBaseline q * D * E| ≤ BD * BE := by
    rw [abs_mul, abs_mul, abs_of_nonneg hE0]
    have hcfD :
        |freeHighBaseline q| * |D| ≤ BD := by
      calc
        |freeHighBaseline q| * |D|
            ≤ 1 * |D| :=
          mul_le_mul_of_nonneg_right hf (abs_nonneg D)
        _ = |D| := one_mul _
        _ ≤ BD := hD
    exact (mul_le_mul_of_nonneg_right hcfD hE0).trans
      (mul_le_mul_of_nonneg_left hE hBD0)
  calc
    |cStarReal q (2 * H) * D * M -
        freeHighBaseline q * D * E|
      ≤ |cStarReal q (2 * H) * D * M| +
          |freeHighBaseline q * D * E| := abs_sub _ _
    _ ≤ BD * BM + BD * BE := add_le_add hleft hright
    _ = oneDimensionalDensityBracketBound q := by
      dsimp [BD, BM, BE, oneDimensionalDensityBracketBound]
      ring

noncomputable def oneDimensionalBoundaryBracketBound
    (q : ℕ) : ℝ :=
  movingBoundaryRemainderBound q +
    etaBoundaryRemainderBound q

theorem abs_oneDimensionalBoundary_difference_le
    (q r H : ℕ) (hq : 0 < q) (hr : q.Coprime r)
    (hH : 2 ≤ H) [NeZero (fixedQPeriod q)] :
    |cStarReal q (2 * H) *
        supportedBoundarySum
          (fixedQPeriod q)
          (occupiedReducedFixedQLowWeight q r H)
          (movingVCoeff q (2 * H)) (H - 1) -
      freeHighBaseline q *
        supportedBoundarySum
          (fixedQPeriod q)
          (freeReducedFixedQLowWeight q r)
          (etaCoeff q) (H - 1)| ≤
      oneDimensionalBoundaryBracketBound q := by
  let X := H - 1
  let Bm :=
    principalBoundaryAverage (fixedQPeriod q)
      (occupiedReducedFixedQLowWeight q r H)
  let Be :=
    principalBoundaryAverage (fixedQPeriod q)
      (freeReducedFixedQLowWeight q r)
  let Fm := logarithmicEulerResidue (movingVCoeff q (2 * H))
  let Fe := logarithmicEulerResidue (etaCoeff q)
  let cm := cStarReal q (2 * H)
  let ce := freeHighBaseline q
  let Lg := Real.log ((H - 1 : ℕ) : ℝ)
  let Mmain := cm * Bm * Fm * Lg
  let Emain := ce * Be * Fe * Lg
  have hM := abs_movingBoundary_remainder_le q r H hq hr hH
  have hE := abs_etaBoundary_remainder_le q r H hq hr hH
  have hB :
      Bm = Be := by
    dsimp [Bm, Be]
    exact principalBoundaryAverage_anchored_eq_free q r H hr
  have hF :
      cm * Fm = ce * Fe := by
    dsimp [cm, ce, Fm, Fe]
    exact principalHighCoefficient_anchored_eq_free q (2 * H) hq
  have hmain : Mmain = Emain := by
    dsimp [Mmain, Emain]
    rw [hB]
    calc
      cm * Be * Fm * Lg = Be * (cm * Fm) * Lg := by ring
      _ = Be * (ce * Fe) * Lg := by rw [hF]
      _ = ce * Be * Fe * Lg := by ring
  have hM' :
      |cStarReal q (2 * H) *
          supportedBoundarySum
            (fixedQPeriod q)
            (occupiedReducedFixedQLowWeight q r H)
            (movingVCoeff q (2 * H)) (H - 1) -
        Mmain| ≤ movingBoundaryRemainderBound q := by
    simpa [Mmain, cm, Bm, Fm, Lg] using hM
  have hE' :
      |freeHighBaseline q *
          supportedBoundarySum
            (fixedQPeriod q)
            (freeReducedFixedQLowWeight q r)
            (etaCoeff q) (H - 1) -
        Emain| ≤ etaBoundaryRemainderBound q := by
    simpa [Emain, ce, Be, Fe, Lg] using hE
  calc
    |cStarReal q (2 * H) *
          supportedBoundarySum
            (fixedQPeriod q)
            (occupiedReducedFixedQLowWeight q r H)
            (movingVCoeff q (2 * H)) (H - 1) -
      freeHighBaseline q *
          supportedBoundarySum
            (fixedQPeriod q)
            (freeReducedFixedQLowWeight q r)
            (etaCoeff q) (H - 1)|
      = |(cStarReal q (2 * H) *
          supportedBoundarySum
            (fixedQPeriod q)
            (occupiedReducedFixedQLowWeight q r H)
            (movingVCoeff q (2 * H)) (H - 1) -
          Mmain) -
        (freeHighBaseline q *
          supportedBoundarySum
            (fixedQPeriod q)
            (freeReducedFixedQLowWeight q r)
            (etaCoeff q) (H - 1) -
          Emain)| := by rw [hmain]; ring
    _ ≤
        |cStarReal q (2 * H) *
          supportedBoundarySum
            (fixedQPeriod q)
            (occupiedReducedFixedQLowWeight q r H)
            (movingVCoeff q (2 * H)) (H - 1) -
          Mmain| +
        |freeHighBaseline q *
          supportedBoundarySum
            (fixedQPeriod q)
            (freeReducedFixedQLowWeight q r)
            (etaCoeff q) (H - 1) -
          Emain| := abs_sub _ _
    _ ≤ movingBoundaryRemainderBound q +
        etaBoundaryRemainderBound q := add_le_add hM' hE'
    _ = oneDimensionalBoundaryBracketBound q := rfl

noncomputable def oneDimensionalTailBracketBound
    (q : ℕ) : ℝ :=
  16 * omegaRankinBound + 16 * etaRankinBound

theorem abs_oneDimensionalTail_difference_le
    (q r H : ℕ) (hH : 2 ≤ H) :
    |cStarReal q (2 * H) *
        (admissibleInteriorCount q r (2 * H) : ℝ) *
        movingVReciprocalTail q (2 * H) (H - 1) -
      freeHighBaseline q *
        (admissibleInteriorCount q r (2 * H) : ℝ) *
        etaReciprocalTail q (H - 1)| ≤
      oneDimensionalTailBracketBound q := by
  let N : ℝ := admissibleInteriorCount q r (2 * H)
  let X : ℝ := ((H - 1 : ℕ) : ℝ)
  let Mt := movingVReciprocalTail q (2 * H) (H - 1)
  let Et := etaReciprocalTail q (H - 1)
  have hN0 : 0 ≤ N := by dsimp [N]; positivity
  have hNnat := admissibleInteriorCount_le_height q r (2 * H)
  have hNXnat :
      admissibleInteriorCount q r (2 * H) ≤ 4 * (H - 1) := by
    calc
      admissibleInteriorCount q r (2 * H) ≤ 2 * H := hNnat
      _ ≤ 4 * (H - 1) := by omega
  have hNX : N ≤ 4 * X := by
    dsimp [N, X]
    exact_mod_cast hNXnat
  have hM0 : 0 ≤ Mt := by
    dsimp [Mt]
    exact movingVReciprocalTail_nonneg q (2 * H) (H - 1)
  have hE0 : 0 ≤ Et := by
    dsimp [Et]
    exact etaReciprocalTail_nonneg q (H - 1)
  have hMt := movingVReciprocalTail_manuscript q (2 * H) H hH
  have hEt := etaReciprocalTail_manuscript q H hH
  have hX0 : 0 ≤ X := by dsimp [X]; positivity
  have hMt' : X * Mt ≤ 4 * omegaRankinBound := by
    simpa [X, Mt, abs_of_nonneg (mul_nonneg hX0 hM0)] using hMt
  have hEt' : X * Et ≤ 4 * etaRankinBound := by
    simpa [X, Et, abs_of_nonneg (mul_nonneg hX0 hE0)] using hEt
  have hNM : N * Mt ≤ 16 * omegaRankinBound := by
    calc
      N * Mt ≤ (4 * X) * Mt :=
        mul_le_mul_of_nonneg_right hNX hM0
      _ = 4 * (X * Mt) := by ring
      _ ≤ 4 * (4 * omegaRankinBound) :=
        mul_le_mul_of_nonneg_left hMt' (by norm_num)
      _ = 16 * omegaRankinBound := by ring
  have hNE : N * Et ≤ 16 * etaRankinBound := by
    calc
      N * Et ≤ (4 * X) * Et :=
        mul_le_mul_of_nonneg_right hNX hE0
      _ = 4 * (X * Et) := by ring
      _ ≤ 4 * (4 * etaRankinBound) :=
        mul_le_mul_of_nonneg_left hEt' (by norm_num)
      _ = 16 * etaRankinBound := by ring
  have hc := abs_cStarReal_le_one q (2 * H)
  have hf : |freeHighBaseline q| ≤ 1 := by
    unfold freeHighBaseline
    exact abs_cStarReal_le_one q 0
  have hleft :
      |cStarReal q (2 * H) * N * Mt| ≤
        16 * omegaRankinBound := by
    rw [abs_mul, abs_mul, abs_of_nonneg hN0, abs_of_nonneg hM0]
    calc
      |cStarReal q (2 * H)| * N * Mt
        ≤ 1 * N * Mt := by
          exact mul_le_mul_of_nonneg_right
            (mul_le_mul_of_nonneg_right hc hN0) hM0
      _ = N * Mt := by ring
      _ ≤ 16 * omegaRankinBound := hNM
  have hright :
      |freeHighBaseline q * N * Et| ≤
        16 * etaRankinBound := by
    rw [abs_mul, abs_mul, abs_of_nonneg hN0, abs_of_nonneg hE0]
    calc
      |freeHighBaseline q| * N * Et
        ≤ 1 * N * Et := by
          exact mul_le_mul_of_nonneg_right
            (mul_le_mul_of_nonneg_right hf hN0) hE0
      _ = N * Et := by ring
      _ ≤ 16 * etaRankinBound := hNE
  calc
    |cStarReal q (2 * H) * N * Mt -
        freeHighBaseline q * N * Et|
      ≤ |cStarReal q (2 * H) * N * Mt| +
          |freeHighBaseline q * N * Et| := abs_sub _ _
    _ ≤ 16 * omegaRankinBound +
        16 * etaRankinBound := add_le_add hleft hright
    _ = oneDimensionalTailBracketBound q := rfl

#print axioms abs_oneDimensionalDensity_difference_le
#print axioms abs_oneDimensionalBoundary_difference_le
#print axioms abs_oneDimensionalTail_difference_le

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem fixedConstant_le_epsilon_log_eventually
    (C ε : ℝ) (hε : 0 < ε) :
    ∃ N : ℕ, ∀ X : ℕ, N ≤ X →
      C ≤ ε * Real.log (X : ℝ) := by
  obtain ⟨N, hN⟩ := exists_nat_ge (Real.exp (C / ε))
  refine ⟨N, ?_⟩
  intro X hNX
  have hNXR : (N : ℝ) ≤ (X : ℝ) := by
    exact_mod_cast hNX
  have hExpX :
      Real.exp (C / ε) ≤ (X : ℝ) :=
    hN.trans hNXR
  have hlog :
      C / ε ≤ Real.log (X : ℝ) := by
    rw [← Real.log_exp (C / ε)]
    exact Real.log_le_log (Real.exp_pos _) hExpX
  have hmul := (div_le_iff₀ hε).mp hlog
  simpa [mul_comm] using hmul

#print axioms fixedConstant_le_epsilon_log_eventually

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem abs_oneDimensionalSawtooth_difference_sublog_of_r0002
    (q : ℕ) (hq : 0 < q) [NeZero (fixedQPeriod q)]
    (homega :
      PetermannMinimalConsumerR0002Spec q PetermannBase.omega)
    (heta :
      PetermannMinimalConsumerR0002Spec q PetermannBase.eta) :
    ∀ ε : ℝ, 0 < ε →
      ∃ T0 : ℝ, ∀ r H : ℕ,
        2 ≤ H →
        T0 ≤ ((H - 1 : ℕ) : ℝ) →
        (2 * fixedQPeriod q : ℝ) ≤ ((H - 1 : ℕ) : ℝ) →
        |cStarReal q (2 * H) *
            supportedSawtoothSum
              (fixedQPeriod q)
              (occupiedReducedFixedQLowWeight q r H)
              (movingVCoeff q (2 * H))
              (((H - 1 : ℕ) : ℝ)) (H - 1) -
          freeHighBaseline q *
            supportedSawtoothSum
              (fixedQPeriod q)
              (freeReducedFixedQLowWeight q r)
              (etaCoeff q)
              (((H - 1 : ℕ) : ℝ)) (H - 1)| ≤
          ε * Real.log (((H - 1 : ℕ) : ℝ)) := by
  intro ε hε
  let δ : ℝ := ε / 2
  have hδ : 0 < δ := by
    dsimp [δ]
    positivity
  obtain ⟨Tm, hTm⟩ :=
    supportedSawtoothSum_moving_sublog_of_r0002
      q hq homega δ hδ
  obtain ⟨Te, hTe⟩ :=
    supportedSawtoothSum_eta_sublog_of_r0002
      q hq heta δ hδ
  refine ⟨max Tm Te, ?_⟩
  intro r H hH hT h2L
  let X := H - 1
  let XR : ℝ := (X : ℕ)
  let wm := occupiedReducedFixedQLowWeight q r H
  let we := freeReducedFixedQLowWeight q r
  let sm :=
    supportedSawtoothSum
      (fixedQPeriod q) wm
      (movingVCoeff q (2 * H)) XR X
  let se :=
    supportedSawtoothSum
      (fixedQPeriod q) we
      (etaCoeff q) XR X
  have hX : 1 ≤ X := by
    dsimp [X]
    omega
  have hXR0 : 0 ≤ Real.log XR := by
    apply Real.log_nonneg
    dsimp [XR]
    exact_mod_cast hX
  have hTm' : Tm ≤ XR := by
    dsimp [XR, X]
    exact (le_max_left Tm Te).trans hT
  have hTe' : Te ≤ XR := by
    dsimp [XR, X]
    exact (le_max_right Tm Te).trans hT
  have hwm :
      ∀ c ∈ Finset.Icc 1 (fixedQPeriod q),
        |wm c| ≤ 6 := by
    intro c hc
    dsimp [wm]
    exact abs_occupiedReducedFixedQLowWeight_le_six q r H c
  have hwe :
      ∀ c ∈ Finset.Icc 1 (fixedQPeriod q),
        |we c| ≤ 6 := by
    intro c hc
    dsimp [we]
    exact abs_freeReducedFixedQLowWeight_le_six q r c
  have hsm :
      |sm| ≤ δ * Real.log XR := by
    dsimp [sm, wm, XR, X]
    exact hTm (2 * H) (by omega)
      (occupiedReducedFixedQLowWeight q r H) hwm
      (((H - 1 : ℕ) : ℝ)) (H - 1)
      hTm' h2L hX (le_refl _)
  have hse :
      |se| ≤ δ * Real.log XR := by
    dsimp [se, we, XR, X]
    exact hTe
      (freeReducedFixedQLowWeight q r) hwe
      (((H - 1 : ℕ) : ℝ)) (H - 1)
      hTe' h2L hX (le_refl _)
  have hc : |cStarReal q (2 * H)| ≤ 1 :=
    abs_cStarReal_le_one q (2 * H)
  have hf : |freeHighBaseline q| ≤ 1 := by
    unfold freeHighBaseline
    exact abs_cStarReal_le_one q 0
  have hδlog0 :
      0 ≤ δ * Real.log XR :=
    mul_nonneg hδ.le hXR0
  have hsm' :
      |cStarReal q (2 * H) * sm| ≤
        δ * Real.log XR := by
    rw [abs_mul]
    calc
      |cStarReal q (2 * H)| * |sm|
        ≤ 1 * (δ * Real.log XR) :=
          mul_le_mul hc hsm (abs_nonneg _) (by norm_num)
      _ = δ * Real.log XR := one_mul _
  have hse' :
      |freeHighBaseline q * se| ≤
        δ * Real.log XR := by
    rw [abs_mul]
    calc
      |freeHighBaseline q| * |se|
        ≤ 1 * (δ * Real.log XR) :=
          mul_le_mul hf hse (abs_nonneg _) (by norm_num)
      _ = δ * Real.log XR := one_mul _
  calc
    |cStarReal q (2 * H) * sm -
        freeHighBaseline q * se|
      ≤ |cStarReal q (2 * H) * sm| +
          |freeHighBaseline q * se| := abs_sub _ _
    _ ≤ δ * Real.log XR +
        δ * Real.log XR := add_le_add hsm' hse'
    _ = ε * Real.log XR := by
      dsimp [δ]
      ring

#print axioms abs_oneDimensionalSawtooth_difference_sublog_of_r0002

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def oneDimensionalFixedBracketBound
    (q : ℕ) : ℝ :=
  oneDimensionalDensityBracketBound q +
    oneDimensionalBoundaryBracketBound q +
    oneDimensionalTailBracketBound q

theorem oneDimensionalBracket_sublog_of_r0002
    (q : ℕ) (hq : 0 < q) [NeZero (fixedQPeriod q)]
    (homega :
      PetermannMinimalConsumerR0002Spec q PetermannBase.omega)
    (heta :
      PetermannMinimalConsumerR0002Spec q PetermannBase.eta) :
    ∀ ε : ℝ, 0 < ε →
      ∃ H0 : ℕ, ∀ a b H n : ℕ,
        q.Coprime a →
        q.Coprime b →
        H0 ≤ H →
        2 * H =
          positiveGapRepresentative q a b + n * q →
        |manuscriptQ1FloorKernel q a H -
          manuscriptS1FloorKernel q a H| ≤
            ε * Real.log (((H - 1 : ℕ) : ℝ)) := by
  intro ε hε
  let δ : ℝ := ε / 2
  have hδ : 0 < δ := by
    dsimp [δ]
    positivity
  obtain ⟨Nc, hNc⟩ :=
    fixedConstant_le_epsilon_log_eventually
      (oneDimensionalFixedBracketBound q) δ hδ
  obtain ⟨Ts, hTs⟩ :=
    abs_oneDimensionalSawtooth_difference_sublog_of_r0002
      q hq homega heta δ hδ
  obtain ⟨Ns, hNs⟩ := exists_nat_ge Ts
  let H0 : ℕ :=
    3 + Nc + Ns + 2 * fixedQPeriod q
  refine ⟨H0, ?_⟩
  intro a b H n ha hb hH0 hcompat
  let X := H - 1
  let Dterm : ℝ :=
    cStarReal q (2 * H) *
        oneDimensionalDensityCoeff q a H *
        movingVReciprocalPrefix q (2 * H) X -
      freeHighBaseline q *
        oneDimensionalDensityCoeff q a H *
        etaReciprocalPrefix q X
  let Bterm : ℝ :=
    cStarReal q (2 * H) *
        supportedBoundarySum
          (fixedQPeriod q)
          (occupiedReducedFixedQLowWeight q a H)
          (movingVCoeff q (2 * H)) X -
      freeHighBaseline q *
        supportedBoundarySum
          (fixedQPeriod q)
          (freeReducedFixedQLowWeight q a)
          (etaCoeff q) X
  let Sterm : ℝ :=
    cStarReal q (2 * H) *
        supportedSawtoothSum
          (fixedQPeriod q)
          (occupiedReducedFixedQLowWeight q a H)
          (movingVCoeff q (2 * H))
          (X : ℝ) X -
      freeHighBaseline q *
        supportedSawtoothSum
          (fixedQPeriod q)
          (freeReducedFixedQLowWeight q a)
          (etaCoeff q)
          (X : ℝ) X
  let Tterm : ℝ :=
    cStarReal q (2 * H) *
        (admissibleInteriorCount q a (2 * H) : ℝ) *
        movingVReciprocalTail q (2 * H) X -
      freeHighBaseline q *
        (admissibleInteriorCount q a (2 * H) : ℝ) *
        etaReciprocalTail q X
  have hH2 : 2 ≤ H := by
    dsimp [H0] at hH0
    omega
  have hXNc : Nc ≤ X := by
    dsimp [H0, X] at hH0 ⊢
    omega
  have hXNs : Ns ≤ X := by
    dsimp [H0, X] at hH0 ⊢
    omega
  have hXL : 2 * fixedQPeriod q ≤ X := by
    dsimp [H0, X] at hH0 ⊢
    omega
  have hTsX : Ts ≤ (X : ℝ) :=
    hNs.trans (by exact_mod_cast hXNs)
  have h2LX :
      (2 * fixedQPeriod q : ℝ) ≤ (X : ℝ) := by
    exact_mod_cast hXL
  have hfixed :
      oneDimensionalFixedBracketBound q ≤
        δ * Real.log (X : ℝ) :=
    hNc X hXNc
  have hD :
      |Dterm| ≤ oneDimensionalDensityBracketBound q := by
    dsimp [Dterm, X]
    exact abs_oneDimensionalDensity_difference_le hq hcompat
  have hB :
      |Bterm| ≤ oneDimensionalBoundaryBracketBound q := by
    dsimp [Bterm, X]
    exact abs_oneDimensionalBoundary_difference_le
      q a H hq ha hH2
  have hT :
      |Tterm| ≤ oneDimensionalTailBracketBound q := by
    dsimp [Tterm, X]
    exact abs_oneDimensionalTail_difference_le q a H hH2
  have hS :
      |Sterm| ≤ δ * Real.log (X : ℝ) := by
    dsimp [Sterm, X]
    exact hTs a H hH2 hTsX h2LX
  have hdecomp :
      manuscriptQ1FloorKernel q a H -
          manuscriptS1FloorKernel q a H =
        Dterm + Bterm - Sterm - Tterm := by
    dsimp [Dterm, Bterm, Sterm, Tterm, X]
    unfold manuscriptQ1FloorKernel manuscriptS1FloorKernel
    dsimp
    ring
  rw [hdecomp]
  have htri1 :
      |Dterm + Bterm - Sterm - Tterm| ≤
        |Dterm + Bterm - Sterm| + |Tterm| :=
    abs_sub _ _
  have htri2 :
      |Dterm + Bterm - Sterm| ≤
        |Dterm + Bterm| + |Sterm| :=
    abs_sub _ _
  have htri3 :
      |Dterm + Bterm| ≤ |Dterm| + |Bterm| :=
    abs_add_le _ _
  calc
    |Dterm + Bterm - Sterm - Tterm|
      ≤ |Dterm| + |Bterm| + |Sterm| + |Tterm| := by
        linarith
    _ ≤ oneDimensionalDensityBracketBound q +
        oneDimensionalBoundaryBracketBound q +
        (δ * Real.log (X : ℝ)) +
        oneDimensionalTailBracketBound q := by
          linarith
    _ = oneDimensionalFixedBracketBound q +
        δ * Real.log (X : ℝ) := by
          unfold oneDimensionalFixedBracketBound
          ring
    _ ≤ δ * Real.log (X : ℝ) +
        δ * Real.log (X : ℝ) := by
          simpa [add_comm] using
            add_le_add_right hfixed (δ * Real.log (X : ℝ))
    _ = ε * Real.log (X : ℝ) := by
          dsimp [δ]
          ring

#print axioms oneDimensionalBracket_sublog_of_r0002

end PaperB.FixedQ
