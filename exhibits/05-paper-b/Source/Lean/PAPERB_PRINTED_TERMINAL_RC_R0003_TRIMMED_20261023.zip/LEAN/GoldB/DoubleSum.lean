import GoldB.Grid
import GoldB.RealAux

/-!
# GoldB.DoubleSum — Vinogradov's lemma on double sums (Karatsuba 1971, (5)–(6))

For `Q ≥ 1`, `Z = [0, Q)`, `b ≥ 1` and real `B_j` (`j < k`, attached to `(yz)^{j+1}`):

`|∑_{y,z ∈ Z} e(∑_j B_j (yz)^{j+1})|^{4b²} ≤ Q^{8b²-4b} J_{b,k}(Z)² ∏_j 𝔖_j`,
`𝔖_j = ∑_{|μ| ≤ L_j} min(2L_j+1, 1/(2‖B_j μ‖))`, `L_j = b (Q-1)^{j+1}`.
-/

open Finset Complex

namespace GoldB

/-- the box radius for the `j`-th power sum -/
def Lbox (b Q : ℕ) (j : ℕ) : ℕ := b * (Q - 1) ^ (j + 1)

/-- the integer interval `[0, Q)` -/
def Zr (Q : ℕ) : Finset ℤ := Ico (0 : ℤ) Q

lemma card_Zr (Q : ℕ) : (Zr Q).card = Q := by simp [Zr]

lemma ee_sum_pow (Z : Finset ℤ) (φ : ℤ → ℝ) (b : ℕ) :
    (∑ z ∈ Z, ee (φ z)) ^ b = ∑ z ∈ tup b Z, ee (∑ i, φ (z i)) := by
  classical
  calc
    (∑ z ∈ Z, ee (φ z)) ^ b =
        ∑ z ∈ tup b Z, ∏ i, ee (φ (z i)) := by
          simpa only [tup] using (Finset.sum_pow' Z (fun z : ℤ => ee (φ z)) b)
    _ = ∑ z ∈ tup b Z, ee (∑ i, φ (z i)) := by
          apply Finset.sum_congr rfl
          intro z hz
          simpa using
            (ee_sum (Finset.univ : Finset (Fin b)) (fun i => φ (z i))).symm

lemma phase_swap {k b : ℕ} (β : Fin k → ℝ) (z : Fin b → ℤ) :
    ∑ i, ∑ j, β j * ((z i : ℝ)) ^ ((j : ℕ) + 1) = ∑ j, β j * (psv k z j : ℝ) := by
  rw [Finset.sum_comm]
  apply sum_congr rfl; intro j _
  simp [psv, Finset.mul_sum]

/-- the `2b`-th moment of a Weyl-type sum as a sum over pairs of tuples -/
lemma norm_pow_eq_pairs {k : ℕ} (Z : Finset ℤ) (β : Fin k → ℝ) (b : ℕ) :
    ((‖∑ z ∈ Z, ee (∑ j, β j * (z : ℝ) ^ ((j : ℕ) + 1))‖ ^ (2 * b) : ℝ) : ℂ) =
      ∑ zz ∈ tup b Z ×ˢ tup b Z,
        ee (∑ j, β j * ((psv k zz.1 j : ℝ) - (psv k zz.2 j : ℝ))) := by
  set S := ∑ z ∈ Z, ee (∑ j, β j * (z : ℝ) ^ ((j : ℕ) + 1))
  have h1 : ((‖S‖ ^ (2 * b) : ℝ) : ℂ) = S ^ b * (starRingEnd ℂ) (S ^ b) := by
    rw [pow_mul, map_pow, ← mul_pow]
    rw [Complex.mul_conj, Complex.normSq_eq_norm_sq]; push_cast; ring
  rw [h1, ee_sum_pow, map_sum, sum_mul_sum, ← sum_product']
  apply sum_congr rfl; intro zz _
  rw [← ee_neg, ← ee_add, phase_swap, phase_swap]
  congr 1
  rw [← sum_neg_distrib, ← sum_add_distrib]
  apply sum_congr rfl; intro j _; ring

lemma psv_Zr_range {k b Q : ℕ} (hQ : 1 ≤ Q) (z : Fin b → ℤ) (hz : z ∈ tup b (Zr Q)) (j : Fin k) :
    0 ≤ psv k z j ∧ psv k z j ≤ (Lbox b Q j : ℤ) := by
  unfold psv Lbox
  have hz' : ∀ i, 0 ≤ z i ∧ z i ≤ (Q : ℤ) - 1 := by
    intro i
    have := Fintype.mem_piFinset.mp hz i
    simp [Zr] at this; omega
  constructor
  · exact sum_nonneg (fun i _ => pow_nonneg (hz' i).1 _)
  · calc ∑ i, z i ^ ((j : ℕ) + 1) ≤ ∑ _i : Fin b, ((Q : ℤ) - 1) ^ ((j : ℕ) + 1) := by
          apply sum_le_sum; intro i _
          exact pow_le_pow_left₀ (hz' i).1 (hz' i).2 _
      _ = ((b * (Q - 1) ^ ((j : ℕ) + 1) : ℕ) : ℤ) := by
          simp; rw [Nat.cast_sub hQ]; simp

/-- the box of possible difference vectors -/
def Lam (k b Q : ℕ) : Finset (Fin k → ℤ) :=
  Fintype.piFinset fun j : Fin k => Icc (-(Lbox b Q j : ℤ)) (Lbox b Q j)

lemma diff_mem_Lam {k b Q : ℕ} (hQ : 1 ≤ Q) (zz : (Fin b → ℤ) × (Fin b → ℤ))
    (h : zz ∈ tup b (Zr Q) ×ˢ tup b (Zr Q)) : psv k zz.1 - psv k zz.2 ∈ Lam k b Q := by
  rw [mem_product] at h
  rw [Lam, Fintype.mem_piFinset]
  intro j
  have h1 := psv_Zr_range (k := k) hQ zz.1 h.1 j
  have h2 := psv_Zr_range (k := k) hQ zz.2 h.2 j
  rw [mem_Icc]; simp only [Pi.sub_apply]; constructor <;> linarith [h1.1, h1.2, h2.1, h2.2]

/-- grouping a sum over pairs by the difference vector -/
lemma sum_pairs_le_J {k b Q : ℕ} (hQ : 1 ≤ Q) (F : (Fin k → ℤ) → ℝ) (hF : ∀ l, 0 ≤ F l) :
    ∑ zz ∈ tup b (Zr Q) ×ˢ tup b (Zr Q), F (psv k zz.1 - psv k zz.2) ≤
      (Jc k b (Zr Q) : ℝ) * ∑ l ∈ Lam k b Q, F l := by
  classical
  rw [← sum_fiberwise_of_maps_to (g := fun zz => psv k zz.1 - psv k zz.2) (t := Lam k b Q)
    (fun zz h => diff_mem_Lam hQ zz h)]
  rw [mul_sum]
  apply sum_le_sum; intro l _
  rw [sum_congr rfl (fun zz hzz => by rw [(mem_filter.mp hzz).2])]
  rw [sum_const, nsmul_eq_mul]
  apply mul_le_mul_of_nonneg_right _ (hF l)
  have : ((tup b (Zr Q) ×ˢ tup b (Zr Q)).filter fun zz => psv k zz.1 - psv k zz.2 = l).card =
      Rc k b (Zr Q) l := by
    unfold Rc; congr 1; ext zz; simp only [mem_filter]
    constructor <;> rintro ⟨h1, h2⟩ <;> refine ⟨h1, ?_⟩
    · rw [← h2]; ring
    · rw [h2]; ring
  rw [this]; exact_mod_cast Rc_le_Jc b (Zr Q) l

/-- the product of geometric sums over the box -/
lemma sum_Lam_ee {k b Q : ℕ} (c : Fin k → ℝ) :
    ∑ l ∈ Lam k b Q, ee (∑ j, c j * (l j : ℝ)) =
      ∏ j : Fin k, ∑ m ∈ Icc (-(Lbox b Q j : ℤ)) (Lbox b Q j), ee (c j * m) := by
  rw [Lam, Finset.prod_univ_sum]
  apply sum_congr rfl; intro l _; rw [ee_sum]

/-- `𝔖_j` -/
noncomputable def Sfrak (b Q : ℕ) (j : ℕ) (Bj : ℝ) : ℝ :=
  ∑ m ∈ Icc (-(Lbox b Q j : ℤ)) (Lbox b Q j), gmin (2 * (Lbox b Q j : ℝ) + 1) (Bj * m)

lemma Sfrak_nonneg (b Q j : ℕ) (Bj : ℝ) : 0 ≤ Sfrak b Q j Bj :=
  sum_nonneg (fun _ _ => gmin_nonneg (by positivity) _)

/-- **Vinogradov's double-sum lemma** -/
theorem double_sum (k b Q : ℕ) (hb : 1 ≤ b) (hQ : 1 ≤ Q) (B : Fin k → ℝ) :
    ‖∑ y ∈ Zr Q, ∑ z ∈ Zr Q, ee (∑ j, B j * ((y : ℝ) * z) ^ ((j : ℕ) + 1))‖ ^ (4 * b ^ 2) ≤
      (Q : ℝ) ^ (8 * b ^ 2 - 4 * b) * (Jc k b (Zr Q) : ℝ) ^ 2 *
        ∏ j : Fin k, Sfrak b Q j (B j) := by
  classical
  set Z := Zr Q
  set J := (Jc k b Z : ℝ)
  have hZ : (Z.card : ℝ) = Q := by simp [Z, card_Zr]
  have hZne : Z.Nonempty := ⟨0, by simp [Z, Zr]; omega⟩
  set S : ℤ → ℂ := fun y => ∑ z ∈ Z, ee (∑ j, (B j * (y : ℝ) ^ ((j : ℕ) + 1)) *
      (z : ℝ) ^ ((j : ℕ) + 1))
  have hW : ∑ y ∈ Z, ∑ z ∈ Z, ee (∑ j, B j * ((y : ℝ) * z) ^ ((j : ℕ) + 1)) = ∑ y ∈ Z, S y := by
    apply sum_congr rfl; intro y _; apply sum_congr rfl; intro z _
    congr 1; apply sum_congr rfl; intro j _; rw [mul_pow]; ring
  set T : (Fin k → ℤ) → ℂ := fun l => ∑ y ∈ Z, ee (∑ j, (B j * (l j : ℝ)) *
      (y : ℝ) ^ ((j : ℕ) + 1))
  set P := tup b Z ×ˢ tup b Z
  have hP : (P.card : ℝ) = (Q : ℝ) ^ (2 * b) := by
    simp [P, card_product, card_tup, Z, card_Zr]; ring
  -- step (3): ∑_y |S y|^{2b} ≤ ∑_{pairs} |T(λ)|
  have h3 : ∑ y ∈ Z, ‖S y‖ ^ (2 * b) ≤ ∑ zz ∈ P, ‖T (psv k zz.1 - psv k zz.2)‖ := by
    have e : ((∑ y ∈ Z, ‖S y‖ ^ (2 * b) : ℝ) : ℂ) = ∑ zz ∈ P, T (psv k zz.1 - psv k zz.2) := by
      simp only [S]
      rw [Complex.ofReal_sum]
      simp_rw [norm_pow_eq_pairs]
      rw [sum_comm]
      apply sum_congr rfl; intro zz _
      simp only [T]
      apply sum_congr rfl; intro y _
      congr 1; apply sum_congr rfl; intro j _
      simp only [Pi.sub_apply, Int.cast_sub]; ring
    have := congrArg norm e
    rw [Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (sum_nonneg (fun _ _ => by positivity))] at this
    rw [this]; exact norm_sum_le _ _
  -- step (6): ∑_{λ ∈ Λ} |T λ|^{2b} ≤ J ∏ 𝔖
  have h6 : ∑ l ∈ Lam k b Q, ‖T l‖ ^ (2 * b) ≤ J * ∏ j : Fin k, Sfrak b Q j (B j) := by
    have e : ((∑ l ∈ Lam k b Q, ‖T l‖ ^ (2 * b) : ℝ) : ℂ) =
        ∑ yy ∈ P, ∏ j : Fin k, ∑ m ∈ Icc (-(Lbox b Q j : ℤ)) (Lbox b Q j),
          ee ((B j * ((psv k yy.1 j : ℝ) - (psv k yy.2 j : ℝ))) * m) := by
      simp only [T]
      rw [Complex.ofReal_sum]
      simp_rw [norm_pow_eq_pairs]
      rw [sum_comm]
      apply sum_congr rfl; intro yy _
      rw [← sum_Lam_ee]
      apply sum_congr rfl; intro l _
      congr 1; apply sum_congr rfl; intro j _; ring
    have hle : ∑ l ∈ Lam k b Q, ‖T l‖ ^ (2 * b) ≤
        ∑ yy ∈ P, ∏ j : Fin k, gmin (2 * (Lbox b Q j : ℝ) + 1)
          (B j * ((psv k yy.1 - psv k yy.2) j : ℝ)) := by
      have := congrArg norm e
      rw [Complex.norm_real, Real.norm_eq_abs,
        abs_of_nonneg (sum_nonneg (fun _ _ => by positivity))] at this
      rw [this]
      refine (norm_sum_le _ _).trans (sum_le_sum ?_)
      intro yy _
      rw [norm_prod]
      gcongr with j
      have := norm_sym_geom_le_gmin (B j * ((psv k yy.1 j : ℝ) - (psv k yy.2 j : ℝ))) (Lbox b Q j)
      simpa using this
    refine hle.trans ?_
    have hgrp := sum_pairs_le_J (k := k) (b := b) hQ
      (fun l => ∏ j : Fin k, gmin (2 * (Lbox b Q j : ℝ) + 1) (B j * (l j : ℝ)))
      (fun l => prod_nonneg (fun j _ => gmin_nonneg (by positivity) _))
    refine hgrp.trans (le_of_eq ?_)
    congr 1
    simp only [Sfrak, Lam]
    exact (Finset.prod_univ_sum (fun j : Fin k => Icc (-(Lbox b Q j : ℤ)) (Lbox b Q j)) (fun j m => gmin (2 * (Lbox b Q j : ℝ) + 1) (B j * m))).symm
  -- step (5): ∑_{pairs} |T λ|^{2b} ≤ J ∑_{λ ∈ Λ} |T λ|^{2b}
  have h5 : ∑ zz ∈ P, ‖T (psv k zz.1 - psv k zz.2)‖ ^ (2 * b) ≤
      J * ∑ l ∈ Lam k b Q, ‖T l‖ ^ (2 * b) :=
    sum_pairs_le_J hQ (fun l => ‖T l‖ ^ (2 * b)) (fun _ => by positivity)
  -- powers
  have hW1 : ‖∑ y ∈ Z, S y‖ ^ (2 * b) ≤ (Q : ℝ) ^ (2 * b - 1) * ∑ y ∈ Z, ‖S y‖ ^ (2 * b) := by
    calc ‖∑ y ∈ Z, S y‖ ^ (2 * b) ≤ (∑ y ∈ Z, ‖S y‖) ^ (2 * b) :=
          pow_le_pow_left₀ (norm_nonneg _) (norm_sum_le _ _) _
      _ ≤ ((Z.card : ℝ) ^ (2 * b) / Z.card) * ∑ y ∈ Z, ‖S y‖ ^ (2 * b) :=
          pow_sum_le_card_pow_div _ _ (fun _ _ => norm_nonneg _) hZne _
      _ = (Q : ℝ) ^ (2 * b - 1) * ∑ y ∈ Z, ‖S y‖ ^ (2 * b) := by
          rw [hZ]; congr 1
          have hQ0 : (Q : ℝ) ≠ 0 := by exact_mod_cast (by omega : Q ≠ 0)
          rw [div_eq_iff hQ0, ← pow_succ]; congr 1; omega
  have hPne : P.Nonempty := by
    apply Nonempty.product <;> exact Fintype.piFinset_nonempty.mpr (fun _ => hZne)
  have hT2b : (∑ zz ∈ P, ‖T (psv k zz.1 - psv k zz.2)‖) ^ (2 * b) ≤
      ((Q : ℝ) ^ (2 * b)) ^ (2 * b - 1) * ∑ zz ∈ P, ‖T (psv k zz.1 - psv k zz.2)‖ ^ (2 * b) := by
    calc (∑ zz ∈ P, ‖T (psv k zz.1 - psv k zz.2)‖) ^ (2 * b)
        ≤ ((P.card : ℝ) ^ (2 * b) / P.card) * ∑ zz ∈ P, ‖T (psv k zz.1 - psv k zz.2)‖ ^ (2 * b) :=
          pow_sum_le_card_pow_div _ _ (fun _ _ => norm_nonneg _) hPne _
      _ = _ := by
          rw [hP]; congr 1
          have hQ0 : (Q : ℝ) ^ (2 * b) ≠ 0 := by positivity
          rw [div_eq_iff hQ0, ← pow_succ]; congr 1; omega
  rw [hW]
  have hJ0 : 0 ≤ J := by positivity
  have hS0 : 0 ≤ ∏ j : Fin k, Sfrak b Q j (B j) := prod_nonneg (fun _ _ => Sfrak_nonneg _ _ _ _)
  calc ‖∑ y ∈ Z, S y‖ ^ (4 * b ^ 2) = (‖∑ y ∈ Z, S y‖ ^ (2 * b)) ^ (2 * b) := by
        rw [← pow_mul]; ring_nf
    _ ≤ ((Q : ℝ) ^ (2 * b - 1) * ∑ zz ∈ P, ‖T (psv k zz.1 - psv k zz.2)‖) ^ (2 * b) := by
        apply pow_le_pow_left₀ (by positivity)
        exact hW1.trans (mul_le_mul_of_nonneg_left h3 (by positivity))
    _ = ((Q : ℝ) ^ (2 * b - 1)) ^ (2 * b) *
          (∑ zz ∈ P, ‖T (psv k zz.1 - psv k zz.2)‖) ^ (2 * b) := by rw [mul_pow]
    _ ≤ ((Q : ℝ) ^ (2 * b - 1)) ^ (2 * b) * (((Q : ℝ) ^ (2 * b)) ^ (2 * b - 1) *
          (J * (J * ∏ j : Fin k, Sfrak b Q j (B j)))) := by
        apply mul_le_mul_of_nonneg_left _ (by positivity)
        refine hT2b.trans (mul_le_mul_of_nonneg_left (h5.trans ?_) (by positivity))
        exact mul_le_mul_of_nonneg_left h6 hJ0
    _ = (Q : ℝ) ^ (8 * b ^ 2 - 4 * b) * J ^ 2 * ∏ j : Fin k, Sfrak b Q j (B j) := by
        rw [← pow_mul, ← pow_mul, mul_comm (2 * b) (2 * b - 1)]
        have : (Q : ℝ) ^ ((2 * b - 1) * (2 * b)) * (Q : ℝ) ^ ((2 * b - 1) * (2 * b)) =
            (Q : ℝ) ^ (8 * b ^ 2 - 4 * b) := by
          rw [← pow_add]; congr 1
          have : 1 ≤ 2 * b := by omega
          zify [this, (by nlinarith : 4 * b ≤ 8 * b ^ 2)]
          ring
        calc (Q : ℝ) ^ ((2 * b - 1) * (2 * b)) *
              ((Q : ℝ) ^ ((2 * b - 1) * (2 * b)) * (J * (J * ∏ j : Fin k, Sfrak b Q j (B j))))
            = ((Q : ℝ) ^ ((2 * b - 1) * (2 * b)) * (Q : ℝ) ^ ((2 * b - 1) * (2 * b))) *
                J ^ 2 * ∏ j : Fin k, Sfrak b Q j (B j) := by ring
          _ = _ := by rw [this]

end GoldB
