import PaperB.Analytic.DerivTestK

namespace PaperB.Analytic

open Real Finset

/-- Paper-B-facing finite-order van der Corput derivative test.
The implementation is the proved Weyl--van der Corput A-process ladder;
only the fixed order and the window actually consumed downstream are exposed. -/
theorem finiteOrderDerivativeTest
    (k : ℕ) (hk : 2 ≤ k) :
    ∃ C : ℝ, 1 ≤ C ∧
      ∀ (f : ℤ → ℝ) (a b : ℤ) (lam c : ℝ),
        a ≤ b →
        0 < lam →
        1 ≤ c →
        (∀ n : ℤ, a < n → n < b → lam ≤ dk k f n) →
        (∀ n : ℤ, a < n → n < b → dk k f n ≤ c * lam) →
        ‖∑ n ∈ Finset.Ioc a b, eR (f n)‖
          ≤ C * c ^ (4 / (2 : ℝ) ^ k)
            * (((b : ℝ) - a) * lam ^ (1 / ((2 : ℝ) ^ k - 2))
              + ((b : ℝ) - a) ^ (1 - 4 / (2 : ℝ) ^ k)
                * lam ^ (-(1 / ((2 : ℝ) ^ k - 2)))) := by
  simpa [IsVdCBound] using vdC_kth_derivative k hk

#print axioms finiteOrderDerivativeTest

end PaperB.Analytic
