import PaperB.FixedQ.DecoratedAnalyticPerEBridge
import PaperB.FixedQ.ShiuMass

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def decoratedAnalyticRemainder (q a h : ℕ) : ℝ :=
  ∑' e : Finset ℕ,
    (ordinaryTwoDimensionalSet h)ᶜ.indicator (decoratedAnalyticPerE q a h) e

noncomputable def decoratedDensityRemainder (q a h : ℕ) : ℝ :=
  ∑' e : Finset ℕ,
    (ordinaryTwoDimensionalSet h)ᶜ.indicator (decoratedDensityPerE q a h) e

theorem abs_decoratedDensityPairTerm_le_h_mul_baseline
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h)
    {e e1 : Finset ℕ} (he1 : e1 ⊆ e) :
    |decoratedDensityPairTerm q a h e e1| ≤
      genericFixedQPeriodicDensityBound q * (h : ℝ) *
        (pairCoefficient q h e e1 / pairDenominator e e1) := by
  by_cases hAall : ∀ p ∈ e, activeHighPrime q p
  · by_cases hheight : heightPrimePart h e ⊆ e1
    · let dS := heightPrimePart h e
      let nS := e \ dS
      let A := e1 \ dS
      let D := decoratedHeightProduct h e
      let H := decoratedReducedHeight h e
      let r := primeSetProduct A
      let s := primeSetProduct (nS \ A)
      have hdsub : dS ⊆ e := by
        dsimp [dS]; exact Finset.filter_subset _ _
      have hAsubn : A ⊆ nS := by
        intro p hp
        exact Finset.mem_sdiff.mpr ⟨he1 (Finset.mem_sdiff.mp hp).1, (Finset.mem_sdiff.mp hp).2⟩
      have hnPrime : ∀ p ∈ nS, p.Prime := by
        intro p hp; exact (hAall p (Finset.mem_sdiff.mp hp).1).1
      have hAPrime : ∀ p ∈ A, p.Prime := fun p hp => hnPrime p (hAsubn hp)
      have hsPrime : ∀ p ∈ nS \ A, p.Prime := fun p hp => hnPrime p (Finset.mem_sdiff.mp hp).1
      have hDpos : 0 < D := decoratedHeightProduct_pos hAall
      have hfact : D * H = h := decoratedHeightProduct_mul_reducedHeight hAall
      have hHpos : 0 < H := by
        by_contra hz
        have : H = 0 := Nat.eq_zero_of_not_pos hz
        rw [this, mul_zero] at hfact
        exact (Nat.ne_of_gt hh) hfact.symm
      have hHpar : ¬ 2 ∣ q → 2 ∣ H :=
        decoratedReducedHeight_parity_admissible hAall h2admissible
      have hdelta :
          |rowPeriodicDensityDelta
              (fixedQLowWeight q (decoratedReducedAnchor q a D) H)
              H (admissibleInteriorCount q a h : ℝ) D| ≤
            genericFixedQPeriodicDensityBound q := by
        have hc : (admissibleInteriorCount q a h : ℝ) =
            (admissibleInteriorCount q a (D * H) : ℝ) := by rw [hfact]
        rw [hc]
        exact abs_generic_fixedQRowPeriodicDensityDelta_le_uniform
          hq hDpos hHpos hHpar
      have hcoeff :
          pairCoefficient q h e e1 =
            finiteVWeightReal h dS * finiteOmegaWeightReal nS := by
        exact pairCoefficient_eq_heightPart_mul_nonheightOmega he1 hAall hheight
      have hrpos : 0 < r := primeSetProduct_pos hAPrime
      have hspos : 0 < s := primeSetProduct_pos hsPrime
      have hrs : r * s = primeSetProduct nS := by
        dsimp [r, s]
        unfold primeSetProduct
        rw [← Finset.prod_union Finset.disjoint_sdiff,
          Finset.union_sdiff_of_subset hAsubn]
      have hePrime : ∀ p ∈ e, p.Prime := fun p hp => (hAall p hp).1
      have hdnDis : Disjoint dS nS := by
        dsimp [nS]
        exact Finset.disjoint_sdiff
      have hdnUnion : dS ∪ nS = e := by
        dsimp [nS]
        exact Finset.union_sdiff_of_subset hdsub
      have hprodD : primeSetProduct dS = D := by
        rfl
      have hprodE : primeSetProduct e = D * r * s := by
        calc
          primeSetProduct e = primeSetProduct (dS ∪ nS) := by rw [hdnUnion]
          _ = primeSetProduct dS * primeSetProduct nS := by
            unfold primeSetProduct
            rw [Finset.prod_union hdnDis]
          _ = D * (r * s) := by rw [hprodD, ← hrs]
          _ = D * r * s := by simp [mul_assoc]
      have hden :
          pairDenominator e e1 =
            (D : ℝ) * (r : ℝ) * (s : ℝ) := by
        have hp := pairDenominator_eq_primeSetProduct he1 hePrime
        have hprodER :
            (∏ p ∈ e, (p : ℝ)) = (D : ℝ) * (r : ℝ) * (s : ℝ) := by
          have hc := congrArg (fun n : ℕ => (n : ℝ)) hprodE
          simpa [primeSetProduct, Nat.cast_mul] using hc
        simpa [pairDenominator, pairLeftModulus, pairRightModulus, primeSetProduct] using hp.trans hprodER
      have hc0 : 0 ≤ pairCoefficient q h e e1 := pairCoefficient_nonneg q h e e1
      have hB0 : 0 ≤ genericFixedQPeriodicDensityBound q := by
        unfold genericFixedQPeriodicDensityBound fixedQDensityDefectUniformBound
          admissibleCountMeanErrorBound
        positivity
      have hrR : 0 < (r : ℝ) := by exact_mod_cast hrpos
      have hsR : 0 < (s : ℝ) := by exact_mod_cast hspos
      have hDR : 0 < (D : ℝ) := by exact_mod_cast hDpos
      have hHR : 1 ≤ (H : ℝ) := by exact_mod_cast (Nat.one_le_iff_ne_zero.mpr (Nat.ne_of_gt hHpos))
      unfold decoratedDensityPairTerm
      dsimp [dS, nS, A, D, H, r, s]
      rw [abs_mul, abs_div, abs_of_nonneg hc0, abs_of_pos (mul_pos hrR hsR)]
      rw [hden]
      have hhR : (h : ℝ) = (D : ℝ) * (H : ℝ) := by
        exact_mod_cast hfact.symm
      rw [hhR]
      field_simp [ne_of_gt hDR, ne_of_gt hrR, ne_of_gt hsR]
      have hdelta' :
          |rowPeriodicDensityDelta
              (fixedQLowWeight q
                (decoratedReducedAnchor q a (decoratedHeightProduct h e))
                (decoratedReducedHeight h e))
              (decoratedReducedHeight h e)
              (admissibleInteriorCount q a h : ℝ)
              (decoratedHeightProduct h e)| ≤
            genericFixedQPeriodicDensityBound q := by
        simpa [D, H] using hdelta
      have hmul :=
        mul_le_mul_of_nonneg_left hdelta' hc0
      have hBH :
          genericFixedQPeriodicDensityBound q ≤
            genericFixedQPeriodicDensityBound q * (H : ℝ) := by
        calc
          genericFixedQPeriodicDensityBound q =
              genericFixedQPeriodicDensityBound q * 1 := by ring
          _ ≤ genericFixedQPeriodicDensityBound q * (H : ℝ) :=
            mul_le_mul_of_nonneg_left hHR hB0
      have hmulH :=
        mul_le_mul_of_nonneg_left hBH hc0
      simpa [mul_assoc] using hmul.trans hmulH
    · have hz := pairCoefficient_eq_zero_of_missing_height_prime he1 hAall
          (by simpa [Finset.not_subset] using hheight)
      simp [decoratedDensityPairTerm, hz]
  · have hz := pairCoefficient_eq_zero_of_not_all_active
      (q := q) (h := h) (e := e) (e1 := e1) hAall
    simp [decoratedDensityPairTerm, hz]



theorem abs_decoratedDensityPairTerm_le_forbidden_harmonic
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h)
    {e e1 : Finset ℕ} (he1 : e1 ⊆ e)
    (hAall : ∀ p ∈ e, activeHighPrime q p)
    (hheight : heightPrimePart h e ⊆ e1) :
    let d := heightPrimePart h e
    let n := e \ d
    |decoratedDensityPairTerm q a h e e1| ≤
      genericFixedQPeriodicDensityBound q *
        finiteVWeightReal h d *
        (finiteOmegaWeightReal n / (primeSetProduct n : ℝ)) := by
  let d := heightPrimePart h e
  let n := e \ d
  let A := e1 \ d
  let D := decoratedHeightProduct h e
  let H := decoratedReducedHeight h e
  let r := primeSetProduct A
  let s := primeSetProduct (n \ A)
  have hAsubn : A ⊆ n := by
    intro p hp
    exact Finset.mem_sdiff.mpr
      ⟨he1 (Finset.mem_sdiff.mp hp).1, (Finset.mem_sdiff.mp hp).2⟩
  have hnActive : ∀ p ∈ n, activeHighPrime q p := by
    intro p hp
    exact hAall p (Finset.mem_sdiff.mp hp).1
  have hnPrime : ∀ p ∈ n, p.Prime := fun p hp => (hnActive p hp).1
  have hAPrime : ∀ p ∈ A, p.Prime := fun p hp => hnPrime p (hAsubn hp)
  have hsPrime : ∀ p ∈ n \ A, p.Prime :=
    fun p hp => hnPrime p (Finset.mem_sdiff.mp hp).1
  have hDpos : 0 < D := decoratedHeightProduct_pos hAall
  have hfact : D * H = h := decoratedHeightProduct_mul_reducedHeight hAall
  have hHpos : 0 < H := by
    by_contra hz
    have : H = 0 := Nat.eq_zero_of_not_pos hz
    rw [this, mul_zero] at hfact
    exact (Nat.ne_of_gt hh) hfact.symm
  have hHpar : ¬ 2 ∣ q → 2 ∣ H :=
    decoratedReducedHeight_parity_admissible hAall h2admissible
  have hdelta :
      |rowPeriodicDensityDelta
          (fixedQLowWeight q (decoratedReducedAnchor q a D) H)
          H (admissibleInteriorCount q a h : ℝ) D| ≤
        genericFixedQPeriodicDensityBound q := by
    have hc : (admissibleInteriorCount q a h : ℝ) =
        (admissibleInteriorCount q a (D * H) : ℝ) := by rw [hfact]
    rw [hc]
    exact abs_generic_fixedQRowPeriodicDensityDelta_le_uniform
      hq hDpos hHpos hHpar
  have hcoeff :
      pairCoefficient q h e e1 =
        finiteVWeightReal h d * finiteOmegaWeightReal n :=
    pairCoefficient_eq_heightPart_mul_nonheightOmega he1 hAall hheight
  have hrpos : 0 < r := primeSetProduct_pos hAPrime
  have hspos : 0 < s := primeSetProduct_pos hsPrime
  have hnpos : 0 < primeSetProduct n := primeSetProduct_pos hnPrime
  have hrs : r * s = primeSetProduct n := by
    dsimp [r, s]
    unfold primeSetProduct
    rw [← Finset.prod_union Finset.disjoint_sdiff,
      Finset.union_sdiff_of_subset hAsubn]
  have hv0 : 0 ≤ finiteVWeightReal h d := by
    apply finiteVWeightReal_nonneg_of_active
    intro p hp
    exact hAall p (Finset.mem_filter.mp hp).1
  have hw0 : 0 ≤ finiteOmegaWeightReal n :=
    finiteOmegaWeightReal_nonneg_of_active hnActive
  have hrR : 0 < (r : ℝ) := by exact_mod_cast hrpos
  have hsR : 0 < (s : ℝ) := by exact_mod_cast hspos
  have hnR : 0 < (primeSetProduct n : ℝ) := by exact_mod_cast hnpos
  dsimp
  unfold decoratedDensityPairTerm
  dsimp only
  rw [hcoeff]
  change
    |(finiteVWeightReal h d * finiteOmegaWeightReal n) *
      (rowPeriodicDensityDelta
        (fixedQLowWeight q (decoratedReducedAnchor q a D) H)
        H (admissibleInteriorCount q a h : ℝ) D /
        ((r : ℝ) * (s : ℝ)))| ≤
      genericFixedQPeriodicDensityBound q *
        finiteVWeightReal h d *
        (finiteOmegaWeightReal n / (primeSetProduct n : ℝ))
  rw [abs_mul, abs_mul, abs_div, abs_of_nonneg hv0, abs_of_nonneg hw0,
    abs_of_pos (mul_pos hrR hsR)]
  have hrsR : (r : ℝ) * (s : ℝ) = (primeSetProduct n : ℝ) := by
    exact_mod_cast hrs
  rw [hrsR]
  calc
    finiteVWeightReal h d * finiteOmegaWeightReal n *
        (|rowPeriodicDensityDelta
          (fixedQLowWeight q (decoratedReducedAnchor q a D) H)
          H (admissibleInteriorCount q a h : ℝ) D| /
          (primeSetProduct n : ℝ))
      ≤ finiteVWeightReal h d * finiteOmegaWeightReal n *
          (genericFixedQPeriodicDensityBound q /
            (primeSetProduct n : ℝ)) := by
            gcongr
    _ = genericFixedQPeriodicDensityBound q *
        finiteVWeightReal h d *
        (finiteOmegaWeightReal n / (primeSetProduct n : ℝ)) := by ring



theorem fixedQShiuWeight_primeSetProduct_eq_card_mul_finiteOmegaWeightReal
    {q : ℕ} {n : Finset ℕ}
    (hn : ∀ p ∈ n, activeHighPrime q p) :
    fixedQShiuWeight q (primeSetProduct n) =
      (2 : ℝ) ^ n.card * finiteOmegaWeightReal n := by
  have hnPrime : ∀ p ∈ n, p.Prime := fun p hp => (hn p hp).1
  have hsq : Squarefree (primeSetProduct n) :=
    primeSetProduct_squarefree hnPrime
  have hcop : (primeSetProduct n).Coprime (6 * q) :=
    activePrimeSetProduct_coprime hn
  have hpos : 0 < primeSetProduct n := primeSetProduct_pos hnPrime
  rw [fixedQShiuWeight_apply, fixedQShiuWeightNat,
    if_neg (Nat.ne_of_gt hpos), if_pos ⟨hsq, hcop⟩]
  have hpf : (primeSetProduct n).primeFactors = n := by
    simpa [primeSetProduct] using Nat.primeFactors_prod hnPrime
  rw [hpf]
  unfold finiteOmegaWeightReal
  calc
    (∏ p ∈ n, fixedQShiuPrimeFactor p)
      = ∏ p ∈ n, (2 : ℝ) * (1 / ((p : ℝ) - 3)) := by
          apply Finset.prod_congr rfl
          intro p hp
          unfold fixedQShiuPrimeFactor
          rw [if_pos (hn p hp).2.1]
          ring
    _ = (∏ _p ∈ n, (2 : ℝ)) *
        (∏ p ∈ n, 1 / ((p : ℝ) - 3)) := by
          rw [← Finset.prod_mul_distrib]
    _ = (2 : ℝ) ^ n.card *
        (∏ p ∈ n, 1 / ((p : ℝ) - 3)) := by
          rw [Finset.prod_const]



theorem abs_decoratedDensityPerE_le_shiu_harmonic
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h)
    {e : Finset ℕ}
    (hAall : ∀ p ∈ e, activeHighPrime q p) :
    let d := heightPrimePart h e
    let n := e \ d
    |decoratedDensityPerE q a h e| ≤
      genericFixedQPeriodicDensityBound q *
        finiteVWeightReal h d *
        (fixedQShiuWeight q (primeSetProduct n) /
          (primeSetProduct n : ℝ)) := by
  let d := heightPrimePart h e
  let n := e \ d
  have hdsub : d ⊆ e := by
    dsimp [d]
    exact Finset.filter_subset _ _
  have hnActive : ∀ p ∈ n, activeHighPrime q p := by
    intro p hp
    exact hAall p (Finset.mem_sdiff.mp hp).1
  have hnPrime : ∀ p ∈ n, p.Prime := fun p hp => (hnActive p hp).1
  have hnpos : 0 < primeSetProduct n := primeSetProduct_pos hnPrime
  have hv0 : 0 ≤ finiteVWeightReal h d := by
    apply finiteVWeightReal_nonneg_of_active
    intro p hp
    exact hAall p (hdsub hp)
  have hw0 : 0 ≤ finiteOmegaWeightReal n :=
    finiteOmegaWeightReal_nonneg_of_active hnActive
  have hB0 : 0 ≤ genericFixedQPeriodicDensityBound q := by
    unfold genericFixedQPeriodicDensityBound fixedQDensityDefectUniformBound
      admissibleCountMeanErrorBound
    positivity
  let C : ℝ :=
    genericFixedQPeriodicDensityBound q *
      finiteVWeightReal h d *
      (finiteOmegaWeightReal n / (primeSetProduct n : ℝ))
  have hC0 : 0 ≤ C := by
    dsimp [C]
    positivity
  let S : Finset (Finset ℕ) :=
    ((e.powerset.erase e).erase d)
  let G : Finset (Finset ℕ) :=
    S.filter (fun e1 => d ⊆ e1)
  have hzero :
      ∀ e1 ∈ S, ¬ d ⊆ e1 →
        decoratedDensityPairTerm q a h e e1 = 0 := by
    intro e1 he1 hmiss
    have he1ps : e1 ∈ e.powerset :=
      Finset.mem_of_mem_erase (Finset.mem_of_mem_erase he1)
    have he1sub : e1 ⊆ e := Finset.mem_powerset.mp he1ps
    have hz := pairCoefficient_eq_zero_of_missing_height_prime
      he1sub hAall (by simpa [Finset.not_subset] using hmiss)
    simp [decoratedDensityPairTerm, hz]
  have hrestrict :
      (∑ e1 ∈ S, |decoratedDensityPairTerm q a h e e1|) =
        ∑ e1 ∈ G, |decoratedDensityPairTerm q a h e e1| := by
    dsimp [G]
    rw [Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro e1 he1
    by_cases hde : d ⊆ e1
    · simp [hde]
    · simp [hde, hzero e1 he1 hde]
  have hGsub :
      G ⊆ e.powerset.filter (fun e1 => d ⊆ e1) := by
    intro e1 he1
    have hmem := Finset.mem_filter.mp he1
    have he1ps : e1 ∈ e.powerset :=
      Finset.mem_of_mem_erase
        (Finset.mem_of_mem_erase hmem.1)
    exact Finset.mem_filter.mpr ⟨he1ps, hmem.2⟩
  have hterm :
      ∀ e1 ∈ G,
        |decoratedDensityPairTerm q a h e e1| ≤ C := by
    intro e1 he1
    have hmem := Finset.mem_filter.mp he1
    have he1ps : e1 ∈ e.powerset :=
      Finset.mem_of_mem_erase
        (Finset.mem_of_mem_erase hmem.1)
    have he1sub : e1 ⊆ e := Finset.mem_powerset.mp he1ps
    dsimp [C]
    simpa [d, n] using
      abs_decoratedDensityPairTerm_le_forbidden_harmonic
        hq hh h2admissible he1sub hAall hmem.2
  have hsumC :
      (∑ e1 ∈ G, |decoratedDensityPairTerm q a h e e1|)
        ≤ (G.card : ℝ) * C := by
    calc
      (∑ e1 ∈ G, |decoratedDensityPairTerm q a h e e1|)
        ≤ ∑ _e1 ∈ G, C := by
            exact Finset.sum_le_sum hterm
      _ = (G.card : ℝ) * C := by simp [mul_comm]
  have hcard :
      G.card ≤ 2 ^ n.card := by
    calc
      G.card ≤ (e.powerset.filter (fun e1 => d ⊆ e1)).card :=
        Finset.card_le_card hGsub
      _ = 2 ^ (e \ d).card := heightContainingPowerset_card hdsub
      _ = 2 ^ n.card := rfl
  have hcardR : (G.card : ℝ) ≤ (2 : ℝ) ^ n.card := by
    exact_mod_cast hcard
  have hsum :
      |decoratedDensityPerE q a h e| ≤
        (2 : ℝ) ^ n.card * C := by
    unfold decoratedDensityPerE
    change |∑ e1 ∈ S, decoratedDensityPairTerm q a h e e1| ≤ _
    calc
      |∑ e1 ∈ S, decoratedDensityPairTerm q a h e e1|
        ≤ ∑ e1 ∈ S, |decoratedDensityPairTerm q a h e e1| :=
          Finset.abs_sum_le_sum_abs _ _
      _ = ∑ e1 ∈ G, |decoratedDensityPairTerm q a h e e1| := hrestrict
      _ ≤ (G.card : ℝ) * C := hsumC
      _ ≤ (2 : ℝ) ^ n.card * C :=
        mul_le_mul_of_nonneg_right hcardR hC0
  have hShiu :=
    fixedQShiuWeight_primeSetProduct_eq_card_mul_finiteOmegaWeightReal
      hnActive
  have hShiuNat :
      fixedQShiuWeightNat q (primeSetProduct n) =
        (2 : ℝ) ^ n.card * finiteOmegaWeightReal n := by
    simpa [fixedQShiuWeight_apply] using hShiu
  dsimp
  dsimp [C] at hsum
  rw [hShiuNat]
  calc
    |decoratedDensityPerE q a h e|
      ≤ (2 : ℝ) ^ n.card *
        (genericFixedQPeriodicDensityBound q *
          finiteVWeightReal h d *
          (finiteOmegaWeightReal n / (primeSetProduct n : ℝ))) := hsum
    _ = genericFixedQPeriodicDensityBound q *
        finiteVWeightReal h d *
        (((2 : ℝ) ^ n.card * finiteOmegaWeightReal n) /
          (primeSetProduct n : ℝ)) := by ring


theorem abs_decoratedDensityPerE_le_normalization
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h)
    (e : Finset ℕ) :
    |decoratedDensityPerE q a h e| ≤
      (genericFixedQPeriodicDensityBound q * (h : ℝ)) *
        normalizationWeightMass q h e := by
  unfold decoratedDensityPerE
  calc
    |∑ e1 ∈ ((e.powerset.erase e).erase (heightPrimePart h e)),
        decoratedDensityPairTerm q a h e e1| ≤
      ∑ e1 ∈ ((e.powerset.erase e).erase (heightPrimePart h e)),
        |decoratedDensityPairTerm q a h e e1| := by
          exact Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ e1 ∈ ((e.powerset.erase e).erase (heightPrimePart h e)),
        genericFixedQPeriodicDensityBound q * (h : ℝ) *
          (pairCoefficient q h e e1 / pairDenominator e e1) := by
          apply Finset.sum_le_sum
          intro e1 he1
          have he1ps : e1 ∈ e.powerset :=
            Finset.mem_of_mem_erase (Finset.mem_of_mem_erase he1)
          exact abs_decoratedDensityPairTerm_le_h_mul_baseline
            hq hh h2admissible (Finset.mem_powerset.mp he1ps)
    _ ≤ ∑ e1 ∈ e.powerset,
        genericFixedQPeriodicDensityBound q * (h : ℝ) *
          (pairCoefficient q h e e1 / pairDenominator e e1) := by
          apply Finset.sum_le_sum_of_subset_of_nonneg
          · exact (Finset.erase_subset _ _).trans (Finset.erase_subset _ _)
          · intro e1 he1 hnot
            exact mul_nonneg
              (mul_nonneg
                (by
                  unfold genericFixedQPeriodicDensityBound
                    fixedQDensityDefectUniformBound admissibleCountMeanErrorBound
                  positivity)
                (by positivity))
              (pairBaseline_nonneg q h e e1)
    _ = (genericFixedQPeriodicDensityBound q * (h : ℝ)) *
        normalizationWeightMass q h e := by
          rw [normalizationWeightMass_eq_pairBaselineSum]
          rw [Finset.mul_sum]


noncomputable def decoratedHeightDensityMassTerm
    (q h : ℕ) (d : Finset ℕ) : ℝ :=
  if d ∈ (decoratedHeightPrimeSet q h).powerset
  then finiteVWeightReal h d
  else 0

lemma decoratedHeightDensityMassTerm_nonneg
    (q h : ℕ) (d : Finset ℕ) :
    0 ≤ decoratedHeightDensityMassTerm q h d := by
  unfold decoratedHeightDensityMassTerm
  split_ifs with hd
  · apply finiteVWeightReal_nonneg_of_active
    intro p hp
    have hsub := Finset.mem_powerset.mp hd
    have hpSet := Finset.mem_filter.mp (hsub hp)
    exact ⟨Nat.prime_of_mem_primeFactors hpSet.1, hpSet.2.1, hpSet.2.2⟩
  · exact le_rfl

theorem summable_decoratedHeightDensityMassTerm
    (q h : ℕ) :
    Summable (decoratedHeightDensityMassTerm q h) := by
  apply summable_of_hasFiniteSupport
  refine (decoratedHeightPrimeSet q h).powerset.finite_toSet.subset ?_
  intro d hd
  by_contra hmem
  have hmemF : d ∉ (decoratedHeightPrimeSet q h).powerset := by
    simpa using hmem
  have hz : decoratedHeightDensityMassTerm q h d = 0 := by
    simp [decoratedHeightDensityMassTerm, hmemF]
  exact hd hz

theorem tsum_decoratedHeightDensityMassTerm
    (q h : ℕ) :
    (∑' d : Finset ℕ, decoratedHeightDensityMassTerm q h d) =
      ∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
        finiteVWeightReal h d := by
  rw [tsum_eq_sum (s := (decoratedHeightPrimeSet q h).powerset)]
  · apply Finset.sum_congr rfl
    intro d hd
    simp [decoratedHeightDensityMassTerm, hd]
  · intro d hd
    simp [decoratedHeightDensityMassTerm, hd]

noncomputable def decoratedDensityProductMajorant
    (q h : ℕ) (dm : Finset ℕ × ℕ) : ℝ :=
  genericFixedQPeriodicDensityBound q *
    decoratedHeightDensityMassTerm q h dm.1 *
    fixedQShiuCoprimeHarmonicTerm q h dm.2

lemma decoratedDensityProductMajorant_nonneg
    (q h : ℕ) (dm : Finset ℕ × ℕ) :
    0 ≤ decoratedDensityProductMajorant q h dm := by
  unfold decoratedDensityProductMajorant
  have hB0 : 0 ≤ genericFixedQPeriodicDensityBound q := by
    unfold genericFixedQPeriodicDensityBound fixedQDensityDefectUniformBound
      admissibleCountMeanErrorBound
    positivity
  exact mul_nonneg
    (mul_nonneg hB0 (decoratedHeightDensityMassTerm_nonneg q h dm.1))
    (fixedQShiuCoprimeHarmonicTerm_nonneg q h dm.2)

theorem summable_decoratedDensityProductMajorant
    (q h : ℕ) :
    Summable (decoratedDensityProductMajorant q h) := by
  apply (summable_prod_of_nonneg
    (fun dm => decoratedDensityProductMajorant_nonneg q h dm)).2
  constructor
  · intro d
    exact (summable_fixedQShiuCoprimeHarmonicTerm q h).mul_left
      (genericFixedQPeriodicDensityBound q *
        decoratedHeightDensityMassTerm q h d)
  · have hsH := summable_decoratedHeightDensityMassTerm q h
    let hM : ℝ := ∑' m : ℕ, fixedQShiuCoprimeHarmonicTerm q h m
    have heq :
        (fun d : Finset ℕ =>
          ∑' m : ℕ, decoratedDensityProductMajorant q h (d, m)) =
        (fun d : Finset ℕ =>
          (genericFixedQPeriodicDensityBound q * hM) *
            decoratedHeightDensityMassTerm q h d) := by
      funext d
      change (∑' m : ℕ,
        (genericFixedQPeriodicDensityBound q *
          decoratedHeightDensityMassTerm q h d) *
          fixedQShiuCoprimeHarmonicTerm q h m) =
        (genericFixedQPeriodicDensityBound q * hM) *
          decoratedHeightDensityMassTerm q h d
      rw [tsum_mul_left]
      dsimp [hM]
      ring
    rw [heq]
    exact hsH.mul_left
      (genericFixedQPeriodicDensityBound q * hM)

theorem tsum_decoratedDensityProductMajorant
    (q h : ℕ) :
    (∑' dm : Finset ℕ × ℕ, decoratedDensityProductMajorant q h dm) =
      genericFixedQPeriodicDensityBound q *
        (∑' d : Finset ℕ, decoratedHeightDensityMassTerm q h d) *
        (∑' m : ℕ, fixedQShiuCoprimeHarmonicTerm q h m) := by
  have hs := summable_decoratedDensityProductMajorant q h
  rw [hs.tsum_prod]
  calc
    (∑' d : Finset ℕ, ∑' m : ℕ,
      decoratedDensityProductMajorant q h (d, m))
      = ∑' d : Finset ℕ,
          (genericFixedQPeriodicDensityBound q *
            decoratedHeightDensityMassTerm q h d) *
          (∑' m : ℕ, fixedQShiuCoprimeHarmonicTerm q h m) := by
            apply tsum_congr
            intro d
            change (∑' m : ℕ,
              (genericFixedQPeriodicDensityBound q *
                decoratedHeightDensityMassTerm q h d) *
                fixedQShiuCoprimeHarmonicTerm q h m) =
              (genericFixedQPeriodicDensityBound q *
                decoratedHeightDensityMassTerm q h d) *
                (∑' m : ℕ, fixedQShiuCoprimeHarmonicTerm q h m)
            rw [tsum_mul_left]
    _ = ∑' d : Finset ℕ,
          (genericFixedQPeriodicDensityBound q *
            (∑' m : ℕ, fixedQShiuCoprimeHarmonicTerm q h m)) *
          decoratedHeightDensityMassTerm q h d := by
            apply tsum_congr
            intro d
            ring
    _ = (genericFixedQPeriodicDensityBound q *
          (∑' m : ℕ, fixedQShiuCoprimeHarmonicTerm q h m)) *
        (∑' d : Finset ℕ, decoratedHeightDensityMassTerm q h d) := by
          rw [tsum_mul_left]
    _ = genericFixedQPeriodicDensityBound q *
        (∑' d : Finset ℕ, decoratedHeightDensityMassTerm q h d) *
        (∑' m : ℕ, fixedQShiuCoprimeHarmonicTerm q h m) := by ring



lemma heightPrimePart_subset_decoratedHeightPrimeSet_of_active
    {q h : ℕ} (hh : 0 < h) {e : Finset ℕ}
    (hAall : ∀ p ∈ e, activeHighPrime q p) :
    heightPrimePart h e ⊆ decoratedHeightPrimeSet q h := by
  intro p hp
  have hpE : p ∈ e := (Finset.mem_filter.mp hp).1
  have hpH : p ∣ h := (Finset.mem_filter.mp hp).2
  have hA := hAall p hpE
  apply Finset.mem_filter.mpr
  constructor
  · exact Nat.mem_primeFactors.mpr
      ⟨hA.1, hpH, Nat.ne_of_gt hh⟩
  · exact ⟨hA.2.1, hA.2.2⟩

lemma primeSetProduct_nonheight_coprime_height
    {q h : ℕ} {e : Finset ℕ}
    (hAall : ∀ p ∈ e, activeHighPrime q p) :
    (primeSetProduct (e \ heightPrimePart h e)).Coprime h := by
  let n := e \ heightPrimePart h e
  have hnPrime : ∀ p ∈ n, p.Prime := by
    intro p hp
    exact (hAall p (Finset.mem_sdiff.mp hp).1).1
  apply (ordinary_primeSetProduct_coprime_height_iff hnPrime).1
  rw [ordinaryTwoDimensionalSet_iff]
  intro p hp
  have hpPair := Finset.mem_sdiff.mp hp
  intro hpH
  apply hpPair.2
  simp [heightPrimePart, hpPair.1, hpH]

lemma decoratedDensityPerE_eq_zero_of_not_all_active
    {q a h : ℕ} {e : Finset ℕ}
    (hnot : ¬ ∀ p ∈ e, activeHighPrime q p) :
    decoratedDensityPerE q a h e = 0 := by
  unfold decoratedDensityPerE
  apply Finset.sum_eq_zero
  intro e1 he1
  have he1ps : e1 ∈ e.powerset :=
    Finset.mem_of_mem_erase (Finset.mem_of_mem_erase he1)
  have he1sub : e1 ⊆ e := Finset.mem_powerset.mp he1ps
  have hz := pairCoefficient_eq_zero_of_not_all_active
    (q := q) (h := h) (e := e) (e1 := e1) hnot
  simp [decoratedDensityPairTerm, hz]

noncomputable def decoratedDensityReindexKey
    (q h : ℕ) (e : Finset ℕ) :
    (Finset ℕ × ℕ) ⊕ Finset ℕ :=
  if ∀ p ∈ e, activeHighPrime q p then
    Sum.inl
      (heightPrimePart h e,
        primeSetProduct (e \ heightPrimePart h e))
  else Sum.inr e

theorem decoratedDensityReindexKey_injective
    (q h : ℕ) :
    Function.Injective (decoratedDensityReindexKey q h) := by
  intro e₁ e₂ hkey
  by_cases hA₁ : ∀ p ∈ e₁, activeHighPrime q p
  · by_cases hA₂ : ∀ p ∈ e₂, activeHighPrime q p
    · rw [decoratedDensityReindexKey, if_pos hA₁,
        decoratedDensityReindexKey, if_pos hA₂] at hkey
      have hk :
          (heightPrimePart h e₁,
            primeSetProduct (e₁ \ heightPrimePart h e₁)) =
          (heightPrimePart h e₂,
            primeSetProduct (e₂ \ heightPrimePart h e₂)) :=
        Sum.inl.inj hkey
      have hd :
          heightPrimePart h e₁ = heightPrimePart h e₂ :=
        congrArg Prod.fst hk
      have hm :
          primeSetProduct (e₁ \ heightPrimePart h e₁) =
          primeSetProduct (e₂ \ heightPrimePart h e₂) :=
        congrArg Prod.snd hk
      let n₁ := e₁ \ heightPrimePart h e₁
      let n₂ := e₂ \ heightPrimePart h e₂
      have hn₁Prime : ∀ p ∈ n₁, p.Prime := by
        intro p hp
        exact (hA₁ p (Finset.mem_sdiff.mp hp).1).1
      have hn₂Prime : ∀ p ∈ n₂, p.Prime := by
        intro p hp
        exact (hA₂ p (Finset.mem_sdiff.mp hp).1).1
      have hpf₁ : (primeSetProduct n₁).primeFactors = n₁ := by
        simpa [primeSetProduct] using Nat.primeFactors_prod hn₁Prime
      have hpf₂ : (primeSetProduct n₂).primeFactors = n₂ := by
        simpa [primeSetProduct] using Nat.primeFactors_prod hn₂Prime
      have hn : n₁ = n₂ := by
        rw [← hpf₁, ← hpf₂]
        simpa [n₁, n₂] using congrArg Nat.primeFactors hm
      have hu₁ :
          heightPrimePart h e₁ ∪ n₁ = e₁ := by
        dsimp [n₁]
        exact Finset.union_sdiff_of_subset (Finset.filter_subset _ _)
      have hu₂ :
          heightPrimePart h e₂ ∪ n₂ = e₂ := by
        dsimp [n₂]
        exact Finset.union_sdiff_of_subset (Finset.filter_subset _ _)
      calc
        e₁ = heightPrimePart h e₁ ∪ n₁ := hu₁.symm
        _ = heightPrimePart h e₂ ∪ n₂ := by rw [hd, hn]
        _ = e₂ := hu₂
    · rw [decoratedDensityReindexKey, if_pos hA₁,
        decoratedDensityReindexKey, if_neg hA₂] at hkey
      cases hkey
  · by_cases hA₂ : ∀ p ∈ e₂, activeHighPrime q p
    · rw [decoratedDensityReindexKey, if_neg hA₁,
        decoratedDensityReindexKey, if_pos hA₂] at hkey
      cases hkey
    · rw [decoratedDensityReindexKey, if_neg hA₁,
        decoratedDensityReindexKey, if_neg hA₂] at hkey
      exact Sum.inr.inj hkey


noncomputable def decoratedDensityReindexMajorant
    (q h : ℕ) :
    (Finset ℕ × ℕ) ⊕ Finset ℕ → ℝ
  | Sum.inl dm => decoratedDensityProductMajorant q h dm
  | Sum.inr _ => 0

theorem summable_decoratedDensityReindexMajorant
    (q h : ℕ) :
    Summable (decoratedDensityReindexMajorant q h) := by
  apply Summable.sum (decoratedDensityReindexMajorant q h)
  · change Summable (decoratedDensityProductMajorant q h)
    exact summable_decoratedDensityProductMajorant q h
  · change Summable (fun _ : Finset ℕ => (0 : ℝ))
    exact summable_zero

theorem tsum_decoratedDensityReindexMajorant
    (q h : ℕ) :
    (∑' x, decoratedDensityReindexMajorant q h x) =
      ∑' dm : Finset ℕ × ℕ, decoratedDensityProductMajorant q h dm := by
  have hL : Summable
      (decoratedDensityReindexMajorant q h ∘ Sum.inl) := by
    change Summable (decoratedDensityProductMajorant q h)
    exact summable_decoratedDensityProductMajorant q h
  have hR : Summable
      (decoratedDensityReindexMajorant q h ∘ Sum.inr) := by
    change Summable (fun _ : Finset ℕ => (0 : ℝ))
    exact summable_zero
  rw [hL.tsum_sum hR]
  simp [decoratedDensityReindexMajorant]

theorem abs_decoratedDensity_indicator_le_reindexMajorant
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h)
    (e : Finset ℕ) :
    |(ordinaryTwoDimensionalSet h)ᶜ.indicator
        (decoratedDensityPerE q a h) e| ≤
      decoratedDensityReindexMajorant q h
        (decoratedDensityReindexKey q h e) := by
  by_cases hA : ∀ p ∈ e, activeHighPrime q p
  · let d := heightPrimePart h e
    let n := e \ d
    let m := primeSetProduct n
    have hdset :
        d ⊆ decoratedHeightPrimeSet q h := by
      simpa [d] using
        heightPrimePart_subset_decoratedHeightPrimeSet_of_active hh hA
    have hH :
        decoratedHeightDensityMassTerm q h d =
          finiteVWeightReal h d := by
      simp [decoratedHeightDensityMassTerm,
        Finset.mem_powerset.mpr hdset]
    have hcop : m.Coprime h := by
      simpa [m, n, d] using
        primeSetProduct_nonheight_coprime_height hA
    have hM :
        fixedQShiuCoprimeHarmonicTerm q h m =
          fixedQShiuWeight q m / (m : ℝ) := by
      simp [fixedQShiuCoprimeHarmonicTerm, hcop]
    have hper :=
      abs_decoratedDensityPerE_le_shiu_harmonic
        (a := a) hq hh h2admissible hA
    rw [decoratedDensityReindexKey, if_pos hA]
    simp only [decoratedDensityReindexMajorant]
    unfold decoratedDensityProductMajorant
    change |(ordinaryTwoDimensionalSet h)ᶜ.indicator
        (decoratedDensityPerE q a h) e| ≤
      genericFixedQPeriodicDensityBound q *
        decoratedHeightDensityMassTerm q h d *
        fixedQShiuCoprimeHarmonicTerm q h m
    by_cases he : e ∈ (ordinaryTwoDimensionalSet h)ᶜ
    · rw [Set.indicator_of_mem he, hH, hM]
      simpa [d, n, m] using hper
    · simp [Set.indicator, he]
      exact mul_nonneg
        (mul_nonneg
          (by
            unfold genericFixedQPeriodicDensityBound
              fixedQDensityDefectUniformBound admissibleCountMeanErrorBound
            positivity)
          (decoratedHeightDensityMassTerm_nonneg q h d))
        (fixedQShiuCoprimeHarmonicTerm_nonneg q h m)
  · have hper : decoratedDensityPerE q a h e = 0 :=
      decoratedDensityPerE_eq_zero_of_not_all_active hA
    simp [decoratedDensityReindexKey, hA,
      decoratedDensityReindexMajorant, hper]


theorem summable_decoratedDensityPerE_indicator
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    Summable
      ((ordinaryTwoDimensionalSet h)ᶜ.indicator
        (decoratedDensityPerE q a h)) := by
  have hmajor :
      Summable (fun e : Finset ℕ =>
        (genericFixedQPeriodicDensityBound q * (h : ℝ)) *
          normalizationWeightMass q h e) :=
    (summable_normalizationWeightMass q h).mul_left
      (genericFixedQPeriodicDensityBound q * (h : ℝ))
  apply hmajor.of_norm_bounded
  intro e
  rw [Real.norm_eq_abs]
  by_cases he : e ∈ (ordinaryTwoDimensionalSet h)ᶜ
  · rw [Set.indicator_of_mem he]
    exact abs_decoratedDensityPerE_le_normalization hq hh h2admissible e
  · simp [Set.indicator, he]
    exact mul_nonneg
      (mul_nonneg
        (by
          unfold genericFixedQPeriodicDensityBound
            fixedQDensityDefectUniformBound admissibleCountMeanErrorBound
          positivity)
        (by positivity))
      (normalizationWeightMass_nonneg q h e)

theorem abs_decoratedDensityRemainder_le_productMajorant
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    |decoratedDensityRemainder q a h| ≤
      ∑' dm : Finset ℕ × ℕ, decoratedDensityProductMajorant q h dm := by
  let f : Finset ℕ → ℝ :=
    (ordinaryTwoDimensionalSet h)ᶜ.indicator
      (decoratedDensityPerE q a h)
  have hsF : Summable f := by
    dsimp [f]
    exact summable_decoratedDensityPerE_indicator hq hh h2admissible
  have hsAbs : Summable (fun e : Finset ℕ => |f e|) := by
    simpa [Real.norm_eq_abs] using hsF.norm
  have hsG := summable_decoratedDensityReindexMajorant q h
  have hle :
      (∑' e : Finset ℕ, |f e|) ≤
        ∑' x, decoratedDensityReindexMajorant q h x := by
    apply hsAbs.tsum_le_tsum_of_inj
      (decoratedDensityReindexKey q h)
      (decoratedDensityReindexKey_injective q h)
    · intro x hx
      cases x with
      | inl dm =>
          exact decoratedDensityProductMajorant_nonneg q h dm
      | inr e => exact le_rfl
    · intro e
      dsimp [f]
      exact abs_decoratedDensity_indicator_le_reindexMajorant
        hq hh h2admissible e
    · exact hsG
  unfold decoratedDensityRemainder
  change |∑' e : Finset ℕ, f e| ≤ _
  calc
    |∑' e : Finset ℕ, f e|
      ≤ ∑' e : Finset ℕ, |f e| := by
        simpa [Real.norm_eq_abs] using norm_tsum_le_tsum_norm hsF.norm
    _ ≤ ∑' x, decoratedDensityReindexMajorant q h x := hle
    _ = ∑' dm : Finset ℕ × ℕ,
        decoratedDensityProductMajorant q h dm :=
      tsum_decoratedDensityReindexMajorant q h




noncomputable def decoratedDensityLogLogConstant (q : ℕ) : ℝ :=
  genericFixedQPeriodicDensityBound q *
    weakDecoratedMertensC * Real.exp 5

lemma decoratedDensityLogLogConstant_nonneg (q : ℕ) :
    0 ≤ decoratedDensityLogLogConstant q := by
  unfold decoratedDensityLogLogConstant
  have hB0 : 0 ≤ genericFixedQPeriodicDensityBound q := by
    unfold genericFixedQPeriodicDensityBound fixedQDensityDefectUniformBound
      admissibleCountMeanErrorBound
    positivity
  have hW0 : 0 ≤ weakDecoratedMertensC := by
    unfold weakDecoratedMertensC weakMertensC
    positivity
  positivity

theorem abs_decoratedDensityRemainder_le_loglog
    {q a h : ℕ} (hq : 0 < q) (hh : 16 ≤ h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    |decoratedDensityRemainder q a h| ≤
      decoratedDensityLogLogConstant q *
        Real.log (Real.log (h : ℝ)) := by
  have hhpos : 0 < h := by omega
  have hbase :=
    abs_decoratedDensityRemainder_le_productMajorant
      (q := q) (a := a) hq hhpos h2admissible
  rw [tsum_decoratedDensityProductMajorant,
    tsum_decoratedHeightDensityMassTerm] at hbase
  have hHle :
      (∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
        finiteVWeightReal h d) ≤
        weakDecoratedMertensC * Real.log (Real.log (h : ℝ)) :=
    (sum_decorated_finiteVWeightReal_lt_weakMertens
      (q := q) hh).le
  have hMle :=
    tsum_fixedQShiuWeight_div_coprime_le_exp_five q h
  have hB0 : 0 ≤ genericFixedQPeriodicDensityBound q := by
    unfold genericFixedQPeriodicDensityBound fixedQDensityDefectUniformBound
      admissibleCountMeanErrorBound
    positivity
  have hH0 :
      0 ≤ ∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
        finiteVWeightReal h d := by
    apply Finset.sum_nonneg
    intro d hd
    apply finiteVWeightReal_nonneg_of_active
    intro p hp
    have hsub := Finset.mem_powerset.mp hd
    have hpSet := Finset.mem_filter.mp (hsub hp)
    exact ⟨Nat.prime_of_mem_primeFactors hpSet.1, hpSet.2.1, hpSet.2.2⟩
  have hM0 :
      0 ≤ ∑' m : ℕ, fixedQShiuCoprimeHarmonicTerm q h m :=
    tsum_nonneg (fixedQShiuCoprimeHarmonicTerm_nonneg q h)
  have hloglog0 : 0 ≤ Real.log (Real.log (h : ℝ)) := by
    have h1 := one_le_log_log_nat_of_sixteen_le hh
    linarith
  have hW0 : 0 ≤ weakDecoratedMertensC := by
    unfold weakDecoratedMertensC weakMertensC
    positivity
  calc
    |decoratedDensityRemainder q a h|
      ≤ genericFixedQPeriodicDensityBound q *
          (∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
            finiteVWeightReal h d) *
          (∑' m : ℕ, fixedQShiuCoprimeHarmonicTerm q h m) := hbase
    _ ≤ genericFixedQPeriodicDensityBound q *
          (weakDecoratedMertensC * Real.log (Real.log (h : ℝ))) *
          (∑' m : ℕ, fixedQShiuCoprimeHarmonicTerm q h m) := by
            gcongr
    _ ≤ genericFixedQPeriodicDensityBound q *
          (weakDecoratedMertensC * Real.log (Real.log (h : ℝ))) *
          Real.exp 5 := by
            gcongr
    _ = decoratedDensityLogLogConstant q *
        Real.log (Real.log (h : ℝ)) := by
          unfold decoratedDensityLogLogConstant
          ring



theorem decoratedDensityRemainder_sublog
    (q : ℕ) (hq : 0 < q) :
    ∀ ε : ℝ, 0 < ε →
      ∃ h0 : ℕ,
        ∀ a h : ℕ,
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          h0 ≤ h →
          |cStarReal q h * decoratedDensityRemainder q a h| ≤
            ε * Real.log (h : ℝ) := by
  intro ε hε
  let C : ℝ := decoratedDensityLogLogConstant q
  have hlo0 :
      (fun x : ℝ => Real.log (Real.log x)) =o[Filter.atTop]
        Real.log := by
    simpa [Function.comp_def] using
      Real.isLittleO_log_id_atTop.comp_tendsto Real.tendsto_log_atTop
  have hlo :
      (fun x : ℝ => C * Real.log (Real.log x)) =o[Filter.atTop]
        Real.log :=
    hlo0.const_mul_left C
  have hev := hlo.bound hε
  rw [Filter.eventually_atTop] at hev
  obtain ⟨T, hT⟩ := hev
  obtain ⟨N, hN⟩ := exists_nat_ge T
  refine ⟨max 16 N, ?_⟩
  intro a h h2admissible hh hlarge
  have hh16 : 16 ≤ h :=
    (le_max_left 16 N).trans hlarge
  have hNh : N ≤ h :=
    (le_max_right 16 N).trans hlarge
  have hTR : T ≤ (h : ℝ) := by
    exact hN.trans (by exact_mod_cast hNh)
  have hasym := hT (h : ℝ) hTR
  have hloglog0 : 0 ≤ Real.log (Real.log (h : ℝ)) := by
    have h1 := one_le_log_log_nat_of_sixteen_le hh16
    linarith
  have hlog0 : 0 ≤ Real.log (h : ℝ) := by
    exact Real.log_nonneg (by exact_mod_cast (show 1 ≤ h by omega))
  have hC0 : 0 ≤ C := by
    dsimp [C]
    exact decoratedDensityLogLogConstant_nonneg q
  rw [Real.norm_eq_abs,
    abs_of_nonneg (mul_nonneg hC0 hloglog0),
    Real.norm_eq_abs, abs_of_nonneg hlog0] at hasym
  have hrem :=
    abs_decoratedDensityRemainder_le_loglog
      (q := q) (a := a) hq hh16 h2admissible
  have hc := abs_cStarReal_le_one q h
  rw [abs_mul]
  calc
    |cStarReal q h| * |decoratedDensityRemainder q a h|
      ≤ 1 * (C * Real.log (Real.log (h : ℝ))) := by
          gcongr
    _ = C * Real.log (Real.log (h : ℝ)) := by ring
    _ ≤ ε * Real.log (h : ℝ) := hasym


theorem abs_cStar_mul_decoratedDensityRemainder_le_height_majorant
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    |cStarReal q h * decoratedDensityRemainder q a h| ≤
      genericFixedQPeriodicDensityBound q * (h : ℝ) := by
  let B : ℝ := genericFixedQPeriodicDensityBound q * (h : ℝ)
  have hB0 : 0 ≤ B := by
    dsimp [B]
    apply mul_nonneg
    · unfold genericFixedQPeriodicDensityBound
        fixedQDensityDefectUniformBound admissibleCountMeanErrorBound
      positivity
    · positivity
  have hsD := summable_decoratedDensityPerE_indicator
    (q := q) (a := a) hq hh h2admissible
  have hmajor :
      Summable (fun e : Finset ℕ => B * normalizationWeightMass q h e) :=
    (summable_normalizationWeightMass q h).mul_left B
  have hpoint :
      ∀ e : Finset ℕ,
        ‖(ordinaryTwoDimensionalSet h)ᶜ.indicator
            (decoratedDensityPerE q a h) e‖ ≤
          B * normalizationWeightMass q h e := by
    intro e
    rw [Real.norm_eq_abs]
    by_cases he : e ∈ (ordinaryTwoDimensionalSet h)ᶜ
    · rw [Set.indicator_of_mem he]
      dsimp [B]
      exact abs_decoratedDensityPerE_le_normalization
        hq hh h2admissible e
    · simp [Set.indicator, he]
      exact mul_nonneg hB0 (normalizationWeightMass_nonneg q h e)
  have hNorm :
      ‖decoratedDensityRemainder q a h‖ ≤
        B * (∑' e : Finset ℕ, normalizationWeightMass q h e) := by
    unfold decoratedDensityRemainder
    calc
      ‖∑' e : Finset ℕ,
          (ordinaryTwoDimensionalSet h)ᶜ.indicator
            (decoratedDensityPerE q a h) e‖ ≤
        ∑' e : Finset ℕ,
          ‖(ordinaryTwoDimensionalSet h)ᶜ.indicator
            (decoratedDensityPerE q a h) e‖ :=
          norm_tsum_le_tsum_norm hsD.norm
      _ ≤ ∑' e : Finset ℕ,
          B * normalizationWeightMass q h e :=
            hsD.norm.tsum_le_tsum hpoint hmajor
      _ = B * (∑' e : Finset ℕ, normalizationWeightMass q h e) := by
        rw [tsum_mul_left]
  have hc0 : 0 ≤ cStarReal q h := cStarReal_nonneg q h
  rw [abs_mul, abs_of_nonneg hc0, ← Real.norm_eq_abs]
  calc
    cStarReal q h * ‖decoratedDensityRemainder q a h‖ ≤
      cStarReal q h *
        (B * (∑' e : Finset ℕ, normalizationWeightMass q h e)) :=
          mul_le_mul_of_nonneg_left hNorm hc0
    _ = B * (cStarReal q h *
        (∑' e : Finset ℕ, normalizationWeightMass q h e)) := by ring
    _ = B := by
      rw [infiniteNormalizationWeightMass q h]
      ring
    _ = genericFixedQPeriodicDensityBound q * (h : ℝ) := rfl

theorem summable_decoratedAnalyticPerE_indicator
    {q a r h : ℕ}
    (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h)
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    Summable
      ((ordinaryTwoDimensionalSet h)ᶜ.indicator
        (decoratedAnalyticPerE q a h)) := by
  have hsT :=
    (summable_twoDimensionalPerE hreflect).indicator
      (ordinaryTwoDimensionalSet h)ᶜ
  have hsD := summable_decoratedDensityPerE_indicator
    (q := q) (a := a) hq hh h2admissible
  have hpoint :
      ∀ e : Finset ℕ,
        (ordinaryTwoDimensionalSet h)ᶜ.indicator
          (decoratedAnalyticPerE q a h) e =
        (ordinaryTwoDimensionalSet h)ᶜ.indicator
          (twoDimensionalPerE q a h) e -
        (ordinaryTwoDimensionalSet h)ᶜ.indicator
          (decoratedDensityPerE q a h) e := by
    intro e
    by_cases he : e ∈ (ordinaryTwoDimensionalSet h)ᶜ
    · simp [Set.indicator, he,
        twoDimensionalPerE_eq_decoratedAnalytic_add_density hq e]
    · simp [Set.indicator, he]
  exact (hsT.sub hsD).congr (fun e => (hpoint e).symm)

theorem decoratedTwoDimensionalRemainder_eq_analytic_add_density
    {q a r h : ℕ}
    (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h)
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    decoratedTwoDimensionalRemainder q a h =
      decoratedAnalyticRemainder q a h +
      decoratedDensityRemainder q a h := by
  have hsA := summable_decoratedAnalyticPerE_indicator
    (q := q) (a := a) (r := r) hq hh h2admissible hreflect
  have hsD := summable_decoratedDensityPerE_indicator
    (q := q) (a := a) hq hh h2admissible
  unfold decoratedTwoDimensionalRemainder
    decoratedAnalyticRemainder decoratedDensityRemainder
  rw [← hsA.tsum_add hsD]
  apply tsum_congr
  intro e
  by_cases he : e ∈ (ordinaryTwoDimensionalSet h)ᶜ
  · simp [Set.indicator, he,
      twoDimensionalPerE_eq_decoratedAnalytic_add_density hq e]
  · simp [Set.indicator, he]

theorem decorated_nonheight_activeOrdinary
    {q h : ℕ} {e : Finset ℕ}
    (hAall : ∀ p ∈ e, activeHighPrime q p) :
    let d := heightPrimePart h e
    let n := e \ d
    let H := decoratedReducedHeight h e
    n ∈ activeOrdinaryTwoDimensionalSet q H := by
  dsimp
  constructor
  · rw [ordinaryTwoDimensionalSet_iff]
    intro p hpN
    have hpPair := Finset.mem_sdiff.mp hpN
    have hpE : p ∈ e := hpPair.1
    have hpNotD : p ∉ heightPrimePart h e := hpPair.2
    intro hpH
    have hfact :
        decoratedHeightProduct h e * decoratedReducedHeight h e = h :=
      decoratedHeightProduct_mul_reducedHeight hAall
    have hpDivProd :
        p ∣ decoratedHeightProduct h e * decoratedReducedHeight h e :=
      dvd_mul_of_dvd_right hpH _
    have hpDivH : p ∣ h := by simpa [hfact] using hpDivProd
    apply hpNotD
    simp [heightPrimePart, hpE, hpDivH]
  · intro p hpN
    exact hAall p (Finset.mem_sdiff.mp hpN).1

noncomputable def decoratedHeightForbiddenCoreTerm
    (q a h : ℕ) (e : Finset ℕ) : ℝ :=
  let d := heightPrimePart h e
  let n := e \ d
  let D := primeSetProduct d
  let H := h / D
  if hAall : ∀ p ∈ e, activeHighPrime q p then
    if Disjoint d n then
      finiteVWeightReal h d *
        ordinaryBooleanCoreTerm q
          (decoratedReducedAnchor q a D) H n
    else 0
  else 0

theorem decoratedAnalyticPerE_eq_height_forbidden_core_term
    {q a h : ℕ} {e : Finset ℕ}
    (hAall : ∀ p ∈ e, activeHighPrime q p) :
    decoratedAnalyticPerE q a h e =
      decoratedHeightForbiddenCoreTerm q a h e := by
  let d := heightPrimePart h e
  let n := e \ d
  have hdis : Disjoint d n := by
    dsimp [n]
    exact Finset.disjoint_sdiff
  have hAct := decorated_nonheight_activeOrdinary
    (q := q) (h := h) (e := e) hAall
  rw [decoratedAnalyticPerE_eq_height_weight_mul_boolean hAall]
  unfold decoratedHeightForbiddenCoreTerm
  simp only [dif_pos hAall]
  rw [if_pos hdis]
  simp only [decoratedHeightProduct, decoratedReducedHeight]
  have hAct' :
      e \ heightPrimePart h e ∈
        activeOrdinaryTwoDimensionalSet q
          (h / primeSetProduct (heightPrimePart h e)) := by
    simpa [decoratedReducedHeight, decoratedHeightProduct] using hAct
  rw [ordinaryBooleanCoreTerm, Set.indicator_of_mem hAct']
  ring

theorem decoratedAnalyticRemainder_eq_height_forbidden_core
    {q a h : ℕ} :
    decoratedAnalyticRemainder q a h =
      ∑' e : Finset ℕ,
        (ordinaryTwoDimensionalSet h)ᶜ.indicator
          (decoratedHeightForbiddenCoreTerm q a h) e := by
  unfold decoratedAnalyticRemainder
  apply tsum_congr
  intro e
  by_cases he : e ∈ (ordinaryTwoDimensionalSet h)ᶜ
  · rw [Set.indicator_of_mem he, Set.indicator_of_mem he]
    by_cases hAall : ∀ p ∈ e, activeHighPrime q p
    · exact decoratedAnalyticPerE_eq_height_forbidden_core_term hAall
    · have hper : decoratedAnalyticPerE q a h e = 0 := by
        unfold decoratedAnalyticPerE
        apply Finset.sum_eq_zero
        intro e1 he1
        have hz := pairCoefficient_eq_zero_of_not_all_active
          (q := q) (h := h) (e := e) (e1 := e1) hAall
        simp [decoratedAnalyticPairTerm, hz]
      rw [hper]
      simp [decoratedHeightForbiddenCoreTerm, hAall]
  · simp [Set.indicator, he]

#print axioms summable_decoratedDensityPerE_indicator
#print axioms abs_cStar_mul_decoratedDensityRemainder_le_height_majorant
#print axioms summable_decoratedAnalyticPerE_indicator
#print axioms decoratedTwoDimensionalRemainder_eq_analytic_add_density
#print axioms decoratedAnalyticPerE_eq_height_forbidden_core_term
#print axioms decoratedAnalyticRemainder_eq_height_forbidden_core

end PaperB.FixedQ
