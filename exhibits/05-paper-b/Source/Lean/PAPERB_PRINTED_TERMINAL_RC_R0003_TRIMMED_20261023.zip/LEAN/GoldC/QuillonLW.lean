import GoldC.QuillonWPhysical
import GoldC.QuillonLSetup

/-!
# Quillon LONG L2: the LONG-left W′ cell (r long, s modulus)

Constant-4 versions of `W_bracket_ev`, `W_term_ev` (copied proofs; the only change is the
admissibility constant `5 → 4` and the calls to `s_large4`/`sdecay4`), the fixed-`C` W′ cell
`W_final_L` on the LONG-left mask `GeoLL`, and the **physical LONG-left W′ theorem** `WL_physical`.

On LONG-left `r > s^{1+δ} ≥ s ≥ LwW(s)`, so the W′ Ramaré cofactor range `n ≥ r/Y ≥ s^{1+δ-u₀}` is
longer than in CORE; the same `s^{3/4}` complete-sum supplier suffices.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonLW

open GoldC.QuillonEv GoldC.QuillonSetup GoldC.QuillonLam GoldC.QuillonLSetup GoldC.QuillonWFinal
  GoldC.QuillonCopyM

lemma LwW_lt_LL {h H : ℕ} {δ : ℝ} (hδ0 : 0 < δ) {r s : ℕ} (hG : GeoLL h H δ r s) : LwW δ s < r := by
  have hL := hG.2.2.1
  unfold longInverseLeft at hL
  have h1 := LwW_le_self δ hδ0 s
  rcases Nat.eq_zero_or_pos s with h0 | h0
  · subst h0
    have hL' : ((0 : ℕ) : ℝ) ^ (1 + δ) < r := hL
    rw [Nat.cast_zero] at hL'
    have : (0 : ℝ) < r := lt_of_le_of_lt (Real.rpow_nonneg (le_refl (0 : ℝ)) _) hL'
    have : 0 < r := by exact_mod_cast this
    omega
  · have hs1 : (1 : ℝ) ≤ s := by exact_mod_cast h0
    have : (s : ℝ) ≤ (s : ℝ) ^ (1 + δ) := by
      calc (s : ℝ) = (s : ℝ) ^ (1 : ℝ) := (Real.rpow_one _).symm
        _ ≤ _ := Real.rpow_le_rpow_of_exponent_le hs1 (by linarith)
    have : s < r := by exact_mod_cast (lt_of_le_of_lt this hL)
    omega

/-- the `s`-part of the W′ bracket (constant 4). -/
theorem W_bracket_ev4 (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 1 ≤ Λ₀ ∧ ∀ Λ : ℝ, Λ₀ ≤ Λ → ∀ C : Finset ℕ, (∀ p ∈ C, p.Prime) →
      4 * Λ ^ σ₀ ≤ Real.log ((∏ p ∈ C, p : ℕ) : ℝ) →
      2 * (1 + Real.log (Yp δ (∏ p ∈ C, p) : ℝ)) / Real.sqrt ((∏ p ∈ C, p : ℕ) : ℝ) +
        2 * (1 + Real.log (Yp δ (∏ p ∈ C, p) : ℝ)) * (8 : ℝ) ^ C.card *
          Real.sqrt (((∏ p ∈ C, p : ℕ) : ℝ) ^ ((3 : ℝ) / 4) / ((∏ p ∈ C, p : ℕ) : ℝ) +
            ((∏ p ∈ C, p : ℕ) : ℝ) ^ ((3 : ℝ) / 4) * (1 + Real.log ((∏ p ∈ C, p : ℕ) : ℝ)) /
              ((LwW δ (∏ p ∈ C, p) / Yp δ (∏ p ∈ C, p) : ℕ) : ℝ)) ≤ 6 * Λ ^ (-(100 : ℝ)) := by
  have ha0 := a0_pos hδ0 hδ1
  have ha0' := a0_le hδ0
  obtain ⟨L₀, hL₀, h8⟩ := GoldC.QuillonAsymp.base_pow_card_le 8 (by norm_num) (a0 δ / 16) (by positivity)
  obtain ⟨Λ₁, hΛ₁, hs₁⟩ := s_large4 (max (Real.exp L₀) 36)
  obtain ⟨Λ₂, hΛ₂, hd₁⟩ := sdecay4 1 (1 / 2) 100 (by norm_num) (by norm_num)
  obtain ⟨Λ₃, hΛ₃, hd₂⟩ := sdecay4 2 (3 * a0 δ / 16) 100 (by positivity) (by norm_num)
  refine ⟨max Λ₁ (max Λ₂ Λ₃), le_trans hΛ₁ (le_max_left _ _), fun Λ hΛ C hC hlog => ?_⟩
  have hΛa : Λ₁ ≤ Λ := le_trans (le_max_left _ _) hΛ
  have hΛb : Λ₂ ≤ Λ := le_trans (le_trans (le_max_left _ _) (le_max_right _ _)) hΛ
  have hΛc : Λ₃ ≤ Λ := le_trans (le_trans (le_max_right _ _) (le_max_right _ _)) hΛ
  set s := ∏ p ∈ C, p with hs
  have hspos : 0 < s := prod_pos fun p hp => (hC p hp).pos
  have hs0 : (0 : ℝ) < s := by exact_mod_cast hspos
  have hsbig := hs₁ Λ hΛa s hs0 hlog
  have hsE : Real.exp L₀ ≤ (s : ℝ) := le_trans (le_max_left _ _) hsbig
  have hs36 : (36 : ℝ) ≤ s := le_trans (le_max_right _ _) hsbig
  have hs1 : (1 : ℝ) ≤ s := by linarith
  have hs1n : 1 ≤ s := by exact_mod_cast hs1
  have hlogL₀ : L₀ ≤ Real.log s := by
    rw [← Real.log_exp L₀]; exact Real.log_le_log (Real.exp_pos _) hsE
  set L := Real.log (s : ℝ) with hL
  have hL0 : 0 ≤ L := Real.log_nonneg hs1
  -- `1 + log Y ≤ 1 + L`
  have hY1 := Yp_pos hδ0 hδ1 hs1n
  have hYR : (1 : ℝ) ≤ Yp δ s := by exact_mod_cast hY1
  have hYs : (Yp δ s : ℝ) ≤ s := by
    refine le_trans (Yp_le δ s) ?_
    calc (s : ℝ) ^ u0 δ ≤ (s : ℝ) ^ (1 : ℝ) :=
          Real.rpow_le_rpow_of_exponent_le hs1 (by unfold u0; linarith)
      _ = s := Real.rpow_one _
  have hlY : 1 + Real.log (Yp δ s : ℝ) ≤ 1 + L := by
    have := Real.log_le_log (by linarith) hYs; linarith
  have hlY0 : 0 ≤ 1 + Real.log (Yp δ s : ℝ) := by have := Real.log_nonneg hYR; linarith
  -- term 1
  have t1 : 2 * (1 + Real.log (Yp δ s : ℝ)) / Real.sqrt s ≤ 2 * Λ ^ (-(100 : ℝ)) := by
    have hd := hd₁ Λ hΛb s hs0 hlog
    rw [pow_one] at hd
    have hsq : Real.sqrt s = (s : ℝ) ^ (1 / 2 : ℝ) := Real.sqrt_eq_rpow _
    have hpos : 0 < Real.sqrt s := Real.sqrt_pos.2 hs0
    rw [div_le_iff₀ hpos]
    have e : (1 + L) * (s : ℝ) ^ (-(1 / 2 : ℝ)) * Real.sqrt s = 1 + L := by
      rw [hsq, mul_assoc, ← Real.rpow_add hs0]; norm_num
    have : 2 * (1 + L) ≤ 2 * Λ ^ (-(100 : ℝ)) * Real.sqrt s := by
      have := mul_le_mul_of_nonneg_right hd hpos.le
      rw [e] at this; nlinarith
    linarith
  -- term 2
  have hβ : 6 ≤ (s : ℝ) ^ (3 / 4 + a0 δ / 2) := by
    calc (6 : ℝ) = (36 : ℝ) ^ (1 / 2 : ℝ) := by
          rw [show (36 : ℝ) = 6 ^ (2 : ℝ) by norm_num, ← Real.rpow_mul (by norm_num)]; norm_num
      _ ≤ (s : ℝ) ^ (1 / 2 : ℝ) := Real.rpow_le_rpow (by norm_num) hs36 (by norm_num)
      _ ≤ (s : ℝ) ^ (3 / 4 + a0 δ / 2) := Real.rpow_le_rpow_of_exponent_le hs1 (by linarith)
  have hdiv := LwW_div_Yp hδ0 hδ1 hs1n hβ
  set D := ((LwW δ s / Yp δ s : ℕ) : ℝ) with hD
  have hDpos : 0 < D := by
    have : (0 : ℝ) < (s : ℝ) ^ (3 / 4 + a0 δ / 2) / 2 := by positivity
    linarith
  have hinner : (s : ℝ) ^ ((3 : ℝ) / 4) / s + (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + L) / D ≤
      3 * (1 + L) * (s : ℝ) ^ (-(a0 δ / 2)) := by
    have e1 : (s : ℝ) ^ ((3 : ℝ) / 4) / s = (s : ℝ) ^ (-(1 / 4 : ℝ)) := by
      rw [div_eq_iff hs0.ne', ← Real.rpow_add_one hs0.ne']; norm_num
    have e2 : (s : ℝ) ^ (-(1 / 4 : ℝ)) ≤ (s : ℝ) ^ (-(a0 δ / 2)) :=
      Real.rpow_le_rpow_of_exponent_le hs1 (by linarith)
    have e3 : (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + L) / D ≤ 2 * (1 + L) * (s : ℝ) ^ (-(a0 δ / 2)) := by
      rw [div_le_iff₀ hDpos]
      have hk : (s : ℝ) ^ ((3 : ℝ) / 4) = (s : ℝ) ^ (-(a0 δ / 2)) * (s : ℝ) ^ (3 / 4 + a0 δ / 2) := by
        rw [← Real.rpow_add hs0]; ring_nf
      rw [hk]
      have hp : 0 ≤ (s : ℝ) ^ (-(a0 δ / 2)) := by positivity
      nlinarith [mul_le_mul_of_nonneg_left hdiv (by positivity : (0 : ℝ) ≤ 2 * (1 + L) * (s : ℝ) ^ (-(a0 δ / 2)))]
    have hp : 0 ≤ (s : ℝ) ^ (-(a0 δ / 2)) := by positivity
    rw [e1]; nlinarith
  have hsqrt : Real.sqrt ((s : ℝ) ^ ((3 : ℝ) / 4) / s + (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + L) / D) ≤
      2 * (1 + L) * (s : ℝ) ^ (-(a0 δ / 4)) := by
    rw [Real.sqrt_le_iff]
    refine ⟨by positivity, le_trans hinner ?_⟩
    have hk : ((s : ℝ) ^ (-(a0 δ / 4))) ^ 2 = (s : ℝ) ^ (-(a0 δ / 2)) := by
      rw [← Real.rpow_natCast, ← Real.rpow_mul hs0.le]; ring_nf
    rw [mul_pow, hk]
    have hp : 0 ≤ (s : ℝ) ^ (-(a0 δ / 2)) := by positivity
    have h3 : 3 * (1 + L) ≤ (2 * (1 + L)) ^ 2 := by nlinarith
    exact mul_le_mul_of_nonneg_right h3 hp
  have h8C : (8 : ℝ) ^ C.card ≤ (s : ℝ) ^ (a0 δ / 16) := h8 C hC hlogL₀
  have t2 : 2 * (1 + Real.log (Yp δ s : ℝ)) * (8 : ℝ) ^ C.card *
      Real.sqrt ((s : ℝ) ^ ((3 : ℝ) / 4) / s + (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + L) / D) ≤
      4 * Λ ^ (-(100 : ℝ)) := by
    have hd := hd₂ Λ hΛc s hs0 hlog
    calc 2 * (1 + Real.log (Yp δ s : ℝ)) * (8 : ℝ) ^ C.card *
          Real.sqrt ((s : ℝ) ^ ((3 : ℝ) / 4) / s + (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + L) / D)
        ≤ 2 * (1 + L) * (s : ℝ) ^ (a0 δ / 16) * (2 * (1 + L) * (s : ℝ) ^ (-(a0 δ / 4))) := by
          gcongr
      _ = 4 * ((1 + L) ^ 2 * (s : ℝ) ^ (-(3 * a0 δ / 16))) := by
          have : (s : ℝ) ^ (a0 δ / 16) * (s : ℝ) ^ (-(a0 δ / 4)) = (s : ℝ) ^ (-(3 * a0 δ / 16)) := by
            rw [← Real.rpow_add hs0]; ring_nf
          rw [← this]; ring
      _ ≤ 4 * Λ ^ (-(100 : ℝ)) := by linarith
  linarith

set_option maxHeartbeats 4000000 in
/-- Each `WTerm` is `≤ Λ^{−95}` eventually. -/
theorem W_term_ev4 (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (h H : ℕ), Λ₀ ≤ Real.log h → H ≤ h →
      ∀ (s M : ℕ) [NeZero s] [NeZero M],
      ∀ (C U : Finset ℕ), (∀ p ∈ C, p.Prime) → s = ∏ p ∈ C, p → M = 6 * q →
        4 * (Real.log h) ^ σ₀ ≤ Real.log (s : ℝ) → (s : ℝ) ≤ h →
        (∀ p ∈ U, p.Prime ∧ 5 ≤ p ∧ p ≤ H ^ 2) →
        ∀ (A : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s),
          (∀ ρ j, 1 ≤ j → ‖A ρ j‖ ≤ (300 * (q : ℝ) ^ 2) / j) →
          (∀ j, 1 ≤ j → C.filter (fun p => (ZMod.cast (c j) : ZMod p) = 0) = C.filter (fun p => p ∣ j)) →
          GoldC.QuillonWCellApp.WTerm C U (Icc 1 (6 * q * h)) A c (Xp h) (Yp δ s) (H ^ 2) (LwW δ s) ≤
            (Real.log h) ^ (-(95 : ℝ)) := by
  set Ab : ℝ := 300 * (q : ℝ) ^ 2 with hAb
  set E : ℝ := Real.exp 10 * (2 * 2 + 1) ^ 10 with hE
  set K1 : ℝ := 5 * (6 * q) * (6 * q * Ab) * 2 * 8 with hK1
  set K2 : ℝ := 6 * q * Ab * 2 * E * 12.5 with hK2
  obtain ⟨Λ₁, hΛ₁, hbr⟩ := W_bracket_ev4 δ hδ0 hδ1
  obtain ⟨Λ₂, hΛ₂, hAω⟩ := Aω_le 5 (1 / 2) (by norm_num) (by norm_num)
  obtain ⟨Λ₃, hΛ₃, hs36⟩ := s_large4 36
  obtain ⟨Λ₄, hΛ₄, hK1Λ⟩ := const_le_rpow K1 1 one_pos
  obtain ⟨Λ₅, hΛ₅, hK2Λ⟩ := const_le_rpow K2 1 one_pos
  set Λ₀ := max 2 (max Λ₁ (max Λ₂ (max Λ₃ (max Λ₄ (max Λ₅ (1 + Real.log (6 * q))))))) with hΛ₀
  refine ⟨Λ₀, le_max_left _ _, ?_⟩
  intro h H hΛ hHh s M _ _ C U hC hsC hM hlog hsh hU A c hA hc
  set Λ := Real.log h with hΛdef
  have hge : ∀ x, x ≤ Λ₀ → x ≤ Λ := fun x hx => le_trans hx hΛ
  have hΛ2 : 2 ≤ Λ := hge _ (le_max_left _ _)
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  have L1 := hge Λ₁ (by simp [hΛ₀])
  have L2 := hge Λ₂ (by simp [hΛ₀])
  have L3 := hge Λ₃ (by simp [hΛ₀])
  have L4 := hge Λ₄ (by simp [hΛ₀])
  have L5 := hge Λ₅ (by simp [hΛ₀])
  have L6 := hge (1 + Real.log (6 * q)) (by simp [hΛ₀])
  have hh1n : 1 ≤ h := by
    rcases Nat.eq_zero_or_pos h with h0 | h0
    · exfalso
      have : Real.log (h : ℝ) = 0 := by rw [h0]; simp
      linarith
    · exact h0
  have hh1 : (1 : ℝ) ≤ h := by exact_mod_cast hh1n
  have hh0 : (0 : ℝ) < h := by linarith
  have hspos : 0 < s := by rw [hsC]; exact prod_pos fun p hp => (hC p hp).pos
  have hs0 : (0 : ℝ) < s := by exact_mod_cast hspos
  have hs36' : (36 : ℝ) ≤ s := hs36 Λ L3 s hs0 hlog
  have hN := LwY_pos hδ0 hδ1 hs36'
  have hX2 : 2 ≤ Xp h := Xp_two hΛ2
  have hW := GoldC.QuillonWEst.WTerm_le (s := s) (M := M) C hC U (fun p hp => (hU p hp).2.1) (6 * q * h) A c Ab
    (by positivity) hA hc (Xp h) (Yp δ s) (H ^ 2) (LwW δ s) (by omega) hN
  refine le_trans hW ?_
  subst hM
  -- factor bounds
  have hmax : ((max (H ^ 2) (LwW δ s) : ℕ) : ℝ) ≤ (h : ℝ) ^ 2 := by
    have h1 : H ^ 2 ≤ h ^ 2 := Nat.pow_le_pow_left hHh 2
    have h2 : (LwW δ s : ℝ) ≤ h := le_trans (by exact_mod_cast LwW_le_self δ hδ0 s) hsh
    have h3 : (h : ℝ) ≤ (h : ℝ) ^ 2 := le_self_pow₀ hh1 (by norm_num)
    rcases le_total (H ^ 2) (LwW δ s) with hle | hle
    · rw [max_eq_right hle]; exact le_trans h2 h3
    · rw [max_eq_left hle]; exact_mod_cast h1
  have hmax0 : (0 : ℝ) < ((max (H ^ 2) (LwW δ s) : ℕ) : ℝ) := by
    have : 0 < LwW δ s := lt_of_lt_of_le (lt_of_lt_of_le Nat.zero_lt_one hN) (Nat.div_le_self _ _)
    exact_mod_cast lt_of_lt_of_le this (le_max_right _ _)
  have hlogmax : Real.log ((max (H ^ 2) (LwW δ s) : ℕ) : ℝ) ≤ 2 * Λ := by
    have := Real.log_le_log hmax0 hmax
    rwa [Real.log_pow, Nat.cast_ofNat] at this
  have b1 : (((Nat.log 2 (max (H ^ 2) (LwW δ s)) + 1 : ℕ)) : ℝ) ≤ 5 * Λ := by
    have := GoldC.QuillonLam.natlog_le_of _ _ hlogmax
    rw [max_eq_left (show (0 : ℝ) ≤ 2 * Λ by linarith)] at this
    push_cast; linarith
  have b2 : (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 * (max (H ^ 2) (LwW δ s)) ^ 2)) : ℝ) ^ 30) ^ 2
      ≤ Λ := by
    have hN2 : Real.log ((2 * (max (H ^ 2) (LwW δ s)) ^ 2 : ℕ) : ℝ) ≤ 5 * Λ := by
      rw [Nat.cast_mul, Nat.cast_pow, Nat.cast_ofNat, Real.log_mul (by norm_num) (by positivity),
        Real.log_pow]
      have : Real.log 2 < 1 := by have := Real.log_two_lt_d9; linarith
      have hl := hlogmax
      push_cast at hl ⊢; linarith
    have h1 := hAω Λ L2 _ hN2
    have h0 : 0 ≤ Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 * (max (H ^ 2) (LwW δ s)) ^ 2)) : ℝ) ^ 30 := by
      positivity
    calc _ ≤ (Λ ^ (1 / 2 : ℝ)) ^ 2 := pow_le_pow_left₀ h0 h1 2
      _ = Λ := by rw [← Real.rpow_natCast, ← Real.rpow_mul hΛ0.le]; norm_num
  have b3 : 1 + Real.log ((6 * q * h : ℕ) : ℝ) ≤ 2 * Λ := by
    push_cast
    rw [Real.log_mul (by positivity) hh0.ne']
    linarith
  have hXge := Xp_ge (h := h) hΛ1
  have hXpos : (0 : ℝ) < Xp h := by
    have : (0 : ℝ) < Λ ^ (200 : ℝ) := by positivity
    linarith
  have b4 : 2 / Real.sqrt (Xp h) ≤ 2 * Λ ^ (-(100 : ℝ)) := by
    have hsq : Λ ^ (100 : ℝ) ≤ Real.sqrt (Xp h) := by
      rw [Real.le_sqrt (by positivity) hXpos.le]
      calc (Λ ^ (100 : ℝ)) ^ 2 = Λ ^ (200 : ℝ) := by
            rw [← Real.rpow_natCast, ← Real.rpow_mul hΛ0.le]; norm_num
        _ ≤ Xp h := hXge
    have hp : 0 < Λ ^ (100 : ℝ) := by positivity
    rw [div_le_iff₀ (lt_of_lt_of_le hp hsq)]
    have e : Λ ^ (-(100 : ℝ)) * Λ ^ (100 : ℝ) = 1 := by
      rw [← Real.rpow_add hΛ0]; norm_num
    have hm : 0 ≤ Λ ^ (-(100 : ℝ)) := by positivity
    calc (2 : ℝ) = 2 * (Λ ^ (-(100 : ℝ)) * Λ ^ (100 : ℝ)) := by rw [e]; ring
      _ ≤ 2 * (Λ ^ (-(100 : ℝ)) * Real.sqrt (Xp h)) := by gcongr
      _ = 2 * Λ ^ (-(100 : ℝ)) * Real.sqrt (Xp h) := by ring
  have b5 := hbr Λ L1 C hC (by rw [← hsC]; exact hlog)
  rw [← hsC] at b5
  have b6 : ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) ≤ E * Λ ^ (10 : ℝ) := by
    have := prodU_le_pow U (fun p hp => ⟨(hU p hp).1, (hU p hp).2.1⟩) (h ^ 2)
      (fun p hp => le_trans (hU p hp).2.2 (Nat.pow_le_pow_left hHh 2)) 2 Λ (by norm_num) hΛ1
      (by push_cast; rw [Real.log_pow]; push_cast; linarith)
    exact this
  have b7 : (12.5 : ℝ) / Xp h ≤ 12.5 * Λ ^ (-(200 : ℝ)) := by
    rw [div_le_iff₀ hXpos]
    have e : Λ ^ (-(200 : ℝ)) * Λ ^ (200 : ℝ) = 1 := by
      rw [← Real.rpow_add hΛ0]; norm_num
    have hp : 0 ≤ Λ ^ (-(200 : ℝ)) := by positivity
    calc (12.5 : ℝ) = 12.5 * (Λ ^ (-(200 : ℝ)) * Λ ^ (200 : ℝ)) := by rw [e]; ring
      _ ≤ 12.5 * (Λ ^ (-(200 : ℝ)) * Xp h) := by gcongr
      _ = 12.5 * Λ ^ (-(200 : ℝ)) * Xp h := by ring
  have hbr0 : 0 ≤ 2 / Real.sqrt (Xp h) := by positivity
  have hlogJ0 : 0 ≤ 1 + Real.log ((6 * q * h : ℕ) : ℝ) := by
    have := Real.log_natCast_nonneg (6 * q * h); linarith
  have hU0 : 0 ≤ ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) := prod_nonneg fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast (hU p hp).2.1
    have : 0 ≤ 1 / ((p : ℝ) - 3) := div_nonneg zero_le_one (by linarith)
    linarith
  have hYge : 0 ≤ 1 + Real.log (Yp δ s : ℝ) := by
    have := Real.log_natCast_nonneg (Yp δ s); linarith
  have hbrk0 : 0 ≤ 2 / Real.sqrt (Xp h) + 2 * (1 + Real.log (Yp δ s : ℝ)) / Real.sqrt s +
          2 * (1 + Real.log (Yp δ s : ℝ)) * (8 : ℝ) ^ C.card *
            Real.sqrt ((s : ℝ) ^ ((3 : ℝ) / 4) / s + (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + Real.log s) /
              (LwW δ s / Yp δ s : ℕ)) := by positivity
  have hq0 : (0 : ℝ) < q := by exact_mod_cast hq
  have hAb0 : 0 ≤ Ab := by positivity
  have hF10 : (0 : ℝ) ≤ (((Nat.log 2 (max (H ^ 2) (LwW δ s)) + 1 : ℕ)) : ℝ) := by positivity
  have hAw0 : 0 ≤ (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 * (max (H ^ 2) (LwW δ s)) ^ 2)) : ℝ) ^ 30) ^ 2 :=
    by positivity
  have hXi0 : (0 : ℝ) ≤ 12.5 / Xp h := by positivity
  refine W_combine Λ _ _ Ab _ _ _ _ _ E hΛ2 (by positivity) hAb0 b1 hF10 b2 hAw0 b3 hlogJ0
    (by linarith) hbrk0 b6 hU0 b7 hXi0 ?_ ?_
  · have := hK1Λ Λ L4; rw [hK1] at this; push_cast; linarith
  · have := hK2Λ Λ L5; rw [hK2] at this; push_cast; linarith

open Classical in
set_option maxHeartbeats 4000000 in
/-- **The W′ cell for a fixed `C` is `≤ 4Λ^{−95}`**, eventually in `h`, uniformly in `a, d, C, Kc`. -/
theorem W_final_L (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (a h H D : ℕ) (T C : Finset ℕ) (Kc : ℕ → Prop) [DecidablePred Kc],
      Λ₀ ≤ Real.log h → 2 ≤ h → H ≤ h →
      (∀ p ∈ T, p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q ∧ p.Coprime H ∧ p ≤ H ^ 2) → C ⊆ T →
      |∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
          (if (Kc B.card ∧ GeoLL h H δ (∏ p ∈ B, p) (∏ p ∈ C, p)) ∧
              (B ∩ (T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ Yp δ (∏ p ∈ C, p))).Nonempty
            then GoldC.QuillonWContext.ωR B *
              GoldC.QuillonCopyF.foldRow q a D H (∏ p ∈ B, p) (∏ p ∈ C, p) else 0)| ≤
        4 * (Real.log h) ^ (-(95 : ℝ)) := by
  obtain ⟨Λ₁, hΛ₁, hWT⟩ := W_term_ev4 q hq δ hδ0 hδ1
  obtain ⟨Λ₂, hΛ₂, h36⟩ := s_large4 36
  refine ⟨max Λ₁ Λ₂, le_trans hΛ₁ (le_max_left _ _), ?_⟩
  intro a h H D T C Kc _ hΛ hh hHh hT hCT
  have hΛa : Λ₁ ≤ Real.log h := le_trans (le_max_left _ _) hΛ
  have hΛb : Λ₂ ≤ Real.log h := le_trans (le_max_right _ _) hΛ
  set s := ∏ p ∈ C, p with hs
  have hpos4 : 0 ≤ 4 * (Real.log h) ^ (-(95 : ℝ)) := by
    have : 0 ≤ Real.log h := Real.log_nonneg (by exact_mod_cast (by omega : 1 ≤ h))
    positivity
  -- empty case
  by_cases hex : ∃ r, GeoLL h H δ r s
  swap
  · push_neg at hex
    rw [sum_eq_zero fun B _ => by rw [if_neg]; rintro ⟨⟨-, hg⟩, -⟩; exact hex _ hg, abs_zero]
    exact hpos4
  obtain ⟨r₀, hr₀⟩ := hex
  obtain ⟨hlogs, -, -, hs1, -, hsh, -, -, -⟩ := admLL h H r₀ s δ hδ0 hh hHh hr₀
  have hCp : ∀ p ∈ C, p.Prime := fun p hp => (hT p (hCT hp)).1
  have hspos : 0 < s := prod_pos fun p hp => (hCp p hp).pos
  have hs0 : (0 : ℝ) < s := by exact_mod_cast hspos
  have hsR : (36 : ℝ) ≤ s := h36 _ hΛb s hs0 hlogs
  have hs2 : 2 ≤ s := by
    have : (2 : ℝ) ≤ s := by linarith
    exact_mod_cast this
  haveI : NeZero s := ⟨by omega⟩
  haveI : NeZero (6 * q) := ⟨by omega⟩
  have hTc : ∀ p ∈ T, p.Prime ∧ 5 ≤ p ∧ p.Coprime (6 * q) ∧ p.Coprime H := fun p hp =>
    ⟨(hT p hp).1, (hT p hp).2.1, coprime_6q (hT p hp).1 (hT p hp).2.1 (hT p hp).2.2.1, (hT p hp).2.2.2.1⟩
  have hsM : s.Coprime (6 * q) := prod_coprime_of fun p hp => (hTc p (hCT hp)).2.2.1
  set μ := GoldC.QuillonCopyF.meanWeight q (GoldC.QuillonCopyF.reducedAnchor q a D) H with hμ
  set Γ := GoldC.QuillonCopyF.gammaClass q a D H with hΓ
  have hμb : |μ| ≤ 4 := by
    have := GoldC.QuillonCopyF.meanWeight_bounds q (GoldC.QuillonCopyF.reducedAnchor q a D) H
    rw [abs_le]; constructor <;> linarith
  have hΓb : ∀ b ν, |Γ b ν| ≤ 48 * q := fun b ν => by
    have := GoldC.QuillonCopyF.abs_gammaClass_le q a D H b ν hq
    have e : (8 : ℝ) * (6 * q) = 48 * q := by ring
    linarith
  have hN := LwY_pos hδ0 hδ1 hsR
  have hY1 := Yp_pos hδ0 hδ1 hs1
  have hYL : Yp δ s ≤ LwW δ s := by
    have := (Nat.le_div_iff_mul_le hY1).1 hN
    omega
  have hX2 : 2 ≤ Xp h := Xp_two (le_trans hΛ₁ hΛa)
  have hshn : s ≤ h := by exact_mod_cast hsh
  have hcell := GoldC.QuillonWCellApp.W_cell (s := s) (M := 6 * q) (by omega) H μ Γ T C hTc hCT rfl hs2
    ((T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ Yp δ s)) (filter_subset _ _) (Xp h) (Yp δ s) hX2 hY1
    (fun p hp => (mem_filter.1 hp).2) Kc (fun r => GeoLL h H δ r s) (H ^ 2) (LwW δ s)
    (fun r hG => by
      have h4 := hG.2.1
      have : r ≤ r * s := Nat.le_mul_of_pos_right r hspos
      omega)
    (fun r hG => LwW_lt_LL hδ0 hG) hYL (geoLL_convex_r h H δ s)
    (fun r => GoldC.QuillonCopyF.foldRow q a D H r s)
    (fun B hB hne _ => by
      have hBp : ∀ p ∈ B, p.Prime ∧ 5 ≤ p := fun p hp =>
        ⟨(hT p (sdiff_subset (hB hp))).1, (hT p (sdiff_subset (hB hp))).2.1⟩
      obtain ⟨p, hp⟩ := nonempty_iff_ne_empty.2 hne
      have hr2 : 2 ≤ ∏ p ∈ B, p := by
        have h1 : p ∣ ∏ p ∈ B, p := dvd_prod_of_mem _ hp
        have h2 : 0 < ∏ p ∈ B, p := prod_pos fun p hp => (hBp p hp).1.pos
        have := Nat.le_of_dvd h2 h1
        have := (hBp p hp).2; omega
      exact GoldC.QuillonBridge.foldRow_eq_rowAbs q a D H _ s hq hr2 hs2
        (prod_coprime_of fun p hp => (hTc p (sdiff_subset (hB hp))).2.2.1) hsM)
    (6 * q * h) (by nlinarith)
  refine le_trans hcell ?_
  have hU : ∀ p ∈ T \ C, p.Prime ∧ 5 ≤ p ∧ p ≤ H ^ 2 := fun p hp =>
    ⟨(hT p (sdiff_subset hp)).1, (hT p (sdiff_subset hp)).2.1, (hT p (sdiff_subset hp)).2.2.2.2⟩
  have hCH : ∀ p ∈ C, p.Prime ∧ p.Coprime H := fun p hp => ⟨hCp p hp, (hT p (hCT hp)).2.2.2.1⟩
  have hs1' : 1 ≤ s := hs1
  have w1 := hWT h H hΛa hHh s (6 * q) C (T \ C) hCp rfl rfl hlogs hsh hU
    (fun (_ : ZMod (6 * q)) k => ((-(2 * μ) : ℝ) : ℂ) * GoldC.QuillonRowNF.αm k s)
    (fun k => ((((k : ℤ) * H : ℤ)) : ZMod s))
    (fun ρ j hj => GoldC.QuillonRowFacts.coef_main q hq μ hμb s hs1' (6 * q) ρ j hj)
    (GoldC.QuillonRowFacts.hc_gen C hCp rfl (H : ℤ) (GoldC.QuillonRowFacts.not_dvd_H hCH) 1 (Or.inl rfl) _
      (fun j => by congr 1; ring))
  have w2 := hWT h H hΛa hHh s (6 * q) C (T \ C) hCp rfl rfl hlogs hsh hU
    (fun (_ : ZMod (6 * q)) k => -(((-(2 * μ) : ℝ) : ℂ) * GoldC.QuillonRowNF.αm k s))
    (fun k => ((((-(k : ℤ)) * H : ℤ)) : ZMod s))
    (fun ρ j hj => GoldC.QuillonRowFacts.coef_mainN q hq μ hμb s hs1' (6 * q) ρ j hj)
    (GoldC.QuillonRowFacts.hc_gen C hCp rfl (H : ℤ) (GoldC.QuillonRowFacts.not_dvd_H hCH) (-1)
      (Or.inr rfl) _ (fun j => by congr 1; ring))
  have w3 := hWT h H hΛa hHh s (6 * q) C (T \ C) hCp rfl rfl hlogs hsh hU
    (fun (ρ : ZMod (6 * q)) k => GoldC.QuillonRowNF.αm k ((6 * q) * s) *
      GoldC.QuillonRowNF.BclS (6 * q) Γ s (k : ℤ) ρ)
    (fun k => ((((k : ℤ) * H * GoldC.QuillonCopyC.invMod (6 * q) s : ℤ)) : ZMod s))
    (fun ρ j hj => GoldC.QuillonRowFacts.coef_cls q hq Γ hΓb s hs1' (fun k => (k : ℤ)) ρ j hj)
    (GoldC.QuillonRowFacts.hc_gen C hCp rfl _
      (GoldC.QuillonRowFacts.not_dvd_HinvM hCH rfl hs2 hsM.symm) 1 (Or.inl rfl) _
      (fun j => by congr 1; ring))
  have w4 := hWT h H hΛa hHh s (6 * q) C (T \ C) hCp rfl rfl hlogs hsh hU
    (fun (ρ : ZMod (6 * q)) k => -(GoldC.QuillonRowNF.αm k ((6 * q) * s) *
      GoldC.QuillonRowNF.BclS (6 * q) Γ s (-(k : ℤ)) ρ))
    (fun k => ((((-(k : ℤ)) * H * GoldC.QuillonCopyC.invMod (6 * q) s : ℤ)) : ZMod s))
    (fun ρ j hj => GoldC.QuillonRowFacts.coef_clsN q hq Γ hΓb s hs1' (fun k => -(k : ℤ)) ρ j hj)
    (GoldC.QuillonRowFacts.hc_gen C hCp rfl _
      (GoldC.QuillonRowFacts.not_dvd_HinvM hCH rfl hs2 hsM.symm) (-1) (Or.inr rfl) _
      (fun j => by congr 1; ring))
  linarith

open GoldC.QuillonCopyS GoldC.QuillonCopyF GoldC.QuillonWPhysical GoldC.QuillonWContext

/-- The exact LONG pair mask (the `pairTerm` condition with `P = longEither δ`). -/
def MkL (Jlow Jhigh h H : ℕ) (δ : ℝ) (B C : Finset ℕ) : Prop :=
  originalZ h < primeSetProduct B * primeSetProduct C ∧
    4 * (primeSetProduct B * primeSetProduct C) ≤ H ^ 2 ∧
    Jlow ≤ B.card + C.card ∧ B.card + C.card < Jhigh ∧
    longEither δ (primeSetProduct B) (primeSetProduct C) ∧
    centralGate h H (primeSetProduct B) (primeSetProduct C)

open Classical in
/-- The LONG-left W′ part at decoration `d`: `s^{1+δ} < r` and `B` has a prime in `[X, ⌊s^{u₀}⌋]`. -/
noncomputable def WLPart (Jlow Jhigh q a h : ℕ) (δ : ℝ) (d : Finset ℕ) : ℝ :=
  ∑ B ∈ (Tsrc q h d).powerset, ∑ C ∈ (Tsrc q h d).powerset,
    if B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C ∧
        (MkL Jlow Jhigh h (h / primeSetProduct d) δ B C ∧
          (longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧ WMask h δ (Tsrc q h d) B C)) then
      omegaWeight B * omegaWeight C *
        foldRow q a (primeSetProduct d) (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct C)
    else 0

open Classical in
/-- **Physical LONG-left W′ theorem.** -/
theorem WL_physical (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (Jlow Jhigh a h : ℕ) (d : Finset ℕ), Λ₀ ≤ Real.log h → 2 ≤ h →
      |WLPart Jlow Jhigh q a h δ d| ≤ (Real.log h) ^ (-(80 : ℝ)) := by
  obtain ⟨Λ₁, hΛ₁, hW⟩ := W_final_L q hq δ hδ0 hδ1
  set K : ℝ := Real.exp 10 * (2 * 2 + 1) ^ 10 * 4 with hK
  obtain ⟨Λ₂, hΛ₂, hKΛ⟩ := GoldC.QuillonLam.const_le_rpow K 1 one_pos
  refine ⟨max Λ₁ Λ₂, le_trans hΛ₁ (le_max_left _ _), ?_⟩
  intro Jlow Jhigh a h d hΛ hh
  have hΛa : Λ₁ ≤ Real.log h := le_trans (le_max_left _ _) hΛ
  have hΛb : Λ₂ ≤ Real.log h := le_trans (le_max_right _ _) hΛ
  set Λ := Real.log h with hΛdef
  have hΛ2 : 2 ≤ Λ := le_trans hΛ₁ hΛa
  have hΛ0 : 0 < Λ := by linarith
  set H := h / primeSetProduct d with hH
  set T := Tsrc q h d with hT
  have hTf := Tsrc_facts q h d
  have hHh : H ≤ h := Nat.div_le_self _ _
  unfold WLPart
  rw [GoldC.QuillonCells.double_sum_fixC]
  -- per-`C` bound
  have hinner : ∀ C ∈ T.powerset.filter (fun C => C ≠ ∅),
      |∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
        (if MkL Jlow Jhigh h H δ B C ∧ (longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧ WMask h δ T B C) then
          omegaWeight B * omegaWeight C *
            foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0)| ≤
        ωR C * (4 * Λ ^ (-(95 : ℝ))) := by
    intro C hC
    have hCT : C ⊆ T := mem_powerset.1 (mem_filter.1 hC).1
    have hω0 : 0 ≤ ωR C := ωR_nonneg C fun p hp => (hTf p (hCT hp)).2.1
    have key := hW a h H (primeSetProduct d) T C
      (fun k => Jlow ≤ k + C.card ∧ k + C.card < Jhigh) hΛa hh hHh hTf hCT
    have e : ∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
        (if MkL Jlow Jhigh h H δ B C ∧ (longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧ WMask h δ T B C) then
          omegaWeight B * omegaWeight C *
            foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0) =
        ωR C * ∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
          (if ((Jlow ≤ B.card + C.card ∧ B.card + C.card < Jhigh) ∧
              GeoLL h H δ (∏ p ∈ B, p) (∏ p ∈ C, p)) ∧
              (B ∩ (T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ Yp δ (∏ p ∈ C, p))).Nonempty
            then ωR B * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p) else 0) := by
      rw [mul_sum]
      refine sum_congr rfl fun B _ => ?_
      have hiff : (MkL Jlow Jhigh h H δ B C ∧ (longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧ WMask h δ T B C)) ↔
          (((Jlow ≤ B.card + C.card ∧ B.card + C.card < Jhigh) ∧
              GeoLL h H δ (∏ p ∈ B, p) (∏ p ∈ C, p)) ∧
              (B ∩ (T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ Yp δ (∏ p ∈ C, p))).Nonempty) := by
        constructor
        · rintro ⟨⟨h1, h2, h3, h4, -, h6⟩, hL, hw⟩; exact ⟨⟨⟨h3, h4⟩, h1, h2, hL, h6⟩, hw⟩
        · rintro ⟨⟨⟨h3, h4⟩, h1, h2, hL, h6⟩, hw⟩; exact ⟨⟨h1, h2, h3, h4, Or.inl hL, h6⟩, hL, hw⟩
      split_ifs with h1 h2 h2
      · show ωR B * ωR C * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p) =
          ωR C * (ωR B * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p))
        ring
      · exact absurd (hiff.1 h1) h2
      · exact absurd (hiff.2 h2) h1
      · rw [mul_zero]
    rw [e, abs_mul, abs_of_nonneg hω0]
    exact mul_le_mul_of_nonneg_left key hω0
  calc _ ≤ ∑ C ∈ T.powerset.filter (fun C => C ≠ ∅),
        |∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
          (if MkL Jlow Jhigh h H δ B C ∧ (longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧ WMask h δ T B C) then
            omegaWeight B * omegaWeight C *
              foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0)| :=
        abs_sum_le_sum_abs _ _
    _ ≤ ∑ C ∈ T.powerset.filter (fun C => C ≠ ∅), ωR C * (4 * Λ ^ (-(95 : ℝ))) := sum_le_sum hinner
    _ ≤ ∑ C ∈ T.powerset, ωR C * (4 * Λ ^ (-(95 : ℝ))) := by
        apply sum_le_sum_of_subset_of_nonneg (filter_subset _ _)
        intro C hC _
        have hCT : C ⊆ T := mem_powerset.1 hC
        have := ωR_nonneg C fun p hp => (hTf p (hCT hp)).2.1
        positivity
    _ = (∑ C ∈ T.powerset, ωR C) * (4 * Λ ^ (-(95 : ℝ))) := by rw [sum_mul]
    _ ≤ (Real.exp 10 * (2 * 2 + 1) ^ 10 * Λ ^ (10 : ℝ)) * (4 * Λ ^ (-(95 : ℝ))) :=
        mul_le_mul_of_nonneg_right (outer_mass q h d (by linarith)) (by positivity)
    _ = K * Λ ^ (-(85 : ℝ)) := by
        rw [hK, show Λ ^ (-(85 : ℝ)) = Λ ^ (10 : ℝ) * Λ ^ (-(95 : ℝ)) by
          rw [← Real.rpow_add hΛ0]; norm_num]
        ring
    _ ≤ Λ ^ (1 : ℝ) * Λ ^ (-(85 : ℝ)) := mul_le_mul_of_nonneg_right (hKΛ Λ hΛb) (by positivity)
    _ = Λ ^ (-(84 : ℝ)) := by rw [← Real.rpow_add hΛ0]; norm_num
    _ ≤ Λ ^ (-(80 : ℝ)) := Real.rpow_le_rpow_of_exponent_le (by linarith) (by norm_num)

end GoldC.QuillonLW

#print axioms GoldC.QuillonLW.W_final_L
#print axioms GoldC.QuillonLW.WL_physical
