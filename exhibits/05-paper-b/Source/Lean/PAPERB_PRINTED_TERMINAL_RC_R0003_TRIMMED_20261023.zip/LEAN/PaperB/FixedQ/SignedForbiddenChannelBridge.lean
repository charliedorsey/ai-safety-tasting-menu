import PaperB.FixedQ.SignedForbiddenNaturalBridge
import PaperB.FixedQ.H2BooleanPeriodicWeightedET
import PaperB.FixedQ.H2BooleanAffineET
import PaperB.FixedQ.H2PeriodicTwistCoherence
import PaperB.FixedQ.H2BooleanFourierBlock

open scoped BigOperators

namespace PaperB.FixedQ

lemma sourceForbiddenNatural_support_active
    {q H D m : ℕ}
    (hsq : Squarefree m)
    (hcop : m.Coprime (H * (6 * q) * D)) :
    (∀ p ∈ m.primeFactors, activeHighPrime q p) ∧
      m.primeFactors ∈ ordinaryTwoDimensionalSet H := by
  have hPrime : ∀ p ∈ m.primeFactors, p.Prime := by
    intro p hp
    exact (Nat.mem_primeFactors.mp hp).1
  have hmH : m.Coprime H := by
    exact (Nat.coprime_mul_iff_right.mp
      (Nat.coprime_mul_iff_right.mp hcop).1).1
  have hm6q : m.Coprime (6 * q) := by
    exact (Nat.coprime_mul_iff_right.mp
      (Nat.coprime_mul_iff_right.mp hcop).1).2
  have hAct : ∀ p ∈ m.primeFactors, activeHighPrime q p := by
    intro p hp
    have hpPrime := hPrime p hp
    have hpDiv : p ∣ m := (Nat.mem_primeFactors.mp hp).2.1
    have hpCop6q : p.Coprime (6 * q) :=
      Nat.Coprime.of_dvd_left hpDiv hm6q
    exact ⟨hpPrime,
      prime_ge_five_of_coprime_six hpPrime hpCop6q,
      fun hpq =>
        (hpPrime.coprime_iff_not_dvd.mp hpCop6q)
          (dvd_mul_of_dvd_right hpq 6)⟩
  have hpfProd : primeSetProduct m.primeFactors = m :=
    Nat.prod_primeFactors_of_squarefree hsq
  have hOrd : m.primeFactors ∈ ordinaryTwoDimensionalSet H := by
    rw [ordinary_primeSetProduct_coprime_height_iff hPrime]
    simpa [hpfProd] using hmH
  exact ⟨hAct, hOrd⟩

theorem sourceForbiddenBooleanNaturalTerm_eq_weighted_interval
    {q a H D m : ℕ}
    (hgt : 1 < m)
    (hsq : Squarefree m)
    (hcop : m.Coprime (H * (6 * q) * D)) :
    sourceForbiddenBooleanNaturalTerm q a H D m =
      fixedQShiuWeight q m *
        fixedQWeightedBooleanIntervalDiscrepancy
          q a H m.primeFactors := by
  have hPrime : ∀ p ∈ m.primeFactors, p.Prime := by
    intro p hp
    exact (Nat.mem_primeFactors.mp hp).1
  rw [sourceForbiddenBooleanNaturalTerm, if_pos ⟨hgt, hsq, hcop⟩]
  rw [fixedProductBooleanDiscrepancy_eq_fixedQWeightedBooleanIntervalDiscrepancy
    hPrime]

theorem sourceForbiddenBooleanNaturalTerm_eq_periodic_affine_sum
    {q a H D m : ℕ}
    (hq : 0 < q)
    (hgt : 1 < m)
    (hsq : Squarefree m)
    (hcop : m.Coprime (H * (6 * q) * D))
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H) :
    let hActive : ∀ p ∈ m.primeFactors, activeHighPrime q p :=
      (sourceForbiddenNatural_support_active hsq hcop).1
    let hOrd : m.primeFactors ∈ ordinaryTwoDimensionalSet H :=
      (sourceForbiddenNatural_support_active hsq hcop).2
    sourceForbiddenBooleanNaturalTerm q a H D m =
      fixedQShiuWeight q m *
        ∑ c : Fin (fixedQPeriod q),
          occupiedFixedQLowWeight q a H (c.1 + 1) *
            fixedProductBooleanAffineRootIntervalDiscrepancy
              m.primeFactors
              (fun p hp => (hActive p hp).1)
              (fixedProductBooleanPeriodicTwist
                (fixedQPeriod q) H m.primeFactors
                (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
                ((ordinary_primeSetProduct_coprime_height_iff
                  (fun p hp => (hActive p hp).1)).mp hOrd).symm)
              (fixedProductBooleanPeriodicShift
                (fixedQPeriod q) m.primeFactors
                (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm c.1)
              (periodicResidueLength (fixedQPeriod q) H c.1 %
                primeSetProduct m.primeFactors) := by
  dsimp only
  have hsupport := sourceForbiddenNatural_support_active hsq hcop
  let hActive : ∀ p ∈ m.primeFactors, activeHighPrime q p := hsupport.1
  let hOrd : m.primeFactors ∈ ordinaryTwoDimensionalSet H := hsupport.2
  rw [sourceForbiddenBooleanNaturalTerm_eq_weighted_interval hgt hsq hcop]
  rw [fixedQWeightedBooleanIntervalDiscrepancy_eq_periodic_affine_sum
    hq hActive hOrd h2admissible]

lemma fixedProductCRTIdempotent_block_image
    {S A : Finset ℕ} (hA : A ⊆ S)
    (hPrime : ∀ p ∈ S, p.Prime) :
    let R := S \ A
    let hdisj : Disjoint A R := Finset.disjoint_sdiff
    let hPrimeA : ∀ p ∈ A, p.Prime := fun p hp => hPrime p (hA hp)
    let hPrimeR : ∀ p ∈ R, p.Prime :=
      fun p hp => hPrime p (Finset.mem_sdiff.mp hp).1
    h2BooleanBlockCRTEquiv A R hdisj hPrimeA hPrimeR
      (fixedProductCRTIdempotentNat S A :
        ZMod (primeSetProduct (A ∪ R))) = (0, 1) := by
  dsimp
  let R := S \ A
  let hdisj : Disjoint A R := Finset.disjoint_sdiff
  let hPrimeA : ∀ p ∈ A, p.Prime := fun p hp => hPrime p (hA hp)
  let hPrimeR : ∀ p ∈ R, p.Prime :=
    fun p hp => hPrime p (Finset.mem_sdiff.mp hp).1
  rw [h2BooleanBlockCRTEquiv_apply_natCast]
  apply Prod.ext
  · have hs := (fixedProductCRTIdempotentNat_specs hA hPrime).1
    simpa using
      ((ZMod.natCast_eq_natCast_iff
        (fixedProductCRTIdempotentNat S A) 0 (primeSetProduct A)).2
        (by simpa using hs))
  · have hs := (fixedProductCRTIdempotentNat_specs hA hPrime).2
    simpa using
      ((ZMod.natCast_eq_natCast_iff
        (fixedProductCRTIdempotentNat S A) 1 (primeSetProduct R)).2
        (by simpa [R] using hs))

lemma fixedProductCRTIdempotent_addChar_eq_rightBlock
    {S A : Finset ℕ} (hA : A ⊆ S)
    (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct A)]
    [NeZero (primeSetProduct (S \ A))]
    [NeZero (primeSetProduct (A ∪ (S \ A)))]
    (t : ZMod (primeSetProduct (A ∪ (S \ A)))) :
    let R := S \ A
    let hdisj : Disjoint A R := Finset.disjoint_sdiff
    let hPrimeA : ∀ p ∈ A, p.Prime := fun p hp => hPrime p (hA hp)
    let hPrimeR : ∀ p ∈ R, p.Prime :=
      fun p hp => hPrime p (Finset.mem_sdiff.mp hp).1
    ZMod.stdAddChar
      (t * (fixedProductCRTIdempotentNat S A :
        ZMod (primeSetProduct (A ∪ R)))) =
      ZMod.stdAddChar
        (h2BooleanBlockRightFrequency A R hdisj hPrimeA hPrimeR t) := by
  dsimp
  let R := S \ A
  let hdisj : Disjoint A R := Finset.disjoint_sdiff
  let hPrimeA : ∀ p ∈ A, p.Prime := fun p hp => hPrime p (hA hp)
  let hPrimeR : ∀ p ∈ R, p.Prime :=
    fun p hp => hPrime p (Finset.mem_sdiff.mp hp).1
  let E : ZMod (primeSetProduct (A ∪ R)) :=
    (fixedProductCRTIdempotentNat S A : ZMod (primeSetProduct (A ∪ R)))
  have hE := fixedProductCRTIdempotent_block_image hA hPrime
  have hmap :
      h2BooleanBlockCRTEquiv A R hdisj hPrimeA hPrimeR (t * E) =
        ((h2BooleanBlockCRTEquiv A R hdisj hPrimeA hPrimeR t).1 * 0,
         (h2BooleanBlockCRTEquiv A R hdisj hPrimeA hPrimeR t).2 * 1) := by
    rw [map_mul, hE]
    apply Prod.ext <;> simp
  have hchar := h2_stdAddChar_eq_block_mul
    A R hdisj hPrimeA hPrimeR (t * E)
  rw [hmap] at hchar
  simp only [Prod.fst, Prod.snd, mul_zero, mul_one] at hchar
  have hzero :
      ZMod.stdAddChar (0 : ZMod (primeSetProduct A)) = 1 :=
    (ZMod.stdAddChar (N := primeSetProduct A)).map_zero_eq_one
  rw [hzero, one_mul] at hchar
  simpa [h2BooleanBlockRightFrequency, E] using hchar

lemma h2_crtRightCoeff_mul_eq_one
    {m n : ℕ} [NeZero n] (hcop : m.Coprime n) :
    (((crtRightCoeff m n : ℤ) : ZMod n) * (m : ZMod n)) = 1 := by
  have hbez := crt_bezout hcop
  have hcast := congrArg (fun z : ℤ => (z : ZMod n)) hbez
  simpa [add_comm, mul_comm, mul_left_comm, mul_assoc] using hcast

lemma h2_crtRightCoeff_eq_unit_inv
    {m n : ℕ} [NeZero n] (hcop : m.Coprime n) :
    ((crtRightCoeff m n : ℤ) : ZMod n) =
      (((ZMod.unitOfCoprime m hcop)⁻¹ : (ZMod n)ˣ) : ZMod n) := by
  let u : (ZMod n)ˣ := ZMod.unitOfCoprime m hcop
  have hu : (u : ZMod n) = (m : ZMod n) := by
    exact ZMod.coe_unitOfCoprime m hcop
  have hmul :
      (u : ZMod n) * ((crtRightCoeff m n : ℤ) : ZMod n) = 1 := by
    rw [hu, mul_comm]
    exact h2_crtRightCoeff_mul_eq_one hcop
  calc
    ((crtRightCoeff m n : ℤ) : ZMod n)
        = 1 * ((crtRightCoeff m n : ℤ) : ZMod n) := by simp
    _ = (((u⁻¹ : (ZMod n)ˣ) : ZMod n) * (u : ZMod n)) *
          ((crtRightCoeff m n : ℤ) : ZMod n) := by simp
    _ = (((u⁻¹ : (ZMod n)ˣ) : ZMod n) *
          ((u : ZMod n) * ((crtRightCoeff m n : ℤ) : ZMod n))) := by ring
    _ = (((u⁻¹ : (ZMod n)ˣ) : ZMod n) * 1) := by rw [hmul]
    _ = (((u⁻¹ : (ZMod n)ˣ) : ZMod n)) := by simp

lemma h2BooleanBlockCRTEquiv_snd_eq_zmodUnitProject_val
    (T R : Finset ℕ) (hdisj : Disjoint T R)
    (hPrimeT : ∀ p ∈ T, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (u : (ZMod (primeSetProduct (T ∪ R)))ˣ) :
    (h2BooleanBlockCRTEquiv T R hdisj hPrimeT hPrimeR
      (u : ZMod (primeSetProduct (T ∪ R)))).2 =
      ((zmodUnitProject
        (primeSetProduct_dvd_of_subset
          (Finset.subset_union_right : R ⊆ T ∪ R)) u :
        (ZMod (primeSetProduct R))ˣ) : ZMod (primeSetProduct R)) := by
  let hPrimeU : ∀ p ∈ T ∪ R, p.Prime := by
    intro p hp
    rcases Finset.mem_union.mp hp with hpT | hpR
    · exact hPrimeT p hpT
    · exact hPrimeR p hpR
  letI : NeZero (primeSetProduct (T ∪ R)) :=
    ⟨(primeSetProduct_pos hPrimeU).ne'⟩
  letI : NeZero (primeSetProduct R) :=
    ⟨(primeSetProduct_pos hPrimeR).ne'⟩
  conv_lhs =>
    rw [← ZMod.natCast_zmod_val
      (u : ZMod (primeSetProduct (T ∪ R)))]
  rw [h2BooleanBlockCRTEquiv_apply_natCast]
  change
    ((u : ZMod (primeSetProduct (T ∪ R))).val : ZMod (primeSetProduct R)) =
      ZMod.castHom
        (primeSetProduct_dvd_of_subset
          (Finset.subset_union_right : R ⊆ T ∪ R))
        (ZMod (primeSetProduct R))
        (u : ZMod (primeSetProduct (T ∪ R)))
  rw [ZMod.castHom_apply, ZMod.cast_eq_val]

lemma h2BooleanBlockRightFrequency_natCast_mul_unit_eq_project
    (T R : Finset ℕ) (hdisj : Disjoint T R)
    (hPrimeT : ∀ p ∈ T, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (j : ℕ) (u : (ZMod (primeSetProduct (T ∪ R)))ˣ) :
    h2BooleanBlockRightFrequency T R hdisj hPrimeT hPrimeR
        ((j : ZMod (primeSetProduct (T ∪ R))) *
          (u : ZMod (primeSetProduct (T ∪ R)))) =
      ((j : ZMod (primeSetProduct R)) *
        ((zmodUnitProject
          (primeSetProduct_dvd_of_subset
            (Finset.subset_union_right : R ⊆ T ∪ R)) u :
          (ZMod (primeSetProduct R))ˣ) :
            ZMod (primeSetProduct R))) *
        (((ZMod.unitOfCoprime (primeSetProduct T)
          (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR))⁻¹ :
            (ZMod (primeSetProduct R))ˣ) :
              ZMod (primeSetProduct R)) := by
  letI : NeZero (primeSetProduct R) :=
    ⟨(primeSetProduct_pos hPrimeR).ne'⟩
  unfold h2BooleanBlockRightFrequency
  rw [map_mul]
  rw [h2BooleanBlockCRTEquiv_apply_natCast]
  simp only [Prod.snd_mul, Prod.snd]
  rw [h2_crtRightCoeff_eq_unit_inv
    (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR)]
  rw [h2BooleanBlockCRTEquiv_snd_eq_zmodUnitProject_val]
  ring

theorem fixedQPeriodic_rightBlockFrequency_eq
    {q H j : ℕ} {T R : Finset ℕ}
    (hdisj : Disjoint T R)
    (hActive : ∀ p ∈ T ∪ R, activeHighPrime q p) :
    h2BooleanBlockRightFrequency T R hdisj
        (fun p hp => (hActive p (Finset.mem_union_left R hp)).1)
        (fun p hp => (hActive p (Finset.mem_union_right T hp)).1)
        ((j : ZMod (primeSetProduct (T ∪ R))) *
          (fixedQPeriodicTotalTwist q H (T ∪ R) :
            ZMod (primeSetProduct (T ∪ R)))) =
      ((j : ZMod (primeSetProduct R)) *
        (fixedQPeriodicTotalTwist q H R :
          ZMod (primeSetProduct R))) *
        (((ZMod.unitOfCoprime (primeSetProduct T)
          (h2_primeSetProduct_coprime hdisj
            (fun p hp => (hActive p (Finset.mem_union_left R hp)).1)
            (fun p hp => (hActive p (Finset.mem_union_right T hp)).1)))⁻¹ :
            (ZMod (primeSetProduct R))ˣ) :
              ZMod (primeSetProduct R)) := by
  let hPrimeT : ∀ p ∈ T, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_left R hp)).1
  let hPrimeR : ∀ p ∈ R, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_right T hp)).1
  have hfreq :=
    h2BooleanBlockRightFrequency_natCast_mul_unit_eq_project
      T R hdisj hPrimeT hPrimeR j
      (fixedQPeriodicTotalTwist q H (T ∪ R))
  have hproj :
      zmodUnitProject
        (primeSetProduct_dvd_of_subset
          (Finset.subset_union_right : R ⊆ T ∪ R))
        (fixedQPeriodicTotalTwist q H (T ∪ R)) =
      fixedQPeriodicTotalTwist q H R :=
    fixedQPeriodicTotalTwist_project
      (Finset.subset_union_right : R ⊆ T ∪ R) hActive
  rw [hproj] at hfreq
  exact hfreq

theorem fixedQPeriodic_rightBlockFrequency_eq_source
    {q H j : ℕ} {T R : Finset ℕ}
    (hdisj : Disjoint T R)
    (hActive : ∀ p ∈ T ∪ R, activeHighPrime q p)
    (hOrdR : R ∈ ordinaryTwoDimensionalSet H) :
    let hPrimeT : ∀ p ∈ T, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_left R hp)).1
    let hPrimeR : ∀ p ∈ R, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_right T hp)).1
    let hPcop :
      (fixedQPeriod q).Coprime (primeSetProduct R) :=
      (activePrimeSetProduct_coprime_fixedQPeriod
        (fun p hp => hActive p (Finset.mem_union_right T hp))).symm
    let hHcop :
      H.Coprime (primeSetProduct R) :=
      ((ordinary_primeSetProduct_coprime_height_iff hPrimeR).mp hOrdR).symm
    h2BooleanBlockRightFrequency T R hdisj hPrimeT hPrimeR
        ((j : ZMod (primeSetProduct (T ∪ R))) *
          (fixedQPeriodicTotalTwist q H (T ∪ R) :
            ZMod (primeSetProduct (T ∪ R)))) =
      ((j : ZMod (primeSetProduct R)) *
        (fixedProductBooleanPeriodicTwist
          (fixedQPeriod q) H R hPcop hHcop :
            ZMod (primeSetProduct R))) *
        (((ZMod.unitOfCoprime (primeSetProduct T)
          (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR))⁻¹ :
            (ZMod (primeSetProduct R))ˣ) :
              ZMod (primeSetProduct R)) := by
  dsimp only
  rw [fixedQPeriodic_rightBlockFrequency_eq hdisj hActive]
  rw [fixedQPeriodicTotalTwist_eq_periodic
    (fun p hp => hActive p (Finset.mem_union_right T hp)) hOrdR]

theorem fixedQShiuWeight_mul_booleanFourierCoeff_eq_omega_phase_sum
    {q m : ℕ}
    [NeZero (primeSetProduct m.primeFactors)]
    (hm0 : m ≠ 0)
    (hsq : Squarefree m)
    (hcop : m.Coprime (6 * q))
    (t : ZMod (primeSetProduct m.primeFactors)) :
    ((fixedQShiuWeight q m : ℝ) : ℂ) *
        fixedProductBooleanFourierCoeff m.primeFactors
          (fun p hp => (Nat.mem_primeFactors.mp hp).1) t =
      (omegaCoeff q m : ℂ) *
        ∑ A ∈ m.primeFactors.powerset,
          ZMod.stdAddChar
            (t * (fixedProductCRTIdempotentNat m.primeFactors A :
              ZMod (primeSetProduct m.primeFactors))) := by
  have hPrime : ∀ p ∈ m.primeFactors, p.Prime := by
    intro p hp
    exact (Nat.mem_primeFactors.mp hp).1
  have hAct : ∀ p ∈ m.primeFactors, activeHighPrime q p := by
    intro p hp
    have hpPrime := hPrime p hp
    have hpDiv : p ∣ m := (Nat.mem_primeFactors.mp hp).2.1
    have hpCop : p.Coprime (6 * q) :=
      Nat.Coprime.of_dvd_left hpDiv hcop
    exact ⟨hpPrime,
      prime_ge_five_of_coprime_six hpPrime hpCop,
      fun hpq =>
        (hpPrime.coprime_iff_not_dvd.mp hpCop)
          (dvd_mul_of_dvd_right hpq 6)⟩
  have hprod : primeSetProduct m.primeFactors = m :=
    Nat.prod_primeFactors_of_squarefree hsq
  letI : NeZero (primeSetProduct m.primeFactors) :=
    ⟨by rw [hprod]; exact hm0⟩
  have hshiu :
      fixedQShiuWeight q m =
        (2 : ℝ) ^ m.primeFactors.card *
          finiteOmegaWeightReal m.primeFactors := by
    calc
      fixedQShiuWeight q m =
          fixedQShiuWeight q (primeSetProduct m.primeFactors) := by rw [hprod]
      _ = _ :=
        fixedQShiuWeight_primeSetProduct_eq_card_mul_finiteOmegaWeightReal hAct
  have homega :
      omegaCoeff q m = finiteOmegaWeightReal m.primeFactors :=
    omegaCoeff_eq_finiteOmegaWeightReal hm0 hsq hcop
  rw [hshiu, homega]
  unfold fixedProductBooleanFourierCoeff
  have hpow : ((2 : ℂ) ^ m.primeFactors.card) ≠ 0 := by
    exact pow_ne_zero _ (by norm_num)
  push_cast
  field_simp [hpow]

#print axioms fixedQShiuWeight_mul_booleanFourierCoeff_eq_omega_phase_sum

#print axioms fixedQPeriodic_rightBlockFrequency_eq
#print axioms fixedQPeriodic_rightBlockFrequency_eq_source

#print axioms h2_crtRightCoeff_eq_unit_inv
#print axioms h2BooleanBlockCRTEquiv_snd_eq_zmodUnitProject_val
#print axioms h2BooleanBlockRightFrequency_natCast_mul_unit_eq_project

#print axioms sourceForbiddenNatural_support_active
#print axioms sourceForbiddenBooleanNaturalTerm_eq_weighted_interval
#print axioms sourceForbiddenBooleanNaturalTerm_eq_periodic_affine_sum
#print axioms fixedProductCRTIdempotent_block_image
#print axioms fixedProductCRTIdempotent_addChar_eq_rightBlock

end PaperB.FixedQ
