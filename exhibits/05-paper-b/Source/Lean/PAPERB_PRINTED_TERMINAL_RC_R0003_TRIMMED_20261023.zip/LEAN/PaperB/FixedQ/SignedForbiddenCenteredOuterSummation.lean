import PaperB.FixedQ.SignedForbiddenCompletionBridge

open scoped BigOperators

namespace PaperB.FixedQ

theorem source_abs_sum_gammaChannels_uniform_forbidden
    {q : ℕ} (S Rset : Finset ℕ)
    (hSact : ∀ p ∈ S, activeHighPrime q p)
    (hRact : ∀ p ∈ Rset, activeHighPrime q p)
    (hdis : Disjoint S Rset)
    (channel : Finset ℕ → ℕ → ℝ)
    {K : ℝ} (hK : 0 ≤ K)
    (hchan : ∀ s ∈ S.powerset,
      ∀ c ∈ (primeSetProduct s * primeSetProduct Rset).divisors,
        |channel s c| ≤
          K * (∏ p ∈ s, gammaPrimeTerm p) *
            invSqrtNat (primeSetProduct Rset) * invSqrtNat c) :
    |∑ s ∈ S.powerset,
      ∑ c ∈ (primeSetProduct s * primeSetProduct Rset).divisors,
        channel s c| ≤
      K * Real.exp (∑' n : ℕ, sourceEnhancedGammaPrimeTerm n) := by
  calc
    |∑ s ∈ S.powerset,
      ∑ c ∈ (primeSetProduct s * primeSetProduct Rset).divisors,
        channel s c|
      ≤ ∑ s ∈ S.powerset,
          |∑ c ∈ (primeSetProduct s * primeSetProduct Rset).divisors,
            channel s c| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ s ∈ S.powerset,
          ∑ c ∈ (primeSetProduct s * primeSetProduct Rset).divisors,
            |channel s c| := by
          apply Finset.sum_le_sum
          intro s hs
          exact Finset.abs_sum_le_sum_abs _ _
    _ ≤ K * Real.exp (∑' n : ℕ, sourceEnhancedGammaPrimeTerm n) :=
      source_sum_gammaChannels_uniform_forbidden
        S Rset hSact hRact hdis
        (fun s c => |channel s c|) hK hchan

theorem source_abs_sum_im_gammaChannels_uniform_forbidden
    {q : ℕ} (S Rset : Finset ℕ)
    (hSact : ∀ p ∈ S, activeHighPrime q p)
    (hRact : ∀ p ∈ Rset, activeHighPrime q p)
    (hdis : Disjoint S Rset)
    (channel : Finset ℕ → ℕ → ℂ)
    {K : ℝ} (hK : 0 ≤ K)
    (hchan : ∀ s ∈ S.powerset,
      ∀ c ∈ (primeSetProduct s * primeSetProduct Rset).divisors,
        ‖channel s c‖ ≤
          K * (∏ p ∈ s, gammaPrimeTerm p) *
            invSqrtNat (primeSetProduct Rset) * invSqrtNat c) :
    |∑ s ∈ S.powerset,
      ∑ c ∈ (primeSetProduct s * primeSetProduct Rset).divisors,
        (channel s c).im| ≤
      K * Real.exp (∑' n : ℕ, sourceEnhancedGammaPrimeTerm n) := by
  apply source_abs_sum_gammaChannels_uniform_forbidden
    S Rset hSact hRact hdis
    (fun s c => (channel s c).im) hK
  intro s hs c hc
  exact (Complex.abs_im_le_norm (channel s c)).trans (hchan s hs c hc)

#print axioms source_abs_sum_gammaChannels_uniform_forbidden
#print axioms source_abs_sum_im_gammaChannels_uniform_forbidden

end PaperB.FixedQ
