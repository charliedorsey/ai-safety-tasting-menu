import GoldC.QuillonVWExplicit
import GoldC.QuillonCContext2
import GoldC.QuillonWCellApp

/-!
# Quillon CSC3 F7.7e: region C for a fixed `s` (P-W + VW + Rankin), explicit

* `VW_m0`: the VW prime sum for one small cofactor `m₀`, restricted to the primes
  `p ∈ (I₀/m₀, I₁/m₀]` that the mask allows.
  - The ratio `P₁/P₀` stays bounded, so the prime-power correction `√P₁/(P₀ log P₀)` saves.
  - The Λ-sums come from `vw_lambda_explicit`.
  - The exceptional primes lie in a fixed finset `Ebig`.
* `VW_uniform`: the same bound, uniform over `m₀ < X`, with explicit monotone majorants.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset ArithmeticFunction

namespace GoldC.QuillonCCellApp

open GoldC.QuillonVW GoldC.QuillonVWClass GoldC.QuillonVWSum GoldC.QuillonVWExplicit GoldC.QuillonVWInner
  GoldC.QuillonPrimeSum GoldC.QuillonWBilinear GoldC.QuillonPContext GoldC.QuillonExplicit
  GoldC.QuillonWContext GoldC.QuillonCContext2 GoldC.QuillonWCellApp GoldC.QuillonCells

variable {s : ℕ} [NeZero s] {M : ℕ} [NeZero M]

/-- The VW prime sum for one cofactor `m₀`. -/
theorem VW_m0 (hs2 : 2 ≤ s) (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p)
    (hMs : Nat.Coprime M s)
    (𝒥 : Finset ℕ) (Acoef : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s) (m₀ : ℕ)
    (hm₀s : IsUnit (m₀ : ZMod s)) (hm₀M : IsUnit (m₀ : ZMod M)) (hm₀ : 1 ≤ m₀)
    (JP : Finset ℕ) (hJP : ∀ p ∈ JP, p.Prime) (Ebig : Finset ℕ) (Ec : ℕ) (hEc : Ebig.card ≤ Ec)
    (I₀ I₁ : ℕ)
    (hE : ∀ p, p.Prime → p ∈ Ioc (I₀ / m₀) (I₁ / m₀) → p ∉ JP → p ∈ Ebig)
    (hP₀M : M < I₀ / m₀) (hP₀6 : 6 ≤ I₀ / m₀)
    (Uv Vv Tv : ℕ) (hVv : Vv ≤ I₀ / m₀) (hUv : 2 ≤ Uv) (hTv : 2 ≤ Tv) :
    ‖∑ p ∈ JP, ((1 / ((p : ℝ) - 3) : ℝ) : ℂ) *
        (if p * m₀ ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (p * m₀) else 0)‖ ≤
      ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ *
        (wt (I₀ / m₀ + 1) * (VWB P (c j) Uv Vv Tv M (I₁ / m₀) +
          Real.log (I₁ / m₀ : ℕ) * (Nat.sqrt (I₁ / m₀) * Nat.log 2 (I₁ / m₀))) + 6 / (I₀ / m₀ : ℕ) +
          Ec * (2.5 / (I₀ / m₀ : ℕ))) := by
  classical
  set P₀ := I₀ / m₀ with hP₀
  set P₁ := I₁ / m₀ with hP₁
  set E' := (Ioc P₀ P₁).filter (fun p => p.Prime ∧ p ∉ JP) with hE'
  set J' := ((Ioc P₀ P₁).filter Nat.Prime) \ E' with hJ'
  have hJ'mem : ∀ p, p ∈ J' ↔ (p.Prime ∧ p ∈ Ioc P₀ P₁ ∧ p ∉ E') := by
    intro p; simp only [hJ', mem_sdiff, mem_filter]; tauto
  have hJ'eq : ∀ p, p ∈ J' ↔ (p ∈ JP ∧ p ∈ Ioc P₀ P₁) := by
    intro p
    rw [hJ'mem]
    simp only [hE', mem_filter]
    constructor
    · rintro ⟨hp, hI, hn⟩
      by_contra hc
      exact hn ⟨hI, hp, fun h => hc ⟨h, hI⟩⟩
    · rintro ⟨hp, hI⟩
      exact ⟨hJP p hp, hI, fun h => h.2.2 hp⟩
  -- restrict the sum
  have hmask : ∀ p, p * m₀ ∈ Ioc I₀ I₁ ↔ p ∈ Ioc P₀ P₁ := by
    intro p
    rw [mem_Ioc_div_iff I₀ I₁ m₀ p hm₀, mul_comm]
  have hrestrict : ∑ p ∈ JP, ((1 / ((p : ℝ) - 3) : ℝ) : ℂ) *
      (if p * m₀ ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (p * m₀) else 0) =
      ∑ p ∈ J', ((1 / ((p : ℝ) - 3) : ℝ) : ℂ) *
      (if p * m₀ ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (p * m₀) else 0) := by
    have hsub : J' ⊆ JP := fun p hp => ((hJ'eq p).1 hp).1
    symm
    refine sum_subset hsub fun p hpJ hpJ' => ?_
    have : p ∉ Ioc P₀ P₁ := fun h => hpJ' ((hJ'eq p).2 ⟨hpJ, h⟩)
    rw [if_neg (fun h => this ((hmask p).1 h)), mul_zero]
  rw [hrestrict]
  -- Λ-sum bounds
  have hP₁ge : ∀ X₁ X', P₀ ≤ X₁ → X₁ ≤ X' → X' ≤ P₁ → 1 ≤ X' := fun X₁ X' h1 h2 _ => by omega
  have hΛ : ∀ j ∈ 𝒥, ∀ ρ' : ZMod M, IsUnit ρ' → ∀ X₁ X', P₀ ≤ X₁ → X₁ ≤ X' → X' ≤ P₁ →
      ‖∑ n ∈ Ioc X₁ X', ((vonMangoldt n : ℝ) : ℂ) * cphase ρ' (c j * (m₀ : ZMod s)⁻¹) n‖ ≤
        VWB P (c j) Uv Vv Tv M P₁ := by
    intro j _ ρ' hρ' X₁ X' h1 h2 h3
    have hu : IsUnit ((m₀ : ZMod s)⁻¹) := unit_inv_isUnit hm₀s
    rw [← VWB_mul_unit P hsP (c j) ((m₀ : ZMod s)⁻¹) hu]
    exact vw_lambda_explicit hs2 P hP hsP (c j * (m₀ : ZMod s)⁻¹) ρ' hρ' hMs Uv Vv Tv X₁ X' P₁
      (hVv.trans h1) h2 h3 (by omega) hUv hTv
  have hVW := VW_inner 𝒥 Acoef c m₀ hm₀s hm₀M hm₀ J' E' P₀ P₁ I₀ I₁ hJ'mem hP₀M hP₀6
    (fun j => VWB P (c j) Uv Vv Tv M P₁)
    (fun j => VWB_nonneg P hP (c j) Uv Vv Tv M P₁ (by omega) (by omega)) hΛ
  refine hVW.trans (sum_le_sum fun ρ _ => sum_le_sum fun j _ => ?_)
  apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
  have hEcard : (E'.card : ℝ) ≤ Ec := by
    have : E' ⊆ Ebig := by
      intro p hp
      simp only [hE', mem_filter] at hp
      exact hE p hp.2.1 hp.1 hp.2.2
    exact_mod_cast (card_le_card this).trans hEc
  have hP₀R : (0 : ℝ) ≤ 2.5 / (P₀ : ℝ) := by positivity
  linarith [mul_le_mul_of_nonneg_right hEcard hP₀R]

lemma VWB_mono (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (c : ZMod s) (U V T Q B B' : ℕ)
    (hU : 1 ≤ U) (hT : 1 ≤ T) (hB : 1 ≤ B) (hBB : B ≤ B') :
    VWB P c U V T Q B ≤ VWB P c U V T Q B' := by
  unfold VWB
  have hBR : (B : ℝ) ≤ B' := by exact_mod_cast hBB
  have hB1R : (1 : ℝ) ≤ B := by exact_mod_cast hB
  have hlog : Real.log B ≤ Real.log B' := Real.log_le_log (by linarith) hBR
  have hlog0 : 0 ≤ Real.log B := Real.log_natCast_nonneg B
  have hK := Kmax_nonneg P c
  have hlU := Real.log_natCast_nonneg U
  have hls := Real.log_natCast_nonneg s
  have hlUV := Real.log_natCast_nonneg (U * V)
  have hTx := TIIx_mono P hP c U V T B B' hU hT hB hBB
  have hQ0 : (0 : ℝ) ≤ Q := Nat.cast_nonneg _
  have hs0 : (0 : ℝ) ≤ s := Nat.cast_nonneg _
  gcongr

/-- `VW_m0`, uniform over the cofactor `m₀ < X`. -/
theorem VW_uniform (hs2 : 2 ≤ s) (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p)
    (hMs : Nat.Coprime M s)
    (𝒥 : Finset ℕ) (Acoef : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s) (X : ℕ) (hX : 2 ≤ X) (m₀ : ℕ)
    (hm₀s : IsUnit (m₀ : ZMod s)) (hm₀M : IsUnit (m₀ : ZMod M)) (hm₀ : 1 ≤ m₀) (hm₀X : m₀ < X)
    (JP : Finset ℕ) (hJP : ∀ p ∈ JP, p.Prime) (Ebig : Finset ℕ) (Ec : ℕ) (hEc : Ebig.card ≤ Ec)
    (I₀ I₁ : ℕ) (hI : I₀ ≤ I₁)
    (hE : ∀ p, p.Prime → I₀ / X < p → p ≤ I₁ → p ∉ JP → p ∈ Ebig)
    (hP₀M : M < I₀ / X) (hP₀6 : 6 ≤ I₀ / X)
    (Uv Vv Tv : ℕ) (hVv : Vv ≤ I₀ / X) (hUv : 2 ≤ Uv) (hTv : 2 ≤ Tv) :
    ‖∑ p ∈ JP, ((1 / ((p : ℝ) - 3) : ℝ) : ℂ) *
        (if p * m₀ ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (p * m₀) else 0)‖ ≤
      ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ *
        (wt (I₀ / X + 1) * (VWB P (c j) Uv Vv Tv M I₁ +
          Real.log I₁ * (Nat.sqrt I₁ * Nat.log 2 I₁)) + 6 / (I₀ / X : ℕ) +
          Ec * (2.5 / (I₀ / X : ℕ))) := by
  have hdiv : I₀ / X ≤ I₀ / m₀ := Nat.div_le_div_left hm₀X.le hm₀
  have hdiv1 : I₁ / m₀ ≤ I₁ := Nat.div_le_self _ _
  have hdiv2 : I₀ / m₀ ≤ I₁ / m₀ := Nat.div_le_div_right hI
  refine (VW_m0 hs2 P hP hsP hMs 𝒥 Acoef c m₀ hm₀s hm₀M hm₀ JP hJP Ebig Ec hEc I₀ I₁
    (fun p hp hpI hpJ => hE p hp (lt_of_le_of_lt hdiv (mem_Ioc.1 hpI).1)
      ((mem_Ioc.1 hpI).2.trans hdiv1) hpJ)
    (lt_of_lt_of_le hP₀M hdiv) (hP₀6.trans hdiv) Uv Vv Tv (hVv.trans hdiv) hUv hTv).trans ?_
  refine sum_le_sum fun ρ _ => sum_le_sum fun j _ => ?_
  apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
  have hP₀R : (6 : ℝ) ≤ (I₀ / X : ℕ) := by exact_mod_cast hP₀6
  have hP₀R' : ((I₀ / X : ℕ) : ℝ) ≤ (I₀ / m₀ : ℕ) := by exact_mod_cast hdiv
  have hwt : wt (I₀ / m₀ + 1) ≤ wt (I₀ / X + 1) := wt_antitone (by omega)
  have hwt0 := wt_nonneg (I₀ / m₀ + 1)
  have hV : VWB P (c j) Uv Vv Tv M (I₁ / m₀) ≤ VWB P (c j) Uv Vv Tv M I₁ :=
    VWB_mono P hP (c j) Uv Vv Tv M (I₁ / m₀) I₁ (by omega) (by omega) (by omega) hdiv1
  have hV0 := VWB_nonneg P hP (c j) Uv Vv Tv M (I₁ / m₀) (by omega) (by omega)
  have hI₁R : ((I₁ / m₀ : ℕ) : ℝ) ≤ I₁ := by exact_mod_cast hdiv1
  have hI₁pos : (1 : ℝ) ≤ ((I₁ / m₀ : ℕ) : ℝ) := by exact_mod_cast (show 1 ≤ I₁ / m₀ by omega)
  have hlog : Real.log (I₁ / m₀ : ℕ) ≤ Real.log I₁ := Real.log_le_log (by linarith) hI₁R
  have hlog0 : 0 ≤ Real.log (I₁ / m₀ : ℕ) := Real.log_natCast_nonneg _
  have hsq : (Nat.sqrt (I₁ / m₀) : ℝ) ≤ Nat.sqrt I₁ := by exact_mod_cast Nat.sqrt_le_sqrt hdiv1
  have hl2 : (Nat.log 2 (I₁ / m₀) : ℝ) ≤ Nat.log 2 I₁ := by exact_mod_cast Nat.log_mono_right hdiv1
  have hcorr : Real.log (I₁ / m₀ : ℕ) * (Nat.sqrt (I₁ / m₀) * Nat.log 2 (I₁ / m₀)) ≤
      Real.log I₁ * (Nat.sqrt I₁ * Nat.log 2 I₁) := by gcongr
  have hcorr0 : 0 ≤ Real.log (I₁ / m₀ : ℕ) * (Nat.sqrt (I₁ / m₀) * Nat.log 2 (I₁ / m₀)) := by positivity
  have h6 : 6 / ((I₀ / m₀ : ℕ) : ℝ) ≤ 6 / ((I₀ / X : ℕ) : ℝ) :=
    div_le_div_of_nonneg_left (by norm_num) (by linarith) hP₀R'
  have h25 : 2.5 / ((I₀ / m₀ : ℕ) : ℝ) ≤ 2.5 / ((I₀ / X : ℕ) : ℝ) :=
    div_le_div_of_nonneg_left (by norm_num) (by linarith) hP₀R'
  have hEc0 : (0 : ℝ) ≤ Ec := Nat.cast_nonneg _
  have hmain : wt (I₀ / m₀ + 1) * (VWB P (c j) Uv Vv Tv M (I₁ / m₀) +
        Real.log (I₁ / m₀ : ℕ) * (Nat.sqrt (I₁ / m₀) * Nat.log 2 (I₁ / m₀))) ≤
      wt (I₀ / X + 1) * (VWB P (c j) Uv Vv Tv M I₁ + Real.log I₁ * (Nat.sqrt I₁ * Nat.log 2 I₁)) :=
    mul_le_mul hwt (add_le_add hV hcorr) (add_nonneg hV0 hcorr0) (wt_nonneg _)
  linarith [mul_le_mul_of_nonneg_left h25 hEc0]

/-! ## One dyadic piece of region C -/

/-- The explicit region-C bound for one row type on one `r`-piece `(a,b]`. -/
noncomputable def CTerm (P : Finset ℕ) (𝒥 : Finset ℕ) (A : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s)
    (U' JP : Finset ℕ) (X Y Tp Uv Vv Tv Ec a b : ℕ) : ℝ :=
  ∑ k ∈ range (Nat.log 2 (b / (X * Y)) + 1), (M : ℝ) * ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖A ρ j‖ *
      (2 * (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30) ^ 2 / a *
        TIIx P (c j) (2 ^ k * Y) (X - 1) Tp b) +
    (∑ B' ∈ (U'.filter (fun p => p < X)).powerset, ωR B') *
      (∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖A ρ j‖ *
        (wt (a / X + 1) * (VWB P (c j) Uv Vv Tv M b + Real.log b * (Nat.sqrt b * Nat.log 2 b)) +
          6 / (a / X : ℕ) + Ec * (2.5 / (a / X : ℕ)))) +
    (∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖A ρ j‖) * (∏ p ∈ U', (1 + 1 / ((p : ℝ) - 3))) * ((12.5 : ℝ) / Y)

theorem C_piece (hs2 : 2 ≤ s) (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p)
    (hMs : Nat.Coprime M s)
    (𝒥 : Finset ℕ) (Acoef : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s)
    (U' JP : Finset ℕ) (hJU : JP ⊆ U') (hU : ∀ p ∈ U', p.Prime ∧ 5 ≤ p)
    (hUs : ∀ p ∈ U', Nat.Coprime p s) (hUM : ∀ p ∈ U', Nat.Coprime p M)
    (X Y Tp Uv Vv Tv : ℕ) (hX : 2 ≤ X) (hY : 2 ≤ Y) (hTp : 2 ≤ Tp)
    (hJP : ∀ p ∈ JP, Y < p)
    (Ebig : Finset ℕ) (Ec : ℕ) (hEc : Ebig.card ≤ Ec)
    (a b : ℕ) (hab : a ≤ b) (ha1 : 1 ≤ a) (hb3 : 3 ≤ b)
    (hE : ∀ p, p.Prime → a / X < p → p ≤ b → p ∉ JP → p ∈ Ebig)
    (hP₀M : M < a / X) (hP₀6 : 6 ≤ a / X) (hVv : Vv ≤ a / X) (hUv : 2 ≤ Uv) (hTv : 2 ≤ Tv)
    (Kset : Finset ℕ) :
    ‖∑ B ∈ U'.powerset.filter (fun B => (B ∩ JP).Nonempty), (ωR B : ℂ) *
        (if (∏ p ∈ B, p) ∈ Ioc a b ∧ B.card ∈ Kset then rowW 𝒥 Acoef c (∏ p ∈ B, p) else 0)‖ ≤
      CTerm P 𝒥 Acoef c U' JP X Y Tp Uv Vv Tv Ec a b := by
  classical
  have hJPp : ∀ p ∈ JP, p.Prime := fun p hp => (hU p (hJU hp)).1
  set Vb : ℝ := ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ *
        (wt (a / X + 1) * (VWB P (c j) Uv Vv Tv M b + Real.log b * (Nat.sqrt b * Nat.log 2 b)) +
          6 / (a / X : ℕ) + Ec * (2.5 / (a / X : ℕ))) with hVb
  have hVW : ∀ B' ∈ U'.powerset, (∏ q ∈ B', q) < X →
      ‖∑ p ∈ JP, ((1 / ((p : ℝ) - 3) : ℝ) : ℂ) *
        (if p * ∏ q ∈ B', q ∈ Ioc a b then rowW 𝒥 Acoef c (p * ∏ q ∈ B', q) else 0)‖ ≤ Vb := by
    intro B' hB' hlt
    have hB'U := mem_powerset.1 hB'
    have hm1 : 1 ≤ ∏ q ∈ B', q := Nat.one_le_iff_ne_zero.2 (prod_ne_zero_iff.2 fun q hq =>
      (hU q (hB'U hq)).1.ne_zero)
    have hms : IsUnit ((∏ q ∈ B', q : ℕ) : ZMod s) :=
      (ZMod.isUnit_iff_coprime _ s).2 (Nat.Coprime.prod_left fun q hq => hUs q (hB'U hq))
    have hmM : IsUnit ((∏ q ∈ B', q : ℕ) : ZMod M) :=
      (ZMod.isUnit_iff_coprime _ M).2 (Nat.Coprime.prod_left fun q hq => hUM q (hB'U hq))
    exact VW_uniform hs2 P hP hsP hMs 𝒥 Acoef c X hX (∏ q ∈ B', q) hms hmM hm1 hlt JP hJPp Ebig Ec
      hEc a b hab hE hP₀M hP₀6 Uv Vv Tv hVv hUv hTv
  set Kp := Nat.log 2 (b / (X * Y)) + 1 with hKpdef
  have hKp : b / X ≤ 2 ^ Kp * Y := by
    have h1 : b / (X * Y) < 2 ^ Kp := Nat.lt_pow_succ_log_self (by norm_num) _
    rw [← Nat.div_div_eq_div_mul] at h1
    have h2 : b / X < (b / X / Y + 1) * Y := by
      have := Nat.lt_div_mul_add (a := b / X) (show 0 < Y by omega); linarith
    have h3 : (b / X / Y + 1) * Y ≤ 2 ^ Kp * Y := Nat.mul_le_mul_right _ h1
    omega
  refine (C_context2 P hP hsP 𝒥 Acoef c U' JP hJU hU hUM Y Kp X Tp a b hY hTp hX hab ha1 hb3 hJP hKp
    Kset Vb hVW).trans ?_
  unfold CTerm
  have hA0 : 0 ≤ ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ :=
    sum_nonneg fun _ _ => sum_nonneg fun _ _ => norm_nonneg _
  have hWU0 : 0 ≤ ∏ p ∈ U', (1 + 1 / ((p : ℝ) - 3)) := prod_nonneg fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast (hU p hp).2
    have : 0 ≤ 1 / ((p : ℝ) - 3) := by apply div_nonneg zero_le_one; linarith
    linarith
  have herr : ∑ p ∈ JP, (1 / ((p : ℝ) - 3)) ^ 2 ≤ (12.5 : ℝ) / Y :=
    sum_inv_sub3_sq JP Y hY fun p hp => ⟨(hJP p hp).le, (hU p (hJU hp)).2⟩
  have hP1 : ∑ k ∈ range Kp, (M : ℝ) * ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ *
        (2 * (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30) ^ 2 / a *
          TIIb P (c j) (2 ^ k * Y) (X - 1) Tp b) ≤
      ∑ k ∈ range Kp, (M : ℝ) * ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ *
        (2 * (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30) ^ 2 / a *
          TIIx P (c j) (2 ^ k * Y) (X - 1) Tp b) := by
    refine sum_le_sum fun k _ => mul_le_mul_of_nonneg_left (sum_le_sum fun ρ _ => sum_le_sum fun j _ => ?_)
      (Nat.cast_nonneg _)
    apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
    apply mul_le_mul_of_nonneg_left _ (by positivity)
    have h2k : 2 ≤ 2 ^ k * Y := le_trans hY (Nat.le_mul_of_pos_left Y (by positivity))
    exact TIIb_le_TIIx P hP (c j) (2 ^ k * Y) (X - 1) Tp b h2k hTp (by omega)
  have hE3 := mul_le_mul_of_nonneg_left herr (mul_nonneg hA0 hWU0)
  exact add_le_add (add_le_add hP1 le_rfl) hE3

/-! ## Dyadic splitting and the Rankin residue -/

omit [NeZero s] [NeZero M] in
lemma dyadic_split_ite {R : Type*} [AddCommMonoid R] (t : ℕ → ℕ) (ht : Monotone t) (x : ℕ) (v : R) :
    ∀ K, (if x ∈ Ioc (t 0) (t K) then v else 0) =
      ∑ i ∈ range K, (if x ∈ Ioc (t i) (t (i + 1)) then v else 0)
  | 0 => by simp
  | K + 1 => by
    rw [sum_range_succ, ← dyadic_split_ite t ht x v K]
    have h0K := ht (Nat.zero_le K)
    have hKK := ht (Nat.le_succ K)
    by_cases h1 : x ∈ Ioc (t 0) (t K)
    · have h2 : x ∈ Ioc (t 0) (t (K + 1)) := by
        rw [mem_Ioc] at h1 ⊢; exact ⟨h1.1, h1.2.trans hKK⟩
      have h3 : x ∉ Ioc (t K) (t (K + 1)) := by rw [mem_Ioc] at h1 ⊢; omega
      simp [h1, h2, h3]
    · by_cases h3 : x ∈ Ioc (t K) (t (K + 1))
      · have h2 : x ∈ Ioc (t 0) (t (K + 1)) := by
          rw [mem_Ioc] at h3 ⊢; exact ⟨lt_of_le_of_lt h0K h3.1, h3.2⟩
        simp [h1, h2, h3]
      · have h2 : x ∉ Ioc (t 0) (t (K + 1)) := by
          rw [mem_Ioc] at h1 h3 ⊢; omega
        simp [h1, h2, h3]

omit [NeZero s] [NeZero M] in
/-- **Rankin's trick** for the `ω`-mass of subsets with a large product. -/
lemma rankin (V : Finset ℕ) (hV : ∀ p ∈ V, 5 ≤ p) (L : ℝ) (hL : 0 < L) (σ : ℝ) (hσ : 0 ≤ σ) :
    ∑ B ∈ V.powerset, (if L < ((∏ p ∈ B, p : ℕ) : ℝ) then ωR B else 0) ≤
      L ^ (-σ) * ∏ p ∈ V, (1 + (p : ℝ) ^ σ / ((p : ℝ) - 3)) := by
  have h1 : ∀ B ∈ V.powerset, (if L < ((∏ p ∈ B, p : ℕ) : ℝ) then ωR B else 0) ≤
      L ^ (-σ) * ∏ p ∈ B, ((p : ℝ) ^ σ / ((p : ℝ) - 3)) := by
    intro B hB
    have hBV := mem_powerset.1 hB
    have hω0 := ωR_nonneg B fun p hp => hV p (hBV hp)
    have hprod : ∏ p ∈ B, ((p : ℝ) ^ σ / ((p : ℝ) - 3)) = (∏ p ∈ B, (p : ℝ)) ^ σ * ωR B := by
      unfold ωR
      rw [← Real.finset_prod_rpow _ _ (fun p _ => Nat.cast_nonneg p), ← prod_mul_distrib]
      exact prod_congr rfl fun p _ => by ring
    rw [hprod]
    split_ifs with h
    · have hP : (L : ℝ) ≤ ∏ p ∈ B, (p : ℝ) := by push_cast at h; exact h.le
      have : (1 : ℝ) ≤ L ^ (-σ) * (∏ p ∈ B, (p : ℝ)) ^ σ := by
        rw [Real.rpow_neg hL.le, ← div_eq_inv_mul, le_div_iff₀ (Real.rpow_pos_of_pos hL σ), one_mul]
        exact Real.rpow_le_rpow hL.le hP hσ
      nlinarith
    · have : 0 ≤ (∏ p ∈ B, (p : ℝ)) ^ σ := Real.rpow_nonneg (prod_nonneg fun _ _ => Nat.cast_nonneg _) _
      have : 0 ≤ L ^ (-σ) := (Real.rpow_pos_of_pos hL _).le
      positivity
  refine (sum_le_sum h1).trans ?_
  rw [← mul_sum, prod_one_add]

/-- The C-cell piece sum, for all four row types at once. -/
noncomputable def CSum4 (P : Finset ℕ) (H : ℕ) (μ : ℝ) (Γ : ℕ → ℕ → ℝ) (Jm : ℕ)
    (U' JP : Finset ℕ) (X Y Tp Uv Vv Tv Ec a b : ℕ) : ℝ :=
  CTerm P (Icc 1 Jm) (fun (_ : ZMod M) k => ((-(2 * μ) : ℝ) : ℂ) * GoldC.QuillonRowNF.αm k s)
      (fun k => ((((k : ℤ) * H : ℤ)) : ZMod s)) U' JP X Y Tp Uv Vv Tv Ec a b +
    CTerm P (Icc 1 Jm) (fun (_ : ZMod M) k => -(((-(2 * μ) : ℝ) : ℂ) * GoldC.QuillonRowNF.αm k s))
      (fun k => ((((-(k : ℤ)) * H : ℤ)) : ZMod s)) U' JP X Y Tp Uv Vv Tv Ec a b +
    CTerm P (Icc 1 Jm) (fun (ρ : ZMod M) k => GoldC.QuillonRowNF.αm k (M * s) *
        GoldC.QuillonRowNF.BclS M Γ s (k : ℤ) ρ)
      (fun k => ((((k : ℤ) * H * GoldC.QuillonCopyC.invMod M s : ℤ)) : ZMod s)) U' JP X Y Tp Uv Vv Tv
      Ec a b +
    CTerm P (Icc 1 Jm) (fun (ρ : ZMod M) k => -(GoldC.QuillonRowNF.αm k (M * s) *
        GoldC.QuillonRowNF.BclS M Γ s (-(k : ℤ)) ρ))
      (fun k => ((((-(k : ℤ)) * H * GoldC.QuillonCopyC.invMod M s : ℤ)) : ZMod s)) U' JP X Y Tp Uv Vv Tv
      Ec a b

/-- One dyadic piece of region C, all four row types. -/
theorem C_piece4 (hM : 2 ≤ M) (H : ℕ) (μ : ℝ) (Γ : ℕ → ℕ → ℝ) (C : Finset ℕ)
    (hCp : ∀ p ∈ C, p.Prime) (hsC : s = ∏ p ∈ C, p) (hs2 : 2 ≤ s)
    (hsM : s.Coprime M) (hHs : H.Coprime s)
    (U' JP : Finset ℕ) (hJU : JP ⊆ U') (hU : ∀ p ∈ U', p.Prime ∧ 5 ≤ p)
    (hUs : ∀ p ∈ U', Nat.Coprime p s) (hUM : ∀ p ∈ U', Nat.Coprime p M)
    (X Y Tp Uv Vv Tv : ℕ) (hX : 2 ≤ X) (hY : 2 ≤ Y) (hTp : 2 ≤ Tp)
    (hJP : ∀ p ∈ JP, Y < p)
    (Ebig : Finset ℕ) (Ec : ℕ) (hEc : Ebig.card ≤ Ec)
    (a b : ℕ) (hab : a ≤ b) (ha1 : 1 ≤ a) (hb3 : 3 ≤ b)
    (hE : ∀ p, p.Prime → a / X < p → p ≤ b → p ∉ JP → p ∈ Ebig)
    (hP₀M : M < a / X) (hP₀6 : 6 ≤ a / X) (hVv : Vv ≤ a / X) (hUv : 2 ≤ Uv) (hTv : 2 ≤ Tv)
    (Kset : Finset ℕ) (Jm : ℕ) (hJm : M * s ≤ 2 * Jm) (F : ℕ → ℝ)
    (hF : ∀ B ⊆ U', B ≠ ∅ → (∏ p ∈ B, p) ∈ Ioc a b →
      F (∏ p ∈ B, p) = GoldC.QuillonRowNF.rowAbs M H μ Γ (∏ p ∈ B, p) s) :
    |∑ B ∈ U'.powerset.filter (fun B => (B ∩ JP).Nonempty),
        (if (∏ p ∈ B, p) ∈ Ioc a b ∧ B.card ∈ Kset then ωR B * F (∏ p ∈ B, p) else 0)| ≤
      CSum4 (s := s) (M := M) C H μ Γ Jm U' JP X Y Tp Uv Vv Tv Ec a b := by
  classical
  set Rτ : (ZMod M → ℕ → ℂ) → (ℕ → ZMod s) → ℂ := fun A c =>
    ∑ B ∈ U'.powerset.filter (fun B => (B ∩ JP).Nonempty), (ωR B : ℂ) *
      (if (∏ p ∈ B, p) ∈ Ioc a b ∧ B.card ∈ Kset then
        rowW (Icc 1 Jm) A c (∏ p ∈ B, p) else 0) with hRτ
  have hexp : ((∑ B ∈ U'.powerset.filter (fun B => (B ∩ JP).Nonempty),
      (if (∏ p ∈ B, p) ∈ Ioc a b ∧ B.card ∈ Kset then ωR B * F (∏ p ∈ B, p) else 0) : ℝ) : ℂ) =
      Rτ (fun (_ : ZMod M) k => ((-(2 * μ) : ℝ) : ℂ) * GoldC.QuillonRowNF.αm k s)
          (fun k => ((((k : ℤ) * H : ℤ)) : ZMod s)) +
        Rτ (fun (_ : ZMod M) k => -(((-(2 * μ) : ℝ) : ℂ) * GoldC.QuillonRowNF.αm k s))
          (fun k => ((((-(k : ℤ)) * H : ℤ)) : ZMod s)) +
        Rτ (fun (ρ : ZMod M) k => GoldC.QuillonRowNF.αm k (M * s) * GoldC.QuillonRowNF.BclS M Γ s (k : ℤ) ρ)
          (fun k => ((((k : ℤ) * H * GoldC.QuillonCopyC.invMod M s : ℤ)) : ZMod s)) +
        Rτ (fun (ρ : ZMod M) k => -(GoldC.QuillonRowNF.αm k (M * s) *
            GoldC.QuillonRowNF.BclS M Γ s (-(k : ℤ)) ρ))
          (fun k => ((((-(k : ℤ)) * H * GoldC.QuillonCopyC.invMod M s : ℤ)) : ZMod s)) := by
    simp only [hRτ, ← sum_add_distrib]
    rw [Complex.ofReal_sum]
    refine sum_congr rfl fun B hB => ?_
    have hBU := mem_powerset.1 (mem_filter.1 hB).1
    have hBne : B ≠ ∅ := by
      rintro rfl; have := (mem_filter.1 hB).2; simp at this
    by_cases hmB : (∏ p ∈ B, p) ∈ Ioc a b ∧ B.card ∈ Kset
    · simp only [if_pos hmB]
      have hrs : (∏ p ∈ B, p).Coprime s := Nat.Coprime.prod_left fun p hp => hUs p (hBU hp)
      rw [Complex.ofReal_mul, hF B hBU hBne hmB.1,
        GoldC.QuillonRowNF.rowAbs_eq_rowW hM hs2 H μ Γ _ hrs hsM hHs Jm hJm]
      ring
    · simp only [if_neg hmB, Complex.ofReal_zero]; ring
  rw [← Real.norm_eq_abs, ← Complex.norm_real, hexp]
  unfold CSum4
  refine (norm_add_le _ _).trans (add_le_add ((norm_add_le _ _).trans (add_le_add
    ((norm_add_le _ _).trans (add_le_add ?_ ?_)) ?_)) ?_) <;>
  exact C_piece hs2 C hCp hsC (Nat.Coprime.symm hsM) (Icc 1 Jm) _ _ U' JP hJU hU hUs hUM X Y Tp Uv Vv Tv
    hX hY hTp hJP Ebig Ec hEc a b hab ha1 hb3 hE hP₀M hP₀6 hVv hUv hTv Kset

/-- **Region C for a fixed `s`.** -/
theorem C_cell (hM : 2 ≤ M) (H : ℕ) (μ : ℝ) (Γ : ℕ → ℕ → ℝ) (T C : Finset ℕ)
    (hT : ∀ p ∈ T, p.Prime ∧ 5 ≤ p ∧ p.Coprime M ∧ p.Coprime H) (hCT : C ⊆ T)
    (hsC : s = ∏ p ∈ C, p) (hs2 : 2 ≤ s)
    (X Y : ℕ) (hX : 2 ≤ X) (hY : 2 ≤ Y)
    (Kc : ℕ → Prop) [DecidablePred Kc] (Geo : ℕ → Prop) [DecidablePred Geo] (Nb Lw : ℕ)
    (hbdd : ∀ r, Geo r → r ≤ Nb) (hlow : ∀ r, Geo r → Lw < r)
    (hconv : ∀ a b c, a ≤ b → b ≤ c → Geo a → Geo c → Geo b)
    (F : ℕ → ℝ)
    (hF : ∀ B ⊆ T \ C, B ≠ ∅ → Geo (∏ p ∈ B, p) →
      F (∏ p ∈ B, p) = GoldC.QuillonRowNF.rowAbs M H μ Γ (∏ p ∈ B, p) s)
    (Fmax : ℝ) (hFmax0 : 0 ≤ Fmax)
    (hFmax : ∀ B ⊆ T \ C, Geo (∏ p ∈ B, p) → |F (∏ p ∈ B, p)| ≤ Fmax)
    (Jm : ℕ) (hJm : M * s ≤ 2 * Jm)
    (Tp Uv Vv Tv : ℕ) (hTp : 2 ≤ Tp) (hUv : 2 ≤ Uv) (hTv : 2 ≤ Tv)
    (Ebig : Finset ℕ) (Ec : ℕ) (hEc : Ebig.card ≤ Ec)
    (hEbig : ∀ p, p.Prime → Y < p → p ≤ max Nb Lw → p ∉ ((T \ C).filter (fun p => Y < p)) → p ∈ Ebig)
    (hLwM : M < Lw / X) (hLw6 : 6 ≤ Lw / X) (hLwV : Vv ≤ Lw / X) (hLwY : Y ≤ Lw / X)
    (σ : ℝ) (hσ : 0 ≤ σ) (Φmax : ℝ) (hΦ0 : 0 ≤ Φmax)
    (hΦ : ∀ a b, Lw ≤ a → a < b → b ≤ 2 * a → b ≤ max Nb Lw →
      CSum4 (s := s) (M := M) C H μ Γ Jm ((T \ C).filter (fun p => ¬ (X ≤ p ∧ p ≤ Y)))
        ((T \ C).filter (fun p => Y < p)) X Y Tp Uv Vv Tv Ec a b ≤ Φmax) :
    |∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
        (if (Kc B.card ∧ Geo (∏ p ∈ B, p)) ∧ ¬ (B ∩ (T \ C).filter (fun p => X ≤ p ∧ p ≤ Y)).Nonempty then
          ωR B * F (∏ p ∈ B, p) else 0)| ≤
      ((Nat.log 2 (max Nb Lw) + 1 : ℕ) : ℝ) * Φmax +
        Fmax * ((Lw : ℝ) ^ (-σ) * ∏ p ∈ (T \ C).filter (fun p => p < X), (1 + (p : ℝ) ^ σ / ((p : ℝ) - 3))) := by
  classical
  set JW := (T \ C).filter (fun p => X ≤ p ∧ p ≤ Y) with hJW
  set U' := (T \ C).filter (fun p => ¬ (X ≤ p ∧ p ≤ Y)) with hU'
  set JP := (T \ C).filter (fun p => Y < p) with hJPdef
  set V := (T \ C).filter (fun p => p < X) with hVdef
  set Sb := max Nb Lw with hSb
  set g : Finset ℕ → ℝ := fun B => ωR B * F (∏ p ∈ B, p) with hg
  have hTC5 : ∀ p ∈ T \ C, 5 ≤ p := fun p hp => (hT p (sdiff_subset hp)).2.1
  have hU'sub : U' ⊆ T \ C := filter_subset _ _
  have hJPU' : JP ⊆ U' := by
    intro p hp; simp only [hJPdef, hU', mem_filter] at hp ⊢; exact ⟨hp.1, by omega⟩
  have hB_JW : ∀ B ⊆ U', ¬ (B ∩ JW).Nonempty := by
    rintro B hB ⟨p, hp⟩
    rw [mem_inter] at hp
    have h1 := hB hp.1
    simp only [hU', hJW, mem_filter] at h1 hp
    exact h1.2 hp.2.2
  have hnotU : ∀ B ⊆ T \ C, ¬ B ⊆ U' → (B ∩ JW).Nonempty := by
    intro B hB hn
    obtain ⟨p, hpB, hpU⟩ := not_subset.1 hn
    refine ⟨p, mem_inter.2 ⟨hpB, ?_⟩⟩
    have hpT := hB hpB
    simp only [hU', hJW, mem_filter] at hpU ⊢
    exact ⟨hpT, by by_contra hc; exact hpU ⟨hpT, hc⟩⟩
  -- step 1: restrict to U'
  have e1 : ∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
      (if (Kc B.card ∧ Geo (∏ p ∈ B, p)) ∧ ¬ (B ∩ JW).Nonempty then g B else 0) =
      ∑ B ∈ U'.powerset.filter (fun B => B ≠ ∅), (if Kc B.card ∧ Geo (∏ p ∈ B, p) then g B else 0) := by
    rw [sum_filter, sum_filter]
    rw [← sum_subset (powerset_mono.2 hU'sub) (fun B hB hBn => ?_)]
    · refine sum_congr rfl fun B hB => ?_
      have := hB_JW B (mem_powerset.1 hB)
      simp [this]
    · have hB' := mem_powerset.1 hB
      have hn : ¬ B ⊆ U' := fun h => hBn (mem_powerset.2 h)
      have := hnotU B hB' hn
      simp [this]
  -- step 2: split by the big primes
  have e2 : ∑ B ∈ U'.powerset.filter (fun B => B ≠ ∅), (if Kc B.card ∧ Geo (∏ p ∈ B, p) then g B else 0) =
      ∑ B ∈ U'.powerset.filter (fun B => B ≠ ∅),
        (if (Kc B.card ∧ Geo (∏ p ∈ B, p)) ∧ (B ∩ JP).Nonempty then g B else 0) +
      ∑ B ∈ U'.powerset.filter (fun B => B ≠ ∅),
        (if (Kc B.card ∧ Geo (∏ p ∈ B, p)) ∧ ¬ (B ∩ JP).Nonempty then g B else 0) := by
    rw [← sum_add_distrib]; refine sum_congr rfl fun B _ => ?_
    by_cases h1 : Kc B.card ∧ Geo (∏ p ∈ B, p) <;> by_cases h2 : (B ∩ JP).Nonempty <;> simp [h1, h2]
  rw [e1, e2]
  have hTp' : ∀ p ∈ T, p.Prime := fun p hp => (hT p hp).1
  have hU'P : ∀ p ∈ U', p.Prime ∧ 5 ≤ p := fun p hp => ⟨hTp' p (sdiff_subset (hU'sub hp)), hTC5 p (hU'sub hp)⟩
  refine (abs_add_le _ _).trans (add_le_add ?_ ?_)
  · -- the big-prime part: dyadic pieces
    obtain ⟨I₀, I₁, hLI, hI₁, hGeo⟩ := exists_Ioc_of_convex Geo Nb Lw hbdd hlow hconv
    rw [cell_sum_Ioc U' JP Kc Geo I₀ I₁ hGeo g]
    set Kset := (range (U'.card + 1)).filter Kc with hKset
    set Kd := Nat.log 2 Sb + 1 with hKd
    have hKd0 : (0 : ℝ) ≤ (Kd : ℝ) := Nat.cast_nonneg _
    rcases le_or_gt I₁ I₀ with hI | hI
    · rw [sum_eq_zero fun B _ => by
        rw [if_neg]; rintro ⟨h1, _⟩; have := mem_Ioc.1 h1; omega]
      rw [abs_zero]; exact mul_nonneg hKd0 hΦ0
    set t : ℕ → ℕ := fun i => min (2 ^ i * I₀) I₁ with ht
    have hI₀1 : 1 ≤ I₀ := by have := Nat.div_le_self Lw X; omega
    have htm : Monotone t := fun i j hij =>
      min_le_min_right _ (Nat.mul_le_mul_right _ (Nat.pow_le_pow_right (by norm_num) hij))
    have ht0 : t 0 = I₀ := by simp only [ht, pow_zero, one_mul]; exact min_eq_left hI.le
    have htK : t Kd = I₁ := by
      simp only [ht]
      apply min_eq_right
      have h1 : Sb < 2 ^ Kd := Nat.lt_pow_succ_log_self (by norm_num) Sb
      have h2 : 2 ^ Kd ≤ 2 ^ Kd * I₀ := Nat.le_mul_of_pos_right _ (by omega)
      omega
    have e3 : ∑ B ∈ U'.powerset.filter (fun B => (B ∩ JP).Nonempty),
        (if (∏ p ∈ B, p) ∈ Ioc I₀ I₁ ∧ B.card ∈ Kset then g B else 0) =
        ∑ i ∈ range Kd, ∑ B ∈ U'.powerset.filter (fun B => (B ∩ JP).Nonempty),
          (if (∏ p ∈ B, p) ∈ Ioc (t i) (t (i + 1)) ∧ B.card ∈ Kset then g B else 0) := by
      rw [sum_comm]
      refine sum_congr rfl fun B _ => ?_
      have h := dyadic_split_ite t htm (∏ p ∈ B, p) (if B.card ∈ Kset then g B else 0) Kd
      rw [ht0, htK] at h
      have hl : (if (∏ p ∈ B, p) ∈ Ioc I₀ I₁ ∧ B.card ∈ Kset then g B else 0) =
          (if (∏ p ∈ B, p) ∈ Ioc I₀ I₁ then (if B.card ∈ Kset then g B else 0) else 0) := by
        by_cases h1 : (∏ p ∈ B, p) ∈ Ioc I₀ I₁ <;> simp [h1]
      rw [hl, h]
      refine sum_congr rfl fun i _ => ?_
      by_cases h1 : (∏ p ∈ B, p) ∈ Ioc (t i) (t (i + 1)) <;> simp [h1]
    rw [e3]
    refine (abs_sum_le_sum_abs _ _).trans ?_
    calc ∑ i ∈ range Kd, |∑ B ∈ U'.powerset.filter (fun B => (B ∩ JP).Nonempty),
          (if (∏ p ∈ B, p) ∈ Ioc (t i) (t (i + 1)) ∧ B.card ∈ Kset then g B else 0)|
        ≤ ∑ _i ∈ range Kd, Φmax := by
          refine sum_le_sum fun i _ => ?_
          rcases le_or_gt (t (i + 1)) (t i) with hti | hti
          · rw [sum_eq_zero fun B _ => by
              rw [if_neg]; rintro ⟨h1, _⟩; have := mem_Ioc.1 h1; omega]
            rw [abs_zero]; exact hΦ0
          have hta : t i = 2 ^ i * I₀ := by
            simp only [ht] at hti ⊢
            by_contra hne
            have : min (2 ^ i * I₀) I₁ = I₁ := by omega
            have h2 : min (2 ^ (i + 1) * I₀) I₁ ≤ I₁ := min_le_right _ _
            omega
          have htb2 : t (i + 1) ≤ 2 * t i := by
            rw [hta]; simp only [ht]
            exact (min_le_left _ _).trans (by rw [pow_succ]; nlinarith)
          have htb : t (i + 1) ≤ I₁ := min_le_right _ _
          have hta0 : I₀ ≤ t i := by rw [← ht0]; exact htm (Nat.zero_le i)
          have hLa : Lw ≤ t i := hLI.trans hta0
          have hdiv : Lw / X ≤ t i / X := Nat.div_le_div_right hLa
          have hb3 : 3 ≤ t (i + 1) := by
            have : 6 ≤ Lw / X := hLw6
            have : Lw / X ≤ Lw := Nat.div_le_self _ _
            omega
          refine (C_piece4 hM H μ Γ C (fun p hp => hTp' p (hCT hp)) hsC hs2
            (by rw [hsC]; exact Nat.Coprime.prod_left fun q hq => (hT q (hCT hq)).2.2.1)
            (by rw [hsC]; exact Nat.Coprime.prod_right fun q hq => ((hT q (hCT hq)).2.2.2).symm)
            U' JP hJPU' hU'P
            (fun p hp => by
              have hpTC := hU'sub hp
              have hpC : p ∉ C := (mem_sdiff.1 hpTC).2
              have := GoldC.QuillonWCellApp.coprime_prod_primes {p} C (by simpa using (hU'P p hp).1)
                (fun q hq => hTp' q (hCT hq)) (by simpa using hpC)
              simpa [hsC] using this)
            (fun p hp => (hT p (sdiff_subset (hU'sub hp))).2.2.1)
            X Y Tp Uv Vv Tv hX hY hTp
            (fun p hp => by
              simp only [hJPdef, mem_filter] at hp
              exact hp.2)
            Ebig Ec hEc (t i) (t (i + 1)) hti.le (by omega) hb3
            (fun p hp hp1 hp2 hp3 => hEbig p hp (lt_of_le_of_lt (hLwY.trans hdiv) hp1)
              (hp2.trans (htb.trans hI₁)) hp3)
            (lt_of_lt_of_le hLwM hdiv) (hLw6.trans hdiv) (hLwV.trans hdiv) hUv hTv Kset Jm hJm F
            (fun B hB hBne hBI => hF B (hB.trans hU'sub) hBne ((hGeo _).2 (by
              rw [mem_Ioc] at hBI ⊢
              exact ⟨lt_of_le_of_lt hta0 hBI.1, hBI.2.trans htb⟩)))).trans ?_
          exact hΦ (t i) (t (i + 1)) hLa hti htb2 (htb.trans hI₁)
      _ = ((Nat.log 2 Sb + 1 : ℕ) : ℝ) * Φmax := by rw [sum_const, card_range, nsmul_eq_mul]
  · -- the smooth part: Rankin
    have hBV : ∀ B ⊆ U', ¬ (B ∩ JP).Nonempty → B ⊆ V := by
      intro B hB hn p hp
      have hpU := hB hp
      simp only [hU', hVdef, mem_filter] at hpU ⊢
      refine ⟨hpU.1, ?_⟩
      by_contra hc
      have hYp : Y < p := by
        have := hpU.2
        by_contra hc2
        exact this ⟨by omega, by omega⟩
      exact hn ⟨p, mem_inter.2 ⟨hp, by simp only [hJPdef, mem_filter]; exact ⟨hpU.1, hYp⟩⟩⟩
    have hV5 : ∀ p ∈ V, 5 ≤ p := fun p hp => hTC5 p (filter_subset _ _ hp)
    have hLw0 : (0 : ℝ) < Lw := by
      have : 0 < Lw := by have := Nat.div_le_self Lw X; omega
      exact_mod_cast this
    calc |∑ B ∈ U'.powerset.filter (fun B => B ≠ ∅),
          (if (Kc B.card ∧ Geo (∏ p ∈ B, p)) ∧ ¬ (B ∩ JP).Nonempty then g B else 0)|
        ≤ ∑ B ∈ U'.powerset.filter (fun B => B ≠ ∅),
          |(if (Kc B.card ∧ Geo (∏ p ∈ B, p)) ∧ ¬ (B ∩ JP).Nonempty then g B else 0)| :=
          abs_sum_le_sum_abs _ _
      _ ≤ ∑ B ∈ U'.powerset.filter (fun B => B ≠ ∅),
          (if B ⊆ V ∧ (Lw : ℝ) < ((∏ p ∈ B, p : ℕ) : ℝ) then Fmax * ωR B else 0) := by
          refine sum_le_sum fun B hB => ?_
          have hBU := mem_powerset.1 (mem_filter.1 hB).1
          split_ifs with h1 h2 h2
          · have hω0 := ωR_nonneg B fun p hp => hTC5 p (hU'sub (hBU hp))
            simp only [hg]
            rw [abs_mul, abs_of_nonneg hω0, mul_comm]
            exact mul_le_mul_of_nonneg_right (hFmax B (hBU.trans hU'sub) h1.1.2) hω0
          · exfalso; apply h2
            refine ⟨hBV B hBU h1.2, ?_⟩
            exact_mod_cast hlow _ h1.1.2
          · rw [abs_zero]
            have hω0 := ωR_nonneg B fun p hp => hTC5 p (hU'sub (hBU hp))
            positivity
          · rw [abs_zero]
      _ = ∑ B ∈ (U'.powerset.filter (fun B => B ≠ ∅)).filter (fun B => B ⊆ V),
          (if (Lw : ℝ) < ((∏ p ∈ B, p : ℕ) : ℝ) then Fmax * ωR B else 0) := by
          rw [sum_filter (p := fun B => B ⊆ V)]
          refine sum_congr rfl fun B _ => ?_
          by_cases h1 : B ⊆ V <;> by_cases h2 : (Lw : ℝ) < ((∏ p ∈ B, p : ℕ) : ℝ) <;> simp [h1, h2]
      _ ≤ ∑ B ∈ V.powerset, (if (Lw : ℝ) < ((∏ p ∈ B, p : ℕ) : ℝ) then Fmax * ωR B else 0) := by
          refine sum_le_sum_of_subset_of_nonneg ?_ fun B hB _ => ?_
          · intro B hB; exact mem_powerset.2 (mem_filter.1 hB).2
          · have hω0 := ωR_nonneg B fun p hp => hV5 p ((mem_powerset.1 hB) hp)
            split_ifs <;> positivity
      _ = Fmax * ∑ B ∈ V.powerset, (if (Lw : ℝ) < ((∏ p ∈ B, p : ℕ) : ℝ) then ωR B else 0) := by
          rw [mul_sum]; refine sum_congr rfl fun B _ => ?_; split_ifs <;> ring
      _ ≤ Fmax * ((Lw : ℝ) ^ (-σ) * ∏ p ∈ V, (1 + (p : ℝ) ^ σ / ((p : ℝ) - 3))) :=
          mul_le_mul_of_nonneg_left (rankin V hV5 Lw hLw0 σ hσ) hFmax0

end GoldC.QuillonCCellApp

#print axioms GoldC.QuillonCCellApp.VW_m0
#print axioms GoldC.QuillonCCellApp.VW_uniform
#print axioms GoldC.QuillonCCellApp.C_piece
#print axioms GoldC.QuillonCCellApp.rankin
#print axioms GoldC.QuillonCCellApp.C_piece4
#print axioms GoldC.QuillonCCellApp.C_cell
