import GoldC.QuillonDecorationGronwall

/-!
# Quillon CSC3 F6: crude, elementary prime-mass bounds (no Mertens, no Brun–Selberg)

* `sum_inv_primes_dyadic_range`: `Σ_{2^{K₁} ≤ p < 2^{K₂}} 1/p ≤ 4(K₂ − K₁)/K₁` for `1 ≤ K₁ ≤ K₂`.
* `sum_inv_primes_Ico`: for `2 ≤ A ≤ B`,
  `Σ_{A ≤ p < B} 1/p ≤ 4·(log₂ B − log₂ A + 2)/log₂ A` (with `Nat.log 2`).

These are the band-mass inputs of residue B: a prime interval `[x^{1−2ε}, x^{1+ε}]` has
`1/p`-mass `≪ ε + 1/log x`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonSieve

open GoldC.QuillonCopyG

lemma primes_Ico_pow_eq (K₁ K₂ : ℕ) (h : K₁ ≤ K₂) :
    (Ico (2 ^ K₁) (2 ^ K₂)).filter Nat.Prime = (Ico K₁ K₂).biUnion block := by
  ext p
  simp only [mem_filter, mem_Ico, mem_biUnion, block]
  constructor
  · rintro ⟨⟨h1, h2⟩, hp⟩
    refine ⟨Nat.log 2 p, ⟨?_, ?_⟩, ⟨Nat.pow_log_le_self 2 hp.ne_zero, Nat.lt_pow_succ_log_self (by norm_num) p⟩, hp⟩
    · exact Nat.le_log_of_pow_le (by norm_num) h1
    · exact (Nat.log_lt_iff_lt_pow (by norm_num) hp.ne_zero).2 h2
  · rintro ⟨k, ⟨hk1, hk2⟩, ⟨h1, h2⟩, hp⟩
    refine ⟨⟨le_trans (Nat.pow_le_pow_right (by norm_num) hk1) h1,
      lt_of_lt_of_le h2 (Nat.pow_le_pow_right (by norm_num) (by omega))⟩, hp⟩

theorem sum_inv_primes_dyadic_range (K₁ K₂ : ℕ) (hK₁ : 1 ≤ K₁) (h : K₁ ≤ K₂) :
    ∑ p ∈ (Ico (2 ^ K₁) (2 ^ K₂)).filter Nat.Prime, (1 / (p : ℝ)) ≤ 4 * (K₂ - K₁ : ℕ) / K₁ := by
  rw [primes_Ico_pow_eq K₁ K₂ h]
  have hdisj : (↑(Ico K₁ K₂) : Set ℕ).PairwiseDisjoint block := by
    intro a _ b _ hab
    simp only [Function.onFun]
    rw [Finset.disjoint_left]
    intro p hpa hpb
    simp only [block, mem_filter, mem_Ico] at hpa hpb
    apply hab
    have ha := Nat.log_eq_of_pow_le_of_lt_pow hpa.1.1 hpa.1.2
    have hb := Nat.log_eq_of_pow_le_of_lt_pow hpb.1.1 hpb.1.2
    rw [← ha, ← hb]
  rw [Finset.sum_biUnion hdisj]
  have hK₁R : (0 : ℝ) < K₁ := by exact_mod_cast hK₁
  calc ∑ k ∈ Ico K₁ K₂, ∑ p ∈ block k, (1 / (p : ℝ))
      ≤ ∑ _k ∈ Ico K₁ K₂, (4 / (K₁ : ℝ)) := by
        refine Finset.sum_le_sum fun k hk => ?_
        have hk' := mem_Ico.1 hk
        refine (block_sum_le k (by omega)).trans ?_
        have : (K₁ : ℝ) ≤ k := by exact_mod_cast hk'.1
        exact div_le_div_of_nonneg_left (by norm_num) hK₁R this
    _ = 4 * (K₂ - K₁ : ℕ) / K₁ := by
        rw [Finset.sum_const, Nat.card_Ico, nsmul_eq_mul]; ring

theorem sum_inv_primes_Ico (A B : ℕ) (hA : 2 ≤ A) (hAB : A ≤ B) :
    ∑ p ∈ (Ico A B).filter Nat.Prime, (1 / (p : ℝ)) ≤
      4 * ((Nat.log 2 B + 1 - Nat.log 2 A : ℕ) : ℝ) / (Nat.log 2 A : ℝ) := by
  set K₁ := Nat.log 2 A
  set K₂ := Nat.log 2 B + 1
  have hK₁ : 1 ≤ K₁ := Nat.le_log_of_pow_le (by norm_num) (by simpa using hA)
  have hK₁₂ : K₁ ≤ K₂ := by have := Nat.log_mono_right (b := 2) hAB; omega
  have hsub : (Ico A B).filter Nat.Prime ⊆ (Ico (2 ^ K₁) (2 ^ K₂)).filter Nat.Prime := by
    intro p hp
    simp only [mem_filter, mem_Ico] at hp ⊢
    refine ⟨⟨le_trans (Nat.pow_log_le_self 2 (by omega)) hp.1.1, ?_⟩, hp.2⟩
    exact lt_of_lt_of_le hp.1.2 (le_of_lt (Nat.lt_pow_succ_log_self (by norm_num) B))
  calc ∑ p ∈ (Ico A B).filter Nat.Prime, (1 / (p : ℝ))
      ≤ ∑ p ∈ (Ico (2 ^ K₁) (2 ^ K₂)).filter Nat.Prime, (1 / (p : ℝ)) :=
        Finset.sum_le_sum_of_subset_of_nonneg hsub fun p _ _ => by positivity
    _ ≤ 4 * (K₂ - K₁ : ℕ) / K₁ := sum_inv_primes_dyadic_range K₁ K₂ hK₁ hK₁₂

end GoldC.QuillonSieve

#print axioms GoldC.QuillonSieve.sum_inv_primes_dyadic_range
#print axioms GoldC.QuillonSieve.sum_inv_primes_Ico
