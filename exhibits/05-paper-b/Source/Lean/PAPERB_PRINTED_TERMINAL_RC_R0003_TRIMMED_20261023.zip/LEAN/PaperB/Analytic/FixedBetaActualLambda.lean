import PaperB.Analytic.FixedOrderDenominatorSqueeze
import PaperB.Analytic.FixedBetaIdealLambda

namespace PaperB.Analytic

open Real

lemma fixedBeta_actual_lambda_squeeze_nat
    {W k : ℕ} {beta : ℝ}
    (hW : 0 < W) (hkW : k ≤ W) :
    ((W : ℝ) ^ beta⁻¹) * (k.factorial : ℝ) *
        ((3 * (W : ℝ)) ^ (k + 1))⁻¹
      ≤
    ((W : ℝ) ^ beta⁻¹) * (k.factorial : ℝ) *
        ((((2 * W + k : ℕ) : ℝ)) ^ (k + 1))⁻¹
    ∧
    ((W : ℝ) ^ beta⁻¹) * (k.factorial : ℝ) *
        ((((2 * W + k : ℕ) : ℝ)) ^ (k + 1))⁻¹
      ≤
    ((W : ℝ) ^ beta⁻¹) * (k.factorial : ℝ) *
        (((W : ℝ) ^ (k + 1))⁻¹) := by
  have hinv := fixedOrder_denominator_inv_squeeze hW hkW
  have hcoeff : 0 ≤ ((W : ℝ) ^ beta⁻¹) * (k.factorial : ℝ) := by
    positivity
  constructor
  · exact mul_le_mul_of_nonneg_left hinv.1 hcoeff
  · have hW2 : (W : ℝ) ^ (k + 1) ≤ ((2 : ℝ) * (W : ℝ)) ^ (k + 1) := by
      exact (pow_le_pow_left₀ (by positivity)
        (show (W : ℝ) ≤ 2 * (W : ℝ) by nlinarith)) (k + 1)
    have hinv2 :
        (((2 : ℝ) * (W : ℝ)) ^ (k + 1))⁻¹
          ≤ (((W : ℝ) ^ (k + 1))⁻¹) := by
      have hWpowPos : 0 < (W : ℝ) ^ (k + 1) := by positivity
      have h2powPos : 0 < ((2 : ℝ) * (W : ℝ)) ^ (k + 1) := by positivity
      exact (inv_le_inv₀ h2powPos hWpowPos).2 hW2
    exact mul_le_mul_of_nonneg_left (hinv.2.trans hinv2) hcoeff

#print axioms fixedBeta_actual_lambda_squeeze_nat

end PaperB.Analytic
