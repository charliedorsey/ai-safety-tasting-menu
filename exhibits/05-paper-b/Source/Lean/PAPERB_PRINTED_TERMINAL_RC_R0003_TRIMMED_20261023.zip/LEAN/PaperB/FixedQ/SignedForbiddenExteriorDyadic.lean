import PaperB.FixedQ.SignedForbiddenMainCompletion
import PaperB.FixedQ.H2BooleanFinalAssembly

namespace PaperB.FixedQ

lemma sourceForbiddenNatural_nonzero_mem_ordinaryDyadic
    {q a H D M m : ℕ}
    (hm : m ∈ Finset.Ioc M (2 * M))
    (hnz : sourceForbiddenBooleanNaturalTerm q a H D m ≠ 0) :
    m.primeFactors ∈ h2BooleanOrdinaryDyadicSets q H M := by
  classical
  have hs :
      1 < m ∧ Squarefree m ∧ m.Coprime (H * (6 * q) * D) := by
    by_contra h
    have hz : sourceForbiddenBooleanNaturalTerm q a H D m = 0 := by
      simp [sourceForbiddenBooleanNaturalTerm, h]
    exact hnz hz
  have hsupport :=
    sourceForbiddenNatural_support_active
      (q := q) (H := H) (D := D) (m := m) hs.2.1 hs.2.2
  have hmI := Finset.mem_Ioc.mp hm
  unfold h2BooleanOrdinaryDyadicSets
  apply Finset.mem_filter.mpr
  constructor
  · unfold h2BooleanDyadicSets
    apply Finset.mem_filter.mpr
    constructor
    · apply Finset.mem_powerset.mpr
      intro p hp
      unfold h2BooleanActivePrimesLE
      apply Finset.mem_filter.mpr
      constructor
      · apply Nat.mem_primesLE.mpr
        constructor
        · have hpdiv : p ∣ m := (Nat.mem_primeFactors.mp hp).2.1
          have hmpos : 0 < m := by omega
          exact (Nat.le_of_dvd hmpos hpdiv).trans hmI.2
        · exact (Nat.mem_primeFactors.mp hp).1
      · exact hsupport.1 p hp
    · unfold primeSetProduct
      rw [Nat.prod_primeFactors_of_squarefree hs.2.1]
      exact hmI
  · exact hsupport.2

noncomputable def sourceForbiddenNaturalDyadicBlock
    (q a H D M : ℕ) : ℝ :=
  ∑ m ∈ Finset.Ioc M (2 * M),
    sourceForbiddenBooleanNaturalTerm q a H D m

theorem sourceForbiddenNaturalDyadicBlock_eq_ordinaryDyadic
    (q a H D M : ℕ) :
    sourceForbiddenNaturalDyadicBlock q a H D M =
      ∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
        sourceForbiddenBooleanNaturalTerm q a H D (primeSetProduct S) := by
  classical
  let G := h2BooleanOrdinaryDyadicSets q H M
  let P := G.image primeSetProduct
  let f : ℕ → ℝ := sourceForbiddenBooleanNaturalTerm q a H D
  have hPsub : P ⊆ Finset.Ioc M (2 * M) := by
    intro m hm
    rcases Finset.mem_image.mp hm with ⟨S, hS, rfl⟩
    exact Finset.mem_Ioc.mpr
      (h2BooleanDyadicSets_range
        (h2BooleanOrdinaryDyadicSets_mem hS).1)
  have hzero :
      ∀ m ∈ Finset.Ioc M (2 * M), m ∉ P → f m = 0 := by
    intro m hm hmP
    by_contra hnz
    have hS :=
      sourceForbiddenNatural_nonzero_mem_ordinaryDyadic
        (q := q) (a := a) (H := H) (D := D) (M := M) hm hnz
    have hsq : Squarefree m := by
      by_contra hnsq
      exact hnz
        (sourceForbiddenBooleanNaturalTerm_eq_zero_of_not_squarefree hnsq)
    apply hmP
    apply Finset.mem_image.mpr
    refine ⟨m.primeFactors, hS, ?_⟩
    unfold primeSetProduct
    exact Nat.prod_primeFactors_of_squarefree hsq
  have hinj : Set.InjOn primeSetProduct (↑G : Set (Finset ℕ)) := by
    intro S hS T hT hEq
    apply h2BooleanDyadicSets_product_injective (q := q) (M := M)
    · exact (h2BooleanOrdinaryDyadicSets_mem hS).1
    · exact (h2BooleanOrdinaryDyadicSets_mem hT).1
    · exact hEq
  unfold sourceForbiddenNaturalDyadicBlock
  change (∑ m ∈ Finset.Ioc M (2 * M), f m) = _
  calc
    (∑ m ∈ Finset.Ioc M (2 * M), f m) =
        ∑ m ∈ P, f m := (Finset.sum_subset hPsub hzero).symm
    _ = ∑ S ∈ G, f (primeSetProduct S) := Finset.sum_image hinj
    _ = _ := by rfl

#print axioms sourceForbiddenNatural_nonzero_mem_ordinaryDyadic
#print axioms sourceForbiddenNaturalDyadicBlock_eq_ordinaryDyadic

end PaperB.FixedQ
