import GoldC.QuillonWCell

/-!
# Quillon CSC3 F7.5a: the W′ Cauchy lemma with a coupled range `n ∈ (L_y, R_y]`

In the W′ cell the product constraint `r = y·n ∈ I` couples `y` and `n`. After Cauchy in `n`
(Davenport's trick), the inner sum for a pair `(y, y')` runs over the **interval**
`(N,M] ∩ (L_y,R_y] ∩ (L_{y'},R_{y'}]`. That is still an incomplete Kloosterman sum of length
`≤ M − N`, so the bound is identical to `W_cauchy` and no decoupling is needed:

    ‖Σ_{n∈𝒩} β_n Σ_{y∈𝒴} α_y 1[n∈(L_y,R_y]] g(y,n)‖²
      ≤ (Σ‖β‖²)·Σ_{y,y'} ‖α_y‖‖α_y'‖·(M−N  if y≡y'  else  KB(c₀(ȳ−ȳ'))((M−N)/s + 1 + log s)).

`W_cell_coupled` is the same with the explicit `KB` evaluation and gcd moment of `W_cell`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonWCoupled

open GoldC.QuillonKl GoldC.QuillonCompletion GoldC.QuillonW GoldC.QuillonWCell

variable {s : ℕ} [NeZero s]

/-- The coupled summand. -/
noncomputable def gI (c₀ : ZMod s) (L R : ℕ → ℕ) (y n : ℕ) : ℂ :=
  if n ∈ Ioc (L y) (R y) then g c₀ y n else 0

lemma filter_Ioc_inter (N M a b a' b' : ℕ) :
    (Ioc N M).filter (fun n => n ∈ Ioc a b ∧ n ∈ Ioc a' b') =
      Ioc (max (max N a) a') (min (min M b) b') := by
  ext n; simp only [mem_filter, mem_Ioc, max_lt_iff, le_min_iff]; omega

theorem W_cauchy_coupled (hs : 2 ≤ s) (c₀ : ZMod s) (𝒴 𝒩 : Finset ℕ) {N M : ℕ} (hNM : N ≤ M)
    (h𝒩 : 𝒩 ⊆ Ioc N M) (hunit : ∀ y ∈ 𝒴, IsUnit (y : ZMod s)) (α β : ℕ → ℂ)
    (L R : ℕ → ℕ) (KB : ZMod s → ℝ) (hKB : ∀ c b : ZMod s, ‖K s b c‖ ≤ KB c) :
    ‖∑ n ∈ 𝒩, β n * ∑ y ∈ 𝒴, α y * gI c₀ L R y n‖ ^ 2 ≤
      (∑ n ∈ 𝒩, ‖β n‖ ^ 2) * ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, ‖α y‖ * ‖α y'‖ *
        (if (y : ZMod s) = y' then ((M - N : ℕ) : ℝ) else
          KB (c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹)) *
            (((M - N : ℕ) : ℝ) / s + 1 + Real.log s)) := by
  classical
  set F : ℕ → ℂ := fun n => ∑ y ∈ 𝒴, α y * gI c₀ L R y n with hF
  have hCS : ‖∑ n ∈ 𝒩, β n * F n‖ ^ 2 ≤ (∑ n ∈ 𝒩, ‖β n‖ ^ 2) * ∑ n ∈ Ioc N M, ‖F n‖ ^ 2 := by
    calc ‖∑ n ∈ 𝒩, β n * F n‖ ^ 2 ≤ (∑ n ∈ 𝒩, ‖β n‖ * ‖F n‖) ^ 2 := by
          refine pow_le_pow_left₀ (norm_nonneg _) ?_ 2
          exact (norm_sum_le _ _).trans (le_of_eq (Finset.sum_congr rfl fun n _ => norm_mul _ _))
      _ ≤ (∑ n ∈ 𝒩, ‖β n‖ ^ 2) * ∑ n ∈ 𝒩, ‖F n‖ ^ 2 := Finset.sum_mul_sq_le_sq_mul_sq _ _ _
      _ ≤ _ := mul_le_mul_of_nonneg_left
          (Finset.sum_le_sum_of_subset_of_nonneg h𝒩 fun n _ _ => by positivity)
          (Finset.sum_nonneg fun n _ => by positivity)
  refine hCS.trans (mul_le_mul_of_nonneg_left ?_ (Finset.sum_nonneg fun n _ => by positivity))
  have hexp : ((∑ n ∈ Ioc N M, ‖F n‖ ^ 2 : ℝ) : ℂ) = ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴,
      α y * (starRingEnd ℂ) (α y') * ∑ n ∈ Ioc N M,
        gI c₀ L R y n * (starRingEnd ℂ) (gI c₀ L R y' n) := by
    rw [Complex.ofReal_sum]
    have : ∀ n, ((‖F n‖ ^ 2 : ℝ) : ℂ) = ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴,
        α y * (starRingEnd ℂ) (α y') * (gI c₀ L R y n * (starRingEnd ℂ) (gI c₀ L R y' n)) := by
      intro n
      rw [Complex.ofReal_pow, ← Complex.mul_conj']
      simp only [hF, map_sum, map_mul]
      rw [Finset.sum_mul_sum]
      refine Finset.sum_congr rfl fun y _ => Finset.sum_congr rfl fun y' _ => by ring
    simp_rw [this]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun y _ => ?_
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun y' _ => ?_
    rw [Finset.mul_sum]
  have hreal : ∑ n ∈ Ioc N M, ‖F n‖ ^ 2 = ‖((∑ n ∈ Ioc N M, ‖F n‖ ^ 2 : ℝ) : ℂ)‖ := by
    rw [Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (Finset.sum_nonneg fun n _ => by positivity)]
  rw [hreal, hexp]
  refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun y hy => ?_)
  refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun y' hy' => ?_)
  rw [norm_mul, norm_mul, Complex.norm_conj]
  refine mul_le_mul_of_nonneg_left ?_ (by positivity)
  -- restrict to the intersection interval
  set a := max (max N (L y)) (L y')
  set b := min (min M (R y)) (R y')
  have hrestrict : ∑ n ∈ Ioc N M, gI c₀ L R y n * (starRingEnd ℂ) (gI c₀ L R y' n) =
      ∑ n ∈ Ioc a b, g c₀ y n * (starRingEnd ℂ) (g c₀ y' n) := by
    rw [← filter_Ioc_inter N M (L y) (R y) (L y') (R y'), sum_filter]
    refine sum_congr rfl fun n _ => ?_
    simp only [gI]
    split_ifs with h1 h2 h3 <;> simp_all
  rw [hrestrict]
  have hlen : ((b - a : ℕ) : ℝ) ≤ ((M - N : ℕ) : ℝ) := by
    exact_mod_cast (show b - a ≤ M - N by
      have : b ≤ M := (min_le_left _ _).trans (min_le_left _ _)
      have : N ≤ a := (le_max_left _ _).trans (le_max_left _ _)
      omega)
  simp_rw [pair_term c₀ y y' _ (hunit y hy) (hunit y' hy')]
  split_ifs with hyy
  · have hc : c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹) = 0 := by rw [hyy, sub_self, mul_zero]
    simp_rw [hc, zero_mul, AddChar.map_zero_eq_one]
    refine (norm_sum_le _ _).trans ?_
    calc ∑ n ∈ Ioc a b, ‖(if IsUnit (n : ZMod s) then (1 : ℂ) else 0)‖
        ≤ ∑ _n ∈ Ioc a b, (1 : ℝ) := Finset.sum_le_sum fun n _ => by split_ifs <;> simp
      _ = ((b - a : ℕ) : ℝ) := by simp
      _ ≤ _ := hlen
  · rcases le_total a b with hab | hab
    · refine (incomplete_bound hs _ a b hab _ fun b' => hKB _ b').trans ?_
      have hK0 : 0 ≤ KB (c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹)) := (norm_nonneg _).trans (hKB _ 0)
      have hsR : (0 : ℝ) < s := by exact_mod_cast (show 0 < s by omega)
      gcongr
    · rw [Ioc_eq_empty (by omega), sum_empty, norm_zero]
      have hK0 : 0 ≤ KB (c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹)) := (norm_nonneg _).trans (hKB _ 0)
      have : 0 ≤ Real.log s := Real.log_nonneg (by exact_mod_cast (show 1 ≤ s by omega))
      positivity

/-- **W5, coupled.** Same bound as `W_cell`, with the coupled range `n ∈ (L_y, R_y]`. -/
theorem W_cell_coupled {s : ℕ} [NeZero s] (hs2 : 2 ≤ s) (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime)
    (hsP : s = ∏ p ∈ P, p) (c₀ : ZMod s) (𝒴 𝒩 : Finset ℕ) (Y N M : ℕ) (hNM : N ≤ M)
    (h𝒩 : 𝒩 ⊆ Ioc N M) (h𝒴 : 𝒴 ⊆ Icc 1 Y) (hunit : ∀ y ∈ 𝒴, IsUnit (y : ZMod s))
    (α β : ℕ → ℂ) (A : ℝ) (hα : ∀ y ∈ 𝒴, ‖α y‖ ≤ A / y) (L R : ℕ → ℕ) :
    ‖∑ n ∈ 𝒩, β n * ∑ y ∈ 𝒴, α y * gI c₀ L R y n‖ ^ 2 ≤
      (∑ n ∈ 𝒩, ‖β n‖ ^ 2) * (((M - N : ℕ) : ℝ) * ∑ y ∈ 𝒴, ‖α y‖ ^ 2 +
        A ^ 2 * (((M - N : ℕ) : ℝ) * (2 * (1 + Real.log Y) ^ 2 / s) +
          (3 : ℝ) ^ ((P.card : ℝ) / 4) * (s : ℝ) ^ ((3 : ℝ) / 4) *
            (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 4) *
            (((M - N : ℕ) : ℝ) / s + 1 + Real.log s) *
            (2 * (1 + Real.log Y) ^ 2 * ∏ p ∈ P, (1 + (p : ℝ) ^ (-(3 : ℝ) / 4))))) := by
  classical
  refine (W_cauchy_coupled hs2 c₀ 𝒴 𝒩 hNM h𝒩 hunit α β L R (KB P)
    (fun c b => norm_K_le_KB P hP s hsP b c)).trans ?_
  apply mul_le_mul_of_nonneg_left _ (sum_nonneg fun n _ => by positivity)
  set L : ℝ := ((M - N : ℕ) : ℝ) with hL
  set G : ℝ := (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 4)
    with hG
  set Kc : ℝ := (3 : ℝ) ^ ((P.card : ℝ) / 4) * (s : ℝ) ^ ((3 : ℝ) / 4) * G *
    (L / s + 1 + Real.log s) with hKc
  have hL0 : 0 ≤ L := by positivity
  have hsR : (1 : ℝ) ≤ s := by exact_mod_cast (show 1 ≤ s by omega)
  have hlogs : 0 ≤ Real.log s := Real.log_nonneg hsR
  have hG0 : 0 ≤ G := by positivity
  have hKc0 : 0 ≤ Kc := by positivity
  have hA : ∀ y ∈ 𝒴, 0 ≤ A / y := fun y hy => (norm_nonneg _).trans (hα y hy)
  set T1 : ℕ → ℕ → ℝ := fun y y' => if y = y' then L * ‖α y‖ ^ 2 else 0 with hT1
  set T2 : ℕ → ℕ → ℝ := fun y y' =>
    if y ≠ y' ∧ ((s : ℕ) : ℤ) ∣ (y : ℤ) - y' then 1 / ((y : ℝ) * y') else 0 with hT2
  set T3 : ℕ → ℕ → ℝ := fun y y' => if y ≠ y' then (1 / ((y : ℝ) * y')) *
    (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^ ((1 : ℝ) / 4) else 0
    with hT3
  have hT2n : ∀ y y', 0 ≤ T2 y y' := fun y y' => by simp only [hT2]; split_ifs <;> positivity
  have hT3n : ∀ y y', 0 ≤ T3 y y' := fun y y' => by simp only [hT3]; split_ifs <;> positivity
  have hT1n : ∀ y y', 0 ≤ T1 y y' := fun y y' => by simp only [hT1]; split_ifs <;> positivity
  -- pointwise
  have hpt : ∀ y ∈ 𝒴, ∀ y' ∈ 𝒴, ‖α y‖ * ‖α y'‖ *
      (if (y : ZMod s) = y' then L else
        KB P (c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹)) * (L / s + 1 + Real.log s)) ≤
      T1 y y' + A ^ 2 * L * T2 y y' + A ^ 2 * Kc * T3 y y' := by
    intro y hy y' hy'
    have hy1 : 1 ≤ y := (mem_Icc.1 (h𝒴 hy)).1
    have hy1' : 1 ≤ y' := (mem_Icc.1 (h𝒴 hy')).1
    have hprod : ‖α y‖ * ‖α y'‖ ≤ A ^ 2 * (1 / ((y : ℝ) * y')) := by
      calc ‖α y‖ * ‖α y'‖ ≤ (A / y) * (A / y') :=
            mul_le_mul (hα y hy) (hα y' hy') (norm_nonneg _) (hA y hy)
        _ = _ := by ring
    have h2 := hT2n y y'; have h3 := hT3n y y'; have h1 := hT1n y y'
    have hA2 : 0 ≤ A ^ 2 := sq_nonneg A
    by_cases hyy : y = y'
    · subst hyy
      rw [if_pos rfl]
      have hT1v : T1 y y = L * ‖α y‖ ^ 2 := if_pos rfl
      have : ‖α y‖ * ‖α y‖ * L = L * ‖α y‖ ^ 2 := by ring
      rw [this, hT1v]
      have := mul_nonneg (mul_nonneg hA2 hL0) h2
      have := mul_nonneg (mul_nonneg hA2 hKc0) h3
      linarith
    · have hT1z : T1 y y' = 0 := by simp only [hT1, if_neg hyy]
      rw [hT1z, zero_add]
      split_ifs with hcong
      · -- congruent distinct pair
        have hdvd : ((s : ℕ) : ℤ) ∣ (y : ℤ) - y' := by
          have : ((y' : ℤ) : ZMod s) = ((y : ℤ) : ZMod s) := by push_cast; exact hcong.symm
          exact (ZMod.intCast_eq_intCast_iff_dvd_sub _ _ _).1 this
        have hT2v : T2 y y' = 1 / ((y : ℝ) * y') := if_pos (And.intro hyy hdvd)
        rw [hT2v]
        have := mul_nonneg (mul_nonneg hA2 hKc0) h3
        calc ‖α y‖ * ‖α y'‖ * L ≤ A ^ 2 * (1 / ((y : ℝ) * y')) * L :=
              mul_le_mul_of_nonneg_right hprod hL0
          _ = A ^ 2 * L * (1 / ((y : ℝ) * y')) := by ring
          _ ≤ _ := by linarith
      · have hT3v : T3 y y' = (1 / ((y : ℝ) * y')) *
            (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^ ((1 : ℝ) / 4) := by
          simp only [hT3, if_neg (not_not.2 hyy), if_pos hyy]
        rw [hT3v]
        have hKB := KB_offdiag P hP hsP c₀ y y' (hunit y hy) (hunit y' hy')
        have hLf : 0 ≤ L / s + 1 + Real.log s := by positivity
        have hKB0 : 0 ≤ KB P (c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹)) := by
          unfold KB; exact Real.rpow_nonneg (KB_base_nonneg P _) _
        have := mul_nonneg (mul_nonneg hA2 hL0) h2
        calc ‖α y‖ * ‖α y'‖ * (KB P (c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹)) *
              (L / s + 1 + Real.log s))
            ≤ A ^ 2 * (1 / ((y : ℝ) * y')) * ((3 : ℝ) ^ ((P.card : ℝ) / 4) *
                (s : ℝ) ^ ((3 : ℝ) / 4) * G *
                (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^ ((1 : ℝ) / 4) *
                (L / s + 1 + Real.log s)) :=
              mul_le_mul hprod (mul_le_mul_of_nonneg_right hKB hLf) (by positivity) (by positivity)
          _ = A ^ 2 * Kc * ((1 / ((y : ℝ) * y')) *
              (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^ ((1 : ℝ) / 4)) := by
              rw [hKc]; ring
          _ ≤ _ := by linarith
  -- sum the pointwise bound
  calc _ ≤ ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, (T1 y y' + A ^ 2 * L * T2 y y' + A ^ 2 * Kc * T3 y y') :=
        sum_le_sum fun y hy => sum_le_sum fun y' hy' => hpt y hy y' hy'
    _ = ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, T1 y y' + A ^ 2 * L * ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, T2 y y' +
          A ^ 2 * Kc * ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, T3 y y' := by
        simp only [sum_add_distrib, mul_sum]
    _ ≤ L * ∑ y ∈ 𝒴, ‖α y‖ ^ 2 + A ^ 2 * L * (2 * (1 + Real.log Y) ^ 2 / s) +
          A ^ 2 * Kc * (2 * (1 + Real.log Y) ^ 2 * ∏ p ∈ P, (1 + (p : ℝ) ^ (-(3 : ℝ) / 4))) := by
        have e1 : ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, T1 y y' = L * ∑ y ∈ 𝒴, ‖α y‖ ^ 2 := by
          rw [mul_sum]; refine sum_congr rfl fun y hy => ?_
          simp only [hT1]; rw [sum_ite_eq 𝒴 y (fun _ => L * ‖α y‖ ^ 2), if_pos hy]
        have e2 : ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, T2 y y' ≤ 2 * (1 + Real.log Y) ^ 2 / s := by
          calc _ ≤ ∑ y ∈ Icc 1 Y, ∑ y' ∈ Icc 1 Y, T2 y y' := by
                refine (sum_le_sum fun y _ => sum_le_sum_of_subset_of_nonneg h𝒴
                  fun y' _ _ => hT2n y y').trans ?_
                exact sum_le_sum_of_subset_of_nonneg h𝒴 fun y _ _ => sum_nonneg fun y' _ => hT2n y y'
            _ = ∑ y ∈ Icc 1 Y, ∑ y' ∈ (Icc 1 Y).filter (fun y' => y ≠ y' ∧
                  ((s : ℕ) : ℤ) ∣ (y : ℤ) - y'), (1 / ((y : ℝ) * y')) := by
                refine sum_congr rfl fun y _ => ?_
                rw [sum_filter]
            _ ≤ _ := gcd_pair_sum_sym s Y (by omega)
        have e3 : ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, T3 y y' ≤
            2 * (1 + Real.log Y) ^ 2 * ∏ p ∈ P, (1 + (p : ℝ) ^ (-(3 : ℝ) / 4)) := by
          calc _ ≤ ∑ y ∈ Icc 1 Y, ∑ y' ∈ Icc 1 Y, T3 y y' := by
                refine (sum_le_sum fun y _ => sum_le_sum_of_subset_of_nonneg h𝒴
                  fun y' _ _ => hT3n y y').trans ?_
                exact sum_le_sum_of_subset_of_nonneg h𝒴 fun y _ _ => sum_nonneg fun y' _ => hT3n y y'
            _ = ∑ y ∈ Icc 1 Y, ∑ y' ∈ (Icc 1 Y).filter (fun y' => y ≠ y'),
                  (1 / ((y : ℝ) * y')) *
                    (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^
                      ((1 : ℝ) / 4) := by
                refine sum_congr rfl fun y _ => ?_
                rw [sum_filter]
            _ ≤ _ := gcd_moment P hP Y
        rw [e1]
        have hAL : 0 ≤ A ^ 2 * L := by positivity
        have hAK : 0 ≤ A ^ 2 * Kc := by positivity
        have := mul_le_mul_of_nonneg_left e2 hAL
        have := mul_le_mul_of_nonneg_left e3 hAK
        linarith
    _ = _ := by rw [hKc]; ring

end GoldC.QuillonWCoupled

#print axioms GoldC.QuillonWCoupled.W_cauchy_coupled
#print axioms GoldC.QuillonWCoupled.W_cell_coupled
