import PaperB.FixedQ.SignedForbiddenMainCompletion
import PaperB.FixedQ.SignedForbiddenMeanNormalization

open scoped BigOperators

namespace PaperB.FixedQ

/-- On an ordinary active Boolean block, the pair-baseline coefficient is
exactly the ordinary omega weight divided by the full squarefree modulus.
This is the source-facing coefficient needed after the gamma-divisor sum has
been restored and the non-resonant mean contributes the full-modulus factor. -/
theorem ordinary_pairBaseline_eq_finiteOmega_div_primeSetProduct
    {q h : ℕ} {e A : Finset ℕ}
    (hA : A ⊆ e)
    (hActive : ∀ p ∈ e, activeHighPrime q p)
    (hH : ∀ p ∈ e, ¬ p ∣ h) :
    pairCoefficient q h e A / pairDenominator e A =
      finiteOmegaWeightReal e / (primeSetProduct e : ℝ) := by
  rw [pairCoefficient_eq_finiteOmega_of_ordinary hA hActive hH]
  rw [pairDenominator_eq_moduli]
  rw [pairDenominator_eq_primeSetProduct hA
    (fun p hp => (hActive p hp).1)]
  unfold primeSetProduct
  push_cast
  rfl

/-- Natural-number specialization of the ordinary pair-baseline identity.
For a squarefree source modulus `m` coprime to `6q` and the height, every
powerset choice has baseline weight `omegaCoeff q m / m`. -/
theorem source_pairBaseline_eq_omegaCoeff_div
    {q h m : ℕ} {A : Finset ℕ}
    (hm0 : m ≠ 0)
    (hsq : Squarefree m)
    (hcop6q : m.Coprime (6 * q))
    (hcoph : m.Coprime h)
    (hA : A ⊆ m.primeFactors) :
    pairCoefficient q h m.primeFactors A /
        pairDenominator m.primeFactors A =
      omegaCoeff q m / (m : ℝ) := by
  have hActive : ∀ p ∈ m.primeFactors, activeHighPrime q p := by
    intro p hp
    have hpPrime : p.Prime := (Nat.mem_primeFactors.mp hp).1
    have hpDiv : p ∣ m := (Nat.mem_primeFactors.mp hp).2.1
    have hpCop6q : p.Coprime (6 * q) :=
      Nat.Coprime.of_dvd_left hpDiv hcop6q
    have hp5 : 5 ≤ p := prime_ge_five_of_coprime_six hpPrime hpCop6q
    have hpq : ¬ p ∣ q := by
      intro hpq
      have hp6q : p ∣ 6 * q := dvd_mul_of_dvd_right hpq 6
      exact (hpPrime.coprime_iff_not_dvd.mp hpCop6q) hp6q
    exact ⟨hpPrime, hp5, hpq⟩
  have hH : ∀ p ∈ m.primeFactors, ¬ p ∣ h := by
    intro p hp hph
    have hpDiv : p ∣ m := (Nat.mem_primeFactors.mp hp).2.1
    have hpCopH : p.Coprime h := Nat.Coprime.of_dvd_left hpDiv hcoph
    have hpPrime : p.Prime := (Nat.mem_primeFactors.mp hp).1
    exact (hpPrime.coprime_iff_not_dvd.mp hpCopH) hph
  rw [ordinary_pairBaseline_eq_finiteOmega_div_primeSetProduct
    hA hActive hH]
  rw [omegaCoeff_eq_finiteOmegaWeightReal hm0 hsq hcop6q]
  unfold primeSetProduct
  rw [Nat.prod_primeFactors_of_squarefree hsq]

/-- The gamma-divisor source coefficient restores exactly to `omegaCoeff`
before any mean split.  This is the real-valued outer-weight form most useful
for source Vaaler restoration. -/
theorem source_gamma_divisor_weight_sum_eq_omegaCoeff
    {q m : ℕ}
    (hm0 : m ≠ 0)
    (hsq : Squarefree m)
    (hcop6q : m.Coprime (6 * q)) :
    (∑ d ∈ m.divisors, sourceGammaNatWeight d / (m : ℝ)) =
      omegaCoeff q m := by
  have h := omegaCoeff_mul_nat_eq_sourceGamma_divisor_sum
    (q := q) (m := m) hm0 hsq hcop6q
  have hmR : (m : ℝ) ≠ 0 := by exact_mod_cast hm0
  rw [← Finset.sum_div]
  exact (div_eq_iff hmR).2 (by
    simpa [mul_comm] using h.symm)

/-- After gamma restoration, the ordinary powerset family is exactly the
normalization mass.  The restored coefficient is constant in the Boolean
split `A`; the pair-baseline identity identifies each summand. -/
theorem source_powerset_omegaCoeff_div_eq_normalizationWeightMass
    {q h m : ℕ}
    (hm0 : m ≠ 0)
    (hsq : Squarefree m)
    (hcop6q : m.Coprime (6 * q))
    (hcoph : m.Coprime h) :
    (∑ A ∈ m.primeFactors.powerset,
        omegaCoeff q m / (m : ℝ)) =
      normalizationWeightMass q h m.primeFactors := by
  rw [normalizationWeightMass_eq_pairBaselineSum]
  apply Finset.sum_congr rfl
  intro A hA
  symm
  exact source_pairBaseline_eq_omegaCoeff_div
    hm0 hsq hcop6q hcoph (Finset.mem_powerset.mp hA)

#print axioms ordinary_pairBaseline_eq_finiteOmega_div_primeSetProduct
#print axioms source_pairBaseline_eq_omegaCoeff_div
#print axioms source_gamma_divisor_weight_sum_eq_omegaCoeff
#print axioms source_powerset_omegaCoeff_div_eq_normalizationWeightMass

end PaperB.FixedQ
