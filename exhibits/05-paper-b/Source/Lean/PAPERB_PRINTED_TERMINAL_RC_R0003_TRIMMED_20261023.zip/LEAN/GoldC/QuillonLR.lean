import GoldC.QuillonRPhysical
import GoldC.QuillonLC

/-!
# Quillon LONG L4: the LONG-right R cell (fixed `r`, reciprocity, VK along classes)

Constant-4 copies of `R_exp_ev` (VK saving; `125 → 64`, the exponent `3σ − 3/200 − 2 > 0` is
unchanged) and `R_term_ev`; the fixed-`B` R cell `R_final_L` on the LONG-right mask
`GeoRL = GeoLR ∧ r^{1+3ε} ≤ s` (the `s`-range is capped by `NbR = H/(E r)`, never by `r^{1+δ}`);
and the **physical LONG-right R theorem** `RL_physical` (`s^{1+δ}`-free: `r^{1+3ε} ≤ r^{1+δ} < s`
once `3ε ≤ δ`).

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonLR

open GoldC.QuillonEv GoldC.QuillonSetup GoldC.QuillonLam GoldC.QuillonCEv GoldC.QuillonCFinal
  GoldC.QuillonREv GoldC.QuillonLSetup GoldC.QuillonRPhysical GoldC.QuillonCopyM GoldC.QuillonWContext
  GoldC.QuillonRowNF

/-- `3ε ≤ δ` eventually. -/
lemma εp3_le_ev (δ : ℝ) (hδ0 : 0 < δ) : ∃ Λ₀ : ℝ, 1 ≤ Λ₀ ∧ ∀ h : ℕ, Λ₀ ≤ Real.log h → 3 * εp h ≤ δ := by
  obtain ⟨Λ₀, hΛ₀, h⟩ := GoldC.QuillonLC.εp_le_ev (δ / 3) (by positivity)
  exact ⟨Λ₀, hΛ₀, fun h' hΛ => by have := h h' hΛ; linarith⟩

/-- On LONG-right, `r^{1+3ε} ≤ s` once `3ε ≤ δ`. -/
lemma LR_eps {h : ℕ} {δ : ℝ} {r s : ℕ} (h3 : 3 * εp h ≤ δ) (hR : longInverseRight δ r s) :
    (r : ℝ) ^ (1 + 3 * εp h) ≤ s := by
  unfold longInverseRight at hR
  rcases Nat.eq_zero_or_pos r with h0 | h0
  · subst h0
    have hε : 0 < 1 + 3 * εp h := by unfold εp; positivity
    rw [Nat.cast_zero, Real.zero_rpow hε.ne']; positivity
  · have hr1 : (1 : ℝ) ≤ r := by exact_mod_cast h0
    exact le_trans (Real.rpow_le_rpow_of_exponent_le hr1 (by linarith)) hR.le

/-- The LONG-right R-cell `s`-mask for fixed `B`. -/
def GeoRL (h H : ℕ) (δ : ℝ) (B : Finset ℕ) (s : ℕ) : Prop :=
  GeoLR h H δ (∏ p ∈ B, p) s ∧ ((∏ p ∈ B, p : ℕ) : ℝ) ^ (1 + 3 * εp h) ≤ s

lemma geoRL_convex (h H : ℕ) (δ : ℝ) (B : Finset ℕ) :
    ∀ a b c, a ≤ b → b ≤ c → GeoRL h H δ B a → GeoRL h H δ B c → GeoRL h H δ B b := by
  intro a b c hab hbc ha hc
  have habR : (a : ℝ) ≤ b := by exact_mod_cast hab
  exact ⟨geoLR_convex_s h H δ _ a b c hab hbc ha.1 hc.1, le_trans ha.2 habR⟩

set_option maxHeartbeats 4000000 in
/-- the VK saving. -/
theorem R_exp_ev4 (c : ℝ) (hc : 0 < c) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ Λ : ℝ, Λ₀ ≤ Λ → ∀ L Lm : ℝ, 4 * Λ ^ (σ₀ - 1 / 200) ≤ L → 0 < Lm →
      Lm ≤ 3 * Λ → Real.exp (-(c * L ^ 3 / Lm ^ 2) / 2) ≤ Λ ^ (-(200 : ℝ)) := by
  have hτ : 0 < 3 * σ₀ - 3 / 200 - 2 := by unfold σ₀; norm_num
  obtain ⟨Λ₀, hΛ₀, hd⟩ := decay 0 200 (64 * c / 18) (3 * σ₀ - 3 / 200 - 2) (by norm_num) (by positivity) hτ
  refine ⟨max 2 Λ₀, le_max_left _ _, fun Λ hΛ L Lm hL hLm0 hLm => ?_⟩
  have hΛ2 : 2 ≤ Λ := le_trans (le_max_left _ _) hΛ
  have hΛ0 : 0 < Λ := by linarith
  have h1 := hd Λ (le_trans (le_max_right _ _) hΛ)
  rw [Real.rpow_zero, one_mul] at h1
  refine le_trans (Real.exp_le_exp.2 ?_) h1
  -- `c L³/Lm² ≥ (125c/9) Λ^τ`
  have hL0 : 0 ≤ 4 * Λ ^ (σ₀ - 1 / 200) := by positivity
  have hL3 : (4 * Λ ^ (σ₀ - 1 / 200)) ^ 3 ≤ L ^ 3 := pow_le_pow_left₀ hL0 hL 3
  have hLm2 : Lm ^ 2 ≤ (3 * Λ) ^ 2 := pow_le_pow_left₀ hLm0.le hLm 2
  have e1 : (4 * Λ ^ (σ₀ - 1 / 200)) ^ 3 = 64 * Λ ^ (3 * σ₀ - 3 / 200) := by
    rw [mul_pow, ← Real.rpow_natCast (Λ ^ (σ₀ - 1 / 200)) 3, ← Real.rpow_mul hΛ0.le]; norm_num; ring_nf
  have e2 : Λ ^ (3 * σ₀ - 3 / 200) = Λ ^ (3 * σ₀ - 3 / 200 - 2) * Λ ^ 2 := by
    rw [← Real.rpow_natCast, rp hΛ0]; norm_num
  have hkey : 64 * c / 18 * Λ ^ (3 * σ₀ - 3 / 200 - 2) ≤ c * L ^ 3 / Lm ^ 2 / 2 := by
    rw [le_div_iff₀ (by norm_num), le_div_iff₀ (by positivity)]
    have hp : 0 ≤ Λ ^ (3 * σ₀ - 3 / 200 - 2) := by positivity
    calc 64 * c / 18 * Λ ^ (3 * σ₀ - 3 / 200 - 2) * 2 * Lm ^ 2
        ≤ 64 * c / 18 * Λ ^ (3 * σ₀ - 3 / 200 - 2) * 2 * (3 * Λ) ^ 2 := by gcongr
      _ = c * (64 * (Λ ^ (3 * σ₀ - 3 / 200 - 2) * Λ ^ 2)) := by ring
      _ = c * (4 * Λ ^ (σ₀ - 1 / 200)) ^ 3 := by rw [e1, e2]
      _ ≤ c * L ^ 3 := by gcongr
  have : -(c * L ^ 3 / Lm ^ 2) / 2 = -(c * L ^ 3 / Lm ^ 2 / 2) := by ring
  rw [this]; linarith

set_option maxHeartbeats 4000000 in
/-- **Each R-cell `RTerm` is `≤ Λ^{−90}`**, eventually in `h`, uniformly in admissible `r`. -/
theorem R_term_ev4 (q : ℕ) (hq : 0 < q) (c C : ℝ) (hc : 0 < c) (hC : 0 ≤ C) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (h H r : ℕ), Λ₀ ≤ Real.log h → H ≤ h → 1 ≤ r →
      4 * (Real.log h) ^ σ₀ ≤ Real.log (r : ℝ) →
      Eh h * r * (r : ℝ) ^ (1 + 3 * εp h) ≤ H → LwR h r ≤ NbR h H r →
      ∀ (U : Finset ℕ), (∀ p ∈ U, p.Prime ∧ 5 ≤ p ∧ p ≤ H ^ 2) →
      ∀ (coef : ℕ → ℂ) (Ym : ℕ → ℝ), (∀ m, 1 ≤ m → ‖coef m‖ ≤ (600 * (q : ℝ) ^ 2 + 8) / m) →
        (∀ m ∈ Icc 1 (6 * q * h), (H : ℝ) / (6 * q * r) ≤ |Ym m| ∧
          |Ym m| ≤ ((6 * q * h : ℕ) : ℝ) * H / r ∧ ((6 * q * r : ℕ) : ℝ) < |Ym m|) →
        GoldC.QuillonRCellApp.RTerm c C (Icc 1 (6 * q * h)) coef Ym (6 * q * r) U (Xp h) (Kvp h r)
          (LwR h r) (max (NbR h H r) (LwR h r)) ≤ (Real.log h) ^ (-(90 : ℝ)) := by
  set Cb : ℝ := 600 * (q : ℝ) ^ 2 + 8 with hCb
  set E : ℝ := Real.exp 10 * (2 * 2 + 1) ^ 10 with hE
  have hτ : 0 < σ₀ - 1 / 200 := by unfold σ₀; norm_num
  obtain ⟨Λ₁, hΛ₁, hexp⟩ := R_exp_ev4 c hc
  obtain ⟨Λ₂, hΛ₂, hdiag⟩ := R_diag_ev (1536 * C * q) (by positivity)
  obtain ⟨Λ₃, hΛ₃, hAω⟩ := Aω_le 5 (1 / 2) (by norm_num) (by norm_num)
  obtain ⟨Λ₄, hΛ₄, hρev⟩ := GoldC.QuillonAsymp.rpow_le_exp_rpow 201 4 (σ₀ - 1 / 200) (by norm_num)
    (by norm_num) hτ
  obtain ⟨Λ₅, hΛ₅, hK⟩ := const_le_rpow (18 * Cb * 2 * 3 + Cb * 2 * E * 12.5 + 96 * q + 10) 1 one_pos
  obtain ⟨Λ₆, hΛ₆, hK2⟩ := const_le_rpow (Real.sqrt (8 * C) + 1) 100 (by norm_num)
  refine ⟨max Λ₁ (max Λ₂ (max Λ₃ (max Λ₄ (max Λ₅ (max Λ₆ (1 + Real.log (6 * q))))))),
    le_trans hΛ₁ (le_max_left _ _), ?_⟩
  intro h H r hΛ hHh hr1 hlogr hEH hLwNb U hU coef Ym hcoef hY
  have L1 : Λ₁ ≤ Real.log h := le_trans (by simp) hΛ
  have L2 : Λ₂ ≤ Real.log h := le_trans (by simp) hΛ
  have L3 : Λ₃ ≤ Real.log h := le_trans (by simp) hΛ
  have L4 : Λ₄ ≤ Real.log h := le_trans (by simp) hΛ
  have L5 : Λ₅ ≤ Real.log h := le_trans (by simp) hΛ
  have L6 : Λ₆ ≤ Real.log h := le_trans (by simp) hΛ
  have L7 : 1 + Real.log (6 * q) ≤ Real.log h := le_trans (by simp) hΛ
  clear hΛ
  set Λ := Real.log h with hΛdef
  have hΛ2 : 2 ≤ Λ := le_trans hΛ₁ L1
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  have hKΛ := hK Λ L5
  rw [Real.rpow_one] at hKΛ
  have hΛq : (96 * q + 10 : ℝ) ≤ Λ := by
    have : 0 ≤ 18 * Cb * 2 * 3 + Cb * 2 * E * 12.5 := by positivity
    linarith
  have hKfin : 18 * Cb * 2 * 3 + Cb * 2 * E * 12.5 ≤ Λ := by
    have : (0 : ℝ) ≤ 96 * q + 10 := by positivity
    linarith
  have hh1n : 1 ≤ h := by
    rcases Nat.eq_zero_or_pos h with h0 | h0
    · exfalso
      have : Real.log (h : ℝ) = 0 := by rw [h0]; simp
      linarith
    · exact h0
  have hh0 : (0 : ℝ) < h := by exact_mod_cast hh1n
  have hrR : (1 : ℝ) ≤ r := by exact_mod_cast hr1
  have hr0 : (0 : ℝ) < r := by linarith
  have hq1 : (1 : ℝ) ≤ q := by exact_mod_cast hq
  have hq0 : (0 : ℝ) < q := by linarith
  obtain ⟨hε0, hε1⟩ := GoldC.QuillonCPhysical.εp_le_one (h := h) hΛ1
  set ε := εp h with hεdef
  have hEh1 : 1 ≤ Eh h := Real.one_le_exp (by positivity)
  have hEh0 : 0 < Eh h := by linarith
  -- `r ≤ h`, `log r ≤ Λ`
  have hρ1 : (1 : ℝ) ≤ (r : ℝ) ^ ε := Real.one_le_rpow hrR hε0
  have hr3 : (r : ℝ) ≤ (r : ℝ) ^ (1 + 3 * ε) :=
    le_trans (le_of_eq (Real.rpow_one _).symm) (Real.rpow_le_rpow_of_exponent_le hrR (by linarith))
  have hHR : (H : ℝ) ≤ h := by exact_mod_cast hHh
  have hrh : (r : ℝ) ≤ h := by
    have : (r : ℝ) ≤ Eh h * r * (r : ℝ) ^ (1 + 3 * ε) := by
      have h1 : (r : ℝ) ≤ Eh h * r := le_mul_of_one_le_left hr0.le hEh1
      have h2 : 1 ≤ (r : ℝ) ^ (1 + 3 * ε) := le_trans hrR hr3
      calc (r : ℝ) ≤ Eh h * r := h1
        _ ≤ Eh h * r * (r : ℝ) ^ (1 + 3 * ε) := le_mul_of_one_le_right (by positivity) h2
    linarith
  have hlogr_le : Real.log r ≤ Λ := Real.log_le_log hr0 hrh
  set ρ := (r : ℝ) ^ ε with hρdef
  -- `ρ` is large
  have hρbig : 48 * q * Xp h + 6 ≤ ρ := by
    have h1 : ρ = Real.exp (ε * Real.log r) := by rw [hρdef, Real.rpow_def_of_pos hr0]; ring_nf
    have h2 : 4 * Λ ^ (σ₀ - 1 / 200) ≤ ε * Real.log r := by
      have e : ε * (4 * Λ ^ σ₀) = 4 * Λ ^ (σ₀ - 1 / 200) := by
        rw [hεdef]; unfold εp; rw [mul_left_comm, rp hΛ0]; ring_nf
      rw [← e]; exact mul_le_mul_of_nonneg_left hlogr hε0
    have h3 : Λ ^ (201 : ℝ) ≤ ρ := by
      rw [h1]; exact le_trans (hρev Λ L4) (Real.exp_le_exp.2 h2)
    have h4 : (48 * q * Xp h + 6 : ℝ) ≤ Λ ^ (201 : ℝ) := by
      have hX := Xp_le (h := h) hΛ1
      have e : Λ ^ (201 : ℝ) = Λ * Λ ^ (200 : ℝ) := by
        rw [show Λ * Λ ^ (200 : ℝ) = Λ ^ (1 : ℝ) * Λ ^ (200 : ℝ) by rw [Real.rpow_one], rp hΛ0]; norm_num
      rw [e]
      have hp : 1 ≤ Λ ^ (200 : ℝ) := Real.one_le_rpow hΛ1 (by norm_num)
      nlinarith
    linarith
  -- `Kv`
  obtain ⟨hKv1, hKv2⟩ := Kv_bounds ρ hρ1 (Kvp h r) rfl
  have hLwge : (r : ℝ) * ρ ^ 3 - 2 ≤ (LwR h r : ℝ) := R_Lw_ge h r hr0
  have hX1 : 1 ≤ Xp h := by have := Xp_two (h := h) hΛ2; omega
  have hL := R_L_lower r ρ q (Xp h) (Kvp h r) (LwR h r) r rfl hq hX1 hrR hρbig hKv2 hLwge
  -- `Sb`
  rw [max_eq_left hLwNb]
  set Sb := NbR h H r with hSb
  have hSbR : (Sb : ℝ) ≤ (H : ℝ) / (Eh h * r) := Nat.floor_le (by positivity)
  have hSbh : (Sb : ℝ) ≤ h := by
    have : (H : ℝ) / (Eh h * r) ≤ H := div_le_self (by positivity) (by nlinarith)
    linarith
  have hlogSb : Real.log Sb ≤ Λ := by
    rcases Nat.eq_zero_or_pos Sb with h0 | hpos
    · rw [h0]; simp; linarith
    · exact Real.log_le_log (by exact_mod_cast hpos) hSbh
  have hlogSb0 : 0 ≤ Real.log (Sb : ℝ) := Real.log_natCast_nonneg _
  -- the closed form
  set Ymin : ℝ := (H : ℝ) / (6 * q * r) with hYmin
  set Ymax : ℝ := ((6 * q * h : ℕ) : ℝ) * H / r with hYmax
  have hH0 : (0 : ℝ) < H := by
    have : 0 < Eh h * r * (r : ℝ) ^ (1 + 3 * ε) := by positivity
    linarith
  have hYmin0 : 0 < Ymin := by positivity
  have hQ1 : 1 ≤ 6 * q * r := by
    have : 1 ≤ 6 * q := by omega
    nlinarith
  have hRT := GoldC.QuillonREst.RTerm_le c C hc hC (6 * q * h) coef Cb (by positivity) hcoef Ym (6 * q * r)
    hQ1 U (fun p hp => (hU p hp).2.1) (Xp h) (Kvp h r) (LwR h r) Sb hX1 Ymin Ymax hYmin0 hY
  refine le_trans hRT ?_
  have hKf := R_Kf_bound Λ (by linarith) Sb r ε hε0 hε1 hrR hlogr_le hlogSb
  have hF4 : 1 + Real.log ((6 * q * h : ℕ) : ℝ) ≤ 2 * Λ := by
    push_cast; rw [Real.log_mul (by positivity) hh0.ne']; linarith
  have hAw : (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 Sb) : ℝ) ^ 30) ^ 2 ≤ Λ := by
    have h1 := hAω Λ L3 Sb (by linarith)
    have h0 : 0 ≤ Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 Sb) : ℝ) ^ 30 := by positivity
    calc _ ≤ (Λ ^ (1 / 2 : ℝ)) ^ 2 := pow_le_pow_left₀ h0 h1 2
      _ = Λ := by rw [← Real.rpow_natCast, ← Real.rpow_mul hΛ0.le]; norm_num
  have hXge := Xp_ge (h := h) hΛ1
  have hXpos : (0 : ℝ) < Xp h := lt_of_lt_of_le (by positivity) hXge
  have hsqX : 2 / Real.sqrt (Xp h) ≤ 2 * Λ ^ (-(100 : ℝ)) := by
    have hsq : Λ ^ (100 : ℝ) ≤ Real.sqrt (Xp h) := by
      rw [Real.le_sqrt (by positivity) hXpos.le]
      calc (Λ ^ (100 : ℝ)) ^ 2 = Λ ^ (200 : ℝ) := by
            rw [← Real.rpow_natCast, ← Real.rpow_mul hΛ0.le]; norm_num
        _ ≤ Xp h := hXge
    exact inv_rpow_le hΛ0 100 2 hsq (by norm_num)
  have hrrH : (r : ℝ) * r ≤ H := by
    have h1 : (r : ℝ) * r ≤ Eh h * r * r := by
      calc (r : ℝ) * r = 1 * (r * r) := by ring
        _ ≤ Eh h * (r * r) := mul_le_mul_of_nonneg_right hEh1 (by positivity)
        _ = Eh h * r * r := by ring
    have h2 : Eh h * r * r ≤ Eh h * r * (r : ℝ) ^ (1 + 3 * ε) :=
      mul_le_mul_of_nonneg_left hr3 (by positivity)
    linarith
  obtain ⟨hLm0, hLm⟩ := R_Ymax_facts Λ h H r q hΛdef hΛ2 hq hr1 hrrH hHR
  have hLlow : 4 * Λ ^ (σ₀ - 1 / 200) ≤
      Real.log ((((LwR h r / (2 ^ Kvp h r * Xp h) - 6 * q * r) / (6 * q * r) : ℕ)) : ℝ) := by
    have h1 : 4 * Λ ^ (σ₀ - 1 / 200) ≤ Real.log ρ := by
      rw [hρdef, Real.log_rpow hr0]
      have e : ε * (4 * Λ ^ σ₀) = 4 * Λ ^ (σ₀ - 1 / 200) := by
        rw [hεdef]; unfold εp; rw [mul_left_comm, rp hΛ0]; ring_nf
      rw [← e]; exact mul_le_mul_of_nonneg_left hlogr hε0
    exact le_trans h1 (Real.log_le_log (by linarith) hL)
  have hexpT := hexp Λ L1 _ _ hLlow hLm0 hLm
  have hdiagT : Real.sqrt (128 * C * Sb * (1 + Real.log Sb) / Ymin) ≤ Λ ^ (-(200 : ℝ)) := by
    apply sqrt_le_of (by positivity)
    have e : (Λ ^ (-(200 : ℝ))) ^ 2 = Λ ^ (-(400 : ℝ)) := by
      rw [← Real.rpow_natCast, ← Real.rpow_mul hΛ0.le]; norm_num
    rw [e]
    exact hdiag Λ L2 _ (by positivity)
      (R_diag_bound C hC Λ hΛ0 H Sb r q hH0 hr0 (Eh h) rfl hSbR hlogSb hΛ1)
  have hBr : 2 / Real.sqrt (Xp h) +
      Real.sqrt (8 * C) * Real.exp (-(c * Real.log ((((LwR h r / (2 ^ Kvp h r * Xp h) - 6 * q * r) /
        (6 * q * r) : ℕ)) : ℝ) ^ 3 / Real.log (Ymax / ((6 * q * r : ℕ) : ℝ)) ^ 2) / 2) +
      Real.sqrt (128 * C * Sb * (1 + Real.log Sb) / Ymin) ≤ 3 * Λ ^ (-(100 : ℝ)) := by
    have hk := hK2 Λ L6
    have e : Λ ^ (100 : ℝ) * Λ ^ (-(200 : ℝ)) = Λ ^ (-(100 : ℝ)) := by rw [rp hΛ0]; norm_num
    have hp : 0 ≤ Λ ^ (-(200 : ℝ)) := by positivity
    have h1 : Real.sqrt (8 * C) * Real.exp (-(c * Real.log ((((LwR h r / (2 ^ Kvp h r * Xp h) - 6 * q * r) /
        (6 * q * r) : ℕ)) : ℝ) ^ 3 / Real.log (Ymax / ((6 * q * r : ℕ) : ℝ)) ^ 2) / 2) ≤
        Real.sqrt (8 * C) * Λ ^ (-(200 : ℝ)) := mul_le_mul_of_nonneg_left hexpT (Real.sqrt_nonneg _)
    have h2 : (Real.sqrt (8 * C) + 1) * Λ ^ (-(200 : ℝ)) ≤ Λ ^ (-(100 : ℝ)) := by
      rw [← e]; exact mul_le_mul_of_nonneg_right hk hp
    linarith
  have hWU := prodU_le_pow U (fun p hp => ⟨(hU p hp).1, (hU p hp).2.1⟩) (h ^ 2)
    (fun p hp => le_trans (hU p hp).2.2 (Nat.pow_le_pow_left hHh 2)) 2 Λ (by norm_num) hΛ1
    (by push_cast; rw [Real.log_pow]; push_cast; linarith)
  have hXi : (12.5 : ℝ) / Xp h ≤ 12.5 * Λ ^ (-(200 : ℝ)) := inv_rpow_le hΛ0 200 12.5 hXge (by norm_num)
  have hWU0 : 0 ≤ ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) := prod_nonneg fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast (hU p hp).2.1
    have : 0 ≤ 1 / ((p : ℝ) - 3) := div_nonneg zero_le_one (by linarith)
    linarith
  exact R_combine Λ _ Cb _ _ _ _ _ E hΛ2 (by positivity) (by positivity) hKf
    (by have := Real.log_natCast_nonneg (6 * q * h); linarith) hF4 (by positivity) hAw (by positivity) hBr
    hWU0 hWU (by positivity) hXi (by positivity) hKfin

open Classical in
set_option maxHeartbeats 8000000 in
/-- **The R cell for a fixed `B` is `≤ 4Λ^{−90}`**, eventually in `h`, uniformly. -/
theorem R_final_L (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (a h H D : ℕ) (T B : Finset ℕ) (Kc : ℕ → Prop) [DecidablePred Kc],
      Λ₀ ≤ Real.log h → 2 ≤ h → H ≤ h →
      (∀ p ∈ T, p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q ∧ p.Coprime H ∧ p ≤ H ^ 2) → B ⊆ T →
      |∑ C ∈ (T \ B).powerset.filter (fun C => C ≠ ∅),
          (if (Kc C.card ∧ GeoRL h H δ B (∏ p ∈ C, p)) ∧
              (C ∩ (T \ B).filter (fun p => Xp h < p ∧ p ≤ 2 ^ (Kvp h (∏ p ∈ B, p)) * Xp h)).Nonempty
            then ωR C * GoldC.QuillonCopyF.foldRow q a D H (∏ p ∈ B, p) (∏ p ∈ C, p) else 0)| ≤
        4 * (Real.log h) ^ (-(90 : ℝ)) := by
  obtain ⟨c, C, hc, hC, hcab⟩ := GoldC.QuillonR.class_amp_bound
  obtain ⟨Λ₁, hΛ₁, hRT⟩ := R_term_ev4 q hq c C hc hC
  obtain ⟨Λ₂, hΛ₂, hEΛ⟩ := GoldC.QuillonAsymp.rpow_le_exp_rpow 401 1 (1 / 4) (by norm_num) (by norm_num)
    (by norm_num)
  obtain ⟨Λ₃, hΛ₃, hsl⟩ := s_large4 2
  obtain ⟨Λ₄, hΛ₄, hρev⟩ := GoldC.QuillonAsymp.rpow_le_exp_rpow 201 4 (σ₀ - 1 / 200) (by norm_num)
    (by norm_num) (by unfold σ₀; norm_num)
  refine ⟨max Λ₁ (max Λ₂ (max Λ₃ (max Λ₄ (18432 * q ^ 2 + 37 * q ^ 2 + 96 * q + 10)))),
    le_trans hΛ₁ (le_max_left _ _), ?_⟩
  intro a h H D T B Kc _ hΛ hh hHh hT hBT
  have L1 : Λ₁ ≤ Real.log h := le_trans (by simp) hΛ
  have L2 : Λ₂ ≤ Real.log h := le_trans (by simp) hΛ
  have L3 : Λ₃ ≤ Real.log h := le_trans (by simp) hΛ
  have L4 : Λ₄ ≤ Real.log h := le_trans (by simp) hΛ
  have L5 : (18432 * q ^ 2 + 37 * q ^ 2 + 96 * q + 10 : ℝ) ≤ Real.log h := le_trans (by simp) hΛ
  clear hΛ
  set Λ := Real.log h with hΛdef
  have hΛ2 : 2 ≤ Λ := le_trans hΛ₁ L1
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  set r := ∏ p ∈ B, p with hr
  have hpos4 : 0 ≤ 4 * Λ ^ (-(90 : ℝ)) := by positivity
  by_cases hex : ∃ s, GeoRL h H δ B s
  swap
  · push_neg at hex
    rw [sum_eq_zero fun C _ => by rw [if_neg]; rintro ⟨⟨-, hg⟩, -⟩; exact hex _ hg, abs_zero]
    exact hpos4
  obtain ⟨s₀, hs₀⟩ := hex
  obtain ⟨hlogr, -, hr1, hs1, hrh, -, -, -, hrsH⟩ := admLR h H r s₀ δ hδ0 hh hHh hs₀.1
  have hrR : (1 : ℝ) ≤ r := by exact_mod_cast hr1
  have hr0 : (0 : ℝ) < r := by linarith
  have hrbig := hsl Λ L3 r hr0 hlogr
  have hr2 : 2 ≤ r := by
    have : (2 : ℝ) ≤ r := hrbig
    exact_mod_cast this
  have hBp : ∀ p ∈ B, p.Prime := fun p hp => (hT p (hBT hp)).1
  haveI : NeZero (6 * q) := ⟨by omega⟩
  set ε := εp h with hεdef
  obtain ⟨hε0, hε1⟩ := GoldC.QuillonCPhysical.εp_le_one (h := h) hΛ1
  set E := Eh h with hEdef
  have hE1 : 1 ≤ E := Real.one_le_exp (by positivity)
  have hEΛ' : Λ ^ (401 : ℝ) ≤ E := by
    have := hEΛ Λ L2; rw [one_mul] at this; exact this
  -- `E r r^{1+3ε} ≤ H`
  have hs₀R : ((r : ℕ) : ℝ) ^ (1 + 3 * ε) ≤ s₀ := hs₀.2
  have hEH : E * r * (r : ℝ) ^ (1 + 3 * ε) ≤ H := by
    calc E * r * (r : ℝ) ^ (1 + 3 * ε) ≤ E * r * s₀ := by gcongr
      _ = ((r : ℝ) * s₀) * E := by ring
      _ ≤ H := hrsH
  -- `Lw ≤ Nb`
  have hNb : ∀ s, GeoRL h H δ B s → s ≤ NbR h H r := by
    intro s hg
    obtain ⟨⟨hZ, -, -, hg1, -, -⟩, -⟩ := hg
    apply Nat.le_floor
    rw [le_div_iff₀ (by positivity)]
    have := hg1
    rw [le_div_iff₀ (Real.exp_pos _)] at this
    have eE : E = Real.exp ((Real.log h) ^ (1 / 4 : ℝ)) := rfl
    calc (s : ℝ) * (E * r) = ((r : ℝ) * s) * E := by ring
      _ = ((r : ℝ) * s) * Real.exp ((Real.log h) ^ (1 / 4 : ℝ)) := by rw [eE]
      _ ≤ H := this
  have hLwlt : ∀ s, GeoRL h H δ B s → LwR h r < s := by
    intro s hg
    have hs1' : 1 ≤ s := by
      have := hg.1.1
      rcases Nat.eq_zero_or_pos s with h0 | h0
      · rw [h0] at this; simp at this
      · exact h0
    have : ⌊(r : ℝ) ^ (1 + 3 * εp h)⌋₊ ≤ s := Nat.floor_le_of_le hg.2
    unfold LwR; omega
  have hLwNb : LwR h r ≤ NbR h H r := le_of_lt (lt_of_lt_of_le (hLwlt s₀ hs₀) (hNb s₀ hs₀))
  have hNbh : NbR h H r ≤ h := by
    have : (NbR h H r : ℝ) ≤ h := by
      have h1 : (NbR h H r : ℝ) ≤ (H : ℝ) / (E * r) := Nat.floor_le (by positivity)
      have h2 : (H : ℝ) / (E * r) ≤ H := div_le_self (by positivity) (by nlinarith)
      have h3 : (H : ℝ) ≤ h := by exact_mod_cast hHh
      linarith
    exact_mod_cast this
  -- `ρ`, `Kv`, `Lw/(2^{Kv}X)`
  set ρ := (r : ℝ) ^ ε with hρdef
  have hρ1 : (1 : ℝ) ≤ ρ := Real.one_le_rpow hrR hε0
  have hρbig : 48 * q * Xp h + 6 ≤ ρ := by
    have h1 : ρ = Real.exp (ε * Real.log r) := by rw [hρdef, Real.rpow_def_of_pos hr0]; ring_nf
    have h2 : 4 * Λ ^ (σ₀ - 1 / 200) ≤ ε * Real.log r := by
      have e : ε * (4 * Λ ^ σ₀) = 4 * Λ ^ (σ₀ - 1 / 200) := by
        rw [hεdef]; unfold εp; rw [mul_left_comm, rp hΛ0]; ring_nf
      rw [← e]; exact mul_le_mul_of_nonneg_left hlogr hε0
    have h3 : Λ ^ (201 : ℝ) ≤ ρ := by rw [h1]; exact le_trans (hρev Λ L4) (Real.exp_le_exp.2 h2)
    have h4 : (48 * q * Xp h + 6 : ℝ) ≤ Λ ^ (201 : ℝ) := by
      have hX := Xp_le (h := h) hΛ1
      have e : Λ ^ (201 : ℝ) = Λ * Λ ^ (200 : ℝ) := by
        rw [show Λ * Λ ^ (200 : ℝ) = Λ ^ (1 : ℝ) * Λ ^ (200 : ℝ) by rw [Real.rpow_one], rp hΛ0]; norm_num
      rw [e]
      have hp : 1 ≤ Λ ^ (200 : ℝ) := Real.one_le_rpow hΛ1 (by norm_num)
      have hq96 : (96 * q + 6 : ℝ) ≤ Λ := by
        have : (0 : ℝ) ≤ 18432 * q ^ 2 + 37 * q ^ 2 + 4 := by positivity
        linarith
      nlinarith
    linarith
  obtain ⟨hKv1, hKv2⟩ := Kv_bounds ρ hρ1 (Kvp h r) rfl
  have hX1 : 1 ≤ Xp h := by have := Xp_two (h := h) hΛ2; omega
  have hXle := Xp_le (h := h) hΛ1
  have hL := R_L_lower r ρ q (Xp h) (Kvp h r) (LwR h r) r rfl hq hX1 hrR hρbig hKv2 (R_Lw_ge h r hr0)
  have hUlo : 4 * (6 * q * r) + 2 ≤ LwR h r / (2 ^ Kvp h r * Xp h) := by
    set N1 := LwR h r / (2 ^ Kvp h r * Xp h)
    set Q := 6 * q * r
    have hQ1 : 1 ≤ Q := Nat.mul_pos (Nat.mul_pos (by norm_num) hq) (by omega)
    have h6ρ : (6 : ℝ) ≤ ρ := by
      have : (0 : ℝ) ≤ 48 * q * Xp h := by positivity
      linarith
    have hk6 : 6 ≤ (N1 - Q) / Q := by
      have : (6 : ℝ) ≤ (((N1 - Q) / Q : ℕ) : ℝ) := by linarith
      exact_mod_cast this
    have h1 : (N1 - Q) / Q * Q ≤ N1 - Q := Nat.div_mul_le_self _ _
    have h2 : 6 * Q ≤ N1 - Q := le_trans (Nat.mul_le_mul_right Q hk6) h1
    omega
  have hHY : 8 * ((6 * q * r : ℕ) : ℝ) * ((2 ^ Kvp h r * Xp h : ℕ) : ℝ) ^ 2 ≤
      (H : ℝ) / ((6 * q * r : ℕ) : ℝ) := by
    have hq1 : (1 : ℝ) ≤ q := by exact_mod_cast hq
    rw [le_div_iff₀ (by positivity)]
    push_cast
    have hD : (2 : ℝ) ^ Kvp h r * Xp h ≤ 4 * ρ * (2 * Λ ^ (200 : ℝ)) := by
      apply mul_le_mul hKv2 hXle (by positivity) (by positivity)
    have hD0 : (0 : ℝ) ≤ (2 : ℝ) ^ Kvp h r * Xp h := by positivity
    have hD2 : ((2 : ℝ) ^ Kvp h r * Xp h) ^ 2 ≤ 64 * ρ ^ 2 * (Λ ^ (200 : ℝ)) ^ 2 := by
      calc ((2 : ℝ) ^ Kvp h r * Xp h) ^ 2 ≤ (4 * ρ * (2 * Λ ^ (200 : ℝ))) ^ 2 := pow_le_pow_left₀ hD0 hD 2
        _ = 64 * ρ ^ 2 * (Λ ^ (200 : ℝ)) ^ 2 := by ring
    have hΛ400 : (Λ ^ (200 : ℝ)) ^ 2 = Λ ^ (400 : ℝ) := by
      rw [← Real.rpow_natCast, ← Real.rpow_mul hΛ0.le]; norm_num
    rw [hΛ400] at hD2
    -- `E ≥ 18432 q² Λ^{400}`
    have hEq : 18432 * (q : ℝ) ^ 2 * Λ ^ (400 : ℝ) ≤ E := by
      have e : Λ ^ (401 : ℝ) = Λ * Λ ^ (400 : ℝ) := by
        rw [show Λ * Λ ^ (400 : ℝ) = Λ ^ (1 : ℝ) * Λ ^ (400 : ℝ) by rw [Real.rpow_one], rp hΛ0]; norm_num
      have hqq : 18432 * (q : ℝ) ^ 2 ≤ Λ := by
        have : (0 : ℝ) ≤ 37 * q ^ 2 + 96 * q + 10 := by positivity
        linarith
      have hp : 0 ≤ Λ ^ (400 : ℝ) := by positivity
      rw [e] at hEΛ'
      calc 18432 * (q : ℝ) ^ 2 * Λ ^ (400 : ℝ) ≤ Λ * Λ ^ (400 : ℝ) := mul_le_mul_of_nonneg_right hqq hp
        _ ≤ E := hEΛ'
    -- `H ≥ E r ρ³ r`
    have hr3 : (r : ℝ) ^ (1 + 3 * ε) = r * ρ ^ 3 := by
      rw [hρdef, ← Real.rpow_natCast (_ : ℝ) 3, ← Real.rpow_mul hr0.le,
        show (r : ℝ) * (r : ℝ) ^ (ε * ((3 : ℕ) : ℝ)) = (r : ℝ) ^ (1 : ℝ) * (r : ℝ) ^ (ε * ((3 : ℕ) : ℝ))
          by rw [Real.rpow_one], rp hr0]
      push_cast; ring_nf
    rw [hr3] at hEH
    have hρ2 : ρ ^ 2 ≤ ρ ^ 3 := by nlinarith
    have hP : 0 ≤ Λ ^ (400 : ℝ) := by positivity
    calc 8 * (6 * (q : ℝ) * r) * ((2 : ℝ) ^ Kvp h r * Xp h) ^ 2 * (6 * q * r)
        ≤ 8 * (6 * (q : ℝ) * r) * (64 * ρ ^ 2 * Λ ^ (400 : ℝ)) * (6 * q * r) := by gcongr
      _ = (18432 * (q : ℝ) ^ 2 * Λ ^ (400 : ℝ)) * (r * r * ρ ^ 2) := by ring
      _ ≤ E * (r * r * ρ ^ 3) := by
          apply mul_le_mul hEq _ (by positivity) (by positivity)
          exact mul_le_mul_of_nonneg_left hρ2 (by positivity)
      _ = E * r * (r * ρ ^ 3) := by ring
      _ ≤ H := hEH
  -- source data
  have hTc : ∀ p ∈ T, p.Prime ∧ 5 ≤ p ∧ p.Coprime (6 * q) ∧ p.Coprime H := fun p hp =>
    ⟨(hT p hp).1, (hT p hp).2.1, GoldC.QuillonWFinal.coprime_6q (hT p hp).1 (hT p hp).2.1 (hT p hp).2.2.1,
      (hT p hp).2.2.2.1⟩
  have hrM : r.Coprime (6 * q) :=
    GoldC.QuillonWFinal.prod_coprime_of fun p hp => (hTc p (hBT hp)).2.2.1
  set μ := GoldC.QuillonCopyF.meanWeight q (GoldC.QuillonCopyF.reducedAnchor q a D) H with hμ
  set Γ := GoldC.QuillonCopyF.gammaClass q a D H with hΓ
  have hμb : |μ| ≤ 4 := by
    have := GoldC.QuillonCopyF.meanWeight_bounds q (GoldC.QuillonCopyF.reducedAnchor q a D) H
    rw [abs_le]; constructor <;> linarith
  have hΓb : ∀ b ν, |Γ b ν| ≤ 48 * q := fun b ν => by
    have := GoldC.QuillonCopyF.abs_gammaClass_le q a D H b ν hq
    have e : (8 : ℝ) * (6 * q) = 48 * q := by ring
    linarith
  have hcell := GoldC.QuillonRCellApp.R_cell c C hc hC hcab (6 * q) H μ Γ (by omega) (48 * q) hΓb T B hTc hBT
    r rfl hr2 ((T \ B).filter (fun p => Xp h < p ∧ p ≤ 2 ^ (Kvp h r) * Xp h)) (filter_subset _ _)
    (Xp h) (Kvp h r) (Xp_two hΛ2) (fun p hp => (mem_filter.1 hp).2) Kc (GeoRL h H δ B) (NbR h H r) (LwR h r)
    hNb hLwlt (geoRL_convex h H δ B) hUlo hHY
    (fun s => GoldC.QuillonCopyF.foldRow q a D H r s)
    (fun C' hC' hne _ => by
      have hCp : ∀ p ∈ C', p.Prime ∧ 5 ≤ p := fun p hp =>
        ⟨(hT p (sdiff_subset (hC' hp))).1, (hT p (sdiff_subset (hC' hp))).2.1⟩
      obtain ⟨p, hp⟩ := nonempty_iff_ne_empty.2 hne
      have hs2 : 2 ≤ ∏ p ∈ C', p := by
        have h1 : p ∣ ∏ p ∈ C', p := dvd_prod_of_mem _ hp
        have h2 : 0 < ∏ p ∈ C', p := prod_pos fun p hp => (hCp p hp).1.pos
        have := Nat.le_of_dvd h2 h1
        have := (hCp p hp).2; omega
      exact GoldC.QuillonBridge.foldRow_eq_rowAbs q a D H r _ hq hr2 hs2 hrM
        (GoldC.QuillonWFinal.prod_coprime_of fun p hp => (hTc p (sdiff_subset (hC' hp))).2.2.1))
    (6 * q * h) (by rw [max_eq_left hLwNb]; nlinarith)
  refine le_trans hcell ?_
  have hU : ∀ p ∈ T \ B, p.Prime ∧ 5 ≤ p ∧ p ≤ H ^ 2 := fun p hp =>
    ⟨(hT p (sdiff_subset hp)).1, (hT p (sdiff_subset hp)).2.1, (hT p (sdiff_subset hp)).2.2.2.2⟩
  have hHq : 36 * (q : ℝ) ^ 2 * (r : ℝ) ^ 2 < H := by
    have hr3 : (r : ℝ) ≤ (r : ℝ) ^ (1 + 3 * ε) :=
      le_trans (le_of_eq (Real.rpow_one _).symm) (Real.rpow_le_rpow_of_exponent_le hrR (by linarith))
    have hE37 : 37 * (q : ℝ) ^ 2 ≤ E := by
      have : 37 * (q : ℝ) ^ 2 ≤ Λ := by
        have : (0 : ℝ) ≤ 18432 * q ^ 2 + 96 * q + 10 := by positivity
        linarith
      have : Λ ≤ Λ ^ (401 : ℝ) := le_rpow_big Λ hΛ1 401 (by norm_num)
      linarith
    have hq1 : (1 : ℝ) ≤ q := by exact_mod_cast hq
    have hqr : 0 < (q : ℝ) ^ 2 * (r * r) := by positivity
    calc 36 * (q : ℝ) ^ 2 * (r : ℝ) ^ 2 < 37 * (q : ℝ) ^ 2 * (r * r) := by nlinarith
      _ ≤ E * r * r := by nlinarith
      _ ≤ E * r * (r : ℝ) ^ (1 + 3 * ε) := by gcongr
      _ ≤ H := hEH
  have w1 := hRT h H r L1 hHh hr1 hlogr hEH hLwNb (T \ B) hU (fun k => ((-(2 * μ) : ℝ) : ℂ) * βk k)
    (fun k => (((k : ℤ) * H : ℤ) : ℝ) / r) (coefR_main q μ hμb)
    (fun m hm => by
      have e : ((((m : ℤ) * H : ℤ)) : ℝ) / r = (((1 * m * H : ℤ)) : ℝ) / ((1 * r : ℕ) : ℝ) := by push_cast; ring
      rw [e]; exact Ym_facts q h H r hq hr1 hHq 1 (Or.inl rfl) 1 (Or.inl rfl) m hm)
  have w2 := hRT h H r L1 hHh hr1 hlogr hEH hLwNb (T \ B) hU (fun k => -(((-(2 * μ) : ℝ) : ℂ) * βk k))
    (fun k => (((-(k : ℤ)) * H : ℤ) : ℝ) / r) (coefR_mainN q μ hμb)
    (fun m hm => by
      have e : (((-(m : ℤ)) * H : ℤ) : ℝ) / r = (((-1 * m * H : ℤ)) : ℝ) / ((1 * r : ℕ) : ℝ) := by
        push_cast; ring
      rw [e]; exact Ym_facts q h H r hq hr1 hHq (-1) (Or.inr rfl) 1 (Or.inl rfl) m hm)
  have w3 := hRT h H r L1 hHh hr1 hlogr hEH hLwNb (T \ B) hU
    (fun k => (((2 * ((6 * q : ℕ) : ℝ) * (48 * q) + 1 : ℝ)) : ℂ) * βk k)
    (fun k => (((k : ℤ) * H : ℤ) : ℝ) / ((6 * q * r : ℕ) : ℝ)) (coefR_cls q)
    (fun m hm => by
      have e : ((((m : ℤ) * H : ℤ)) : ℝ) / ((6 * q * r : ℕ) : ℝ) =
          (((1 * m * H : ℤ)) : ℝ) / ((6 * q * r : ℕ) : ℝ) := by push_cast; ring
      rw [e]; exact Ym_facts q h H r hq hr1 hHq 1 (Or.inl rfl) (6 * q) (Or.inr rfl) m hm)
  have w4 := hRT h H r L1 hHh hr1 hlogr hEH hLwNb (T \ B) hU
    (fun k => (((2 * ((6 * q : ℕ) : ℝ) * (48 * q) + 1 : ℝ)) : ℂ) * -βk k)
    (fun k => (((-(k : ℤ)) * H : ℤ) : ℝ) / ((6 * q * r : ℕ) : ℝ)) (coefR_clsN q)
    (fun m hm => by
      have e : (((-(m : ℤ)) * H : ℤ) : ℝ) / ((6 * q * r : ℕ) : ℝ) =
          (((-1 * m * H : ℤ)) : ℝ) / ((6 * q * r : ℕ) : ℝ) := by push_cast; ring
      rw [e]; exact Ym_facts q h H r hq hr1 hHq (-1) (Or.inr rfl) (6 * q) (Or.inr rfl) m hm)
  linarith

end GoldC.QuillonLR

namespace GoldC.QuillonLR

open Classical
open GoldC.QuillonEv GoldC.QuillonSetup GoldC.QuillonLam GoldC.QuillonCEv GoldC.QuillonCFinal
  GoldC.QuillonREv GoldC.QuillonWContext GoldC.QuillonRPhysical GoldC.QuillonLSetup GoldC.QuillonLW
open GoldC.QuillonCopyS GoldC.QuillonCopyF GoldC.QuillonCopyM GoldC.QuillonWPhysical

/-- The LONG-right R part at decoration `d`: not LONG-left (hence `r^{1+δ} < s`) and `C` meets `J_R(B)`. -/
noncomputable def RLPart (Jlow Jhigh q a h : ℕ) (δ : ℝ) (d : Finset ℕ) : ℝ :=
  ∑ B ∈ (Tsrc q h d).powerset, ∑ C ∈ (Tsrc q h d).powerset,
    if B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C ∧
        (MkL Jlow Jhigh h (h / primeSetProduct d) δ B C ∧
          (¬ longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧
            (C ∩ JR h (Tsrc q h d) B).Nonempty)) then
      omegaWeight B * omegaWeight C *
        foldRow q a (primeSetProduct d) (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct C)
    else 0

set_option maxHeartbeats 4000000 in
/-- **Physical R theorem.** -/
theorem RL_physical (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (Jlow Jhigh a h : ℕ) (d : Finset ℕ), Λ₀ ≤ Real.log h → 2 ≤ h →
      |RLPart Jlow Jhigh q a h δ d| ≤ (Real.log h) ^ (-(75 : ℝ)) := by
  obtain ⟨Λ₁, hΛ₁, hRf⟩ := R_final_L q hq δ hδ0 hδ1
  set E : ℝ := Real.exp 10 * (2 * 2 + 1) ^ 10 with hE
  obtain ⟨Λ₂, hΛ₂, hKΛ⟩ := const_le_rpow (4 * E) 1 one_pos
  obtain ⟨Λ₃, hΛ₃, h3ε'⟩ := εp3_le_ev δ hδ0
  refine ⟨max Λ₁ (max Λ₂ Λ₃), le_trans hΛ₁ (le_max_left _ _), ?_⟩
  intro Jlow Jhigh a h d hΛ hh
  have hΛa : Λ₁ ≤ Real.log h := le_trans (le_max_left _ _) hΛ
  have hΛb : Λ₂ ≤ Real.log h := le_trans (le_trans (le_max_left _ _) (le_max_right _ _)) hΛ
  have h3ε : 3 * εp h ≤ δ := h3ε' h (le_trans (le_trans (le_max_right _ _) (le_max_right _ _)) hΛ)
  set Λ := Real.log h with hΛdef
  have hΛ2 : 2 ≤ Λ := le_trans hΛ₁ hΛa
  have hΛ0 : 0 < Λ := by linarith
  have hK := hKΛ Λ hΛb
  rw [Real.rpow_one] at hK
  set H := h / primeSetProduct d with hH
  set T := Tsrc q h d with hT
  have hTf := Tsrc_facts q h d
  have hHh : H ≤ h := Nat.div_le_self _ _
  unfold RLPart
  rw [GoldC.QuillonCells.double_sum_fixB]
  have hinner : ∀ B ∈ T.powerset.filter (fun B => B ≠ ∅),
      |∑ C ∈ (T \ B).powerset.filter (fun C => C ≠ ∅),
        (if MkL Jlow Jhigh h H δ B C ∧
            (¬ longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧ (C ∩ JR h T B).Nonempty) then
          omegaWeight B * omegaWeight C *
            foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0)| ≤
        ωR B * (4 * Λ ^ (-(90 : ℝ))) := by
    intro B hB
    have hBT : B ⊆ T := mem_powerset.1 (mem_filter.1 hB).1
    have hω0 : 0 ≤ ωR B := ωR_nonneg B fun p hp => (hTf p (hBT hp)).2.1
    have e : ∑ C ∈ (T \ B).powerset.filter (fun C => C ≠ ∅),
        (if MkL Jlow Jhigh h H δ B C ∧
            (¬ longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧ (C ∩ JR h T B).Nonempty) then
          omegaWeight B * omegaWeight C *
            foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0) =
        ωR B * ∑ C ∈ (T \ B).powerset.filter (fun C => C ≠ ∅),
          (if ((Jlow ≤ B.card + C.card ∧ B.card + C.card < Jhigh) ∧ GeoRL h H δ B (∏ p ∈ C, p)) ∧
              (C ∩ (T \ B).filter (fun p => Xp h < p ∧ p ≤ 2 ^ (Kvp h (∏ p ∈ B, p)) * Xp h)).Nonempty
            then ωR C * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p) else 0) := by
      rw [mul_sum]
      refine sum_congr rfl fun C hC => ?_
      have hCB : C ⊆ T \ B := mem_powerset.1 (mem_filter.1 hC).1
      have hiff : (MkL Jlow Jhigh h H δ B C ∧
            (¬ longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧ (C ∩ JR h T B).Nonempty)) ↔
          (((Jlow ≤ B.card + C.card ∧ B.card + C.card < Jhigh) ∧ GeoRL h H δ B (∏ p ∈ C, p)) ∧
              (C ∩ (T \ B).filter (fun p => Xp h < p ∧ p ≤ 2 ^ (Kvp h (∏ p ∈ B, p)) * Xp h)).Nonempty) := by
        unfold MkL GeoRL GeoLR JR
        constructor
        · rintro ⟨⟨h1, h2, h3, h4, h5, h6⟩, hnL, hj⟩
          have hR : longInverseRight δ (primeSetProduct B) (primeSetProduct C) := h5.resolve_left hnL
          exact ⟨⟨⟨h3, h4⟩, ⟨h1, h2, hR, h6⟩, LR_eps h3ε hR⟩, hj⟩
        · rintro ⟨⟨⟨h3, h4⟩, ⟨h1, h2, hR, h6⟩, -⟩, hj⟩
          exact ⟨⟨h1, h2, h3, h4, Or.inr hR, h6⟩, fun hL => not_both δ hδ0.le _ _ ⟨hL, hR⟩, hj⟩
      split_ifs with h1 h2 h2
      · show ωR B * ωR C * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p) =
          ωR B * (ωR C * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p))
        ring
      · exact absurd (hiff.1 h1) h2
      · exact absurd (hiff.2 h2) h1
      · rw [mul_zero]
    rw [e, abs_mul, abs_of_nonneg hω0]
    exact mul_le_mul_of_nonneg_left (hRf a h H (primeSetProduct d) T B
      (fun k => Jlow ≤ B.card + k ∧ B.card + k < Jhigh) hΛa hh hHh hTf hBT) hω0
  calc _ ≤ ∑ B ∈ T.powerset.filter (fun B => B ≠ ∅),
        |∑ C ∈ (T \ B).powerset.filter (fun C => C ≠ ∅),
          (if MkL Jlow Jhigh h H δ B C ∧
              (¬ longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧ (C ∩ JR h T B).Nonempty) then
            omegaWeight B * omegaWeight C *
              foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0)| :=
        abs_sum_le_sum_abs _ _
    _ ≤ ∑ B ∈ T.powerset.filter (fun B => B ≠ ∅), ωR B * (4 * Λ ^ (-(90 : ℝ))) := sum_le_sum hinner
    _ ≤ ∑ B ∈ T.powerset, ωR B * (4 * Λ ^ (-(90 : ℝ))) := by
        apply sum_le_sum_of_subset_of_nonneg (filter_subset _ _)
        intro B hB _
        have hBT : B ⊆ T := mem_powerset.1 hB
        have := ωR_nonneg B fun p hp => (hTf p (hBT hp)).2.1
        positivity
    _ = (∑ B ∈ T.powerset, ωR B) * (4 * Λ ^ (-(90 : ℝ))) := by rw [sum_mul]
    _ ≤ (E * Λ ^ (10 : ℝ)) * (4 * Λ ^ (-(90 : ℝ))) :=
        mul_le_mul_of_nonneg_right (outer_mass q h d (by linarith)) (by positivity)
    _ = (4 * E) * Λ ^ (-(80 : ℝ)) := by
        rw [show Λ ^ (-(80 : ℝ)) = Λ ^ (10 : ℝ) * Λ ^ (-(90 : ℝ)) by rw [rp hΛ0]; norm_num]; ring
    _ ≤ Λ * Λ ^ (-(80 : ℝ)) := mul_le_mul_of_nonneg_right hK (by positivity)
    _ = Λ ^ (-(79 : ℝ)) := by
        rw [show Λ * Λ ^ (-(80 : ℝ)) = Λ ^ (1 : ℝ) * Λ ^ (-(80 : ℝ)) by rw [Real.rpow_one], rp hΛ0]
        norm_num
    _ ≤ Λ ^ (-(75 : ℝ)) := Real.rpow_le_rpow_of_exponent_le (by linarith) (by norm_num)

end GoldC.QuillonLR

#print axioms GoldC.QuillonLR.R_exp_ev4
#print axioms GoldC.QuillonLR.R_term_ev4
#print axioms GoldC.QuillonLR.R_final_L
#print axioms GoldC.QuillonLR.RL_physical
