import PaperB.FixedQ.SignedForbiddenSourceFacingPrincipalBridge
import PaperB.FixedQ.H3DecoratedAnalyticTerminal

namespace PaperB.FixedQ

def CompletedMainPrincipalLogPowerSaving (q : ℕ) : Prop :=
  ∃ C rho : ℝ, ∃ k H0 : ℕ,
    0 ≤ C ∧ rho < 1 ∧
      ∀ a b h : ℕ,
        q.Coprime a →
        q.Coprime b →
        Nat.ModEq q (a + h) b →
        (¬ 2 ∣ q → 2 ∣ h) →
        0 < h →
        H0 ≤ h →
        |cStarReal q h * completedBooleanMain q a h -
            signedMainB1Principal q (h / 2)| ≤
          C * (Real.log (h : ℝ)) ^ rho *
            (Real.log (Real.log (h : ℝ))) ^ k

theorem sourceFacingMainPrincipalContract_of_logPower
    (hRate :
      ∀ q : ℕ, 0 < q → Squarefree q →
        CompletedMainPrincipalLogPowerSaving q) :
    SourceFacingMainPrincipalContract := by
  intro q hq hsq
  rcases hRate q hq hsq with ⟨C, rho, k, H0, hC, hrho, hRateQ⟩
  intro eps heps
  obtain ⟨hAbsorb, hAbsorbSpec⟩ :=
    eventually_const_mul_loglog_pow_mul_log_rpow_le_no_extra
      (C := C) (rho := rho) (k := k) hC hrho eps heps
  refine ⟨max H0 hAbsorb, ?_⟩
  intro a b h ha hb hcompat h2 hh hlarge
  have hH0 : H0 ≤ h := (le_max_left H0 hAbsorb).trans hlarge
  have hAbs : hAbsorb ≤ h := (le_max_right H0 hAbsorb).trans hlarge
  have hr := hRateQ a b h ha hb hcompat h2 hh hH0
  calc
    |cStarReal q h * completedBooleanMain q a h -
        signedMainB1Principal q (h / 2)|
      ≤ C * (Real.log (h : ℝ)) ^ rho *
          (Real.log (Real.log (h : ℝ))) ^ k := hr
    _ = C * (Real.log (Real.log (h : ℝ))) ^ k *
          (Real.log (h : ℝ)) ^ rho := by ring
    _ ≤ eps * Real.log (h : ℝ) := hAbsorbSpec h hAbs

theorem sourceFacingMain_of_principalLogPower
    (hRate :
      ∀ q : ℕ, 0 < q → Squarefree q →
        CompletedMainPrincipalLogPowerSaving q) :
    SourceFacingMainContract :=
  sourceFacingMain_of_principalContract
    (sourceFacingMainPrincipalContract_of_logPower hRate)

theorem paperBTerminal_of_principalLogPower
    (hRate :
      ∀ q : ℕ, 0 < q → Squarefree q →
        CompletedMainPrincipalLogPowerSaving q) :
    PaperB.Closure.PaperBTerminalStatement :=
  paperBTerminal_of_sourceFacingMain
    (sourceFacingMain_of_principalLogPower hRate)

#print axioms sourceFacingMainPrincipalContract_of_logPower
#print axioms sourceFacingMain_of_principalLogPower
#print axioms paperBTerminal_of_principalLogPower

end PaperB.FixedQ
