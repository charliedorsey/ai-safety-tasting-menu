import PaperB.FixedQ.SignedForbiddenSourceEmptyMajorant
import PaperB.FixedQ.SignedForbiddenActiveSourceBridge

open scoped BigOperators

namespace PaperB.FixedQ

lemma sourceForbiddenBooleanMainTerm_anchor_mod
    (q a H : ℕ) (d n : Finset ℕ) :
    sourceForbiddenBooleanMainTerm q a H d n =
      sourceForbiddenBooleanMainTerm q (a % q) H d n := by
  have hw : fixedQLowWeight q a H = fixedQLowWeight q (a % q) H := by
    funext y
    exact fixedQLowWeight_anchor_mod q a H y
  unfold sourceForbiddenBooleanMainTerm
  rw [hw]

noncomputable def sourceForbiddenMainEmptyL1
    (q a H : ℕ) : ℝ :=
  ∑' n : Finset ℕ, |sourceForbiddenBooleanMainTerm q a H ∅ n|

lemma sourceForbiddenMainEmptyL1_anchor_mod
    (q a H : ℕ) :
    sourceForbiddenMainEmptyL1 q a H =
      sourceForbiddenMainEmptyL1 q (a % q) H := by
  unfold sourceForbiddenMainEmptyL1
  apply tsum_congr
  intro n
  rw [sourceForbiddenBooleanMainTerm_anchor_mod q a H ∅ n]

lemma sourceForbiddenMainEmptyL1_nonneg
    (q a H : ℕ) :
    0 ≤ sourceForbiddenMainEmptyL1 q a H := by
  unfold sourceForbiddenMainEmptyL1
  exact tsum_nonneg (fun n => abs_nonneg _)

noncomputable def sourceForbiddenMainSmallHeightUniformBound
    (q H0 : ℕ) : ℝ :=
  ∑ H ∈ Finset.range H0,
    ∑ a ∈ Finset.range q,
      sourceForbiddenMainEmptyL1 q a H

theorem sourceForbiddenMain_abs_l1_smallHeight_uniform
    (q H0 : ℕ) (hq : 0 < q) :
    ∃ B : ℝ, 0 ≤ B ∧
      ∀ A H : ℕ,
        q.Coprime A →
        (¬ 2 ∣ q → 2 ∣ H) →
        0 < H →
        H < H0 →
        (∑' n : Finset ℕ,
          |sourceForbiddenBooleanMainTerm q A H ∅ n|) ≤ B := by
  refine ⟨sourceForbiddenMainSmallHeightUniformBound q H0, ?_, ?_⟩
  · unfold sourceForbiddenMainSmallHeightUniformBound
    apply Finset.sum_nonneg
    intro H hH
    apply Finset.sum_nonneg
    intro a ha
    exact sourceForbiddenMainEmptyL1_nonneg q a H
  · intro A H _hA _h2 _hH hlt
    have hHmem : H ∈ Finset.range H0 := Finset.mem_range.mpr hlt
    have hmodlt : A % q < q := Nat.mod_lt A hq
    have hAmem : A % q ∈ Finset.range q := Finset.mem_range.mpr hmodlt
    change sourceForbiddenMainEmptyL1 q A H ≤
      sourceForbiddenMainSmallHeightUniformBound q H0
    rw [sourceForbiddenMainEmptyL1_anchor_mod q A H]
    unfold sourceForbiddenMainSmallHeightUniformBound
    calc
      sourceForbiddenMainEmptyL1 q (A % q) H ≤
          ∑ a ∈ Finset.range q,
            sourceForbiddenMainEmptyL1 q a H := by
        exact Finset.single_le_sum
          (fun a ha => sourceForbiddenMainEmptyL1_nonneg q a H) hAmem
      _ ≤ ∑ H ∈ Finset.range H0,
          ∑ a ∈ Finset.range q,
            sourceForbiddenMainEmptyL1 q a H := by
        exact Finset.single_le_sum
          (fun H hH => Finset.sum_nonneg (fun a ha =>
            sourceForbiddenMainEmptyL1_nonneg q a H)) hHmem

theorem abs_tsum_dForbiddenBooleanMainTerm_le_emptyL1
    {q A H : ℕ} {d : Finset ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2 : ¬ 2 ∣ q → 2 ∣ H)
    (hdActive : ∀ p ∈ d, activeHighPrime q p) :
    |∑' n : Finset ℕ, dForbiddenBooleanMainTerm q A H d n| ≤
      sourceForbiddenMainEmptyL1 q A H := by
  have hsrcD :=
    summable_sourceForbiddenBooleanMainTerm
      (q := q) (a := A) (H := H) hq hH h2 d
  have hsrc0 :=
    summable_sourceForbiddenBooleanMainTerm
      (q := q) (a := A) (H := H) hq hH h2 ∅
  have hdSum : Summable (dForbiddenBooleanMainTerm q A H d) := by
    exact hsrcD.congr (fun n => by
      symm
      exact dForbiddenBooleanMainTerm_eq_source_signed_of_active hdActive)
  calc
    |∑' n : Finset ℕ, dForbiddenBooleanMainTerm q A H d n|
      ≤ ∑' n : Finset ℕ, |dForbiddenBooleanMainTerm q A H d n| := by
        simpa [Real.norm_eq_abs] using norm_tsum_le_tsum_norm hdSum.norm
    _ = ∑' n : Finset ℕ, |sourceForbiddenBooleanMainTerm q A H d n| := by
        apply tsum_congr
        intro n
        rw [dForbiddenBooleanMainTerm_eq_source_signed_of_active hdActive]
    _ ≤ ∑' n : Finset ℕ, |sourceForbiddenBooleanMainTerm q A H ∅ n| := by
        exact hsrcD.norm.tsum_le_tsum
          (fun n => abs_sourceForbiddenBooleanMainTerm_le_empty)
          hsrc0.norm
    _ = sourceForbiddenMainEmptyL1 q A H := rfl

#print axioms sourceForbiddenMain_abs_l1_smallHeight_uniform
#print axioms abs_tsum_dForbiddenBooleanMainTerm_le_emptyL1

end PaperB.FixedQ
