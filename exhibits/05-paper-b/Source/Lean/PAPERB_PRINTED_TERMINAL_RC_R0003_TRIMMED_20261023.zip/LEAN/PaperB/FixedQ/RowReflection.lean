import PaperB.FixedQ.RowReduction

open scoped BigOperators

namespace PaperB.FixedQ

/-- Reflection of an interior row.  The involution y ↦ H-y swaps the two
divisibility moduli exactly. -/
theorem rowConstrainedMass_reflect
    (lambda : ℕ → ℝ) (H e1 e2 : ℕ) :
    rowConstrainedMass lambda H e1 e2 =
      rowConstrainedMass (fun z => lambda (H - z)) H e2 e1 := by
  rw [rowConstrainedMass_eq_sum_set, rowConstrainedMass_eq_sum_set]
  classical
  apply Finset.sum_bij'
    (fun y _ => H - y)
    (fun z _ => H - z)
  · intro y hy
    have hy' := Finset.mem_filter.mp hy
    have hyI := Finset.mem_Ioo.mp hy'.1
    apply Finset.mem_filter.mpr
    constructor
    · apply Finset.mem_Ioo.mpr
      omega
    · constructor
      · simpa [Nat.sub_sub_self hyI.2.le] using hy'.2.2
      · simpa [Nat.sub_sub_self hyI.2.le] using hy'.2.1
  · intro z hz
    have hz' := Finset.mem_filter.mp hz
    have hzI := Finset.mem_Ioo.mp hz'.1
    apply Finset.mem_filter.mpr
    constructor
    · apply Finset.mem_Ioo.mpr
      omega
    · constructor
      · simpa [Nat.sub_sub_self hzI.2.le] using hz'.2.2
      · simpa [Nat.sub_sub_self hzI.2.le] using hz'.2.1
  · intro y hy
    have hyI := Finset.mem_Ioo.mp (Finset.mem_filter.mp hy).1
    omega
  · intro z hz
    have hzI := Finset.mem_Ioo.mp (Finset.mem_filter.mp hz).1
    omega
  · intro y hy
    have hyI := Finset.mem_Ioo.mp (Finset.mem_filter.mp hy).1
    simp [Nat.sub_sub_self hyI.2.le]

/-- Reflection for row discrepancy when the reflected weight agrees pointwise. -/
theorem rowDiscrepancy_reflect
    (lambda lambdaR : ℕ → ℝ) (H e1 e2 : ℕ)
    (hreflect : ∀ z ∈ Finset.Ioo 0 H, lambda (H - z) = lambdaR z) :
    rowDiscrepancy lambda H e1 e2 =
      rowDiscrepancy lambdaR H e2 e1 := by
  unfold rowDiscrepancy
  have hmass :
      rowConstrainedMass lambda H e1 e2 =
        rowConstrainedMass lambdaR H e2 e1 := by
    rw [rowConstrainedMass_reflect]
    unfold rowConstrainedMass
    apply Finset.sum_congr rfl
    intro z hz
    by_cases hcond : e2 ∣ z ∧ e1 ∣ H - z
    · simp only [hcond, if_true]
      exact hreflect z hz
    · simp only [hcond, if_false]
  have hweightReflect :
      rowWeightMass lambda H =
        rowWeightMass (fun z => lambda (H - z)) H := by
    have htmp := rowConstrainedMass_reflect lambda H 1 1
    simpa [rowConstrainedMass, rowWeightMass] using htmp
  have hweightPointwise :
      rowWeightMass (fun z => lambda (H - z)) H =
        rowWeightMass lambdaR H := by
    unfold rowWeightMass
    apply Finset.sum_congr rfl
    intro z hz
    exact hreflect z hz
  rw [hmass, hweightReflect, hweightPointwise]
  ring

#print axioms rowConstrainedMass_reflect
#print axioms rowDiscrepancy_reflect

end PaperB.FixedQ
