import GoldB.StepThm
import Mathlib.NumberTheory.Bertrand

/-!
# GoldB.Vino — Vinogradov's mean value theorem with a `k`-uniform explicit constant

For `k ≥ 1`, `τ ≥ 0`, `N ≥ 1`:

`J_{kτ,k}(N) ≤ 2^{24k⁴ + 5k²τ + 2kτ²} · N^{2kτ - k(k+1)/2 + Δ_τ}`,
`Δ_τ = (k(k+1)/2)(1 - 1/k)^τ`.
-/

open Finset

namespace GoldB

noncomputable def kap (k : ℕ) : ℝ := (k : ℝ) * (k + 1) / 2
noncomputable def Del (k τ : ℕ) : ℝ := kap k * (1 - 1 / (k : ℝ)) ^ τ
def Dexp (k τ : ℕ) : ℕ := 24 * k ^ 4 + 5 * k ^ 2 * τ + 2 * k * τ ^ 2
noncomputable def Dv (k τ : ℕ) : ℝ := 2 ^ Dexp k τ
noncomputable def Eexp (k τ : ℕ) : ℝ := 2 * k * τ - kap k + Del k τ

lemma kap_nonneg (k : ℕ) : 0 ≤ kap k := by unfold kap; positivity

lemma kap_le_sq (k : ℕ) (hk : 1 ≤ k) : kap k ≤ (k : ℝ) ^ 2 := by
  unfold kap
  have : (1 : ℝ) ≤ k := by exact_mod_cast hk
  nlinarith

lemma base_mem (k : ℕ) (hk : 1 ≤ k) : 0 ≤ 1 - 1 / (k : ℝ) ∧ 1 - 1 / (k : ℝ) ≤ 1 := by
  have : (1 : ℝ) ≤ k := by exact_mod_cast hk
  constructor
  · rw [sub_nonneg, div_le_one (by linarith)]; exact this
  · have : 0 < 1 / (k : ℝ) := by positivity
    linarith

lemma Del_nonneg (k τ : ℕ) (hk : 1 ≤ k) : 0 ≤ Del k τ := by
  unfold Del
  exact mul_nonneg (kap_nonneg k) (pow_nonneg (base_mem k hk).1 _)

lemma Del_le_kap (k τ : ℕ) (hk : 1 ≤ k) : Del k τ ≤ kap k := by
  unfold Del
  have h := base_mem k hk
  calc kap k * (1 - 1 / (k : ℝ)) ^ τ ≤ kap k * 1 :=
        mul_le_mul_of_nonneg_left (pow_le_one₀ h.1 h.2) (kap_nonneg k)
    _ = kap k := mul_one _

lemma Del_succ (k τ : ℕ) : Del k (τ + 1) = Del k τ * (1 - 1 / (k : ℝ)) := by
  unfold Del; rw [pow_succ]; ring

/-- Bernoulli: the saving after `τ` steps is at most `(k+1)τ/2`. -/
lemma kap_sub_Del_le (k τ : ℕ) (hk : 1 ≤ k) : kap k - Del k τ ≤ ((k : ℝ) + 1) * τ / 2 := by
  have hk' : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hb : 1 + (τ : ℝ) * (-(1 / (k : ℝ))) ≤ (1 + (-(1 / (k : ℝ)))) ^ τ :=
    one_add_mul_le_pow (by
      have : 1 / (k : ℝ) ≤ 1 := by rw [div_le_one (by linarith)]; exact hk'
      linarith) τ
  unfold Del
  have e : kap k - kap k * (1 - 1 / (k : ℝ)) ^ τ = kap k * (1 - (1 - 1 / (k : ℝ)) ^ τ) := by ring
  rw [e]
  calc kap k * (1 - (1 - 1 / (k : ℝ)) ^ τ) ≤ kap k * ((τ : ℝ) * (1 / (k : ℝ))) := by
        apply mul_le_mul_of_nonneg_left _ (kap_nonneg k)
        rw [show 1 + -(1 / (k : ℝ)) = 1 - 1 / (k : ℝ) by ring] at hb
        linarith
    _ = ((k : ℝ) + 1) * τ / 2 := by unfold kap; field_simp

lemma Eexp_nonneg (k τ : ℕ) (hk : 1 ≤ k) : 0 ≤ Eexp k τ := by
  unfold Eexp
  have := kap_sub_Del_le k τ hk
  have hk' : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have : 0 ≤ (τ : ℝ) := by positivity
  nlinarith

lemma Eexp_succ_sub (k τ : ℕ) (hk : 2 ≤ k) :
    (k : ℝ) * (τ + 1) / 4 ≤ Eexp k (τ + 1) - k * (τ + 1) := by
  unfold Eexp
  have := kap_sub_Del_le k (τ + 1) (by omega)
  have hk' : (2 : ℝ) ≤ k := by exact_mod_cast hk
  push_cast at this ⊢
  have : 0 ≤ (τ : ℝ) := by positivity
  nlinarith

lemma Eexp_le_twoT (k τ : ℕ) (hk : 1 ≤ k) : Eexp k τ ≤ 2 * (k * τ : ℝ) := by
  unfold Eexp
  have := Del_le_kap k τ hk
  linarith

lemma factorial_le_two_pow_sq (k : ℕ) : (k.factorial : ℝ) ≤ 2 ^ (k ^ 2) := by
  have h1 : k.factorial ≤ k ^ k := Nat.factorial_le_pow k
  have h2 : k ^ k ≤ (2 ^ k) ^ k := Nat.pow_le_pow_left (Nat.lt_two_pow_self).le k
  have : k.factorial ≤ 2 ^ (k ^ 2) := by
    calc k.factorial ≤ (2 ^ k) ^ k := h1.trans h2
      _ = 2 ^ (k ^ 2) := by rw [← pow_mul, sq]
  exact_mod_cast this

/-- the threshold below which the trivial bound is used -/
def N0 (k : ℕ) : ℕ := 16 * (8 * k ^ 2) ^ (4 * k)

lemma N0_le (k : ℕ) (hk : 1 ≤ k) : N0 k ≤ 2 ^ (24 * k ^ 2) := by
  unfold N0
  have h1 : k ^ 2 ≤ 2 ^ (2 * k) := by
    rw [pow_mul, show (2:ℕ) ^ 2 = 4 by norm_num]
    calc k ^ 2 ≤ (2 ^ k) ^ 2 := Nat.pow_le_pow_left (Nat.lt_two_pow_self).le 2
      _ = 4 ^ k := by rw [← pow_mul, mul_comm, pow_mul]; norm_num
  have h2 : 8 * k ^ 2 ≤ 2 ^ (3 + 2 * k) := by
    rw [pow_add]; norm_num; exact h1
  calc 16 * (8 * k ^ 2) ^ (4 * k) ≤ 2 ^ 4 * (2 ^ (3 + 2 * k)) ^ (4 * k) := by
        gcongr; norm_num
    _ = 2 ^ (4 + (3 + 2 * k) * (4 * k)) := by rw [← pow_mul, ← pow_add]
    _ ≤ 2 ^ (24 * k ^ 2) := by
        apply Nat.pow_le_pow_right (by norm_num)
        nlinarith

lemma N0_pow_le (k : ℕ) (hk : 1 ≤ k) : ((N0 k : ℝ)) ^ (k ^ 2) ≤ 2 ^ (24 * k ^ 4) := by
  have := N0_le k hk
  have h : (N0 k : ℝ) ≤ 2 ^ (24 * k ^ 2) := by exact_mod_cast this
  calc (N0 k : ℝ) ^ (k ^ 2) ≤ ((2 : ℝ) ^ (24 * k ^ 2)) ^ (k ^ 2) :=
        pow_le_pow_left₀ (by positivity) h _
    _ = 2 ^ (24 * k ^ 4) := by rw [← pow_mul]; ring_nf

/-- the degree-one case -/
lemma vmvt_one (τ N : ℕ) (hN : 1 ≤ N) :
    (Jc 1 (1 * τ) (Icc (1 : ℤ) N) : ℝ) ≤ Dv 1 τ * (N : ℝ) ^ (Eexp 1 τ) := by
  have hD : (1 : ℝ) ≤ Dv 1 τ := by unfold Dv; exact one_le_pow₀ (by norm_num)
  have hN' : (1 : ℝ) ≤ N := by exact_mod_cast hN
  rcases Nat.eq_zero_or_pos τ with h0 | hpos
  · subst h0
    simp only [mul_zero, Jc_zero, Nat.cast_one]
    have : Eexp 1 0 = 0 := by unfold Eexp Del kap; norm_num
    rw [this, Real.rpow_zero, mul_one]; exact hD
  · have e : Eexp 1 τ = ((2 * τ - 1 : ℕ) : ℝ) := by
      unfold Eexp Del kap
      rw [Nat.cast_sub (by omega)]
      simp [zero_pow hpos.ne']
    rw [e, Real.rpow_natCast, one_mul]
    have := Jc_deg_one τ hpos (Icc (1 : ℤ) N)
    rw [Int.card_Icc] at this
    have hc : ((N : ℤ) + 1 - 1).toNat = N := by omega
    rw [hc] at this
    calc (Jc 1 τ (Icc (1 : ℤ) N) : ℝ) ≤ (N : ℝ) ^ (2 * τ - 1) := by exact_mod_cast this
      _ ≤ Dv 1 τ * (N : ℝ) ^ (2 * τ - 1) := le_mul_of_one_le_left (by positivity) hD

end GoldB
