import PaperB.FixedQ.H2BooleanFourierCRT
import Mathlib.Algebra.Group.Pi.Units
import Mathlib.Algebra.GroupWithZero.Units.Fintype
import Mathlib.Data.ZMod.QuotientRing

open scoped BigOperators
open Function

namespace PaperB.FixedQ

noncomputable instance h2FintypeZModUnits (n : ℕ) [NeZero n] :
    Fintype (ZMod n)ˣ :=
  Fintype.ofEquiv
    {x : ZMod n // Nat.Coprime x.val n}
    ZMod.unitsEquivCoprime.symm

noncomputable def h2BooleanRingCRTEquiv
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime) :
    ZMod (primeSetProduct S) ≃+* (∀ p : S, ZMod (p : ℕ)) := by
  have hcop : Pairwise (Nat.Coprime on (fun p : S => (p : ℕ))) := by
    intro p q hpq
    exact (Nat.coprime_primes (hPrime p p.property) (hPrime q q.property)).2 (by
      intro h
      apply hpq
      exact Subtype.ext h)
  have hprod : primeSetProduct S = (∏ p : S, (p : ℕ)) := by
    rw [Finset.prod_coe_sort S (fun p : ℕ => p)]
    rfl
  exact (ZMod.ringEquivCongr hprod).trans
    (ZMod.prodEquivPi (fun p : S => (p : ℕ)) hcop)

noncomputable def h2BooleanUnitsCRTEquiv
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime) :
    (ZMod (primeSetProduct S))ˣ ≃*
      (∀ p : S, (ZMod (p : ℕ))ˣ) :=
  (Units.mapEquiv
    (h2BooleanRingCRTEquiv S hPrime).toMulEquiv).trans
      MulEquiv.piUnits

lemma h2BooleanUnitsCRTEquiv_bijective
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime) :
    Function.Bijective (h2BooleanUnitsCRTEquiv S hPrime) :=
  (h2BooleanUnitsCRTEquiv S hPrime).bijective



lemma h2BooleanRingCRTEquiv_apply
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (x : ZMod (primeSetProduct S)) (q : S) :
    h2BooleanRingCRTEquiv S hPrime x q =
      ZMod.castHom
        (by
          unfold primeSetProduct
          exact Finset.dvd_prod_of_mem (fun p => p) q.property)
        (ZMod (q : ℕ)) x := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  letI : NeZero (q : ℕ) :=
    ⟨(hPrime q q.property).ne_zero⟩
  let hcop : Pairwise (Nat.Coprime on (fun p : S => (p : ℕ))) := by
    intro p r hpr
    exact (Nat.coprime_primes (hPrime p p.property) (hPrime r r.property)).2 (by
      intro h
      apply hpr
      exact Subtype.ext h)
  let hprod : primeSetProduct S = (∏ p : S, (p : ℕ)) := by
    rw [Finset.prod_coe_sort S (fun p : ℕ => p)]
    rfl
  letI : NeZero (∏ p : S, (p : ℕ)) := ⟨by
    intro hz
    exact (primeSetProduct_pos hPrime).ne' (hprod.trans hz)⟩
  change
    ((ZMod.ringEquivCongr hprod).trans
      (ZMod.prodEquivPi (fun p : S => (p : ℕ)) hcop)) x q =
      _
  simp only [RingEquiv.trans_apply]
  rw [ZMod.prodEquivPi_apply]
  simp only [ZMod.castHom_apply, ZMod.cast_eq_val]
  rw [ZMod.ringEquivCongr_val]

#print axioms h2BooleanRingCRTEquiv_apply

#print axioms h2BooleanUnitsCRTEquiv_bijective


lemma h2Boolean_sum_units_prod_local
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    [∀ p : S, NeZero (p : ℕ)]
    (F : ∀ p : S, (ZMod (p : ℕ))ˣ → ℝ) :
    (∑ u : (ZMod (primeSetProduct S))ˣ,
      ∏ p : S, F p ((h2BooleanUnitsCRTEquiv S hPrime u) p)) =
      ∏ p : S, ∑ a : (ZMod (p : ℕ))ˣ, F p a := by
  let e := h2BooleanUnitsCRTEquiv S hPrime
  rw [Fintype.sum_equiv e.toEquiv
      (fun u : (ZMod (primeSetProduct S))ˣ =>
        ∏ p : S, F p ((e u) p))
      (fun v : ∀ p : S, (ZMod (p : ℕ))ˣ =>
        ∏ p : S, F p (v p))]
  · exact (Fintype.prod_sum F).symm
  · intro u
    rfl

#print axioms h2Boolean_sum_units_prod_local


lemma h2BooleanRingCRTEquiv_primeBasis_self
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    {p : ℕ} (hpS : p ∈ S) :
    h2BooleanRingCRTEquiv S hPrime
      (h2BooleanPrimeBasis S p : ZMod (primeSetProduct S))
      ⟨p, hpS⟩ = 1 := by
  rw [h2BooleanRingCRTEquiv_apply]
  simp only [map_natCast]
  unfold h2BooleanPrimeBasis
  rw [fixedProductCRTIdempotentNat_mod_prime_eq_bit
    (Finset.sdiff_subset) hPrime hpS]
  simp

lemma h2BooleanUnitsCRTEquiv_val
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ) (q : S) :
    (((h2BooleanUnitsCRTEquiv S hPrime u) q : (ZMod (q : ℕ))ˣ) :
      ZMod (q : ℕ)) =
      h2BooleanRingCRTEquiv S hPrime
        (u : ZMod (primeSetProduct S)) q := by
  rfl

#print axioms h2BooleanRingCRTEquiv_primeBasis_self
#print axioms h2BooleanUnitsCRTEquiv_val


lemma h2BooleanRingCRTEquiv_primeBasis
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (q : S) :
    h2BooleanRingCRTEquiv S hPrime
      (h2BooleanPrimeBasis S q.1 : ZMod (primeSetProduct S)) =
      Pi.single q 1 := by
  ext r
  rw [h2BooleanRingCRTEquiv_apply]
  simp only [map_natCast]
  unfold h2BooleanPrimeBasis
  rw [fixedProductCRTIdempotentNat_mod_prime_eq_bit
    (Finset.sdiff_subset) hPrime r.property]
  by_cases hrq : r = q
  · subst r
    simp
  · have hrqv : r.1 ≠ q.1 := by
      intro h
      apply hrq
      exact Subtype.ext h
    have hrmem : r.1 ∈ S \ {q.1} := by
      simp [r.property, hrqv]
    simp [hrmem, Pi.single, hrq]

noncomputable def h2BooleanPrimeComponentEmbedding
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (q : S) :
    ZMod (q : ℕ) →+ ZMod (primeSetProduct S) :=
  (h2BooleanRingCRTEquiv S hPrime).symm.toAddEquiv.toAddMonoidHom.comp
    (AddMonoidHom.single (fun r : S => ZMod (r : ℕ)) q)

lemma h2BooleanPrimeComponentEmbedding_one
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (q : S) :
    h2BooleanPrimeComponentEmbedding S hPrime q 1 =
      (h2BooleanPrimeBasis S q.1 : ZMod (primeSetProduct S)) := by
  apply (h2BooleanRingCRTEquiv S hPrime).injective
  have hemb :
      h2BooleanRingCRTEquiv S hPrime
        (h2BooleanPrimeComponentEmbedding S hPrime q 1) =
        Pi.single q 1 := by
    simp [h2BooleanPrimeComponentEmbedding]
  rw [hemb, h2BooleanRingCRTEquiv_primeBasis]

#print axioms h2BooleanRingCRTEquiv_primeBasis
#print axioms h2BooleanPrimeComponentEmbedding_one

end PaperB.FixedQ
