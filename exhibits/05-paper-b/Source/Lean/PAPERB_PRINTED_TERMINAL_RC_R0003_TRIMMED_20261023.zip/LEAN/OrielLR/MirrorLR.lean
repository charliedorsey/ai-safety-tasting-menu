import OrielUpper.Mirror

/-!
# Oriel L/R — further verbatim mirrors (Left/Right regions, actual cutoff)

* `ScratchVirelleR0037FourRegionGate.lean` — `virelleR0037Left`, `virelleR0037Right`
* `PaperB/FixedQ/H2BooleanParameters.lean` — `h2BooleanSigma`
* `PaperB/FixedQ/H2BooleanGlobalSourceSplit.lean` — `h2BooleanSourceCutoff`
* `PaperB/FixedQ/GlobalProperProductSplit.lean` — `globalProperBooleanBlockCount`,
  `globalProperBooleanProductCutoff`
-/

section R0037LR
open scoped BigOperators Classical
namespace OrielUpper.Mirror

def virelleR0037Left (h H r s : ℕ) : Prop :=
  elarinR0031VKLowProduct h H r s ∧ r ^ 2 < s

def virelleR0037Right (h H r s : ℕ) : Prop :=
  elarinR0031VKLowProduct h H r s ∧ s ^ 2 < r

end OrielUpper.Mirror
end R0037LR

section H2Params
namespace OrielUpper.Mirror

noncomputable def h2BooleanSigma : ℝ := 2 / 3 + 1 / 100

end OrielUpper.Mirror
end H2Params

section H2Split
open scoped BigOperators
open Filter Real Asymptotics
namespace OrielUpper.Mirror

noncomputable def h2BooleanSourceCutoff (H : ℕ) : ℕ :=
  ⌊(Real.log (H : ℝ)) ^ h2BooleanSigma⌋₊

end OrielUpper.Mirror
end H2Split

section GPSplit
open Filter Real Asymptotics
open scoped BigOperators
namespace OrielUpper.Mirror

noncomputable def globalProperBooleanBlockCount (h : ℕ) : ℕ :=
  20 * (h2BooleanSourceCutoff h + 1)

noncomputable def globalProperBooleanProductCutoff (h : ℕ) : ℕ :=
  2 ^ globalProperBooleanBlockCount h

end OrielUpper.Mirror
end GPSplit
