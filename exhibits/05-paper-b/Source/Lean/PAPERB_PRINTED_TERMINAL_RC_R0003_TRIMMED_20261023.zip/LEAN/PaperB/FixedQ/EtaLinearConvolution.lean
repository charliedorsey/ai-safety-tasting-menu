import PaperB.FixedQ.PetermannConvolutionGlobal

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def etaArithmetic (q : ℕ) : ArithmeticFunction ℝ :=
  petermannSupportedArithmetic q petermannB

@[simp] theorem etaArithmetic_apply (q n : ℕ) :
    etaArithmetic q n = etaCoeff q n := by
  simp [etaArithmetic, petermannSupportedArithmetic,
    petermannSupportedCoeff, etaCoeff, petermannB]

theorem etaArithmetic_multiplicative (q : ℕ) :
    (etaArithmetic q).IsMultiplicative :=
  petermannSupportedArithmetic_multiplicative q petermannB

noncomputable def coprimeIndicatorCoeff (q n : ℕ) : ℝ :=
  if n = 0 then 0 else if n.Coprime (6 * q) then 1 else 0

noncomputable def coprimeIndicatorArithmetic (q : ℕ) : ArithmeticFunction ℝ :=
  ⟨coprimeIndicatorCoeff q, by simp [coprimeIndicatorCoeff]⟩

@[simp] theorem coprimeIndicatorArithmetic_apply (q n : ℕ) :
    coprimeIndicatorArithmetic q n = coprimeIndicatorCoeff q n := rfl

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem coprimeIndicatorArithmetic_multiplicative (q : ℕ) :
    (coprimeIndicatorArithmetic q).IsMultiplicative := by
  constructor
  · simp [coprimeIndicatorArithmetic, coprimeIndicatorCoeff]
  · intro m n hcop
    change coprimeIndicatorCoeff q (m * n) =
      coprimeIndicatorCoeff q m * coprimeIndicatorCoeff q n
    by_cases hm0 : m = 0
    · subst m
      have hn1 : n = 1 := by simpa using hcop
      subst n
      simp [coprimeIndicatorCoeff]
    · by_cases hn0 : n = 0
      · subst n
        have hm1 : m = 1 := by simpa using hcop
        subst m
        simp [coprimeIndicatorCoeff]
      · by_cases hm : m.Coprime (6 * q)
        · by_cases hn : n.Coprime (6 * q)
          · have hmn : (m * n).Coprime (6 * q) :=
              Nat.coprime_mul_iff_left.mpr ⟨hm, hn⟩
            rw [coprimeIndicatorCoeff, if_neg (mul_ne_zero hm0 hn0),
              if_pos hmn, coprimeIndicatorCoeff, if_neg hm0, if_pos hm,
              coprimeIndicatorCoeff, if_neg hn0, if_pos hn]
            norm_num
          · have hmn : ¬ (m * n).Coprime (6 * q) := by
              intro h
              exact hn (Nat.coprime_mul_iff_left.mp h).2
            rw [coprimeIndicatorCoeff, if_neg (mul_ne_zero hm0 hn0),
              if_neg hmn, coprimeIndicatorCoeff, if_neg hm0, if_pos hm,
              coprimeIndicatorCoeff, if_neg hn0, if_neg hn]
            norm_num
        · have hmn : ¬ (m * n).Coprime (6 * q) := by
            intro h
            exact hm (Nat.coprime_mul_iff_left.mp h).1
          rw [coprimeIndicatorCoeff, if_neg (mul_ne_zero hm0 hn0),
            if_neg hmn, coprimeIndicatorCoeff, if_neg hm0, if_neg hm]
          norm_num

noncomputable def etaLinearArithmetic (q : ℕ) : ArithmeticFunction ℝ :=
  ⟨fun n => (n : ℝ) * etaCoeff q n, by simp⟩

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem etaLinearArithmetic_multiplicative (q : ℕ) :
    (etaLinearArithmetic q).IsMultiplicative := by
  constructor
  · simp [etaLinearArithmetic, etaCoeff]
  · intro m n hcop
    change (((m * n : ℕ) : ℝ) * etaCoeff q (m * n)) =
      ((m : ℝ) * etaCoeff q m) * ((n : ℝ) * etaCoeff q n)
    have heta :=
      (etaArithmetic_multiplicative q).map_mul_of_coprime hcop
    simp only [etaArithmetic_apply] at heta
    rw [Nat.cast_mul, heta]
    ring

noncomputable def etaLinearCorrectionLocal
    (q p nu : ℕ) : ℝ :=
  if nu = 0 then 1
  else if p.Prime ∧ p.Coprime (6 * q) then
    if nu = 1 then 2 / ((p : ℝ) - 2)
    else if nu = 2 then -(p : ℝ) / ((p : ℝ) - 2)
    else 0
  else 0

noncomputable def etaLinearCorrectionCoeff
    (q n : ℕ) : ℝ :=
  if n = 0 then 0
  else ∏ p ∈ n.primeFactors,
    etaLinearCorrectionLocal q p (n.factorization p)

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def etaLinearCorrectionArithmetic
    (q : ℕ) : ArithmeticFunction ℝ :=
  ⟨etaLinearCorrectionCoeff q, by simp [etaLinearCorrectionCoeff]⟩

@[simp] theorem etaLinearCorrectionArithmetic_apply (q n : ℕ) :
    etaLinearCorrectionArithmetic q n = etaLinearCorrectionCoeff q n := rfl

theorem etaLinearCorrectionArithmetic_multiplicative (q : ℕ) :
    (etaLinearCorrectionArithmetic q).IsMultiplicative := by
  constructor
  · change etaLinearCorrectionCoeff q 1 = 1
    simp [etaLinearCorrectionCoeff]
  · intro m n hcop
    change etaLinearCorrectionCoeff q (m * n) =
      etaLinearCorrectionCoeff q m * etaLinearCorrectionCoeff q n
    by_cases hm0 : m = 0
    · subst m
      have hn1 : n = 1 := by simpa using hcop
      subst n
      simp [etaLinearCorrectionCoeff]
    · by_cases hn0 : n = 0
      · subst n
        have hm1 : m = 1 := by simpa using hcop
        subst m
        simp [etaLinearCorrectionCoeff]
      · have hmn0 : m * n ≠ 0 := mul_ne_zero hm0 hn0
        have hpf : (m * n).primeFactors =
            m.primeFactors ∪ n.primeFactors :=
          Nat.primeFactors_mul hm0 hn0
        have hdisj : Disjoint m.primeFactors n.primeFactors := by
          rw [Finset.disjoint_left]
          intro p hpm hpn
          have hpd : p ∣ m.gcd n :=
            Nat.dvd_gcd (Nat.dvd_of_mem_primeFactors hpm)
              (Nat.dvd_of_mem_primeFactors hpn)
          rw [hcop.gcd_eq_one] at hpd
          exact (Nat.prime_of_mem_primeFactors hpm).not_dvd_one hpd

        rw [etaLinearCorrectionCoeff, if_neg hmn0,
          etaLinearCorrectionCoeff, if_neg hm0,
          etaLinearCorrectionCoeff, if_neg hn0, hpf,
          Finset.prod_union hdisj]
        congr 1
        · apply Finset.prod_congr rfl
          intro p hp
          have hpL : p ∈ m.primeFactorsList :=
            Nat.mem_primeFactors_iff_mem_primeFactorsList.mp hp
          rw [Nat.factorization_eq_of_coprime_left hcop hpL]
        · apply Finset.prod_congr rfl
          intro p hp
          have hpL : p ∈ n.primeFactorsList :=
            Nat.mem_primeFactors_iff_mem_primeFactorsList.mp hp
          rw [Nat.factorization_eq_of_coprime_right hcop hpL]

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem coprimeIndicatorArithmetic_prime_pow
    (q : ℕ) {p i : ℕ} (hp : p.Prime) :
    coprimeIndicatorArithmetic q (p ^ i) =
      if i = 0 then 1
      else if p.Coprime (6 * q) then 1 else 0 := by
  by_cases hi0 : i = 0
  · subst i
    simp [coprimeIndicatorArithmetic, coprimeIndicatorCoeff]
  · have hp0 : p ^ i ≠ 0 := pow_ne_zero _ hp.ne_zero
    rw [if_neg hi0]
    change coprimeIndicatorCoeff q (p ^ i) =
      if p.Coprime (6 * q) then 1 else 0
    by_cases hcop : p.Coprime (6 * q)
    · have hpow : (p ^ i).Coprime (6 * q) := hcop.pow_left i
      rw [coprimeIndicatorCoeff, if_neg hp0, if_pos hpow, if_pos hcop]
    · have hnot : ¬ (p ^ i).Coprime (6 * q) := by
        intro h
        exact hcop (h.coprime_dvd_left (dvd_pow_self p hi0))
      rw [coprimeIndicatorCoeff, if_neg hp0, if_neg hnot, if_neg hcop]

theorem etaLinearArithmetic_prime_pow
    (q : ℕ) {p i : ℕ} (hp : p.Prime) :
    etaLinearArithmetic q (p ^ i) =
      if i = 0 then 1
      else if i = 1 ∧ p.Coprime (6 * q) then
        (p : ℝ) / ((p : ℝ) - 2)
      else 0 := by
  by_cases hi0 : i = 0
  · subst i
    simp [etaLinearArithmetic, etaCoeff]
  · by_cases hi1 : i = 1
    · subst i
      by_cases hcop : p.Coprime (6 * q)
      · simp [etaLinearArithmetic, etaCoeff, hp, hp.ne_zero,
          hp.squarefree, hcop, div_eq_mul_inv]
      · simp [etaLinearArithmetic, etaCoeff, hp, hp.ne_zero,
          hp.squarefree, hcop]
    · have hsq : ¬ Squarefree (p ^ i) := by
        rw [Nat.squarefree_pow_iff hp.ne_one hi0]
        simp [hi1]
      have hp0 : p ^ i ≠ 0 := pow_ne_zero _ hp.ne_zero
      simp [etaLinearArithmetic, etaCoeff, hi0, hi1, hsq, hp0]

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem etaLinearCorrectionArithmetic_prime_pow
    (q : ℕ) {p i : ℕ} (hp : p.Prime) :
    etaLinearCorrectionArithmetic q (p ^ i) =
      etaLinearCorrectionLocal q p i := by
  by_cases hi0 : i = 0
  · subst i
    simp [etaLinearCorrectionArithmetic, etaLinearCorrectionCoeff,
      etaLinearCorrectionLocal]
  · have hp0 : p ^ i ≠ 0 := pow_ne_zero _ hp.ne_zero
    rw [etaLinearCorrectionArithmetic_apply,
      etaLinearCorrectionCoeff, if_neg hp0,
      Nat.primeFactors_prime_pow hi0 hp]
    simp [etaLinearCorrectionLocal, hp, hi0]

private lemma sum_range_zero_two
    (a b : ℝ) (f : ℕ → ℝ) :
    ∀ i : ℕ,
      (∑ j ∈ Finset.range (i + 1),
        (if j = 0 then 1
         else if j = 1 then a
         else if j = 2 then b
         else 0) * f j) =
      if i = 0 then f 0
      else if i = 1 then f 0 + a * f 1
      else f 0 + a * f 1 + b * f 2 := by
  intro i
  induction i with
  | zero => simp
  | succ i ih =>
      rw [Finset.sum_range_succ, ih]
      cases i with
      | zero => simp
      | succ k =>
          cases k with
          | zero => simp
          | succ t =>
              have h0 : Nat.succ (Nat.succ (Nat.succ t)) ≠ 0 := by omega
              have h1 : Nat.succ (Nat.succ (Nat.succ t)) ≠ 1 := by omega
              have h2 : Nat.succ (Nat.succ (Nat.succ t)) ≠ 2 := by omega
              simp [h0, h1, h2]

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem etaLinearCorrection_mul_coprime_prime_pow
    (q : ℕ) {p i : ℕ} (hp : p.Prime) :
    (etaLinearCorrectionArithmetic q * coprimeIndicatorArithmetic q) (p ^ i) =
      etaLinearArithmetic q (p ^ i) := by
  rw [ArithmeticFunction.mul_apply,
    Nat.sum_divisorsAntidiagonal
      (fun a b =>
        etaLinearCorrectionArithmetic q a *
          coprimeIndicatorArithmetic q b),
    Nat.sum_divisors_prime_pow hp]
  have hdiv :
      ∀ j ∈ Finset.range (i + 1), p ^ i / p ^ j = p ^ (i - j) := by
    intro j hj
    have hji : j ≤ i := by
      simpa [Finset.mem_range] using hj
    have hpow : p ^ j * p ^ (i - j) = p ^ i :=
      pow_mul_pow_sub p hji
    rw [← hpow]
    exact Nat.mul_div_cancel_left _ (pow_pos hp.pos _)
  have hsum :
      (∑ j ∈ Finset.range (i + 1),
        etaLinearCorrectionArithmetic q (p ^ j) *
          coprimeIndicatorArithmetic q (p ^ i / p ^ j)) =
      ∑ j ∈ Finset.range (i + 1),
        etaLinearCorrectionLocal q p j *
          coprimeIndicatorArithmetic q (p ^ (i - j)) := by
    apply Finset.sum_congr rfl
    intro j hj
    rw [etaLinearCorrectionArithmetic_prime_pow q hp, hdiv j hj]
  rw [hsum]

  by_cases hcop : p.Coprime (6 * q)
  · have hcorr : ∀ j : ℕ,
        etaLinearCorrectionLocal q p j =
          if j = 0 then 1
          else if j = 1 then 2 / ((p : ℝ) - 2)
          else if j = 2 then -(p : ℝ) / ((p : ℝ) - 2)
          else 0 := by
      intro j
      by_cases hj0 : j = 0
      · simp [etaLinearCorrectionLocal, hj0]
      · rw [etaLinearCorrectionLocal, if_neg hj0]
        rw [if_pos ⟨hp, hcop⟩]
        simp [hj0]
    have hbase : ∀ j : ℕ,
        coprimeIndicatorArithmetic q (p ^ (i - j)) = 1 := by
      intro j
      rw [coprimeIndicatorArithmetic_prime_pow q hp]
      by_cases hz : i - j = 0
      · simp [hz]
      · simp [hz, hcop]
    simp_rw [hcorr, hbase]
    rw [sum_range_zero_two
      (2 / ((p : ℝ) - 2))
      (-(p : ℝ) / ((p : ℝ) - 2))
      (fun _ => (1 : ℝ)) i]
    rw [etaLinearArithmetic_prime_pow q hp]
    have hp2 : p ≠ 2 := by
      intro heq
      subst p
      have hd : 2 ∣ Nat.gcd 2 (6 * q) :=
        Nat.dvd_gcd (by norm_num)
          (dvd_mul_of_dvd_left (by norm_num : 2 ∣ 6) q)
      rw [hcop.gcd_eq_one] at hd
      norm_num at hd
    have hp2R : (p : ℝ) - 2 ≠ 0 := by
      exact sub_ne_zero.mpr (by exact_mod_cast hp2)
    by_cases hi0 : i = 0
    · subst i
      simp
    · by_cases hi1 : i = 1
      · have hcond : i = 1 ∧ p.Coprime (6 * q) := ⟨hi1, hcop⟩
        rw [if_neg hi0, if_pos hi1, if_neg hi0, if_pos hcond]
        field_simp [hp2R]
        ring
      · have hcond : ¬ (i = 1 ∧ p.Coprime (6 * q)) := by
          intro h
          exact hi1 h.1
        rw [if_neg hi0, if_neg hi1, if_neg hi0, if_neg hcond]
        field_simp [hp2R]
        ring

  · have hcorr : ∀ j : ℕ,
        etaLinearCorrectionLocal q p j =
          if j = 0 then 1 else 0 := by
      intro j
      simp [etaLinearCorrectionLocal, hp, hcop]
    simp_rw [hcorr]
    have hzero :
        (∑ j ∈ Finset.range (i + 1),
          (if j = 0 then 1 else 0) *
            coprimeIndicatorArithmetic q (p ^ (i - j))) =
          coprimeIndicatorArithmetic q (p ^ i) := by
      calc
        (∑ j ∈ Finset.range (i + 1),
          (if j = 0 then 1 else 0) *
            coprimeIndicatorArithmetic q (p ^ (i - j))) =
            (if 0 = 0 then 1 else 0) *
              coprimeIndicatorArithmetic q (p ^ (i - 0)) := by
                apply Finset.sum_eq_single 0
                · intro b hb hb0
                  simp [hb0]
                · simp
        _ = coprimeIndicatorArithmetic q (p ^ i) := by simp
    rw [hzero, coprimeIndicatorArithmetic_prime_pow q hp,
      etaLinearArithmetic_prime_pow q hp]
    by_cases hi0 : i = 0
    · simp [hi0]
    · simp [hi0, hcop]

theorem etaLinearArithmetic_eq_correction_mul_coprime (q : ℕ) :
    etaLinearArithmetic q =
      etaLinearCorrectionArithmetic q * coprimeIndicatorArithmetic q := by
  apply (ArithmeticFunction.IsMultiplicative.eq_iff_eq_on_prime_powers
    (etaLinearArithmetic q)
    (etaLinearArithmetic_multiplicative q)
    (etaLinearCorrectionArithmetic q * coprimeIndicatorArithmetic q)
    ((etaLinearCorrectionArithmetic_multiplicative q).mul
      (coprimeIndicatorArithmetic_multiplicative q))).2
  intro p i hp
  exact (etaLinearCorrection_mul_coprime_prime_pow q hp).symm

#print axioms etaLinearCorrection_mul_coprime_prime_pow
#print axioms etaLinearArithmetic_eq_correction_mul_coprime

end PaperB.FixedQ
