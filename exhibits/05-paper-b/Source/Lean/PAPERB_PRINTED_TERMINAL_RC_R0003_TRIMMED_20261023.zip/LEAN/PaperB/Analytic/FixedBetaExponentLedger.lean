import PaperB.Analytic.ReciprocalFiniteOrderNatIcc

namespace PaperB.Analytic

open Real

lemma fixedBeta_denominator_pos
    {k : ℕ} (hk : 2 ≤ k) :
    0 < (2 : ℝ)^k - 2 := by
  have hpow : (4 : ℝ) ≤ (2 : ℝ)^k := by
    have hmono := pow_le_pow_right₀ (a := (2 : ℝ)) (by norm_num) hk
    norm_num at hmono ⊢
    exact hmono
  linarith

noncomputable def fixedBetaFirstExponent (beta : ℝ) (k : ℕ) : ℝ :=
  1 + (beta⁻¹ - (k + 1 : ℝ)) / ((2 : ℝ)^k - 2)

noncomputable def fixedBetaSecondExponent (beta : ℝ) (k : ℕ) : ℝ :=
  1 - 4 / (2 : ℝ)^k -
    (beta⁻¹ - (k + 1 : ℝ)) / ((2 : ℝ)^k - 2)

lemma fixedBeta_first_exponent_lt_one
    {beta : ℝ} {k : ℕ}
    (hk : 2 ≤ k)
    (horder : beta⁻¹ < (k + 1 : ℝ)) :
    fixedBetaFirstExponent beta k < 1 := by
  rw [fixedBetaFirstExponent]
  have hden := fixedBeta_denominator_pos hk
  have hnum : beta⁻¹ - (k + 1 : ℝ) < 0 := sub_neg.mpr horder
  have hquot : (beta⁻¹ - (k + 1 : ℝ)) / ((2 : ℝ)^k - 2) < 0 :=
    div_neg_of_neg_of_pos hnum hden
  linarith

lemma fixedBeta_second_exponent_lt_one
    {beta : ℝ} {k : ℕ}
    (hk : 2 ≤ k)
    (hwindow :
      (k + 1 : ℝ) - beta⁻¹ <
        4 - 8 / (2 : ℝ)^k) :
    fixedBetaSecondExponent beta k < 1 := by
  rw [fixedBetaSecondExponent]
  have hden := fixedBeta_denominator_pos hk
  have hpow : 0 < (2 : ℝ)^k := by positivity
  have hid :
      (4 / (2 : ℝ)^k) * ((2 : ℝ)^k - 2) =
        4 - 8 / (2 : ℝ)^k := by
    field_simp [ne_of_gt hpow]
    ring
  have htarget :
      ((k + 1 : ℝ) - beta⁻¹) / ((2 : ℝ)^k - 2) <
        4 / (2 : ℝ)^k := by
    rw [div_lt_iff₀ hden]
    rw [hid]
    exact hwindow
  have hre :
      -(beta⁻¹ - (k + 1 : ℝ)) / ((2 : ℝ)^k - 2) <
        4 / (2 : ℝ)^k := by
    convert htarget using 1 <;> ring
  have hre' :
      -((beta⁻¹ - (k + 1 : ℝ)) / ((2 : ℝ)^k - 2)) <
        4 / (2 : ℝ)^k := by
    convert hre using 1 <;> ring
  linarith

theorem fixedBeta_exponent_ledger
    {beta : ℝ} {k : ℕ}
    (hk : 2 ≤ k)
    (horder : beta⁻¹ < (k + 1 : ℝ))
    (hwindow :
      (k + 1 : ℝ) - beta⁻¹ <
        4 - 8 / (2 : ℝ)^k) :
    fixedBetaFirstExponent beta k < 1 ∧
      fixedBetaSecondExponent beta k < 1 :=
  ⟨fixedBeta_first_exponent_lt_one hk horder,
    fixedBeta_second_exponent_lt_one hk hwindow⟩

#print axioms fixedBeta_exponent_ledger

end PaperB.Analytic
