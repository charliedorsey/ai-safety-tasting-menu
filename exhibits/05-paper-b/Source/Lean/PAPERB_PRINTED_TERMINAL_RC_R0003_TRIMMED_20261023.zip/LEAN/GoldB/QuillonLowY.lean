import GoldB.Suzuki
import GoldC.VKRegimes

/-!
# `GoldB.QuillonLowY`: the low-`Y` branch, and `ShiftedSuzukiCore` without hypotheses

Written by Quillon for Hunt B R0001. No axiom, no `sorry`.

* `quillon_shifted_lowY : ShiftedSuzukiLowY`. If `N ≥ 4096` and
  `log Y < (3/2)(log N + log 2)`, then `Y < (2N)^{3/2} ≤ N²/2`. The reciprocal phase
  `Y/(m+ϑ)` over `N < m ≤ U ≤ 2N` is then in the Kusmin–Landau regime. Quillon's proved
  `GoldC.VK.recipSum_small_T` (window `[L,2L]`, `L = N+1`, `T = Y/L ≤ L/2`) gives
  `‖S‖ ≤ 8L²/Y ≤ 16 N²/Y`. The `N²/Y` term of the target dominates, and no mean value theorem is
  used.
* `shiftedSuzukiCore_unconditional : ShiftedSuzukiCore`. This joins the low-`Y` branch with the
  archived `GoldB.shiftedSuzukiCore_of_lowY`.
-/

open Finset

namespace GoldB

open GoldB.Iface

/-- The `ℕ`-indexed clip sum as a GoldC run sum starting at `N+1`. -/
lemma shiftedModeSum_eq_expSum (Y ϑ : ℝ) (N U : ℕ) :
    shiftedModeSum 1 Y ϑ 0 N U =
      GoldC.VK.expSum (GoldC.VK.recipPhase Y ϑ) ((N + 1 : ℕ) : ℤ) (U - N) := by
  unfold shiftedModeSum GoldC.VK.expSum
  rw [← Finset.Ico_add_one_add_one_eq_Ioc, Finset.sum_Ico_eq_sum_range,
    show U + 1 - (N + 1) = U - N by omega]
  apply sum_congr rfl; intro i _
  unfold shiftedExpMode GoldC.VK.eAdd GoldC.VK.recipPhase
  congr 1; push_cast; ring

/-- **Low-`Y` branch (Kusmin–Landau), unconditional.** -/
theorem quillon_shifted_lowY : ShiftedSuzukiLowY := by
  refine ⟨1, 16, one_pos, by norm_num, ?_⟩
  intro Y hY N hN ϑ hϑ0 hϑ1 U hU hlow
  have hNr : (4096 : ℝ) ≤ N := by exact_mod_cast hN
  have hN0 : (0 : ℝ) < N := by linarith
  have hY0 : 0 < Y := by linarith
  have hYlt : Y < (N : ℝ) ^ 2 / 2 := by
    have h32 : Real.log 32 ≤ Real.log N := Real.log_le_log (by norm_num) (by linarith)
    have e32 : Real.log 32 = 5 * Real.log 2 := by
      rw [show (32 : ℝ) = 2 ^ 5 by norm_num, Real.log_pow]; norm_num
    have eN : Real.log ((N : ℝ) ^ 2 / 2) = 2 * Real.log N - Real.log 2 := by
      rw [Real.log_div (by positivity) (by norm_num), Real.log_pow]; push_cast; ring
    have : Real.log Y < Real.log ((N : ℝ) ^ 2 / 2) := by rw [eN]; linarith
    exact (Real.log_lt_log_iff hY0 (by positivity)).mp this
  have hR0 : 0 ≤ 16 * ((N : ℝ) * Real.exp (-(1 * Real.log (N : ℝ) ^ 3 / Real.log Y ^ 2)) +
      (N : ℝ) ^ 2 / Y) := by positivity
  rcases le_or_gt U N with hUN | hUN
  · have : shiftedModeSum 1 Y ϑ 0 N U = 0 := by
      unfold shiftedModeSum; rw [Finset.Ioc_eq_empty (by omega)]; simp
    rw [this, norm_zero]; exact hR0
  set L : ℝ := (N : ℝ) + 1 with hLdef
  have hL : 0 < L := by positivity
  set T : ℝ := Y / L with hTdef
  have hT : 0 < T := by positivity
  have hTL : T ≤ L / 2 := by
    simp only [T]; rw [div_le_iff₀ hL]; nlinarith
  have hwin : ∀ x ∈ GoldC.VK.runIcc ((N + 1 : ℕ) : ℤ) (U - N), L ≤ x + ϑ ∧ x + ϑ ≤ 2 * L := by
    intro x hx
    simp only [GoldC.VK.runIcc, Set.mem_Icc] at hx
    have hUN' : ((U - N : ℕ) : ℝ) = (U : ℝ) - N := by rw [Nat.cast_sub hUN.le]
    rw [hUN'] at hx
    push_cast at hx
    have hUr : (U : ℝ) ≤ 2 * N := by exact_mod_cast hU
    constructor <;> simp only [L] <;> linarith [hx.1, hx.2]
  have hS := GoldC.VK.recipSum_small_T (θ := ϑ) ((N + 1 : ℕ) : ℤ) (U - N) hL hT hTL hwin
  have hTL' : T * L = Y := by simp only [T]; field_simp
  rw [hTL'] at hS
  rw [shiftedModeSum_eq_expSum]
  refine hS.trans ?_
  have e : 8 * L / T = 8 * L ^ 2 / Y := by simp only [T]; field_simp
  rw [e]
  have hLsq : 8 * L ^ 2 ≤ 16 * (N : ℝ) ^ 2 := by simp only [L]; nlinarith
  have h1 : 8 * L ^ 2 / Y ≤ 16 * ((N : ℝ) ^ 2 / Y) := by
    rw [mul_div_assoc']; exact div_le_div_of_nonneg_right hLsq hY0.le
  have h2 : 0 ≤ (N : ℝ) * Real.exp (-(1 * Real.log (N : ℝ) ^ 3 / Real.log Y ^ 2)) := by
    positivity
  nlinarith

/-- **`ShiftedSuzukiCore`, with no hypothesis.** It joins the archived high-`Y`/small-`N` theorem
`GoldB.shifted_suzuki_highY`, which rests on the archived `karatsuba_lemma` and the reconstructed
R0010/R0016 interface, with the Kusmin–Landau low-`Y` branch above. -/
theorem shiftedSuzukiCore_unconditional : ShiftedSuzukiCore :=
  shiftedSuzukiCore_of_lowY quillon_shifted_lowY

end GoldB

#print axioms GoldB.quillon_shifted_lowY
#print axioms GoldB.shifted_highY_bound
#print axioms GoldB.shifted_suzuki_highY
#print axioms GoldB.shiftedSuzukiCore_unconditional
