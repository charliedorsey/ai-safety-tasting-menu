import PaperB.FixedQ.GlobalProperProductSplit

open scoped BigOperators Classical

namespace PaperB.FixedQ

/-- Finite shared-prime Euler identity, abstracted only over the local
coefficients. No summability, analytic estimate, or source cutoff is assumed.
For a supported prime set S, G indexes the primes common to both moduli. -/
theorem thalen_finite_shared_prime_euler
    (S : Finset ℕ) (delta left right : ℕ → ℝ) :
    (∏ p ∈ S, (1 + delta p * left p)) *
        (∏ p ∈ S, (1 + delta p * right p)) -
      (∏ p ∈ S, (1 + delta p ^ 2 * left p * right p)) =
    ∑ G ∈ S.powerset,
      (∏ p ∈ G, delta p ^ 2 * left p * right p) *
        ((∏ p ∈ S \ G,
          (1 + delta p * (left p + right p))) - 1) := by
  classical
  let D : ℕ → ℝ := fun p => delta p ^ 2 * left p * right p
  let U : ℕ → ℝ := fun p => 1 + delta p * (left p + right p)
  have hfull :
      (∑ G ∈ S.powerset, (∏ p ∈ G, D p) *
        (∏ p ∈ S \ G, U p)) =
      ∏ p ∈ S, (D p + U p) := by
    simpa using (Finset.prod_add D U S).symm
  have hdiag :
      (∑ G ∈ S.powerset, ∏ p ∈ G, D p) =
      ∏ p ∈ S, (1 + D p) := by
    simpa [add_comm] using
      (Finset.prod_add D (fun _ => (1 : ℝ)) S).symm
  have hprod :
      (∏ p ∈ S, (1 + delta p * left p)) *
        (∏ p ∈ S, (1 + delta p * right p)) =
      ∏ p ∈ S, (D p + U p) := by
    rw [← Finset.prod_mul_distrib]
    apply Finset.prod_congr rfl
    intro p hp
    dsimp [D, U]
    ring
  have hdiag' :
      (∏ p ∈ S, (1 + delta p ^ 2 * left p * right p)) =
      ∏ p ∈ S, (1 + D p) := by
    rfl
  calc
    (∏ p ∈ S, (1 + delta p * left p)) *
        (∏ p ∈ S, (1 + delta p * right p)) -
      (∏ p ∈ S, (1 + delta p ^ 2 * left p * right p)) =
        (∏ p ∈ S, (D p + U p)) -
          (∏ p ∈ S, (1 + D p)) := by rw [hprod, hdiag']
    _ = (∑ G ∈ S.powerset,
          (∏ p ∈ G, D p) * (∏ p ∈ S \ G, U p)) -
          (∑ G ∈ S.powerset, ∏ p ∈ G, D p) := by
            rw [hfull, hdiag]
    _ = ∑ G ∈ S.powerset,
          (∏ p ∈ G, D p) *
          ((∏ p ∈ S \ G, U p) - 1) := by
            rw [← Finset.sum_sub_distrib]
            apply Finset.sum_congr rfl
            intro G hG
            ring
    _ = _ := by
      apply Finset.sum_congr rfl
      intro G hG
      rfl

#print axioms thalen_finite_shared_prime_euler


/-- Finite coefficient correction: b_empty = A - 1 and
b_nonempty = A * product(delta). The difference between
the product of centered one-sided packets and the spectral diagonal
equals the shared-prime Euler expression plus the explicit two
one-sided exceptional-index corrections. -/
theorem thalen_finite_centered_shared_prime_euler
    (S : Finset ℕ) (A : ℝ) (delta left right : ℕ → ℝ) :
    (A * (∏ p ∈ S, (1 + delta p * left p)) - 1) *
      (A * (∏ p ∈ S, (1 + delta p * right p)) - 1) -
      ((A - 1) ^ 2 +
        A ^ 2 * ((∏ p ∈ S,
          (1 + delta p ^ 2 * left p * right p)) - 1)) =
    A ^ 2 * (∑ G ∈ S.powerset,
      (∏ p ∈ G, delta p ^ 2 * left p * right p) *
        ((∏ p ∈ S \ G,
          (1 + delta p * (left p + right p))) - 1)) -
      A * (((∏ p ∈ S, (1 + delta p * left p)) - 1) +
        ((∏ p ∈ S, (1 + delta p * right p)) - 1)) := by
  have h := thalen_finite_shared_prime_euler S delta left right
  linear_combination A ^ 2 * h

#print axioms thalen_finite_centered_shared_prime_euler

/-- Caldrin's local Ramanujan Euler coefficient. -/
noncomputable def thalenPrimeDelta (p : ℕ) : ℝ :=
  1 / ((p : ℝ) * ((p : ℝ) - 3) + 1)

/-- Prime Ramanujan sum, in its elementary real two-valued form. -/
noncomputable def thalenPrimeRamanujan (p y : ℕ) : ℝ :=
  if p ∣ y then (p : ℝ) - 1 else -1

/-- A finite Euler truncation of the centered one-sided packet. -/
noncomputable def thalenFiniteCenteredPacket
    (S : Finset ℕ) (A : ℝ) (y : ℕ) : ℝ :=
  A * (∏ p ∈ S,
    (1 + thalenPrimeDelta p * thalenPrimeRamanujan p y)) - 1

/-- The finite spectral diagonal, including the exceptional empty index. -/
noncomputable def thalenFiniteDiagonal
    (S : Finset ℕ) (A : ℝ) (y z : ℕ) : ℝ :=
  (A - 1) ^ 2 +
    A ^ 2 * ((∏ p ∈ S,
      (1 + thalenPrimeDelta p ^ 2 *
        thalenPrimeRamanujan p y * thalenPrimeRamanujan p z)) - 1)

/-- Off-diagonal shared-prime Euler kernel with the empty-index correction. -/
noncomputable def thalenFiniteSharedPrimeOffDiagonal
    (S : Finset ℕ) (A : ℝ) (y z : ℕ) : ℝ :=
  A ^ 2 * (∑ G ∈ S.powerset,
    (∏ p ∈ G, thalenPrimeDelta p ^ 2 *
      thalenPrimeRamanujan p y * thalenPrimeRamanujan p z) *
      ((∏ p ∈ S \ G,
        (1 + thalenPrimeDelta p *
          (thalenPrimeRamanujan p y + thalenPrimeRamanujan p z))) - 1)) -
    A * (((∏ p ∈ S,
      (1 + thalenPrimeDelta p * thalenPrimeRamanujan p y)) - 1) +
      ((∏ p ∈ S,
      (1 + thalenPrimeDelta p * thalenPrimeRamanujan p z)) - 1))

/-- Exact finite centered correlation split at every source point. -/
theorem thalen_finite_centered_eq_diagonal_add_sharedPrime
    (S : Finset ℕ) (A : ℝ) (y z : ℕ) :
    thalenFiniteCenteredPacket S A y *
      thalenFiniteCenteredPacket S A z =
      thalenFiniteDiagonal S A y z +
        thalenFiniteSharedPrimeOffDiagonal S A y z := by
  unfold thalenFiniteCenteredPacket thalenFiniteDiagonal
    thalenFiniteSharedPrimeOffDiagonal
  have h := thalen_finite_centered_shared_prime_euler S A
    thalenPrimeDelta (fun p => thalenPrimeRamanujan p y)
    (fun p => thalenPrimeRamanujan p z)
  linarith

/-- Source-weight-compatible finite correlation identity: no cutoff,
norm, or approximation, with all weights retained outside the packet. -/
theorem thalen_weighted_finite_correlation_eq_spectral
    (S : Finset ℕ) (A : ℝ) (lambda : ℕ → ℝ) (h : ℕ) :
    (∑ y ∈ Finset.Ioo 0 h,
      lambda y * (thalenFiniteCenteredPacket S A y *
        thalenFiniteCenteredPacket S A (h-y))) =
    ∑ y ∈ Finset.Ioo 0 h,
      lambda y * (thalenFiniteDiagonal S A y (h-y) +
        thalenFiniteSharedPrimeOffDiagonal S A y (h-y)) := by
  apply Finset.sum_congr rfl
  intro y hy
  rw [thalen_finite_centered_eq_diagonal_add_sharedPrime]

#print axioms thalen_weighted_finite_correlation_eq_spectral

/-- Finite-support Euler normalization. This is not the infinite A. -/
noncomputable def thalenFiniteA (S : Finset ℕ) : ℝ :=
  ∏ p ∈ S, (1 + 1 / ((p : ℝ) * ((p : ℝ) - 3)))

/-- A finite Euler factor identifies exactly with the source divisor
indicator after the correct finite normalization is supplied. -/
theorem thalen_local_source_euler
    (p y : ℕ) (hp : 5 ≤ p) :
    (1 + 1 / ((p : ℝ) * ((p : ℝ) - 3))) *
      (1 + thalenPrimeDelta p * thalenPrimeRamanujan p y) =
    1 + (if p ∣ y then 1 / ((p : ℝ) - 3) else 0) := by
  have hp0 : (p : ℝ) ≠ 0 := by exact_mod_cast (by omega : p ≠ 0)
  have hp3 : (p : ℝ) - 3 ≠ 0 := by
    have := (show (5 : ℝ) ≤ (p : ℝ) from by exact_mod_cast hp)
    linarith
  have hden : (p : ℝ) * ((p : ℝ) - 3) + 1 ≠ 0 := by
    have hpr : (5 : ℝ) ≤ (p : ℝ) := by exact_mod_cast hp
    nlinarith
  unfold thalenPrimeDelta thalenPrimeRamanujan
  by_cases hy : p ∣ y
  · simp only [hy, if_pos]
    field_simp
    ring
  · simp only [hy, ↓reduceIte]
    field_simp
    ring

theorem thalen_finite_source_euler
    (S : Finset ℕ) (h5 : ∀ p ∈ S, 5 ≤ p) (y : ℕ) :
    thalenFiniteCenteredPacket S (thalenFiniteA S) y =
      (∏ p ∈ S,
        (1 + (if p ∣ y then 1 / ((p : ℝ) - 3) else 0))) - 1 := by
  unfold thalenFiniteCenteredPacket thalenFiniteA
  rw [← Finset.prod_mul_distrib]
  congr 1
  apply Finset.prod_congr rfl
  intro p hp
  exact thalen_local_source_euler p y (h5 p hp)

#print axioms thalen_finite_source_euler

end PaperB.FixedQ
