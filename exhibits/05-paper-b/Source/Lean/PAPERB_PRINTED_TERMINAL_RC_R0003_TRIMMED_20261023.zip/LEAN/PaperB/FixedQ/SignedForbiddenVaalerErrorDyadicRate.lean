import PaperB.FixedQ.SignedForbiddenVaalerErrorDyadic
import PaperB.FixedQ.SignedForbiddenHarmonicShellSourceRate
import PaperB.FixedQ.SignedForbiddenVaalerTruncationRate

open scoped BigOperators

namespace PaperB.FixedQ

theorem sourceForbiddenNaturalVaalerErrorDyadicBlock_sourceCutoff_le_rate
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ M0 : ℕ,
      0 ≤ C ∧
      ∀ A H D M : ℕ,
        (¬ 2 ∣ q → 2 ∣ H) →
        M0 ≤ M →
        3 ≤ M →
        4 ≤ h2BooleanRoughCutoff M →
        3 ≤ Nat.nthRoot 4 M →
        (h2BooleanRoughCutoff M) ^ 2 ≤ M →
        ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
        ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
        2 ≤ Real.log (M : ℝ) →
        1 ≤ Real.log (Real.log (M : ℝ)) →
        h2BooleanTailCorrectionConst ≤
          (1 / 8 : ℝ) *
            (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) →
        Real.exp (-(1 / 8 : ℝ) *
            (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) ≤
          (Real.log (M : ℝ)) ^ (-4 : ℝ) →
        sourceForbiddenNaturalVaalerErrorDyadicBlock
            q A H D M (sourceVaalerCutoff M) ≤
          C * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
            (Real.log (Real.log (M : ℝ))) ^ 2 := by
  rcases sourcePeriodicHarmonicShell_sourceCutoff_le_rate_of_conditions q hq with
    ⟨Ch, Mh, hCh0, hHarm⟩
  rcases sourceOrdinaryDyadicShiuMass_sourceCutoff_truncation_le_rate q hq with
    ⟨Ct, Mt, hCt0, hTrunc⟩
  let P : ℝ := 6 * (fixedQPeriod q : ℝ)
  let C : ℝ := P * (Ct + 2 * Ch)
  refine ⟨C, max Mh Mt, ?_, ?_⟩
  · dsimp [C, P]
    positivity
  · intro A H D M h2 hM0 hM3 hY4 hroot hYsq hquarter hqM
      hlog2 hll hTail hdec
    have hMh : Mh ≤ M := (le_max_left Mh Mt).trans hM0
    have hMt : Mt ≤ M := (le_max_right Mh Mt).trans hM0
    have hM2 : 2 ≤ M := by omega
    have hlog1 : 1 ≤ Real.log (M : ℝ) := by linarith
    have ht :=
      hTrunc H M hMt hM2 hquarter hqM hlog2
    have hh :=
      hHarm H M hMh hM3 hY4 hroot hYsq hquarter hqM
        hlog2 hll hTail hdec
    have hshell :=
      sourceForbiddenNaturalVaalerErrorDyadicBlock_le_shell
        (q := q) (A := A) (H := H) (D := D)
        (M := M) (J := sourceVaalerCutoff M) h2
    let X : ℝ := (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1)
    let LL : ℝ := Real.log (Real.log (M : ℝ))
    have hX0 : 0 ≤ X := by
      dsimp [X]
      exact Real.rpow_nonneg (Real.log_nonneg (by
        exact_mod_cast (show 1 ≤ M by omega))) _
    have hLL1 : 1 ≤ LL := by simpa [LL] using hll
    have hLL2one : 1 ≤ LL ^ 2 := one_le_pow₀ hLL1
    have ht' :
        (1 / (((sourceVaalerCutoff M + 1 : ℕ) : ℝ))) *
            sourceOrdinaryDyadicShiuMass q H M ≤
          Ct * X * LL ^ 2 := by
      calc
        _ ≤ Ct * X := by simpa [X] using ht
        _ ≤ Ct * X * LL ^ 2 := by
          exact le_mul_of_one_le_right (mul_nonneg hCt0 hX0) hLL2one
    have hh' :
        sourceOrdinaryDyadicHarmonicShell
            q H M (sourceVaalerCutoff M) ≤
          Ch * X * LL ^ 2 := by
      simpa [sourceOrdinaryDyadicHarmonicShell, X, LL] using hh
    have hP0 : 0 ≤ P := by
      dsimp [P]
      positivity
    calc
      sourceForbiddenNaturalVaalerErrorDyadicBlock
          q A H D M (sourceVaalerCutoff M)
        ≤ P *
          ((1 / (((sourceVaalerCutoff M + 1 : ℕ) : ℝ))) *
              sourceOrdinaryDyadicShiuMass q H M +
            2 * sourceOrdinaryDyadicHarmonicShell
              q H M (sourceVaalerCutoff M)) := by
            simpa [P] using hshell
      _ ≤ P * (Ct * X * LL ^ 2 + 2 * (Ch * X * LL ^ 2)) := by
            apply mul_le_mul_of_nonneg_left _ hP0
            exact add_le_add ht' (mul_le_mul_of_nonneg_left hh' (by norm_num))
      _ = C * X * LL ^ 2 := by
            dsimp [C]
            ring
      _ = _ := by rfl

#print axioms sourceForbiddenNaturalVaalerErrorDyadicBlock_sourceCutoff_le_rate

end PaperB.FixedQ
