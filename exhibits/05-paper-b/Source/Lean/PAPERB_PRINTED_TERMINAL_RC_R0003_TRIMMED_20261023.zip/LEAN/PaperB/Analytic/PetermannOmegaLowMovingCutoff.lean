import PaperB.Analytic.PetermannOmegaMovingFourierBand
import PaperB.FixedQ.HarmonicLogTail
import PaperB.FixedQ.EtaLinearConvolution

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset

lemma abs_coprimeIndicatorArithmetic_le_one (q m : ℕ) :
    |coprimeIndicatorArithmetic q m| ≤ 1 := by
  rw [coprimeIndicatorArithmetic_apply, coprimeIndicatorCoeff]
  by_cases hm : m = 0
  · rw [if_pos hm]
    norm_num
  · rw [if_neg hm]
    by_cases hc : m.Coprime (6 * q)
    · rw [if_pos hc]
      norm_num
    · rw [if_neg hc]
      norm_num

theorem omega_smoothed_low_transition_tail_sublog
    {S : ℝ} (hS : 1 < S)
    (q M N H : ℕ) (K : ℕ → ℕ) (x : ℕ → ℝ)
    (hM : 1 ≤ M)
    (hKH : ∀ m ∈ Finset.Icc M N, K m ≤ H) :
    ‖∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          ∑ k ∈ Finset.Ico (K m) H,
            sawSmoothPair S k (x m : AddCircle (1 : ℝ)))‖
      ≤ (12 / Real.pi) *
          ∑ m ∈ Finset.Icc M N, (1 : ℝ) / (m : ℝ) := by
  calc
    ‖∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          ∑ k ∈ Finset.Ico (K m) H,
            sawSmoothPair S k (x m : AddCircle (1 : ℝ)))‖
      ≤ ∑ m ∈ Finset.Icc M N,
          ‖(((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
            ∑ k ∈ Finset.Ico (K m) H,
              sawSmoothPair S k (x m : AddCircle (1 : ℝ)))‖ :=
        norm_sum_le _ _
    _ ≤ ∑ m ∈ Finset.Icc M N,
          ((1 : ℝ) / (m : ℝ)) * (12 / Real.pi) := by
      apply Finset.sum_le_sum
      intro m hm
      have hmM : M ≤ m := (Finset.mem_Icc.mp hm).1
      have hm1 : 1 ≤ m := le_trans hM hmM
      have hmpos : (0 : ℝ) < m := by exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hm1)
      have hcind := abs_coprimeIndicatorArithmetic_le_one q m
      have hband := omega_low_transition_moving_fourier_band_uniform
        hS (x m) (K m) H (hKH m hm)
      rw [norm_mul, Complex.norm_real, Real.norm_eq_abs, abs_div,
        abs_of_pos hmpos]
      have hcoef :
          |coprimeIndicatorArithmetic q m| / (m : ℝ) ≤ 1 / (m : ℝ) := by
        exact (div_le_div_iff_of_pos_right hmpos).2 hcind
      exact mul_le_mul hcoef hband (norm_nonneg _) (by positivity)
    _ = (12 / Real.pi) *
          ∑ m ∈ Finset.Icc M N, (1 : ℝ) / (m : ℝ) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro m hm
      ring

#print axioms omega_smoothed_low_transition_tail_sublog

end PaperB.Analytic

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset

lemma harmonic_Icc_le_one_div_add_log_ratio
    {M N : ℕ} (hM : 1 ≤ M) (hMN : M ≤ N) :
    (∑ m ∈ Finset.Icc M N, (1 : ℝ) / (m : ℝ))
      ≤ (1 : ℝ) / (M : ℝ) +
        (Real.log ((N + 1 : ℕ) : ℝ) - Real.log (M : ℝ)) := by
  have hIcc :
      (∑ m ∈ Finset.Icc M N, (1 : ℝ) / (m : ℝ)) =
        ∑ j ∈ Finset.range (N + 1 - M),
          (1 : ℝ) / ((M + j : ℕ) : ℝ) := by
    rw [show Finset.Icc M N = Finset.Ico M (N + 1) by
      ext m
      simp]
    rw [Finset.sum_Ico_eq_sum_range]
  rw [hIcc]
  have h := shifted_harmonic_range_le
    (K := M) (N := N + 1 - M) hM
  have hsum : M + (N + 1 - M) = N + 1 := by omega
  simpa [hsum] using h

lemma low_transition_log_ratio_le
    {a beta : ℝ} {H M N : ℕ}
    (ha : 1 ≤ a) (hb0 : 0 ≤ beta)
    (hH : 1 ≤ H) (hM : 1 ≤ M)
    (hlow : a ^ beta ≤ (M : ℝ))
    (hhigh : ((N + 1 : ℕ) : ℝ) ≤
      2 * (((H : ℝ) * a) ^ beta)) :
    Real.log ((N + 1 : ℕ) : ℝ) - Real.log (M : ℝ)
      ≤ Real.log 2 + beta * Real.log (H : ℝ) := by
  have ha0 : 0 < a := lt_of_lt_of_le zero_lt_one ha
  have hH0 : (0 : ℝ) < H := by
    exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hH)
  have hM0 : (0 : ℝ) < M := by
    exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hM)
  have hN0 : (0 : ℝ) < ((N + 1 : ℕ) : ℝ) := by positivity
  have hHa0 : 0 < (H : ℝ) * a := mul_pos hH0 ha0
  have hpowA0 : 0 < a ^ beta := Real.rpow_pos_of_pos ha0 beta
  have hpowHA0 : 0 < ((H : ℝ) * a) ^ beta :=
    Real.rpow_pos_of_pos hHa0 beta
  have hlogN :
      Real.log ((N + 1 : ℕ) : ℝ) ≤
        Real.log (2 * (((H : ℝ) * a) ^ beta)) := by
    exact Real.log_le_log hN0 hhigh
  have hlogM : Real.log (a ^ beta) ≤ Real.log (M : ℝ) := by
    exact Real.log_le_log hpowA0 hlow
  have htwo : (0 : ℝ) < 2 := by norm_num
  rw [Real.log_mul htwo.ne' hpowHA0.ne'] at hlogN
  rw [Real.log_rpow hHa0 beta] at hlogN
  rw [Real.log_rpow ha0 beta] at hlogM
  have hlogHa : Real.log ((H : ℝ) * a) =
      Real.log (H : ℝ) + Real.log a := by
    rw [Real.log_mul (ne_of_gt hH0) (ne_of_gt ha0)]
  rw [hlogHa] at hlogN
  nlinarith

theorem omega_smoothed_low_moving_cutoff_sublog
    {S a beta : ℝ} (hS : 1 < S)
    (q M N H : ℕ) (K : ℕ → ℕ) (x : ℕ → ℝ)
    (ha : 1 ≤ a) (hb0 : 0 ≤ beta)
    (hH : 1 ≤ H) (hM : 1 ≤ M) (hMN : M ≤ N)
    (hKH : ∀ m ∈ Finset.Icc M N, K m ≤ H)
    (hlow : a ^ beta ≤ (M : ℝ))
    (hhigh : ((N + 1 : ℕ) : ℝ) ≤
      2 * (((H : ℝ) * a) ^ beta)) :
    ‖∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          ∑ k ∈ Finset.Ico (K m) H,
            sawSmoothPair S k (x m : AddCircle (1 : ℝ)))‖
      ≤ (12 / Real.pi) *
          ((1 : ℝ) / (M : ℝ) +
            Real.log 2 + beta * Real.log (H : ℝ)) := by
  have htail := omega_smoothed_low_transition_tail_sublog
    hS q M N H K x hM hKH
  have hharm := harmonic_Icc_le_one_div_add_log_ratio
    (M := M) (N := N) hM hMN
  have hratio := low_transition_log_ratio_le
    (a := a) (beta := beta) (H := H) (M := M) (N := N)
    ha hb0 hH hM hlow hhigh
  have hpi0 : 0 ≤ 12 / Real.pi := by positivity
  calc
    ‖∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          ∑ k ∈ Finset.Ico (K m) H,
            sawSmoothPair S k (x m : AddCircle (1 : ℝ)))‖
      ≤ (12 / Real.pi) *
          ∑ m ∈ Finset.Icc M N, (1 : ℝ) / (m : ℝ) := htail
    _ ≤ (12 / Real.pi) *
        ((1 : ℝ) / (M : ℝ) +
          (Real.log ((N + 1 : ℕ) : ℝ) - Real.log (M : ℝ))) := by
      exact mul_le_mul_of_nonneg_left hharm hpi0
    _ ≤ (12 / Real.pi) *
        ((1 : ℝ) / (M : ℝ) +
          Real.log 2 + beta * Real.log (H : ℝ)) := by
      exact mul_le_mul_of_nonneg_left (by linarith) hpi0

#print axioms harmonic_Icc_le_one_div_add_log_ratio
#print axioms low_transition_log_ratio_le
#print axioms omega_smoothed_low_moving_cutoff_sublog

end PaperB.Analytic
