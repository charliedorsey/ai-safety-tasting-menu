import PaperB.FixedQ.H2BooleanSecondMomentCutoff

open scoped BigOperators

namespace PaperB.FixedQ

lemma h2BooleanRough_primeMass_le_modulus_one
    (q Y X k : ℕ) :
    PaperB.M4B.primeMass
        (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt) X k ≤
      PaperB.M4B.primeMass
        (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt) X 1 := by
  unfold PaperB.M4B.primeMass
  let Pk := (Nat.primesLE X).filter (fun p => ¬ p ∣ k)
  let P1 := (Nat.primesLE X).filter (fun p => ¬ p ∣ 1)
  have hsub : Pk ⊆ P1 := by
    intro p hp
    have hpP := (Nat.mem_primesLE.mp (Finset.mem_filter.mp hp).1).2
    rw [Finset.mem_filter]
    exact ⟨(Finset.mem_filter.mp hp).1, hpP.not_dvd_one⟩
  exact Finset.sum_le_sum_of_subset_of_nonneg hsub (by
    intro p hp hnot
    exact div_nonneg
      (h2BooleanRoughTiltLift_nonneg q Y p h2BooleanSecondTilt_nonneg)
      (by positivity))

lemma h2BooleanRough_exp_primeMass_le_modulus_one
    (q Y X k : ℕ) :
    Real.exp
        (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt) X k) ≤
      Real.exp
        (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt) X 1) := by
  exact Real.exp_le_exp.mpr (h2BooleanRough_primeMass_le_modulus_one q Y X k)

theorem h2BooleanBadFrequencyFiberSum_le_raw
    (q M j : ℕ) :
    (∑ T ∈ h2BooleanBadSmoothSets q M,
      h2BooleanDyadicFrequencyFiberMoment
        q (h2BooleanRoughCutoff M) M T j) ≤
      Real.exp
        (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
            h2BooleanSecondTilt)
          (2 * M) 1) *
      (∑ T ∈ h2BooleanBadSmoothSets q M,
        finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) := by
  let E := Real.exp
    (PaperB.M4B.primeMass
      (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
        h2BooleanSecondTilt)
      (2 * M) 1)
  calc
    (∑ T ∈ h2BooleanBadSmoothSets q M,
      h2BooleanDyadicFrequencyFiberMoment
        q (h2BooleanRoughCutoff M) M T j)
      ≤ ∑ T ∈ h2BooleanBadSmoothSets q M,
          (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) * E := by
        apply Finset.sum_le_sum
        intro T hT
        have hA := h2BooleanBadSmoothSets_active hT
        have hraw :=
          h2BooleanDyadicFrequencyFiberMoment_le_exp_rough_mass
            (q := q) (Y := h2BooleanRoughCutoff M) (M := M)
            (T := T) (j := j) hA
        have hmass :=
          h2BooleanRough_exp_primeMass_le_modulus_one
            q (h2BooleanRoughCutoff M) (2 * M) (primeSetProduct T)
        have hw0 : 0 ≤ finiteOmegaWeightReal T * h2BooleanV0 ^ T.card :=
          mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hA)
            (pow_nonneg h2BooleanV0_nonneg _)
        exact hraw.trans (mul_le_mul_of_nonneg_left
          (by simpa [E] using hmass) hw0)
    _ = E * (∑ T ∈ h2BooleanBadSmoothSets q M,
        finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro T hT
      ring
    _ = _ := by rfl

theorem h2BooleanBadFrequencyFiberSum_le_rankin
    {q M j : ℕ}
    (hM : 2 ≤ M)
    (hlog : 1 ≤ Real.log (M : ℝ))
    (hC : h2BooleanTailCorrectionConst ≤
      (1 / 8 : ℝ) * (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) :
    (∑ T ∈ h2BooleanBadSmoothSets q M,
      h2BooleanDyadicFrequencyFiberMoment
        q (h2BooleanRoughCutoff M) M T j) ≤
      Real.exp
        (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
            h2BooleanSecondTilt)
          (2 * M) 1) *
      Real.exp
        (PaperB.M4B.primeMass
          (h2BooleanTiltLift q h2BooleanSecondTilt)
          (h2BooleanRoughCutoff M) q -
        (1 / 8 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) := by
  have hraw := h2BooleanBadFrequencyFiberSum_le_raw q M j
  have htail := h2BooleanBadSmoothWeightSum_rankin
    (q := q) (M := M) hM hlog hC
  have hE0 : 0 ≤ Real.exp
      (PaperB.M4B.primeMass
        (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
          h2BooleanSecondTilt)
        (2 * M) 1) := (Real.exp_pos _).le
  exact hraw.trans (mul_le_mul_of_nonneg_left htail hE0)

#print axioms h2BooleanRough_primeMass_le_modulus_one
#print axioms h2BooleanBadFrequencyFiberSum_le_rankin

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def h2BooleanGoodSmoothSetsNontrivial (q M : ℕ) :
    Finset (Finset ℕ) :=
  (h2BooleanGoodSmoothSets q M).filter
    (fun T => 1 < primeSetProduct T)

lemma h2BooleanGoodSmoothSetsNontrivial_subset
    (q M : ℕ) :
    h2BooleanGoodSmoothSetsNontrivial q M ⊆
      (h2BooleanSmoothActivePrimeSet q (h2BooleanRoughCutoff M)).powerset := by
  intro T hT
  have hG := (Finset.mem_filter.mp hT).1
  exact (Finset.mem_filter.mp hG).1

lemma h2BooleanGoodSmoothSetsNontrivial_active
    {q M : ℕ} {T : Finset ℕ}
    (hT : T ∈ h2BooleanGoodSmoothSetsNontrivial q M) :
    ∀ p ∈ T, activeHighPrime q p :=
  h2BooleanGoodSmoothSets_active (Finset.mem_filter.mp hT).1

lemma h2BooleanGoodSmoothSetsNontrivial_product_gt_one
    {q M : ℕ} {T : Finset ℕ}
    (hT : T ∈ h2BooleanGoodSmoothSetsNontrivial q M) :
    1 < primeSetProduct T :=
  (Finset.mem_filter.mp hT).2

/-- Good-smooth family assembly before the geometric hypotheses and rough
prime-mass bound are discharged.  This is the exact uniform-Shiu/M3 seam. -/
theorem h2BooleanGoodFrequencyFiberSum_le_m3_raw
    (q : ℕ) :
    ∃ X0 : ℕ, ∀ M j : ℕ,
      4 ≤ h2BooleanRoughCutoff M →
      (∀ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        X0 ≤ PaperB.M4B.scaledCoverUpper
          (2 * M) (primeSetProduct T)) →
      (∀ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        ((PaperB.M4B.scaledCoverUpper
          (2 * M) (primeSetProduct T) : ℝ) ^ (1 / 4 : ℝ) <
          (PaperB.M4B.scaledCoverLength
            (2 * M) M (primeSetProduct T) : ℝ))) →
      (∀ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        PaperB.M4B.scaledCoverLength
          (2 * M) M (primeSetProduct T) ≤
        PaperB.M4B.scaledCoverUpper
          (2 * M) (primeSetProduct T)) →
      (∀ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        (primeSetProduct T : ℝ) <
          (PaperB.M4B.scaledCoverLength
            (2 * M) M (primeSetProduct T) : ℝ) ^ (3 / 4 : ℝ)) →
      (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanDyadicFrequencyFiberMoment
          q (h2BooleanRoughCutoff M) M T j) ≤
        ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          ((primeSetProduct T : ℝ) / (M : ℝ)) *
          PaperB.M4B.shiuFixedQuarterAssembleConstant
            8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
          ((PaperB.M4B.scaledCoverLength
              (2 * M) M (primeSetProduct T) : ℝ) /
            Real.log (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T) : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt)
            (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T))
            (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
  rcases h2BooleanDyadicFrequencyFiberMoment_le_m3_cover_uniform q with
    ⟨X0, hfiber⟩
  refine ⟨X0, ?_⟩
  intro M j hY hX hquarter hyx hmod
  apply Finset.sum_le_sum
  intro T hT
  have hA := h2BooleanGoodSmoothSetsNontrivial_active hT
  letI : NeZero (primeSetProduct T) :=
    ⟨(primeSetProduct_pos (fun p hp => (hA p hp).1)).ne'⟩
  have hG : T ∈ h2BooleanGoodSmoothSets q M :=
    (Finset.mem_filter.mp hT).1
  have hpow := h2BooleanGoodSmoothSets_product_pow_four_le hG
  have hMpos : 0 < M := by
    have hgt := h2BooleanGoodSmoothSetsNontrivial_product_gt_one hT
    have hpowpos : 0 < (primeSetProduct T) ^ 4 := by positivity
    omega
  exact hfiber
    (h2BooleanRoughCutoff M) T hA j M
    hMpos
    (h2BooleanGoodSmoothSetsNontrivial_product_gt_one hT)
    (hX T hT) (hquarter T hT) (hyx T hT) (hmod T hT)

#print axioms h2BooleanGoodFrequencyFiberSum_le_m3_raw

end PaperB.FixedQ


namespace PaperB.FixedQ

/-- Exact good/bad decomposition of the dyadic frequency second moment at
the moving smooth/rough cutoff. -/
theorem h2BooleanDyadicFrequencySecondMoment_eq_good_add_bad
    (q M j : ℕ) :
    h2BooleanDyadicFrequencySecondMoment q M j =
      (∑ T ∈ h2BooleanGoodSmoothSets q M,
        h2BooleanDyadicFrequencyFiberMoment
          q (h2BooleanRoughCutoff M) M T j) +
      (∑ T ∈ h2BooleanBadSmoothSets q M,
        h2BooleanDyadicFrequencyFiberMoment
          q (h2BooleanRoughCutoff M) M T j) := by
  rw [h2BooleanDyadicFrequencySecondMoment_eq_sum_fibers
    q (h2BooleanRoughCutoff M) M j]
  rw [h2BooleanGoodSmoothSets_partition q M]
  exact Finset.sum_union (h2BooleanGoodBad_disjoint q M)

#print axioms h2BooleanDyadicFrequencySecondMoment_eq_good_add_bad

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma h2Boolean_good_scaled_quarter_real
    {q M : ℕ} {T : Finset ℕ}
    (hT : T ∈ h2BooleanGoodSmoothSets q M)
    (hM : 1 ≤ M) :
    (PaperB.M4B.scaledCoverUpper
        (2 * M) (primeSetProduct T) : ℝ) ^ (1 / 4 : ℝ) <
      (PaperB.M4B.scaledCoverLength
        (2 * M) M (primeSetProduct T) : ℝ) := by
  have hnat := h2Boolean_good_scaled_quarter_nat hT hM
  let x := PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)
  let y := PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T)
  have hxy : (x : ℝ) < ((y ^ 4 : ℕ) : ℝ) := by exact_mod_cast hnat
  have hr := Real.rpow_lt_rpow
    (show (0 : ℝ) ≤ x by positivity) hxy
    (show (0 : ℝ) < 1 / 4 by norm_num)
  have hy0 : (0 : ℝ) ≤ y := by positivity
  have hroot : (((y ^ 4 : ℕ) : ℝ)) ^ (1 / 4 : ℝ) = (y : ℝ) := by
    norm_num only [Nat.cast_pow]
    rw [← Real.rpow_natCast]
    rw [← Real.rpow_mul hy0]
    norm_num
  rw [hroot] at hr
  simpa [x, y] using hr

lemma h2Boolean_scaledCoverLength_le_upper
    (M m : ℕ) :
    PaperB.M4B.scaledCoverLength (2 * M) M m ≤
      PaperB.M4B.scaledCoverUpper (2 * M) m := by
  unfold PaperB.M4B.scaledCoverLength PaperB.M4B.scaledCoverUpper
    PaperB.M4B.scaledLength PaperB.M4B.scaledUpper
    PaperB.M4B.scaledLower
  exact Nat.add_le_add_right (Nat.sub_le _ _) 1

lemma h2Boolean_good_scaled_modulus_real
    {q M : ℕ} {T : Finset ℕ}
    (hT : T ∈ h2BooleanGoodSmoothSetsNontrivial q M) :
    (primeSetProduct T : ℝ) <
      (PaperB.M4B.scaledCoverLength
        (2 * M) M (primeSetProduct T) : ℝ) ^ (3 / 4 : ℝ) := by
  let m := primeSetProduct T
  let y := PaperB.M4B.scaledCoverLength (2 * M) M m
  have hG : T ∈ h2BooleanGoodSmoothSets q M :=
    (Finset.mem_filter.mp hT).1
  have hm1 : 1 < m := h2BooleanGoodSmoothSetsNontrivial_product_gt_one hT
  have hcubed : m ^ 3 ≤ M / m := by
    simpa [m] using h2Boolean_good_scaled_div_ge_cube hG
  have hydiv : M / m + 1 ≤ y := by
    simpa [m, y] using h2Boolean_scaledCoverLength_ge_div (M := M) (m := m)
  have hcubed_y_nat : m ^ 3 < y := by omega
  have hm0 : (0 : ℝ) ≤ m := by positivity
  have hy0 : (0 : ℝ) ≤ y := by positivity
  have hcubed_y_cast : (((m ^ 3 : ℕ) : ℝ)) < (y : ℝ) := by
    exact_mod_cast hcubed_y_nat
  have hcubed_y : (m : ℝ) ^ (3 : ℝ) < (y : ℝ) := by
    calc
      (m : ℝ) ^ (3 : ℝ) = (m : ℝ) ^ (3 : ℕ) := by
        exact Real.rpow_natCast (m : ℝ) 3
      _ = (((m ^ 3 : ℕ) : ℝ)) := by norm_num
      _ < (y : ℝ) := hcubed_y_cast
  have hm_root : (m : ℝ) < (y : ℝ) ^ ((3 : ℝ)⁻¹) := by
    exact (Real.lt_rpow_inv_iff_of_pos hm0 hy0 (by norm_num : (0 : ℝ) < 3)).2
      hcubed_y
  have hy1 : (1 : ℝ) < (y : ℝ) := by
    have hm2 : 2 ≤ m := by omega
    have : 1 < y := by
      have hcube8 : 8 ≤ m ^ 3 := by
        calc
          8 = 2 * 2 * 2 := by norm_num
          _ ≤ m * m * m := by gcongr
          _ = m ^ 3 := by ring
      omega
    exact_mod_cast this
  have hexp : (3 : ℝ)⁻¹ < 3 / 4 := by norm_num
  have hpowmono :=
    (Real.strictMono_rpow_of_base_gt_one hy1) hexp
  exact hm_root.trans hpowmono

#print axioms h2Boolean_good_scaled_quarter_real
#print axioms h2Boolean_good_scaled_modulus_real

end PaperB.FixedQ


namespace PaperB.FixedQ

/-- Good-smooth family assembly with the paid fourth-root geometry discharged.
Only the eventual lower threshold on the scaled Shiu variable remains. -/
theorem h2BooleanGoodFrequencyFiberSum_le_m3
    (q : ℕ) :
    ∃ X0 : ℕ, ∀ M j : ℕ,
      1 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      (∀ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        X0 ≤ PaperB.M4B.scaledCoverUpper
          (2 * M) (primeSetProduct T)) →
      (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanDyadicFrequencyFiberMoment
          q (h2BooleanRoughCutoff M) M T j) ≤
        ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          ((primeSetProduct T : ℝ) / (M : ℝ)) *
          PaperB.M4B.shiuFixedQuarterAssembleConstant
            8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
          ((PaperB.M4B.scaledCoverLength
              (2 * M) M (primeSetProduct T) : ℝ) /
            Real.log (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T) : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt)
            (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T))
            (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
  rcases h2BooleanGoodFrequencyFiberSum_le_m3_raw q with ⟨X0, hraw⟩
  refine ⟨X0, ?_⟩
  intro M j hM hY hX
  apply hraw M j hY hX
  · intro T hT
    exact h2Boolean_good_scaled_quarter_real
      (Finset.mem_filter.mp hT).1 hM
  · intro T hT
    exact h2Boolean_scaledCoverLength_le_upper M (primeSetProduct T)
  · intro T hT
    exact h2Boolean_good_scaled_modulus_real hT

#print axioms h2BooleanGoodFrequencyFiberSum_le_m3

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma h2Boolean_active_primeSetProduct_eq_one_iff_empty
    {q : ℕ} {T : Finset ℕ}
    (hT : ∀ p ∈ T, activeHighPrime q p) :
    primeSetProduct T = 1 ↔ T = ∅ := by
  constructor
  · intro hprod
    by_contra hne
    rcases Finset.nonempty_iff_ne_empty.mpr hne with ⟨p, hp⟩
    have hpprime : p.Prime := (hT p hp).1
    have hfac : p ≤ primeSetProduct T := by
      unfold primeSetProduct
      exact Finset.single_le_prod
        (fun r hr => (hT r hr).1.one_le) hp
    rw [hprod] at hfac
    have hp2 := hpprime.two_le
    omega
  · rintro rfl
    rfl

lemma h2BooleanGoodSmoothSets_eq_nontrivial_insert_empty
    (q M : ℕ)
    (hcut : 1 < h2BooleanSmoothProductCutoff M) :
    h2BooleanGoodSmoothSets q M =
      insert ∅ (h2BooleanGoodSmoothSetsNontrivial q M) := by
  ext T
  constructor
  · intro hT
    by_cases hE : T = ∅
    · simp [hE]
    · have hA := h2BooleanGoodSmoothSets_active hT
      have hne1 : primeSetProduct T ≠ 1 := by
        intro h1
        exact hE ((h2Boolean_active_primeSetProduct_eq_one_iff_empty hA).mp h1)
      have hgt : 1 < primeSetProduct T := by
        have hpos := primeSetProduct_pos (fun p hp => (hA p hp).1)
        omega
      simp [h2BooleanGoodSmoothSetsNontrivial, hT, hgt]
  · intro hT
    rw [Finset.mem_insert] at hT
    rcases hT with rfl | hNT
    · unfold h2BooleanGoodSmoothSets
      rw [Finset.mem_filter]
      constructor
      · simp
      · simpa [primeSetProduct] using hcut
    · exact (Finset.mem_filter.mp hNT).1

lemma h2Boolean_empty_not_mem_good_nontrivial
    (q M : ℕ) :
    ∅ ∉ h2BooleanGoodSmoothSetsNontrivial q M := by
  unfold h2BooleanGoodSmoothSetsNontrivial
  rw [Finset.mem_filter]
  simp [primeSetProduct]

theorem h2BooleanGoodFrequencyFiberSum_eq_empty_add_nontrivial
    (q M j : ℕ)
    (hcut : 1 < h2BooleanSmoothProductCutoff M) :
    (∑ T ∈ h2BooleanGoodSmoothSets q M,
      h2BooleanDyadicFrequencyFiberMoment
        q (h2BooleanRoughCutoff M) M T j) =
      h2BooleanDyadicFrequencyFiberMoment
        q (h2BooleanRoughCutoff M) M ∅ j +
      ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanDyadicFrequencyFiberMoment
          q (h2BooleanRoughCutoff M) M T j := by
  rw [h2BooleanGoodSmoothSets_eq_nontrivial_insert_empty q M hcut]
  rw [Finset.sum_insert (h2Boolean_empty_not_mem_good_nontrivial q M)]

theorem h2BooleanEmptyFrequencyFiber_le_exp_rough_mass
    (q M j : ℕ) :
    h2BooleanDyadicFrequencyFiberMoment
        q (h2BooleanRoughCutoff M) M ∅ j ≤
      Real.exp (PaperB.M4B.primeMass
        (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
          h2BooleanSecondTilt)
        (2 * M) 1) := by
  have h := h2BooleanDyadicFrequencyFiberMoment_le_exp_rough_mass
    (q := q) (Y := h2BooleanRoughCutoff M) (M := M)
    (T := ∅) (j := j) (by simp)
  simpa [primeSetProduct, finiteOmegaWeightReal] using h

#print axioms h2BooleanGoodFrequencyFiberSum_eq_empty_add_nontrivial
#print axioms h2BooleanEmptyFrequencyFiber_le_exp_rough_mass

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma h2Boolean_good_scale_length_le_three
    {q M : ℕ} {T : Finset ℕ}
    (hT : T ∈ h2BooleanGoodSmoothSetsNontrivial q M) :
    ((primeSetProduct T : ℝ) / (M : ℝ)) *
        (PaperB.M4B.scaledCoverLength
          (2 * M) M (primeSetProduct T) : ℝ) ≤ 3 := by
  let m := primeSetProduct T
  let y := PaperB.M4B.scaledCoverLength (2 * M) M m
  have hG : T ∈ h2BooleanGoodSmoothSets q M :=
    (Finset.mem_filter.mp hT).1
  have hA := h2BooleanGoodSmoothSets_active hG
  have hm2 : 2 ≤ m := by
    have hgt := h2BooleanGoodSmoothSetsNontrivial_product_gt_one hT
    dsimp [m]
    omega
  have hpow : m ^ 4 ≤ M := by
    simpa [m] using h2BooleanGoodSmoothSets_product_pow_four_le hG
  have hmlepow : m ≤ m ^ 4 := by
    calc
      m = m * 1 := by simp
      _ ≤ m * (m ^ 3) := by
        gcongr
        have : 1 ≤ m := by omega
        exact one_le_pow₀ this
      _ = m ^ 4 := by ring
  have hmle : m ≤ M := hmlepow.trans hpow
  have hMpos : 0 < M := lt_of_lt_of_le (by omega : 0 < m) hmle
  have hy : y ≤ M / m + 2 := by
    simpa [m, y] using
      PaperB.M4B.scaledCoverLength_le
        (x := 2 * M) (y := M) (b := m) (by omega)
  have hmq : m * (M / m) ≤ M := by
    simpa [Nat.mul_comm] using Nat.mul_div_le M m
  have hmy : m * y ≤ 3 * M := by
    calc
      m * y ≤ m * (M / m + 2) := Nat.mul_le_mul_left m hy
      _ = m * (M / m) + 2 * m := by ring
      _ ≤ M + 2 * M := by
        exact Nat.add_le_add hmq (Nat.mul_le_mul_left 2 hmle)
      _ = 3 * M := by ring
  have hmyR : (m : ℝ) * (y : ℝ) ≤ 3 * (M : ℝ) := by
    exact_mod_cast hmy
  have hMR : (0 : ℝ) < M := by exact_mod_cast hMpos
  calc
    ((primeSetProduct T : ℝ) / (M : ℝ)) *
        (PaperB.M4B.scaledCoverLength
          (2 * M) M (primeSetProduct T) : ℝ)
      = ((m : ℝ) * (y : ℝ)) / (M : ℝ) := by
          simp [m, y]
          ring
    _ ≤ (3 * (M : ℝ)) / (M : ℝ) :=
      div_le_div_of_nonneg_right hmyR hMR.le
    _ = 3 := by field_simp [hMR.ne']

lemma h2Boolean_good_scaledCoverUpper_le_twoM_add_one
    {q M : ℕ} {T : Finset ℕ}
    (hT : T ∈ h2BooleanGoodSmoothSetsNontrivial q M) :
    PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T) ≤
      2 * M + 1 := by
  unfold PaperB.M4B.scaledCoverUpper PaperB.M4B.scaledUpper
  have hmpos : 0 < primeSetProduct T := by
    have hA := h2BooleanGoodSmoothSetsNontrivial_active hT
    exact primeSetProduct_pos (fun p hp => (hA p hp).1)
  have hdiv : (2 * M) / primeSetProduct T ≤ 2 * M := by
    exact Nat.div_le_self _ _
  omega

#print axioms h2Boolean_good_scale_length_le_three

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma h2Boolean_good_scaledCoverUpper_ge_threshold
    {q M X0 : ℕ} {T : Finset ℕ}
    (hT : T ∈ h2BooleanGoodSmoothSetsNontrivial q M)
    (hMX : X0 ^ 4 ≤ M) :
    X0 ≤ PaperB.M4B.scaledCoverUpper
      (2 * M) (primeSetProduct T) := by
  let m := primeSetProduct T
  have hG : T ∈ h2BooleanGoodSmoothSets q M :=
    (Finset.mem_filter.mp hT).1
  have hm4 : m ^ 4 ≤ M := by
    simpa [m] using h2BooleanGoodSmoothSets_product_pow_four_le hG
  have hm2 : 2 ≤ m := by
    have hgt := h2BooleanGoodSmoothSetsNontrivial_product_gt_one hT
    dsimp [m]
    omega
  have hXm : X0 * m ≤ M := by
    by_cases h : X0 ≤ m
    · have hXm_m2 : X0 * m ≤ m ^ 2 := by
        simpa [pow_two] using Nat.mul_le_mul_right m h
      have hm2m4 : m ^ 2 ≤ m ^ 4 := by
        have hm1 : 1 ≤ m := by omega
        calc
          m ^ 2 = m * m := by ring
          _ ≤ (m * m) * (m * m) := by
            exact Nat.le_mul_of_pos_right (m * m)
              (Nat.mul_pos (by omega) (by omega))
          _ = m ^ 4 := by ring
      exact hXm_m2.trans (hm2m4.trans hm4)
    · have hmX : m ≤ X0 := Nat.le_of_lt (Nat.lt_of_not_ge h)
      have hX2 : X0 * m ≤ X0 ^ 2 := by
        simpa [pow_two] using Nat.mul_le_mul_left X0 hmX
      have hX1 : 1 ≤ X0 := hmX.trans' (by omega)
      have hX2X4 : X0 ^ 2 ≤ X0 ^ 4 := by
        calc
          X0 ^ 2 = X0 * X0 := by ring
          _ ≤ (X0 * X0) * (X0 * X0) := by
            exact Nat.le_mul_of_pos_right (X0 * X0)
              (Nat.mul_pos (by omega) (by omega))
          _ = X0 ^ 4 := by ring
      exact hX2.trans (hX2X4.trans hMX)
  have hdiv : X0 ≤ M / m :=
    (Nat.le_div_iff_mul_le (by omega : 0 < m)).2 (by
      simpa [Nat.mul_comm] using hXm)
  have hdiv2 : M / m ≤ (2 * M) / m := by
    exact Nat.div_le_div_right (by omega)
  unfold PaperB.M4B.scaledCoverUpper PaperB.M4B.scaledUpper
  exact hdiv.trans (hdiv2.trans (Nat.le_succ _))

theorem h2BooleanGoodFrequencyFiberSum_le_m3_uniform
    (q : ℕ) :
    ∃ M0 : ℕ, ∀ M j : ℕ,
      M0 ≤ M →
      1 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanDyadicFrequencyFiberMoment
          q (h2BooleanRoughCutoff M) M T j) ≤
        ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          ((primeSetProduct T : ℝ) / (M : ℝ)) *
          PaperB.M4B.shiuFixedQuarterAssembleConstant
            8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
          ((PaperB.M4B.scaledCoverLength
              (2 * M) M (primeSetProduct T) : ℝ) /
            Real.log (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T) : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt)
            (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T))
            (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
  rcases h2BooleanGoodFrequencyFiberSum_le_m3 q with ⟨X0, hgood⟩
  refine ⟨X0 ^ 4, ?_⟩
  intro M j hM0 hM hY
  exact hgood M j hM hY
    (fun T hT => h2Boolean_good_scaledCoverUpper_ge_threshold hT hM0)

#print axioms h2Boolean_good_scaledCoverUpper_ge_threshold
#print axioms h2BooleanGoodFrequencyFiberSum_le_m3_uniform

end PaperB.FixedQ


namespace PaperB.FixedQ

/-- Quantitative good-family bound after Shiu geometry.  The two remaining
uniform hypotheses are exactly the moving-cutoff comparison and the
logarithmic lower bound for the scaled cover; both are independent of the
Fourier/M3 argument. -/
theorem h2BooleanGoodFrequencyFiberSum_le_log_power
    (q : ℕ) :
    ∃ M0 : ℕ, ∀ M j : ℕ,
      M0 ≤ M →
      2 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      4 ≤ j →
      (∀ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanRoughCutoff M ≤
          PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)) →
      (∀ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        (1 / 2 : ℝ) * Real.log (M : ℝ) ≤
          Real.log (PaperB.M4B.scaledCoverUpper
            (2 * M) (primeSetProduct T) : ℝ)) →
      (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanDyadicFrequencyFiberMoment
          q (h2BooleanRoughCutoff M) M T j) ≤
        (6 *
          PaperB.M4B.shiuFixedQuarterAssembleConstant
            8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
          Real.exp (6 * h2BooleanV0 + 24) *
          Real.exp (5 * h2BooleanV0 + 24)) *
        ((Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 /
          Real.log (M : ℝ)) *
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) *
        (Real.log (M : ℝ)) ^
          (h2BooleanTheta * (h2BooleanV0 / 2)) *
        (Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by
  rcases h2BooleanGoodFrequencyFiberSum_le_m3_uniform q with ⟨M0, hraw⟩
  refine ⟨M0, ?_⟩
  intro M j hM0 hM hY hj hYX hloglow
  have hM1 : 1 ≤ M := by omega
  have hlogMpos : 0 < Real.log (M : ℝ) := by
    exact Real.log_pos (by exact_mod_cast (show 1 < M by omega))
  have hbase := hraw M j hM0 hM1 hY
  let Csh : ℝ := PaperB.M4B.shiuFixedQuarterAssembleConstant
    8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold)
  let Cr : ℝ := Real.exp (6 * h2BooleanV0 + 24)
  let B : ℝ :=
    6 * Csh * Cr *
      ((Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 /
        Real.log (M : ℝ)) *
      (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0)
  have hB0 : 0 ≤ B := by
    dsimp [B, Csh, Cr, PaperB.M4B.shiuFixedQuarterAssembleConstant,
      PaperB.M4B.shiuClassIVConstant]
    positivity
  have hpoint : ∀ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
      ((primeSetProduct T : ℝ) / (M : ℝ)) * Csh *
          ((PaperB.M4B.scaledCoverLength
              (2 * M) M (primeSetProduct T) : ℝ) /
            Real.log (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T) : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt)
            (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T))
            (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))
        ≤ B * (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
    intro T hT
    let x := PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)
    let y := PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T)
    have hxY : h2BooleanRoughCutoff M ≤ x := by simpa [x] using hYX T hT
    have hx4 : 4 ≤ x := hY.trans hxY
    have hrough := h2BooleanSecondRough_exp_primeMass_cutoff_le
      (q := q) (M := M) (X := x) (k := primeSetProduct T)
      hM (by omega) hxY hx4
    have hxup : x ≤ 2 * M + 1 := by
      simpa [x] using h2Boolean_good_scaledCoverUpper_le_twoM_add_one hT
    have hxpos : (0 : ℝ) < x := by exact_mod_cast (show 0 < x by omega)
    have htoppos : (0 : ℝ) < ((2 * M + 1 : ℕ) : ℝ) := by positivity
    have hlogxpos : 0 < Real.log (x : ℝ) :=
      Real.log_pos (by exact_mod_cast (show 1 < x by omega))
    have hlogup : Real.log (x : ℝ) ≤
        Real.log ((2 * M + 1 : ℕ) : ℝ) :=
      Real.strictMonoOn_log.monotoneOn hxpos htoppos (by exact_mod_cast hxup)
    have hlogtop0 : 0 ≤ Real.log ((2 * M + 1 : ℕ) : ℝ) :=
      Real.log_nonneg (by exact_mod_cast (show 1 ≤ 2 * M + 1 by omega))
    have hpup :
        (Real.log (x : ℝ)) ^ h2BooleanV0 ≤
          (Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 :=
      Real.rpow_le_rpow hlogxpos.le hlogup h2BooleanV0_nonneg
    have hinvlog :
        1 / Real.log (x : ℝ) ≤ 2 / Real.log (M : ℝ) := by
      have hl := hloglow T hT
      have hhalfpos : 0 < (1 / 2 : ℝ) * Real.log (M : ℝ) := by positivity
      have hi := one_div_le_one_div_of_le hhalfpos hl
      have hhalf :
          1 / ((1 / 2 : ℝ) * Real.log (M : ℝ)) =
            2 / Real.log (M : ℝ) := by field_simp [hlogMpos.ne']
      rw [hhalf] at hi
      simpa [x] using hi
    have hscale := h2Boolean_good_scale_length_le_three hT
    have hprod0 : 0 ≤ ∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ) :=
      h2BooleanM3LocalWeight_prod_nonneg (j : ℤ)
        (h2BooleanGoodSmoothSetsNontrivial_active hT)
    have hnegpow0 : 0 ≤
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) :=
      Real.rpow_nonneg hlogMpos.le _
    have hCsh0 : 0 ≤ Csh := by
      dsimp [Csh, PaperB.M4B.shiuFixedQuarterAssembleConstant,
        PaperB.M4B.shiuClassIVConstant]
      positivity
    change
      ((primeSetProduct T : ℝ) / (M : ℝ)) * Csh *
          ((y : ℝ) / Real.log (x : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt) x (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))
        ≤ B * (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))
    rw [show ((y : ℝ) / Real.log (x : ℝ)) =
        (y : ℝ) * (1 / Real.log (x : ℝ)) by ring]
    calc
      ((primeSetProduct T : ℝ) / (M : ℝ)) * Csh *
          ((y : ℝ) * (1 / Real.log (x : ℝ))) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt) x (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))
        = Csh *
          ((((primeSetProduct T : ℝ) / (M : ℝ)) * (y : ℝ)) *
            (1 / Real.log (x : ℝ)) *
            Real.exp (PaperB.M4B.primeMass
              (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
                h2BooleanSecondTilt) x (primeSetProduct T)) *
            (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))) := by ring
      _ ≤ Csh *
          (3 * (2 / Real.log (M : ℝ)) *
            (Cr * (Real.log (x : ℝ)) ^ h2BooleanV0 *
              (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0)) *
            (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))) := by
            apply mul_le_mul_of_nonneg_left _ hCsh0
            gcongr
      _ ≤ Csh *
          (3 * (2 / Real.log (M : ℝ)) *
            (Cr * (Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 *
              (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0)) *
            (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))) := by
            gcongr
      _ = B * (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
            dsimp [B]
            ring
  have hsum :
      (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanDyadicFrequencyFiberMoment
          q (h2BooleanRoughCutoff M) M T j) ≤
        B * ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
    calc
      _ ≤ ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          ((primeSetProduct T : ℝ) / (M : ℝ)) * Csh *
          ((PaperB.M4B.scaledCoverLength
              (2 * M) M (primeSetProduct T) : ℝ) /
            Real.log (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T) : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt)
            (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T))
            (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
            simpa [Csh] using hbase
      _ ≤ ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          B * (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
            apply Finset.sum_le_sum
            intro T hT
            exact hpoint T hT
      _ = B * ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
            rw [Finset.mul_sum]
  have hm3 := h2BooleanM3_sum_family_le_log_powers
    (q := q) (Y := h2BooleanRoughCutoff M) (j := j)
    hY hj (h2BooleanGoodSmoothSetsNontrivial q M)
    (h2BooleanGoodSmoothSetsNontrivial_subset q M)
  have hsmooth := h2BooleanRoughCutoff_smooth_rpow_le hM
  calc
    _ ≤ B * ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := hsum
    _ ≤ B * (Real.exp (5 * h2BooleanV0 + 24) *
        (Real.log (h2BooleanRoughCutoff M : ℝ)) ^ (h2BooleanV0 / 2) *
        (Real.log (j : ℝ)) ^ (h2BooleanV0 / 2)) :=
      mul_le_mul_of_nonneg_left hm3 hB0
    _ ≤ B * (Real.exp (5 * h2BooleanV0 + 24) *
        (Real.log (M : ℝ)) ^
          (h2BooleanTheta * (h2BooleanV0 / 2)) *
        (Real.log (j : ℝ)) ^ (h2BooleanV0 / 2)) := by
      gcongr
    _ = _ := by
      dsimp [B, Csh, Cr]
      ring

#print axioms h2BooleanGoodFrequencyFiberSum_le_log_power

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma h2Boolean_good_scaledCoverUpper_sq_gt_M
    {q M : ℕ} {T : Finset ℕ}
    (hT : T ∈ h2BooleanGoodSmoothSetsNontrivial q M)
    (hroot3 : 3 ≤ Nat.nthRoot 4 M) :
    M <
      (PaperB.M4B.scaledCoverUpper
        (2 * M) (primeSetProduct T)) ^ 2 := by
  let r := Nat.nthRoot 4 M
  let m := primeSetProduct T
  let x := PaperB.M4B.scaledCoverUpper (2 * M) m
  have hG : T ∈ h2BooleanGoodSmoothSets q M :=
    (Finset.mem_filter.mp hT).1
  have hmcut := (Finset.mem_filter.mp hG).2
  have hmle : m ≤ r := by
    unfold h2BooleanSmoothProductCutoff at hmcut
    dsimp [r, m]
    omega
  have hr4 : r ^ 4 ≤ M := by
    exact Nat.pow_nthRoot_le (Or.inl (by norm_num : 4 ≠ 0))
  have hMlt : M < (r + 1) ^ 4 :=
    Nat.lt_pow_nthRoot_add_one (by norm_num : 4 ≠ 0) M
  have hdivr : r ^ 3 ≤ M / m := by
    apply (Nat.le_div_iff_mul_le (by
      have hA := h2BooleanGoodSmoothSetsNontrivial_active hT
      exact primeSetProduct_pos (fun p hp => (hA p hp).1))).2
    have hm_r3 : m * r ^ 3 ≤ r * r ^ 3 :=
      Nat.mul_le_mul_right (r ^ 3) hmle
    calc
      r ^ 3 * m = m * r ^ 3 := by ring
      _ ≤ r * r ^ 3 := hm_r3
      _ = r ^ 4 := by ring
      _ ≤ M := hr4
  have hxdiv : M / m ≤ x := by
    unfold x PaperB.M4B.scaledCoverUpper PaperB.M4B.scaledUpper
    have hbase : M / m ≤ (2 * M) / m := Nat.div_le_div_right (by omega)
    exact hbase.trans (Nat.le_succ _)
  have hr3x : r ^ 3 ≤ x := hdivr.trans hxdiv
  have hrpoly : (r + 1) ^ 2 ≤ r ^ 3 := by
    nlinarith [hroot3]
  have hsquare :
      (r + 1) ^ 4 ≤ x ^ 2 := by
    calc
      (r + 1) ^ 4 = ((r + 1) ^ 2) ^ 2 := by ring
      _ ≤ (r ^ 3) ^ 2 := Nat.pow_le_pow_left hrpoly 2
      _ ≤ x ^ 2 := Nat.pow_le_pow_left hr3x 2
  exact hMlt.trans_le hsquare

lemma h2Boolean_good_scaledCover_log_lower
    {q M : ℕ} {T : Finset ℕ}
    (hT : T ∈ h2BooleanGoodSmoothSetsNontrivial q M)
    (hM : 2 ≤ M)
    (hroot3 : 3 ≤ Nat.nthRoot 4 M) :
    (1 / 2 : ℝ) * Real.log (M : ℝ) <
      Real.log (PaperB.M4B.scaledCoverUpper
        (2 * M) (primeSetProduct T) : ℝ) := by
  let x := PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)
  have hsq := h2Boolean_good_scaledCoverUpper_sq_gt_M hT hroot3
  have hMR : (0 : ℝ) < (M : ℝ) := by exact_mod_cast (show 0 < M by omega)
  have hxR : (0 : ℝ) < (x : ℝ) := by
    have hsqx : M < x ^ 2 := by simpa [x] using hsq
    have hxnat : 0 < x := by
      by_contra hnot
      have hx0 : x = 0 := Nat.eq_zero_of_not_pos hnot
      rw [hx0] at hsqx
      simp at hsqx
    exact_mod_cast hxnat
  have hsqR : (M : ℝ) < (x : ℝ) ^ (2 : ℕ) := by exact_mod_cast hsq
  have hlog := Real.log_lt_log hMR hsqR
  rw [Real.log_pow] at hlog
  norm_num at hlog
  change (1 / 2 : ℝ) * Real.log (M : ℝ) < Real.log (x : ℝ)
  nlinarith

lemma h2Boolean_good_roughCutoff_le_scaledCover
    {q M : ℕ} {T : Finset ℕ}
    (hT : T ∈ h2BooleanGoodSmoothSetsNontrivial q M)
    (hroot3 : 3 ≤ Nat.nthRoot 4 M)
    (hYsq : (h2BooleanRoughCutoff M) ^ 2 ≤ M) :
    h2BooleanRoughCutoff M ≤
      PaperB.M4B.scaledCoverUpper
        (2 * M) (primeSetProduct T) := by
  have hMx := h2Boolean_good_scaledCoverUpper_sq_gt_M hT hroot3
  by_contra hnot
  have hxY :
      PaperB.M4B.scaledCoverUpper
        (2 * M) (primeSetProduct T) < h2BooleanRoughCutoff M :=
    Nat.lt_of_not_ge hnot
  have hxsq :
      (PaperB.M4B.scaledCoverUpper
        (2 * M) (primeSetProduct T)) ^ 2 <
      (h2BooleanRoughCutoff M) ^ 2 :=
    Nat.pow_lt_pow_left hxY (by norm_num)
  omega

#print axioms h2Boolean_good_scaledCoverUpper_sq_gt_M
#print axioms h2Boolean_good_scaledCover_log_lower
#print axioms h2Boolean_good_roughCutoff_le_scaledCover

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem h2BooleanGoodFrequencyFiberSum_le_log_power_closed
    (q : ℕ) :
    ∃ M0 : ℕ, ∀ M j : ℕ,
      M0 ≤ M →
      2 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      4 ≤ j →
      3 ≤ Nat.nthRoot 4 M →
      (h2BooleanRoughCutoff M) ^ 2 ≤ M →
      (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanDyadicFrequencyFiberMoment
          q (h2BooleanRoughCutoff M) M T j) ≤
        (6 *
          PaperB.M4B.shiuFixedQuarterAssembleConstant
            8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
          Real.exp (6 * h2BooleanV0 + 24) *
          Real.exp (5 * h2BooleanV0 + 24)) *
        ((Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 /
          Real.log (M : ℝ)) *
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) *
        (Real.log (M : ℝ)) ^
          (h2BooleanTheta * (h2BooleanV0 / 2)) *
        (Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by
  rcases h2BooleanGoodFrequencyFiberSum_le_log_power q with ⟨M0, hgood⟩
  refine ⟨M0, ?_⟩
  intro M j hM0 hM hY hj hroot hYsq
  exact hgood M j hM0 hM hY hj
    (fun T hT => h2Boolean_good_roughCutoff_le_scaledCover hT hroot hYsq)
    (fun T hT => (h2Boolean_good_scaledCover_log_lower hT hM hroot).le)

#print axioms h2BooleanGoodFrequencyFiberSum_le_log_power_closed

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma h2BooleanTilt_progression_zero_of_not_coprime
    (q x y a : ℕ) (c : ℝ)
    (ha : ¬ a.Coprime (6 * q)) :
    PaperB.M4B.progressionSum
      (h2BooleanTiltLift q c) x y (6 * q) a = 0 := by
  unfold PaperB.M4B.progressionSum
  apply Finset.sum_eq_zero
  intro n hn
  by_cases hmod : n ≡ a [MOD 6 * q]
  · rw [if_pos hmod]
    apply h2BooleanTiltLift_eq_zero_of_not_coprime
    intro hncop
    exact ha (PaperB.M4B.coprime_of_modEq_reduced hncop hmod.symm)
  · rw [if_neg hmod]

theorem h2BooleanSecondTilt_interval_shiu
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ X0 : ℕ, ∀ M : ℕ,
      X0 ≤ 2 * M →
      4 ≤ 2 * M →
      ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
      ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
      (∑ n ∈ Finset.Ioc M (2 * M),
        h2BooleanTiltLift q h2BooleanSecondTilt n) ≤
      C *
        ((M : ℝ) /
          (((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ))) *
        Real.exp
          (PaperB.M4B.primeMass
            (h2BooleanTiltLift q h2BooleanSecondTilt) (2 * M) (6 * q)) := by
  rcases h2BooleanSecondTiltLift_progression q with ⟨CS, X0, hS⟩
  refine ⟨(6 * q : ℝ) * |CS|, X0, ?_⟩
  intro M hX h4 hquarter hk
  have hkpos : 0 < 6 * q := by omega
  have hpart := h2_sum_progressionSum_range_eq_interval
    (h2BooleanTiltLift q h2BooleanSecondTilt) (2 * M) M (6 * q) hkpos
  have hsub : 2 * M - M = M := by omega
  rw [hsub] at hpart
  have hbase0 :
      0 ≤ (M : ℝ) /
        (((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ)) := by
    have hM2 : 2 ≤ M := by omega
    have hlog : 0 < Real.log ((2 * M : ℕ) : ℝ) := by
      apply Real.log_pos
      exact_mod_cast (show 1 < 2 * M by omega)
    have hphi : 0 < ((6 * q).totient : ℝ) := by
      exact_mod_cast Nat.totient_pos.mpr hkpos
    positivity
  have hexp0 :
      0 ≤ Real.exp
        (PaperB.M4B.primeMass
          (h2BooleanTiltLift q h2BooleanSecondTilt) (2 * M) (6 * q)) :=
    (Real.exp_pos _).le
  rw [← hpart]
  calc
    (∑ a ∈ Finset.range (6 * q),
      PaperB.M4B.progressionSum
        (h2BooleanTiltLift q h2BooleanSecondTilt)
        (2 * M) M (6 * q) a)
      ≤ ∑ _a ∈ Finset.range (6 * q),
        |CS| *
          ((M : ℝ) /
            (((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ))) *
          Real.exp
            (PaperB.M4B.primeMass
              (h2BooleanTiltLift q h2BooleanSecondTilt)
              (2 * M) (6 * q)) := by
        apply Finset.sum_le_sum
        intro a ha
        by_cases hcop : a.Coprime (6 * q)
        · have halt : a < 6 * q := Finset.mem_range.mp ha
          have ha0 : 0 < a := by
            by_contra hna
            have haeq : a = 0 := Nat.eq_zero_of_not_pos hna
            subst a
            have hk1 : 6 * q = 1 := hcop.symm.eq_one_of_dvd (dvd_zero _)
            omega
          have hrow := hS (2 * M) M (6 * q) a
            hX hquarter (by omega) hk ha0 halt hcop
          calc
            PaperB.M4B.progressionSum
                (h2BooleanTiltLift q h2BooleanSecondTilt)
                (2 * M) M (6 * q) a
                ≤ CS *
                    ((M : ℝ) /
                      (((6 * q).totient : ℝ) *
                        Real.log ((2 * M : ℕ) : ℝ))) *
                    Real.exp
                      (PaperB.M4B.primeMass
                        (h2BooleanTiltLift q h2BooleanSecondTilt)
                        (2 * M) (6 * q)) := hrow
            _ ≤ |CS| *
                    ((M : ℝ) /
                      (((6 * q).totient : ℝ) *
                        Real.log ((2 * M : ℕ) : ℝ))) *
                    Real.exp
                      (PaperB.M4B.primeMass
                        (h2BooleanTiltLift q h2BooleanSecondTilt)
                        (2 * M) (6 * q)) := by
                  gcongr
                  exact le_abs_self CS
        · rw [h2BooleanTilt_progression_zero_of_not_coprime
              q (2 * M) M a h2BooleanSecondTilt hcop]
          positivity
    _ = (6 * q : ℝ) * |CS| *
          ((M : ℝ) /
            (((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ))) *
          Real.exp
            (PaperB.M4B.primeMass
              (h2BooleanTiltLift q h2BooleanSecondTilt)
              (2 * M) (6 * q)) := by
        simp
        ring

#print axioms h2BooleanSecondTilt_interval_shiu

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem h2BooleanEmptyFrequencyFiber_le_secondTilt_interval
    {q Y M j : ℕ} (hM : 0 < M) :
    h2BooleanDyadicFrequencyFiberMoment q Y M ∅ j ≤
      (M : ℝ)⁻¹ *
        (∑ n ∈ Finset.Ioc M (2 * M),
          h2BooleanTiltLift q h2BooleanSecondTilt n) := by
  have hrough :=
    h2BooleanDyadicFrequencyFiberMoment_le_roughProducts
      (q := q) (Y := Y) (M := M) (T := ∅) (j := j) (by simp)
  have hrough' :
      h2BooleanDyadicFrequencyFiberMoment q Y M ∅ j ≤
        ∑ r ∈ h2BooleanDyadicRoughProducts q Y M ∅,
          h2BooleanRoughFiberTerm q Y ∅ (by simp) j r := by
    simpa [finiteOmegaWeightReal, primeSetProduct] using hrough
  let R := h2BooleanDyadicRoughProducts q Y M ∅
  have hpoint : ∀ r ∈ R,
      h2BooleanRoughFiberTerm q Y ∅ (by simp) j r ≤
        (M : ℝ)⁻¹ * h2BooleanTiltLift q h2BooleanSecondTilt r := by
    intro r hr
    have hcop := h2BooleanDyadicRoughProducts_coprime_smooth
      (q := q) (Y := Y) (M := M) (T := ∅) hr
    rw [h2BooleanRoughFiberTerm_eq_of_coprime (T := ∅) (by simp) j r hcop]
    have hcoeff := norm_fixedProductBooleanFourierCoeff_le_one
      (∅ : Finset ℕ) (by simp)
      ((j : ZMod (primeSetProduct ∅)) *
        (((ZMod.unitOfCoprime r hcop)⁻¹ :
          (ZMod (primeSetProduct ∅))ˣ) : ZMod (primeSetProduct ∅)))
    have hcoeff0 : 0 ≤
        ‖fixedProductBooleanFourierCoeff (∅ : Finset ℕ) (by simp)
          ((j : ZMod (primeSetProduct ∅)) *
            (((ZMod.unitOfCoprime r hcop)⁻¹ :
              (ZMod (primeSetProduct ∅))ˣ) : ZMod (primeSetProduct ∅)))‖ :=
      norm_nonneg _
    have hsqle :
        ‖fixedProductBooleanFourierCoeff (∅ : Finset ℕ) (by simp)
          ((j : ZMod (primeSetProduct ∅)) *
            (((ZMod.unitOfCoprime r hcop)⁻¹ :
              (ZMod (primeSetProduct ∅))ˣ) : ZMod (primeSetProduct ∅)))‖ ^ 2 ≤ 1 := by
      nlinarith
    have hrange := h2BooleanDyadicRoughProducts_range
      (q := q) (Y := Y) (M := M) (T := ∅) hr
    simp [primeSetProduct] at hrange
    have hrpos : (0 : ℝ) < r := by exact_mod_cast (lt_trans hM hrange.1)
    have hMposR : (0 : ℝ) < M := by exact_mod_cast hM
    have hMr : (M : ℝ) ≤ (r : ℝ) := by
      exact_mod_cast hrange.1.le
    have hinv : (r : ℝ)⁻¹ ≤ (M : ℝ)⁻¹ := by
      simpa [one_div] using one_div_le_one_div_of_le hMposR hMr
    have hroughEq := h2BooleanDyadicRoughProducts_roughLift_eq
      (q := q) (Y := Y) (M := M) (T := ∅) hr
    have hfull0 : 0 ≤ h2BooleanTiltLift q h2BooleanSecondTilt r :=
      h2BooleanTiltLift_nonneg q r h2BooleanSecondTilt_nonneg
    rw [hroughEq]
    rw [div_eq_mul_inv]
    calc
      (h2BooleanTiltLift q h2BooleanSecondTilt r * (r : ℝ)⁻¹) *
          ‖fixedProductBooleanFourierCoeff (∅ : Finset ℕ) (by simp)
            ((j : ZMod (primeSetProduct ∅)) *
              (((ZMod.unitOfCoprime r hcop)⁻¹ :
                (ZMod (primeSetProduct ∅))ˣ) : ZMod (primeSetProduct ∅)))‖ ^ 2
        ≤ h2BooleanTiltLift q h2BooleanSecondTilt r * (r : ℝ)⁻¹ := by
          exact mul_le_of_le_one_right
            (mul_nonneg hfull0 (inv_nonneg.mpr hrpos.le)) hsqle
      _ ≤ h2BooleanTiltLift q h2BooleanSecondTilt r * (M : ℝ)⁻¹ :=
        mul_le_mul_of_nonneg_left hinv hfull0
      _ = (M : ℝ)⁻¹ * h2BooleanTiltLift q h2BooleanSecondTilt r := by ring
  have hsub : R ⊆ Finset.Ioc M (2 * M) := by
    intro r hr
    have hrange := h2BooleanDyadicRoughProducts_range
      (q := q) (Y := Y) (M := M) (T := ∅) hr
    simp [R, primeSetProduct] at hrange ⊢
    exact hrange
  have hsum :
      (∑ r ∈ R, h2BooleanRoughFiberTerm q Y ∅ (by simp) j r) ≤
        ∑ r ∈ Finset.Ioc M (2 * M),
          (M : ℝ)⁻¹ * h2BooleanTiltLift q h2BooleanSecondTilt r := by
    calc
      _ ≤ ∑ r ∈ R,
          (M : ℝ)⁻¹ * h2BooleanTiltLift q h2BooleanSecondTilt r := by
            apply Finset.sum_le_sum
            intro r hr
            exact hpoint r hr
      _ ≤ ∑ r ∈ Finset.Ioc M (2 * M),
          (M : ℝ)⁻¹ * h2BooleanTiltLift q h2BooleanSecondTilt r := by
            apply Finset.sum_le_sum_of_subset_of_nonneg hsub
            intro r hr hnot
            exact mul_nonneg (inv_nonneg.mpr (by positivity))
              (h2BooleanTiltLift_nonneg q r h2BooleanSecondTilt_nonneg)
  calc
    h2BooleanDyadicFrequencyFiberMoment q Y M ∅ j
      ≤ ∑ r ∈ R, h2BooleanRoughFiberTerm q Y ∅ (by simp) j r := by
          simpa [R] using hrough'
    _ ≤ ∑ r ∈ Finset.Ioc M (2 * M),
          (M : ℝ)⁻¹ * h2BooleanTiltLift q h2BooleanSecondTilt r := hsum
    _ = (M : ℝ)⁻¹ *
        (∑ n ∈ Finset.Ioc M (2 * M),
          h2BooleanTiltLift q h2BooleanSecondTilt n) := by
          rw [Finset.mul_sum]

#print axioms h2BooleanEmptyFrequencyFiber_le_secondTilt_interval

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem h2BooleanSecondTilt_interval_log_power
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ X0 : ℕ, ∀ M : ℕ,
      X0 ≤ M →
      ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
      ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
      (∑ n ∈ Finset.Ioc M (2 * M),
        h2BooleanTiltLift q h2BooleanSecondTilt n) ≤
      C * (M : ℝ) *
        (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanV0 - 1) := by
  rcases h2BooleanSecondTilt_interval_shiu q hq with ⟨CS, XS, hS⟩
  let E : ℝ := Real.exp (10 * h2BooleanSecondTilt + 24)
  refine ⟨|CS| * E, max XS 2, ?_⟩
  intro M hM hquarter hk
  have hXS : XS ≤ 2 * M := by
    have : XS ≤ M := (le_max_left XS 2).trans hM
    omega
  have hM2 : 2 ≤ M := (le_max_right XS 2).trans hM
  have h4 : 4 ≤ 2 * M := by omega
  have hraw := hS M hXS h4 hquarter hk
  have hmass :=
    h2BooleanSecondTiltLift_exp_primeMass_le
      q (2 * M) (6 * q) h4
  have hlog : 0 < Real.log ((2 * M : ℕ) : ℝ) := by
    apply Real.log_pos
    exact_mod_cast (show 1 < 2 * M by omega)
  have hkpos : 0 < 6 * q := by omega
  have hphiNat : 0 < (6 * q).totient :=
    Nat.totient_pos.mpr hkpos
  have hphi : (1 : ℝ) ≤ ((6 * q).totient : ℝ) := by
    exact_mod_cast hphiNat
  have hbase :
      (M : ℝ) /
          (((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ))
        ≤ (M : ℝ) / Real.log ((2 * M : ℕ) : ℝ) := by
    have hden :
        Real.log ((2 * M : ℕ) : ℝ) ≤
          ((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ) := by
      nlinarith
    exact div_le_div_of_nonneg_left (by positivity) hlog hden
  have hpow0 :
      0 ≤ (Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0 :=
    Real.rpow_nonneg hlog.le _
  have hE0 : 0 ≤ E := (Real.exp_pos _).le
  calc
    (∑ n ∈ Finset.Ioc M (2 * M),
        h2BooleanTiltLift q h2BooleanSecondTilt n)
        ≤ CS *
          ((M : ℝ) /
            (((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ))) *
          Real.exp
            (PaperB.M4B.primeMass
              (h2BooleanTiltLift q h2BooleanSecondTilt) (2 * M) (6 * q)) := hraw
    _ ≤ |CS| *
          ((M : ℝ) /
            (((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ))) *
          Real.exp
            (PaperB.M4B.primeMass
              (h2BooleanTiltLift q h2BooleanSecondTilt) (2 * M) (6 * q)) := by
          gcongr
          exact le_abs_self CS
    _ ≤ |CS| *
          ((M : ℝ) / Real.log ((2 * M : ℕ) : ℝ)) *
          Real.exp
            (PaperB.M4B.primeMass
              (h2BooleanTiltLift q h2BooleanSecondTilt) (2 * M) (6 * q)) := by
          gcongr
    _ ≤ |CS| *
          ((M : ℝ) / Real.log ((2 * M : ℕ) : ℝ)) *
          (E * (Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0) := by
          dsimp [E]
          gcongr
    _ = (|CS| * E) * (M : ℝ) *
          (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanV0 - 1) := by
          rw [Real.rpow_sub_one hlog.ne' h2BooleanV0]
          field_simp [hlog.ne']

theorem h2BooleanEmptyFrequencyFiber_le_log_power
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ M0 : ℕ, ∀ M Y j : ℕ,
      M0 ≤ M →
      2 ≤ M →
      ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
      ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
      h2BooleanDyadicFrequencyFiberMoment q Y M ∅ j ≤
        C * (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanV0 - 1) := by
  rcases h2BooleanSecondTilt_interval_log_power q hq with ⟨C, M0, hI⟩
  refine ⟨C, M0, ?_⟩
  intro M Y j hM hM2 hquarter hk
  have hMpos : 0 < M := by omega
  have hraw := h2BooleanEmptyFrequencyFiber_le_secondTilt_interval
    (q := q) (Y := Y) (M := M) (j := j) hMpos
  have hI' := hI M hM hquarter hk
  calc
    h2BooleanDyadicFrequencyFiberMoment q Y M ∅ j
      ≤ (M : ℝ)⁻¹ *
          (∑ n ∈ Finset.Ioc M (2 * M),
            h2BooleanTiltLift q h2BooleanSecondTilt n) := hraw
    _ ≤ (M : ℝ)⁻¹ *
          (C * (M : ℝ) *
            (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanV0 - 1)) := by
          gcongr
    _ = C * (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanV0 - 1) := by
          have hMR : (M : ℝ) ≠ 0 := by exact_mod_cast hMpos.ne'
          field_simp [hMR]

#print axioms h2BooleanSecondTilt_interval_log_power
#print axioms h2BooleanEmptyFrequencyFiber_le_log_power

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem h2BooleanBadFrequencyFiberSum_le_log_power_raw
    {q M j : ℕ}
    (hM : 2 ≤ M)
    (hY4 : 4 ≤ h2BooleanRoughCutoff M)
    (hYsq : (h2BooleanRoughCutoff M) ^ 2 ≤ M)
    (hlog : 1 ≤ Real.log (M : ℝ))
    (hC : h2BooleanTailCorrectionConst ≤
      (1 / 8 : ℝ) * (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) :
    (∑ T ∈ h2BooleanBadSmoothSets q M,
      h2BooleanDyadicFrequencyFiberMoment
        q (h2BooleanRoughCutoff M) M T j) ≤
      (Real.exp (6 * h2BooleanV0 + 24) *
        (Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0 *
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0)) *
      (Real.exp (10 * h2BooleanSecondTilt + 24) *
        (Real.log (h2BooleanRoughCutoff M : ℝ)) ^ h2BooleanV0 *
        Real.exp (-(1 / 8 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta))) := by
  have hbad := h2BooleanBadFrequencyFiberSum_le_rankin
    (q := q) (M := M) (j := j) hM hlog hC
  have hY1 : 1 ≤ h2BooleanRoughCutoff M := by omega
  have hYleM : h2BooleanRoughCutoff M ≤ M := by
    have hYY : h2BooleanRoughCutoff M ≤
        (h2BooleanRoughCutoff M) ^ 2 := by
      calc
        h2BooleanRoughCutoff M =
            h2BooleanRoughCutoff M * 1 := by simp
        _ ≤ h2BooleanRoughCutoff M * h2BooleanRoughCutoff M := by
          exact Nat.mul_le_mul_left _ hY1
        _ = (h2BooleanRoughCutoff M) ^ 2 := by ring
    exact hYY.trans hYsq
  have hYX : h2BooleanRoughCutoff M ≤ 2 * M := hYleM.trans (by omega)
  have hX4 : 4 ≤ 2 * M := by omega
  have hrough := h2BooleanSecondRough_exp_primeMass_cutoff_le
    (q := q) (M := M) (X := 2 * M) (k := 1)
    hM (by omega) hYX hX4
  have hsmooth := h2BooleanSecondTiltLift_exp_primeMass_le
    q (h2BooleanRoughCutoff M) q hY4
  have hR0 : 0 ≤
      Real.exp (-(1 / 8 : ℝ) *
        (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) :=
    (Real.exp_pos _).le
  have hroughR0 : 0 ≤
      Real.exp
        (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
            h2BooleanSecondTilt)
          (2 * M) 1) := (Real.exp_pos _).le
  calc
    (∑ T ∈ h2BooleanBadSmoothSets q M,
      h2BooleanDyadicFrequencyFiberMoment
        q (h2BooleanRoughCutoff M) M T j)
      ≤ Real.exp
          (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt)
            (2 * M) 1) *
        Real.exp
          (PaperB.M4B.primeMass
            (h2BooleanTiltLift q h2BooleanSecondTilt)
            (h2BooleanRoughCutoff M) q -
          (1 / 8 : ℝ) *
            (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) := hbad
    _ = Real.exp
          (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt)
            (2 * M) 1) *
        (Real.exp
          (PaperB.M4B.primeMass
            (h2BooleanTiltLift q h2BooleanSecondTilt)
            (h2BooleanRoughCutoff M) q) *
          Real.exp (-(1 / 8 : ℝ) *
            (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta))) := by
          rw [show
            PaperB.M4B.primeMass
                (h2BooleanTiltLift q h2BooleanSecondTilt)
                (h2BooleanRoughCutoff M) q -
              (1 / 8 : ℝ) *
                (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) =
            PaperB.M4B.primeMass
                (h2BooleanTiltLift q h2BooleanSecondTilt)
                (h2BooleanRoughCutoff M) q +
              (-(1 / 8 : ℝ) *
                (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) by ring]
          rw [Real.exp_add]
    _ ≤
      (Real.exp (6 * h2BooleanV0 + 24) *
        (Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0 *
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0)) *
      (Real.exp
          (PaperB.M4B.primeMass
            (h2BooleanTiltLift q h2BooleanSecondTilt)
            (h2BooleanRoughCutoff M) q) *
        Real.exp (-(1 / 8 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta))) := by
            gcongr
    _ ≤
      (Real.exp (6 * h2BooleanV0 + 24) *
        (Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0 *
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0)) *
      (Real.exp (10 * h2BooleanSecondTilt + 24) *
        (Real.log (h2BooleanRoughCutoff M : ℝ)) ^ h2BooleanV0 *
        Real.exp (-(1 / 8 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta))) := by
            gcongr

#print axioms h2BooleanBadFrequencyFiberSum_le_log_power_raw

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma h2BooleanRoughTiltLift_eq_zero_of_not_coprime
    (q Y n : ℕ) {c : ℝ} (hc : 0 ≤ c)
    (hcop : ¬ n.Coprime (6 * q)) :
    h2BooleanRoughTiltLift q Y c n = 0 := by
  have hfull := h2BooleanTiltLift_eq_zero_of_not_coprime
    (q := q) (n := n) (c := c) hcop
  have hnon := h2BooleanRoughTiltLift_nonneg q Y n hc
  have hle := h2BooleanRoughTiltLift_le q Y n hc
  rw [hfull] at hle
  linarith

lemma h2BooleanRoughTilt_progression_zero_of_not_coprime
    (q Y x y a : ℕ) {c : ℝ} (hc : 0 ≤ c)
    (ha : ¬ a.Coprime (6 * q)) :
    PaperB.M4B.progressionSum
      (h2BooleanRoughTiltLift q Y c) x y (6 * q) a = 0 := by
  unfold PaperB.M4B.progressionSum
  apply Finset.sum_eq_zero
  intro n hn
  by_cases hmod : n ≡ a [MOD 6 * q]
  · rw [if_pos hmod]
    apply h2BooleanRoughTiltLift_eq_zero_of_not_coprime q Y n hc
    intro hncop
    exact ha (PaperB.M4B.coprime_of_modEq_reduced hncop hmod.symm)
  · rw [if_neg hmod]

/-- Uniform-in-the-moving-cutoff short-interval Shiu bound for the rough
second tilt. The threshold is fixed before the cutoff parameter. -/
theorem h2BooleanRoughSecondTilt_interval_shiu_uniform
    (q : ℕ) (hq : 0 < q) :
    ∃ X0 : ℕ, ∀ Y M : ℕ,
      X0 ≤ 2 * M →
      4 ≤ 2 * M →
      ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
      ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
      (∑ n ∈ Finset.Ioc M (2 * M),
        h2BooleanRoughTiltLift q Y h2BooleanSecondTilt n) ≤
      (6 * q : ℝ) *
        PaperB.M4B.shiuFixedQuarterAssembleConstant
          8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
        ((M : ℝ) /
          (((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ))) *
        Real.exp
          (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
            (2 * M) (6 * q)) := by
  rcases PaperB.M4B.shiuFixedQuarter_progression_uniform
      8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) with ⟨X0, hS⟩
  refine ⟨X0, ?_⟩
  intro Y M hX h4 hquarter hk
  have hkpos : 0 < 6 * q := by omega
  have hpart := h2_sum_progressionSum_range_eq_interval
    (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
    (2 * M) M (6 * q) hkpos
  have hsub : 2 * M - M = M := by omega
  rw [hsub] at hpart
  have henv := h2BooleanRoughTiltLift_envelope q Y
    h2BooleanSecondTilt_nonneg h2BooleanSecondTilt_le_three_halves
  have hbase0 :
      0 ≤ (M : ℝ) /
        (((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ)) := by
    have hM2 : 2 ≤ M := by omega
    have hlog : 0 < Real.log ((2 * M : ℕ) : ℝ) := by
      apply Real.log_pos
      exact_mod_cast (show 1 < 2 * M by omega)
    have hphi : 0 < ((6 * q).totient : ℝ) := by
      exact_mod_cast Nat.totient_pos.mpr hkpos
    positivity
  have hexp0 :
      0 ≤ Real.exp
        (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
          (2 * M) (6 * q)) := (Real.exp_pos _).le
  rw [← hpart]
  calc
    (∑ a ∈ Finset.range (6 * q),
      PaperB.M4B.progressionSum
        (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
        (2 * M) M (6 * q) a)
      ≤ ∑ _a ∈ Finset.range (6 * q),
        PaperB.M4B.shiuFixedQuarterAssembleConstant
          8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
          ((M : ℝ) /
            (((6 * q).totient : ℝ) *
              Real.log ((2 * M : ℕ) : ℝ))) *
          Real.exp
            (PaperB.M4B.primeMass
              (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
              (2 * M) (6 * q)) := by
        apply Finset.sum_le_sum
        intro a ha
        by_cases hcop : a.Coprime (6 * q)
        · have halt : a < 6 * q := Finset.mem_range.mp ha
          have ha0 : 0 < a := by
            by_contra hna
            have haeq : a = 0 := Nat.eq_zero_of_not_pos hna
            subst a
            have hk1 : 6 * q = 1 := hcop.symm.eq_one_of_dvd (dvd_zero _)
            omega
          exact hS
            (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt) henv
            (2 * M) M (6 * q) a
            hX hquarter (by omega) hk ha0 halt hcop
        · rw [h2BooleanRoughTilt_progression_zero_of_not_coprime
              q Y (2 * M) M a h2BooleanSecondTilt_nonneg hcop]
          have hCsh0 : 0 ≤
              PaperB.M4B.shiuFixedQuarterAssembleConstant
                8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) := by
            unfold PaperB.M4B.shiuFixedQuarterAssembleConstant
              PaperB.M4B.shiuClassIVConstant
            positivity
          exact mul_nonneg (mul_nonneg hCsh0 hbase0) hexp0
    _ =
      (6 * q : ℝ) *
        PaperB.M4B.shiuFixedQuarterAssembleConstant
          8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
        ((M : ℝ) /
          (((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ))) *
        Real.exp
          (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
            (2 * M) (6 * q)) := by
      simp
      ring

#print axioms h2BooleanRoughSecondTilt_interval_shiu_uniform

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem h2BooleanEmptyFrequencyFiber_le_rough_interval
    {q Y M j : ℕ} (hM : 0 < M) :
    h2BooleanDyadicFrequencyFiberMoment q Y M ∅ j ≤
      (M : ℝ)⁻¹ *
        (∑ n ∈ Finset.Ioc M (2 * M),
          h2BooleanRoughTiltLift q Y h2BooleanSecondTilt n) := by
  have hrough :=
    h2BooleanDyadicFrequencyFiberMoment_le_roughProducts
      (q := q) (Y := Y) (M := M) (T := ∅) (j := j) (by simp)
  have hrough' :
      h2BooleanDyadicFrequencyFiberMoment q Y M ∅ j ≤
        ∑ r ∈ h2BooleanDyadicRoughProducts q Y M ∅,
          h2BooleanRoughFiberTerm q Y ∅ (by simp) j r := by
    simpa [finiteOmegaWeightReal, primeSetProduct] using hrough
  let R := h2BooleanDyadicRoughProducts q Y M ∅
  have hpoint : ∀ r ∈ R,
      h2BooleanRoughFiberTerm q Y ∅ (by simp) j r ≤
        (M : ℝ)⁻¹ *
          h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r := by
    intro r hr
    have hcop := h2BooleanDyadicRoughProducts_coprime_smooth
      (q := q) (Y := Y) (M := M) (T := ∅) hr
    rw [h2BooleanRoughFiberTerm_eq_of_coprime (T := ∅) (by simp) j r hcop]
    have hcoeff := norm_fixedProductBooleanFourierCoeff_le_one
      (∅ : Finset ℕ) (by simp)
      ((j : ZMod (primeSetProduct ∅)) *
        (((ZMod.unitOfCoprime r hcop)⁻¹ :
          (ZMod (primeSetProduct ∅))ˣ) : ZMod (primeSetProduct ∅)))
    have hcoeff0 : 0 ≤
        ‖fixedProductBooleanFourierCoeff (∅ : Finset ℕ) (by simp)
          ((j : ZMod (primeSetProduct ∅)) *
            (((ZMod.unitOfCoprime r hcop)⁻¹ :
              (ZMod (primeSetProduct ∅))ˣ) : ZMod (primeSetProduct ∅)))‖ :=
      norm_nonneg _
    have hsqle :
        ‖fixedProductBooleanFourierCoeff (∅ : Finset ℕ) (by simp)
          ((j : ZMod (primeSetProduct ∅)) *
            (((ZMod.unitOfCoprime r hcop)⁻¹ :
              (ZMod (primeSetProduct ∅))ˣ) : ZMod (primeSetProduct ∅)))‖ ^ 2 ≤ 1 := by
      nlinarith
    have hrange := h2BooleanDyadicRoughProducts_range
      (q := q) (Y := Y) (M := M) (T := ∅) hr
    simp [primeSetProduct] at hrange
    have hrpos : (0 : ℝ) < r := by exact_mod_cast (lt_trans hM hrange.1)
    have hMposR : (0 : ℝ) < M := by exact_mod_cast hM
    have hMr : (M : ℝ) ≤ (r : ℝ) := by exact_mod_cast hrange.1.le
    have hinv : (r : ℝ)⁻¹ ≤ (M : ℝ)⁻¹ := by
      simpa [one_div] using one_div_le_one_div_of_le hMposR hMr
    have hf0 : 0 ≤ h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r :=
      h2BooleanRoughTiltLift_nonneg q Y r h2BooleanSecondTilt_nonneg
    rw [div_eq_mul_inv]
    calc
      (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r * (r : ℝ)⁻¹) *
          ‖fixedProductBooleanFourierCoeff (∅ : Finset ℕ) (by simp)
            ((j : ZMod (primeSetProduct ∅)) *
              (((ZMod.unitOfCoprime r hcop)⁻¹ :
                (ZMod (primeSetProduct ∅))ˣ) : ZMod (primeSetProduct ∅)))‖ ^ 2
        ≤ h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r * (r : ℝ)⁻¹ := by
          exact mul_le_of_le_one_right
            (mul_nonneg hf0 (inv_nonneg.mpr hrpos.le)) hsqle
      _ ≤ h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r * (M : ℝ)⁻¹ :=
        mul_le_mul_of_nonneg_left hinv hf0
      _ = (M : ℝ)⁻¹ *
          h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r := by ring
  have hsub : R ⊆ Finset.Ioc M (2 * M) := by
    intro r hr
    have hrange := h2BooleanDyadicRoughProducts_range
      (q := q) (Y := Y) (M := M) (T := ∅) hr
    simp [primeSetProduct] at hrange ⊢
    exact hrange
  have hsum :
      (∑ r ∈ R, h2BooleanRoughFiberTerm q Y ∅ (by simp) j r) ≤
        ∑ r ∈ Finset.Ioc M (2 * M),
          (M : ℝ)⁻¹ *
            h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r := by
    calc
      _ ≤ ∑ r ∈ R,
          (M : ℝ)⁻¹ *
            h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r := by
            apply Finset.sum_le_sum
            intro r hr
            exact hpoint r hr
      _ ≤ ∑ r ∈ Finset.Ioc M (2 * M),
          (M : ℝ)⁻¹ *
            h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r := by
            apply Finset.sum_le_sum_of_subset_of_nonneg hsub
            intro r hr hnot
            exact mul_nonneg (inv_nonneg.mpr (by positivity))
              (h2BooleanRoughTiltLift_nonneg
                q Y r h2BooleanSecondTilt_nonneg)
  calc
    h2BooleanDyadicFrequencyFiberMoment q Y M ∅ j
      ≤ ∑ r ∈ R, h2BooleanRoughFiberTerm q Y ∅ (by simp) j r := by
          simpa [R] using hrough'
    _ ≤ ∑ r ∈ Finset.Ioc M (2 * M),
          (M : ℝ)⁻¹ *
            h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r := hsum
    _ = (M : ℝ)⁻¹ *
        (∑ n ∈ Finset.Ioc M (2 * M),
          h2BooleanRoughTiltLift q Y h2BooleanSecondTilt n) := by
          rw [Finset.mul_sum]

#print axioms h2BooleanEmptyFrequencyFiber_le_rough_interval

end PaperB.FixedQ

namespace PaperB.FixedQ

/-- Quantitative empty-smooth-fiber bound retaining the rough-cutoff saving. -/
theorem h2BooleanEmptyFrequencyFiber_le_rough_log_power
    (q : ℕ) (hq : 0 < q) :
    ∃ X0 : ℕ, ∀ M j : ℕ,
      X0 ≤ 2 * M →
      2 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      (h2BooleanRoughCutoff M) ^ 2 ≤ M →
      ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
      ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
      h2BooleanDyadicFrequencyFiberMoment
          q (h2BooleanRoughCutoff M) M ∅ j ≤
        ((6 * q : ℝ) *
          PaperB.M4B.shiuFixedQuarterAssembleConstant
            8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
          Real.exp (6 * h2BooleanV0 + 24)) *
        (((Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0) /
          Real.log ((2 * M : ℕ) : ℝ)) *
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) := by
  rcases h2BooleanRoughSecondTilt_interval_shiu_uniform q hq with
    ⟨X0, hI⟩
  refine ⟨X0, ?_⟩
  intro M j hX hM hY4 hYsq hquarter hk
  have hMpos : 0 < M := by omega
  have hraw := h2BooleanEmptyFrequencyFiber_le_rough_interval
    (q := q) (Y := h2BooleanRoughCutoff M) (M := M) (j := j) hMpos
  have hI' := hI (h2BooleanRoughCutoff M) M
    hX (by omega) hquarter hk
  have hY1 : 1 ≤ h2BooleanRoughCutoff M := by omega
  have hYleM : h2BooleanRoughCutoff M ≤ M := by
    have hYY : h2BooleanRoughCutoff M ≤
        (h2BooleanRoughCutoff M) ^ 2 := by
      calc
        h2BooleanRoughCutoff M =
            h2BooleanRoughCutoff M * 1 := by simp
        _ ≤ h2BooleanRoughCutoff M * h2BooleanRoughCutoff M :=
          Nat.mul_le_mul_left _ hY1
        _ = (h2BooleanRoughCutoff M) ^ 2 := by ring
    exact hYY.trans hYsq
  have hYX : h2BooleanRoughCutoff M ≤ 2 * M := hYleM.trans (by omega)
  have hmass := h2BooleanSecondRough_exp_primeMass_cutoff_le
    (q := q) (M := M) (X := 2 * M) (k := 6 * q)
    hM (by omega) hYX (by omega)
  have hlogX : 0 < Real.log ((2 * M : ℕ) : ℝ) := by
    apply Real.log_pos
    exact_mod_cast (show 1 < 2 * M by omega)
  have hphiNat : 0 < (6 * q).totient :=
    Nat.totient_pos.mpr (by omega)
  have hphi : (1 : ℝ) ≤ ((6 * q).totient : ℝ) := by
    exact_mod_cast hphiNat
  have hden :
      Real.log ((2 * M : ℕ) : ℝ) ≤
        ((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ) := by
    nlinarith
  have hfrac :
      (M : ℝ) /
          (((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ))
        ≤ (M : ℝ) / Real.log ((2 * M : ℕ) : ℝ) :=
    div_le_div_of_nonneg_left (by positivity) hlogX hden
  let Csh : ℝ := PaperB.M4B.shiuFixedQuarterAssembleConstant
    8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold)
  let Cr : ℝ := Real.exp (6 * h2BooleanV0 + 24)
  have hCsh0 : 0 ≤ Csh := by
    dsimp [Csh, PaperB.M4B.shiuFixedQuarterAssembleConstant,
      PaperB.M4B.shiuClassIVConstant]
    positivity
  have hCr0 : 0 ≤ Cr := by dsimp [Cr]; positivity
  have hlogpow0 : 0 ≤
      (Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0 :=
    Real.rpow_nonneg hlogX.le _
  have hnegpow0 : 0 ≤
      (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) :=
    Real.rpow_nonneg
      (Real.log_nonneg (by exact_mod_cast (show 1 ≤ M by omega))) _
  calc
    h2BooleanDyadicFrequencyFiberMoment
        q (h2BooleanRoughCutoff M) M ∅ j
      ≤ (M : ℝ)⁻¹ *
          (∑ n ∈ Finset.Ioc M (2 * M),
            h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt n) := hraw
    _ ≤ (M : ℝ)⁻¹ *
        ((6 * q : ℝ) * Csh *
          ((M : ℝ) /
            (((6 * q).totient : ℝ) *
              Real.log ((2 * M : ℕ) : ℝ))) *
          Real.exp
            (PaperB.M4B.primeMass
              (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
                h2BooleanSecondTilt)
              (2 * M) (6 * q))) := by
          apply mul_le_mul_of_nonneg_left hI'
          positivity
    _ ≤ (M : ℝ)⁻¹ *
        ((6 * q : ℝ) * Csh *
          ((M : ℝ) / Real.log ((2 * M : ℕ) : ℝ)) *
          Real.exp
            (PaperB.M4B.primeMass
              (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
                h2BooleanSecondTilt)
              (2 * M) (6 * q))) := by
          gcongr
    _ ≤ (M : ℝ)⁻¹ *
        ((6 * q : ℝ) * Csh *
          ((M : ℝ) / Real.log ((2 * M : ℕ) : ℝ)) *
          (Cr *
            (Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0 *
            (Real.log (M : ℝ)) ^
              (-h2BooleanTheta * h2BooleanV0))) := by
          dsimp [Cr]
          gcongr
    _ =
        ((6 * q : ℝ) * Csh * Cr) *
        (((Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0) /
          Real.log ((2 * M : ℕ) : ℝ)) *
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) := by
          have hMR : (M : ℝ) ≠ 0 := by exact_mod_cast hMpos.ne'
          field_simp [hMR, hlogX.ne']
    _ = _ := by rfl

#print axioms h2BooleanEmptyFrequencyFiber_le_rough_log_power

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def h2BooleanGoodFrequencyMajorant (M j : ℕ) : ℝ :=
  (6 *
    PaperB.M4B.shiuFixedQuarterAssembleConstant
      8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
    Real.exp (6 * h2BooleanV0 + 24) *
    Real.exp (5 * h2BooleanV0 + 24)) *
  ((Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 /
    Real.log (M : ℝ)) *
  (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) *
  (Real.log (M : ℝ)) ^
    (h2BooleanTheta * (h2BooleanV0 / 2)) *
  (Real.log (j : ℝ)) ^ (h2BooleanV0 / 2)

noncomputable def h2BooleanEmptyFrequencyMajorant (q M : ℕ) : ℝ :=
  ((6 * q : ℝ) *
    PaperB.M4B.shiuFixedQuarterAssembleConstant
      8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
    Real.exp (6 * h2BooleanV0 + 24)) *
  (((Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0) /
    Real.log ((2 * M : ℕ) : ℝ)) *
  (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0)

noncomputable def h2BooleanBadFrequencyMajorant (q M : ℕ) : ℝ :=
  (Real.exp (6 * h2BooleanV0 + 24) *
    (Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0 *
    (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0)) *
  (Real.exp (10 * h2BooleanSecondTilt + 24) *
    (Real.log (h2BooleanRoughCutoff M : ℝ)) ^ h2BooleanV0 *
    Real.exp (-(1 / 8 : ℝ) *
      (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)))

noncomputable def h2BooleanFrequencySecondMomentMajorant
    (q M j : ℕ) : ℝ :=
  h2BooleanEmptyFrequencyMajorant q M +
    h2BooleanGoodFrequencyMajorant M j +
    h2BooleanBadFrequencyMajorant q M

/-- Full good+bad dyadic frequency second-moment bound.  No positive power
of M or smooth modulus survives. -/
theorem h2BooleanDyadicFrequencySecondMoment_le_quantitative
    (q : ℕ) (hq : 0 < q) :
    ∃ M0 : ℕ, ∀ M j : ℕ,
      M0 ≤ M →
      2 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      4 ≤ j →
      3 ≤ Nat.nthRoot 4 M →
      (h2BooleanRoughCutoff M) ^ 2 ≤ M →
      ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
      ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
      1 ≤ Real.log (M : ℝ) →
      h2BooleanTailCorrectionConst ≤
        (1 / 8 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) →
      h2BooleanDyadicFrequencySecondMoment q M j ≤
        h2BooleanFrequencySecondMomentMajorant q M j := by
  rcases h2BooleanGoodFrequencyFiberSum_le_log_power_closed q with
    ⟨MG, hgood⟩
  rcases h2BooleanEmptyFrequencyFiber_le_rough_log_power q hq with
    ⟨XE, hempty⟩
  refine ⟨max MG XE, ?_⟩
  intro M j hM0 hM hY4 hj hroot hYsq hquarter hk hlog hC
  have hMG : MG ≤ M := (le_max_left MG XE).trans hM0
  have hXE : XE ≤ M := (le_max_right MG XE).trans hM0
  have hXE2 : XE ≤ 2 * M := hXE.trans (by omega)
  have hg := hgood M j hMG hM hY4 hj hroot hYsq
  have he := hempty M j hXE2 hM hY4 hYsq hquarter hk
  have hb := h2BooleanBadFrequencyFiberSum_le_log_power_raw
    (q := q) (M := M) (j := j) hM hY4 hYsq hlog hC
  have hcut : 1 < h2BooleanSmoothProductCutoff M := by
    unfold h2BooleanSmoothProductCutoff
    omega
  have hgsplit :=
    h2BooleanGoodFrequencyFiberSum_eq_empty_add_nontrivial
      q M j hcut
  rw [h2BooleanDyadicFrequencySecondMoment_eq_good_add_bad q M j]
  rw [hgsplit]
  unfold h2BooleanFrequencySecondMomentMajorant
  have he' :
      h2BooleanDyadicFrequencyFiberMoment
          q (h2BooleanRoughCutoff M) M ∅ j ≤
        h2BooleanEmptyFrequencyMajorant q M := by
    simpa [h2BooleanEmptyFrequencyMajorant] using he
  have hg' :
      (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanDyadicFrequencyFiberMoment
          q (h2BooleanRoughCutoff M) M T j) ≤
        h2BooleanGoodFrequencyMajorant M j := by
    simpa [h2BooleanGoodFrequencyMajorant] using hg
  have hb' :
      (∑ T ∈ h2BooleanBadSmoothSets q M,
        h2BooleanDyadicFrequencyFiberMoment
          q (h2BooleanRoughCutoff M) M T j) ≤
        h2BooleanBadFrequencyMajorant q M := by
    simpa [h2BooleanBadFrequencyMajorant] using hb
  exact add_le_add (add_le_add he' hg') hb'

#print axioms h2BooleanDyadicFrequencySecondMoment_le_quantitative

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem h2BooleanDyadicSecondWeightMoment_le_interval
    {q M : ℕ} (hM : 0 < M) :
    (∑ S ∈ h2BooleanDyadicSets q M,
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) ≤
      (M : ℝ)⁻¹ *
        (∑ n ∈ Finset.Ioc M (2 * M),
          h2BooleanTiltLift q h2BooleanSecondTilt n) := by
  let F := h2BooleanDyadicSets q M
  let I := Finset.image primeSetProduct F
  have hinj : Set.InjOn primeSetProduct (↑F : Set (Finset ℕ)) := by
    dsimp [F]
    simpa using (h2BooleanDyadicSets_product_injective (q := q) (M := M))
  have himage :
      (∑ S ∈ F,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) =
      ∑ n ∈ I,
        h2BooleanTiltLift q h2BooleanSecondTilt n / (n : ℝ) := by
    rw [Finset.sum_image hinj]
    apply Finset.sum_congr rfl
    intro S hS
    have hA := h2BooleanDyadicSets_active (q := q) (M := M) hS
    exact (h2BooleanSecondTiltLift_primeSetProduct_div hA).symm
  rw [himage]
  calc
    (∑ n ∈ I,
        h2BooleanTiltLift q h2BooleanSecondTilt n / (n : ℝ))
      ≤ ∑ n ∈ I,
          (M : ℝ)⁻¹ * h2BooleanTiltLift q h2BooleanSecondTilt n := by
        apply Finset.sum_le_sum
        intro n hn
        rcases Finset.mem_image.mp hn with ⟨S, hSF, rfl⟩
        have hr := h2BooleanDyadicSets_range (q := q) (M := M) hSF
        have hlift0 :
            0 ≤ h2BooleanTiltLift q h2BooleanSecondTilt (primeSetProduct S) :=
          h2BooleanTiltLift_nonneg q _ h2BooleanSecondTilt_nonneg
        have hMR : (0 : ℝ) < M := by exact_mod_cast hM
        have hnR : (M : ℝ) < primeSetProduct S := by exact_mod_cast hr.1
        rw [div_eq_mul_inv, mul_comm]
        exact mul_le_mul_of_nonneg_right
          (inv_anti₀ hMR hnR.le) hlift0
    _ = (M : ℝ)⁻¹ *
          (∑ n ∈ I, h2BooleanTiltLift q h2BooleanSecondTilt n) := by
        rw [Finset.mul_sum]
    _ ≤ (M : ℝ)⁻¹ *
          (∑ n ∈ Finset.Ioc M (2 * M),
            h2BooleanTiltLift q h2BooleanSecondTilt n) := by
        apply mul_le_mul_of_nonneg_left
        · apply Finset.sum_le_sum_of_subset_of_nonneg
          · intro n hn
            rcases Finset.mem_image.mp hn with ⟨S, hSF, rfl⟩
            exact Finset.mem_Ioc.mpr
              (h2BooleanDyadicSets_range (q := q) (M := M) hSF)
          · intro n hnI hnnot
            exact h2BooleanTiltLift_nonneg q _ h2BooleanSecondTilt_nonneg
        · positivity

#print axioms h2BooleanDyadicSecondWeightMoment_le_interval

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma h2BooleanFourierNormSq_eq_frequencyMass_sq
    {q : ℕ} {S : Finset ℕ} (j : ℕ)
    (hA : ∀ p ∈ S, activeHighPrime q p) :
    h2BooleanFourierNormSq q S j =
      (fixedProductBooleanFrequencyMass S
        (fun p hp => (hA p hp).1) j) ^ 2 := by
  rw [h2BooleanFourierNormSq_eq_of_active j hA]
  rfl

noncomputable def h2BooleanRootDiscrepancy
    (q : ℕ) (S : Finset ℕ) (r : ℕ) : ℝ :=
  if hA : ∀ p ∈ S, activeHighPrime q p then
    fixedProductBooleanRootIntervalDiscrepancy S
      (fun p hp => (hA p hp).1) r
  else 0

lemma h2BooleanRootDiscrepancy_eq_of_active
    {q : ℕ} {S : Finset ℕ} (r : ℕ)
    (hA : ∀ p ∈ S, activeHighPrime q p) :
    h2BooleanRootDiscrepancy q S r =
      fixedProductBooleanRootIntervalDiscrepancy S
        (fun p hp => (hA p hp).1) r := by
  unfold h2BooleanRootDiscrepancy
  rw [dif_pos hA]

/-- Erdos--Turan square summed over one dyadic Boolean shell.  The Boolean
average stays inside the frequency mass until after squaring. -/
theorem h2BooleanDyadicRootDiscrepancySecondMoment_le_ET
    (q M J : ℕ) (r : Finset ℕ → ℕ)
    (hJ : 1 ≤ J)
    (hr : ∀ S ∈ h2BooleanDyadicSets q M,
      r S < primeSetProduct S) :
    (∑ S ∈ h2BooleanDyadicSets q M,
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
        (h2BooleanRootDiscrepancy q S (r S)) ^ 2) ≤
      (32 / ((J : ℝ) ^ 2)) *
        (∑ S ∈ h2BooleanDyadicSets q M,
          finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) +
      32 * (1 + Real.log (J : ℝ)) *
        (∑ j ∈ Finset.Icc 1 J,
          h2BooleanDyadicFrequencySecondMoment q M j / (j : ℝ)) := by
  let F := h2BooleanDyadicSets q M
  let A : ℝ := 32 / ((J : ℝ) ^ 2)
  let B : ℝ := 32 * (1 + Real.log (J : ℝ))
  have hpoint : ∀ S ∈ F,
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
          (h2BooleanRootDiscrepancy q S (r S)) ^ 2
        ≤
      (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) *
        (A + B *
          (∑ j ∈ Finset.Icc 1 J,
            h2BooleanFourierNormSq q S j / (j : ℝ))) := by
    intro S hS
    have hA := h2BooleanDyadicSets_active (q := q) (M := M) hS
    have hPrime : ∀ p ∈ S, p.Prime := fun p hp => (hA p hp).1
    have hF0 : ∀ j ∈ Finset.Icc 1 J,
        0 ≤ fixedProductBooleanFrequencyMass S hPrime j := by
      intro j hj
      exact norm_nonneg _
    have hET := fixedProductBooleanRootInterval_erdosTuran
      S hPrime (r S) J (hr S hS) hJ
    have hsq := erdosTuran_square_after_boolean_average
      (fixedProductBooleanRootIntervalDiscrepancy S hPrime (r S))
      (fun j => fixedProductBooleanFrequencyMass S hPrime j)
      J hJ hF0 hET
    have hfreqeq :
        (∑ j ∈ Finset.Icc 1 J,
          h2BooleanFourierNormSq q S j / (j : ℝ)) =
        ∑ j ∈ Finset.Icc 1 J,
          (fixedProductBooleanFrequencyMass S hPrime j) ^ 2 / (j : ℝ) := by
      apply Finset.sum_congr rfl
      intro j hj
      rw [h2BooleanFourierNormSq_eq_frequencyMass_sq j hA]
    have hsq' :
        (h2BooleanRootDiscrepancy q S (r S)) ^ 2 ≤
          A + B *
            (∑ j ∈ Finset.Icc 1 J,
              h2BooleanFourierNormSq q S j / (j : ℝ)) := by
      rw [h2BooleanRootDiscrepancy_eq_of_active (r S) hA, hfreqeq]
      simpa [A, B] using hsq
    have hw0 :
        0 ≤ finiteOmegaWeightReal S * h2BooleanV0 ^ S.card :=
      mul_nonneg
        (finiteOmegaWeightReal_nonneg_of_active hA)
        (pow_nonneg h2BooleanV0_nonneg _)
    exact mul_le_mul_of_nonneg_left hsq' hw0
  have hconst :
      (∑ S ∈ F,
        (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) * A) =
        A * (∑ S ∈ F,
          finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro S hS
    ring
  have hfreqInner :
      (∑ S ∈ F,
        (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) *
          (∑ j ∈ Finset.Icc 1 J,
            h2BooleanFourierNormSq q S j / (j : ℝ))) =
        ∑ j ∈ Finset.Icc 1 J,
          h2BooleanDyadicFrequencySecondMoment q M j / (j : ℝ) := by
    calc
      (∑ S ∈ F,
        (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) *
          (∑ j ∈ Finset.Icc 1 J,
            h2BooleanFourierNormSq q S j / (j : ℝ)))
        = ∑ S ∈ F, ∑ j ∈ Finset.Icc 1 J,
            (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
              h2BooleanFourierNormSq q S j) / (j : ℝ) := by
              apply Finset.sum_congr rfl
              intro S hS
              rw [Finset.mul_sum]
              apply Finset.sum_congr rfl
              intro j hj
              ring
      _ = ∑ j ∈ Finset.Icc 1 J, ∑ S ∈ F,
            (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
              h2BooleanFourierNormSq q S j) / (j : ℝ) := by
              rw [Finset.sum_comm]
      _ = ∑ j ∈ Finset.Icc 1 J,
            h2BooleanDyadicFrequencySecondMoment q M j / (j : ℝ) := by
              apply Finset.sum_congr rfl
              intro j hj
              rw [← Finset.sum_div]
              unfold h2BooleanDyadicFrequencySecondMoment
              rfl
  have hfreq :
      (∑ S ∈ F,
        (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) *
          (B * (∑ j ∈ Finset.Icc 1 J,
            h2BooleanFourierNormSq q S j / (j : ℝ)))) =
        B * (∑ j ∈ Finset.Icc 1 J,
          h2BooleanDyadicFrequencySecondMoment q M j / (j : ℝ)) := by
    calc
      _ = B * (∑ S ∈ F,
          (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) *
            (∑ j ∈ Finset.Icc 1 J,
              h2BooleanFourierNormSq q S j / (j : ℝ))) := by
            rw [Finset.mul_sum]
            apply Finset.sum_congr rfl
            intro S hS
            ring
      _ = _ := by rw [hfreqInner]
  calc
    (∑ S ∈ h2BooleanDyadicSets q M,
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
        (h2BooleanRootDiscrepancy q S (r S)) ^ 2)
      ≤ ∑ S ∈ F,
          (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) *
            (A + B *
              (∑ j ∈ Finset.Icc 1 J,
                h2BooleanFourierNormSq q S j / (j : ℝ))) := by
          dsimp [F]
          apply Finset.sum_le_sum
          intro S hS
          exact hpoint S hS
    _ = (∑ S ∈ F,
          (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) * A) +
        (∑ S ∈ F,
          (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) *
            (B * (∑ j ∈ Finset.Icc 1 J,
              h2BooleanFourierNormSq q S j / (j : ℝ)))) := by
      simp_rw [mul_add]
      rw [Finset.sum_add_distrib]
    _ = A * (∑ S ∈ F,
          finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) +
        B * (∑ j ∈ Finset.Icc 1 J,
          h2BooleanDyadicFrequencySecondMoment q M j / (j : ℝ)) := by
      rw [hconst, hfreq]
    _ = _ := by
      dsimp [A, B, F]

#print axioms h2BooleanDyadicRootDiscrepancySecondMoment_le_ET

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma h2BooleanM3LocalWeight_le_baseline_of_small_frequency
    {q p j : ℕ} (hp : activeHighPrime q p)
    (hj : 1 ≤ j) (hj4 : j < 4) :
    h2BooleanM3LocalWeight q p (j : ℤ) ≤
      h2BooleanM3BaselinePrimeTerm p := by
  have hp5 : 5 ≤ p := hp.2.1
  have hndiv : ¬ p ∣ j := by
    intro hdiv
    have hpj : p ≤ j := Nat.le_of_dvd (by omega) hdiv
    omega
  have h := h2BooleanM3LocalWeight_le_baseline_plus_resonance
    (j := j) hp
  rw [if_neg hndiv] at h
  simpa using h

theorem h2BooleanSmoothM3EulerMass_le_log_power_small_frequency
    {q Y j : ℕ} (hY : 4 ≤ Y)
    (hj : 1 ≤ j) (hj4 : j < 4) :
    h2BooleanSmoothM3EulerMass q Y (j : ℤ) ≤
      Real.exp (5 * (h2BooleanV0 / 2) + 12) *
        (Real.log (Y : ℝ)) ^ (h2BooleanV0 / 2) := by
  let g : ℕ → ℝ := fun p =>
    if hp : p ∈ h2BooleanSmoothActivePrimeSet q Y then
      h2BooleanM3LocalWeight q p (j : ℤ) else 0
  have hg : ∀ p : ℕ, 0 ≤ g p := by
    intro p
    dsimp [g]
    split_ifs with hp
    · exact h2BooleanM3LocalWeight_nonneg (j : ℤ)
        (h2BooleanSmoothActivePrimeSet_prime p hp)
    · exact le_rfl
  have hprod :
      (∏ p ∈ h2BooleanSmoothActivePrimeSet q Y,
        (1 + h2BooleanM3LocalWeight q p (j : ℤ))) =
      ∏ p ∈ h2BooleanSmoothActivePrimeSet q Y, (1 + g p) := by
    apply Finset.prod_congr rfl
    intro p hp
    simp [g, hp]
  have hpe :
      (∏ p ∈ h2BooleanSmoothActivePrimeSet q Y, (1 + g p)) ≤
        Real.exp
          (∑ p ∈ h2BooleanSmoothActivePrimeSet q Y, g p) :=
    Real.prod_one_add_le_exp_sum
      (h2BooleanSmoothActivePrimeSet q Y) hg
  have hsumg :
      (∑ p ∈ h2BooleanSmoothActivePrimeSet q Y, g p) =
        ∑ p ∈ h2BooleanSmoothActivePrimeSet q Y,
          h2BooleanM3LocalWeight q p (j : ℤ) := by
    apply Finset.sum_congr rfl
    intro p hp
    simp [g, hp]
  rw [hsumg] at hpe
  have hlocal :
      (∑ p ∈ h2BooleanSmoothActivePrimeSet q Y,
        h2BooleanM3LocalWeight q p (j : ℤ)) ≤
        (h2BooleanV0 / 2) *
          (Real.log (Real.log (Y : ℝ)) + 5) + 12 := by
    calc
      _ ≤ ∑ p ∈ h2BooleanSmoothActivePrimeSet q Y,
          h2BooleanM3BaselinePrimeTerm p := by
            apply Finset.sum_le_sum
            intro p hp
            exact h2BooleanM3LocalWeight_le_baseline_of_small_frequency
              (h2BooleanSmoothActivePrimeSet_active p hp) hj hj4
      _ ≤ ∑ p ∈ Y.primesLE,
          h2BooleanM3BaselinePrimeTerm p := by
            exact Finset.sum_le_sum_of_subset_of_nonneg
              (h2BooleanSmoothActivePrimeSet_subset_primesLE q Y)
              (fun p hp hnot => h2BooleanM3BaselinePrimeTerm_nonneg p)
      _ ≤ _ := sum_h2BooleanM3BaselinePrimeTerm_primesLE_le hY
  have hbase :
      h2BooleanSmoothM3EulerMass q Y (j : ℤ) ≤
        Real.exp
          ((h2BooleanV0 / 2) *
            (Real.log (Real.log (Y : ℝ)) + 5) + 12) := by
    calc
      h2BooleanSmoothM3EulerMass q Y (j : ℤ)
        = ∏ p ∈ h2BooleanSmoothActivePrimeSet q Y,
            (1 + h2BooleanM3LocalWeight q p (j : ℤ)) :=
          h2BooleanSmoothM3EulerMass_eq_prod q Y (j : ℤ)
      _ = ∏ p ∈ h2BooleanSmoothActivePrimeSet q Y, (1 + g p) := hprod
      _ ≤ Real.exp
          (∑ p ∈ h2BooleanSmoothActivePrimeSet q Y,
            h2BooleanM3LocalWeight q p (j : ℤ)) := hpe
      _ ≤ Real.exp
          ((h2BooleanV0 / 2) *
            (Real.log (Real.log (Y : ℝ)) + 5) + 12) :=
          Real.exp_le_exp.mpr hlocal
  have hY1 : (1 : ℝ) < (Y : ℝ) := by
    exact_mod_cast (show 1 < Y by omega)
  have hlogY : 0 < Real.log (Y : ℝ) := Real.log_pos hY1
  calc
    h2BooleanSmoothM3EulerMass q Y (j : ℤ)
      ≤ Real.exp
        ((h2BooleanV0 / 2) *
          (Real.log (Real.log (Y : ℝ)) + 5) + 12) := hbase
    _ = Real.exp (5 * (h2BooleanV0 / 2) + 12) *
        Real.exp
          (Real.log (Real.log (Y : ℝ)) * (h2BooleanV0 / 2)) := by
          rw [show
            (h2BooleanV0 / 2) *
                (Real.log (Real.log (Y : ℝ)) + 5) + 12 =
              (5 * (h2BooleanV0 / 2) + 12) +
                Real.log (Real.log (Y : ℝ)) *
                  (h2BooleanV0 / 2) by ring]
          rw [Real.exp_add]
    _ = _ := by
          rw [Real.rpow_def_of_pos hlogY]

theorem h2BooleanM3_sum_family_le_log_power_small_frequency
    {q Y j : ℕ} (hY : 4 ≤ Y)
    (hj : 1 ≤ j) (hj4 : j < 4)
    (F : Finset (Finset ℕ))
    (hF : F ⊆ (h2BooleanSmoothActivePrimeSet q Y).powerset) :
    (∑ T ∈ F, ∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) ≤
      Real.exp (5 * (h2BooleanV0 / 2) + 12) *
        (Real.log (Y : ℝ)) ^ (h2BooleanV0 / 2) := by
  exact (h2BooleanM3_sum_family_le_euler (j : ℤ) F hF).trans
    (h2BooleanSmoothM3EulerMass_le_log_power_small_frequency
      (q := q) (Y := Y) (j := j) hY hj hj4)

#print axioms h2BooleanM3_sum_family_le_log_power_small_frequency

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem h2BooleanGoodFrequencyFiberSum_le_log_power_small_frequency
    (q : ℕ) :
    ∃ M0 : ℕ, ∀ M j : ℕ,
      M0 ≤ M →
      2 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      1 ≤ j →
      j < 4 →
      (∀ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanRoughCutoff M ≤
          PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)) →
      (∀ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        (1 / 2 : ℝ) * Real.log (M : ℝ) ≤
          Real.log (PaperB.M4B.scaledCoverUpper
            (2 * M) (primeSetProduct T) : ℝ)) →
      (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanDyadicFrequencyFiberMoment
          q (h2BooleanRoughCutoff M) M T j) ≤
        (6 *
          PaperB.M4B.shiuFixedQuarterAssembleConstant
            8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
          Real.exp (6 * h2BooleanV0 + 24) *
          Real.exp (5 * (h2BooleanV0 / 2) + 12)) *
        ((Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 /
          Real.log (M : ℝ)) *
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) *
        (Real.log (M : ℝ)) ^
          (h2BooleanTheta * (h2BooleanV0 / 2)) := by
  rcases h2BooleanGoodFrequencyFiberSum_le_m3_uniform q with ⟨M0, hraw⟩
  refine ⟨M0, ?_⟩
  intro M j hM0 hM hY hj hj4 hYX hloglow
  have hM1 : 1 ≤ M := by omega
  have hlogMpos : 0 < Real.log (M : ℝ) := by
    exact Real.log_pos (by exact_mod_cast (show 1 < M by omega))
  have hbase := hraw M j hM0 hM1 hY
  let Csh : ℝ := PaperB.M4B.shiuFixedQuarterAssembleConstant
    8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold)
  let Cr : ℝ := Real.exp (6 * h2BooleanV0 + 24)
  let B : ℝ :=
    6 * Csh * Cr *
      ((Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 /
        Real.log (M : ℝ)) *
      (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0)
  have hB0 : 0 ≤ B := by
    dsimp [B, Csh, Cr, PaperB.M4B.shiuFixedQuarterAssembleConstant,
      PaperB.M4B.shiuClassIVConstant]
    positivity
  have hpoint : ∀ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
      ((primeSetProduct T : ℝ) / (M : ℝ)) * Csh *
          ((PaperB.M4B.scaledCoverLength
              (2 * M) M (primeSetProduct T) : ℝ) /
            Real.log (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T) : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt)
            (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T))
            (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))
        ≤ B * (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
    intro T hT
    let x := PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)
    let y := PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T)
    have hxY : h2BooleanRoughCutoff M ≤ x := by simpa [x] using hYX T hT
    have hx4 : 4 ≤ x := hY.trans hxY
    have hrough := h2BooleanSecondRough_exp_primeMass_cutoff_le
      (q := q) (M := M) (X := x) (k := primeSetProduct T)
      hM (by omega) hxY hx4
    have hxup : x ≤ 2 * M + 1 := by
      simpa [x] using h2Boolean_good_scaledCoverUpper_le_twoM_add_one hT
    have hxpos : (0 : ℝ) < x := by exact_mod_cast (show 0 < x by omega)
    have htoppos : (0 : ℝ) < ((2 * M + 1 : ℕ) : ℝ) := by positivity
    have hlogxpos : 0 < Real.log (x : ℝ) :=
      Real.log_pos (by exact_mod_cast (show 1 < x by omega))
    have hlogup : Real.log (x : ℝ) ≤
        Real.log ((2 * M + 1 : ℕ) : ℝ) :=
      Real.strictMonoOn_log.monotoneOn hxpos htoppos (by exact_mod_cast hxup)
    have hlogtop0 : 0 ≤ Real.log ((2 * M + 1 : ℕ) : ℝ) :=
      Real.log_nonneg (by exact_mod_cast (show 1 ≤ 2 * M + 1 by omega))
    have hpup :
        (Real.log (x : ℝ)) ^ h2BooleanV0 ≤
          (Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 :=
      Real.rpow_le_rpow hlogxpos.le hlogup h2BooleanV0_nonneg
    have hinvlog :
        1 / Real.log (x : ℝ) ≤ 2 / Real.log (M : ℝ) := by
      have hl := hloglow T hT
      have hhalfpos : 0 < (1 / 2 : ℝ) * Real.log (M : ℝ) := by positivity
      have hi := one_div_le_one_div_of_le hhalfpos hl
      have hhalf :
          1 / ((1 / 2 : ℝ) * Real.log (M : ℝ)) =
            2 / Real.log (M : ℝ) := by field_simp [hlogMpos.ne']
      rw [hhalf] at hi
      simpa [x] using hi
    have hscale := h2Boolean_good_scale_length_le_three hT
    have hprod0 : 0 ≤ ∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ) :=
      h2BooleanM3LocalWeight_prod_nonneg (j : ℤ)
        (h2BooleanGoodSmoothSetsNontrivial_active hT)
    have hnegpow0 : 0 ≤
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) :=
      Real.rpow_nonneg hlogMpos.le _
    have hCsh0 : 0 ≤ Csh := by
      dsimp [Csh, PaperB.M4B.shiuFixedQuarterAssembleConstant,
        PaperB.M4B.shiuClassIVConstant]
      positivity
    change
      ((primeSetProduct T : ℝ) / (M : ℝ)) * Csh *
          ((y : ℝ) / Real.log (x : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt) x (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))
        ≤ B * (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))
    rw [show ((y : ℝ) / Real.log (x : ℝ)) =
        (y : ℝ) * (1 / Real.log (x : ℝ)) by ring]
    calc
      ((primeSetProduct T : ℝ) / (M : ℝ)) * Csh *
          ((y : ℝ) * (1 / Real.log (x : ℝ))) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt) x (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))
        = Csh *
          ((((primeSetProduct T : ℝ) / (M : ℝ)) * (y : ℝ)) *
            (1 / Real.log (x : ℝ)) *
            Real.exp (PaperB.M4B.primeMass
              (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
                h2BooleanSecondTilt) x (primeSetProduct T)) *
            (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))) := by ring
      _ ≤ Csh *
          (3 * (2 / Real.log (M : ℝ)) *
            (Cr * (Real.log (x : ℝ)) ^ h2BooleanV0 *
              (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0)) *
            (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))) := by
            apply mul_le_mul_of_nonneg_left _ hCsh0
            gcongr
      _ ≤ Csh *
          (3 * (2 / Real.log (M : ℝ)) *
            (Cr * (Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 *
              (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0)) *
            (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))) := by
            gcongr
      _ = B * (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
            dsimp [B]
            ring
  have hsum :
      (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanDyadicFrequencyFiberMoment
          q (h2BooleanRoughCutoff M) M T j) ≤
        B * ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
    calc
      _ ≤ ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          ((primeSetProduct T : ℝ) / (M : ℝ)) * Csh *
          ((PaperB.M4B.scaledCoverLength
              (2 * M) M (primeSetProduct T) : ℝ) /
            Real.log (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T) : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt)
            (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T))
            (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
            simpa [Csh] using hbase
      _ ≤ ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          B * (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
            apply Finset.sum_le_sum
            intro T hT
            exact hpoint T hT
      _ = B * ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
            rw [Finset.mul_sum]
  have hm3 := h2BooleanM3_sum_family_le_log_power_small_frequency
    (q := q) (Y := h2BooleanRoughCutoff M) (j := j)
    hY hj hj4 (h2BooleanGoodSmoothSetsNontrivial q M)
    (h2BooleanGoodSmoothSetsNontrivial_subset q M)
  have hsmooth := h2BooleanRoughCutoff_smooth_rpow_le hM
  calc
    _ ≤ B * ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := hsum
    _ ≤ B * (Real.exp (5 * (h2BooleanV0 / 2) + 12) *
        (Real.log (h2BooleanRoughCutoff M : ℝ)) ^ (h2BooleanV0 / 2)) :=
      mul_le_mul_of_nonneg_left hm3 hB0
    _ ≤ B * (Real.exp (5 * (h2BooleanV0 / 2) + 12) *
        (Real.log (M : ℝ)) ^
          (h2BooleanTheta * (h2BooleanV0 / 2))) := by
      gcongr
    _ = _ := by
      dsimp [B, Csh, Cr]
      ring

#print axioms h2BooleanGoodFrequencyFiberSum_le_log_power_small_frequency


end PaperB.FixedQ

namespace PaperB.FixedQ

theorem h2BooleanGoodFrequencyFiberSum_le_log_power_small_frequency_closed
    (q : ℕ) :
    ∃ M0 : ℕ, ∀ M j : ℕ,
      M0 ≤ M →
      2 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      1 ≤ j →
      j < 4 →
      3 ≤ Nat.nthRoot 4 M →
      (h2BooleanRoughCutoff M) ^ 2 ≤ M →
      (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanDyadicFrequencyFiberMoment
          q (h2BooleanRoughCutoff M) M T j) ≤
        (6 *
          PaperB.M4B.shiuFixedQuarterAssembleConstant
            8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
          Real.exp (6 * h2BooleanV0 + 24) *
          Real.exp (5 * (h2BooleanV0 / 2) + 12)) *
        ((Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 /
          Real.log (M : ℝ)) *
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) *
        (Real.log (M : ℝ)) ^
          (h2BooleanTheta * (h2BooleanV0 / 2)) := by
  rcases h2BooleanGoodFrequencyFiberSum_le_log_power_small_frequency q with
    ⟨M0, hgood⟩
  refine ⟨M0, ?_⟩
  intro M j hM0 hM hY hj hj4 hroot hYsq
  exact hgood M j hM0 hM hY hj hj4
    (fun T hT => h2Boolean_good_roughCutoff_le_scaledCover hT hroot hYsq)
    (fun T hT => (h2Boolean_good_scaledCover_log_lower hT hM hroot).le)

noncomputable def h2BooleanGoodFrequencyMajorantSmall (M : ℕ) : ℝ :=
  (6 *
    PaperB.M4B.shiuFixedQuarterAssembleConstant
      8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
    Real.exp (6 * h2BooleanV0 + 24) *
    Real.exp (5 * (h2BooleanV0 / 2) + 12)) *
  ((Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 /
    Real.log (M : ℝ)) *
  (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) *
  (Real.log (M : ℝ)) ^
    (h2BooleanTheta * (h2BooleanV0 / 2))

noncomputable def h2BooleanFrequencySecondMomentMajorantAll
    (q M j : ℕ) : ℝ :=
  h2BooleanEmptyFrequencyMajorant q M +
    (if j < 4 then
      h2BooleanGoodFrequencyMajorantSmall M
    else
      h2BooleanGoodFrequencyMajorant M j) +
    h2BooleanBadFrequencyMajorant q M

/-- Global dyadic frequency second moment, including the three low
frequencies.  This is the H2 handoff theorem for the weighted ET consumer. -/
theorem h2BooleanDyadicFrequencySecondMoment_le_quantitative_all
    (q : ℕ) (hq : 0 < q) :
    ∃ M0 : ℕ, ∀ M j : ℕ,
      M0 ≤ M →
      2 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      1 ≤ j →
      3 ≤ Nat.nthRoot 4 M →
      (h2BooleanRoughCutoff M) ^ 2 ≤ M →
      ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
      ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
      1 ≤ Real.log (M : ℝ) →
      h2BooleanTailCorrectionConst ≤
        (1 / 8 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) →
      h2BooleanDyadicFrequencySecondMoment q M j ≤
        h2BooleanFrequencySecondMomentMajorantAll q M j := by
  rcases h2BooleanGoodFrequencyFiberSum_le_log_power_closed q with
    ⟨MG, hgoodLarge⟩
  rcases h2BooleanGoodFrequencyFiberSum_le_log_power_small_frequency_closed q with
    ⟨MS, hgoodSmall⟩
  rcases h2BooleanEmptyFrequencyFiber_le_rough_log_power q hq with
    ⟨XE, hempty⟩
  refine ⟨max MG (max MS XE), ?_⟩
  intro M j hM0 hM hY4 hj hroot hYsq hquarter hk hlog hC
  have hMG : MG ≤ M := (le_max_left MG (max MS XE)).trans hM0
  have hMS : MS ≤ M := by
    exact (le_max_left MS XE).trans
      ((le_max_right MG (max MS XE)).trans hM0)
  have hXE : XE ≤ M := by
    exact (le_max_right MS XE).trans
      ((le_max_right MG (max MS XE)).trans hM0)
  have hXE2 : XE ≤ 2 * M := hXE.trans (by omega)
  have he := hempty M j hXE2 hM hY4 hYsq hquarter hk
  have hb := h2BooleanBadFrequencyFiberSum_le_log_power_raw
    (q := q) (M := M) (j := j) hM hY4 hYsq hlog hC
  have hcut : 1 < h2BooleanSmoothProductCutoff M := by
    unfold h2BooleanSmoothProductCutoff
    omega
  have hgsplit :=
    h2BooleanGoodFrequencyFiberSum_eq_empty_add_nontrivial
      q M j hcut
  have he' :
      h2BooleanDyadicFrequencyFiberMoment
          q (h2BooleanRoughCutoff M) M ∅ j ≤
        h2BooleanEmptyFrequencyMajorant q M := by
    simpa [h2BooleanEmptyFrequencyMajorant] using he
  have hb' :
      (∑ T ∈ h2BooleanBadSmoothSets q M,
        h2BooleanDyadicFrequencyFiberMoment
          q (h2BooleanRoughCutoff M) M T j) ≤
        h2BooleanBadFrequencyMajorant q M := by
    simpa [h2BooleanBadFrequencyMajorant] using hb
  rw [h2BooleanDyadicFrequencySecondMoment_eq_good_add_bad q M j]
  rw [hgsplit]
  by_cases hj4 : j < 4
  · have hg := hgoodSmall M j hMS hM hY4 hj hj4 hroot hYsq
    have hg' :
        (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          h2BooleanDyadicFrequencyFiberMoment
            q (h2BooleanRoughCutoff M) M T j) ≤
          h2BooleanGoodFrequencyMajorantSmall M := by
      simpa [h2BooleanGoodFrequencyMajorantSmall] using hg
    unfold h2BooleanFrequencySecondMomentMajorantAll
    rw [if_pos hj4]
    exact add_le_add (add_le_add he' hg') hb'
  · have hjLarge : 4 ≤ j := by omega
    have hg := hgoodLarge M j hMG hM hY4 hjLarge hroot hYsq
    have hg' :
        (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          h2BooleanDyadicFrequencyFiberMoment
            q (h2BooleanRoughCutoff M) M T j) ≤
          h2BooleanGoodFrequencyMajorant M j := by
      simpa [h2BooleanGoodFrequencyMajorant] using hg
    unfold h2BooleanFrequencySecondMomentMajorantAll
    rw [if_neg hj4]
    exact add_le_add (add_le_add he' hg') hb'

#print axioms h2BooleanGoodFrequencyFiberSum_le_log_power_small_frequency_closed
#print axioms h2BooleanDyadicFrequencySecondMoment_le_quantitative_all

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma h2_sum_units_fourier_external_mul_eq
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (j : ℤ) (u0 : (ZMod (primeSetProduct S))ˣ) :
    (∑ u : (ZMod (primeSetProduct S))ˣ,
      ‖fixedProductBooleanFourierCoeff S hPrime
        (((j : ZMod (primeSetProduct S)) *
            (u0 : ZMod (primeSetProduct S))) *
          (u : ZMod (primeSetProduct S)))‖ ^ 2) =
    ∑ u : (ZMod (primeSetProduct S))ˣ,
      ‖fixedProductBooleanFourierCoeff S hPrime
        ((j : ZMod (primeSetProduct S)) *
          (u : ZMod (primeSetProduct S)))‖ ^ 2 := by
  let F : (ZMod (primeSetProduct S))ˣ → ℝ := fun u =>
    ‖fixedProductBooleanFourierCoeff S hPrime
      ((j : ZMod (primeSetProduct S)) *
        (u : ZMod (primeSetProduct S)))‖ ^ 2
  have hperm := Equiv.sum_comp (Equiv.mulLeft u0) F
  simpa [F, mul_assoc] using hperm

theorem h2_completeUnitFourierSecondMoment_external_unit
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (j : ℤ) (u0 : (ZMod (primeSetProduct S))ˣ) :
    ((Fintype.card (ZMod (primeSetProduct S))ˣ : ℝ)⁻¹) *
      (∑ u : (ZMod (primeSetProduct S))ˣ,
        ‖fixedProductBooleanFourierCoeff S hPrime
          (((j : ZMod (primeSetProduct S)) *
              (u0 : ZMod (primeSetProduct S))) *
            (u : ZMod (primeSetProduct S)))‖ ^ 2) =
      (PaperB.Boolean.booleanCRTSecondMoment S j : ℝ) := by
  rw [h2_sum_units_fourier_external_mul_eq S hPrime j u0]
  exact h2_completeUnitFourierSecondMoment S hPrime j

theorem h2_weightedCompleteUnitFourierSecondMoment_external_eq_m3
    {q : ℕ} {S : Finset ℕ}
    (hA : ∀ p ∈ S, activeHighPrime q p)
    [NeZero (primeSetProduct S)]
    (j : ℤ) (u0 : (ZMod (primeSetProduct S))ˣ) :
    finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
      (((Fintype.card (ZMod (primeSetProduct S))ˣ : ℝ)⁻¹) *
        (∑ u : (ZMod (primeSetProduct S))ˣ,
          ‖fixedProductBooleanFourierCoeff S
            (fun p hp => (hA p hp).1)
            (((j : ZMod (primeSetProduct S)) *
                (u0 : ZMod (primeSetProduct S))) *
              (u : ZMod (primeSetProduct S)))‖ ^ 2)) =
      ∏ p ∈ S, h2BooleanM3LocalWeight q p j := by
  rw [h2_completeUnitFourierSecondMoment_external_unit
    S (fun p hp => (hA p hp).1) j u0]
  exact (h2BooleanM3LocalWeight_prod_eq j hA).symm

lemma h2_resonance_mul_coprime_iff
    {S : Finset ℕ} (hPrime : ∀ p ∈ S, p.Prime)
    {a j p : ℕ} (ha : a.Coprime (primeSetProduct S))
    (hp : p ∈ S) :
    p ∣ j * a ↔ p ∣ j := by
  have hpProd : p ∣ primeSetProduct S := by
    unfold primeSetProduct
    exact Finset.dvd_prod_of_mem (fun x => x) hp
  have hpa : p.Coprime a := by
    exact Nat.Coprime.of_dvd_left hpProd ha.symm
  have hpa_not : ¬ p ∣ a :=
    (Nat.Prime.coprime_iff_not_dvd (hPrime p hp)).mp hpa
  constructor
  · intro h
    rcases (Nat.Prime.dvd_mul (hPrime p hp)).mp h with hj | ha'
    · exact hj
    · exact (hpa_not ha').elim
  · intro hj
    exact dvd_mul_of_dvd_left hj a

#print axioms h2_completeUnitFourierSecondMoment_external_unit
#print axioms h2_weightedCompleteUnitFourierSecondMoment_external_eq_m3
#print axioms h2_resonance_mul_coprime_iff

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem h2BooleanRoughUnitWeighted_progression_uniform_external
    (q : ℕ) :
    ∃ X0 : ℕ, ∀
      (Y : ℕ)
      (T : Finset ℕ) [NeZero (primeSetProduct T)]
      (hT : ∀ p ∈ T, activeHighPrime q p)
      (j x y : ℕ)
      (u0 : (ZMod (primeSetProduct T))ˣ),
      1 < primeSetProduct T →
      X0 ≤ x →
      (x : ℝ) ^ (1 / 4 : ℝ) < (y : ℝ) →
      y ≤ x →
      (primeSetProduct T : ℝ) < (y : ℝ) ^ (3 / 4 : ℝ) →
      (∑ n ∈ Finset.Ioc (x - y) x,
        if hn : n.Coprime (primeSetProduct T) then
          h2BooleanRoughTiltLift q Y h2BooleanSecondTilt n *
            ‖fixedProductBooleanFourierCoeff T
              (fun p hp => (hT p hp).1)
              (((j : ZMod (primeSetProduct T)) *
                  (u0 : ZMod (primeSetProduct T))) *
                (((ZMod.unitOfCoprime n hn)⁻¹ :
                  (ZMod (primeSetProduct T))ˣ) :
                    ZMod (primeSetProduct T)))‖ ^ 2
        else 0) ≤
      PaperB.M4B.shiuFixedQuarterAssembleConstant
          8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
        ((y : ℝ) /
          (((primeSetProduct T).totient : ℝ) * Real.log (x : ℝ))) *
        Real.exp (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
          x (primeSetProduct T)) *
        (∑ u : (ZMod (primeSetProduct T))ˣ,
          ‖fixedProductBooleanFourierCoeff T
            (fun p hp => (hT p hp).1)
            (((j : ZMod (primeSetProduct T)) *
                (u0 : ZMod (primeSetProduct T))) *
              (u : ZMod (primeSetProduct T)))‖ ^ 2) := by
  rcases PaperB.M4B.shiuFixedQuarter_progression_uniform
      8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) with ⟨X0, hShiu⟩
  refine ⟨X0, ?_⟩
  intro Y T _ hT j x y u0 hm1 hX hquarter hyx hmod
  let C : ℝ :=
    PaperB.M4B.shiuFixedQuarterAssembleConstant
      8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold)
  let G : (ZMod (primeSetProduct T))ˣ → ℝ := fun u =>
    ‖fixedProductBooleanFourierCoeff T
      (fun p hp => (hT p hp).1)
      (((j : ZMod (primeSetProduct T)) *
          (u0 : ZMod (primeSetProduct T))) *
        ((u⁻¹ : (ZMod (primeSetProduct T))ˣ) :
          ZMod (primeSetProduct T)))‖ ^ 2
  let B : ℝ :=
    C * ((y : ℝ) /
      (((primeSetProduct T).totient : ℝ) * Real.log (x : ℝ))) *
      Real.exp (PaperB.M4B.primeMass
        (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
        x (primeSetProduct T))
  have hG : ∀ u, 0 ≤ G u := fun u => sq_nonneg _
  have henv :=
    h2BooleanRoughTiltLift_envelope q Y
      h2BooleanSecondTilt_nonneg h2BooleanSecondTilt_le_three_halves
  have hprog : ∀ u : (ZMod (primeSetProduct T))ˣ,
      PaperB.M4B.progressionSum
        (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
        x y (primeSetProduct T) (u : ZMod (primeSetProduct T)).val ≤ B := by
    intro u
    have ha0 : 0 < (u : ZMod (primeSetProduct T)).val :=
      h2_zmod_unit_val_pos hm1 u
    have halt : (u : ZMod (primeSetProduct T)).val < primeSetProduct T :=
      ZMod.val_lt _
    have hacop : (u : ZMod (primeSetProduct T)).val.Coprime
        (primeSetProduct T) := h2_zmod_unit_val_coprime u
    exact hShiu
      (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt) henv
      x y (primeSetProduct T) (u : ZMod (primeSetProduct T)).val
      hX hquarter hyx hmod ha0 halt hacop
  have hsum := h2_unit_progression_sum_le
    (f := h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
    (G := G) B hG hprog
  dsimp [G, B, C] at hsum ⊢
  have hinv := h2_sum_units_inv
    (m := primeSetProduct T)
    (fun u : (ZMod (primeSetProduct T))ˣ =>
      ‖fixedProductBooleanFourierCoeff T
        (fun p hp => (hT p hp).1)
        (((j : ZMod (primeSetProduct T)) *
            (u0 : ZMod (primeSetProduct T))) *
          (u : ZMod (primeSetProduct T)))‖ ^ 2)
  have hinv' :
      (∑ u : (ZMod (primeSetProduct T))ˣ,
        ‖fixedProductBooleanFourierCoeff T
          (fun p hp => (hT p hp).1)
          (((j : ZMod (primeSetProduct T)) *
              (u0 : ZMod (primeSetProduct T))) *
            ((u⁻¹ : (ZMod (primeSetProduct T))ˣ) :
              ZMod (primeSetProduct T)))‖ ^ 2) =
      ∑ u : (ZMod (primeSetProduct T))ˣ,
        ‖fixedProductBooleanFourierCoeff T
          (fun p hp => (hT p hp).1)
          (((j : ZMod (primeSetProduct T)) *
              (u0 : ZMod (primeSetProduct T))) *
            (u : ZMod (primeSetProduct T)))‖ ^ 2 := by
    simpa using hinv
  rw [hinv'] at hsum
  exact hsum

#print axioms h2BooleanRoughUnitWeighted_progression_uniform_external

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def h2BooleanFourierNormSqTwisted
    (q : ℕ) (S : Finset ℕ) (j : ℕ)
    (u0 : (ZMod (primeSetProduct S))ˣ) : ℝ :=
  if hA : ∀ p ∈ S, activeHighPrime q p then
    ‖fixedProductBooleanFourierCoeff S
      (fun p hp => (hA p hp).1)
      ((j : ZMod (primeSetProduct S)) *
        (u0 : ZMod (primeSetProduct S)))‖ ^ 2
  else 0

lemma h2BooleanFourierNormSqTwisted_nonneg
    (q : ℕ) (S : Finset ℕ) (j : ℕ)
    (u0 : (ZMod (primeSetProduct S))ˣ) :
    0 ≤ h2BooleanFourierNormSqTwisted q S j u0 := by
  unfold h2BooleanFourierNormSqTwisted
  split_ifs
  · positivity
  · exact le_rfl

noncomputable def h2BooleanDyadicFrequencySecondMomentTwisted
    (q M j : ℕ)
    (u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ) : ℝ :=
  ∑ S ∈ h2BooleanDyadicSets q M,
    finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
      h2BooleanFourierNormSqTwisted q S j (u S)

noncomputable def h2BooleanDyadicFrequencyFiberMomentTwisted
    (q Y M : ℕ) (T : Finset ℕ) (j : ℕ)
    (u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ) : ℝ :=
  ∑ S ∈ h2BooleanDyadicSmoothFiber q Y M T,
    finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
      h2BooleanFourierNormSqTwisted q S j (u S)

noncomputable def h2BooleanRoughFiberTermExternal
    (q Y : ℕ) (T : Finset ℕ)
    (hT : ∀ p ∈ T, activeHighPrime q p)
    (j r : ℕ) (u0 : (ZMod (primeSetProduct T))ˣ) : ℝ :=
  if hr : r.Coprime (primeSetProduct T) then
    (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r / (r : ℝ)) *
      ‖fixedProductBooleanFourierCoeff T
        (fun p hp => (hT p hp).1)
        (((j : ZMod (primeSetProduct T)) *
            (u0 : ZMod (primeSetProduct T))) *
          (((ZMod.unitOfCoprime r hr)⁻¹ :
            (ZMod (primeSetProduct T))ˣ) : ZMod (primeSetProduct T)))‖ ^ 2
  else 0

lemma h2BooleanRoughFiberTermExternal_eq_of_coprime
    {q Y : ℕ} {T : Finset ℕ}
    (hT : ∀ p ∈ T, activeHighPrime q p)
    (j r : ℕ) (u0 : (ZMod (primeSetProduct T))ˣ)
    (hr : r.Coprime (primeSetProduct T)) :
    h2BooleanRoughFiberTermExternal q Y T hT j r u0 =
      (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r / (r : ℝ)) *
      ‖fixedProductBooleanFourierCoeff T
        (fun p hp => (hT p hp).1)
        (((j : ZMod (primeSetProduct T)) *
            (u0 : ZMod (primeSetProduct T))) *
          (((ZMod.unitOfCoprime r hr)⁻¹ :
            (ZMod (primeSetProduct T))ˣ) : ZMod (primeSetProduct T)))‖ ^ 2 := by
  unfold h2BooleanRoughFiberTermExternal
  rw [dif_pos hr]

def H2BooleanTwistFiberCompatible
    (q Y M j : ℕ) (T : Finset ℕ)
    (u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ)
    (u0 : (ZMod (primeSetProduct T))ˣ) : Prop :=
  ∀ S, ∀ hS : S ∈ h2BooleanDyadicSmoothFiber q Y M T,
    h2BooleanFourierNormSqTwisted q S j (u S) ≤
      ‖fixedProductBooleanFourierCoeff T
        (fun p hp => (h2BooleanDyadicSmoothFiber_smooth_active hS p hp).1)
        (((j : ZMod (primeSetProduct T)) *
            (u0 : ZMod (primeSetProduct T))) *
          (((ZMod.unitOfCoprime
            (primeSetProduct (S.filter (fun p => Y < p)))
            (h2_primeSetProduct_coprime
              (h2BooleanDyadicSmoothFiber_disjoint hS)
              (fun p hp => (h2BooleanDyadicSmoothFiber_smooth_active hS p hp).1)
              (fun p hp => (h2BooleanDyadicSmoothFiber_rough_active hS p hp).1)).symm)⁻¹ :
              (ZMod (primeSetProduct T))ˣ) :
                ZMod (primeSetProduct T)))‖ ^ 2

#print axioms h2BooleanRoughFiberTermExternal_eq_of_coprime

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma h2BooleanDyadicFrequencyFiberMomentTwisted_le_roughProducts
    {q Y M : ℕ} {T : Finset ℕ} {j : ℕ}
    (u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ)
    (u0 : (ZMod (primeSetProduct T))ˣ)
    (hT : ∀ p ∈ T, activeHighPrime q p)
    (hcompat : H2BooleanTwistFiberCompatible q Y M j T u u0) :
    h2BooleanDyadicFrequencyFiberMomentTwisted q Y M T j u ≤
      (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
        ∑ r ∈ h2BooleanDyadicRoughProducts q Y M T,
          h2BooleanRoughFiberTermExternal q Y T hT j r u0 := by
  unfold h2BooleanDyadicFrequencyFiberMomentTwisted
  calc
    (∑ S ∈ h2BooleanDyadicSmoothFiber q Y M T,
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
        h2BooleanFourierNormSqTwisted q S j (u S))
      ≤ ∑ S ∈ h2BooleanDyadicSmoothFiber q Y M T,
        (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
          h2BooleanRoughFiberTermExternal q Y T hT j
            (primeSetProduct (S.filter (fun p => Y < p))) u0 := by
          apply Finset.sum_le_sum
          intro S hS
          let R := S.filter (fun p => Y < p)
          have hR := h2BooleanDyadicSmoothFiber_rough_active hS
          have hdisj := h2BooleanDyadicSmoothFiber_disjoint hS
          have hPrimeR : ∀ p ∈ R, p.Prime := fun p hp => (hR p hp).1
          have hroughEq := h2BooleanRoughTiltLift_primeSetProduct
            (q := q) (Y := Y) (R := R) (c := h2BooleanSecondTilt)
            hPrimeR (fun p hp => (Finset.mem_filter.mp hp).2)
          have hweight : finiteOmegaWeightReal S * h2BooleanV0 ^ S.card =
              (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
              (finiteOmegaWeightReal R * h2BooleanV0 ^ R.card) := by
            rw [h2BooleanDyadicSmoothFiber_partition hS]
            exact h2BooleanSecondWeight_union T R hdisj
          have hRweight := h2BooleanSecondTiltLift_primeSetProduct_div
            (q := q) (S := R) hR
          have hc := h2BooleanDyadicRoughProducts_coprime_smooth
            (q := q) (Y := Y) (M := M) (T := T)
            (show primeSetProduct R ∈
              h2BooleanDyadicRoughProducts q Y M T by
                exact Finset.mem_image.mpr ⟨S, hS, rfl⟩)
          rw [h2BooleanRoughFiberTermExternal_eq_of_coprime hT j _ u0 hc]
          rw [hweight]
          have hc' := hcompat S hS
          have hTR0 :
              0 ≤ (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
                (finiteOmegaWeightReal R * h2BooleanV0 ^ R.card) :=
            mul_nonneg
              (mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hT)
                (pow_nonneg h2BooleanV0_nonneg _))
              (mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hR)
                (pow_nonneg h2BooleanV0_nonneg _))
          calc
            ((finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
              (finiteOmegaWeightReal R * h2BooleanV0 ^ R.card)) *
              h2BooleanFourierNormSqTwisted q S j (u S)
              ≤ ((finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
                (finiteOmegaWeightReal R * h2BooleanV0 ^ R.card)) *
                ‖fixedProductBooleanFourierCoeff T
                  (fun p hp => (h2BooleanDyadicSmoothFiber_smooth_active hS p hp).1)
                  (((j : ZMod (primeSetProduct T)) *
                      (u0 : ZMod (primeSetProduct T))) *
                    (((ZMod.unitOfCoprime (primeSetProduct R)
                      (h2_primeSetProduct_coprime hdisj
                        (fun p hp =>
                          (h2BooleanDyadicSmoothFiber_smooth_active hS p hp).1)
                        hPrimeR).symm)⁻¹ :
                      (ZMod (primeSetProduct T))ˣ) :
                        ZMod (primeSetProduct T)))‖ ^ 2 := by
                    exact mul_le_mul_of_nonneg_left hc' hTR0
            _ = (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
                ((h2BooleanRoughTiltLift q Y h2BooleanSecondTilt
                  (primeSetProduct R) / (primeSetProduct R : ℝ)) *
                ‖fixedProductBooleanFourierCoeff T
                  (fun p hp => (h2BooleanDyadicSmoothFiber_smooth_active hS p hp).1)
                  (((j : ZMod (primeSetProduct T)) *
                      (u0 : ZMod (primeSetProduct T))) *
                    (((ZMod.unitOfCoprime (primeSetProduct R)
                      (h2_primeSetProduct_coprime hdisj
                        (fun p hp =>
                          (h2BooleanDyadicSmoothFiber_smooth_active hS p hp).1)
                        hPrimeR).symm)⁻¹ :
                      (ZMod (primeSetProduct T))ˣ) :
                        ZMod (primeSetProduct T)))‖ ^ 2) := by
                    rw [hroughEq, hRweight]
                    ring
    _ = (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
        ∑ S ∈ h2BooleanDyadicSmoothFiber q Y M T,
          h2BooleanRoughFiberTermExternal q Y T hT j
            (primeSetProduct (S.filter (fun p => Y < p))) u0 := by
          rw [Finset.mul_sum]
    _ = (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
        ∑ r ∈ h2BooleanDyadicRoughProducts q Y M T,
          h2BooleanRoughFiberTermExternal q Y T hT j r u0 := by
          congr 1
          unfold h2BooleanDyadicRoughProducts
          rw [Finset.sum_image
            (h2BooleanDyadicSmoothFiber_rough_product_injective
              (q := q) (Y := Y) (M := M) (T := T))]

#print axioms h2BooleanDyadicFrequencyFiberMomentTwisted_le_roughProducts

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma h2BooleanDyadicRoughProducts_sum_le_cover_external
    {q Y M : ℕ} {T : Finset ℕ} {j : ℕ}
    (u0 : (ZMod (primeSetProduct T))ˣ)
    (hM : 0 < M)
    (hT : ∀ p ∈ T, activeHighPrime q p) :
    (∑ r ∈ h2BooleanDyadicRoughProducts q Y M T,
      h2BooleanRoughFiberTermExternal q Y T hT j r u0) ≤
      ((primeSetProduct T : ℝ) / (M : ℝ)) *
      (∑ n ∈ Finset.Ioc
        (PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T) -
          PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T))
        (PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)),
        if hn : n.Coprime (primeSetProduct T) then
          h2BooleanRoughTiltLift q Y h2BooleanSecondTilt n *
            ‖fixedProductBooleanFourierCoeff T
              (fun p hp => (hT p hp).1)
              (((j : ZMod (primeSetProduct T)) *
                  (u0 : ZMod (primeSetProduct T))) *
                (((ZMod.unitOfCoprime n hn)⁻¹ :
                  (ZMod (primeSetProduct T))ˣ) :
                    ZMod (primeSetProduct T)))‖ ^ 2
        else 0) := by
  let I := Finset.Ioc
    (PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T) -
      PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T))
    (PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T))
  let H : ℕ → ℝ := fun n =>
    if hn : n.Coprime (primeSetProduct T) then
      h2BooleanRoughTiltLift q Y h2BooleanSecondTilt n *
        ‖fixedProductBooleanFourierCoeff T
          (fun p hp => (hT p hp).1)
          (((j : ZMod (primeSetProduct T)) *
              (u0 : ZMod (primeSetProduct T))) *
            (((ZMod.unitOfCoprime n hn)⁻¹ :
              (ZMod (primeSetProduct T))ˣ) :
                ZMod (primeSetProduct T)))‖ ^ 2
    else 0
  have hscale0 : 0 ≤ (primeSetProduct T : ℝ) / (M : ℝ) := by positivity
  calc
    (∑ r ∈ h2BooleanDyadicRoughProducts q Y M T,
      h2BooleanRoughFiberTermExternal q Y T hT j r u0)
      ≤ ∑ r ∈ h2BooleanDyadicRoughProducts q Y M T,
          ((primeSetProduct T : ℝ) / (M : ℝ)) * H r := by
        apply Finset.sum_le_sum
        intro r hr
        have hcop := h2BooleanDyadicRoughProducts_coprime_smooth hr
        have hrange := h2BooleanDyadicRoughProducts_range hr
        have hinv := h2_inv_le_modulus_div_of_product_gt hM hrange.1
        rw [h2BooleanRoughFiberTermExternal_eq_of_coprime hT j r u0 hcop]
        dsimp [H]
        rw [dif_pos hcop]
        have hf0 : 0 ≤ h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r :=
          h2BooleanRoughTiltLift_nonneg q Y r h2BooleanSecondTilt_nonneg
        have hW0 : 0 ≤
            ‖fixedProductBooleanFourierCoeff T
              (fun p hp => (hT p hp).1)
              (((j : ZMod (primeSetProduct T)) *
                  (u0 : ZMod (primeSetProduct T))) *
                (((ZMod.unitOfCoprime r hcop)⁻¹ :
                  (ZMod (primeSetProduct T))ˣ) :
                    ZMod (primeSetProduct T)))‖ ^ 2 := sq_nonneg _
        rw [div_eq_mul_inv]
        calc
          h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r * (r : ℝ)⁻¹ * _
            ≤ h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r *
                ((primeSetProduct T : ℝ) / (M : ℝ)) * _ := by
              gcongr
          _ = ((primeSetProduct T : ℝ) / (M : ℝ)) *
              (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r *
                ‖fixedProductBooleanFourierCoeff T
                  (fun p hp => (hT p hp).1)
                  (((j : ZMod (primeSetProduct T)) *
                      (u0 : ZMod (primeSetProduct T))) *
                    (((ZMod.unitOfCoprime r hcop)⁻¹ :
                      (ZMod (primeSetProduct T))ˣ) :
                        ZMod (primeSetProduct T)))‖ ^ 2) := by ring
    _ ≤ ∑ n ∈ I, ((primeSetProduct T : ℝ) / (M : ℝ)) * H n := by
        apply Finset.sum_le_sum_of_subset_of_nonneg
        · intro r hr
          dsimp [I]
          exact h2BooleanDyadicRoughProducts_mem_cover hr
        · intro n hnI hnnot
          exact mul_nonneg hscale0 (by
            dsimp [H]
            split_ifs
            · exact mul_nonneg
                (h2BooleanRoughTiltLift_nonneg q Y n h2BooleanSecondTilt_nonneg)
                (sq_nonneg _)
            · exact le_rfl)
    _ = ((primeSetProduct T : ℝ) / (M : ℝ)) * ∑ n ∈ I, H n := by
        rw [Finset.mul_sum]
    _ = _ := by rfl

#print axioms h2BooleanDyadicRoughProducts_sum_le_cover_external

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem h2BooleanDyadicFrequencyFiberMomentTwisted_le_m3_cover_uniform
    (q : ℕ) :
    ∃ X0 : ℕ, ∀
      (Y : ℕ)
      (T : Finset ℕ) [NeZero (primeSetProduct T)]
      (hT : ∀ p ∈ T, activeHighPrime q p)
      (j M : ℕ)
      (u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ)
      (u0 : (ZMod (primeSetProduct T))ˣ),
      H2BooleanTwistFiberCompatible q Y M j T u u0 →
      0 < M →
      1 < primeSetProduct T →
      let x := PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)
      let y := PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T)
      X0 ≤ x →
      (x : ℝ) ^ (1 / 4 : ℝ) < (y : ℝ) →
      y ≤ x →
      (primeSetProduct T : ℝ) < (y : ℝ) ^ (3 / 4 : ℝ) →
      h2BooleanDyadicFrequencyFiberMomentTwisted q Y M T j u ≤
        ((primeSetProduct T : ℝ) / (M : ℝ)) *
          PaperB.M4B.shiuFixedQuarterAssembleConstant
            8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
          ((y : ℝ) / Real.log (x : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
            x (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
  rcases h2BooleanRoughUnitWeighted_progression_uniform_external q with
    ⟨X0, hunit⟩
  refine ⟨X0, ?_⟩
  intro Y T _ hT j M u u0 hcompat hM hm1
  dsimp
  intro hX hquarter hyx hmod
  let x := PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)
  let y := PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T)
  let C : ℝ :=
    PaperB.M4B.shiuFixedQuarterAssembleConstant
      8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold)
  have hfiber := h2BooleanDyadicFrequencyFiberMomentTwisted_le_roughProducts
    (q := q) (Y := Y) (M := M) (T := T) (j := j)
    u u0 hT hcompat
  have hcover := h2BooleanDyadicRoughProducts_sum_le_cover_external
    (q := q) (Y := Y) (M := M) (T := T) (j := j)
    u0 hM hT
  have hunit' := hunit Y T hT j x y u0 hm1 hX hquarter hyx hmod
  have hTweight0 : 0 ≤ finiteOmegaWeightReal T * h2BooleanV0 ^ T.card :=
    mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hT)
      (pow_nonneg h2BooleanV0_nonneg _)
  have hscale0 : 0 ≤ (primeSetProduct T : ℝ) / (M : ℝ) := by positivity
  have hrough :
      (∑ r ∈ h2BooleanDyadicRoughProducts q Y M T,
        h2BooleanRoughFiberTermExternal q Y T hT j r u0) ≤
      ((primeSetProduct T : ℝ) / (M : ℝ)) *
        (C * ((y : ℝ) /
          (((primeSetProduct T).totient : ℝ) * Real.log (x : ℝ))) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
            x (primeSetProduct T)) *
          (∑ v : (ZMod (primeSetProduct T))ˣ,
            ‖fixedProductBooleanFourierCoeff T
              (fun p hp => (hT p hp).1)
              (((j : ZMod (primeSetProduct T)) *
                  (u0 : ZMod (primeSetProduct T))) *
                (v : ZMod (primeSetProduct T)))‖ ^ 2)) := by
    calc
      (∑ r ∈ h2BooleanDyadicRoughProducts q Y M T,
        h2BooleanRoughFiberTermExternal q Y T hT j r u0)
        ≤ ((primeSetProduct T : ℝ) / (M : ℝ)) *
          (∑ n ∈ Finset.Ioc (x - y) x,
            if hn : n.Coprime (primeSetProduct T) then
              h2BooleanRoughTiltLift q Y h2BooleanSecondTilt n *
                ‖fixedProductBooleanFourierCoeff T
                  (fun p hp => (hT p hp).1)
                  (((j : ZMod (primeSetProduct T)) *
                      (u0 : ZMod (primeSetProduct T))) *
                    (((ZMod.unitOfCoprime n hn)⁻¹ :
                      (ZMod (primeSetProduct T))ˣ) :
                        ZMod (primeSetProduct T)))‖ ^ 2
            else 0) := by
              simpa [x, y] using hcover
      _ ≤ ((primeSetProduct T : ℝ) / (M : ℝ)) *
          (C * ((y : ℝ) /
            (((primeSetProduct T).totient : ℝ) * Real.log (x : ℝ))) *
            Real.exp (PaperB.M4B.primeMass
              (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
              x (primeSetProduct T)) *
            (∑ v : (ZMod (primeSetProduct T))ˣ,
              ‖fixedProductBooleanFourierCoeff T
                (fun p hp => (hT p hp).1)
                (((j : ZMod (primeSetProduct T)) *
                    (u0 : ZMod (primeSetProduct T))) *
                  (v : ZMod (primeSetProduct T)))‖ ^ 2)) :=
            mul_le_mul_of_nonneg_left
              (by simpa [C] using hunit') hscale0
  have hmain := hfiber.trans
    (mul_le_mul_of_nonneg_left hrough hTweight0)
  have hcard :
      (Fintype.card (ZMod (primeSetProduct T))ˣ : ℝ) =
        ((primeSetProduct T).totient : ℝ) := by
    exact_mod_cast ZMod.card_units_eq_totient (primeSetProduct T)
  have hm3 :=
    h2_weightedCompleteUnitFourierSecondMoment_external_eq_m3
      (q := q) (S := T) hT (j : ℤ) u0
  have hm3nat :
      finiteOmegaWeightReal T * h2BooleanV0 ^ T.card *
        (((Fintype.card (ZMod (primeSetProduct T))ˣ : ℝ)⁻¹) *
          (∑ v : (ZMod (primeSetProduct T))ˣ,
            ‖fixedProductBooleanFourierCoeff T
              (fun p hp => (hT p hp).1)
              (((j : ZMod (primeSetProduct T)) *
                  (u0 : ZMod (primeSetProduct T))) *
                (v : ZMod (primeSetProduct T)))‖ ^ 2)) =
        ∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ) := by
    simpa using hm3
  calc
    h2BooleanDyadicFrequencyFiberMomentTwisted q Y M T j u
      ≤ (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
        (((primeSetProduct T : ℝ) / (M : ℝ)) *
          (C * ((y : ℝ) /
            (((primeSetProduct T).totient : ℝ) * Real.log (x : ℝ))) *
            Real.exp (PaperB.M4B.primeMass
              (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
              x (primeSetProduct T)) *
            (∑ v : (ZMod (primeSetProduct T))ˣ,
              ‖fixedProductBooleanFourierCoeff T
                (fun p hp => (hT p hp).1)
                (((j : ZMod (primeSetProduct T)) *
                    (u0 : ZMod (primeSetProduct T))) *
                  (v : ZMod (primeSetProduct T)))‖ ^ 2))) := hmain
    _ = ((primeSetProduct T : ℝ) / (M : ℝ)) * C *
        ((y : ℝ) / Real.log (x : ℝ)) *
        Real.exp (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
          x (primeSetProduct T)) *
        (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card *
          (((Fintype.card (ZMod (primeSetProduct T))ˣ : ℝ)⁻¹) *
            (∑ v : (ZMod (primeSetProduct T))ˣ,
              ‖fixedProductBooleanFourierCoeff T
                (fun p hp => (hT p hp).1)
                (((j : ZMod (primeSetProduct T)) *
                    (u0 : ZMod (primeSetProduct T))) *
                  (v : ZMod (primeSetProduct T)))‖ ^ 2))) := by
          rw [hcard]
          ring
    _ = ((primeSetProduct T : ℝ) / (M : ℝ)) * C *
        ((y : ℝ) / Real.log (x : ℝ)) *
        Real.exp (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
          x (primeSetProduct T)) *
        (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
          rw [hm3nat]
    _ = _ := by
          rfl

#print axioms h2BooleanDyadicFrequencyFiberMomentTwisted_le_m3_cover_uniform

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem h2BooleanDyadicFrequencyFiberMomentTwisted_le_m3_cover
    (q Y : ℕ) :
    ∃ C : ℝ, ∃ X0 : ℕ, ∀
      (T : Finset ℕ) [NeZero (primeSetProduct T)]
      (hT : ∀ p ∈ T, activeHighPrime q p)
      (j M : ℕ)
      (u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ)
      (u0 : (ZMod (primeSetProduct T))ˣ),
      H2BooleanTwistFiberCompatible q Y M j T u u0 →
      0 < M →
      1 < primeSetProduct T →
      let x := PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)
      let y := PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T)
      X0 ≤ x →
      (x : ℝ) ^ (1 / 4 : ℝ) < (y : ℝ) →
      y ≤ x →
      (primeSetProduct T : ℝ) < (y : ℝ) ^ (3 / 4 : ℝ) →
      h2BooleanDyadicFrequencyFiberMomentTwisted q Y M T j u ≤
        ((primeSetProduct T : ℝ) / (M : ℝ)) * C *
          ((y : ℝ) / Real.log (x : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
            x (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
  rcases h2BooleanDyadicFrequencyFiberMomentTwisted_le_m3_cover_uniform q with
    ⟨X0, h⟩
  refine ⟨PaperB.M4B.shiuFixedQuarterAssembleConstant
      8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold), X0, ?_⟩
  intro T _ hT j M u u0 hcompat hM hm1
  exact h Y T hT j M u u0 hcompat hM hm1

#print axioms h2BooleanDyadicFrequencyFiberMomentTwisted_le_m3_cover
#print axioms h2BooleanDyadicFrequencyFiberMomentTwisted_le_m3_cover_uniform

end PaperB.FixedQ

namespace PaperB.FixedQ

def H2BooleanTwistFamilyCompatible
    (q Y M j : ℕ)
    (u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ) : Prop :=
  ∀ T ∈ (h2BooleanSmoothActivePrimeSet q Y).powerset,
    ∃ u0 : (ZMod (primeSetProduct T))ˣ,
      H2BooleanTwistFiberCompatible q Y M j T u u0

lemma h2BooleanDyadicFrequencySecondMomentTwisted_eq_sum_fibers
    (q Y M j : ℕ)
    (u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ) :
    h2BooleanDyadicFrequencySecondMomentTwisted q M j u =
      ∑ T ∈ (h2BooleanSmoothActivePrimeSet q Y).powerset,
        h2BooleanDyadicFrequencyFiberMomentTwisted q Y M T j u := by
  let F := h2BooleanDyadicSets q M
  let P := (h2BooleanSmoothActivePrimeSet q Y).powerset
  let phi : Finset ℕ → Finset ℕ := fun S => S.filter (fun p => p ≤ Y)
  let w : Finset ℕ → ℝ := fun S =>
    finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
      h2BooleanFourierNormSqTwisted q S j (u S)
  have hmaps : ∀ S ∈ F, phi S ∈ P := by
    intro S hS
    dsimp [F, P, phi] at hS ⊢
    exact h2BooleanDyadic_smooth_filter_mem hS
  have hfiber := Finset.sum_fiberwise_of_maps_to hmaps w
  unfold h2BooleanDyadicFrequencySecondMomentTwisted
  symm
  calc
    (∑ T ∈ (h2BooleanSmoothActivePrimeSet q Y).powerset,
      h2BooleanDyadicFrequencyFiberMomentTwisted q Y M T j u)
      = ∑ T ∈ P, ∑ S ∈ F with phi S = T, w S := by
          apply Finset.sum_congr rfl
          intro T hT
          unfold h2BooleanDyadicFrequencyFiberMomentTwisted
          dsimp [h2BooleanDyadicSmoothFiber, F, phi, w]
    _ = ∑ S ∈ F, w S := hfiber
    _ = ∑ S ∈ h2BooleanDyadicSets q M,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
          h2BooleanFourierNormSqTwisted q S j (u S) := by rfl

theorem h2BooleanDyadicFrequencySecondMomentTwisted_eq_good_add_bad
    (q M j : ℕ)
    (u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ) :
    h2BooleanDyadicFrequencySecondMomentTwisted q M j u =
      (∑ T ∈ h2BooleanGoodSmoothSets q M,
        h2BooleanDyadicFrequencyFiberMomentTwisted
          q (h2BooleanRoughCutoff M) M T j u) +
      (∑ T ∈ h2BooleanBadSmoothSets q M,
        h2BooleanDyadicFrequencyFiberMomentTwisted
          q (h2BooleanRoughCutoff M) M T j u) := by
  rw [h2BooleanDyadicFrequencySecondMomentTwisted_eq_sum_fibers
    q (h2BooleanRoughCutoff M) M j u]
  rw [h2BooleanGoodSmoothSets_partition q M]
  exact Finset.sum_union (h2BooleanGoodBad_disjoint q M)

#print axioms h2BooleanDyadicFrequencySecondMomentTwisted_eq_sum_fibers
#print axioms h2BooleanDyadicFrequencySecondMomentTwisted_eq_good_add_bad

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem h2BooleanGoodFrequencyFiberSumTwisted_le_m3
    (q : ℕ) :
    ∃ X0 : ℕ, ∀ M j : ℕ,
      ∀ u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ,
      H2BooleanTwistFamilyCompatible q (h2BooleanRoughCutoff M) M j u →
      1 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      (∀ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        X0 ≤ PaperB.M4B.scaledCoverUpper
          (2 * M) (primeSetProduct T)) →
      (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanDyadicFrequencyFiberMomentTwisted
          q (h2BooleanRoughCutoff M) M T j u) ≤
        ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          ((primeSetProduct T : ℝ) / (M : ℝ)) *
          PaperB.M4B.shiuFixedQuarterAssembleConstant
            8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
          ((PaperB.M4B.scaledCoverLength
              (2 * M) M (primeSetProduct T) : ℝ) /
            Real.log (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T) : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt)
            (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T))
            (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
  rcases h2BooleanDyadicFrequencyFiberMomentTwisted_le_m3_cover_uniform q with
    ⟨X0, hfiber⟩
  refine ⟨X0, ?_⟩
  intro M j u hcompat hM hY hX
  apply Finset.sum_le_sum
  intro T hT
  have hA := h2BooleanGoodSmoothSetsNontrivial_active hT
  letI : NeZero (primeSetProduct T) :=
    ⟨(primeSetProduct_pos (fun p hp => (hA p hp).1)).ne'⟩
  rcases hcompat T (h2BooleanGoodSmoothSetsNontrivial_subset q M hT) with
    ⟨u0, hcompatT⟩
  have hMpos : 0 < M := by omega
  exact hfiber
    (h2BooleanRoughCutoff M) T hA j M u u0 hcompatT
    hMpos
    (h2BooleanGoodSmoothSetsNontrivial_product_gt_one hT)
    (hX T hT)
    (h2Boolean_good_scaled_quarter_real (Finset.mem_filter.mp hT).1 hM)
    (h2Boolean_scaledCoverLength_le_upper M (primeSetProduct T))
    (h2Boolean_good_scaled_modulus_real hT)

theorem h2BooleanGoodFrequencyFiberSumTwisted_le_m3_uniform
    (q : ℕ) :
    ∃ M0 : ℕ, ∀ M j : ℕ,
      ∀ u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ,
      H2BooleanTwistFamilyCompatible q (h2BooleanRoughCutoff M) M j u →
      M0 ≤ M →
      1 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanDyadicFrequencyFiberMomentTwisted
          q (h2BooleanRoughCutoff M) M T j u) ≤
        ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          ((primeSetProduct T : ℝ) / (M : ℝ)) *
          PaperB.M4B.shiuFixedQuarterAssembleConstant
            8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
          ((PaperB.M4B.scaledCoverLength
              (2 * M) M (primeSetProduct T) : ℝ) /
            Real.log (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T) : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt)
            (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T))
            (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
  rcases h2BooleanGoodFrequencyFiberSumTwisted_le_m3 q with ⟨X0, hgood⟩
  refine ⟨X0 ^ 4, ?_⟩
  intro M j u hcompat hM0 hM hY
  exact hgood M j u hcompat hM hY
    (fun T hT => h2Boolean_good_scaledCoverUpper_ge_threshold hT hM0)

#print axioms h2BooleanGoodFrequencyFiberSumTwisted_le_m3
#print axioms h2BooleanGoodFrequencyFiberSumTwisted_le_m3_uniform

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem h2BooleanGoodFrequencyFiberSumTwisted_le_log_power
    (q : ℕ) :
    ∃ M0 : ℕ, ∀ M j : ℕ,
      ∀ u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ,
      H2BooleanTwistFamilyCompatible q (h2BooleanRoughCutoff M) M j u →
      M0 ≤ M →
      2 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      4 ≤ j →
      (∀ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanRoughCutoff M ≤
          PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)) →
      (∀ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        (1 / 2 : ℝ) * Real.log (M : ℝ) ≤
          Real.log (PaperB.M4B.scaledCoverUpper
            (2 * M) (primeSetProduct T) : ℝ)) →
      (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanDyadicFrequencyFiberMomentTwisted
          q (h2BooleanRoughCutoff M) M T j u) ≤
        (6 *
          PaperB.M4B.shiuFixedQuarterAssembleConstant
            8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
          Real.exp (6 * h2BooleanV0 + 24) *
          Real.exp (5 * h2BooleanV0 + 24)) *
        ((Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 /
          Real.log (M : ℝ)) *
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) *
        (Real.log (M : ℝ)) ^
          (h2BooleanTheta * (h2BooleanV0 / 2)) *
        (Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by
  rcases h2BooleanGoodFrequencyFiberSumTwisted_le_m3_uniform q with ⟨M0, hraw⟩
  refine ⟨M0, ?_⟩
  intro M j u hcompat hM0 hM hY hj hYX hloglow
  have hM1 : 1 ≤ M := by omega
  have hlogMpos : 0 < Real.log (M : ℝ) := by
    exact Real.log_pos (by exact_mod_cast (show 1 < M by omega))
  have hbase := hraw M j u hcompat hM0 hM1 hY
  let Csh : ℝ := PaperB.M4B.shiuFixedQuarterAssembleConstant
    8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold)
  let Cr : ℝ := Real.exp (6 * h2BooleanV0 + 24)
  let B : ℝ :=
    6 * Csh * Cr *
      ((Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 /
        Real.log (M : ℝ)) *
      (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0)
  have hB0 : 0 ≤ B := by
    dsimp [B, Csh, Cr, PaperB.M4B.shiuFixedQuarterAssembleConstant,
      PaperB.M4B.shiuClassIVConstant]
    positivity
  have hpoint : ∀ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
      ((primeSetProduct T : ℝ) / (M : ℝ)) * Csh *
          ((PaperB.M4B.scaledCoverLength
              (2 * M) M (primeSetProduct T) : ℝ) /
            Real.log (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T) : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt)
            (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T))
            (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))
        ≤ B * (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
    intro T hT
    let x := PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)
    let y := PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T)
    have hxY : h2BooleanRoughCutoff M ≤ x := by simpa [x] using hYX T hT
    have hx4 : 4 ≤ x := hY.trans hxY
    have hrough := h2BooleanSecondRough_exp_primeMass_cutoff_le
      (q := q) (M := M) (X := x) (k := primeSetProduct T)
      hM (by omega) hxY hx4
    have hxup : x ≤ 2 * M + 1 := by
      simpa [x] using h2Boolean_good_scaledCoverUpper_le_twoM_add_one hT
    have hxpos : (0 : ℝ) < x := by exact_mod_cast (show 0 < x by omega)
    have htoppos : (0 : ℝ) < ((2 * M + 1 : ℕ) : ℝ) := by positivity
    have hlogxpos : 0 < Real.log (x : ℝ) :=
      Real.log_pos (by exact_mod_cast (show 1 < x by omega))
    have hlogup : Real.log (x : ℝ) ≤
        Real.log ((2 * M + 1 : ℕ) : ℝ) :=
      Real.strictMonoOn_log.monotoneOn hxpos htoppos (by exact_mod_cast hxup)
    have hlogtop0 : 0 ≤ Real.log ((2 * M + 1 : ℕ) : ℝ) :=
      Real.log_nonneg (by exact_mod_cast (show 1 ≤ 2 * M + 1 by omega))
    have hpup :
        (Real.log (x : ℝ)) ^ h2BooleanV0 ≤
          (Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 :=
      Real.rpow_le_rpow hlogxpos.le hlogup h2BooleanV0_nonneg
    have hinvlog :
        1 / Real.log (x : ℝ) ≤ 2 / Real.log (M : ℝ) := by
      have hl := hloglow T hT
      have hhalfpos : 0 < (1 / 2 : ℝ) * Real.log (M : ℝ) := by positivity
      have hi := one_div_le_one_div_of_le hhalfpos hl
      have hhalf :
          1 / ((1 / 2 : ℝ) * Real.log (M : ℝ)) =
            2 / Real.log (M : ℝ) := by field_simp [hlogMpos.ne']
      rw [hhalf] at hi
      simpa [x] using hi
    have hscale := h2Boolean_good_scale_length_le_three hT
    have hprod0 : 0 ≤ ∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ) :=
      h2BooleanM3LocalWeight_prod_nonneg (j : ℤ)
        (h2BooleanGoodSmoothSetsNontrivial_active hT)
    have hnegpow0 : 0 ≤
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) :=
      Real.rpow_nonneg hlogMpos.le _
    have hCsh0 : 0 ≤ Csh := by
      dsimp [Csh, PaperB.M4B.shiuFixedQuarterAssembleConstant,
        PaperB.M4B.shiuClassIVConstant]
      positivity
    change
      ((primeSetProduct T : ℝ) / (M : ℝ)) * Csh *
          ((y : ℝ) / Real.log (x : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt) x (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))
        ≤ B * (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))
    rw [show ((y : ℝ) / Real.log (x : ℝ)) =
        (y : ℝ) * (1 / Real.log (x : ℝ)) by ring]
    calc
      ((primeSetProduct T : ℝ) / (M : ℝ)) * Csh *
          ((y : ℝ) * (1 / Real.log (x : ℝ))) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt) x (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))
        = Csh *
          ((((primeSetProduct T : ℝ) / (M : ℝ)) * (y : ℝ)) *
            (1 / Real.log (x : ℝ)) *
            Real.exp (PaperB.M4B.primeMass
              (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
                h2BooleanSecondTilt) x (primeSetProduct T)) *
            (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))) := by ring
      _ ≤ Csh *
          (3 * (2 / Real.log (M : ℝ)) *
            (Cr * (Real.log (x : ℝ)) ^ h2BooleanV0 *
              (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0)) *
            (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))) := by
            apply mul_le_mul_of_nonneg_left _ hCsh0
            gcongr
      _ ≤ Csh *
          (3 * (2 / Real.log (M : ℝ)) *
            (Cr * (Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 *
              (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0)) *
            (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))) := by
            gcongr
      _ = B * (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
            dsimp [B]
            ring
  have hsum :
      (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanDyadicFrequencyFiberMomentTwisted
          q (h2BooleanRoughCutoff M) M T j u) ≤
        B * ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
    calc
      _ ≤ ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          ((primeSetProduct T : ℝ) / (M : ℝ)) * Csh *
          ((PaperB.M4B.scaledCoverLength
              (2 * M) M (primeSetProduct T) : ℝ) /
            Real.log (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T) : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt)
            (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T))
            (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
            simpa [Csh] using hbase
      _ ≤ ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          B * (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
            apply Finset.sum_le_sum
            intro T hT
            exact hpoint T hT
      _ = B * ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
            rw [Finset.mul_sum]
  have hm3 := h2BooleanM3_sum_family_le_log_powers
    (q := q) (Y := h2BooleanRoughCutoff M) (j := j)
    hY hj (h2BooleanGoodSmoothSetsNontrivial q M)
    (h2BooleanGoodSmoothSetsNontrivial_subset q M)
  have hsmooth := h2BooleanRoughCutoff_smooth_rpow_le hM
  calc
    _ ≤ B * ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := hsum
    _ ≤ B * (Real.exp (5 * h2BooleanV0 + 24) *
        (Real.log (h2BooleanRoughCutoff M : ℝ)) ^ (h2BooleanV0 / 2) *
        (Real.log (j : ℝ)) ^ (h2BooleanV0 / 2)) :=
      mul_le_mul_of_nonneg_left hm3 hB0
    _ ≤ B * (Real.exp (5 * h2BooleanV0 + 24) *
        (Real.log (M : ℝ)) ^
          (h2BooleanTheta * (h2BooleanV0 / 2)) *
        (Real.log (j : ℝ)) ^ (h2BooleanV0 / 2)) := by
      gcongr
    _ = _ := by
      dsimp [B, Csh, Cr]
      ring

#print axioms h2BooleanGoodFrequencyFiberSumTwisted_le_log_power

theorem h2BooleanGoodFrequencyFiberSumTwisted_le_log_power_closed
    (q : ℕ) :
    ∃ M0 : ℕ, ∀ M j : ℕ,
      ∀ u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ,
      H2BooleanTwistFamilyCompatible q (h2BooleanRoughCutoff M) M j u →
      M0 ≤ M →
      2 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      4 ≤ j →
      3 ≤ Nat.nthRoot 4 M →
      (h2BooleanRoughCutoff M) ^ 2 ≤ M →
      (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanDyadicFrequencyFiberMomentTwisted
          q (h2BooleanRoughCutoff M) M T j u) ≤
        (6 *
          PaperB.M4B.shiuFixedQuarterAssembleConstant
            8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
          Real.exp (6 * h2BooleanV0 + 24) *
          Real.exp (5 * h2BooleanV0 + 24)) *
        ((Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 /
          Real.log (M : ℝ)) *
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) *
        (Real.log (M : ℝ)) ^
          (h2BooleanTheta * (h2BooleanV0 / 2)) *
        (Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by
  rcases h2BooleanGoodFrequencyFiberSumTwisted_le_log_power q with ⟨M0, hgood⟩
  refine ⟨M0, ?_⟩
  intro M j u hcompat hM0 hM hY hj hroot hYsq
  exact hgood M j u hcompat hM0 hM hY hj
    (fun T hT => h2Boolean_good_roughCutoff_le_scaledCover hT hroot hYsq)
    (fun T hT => (h2Boolean_good_scaledCover_log_lower hT hM hroot).le)

#print axioms h2BooleanGoodFrequencyFiberSumTwisted_le_log_power_closed

theorem h2BooleanGoodFrequencyFiberSumTwisted_le_log_power_small_frequency
    (q : ℕ) :
    ∃ M0 : ℕ, ∀ M j : ℕ,
      ∀ u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ,
      H2BooleanTwistFamilyCompatible q (h2BooleanRoughCutoff M) M j u →
      M0 ≤ M →
      2 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      1 ≤ j →
      j < 4 →
      (∀ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanRoughCutoff M ≤
          PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)) →
      (∀ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        (1 / 2 : ℝ) * Real.log (M : ℝ) ≤
          Real.log (PaperB.M4B.scaledCoverUpper
            (2 * M) (primeSetProduct T) : ℝ)) →
      (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanDyadicFrequencyFiberMomentTwisted
          q (h2BooleanRoughCutoff M) M T j u) ≤
        (6 *
          PaperB.M4B.shiuFixedQuarterAssembleConstant
            8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
          Real.exp (6 * h2BooleanV0 + 24) *
          Real.exp (5 * (h2BooleanV0 / 2) + 12)) *
        ((Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 /
          Real.log (M : ℝ)) *
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) *
        (Real.log (M : ℝ)) ^
          (h2BooleanTheta * (h2BooleanV0 / 2)) := by
  rcases h2BooleanGoodFrequencyFiberSumTwisted_le_m3_uniform q with ⟨M0, hraw⟩
  refine ⟨M0, ?_⟩
  intro M j u hcompat hM0 hM hY hj hj4 hYX hloglow
  have hM1 : 1 ≤ M := by omega
  have hlogMpos : 0 < Real.log (M : ℝ) := by
    exact Real.log_pos (by exact_mod_cast (show 1 < M by omega))
  have hbase := hraw M j u hcompat hM0 hM1 hY
  let Csh : ℝ := PaperB.M4B.shiuFixedQuarterAssembleConstant
    8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold)
  let Cr : ℝ := Real.exp (6 * h2BooleanV0 + 24)
  let B : ℝ :=
    6 * Csh * Cr *
      ((Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 /
        Real.log (M : ℝ)) *
      (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0)
  have hB0 : 0 ≤ B := by
    dsimp [B, Csh, Cr, PaperB.M4B.shiuFixedQuarterAssembleConstant,
      PaperB.M4B.shiuClassIVConstant]
    positivity
  have hpoint : ∀ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
      ((primeSetProduct T : ℝ) / (M : ℝ)) * Csh *
          ((PaperB.M4B.scaledCoverLength
              (2 * M) M (primeSetProduct T) : ℝ) /
            Real.log (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T) : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt)
            (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T))
            (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))
        ≤ B * (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
    intro T hT
    let x := PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)
    let y := PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T)
    have hxY : h2BooleanRoughCutoff M ≤ x := by simpa [x] using hYX T hT
    have hx4 : 4 ≤ x := hY.trans hxY
    have hrough := h2BooleanSecondRough_exp_primeMass_cutoff_le
      (q := q) (M := M) (X := x) (k := primeSetProduct T)
      hM (by omega) hxY hx4
    have hxup : x ≤ 2 * M + 1 := by
      simpa [x] using h2Boolean_good_scaledCoverUpper_le_twoM_add_one hT
    have hxpos : (0 : ℝ) < x := by exact_mod_cast (show 0 < x by omega)
    have htoppos : (0 : ℝ) < ((2 * M + 1 : ℕ) : ℝ) := by positivity
    have hlogxpos : 0 < Real.log (x : ℝ) :=
      Real.log_pos (by exact_mod_cast (show 1 < x by omega))
    have hlogup : Real.log (x : ℝ) ≤
        Real.log ((2 * M + 1 : ℕ) : ℝ) :=
      Real.strictMonoOn_log.monotoneOn hxpos htoppos (by exact_mod_cast hxup)
    have hlogtop0 : 0 ≤ Real.log ((2 * M + 1 : ℕ) : ℝ) :=
      Real.log_nonneg (by exact_mod_cast (show 1 ≤ 2 * M + 1 by omega))
    have hpup :
        (Real.log (x : ℝ)) ^ h2BooleanV0 ≤
          (Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 :=
      Real.rpow_le_rpow hlogxpos.le hlogup h2BooleanV0_nonneg
    have hinvlog :
        1 / Real.log (x : ℝ) ≤ 2 / Real.log (M : ℝ) := by
      have hl := hloglow T hT
      have hhalfpos : 0 < (1 / 2 : ℝ) * Real.log (M : ℝ) := by positivity
      have hi := one_div_le_one_div_of_le hhalfpos hl
      have hhalf :
          1 / ((1 / 2 : ℝ) * Real.log (M : ℝ)) =
            2 / Real.log (M : ℝ) := by field_simp [hlogMpos.ne']
      rw [hhalf] at hi
      simpa [x] using hi
    have hscale := h2Boolean_good_scale_length_le_three hT
    have hprod0 : 0 ≤ ∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ) :=
      h2BooleanM3LocalWeight_prod_nonneg (j : ℤ)
        (h2BooleanGoodSmoothSetsNontrivial_active hT)
    have hnegpow0 : 0 ≤
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) :=
      Real.rpow_nonneg hlogMpos.le _
    have hCsh0 : 0 ≤ Csh := by
      dsimp [Csh, PaperB.M4B.shiuFixedQuarterAssembleConstant,
        PaperB.M4B.shiuClassIVConstant]
      positivity
    change
      ((primeSetProduct T : ℝ) / (M : ℝ)) * Csh *
          ((y : ℝ) / Real.log (x : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt) x (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))
        ≤ B * (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))
    rw [show ((y : ℝ) / Real.log (x : ℝ)) =
        (y : ℝ) * (1 / Real.log (x : ℝ)) by ring]
    calc
      ((primeSetProduct T : ℝ) / (M : ℝ)) * Csh *
          ((y : ℝ) * (1 / Real.log (x : ℝ))) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt) x (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))
        = Csh *
          ((((primeSetProduct T : ℝ) / (M : ℝ)) * (y : ℝ)) *
            (1 / Real.log (x : ℝ)) *
            Real.exp (PaperB.M4B.primeMass
              (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
                h2BooleanSecondTilt) x (primeSetProduct T)) *
            (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))) := by ring
      _ ≤ Csh *
          (3 * (2 / Real.log (M : ℝ)) *
            (Cr * (Real.log (x : ℝ)) ^ h2BooleanV0 *
              (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0)) *
            (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))) := by
            apply mul_le_mul_of_nonneg_left _ hCsh0
            gcongr
      _ ≤ Csh *
          (3 * (2 / Real.log (M : ℝ)) *
            (Cr * (Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 *
              (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0)) *
            (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))) := by
            gcongr
      _ = B * (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
            dsimp [B]
            ring
  have hsum :
      (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanDyadicFrequencyFiberMomentTwisted
          q (h2BooleanRoughCutoff M) M T j u) ≤
        B * ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
    calc
      _ ≤ ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          ((primeSetProduct T : ℝ) / (M : ℝ)) * Csh *
          ((PaperB.M4B.scaledCoverLength
              (2 * M) M (primeSetProduct T) : ℝ) /
            Real.log (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T) : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt)
            (PaperB.M4B.scaledCoverUpper
              (2 * M) (primeSetProduct T))
            (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
            simpa [Csh] using hbase
      _ ≤ ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          B * (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
            apply Finset.sum_le_sum
            intro T hT
            exact hpoint T hT
      _ = B * ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
            rw [Finset.mul_sum]
  have hm3 := h2BooleanM3_sum_family_le_log_power_small_frequency
    (q := q) (Y := h2BooleanRoughCutoff M) (j := j)
    hY hj hj4 (h2BooleanGoodSmoothSetsNontrivial q M)
    (h2BooleanGoodSmoothSetsNontrivial_subset q M)
  have hsmooth := h2BooleanRoughCutoff_smooth_rpow_le hM
  calc
    _ ≤ B * ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := hsum
    _ ≤ B * (Real.exp (5 * (h2BooleanV0 / 2) + 12) *
        (Real.log (h2BooleanRoughCutoff M : ℝ)) ^ (h2BooleanV0 / 2)) :=
      mul_le_mul_of_nonneg_left hm3 hB0
    _ ≤ B * (Real.exp (5 * (h2BooleanV0 / 2) + 12) *
        (Real.log (M : ℝ)) ^
          (h2BooleanTheta * (h2BooleanV0 / 2))) := by
      gcongr
    _ = _ := by
      dsimp [B, Csh, Cr]
      ring

#print axioms h2BooleanGoodFrequencyFiberSumTwisted_le_log_power_small_frequency

theorem h2BooleanGoodFrequencyFiberSumTwisted_le_log_power_small_frequency_closed
    (q : ℕ) :
    ∃ M0 : ℕ, ∀ M j : ℕ,
      ∀ u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ,
      H2BooleanTwistFamilyCompatible q (h2BooleanRoughCutoff M) M j u →
      M0 ≤ M →
      2 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      1 ≤ j →
      j < 4 →
      3 ≤ Nat.nthRoot 4 M →
      (h2BooleanRoughCutoff M) ^ 2 ≤ M →
      (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanDyadicFrequencyFiberMomentTwisted
          q (h2BooleanRoughCutoff M) M T j u) ≤
        (6 *
          PaperB.M4B.shiuFixedQuarterAssembleConstant
            8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
          Real.exp (6 * h2BooleanV0 + 24) *
          Real.exp (5 * (h2BooleanV0 / 2) + 12)) *
        ((Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 /
          Real.log (M : ℝ)) *
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) *
        (Real.log (M : ℝ)) ^
          (h2BooleanTheta * (h2BooleanV0 / 2)) := by
  rcases h2BooleanGoodFrequencyFiberSumTwisted_le_log_power_small_frequency q with
    ⟨M0, hgood⟩
  refine ⟨M0, ?_⟩
  intro M j u hcompat hM0 hM hY hj hj4 hroot hYsq
  exact hgood M j u hcompat hM0 hM hY hj hj4
    (fun T hT => h2Boolean_good_roughCutoff_le_scaledCover hT hroot hYsq)
    (fun T hT => (h2Boolean_good_scaledCover_log_lower hT hM hroot).le)

#print axioms h2BooleanGoodFrequencyFiberSumTwisted_le_log_power_small_frequency_closed

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem h2BooleanDyadicFrequencyFiberMomentTwisted_le_exp_rough_mass
    {q Y M : ℕ} {T : Finset ℕ} {j : ℕ}
    (u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ)
    (u0 : (ZMod (primeSetProduct T))ˣ)
    (hcompat : H2BooleanTwistFiberCompatible q Y M j T u u0)
    (hT : ∀ p ∈ T, activeHighPrime q p) :
    h2BooleanDyadicFrequencyFiberMomentTwisted q Y M T j u ≤
      (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
        Real.exp (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
          (2 * M) (primeSetProduct T)) := by
  have hfiber := h2BooleanDyadicFrequencyFiberMomentTwisted_le_roughProducts
    (q := q) (Y := Y) (M := M) (T := T) (j := j) u u0 hT hcompat
  let f := h2BooleanRoughTiltLift q Y h2BooleanSecondTilt
  let R := h2BooleanDyadicRoughProducts q Y M T
  have hPrimeT : ∀ p ∈ T, p.Prime := fun p hp => (hT p hp).1
  have hmpos : 0 < primeSetProduct T := primeSetProduct_pos hPrimeT
  have hpoint : ∀ r ∈ R,
      h2BooleanRoughFiberTermExternal q Y T hT j r u0 ≤ f r / (r : ℝ) := by
    intro r hr
    have hcop := h2BooleanDyadicRoughProducts_coprime_smooth
      (q := q) (Y := Y) (M := M) (T := T) hr
    rw [h2BooleanRoughFiberTermExternal_eq_of_coprime hT j r u0 hcop]
    have hcoeff := norm_fixedProductBooleanFourierCoeff_le_one
      T hPrimeT
      (((j : ZMod (primeSetProduct T)) *
          (u0 : ZMod (primeSetProduct T))) *
        (((ZMod.unitOfCoprime r hcop)⁻¹ :
          (ZMod (primeSetProduct T))ˣ) : ZMod (primeSetProduct T)))
    have hcoeff0 : 0 ≤
        ‖fixedProductBooleanFourierCoeff T hPrimeT
          (((j : ZMod (primeSetProduct T)) *
              (u0 : ZMod (primeSetProduct T))) *
            (((ZMod.unitOfCoprime r hcop)⁻¹ :
              (ZMod (primeSetProduct T))ˣ) : ZMod (primeSetProduct T)))‖ := norm_nonneg _
    have hsqle :
        ‖fixedProductBooleanFourierCoeff T hPrimeT
          (((j : ZMod (primeSetProduct T)) *
              (u0 : ZMod (primeSetProduct T))) *
            (((ZMod.unitOfCoprime r hcop)⁻¹ :
              (ZMod (primeSetProduct T))ˣ) : ZMod (primeSetProduct T)))‖ ^ 2 ≤ 1 := by
      nlinarith
    have hf0 : 0 ≤ f r := by
      dsimp [f]
      exact h2BooleanRoughTiltLift_nonneg q Y r h2BooleanSecondTilt_nonneg
    have hr0 : 0 ≤ (r : ℝ) := by positivity
    have hfr0 : 0 ≤ f r / (r : ℝ) := div_nonneg hf0 hr0
    exact mul_le_of_le_one_right hfr0 hsqle
  have hsubset : R ⊆
      (Finset.Icc 1 (2 * M)).filter
        (fun r => r.Coprime (primeSetProduct T)) := by
    intro r hr
    rw [Finset.mem_filter]
    have hrpos := h2BooleanDyadicRoughProducts_pos
      (q := q) (Y := Y) (M := M) (T := T) hr
    have hrange := h2BooleanDyadicRoughProducts_range
      (q := q) (Y := Y) (M := M) (T := T) hr
    have hrle : r ≤ 2 * M := by
      have hm1 : 1 ≤ primeSetProduct T := hmpos
      nlinarith
    exact ⟨Finset.mem_Icc.mpr ⟨hrpos, hrle⟩,
      h2BooleanDyadicRoughProducts_coprime_smooth
        (q := q) (Y := Y) (M := M) (T := T) hr⟩
  have hsum :
      (∑ r ∈ R, h2BooleanRoughFiberTermExternal q Y T hT j r u0) ≤
        PaperB.M4B.coprimeHarmonicMass f (2 * M) (primeSetProduct T) := by
    calc
      (∑ r ∈ R, h2BooleanRoughFiberTermExternal q Y T hT j r u0)
          ≤ ∑ r ∈ R, f r / (r : ℝ) := by
            apply Finset.sum_le_sum
            intro r hr
            exact hpoint r hr
      _ ≤ ∑ r ∈ (Finset.Icc 1 (2 * M)).filter
            (fun r => r.Coprime (primeSetProduct T)),
            f r / (r : ℝ) := by
          apply Finset.sum_le_sum_of_subset_of_nonneg hsubset
          intro r hr hnot
          exact div_nonneg
            (by
              dsimp [f]
              exact h2BooleanRoughTiltLift_nonneg
                q Y r h2BooleanSecondTilt_nonneg)
            (by positivity)
      _ = PaperB.M4B.coprimeHarmonicMass f (2 * M)
          (primeSetProduct T) := by
            rfl
  have heuler :
      PaperB.M4B.coprimeHarmonicMass f (2 * M) (primeSetProduct T) ≤
        Real.exp (PaperB.M4B.primeMass f (2 * M) (primeSetProduct T)) := by
    exact PaperB.M4B.squarefree_coprime_harmonic_upper
      (h2BooleanRoughTiltLift_envelope q Y
        h2BooleanSecondTilt_nonneg h2BooleanSecondTilt_le_three_halves)
      (2 * M) (primeSetProduct T)
  have hweight0 : 0 ≤ finiteOmegaWeightReal T * h2BooleanV0 ^ T.card :=
    mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hT)
      (pow_nonneg h2BooleanV0_nonneg _)
  calc
    h2BooleanDyadicFrequencyFiberMomentTwisted q Y M T j u
      ≤ (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
          ∑ r ∈ R, h2BooleanRoughFiberTermExternal q Y T hT j r u0 := by
            simpa [R] using hfiber
    _ ≤ (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
          PaperB.M4B.coprimeHarmonicMass f (2 * M)
            (primeSetProduct T) :=
      mul_le_mul_of_nonneg_left hsum hweight0
    _ ≤ (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
          Real.exp (PaperB.M4B.primeMass f (2 * M) (primeSetProduct T)) :=
      mul_le_mul_of_nonneg_left heuler hweight0
    _ = _ := by rfl

#print axioms h2BooleanDyadicFrequencyFiberMomentTwisted_le_exp_rough_mass

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem h2BooleanBadFrequencyFiberSumTwisted_le_raw
    (q M j : ℕ)
    (u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ)
    (hcompat :
      H2BooleanTwistFamilyCompatible
        q (h2BooleanRoughCutoff M) M j u) :
    (∑ T ∈ h2BooleanBadSmoothSets q M,
      h2BooleanDyadicFrequencyFiberMomentTwisted
        q (h2BooleanRoughCutoff M) M T j u) ≤
      Real.exp
        (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
            h2BooleanSecondTilt)
          (2 * M) 1) *
      (∑ T ∈ h2BooleanBadSmoothSets q M,
        finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) := by
  let E := Real.exp
    (PaperB.M4B.primeMass
      (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
        h2BooleanSecondTilt)
      (2 * M) 1)
  calc
    (∑ T ∈ h2BooleanBadSmoothSets q M,
      h2BooleanDyadicFrequencyFiberMomentTwisted
        q (h2BooleanRoughCutoff M) M T j u)
      ≤ ∑ T ∈ h2BooleanBadSmoothSets q M,
          (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) * E := by
        apply Finset.sum_le_sum
        intro T hT
        have hA := h2BooleanBadSmoothSets_active hT
        rcases hcompat T
          (h2BooleanBadSmoothSets_subset_powerset (q := q) (M := M) hT) with
          ⟨u0, hcompatT⟩
        have hraw :=
          h2BooleanDyadicFrequencyFiberMomentTwisted_le_exp_rough_mass
            (q := q) (Y := h2BooleanRoughCutoff M) (M := M)
            (T := T) (j := j) u u0 hcompatT hA
        have hmass :=
          h2BooleanRough_exp_primeMass_le_modulus_one
            q (h2BooleanRoughCutoff M) (2 * M) (primeSetProduct T)
        have hw0 : 0 ≤ finiteOmegaWeightReal T * h2BooleanV0 ^ T.card :=
          mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hA)
            (pow_nonneg h2BooleanV0_nonneg _)
        exact hraw.trans (mul_le_mul_of_nonneg_left
          (by simpa [E] using hmass) hw0)
    _ = E * (∑ T ∈ h2BooleanBadSmoothSets q M,
        finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro T hT
      ring
    _ = _ := by rfl

theorem h2BooleanBadFrequencyFiberSumTwisted_le_rankin
    {q M j : ℕ}
    (u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ)
    (hcompat :
      H2BooleanTwistFamilyCompatible
        q (h2BooleanRoughCutoff M) M j u)
    (hM : 2 ≤ M)
    (hlog : 1 ≤ Real.log (M : ℝ))
    (hC : h2BooleanTailCorrectionConst ≤
      (1 / 8 : ℝ) * (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) :
    (∑ T ∈ h2BooleanBadSmoothSets q M,
      h2BooleanDyadicFrequencyFiberMomentTwisted
        q (h2BooleanRoughCutoff M) M T j u) ≤
      Real.exp
        (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
            h2BooleanSecondTilt)
          (2 * M) 1) *
      Real.exp
        (PaperB.M4B.primeMass
          (h2BooleanTiltLift q h2BooleanSecondTilt)
          (h2BooleanRoughCutoff M) q -
        (1 / 8 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) := by
  have hraw := h2BooleanBadFrequencyFiberSumTwisted_le_raw
    q M j u hcompat
  have htail := h2BooleanBadSmoothWeightSum_rankin
    (q := q) (M := M) hM hlog hC
  have hE0 : 0 ≤ Real.exp
      (PaperB.M4B.primeMass
        (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
          h2BooleanSecondTilt)
        (2 * M) 1) := (Real.exp_pos _).le
  exact hraw.trans (mul_le_mul_of_nonneg_left htail hE0)

#print axioms h2BooleanBadFrequencyFiberSumTwisted_le_raw
#print axioms h2BooleanBadFrequencyFiberSumTwisted_le_rankin

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem h2BooleanBadFrequencyFiberSumTwisted_le_log_power_raw
    {q M j : ℕ}
    (u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ)
    (hcompat : H2BooleanTwistFamilyCompatible
      q (h2BooleanRoughCutoff M) M j u)
    (hM : 2 ≤ M)
    (hY4 : 4 ≤ h2BooleanRoughCutoff M)
    (hYsq : (h2BooleanRoughCutoff M) ^ 2 ≤ M)
    (hlog : 1 ≤ Real.log (M : ℝ))
    (hC : h2BooleanTailCorrectionConst ≤
      (1 / 8 : ℝ) * (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) :
    (∑ T ∈ h2BooleanBadSmoothSets q M,
      h2BooleanDyadicFrequencyFiberMomentTwisted
        q (h2BooleanRoughCutoff M) M T j u) ≤
      (Real.exp (6 * h2BooleanV0 + 24) *
        (Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0 *
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0)) *
      (Real.exp (10 * h2BooleanSecondTilt + 24) *
        (Real.log (h2BooleanRoughCutoff M : ℝ)) ^ h2BooleanV0 *
        Real.exp (-(1 / 8 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta))) := by
  have hbad := h2BooleanBadFrequencyFiberSumTwisted_le_rankin
    (q := q) (M := M) (j := j) u hcompat hM hlog hC
  have hY1 : 1 ≤ h2BooleanRoughCutoff M := by omega
  have hYleM : h2BooleanRoughCutoff M ≤ M := by
    have hYY : h2BooleanRoughCutoff M ≤
        (h2BooleanRoughCutoff M) ^ 2 := by
      calc
        h2BooleanRoughCutoff M =
            h2BooleanRoughCutoff M * 1 := by simp
        _ ≤ h2BooleanRoughCutoff M * h2BooleanRoughCutoff M := by
          exact Nat.mul_le_mul_left _ hY1
        _ = (h2BooleanRoughCutoff M) ^ 2 := by ring
    exact hYY.trans hYsq
  have hYX : h2BooleanRoughCutoff M ≤ 2 * M := hYleM.trans (by omega)
  have hX4 : 4 ≤ 2 * M := by omega
  have hrough := h2BooleanSecondRough_exp_primeMass_cutoff_le
    (q := q) (M := M) (X := 2 * M) (k := 1)
    hM (by omega) hYX hX4
  have hsmooth := h2BooleanSecondTiltLift_exp_primeMass_le
    q (h2BooleanRoughCutoff M) q hY4
  have hR0 : 0 ≤
      Real.exp (-(1 / 8 : ℝ) *
        (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) :=
    (Real.exp_pos _).le
  have hroughR0 : 0 ≤
      Real.exp
        (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
            h2BooleanSecondTilt)
          (2 * M) 1) := (Real.exp_pos _).le
  calc
    (∑ T ∈ h2BooleanBadSmoothSets q M,
      h2BooleanDyadicFrequencyFiberMomentTwisted
        q (h2BooleanRoughCutoff M) M T j u)
      ≤ Real.exp
          (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt)
            (2 * M) 1) *
        Real.exp
          (PaperB.M4B.primeMass
            (h2BooleanTiltLift q h2BooleanSecondTilt)
            (h2BooleanRoughCutoff M) q -
          (1 / 8 : ℝ) *
            (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) := hbad
    _ = Real.exp
          (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt)
            (2 * M) 1) *
        (Real.exp
          (PaperB.M4B.primeMass
            (h2BooleanTiltLift q h2BooleanSecondTilt)
            (h2BooleanRoughCutoff M) q) *
          Real.exp (-(1 / 8 : ℝ) *
            (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta))) := by
          rw [show
            PaperB.M4B.primeMass
                (h2BooleanTiltLift q h2BooleanSecondTilt)
                (h2BooleanRoughCutoff M) q -
              (1 / 8 : ℝ) *
                (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) =
            PaperB.M4B.primeMass
                (h2BooleanTiltLift q h2BooleanSecondTilt)
                (h2BooleanRoughCutoff M) q +
              (-(1 / 8 : ℝ) *
                (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) by ring]
          rw [Real.exp_add]
    _ ≤
      (Real.exp (6 * h2BooleanV0 + 24) *
        (Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0 *
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0)) *
      (Real.exp
          (PaperB.M4B.primeMass
            (h2BooleanTiltLift q h2BooleanSecondTilt)
            (h2BooleanRoughCutoff M) q) *
        Real.exp (-(1 / 8 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta))) := by
            gcongr
    _ ≤
      (Real.exp (6 * h2BooleanV0 + 24) *
        (Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0 *
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0)) *
      (Real.exp (10 * h2BooleanSecondTilt + 24) *
        (Real.log (h2BooleanRoughCutoff M : ℝ)) ^ h2BooleanV0 *
        Real.exp (-(1 / 8 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta))) := by
            gcongr

#print axioms h2BooleanBadFrequencyFiberSumTwisted_le_log_power_raw

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem h2BooleanEmptyFrequencyFiberTwisted_le_rough_interval
    {q Y M j : ℕ}
    (u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ)
    (u0 : (ZMod (primeSetProduct ∅))ˣ)
    (hcompat : H2BooleanTwistFiberCompatible q Y M j ∅ u u0)
    (hM : 0 < M) :
    h2BooleanDyadicFrequencyFiberMomentTwisted q Y M ∅ j u ≤
      (M : ℝ)⁻¹ *
        (∑ n ∈ Finset.Ioc M (2 * M),
          h2BooleanRoughTiltLift q Y h2BooleanSecondTilt n) := by
  have hrough :=
    h2BooleanDyadicFrequencyFiberMomentTwisted_le_roughProducts
      (q := q) (Y := Y) (M := M) (T := ∅) (j := j)
      u u0 (by simp) hcompat
  have hrough' :
      h2BooleanDyadicFrequencyFiberMomentTwisted q Y M ∅ j u ≤
        ∑ r ∈ h2BooleanDyadicRoughProducts q Y M ∅,
          h2BooleanRoughFiberTermExternal q Y ∅ (by simp) j r u0 := by
    simpa [finiteOmegaWeightReal, primeSetProduct] using hrough
  let R := h2BooleanDyadicRoughProducts q Y M ∅
  have hpoint : ∀ r ∈ R,
      h2BooleanRoughFiberTermExternal q Y ∅ (by simp) j r u0 ≤
        (M : ℝ)⁻¹ *
          h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r := by
    intro r hr
    have hcop := h2BooleanDyadicRoughProducts_coprime_smooth
      (q := q) (Y := Y) (M := M) (T := ∅) hr
    rw [h2BooleanRoughFiberTermExternal_eq_of_coprime (T := ∅) (by simp) j r u0 hcop]
    have hcoeff := norm_fixedProductBooleanFourierCoeff_le_one
      (∅ : Finset ℕ) (by simp)
      (((j : ZMod (primeSetProduct ∅)) *
          (u0 : ZMod (primeSetProduct ∅))) *
        (((ZMod.unitOfCoprime r hcop)⁻¹ :
          (ZMod (primeSetProduct ∅))ˣ) : ZMod (primeSetProduct ∅)))
    have hcoeff0 : 0 ≤
        ‖fixedProductBooleanFourierCoeff (∅ : Finset ℕ) (by simp)
          (((j : ZMod (primeSetProduct ∅)) *
              (u0 : ZMod (primeSetProduct ∅))) *
            (((ZMod.unitOfCoprime r hcop)⁻¹ :
              (ZMod (primeSetProduct ∅))ˣ) : ZMod (primeSetProduct ∅)))‖ :=
      norm_nonneg _
    have hsqle :
        ‖fixedProductBooleanFourierCoeff (∅ : Finset ℕ) (by simp)
          (((j : ZMod (primeSetProduct ∅)) *
              (u0 : ZMod (primeSetProduct ∅))) *
            (((ZMod.unitOfCoprime r hcop)⁻¹ :
              (ZMod (primeSetProduct ∅))ˣ) : ZMod (primeSetProduct ∅)))‖ ^ 2 ≤ 1 := by
      nlinarith
    have hrange := h2BooleanDyadicRoughProducts_range
      (q := q) (Y := Y) (M := M) (T := ∅) hr
    simp [primeSetProduct] at hrange
    have hrpos : (0 : ℝ) < r := by exact_mod_cast (lt_trans hM hrange.1)
    have hMposR : (0 : ℝ) < M := by exact_mod_cast hM
    have hMr : (M : ℝ) ≤ (r : ℝ) := by exact_mod_cast hrange.1.le
    have hinv : (r : ℝ)⁻¹ ≤ (M : ℝ)⁻¹ := by
      simpa [one_div] using one_div_le_one_div_of_le hMposR hMr
    have hf0 : 0 ≤ h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r :=
      h2BooleanRoughTiltLift_nonneg q Y r h2BooleanSecondTilt_nonneg
    rw [div_eq_mul_inv]
    calc
      (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r * (r : ℝ)⁻¹) *
          ‖fixedProductBooleanFourierCoeff (∅ : Finset ℕ) (by simp)
            (((j : ZMod (primeSetProduct ∅)) *
                (u0 : ZMod (primeSetProduct ∅))) *
              (((ZMod.unitOfCoprime r hcop)⁻¹ :
                (ZMod (primeSetProduct ∅))ˣ) : ZMod (primeSetProduct ∅)))‖ ^ 2
        ≤ h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r * (r : ℝ)⁻¹ := by
          exact mul_le_of_le_one_right
            (mul_nonneg hf0 (inv_nonneg.mpr hrpos.le)) hsqle
      _ ≤ h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r * (M : ℝ)⁻¹ :=
        mul_le_mul_of_nonneg_left hinv hf0
      _ = (M : ℝ)⁻¹ *
          h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r := by ring
  have hsub : R ⊆ Finset.Ioc M (2 * M) := by
    intro r hr
    have hrange := h2BooleanDyadicRoughProducts_range
      (q := q) (Y := Y) (M := M) (T := ∅) hr
    simp [primeSetProduct] at hrange ⊢
    exact hrange
  have hsum :
      (∑ r ∈ R, h2BooleanRoughFiberTermExternal q Y ∅ (by simp) j r u0) ≤
        ∑ r ∈ Finset.Ioc M (2 * M),
          (M : ℝ)⁻¹ *
            h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r := by
    calc
      _ ≤ ∑ r ∈ R,
          (M : ℝ)⁻¹ *
            h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r := by
            apply Finset.sum_le_sum
            intro r hr
            exact hpoint r hr
      _ ≤ ∑ r ∈ Finset.Ioc M (2 * M),
          (M : ℝ)⁻¹ *
            h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r := by
            apply Finset.sum_le_sum_of_subset_of_nonneg hsub
            intro r hr hnot
            exact mul_nonneg (inv_nonneg.mpr (by positivity))
              (h2BooleanRoughTiltLift_nonneg
                q Y r h2BooleanSecondTilt_nonneg)
  calc
    h2BooleanDyadicFrequencyFiberMomentTwisted q Y M ∅ j u
      ≤ ∑ r ∈ R, h2BooleanRoughFiberTermExternal q Y ∅ (by simp) j r u0 := by
          simpa [R] using hrough'
    _ ≤ ∑ r ∈ Finset.Ioc M (2 * M),
          (M : ℝ)⁻¹ *
            h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r := hsum
    _ = (M : ℝ)⁻¹ *
        (∑ n ∈ Finset.Ioc M (2 * M),
          h2BooleanRoughTiltLift q Y h2BooleanSecondTilt n) := by
          rw [Finset.mul_sum]

#print axioms h2BooleanEmptyFrequencyFiberTwisted_le_rough_interval

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem h2BooleanEmptyFrequencyFiberTwisted_le_rough_log_power
    (q : ℕ) (hq : 0 < q) :
    ∃ X0 : ℕ, ∀ M j : ℕ,
      ∀ u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ,
      ∀ u0 : (ZMod (primeSetProduct ∅))ˣ,
      H2BooleanTwistFiberCompatible
        q (h2BooleanRoughCutoff M) M j ∅ u u0 →
      X0 ≤ 2 * M →
      2 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      (h2BooleanRoughCutoff M) ^ 2 ≤ M →
      ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
      ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
      h2BooleanDyadicFrequencyFiberMomentTwisted
          q (h2BooleanRoughCutoff M) M ∅ j u ≤
        ((6 * q : ℝ) *
          PaperB.M4B.shiuFixedQuarterAssembleConstant
            8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
          Real.exp (6 * h2BooleanV0 + 24)) *
        (((Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0) /
          Real.log ((2 * M : ℕ) : ℝ)) *
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) := by
  rcases h2BooleanRoughSecondTilt_interval_shiu_uniform q hq with
    ⟨X0, hI⟩
  refine ⟨X0, ?_⟩
  intro M j u u0 hcompat hX hM hY4 hYsq hquarter hk
  have hMpos : 0 < M := by omega
  have hraw := h2BooleanEmptyFrequencyFiberTwisted_le_rough_interval
    (q := q) (Y := h2BooleanRoughCutoff M) (M := M) (j := j)
    u u0 hcompat hMpos
  have hI' := hI (h2BooleanRoughCutoff M) M
    hX (by omega) hquarter hk
  have hY1 : 1 ≤ h2BooleanRoughCutoff M := by omega
  have hYleM : h2BooleanRoughCutoff M ≤ M := by
    have hYY : h2BooleanRoughCutoff M ≤
        (h2BooleanRoughCutoff M) ^ 2 := by
      calc
        h2BooleanRoughCutoff M =
            h2BooleanRoughCutoff M * 1 := by simp
        _ ≤ h2BooleanRoughCutoff M * h2BooleanRoughCutoff M :=
          Nat.mul_le_mul_left _ hY1
        _ = (h2BooleanRoughCutoff M) ^ 2 := by ring
    exact hYY.trans hYsq
  have hYX : h2BooleanRoughCutoff M ≤ 2 * M := hYleM.trans (by omega)
  have hmass := h2BooleanSecondRough_exp_primeMass_cutoff_le
    (q := q) (M := M) (X := 2 * M) (k := 6 * q)
    hM (by omega) hYX (by omega)
  have hlogX : 0 < Real.log ((2 * M : ℕ) : ℝ) := by
    apply Real.log_pos
    exact_mod_cast (show 1 < 2 * M by omega)
  have hphiNat : 0 < (6 * q).totient :=
    Nat.totient_pos.mpr (by omega)
  have hphi : (1 : ℝ) ≤ ((6 * q).totient : ℝ) := by
    exact_mod_cast hphiNat
  have hden :
      Real.log ((2 * M : ℕ) : ℝ) ≤
        ((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ) := by
    nlinarith
  have hfrac :
      (M : ℝ) /
          (((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ))
        ≤ (M : ℝ) / Real.log ((2 * M : ℕ) : ℝ) :=
    div_le_div_of_nonneg_left (by positivity) hlogX hden
  let Csh : ℝ := PaperB.M4B.shiuFixedQuarterAssembleConstant
    8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold)
  let Cr : ℝ := Real.exp (6 * h2BooleanV0 + 24)
  have hCsh0 : 0 ≤ Csh := by
    dsimp [Csh, PaperB.M4B.shiuFixedQuarterAssembleConstant,
      PaperB.M4B.shiuClassIVConstant]
    positivity
  have hCr0 : 0 ≤ Cr := by dsimp [Cr]; positivity
  have hlogpow0 : 0 ≤
      (Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0 :=
    Real.rpow_nonneg hlogX.le _
  have hnegpow0 : 0 ≤
      (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) :=
    Real.rpow_nonneg
      (Real.log_nonneg (by exact_mod_cast (show 1 ≤ M by omega))) _
  calc
    h2BooleanDyadicFrequencyFiberMomentTwisted
        q (h2BooleanRoughCutoff M) M ∅ j u
      ≤ (M : ℝ)⁻¹ *
          (∑ n ∈ Finset.Ioc M (2 * M),
            h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
              h2BooleanSecondTilt n) := hraw
    _ ≤ (M : ℝ)⁻¹ *
        ((6 * q : ℝ) * Csh *
          ((M : ℝ) /
            (((6 * q).totient : ℝ) *
              Real.log ((2 * M : ℕ) : ℝ))) *
          Real.exp
            (PaperB.M4B.primeMass
              (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
                h2BooleanSecondTilt)
              (2 * M) (6 * q))) := by
          apply mul_le_mul_of_nonneg_left hI'
          positivity
    _ ≤ (M : ℝ)⁻¹ *
        ((6 * q : ℝ) * Csh *
          ((M : ℝ) / Real.log ((2 * M : ℕ) : ℝ)) *
          Real.exp
            (PaperB.M4B.primeMass
              (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
                h2BooleanSecondTilt)
              (2 * M) (6 * q))) := by
          gcongr
    _ ≤ (M : ℝ)⁻¹ *
        ((6 * q : ℝ) * Csh *
          ((M : ℝ) / Real.log ((2 * M : ℕ) : ℝ)) *
          (Cr *
            (Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0 *
            (Real.log (M : ℝ)) ^
              (-h2BooleanTheta * h2BooleanV0))) := by
          dsimp [Cr]
          gcongr
    _ =
        ((6 * q : ℝ) * Csh * Cr) *
        (((Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0) /
          Real.log ((2 * M : ℕ) : ℝ)) *
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) := by
          have hMR : (M : ℝ) ≠ 0 := by exact_mod_cast hMpos.ne'
          field_simp [hMR, hlogX.ne']
    _ = _ := by rfl

#print axioms h2BooleanEmptyFrequencyFiberTwisted_le_rough_log_power

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem h2BooleanGoodFrequencyFiberSumTwisted_eq_empty_add_nontrivial
    (q M j : ℕ)
    (u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ)
    (hcut : 1 < h2BooleanSmoothProductCutoff M) :
    (∑ T ∈ h2BooleanGoodSmoothSets q M,
      h2BooleanDyadicFrequencyFiberMomentTwisted
        q (h2BooleanRoughCutoff M) M T j u) =
      h2BooleanDyadicFrequencyFiberMomentTwisted
        q (h2BooleanRoughCutoff M) M ∅ j u +
      ∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
        h2BooleanDyadicFrequencyFiberMomentTwisted
          q (h2BooleanRoughCutoff M) M T j u := by
  rw [h2BooleanGoodSmoothSets_eq_nontrivial_insert_empty q M hcut]
  rw [Finset.sum_insert (h2Boolean_empty_not_mem_good_nontrivial q M)]

theorem h2BooleanDyadicFrequencySecondMomentTwisted_le_quantitative_all
    (q : ℕ) (hq : 0 < q) :
    ∃ M0 : ℕ, ∀ M j : ℕ,
      ∀ u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ,
      H2BooleanTwistFamilyCompatible
        q (h2BooleanRoughCutoff M) M j u →
      M0 ≤ M →
      2 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      1 ≤ j →
      3 ≤ Nat.nthRoot 4 M →
      (h2BooleanRoughCutoff M) ^ 2 ≤ M →
      ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
      ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
      1 ≤ Real.log (M : ℝ) →
      h2BooleanTailCorrectionConst ≤
        (1 / 8 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) →
      h2BooleanDyadicFrequencySecondMomentTwisted q M j u ≤
        h2BooleanFrequencySecondMomentMajorantAll q M j := by
  rcases h2BooleanGoodFrequencyFiberSumTwisted_le_log_power_closed q with
    ⟨MG, hgoodLarge⟩
  rcases
      h2BooleanGoodFrequencyFiberSumTwisted_le_log_power_small_frequency_closed q with
    ⟨MS, hgoodSmall⟩
  rcases h2BooleanEmptyFrequencyFiberTwisted_le_rough_log_power q hq with
    ⟨XE, hempty⟩
  refine ⟨max MG (max MS XE), ?_⟩
  intro M j u hcompat hM0 hM hY4 hj hroot hYsq hquarter hk hlog hC
  have hMG : MG ≤ M := (le_max_left MG (max MS XE)).trans hM0
  have hMS : MS ≤ M := by
    exact (le_max_left MS XE).trans
      ((le_max_right MG (max MS XE)).trans hM0)
  have hXE : XE ≤ M := by
    exact (le_max_right MS XE).trans
      ((le_max_right MG (max MS XE)).trans hM0)
  have hXE2 : XE ≤ 2 * M := hXE.trans (by omega)
  have hemptyMem :
      (∅ : Finset ℕ) ∈
        (h2BooleanSmoothActivePrimeSet q (h2BooleanRoughCutoff M)).powerset := by
    simp
  rcases hcompat ∅ hemptyMem with ⟨uEmpty, hcompatEmpty⟩
  have he := hempty M j u uEmpty hcompatEmpty
    hXE2 hM hY4 hYsq hquarter hk
  have hb := h2BooleanBadFrequencyFiberSumTwisted_le_log_power_raw
    (q := q) (M := M) (j := j) u hcompat hM hY4 hYsq hlog hC
  have hcut : 1 < h2BooleanSmoothProductCutoff M := by
    unfold h2BooleanSmoothProductCutoff
    omega
  have hgsplit :=
    h2BooleanGoodFrequencyFiberSumTwisted_eq_empty_add_nontrivial
      q M j u hcut
  have he' :
      h2BooleanDyadicFrequencyFiberMomentTwisted
          q (h2BooleanRoughCutoff M) M ∅ j u ≤
        h2BooleanEmptyFrequencyMajorant q M := by
    simpa [h2BooleanEmptyFrequencyMajorant] using he
  have hb' :
      (∑ T ∈ h2BooleanBadSmoothSets q M,
        h2BooleanDyadicFrequencyFiberMomentTwisted
          q (h2BooleanRoughCutoff M) M T j u) ≤
        h2BooleanBadFrequencyMajorant q M := by
    simpa [h2BooleanBadFrequencyMajorant] using hb
  rw [h2BooleanDyadicFrequencySecondMomentTwisted_eq_good_add_bad
    q M j u]
  rw [hgsplit]
  by_cases hj4 : j < 4
  · have hg := hgoodSmall M j u hcompat hMS hM hY4 hj hj4 hroot hYsq
    have hg' :
        (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          h2BooleanDyadicFrequencyFiberMomentTwisted
            q (h2BooleanRoughCutoff M) M T j u) ≤
          h2BooleanGoodFrequencyMajorantSmall M := by
      simpa [h2BooleanGoodFrequencyMajorantSmall] using hg
    unfold h2BooleanFrequencySecondMomentMajorantAll
    rw [if_pos hj4]
    exact add_le_add (add_le_add he' hg') hb'
  · have hjLarge : 4 ≤ j := by omega
    have hg := hgoodLarge M j u hcompat hMG hM hY4 hjLarge hroot hYsq
    have hg' :
        (∑ T ∈ h2BooleanGoodSmoothSetsNontrivial q M,
          h2BooleanDyadicFrequencyFiberMomentTwisted
            q (h2BooleanRoughCutoff M) M T j u) ≤
          h2BooleanGoodFrequencyMajorant M j := by
      simpa [h2BooleanGoodFrequencyMajorant] using hg
    unfold h2BooleanFrequencySecondMomentMajorantAll
    rw [if_neg hj4]
    exact add_le_add (add_le_add he' hg') hb'

#print axioms h2BooleanGoodFrequencyFiberSumTwisted_eq_empty_add_nontrivial
#print axioms h2BooleanDyadicFrequencySecondMomentTwisted_le_quantitative_all

end PaperB.FixedQ
