import GoldC.QuillonCPhysical
import GoldC.QuillonLW

/-!
# Quillon LONG L3: the LONG-left region-C cell (Parseval-W + VW + Rankin; r long, s modulus)

Constant-4 copies of `CTerm_ev` and `rankin_Lw_ev`, the fixed-`C` cell `C_final_L` on the LONG-left
mask `GeoLL` (no upper cap on `r` is used: the dyadic `r`-pieces run up to `H²`), and the
**physical LONG-left C theorem** `CL_physical`. On LONG-left `s^{1+ε} ≤ s^{1+δ} < r` once
`ε = Λ^{-1/200} ≤ δ`, so the CORE region-C lower edge `LwC < r` holds automatically.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonLC

open GoldC.QuillonEv GoldC.QuillonSetup GoldC.QuillonLam GoldC.QuillonCEv GoldC.QuillonCFinal
  GoldC.QuillonCEst GoldC.QuillonLSetup GoldC.QuillonCPhysical GoldC.QuillonCopyM GoldC.QuillonWContext

/-- `ε = Λ^{-1/200} ≤ δ` eventually. -/
lemma εp_le_ev (δ : ℝ) (hδ0 : 0 < δ) : ∃ Λ₀ : ℝ, 1 ≤ Λ₀ ∧ ∀ h : ℕ, Λ₀ ≤ Real.log h → εp h ≤ δ := by
  obtain ⟨Λ₀, hΛ₀, hK⟩ := const_le_rpow (1 / δ) (1 / 200) (by norm_num)
  refine ⟨max 1 Λ₀, le_max_left _ _, fun h hΛ => ?_⟩
  have hΛ1 : 1 ≤ Real.log h := le_trans (le_max_left _ _) hΛ
  have h1 := hK _ (le_trans (le_max_right _ _) hΛ)
  unfold εp
  have hp : 0 < (Real.log h) ^ (1 / 200 : ℝ) := by positivity
  rw [Real.rpow_neg (by linarith), ← one_div, div_le_iff₀ hp]
  rw [div_le_iff₀ hδ0] at h1
  linarith

/-- On LONG-left, `s^{1+ε} ≤ r` once `ε ≤ δ`. -/
lemma LL_eps {h H : ℕ} {δ : ℝ} {r s : ℕ} (hεδ : εp h ≤ δ) (hG : GeoLL h H δ r s) :
    (s : ℝ) ^ (1 + εp h) ≤ r := by
  have hL := hG.2.2.1
  unfold longInverseLeft at hL
  rcases Nat.eq_zero_or_pos s with h0 | h0
  · subst h0
    have hε : 0 < 1 + εp h := by unfold εp; positivity
    rw [Nat.cast_zero, Real.zero_rpow hε.ne']; positivity
  · have hs1 : (1 : ℝ) ≤ s := by exact_mod_cast h0
    exact le_trans (Real.rpow_le_rpow_of_exponent_le hs1 (by linarith)) hL.le

set_option maxHeartbeats 4000000 in
/-- **Each region-C `CTerm` is `≤ Λ^{−40}`**, eventually in `h`, uniformly in admissible `s` and
dyadic pieces `(a, b]` with `s^{1+ε}/2 ≤ a < b ≤ 2a`, `b ≤ H²`. -/
theorem CTerm_ev4 (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (h H : ℕ), Λ₀ ≤ Real.log h → H ≤ h →
      ∀ (s M : ℕ) [NeZero s] [NeZero M] (C U' JP : Finset ℕ), (∀ p ∈ C, p.Prime) → s = ∏ p ∈ C, p →
        M = 6 * q → 4 * (Real.log h) ^ σ₀ ≤ Real.log (s : ℝ) →
        (∀ p ∈ U', p.Prime ∧ 5 ≤ p ∧ p ≤ H ^ 2) →
        ∀ (A : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s),
          (∀ ρ j, 1 ≤ j → ‖A ρ j‖ ≤ (300 * (q : ℝ) ^ 2) / j) →
          (∀ j, 1 ≤ j → C.filter (fun p => (ZMod.cast (c j) : ZMod p) = 0) = C.filter (fun p => p ∣ j)) →
          ∀ (Ec a b : ℕ), (Ec : ℝ) ≤ (Real.log h) ^ 2 →
            (s : ℝ) ^ (1 + εp h) / 2 ≤ a → a < b → b ≤ 2 * a → b ≤ H ^ 2 →
            GoldC.QuillonCCellApp.CTerm C (Icc 1 (6 * q * h)) A c U' JP (Xp h) (Yp δ s) (Tpp h)
              (Uvp s) (Uvp s) (Tvp h) Ec a b ≤ (Real.log h) ^ (-(40 : ℝ)) := by
  have ha0 := a0_pos hδ0 hδ1
  have ha0' := a0_le hδ0
  have hu0 : 0 < u0 δ := by unfold u0; linarith
  have hu1 : u0 δ ≤ 1 / 8 := by unfold u0; linarith
  set Ab : ℝ := 300 * (q : ℝ) ^ 2 with hAb
  set E : ℝ := Real.exp 10 * (2 * 2 + 1) ^ 10 with hE
  set Mr : ℝ := ((6 * q : ℕ) : ℝ) with hMr
  set Kc : ℝ := 5 * Mr * (Mr * Ab * 2) * 82944 + E * (Mr * Ab * 2) * 2 + Mr * Ab * 2 * E with hKc
  have hKc0 : 0 ≤ Kc := by positivity
  obtain ⟨Λ₁, hΛ₁, hτ⟩ := sdecay4 2 (u0 δ / 8) 3000 (by positivity) (by norm_num)
  obtain ⟨Λ₂, hΛ₂, hε⟩ := edecay4 3001 (by norm_num)
  obtain ⟨L₀, hL₀, h4⟩ := GoldC.QuillonAsymp.four_pow_card_le (u0 δ / 8 / 2) (by positivity)
  obtain ⟨Λ₃, hΛ₃, hsl⟩ := s_large4 (max (Real.exp L₀) (2 ^ (16 / u0 δ)))
  obtain ⟨Λ₄, hΛ₄, hAω⟩ := Aω_le 5 (1 / 2) (by norm_num) (by norm_num)
  obtain ⟨Λ₅, hΛ₅, hK⟩ := const_le_rpow (Kc + Mr + 6 * q + 6 + 200000) 1 one_pos
  refine ⟨max 2 (max Λ₁ (max Λ₂ (max Λ₃ (max Λ₄ (max Λ₅ (1 + Real.log (6 * q))))))), le_max_left _ _, ?_⟩
  intro h H hΛ hHh s M _ _ C U' JP hC hsC hM hlog hU' A c hA hc Ec a b hEc ha hab hb2 hbH
  set Λ := Real.log h with hΛdef
  have hge : ∀ x, x ≤ max 2 (max Λ₁ (max Λ₂ (max Λ₃ (max Λ₄ (max Λ₅ (1 + Real.log (6 * q))))))) → x ≤ Λ :=
    fun x hx => le_trans hx hΛ
  have hΛ2 : 2 ≤ Λ := hge _ (le_max_left _ _)
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  have L1 := hge Λ₁ (by simp)
  have L2 := hge Λ₂ (by simp)
  have L3 := hge Λ₃ (by simp)
  have L4 := hge Λ₄ (by simp)
  have L5 := hge Λ₅ (by simp)
  have L6 := hge (1 + Real.log (6 * q)) (by simp)
  clear hge hΛ
  have hKΛ := hK Λ L5
  rw [Real.rpow_one] at hKΛ
  have hΛbig : 200000 ≤ Λ := by
    have : (0 : ℝ) ≤ Mr + 6 * q + 6 := by positivity
    linarith
  have hKcΛ : Kc ≤ Λ := by
    have : (0 : ℝ) ≤ Mr + 6 * q + 6 + 200000 := by positivity
    linarith
  have hMΛ : Mr ≤ Λ := by
    have : (0 : ℝ) ≤ 6 * q + 6 + 200000 := by positivity
    linarith
  have hh1n : 1 ≤ h := by
    rcases Nat.eq_zero_or_pos h with h0 | h0
    · exfalso
      have : Real.log (h : ℝ) = 0 := by rw [h0]; simp
      linarith
    · exact h0
  have hh0 : (0 : ℝ) < h := by exact_mod_cast hh1n
  have hspos : 0 < s := by rw [hsC]; exact prod_pos fun p hp => (hC p hp).pos
  have hs0 : (0 : ℝ) < s := by exact_mod_cast hspos
  have hsbig := hsl Λ L3 s hs0 hlog
  have hsL₀ : L₀ ≤ Real.log s := by
    rw [← Real.log_exp L₀]; exact Real.log_le_log (Real.exp_pos _) (le_trans (le_max_left _ _) hsbig)
  have hτΛ := hτ Λ L1 s hs0 hlog
  obtain ⟨hs65, hs1, hsu2, hsΛ⟩ := s_facts Λ s (u0 δ) (u0 δ / 8) hΛ2 hu0 hu1 (by linarith)
    (le_trans (le_max_right _ _) hsbig) hτΛ
  have h4n : (4 : ℝ) ^ C.card ≤ (s : ℝ) ^ (u0 δ / 8 / 2) := by
    have := h4 C hC (by rw [← hsC]; exact hsL₀); rwa [← hsC] at this
  -- `a`, `b`
  have hε0 : 0 ≤ εp h := by unfold εp; positivity
  have hs1e : (s : ℝ) ≤ (s : ℝ) ^ (1 + εp h) := by
    calc (s : ℝ) = (s : ℝ) ^ (1 : ℝ) := (Real.rpow_one _).symm
      _ ≤ (s : ℝ) ^ (1 + εp h) := Real.rpow_le_rpow_of_exponent_le hs1 (by linarith)
  have habR : (a : ℝ) ≤ b := by exact_mod_cast hab.le
  have haR : (s : ℝ) / 2 ≤ a := le_trans (by linarith) ha
  have hbR : (s : ℝ) / 2 ≤ b := le_trans haR habR
  have hb1 : 1 ≤ b := by
    have : (1 : ℝ) ≤ b := by linarith
    exact_mod_cast this
  have hb0 : (0 : ℝ) < b := by linarith
  have hbh : Real.log b ≤ 2 * Λ := by
    have h1 : (b : ℝ) ≤ (h : ℝ) ^ 2 := by
      have : b ≤ h ^ 2 := le_trans hbH (Nat.pow_le_pow_left hHh 2)
      exact_mod_cast this
    have := Real.log_le_log hb0 h1
    rwa [Real.log_pow, Nat.cast_ofNat] at this
  have hlb : (Nat.log 2 b : ℝ) + 1 ≤ 5 * Λ := by
    have := natlog_le_of b (2 * Λ) hbh
    rw [max_eq_left (show (0 : ℝ) ≤ 2 * Λ by linarith)] at this
    linarith
  have hsb : (s : ℝ) / b ≤ Λ ^ (-(3000 : ℝ)) :=
    sb_fact Λ s b (εp h) hΛ2 hs0 hb0 (hε Λ L2 s hs0 hlog) (le_trans ha habR)
  -- `X`, `Y`, `Tp`, `Tv`, `Uv`
  have hXge := Xp_ge (h := h) hΛ1
  have hXle := Xp_le (h := h) hΛ1
  have hX1 : 1 ≤ Xp h := by
    have : (1 : ℝ) ≤ Xp h := le_trans (Real.one_le_rpow hΛ1 (by norm_num)) hXge
    exact_mod_cast this
  obtain ⟨hTp1, hTp2⟩ := Tpp_bounds (h := h) hΛ1
  obtain ⟨hTv1, hTv2⟩ := Tvp_bounds (h := h) hΛ1
  have hYge := inv_Yp_le hδ0 hδ1 hsu2
  have hY1 : 1 ≤ Yp δ s := by
    have : (1 : ℝ) ≤ Yp δ s := by linarith
    exact_mod_cast this
  obtain ⟨hY2, hY12, hsY⟩ := Y_facts Λ s (u0 δ) (u0 δ / 8) (Yp δ s) C.card hΛbig hu0 (by linarith)
    (by linarith) hs1 hYge hsu2 hτΛ h4n (by positivity)
  have haX := aX_fact Λ s a (Xp h) hΛbig hX1 hXle haR hsΛ
  have ha6 : 6 ≤ a / Xp h := by
    have h6 : (6 * q + 6 : ℝ) ≤ (s : ℝ) / (8 * Λ ^ (200 : ℝ)) := by
      rw [le_div_iff₀ (by positivity)]
      have e3 : Λ ^ (3000 : ℝ) = Λ ^ (1 : ℝ) * Λ ^ (200 : ℝ) * Λ ^ (2799 : ℝ) := by
        rw [rp hΛ0, rp hΛ0]; norm_num
      have hb8 : (8 : ℝ) ≤ Λ ^ (2799 : ℝ) := le_trans (by linarith) (le_rpow_big Λ hΛ1 2799 (by norm_num))
      have hq6 : (6 * q + 6 : ℝ) ≤ Λ := by
        have : (0 : ℝ) ≤ Kc + Mr + 200000 := by positivity
        linarith
      rw [e3, Real.rpow_one] at hsΛ
      have hp : 0 < Λ ^ (200 : ℝ) := by positivity
      calc (6 * q + 6 : ℝ) * (8 * Λ ^ (200 : ℝ)) ≤ Λ * (8 * Λ ^ (200 : ℝ)) :=
            mul_le_mul_of_nonneg_right hq6 (by positivity)
        _ ≤ Λ * (Λ ^ (2799 : ℝ) * Λ ^ (200 : ℝ)) :=
            mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right hb8 hp.le) hΛ0.le
        _ = Λ * Λ ^ (200 : ℝ) * Λ ^ (2799 : ℝ) := by ring
        _ ≤ s := hsΛ
    have : (6 : ℝ) ≤ ((a / Xp h : ℕ) : ℝ) := by
      have : (0 : ℝ) ≤ q := by positivity
      linarith
    exact_mod_cast this
  obtain ⟨hUv2, hUvb⟩ := Uv_b_facts s b hs65 hbR
  have hXYb := XY_fact Λ s (Xp h) (Yp δ s) b (u0 δ) hΛbig hu1 hs65 hsΛ hXle (Yp_le δ s) hbR
  -- weights
  have hAωb : (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30) ^ 2 ≤ Λ := by
    have h1 := hAω Λ L4 b (by linarith)
    have h0 : 0 ≤ Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30 := by positivity
    calc _ ≤ (Λ ^ (1 / 2 : ℝ)) ^ 2 := pow_le_pow_left₀ h0 h1 2
      _ = Λ := by rw [← Real.rpow_natCast, ← Real.rpow_mul hΛ0.le]; norm_num
  have hU'5 : ∀ p ∈ U', 5 ≤ p := fun p hp => (hU' p hp).2.1
  have hlogh2 : Real.log ((h ^ 2 : ℕ) : ℝ) ≤ 2 * Λ := by
    push_cast; rw [Real.log_pow]; push_cast; exact le_rfl
  have hWU : ∏ p ∈ U', (1 + 1 / ((p : ℝ) - 3)) ≤ E * Λ ^ (10 : ℝ) :=
    prodU_le_pow U' (fun p hp => ⟨(hU' p hp).1, (hU' p hp).2.1⟩) (h ^ 2)
      (fun p hp => le_trans (hU' p hp).2.2 (Nat.pow_le_pow_left hHh 2)) 2 Λ (by norm_num) hΛ1 hlogh2
  have hSm : ∑ B' ∈ (U'.filter (fun p => p < Xp h)).powerset, ωR B' ≤ E * Λ ^ (10 : ℝ) := by
    rw [sum_ωR_powerset]
    exact prodU_le_pow _ (fun p hp => ⟨(hU' p (filter_subset _ _ hp)).1, (hU' p (filter_subset _ _ hp)).2.1⟩)
      (h ^ 2) (fun p hp => le_trans (hU' p (filter_subset _ _ hp)).2.2 (Nat.pow_le_pow_left hHh 2)) 2 Λ
      (by norm_num) hΛ1 hlogh2
  have hJm : 1 + Real.log ((6 * q * h : ℕ) : ℝ) ≤ 2 * Λ := by
    push_cast
    rw [Real.log_mul (by positivity) hh0.ne']
    linarith
  have hK1 : (((Nat.log 2 (b / (Xp h * Yp δ s)) + 1 : ℕ)) : ℝ) ≤ 5 * Λ := by
    have h1 : Nat.log 2 (b / (Xp h * Yp δ s)) ≤ Nat.log 2 b := Nat.log_mono_right (Nat.div_le_self _ _)
    have : (Nat.log 2 (b / (Xp h * Yp δ s)) : ℝ) ≤ Nat.log 2 b := by exact_mod_cast h1
    push_cast; linarith
  subst hM
  have hM1 : 1 ≤ 6 * q := by omega
  have hMΛ' : ((6 * q : ℕ) : ℝ) ≤ Λ := hMΛ
  have hCT := GoldC.QuillonCEst.CTerm_le (s := s) (M := 6 * q) C hC hsC (6 * q * h) A c Ab (by positivity)
    hA hc U' JP hU'5 (Xp h) (Yp δ s) (Tpp h) (Uvp s) (Uvp s) (Tvp h) Ec a a b hX1 hY1
    (by have : (1 : ℝ) ≤ Tpp h := le_trans (Real.one_le_rpow hΛ1 (by norm_num)) hTp1
        exact_mod_cast this)
    (by omega) le_rfl hb2 hab.le ha6 hUv2 (by omega)
    (by have : (1 : ℝ) ≤ Tvp h := le_trans (Real.one_le_rpow hΛ1 (by norm_num)) hTv1
        exact_mod_cast this)
    hUvb hXYb
  refine le_trans hCT ?_
  have hPα := Pα_le Λ hΛ2 s (Xp h) (Yp δ s) (Tpp h) b _ (by positivity) hAωb hb1 hbh hlb hTp1 hTp2 hXge
    (le_trans hsb (Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num))) hY2
  have hPβ := Pβ_le Λ hΛ2 s (Yp δ s) (Tpp h) b C.card _ (by positivity) hAωb hb1 hbh hlb hTp2 hsY
  have hVα := Vα_le Λ hΛ2 (by linarith) s (Xp h) a b (Uvp s) (Tvp h) Ec (6 * q) (u0 δ / 8) (by linarith)
    hs65 hτΛ hsb hX1 hXle hbR hb1 hbh rfl hTv1 hTv2 hEc haX hM1 hMΛ' hlb
  have hVβ := Vβ_le Λ hΛ2 (by linarith) s (Xp h) b (Uvp s) (Tvp h) (6 * q) C.card (u0 δ / 8)
    (by positivity) (by linarith) hs65 hτΛ h4n hX1 hXle hbR hb1 hbh rfl hTv2 hM1 hMΛ' hlb
  have hL3 := (L3b_le Λ hΛ2 b hb1 hbh).1
  have hP0 : 0 ≤ Pα s (Xp h) (Yp δ s) (Tpp h) b
      ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30) ^ 2) +
      Pβ s (Yp δ s) (Tpp h) b ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30) ^ 2) * 2 ^ C.card := by
    unfold Pα Pβ; positivity
  have hV0 : 0 ≤ Vα s (Xp h) a b (Uvp s) (Uvp s) (Tvp h) Ec (6 * q) +
      Vβ s (Xp h) b (Uvp s) (Uvp s) (Tvp h) (6 * q) C.card * 2 ^ C.card := by
    unfold Vα Vβ
    have : 0 ≤ Real.log (b : ℝ) := Real.log_nonneg (by exact_mod_cast hb1)
    have : 0 ≤ Real.log ((Uvp s * Uvp s : ℕ) : ℝ) := Real.log_natCast_nonneg _
    have : 0 ≤ Real.log (s : ℝ) := Real.log_nonneg hs1
    positivity
  have hSm0 : 0 ≤ ∑ B' ∈ (U'.filter (fun p => p < Xp h)).powerset, ωR B' :=
    sum_nonneg fun B' hB' => ωR_nonneg B' fun p hp => hU'5 p (filter_subset _ _ ((mem_powerset.1 hB') hp))
  have hWU0 : 0 ≤ ∏ p ∈ U', (1 + 1 / ((p : ℝ) - 3)) := prod_nonneg fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast hU'5 p hp
    have : 0 ≤ 1 / ((p : ℝ) - 3) := div_nonneg zero_le_one (by linarith)
    linarith
  have hPsum : Pα s (Xp h) (Yp δ s) (Tpp h) b
      ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30) ^ 2) +
      Pβ s (Yp δ s) (Tpp h) b ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30) ^ 2) * 2 ^ C.card ≤
      82944 * Λ ^ (-(45 : ℝ)) := by
    have := add_le_add hPα hPβ; linarith
  have hVsum := add_le_add hVα hVβ
  exact C_combine Λ _ _ Ab _ _ _ _ _ _ E hΛ2 (by positivity) (by positivity) (by positivity) hK1
    (by have := Real.log_natCast_nonneg (6 * q * h); linarith) hJm hP0 hPsum hV0 (by linarith)
    hSm0 hSm hWU0 hWU (by positivity) hY12 (by positivity) (by rw [Real.rpow_one]; exact hKcΛ)

/-- `Lw^{−σ_R} ≤ Λ^{−100}` for `Lw ≥ √s`, `log s ≥ 5Λ^σ`. -/
theorem rankin_Lw_ev4 :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ h : ℕ, Λ₀ ≤ Real.log h → ∀ (s Lw : ℝ), 1 ≤ s →
      4 * (Real.log h) ^ σ₀ ≤ Real.log s → Real.sqrt s ≤ Lw →
      Lw ^ (-(σRk h)) ≤ (Real.log h) ^ (-(100 : ℝ)) := by
  have hτ : 0 < σ₀ - 1 / 10 := by unfold σ₀; norm_num
  obtain ⟨Λ₀, hΛ₀, hd⟩ := decay 0 100 2 (σ₀ - 1 / 10) (by norm_num) (by norm_num) hτ
  refine ⟨max 2 Λ₀, le_max_left _ _, fun h hΛ s Lw hs1 hlog hLw => ?_⟩
  set Λ := Real.log h
  have hΛ2 : 2 ≤ Λ := le_trans (le_max_left _ _) hΛ
  have hΛ0 : 0 < Λ := by linarith
  have h1 := hd Λ (le_trans (le_max_right _ _) hΛ)
  rw [Real.rpow_zero, one_mul] at h1
  have hsq0 : 0 < Real.sqrt s := Real.sqrt_pos.2 (by linarith)
  have hLw0 : 0 < Lw := lt_of_lt_of_le hsq0 hLw
  have hlogLw : Real.log s / 2 ≤ Real.log Lw := by
    have := Real.log_le_log hsq0 hLw
    rw [Real.log_sqrt (by linarith)] at this; exact this
  have hσ0 : 0 ≤ σRk h := by unfold σRk; positivity
  have he : σRk h * (4 * Λ ^ σ₀ / 2) = 2 * Λ ^ (σ₀ - 1 / 10) := by
    unfold σRk
    have : Λ ^ (-(1 / 10 : ℝ)) * Λ ^ σ₀ = Λ ^ (σ₀ - 1 / 10) := by rw [rp hΛ0]; ring_nf
    rw [← this]; ring
  calc Lw ^ (-(σRk h)) = Real.exp (-(σRk h) * Real.log Lw) := by rw [Real.rpow_def_of_pos hLw0]; ring_nf
    _ ≤ Real.exp (-(2 * Λ ^ (σ₀ - 1 / 10))) := by
        apply Real.exp_le_exp.2
        rw [← he]
        have : 4 * Λ ^ σ₀ / 2 ≤ Real.log Lw := by linarith
        nlinarith [mul_le_mul_of_nonneg_left this hσ0]
    _ ≤ Λ ^ (-(100 : ℝ)) := h1

open Classical in
set_option maxHeartbeats 8000000 in
/-- **The region-C cell for a fixed `C` is `≤ Λ^{−30}`**, eventually in `h`, uniformly. -/
theorem C_final_L (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (a h H D : ℕ) (T C E0 : Finset ℕ) (Kc : ℕ → Prop) [DecidablePred Kc],
      Λ₀ ≤ Real.log h → 2 ≤ h → H ≤ h →
      (∀ p ∈ T, p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q ∧ p.Coprime H ∧ p ≤ H ^ 2) →
      (∀ p, p.Prime → 5 ≤ p → p ≤ H ^ 2 → p ∉ T → p ∈ E0) →
      ((E0.card + C.card : ℕ) : ℝ) ≤ (Real.log h) ^ 2 → C ⊆ T →
      |∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
          (if (Kc B.card ∧ GeoLL h H δ (∏ p ∈ B, p) (∏ p ∈ C, p)) ∧
              ¬ (B ∩ (T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ Yp δ (∏ p ∈ C, p))).Nonempty
            then ωR B * GoldC.QuillonCopyF.foldRow q a D H (∏ p ∈ B, p) (∏ p ∈ C, p) else 0)| ≤
        (Real.log h) ^ (-(30 : ℝ)) := by
  have ha0 := a0_pos hδ0 hδ1
  have ha0' := a0_le hδ0
  have hu0 : 0 < u0 δ := by unfold u0; linarith
  have hu1 : u0 δ ≤ 1 / 8 := by unfold u0; linarith
  set E : ℝ := Real.exp 10 * (2 * 2 + 1) ^ 10 with hE
  set Fm : ℝ := 4 + 48 * q with hFm
  obtain ⟨Λ₁, hΛ₁, hCT⟩ := CTerm_ev4 q hq δ hδ0 hδ1
  obtain ⟨Λ₂, hΛ₂, hτ⟩ := sdecay4 2 (u0 δ / 8) 3000 (by positivity) (by norm_num)
  obtain ⟨Λ₃, hΛ₃, hsl⟩ := s_large4 (2 ^ (16 / u0 δ))
  obtain ⟨Λ₄, hΛ₄, hrσ⟩ := rankin_σ_ev
  obtain ⟨Λ₅, hΛ₅, hrL⟩ := rankin_Lw_ev4
  obtain ⟨Λ₆, hΛ₆, hK⟩ := const_le_rpow (20 + Fm * E ^ 3 + 6 * q + 7 + 200000) 1 one_pos
  obtain ⟨Λ₇, hΛ₇, hεδ'⟩ := εp_le_ev δ hδ0
  refine ⟨max Λ₁ (max Λ₂ (max Λ₃ (max Λ₄ (max Λ₅ (max Λ₆ Λ₇))))), le_trans hΛ₁ (le_max_left _ _), ?_⟩
  intro a h H D T C E0 Kc _ hΛ hh hHh hT hE0 hEc hCT'
  have L1 : Λ₁ ≤ Real.log h := le_trans (by simp) hΛ
  have L2 : Λ₂ ≤ Real.log h := le_trans (by simp) hΛ
  have L3 : Λ₃ ≤ Real.log h := le_trans (by simp) hΛ
  have L4 : Λ₄ ≤ Real.log h := le_trans (by simp) hΛ
  have L5 : Λ₅ ≤ Real.log h := le_trans (by simp) hΛ
  have L6 : Λ₆ ≤ Real.log h := le_trans (by simp) hΛ
  have L7 : Λ₇ ≤ Real.log h := le_trans (by simp) hΛ
  have hεδ : εp h ≤ δ := hεδ' h L7
  clear hΛ
  set Λ := Real.log h with hΛdef
  have hΛ2 : 2 ≤ Λ := le_trans hΛ₁ L1
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  have hKΛ := hK Λ L6
  rw [Real.rpow_one] at hKΛ
  have hFm0 : 0 ≤ Fm := by positivity
  have hE0' : 0 ≤ E := by positivity
  have hΛbig : 200000 ≤ Λ := by
    have : 0 ≤ 20 + Fm * E ^ 3 + 6 * q + 7 := by positivity
    linarith
  have hq7 : (6 * q + 7 : ℝ) ≤ Λ := by
    have : 0 ≤ 20 + Fm * E ^ 3 + 200000 := by positivity
    linarith
  have hKfin : 20 + Fm * E ^ 3 ≤ Λ := by
    have : (0 : ℝ) ≤ 6 * q + 7 + 200000 := by positivity
    linarith
  set s := ∏ p ∈ C, p with hs
  have hpos30 : 0 ≤ Λ ^ (-(30 : ℝ)) := by positivity
  by_cases hex : ∃ r, GeoLL h H δ r s
  swap
  · push_neg at hex
    rw [sum_eq_zero fun B _ => by
      rw [if_neg]; rintro ⟨⟨-, hg⟩, -⟩; exact hex _ hg, abs_zero]
    exact hpos30
  obtain ⟨r₀, hr₀⟩ := hex
  obtain ⟨hlogs, -, hr1, hs1n, -, hsh, -, -, hrsH⟩ := admLL h H r₀ s δ hδ0 hh hHh hr₀
  have hCp : ∀ p ∈ C, p.Prime := fun p hp => (hT p (hCT' hp)).1
  have hspos : 0 < s := prod_pos fun p hp => (hCp p hp).pos
  have hs0 : (0 : ℝ) < s := by exact_mod_cast hspos
  have hτΛ := hτ Λ L2 s hs0 hlogs
  obtain ⟨hs65, hs1, hsu2, hsΛ⟩ := s_facts Λ s (u0 δ) (u0 δ / 8) hΛ2 hu0 hu1 (by linarith)
    (hsl Λ L3 s hs0 hlogs) hτΛ
  have hs2 : 2 ≤ s := by
    have : (2 : ℝ) ≤ s := by linarith
    exact_mod_cast this
  haveI : NeZero s := ⟨by omega⟩
  haveI : NeZero (6 * q) := ⟨by omega⟩
  -- `s ≤ H`
  have hsH : (s : ℝ) ≤ H := by
    have hE1 : 1 ≤ Real.exp (Λ ^ (1 / 4 : ℝ)) := Real.one_le_exp (by positivity)
    have hr1R : (1 : ℝ) ≤ r₀ := by exact_mod_cast hr1
    calc (s : ℝ) ≤ ((r₀ : ℝ) * s) * Real.exp (Λ ^ (1 / 4 : ℝ)) := by
          have : (s : ℝ) ≤ (r₀ : ℝ) * s := le_mul_of_one_le_left hs0.le hr1R
          exact le_trans this (le_mul_of_one_le_right (by positivity) hE1)
      _ ≤ H := hrsH
  have hH1 : (1 : ℝ) ≤ H := by linarith
  -- `Lw`
  obtain ⟨hLwlo, hLwhi, hLwsq⟩ := LwC_facts h s hΛ1 (by linarith)
  have hLwH : LwC h s ≤ H ^ 2 := by
    have : (LwC h s : ℝ) ≤ (H : ℝ) ^ 2 := le_trans hLwhi (pow_le_pow_left₀ hs0.le hsH 2)
    exact_mod_cast this
  have hmax : max (H ^ 2) (LwC h s) = H ^ 2 := max_eq_left hLwH
  -- `X`, `Y`
  have hXge := Xp_ge (h := h) hΛ1
  have hXle := Xp_le (h := h) hΛ1
  have hX2 : 2 ≤ Xp h := Xp_two hΛ2
  have hX1 : 1 ≤ Xp h := by omega
  have hY4 : 4 ≤ Yp δ s := by
    unfold Yp; apply Nat.le_floor; push_cast
    have h16 : (2 : ℝ) ^ (16 / u0 δ) ≤ s := hsl Λ L3 s hs0 hlogs
    calc (4 : ℝ) ≤ 2 ^ (16 : ℝ) := by norm_num
      _ = ((2 : ℝ) ^ (16 / u0 δ)) ^ u0 δ := by
          rw [← Real.rpow_mul (by norm_num), div_mul_cancel₀ _ hu0.ne']
      _ ≤ (s : ℝ) ^ u0 δ := Real.rpow_le_rpow (by positivity) h16 hu0.le
  have hYs : (Yp δ s : ℝ) ≤ (s : ℝ) ^ (1 / 8 : ℝ) :=
    le_trans (Yp_le δ s) (Real.rpow_le_rpow_of_exponent_le hs1 hu1)
  -- `Lw/X`
  have hLwX := aX_fact Λ s (LwC h s) (Xp h) hΛbig hX1 hXle (by
    have : (s : ℝ) ≤ (s : ℝ) ^ (1 + εp h) := by
      calc (s : ℝ) = (s : ℝ) ^ (1 : ℝ) := (Real.rpow_one _).symm
        _ ≤ _ := Real.rpow_le_rpow_of_exponent_le hs1 (by linarith [(εp_le_one hΛ1).1])
    linarith) hsΛ
  obtain ⟨hd1, hd2⟩ := div8_facts Λ s q hΛbig hq7 hsΛ
  have hUvs : (Uvp s : ℝ) ≤ (s : ℝ) ^ (1 / 8 : ℝ) := by
    have : (Uvp s : ℝ) ≤ (s : ℝ) ^ (1 / 16 : ℝ) := Nat.floor_le (by positivity)
    exact le_trans this (Real.rpow_le_rpow_of_exponent_le hs1 (by norm_num))
  have hLwM : 6 * q < LwC h s / Xp h := by
    have : (6 * q : ℝ) < ((LwC h s / Xp h : ℕ) : ℝ) := by linarith
    exact_mod_cast this
  have hLw6 : 6 ≤ LwC h s / Xp h := by
    have : (6 : ℝ) ≤ ((LwC h s / Xp h : ℕ) : ℝ) := by
      have : (0 : ℝ) ≤ q := by positivity
      linarith
    exact_mod_cast this
  have hLwV : Uvp s ≤ LwC h s / Xp h := by
    have : (Uvp s : ℝ) ≤ ((LwC h s / Xp h : ℕ) : ℝ) := by linarith
    exact_mod_cast this
  have hLwY : Yp δ s ≤ LwC h s / Xp h := by
    have : (Yp δ s : ℝ) ≤ ((LwC h s / Xp h : ℕ) : ℝ) := by linarith
    exact_mod_cast this
  -- source data
  have hTc : ∀ p ∈ T, p.Prime ∧ 5 ≤ p ∧ p.Coprime (6 * q) ∧ p.Coprime H := fun p hp =>
    ⟨(hT p hp).1, (hT p hp).2.1, GoldC.QuillonWFinal.coprime_6q (hT p hp).1 (hT p hp).2.1 (hT p hp).2.2.1,
      (hT p hp).2.2.2.1⟩
  have hsM : s.Coprime (6 * q) :=
    GoldC.QuillonWFinal.prod_coprime_of fun p hp => (hTc p (hCT' hp)).2.2.1
  set μ := GoldC.QuillonCopyF.meanWeight q (GoldC.QuillonCopyF.reducedAnchor q a D) H with hμ
  set Γ := GoldC.QuillonCopyF.gammaClass q a D H with hΓ
  have hμb : |μ| ≤ 4 := by
    have := GoldC.QuillonCopyF.meanWeight_bounds q (GoldC.QuillonCopyF.reducedAnchor q a D) H
    rw [abs_le]; constructor <;> linarith
  have hΓb : ∀ b ν, |Γ b ν| ≤ 48 * q := fun b ν => by
    have := GoldC.QuillonCopyF.abs_gammaClass_le q a D H b ν hq
    have e : (8 : ℝ) * (6 * q) = 48 * q := by ring
    linarith
  have hshn : s ≤ h := by exact_mod_cast hsh
  have hU' : ∀ p ∈ (T \ C).filter (fun p => ¬ (Xp h ≤ p ∧ p ≤ Yp δ s)), p.Prime ∧ 5 ≤ p ∧ p ≤ H ^ 2 :=
    fun p hp => have hpT := sdiff_subset (filter_subset _ _ hp)
      ⟨(hT p hpT).1, (hT p hpT).2.1, (hT p hpT).2.2.2.2⟩
  have hCH : ∀ p ∈ C, p.Prime ∧ p.Coprime H := fun p hp => ⟨hCp p hp, (hT p (hCT' hp)).2.2.2.1⟩
  have hs1' : 1 ≤ s := by omega
  have hEc' : ((E0.card + C.card : ℕ) : ℝ) ≤ Λ ^ 2 := hEc
  -- the cell
  have hcell := GoldC.QuillonCCellApp.C_cell (s := s) (M := 6 * q) (by omega) H μ Γ T C hTc hCT' rfl hs2
    (Xp h) (Yp δ s) hX2 (by omega) Kc (fun r => GeoLL h H δ r s)
    (H ^ 2) (LwC h s)
    (fun r hG => by
      have h4 := hG.2.1
      have : r ≤ r * s := Nat.le_mul_of_pos_right r hspos
      omega)
    (fun r hG => by
      have hr1 : 1 ≤ r := by
        have := hG.1
        rcases Nat.eq_zero_or_pos r with h0 | h0
        · rw [h0] at this; simp at this
        · exact h0
      exact LwC_lt (H := H) (δ := δ) hr1 (LL_eps hεδ hG))
    (geoLL_convex_r h H δ s)
    (fun r => GoldC.QuillonCopyF.foldRow q a D H r s)
    (fun B hB hne _ => by
      have hBp : ∀ p ∈ B, p.Prime ∧ 5 ≤ p := fun p hp =>
        ⟨(hT p (sdiff_subset (hB hp))).1, (hT p (sdiff_subset (hB hp))).2.1⟩
      obtain ⟨p, hp⟩ := nonempty_iff_ne_empty.2 hne
      have hr2 : 2 ≤ ∏ p ∈ B, p := by
        have h1 : p ∣ ∏ p ∈ B, p := dvd_prod_of_mem _ hp
        have h2 : 0 < ∏ p ∈ B, p := prod_pos fun p hp => (hBp p hp).1.pos
        have := Nat.le_of_dvd h2 h1
        have := (hBp p hp).2; omega
      exact GoldC.QuillonBridge.foldRow_eq_rowAbs q a D H _ s hq hr2 hs2
        (GoldC.QuillonWFinal.prod_coprime_of fun p hp => (hTc p (sdiff_subset (hB hp))).2.2.1) hsM)
    Fm hFm0 (fun B _ _ => GoldC.QuillonBridge.abs_foldRow_le q a D H _ s hq)
    (6 * q * h) (by nlinarith) (Tpp h) (Uvp s) (Uvp s) (Tvp h)
    (by have : (2 : ℝ) ≤ Tpp h := le_trans (le_trans hΛ2 (le_rpow_big Λ hΛ1 100 (by norm_num)))
          (Tpp_bounds hΛ1).1
        exact_mod_cast this)
    (Uv_b_facts s s hs65 (by linarith)).1
    (by have : (2 : ℝ) ≤ Tvp h := le_trans (le_trans hΛ2 (le_rpow_big Λ hΛ1 600 (by norm_num)))
          (Tvp_bounds hΛ1).1
        exact_mod_cast this)
    (E0 ∪ C) (E0.card + C.card) (card_union_le _ _)
    (fun p hp hYp hpN hpT => by
      rw [hmax] at hpN
      have hp5 : 5 ≤ p := by omega
      by_cases hpC : p ∈ C
      · exact mem_union_right _ hpC
      · apply mem_union_left
        apply hE0 p hp hp5 hpN
        intro hpT'
        exact hpT (mem_filter.2 ⟨mem_sdiff.2 ⟨hpT', hpC⟩, hYp⟩))
    hLwM hLw6 hLwV hLwY (σRk h) (by unfold σRk; positivity) (4 * Λ ^ (-(40 : ℝ))) (by positivity)
    (fun a' b' ha' hab' hb2' hbN => by
      rw [hmax] at hbN
      unfold GoldC.QuillonCCellApp.CSum4
      have ha'' : (s : ℝ) ^ (1 + εp h) / 2 ≤ a' := le_trans hLwlo (by exact_mod_cast ha')
      have c1 := hCT h H L1 hHh s (6 * q) C _ ((T \ C).filter (fun p => Yp δ s < p)) hCp rfl rfl hlogs hU'
        (fun (_ : ZMod (6 * q)) k => ((-(2 * μ) : ℝ) : ℂ) * GoldC.QuillonRowNF.αm k s)
        (fun k => ((((k : ℤ) * H : ℤ)) : ZMod s))
        (fun ρ j hj => GoldC.QuillonRowFacts.coef_main q hq μ hμb s hs1' (6 * q) ρ j hj)
        (GoldC.QuillonRowFacts.hc_gen C hCp rfl (H : ℤ) (GoldC.QuillonRowFacts.not_dvd_H hCH) 1
          (Or.inl rfl) _ (fun j => by congr 1; ring))
        (E0.card + C.card) a' b' hEc' ha'' hab' hb2' hbN
      have c2 := hCT h H L1 hHh s (6 * q) C _ ((T \ C).filter (fun p => Yp δ s < p)) hCp rfl rfl hlogs hU'
        (fun (_ : ZMod (6 * q)) k => -(((-(2 * μ) : ℝ) : ℂ) * GoldC.QuillonRowNF.αm k s))
        (fun k => ((((-(k : ℤ)) * H : ℤ)) : ZMod s))
        (fun ρ j hj => GoldC.QuillonRowFacts.coef_mainN q hq μ hμb s hs1' (6 * q) ρ j hj)
        (GoldC.QuillonRowFacts.hc_gen C hCp rfl (H : ℤ) (GoldC.QuillonRowFacts.not_dvd_H hCH) (-1)
          (Or.inr rfl) _ (fun j => by congr 1; ring))
        (E0.card + C.card) a' b' hEc' ha'' hab' hb2' hbN
      have c3 := hCT h H L1 hHh s (6 * q) C _ ((T \ C).filter (fun p => Yp δ s < p)) hCp rfl rfl hlogs hU'
        (fun (ρ : ZMod (6 * q)) k => GoldC.QuillonRowNF.αm k ((6 * q) * s) *
          GoldC.QuillonRowNF.BclS (6 * q) Γ s (k : ℤ) ρ)
        (fun k => ((((k : ℤ) * H * GoldC.QuillonCopyC.invMod (6 * q) s : ℤ)) : ZMod s))
        (fun ρ j hj => GoldC.QuillonRowFacts.coef_cls q hq Γ hΓb s hs1' (fun k => (k : ℤ)) ρ j hj)
        (GoldC.QuillonRowFacts.hc_gen C hCp rfl _
          (GoldC.QuillonRowFacts.not_dvd_HinvM hCH rfl hs2 hsM.symm) 1 (Or.inl rfl) _
          (fun j => by congr 1; ring))
        (E0.card + C.card) a' b' hEc' ha'' hab' hb2' hbN
      have c4 := hCT h H L1 hHh s (6 * q) C _ ((T \ C).filter (fun p => Yp δ s < p)) hCp rfl rfl hlogs hU'
        (fun (ρ : ZMod (6 * q)) k => -(GoldC.QuillonRowNF.αm k ((6 * q) * s) *
          GoldC.QuillonRowNF.BclS (6 * q) Γ s (-(k : ℤ)) ρ))
        (fun k => ((((-(k : ℤ)) * H * GoldC.QuillonCopyC.invMod (6 * q) s : ℤ)) : ZMod s))
        (fun ρ j hj => GoldC.QuillonRowFacts.coef_clsN q hq Γ hΓb s hs1' (fun k => -(k : ℤ)) ρ j hj)
        (GoldC.QuillonRowFacts.hc_gen C hCp rfl _
          (GoldC.QuillonRowFacts.not_dvd_HinvM hCH rfl hs2 hsM.symm) (-1) (Or.inr rfl) _
          (fun j => by congr 1; ring))
        (E0.card + C.card) a' b' hEc' ha'' hab' hb2' hbN
      linarith)
  refine le_trans hcell ?_
  rw [hmax]
  -- Rankin pieces
  have hσX : ∀ p ∈ (T \ C).filter (fun p => p < Xp h), (p : ℝ) ^ σRk h ≤ 3 := fun p hp =>
    hrσ h L4 p (by have := (hT p (sdiff_subset (filter_subset _ _ hp))).2.1; omega)
      (le_of_lt (mem_filter.1 hp).2)
  have hV5 : ∀ p ∈ (T \ C).filter (fun p => p < Xp h), 5 ≤ p := fun p hp =>
    (hT p (sdiff_subset (filter_subset _ _ hp))).2.1
  have hprod := rankin_prod_le _ hV5 (σRk h) hσX
  have hlogh2 : Real.log ((h ^ 2 : ℕ) : ℝ) ≤ 2 * Λ := by
    push_cast; rw [Real.log_pow]; push_cast; exact le_rfl
  have hprodU : ∏ p ∈ (T \ C).filter (fun p => p < Xp h), (1 + 1 / ((p : ℝ) - 3)) ≤ E * Λ ^ (10 : ℝ) :=
    prodU_le_pow _ (fun p hp => ⟨(hT p (sdiff_subset (filter_subset _ _ hp))).1, hV5 p hp⟩) (h ^ 2)
      (fun p hp => le_trans (hT p (sdiff_subset (filter_subset _ _ hp))).2.2.2.2
        (Nat.pow_le_pow_left hHh 2)) 2 Λ (by norm_num) hΛ1 hlogh2
  have hprodU0 : 0 ≤ ∏ p ∈ (T \ C).filter (fun p => p < Xp h), (1 + 1 / ((p : ℝ) - 3)) :=
    prod_nonneg fun p hp => by
      have : (5 : ℝ) ≤ p := by exact_mod_cast hV5 p hp
      have : 0 ≤ 1 / ((p : ℝ) - 3) := div_nonneg zero_le_one (by linarith)
      linarith
  have hP : ∏ p ∈ (T \ C).filter (fun p => p < Xp h), (1 + (p : ℝ) ^ σRk h / ((p : ℝ) - 3)) ≤
      (E * Λ ^ (10 : ℝ)) ^ 3 := le_trans hprod (pow_le_pow_left₀ hprodU0 hprodU 3)
  have hP0 : 0 ≤ ∏ p ∈ (T \ C).filter (fun p => p < Xp h), (1 + (p : ℝ) ^ σRk h / ((p : ℝ) - 3)) :=
    prod_nonneg fun p hp => by
      have : (5 : ℝ) ≤ p := by exact_mod_cast hV5 p hp
      have : 0 ≤ (p : ℝ) ^ σRk h / ((p : ℝ) - 3) := div_nonneg (by positivity) (by linarith)
      linarith
  have hL := hrL h L5 s (LwC h s) hs1 hlogs hLwsq
  have hK1 : (((Nat.log 2 (H ^ 2) + 1 : ℕ)) : ℝ) ≤ 5 * Λ := by
    have hH2 : Real.log ((H ^ 2 : ℕ) : ℝ) ≤ 2 * Λ := by
      have hHR : (H : ℝ) ≤ h := by exact_mod_cast hHh
      have h0 : (0 : ℝ) < ((H ^ 2 : ℕ) : ℝ) := by push_cast; positivity
      have := Real.log_le_log h0 (show ((H ^ 2 : ℕ) : ℝ) ≤ ((h ^ 2 : ℕ) : ℝ) by
        push_cast; exact pow_le_pow_left₀ (by positivity) hHR 2)
      linarith
    have := natlog_le_of (H ^ 2) (2 * Λ) hH2
    rw [max_eq_left (show (0 : ℝ) ≤ 2 * Λ by linarith)] at this
    push_cast; linarith
  exact Cfin_combine Λ _ _ Fm _ _ E hΛ2 (by positivity) hK1 rfl hFm0 (by positivity) hL hP0 hP hE0' hKfin

end GoldC.QuillonLC

namespace GoldC.QuillonLC

open Classical
open GoldC.QuillonEv GoldC.QuillonSetup GoldC.QuillonLam GoldC.QuillonCEv GoldC.QuillonCFinal
  GoldC.QuillonWContext GoldC.QuillonCPhysical GoldC.QuillonLSetup GoldC.QuillonLW
open GoldC.QuillonCopyS GoldC.QuillonCopyF GoldC.QuillonCopyM GoldC.QuillonWPhysical

/-- The LONG-left region-C part at decoration `d`: `s^{1+δ} < r` and `B` misses `[X, ⌊s^{u₀}⌋]`. -/
noncomputable def CLPart (Jlow Jhigh q a h : ℕ) (δ : ℝ) (d : Finset ℕ) : ℝ :=
  ∑ B ∈ (Tsrc q h d).powerset, ∑ C ∈ (Tsrc q h d).powerset,
    if B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C ∧
        (MkL Jlow Jhigh h (h / primeSetProduct d) δ B C ∧
          (longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧ ¬ WMask h δ (Tsrc q h d) B C)) then
      omegaWeight B * omegaWeight C *
        foldRow q a (primeSetProduct d) (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct C)
    else 0

set_option maxHeartbeats 4000000 in
/-- **Physical region-C theorem.** For `d ⊆ primeFactors h` (every CORE decoration), the
region-C part of the CORE pair sum is `≤ Λ^{−15}`, eventually in `h`, uniformly in `a`, `d`, `Jlow`, `Jhigh`. -/
theorem CL_physical (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (Jlow Jhigh a h : ℕ) (d : Finset ℕ), Λ₀ ≤ Real.log h → 2 ≤ h →
      d ⊆ h.primeFactors → |CLPart Jlow Jhigh q a h δ d| ≤ (Real.log h) ^ (-(15 : ℝ)) := by
  obtain ⟨Λ₁, hΛ₁, hCf⟩ := C_final_L q hq δ hδ0 hδ1
  set E : ℝ := Real.exp 10 * (2 * 2 + 1) ^ 10 with hE
  obtain ⟨Λ₂, hΛ₂, hKΛ⟩ := const_le_rpow (E + 2 * q + 10) 1 one_pos
  refine ⟨max Λ₁ Λ₂, le_trans hΛ₁ (le_max_left _ _), ?_⟩
  intro Jlow Jhigh a h d hΛ hh hd
  have hΛa : Λ₁ ≤ Real.log h := le_trans (le_max_left _ _) hΛ
  have hΛb : Λ₂ ≤ Real.log h := le_trans (le_max_right _ _) hΛ
  set Λ := Real.log h with hΛdef
  have hΛ2 : 2 ≤ Λ := le_trans hΛ₁ hΛa
  have hΛ0 : 0 < Λ := by linarith
  have hK := hKΛ Λ hΛb
  rw [Real.rpow_one] at hK
  have hE0' : 0 ≤ E := by positivity
  set H := h / primeSetProduct d with hH
  set T := Tsrc q h d with hT
  have hTf := Tsrc_facts q h d
  have hHh : H ≤ h := Nat.div_le_self _ _
  have hh0' : h ≠ 0 := by omega
  -- the exceptional set
  set E0 := q.primeFactors ∪ H.primeFactors ∪ d with hE0
  have hE0c : (E0.card : ℝ) ≤ 2 * q + 2 * Λ + 2 * Λ := by
    have h1 : E0.card ≤ q.primeFactors.card + H.primeFactors.card + d.card :=
      le_trans (card_union_le _ _) (Nat.add_le_add_right (card_union_le _ _) _)
    have h1R : (E0.card : ℝ) ≤ q.primeFactors.card + H.primeFactors.card + d.card := by exact_mod_cast h1
    have hq1 : (q.primeFactors.card : ℝ) ≤ 2 * q := by
      have := card_primeFactors_le q hq.ne' _ subset_rfl
      have hl : Real.log q ≤ q := le_trans (Real.log_le_sub_one_of_pos (by exact_mod_cast hq)) (by linarith)
      linarith
    have hH1 : (H.primeFactors.card : ℝ) ≤ 2 * Λ := by
      rcases Nat.eq_zero_or_pos H with h0 | hpos
      · rw [h0]; simp; linarith
      · have := card_primeFactors_le H hpos.ne' _ subset_rfl
        have : Real.log H ≤ Λ := Real.log_le_log (by exact_mod_cast hpos) (by exact_mod_cast hHh)
        linarith
    have hd1 : (d.card : ℝ) ≤ 2 * Λ := card_primeFactors_le h hh0' d hd
    linarith
  have hE0T : ∀ p, p.Prime → 5 ≤ p → p ≤ H ^ 2 → p ∉ T → p ∈ E0 := fun p hp h5 hpH hpT =>
    Tsrc_compl q h hq d p hp h5 hpH hpT
  unfold CLPart
  rw [GoldC.QuillonCells.double_sum_fixC]
  have hinner : ∀ C ∈ T.powerset.filter (fun C => C ≠ ∅),
      |∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
        (if MkL Jlow Jhigh h H δ B C ∧ (longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧
            ¬ WMask h δ T B C) then
          omegaWeight B * omegaWeight C *
            foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0)| ≤
        ωR C * Λ ^ (-(30 : ℝ)) := by
    intro C hC
    have hCT : C ⊆ T := mem_powerset.1 (mem_filter.1 hC).1
    have hω0 : 0 ≤ ωR C := ωR_nonneg C fun p hp => (hTf p (hCT hp)).2.1
    have e : ∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
        (if MkL Jlow Jhigh h H δ B C ∧ (longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧
            ¬ WMask h δ T B C) then
          omegaWeight B * omegaWeight C *
            foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0) =
        ωR C * ∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
          (if ((Jlow ≤ B.card + C.card ∧ B.card + C.card < Jhigh) ∧
              GeoLL h H δ (∏ p ∈ B, p) (∏ p ∈ C, p)) ∧
              ¬ (B ∩ (T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ Yp δ (∏ p ∈ C, p))).Nonempty
            then ωR B * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p) else 0) := by
      rw [mul_sum]
      refine sum_congr rfl fun B _ => ?_
      have hiff : (MkL Jlow Jhigh h H δ B C ∧ (longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧
            ¬ WMask h δ T B C)) ↔
          (((Jlow ≤ B.card + C.card ∧ B.card + C.card < Jhigh) ∧
              GeoLL h H δ (∏ p ∈ B, p) (∏ p ∈ C, p)) ∧
              ¬ (B ∩ (T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ Yp δ (∏ p ∈ C, p))).Nonempty) := by
        constructor
        · rintro ⟨⟨h1, h2, h3, h4, -, h6⟩, hL, hw⟩; exact ⟨⟨⟨h3, h4⟩, ⟨h1, h2, hL, h6⟩⟩, hw⟩
        · rintro ⟨⟨⟨h3, h4⟩, ⟨h1, h2, hL, h6⟩⟩, hw⟩; exact ⟨⟨h1, h2, h3, h4, Or.inl hL, h6⟩, hL, hw⟩
      split_ifs with h1 h2 h2
      · show ωR B * ωR C * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p) =
          ωR C * (ωR B * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p))
        ring
      · exact absurd (hiff.1 h1) h2
      · exact absurd (hiff.2 h2) h1
      · rw [mul_zero]
    rw [e, abs_mul, abs_of_nonneg hω0]
    refine mul_le_mul_of_nonneg_left ?_ hω0
    -- case split on the size of `s`
    by_cases hsh : ((∏ p ∈ C, p : ℕ) : ℝ) ≤ h
    · have hCc : (C.card : ℝ) ≤ 2 * Λ := by
        have := card_le_of_prod_le C (fun p hp => (hTf p (hCT hp)).1.two_le) h (by exact_mod_cast hsh)
        exact this
      have hEc : ((E0.card + C.card : ℕ) : ℝ) ≤ Λ ^ 2 := by
        push_cast
        have hq' : (2 * q + 10 : ℝ) ≤ Λ := by linarith
        nlinarith
      exact hCf a h H (primeSetProduct d) T C E0 (fun k => Jlow ≤ k + C.card ∧ k + C.card < Jhigh) hΛa hh
        hHh hTf hE0T hEc hCT
    · -- no admissible `B`: every term vanishes
      have hzero : ∀ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
          (if ((Jlow ≤ B.card + C.card ∧ B.card + C.card < Jhigh) ∧
              GeoLL h H δ (∏ p ∈ B, p) (∏ p ∈ C, p)) ∧
              ¬ (B ∩ (T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ Yp δ (∏ p ∈ C, p))).Nonempty
            then ωR B * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p) else 0) = 0 := by
        intro B _
        rw [if_neg]
        rintro ⟨⟨-, hg⟩, -⟩
        exact hsh (admLL h H _ _ δ hδ0 hh hHh hg).2.2.2.2.2.1
      rw [sum_eq_zero hzero, abs_zero]; positivity
  calc _ ≤ ∑ C ∈ T.powerset.filter (fun C => C ≠ ∅),
        |∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
          (if MkL Jlow Jhigh h H δ B C ∧ (longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧
              ¬ WMask h δ T B C) then
            omegaWeight B * omegaWeight C *
              foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0)| :=
        abs_sum_le_sum_abs _ _
    _ ≤ ∑ C ∈ T.powerset.filter (fun C => C ≠ ∅), ωR C * Λ ^ (-(30 : ℝ)) := sum_le_sum hinner
    _ ≤ ∑ C ∈ T.powerset, ωR C * Λ ^ (-(30 : ℝ)) := by
        apply sum_le_sum_of_subset_of_nonneg (filter_subset _ _)
        intro C hC _
        have hCT : C ⊆ T := mem_powerset.1 hC
        have := ωR_nonneg C fun p hp => (hTf p (hCT hp)).2.1
        positivity
    _ = (∑ C ∈ T.powerset, ωR C) * Λ ^ (-(30 : ℝ)) := by rw [sum_mul]
    _ ≤ (E * Λ ^ (10 : ℝ)) * Λ ^ (-(30 : ℝ)) :=
        mul_le_mul_of_nonneg_right (outer_mass q h d (by linarith)) (by positivity)
    _ = E * Λ ^ (-(20 : ℝ)) := by rw [mul_assoc, rp hΛ0]; norm_num
    _ ≤ Λ * Λ ^ (-(20 : ℝ)) := by
        apply mul_le_mul_of_nonneg_right _ (by positivity)
        have : (0 : ℝ) ≤ 2 * q + 10 := by positivity
        linarith
    _ = Λ ^ (-(19 : ℝ)) := by
        rw [show Λ * Λ ^ (-(20 : ℝ)) = Λ ^ (1 : ℝ) * Λ ^ (-(20 : ℝ)) by rw [Real.rpow_one], rp hΛ0]
        norm_num
    _ ≤ Λ ^ (-(15 : ℝ)) := Real.rpow_le_rpow_of_exponent_le (by linarith) (by norm_num)

end GoldC.QuillonLC

#print axioms GoldC.QuillonLC.CTerm_ev4
#print axioms GoldC.QuillonLC.rankin_Lw_ev4
#print axioms GoldC.QuillonLC.C_final_L
#print axioms GoldC.QuillonLC.CL_physical
