import PaperB.FixedQ.ShiuMass
import Mathlib.Analysis.SpecialFunctions.Log.Summable

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def sourceShiuQuarterPrimeMajorant (p : ℕ) : ℝ :=
  5 * (p : ℝ) ^ (-5 / 4 : ℝ)

lemma sourceShiuQuarterPrimeMajorant_nonneg (p : ℕ) :
    0 ≤ sourceShiuQuarterPrimeMajorant p := by
  unfold sourceShiuQuarterPrimeMajorant
  positivity

lemma fixedQShiuPrimeFactor_mul_quarter_le_majorant
    {p : ℕ} (hp5 : 5 ≤ p) :
    fixedQShiuPrimeFactor p * (p : ℝ) ^ (-1 / 4 : ℝ) ≤
      sourceShiuQuarterPrimeMajorant p := by
  unfold fixedQShiuPrimeFactor sourceShiuQuarterPrimeMajorant
  rw [if_pos hp5]
  let x : ℝ := p
  have hx5 : (5 : ℝ) ≤ x := by
    dsimp [x]
    exact_mod_cast hp5
  have hx0 : 0 < x := by linarith
  have hd : 0 < x - 3 := by linarith
  have hid :
      x ^ (-1 / 4 : ℝ) = x * x ^ (-5 / 4 : ℝ) := by
    calc
      x ^ (-1 / 4 : ℝ)
          = x ^ ((1 : ℝ) + (-5 / 4 : ℝ)) := by norm_num
      _ = x ^ (1 : ℝ) * x ^ (-5 / 4 : ℝ) :=
        Real.rpow_add hx0 1 (-5 / 4)
      _ = x * x ^ (-5 / 4 : ℝ) := by rw [Real.rpow_one]
  have hcoef : 2 * x / (x - 3) ≤ 5 := by
    rw [div_le_iff₀ hd]
    nlinarith
  change (2 / (x - 3)) * x ^ (-1 / 4 : ℝ) ≤
    5 * x ^ (-5 / 4 : ℝ)
  rw [hid]
  have hr0 : 0 ≤ x ^ (-5 / 4 : ℝ) := Real.rpow_nonneg hx0.le _
  calc
    (2 / (x - 3)) * (x * x ^ (-5 / 4 : ℝ))
        = (2 * x / (x - 3)) * x ^ (-5 / 4 : ℝ) := by ring
    _ ≤ 5 * x ^ (-5 / 4 : ℝ) :=
      mul_le_mul_of_nonneg_right hcoef hr0

lemma summable_sourceShiuQuarterPrimeMajorant :
    Summable sourceShiuQuarterPrimeMajorant := by
  unfold sourceShiuQuarterPrimeMajorant
  exact (Real.summable_nat_rpow.mpr
    (by norm_num : (-5 / 4 : ℝ) < -1)).mul_left 5

lemma summable_sourceShiuQuarterFinsetProduct :
    Summable (fun s : Finset ℕ =>
      ∏ p ∈ s, sourceShiuQuarterPrimeMajorant p) := by
  exact summable_finsetProd_of_summable_nonneg
    sourceShiuQuarterPrimeMajorant_nonneg
    summable_sourceShiuQuarterPrimeMajorant

lemma source_primeFactors_injective_on_squarefreePositive :
    Function.Injective
      (fun n : {n : ℕ // n ≠ 0 ∧ Squarefree n} => n.1.primeFactors) := by
  intro a b hab
  apply Subtype.ext
  have ha := Nat.prod_primeFactors_of_squarefree a.2.2
  have hb := Nat.prod_primeFactors_of_squarefree b.2.2
  calc
    a.1 = ∏ p ∈ a.1.primeFactors, p := ha.symm
    _ = ∏ p ∈ b.1.primeFactors, p := by
      exact Finset.prod_congr hab (fun _ _ => rfl)
    _ = b.1 := hb

lemma fixedQShiuWeight_mul_quarter_le_finsetMajorant
    (q : ℕ) (n : {n : ℕ // n ≠ 0 ∧ Squarefree n}) :
    fixedQShiuWeight q n.1 * (n.1 : ℝ) ^ (-1 / 4 : ℝ) ≤
      ∏ p ∈ n.1.primeFactors, sourceShiuQuarterPrimeMajorant p := by
  by_cases hcop : n.1.Coprime (6 * q)
  · have hprod := Nat.prod_primeFactors_of_squarefree n.2.2
    have hcast :
        (∏ p ∈ n.1.primeFactors, (p : ℝ)) = (n.1 : ℝ) := by
      have hc := congrArg (fun z : ℕ => (z : ℝ)) hprod
      simpa using hc
    have hrpow :
        (n.1 : ℝ) ^ (-1 / 4 : ℝ) =
          ∏ p ∈ n.1.primeFactors, (p : ℝ) ^ (-1 / 4 : ℝ) := by
      calc
        (n.1 : ℝ) ^ (-1 / 4 : ℝ)
            = (∏ p ∈ n.1.primeFactors, (p : ℝ)) ^
                (-1 / 4 : ℝ) := by rw [hcast]
        _ = ∏ p ∈ n.1.primeFactors,
              (p : ℝ) ^ (-1 / 4 : ℝ) := by
            symm
            exact Real.finsetProd_rpow n.1.primeFactors
              (fun p => (p : ℝ))
              (fun p hp => by positivity)
              (-1 / 4)
    rw [fixedQShiuWeight_apply, fixedQShiuWeightNat,
      if_neg n.2.1, if_pos ⟨n.2.2, hcop⟩, hrpow,
      ← Finset.prod_mul_distrib]
    apply Finset.prod_le_prod₀
    · intro p hp
      exact mul_nonneg (fixedQShiuPrimeFactor_nonneg p)
        (Real.rpow_nonneg (by positivity) _)
    · intro p hp
      have hpPrime : p.Prime := Nat.prime_of_mem_primeFactors hp
      have hpdvd : p ∣ n.1 := Nat.dvd_of_mem_primeFactors hp
      have hpCop6q : p.Coprime (6 * q) := hcop.of_dvd_left hpdvd
      have hpCop6 : p.Coprime 6 := hpCop6q.of_dvd_right (by
        exact Nat.dvd_mul_right 6 q)
      exact fixedQShiuPrimeFactor_mul_quarter_le_majorant
        (prime_ge_five_of_coprime_six hpPrime hpCop6q)
  · rw [fixedQShiuWeight_apply, fixedQShiuWeightNat,
      if_neg n.2.1, if_neg]
    · simp only [zero_mul]
      apply Finset.prod_nonneg
      intro p hp
      exact sourceShiuQuarterPrimeMajorant_nonneg p
    · exact fun hs => hcop hs.2

theorem summable_fixedQShiuWeight_mul_quarter (q : ℕ) :
    Summable (fun n : ℕ =>
      fixedQShiuWeight q n * (n : ℝ) ^ (-1 / 4 : ℝ)) := by
  let t : {n : ℕ // n ≠ 0 ∧ Squarefree n} → ℝ := fun n =>
    fixedQShiuWeight q n.1 * (n.1 : ℝ) ^ (-1 / 4 : ℝ)
  let T : {n : ℕ // n ≠ 0 ∧ Squarefree n} → ℝ := fun n =>
    ∏ p ∈ n.1.primeFactors, sourceShiuQuarterPrimeMajorant p
  have hT : Summable T := by
    exact summable_sourceShiuQuarterFinsetProduct.comp_injective
      source_primeFactors_injective_on_squarefreePositive
  have ht0 : ∀ n, 0 ≤ t n := by
    intro n
    exact mul_nonneg (fixedQShiuWeight_nonneg q n.1)
      (Real.rpow_nonneg (by positivity) _)
  have htT : ∀ n, t n ≤ T n := by
    intro n
    exact fixedQShiuWeight_mul_quarter_le_finsetMajorant q n
  have ht : Summable t :=
    Summable.of_nonneg_of_le ht0 htT hT
  let s : Set ℕ := {n | n ≠ 0 ∧ Squarefree n}
  have hsub :
      Summable
        ((fun n : ℕ =>
          fixedQShiuWeight q n * (n : ℝ) ^ (-1 / 4 : ℝ)) ∘
          (Subtype.val : s → ℕ)) := by
    change Summable t
    exact ht
  have hind :
      Summable (s.indicator (fun n : ℕ =>
        fixedQShiuWeight q n * (n : ℝ) ^ (-1 / 4 : ℝ))) :=
    summable_subtype_iff_indicator.mp hsub
  exact hind.congr (fun n => by
    by_cases hn : n ≠ 0 ∧ Squarefree n
    · simp [s, Set.indicator, hn]
    · have hz : fixedQShiuWeight q n = 0 := by
        rw [fixedQShiuWeight_apply]
        unfold fixedQShiuWeightNat
        by_cases h0 : n = 0
        · simp [h0]
        · rw [if_neg h0]
          by_cases hs : Squarefree n ∧ n.Coprime (6 * q)
          · exact False.elim (hn ⟨h0, hs.1⟩)
          · simp [hs]
      simp [s, Set.indicator, hn, hz])

noncomputable def fixedQShiuQuarterMoment (q : ℕ) : ℝ :=
  ∑' n : ℕ, fixedQShiuWeight q n * (n : ℝ) ^ (-1 / 4 : ℝ)

lemma fixedQShiuQuarterMoment_nonneg (q : ℕ) :
    0 ≤ fixedQShiuQuarterMoment q := by
  unfold fixedQShiuQuarterMoment
  exact tsum_nonneg (fun n =>
    mul_nonneg (fixedQShiuWeight_nonneg q n)
      (Real.rpow_nonneg (by positivity) _))

#print axioms summable_fixedQShiuWeight_mul_quarter

end PaperB.FixedQ
