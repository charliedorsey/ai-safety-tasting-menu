import PaperB.Analytic.H3VaalerGCIntegrable
import PaperB.Analytic.H3VaalerPointwiseLpIdentification
import PaperB.Analytic.H3VaalerFourierLimit
import PaperB.Analytic.H3VaalerCesaroLp

noncomputable section

open MeasureTheory Complex Real Filter Topology
open scoped FourierTransform ENNReal

namespace PaperB.Analytic.H3VaalerGCFourier

open PaperB.Analytic.H3VaalerContinuous
open PaperB.Analytic.H3VaalerJHatContinuous
open PaperB.Analytic.H3VaalerCesaroLp
open PaperB.Analytic.H3VaalerFourierLimit
open PaperB.Analytic.H3VaalerPointwiseLpIdentification
open PaperB.Analytic.H3VaalerGCIntegrable

/-- Exact live Paper B analogue of the certified GCFTeqJhat. -/
theorem GCFTeqJhat :
    ∀ t : ℝ, 𝓕 h3GC t = h3VaalerJHatContC t := by
  intro t
  have hfun :
      𝓕 h3GC = h3VaalerJHatContC :=
    h3GCFourier_eq_JHat_of_fourierLimit
      memLp_gCes
      fourierSideL2Limit
      h3GC_integrable
  exact congrFun hfun t

theorem GCFTeqJhat_fun :
    𝓕 h3GC = h3VaalerJHatContC :=
  funext GCFTeqJhat

#print axioms GCFTeqJhat
#print axioms GCFTeqJhat_fun

end PaperB.Analytic.H3VaalerGCFourier
