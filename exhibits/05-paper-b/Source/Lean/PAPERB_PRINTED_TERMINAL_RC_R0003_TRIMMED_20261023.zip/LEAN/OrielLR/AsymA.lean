import OrielLR.LRMaster

/-!
# Oriel L/R — real asymptotic toolkit
-/

open Filter Topology

namespace OrielUpper

/-- `(ℓ+2)^k exp(-c ℓ^δ) → 0`. -/
theorem tendsto_poly_exp (k : ℕ) {c δ : ℝ} (hc : 0 < c) (hδ : 0 < δ) :
    Tendsto (fun ℓ : ℝ => (ℓ + 2) ^ k * Real.exp (-(c * ℓ ^ δ))) atTop (𝓝 0) := by
  have h1 : Tendsto (fun y : ℝ => y ^ ((k : ℝ) / δ) * Real.exp (-c * y)) atTop (𝓝 0) :=
    tendsto_rpow_mul_exp_neg_mul_atTop_nhds_zero _ _ hc
  have h2 : Tendsto (fun ℓ : ℝ => ℓ ^ δ) atTop atTop := tendsto_rpow_atTop hδ
  have h3 := (h1.comp h2).const_mul (2 ^ k)
  rw [mul_zero] at h3
  apply squeeze_zero' ((eventually_ge_atTop (0 : ℝ)).mono (fun ℓ hℓ => by positivity)) _ h3
  filter_upwards [eventually_ge_atTop (2 : ℝ)] with ℓ hℓ
  simp only [Function.comp]
  have hℓ0 : 0 ≤ ℓ := by linarith
  have e : (ℓ ^ δ) ^ ((k : ℝ) / δ) = ℓ ^ k := by
    rw [← Real.rpow_mul hℓ0, mul_div_cancel₀ _ hδ.ne', Real.rpow_natCast]
  rw [e]
  have hpow : (ℓ + 2) ^ k ≤ 2 ^ k * ℓ ^ k := by
    rw [← mul_pow]; exact pow_le_pow_left₀ (by linarith) (by linarith) k
  have hexp : Real.exp (-(c * ℓ ^ δ)) = Real.exp (-c * ℓ ^ δ) := by ring_nf
  rw [hexp]
  calc (ℓ + 2) ^ k * Real.exp (-c * ℓ ^ δ) ≤ 2 ^ k * ℓ ^ k * Real.exp (-c * ℓ ^ δ) :=
        mul_le_mul_of_nonneg_right hpow (Real.exp_pos _).le
    _ = 2 ^ k * (ℓ ^ k * Real.exp (-c * ℓ ^ δ)) := by ring

/-- Eventually `A ℓ^a + C ≤ ℓ^b` for `0 ≤ a < b`. -/
theorem eventually_rpow_dom {a b : ℝ} (ha : 0 ≤ a) (hab : a < b) (A C : ℝ) :
    ∀ᶠ ℓ : ℝ in atTop, A * ℓ ^ a + C ≤ ℓ ^ b := by
  have h := tendsto_rpow_atTop (show 0 < b - a by linarith)
  filter_upwards [h.eventually_ge_atTop (|A| + |C| + 1), eventually_ge_atTop (1 : ℝ)] with ℓ h1 h2
  have hℓ0 : 0 < ℓ := by linarith
  have hla : 1 ≤ ℓ ^ a := Real.one_le_rpow h2 ha
  have e : ℓ ^ b = ℓ ^ a * ℓ ^ (b - a) := by
    rw [← Real.rpow_add hℓ0]; ring_nf
  rw [e]
  have hA : A ≤ |A| := le_abs_self A
  have hC : C ≤ |C| := le_abs_self C
  have : ℓ ^ a * (|A| + |C| + 1) ≤ ℓ ^ a * ℓ ^ (b - a) :=
    mul_le_mul_of_nonneg_left h1 (by linarith)
  nlinarith [abs_nonneg A, abs_nonneg C]

/-- Eventually `C (ℓ+2)^{1/8} ≤ ε ℓ`. -/
theorem eventually_small_root {C ε : ℝ} (hε : 0 < ε) :
    ∀ᶠ ℓ : ℝ in atTop, C * (ℓ + 2) ^ (1 / 8 : ℝ) ≤ ε * ℓ := by
  have h := (tendsto_rpow_atTop (show (0 : ℝ) < 7 / 8 by norm_num)).comp
    (tendsto_atTop_add_const_right atTop (2 : ℝ) tendsto_id)
  filter_upwards [h.eventually_ge_atTop (2 * |C| / ε + 1), eventually_ge_atTop (2 : ℝ)] with ℓ h1 h2
  simp only [Function.comp, id] at h1
  have hp : 0 < ℓ + 2 := by linarith
  have e : ℓ + 2 = (ℓ + 2) ^ (1 / 8 : ℝ) * (ℓ + 2) ^ (7 / 8 : ℝ) := by
    rw [← Real.rpow_add hp]; norm_num
  have hr : 0 < (ℓ + 2) ^ (1 / 8 : ℝ) := by positivity
  have hC : C ≤ |C| := le_abs_self C
  have h3 : 2 * |C| ≤ ε * (ℓ + 2) ^ (7 / 8 : ℝ) := by
    have := mul_le_mul_of_nonneg_left h1 hε.le
    rw [mul_add, mul_div_cancel₀ _ hε.ne'] at this
    linarith
  have h4 : C * (ℓ + 2) ^ (1 / 8 : ℝ) ≤ ε * (ℓ + 2) / 2 := by
    calc C * (ℓ + 2) ^ (1 / 8 : ℝ) ≤ |C| * (ℓ + 2) ^ (1 / 8 : ℝ) :=
          mul_le_mul_of_nonneg_right hC hr.le
      _ ≤ (ε * (ℓ + 2) ^ (7 / 8 : ℝ) / 2) * (ℓ + 2) ^ (1 / 8 : ℝ) :=
          mul_le_mul_of_nonneg_right (by linarith) hr.le
      _ = ε * ((ℓ + 2) ^ (1 / 8 : ℝ) * (ℓ + 2) ^ (7 / 8 : ℝ)) / 2 := by ring
      _ = ε * (ℓ + 2) / 2 := by rw [← e]
  nlinarith [mul_nonneg hε.le (show (0 : ℝ) ≤ ℓ - 2 by linarith)]

end OrielUpper
