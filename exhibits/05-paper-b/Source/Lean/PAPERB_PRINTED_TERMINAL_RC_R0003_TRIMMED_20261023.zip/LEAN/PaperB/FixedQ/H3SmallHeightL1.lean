import PaperB.FixedQ.TwoDimensionalClosure

open scoped BigOperators

namespace PaperB.FixedQ

/-- The fixed-q low weight depends on the anchor only modulo q. -/
lemma fixedQLowWeight_anchor_mod
    (q a h y : ℕ) :
    fixedQLowWeight q a h y =
      fixedQLowWeight q (a % q) h y := by
  unfold fixedQLowWeight
  have hmod : a ≡ a % q [MOD q] := (Nat.mod_modEq a q).symm
  have hsum : a + y ≡ a % q + y [MOD q] :=
    hmod.add (Nat.ModEq.refl y)
  have hc :
      q.Coprime (a + y) ↔ q.Coprime (a % q + y) :=
    coprime_right_iff_of_modEq hsum
  by_cases ha : q.Coprime (a + y)
  · rw [if_pos ha, if_pos (hc.mp ha)]
  · rw [if_neg ha, if_neg (fun hz => ha (hc.mpr hz))]

/-- Hence the ordinary Boolean core term also depends on the anchor only modulo q. -/
lemma ordinaryBooleanCoreTerm_anchor_mod
    (q a h : ℕ) (e : Finset ℕ) :
    ordinaryBooleanCoreTerm q a h e =
      ordinaryBooleanCoreTerm q (a % q) h e := by
  have hw :
      fixedQLowWeight q a h =
        fixedQLowWeight q (a % q) h := by
    funext y
    exact fixedQLowWeight_anchor_mod q a h y
  unfold ordinaryBooleanCoreTerm
  rw [hw]

noncomputable def ordinaryBooleanSmallHeightL1
    (q a H : ℕ) : ℝ :=
  ∑' n : Finset ℕ, |ordinaryBooleanCoreTerm q a H n|

lemma ordinaryBooleanSmallHeightL1_anchor_mod
    (q a H : ℕ) :
    ordinaryBooleanSmallHeightL1 q a H =
      ordinaryBooleanSmallHeightL1 q (a % q) H := by
  unfold ordinaryBooleanSmallHeightL1
  apply tsum_congr
  intro n
  rw [ordinaryBooleanCoreTerm_anchor_mod q a H n]

lemma ordinaryBooleanSmallHeightL1_nonneg
    (q a H : ℕ) :
    0 ≤ ordinaryBooleanSmallHeightL1 q a H := by
  unfold ordinaryBooleanSmallHeightL1
  exact tsum_nonneg (fun n => abs_nonneg _)

/-- A finite fixed-q/fixed-height-cutoff envelope for the full ordinary Boolean L1 mass. -/
noncomputable def ordinaryBooleanSmallHeightUniformBound
    (q H0 : ℕ) : ℝ :=
  ∑ H ∈ Finset.range H0,
    ∑ a ∈ Finset.range q,
      ordinaryBooleanSmallHeightL1 q a H

/-- Uniform absolute L1 bound for all heights below a fixed cutoff.

The proof is finite packaging only: for fixed q, the anchor enters through
its residue modulo q, so below H0 there are only q * H0 representative L1 values. -/
theorem ordinaryBooleanCore_abs_l1_smallHeight_uniform
    (q H0 : ℕ) (hq : 0 < q) :
    ∃ B : ℝ, 0 ≤ B ∧
      ∀ A H : ℕ,
        q.Coprime A →
        (¬ 2 ∣ q → 2 ∣ H) →
        0 < H →
        H < H0 →
        (∑' n : Finset ℕ,
          |ordinaryBooleanCoreTerm q A H n|) ≤ B := by
  refine ⟨ordinaryBooleanSmallHeightUniformBound q H0, ?_, ?_⟩
  · unfold ordinaryBooleanSmallHeightUniformBound
    apply Finset.sum_nonneg
    intro H hH
    apply Finset.sum_nonneg
    intro a ha
    exact ordinaryBooleanSmallHeightL1_nonneg q a H
  · intro A H _hA _h2 _hH hlt
    have hHmem : H ∈ Finset.range H0 := Finset.mem_range.mpr hlt
    have hmodlt : A % q < q := Nat.mod_lt A hq
    have hAmem : A % q ∈ Finset.range q := Finset.mem_range.mpr hmodlt
    change ordinaryBooleanSmallHeightL1 q A H ≤
      ordinaryBooleanSmallHeightUniformBound q H0
    rw [ordinaryBooleanSmallHeightL1_anchor_mod q A H]
    unfold ordinaryBooleanSmallHeightUniformBound
    calc
      ordinaryBooleanSmallHeightL1 q (A % q) H ≤
          ∑ a ∈ Finset.range q, ordinaryBooleanSmallHeightL1 q a H := by
        exact Finset.single_le_sum
          (fun a ha => ordinaryBooleanSmallHeightL1_nonneg q a H) hAmem
      _ ≤ ∑ H ∈ Finset.range H0,
          ∑ a ∈ Finset.range q, ordinaryBooleanSmallHeightL1 q a H := by
        exact Finset.single_le_sum
          (fun H hH => Finset.sum_nonneg (fun a ha =>
            ordinaryBooleanSmallHeightL1_nonneg q a H)) hHmem

#print axioms ordinaryBooleanCore_abs_l1_smallHeight_uniform

end PaperB.FixedQ
