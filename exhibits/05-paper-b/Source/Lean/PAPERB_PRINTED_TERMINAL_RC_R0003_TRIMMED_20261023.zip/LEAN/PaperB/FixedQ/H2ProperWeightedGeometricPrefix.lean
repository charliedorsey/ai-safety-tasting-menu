import PaperB.FixedQ.H2ProperWeightedInitial
import PaperB.FixedQ.H2BooleanGeometricExterior

open Filter Real Asymptotics
open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def h2BooleanProperGeometricPrefix
    (q A H N J : ℕ) : ℝ :=
  ∑ k ∈ Finset.range J,
    h2BooleanProperWeightedDyadicShell q A H (N * 2 ^ k)

lemma h2Boolean_geometric_scale_le_top
    {N J k : ℕ} (hk : k < J) :
    N * 2 ^ k ≤ N * 2 ^ J := by
  gcongr

lemma h2Boolean_log_rate_mono
    {M U : ℕ}
    (hMposNat : 0 < M)
    (hlogM2 : 2 ≤ Real.log (M : ℝ))
    (hMU : M ≤ U) :
    (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
        (Real.log (Real.log (M : ℝ))) ^ 2 ≤
      (Real.log (U : ℝ)) ^ (h2BooleanX0 - 1) *
        (Real.log (Real.log (U : ℝ))) ^ 2 := by
  have hM1 : (1 : ℝ) ≤ (M : ℝ) := by
    exact_mod_cast (show 1 ≤ M by omega)
  have hMUreal : (M : ℝ) ≤ (U : ℝ) := by exact_mod_cast hMU
  have hMpos : (0 : ℝ) < M := by exact_mod_cast hMposNat
  have hUpos : (0 : ℝ) < U := lt_of_lt_of_le hMpos hMUreal
  have hlogM0 : 0 ≤ Real.log (M : ℝ) := Real.log_nonneg hM1
  have hlogMU : Real.log (M : ℝ) ≤ Real.log (U : ℝ) :=
    Real.strictMonoOn_log.monotoneOn hMpos hUpos hMUreal
  have hllM0 : 0 ≤ Real.log (Real.log (M : ℝ)) := by
    exact Real.log_nonneg (le_trans (by norm_num) hlogM2)
  have hlogUpos : 0 < Real.log (U : ℝ) := by
    linarith
  have hllMU :
      Real.log (Real.log (M : ℝ)) ≤
        Real.log (Real.log (U : ℝ)) := by
    exact Real.strictMonoOn_log.monotoneOn
      (lt_of_lt_of_le (by norm_num) hlogM2) hlogUpos hlogMU
  have ha0 : 0 ≤ h2BooleanX0 - 1 :=
    sub_nonneg.mpr h2BooleanX0_one_le_public
  have hp :
      (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) ≤
        (Real.log (U : ℝ)) ^ (h2BooleanX0 - 1) := by
    exact Real.rpow_le_rpow hlogM0 hlogMU ha0
  have hsq :
      (Real.log (Real.log (M : ℝ))) ^ 2 ≤
        (Real.log (Real.log (U : ℝ))) ^ 2 := by
    nlinarith [sq_nonneg
      (Real.log (Real.log (U : ℝ)) -
        Real.log (Real.log (M : ℝ)))]
  have hlogU0 : 0 ≤ Real.log (U : ℝ) := hlogM0.trans hlogMU
  exact mul_le_mul hp hsq (sq_nonneg _) (Real.rpow_nonneg hlogU0 _)

theorem h2BooleanProperGeometricPrefix_le_rate
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ N0 : ℕ,
      0 ≤ C ∧
      ∀ A H N J : ℕ,
        (¬ 2 ∣ q → 2 ∣ H) →
        N0 ≤ N →
        h2BooleanProperGeometricPrefix q A H N J ≤
          (J : ℝ) * C *
            (Real.log ((N * 2 ^ J : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) *
            (Real.log (Real.log ((N * 2 ^ J : ℕ) : ℝ))) ^ 2 := by
  rcases h2BooleanProperWeightedDyadicShell_le_rate_eventually q hq with
    ⟨C, M0, hC, hrate⟩
  obtain ⟨Mcond, hcond⟩ := exists_h2BooleanProperShellConditionThreshold q
  let N0 := max M0 Mcond
  refine ⟨C, N0, hC, ?_⟩
  intro A H N J h2 hN
  have hM0N : M0 ≤ N := (le_max_left M0 Mcond).trans hN
  have hcondN : Mcond ≤ N := (le_max_right M0 Mcond).trans hN
  unfold h2BooleanProperGeometricPrefix
  calc
    (∑ k ∈ Finset.range J,
      h2BooleanProperWeightedDyadicShell q A H (N * 2 ^ k))
      ≤ ∑ k ∈ Finset.range J,
          C * (Real.log ((N * 2 ^ k : ℕ) : ℝ)) ^
              (h2BooleanX0 - 1) *
            (Real.log (Real.log ((N * 2 ^ k : ℕ) : ℝ))) ^ 2 := by
        apply Finset.sum_le_sum
        intro k hk
        have hkJ : k < J := Finset.mem_range.mp hk
        apply hrate A H (N * 2 ^ k) h2
        exact hM0N.trans (by
          simpa using Nat.le_mul_of_pos_right N (pow_pos (by norm_num) k))
    _ ≤ ∑ _k ∈ Finset.range J,
          C * (Real.log ((N * 2 ^ J : ℕ) : ℝ)) ^
              (h2BooleanX0 - 1) *
            (Real.log (Real.log ((N * 2 ^ J : ℕ) : ℝ))) ^ 2 := by
        apply Finset.sum_le_sum
        intro k hk
        have hkJ : k < J := Finset.mem_range.mp hk
        have hscale := h2Boolean_geometric_scale_le_top
          (N := N) (J := J) hkJ
        have hNscale : N ≤ N * 2 ^ k := by
          simpa using Nat.le_mul_of_pos_right N (pow_pos (by norm_num) k)
        have hcondScale := hcond (N * 2 ^ k) (hcondN.trans hNscale)
        have hmono := h2Boolean_log_rate_mono
          (M := N * 2 ^ k) (U := N * 2 ^ J)
          (by omega)
          hcondScale.2.2.2.2.2.2.1
          hscale
        calc
          C * (Real.log ((N * 2 ^ k : ℕ) : ℝ)) ^
                (h2BooleanX0 - 1) *
              (Real.log (Real.log ((N * 2 ^ k : ℕ) : ℝ))) ^ 2
            = C * ((Real.log ((N * 2 ^ k : ℕ) : ℝ)) ^
                (h2BooleanX0 - 1) *
              (Real.log (Real.log ((N * 2 ^ k : ℕ) : ℝ))) ^ 2) := by ring
          _ ≤ C * ((Real.log ((N * 2 ^ J : ℕ) : ℝ)) ^
                (h2BooleanX0 - 1) *
              (Real.log (Real.log ((N * 2 ^ J : ℕ) : ℝ))) ^ 2) :=
                mul_le_mul_of_nonneg_left hmono hC
          _ = C * (Real.log ((N * 2 ^ J : ℕ) : ℝ)) ^
                (h2BooleanX0 - 1) *
              (Real.log (Real.log ((N * 2 ^ J : ℕ) : ℝ))) ^ 2 := by ring
    _ = (J : ℝ) * C *
          (Real.log ((N * 2 ^ J : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) *
          (Real.log (Real.log ((N * 2 ^ J : ℕ) : ℝ))) ^ 2 := by
        simp
        ring

#print axioms h2Boolean_log_rate_mono
#print axioms h2BooleanProperGeometricPrefix_le_rate

end PaperB.FixedQ
