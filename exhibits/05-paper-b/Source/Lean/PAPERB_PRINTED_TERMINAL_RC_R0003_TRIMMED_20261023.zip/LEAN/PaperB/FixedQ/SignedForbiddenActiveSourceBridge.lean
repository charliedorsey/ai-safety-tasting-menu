import PaperB.FixedQ.SignedForbiddenNaturalBridge

namespace PaperB.FixedQ

theorem dForbidden_source_coprime_iff_of_active
    {q H : ℕ} {d n : Finset ℕ}
    (hdActive : ∀ p ∈ d, activeHighPrime q p)
    (hn : n ∈ activeOrdinaryTwoDimensionalSet q H) :
    Disjoint d n ↔
      (primeSetProduct n).Coprime
        (H * (6 * q) * primeSetProduct d) := by
  have hdPrime : ∀ p ∈ d, p.Prime := fun p hp => (hdActive p hp).1
  have hnPrime : ∀ p ∈ n, p.Prime := fun p hp => (hn.2 p hp).1
  constructor
  · intro hdis
    exact dForbidden_source_coprime hdActive hn hdis
  · intro hcop
    have hnD : (primeSetProduct n).Coprime (primeSetProduct d) :=
      (Nat.coprime_mul_iff_right.mp hcop).2
    exact (disjoint_iff_primeSetProduct_coprime hdPrime hnPrime).2 hnD.symm

theorem dForbiddenBooleanShiuMainTerm_eq_source_signed_of_active
    {q a H : ℕ} {d n : Finset ℕ}
    (hdActive : ∀ p ∈ d, activeHighPrime q p) :
    dForbiddenBooleanShiuMainTerm q a H d n =
      sourceForbiddenBooleanMainTerm q a H d n := by
  classical
  by_cases hact : n ∈ activeOrdinaryTwoDimensionalSet q H
  · have hiff :=
      dForbidden_source_coprime_iff_of_active hdActive hact
    by_cases hne : n.Nonempty
    · by_cases hdis : Disjoint d n
      · have hcop := hiff.mp hdis
        simp [dForbiddenBooleanShiuMainTerm,
          sourceForbiddenBooleanMainTerm, hdis, hcop, hne,
          Set.indicator_of_mem hact]
      · have hncop : ¬ (primeSetProduct n).Coprime
            (H * (6 * q) * primeSetProduct d) := by
          exact fun hc => hdis (hiff.mpr hc)
        simp [dForbiddenBooleanShiuMainTerm,
          sourceForbiddenBooleanMainTerm, hdis, hncop, hne]
    · have hn0 : n = ∅ := Finset.not_nonempty_iff_eq_empty.mp hne
      subst n
      simp [dForbiddenBooleanShiuMainTerm,
        sourceForbiddenBooleanMainTerm]
  · simp [dForbiddenBooleanShiuMainTerm,
      sourceForbiddenBooleanMainTerm, Set.indicator, hact]

theorem dForbiddenBooleanMainTerm_eq_source_signed_of_active
    {q a H : ℕ} {d n : Finset ℕ}
    (hdActive : ∀ p ∈ d, activeHighPrime q p) :
    dForbiddenBooleanMainTerm q a H d n =
      sourceForbiddenBooleanMainTerm q a H d n := by
  rw [dForbiddenBooleanMainTerm_eq_shiu]
  exact dForbiddenBooleanShiuMainTerm_eq_source_signed_of_active hdActive

#print axioms dForbidden_source_coprime_iff_of_active
#print axioms dForbiddenBooleanShiuMainTerm_eq_source_signed_of_active
#print axioms dForbiddenBooleanMainTerm_eq_source_signed_of_active

end PaperB.FixedQ
