import PaperB.Analytic.PetermannOmegaWeightedExpansion
import PaperB.Analytic.PetermannOmegaLowMovingCutoff
import PaperB.Analytic.PetermannOmegaHighNonzeroDFT
import PaperB.Analytic.PetermannOmegaHighZeroMode
import PaperB.Analytic.PetermannOmegaHighCoprimeDFT
import PaperB.Analytic.Basic

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset

theorem omega_reciprocal_phase_eq_correction_coprime
    (q X : ℕ) (A xi : ℝ) :
    (∑ e ∈ Finset.Icc 1 X,
      (omegaCoeff q e : ℂ) *
        eR (A / (e : ℝ) + xi * (e : ℝ))) =
      ∑ d ∈ Finset.Icc 1 X,
        (omegaCorrectionInvTerm q d : ℂ) *
          ∑ m ∈ Finset.Icc 1 (X / d),
            ((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
              eR (A / ((d * m : ℕ) : ℝ) +
                xi * ((d * m : ℕ) : ℝ)) := by
  simpa using
    (omega_weighted_sum_eq_correction_coprime q X
      (fun n => eR (A / (n : ℝ) + xi * (n : ℝ))))

#print axioms omega_reciprocal_phase_eq_correction_coprime

end PaperB.Analytic
