import PaperB.Analytic.PetermannSmoothExpansion
import PaperB.FixedQ.PetermannInterface

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset

theorem omega_smoothed_additive_kernel_expansion
    {S : ℝ} (hS : 1 < S)
    (q H X : ℕ) (xi T : ℝ) (r : ℤ) :
    (∑ e ∈ Finset.Icc 1 X,
      (omegaCoeff q e : ℂ) *
        (eR (xi * (e : ℝ)) *
          sawSmoothPartial S H
            ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
              (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) :
              ℝ) : AddCircle (1 : ℝ)))) =
      ∑ k ∈ Finset.range H,
        (sawSmoothCoeff S (k + 1 : ℕ) *
            eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) /
              ((Nat.lcm 6 q : ℕ) : ℝ)) *
            (∑ e ∈ Finset.Icc 1 X,
              (omegaCoeff q e : ℂ) *
                eR (((((k + 1 : ℕ) : ℝ) * T) /
                    ((Nat.lcm 6 q : ℕ) : ℝ)) / (e : ℝ) +
                  xi * (e : ℝ))) +
          sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
            eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) /
              ((Nat.lcm 6 q : ℕ) : ℝ)) *
            (∑ e ∈ Finset.Icc 1 X,
              (omegaCoeff q e : ℂ) *
                eR (((-((k + 1 : ℕ) : ℤ) : ℝ) * T) /
                    ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
                  xi * (e : ℝ)))) := by
  calc
    (∑ e ∈ Finset.Icc 1 X,
      (omegaCoeff q e : ℂ) *
        (eR (xi * (e : ℝ)) *
          sawSmoothPartial S H
            ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
              (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) :
              ℝ) : AddCircle (1 : ℝ))))
      =
    ∑ e ∈ Finset.Icc 1 X,
      (omegaCoeff q e : ℂ) *
        (∑ k ∈ Finset.range H,
          (sawSmoothCoeff S (k + 1 : ℕ) *
            eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) /
              ((Nat.lcm 6 q : ℕ) : ℝ)) *
            eR (((((k + 1 : ℕ) : ℝ) * T) /
                ((Nat.lcm 6 q : ℕ) : ℝ)) / (e : ℝ) +
              xi * (e : ℝ)) +
          sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
            eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) /
              ((Nat.lcm 6 q : ℕ) : ℝ)) *
            eR (((-((k + 1 : ℕ) : ℤ) : ℝ) * T) /
                ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
              xi * (e : ℝ)))) := by
        apply Finset.sum_congr rfl
        intro e he
        rw [eR_mul_sawSmoothPartial_petermann_phase hS]
    _ = _ := by
      simp_rw [Finset.mul_sum]
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro k hk
      rw [← Finset.sum_add_distrib]
      apply Finset.sum_congr rfl
      intro e he
      ring

#print axioms omega_smoothed_additive_kernel_expansion

end PaperB.Analytic
