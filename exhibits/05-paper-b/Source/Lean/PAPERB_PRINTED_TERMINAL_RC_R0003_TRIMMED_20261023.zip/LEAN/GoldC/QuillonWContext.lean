import GoldC.QuillonWBilinear
import GoldC.QuillonRamare
import Mathlib.Data.Nat.Squarefree

/-!
# Quillon CSC3 F7.5f: the W′ route at the finset level (fixed `s`)

For a universe `U` of primes `≥ 5`, coprime to `s` and `M`, and the Ramaré set `J ⊆ U ∩ [X, Y]`:

    S = Σ_{B⊆U, B∩J≠∅} ω(B)·1[∏B ∈ (I₀,I₁], |B| ∈ K]·rowW(∏B).

* Ramaré, then `B' ⊆ U` minus the terms with `p ∈ B'`, then reindex `B' ↦ n = ∏B'`, then
  `W_bilinear_full`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonWContext

open GoldC.QuillonWBilinear GoldC.QuillonVW GoldC.QuillonRamare GoldC.QuillonOmega

/-- The source weight `ω(B) = ∏_{p∈B} 1/(p−3)`. -/
noncomputable def ωR (B : Finset ℕ) : ℝ := ∏ p ∈ B, (1 / ((p : ℝ) - 3))

lemma ωR_nonneg (B : Finset ℕ) (hB : ∀ p ∈ B, 5 ≤ p) : 0 ≤ ωR B :=
  prod_nonneg fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast hB p hp
    apply div_nonneg zero_le_one; linarith

lemma ωR_insert (p : ℕ) (B : Finset ℕ) (hp : p ∉ B) :
    ωR (insert p B) = (1 / ((p : ℝ) - 3)) * ωR B := by
  unfold ωR; rw [prod_insert hp]

lemma erase_powerset_eq (U : Finset ℕ) (p : ℕ) :
    (U.erase p).powerset = U.powerset.filter (fun B => p ∉ B) := by
  ext B; simp only [mem_powerset, mem_filter]
  constructor
  · intro h; exact ⟨h.trans (erase_subset _ _), fun hp => (mem_erase.1 (h hp)).1 rfl⟩
  · rintro ⟨h, hp⟩ x hx
    exact mem_erase.2 ⟨fun hxp => hp (hxp ▸ hx), h hx⟩

lemma prod_injOn (U : Finset ℕ) (hU : ∀ p ∈ U, p.Prime) :
    Set.InjOn (fun B : Finset ℕ => ∏ p ∈ B, p) (U.powerset : Set (Finset ℕ)) := by
  intro B₁ h₁ B₂ h₂ heq
  have h₁' : ∀ p ∈ B₁, p.Prime := fun p hp => hU p (mem_powerset.1 h₁ hp)
  have h₂' : ∀ p ∈ B₂, p.Prime := fun p hp => hU p (mem_powerset.1 h₂ hp)
  rw [← Nat.primeFactors_prod h₁', ← Nat.primeFactors_prod h₂']
  exact congrArg Nat.primeFactors heq

lemma sum_inv_sub3_sq (J : Finset ℕ) (X : ℕ) (hX : 2 ≤ X) (hJ : ∀ p ∈ J, X ≤ p ∧ 5 ≤ p) :
    ∑ p ∈ J, (1 / ((p : ℝ) - 3)) ^ 2 ≤ (12.5 : ℝ) / X := by
  calc ∑ p ∈ J, (1 / ((p : ℝ) - 3)) ^ 2 ≤ ∑ p ∈ J.filter (fun p => X ≤ p), 6.25 * (1 / ((p : ℝ) ^ 2)) := by
        rw [filter_true_of_mem fun p hp => (hJ p hp).1]
        refine sum_le_sum fun p hp => ?_
        have h5 : (5 : ℝ) ≤ p := by exact_mod_cast (hJ p hp).2
        rw [div_pow, one_pow, mul_one_div, div_le_div_iff₀ (by nlinarith) (by nlinarith)]
        nlinarith
    _ = 6.25 * ∑ p ∈ J.filter (fun p => X ≤ p), (1 / ((p : ℝ) ^ 2)) := by rw [mul_sum]
    _ ≤ 6.25 * (2 / X) := by gcongr; exact sum_inv_sq_tail J X hX
    _ = (12.5 : ℝ) / X := by ring

section main
variable {s : ℕ} [NeZero s] {M : ℕ} [NeZero M]

lemma norm_rowW_le (𝒥 : Finset ℕ) (Acoef : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s) (r : ℕ) :
    ‖rowW 𝒥 Acoef c r‖ ≤ ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ := by
  unfold rowW
  refine (norm_sum_le _ _).trans (sum_le_sum fun ρ _ => ?_)
  split_ifs
  · refine (norm_sum_le _ _).trans (sum_le_sum fun j _ => ?_)
    rw [norm_mul]
    calc ‖Acoef ρ j‖ * ‖kphase (c j) r‖ ≤ ‖Acoef ρ j‖ * 1 :=
          mul_le_mul_of_nonneg_left (norm_kphase_le _ _) (norm_nonneg _)
      _ = _ := mul_one _
  · rw [norm_zero]; exact sum_nonneg fun _ _ => norm_nonneg _

lemma sum_ωR_powerset (U : Finset ℕ) :
    ∑ B ∈ U.powerset, ωR B = ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) := by
  unfold ωR; rw [prod_one_add]

theorem W_context (hs2 : 2 ≤ s) (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p)
    (𝒥 : Finset ℕ) (Acoef : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s)
    (U J : Finset ℕ) (hJU : J ⊆ U) (hU : ∀ p ∈ U, p.Prime ∧ 5 ≤ p)
    (hUs : ∀ p ∈ U, Nat.Coprime p s) (hUM : ∀ p ∈ U, Nat.Coprime p M)
    (X Y I₀ I₁ : ℕ) (hX : 2 ≤ X) (hY1 : 1 ≤ Y) (hJ : ∀ p ∈ J, X ≤ p ∧ p ≤ Y) (hYI : Y ≤ I₀)
    (Kset : Finset ℕ) :
    ‖∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty), (ωR B : ℂ) *
        (if (∏ p ∈ B, p) ∈ Ioc I₀ I₁ ∧ B.card ∈ Kset then rowW 𝒥 Acoef c (∏ p ∈ B, p) else 0)‖ ≤
      ((Nat.log 2 I₁ + 1 : ℕ) : ℝ) * M * ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ *
        ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 ^ (Nat.log 2 I₁ + 1) * (I₀ / Y))) : ℝ) ^ 30) ^ 2 *
          Real.sqrt (2 * WPsi P (c j) X Y (I₀ / Y))) +
      (∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖) * (∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3))) * ((12.5 : ℝ) / X) := by
  classical
  set Kd := Nat.log 2 I₁ + 1 with hKd
  set N₀ := I₀ / Y with hN₀def
  set Aω : ℝ := Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 ^ Kd * N₀)) : ℝ) ^ 30 with hAω
  set Atot : ℝ := ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ with hAtot
  set WU : ℝ := ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) with hWU
  set Φ : ℕ → ℕ → ℂ := fun r k => if r ∈ Ioc I₀ I₁ ∧ k ∈ Kset then rowW 𝒥 Acoef c r else 0 with hΦ
  have hΦle : ∀ r k, ‖Φ r k‖ ≤ Atot := by
    intro r k; simp only [hΦ]; split_ifs
    · exact norm_rowW_le 𝒥 Acoef c r
    · rw [norm_zero]; exact sum_nonneg fun _ _ => sum_nonneg fun _ _ => norm_nonneg _
  have hN₀1 : 1 ≤ N₀ := (Nat.one_le_div_iff (by omega)).2 hYI
  have hAω0 : 0 ≤ Aω := by positivity
  set g : ℕ → Finset ℕ → ℂ := fun p B' =>
    ((1 / ((p : ℝ) - 3) : ℝ) : ℂ) * (((ωR B' / (1 + ((B' ∩ J).card : ℝ)) : ℝ) : ℂ) *
      Φ (p * ∏ q ∈ B', q) (B'.card + 1)) with hg
  -- step 1–3: Ramaré and the subtraction
  have hS : ∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty), (ωR B : ℂ) * Φ (∏ p ∈ B, p) B.card =
      ∑ p ∈ J, ∑ B' ∈ U.powerset, g p B' - ∑ p ∈ J, ∑ B' ∈ U.powerset.filter (fun B' => p ∈ B'), g p B' := by
    rw [ramare U J hJU, ← sum_sub_distrib]
    refine sum_congr rfl fun p hp => ?_
    rw [erase_powerset_eq, eq_sub_iff_add_eq, ← sum_filter_add_sum_filter_not U.powerset (fun B' => p ∈ B'),
      add_comm]
    congr 1
    refine sum_congr rfl fun B' hB' => ?_
    have hpB' : p ∉ B' := (mem_filter.1 hB').2
    simp only [hg]
    rw [ωR_insert p B' hpB', prod_insert hpB', card_insert_of_notMem hpB']
    push_cast
    ring
  have hrewrite : ∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty), (ωR B : ℂ) *
      (if (∏ p ∈ B, p) ∈ Ioc I₀ I₁ ∧ B.card ∈ Kset then rowW 𝒥 Acoef c (∏ p ∈ B, p) else 0) =
      ∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty), (ωR B : ℂ) * Φ (∏ p ∈ B, p) B.card := rfl
  rw [hrewrite, hS]
  refine (norm_sub_le _ _).trans (add_le_add ?_ ?_)
  · -- main bilinear term
    set α : ℕ → ℂ := fun p => ((1 / ((p : ℝ) - 3) : ℝ) : ℂ) with hα
    set β' : Finset ℕ → ℂ := fun B' => ((ωR B' / (1 + ((B' ∩ J).card : ℝ)) : ℝ) : ℂ) *
      (if B'.card + 1 ∈ Kset then (1 : ℂ) else 0) with hβ'
    set β : ℕ → ℂ := fun n => β' n.primeFactors with hβ
    set G : ℕ → ℂ := fun n => ∑ p ∈ J, α p *
      (if p * n ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (p * n) else 0) with hG
    have hUp : ∀ p ∈ U, p.Prime := fun p hp => (hU p hp).1
    have e1 : ∑ p ∈ J, ∑ B' ∈ U.powerset, g p B' = ∑ B' ∈ U.powerset, β' B' * G (∏ q ∈ B', q) := by
      rw [sum_comm]
      refine sum_congr rfl fun B' _ => ?_
      rw [hG, mul_sum]
      refine sum_congr rfl fun p _ => ?_
      simp only [hg, hΦ, hβ', hα]
      by_cases h1 : p * ∏ q ∈ B', q ∈ Ioc I₀ I₁ <;> by_cases h2 : B'.card + 1 ∈ Kset <;>
        simp [h1, h2] <;> ring
    have e2 : ∑ B' ∈ U.powerset, β' B' * G (∏ q ∈ B', q) =
        ∑ n ∈ U.powerset.image (fun B => ∏ q ∈ B, q), β n * G n := by
      rw [sum_image (prod_injOn U hUp)]
      refine sum_congr rfl fun B' hB' => ?_
      simp only [hβ]
      rw [Nat.primeFactors_prod fun q hq => hUp q (mem_powerset.1 hB' hq)]
    set 𝒩 := (U.powerset.image (fun B => ∏ q ∈ B, q)).filter (fun n => n ∈ Ioc N₀ (2 ^ Kd * N₀))
      with h𝒩def
    have hpow : I₁ < 2 ^ Kd := Nat.lt_pow_succ_log_self (by norm_num) I₁
    have e3 : ∑ n ∈ U.powerset.image (fun B => ∏ q ∈ B, q), β n * G n = ∑ n ∈ 𝒩, β n * G n := by
      rw [h𝒩def, sum_filter]
      refine sum_congr rfl fun n _ => ?_
      split_ifs with hn
      · rfl
      · have hG0 : G n = 0 := by
          simp only [hG]
          refine sum_eq_zero fun p hp => ?_
          have hpY := (hJ p hp).2
          have hp1 : 1 ≤ p := le_trans (by omega) (hJ p hp).1
          rw [if_neg, mul_zero]
          intro hI
          simp only [mem_Ioc] at hI hn
          push Not at hn
          rcases le_or_gt n N₀ with h | h
          · have : p * n ≤ Y * N₀ := Nat.mul_le_mul hpY h
            have : Y * N₀ ≤ I₀ := by rw [hN₀def]; exact Nat.mul_div_le I₀ Y
            omega
          · have h2 := hn h
            have : 2 ^ Kd ≤ 2 ^ Kd * N₀ := Nat.le_mul_of_pos_right _ (by omega)
            have : n ≤ p * n := Nat.le_mul_of_pos_left n (by omega)
            omega
        rw [hG0, mul_zero]
    rw [e1, e2, e3]
    have hW := W_bilinear_full hs2 P hP hsP 𝒥 Acoef c J 𝒩 X Y N₀ Kd I₀ I₁ hX hN₀1
      (fun p hp => hJ p hp)
      (fun p hp => (ZMod.isUnit_iff_coprime p s).2 (hUs p (hJU hp)))
      (fun p hp => (ZMod.isUnit_iff_coprime p M).2 (hUM p (hJU hp)))
      (fun n hn => (mem_filter.1 hn).2) α β Aω hAω0
      (fun p hp => by
        have h5 : (5 : ℝ) ≤ p := by exact_mod_cast (hU p (hJU hp)).2
        simp only [hα]
        rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (by apply div_nonneg zero_le_one; linarith)]
        rw [div_le_div_iff₀ (by linarith) (by linarith)]
        have hA1 : (2.5 : ℝ) ≤ Aω := by
          have : (2.5 : ℝ) ≤ Real.exp 37.5 := by
            have := Real.add_one_le_exp (37.5 : ℝ); linarith
          have : (1 : ℝ) ≤ (1 + Nat.log 2 (Nat.log 2 (2 ^ Kd * N₀)) : ℝ) ^ 30 :=
            one_le_pow₀ (by linarith [(Nat.cast_nonneg _ : (0 : ℝ) ≤ Nat.log 2 (Nat.log 2 (2 ^ Kd * N₀)))])
          nlinarith [Real.exp_pos 37.5]
        nlinarith)
      (fun n hn => by
        have hn' := mem_filter.1 hn
        obtain ⟨B', hB', rfl⟩ := mem_image.1 hn'.1
        have hB'U := mem_powerset.1 hB'
        simp only [hβ]
        rw [Nat.primeFactors_prod fun q hq => hUp q (hB'U hq)]
        simp only [hβ']
        have hω0 := ωR_nonneg B' fun q hq => (hU q (hB'U hq)).2
        have hωle := omega_pointwise B' (fun q hq => hU q (hB'U hq)) (2 ^ Kd * N₀) (mem_Ioc.1 hn'.2).2
        rw [norm_mul]
        calc ‖((ωR B' / (1 + ((B' ∩ J).card : ℝ)) : ℝ) : ℂ)‖ *
              ‖(if B'.card + 1 ∈ Kset then (1 : ℂ) else 0)‖
            ≤ ωR B' * 1 := by
              apply mul_le_mul _ (by split_ifs <;> simp) (norm_nonneg _) hω0
              rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (by positivity)]
              exact div_le_self hω0 (by linarith [(Nat.cast_nonneg _ : (0 : ℝ) ≤ (B' ∩ J).card)])
          _ ≤ Aω / ((∏ q ∈ B', q : ℕ) : ℝ) := by
              rw [mul_one, Nat.cast_prod]; exact hωle)
    exact hW
  · -- the subtracted terms
    have hsubB : ∀ p ∈ J, ∑ B' ∈ U.powerset.filter (fun B' => p ∈ B'), ωR B' ≤
        (1 / ((p : ℝ) - 3)) * WU := by
      intro p hp
      have hpU := hJU hp
      rw [powerset_filter_mem_eq_image U p hpU, sum_image]
      · calc ∑ B'' ∈ (U.erase p).powerset, ωR (insert p B'')
            = (1 / ((p : ℝ) - 3)) * ∑ B'' ∈ (U.erase p).powerset, ωR B'' := by
              rw [mul_sum]
              refine sum_congr rfl fun B'' hB'' => ?_
              have : p ∉ B'' := fun h => by have := mem_powerset.1 hB'' h; simp at this
              rw [ωR_insert p B'' this]
          _ ≤ (1 / ((p : ℝ) - 3)) * ∑ B ∈ U.powerset, ωR B := by
              have h5 : (5 : ℝ) ≤ p := by exact_mod_cast (hU p hpU).2
              apply mul_le_mul_of_nonneg_left _ (by apply div_nonneg zero_le_one; linarith)
              exact sum_le_sum_of_subset_of_nonneg (powerset_mono.2 (erase_subset _ _))
                fun B hB _ => ωR_nonneg B fun q hq => (hU q (mem_powerset.1 hB hq)).2
          _ = _ := by rw [sum_ωR_powerset]
      · intro B₁ h₁ B₂ h₂ heq
        have hp₁ : p ∉ B₁ := fun h => by have := (mem_powerset.1 h₁) h; simp at this
        have hp₂ : p ∉ B₂ := fun h => by have := (mem_powerset.1 h₂) h; simp at this
        have := congrArg (fun B => B.erase p) heq
        simpa [erase_insert hp₁, erase_insert hp₂] using this
    have hAt0 : 0 ≤ Atot := sum_nonneg fun _ _ => sum_nonneg fun _ _ => norm_nonneg _
    have hWU0 : 0 ≤ WU := prod_nonneg fun p hp => by
      have : (5 : ℝ) ≤ p := by exact_mod_cast (hU p hp).2
      have : 0 ≤ 1 / ((p : ℝ) - 3) := by apply div_nonneg zero_le_one; linarith
      linarith
    calc _ ≤ ∑ p ∈ J, ∑ B' ∈ U.powerset.filter (fun B' => p ∈ B'), ‖g p B'‖ :=
          (norm_sum_le _ _).trans (sum_le_sum fun p _ => norm_sum_le _ _)
      _ ≤ ∑ p ∈ J, ∑ B' ∈ U.powerset.filter (fun B' => p ∈ B'),
            (1 / ((p : ℝ) - 3)) * (ωR B' * Atot) := by
          refine sum_le_sum fun p hp => sum_le_sum fun B' hB' => ?_
          have hB'U := mem_powerset.1 (mem_filter.1 hB').1
          have h5 : (5 : ℝ) ≤ p := by exact_mod_cast (hU p (hJU hp)).2
          have hω0 := ωR_nonneg B' fun q hq => (hU q (hB'U hq)).2
          simp only [hg]
          rw [norm_mul, norm_mul, Complex.norm_real, Complex.norm_real, Real.norm_eq_abs,
            Real.norm_eq_abs, abs_of_nonneg (by apply div_nonneg zero_le_one; linarith),
            abs_of_nonneg (by positivity)]
          apply mul_le_mul_of_nonneg_left _ (by apply div_nonneg zero_le_one; linarith)
          apply mul_le_mul _ (hΦle _ _) (norm_nonneg _) hω0
          exact div_le_self hω0 (by linarith [(Nat.cast_nonneg _ : (0 : ℝ) ≤ (B' ∩ J).card)])
      _ = Atot * ∑ p ∈ J, (1 / ((p : ℝ) - 3)) *
            ∑ B' ∈ U.powerset.filter (fun B' => p ∈ B'), ωR B' := by
          rw [mul_sum]; refine sum_congr rfl fun p _ => ?_
          rw [mul_sum, mul_sum]; refine sum_congr rfl fun B' _ => by ring
      _ ≤ Atot * ∑ p ∈ J, (1 / ((p : ℝ) - 3)) * ((1 / ((p : ℝ) - 3)) * WU) := by
          apply mul_le_mul_of_nonneg_left _ hAt0
          refine sum_le_sum fun p hp => ?_
          have h5 : (5 : ℝ) ≤ p := by exact_mod_cast (hU p (hJU hp)).2
          exact mul_le_mul_of_nonneg_left (hsubB p hp) (by apply div_nonneg zero_le_one; linarith)
      _ = Atot * WU * ∑ p ∈ J, (1 / ((p : ℝ) - 3)) ^ 2 := by
          rw [mul_assoc, mul_sum, mul_sum, mul_sum]; refine sum_congr rfl fun p _ => by ring
      _ ≤ Atot * WU * ((12.5 : ℝ) / X) := by
          apply mul_le_mul_of_nonneg_left _ (mul_nonneg hAt0 hWU0)
          exact sum_inv_sub3_sq J X hX fun p hp => ⟨(hJ p hp).1, (hU p (hJU hp)).2⟩

end main

end GoldC.QuillonWContext

#print axioms GoldC.QuillonWContext.prod_injOn
#print axioms GoldC.QuillonWContext.sum_inv_sub3_sq
#print axioms GoldC.QuillonWContext.W_context
