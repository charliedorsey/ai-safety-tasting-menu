import GoldB.CoreMain
import GoldB.TaylorAux

/-!
# GoldB.Karatsuba — the order-uniform Karatsuba lemma

Suzuki, arXiv:1811.02556v2, §3 Lemma 1 (= Karatsuba, Proc. Steklov 112 (1971), Thm 1):
for `0 < c0 < 1`, `0 < c3 ≤ c2 < c1 < 1` there are `0 < γ ≤ 1`, `C ≥ 0` depending only on
`c0..c3` such that for every `k ≥ 1`, `P ≥ 1`, real `X`, every `f` that is `C^{k+1}` at each
point of `[X, X+P]` with

* (A) `|f^{(k+1)}(x)|/(k+1)! ≤ P^{-c1(k+1)}` on `[X, X+P]`,
* (B) for at least `c0 k` orders `1 ≤ j ≤ k`: `P^{-c2 j} ≤ |f^{(j)}(x)|/j! ≤ P^{-c3 j}` there,

and every `P1 ≤ P`: `|∑_{X < n ≤ X+P1} e(f(n))| ≤ C P^{1-γ/k²}`.
-/

open Finset Set

namespace GoldB

/-- shifting an integer interval sum -/
lemma shift_err (g : ℤ → ℂ) (hg : ∀ a, ‖g a‖ ≤ 1) (u v : ℤ) (t : ℕ) :
    ‖∑ a ∈ Finset.Icc u v, g (a + t) - ∑ a ∈ Finset.Icc u v, g a‖ ≤ 2 * t := by
  classical
  have hmap : ∑ a ∈ Finset.Icc u v, g (a + t) = ∑ a ∈ Finset.Icc (u + t) (v + t), g a := by
    rw [← Finset.map_add_right_Icc, Finset.sum_map]; rfl
  rw [hmap]
  set A := Finset.Icc (u + t) (v + t)
  set B := Finset.Icc u v
  have e : ∑ a ∈ A, g a - ∑ a ∈ B, g a = ∑ a ∈ A \ B, g a - ∑ a ∈ B \ A, g a := by
    rw [← Finset.sum_sdiff (Finset.inter_subset_left : A ∩ B ⊆ A),
      ← Finset.sum_sdiff (Finset.inter_subset_right : A ∩ B ⊆ B)]
    rw [Finset.sdiff_inter_self_left, Finset.sdiff_inter_self_right]
    ring
  rw [e]
  have h1 : (A \ B).card ≤ t := by
    calc (A \ B).card ≤ (Finset.Icc (v + 1) (v + t)).card := by
          apply Finset.card_le_card; intro a ha
          simp only [A, B, Finset.mem_sdiff, Finset.mem_Icc] at ha ⊢; omega
      _ = t := by rw [Int.card_Icc]; omega
  have h2 : (B \ A).card ≤ t := by
    calc (B \ A).card ≤ (Finset.Icc u (u + t - 1)).card := by
          apply Finset.card_le_card; intro a ha
          simp only [A, B, Finset.mem_sdiff, Finset.mem_Icc] at ha ⊢; omega
      _ = t := by rw [Int.card_Icc]; omega
  have hn : ∀ s : Finset ℤ, ‖∑ a ∈ s, g a‖ ≤ s.card := by
    intro s
    calc ‖∑ a ∈ s, g a‖ ≤ ∑ a ∈ s, ‖g a‖ := norm_sum_le _ _
      _ ≤ ∑ _a ∈ s, (1 : ℝ) := sum_le_sum (fun a _ => hg a)
      _ = s.card := by simp
  calc ‖∑ a ∈ A \ B, g a - ∑ a ∈ B \ A, g a‖ ≤ ‖∑ a ∈ A \ B, g a‖ + ‖∑ a ∈ B \ A, g a‖ :=
        norm_sub_le _ _
    _ ≤ (A \ B).card + (B \ A).card := add_le_add (hn _) (hn _)
    _ ≤ 2 * t := by
        have : ((A \ B).card : ℝ) ≤ t := by exact_mod_cast h1
        have : ((B \ A).card : ℝ) ≤ t := by exact_mod_cast h2
        linarith

/-- averaging over the shifts `yz` -/
lemma avg_shift (f : ℝ → ℝ) (u v : ℤ) (Q : ℕ) (hQ : 1 ≤ Q) :
    ‖∑ a ∈ Finset.Icc u v, ee (f a)‖ ≤
      (1 / (Q : ℝ) ^ 2) * ∑ a ∈ Finset.Icc u v,
        ‖∑ y ∈ Zr Q, ∑ z ∈ Zr Q, ee (f (a + (y : ℝ) * z))‖ + 2 * ((Q : ℝ) - 1) ^ 2 := by
  classical
  set S := ∑ a ∈ Finset.Icc u v, ee (f a)
  have hQr : (1 : ℝ) ≤ Q := by exact_mod_cast hQ
  have hzr : ∀ y ∈ Zr Q, 0 ≤ y ∧ y ≤ (Q : ℤ) - 1 := by
    intro y hy; simp [Zr] at hy; omega
  -- for each (y,z), the shifted sum is S up to 2yz
  have hyz : ∀ y ∈ Zr Q, ∀ z ∈ Zr Q,
      ‖∑ a ∈ Finset.Icc u v, ee (f (a + (y : ℝ) * z)) - S‖ ≤ 2 * ((Q : ℝ) - 1) ^ 2 := by
    intro y hy z hz
    obtain ⟨hy0, hy1⟩ := hzr y hy
    obtain ⟨hz0, hz1⟩ := hzr z hz
    set t : ℕ := (y * z).toNat
    have ht : ((t : ℤ) : ℝ) = (y : ℝ) * z := by
      simp only [t]; rw [Int.toNat_of_nonneg (mul_nonneg hy0 hz0)]; push_cast; ring
    have := shift_err (fun a => ee (f a)) (fun a => by simp) u v t
    have e : ∑ a ∈ Finset.Icc u v, ee (f (a + (y : ℝ) * z)) =
        ∑ a ∈ Finset.Icc u v, (fun a : ℤ => ee (f a)) (a + t) := by
      apply sum_congr rfl; intro a _; simp only; push_cast; rw [← ht]; push_cast; ring_nf
    rw [e]
    refine this.trans ?_
    have htle : (t : ℝ) ≤ ((Q : ℝ) - 1) ^ 2 := by
      have : (t : ℝ) = (y : ℝ) * z := by exact_mod_cast ht
      rw [this, sq]
      have hy1' : (y : ℝ) ≤ (Q : ℝ) - 1 := by exact_mod_cast hy1
      have hz1' : (z : ℝ) ≤ (Q : ℝ) - 1 := by exact_mod_cast hz1
      have hy0' : (0 : ℝ) ≤ y := by exact_mod_cast hy0
      have hz0' : (0 : ℝ) ≤ z := by exact_mod_cast hz0
      nlinarith
    linarith
  have hcardZ : ((Zr Q).card : ℝ) = Q := by simp [card_Zr]
  have hQ2 : (0 : ℝ) < (Q : ℝ) ^ 2 := by positivity
  -- Q² S = ∑_{y,z} ∑_a ... - ∑_{y,z} err
  have hsum : ((Q : ℝ) ^ 2 : ℂ) * S = ∑ y ∈ Zr Q, ∑ z ∈ Zr Q,
      (∑ a ∈ Finset.Icc u v, ee (f (a + (y : ℝ) * z))) -
        ∑ y ∈ Zr Q, ∑ z ∈ Zr Q, (∑ a ∈ Finset.Icc u v, ee (f (a + (y : ℝ) * z)) - S) := by
    rw [← sum_sub_distrib]
    simp_rw [← sum_sub_distrib, sub_sub_cancel]
    rw [sum_const, sum_const, card_Zr, nsmul_eq_mul]
    simp only [nsmul_eq_mul]; push_cast; ring
  have hnorm : (Q : ℝ) ^ 2 * ‖S‖ ≤ ∑ a ∈ Finset.Icc u v,
      ‖∑ y ∈ Zr Q, ∑ z ∈ Zr Q, ee (f (a + (y : ℝ) * z))‖ + (Q : ℝ) ^ 2 * (2 * ((Q : ℝ) - 1) ^ 2) := by
    have := congrArg norm hsum
    rw [norm_mul, ← Complex.ofReal_pow, Complex.norm_real, Real.norm_eq_abs, abs_of_pos hQ2] at this
    rw [this]
    refine (norm_sub_le _ _).trans (add_le_add ?_ ?_)
    · rw [show (∑ y ∈ Zr Q, ∑ z ∈ Zr Q, ∑ a ∈ Finset.Icc u v, ee (f (a + (y : ℝ) * z))) =
          ∑ a ∈ Finset.Icc u v, ∑ y ∈ Zr Q, ∑ z ∈ Zr Q, ee (f (a + (y : ℝ) * z)) by
          exact (sum_congr rfl (fun y _ => Finset.sum_comm)).trans Finset.sum_comm]
      exact norm_sum_le _ _
    · calc ‖∑ y ∈ Zr Q, ∑ z ∈ Zr Q, (∑ a ∈ Finset.Icc u v, ee (f (a + (y : ℝ) * z)) - S)‖
          ≤ ∑ y ∈ Zr Q, ∑ z ∈ Zr Q, ‖∑ a ∈ Finset.Icc u v, ee (f (a + (y : ℝ) * z)) - S‖ :=
            (norm_sum_le _ _).trans (sum_le_sum (fun y _ => norm_sum_le _ _))
        _ ≤ ∑ _y ∈ Zr Q, ∑ _z ∈ Zr Q, 2 * ((Q : ℝ) - 1) ^ 2 :=
            sum_le_sum (fun y hy => sum_le_sum (fun z hz => hyz y hy z hz))
        _ = (Q : ℝ) ^ 2 * (2 * ((Q : ℝ) - 1) ^ 2) := by
            rw [sum_const, sum_const, card_Zr, nsmul_eq_mul, nsmul_eq_mul]; ring
  calc ‖S‖ = ((Q : ℝ) ^ 2 * ‖S‖) / (Q : ℝ) ^ 2 := by field_simp
    _ ≤ (∑ a ∈ Finset.Icc u v, ‖∑ y ∈ Zr Q, ∑ z ∈ Zr Q, ee (f (a + (y : ℝ) * z))‖ +
          (Q : ℝ) ^ 2 * (2 * ((Q : ℝ) - 1) ^ 2)) / (Q : ℝ) ^ 2 :=
        div_le_div_of_nonneg_right hnorm hQ2.le
    _ = _ := by field_simp

end GoldB
