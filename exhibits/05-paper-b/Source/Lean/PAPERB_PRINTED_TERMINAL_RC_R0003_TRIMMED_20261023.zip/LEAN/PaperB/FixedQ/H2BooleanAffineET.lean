import PaperB.FixedQ.H2BooleanETBridge
import PaperB.FixedQ.H2BooleanETConsumer

open scoped BigOperators ComplexConjugate
namespace PaperB.FixedQ

noncomputable def fixedProductBooleanTwistedFrequencyMass
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ) (j : ℕ) : ℝ :=
  ‖fixedProductBooleanFourierCoeff S hPrime
      ((j : ZMod (primeSetProduct S)) * (u : ZMod (primeSetProduct S)))‖

noncomputable def fixedProductBooleanAffineRootIntervalDiscrepancy
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S)) (r : ℕ) : ℝ :=
  ((2 : ℝ) ^ S.card)⁻¹ *
      ∑ A ∈ S.powerset,
        (if (((u : ZMod (primeSetProduct S)) *
              (fixedProductCRTIdempotentNat S A :
                ZMod (primeSetProduct S)) + v).val) < r then 1 else 0)
    - (r : ℝ) / (primeSetProduct S : ℝ)

lemma calder_affine_discrepancy_eq_rootAverage_indicator_sub
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S)) (r : ℕ) :
    fixedProductBooleanAffineRootIntervalDiscrepancy S hPrime u v r =
      calderBooleanRootAverageR S
        (fun x : ZMod (primeSetProduct S) =>
          h3HalfOpenIntervalIndicator r ((u : ZMod (primeSetProduct S)) * x + v)) -
        (r : ℝ) / (primeSetProduct S : ℝ) := by
  unfold fixedProductBooleanAffineRootIntervalDiscrepancy
  unfold calderBooleanRootAverageR h3HalfOpenIntervalIndicator
  rfl

lemma calder_booleanFrequencyMass_neg_mul_unit
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (t : ZMod (primeSetProduct S)) :
    ‖fixedProductBooleanFourierCoeff S hPrime ((-t) * (u : ZMod (primeSetProduct S)))‖ =
      ‖fixedProductBooleanFourierCoeff S hPrime (t * (u : ZMod (primeSetProduct S)))‖ := by
  rw [show (-t) * (u : ZMod (primeSetProduct S)) =
      -(t * (u : ZMod (primeSetProduct S))) by ring]
  exact calder_booleanFrequencyMass_neg S hPrime (t * (u : ZMod (primeSetProduct S)))

lemma calder_booleanCoeff_row_norm_twisted_le
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (J b : ℕ) (hb : b < J + 1) :
    (∑ a ∈ Finset.range (J + 1),
      ‖fixedProductBooleanFourierCoeff S hPrime
        (((a : ZMod (primeSetProduct S)) -
          (b : ZMod (primeSetProduct S))) * (u : ZMod (primeSetProduct S)))‖) ≤
      1 + 2 * ∑ j ∈ Finset.Icc 1 J,
        fixedProductBooleanTwistedFrequencyMass S hPrime u j := by
  letI : NeZero (primeSetProduct S) := ⟨(primeSetProduct_pos hPrime).ne'⟩
  let F : ℕ → ℝ := fun j => fixedProductBooleanTwistedFrequencyMass S hPrime u j
  let g : ℕ → ℝ := fun a =>
    ‖fixedProductBooleanFourierCoeff S hPrime
      (((a : ZMod (primeSetProduct S)) -
        (b : ZMod (primeSetProduct S))) * (u : ZMod (primeSetProduct S)))‖
  have hbJ : b ≤ J := by omega
  have hF0 : ∀ j ∈ Finset.Icc 1 J, 0 ≤ F j := by
    intro j hj
    exact norm_nonneg _
  have hdiag : g b = 1 := by
    dsimp [g]
    rw [sub_self, zero_mul, calder_booleanFourierCoeff_zero]
    norm_num
  have hleft :
      (∑ a ∈ Finset.range b, g a) ≤
        ∑ j ∈ Finset.Icc 1 J, F j := by
    calc
      (∑ a ∈ Finset.range b, g a) =
          ∑ a ∈ Finset.range b, F (b - a) := by
            apply Finset.sum_congr rfl
            intro a ha
            have hab : a < b := Finset.mem_range.mp ha
            dsimp [g, F, fixedProductBooleanTwistedFrequencyMass]
            have hcast :
                ((b - a : ℕ) : ZMod (primeSetProduct S)) =
                  (b : ZMod (primeSetProduct S)) -
                    (a : ZMod (primeSetProduct S)) := by
              rw [Nat.cast_sub (Nat.le_of_lt hab)]
            have hneg :
                ((a : ZMod (primeSetProduct S)) -
                    (b : ZMod (primeSetProduct S))) * (u : ZMod (primeSetProduct S)) =
                  -(((b - a : ℕ) : ZMod (primeSetProduct S)) *
                    (u : ZMod (primeSetProduct S))) := by
              rw [hcast]
              ring
            rw [hneg, calder_booleanFrequencyMass_neg]
      _ = ∑ k ∈ Finset.range b, F (k + 1) := by
            rw [← Finset.sum_range_reflect (fun k => F (k + 1)) b]
            apply Finset.sum_congr rfl
            intro a ha
            congr 1
            have hab : a < b := Finset.mem_range.mp ha
            omega
      _ = ∑ j ∈ Finset.Icc 1 b, F j :=
            calder_sum_range_succ_shift_eq_Icc F b
      _ ≤ ∑ j ∈ Finset.Icc 1 J, F j :=
            calder_sum_Icc_mono_of_nonneg F hbJ hF0
  have hright :
      (∑ k ∈ Finset.range (J - b), g (b + (1 + k))) ≤
        ∑ j ∈ Finset.Icc 1 J, F j := by
    calc
      (∑ k ∈ Finset.range (J - b), g (b + (1 + k))) =
          ∑ k ∈ Finset.range (J - b), F (k + 1) := by
            apply Finset.sum_congr rfl
            intro k hk
            dsimp [g, F, fixedProductBooleanTwistedFrequencyMass]
            simp only [Nat.cast_add, Nat.cast_one]
            congr 2
            ring
      _ = ∑ j ∈ Finset.Icc 1 (J - b), F j :=
            calder_sum_range_succ_shift_eq_Icc F (J - b)
      _ ≤ ∑ j ∈ Finset.Icc 1 J, F j :=
            calder_sum_Icc_mono_of_nonneg F (Nat.sub_le J b) hF0
  have hsplit :
      (∑ a ∈ Finset.range (J + 1), g a) =
        (∑ a ∈ Finset.range b, g a) + g b +
          ∑ k ∈ Finset.range (J - b), g (b + (1 + k)) := by
    rw [show J + 1 = b + (1 + (J - b)) by omega]
    rw [Finset.sum_range_add, Finset.sum_range_add]
    simp
    ring
  rw [show (∑ a ∈ Finset.range (J + 1),
      ‖fixedProductBooleanFourierCoeff S hPrime
        (((a : ZMod (primeSetProduct S)) -
          (b : ZMod (primeSetProduct S))) * (u : ZMod (primeSetProduct S)))‖) =
      ∑ a ∈ Finset.range (J + 1), g a by rfl]
  rw [hsplit, hdiag]
  dsimp [F] at hleft hright ⊢
  linarith

lemma calderBooleanRootAverageC_stdAddChar_affine_translate
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (u : (ZMod (primeSetProduct S))ˣ)
    (v t c : ZMod (primeSetProduct S)) :
    calderBooleanRootAverageC S
      (fun x => ZMod.stdAddChar
        (t * (((u : ZMod (primeSetProduct S)) * x + v) - c))) =
      ZMod.stdAddChar (t * (v - c)) *
        fixedProductBooleanFourierCoeff S hPrime
          (t * (u : ZMod (primeSetProduct S))) := by
  have hfun :
      (fun x : ZMod (primeSetProduct S) =>
        ZMod.stdAddChar (t * (((u : ZMod (primeSetProduct S)) * x + v) - c))) =
      (fun x =>
        ZMod.stdAddChar (t * (v - c)) *
          ZMod.stdAddChar ((t * (u : ZMod (primeSetProduct S))) * x)) := by
    funext x
    rw [← AddChar.map_add_eq_mul]
    congr 1
    ring
  rw [hfun, calderBooleanRootAverageC_const_mul,
    calderBooleanRootAverageC_stdAddChar]

#print axioms calder_booleanCoeff_row_norm_twisted_le
#print axioms calderBooleanRootAverageC_stdAddChar_affine_translate
#print axioms calder_affine_discrepancy_eq_rootAverage_indicator_sub

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma calder_booleanAverage_fejer_normsq_affine_translate_eq_double
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S))
    (L : ℕ) (c : ZMod (primeSetProduct S)) :
    ((calderBooleanRootAverageR S
      (fun x : ZMod (primeSetProduct S) =>
        ‖∑ k ∈ Finset.range L,
          (ZMod.stdAddChar (((u : ZMod (primeSetProduct S)) * x + v) - c)) ^ k‖ ^ 2) : ℝ) : ℂ) =
      ∑ b ∈ Finset.range L, ∑ a ∈ Finset.range L,
        ZMod.stdAddChar
          ((((a : ZMod (primeSetProduct S)) -
              (b : ZMod (primeSetProduct S))) * (v - c))) *
        fixedProductBooleanFourierCoeff S hPrime
          (((a : ZMod (primeSetProduct S)) -
              (b : ZMod (primeSetProduct S))) *
            (u : ZMod (primeSetProduct S))) := by
  rw [← calderBooleanRootAverageC_ofReal]
  have hpoint :
      (fun x : ZMod (primeSetProduct S) =>
        ((‖∑ k ∈ Finset.range L,
          (ZMod.stdAddChar (((u : ZMod (primeSetProduct S)) * x + v) - c)) ^ k‖ ^ 2 : ℝ) : ℂ)) =
      (fun x =>
        ∑ b ∈ Finset.range L, ∑ a ∈ Finset.range L,
          ZMod.stdAddChar
            ((((a : ZMod (primeSetProduct S)) -
              (b : ZMod (primeSetProduct S)))) *
                (((u : ZMod (primeSetProduct S)) * x + v) - c))) := by
    funext x
    exact calder_fejer_norm_sq_expand
      (((u : ZMod (primeSetProduct S)) * x + v) - c)
  rw [hpoint, calderBooleanRootAverageC_sum]
  apply Finset.sum_congr rfl
  intro b hb
  rw [calderBooleanRootAverageC_sum]
  apply Finset.sum_congr rfl
  intro a ha
  exact calderBooleanRootAverageC_stdAddChar_affine_translate
    S hPrime u v
      ((a : ZMod (primeSetProduct S)) - (b : ZMod (primeSetProduct S))) c

lemma calder_booleanAverage_fejer_normsq_affine_translate_le
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S))
    (J : ℕ) (c : ZMod (primeSetProduct S)) :
    calderBooleanRootAverageR S
      (fun x : ZMod (primeSetProduct S) =>
        ‖∑ k ∈ Finset.range (J + 1),
          (ZMod.stdAddChar (((u : ZMod (primeSetProduct S)) * x + v) - c)) ^ k‖ ^ 2) ≤
      (J + 1 : ℝ) *
        (1 + 2 * ∑ j ∈ Finset.Icc 1 J,
          fixedProductBooleanTwistedFrequencyMass S hPrime u j) := by
  let A : ℝ :=
    calderBooleanRootAverageR S
      (fun x : ZMod (primeSetProduct S) =>
        ‖∑ k ∈ Finset.range (J + 1),
          (ZMod.stdAddChar (((u : ZMod (primeSetProduct S)) * x + v) - c)) ^ k‖ ^ 2)
  let T : ℝ := ∑ j ∈ Finset.Icc 1 J,
    fixedProductBooleanTwistedFrequencyMass S hPrime u j
  have hA0 : 0 ≤ A := by
    dsimp [A, calderBooleanRootAverageR]
    positivity
  have heq :=
    calder_booleanAverage_fejer_normsq_affine_translate_eq_double
      S hPrime u v (J + 1) c
  have hnorm : A = ‖(A : ℂ)‖ := by
    rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg hA0]
  change A ≤ ((J : ℝ) + 1) * (1 + 2 * T)
  rw [hnorm]
  rw [show (A : ℂ) =
      ∑ b ∈ Finset.range (J + 1), ∑ a ∈ Finset.range (J + 1),
        ZMod.stdAddChar
          ((((a : ZMod (primeSetProduct S)) -
              (b : ZMod (primeSetProduct S))) * (v - c))) *
        fixedProductBooleanFourierCoeff S hPrime
          (((a : ZMod (primeSetProduct S)) -
              (b : ZMod (primeSetProduct S))) *
            (u : ZMod (primeSetProduct S))) by
      simpa [A] using heq]
  calc
    ‖∑ b ∈ Finset.range (J + 1), ∑ a ∈ Finset.range (J + 1),
        ZMod.stdAddChar
          ((((a : ZMod (primeSetProduct S)) -
              (b : ZMod (primeSetProduct S))) * (v - c))) *
        fixedProductBooleanFourierCoeff S hPrime
          (((a : ZMod (primeSetProduct S)) -
              (b : ZMod (primeSetProduct S))) *
            (u : ZMod (primeSetProduct S)))‖
      ≤ ∑ b ∈ Finset.range (J + 1),
          ‖∑ a ∈ Finset.range (J + 1),
            ZMod.stdAddChar
              ((((a : ZMod (primeSetProduct S)) -
                (b : ZMod (primeSetProduct S))) * (v - c))) *
            fixedProductBooleanFourierCoeff S hPrime
              (((a : ZMod (primeSetProduct S)) -
                (b : ZMod (primeSetProduct S))) *
                (u : ZMod (primeSetProduct S)))‖ := norm_sum_le _ _
    _ ≤ ∑ b ∈ Finset.range (J + 1),
          ∑ a ∈ Finset.range (J + 1),
            ‖fixedProductBooleanFourierCoeff S hPrime
              (((a : ZMod (primeSetProduct S)) -
                (b : ZMod (primeSetProduct S))) *
                (u : ZMod (primeSetProduct S)))‖ := by
        apply Finset.sum_le_sum
        intro b hb
        calc
          ‖∑ a ∈ Finset.range (J + 1),
            ZMod.stdAddChar
              ((((a : ZMod (primeSetProduct S)) -
                (b : ZMod (primeSetProduct S))) * (v - c))) *
            fixedProductBooleanFourierCoeff S hPrime
              (((a : ZMod (primeSetProduct S)) -
                (b : ZMod (primeSetProduct S))) *
                (u : ZMod (primeSetProduct S)))‖
            ≤ ∑ a ∈ Finset.range (J + 1),
              ‖ZMod.stdAddChar
                ((((a : ZMod (primeSetProduct S)) -
                  (b : ZMod (primeSetProduct S))) * (v - c))) *
              fixedProductBooleanFourierCoeff S hPrime
                (((a : ZMod (primeSetProduct S)) -
                  (b : ZMod (primeSetProduct S))) *
                  (u : ZMod (primeSetProduct S)))‖ := norm_sum_le _ _
          _ = ∑ a ∈ Finset.range (J + 1),
              ‖fixedProductBooleanFourierCoeff S hPrime
                (((a : ZMod (primeSetProduct S)) -
                  (b : ZMod (primeSetProduct S))) *
                  (u : ZMod (primeSetProduct S)))‖ := by
              apply Finset.sum_congr rfl
              intro a ha
              rw [norm_mul, norm_stdAddChar_eq_one, one_mul]
    _ ≤ ∑ b ∈ Finset.range (J + 1), (1 + 2 * T) := by
        apply Finset.sum_le_sum
        intro b hb
        have hb' : b < J + 1 := Finset.mem_range.mp hb
        simpa [T] using
          calder_booleanCoeff_row_norm_twisted_le S hPrime u J b hb'
    _ = (J + 1 : ℝ) * (1 + 2 * T) := by
        simp [nsmul_eq_mul]
        ring
    _ = _ := by ring

lemma calderBooleanRootAverageR_stdAddChar_affine_translate_im
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (u : (ZMod (primeSetProduct S))ˣ)
    (v t c : ZMod (primeSetProduct S)) :
    calderBooleanRootAverageR S
      (fun x =>
        (ZMod.stdAddChar
          (t * (((u : ZMod (primeSetProduct S)) * x + v) - c))).im) =
      (ZMod.stdAddChar (t * (v - c)) *
        fixedProductBooleanFourierCoeff S hPrime
          (t * (u : ZMod (primeSetProduct S)))).im := by
  rw [calderBooleanRootAverageR_im]
  rw [calderBooleanRootAverageC_stdAddChar_affine_translate]

lemma calder_booleanAverage_h3VaalerApprox_affine_translate_eq
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S))
    (J : ℕ) (c : ZMod (primeSetProduct S)) :
    calderBooleanRootAverageR S
      (fun x : ZMod (primeSetProduct S) =>
        h3VaalerApprox (primeSetProduct S) J
          (((u : ZMod (primeSetProduct S)) * x + v) - c)) =
      - ∑ j ∈ Finset.Icc 1 J,
        (h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
          (ZMod.stdAddChar
              ((j : ZMod (primeSetProduct S)) * (v - c)) *
            fixedProductBooleanFourierCoeff S hPrime
              ((j : ZMod (primeSetProduct S)) *
                (u : ZMod (primeSetProduct S)))).im := by
  unfold h3VaalerApprox
  rw [calderBooleanRootAverageR_neg]
  rw [calderBooleanRootAverageR_sum]
  congr 1
  apply Finset.sum_congr rfl
  intro j hj
  rw [calderBooleanRootAverageR_const_mul]
  rw [calderBooleanRootAverageR_stdAddChar_affine_translate_im]

lemma calder_abs_booleanAverage_h3VaalerApprox_affine_translate_le
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S))
    (J : ℕ) (c : ZMod (primeSetProduct S)) :
    |calderBooleanRootAverageR S
      (fun x : ZMod (primeSetProduct S) =>
        h3VaalerApprox (primeSetProduct S) J
          (((u : ZMod (primeSetProduct S)) * x + v) - c))| ≤
      ∑ j ∈ Finset.Icc 1 J,
        fixedProductBooleanTwistedFrequencyMass S hPrime u j / (j : ℝ) := by
  rw [calder_booleanAverage_h3VaalerApprox_affine_translate_eq
    S hPrime u v J c]
  rw [abs_neg]
  calc
    |∑ j ∈ Finset.Icc 1 J,
        (h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
          (ZMod.stdAddChar
              ((j : ZMod (primeSetProduct S)) * (v - c)) *
            fixedProductBooleanFourierCoeff S hPrime
              ((j : ZMod (primeSetProduct S)) *
                (u : ZMod (primeSetProduct S)))).im|
      ≤ ∑ j ∈ Finset.Icc 1 J,
          |(h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
            (ZMod.stdAddChar
                ((j : ZMod (primeSetProduct S)) * (v - c)) *
              fixedProductBooleanFourierCoeff S hPrime
                ((j : ZMod (primeSetProduct S)) *
                  (u : ZMod (primeSetProduct S)))).im| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ j ∈ Finset.Icc 1 J,
        fixedProductBooleanTwistedFrequencyMass S hPrime u j / (j : ℝ) := by
      apply Finset.sum_le_sum
      intro j hj
      have hw := calder_vaaler_weight_le_one_div hj
      have him :
          |(ZMod.stdAddChar
              ((j : ZMod (primeSetProduct S)) * (v - c)) *
            fixedProductBooleanFourierCoeff S hPrime
              ((j : ZMod (primeSetProduct S)) *
                (u : ZMod (primeSetProduct S)))).im| ≤
            fixedProductBooleanTwistedFrequencyMass S hPrime u j := by
        calc
          |(ZMod.stdAddChar
              ((j : ZMod (primeSetProduct S)) * (v - c)) *
            fixedProductBooleanFourierCoeff S hPrime
              ((j : ZMod (primeSetProduct S)) *
                (u : ZMod (primeSetProduct S)))).im|
            ≤ ‖ZMod.stdAddChar
                ((j : ZMod (primeSetProduct S)) * (v - c)) *
              fixedProductBooleanFourierCoeff S hPrime
                ((j : ZMod (primeSetProduct S)) *
                  (u : ZMod (primeSetProduct S)))‖ :=
              Complex.abs_im_le_norm _
          _ = fixedProductBooleanTwistedFrequencyMass S hPrime u j := by
              rw [norm_mul, norm_stdAddChar_eq_one, one_mul]
              rfl
      rw [abs_mul, abs_of_nonneg hw.1]
      calc
        (h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
            |(ZMod.stdAddChar
                ((j : ZMod (primeSetProduct S)) * (v - c)) *
              fixedProductBooleanFourierCoeff S hPrime
                ((j : ZMod (primeSetProduct S)) *
                  (u : ZMod (primeSetProduct S)))).im|
          ≤ (1 / (j : ℝ)) *
              fixedProductBooleanTwistedFrequencyMass S hPrime u j := by
                exact mul_le_mul hw.2 him (abs_nonneg _) (by positivity)
        _ = fixedProductBooleanTwistedFrequencyMass S hPrime u j / (j : ℝ) := by
              ring

lemma calder_booleanAverage_h3VaalerError_affine_translate_le
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S))
    (J : ℕ) (c : ZMod (primeSetProduct S)) :
    calderBooleanRootAverageR S
      (fun x : ZMod (primeSetProduct S) =>
        h3VaalerError (primeSetProduct S) J
          (((u : ZMod (primeSetProduct S)) * x + v) - c)) ≤
      (1 + 2 * ∑ j ∈ Finset.Icc 1 J,
        fixedProductBooleanTwistedFrequencyMass S hPrime u j) /
        (2 * ((J + 1 : ℕ) : ℝ)) := by
  let M : ℝ := ∑ j ∈ Finset.Icc 1 J,
    fixedProductBooleanTwistedFrequencyMass S hPrime u j
  have hN :=
    calder_booleanAverage_fejer_normsq_affine_translate_le
      S hPrime u v J c
  have hJpos : (0 : ℝ) < ((J + 1 : ℕ) : ℝ) := by positivity
  unfold h3VaalerError h3FejerKernel
  rw [calderBooleanRootAverageR_const_mul]
  rw [calderBooleanRootAverageR_const_mul]
  calc
    (1 / (2 * ((J + 1 : ℕ) : ℝ))) *
        ((((J + 1 : ℕ) : ℝ))⁻¹ *
          calderBooleanRootAverageR S
            (fun x : ZMod (primeSetProduct S) =>
              ‖∑ k ∈ Finset.range (J + 1),
                (ZMod.stdAddChar
                  (((u : ZMod (primeSetProduct S)) * x + v) - c)) ^ k‖ ^ 2))
      ≤ (1 / (2 * ((J + 1 : ℕ) : ℝ))) *
          ((((J + 1 : ℕ) : ℝ))⁻¹ *
            (((J + 1 : ℕ) : ℝ) * (1 + 2 * M))) := by
              gcongr
              simpa [M] using hN
    _ = (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) := by
          field_simp [hJpos.ne']
    _ = _ := by rfl

#print axioms calder_booleanAverage_fejer_normsq_affine_translate_le
#print axioms calder_abs_booleanAverage_h3VaalerApprox_affine_translate_le
#print axioms calder_booleanAverage_h3VaalerError_affine_translate_le

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem fixedProductBooleanAffineRootInterval_erdosTuran_of_grid_error
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S))
    (r J : ℕ)
    (hr : r < primeSetProduct S)
    (hJ : 1 ≤ J)
    (hGrid : @H3VaalerGridErrorSpec (primeSetProduct S) J
      ⟨(primeSetProduct_pos hPrime).ne'⟩) :
    |fixedProductBooleanAffineRootIntervalDiscrepancy S hPrime u v r| ≤
      4 / (J : ℝ) +
        4 * ∑ j ∈ Finset.Icc 1 J,
          fixedProductBooleanTwistedFrequencyMass S hPrime u j / (j : ℝ) := by
  let N := primeSetProduct S
  letI : NeZero N := ⟨(primeSetProduct_pos hPrime).ne'⟩
  let R : ZMod N := (r : ZMod N)
  let H : ℝ := ∑ j ∈ Finset.Icc 1 J,
    fixedProductBooleanTwistedFrequencyMass S hPrime u j / (j : ℝ)
  let M : ℝ := ∑ j ∈ Finset.Icc 1 J,
    fixedProductBooleanTwistedFrequencyMass S hPrime u j
  have hH0 : 0 ≤ H := by
    dsimp [H]
    apply Finset.sum_nonneg
    intro j hj
    exact div_nonneg (norm_nonneg _) (by positivity)
  have hM0 : 0 ≤ M := by
    dsimp [M]
    apply Finset.sum_nonneg
    intro j hj
    exact norm_nonneg _
  have hJpos : (0 : ℝ) < (J : ℝ) := by
    exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hJ)
  have hJ1pos : (0 : ℝ) < ((J + 1 : ℕ) : ℝ) := by positivity
  have hInd :
      fixedProductBooleanAffineRootIntervalDiscrepancy S hPrime u v r =
        calderBooleanRootAverageR S
          (fun x : ZMod N =>
            h3HalfOpenIntervalIndicator r ((u : ZMod N) * x + v)) -
          (r : ℝ) / (N : ℝ) := by
    simpa [N] using
      calder_affine_discrepancy_eq_rootAverage_indicator_sub
        S hPrime u v r
  have hSand : ∀ x : ZMod N,
      h3IntervalLowerMinorant N r J ((u : ZMod N) * x + v) ≤
          h3HalfOpenIntervalIndicator r ((u : ZMod N) * x + v) ∧
      h3HalfOpenIntervalIndicator r ((u : ZMod N) * x + v) ≤
          h3IntervalUpperMajorant N r J ((u : ZMod N) * x + v) := by
    intro x
    exact fixedProductBooleanRootInterval_selberg_majorant_of_grid_error
      (N := N) (r := r) (J := J) (by simpa [N] using hr) hGrid
      ((u : ZMod N) * x + v)
  have hLow := calderBooleanRootAverageR_mono S (fun x => (hSand x).1)
  have hUp := calderBooleanRootAverageR_mono S (fun x => (hSand x).2)
  have hSawR :=
    calder_abs_booleanAverage_h3VaalerApprox_affine_translate_le
      S hPrime u v J R
  have hSaw0 :=
    calder_abs_booleanAverage_h3VaalerApprox_affine_translate_le
      S hPrime u v J (0 : ZMod N)
  have hErrR :=
    calder_booleanAverage_h3VaalerError_affine_translate_le
      S hPrime u v J R
  have hErr0 :=
    calder_booleanAverage_h3VaalerError_affine_translate_le
      S hPrime u v J (0 : ZMod N)
  have hA0 :
      calderBooleanRootAverageR S
        (fun x : ZMod N =>
          h3VaalerApprox N J ((u : ZMod N) * x + v)) =
      calderBooleanRootAverageR S
        (fun x : ZMod N =>
          h3VaalerApprox N J (((u : ZMod N) * x + v) - (0 : ZMod N))) := by
    congr 1
    funext x
    simp
  rw [← hA0] at hSaw0
  have hE0 :
      calderBooleanRootAverageR S
        (fun x : ZMod N =>
          h3VaalerError N J ((u : ZMod N) * x + v)) =
      calderBooleanRootAverageR S
        (fun x : ZMod N =>
          h3VaalerError N J (((u : ZMod N) * x + v) - (0 : ZMod N))) := by
    congr 1
    funext x
    simp
  rw [← hE0] at hErr0
  have hM_to_H :
      M / ((J + 1 : ℕ) : ℝ) ≤ H := by
    have hrewrite :
        M / ((J + 1 : ℕ) : ℝ) =
          ∑ j ∈ Finset.Icc 1 J,
            fixedProductBooleanTwistedFrequencyMass S hPrime u j /
              ((J + 1 : ℕ) : ℝ) := by
      dsimp [M]
      rw [Finset.sum_div]
    rw [hrewrite]
    dsimp [H]
    apply Finset.sum_le_sum
    intro j hj
    have hjJ : j ≤ J := (Finset.mem_Icc.mp hj).2
    have hjpos : (0 : ℝ) < (j : ℝ) := by
      have hj1 : 1 ≤ j := (Finset.mem_Icc.mp hj).1
      exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hj1)
    have hm0 : 0 ≤ fixedProductBooleanTwistedFrequencyMass S hPrime u j :=
      norm_nonneg _
    have hden : (j : ℝ) ≤ ((J + 1 : ℕ) : ℝ) := by
      exact_mod_cast Nat.le_succ_of_le hjJ
    have hinv :
        1 / ((J + 1 : ℕ) : ℝ) ≤ 1 / (j : ℝ) :=
      one_div_le_one_div_of_le hjpos hden
    calc
      fixedProductBooleanTwistedFrequencyMass S hPrime u j /
          ((J + 1 : ℕ) : ℝ)
        = fixedProductBooleanTwistedFrequencyMass S hPrime u j *
            (1 / ((J + 1 : ℕ) : ℝ)) := by ring
      _ ≤ fixedProductBooleanTwistedFrequencyMass S hPrime u j *
            (1 / (j : ℝ)) := mul_le_mul_of_nonneg_left hinv hm0
      _ = fixedProductBooleanTwistedFrequencyMass S hPrime u j / (j : ℝ) := by ring
  have hErrSum :
      calderBooleanRootAverageR S
          (fun x : ZMod N =>
            h3VaalerError N J (((u : ZMod N) * x + v) - R)) +
        calderBooleanRootAverageR S
          (fun x : ZMod N =>
            h3VaalerError N J ((u : ZMod N) * x + v)) ≤
        1 / ((J + 1 : ℕ) : ℝ) + 2 * H := by
    have hs := add_le_add hErrR hErr0
    have hs' :
        calderBooleanRootAverageR S
            (fun x : ZMod N =>
              h3VaalerError N J (((u : ZMod N) * x + v) - R)) +
          calderBooleanRootAverageR S
            (fun x : ZMod N =>
              h3VaalerError N J ((u : ZMod N) * x + v)) ≤
          (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) +
          (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) := by
      simpa [N, M] using hs
    have hcalc :
        (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) +
          (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) =
          1 / ((J + 1 : ℕ) : ℝ) +
            2 * (M / ((J + 1 : ℕ) : ℝ)) := by
      field_simp [hJ1pos.ne']
      ring
    calc
      calderBooleanRootAverageR S
          (fun x : ZMod N =>
            h3VaalerError N J (((u : ZMod N) * x + v) - R)) +
        calderBooleanRootAverageR S
          (fun x : ZMod N =>
            h3VaalerError N J ((u : ZMod N) * x + v))
        ≤ (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) +
          (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) := hs'
      _ = 1 / ((J + 1 : ℕ) : ℝ) +
            2 * (M / ((J + 1 : ℕ) : ℝ)) := hcalc
      _ ≤ 1 / ((J + 1 : ℕ) : ℝ) + 2 * H := by
            gcongr
  have hSawDiff :
      |calderBooleanRootAverageR S
          (fun x : ZMod N =>
            h3VaalerApprox N J (((u : ZMod N) * x + v) - R)) -
        calderBooleanRootAverageR S
          (fun x : ZMod N =>
            h3VaalerApprox N J ((u : ZMod N) * x + v))| ≤ 2 * H := by
    calc
      |calderBooleanRootAverageR S
          (fun x : ZMod N =>
            h3VaalerApprox N J (((u : ZMod N) * x + v) - R)) -
        calderBooleanRootAverageR S
          (fun x : ZMod N =>
            h3VaalerApprox N J ((u : ZMod N) * x + v))|
        ≤ |calderBooleanRootAverageR S
            (fun x : ZMod N =>
              h3VaalerApprox N J (((u : ZMod N) * x + v) - R))| +
          |calderBooleanRootAverageR S
            (fun x : ZMod N =>
              h3VaalerApprox N J ((u : ZMod N) * x + v))| := abs_sub _ _
      _ ≤ H + H := by
        exact add_le_add
          (by simpa [N, H, fixedProductBooleanTwistedFrequencyMass] using hSawR)
          (by simpa [N, H, fixedProductBooleanTwistedFrequencyMass] using hSaw0)
      _ = 2 * H := by ring
  have hCenteredUp :
      fixedProductBooleanAffineRootIntervalDiscrepancy S hPrime u v r ≤
        (calderBooleanRootAverageR S
            (fun x : ZMod N =>
              h3VaalerApprox N J (((u : ZMod N) * x + v) - R)) -
          calderBooleanRootAverageR S
            (fun x : ZMod N =>
              h3VaalerApprox N J ((u : ZMod N) * x + v))) +
        calderBooleanRootAverageR S
            (fun x : ZMod N =>
              h3VaalerError N J (((u : ZMod N) * x + v) - R)) +
        calderBooleanRootAverageR S
            (fun x : ZMod N =>
              h3VaalerError N J ((u : ZMod N) * x + v)) := by
    rw [hInd]
    have hUp' := hUp
    unfold h3IntervalUpperMajorant h3IntervalUpperCentered at hUp'
    rw [calderBooleanRootAverageR_add] at hUp'
    rw [calderBooleanRootAverageR_add] at hUp'
    rw [calderBooleanRootAverageR_add] at hUp'
    rw [calderBooleanRootAverageR_sub] at hUp'
    rw [calderBooleanRootAverageR_const] at hUp'
    dsimp [R] at hUp' ⊢
    linarith
  have hCenteredLow :
      - fixedProductBooleanAffineRootIntervalDiscrepancy S hPrime u v r ≤
        -(calderBooleanRootAverageR S
            (fun x : ZMod N =>
              h3VaalerApprox N J (((u : ZMod N) * x + v) - R)) -
          calderBooleanRootAverageR S
            (fun x : ZMod N =>
              h3VaalerApprox N J ((u : ZMod N) * x + v))) +
        calderBooleanRootAverageR S
            (fun x : ZMod N =>
              h3VaalerError N J (((u : ZMod N) * x + v) - R)) +
        calderBooleanRootAverageR S
            (fun x : ZMod N =>
              h3VaalerError N J ((u : ZMod N) * x + v)) := by
    rw [hInd]
    have hLow' := hLow
    unfold h3IntervalLowerMinorant h3IntervalLowerCentered at hLow'
    rw [calderBooleanRootAverageR_add] at hLow'
    rw [calderBooleanRootAverageR_sub] at hLow'
    rw [calderBooleanRootAverageR_sub] at hLow'
    rw [calderBooleanRootAverageR_sub] at hLow'
    rw [calderBooleanRootAverageR_const] at hLow'
    dsimp [R] at hLow' ⊢
    linarith
  have hCore :
      |fixedProductBooleanAffineRootIntervalDiscrepancy S hPrime u v r| ≤
        1 / ((J + 1 : ℕ) : ℝ) + 4 * H := by
    rw [abs_le]
    have hSawLower := (abs_le.mp hSawDiff).1
    have hSawUpper := (abs_le.mp hSawDiff).2
    constructor <;> linarith [hCenteredLow, hCenteredUp, hErrSum]
  calc
    |fixedProductBooleanAffineRootIntervalDiscrepancy S hPrime u v r|
      ≤ 1 / ((J + 1 : ℕ) : ℝ) + 4 * H := hCore
    _ ≤ 4 / (J : ℝ) + 4 * H := by
      have hden : (J : ℝ) ≤ ((J + 1 : ℕ) : ℝ) := by
        exact_mod_cast Nat.le_succ J
      have hinv :
          1 / ((J + 1 : ℕ) : ℝ) ≤ 1 / (J : ℝ) :=
        one_div_le_one_div_of_le hJpos hden
      have hposinv : 0 < 1 / (J : ℝ) := one_div_pos.mpr hJpos
      have h1to4 : 1 / (J : ℝ) ≤ 4 / (J : ℝ) := by
        calc
          1 / (J : ℝ) = 1 * (1 / (J : ℝ)) := by ring
          _ ≤ 4 * (1 / (J : ℝ)) :=
            mul_le_mul_of_nonneg_right (by norm_num) hposinv.le
          _ = 4 / (J : ℝ) := by ring
      exact add_le_add (hinv.trans h1to4) (le_refl (4 * H))
    _ = _ := by rfl

theorem fixedProductBooleanAffineRootInterval_erdosTuran
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S))
    (r J : ℕ)
    (hr : r < primeSetProduct S)
    (hJ : 1 ≤ J) :
    |fixedProductBooleanAffineRootIntervalDiscrepancy S hPrime u v r| ≤
      4 / (J : ℝ) +
        4 * ∑ j ∈ Finset.Icc 1 J,
          fixedProductBooleanTwistedFrequencyMass S hPrime u j / (j : ℝ) := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  exact fixedProductBooleanAffineRootInterval_erdosTuran_of_grid_error
    S hPrime u v r J hr hJ
    (h3VaalerGridErrorSpec_holds (primeSetProduct S) J)

theorem fixedProductBooleanAffineRootInterval_erdosTuran_sq
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S))
    (r J : ℕ)
    (hr : r < primeSetProduct S)
    (hJ : 1 ≤ J) :
    (fixedProductBooleanAffineRootIntervalDiscrepancy S hPrime u v r) ^ 2 ≤
      32 / ((J : ℝ) ^ 2) +
      32 * (1 + Real.log (J : ℝ)) *
        (∑ j ∈ Finset.Icc 1 J,
          (fixedProductBooleanTwistedFrequencyMass S hPrime u j) ^ 2 /
            (j : ℝ)) := by
  apply erdosTuran_square_after_boolean_average
    (fixedProductBooleanAffineRootIntervalDiscrepancy S hPrime u v r)
    (fun j => fixedProductBooleanTwistedFrequencyMass S hPrime u j) J hJ
  · intro j hj
    exact norm_nonneg _
  · exact fixedProductBooleanAffineRootInterval_erdosTuran
      S hPrime u v r J hr hJ

#print axioms fixedProductBooleanAffineRootInterval_erdosTuran
#print axioms fixedProductBooleanAffineRootInterval_erdosTuran_sq

end PaperB.FixedQ
