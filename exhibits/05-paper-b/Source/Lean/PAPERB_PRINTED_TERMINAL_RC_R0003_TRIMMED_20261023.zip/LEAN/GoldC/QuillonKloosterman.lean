import Mathlib.NumberTheory.LegendreSymbol.AddCharacter
import Mathlib.Analysis.SpecialFunctions.Complex.CircleAddChar
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic

/-!
# Quillon CSC3 F1: Kloosterman's bound `|K(a,b;p)| ≤ 3^{1/4} p^{3/4}` (fourth moment)

Elementary (Kloosterman 1926). Works over any finite field `F` with a primitive additive character
`ψ : AddChar F ℂ`. Over `ZMod p` the standard character is `ZMod.stdAddChar`.

* `kl ψ a b = Σ_{x ≠ 0} ψ(a x + b x⁻¹)`.
* `kl_scale`: `kl ψ a (n a⁻¹) = kl ψ 1 n` for `a ≠ 0`.
* `fourth_moment`: `Σ_{a,b} ‖kl ψ a b‖^4 = q² · N`, where `N` counts the nonzero solutions of
  `x₁+x₂ = y₁+y₂ ∧ x₁⁻¹+x₂⁻¹ = y₁⁻¹+y₂⁻¹`.
* `count_le`: `N ≤ 3 (q-1)²`.
* `kloosterman_bound`: `‖kl ψ 1 n‖^4 ≤ 3 q² (q-1)`, so `‖K‖ ≤ 3^{1/4} q^{3/4}`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonKloosterman

variable {F : Type*} [Field F] [Fintype F] [DecidableEq F]

/-- The Kloosterman sum. -/
noncomputable def kl (ψ : AddChar F ℂ) (a b : F) : ℂ :=
  ∑ x ∈ univ.erase (0 : F), ψ (a * x + b * x⁻¹)

lemma kl_scale (ψ : AddChar F ℂ) (a n : F) (ha : a ≠ 0) : kl ψ a (n * a⁻¹) = kl ψ 1 n := by
  unfold kl
  refine Finset.sum_nbij' (fun x => a * x) (fun y => a⁻¹ * y) ?_ ?_ ?_ ?_ ?_
  · intro x hx
    have hx' : x ≠ 0 := by simpa using hx
    simpa using mul_ne_zero ha hx'
  · intro y hy
    have hy' : y ≠ 0 := by simpa using hy
    simpa using mul_ne_zero (inv_ne_zero ha) hy'
  · intro x _; field_simp
  · intro y _; field_simp
  · intro x hx
    simp only [mem_erase] at hx
    congr 1
    field_simp

omit [DecidableEq F] in
/-- `conj ψ(t) = ψ(-t)` for a character into `ℂ` on a finite ring of positive characteristic. -/
lemma conj_apply (ψ : AddChar F ℂ) (t : F) : (starRingEnd ℂ) (ψ t) = ψ (-t) := by
  have hR : 0 < ringChar F := Nat.Prime.pos (CharP.char_is_prime F (ringChar F))
  rw [AddChar.starComp_apply hR, AddChar.map_neg_eq_inv, AddChar.inv_apply']

lemma conj_kl (ψ : AddChar F ℂ) (a b : F) : (starRingEnd ℂ) (kl ψ a b) = kl ψ (-a) (-b) := by
  unfold kl
  rw [map_sum]
  refine Finset.sum_congr rfl fun x _ => ?_
  rw [conj_apply]; congr 1; ring

lemma normSq_kl (ψ : AddChar F ℂ) (a b : F) :
    ((‖kl ψ a b‖ ^ 2 : ℝ) : ℂ) = kl ψ a b * kl ψ (-a) (-b) := by
  rw [← conj_kl, Complex.mul_conj, Complex.normSq_eq_norm_sq]

/-- The solution set of the fourth-moment equations, inside `(F^×)^4`. -/
def sol : Finset (F × F × F × F) :=
  ((univ.erase (0 : F)) ×ˢ (univ.erase (0 : F)) ×ˢ (univ.erase (0 : F)) ×ˢ (univ.erase (0 : F))).filter
    (fun z => z.1 + z.2.2.1 = z.2.1 + z.2.2.2 ∧ z.1⁻¹ + z.2.2.1⁻¹ = z.2.1⁻¹ + z.2.2.2⁻¹)

/-- **Fourth moment identity**: `Σ_{a,b} (K K̄)² = q² · #sol`. -/
theorem fourth_moment (ψ : AddChar F ℂ) (hψ : ψ.IsPrimitive) :
    ∑ a : F, ∑ b : F, (kl ψ a b * kl ψ (-a) (-b)) ^ 2 =
      ((Fintype.card F : ℂ) ^ 2) * (sol (F := F)).card := by
  set S := univ.erase (0 : F)
  -- K K̄ = Σ_{x,y} ψ(a(x - y) + b(x⁻¹ - y⁻¹))
  have hM : ∀ a b : F, kl ψ a b * kl ψ (-a) (-b) =
      ∑ x ∈ S, ∑ y ∈ S, ψ (a * (x - y) + b * (x⁻¹ - y⁻¹)) := by
    intro a b
    unfold kl
    rw [Finset.sum_mul_sum]
    refine Finset.sum_congr rfl fun x _ => Finset.sum_congr rfl fun y _ => ?_
    rw [← AddChar.map_add_eq_mul]; congr 1; ring
  -- square: Σ over (x1,y1,x2,y2)
  have hM2 : ∀ a b : F, (kl ψ a b * kl ψ (-a) (-b)) ^ 2 =
      ∑ z ∈ S ×ˢ S ×ˢ S ×ˢ S, ψ (a * (z.1 + z.2.2.1 - z.2.1 - z.2.2.2) +
        b * (z.1⁻¹ + z.2.2.1⁻¹ - z.2.1⁻¹ - z.2.2.2⁻¹)) := by
    intro a b
    rw [hM, sq, Finset.sum_mul_sum]
    rw [Finset.sum_product, ]
    refine Finset.sum_congr rfl fun x1 _ => ?_
    rw [Finset.sum_product]
    simp_rw [Finset.sum_mul_sum]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun y1 _ => ?_
    rw [Finset.sum_product]
    refine Finset.sum_congr rfl fun x2 _ => Finset.sum_congr rfl fun y2 _ => ?_
    rw [← AddChar.map_add_eq_mul]; congr 1; ring
  simp_rw [hM2]
  set P : F × F × F × F → Prop := fun z => z.1 + z.2.2.1 = z.2.1 + z.2.2.2 ∧
    z.1⁻¹ + z.2.2.1⁻¹ = z.2.1⁻¹ + z.2.2.2⁻¹ with hP
  have hswap : ∀ f : F → F → (F × F × F × F) → ℂ,
      ∑ a : F, ∑ b : F, ∑ z ∈ S ×ˢ S ×ˢ S ×ˢ S, f a b z =
        ∑ z ∈ S ×ˢ S ×ˢ S ×ˢ S, ∑ a : F, ∑ b : F, f a b z := by
    intro f
    calc ∑ a : F, ∑ b : F, ∑ z ∈ S ×ˢ S ×ˢ S ×ˢ S, f a b z
        = ∑ a : F, ∑ z ∈ S ×ˢ S ×ˢ S ×ˢ S, ∑ b : F, f a b z :=
          Finset.sum_congr rfl fun a _ => Finset.sum_comm
      _ = _ := Finset.sum_comm
  rw [hswap]
  have horth : ∀ z ∈ S ×ˢ S ×ˢ S ×ˢ S,
      ∑ a : F, ∑ b : F, ψ (a * (z.1 + z.2.2.1 - z.2.1 - z.2.2.2) +
        b * (z.1⁻¹ + z.2.2.1⁻¹ - z.2.1⁻¹ - z.2.2.2⁻¹)) =
      if P z then (Fintype.card F : ℂ) ^ 2 else 0 := by
    intro z _
    simp_rw [AddChar.map_add_eq_mul, ← Finset.mul_sum, ← Finset.sum_mul]
    rw [AddChar.sum_mulShift _ hψ, AddChar.sum_mulShift _ hψ]
    by_cases h1 : z.1 + z.2.2.1 - z.2.1 - z.2.2.2 = 0 <;>
      by_cases h2 : z.1⁻¹ + z.2.2.1⁻¹ - z.2.1⁻¹ - z.2.2.2⁻¹ = 0
    · have e1 : z.1 + z.2.2.1 = z.2.1 + z.2.2.2 := by linear_combination h1
      have e2 : z.1⁻¹ + z.2.2.1⁻¹ = z.2.1⁻¹ + z.2.2.2⁻¹ := by linear_combination h2
      have : P z := ⟨e1, e2⟩
      rw [if_pos h1, if_pos h2, if_pos this]; push_cast; ring
    · have : ¬ P z := fun e => h2 (by linear_combination e.2)
      rw [if_neg h2, if_neg this]; push_cast; ring
    · have : ¬ P z := fun e => h1 (by linear_combination e.1)
      rw [if_neg h1, if_neg this]; push_cast; ring
    · have : ¬ P z := fun e => h1 (by linear_combination e.1)
      rw [if_neg h1, if_neg this]; push_cast; ring
  rw [Finset.sum_congr rfl horth, ← Finset.sum_filter, Finset.sum_const, nsmul_eq_mul, mul_comm]
  rfl

/-- **Solution count**: `#sol ≤ 3 (q-1)²`. -/
theorem count_le : (sol (F := F)).card ≤ 3 * (Fintype.card F - 1) ^ 2 := by
  set S := univ.erase (0 : F)
  have hS : S.card = Fintype.card F - 1 := by
    rw [Finset.card_erase_of_mem (mem_univ _), Finset.card_univ]
  -- fiber over (x1, x2)
  have hfib : sol (F := F) ⊆ (S ×ˢ S).biUnion (fun p : F × F =>
      ((S ×ˢ S).filter (fun q : F × F => p.1 + p.2 = q.1 + q.2 ∧
          p.1⁻¹ + p.2⁻¹ = q.1⁻¹ + q.2⁻¹)).image (fun q => (p.1, q.1, p.2, q.2))) := by
    intro z hz
    unfold sol at hz
    rw [Finset.mem_filter, Finset.mem_product, Finset.mem_product, Finset.mem_product] at hz
    rw [Finset.mem_biUnion]
    refine ⟨(z.1, z.2.2.1), Finset.mem_product.2 ⟨hz.1.1, hz.1.2.2.1⟩, ?_⟩
    rw [Finset.mem_image]
    refine ⟨(z.2.1, z.2.2.2), ?_, rfl⟩
    rw [Finset.mem_filter, Finset.mem_product]
    exact ⟨⟨hz.1.2.1, hz.1.2.2.2⟩, hz.2⟩
  have hinner : ∀ p ∈ S ×ˢ S,
      (((S ×ˢ S).filter (fun q : F × F => p.1 + p.2 = q.1 + q.2 ∧
          p.1⁻¹ + p.2⁻¹ = q.1⁻¹ + q.2⁻¹)).image (fun q => (p.1, q.1, p.2, q.2))).card ≤
        if p.1 + p.2 = 0 then Fintype.card F - 1 else 2 := by
    intro p hp
    rw [Finset.mem_product] at hp
    have hp1 : p.1 ≠ 0 := (Finset.mem_erase.1 hp.1).1
    have hp2 : p.2 ≠ 0 := (Finset.mem_erase.1 hp.2).1
    refine Finset.card_image_le.trans ?_
    split_ifs with ht
    · -- q.2 = -q.1
      have hsub : (S ×ˢ S).filter (fun q : F × F => p.1 + p.2 = q.1 + q.2 ∧
          p.1⁻¹ + p.2⁻¹ = q.1⁻¹ + q.2⁻¹) ⊆ S.image (fun y => (y, -y)) := by
        intro q hq
        rw [Finset.mem_filter, Finset.mem_product] at hq
        rw [Finset.mem_image]
        refine ⟨q.1, hq.1.1, ?_⟩
        have : q.2 = -q.1 := by linear_combination -hq.2.1 + ht
        ext <;> simp [this]
      exact (Finset.card_le_card hsub).trans (Finset.card_image_le.trans hS.le)
    · have hsub : (S ×ˢ S).filter (fun q : F × F => p.1 + p.2 = q.1 + q.2 ∧
          p.1⁻¹ + p.2⁻¹ = q.1⁻¹ + q.2⁻¹) ⊆ ({p.1, p.2} : Finset F).image
            (fun y => (y, p.1 + p.2 - y)) := by
        intro q hq
        rw [Finset.mem_filter, Finset.mem_product] at hq
        have hq1 : q.1 ≠ 0 := (Finset.mem_erase.1 hq.1.1).1
        have hq2 : q.2 ≠ 0 := (Finset.mem_erase.1 hq.1.2).1
        obtain ⟨e1, e2⟩ := hq.2
        -- q1 q2 = p1 p2
        have hprod : q.1 * q.2 = p.1 * p.2 := by
          have key : (p.1 + p.2) * (q.1 * q.2) - (q.1 + q.2) * (p.1 * p.2) =
              (p.1 * p.2 * q.1 * q.2) * ((p.1⁻¹ + p.2⁻¹) - (q.1⁻¹ + q.2⁻¹)) := by
            field_simp; ring
          rw [e2, sub_self, mul_zero, ← e1] at key
          have : (p.1 + p.2) * (q.1 * q.2 - p.1 * p.2) = 0 := by linear_combination key
          rcases mul_eq_zero.1 this with h | h
          · exact absurd h ht
          · linear_combination h
        have hroot : (q.1 - p.1) * (q.1 - p.2) = 0 := by
          have hq2' : q.2 = p.1 + p.2 - q.1 := by linear_combination -e1
          rw [hq2'] at hprod
          linear_combination -hprod
        rw [Finset.mem_image]
        rcases mul_eq_zero.1 hroot with h | h
        · refine ⟨p.1, by simp, Prod.ext ?_ ?_⟩
          · show p.1 = q.1; linear_combination -h
          · show p.1 + p.2 - p.1 = q.2; linear_combination e1 + h
        · refine ⟨p.2, by simp, Prod.ext ?_ ?_⟩
          · show p.2 = q.1; linear_combination -h
          · show p.1 + p.2 - p.2 = q.2; linear_combination e1 + h
      refine (Finset.card_le_card hsub).trans (Finset.card_image_le.trans ?_)
      exact Finset.card_le_two
  calc (sol (F := F)).card
      ≤ ((S ×ˢ S).biUnion _).card := Finset.card_le_card hfib
    _ ≤ ∑ p ∈ S ×ˢ S, _ := Finset.card_biUnion_le
    _ ≤ ∑ p ∈ S ×ˢ S, (if p.1 + p.2 = 0 then Fintype.card F - 1 else 2) :=
        Finset.sum_le_sum hinner
    _ = ∑ x1 ∈ S, ∑ x2 ∈ S, (if x1 + x2 = 0 then Fintype.card F - 1 else 2) := by
        rw [Finset.sum_product]
    _ ≤ ∑ x1 ∈ S, 3 * (Fintype.card F - 1) := by
        refine Finset.sum_le_sum fun x1 _ => ?_
        rw [Finset.sum_ite]
        have h1 : ((S.filter (fun x2 => x1 + x2 = 0))).card ≤ 1 := by
          rw [Finset.card_le_one]
          intro u hu v hv
          rw [Finset.mem_filter] at hu hv
          linear_combination hu.2 - hv.2
        have h2 : ((S.filter (fun x2 => ¬ x1 + x2 = 0))).card ≤ Fintype.card F - 1 :=
          (Finset.card_filter_le _ _).trans hS.le
        simp only [Finset.sum_const, smul_eq_mul]
        nlinarith
    _ = 3 * (Fintype.card F - 1) ^ 2 := by
        rw [Finset.sum_const, hS, smul_eq_mul]; ring

/-- **Kloosterman's bound**: `‖K(1,n)‖⁴ ≤ 3 q² (q - 1)`. -/
theorem kloosterman_bound (ψ : AddChar F ℂ) (hψ : ψ.IsPrimitive) (n : F) :
    ‖kl ψ 1 n‖ ^ 4 ≤ 3 * (Fintype.card F : ℝ) ^ 2 * ((Fintype.card F : ℝ) - 1) := by
  set q := Fintype.card F
  have hq2 : 2 ≤ q := by
    have := Fintype.one_lt_card (α := F); omega
  have hqR : (2 : ℝ) ≤ q := by exact_mod_cast hq2
  set S := univ.erase (0 : F)
  -- real fourth moment
  have hreal : ∑ a : F, ∑ b : F, ‖kl ψ a b‖ ^ 4 = (q : ℝ) ^ 2 * (sol (F := F)).card := by
    have h := fourth_moment ψ hψ
    have h' : ∀ a b : F, (kl ψ a b * kl ψ (-a) (-b)) ^ 2 = (((‖kl ψ a b‖ ^ 4 : ℝ)) : ℂ) := by
      intro a b; rw [← normSq_kl]; push_cast; ring
    simp_rw [h'] at h
    exact_mod_cast h
  -- the (q-1) points (a, n a⁻¹) all give ‖K(1,n)‖⁴
  have hlow : ((q : ℝ) - 1) * ‖kl ψ 1 n‖ ^ 4 ≤ ∑ a : F, ∑ b : F, ‖kl ψ a b‖ ^ 4 := by
    calc ((q : ℝ) - 1) * ‖kl ψ 1 n‖ ^ 4 = ∑ a ∈ S, ‖kl ψ a (n * a⁻¹)‖ ^ 4 := by
          rw [Finset.sum_congr rfl fun a ha => by rw [kl_scale ψ a n (Finset.mem_erase.1 ha).1],
            Finset.sum_const, Finset.card_erase_of_mem (mem_univ _), Finset.card_univ,
            nsmul_eq_mul]
          rw [Nat.cast_sub (by omega)]; simp
          exact Or.inl rfl
      _ ≤ ∑ a ∈ S, ∑ b : F, ‖kl ψ a b‖ ^ 4 := by
          refine Finset.sum_le_sum fun a _ => ?_
          exact Finset.single_le_sum (f := fun b => ‖kl ψ a b‖ ^ 4) (fun b _ => by positivity)
            (mem_univ _)
      _ ≤ ∑ a : F, ∑ b : F, ‖kl ψ a b‖ ^ 4 :=
          Finset.sum_le_sum_of_subset_of_nonneg (subset_univ _) fun a _ _ =>
            Finset.sum_nonneg fun b _ => by positivity
  have hcount : ((sol (F := F)).card : ℝ) ≤ 3 * ((q : ℝ) - 1) ^ 2 := by
    have := count_le (F := F)
    have h' : ((sol (F := F)).card : ℝ) ≤ ((3 * (q - 1) ^ 2 : ℕ) : ℝ) := by exact_mod_cast this
    rw [Nat.cast_mul, Nat.cast_pow, Nat.cast_sub (by omega)] at h'
    simpa using h'
  have hq1 : (0 : ℝ) < (q : ℝ) - 1 := by linarith
  have key : ((q : ℝ) - 1) * ‖kl ψ 1 n‖ ^ 4 ≤ ((q : ℝ) - 1) * (3 * (q : ℝ) ^ 2 * ((q : ℝ) - 1)) := by
    calc _ ≤ _ := hlow
      _ = (q : ℝ) ^ 2 * (sol (F := F)).card := hreal
      _ ≤ (q : ℝ) ^ 2 * (3 * ((q : ℝ) - 1) ^ 2) := by gcongr
      _ = _ := by ring
  exact le_of_mul_le_mul_left key hq1

end GoldC.QuillonKloosterman

#print axioms GoldC.QuillonKloosterman.fourth_moment
#print axioms GoldC.QuillonKloosterman.count_le
#print axioms GoldC.QuillonKloosterman.kloosterman_bound
