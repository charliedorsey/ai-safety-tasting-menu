import PaperB.Analytic.FixedBetaIdealLambda

namespace PaperB.Analytic

open Real

lemma fixedOrder_denominator_linear_squeeze
    {k W : ℕ} (hW : 0 < W) (hkW : k ≤ W) :
    (2 : ℝ) * (W : ℝ) ≤ ((2 * W + k : ℕ) : ℝ) ∧
      ((2 * W + k : ℕ) : ℝ) ≤ 3 * (W : ℝ) := by
  constructor
  · exact_mod_cast (show 2 * W ≤ 2 * W + k by omega)
  · exact_mod_cast (show 2 * W + k ≤ 3 * W by omega)

lemma fixedOrder_denominator_power_squeeze
    {k W : ℕ} (hW : 0 < W) (hkW : k ≤ W) :
    ((2 : ℝ) * (W : ℝ)) ^ (k + 1)
      ≤ (((2 * W + k : ℕ) : ℝ)) ^ (k + 1)
    ∧
    (((2 * W + k : ℕ) : ℝ)) ^ (k + 1)
      ≤ (3 * (W : ℝ)) ^ (k + 1) := by
  have hlin := fixedOrder_denominator_linear_squeeze hW hkW
  constructor
  · exact (pow_le_pow_left₀ (by positivity) hlin.1) (k + 1)
  · exact (pow_le_pow_left₀ (by positivity) hlin.2) (k + 1)

lemma fixedOrder_denominator_inv_squeeze
    {k W : ℕ} (hW : 0 < W) (hkW : k ≤ W) :
    ((3 * (W : ℝ)) ^ (k + 1))⁻¹
      ≤ ((((2 * W + k : ℕ) : ℝ)) ^ (k + 1))⁻¹
    ∧
    ((((2 * W + k : ℕ) : ℝ)) ^ (k + 1))⁻¹
      ≤ (((2 : ℝ) * (W : ℝ)) ^ (k + 1))⁻¹ := by
  have hp := fixedOrder_denominator_power_squeeze hW hkW
  have htwoPos : 0 < ((2 : ℝ) * (W : ℝ)) ^ (k + 1) := by positivity
  have hactualPos : 0 < (((2 * W + k : ℕ) : ℝ)) ^ (k + 1) := by
    have hbase : 0 < ((2 * W + k : ℕ) : ℝ) := by
      exact_mod_cast (show 0 < 2 * W + k by omega)
    positivity
  have hthreePos : 0 < (3 * (W : ℝ)) ^ (k + 1) := by positivity
  constructor
  · exact (inv_le_inv₀ hthreePos hactualPos).2 hp.2
  · exact (inv_le_inv₀ hactualPos htwoPos).2 hp.1

#print axioms fixedOrder_denominator_linear_squeeze
#print axioms fixedOrder_denominator_power_squeeze
#print axioms fixedOrder_denominator_inv_squeeze

end PaperB.Analytic
