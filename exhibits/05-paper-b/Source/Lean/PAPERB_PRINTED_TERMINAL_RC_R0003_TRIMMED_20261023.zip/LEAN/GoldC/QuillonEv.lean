import GoldC.QuillonSetup

/-!
# Quillon CSC3 F8.4: parameters and the `s`-decay lemmas

**Parameters.**
* `X = ⌈Λ^{200}⌉`.
* `a₀ = 1/(1+δ) − 3/4 ∈ (0, 1/4)`, `u₀ = a₀/2`.
* `Y(s) = ⌊s^{u₀}⌋`.
* `LwW(s) = ⌊s^{1/(1+δ)}⌋ − 1`.

**Lemmas.**
* `s_large`: `log x ≥ 5Λ^σ` forces `x ≥ x₀` eventually.
* `sdecay`: `(1 + log x)^m · x^{−c} ≤ Λ^{−K}` eventually, uniformly in `log x ≥ 5Λ^σ`.
* The geometry of `X`, `Y`, `LwW`, including `LwW/Y ≥ s^{3/4 + a₀/2}/2`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonEv

open GoldC.QuillonSetup

noncomputable def Xp (h : ℕ) : ℕ := ⌈(Real.log h) ^ (200 : ℝ)⌉₊
noncomputable def a0 (δ : ℝ) : ℝ := 1 / (1 + δ) - 3 / 4
noncomputable def u0 (δ : ℝ) : ℝ := a0 δ / 2
noncomputable def Yp (δ : ℝ) (s : ℕ) : ℕ := ⌊(s : ℝ) ^ u0 δ⌋₊
noncomputable def LwW (δ : ℝ) (s : ℕ) : ℕ := ⌊(s : ℝ) ^ (1 / (1 + δ))⌋₊ - 1

lemma σ₀_pos : 0 < σ₀ := by unfold σ₀; norm_num

lemma a0_pos {δ : ℝ} (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) : 0 < a0 δ := by
  unfold a0
  have : (3 / 4 : ℝ) < 1 / (1 + δ) := by
    rw [lt_div_iff₀ (by linarith)]; linarith
  linarith

lemma a0_le {δ : ℝ} (hδ0 : 0 < δ) : a0 δ ≤ 1 / 4 := by
  unfold a0
  have : 1 / (1 + δ) ≤ 1 := by rw [div_le_one (by linarith)]; linarith
  linarith

lemma Xp_ge {h : ℕ} (hΛ : 1 ≤ Real.log h) : (Real.log h) ^ (200 : ℝ) ≤ (Xp h : ℝ) :=
  Nat.le_ceil _

lemma Xp_two {h : ℕ} (hΛ : 2 ≤ Real.log h) : 2 ≤ Xp h := by
  have h1 := Xp_ge (h := h) (by linarith)
  have h2 : (2 : ℝ) ≤ (Real.log h) ^ (200 : ℝ) := by
    calc (2 : ℝ) ≤ Real.log h := hΛ
      _ = (Real.log h) ^ (1 : ℝ) := (Real.rpow_one _).symm
      _ ≤ (Real.log h) ^ (200 : ℝ) := Real.rpow_le_rpow_of_exponent_le (by linarith) (by norm_num)
  have : (2 : ℝ) ≤ (Xp h : ℝ) := le_trans h2 h1
  exact_mod_cast this

lemma Yp_le (δ : ℝ) (s : ℕ) : (Yp δ s : ℝ) ≤ (s : ℝ) ^ u0 δ :=
  Nat.floor_le (by positivity)

lemma Yp_pos {δ : ℝ} (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) {s : ℕ} (hs : 1 ≤ s) : 1 ≤ Yp δ s := by
  unfold Yp
  apply Nat.le_floor
  push_cast
  apply Real.one_le_rpow (by exact_mod_cast hs)
  have := a0_pos hδ0 hδ1; unfold u0; linarith

lemma LwW_ge (δ : ℝ) (s : ℕ) : (s : ℝ) ^ (1 / (1 + δ)) - 2 ≤ (LwW δ s : ℝ) := by
  unfold LwW
  have h1 := Nat.lt_floor_add_one ((s : ℝ) ^ (1 / (1 + δ)))
  rcases Nat.eq_zero_or_pos ⌊(s : ℝ) ^ (1 / (1 + δ))⌋₊ with h0 | hpos
  · rw [h0] at h1 ⊢; rw [Nat.zero_sub, Nat.cast_zero]; push_cast at h1; linarith
  · rw [Nat.cast_sub hpos]; push_cast; linarith

lemma LwW_lt {h H : ℕ} {δ : ℝ} (hδ0 : 0 < δ) {r s : ℕ} (hG : Geo0 h H δ r s) : LwW δ s < r := by
  obtain ⟨hZ, -, hlong, -⟩ := hG
  unfold GoldC.QuillonCopyM.longEither GoldC.QuillonCopyM.longInverseLeft
    GoldC.QuillonCopyM.longInverseRight at hlong
  push_neg at hlong
  have hR := hlong.2
  have hr1 : 1 ≤ r := Nat.pos_of_ne_zero (by rintro rfl; simp at hZ)
  have hr0 : (0 : ℝ) ≤ r := by positivity
  -- `s^{1/(1+δ)} ≤ r`
  have h1 : (s : ℝ) ^ (1 / (1 + δ)) ≤ r := by
    calc (s : ℝ) ^ (1 / (1 + δ)) ≤ ((r : ℝ) ^ (1 + δ)) ^ (1 / (1 + δ)) :=
          Real.rpow_le_rpow (by positivity) hR (by positivity)
      _ = r := by rw [← Real.rpow_mul hr0]; field_simp; simp
  have h2 : ⌊(s : ℝ) ^ (1 / (1 + δ))⌋₊ ≤ r := Nat.floor_le_of_le h1
  unfold LwW; omega

/-- `log x ≥ 5Λ^σ` forces `x ≥ x₀` eventually. -/
lemma s_large (x₀ : ℝ) :
    ∃ Λ₀ : ℝ, 1 ≤ Λ₀ ∧ ∀ Λ : ℝ, Λ₀ ≤ Λ → ∀ x : ℝ, 0 < x → 5 * Λ ^ σ₀ ≤ Real.log x → x₀ ≤ x := by
  obtain ⟨Λ₀, hΛ₀, h⟩ := GoldC.QuillonLam.exp_ge x₀ 5 σ₀ (by norm_num) σ₀_pos
  refine ⟨Λ₀, hΛ₀, fun Λ hΛ x hx hlog => ?_⟩
  calc x₀ ≤ Real.exp (5 * Λ ^ σ₀) := h Λ hΛ
    _ ≤ Real.exp (Real.log x) := Real.exp_le_exp.2 hlog
    _ = x := Real.exp_log hx

/-- `(1 + log x)^m · x^{−c} ≤ Λ^{−K}` eventually, uniformly in `log x ≥ 5Λ^σ`. -/
theorem sdecay (m : ℕ) (c K : ℝ) (hc : 0 < c) (hK : 0 ≤ K) :
    ∃ Λ₀ : ℝ, 1 ≤ Λ₀ ∧ ∀ Λ : ℝ, Λ₀ ≤ Λ → ∀ x : ℝ, 0 < x → 5 * Λ ^ σ₀ ≤ Real.log x →
      (1 + Real.log x) ^ m * x ^ (-c) ≤ Λ ^ (-K) := by
  obtain ⟨x₀, hx₀, hlog⟩ := GoldC.QuillonAsymp.one_add_log_pow_le m (c / 2) (by positivity)
  obtain ⟨Λ₁, hΛ₁, h1⟩ := s_large x₀
  obtain ⟨Λ₂, hΛ₂, h2⟩ := GoldC.QuillonLam.decay 0 K (5 * (c / 2)) σ₀ (by linarith) (by positivity)
    σ₀_pos
  refine ⟨max Λ₁ Λ₂, le_trans hΛ₁ (le_max_left _ _), fun Λ hΛ x hx hlx => ?_⟩
  have hΛ1 : Λ₁ ≤ Λ := le_trans (le_max_left _ _) hΛ
  have hΛ2 : Λ₂ ≤ Λ := le_trans (le_max_right _ _) hΛ
  have hxx₀ := h1 Λ hΛ1 x hx hlx
  have hpow := hlog x hxx₀
  have hdec := h2 Λ hΛ2
  have hΛ0 : 0 < Λ := by linarith
  rw [Real.rpow_zero, one_mul] at hdec
  have hx1 : 0 < x ^ (-c) := Real.rpow_pos_of_pos hx _
  calc (1 + Real.log x) ^ m * x ^ (-c) ≤ x ^ (c / 2) * x ^ (-c) :=
        mul_le_mul_of_nonneg_right hpow hx1.le
    _ = x ^ (-(c / 2)) := by rw [← Real.rpow_add hx]; ring_nf
    _ = Real.exp (-(c / 2) * Real.log x) := by rw [Real.rpow_def_of_pos hx]; ring_nf
    _ ≤ Real.exp (-(5 * (c / 2) * Λ ^ σ₀)) := by
        apply Real.exp_le_exp.2; nlinarith
    _ ≤ Λ ^ (-K) := hdec

lemma natdiv_ge (a b : ℕ) (hb : 1 ≤ b) : (a : ℝ) / b - 1 ≤ ((a / b : ℕ) : ℝ) := by
  have hbR : (0 : ℝ) < b := by exact_mod_cast hb
  have h1 := Nat.lt_div_mul_add (a := a) (b := b) (by omega)
  have h2 : (a : ℝ) < ((a / b : ℕ) : ℝ) * b + b := by exact_mod_cast h1
  rw [div_sub_one hbR.ne', div_le_iff₀ hbR]; linarith

/-- `LwW/Y ≥ s^{3/4 + a₀/2}/2` once `s^{3/4+a₀/2} ≥ 6`. -/
lemma LwW_div_Yp {δ : ℝ} (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) {s : ℕ} (hs : 1 ≤ s)
    (hbig : 6 ≤ (s : ℝ) ^ (3 / 4 + a0 δ / 2)) :
    (s : ℝ) ^ (3 / 4 + a0 δ / 2) / 2 ≤ ((LwW δ s / Yp δ s : ℕ) : ℝ) := by
  have hY1 := Yp_pos hδ0 hδ1 hs
  have hYR : (1 : ℝ) ≤ Yp δ s := by exact_mod_cast hY1
  have hY := Yp_le δ s
  have hL := LwW_ge δ s
  have hd := natdiv_ge (LwW δ s) (Yp δ s) hY1
  have hsR : (1 : ℝ) ≤ s := by exact_mod_cast hs
  have hs0 : (0 : ℝ) < s := by linarith
  have he : 1 / (1 + δ) = u0 δ + (3 / 4 + a0 δ / 2) := by unfold u0 a0; ring
  have hpow : (s : ℝ) ^ (1 / (1 + δ)) = (s : ℝ) ^ u0 δ * (s : ℝ) ^ (3 / 4 + a0 δ / 2) := by
    rw [he, Real.rpow_add hs0]
  have hu : 1 ≤ (s : ℝ) ^ u0 δ := Real.one_le_rpow hsR (by have := a0_pos hδ0 hδ1; unfold u0; linarith)
  set P := (s : ℝ) ^ (3 / 4 + a0 δ / 2)
  set U := (s : ℝ) ^ u0 δ
  -- `(L)/Y ≥ (U·P − 2)/U ≥ P − 2`
  have hLY : P - 2 ≤ (LwW δ s : ℝ) / Yp δ s := by
    rw [le_div_iff₀ (by linarith)]
    have : (P - 2) * Yp δ s ≤ (P - 2) * U := by
      apply mul_le_mul_of_nonneg_left hY; linarith
    nlinarith
  linarith

end GoldC.QuillonEv

#print axioms GoldC.QuillonEv.sdecay
#print axioms GoldC.QuillonEv.LwW_div_Yp
#print axioms GoldC.QuillonEv.LwW_lt
