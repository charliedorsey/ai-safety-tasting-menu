import PaperB.Analytic.DerivTestK

namespace PaperB.Analytic

open Real Finset

/-- Peel a forward difference from the inside. -/
lemma dk_peel_inside (f : ℤ → ℝ) (k : ℕ) (m : ℤ) :
    dk (k + 1) f m = dk k (fun x => f (x + 1) - f x) m := by
  rw [dk_sub (fun x => f (x + 1)) f k m, dk_shift f 1 k m, dk_succ]

/-- Finite-difference mean-value bridge.
If a smooth derivative tower has its k-th level in [lo,hi] on [n,n+k],
then the k-th forward difference of the sampled phase lies in [lo,hi]. -/
lemma dk_bound_of_deriv_tower (n : ℤ) (hn : 0 < n) (k : ℕ) :
    ∀ (Phi : ℕ → ℝ → ℝ) (lo hi : ℝ),
      (∀ j : ℕ, ∀ x : ℝ, 0 < x → HasDerivAt (Phi j) (Phi (j + 1) x) x) →
      (∀ x : ℝ, (n : ℝ) ≤ x → x ≤ (n : ℝ) + (k : ℝ) → lo ≤ Phi k x) →
      (∀ x : ℝ, (n : ℝ) ≤ x → x ≤ (n : ℝ) + (k : ℝ) → Phi k x ≤ hi) →
      lo ≤ dk k (fun i : ℤ => Phi 0 (i : ℝ)) n ∧
        dk k (fun i : ℤ => Phi 0 (i : ℝ)) n ≤ hi := by
  have hn0 : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn
  induction k with
  | zero =>
      intro Phi lo hi _ hlo hhi
      simp only [dk_zero]
      exact ⟨hlo (n : ℝ) le_rfl (by simp), hhi (n : ℝ) le_rfl (by simp)⟩
  | succ k ih =>
      intro Phi lo hi hderiv hlo hhi
      set Psi : ℕ → ℝ → ℝ := fun j y => Phi j (y + 1) - Phi j y with hPsi
      have hAB : (fun x : ℤ => Phi 0 ((↑(x + 1) : ℝ)) - Phi 0 (↑x))
          = (fun i : ℤ => Psi 0 (↑i)) := by
        funext x
        simp only [hPsi]
        push_cast
        ring
      have key : dk (k + 1) (fun i : ℤ => Phi 0 (↑i)) n =
          dk k (fun i : ℤ => Psi 0 (↑i)) n := by
        rw [dk_peel_inside, hAB]
      rw [key]
      have hderiv' : ∀ j : ℕ, ∀ x : ℝ, 0 < x →
          HasDerivAt (Psi j) (Psi (j + 1) x) x := by
        intro j x hx
        have hxp1 : (0 : ℝ) < x + 1 := by linarith
        have h1 : HasDerivAt (fun y : ℝ => Phi j (y + 1))
            (Phi (j + 1) (x + 1)) x :=
          (hderiv j (x + 1) hxp1).comp_add_const x 1
        have h2 : HasDerivAt (Phi j) (Phi (j + 1) x) x := hderiv j x hx
        have h3 : HasDerivAt (fun y : ℝ => Phi j (y + 1) - Phi j y)
            (Phi (j + 1) (x + 1) - Phi (j + 1) x) x := h1.sub h2
        simpa only [hPsi] using h3
      have hPsibound : ∀ x : ℝ, (n : ℝ) ≤ x → x ≤ (n : ℝ) + (k : ℝ) →
          lo ≤ Psi k x ∧ Psi k x ≤ hi := by
        intro x hx1 hx2
        have hxpos : (0 : ℝ) < x := lt_of_lt_of_le hn0 hx1
        have hcont : ContinuousOn (Phi k) (Set.Icc x (x + 1)) := by
          intro y hy
          rw [Set.mem_Icc] at hy
          exact ((hderiv k y (by linarith [hy.1])).continuousAt).continuousWithinAt
        have hmvt := exists_hasDerivAt_eq_slope (Phi k) (Phi (k + 1))
          (by linarith : x < x + 1) hcont
          (fun y hy => by
            rw [Set.mem_Ioo] at hy
            exact hderiv k y (by linarith [hy.1]))
        obtain ⟨xi, hxi, hxieq⟩ := hmvt
        rw [Set.mem_Ioo] at hxi
        rw [show (x + 1) - x = 1 from by ring, div_one] at hxieq
        have hPsieq : Psi k x = Phi (k + 1) xi := by
          simp only [hPsi]
          rw [hxieq]
        have hlb : lo ≤ Phi (k + 1) xi :=
          hlo xi (by linarith [hxi.1]) (by push_cast; linarith [hxi.2])
        have hub : Phi (k + 1) xi ≤ hi :=
          hhi xi (by linarith [hxi.1]) (by push_cast; linarith [hxi.2])
        rw [hPsieq]
        exact ⟨hlb, hub⟩
      exact ih Psi lo hi hderiv'
        (fun x hx1 hx2 => (hPsibound x hx1 hx2).1)
        (fun x hx1 hx2 => (hPsibound x hx1 hx2).2)

#print axioms dk_bound_of_deriv_tower

end PaperB.Analytic
