import GoldC.QuillonClassNormalFormCopyQ0001
import Mathlib.Data.Nat.GCD.BigOperators

/-!
# Quillon CSC3 F8.0: verbatim source copies for the folded row (`GoldC.QuillonCopyF`)

These are verbatim copies of the curated source definitions and lemmas needed to identify the source
summand `foldRow` with the abstract row `rowAbs`. They come from `GoldC/SourceCore.lean`,
`RowRounding.lean`, `CentralDecomp.lean`, `InvBound.lean`, `DigitSplit.lean` and `C2Fold.lean`.
`saw`, `invMod` and `crtResidue` are the existing copies in `GoldC.QuillonCopyC`
(`QuillonClassNormalForm`). The source files themselves `import Mathlib`, and no full Mathlib
olean is available here, so the declarations are copied instead.

To replay in production, delete this file and use the `GoldC` originals. Every body is
character-identical, so all uses go through by `rfl`.
-/

open scoped BigOperators Classical
open Finset

namespace GoldC.QuillonCopyF

open GoldC.QuillonCopyC

-- verbatim from GoldC/SourceCore.lean
def centralGate (h H r s : ℕ) : Prop :=
  (r * s : ℝ) ≤ (H : ℝ) /
    Real.exp ((Real.log (h : ℝ)) ^ (1/4 : ℝ)) ∧
  s ≤ r ^ 2 ∧ r ≤ s ^ 2

-- verbatim from GoldC/SourceCore.lean
noncomputable def reducedAnchor (q a D : ℕ) : ℕ :=
  if hDq : D.Coprime q then
    (((((ZMod.unitOfCoprime D hDq)⁻¹ : (ZMod q)ˣ) : ZMod q) *
      (a : ZMod q)).val)
  else 0

-- verbatim from GoldC/SourceCore.lean
def lowPrimeSet : Finset ℕ := {2, 3}

-- verbatim from GoldC/SourceCore.lean
def endpointOccupiedCount (p H : ℕ) : ℕ :=
  ({0 % p, H % p} : Finset ℕ).card

-- verbatim from GoldC/SourceCore.lean
def tripleOccupiedCount (p H y : ℕ) : ℕ :=
  ({0 % p, y % p, H % p} : Finset ℕ).card

-- verbatim from GoldC/SourceCore.lean
noncomputable def occupiedLocalRatio (p H y : ℕ) : ℝ :=
  ((1 - (tripleOccupiedCount p H y : ℝ) / (p : ℝ)) /
      (1 - (endpointOccupiedCount p H : ℝ) / (p : ℝ))) /
    (1 - 1 / (p : ℝ))

-- verbatim from GoldC/SourceCore.lean
noncomputable def occupiedWeight (q a H y : ℕ) : ℝ :=
  (if q.Coprime (a + y) then 1 else 0) *
    ∏ p ∈ lowPrimeSet,
      if p ∣ q then 1 else occupiedLocalRatio p H y

-- verbatim from GoldC/RowRounding.lean
lemma tripleOccupiedCount_add (p H y k : ℕ) (hp : p ∣ k) :
    tripleOccupiedCount p H (y + k) = tripleOccupiedCount p H y := by
  unfold tripleOccupiedCount
  have : (y + k) % p = y % p := by
    obtain ⟨m, rfl⟩ := hp; simp [Nat.add_mul_mod_self_left]
  rw [this]

-- verbatim from GoldC/RowRounding.lean
/-- **The source weight is `6q`-periodic.** -/
theorem occupiedWeight_periodic (q a H y : ℕ) :
    occupiedWeight q a H (y + 6 * q) = occupiedWeight q a H y := by
  unfold occupiedWeight
  congr 1
  · congr 1
    have : a + (y + 6 * q) = a + y + q * 6 := by ring
    rw [this]
    exact propext (Nat.coprime_add_mul_left_right _ _ _)
  · refine Finset.prod_congr rfl fun p hp => ?_
    have hp' : p = 2 ∨ p = 3 := by simpa [lowPrimeSet] using hp
    have hdvd : p ∣ 6 * q := by
      rcases hp' with rfl | rfl
      · exact Dvd.dvd.mul_right (by norm_num) _
      · exact Dvd.dvd.mul_right (by norm_num) _
    unfold occupiedLocalRatio
    rw [tripleOccupiedCount_add p H y _ hdvd]

-- verbatim from GoldC/CentralDecomp.lean
/-- The period-`6q` mean `μ` of the source weight `y ↦ occupiedWeight q a' H y`. -/
noncomputable def meanWeight (q a' H : ℕ) : ℝ :=
  (∑ y ∈ Finset.range (6 * q), occupiedWeight q a' H y) / (6 * q : ℝ)

-- verbatim from GoldC/InvBound.lean
lemma triple_le (p H y : ℕ) (hp : 0 < p) : tripleOccupiedCount p H y ≤ p := by
  unfold tripleOccupiedCount
  calc ({0 % p, y % p, H % p} : Finset ℕ).card ≤ (Finset.range p).card := by
        apply Finset.card_le_card
        intro x hx
        simp only [Finset.mem_insert, Finset.mem_singleton] at hx
        rw [Finset.mem_range]
        rcases hx with rfl | rfl | rfl <;> exact Nat.mod_lt _ hp
    _ = p := Finset.card_range p

-- verbatim from GoldC/InvBound.lean
lemma endpoint_le_triple (p H y : ℕ) : endpointOccupiedCount p H ≤ tripleOccupiedCount p H y := by
  unfold endpointOccupiedCount tripleOccupiedCount
  apply Finset.card_le_card
  intro x hx
  simp only [Finset.mem_insert, Finset.mem_singleton] at hx ⊢
  tauto

-- verbatim from GoldC/InvBound.lean
lemma occupiedLocalRatio_bounds {p : ℕ} (hp : 2 ≤ p) (H y : ℕ) :
    0 ≤ occupiedLocalRatio p H y ∧ occupiedLocalRatio p H y ≤ 2 := by
  unfold occupiedLocalRatio
  have hpR : (2 : ℝ) ≤ p := by exact_mod_cast hp
  have ht := triple_le p H y (by omega)
  have het := endpoint_le_triple p H y
  set t := tripleOccupiedCount p H y
  set e := endpointOccupiedCount p H
  have htR : (t : ℝ) ≤ p := by exact_mod_cast ht
  have hetR : (e : ℝ) ≤ t := by exact_mod_cast het
  have hp0 : (0 : ℝ) < p := by linarith
  have h1p : (1 / 2 : ℝ) ≤ 1 - 1 / (p : ℝ) := by
    have : (1 : ℝ) / p ≤ 1 / 2 := by
      rw [div_le_div_iff₀ hp0 (by norm_num)]; linarith
    linarith
  have hnum0 : 0 ≤ 1 - (t : ℝ) / p := by
    rw [sub_nonneg, div_le_one hp0]; exact htR
  by_cases hden : 1 - (e : ℝ) / p = 0
  · rw [hden, div_zero, zero_div]; norm_num
  · have hden_pos : 0 < 1 - (e : ℝ) / p := by
      rcases lt_or_gt_of_ne hden with h | h
      · exfalso
        have : (p : ℝ) < e := by
          rw [sub_neg, one_lt_div hp0] at h; exact h
        linarith
      · exact h
    have hle : 1 - (t : ℝ) / p ≤ 1 - (e : ℝ) / p := by
      have : (e : ℝ) / p ≤ t / p := div_le_div_of_nonneg_right hetR hp0.le
      linarith
    have hq : (1 - (t : ℝ) / p) / (1 - (e : ℝ) / p) ≤ 1 := (div_le_one hden_pos).2 hle
    have hq0 : 0 ≤ (1 - (t : ℝ) / p) / (1 - (e : ℝ) / p) := div_nonneg hnum0 hden_pos.le
    refine ⟨div_nonneg hq0 (by linarith), ?_⟩
    rw [div_le_iff₀ (by linarith)]
    nlinarith

-- verbatim from GoldC/InvBound.lean
lemma occupiedWeight_bounds (q a H y : ℕ) :
    0 ≤ occupiedWeight q a H y ∧ occupiedWeight q a H y ≤ 4 := by
  unfold occupiedWeight
  have hprod : 0 ≤ (∏ p ∈ lowPrimeSet, if p ∣ q then (1 : ℝ) else occupiedLocalRatio p H y) ∧
      (∏ p ∈ lowPrimeSet, if p ∣ q then (1 : ℝ) else occupiedLocalRatio p H y) ≤ 4 := by
    have hb : ∀ p ∈ lowPrimeSet, 0 ≤ (if p ∣ q then (1 : ℝ) else occupiedLocalRatio p H y) ∧
        (if p ∣ q then (1 : ℝ) else occupiedLocalRatio p H y) ≤ 2 := by
      intro p hp
      have hp2 : 2 ≤ p := by
        simp only [lowPrimeSet, Finset.mem_insert, Finset.mem_singleton] at hp
        rcases hp with rfl | rfl <;> norm_num
      split_ifs
      · norm_num
      · exact occupiedLocalRatio_bounds hp2 H y
    unfold lowPrimeSet at hb ⊢
    rw [Finset.prod_insert (by norm_num), Finset.prod_singleton]
    obtain ⟨h1, h2⟩ := hb 2 (by simp)
    obtain ⟨h3, h4⟩ := hb 3 (by simp)
    exact ⟨mul_nonneg h1 h3, by nlinarith⟩
  split_ifs
  · rw [one_mul]; exact hprod
  · rw [zero_mul]; norm_num

-- verbatim from GoldC/InvBound.lean
lemma meanWeight_bounds (q a' H : ℕ) : 0 ≤ meanWeight q a' H ∧ meanWeight q a' H ≤ 4 := by
  unfold meanWeight
  rcases Nat.eq_zero_or_pos q with rfl | hq
  · simp
  have hq' : (0 : ℝ) < 6 * q := by positivity
  constructor
  · exact div_nonneg (Finset.sum_nonneg fun y _ => (occupiedWeight_bounds q a' H y).1) hq'.le
  · rw [div_le_iff₀ hq']
    calc (∑ y ∈ Finset.range (6 * q), occupiedWeight q a' H y)
        ≤ ∑ y ∈ Finset.range (6 * q), (4 : ℝ) :=
          Finset.sum_le_sum fun y _ => (occupiedWeight_bounds q a' H y).2
      _ = 4 * (6 * q) := by rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul]; push_cast; ring

-- verbatim from GoldC/DigitSplit.lean
lemma sum_shift_period (f : ℕ → ℝ) (M : ℕ) (hper : ∀ y, f (y + M) = f y) (K : ℕ) :
    ∑ i ∈ Finset.range M, f (K + i) = ∑ i ∈ Finset.range M, f i := by
  induction K with
  | zero => simp
  | succ K ih =>
    rw [← ih]
    rcases Nat.eq_zero_or_pos M with rfl | hM
    · simp
    obtain ⟨m, rfl⟩ : ∃ m, M = m + 1 := ⟨M - 1, by omega⟩
    rw [Finset.sum_range_succ, Finset.sum_range_succ' (fun i => f (K + i))]
    have h3 : f (K + 1 + m) = f (K + 0) := by
      rw [show K + 1 + m = K + (m + 1) by ring, hper, add_zero]
    rw [h3]
    have h4 : ∑ i ∈ Finset.range m, f (K + 1 + i) = ∑ i ∈ Finset.range m, f (K + (i + 1)) :=
      Finset.sum_congr rfl fun i _ => by ring_nf
    rw [h4]

-- verbatim from GoldC/C2Fold.lean
lemma periodic_mod (g : ℕ → ℝ) (M : ℕ) (hper : ∀ y, g (y + M) = g y) (y : ℕ) :
    g y = g (y % M) := by
  have key : ∀ k x, g (x + M * k) = g x := by
    intro k; induction k with
    | zero => intro x; simp
    | succ k ih => intro x; rw [Nat.mul_succ, ← add_assoc, hper, ih]
  conv_lhs => rw [← Nat.mod_add_div y M]
  exact key _ _

-- verbatim from GoldC/C2Fold.lean
lemma periodic_modEq (g : ℕ → ℝ) (M : ℕ) (hper : ∀ y, g (y + M) = g y) {x y : ℕ}
    (h : x ≡ y [MOD M]) : g x = g y := by
  rw [periodic_mod g M hper x, periodic_mod g M hper y, h]

-- verbatim from GoldC/C2Fold.lean
/-- The potential of `g` along steps of size `n`, modulo `M`. -/
noncomputable def pot (g : ℕ → ℝ) (M n y : ℕ) : ℝ :=
  ∑ t ∈ Finset.range ((y * invMod n M) % M), g (t * n)

-- verbatim from GoldC/C2Fold.lean
lemma pot_congr (g : ℕ → ℝ) (M n : ℕ) {x y : ℕ} (h : x ≡ y [MOD M]) :
    pot g M n x = pot g M n y := by
  unfold pot
  have : (x * invMod n M) % M = (y * invMod n M) % M := Nat.ModEq.mul_right _ h
  rw [this]

-- verbatim from GoldC/C2Fold.lean
/-- The centred source weight `g = λ - μ`. -/
noncomputable def srcG (q a' H : ℕ) (y : ℕ) : ℝ :=
  occupiedWeight q a' H y - meanWeight q a' H

-- verbatim from GoldC/C2Fold.lean
lemma srcG_periodic (q a' H y : ℕ) : srcG q a' H (y + 6 * q) = srcG q a' H y := by
  unfold srcG; rw [occupiedWeight_periodic]

-- verbatim from GoldC/C2Fold.lean
lemma srcG_bound (q a' H y : ℕ) : |srcG q a' H y| ≤ 4 := by
  unfold srcG
  have h1 := occupiedWeight_bounds q a' H y
  have h2 := meanWeight_bounds q a' H
  rw [abs_le]; constructor <;> linarith

-- verbatim from GoldC/C2Fold.lean
/-- `|pot| ≤ 4M` for the source potential. -/
lemma pot_srcG_bound (q a' H n y : ℕ) (hq : 0 < q) :
    |pot (srcG q a' H) (6 * q) n y| ≤ 4 * (6 * q) := by
  unfold pot
  calc |∑ t ∈ Finset.range ((y * invMod n (6 * q)) % (6 * q)), srcG q a' H (t * n)|
      ≤ ∑ t ∈ Finset.range ((y * invMod n (6 * q)) % (6 * q)), |srcG q a' H (t * n)| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ t ∈ Finset.range ((y * invMod n (6 * q)) % (6 * q)), (4 : ℝ) :=
        Finset.sum_le_sum fun t _ => srcG_bound _ _ _ _
    _ = ((y * invMod n (6 * q)) % (6 * q) : ℕ) * 4 := by
        rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
    _ ≤ ((6 * q : ℕ) : ℝ) * 4 := by
        gcongr; exact_mod_cast (Nat.mod_lt _ (by omega)).le
    _ = 4 * (6 * q) := by push_cast; ring

-- verbatim from GoldC/C2Fold.lean
lemma pot_mod_n (g : ℕ → ℝ) (M n y : ℕ) (hper : ∀ y, g (y + M) = g y) :
    pot g M n y = pot g M (n % M) y := by
  unfold pot
  have hinv : invMod n M = invMod (n % M) M := by
    unfold invMod; rw [ZMod.natCast_mod]
  rw [hinv]
  refine Finset.sum_congr rfl fun t _ => periodic_modEq g M hper ?_
  exact Nat.ModEq.mul_left t (Nat.mod_modEq n M).symm

-- verbatim from GoldC/C2Fold.lean
/-- The class value of the entry/exit potential difference: `c ≡ b`, `rs ≡ ν (mod 6q)`. -/
noncomputable def gammaClass (q a D H b ν : ℕ) : ℝ :=
  pot (srcG q (reducedAnchor q a D) H) (6 * q) ν (H + ν + 6 * q - b) -
    pot (srcG q (reducedAnchor q a D) H) (6 * q) ν b

-- verbatim from GoldC/C2Fold.lean
lemma pot_diff_eq_gammaClass (q a D H n c : ℕ) (hq : 0 < q) (hc : c < n) :
    pot (srcG q (reducedAnchor q a D) H) (6 * q) n (H + n - c) -
      pot (srcG q (reducedAnchor q a D) H) (6 * q) n c =
    gammaClass q a D H (c % (6 * q)) (n % (6 * q)) := by
  unfold gammaClass
  have hper := srcG_periodic q (reducedAnchor q a D) H
  rw [pot_mod_n _ _ n _ hper, pot_mod_n _ _ n c hper]
  congr 1
  · apply pot_congr
    rw [Nat.modEq_iff_dvd]
    have hb : c % (6 * q) ≤ 6 * q := (Nat.mod_lt _ (by omega)).le
    have e1 := Nat.mod_add_div n (6 * q)
    have e2 := Nat.mod_add_div c (6 * q)
    push_cast [Nat.cast_sub (show c ≤ H + n by omega),
      Nat.cast_sub (show c % (6 * q) ≤ H + n % (6 * q) + 6 * q by omega)]
    have e1' : ((n % (6 * q) : ℕ) : ℤ) = n - 6 * q * (n / (6 * q) : ℕ) := by
      have := congrArg (fun t : ℕ => (t : ℤ)) e1; push_cast at this ⊢; linarith
    have e2' : ((c % (6 * q) : ℕ) : ℤ) = c - 6 * q * (c / (6 * q) : ℕ) := by
      have := congrArg (fun t : ℕ => (t : ℤ)) e2; push_cast at this ⊢; linarith
    push_cast at e1' e2'
    rw [e1', e2']
    exact ⟨1 - (n / (6 * q) : ℕ) + (c / (6 * q) : ℕ), by push_cast; ring⟩
  · exact pot_congr _ _ _ (Nat.mod_modEq c (6 * q)).symm

-- verbatim from GoldC/C2Fold.lean
lemma sum_sum_ite_eq (M x y : ℕ) (hx : x < M) (hy : y < M) (f : ℕ → ℕ → ℝ) :
    ∑ b ∈ Finset.range M, ∑ ν ∈ Finset.range M, f b ν * (if x = b ∧ y = ν then 1 else 0) =
      f x y := by
  rw [Finset.sum_eq_single x]
  · rw [Finset.sum_eq_single y]
    · simp
    · intro ν _ hν; simp [Ne.symm hν]
    · intro h; exact absurd (Finset.mem_range.2 hy) h
  · intro b _ hb
    exact Finset.sum_eq_zero fun ν _ => by simp [Ne.symm hb]
  · intro h; exact absurd (Finset.mem_range.2 hx) h

-- verbatim from GoldC/C2Fold.lean
/-- The folded row: twice the oriented sawtooth plus the entry/exit potential difference.
It depends on the pair only through the CRT residue `c(r,s)` and `n = rs`. -/
noncomputable def foldRow (q a : ℕ) (D H r s : ℕ) : ℝ :=
  -(2 * meanWeight q (reducedAnchor q a D) H) * saw ((H : ℝ) * invMod r s / s) +
    (pot (srcG q (reducedAnchor q a D) H) (6 * q) (r * s) (H + r * s - crtResidue H r s) -
      pot (srcG q (reducedAnchor q a D) H) (6 * q) (r * s) (crtResidue H r s))

-- verbatim from GoldC/C2Fold.lean
lemma sum_gammaClass_zero (q a D H ν : ℕ) :
    ∑ b ∈ Finset.range (6 * q), gammaClass q a D H b ν = 0 := by
  unfold gammaClass
  rw [Finset.sum_sub_distrib, sub_eq_zero]
  set f := pot (srcG q (reducedAnchor q a D) H) (6 * q) ν with hf
  have hfper : ∀ y, f (y + 6 * q) = f y := fun y =>
    pot_congr _ _ _ (Nat.add_modEq_right)
  rw [← Finset.sum_range_reflect (fun b => f (H + ν + 6 * q - b))]
  have : ∀ j ∈ Finset.range (6 * q), f (H + ν + 6 * q - (6 * q - 1 - j)) = f ((H + ν + 1) + j) := by
    intro j hj
    rw [Finset.mem_range] at hj
    congr 1; omega
  rw [Finset.sum_congr rfl this]
  exact sum_shift_period f (6 * q) hfper (H + ν + 1)

-- verbatim from GoldC/C2Fold.lean
lemma abs_gammaClass_le (q a D H b ν : ℕ) (hq : 0 < q) :
    |gammaClass q a D H b ν| ≤ 8 * (6 * q) := by
  unfold gammaClass
  have h1 := pot_srcG_bound q (reducedAnchor q a D) H ν (H + ν + 6 * q - b) hq
  have h2 := pot_srcG_bound q (reducedAnchor q a D) H ν b hq
  calc _ ≤ |pot (srcG q (reducedAnchor q a D) H) (6 * q) ν (H + ν + 6 * q - b)| +
        |pot (srcG q (reducedAnchor q a D) H) (6 * q) ν b| := abs_sub _ _
    _ ≤ 4 * (6 * q) + 4 * (6 * q) := add_le_add h1 h2
    _ = 8 * (6 * q) := by ring

-- verbatim from GoldC/RowRounding.lean
lemma crtResidue_lt {H r s : ℕ} (hs : 2 ≤ s) (hr : 1 ≤ r) : crtResidue H r s < r * s := by
  unfold crtResidue
  exact Nat.mul_lt_mul_of_pos_left (Nat.mod_lt _ (by omega)) (by omega)

end GoldC.QuillonCopyF

#print axioms GoldC.QuillonCopyF.pot_diff_eq_gammaClass
#print axioms GoldC.QuillonCopyF.sum_gammaClass_zero
#print axioms GoldC.QuillonCopyF.abs_gammaClass_le
#print axioms GoldC.QuillonCopyF.meanWeight_bounds
