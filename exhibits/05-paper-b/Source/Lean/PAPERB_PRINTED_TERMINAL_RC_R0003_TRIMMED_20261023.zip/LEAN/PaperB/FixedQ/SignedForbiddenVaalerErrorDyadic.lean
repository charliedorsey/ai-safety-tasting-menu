import PaperB.FixedQ.SignedForbiddenVaalerErrorLocal
import PaperB.FixedQ.SignedForbiddenDyadicVaalerReindex

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def sourceOrdinaryDyadicShiuMass
    (q H M : ℕ) : ℝ :=
  ∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
    finiteOmegaWeightReal S * (2 : ℝ) ^ S.card

noncomputable def sourceOrdinaryDyadicHarmonicShell
    (q H M J : ℕ) : ℝ :=
  ∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
    finiteOmegaWeightReal S * (2 : ℝ) ^ S.card *
      sourcePeriodicHarmonicMass q H J S

lemma sourceOrdinaryDyadicShiuMass_nonneg
    (q H M : ℕ) :
    0 ≤ sourceOrdinaryDyadicShiuMass q H M := by
  unfold sourceOrdinaryDyadicShiuMass
  apply Finset.sum_nonneg
  intro S hS
  have hActive :=
    h2BooleanDyadicSets_active (h2BooleanOrdinaryDyadicSets_mem hS).1
  exact mul_nonneg
    (finiteOmegaWeightReal_nonneg_of_active hActive)
    (pow_nonneg (by norm_num) _)

lemma sourceOrdinaryDyadicHarmonicShell_nonneg
    (q H M J : ℕ) :
    0 ≤ sourceOrdinaryDyadicHarmonicShell q H M J := by
  unfold sourceOrdinaryDyadicHarmonicShell
  apply Finset.sum_nonneg
  intro S hS
  have hActive :=
    h2BooleanDyadicSets_active (h2BooleanOrdinaryDyadicSets_mem hS).1
  exact mul_nonneg
    (mul_nonneg
      (finiteOmegaWeightReal_nonneg_of_active hActive)
      (pow_nonneg (by norm_num) _))
    (sourcePeriodicHarmonicMass_nonneg q H J S)

theorem sourceForbiddenNaturalVaalerErrorDyadicBlock_le_shell
    {q A H D M J : ℕ}
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H) :
    sourceForbiddenNaturalVaalerErrorDyadicBlock q A H D M J ≤
      (6 * (fixedQPeriod q : ℝ)) *
        (1 / ((J + 1 : ℕ) : ℝ) *
            sourceOrdinaryDyadicShiuMass q H M +
          2 * sourceOrdinaryDyadicHarmonicShell q H M J) := by
  rw [neris_sourceForbiddenNaturalVaalerErrorDyadicBlock_eq_ordinaryDyadic]
  let F := h2BooleanOrdinaryDyadicSets q H M
  have hpoint : ∀ S ∈ F,
      sourceForbiddenNaturalVaalerError
          q A H D (primeSetProduct S) J ≤
        (6 * (fixedQPeriod q : ℝ)) *
          ((1 / ((J + 1 : ℕ) : ℝ)) *
              (finiteOmegaWeightReal S * (2 : ℝ) ^ S.card) +
            2 * (finiteOmegaWeightReal S * (2 : ℝ) ^ S.card *
              sourcePeriodicHarmonicMass q H J S)) := by
    intro S hS
    have hActive :=
      h2BooleanDyadicSets_active (h2BooleanOrdinaryDyadicSets_mem hS).1
    have hPrime : ∀ p ∈ S, p.Prime := fun p hp => (hActive p hp).1
    have hpf : (primeSetProduct S).primeFactors = S := by
      simpa [primeSetProduct] using Nat.primeFactors_prod hPrime
    have hlocal :=
      sourceForbiddenNaturalVaalerError_le_periodicHarmonic
        (q := q) (a := A) (H := H) (D := D)
        (m := primeSetProduct S) (J := J) h2admissible
    rw [fixedQShiuWeight_primeSetProduct_eq_card_mul_finiteOmegaWeightReal
      hActive, hpf] at hlocal
    calc
      sourceForbiddenNaturalVaalerError
          q A H D (primeSetProduct S) J
        ≤ (finiteOmegaWeightReal S * (2 : ℝ) ^ S.card) *
            (6 * (fixedQPeriod q : ℝ)) *
            (1 / ((J + 1 : ℕ) : ℝ) +
              2 * sourcePeriodicHarmonicMass q H J S) := by
          simpa [mul_comm] using hlocal
      _ = (6 * (fixedQPeriod q : ℝ)) *
          ((1 / ((J + 1 : ℕ) : ℝ)) *
              (finiteOmegaWeightReal S * (2 : ℝ) ^ S.card) +
            2 * (finiteOmegaWeightReal S * (2 : ℝ) ^ S.card *
              sourcePeriodicHarmonicMass q H J S)) := by ring
  calc
    (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
      sourceForbiddenNaturalVaalerError q A H D (primeSetProduct S) J)
      ≤ ∑ S ∈ F,
          (6 * (fixedQPeriod q : ℝ)) *
            ((1 / ((J + 1 : ℕ) : ℝ)) *
                (finiteOmegaWeightReal S * (2 : ℝ) ^ S.card) +
              2 * (finiteOmegaWeightReal S * (2 : ℝ) ^ S.card *
                sourcePeriodicHarmonicMass q H J S)) := by
          apply Finset.sum_le_sum
          intro S hS
          exact hpoint S hS
    _ = (6 * (fixedQPeriod q : ℝ)) *
        (1 / ((J + 1 : ℕ) : ℝ) *
            sourceOrdinaryDyadicShiuMass q H M +
          2 * sourceOrdinaryDyadicHarmonicShell q H M J) := by
          unfold sourceOrdinaryDyadicShiuMass
          unfold sourceOrdinaryDyadicHarmonicShell
          dsimp [F]
          calc
            (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
              (6 * (fixedQPeriod q : ℝ)) *
                ((1 / ((J + 1 : ℕ) : ℝ)) *
                    (finiteOmegaWeightReal S * (2 : ℝ) ^ S.card) +
                  2 * (finiteOmegaWeightReal S * (2 : ℝ) ^ S.card *
                    sourcePeriodicHarmonicMass q H J S)))
              =
              (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
                (6 * (fixedQPeriod q : ℝ)) *
                  (1 / ((J + 1 : ℕ) : ℝ)) *
                  (finiteOmegaWeightReal S * (2 : ℝ) ^ S.card)) +
              (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
                (12 * (fixedQPeriod q : ℝ)) *
                  (finiteOmegaWeightReal S * (2 : ℝ) ^ S.card *
                    sourcePeriodicHarmonicMass q H J S)) := by
                rw [← Finset.sum_add_distrib]
                apply Finset.sum_congr rfl
                intro S hS
                ring
            _ = (6 * (fixedQPeriod q : ℝ)) *
                (1 / ((J + 1 : ℕ) : ℝ)) *
                  (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
                    finiteOmegaWeightReal S * (2 : ℝ) ^ S.card) +
                (12 * (fixedQPeriod q : ℝ)) *
                  (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
                    finiteOmegaWeightReal S * (2 : ℝ) ^ S.card *
                      sourcePeriodicHarmonicMass q H J S) := by
                rw [Finset.mul_sum, Finset.mul_sum]
            _ = (6 * (fixedQPeriod q : ℝ)) *
                (1 / ((J + 1 : ℕ) : ℝ) *
                    (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
                      finiteOmegaWeightReal S * (2 : ℝ) ^ S.card) +
                  2 * (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
                    finiteOmegaWeightReal S * (2 : ℝ) ^ S.card *
                      sourcePeriodicHarmonicMass q H J S)) := by ring

#print axioms sourceForbiddenNaturalVaalerErrorDyadicBlock_le_shell

end PaperB.FixedQ
