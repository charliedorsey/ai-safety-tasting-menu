import GoldC.QuillonTypeIIEval

/-!
# Quillon CSC3 F7.4j: Type II for arbitrary coefficients

`typeII_gen` and `typeII_eval_gen` are `typeII_abstract` and `typeII_eval` for an arbitrary bilinear form
`Σ_{d≤B} α_d Σ_{m∈(A/d,B/d]} β_m kphase(c, dm)`. The hypotheses are:
- `|α_d| ≤ τ(d)`, and `α_d = 0` for `d ≤ U`;
- `‖β_m‖ ≤ log B` for `m ≤ B`, and `β_m = 0` for `m ≤ V`.

This covers the class-restricted Type II, where `α`, `β` carry indicators of residue classes mod `Q`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset ArithmeticFunction

namespace GoldC.QuillonTypeIIGen

open GoldC.QuillonVW GoldC.QuillonTypeII GoldC.QuillonPartition GoldC.QuillonTypeIIEval
  GoldC.QuillonDivisorMoment

section
variable {s : ℕ} [NeZero s]

theorem typeII_gen (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p)
    (c : ZMod s) (U V A B : ℕ) (hAB : A ≤ B) (t : ℕ → ℕ) (J : ℕ) (ht0 : t 0 = U) (hU : 1 ≤ U)
    (htm : Monotone t) (htJ : B < (V + 1) * t J) (α β : ℕ → ℂ) (hα0 : ∀ d, d ≤ U → α d = 0)
    (hαb : ∀ d, ‖α d‖ ≤ (d.divisors.card : ℝ)) (hβ0 : ∀ m, m ≤ V → β m = 0)
    (hβb : ∀ m, m ≤ B → ‖β m‖ ≤ Real.log B) :
    ‖∑ d ∈ Ioc 0 B, α d * ∑ m ∈ Ioc (A / d) (B / d), β m * kphase c (d * m)‖ ≤
      ∑ j ∈ range J, Real.sqrt ((∑ d ∈ Ioc (t j) (t (j + 1)), ((d.divisors.card : ℝ)) ^ 2) *
          (((t (j + 1) : ℕ) : ℝ) / s + 1) * s *
          (Real.log B ^ 2 * (((B / t j - A / t j : ℕ) : ℝ) * (((B / t j - A / t j : ℕ) : ℝ) /
            ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ) + 1)))) +
        ∑ j ∈ range J, ∑ d ∈ Ioc (t j) (t (j + 1)), (d.divisors.card : ℝ) *
          (Real.log B * (((A / t j - A / t (j + 1) : ℕ) : ℝ) + ((B / t j - B / t (j + 1) : ℕ) : ℝ))) := by
  classical
  set F : ℕ → ℂ := fun d => α d * ∑ m ∈ Ioc (A / d) (B / d), β m * kphase c (d * m)
    with hF
  have hext : ∑ d ∈ Ioc 0 B, F d = ∑ d ∈ Ioc (t 0) (t J), F d := by
    have hFB : ∀ d, B < d → F d = 0 := by
      intro d hd
      simp only [hF, Nat.div_eq_of_lt hd, Nat.div_eq_of_lt (lt_of_le_of_lt hAB hd), Ioc_self,
        sum_empty, mul_zero]
    have hFJ : ∀ d, t J < d → F d = 0 := by
      intro d hd
      simp only [hF]
      rw [sum_eq_zero, mul_zero]
      intro m hm
      have hm2 := (mem_Ioc.1 hm).2
      have hmV : m ≤ V := by
        have h1 : B / d ≤ B / t J := Nat.div_le_div_left hd.le (by
          rcases Nat.eq_zero_or_pos (t J) with h | h
          · rw [h, mul_zero] at htJ; omega
          · exact h)
        have h2 : B / t J < V + 1 := by
          rw [Nat.div_lt_iff_lt_mul (by
            rcases Nat.eq_zero_or_pos (t J) with h | h
            · rw [h, mul_zero] at htJ; omega
            · exact h)]
          linarith [mul_comm (V + 1) (t J)]
        omega
      rw [hβ0 m hmV, zero_mul]
    have h1 : ∑ d ∈ Ioc 0 B, F d = ∑ d ∈ Ioc 0 (t J), F d := by
      have hm1 : ∑ d ∈ Ioc 0 (min B (t J)), F d = ∑ d ∈ Ioc 0 B, F d := by
        apply sum_subset (Ioc_subset_Ioc_right (min_le_left _ _))
        intro d hd hdn
        simp only [mem_Ioc, not_and, not_le] at hd hdn
        have hlt := hdn hd.1
        apply hFJ
        rcases le_total B (t J) with h | h
        · rw [min_eq_left h] at hlt; omega
        · rw [min_eq_right h] at hlt; exact hlt
      have hm2 : ∑ d ∈ Ioc 0 (min B (t J)), F d = ∑ d ∈ Ioc 0 (t J), F d := by
        apply sum_subset (Ioc_subset_Ioc_right (min_le_right _ _))
        intro d hd hdn
        simp only [mem_Ioc, not_and, not_le] at hd hdn
        have hlt := hdn hd.1
        apply hFB
        rcases le_total B (t J) with h | h
        · rw [min_eq_left h] at hlt; exact hlt
        · rw [min_eq_right h] at hlt; omega
      rw [← hm1, hm2]
    have h2 : ∑ d ∈ Ioc (t 0) (t J), F d = ∑ d ∈ Ioc 0 (t J), F d := by
      apply sum_subset (Ioc_subset_Ioc_left (Nat.zero_le _))
      intro d hd hdU
      simp only [mem_Ioc, not_and, not_lt] at hd hdU
      have : d ≤ U := by rw [← ht0]; by_contra h; exact absurd (hdU (lt_of_not_ge h)) (by omega)
      simp only [hF, hα0 d this, zero_mul]
    rw [h1, h2]
  rw [hext]
  have ht1 : 1 ≤ t 0 := by rw [ht0]; exact hU
  refine (decouple α (fun d m => β m * kphase c (d * m)) A B hAB t J
    ht1 htm).trans (add_le_add ?_ ?_)
  · -- main terms via `parseval_block`
    refine sum_le_sum fun j _ => ?_
    have htj : 1 ≤ t j := ht1.trans (htm (Nat.zero_le j))
    have hsub : Ioc (t j) (t (j + 1)) ⊆ Icc 1 (t (j + 1)) := by
      intro d hd; simp only [mem_Ioc, mem_Icc] at hd ⊢; omega
    have hpb := parseval_block P hP hsP c (t (j + 1)) (Ioc (t j) (t (j + 1))) hsub (A / t j) (B / t j)
      α β (Real.log B)
      (fun m hm => hβb m ((mem_Ioc.1 hm).2.trans (Nat.div_le_self _ _)))
    rw [← Real.sqrt_sq (norm_nonneg _)]
    apply Real.sqrt_le_sqrt
    refine (le_of_eq_of_le ?_ hpb).trans ?_
    · simp only [mul_sum]
    · have hsq : ∑ d ∈ Ioc (t j) (t (j + 1)), ‖α d‖ ^ 2 ≤
          ∑ d ∈ Ioc (t j) (t (j + 1)), ((d.divisors.card : ℝ)) ^ 2 := by
        refine sum_le_sum fun d _ => ?_
        exact pow_le_pow_left₀ (norm_nonneg _) (hαb d) 2
      have h0 : (0 : ℝ) ≤ (((t (j + 1) : ℕ) : ℝ) / s + 1) * s := by positivity
      have h0' : (0 : ℝ) ≤ Real.log B ^ 2 * (((B / t j - A / t j : ℕ) : ℝ) *
          (((B / t j - A / t j : ℕ) : ℝ) /
            ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ) + 1)) := by
        positivity
      rw [mul_assoc _ _ (s : ℝ), mul_assoc _ _ (s : ℝ)]
      exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hsq h0) h0'
  · -- boundary terms
    refine sum_le_sum fun j _ => sum_le_sum fun d _ => ?_
    have htj : 1 ≤ t j := ht1.trans (htm (Nat.zero_le j))
    have hα : ‖α d‖ ≤ (d.divisors.card : ℝ) := hαb d
    have hbd : ∀ x y : ℕ, y ≤ B → ∑ m ∈ Ioc x y, ‖β m * kphase c (d * m)‖ ≤
        Real.log B * ((y - x : ℕ) : ℝ) := by
      intro x y hy
      calc _ ≤ ∑ _m ∈ Ioc x y, Real.log B := by
            refine sum_le_sum fun m hm => ?_
            rw [norm_mul]
            calc _ ≤ Real.log B * 1 := mul_le_mul (hβb m ((mem_Ioc.1 hm).2.trans hy))
                  (norm_kphase_le c _) (norm_nonneg _) (Real.log_natCast_nonneg B)
              _ = _ := mul_one _
        _ = _ := by rw [sum_const, Nat.card_Ioc, nsmul_eq_mul, mul_comm]
    have hA' : A / t j ≤ B := (Nat.div_le_self _ _).trans hAB
    have hB' : B / t j ≤ B := Nat.div_le_self _ _
    refine mul_le_mul hα ?_ (by positivity) (by positivity)
    rw [mul_add]
    exact add_le_add (hbd _ _ hA') (hbd _ _ hB')


/-- **Type II, closed form** for the near-geometric partition. -/
theorem typeII_eval_gen (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p)
    (c : ZMod s) (U V T A B : ℕ) (hAB : A ≤ B) (hU : 2 ≤ U) (hT : 2 ≤ T)
    (α β : ℕ → ℂ) (hα0 : ∀ d, d ≤ U → α d = 0)
    (hαb : ∀ d, ‖α d‖ ≤ (d.divisors.card : ℝ)) (hβ0 : ∀ m, m ≤ V → β m = 0)
    (hβb : ∀ m, m ≤ B → ‖β m‖ ≤ Real.log B) :
    ‖∑ d ∈ Ioc 0 B, α d * ∑ m ∈ Ioc (A / d) (B / d), β m * kphase c (d * m)‖ ≤
      Real.sqrt (2 * (1 + Real.log (tseq U T (Jstop U T V B (by omega) (by omega)))) ^ 4) *
        Real.sqrt (Real.log B ^ 2 * B * (Jstop U T V B (by omega) (by omega) : ℝ) *
          (2 * B / ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ) +
            2 * (tseq U T (Jstop U T V B (by omega) (by omega)) : ℝ) +
            s * B / (U * ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ)) +
            s)) +
      Real.log B * (1 + Real.log (tseq U T (Jstop U T V B (by omega) (by omega)))) ^ 4 *
        (2 * B / T + 2 * B / U + 2 * (tseq U T (Jstop U T V B (by omega) (by omega)) : ℝ)) := by
  classical
  set J := Jstop U T V B (by omega) (by omega) with hJ
  set t := tseq U T with ht
  set tJ := t J with htJdef
  set g : ℕ := ∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p with hg
  have hg1 : 1 ≤ g := Nat.one_le_iff_ne_zero.2 (Finset.prod_ne_zero_iff.2 fun p hp =>
    (hP p (filter_subset _ _ hp)).ne_zero)
  have hs1 : 1 ≤ s := Nat.one_le_iff_ne_zero.2 (NeZero.ne s)
  have hspec : B < (V + 1) * t J := Jstop_spec V B (by omega) (by omega)
  have habs := typeII_gen P hP hsP c U V A B hAB t J rfl (by omega) tseq_mono hspec α β hα0 hαb hβ0 hβb
  refine habs.trans (add_le_add ?_ ?_)
  · -- main terms
    have htpos : ∀ j, (0 : ℝ) < t j := fun j => by
      have := tseq_ge (U := U) (T := T) j
      show (0 : ℝ) < (tseq U T j : ℝ)
      exact_mod_cast (show 0 < tseq U T j by omega)
    set X : ℕ → ℝ := fun j => ∑ d ∈ Ioc (t j) (t (j + 1)), ((d.divisors.card : ℝ)) ^ 2 with hX
    set Z : ℕ → ℝ := fun j => (((t (j + 1) : ℕ) : ℝ) / s + 1) * s *
      (Real.log B ^ 2 * (((B / t j - A / t j : ℕ) : ℝ) * (((B / t j - A / t j : ℕ) : ℝ) /
        (g : ℝ) + 1))) with hZ
    have hX0 : ∀ j, 0 ≤ X j := fun j => sum_nonneg fun _ _ => by positivity
    have hZ0 : ∀ j, 0 ≤ Z j := fun j => by simp only [hZ]; positivity
    have hsplit : ∀ j ∈ range J, Real.sqrt (X j * (((t (j + 1) : ℕ) : ℝ) / s + 1) * s *
        (Real.log B ^ 2 * (((B / t j - A / t j : ℕ) : ℝ) * (((B / t j - A / t j : ℕ) : ℝ) /
          (g : ℝ) + 1)))) = Real.sqrt (X j / t j) * Real.sqrt (t j * Z j) := by
      intro j _
      rw [← Real.sqrt_mul (div_nonneg (hX0 j) (htpos j).le)]
      congr 1
      simp only [hZ]
      have := (htpos j).ne'
      field_simp
    rw [sum_congr rfl hsplit]
    refine (Real.sum_sqrt_mul_sqrt_le _ (fun j => div_nonneg (hX0 j) (htpos j).le)
      (fun j => mul_nonneg (htpos j).le (hZ0 j))).trans ?_
    apply mul_le_mul _ _ (Real.sqrt_nonneg _) (Real.sqrt_nonneg _)
    · apply Real.sqrt_le_sqrt
      calc ∑ j ∈ range J, X j / t j
          ≤ ∑ j ∈ range J, ∑ d ∈ Ioc (t j) (t (j + 1)),
              2 * (((d.divisors.card : ℝ)) ^ 2 * (1 / (d : ℝ))) := by
            refine sum_le_sum fun j _ => ?_
            simp only [hX, sum_div]
            refine sum_le_sum fun d hd => ?_
            have hd' := mem_Ioc.1 hd
            have h2 := tseq_succ_le (U := U) hT hU j
            have hdR : (0 : ℝ) < d := by exact_mod_cast (show 0 < d by omega)
            have hd2 : (d : ℝ) ≤ 2 * t j := by exact_mod_cast hd'.2.trans h2
            rw [div_le_iff₀ (htpos j)]
            have : (0 : ℝ) ≤ ((d.divisors.card : ℝ)) ^ 2 := by positivity
            calc ((d.divisors.card : ℝ)) ^ 2 = ((d.divisors.card : ℝ)) ^ 2 * (d * (1 / d)) := by
                  field_simp
              _ ≤ ((d.divisors.card : ℝ)) ^ 2 * (2 * t j * (1 / d)) := by gcongr
              _ = _ := by ring
        _ = ∑ d ∈ Ioc (t 0) tJ, 2 * (((d.divisors.card : ℝ)) ^ 2 * (1 / (d : ℝ))) :=
            telescope_R _ t tseq_mono J
        _ ≤ ∑ d ∈ Ioc 0 tJ, 2 * (((d.divisors.card : ℝ)) ^ 2 * (1 / (d : ℝ))) :=
            sum_le_sum_of_subset_of_nonneg (Ioc_subset_Ioc_left (Nat.zero_le _))
              fun _ _ _ => by positivity
        _ = 2 * ∑ d ∈ Ioc 0 tJ, ((d.divisors.card : ℝ)) ^ 2 * (1 / (d : ℝ)) := by rw [mul_sum]
        _ ≤ 2 * (1 + Real.log tJ) ^ 4 := by
            gcongr; exact tau_sq_moment tJ
    · apply Real.sqrt_le_sqrt
      calc ∑ j ∈ range J, t j * Z j
          ≤ ∑ _j ∈ range J, Real.log B ^ 2 * B * (2 * B / g + 2 * tJ + s * B / (U * g) + s) := by
            refine sum_le_sum fun j hj => ?_
            have hjJ : j ≤ J := (mem_range.1 hj).le
            exact main_term_le A B U (t j) (t (j + 1)) tJ s g (by omega) (tseq_ge j)
              (tseq_succ_le hT hU j) (tseq_mono hjJ) hs1 hg1
        _ = _ := by rw [sum_const, card_range, nsmul_eq_mul]; ring
  · -- boundary terms
    have hlogB : 0 ≤ Real.log B := Real.log_natCast_nonneg B
    calc _ ≤ ∑ j ∈ range J, ∑ d ∈ Ioc (t j) (t (j + 1)), (d.divisors.card : ℝ) *
          (Real.log B * (2 * B / T * (1 / (d : ℝ)) + 2 * B / U * (1 / (d : ℝ)) + 2)) := by
          refine sum_le_sum fun j _ => sum_le_sum fun d hd => ?_
          apply mul_le_mul_of_nonneg_left _ (by positivity)
          apply mul_le_mul_of_nonneg_left _ hlogB
          have hd' : d ∈ Ioc (t j) (t j + t j / T + 1) := by rw [← tseq_succ]; exact hd
          have h1 := delta_le A U T (t j) d (by omega) (by omega) (tseq_ge j) hd'
          have h2 := delta_le B U T (t j) d (by omega) (by omega) (tseq_ge j) hd'
          rw [← tseq_succ] at h1 h2
          have hAB' : (A : ℝ) ≤ B := by exact_mod_cast hAB
          have hdR : (0 : ℝ) < d := by
            have := (mem_Ioc.1 hd).1; exact_mod_cast (show 0 < d by omega)
          have hTR : (0 : ℝ) < T := by exact_mod_cast (show 0 < T by omega)
          have hUR : (0 : ℝ) < U := by exact_mod_cast (show 0 < U by omega)
          have e1 : (A : ℝ) / (T * d) ≤ (B : ℝ) / (T * d) := by gcongr
          have e2 : (A : ℝ) / (U * d) ≤ (B : ℝ) / (U * d) := by gcongr
          have e3 : 2 * (B : ℝ) / T * (1 / d) + 2 * B / U * (1 / d) + 2 =
              2 * ((B : ℝ) / (T * d) + (B : ℝ) / (U * d) + 1) := by field_simp
          rw [e3]; linarith
      _ = ∑ d ∈ Ioc (t 0) tJ, (d.divisors.card : ℝ) *
          (Real.log B * (2 * B / T * (1 / (d : ℝ)) + 2 * B / U * (1 / (d : ℝ)) + 2)) :=
          telescope_R _ t tseq_mono J
      _ ≤ ∑ d ∈ Ioc 0 tJ, (d.divisors.card : ℝ) *
          (Real.log B * (2 * B / T * (1 / (d : ℝ)) + 2 * B / U * (1 / (d : ℝ)) + 2)) :=
          sum_le_sum_of_subset_of_nonneg (Ioc_subset_Ioc_left (Nat.zero_le _))
            fun _ _ _ => by positivity
      _ = Real.log B * ((2 * B / T + 2 * B / U) *
            ∑ d ∈ Ioc 0 tJ, (d.divisors.card : ℝ) * (1 / (d : ℝ)) +
          2 * ∑ d ∈ Ioc 0 tJ, (d.divisors.card : ℝ)) := by
          rw [mul_sum, mul_sum, ← sum_add_distrib, mul_sum]
          refine sum_congr rfl fun d _ => by ring
      _ ≤ Real.log B * ((2 * B / T + 2 * B / U) * (1 + Real.log tJ) ^ 4 +
          2 * (tJ * (1 + Real.log tJ) ^ 4)) := by
          gcongr
          · exact tau_div_sum tJ
          · exact tau_sum tJ
      _ = _ := by ring

end

end GoldC.QuillonTypeIIGen

#print axioms GoldC.QuillonTypeIIGen.typeII_gen
#print axioms GoldC.QuillonTypeIIGen.typeII_eval_gen
