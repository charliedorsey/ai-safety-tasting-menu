import PaperB.FixedQ.SignedForbiddenIriamTorvenFarBridge
import PaperB.FixedQ.GlobalProperSplitTerminal

open Real
namespace PaperB.FixedQ

/-- If the literal signed quarter-middle is sublog at the true source cutoff,
then the entire global proper exterior is sublog. The quarter-far complement
is already paid by Iriam/Torven. -/
theorem globalProperExteriorSublog_of_quarterMiddleSublog
    (q : ℕ) (hq : 0 < q)
    (hMid :
      ∀ eps : ℝ, 0 < eps →
        ∃ H0 : ℕ, ∀ a h : ℕ,
          q.Coprime a →
          0 < h →
          (¬ 2 ∣ q → 2 ∣ h) →
          H0 ≤ h →
          |tavrenGlobalExteriorQuarterMiddle q a h
            (globalProperBooleanProductCutoff h)| ≤
            eps * Real.log (h : ℝ)) :
    GlobalProperExteriorSublog q := by
  intro eps heps
  let delta : ℝ := eps / 2
  have hdelta : 0 < delta := by
    dsimp [delta]
    positivity
  obtain ⟨Hmid, hmid⟩ := hMid delta hdelta
  obtain ⟨Hfar, hfar⟩ := iriam_globalExterior_sub_middle_sublog q hq delta hdelta
  refine ⟨max Hmid Hfar, ?_⟩
  intro a h ha hh h2 hlarge
  have hmidh : Hmid ≤ h := (le_max_left Hmid Hfar).trans hlarge
  have hfarh : Hfar ≤ h := (le_max_right Hmid Hfar).trans hlarge
  have hm := hmid a h ha hh h2 hmidh
  have hf := hfar a h h2 hh hfarh
  have htri :
      |globalProperExteriorAnalytic q a h
          (globalProperBooleanProductCutoff h)| ≤
        |globalProperExteriorAnalytic q a h
            (globalProperBooleanProductCutoff h) -
          tavrenGlobalExteriorQuarterMiddle q a h
            (globalProperBooleanProductCutoff h)| +
        |tavrenGlobalExteriorQuarterMiddle q a h
            (globalProperBooleanProductCutoff h)| := by
    have h := abs_add_le
      (globalProperExteriorAnalytic q a h (globalProperBooleanProductCutoff h) -
        tavrenGlobalExteriorQuarterMiddle q a h (globalProperBooleanProductCutoff h))
      (tavrenGlobalExteriorQuarterMiddle q a h (globalProperBooleanProductCutoff h))
    convert h using 1 <;> ring
  calc
    |globalProperExteriorAnalytic q a h (globalProperBooleanProductCutoff h)|
      ≤ |globalProperExteriorAnalytic q a h (globalProperBooleanProductCutoff h) -
          tavrenGlobalExteriorQuarterMiddle q a h (globalProperBooleanProductCutoff h)| +
        |tavrenGlobalExteriorQuarterMiddle q a h (globalProperBooleanProductCutoff h)| := htri
    _ ≤ delta * Real.log (h : ℝ) + delta * Real.log (h : ℝ) := by
      exact add_le_add hf hm
    _ = eps * Real.log (h : ℝ) := by
      dsimp [delta]
      ring

/-- The literal quarter-middle sublog estimate is enough for Paper B terminal. -/
theorem paperBTerminal_of_quarterMiddleSublog
    (hMid :
      ∀ q : ℕ, 0 < q → Squarefree q →
        ∀ eps : ℝ, 0 < eps →
          ∃ H0 : ℕ, ∀ a h : ℕ,
            q.Coprime a →
            0 < h →
            (¬ 2 ∣ q → 2 ∣ h) →
            H0 ≤ h →
            |tavrenGlobalExteriorQuarterMiddle q a h
              (globalProperBooleanProductCutoff h)| ≤
              eps * Real.log (h : ℝ)) :
    PaperB.Closure.PaperBTerminalStatement := by
  apply paperBTerminal_of_globalProper_split
  intro q hq hsq
  exact globalProperExteriorSublog_of_quarterMiddleSublog q hq (hMid q hq hsq)

#print axioms globalProperExteriorSublog_of_quarterMiddleSublog
#print axioms paperBTerminal_of_quarterMiddleSublog

end PaperB.FixedQ
