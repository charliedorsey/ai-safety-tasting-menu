import PaperB.FixedQ.RowReduction

open scoped BigOperators

namespace PaperB.FixedQ

/-- If the height is odd, the p=2 endpoint density denominator vanishes,
and Lean's exact source local-ratio convention returns zero. -/
theorem tavren_occupiedLocalRatio_two_eq_zero_of_odd
    (H y : ℕ) (hodd : ¬ 2 ∣ H) :
    occupiedAnchoredLocalFactorRatio 2 H y = 0 := by
  have hend : endpointOccupiedCount 2 H = 2 := by
    rw [endpointOccupiedCount_eq]
    simp [endpointResidueCount, hodd]
  simp [occupiedAnchoredLocalFactorRatio, hend]

/-- The source low-prime weight has absolute value at most six for all
heights. In the parity-inadmissible case the p=2 source factor is zero. -/
theorem tavren_abs_occupiedFixedQLowWeight_le_six
    (q a H y : ℕ) :
    |occupiedFixedQLowWeight q a H y| ≤ 6 := by
  by_cases hcompat : ¬ 2 ∣ q → 2 ∣ H
  · exact abs_occupiedFixedQLowWeight_le_six q a H y hcompat
  · have h2q : ¬ 2 ∣ q := by
      intro h2q
      exact hcompat (fun hnot => (hnot h2q).elim)
    have h2H : ¬ 2 ∣ H := by
      intro h2H
      exact hcompat (fun _ => h2H)
    have hr : occupiedAnchoredLocalFactorRatio 2 H y = 0 :=
      tavren_occupiedLocalRatio_two_eq_zero_of_odd H y h2H
    have hf : occupiedLowPrimeFactor q H y = 0 := by
      by_cases h3q : 3 ∣ q
      · simp [occupiedLowPrimeFactor, lowPrimeSet, h2q, h3q, hr]
      · simp [occupiedLowPrimeFactor, lowPrimeSet, h2q, h3q, hr]
    rw [occupiedFixedQLowWeight_eq_indicator_mul_factor, hf]
    simp

#print axioms tavren_occupiedLocalRatio_two_eq_zero_of_odd
#print axioms tavren_abs_occupiedFixedQLowWeight_le_six

end PaperB.FixedQ
