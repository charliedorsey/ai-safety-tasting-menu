import OrielLR.Saw

/-!
# Oriel L/R — exact complete-class cancellation of the sawtooth constant

`∑_{v ∈ (ZMod P)ˣ} ∑_{t ∈ (ZMod m)ˣ} C(v, t) = 0` whenever `m ∤ H`:
pair `j ↔ Q - j` with `(v, t) ↔ (-v, -t)`; the endpoint `j = Q` carries the
condition `H ≡ 0 (mod m)` and is empty.
-/

open Finset

namespace OrielUpper

variable {P : ℕ} [NeZero P]

lemma rowF_reflect {m H : ℕ} {Λ : ZMod P → ℝ} {α β v : ZMod P} {t : ZMod m} {j : ℕ}
    (hj : j ≤ P * m) :
    rowF m H Λ α β (-v) (-t) (P * m - j) = rowF m H Λ α β v t j := by
  unfold rowF
  have h1 : (((P * m - j : ℕ)) : ZMod P) = -(j : ZMod P) := by
    rw [Nat.cast_sub hj]; push_cast; rw [ZMod.natCast_self]; ring
  have h2 : (((P * m - j : ℕ)) : ZMod m) = -(j : ZMod m) := by
    rw [Nat.cast_sub hj]; push_cast; rw [ZMod.natCast_self]; ring
  rw [h1, h2]
  congr 1
  · congr 1; ring
  · congr 1; apply propext; constructor <;> intro h <;> rw [h] <;> ring

theorem sawC_class_sum_zero {m H : ℕ} [NeZero m] (hH : ¬ m ∣ H) (Λ : ZMod P → ℝ)
    (α β : ZMod P) :
    ∑ v : (ZMod P)ˣ, ∑ t : (ZMod m)ˣ, sawC m H Λ α β (v : ZMod P) (t : ZMod m) = 0 := by
  have hm : 0 < m := NeZero.pos m
  set Q := P * m with hQ
  have hQ0 : 0 < Q := Nat.mul_pos (NeZero.pos P) hm
  have hQr : (0 : ℝ) < Q := by exact_mod_cast hQ0
  set T : ZMod P → ZMod m → ℕ → ℝ := fun v t j =>
    rowF m H Λ α β v t j * (1 / 2 - (j : ℝ) / (Q : ℕ))
  -- endpoint vanishes
  have hend : ∀ v t, rowF m H Λ α β v t Q = 0 := by
    intro v t
    unfold rowF
    rw [if_neg, mul_zero]
    intro h
    apply hH
    have : (Q : ZMod m) = 0 := by rw [hQ]; push_cast; rw [ZMod.natCast_self, mul_zero]
    rw [this, mul_zero] at h
    exact (ZMod.natCast_eq_zero_iff H m).mp h
  have hsplit : ∀ v t, sawC m H Λ α β v t = ∑ j ∈ Icc 1 (Q - 1), T v t j := by
    intro v t
    unfold sawC
    have : Icc 1 Q = insert Q (Icc 1 (Q - 1)) := by
      ext j; simp only [mem_insert, mem_Icc]; omega
    rw [this, sum_insert (by simp only [mem_Icc]; omega), hend, zero_mul, zero_add]
  simp_rw [hsplit]
  set S := ∑ v : (ZMod P)ˣ, ∑ t : (ZMod m)ˣ, ∑ j ∈ Icc 1 (Q - 1), T v t j
  have hneg : S = -S := by
    have hT : ∀ (v : ZMod P) (t : ZMod m) j, j ∈ Icc 1 (Q - 1) → T (-v) (-t) (Q - j) = -T v t j := by
      intro v t j hj
      rw [mem_Icc] at hj
      simp only [T]
      rw [rowF_reflect (by omega)]
      have : ((Q - j : ℕ) : ℝ) = (Q : ℝ) - j := by rw [Nat.cast_sub (by omega)]
      rw [this]
      field_simp
      ring
    have hj : ∀ (v : ZMod P) (t : ZMod m),
        ∑ j ∈ Icc 1 (Q - 1), T v t j = ∑ j ∈ Icc 1 (Q - 1), T v t (Q - j) := by
      intro v t
      apply Finset.sum_nbij' (fun j => Q - j) (fun j => Q - j)
      · intro j hj; simp only [Finset.mem_coe, Finset.mem_Icc, Set.mem_Icc, Finset.coe_Icc] at hj ⊢; omega
      · intro j hj; simp only [Finset.mem_coe, Finset.mem_Icc, Set.mem_Icc, Finset.coe_Icc] at hj ⊢; omega
      · intro j hj; simp only [Finset.mem_coe, Finset.mem_Icc, Set.mem_Icc, Finset.coe_Icc] at hj ⊢; omega
      · intro j hj; simp only [Finset.mem_coe, Finset.mem_Icc, Set.mem_Icc, Finset.coe_Icc] at hj ⊢; omega
      · intro j hj
        simp only [Finset.mem_coe, Finset.mem_Icc, Set.mem_Icc, Finset.coe_Icc] at hj
        rw [show Q - (Q - j) = j by omega]
    calc S = ∑ v : (ZMod P)ˣ, ∑ t : (ZMod m)ˣ, ∑ j ∈ Icc 1 (Q - 1),
          T ((-v : (ZMod P)ˣ) : ZMod P) ((-t : (ZMod m)ˣ) : ZMod m) j := by
          simp only [S]
          rw [← Fintype.sum_equiv (Equiv.neg (ZMod P)ˣ) _ _ (fun v => rfl)]
          apply sum_congr rfl; intro v _
          rw [← Fintype.sum_equiv (Equiv.neg (ZMod m)ˣ) _ _ (fun t => rfl)]
          simp only [Equiv.neg_apply, neg_neg]
      _ = ∑ v : (ZMod P)ˣ, ∑ t : (ZMod m)ˣ, ∑ j ∈ Icc 1 (Q - 1),
          T (-(v : ZMod P)) (-(t : ZMod m)) (Q - j) := by
          apply sum_congr rfl; intro v _; apply sum_congr rfl; intro t _
          rw [hj]; simp only [Units.val_neg]
      _ = ∑ v : (ZMod P)ˣ, ∑ t : (ZMod m)ˣ, ∑ j ∈ Icc 1 (Q - 1), -T v t j := by
          apply sum_congr rfl; intro v _; apply sum_congr rfl; intro t _
          apply sum_congr rfl; intro j hj; exact hT _ _ j hj
      _ = -S := by simp only [S, sum_neg_distrib]
  linarith

end OrielUpper
