import OrielLR.Hyp

/-!
# Oriel L/R — the inner sum with the classical reciprocal input

For a head divisor `e` (coprime to `Q = P m`):

`|innerS e| ≤ (Q (P+1) B / (A/e) + (P+1) B Lb C (E₀ + Bn Q / X₀)) / e`

The first term is the complete-class cancellation of the sawtooth constant
(exact, `sawC_class_sum_zero`); the second is the long reciprocal sawtooth, where
the single classical input `ShiftedKaratsuba` is used.
-/

open Finset

namespace OrielUpper

variable {P : ℕ} [NeZero P]

lemma sum_abs_rowF_le {m H : ℕ} [NeZero m] {Λ : ZMod P → ℝ} {B : ℝ} (hB : ∀ z, |Λ z| ≤ B)
    {α β v : ZMod P} {t : ZMod m} (ht : IsUnit t) :
    ∑ j ∈ Icc 1 (P * m), |rowF m H Λ α β v t j| ≤ ((P : ℝ) + 1) * B := by
  have hB0 : 0 ≤ B := le_trans (abs_nonneg _) (hB 0)
  have hmr : (0 : ℝ) < m := by exact_mod_cast NeZero.pos m
  calc ∑ j ∈ Icc 1 (P * m), |rowF m H Λ α β v t j|
      ≤ ∑ j ∈ Icc 1 (P * m), (if (H : ZMod m) = t * (j : ZMod m) then B else 0) := by
        apply sum_le_sum; intro j _
        unfold rowF
        split_ifs
        · rw [mul_one]; exact hB _
        · simp
    _ = B * (rowN m H t ((P * m : ℕ) : ℝ) : ℝ) := by
        rw [← sum_filter, sum_const, nsmul_eq_mul, mul_comm]
        unfold rowN; rw [Nat.floor_natCast]
    _ ≤ B * (((P * m : ℕ) : ℝ) / m + 1) :=
        mul_le_mul_of_nonneg_left (rowN_le ht (by positivity)) hB0
    _ = ((P : ℝ) + 1) * B := by push_cast; field_simp

lemma tele_inv (a n : ℕ) :
    ∑ i ∈ range n, |(1 : ℝ) / ((a + 1 + (i + 1) : ℕ) : ℝ) - 1 / ((a + 1 + i : ℕ) : ℝ)| ≤
      1 / ((a + 1 : ℕ) : ℝ) := by
  have h : ∀ i ∈ range n, |(1 : ℝ) / ((a + 1 + (i + 1) : ℕ) : ℝ) - 1 / ((a + 1 + i : ℕ) : ℝ)| =
      (fun i : ℕ => (1 : ℝ) / ((a + 1 + i : ℕ) : ℝ)) i -
        (fun i : ℕ => (1 : ℝ) / ((a + 1 + i : ℕ) : ℝ)) (i + 1) := by
    intro i _
    simp only
    rw [abs_sub_comm, abs_of_nonneg]
    apply sub_nonneg.mpr
    apply one_div_le_one_div_of_le (by positivity)
    exact_mod_cast (show a + 1 + i ≤ a + 1 + (i + 1) by omega)
  rw [sum_congr rfl h, sum_range_sub']
  simp only [add_zero]
  have : 0 ≤ (1 : ℝ) / ((a + 1 + n : ℕ) : ℝ) := by positivity
  linarith

/-- Harmonic mass of one class vs. the average. -/
lemma class_harmonic_close {Q : ℕ} (hQ : 0 < Q) (c : ℕ) {a b : ℕ} (ha : 1 ≤ a) (hab : a ≤ b) :
    |∑ k ∈ (Ioc a b).filter (fun k => k ≡ c [MOD Q]), (1 : ℝ) / k -
        (∑ k ∈ Ioc a b, (1 : ℝ) / k) / Q| ≤ 2 / a := by
  have hbv := oriel_bv_progression hQ c a b hab (fun k : ℕ => (1 : ℝ) / k)
  refine hbv.trans ?_
  have har : (0 : ℝ) < a := by exact_mod_cast (show 0 < a by omega)
  have h1 : |(1 : ℝ) / (b : ℝ)| ≤ 1 / a := by
    rw [abs_of_nonneg (by positivity)]
    exact one_div_le_one_div_of_le har (by exact_mod_cast hab)
  have h2 := tele_inv a (b - a - 1)
  have h3 : (1 : ℝ) / ((a + 1 : ℕ) : ℝ) ≤ 1 / a :=
    one_div_le_one_div_of_le har (by exact_mod_cast (show a ≤ a + 1 by omega))
  have e : ∀ i ∈ range (b - a - 1),
      |(fun k : ℕ => (1 : ℝ) / k) (a + 1 + (i + 1)) - (fun k : ℕ => (1 : ℝ) / k) (a + 1 + i)| =
      |(1 : ℝ) / ((a + 1 + (i + 1) : ℕ) : ℝ) - 1 / ((a + 1 + i : ℕ) : ℝ)| := by
    intro i _; rfl
  rw [sum_congr rfl e]
  have : (2 : ℝ) / a = 1 / a + 1 / a := by ring
  linarith

/-- Reindexing a residue class of an interval along `k = c + Q i`. -/
lemma sum_class_reindex {Q c a b : ℕ} (hQ : 0 < Q) (hc : c < Q) (hca : c ≤ a) (f : ℕ → ℝ) :
    ∑ k ∈ (Ioc a b).filter (fun k => k ≡ c [MOD Q]), f k =
      ∑ i ∈ Ioc ((a - c) / Q) ((b - c) / Q), f (c + Q * i) := by
  have hmodk : ∀ k, k ≡ c [MOD Q] → c + Q * (k / Q) = k := by
    intro k h3
    unfold Nat.ModEq at h3
    rw [Nat.mod_eq_of_lt hc] at h3
    have := Nat.mod_add_div k Q
    rw [h3] at this; exact this
  symm
  apply Finset.sum_bij' (fun i _ => c + Q * i) (fun k _ => k / Q)
  · intro i hi
    rw [mem_Ioc] at hi
    rw [mem_filter, mem_Ioc]
    obtain ⟨h1, h2⟩ := hi
    rw [Nat.div_lt_iff_lt_mul hQ] at h1
    rw [Nat.le_div_iff_mul_le hQ] at h2
    have h1' : a - c < Q * i := by rw [mul_comm]; exact h1
    have h2' : Q * i ≤ b - c := by rw [mul_comm]; exact h2
    refine ⟨⟨?_, ?_⟩, ?_⟩
    · generalize Q * i = A at h1' ⊢; omega
    · generalize Q * i = A at h2' ⊢; omega
    · unfold Nat.ModEq; rw [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt hc]
  · intro k hk
    rw [mem_filter, mem_Ioc] at hk
    obtain ⟨⟨h1, h2⟩, h3⟩ := hk
    have hk := hmodk k h3
    rw [mem_Ioc]
    constructor
    · rw [Nat.div_lt_iff_lt_mul hQ, mul_comm]
      have : Q * (k / Q) = k - c := by omega
      rw [this]; omega
    · rw [Nat.le_div_iff_mul_le hQ, mul_comm]
      have : Q * (k / Q) = k - c := by omega
      rw [this]; omega
  · intro i _
    rw [Nat.add_mul_div_left _ _ hQ, Nat.div_eq_of_lt hc, zero_add]
  · intro k hk
    rw [mem_filter] at hk
    exact hmodk k hk.2
  · intro i _; rfl

end OrielUpper
