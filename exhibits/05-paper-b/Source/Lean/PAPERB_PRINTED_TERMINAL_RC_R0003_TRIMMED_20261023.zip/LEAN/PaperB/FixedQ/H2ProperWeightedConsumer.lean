import PaperB.FixedQ.H2ProperFourierET
import PaperB.FixedQ.H2ProperRootInterface
import PaperB.FixedQ.H2BooleanPeriodicWeightedET
import PaperB.FixedQ.H2PeriodicTwistCoherence

open scoped BigOperators ComplexConjugate

namespace PaperB.FixedQ

noncomputable def fixedQProperWeightedDiscrepancy
    (q A H : ℕ) (S : Finset ℕ) : ℝ :=
  ((2 : ℝ) ^ S.card)⁻¹ *
    ∑ e1 ∈ ((S.powerset.erase S).erase ∅),
      fixedProductPartitionDiscrepancy
        (fixedQLowWeight q A H) H S e1

theorem ordinaryBooleanInteriorDiscrepancy_eq_pow_mul_properWeighted
    (q A H : ℕ) (S : Finset ℕ) :
    ordinaryBooleanInteriorDiscrepancy
        (fixedQLowWeight q A H) H S =
      (2 : ℝ) ^ S.card *
        fixedQProperWeightedDiscrepancy q A H S := by
  unfold ordinaryBooleanInteriorDiscrepancy fixedQProperWeightedDiscrepancy
  have hp : (2 : ℝ) ^ S.card ≠ 0 := by positivity
  field_simp [hp]

lemma fixedProductPartitionDiscrepancy_eq_fiber_sub_mean
    {q A H : ℕ} {S e1 : Finset ℕ}
    (he1 : e1 ⊆ S)
    (hPrime : ∀ p ∈ S, p.Prime) :
    fixedProductPartitionDiscrepancy
        (fixedQLowWeight q A H) H S e1 =
      fixedQBooleanResidueFiberMass q A H S e1 -
        rowWeightMass (fixedQLowWeight q A H) H /
          (primeSetProduct S : ℝ) := by
  unfold fixedProductPartitionDiscrepancy rowDiscrepancy
  rw [fixedProductPartition_constrainedMass_eq_crtResidueFiberMass he1 hPrime]
  have hm := pair_moduli_product_eq_fixedProduct he1 hPrime
  rw [show ((primeSetProduct e1 : ℝ) *
      (primeSetProduct (S \ e1) : ℝ)) =
      (primeSetProduct S : ℝ) by exact_mod_cast hm]

lemma fixedQProperWeightedDiscrepancy_eq_fiber_centered
    {q A H : ℕ} {S : Finset ℕ}
    (hPrime : ∀ p ∈ S, p.Prime) :
    fixedQProperWeightedDiscrepancy q A H S =
      ((2 : ℝ) ^ S.card)⁻¹ *
        ∑ e1 ∈ ((S.powerset.erase S).erase ∅),
          (fixedQBooleanResidueFiberMass q A H S e1 -
            rowWeightMass (fixedQLowWeight q A H) H /
              (primeSetProduct S : ℝ)) := by
  unfold fixedQProperWeightedDiscrepancy
  congr 1
  apply Finset.sum_congr rfl
  intro e1 he1
  have hpw : e1 ∈ S.powerset :=
    (Finset.mem_erase.mp (Finset.mem_erase.mp he1).2).2
  exact fixedProductPartitionDiscrepancy_eq_fiber_sub_mean
    (Finset.mem_powerset.mp hpw) hPrime

theorem periodic_weighted_proper_discrepancy_eq_affine_sum
    {f : ℕ → ℝ} {P H : ℕ} {S : Finset ℕ}
    (hPrime : ∀ p ∈ S, p.Prime)
    (hPpos : 0 < P)
    (hper : Function.Periodic f P)
    (hPcop : P.Coprime (primeSetProduct S))
    (hHcop : H.Coprime (primeSetProduct S)) :
    ((2 : ℝ) ^ S.card)⁻¹ *
      ∑ A ∈ ((S.powerset.erase S).erase ∅),
        ((∑ y ∈ Finset.Ioo 0 H,
            if y ≡ H * fixedProductCRTIdempotentNat S A
                [MOD primeSetProduct S]
            then f y else 0) -
          (∑ y ∈ Finset.Ioo 0 H, f y) /
            (primeSetProduct S : ℝ)) =
      ∑ c : Fin P,
        f (c.1 + 1) *
          fixedProductProperAffineRootIntervalDiscrepancy
            S hPrime
            (fixedProductBooleanPeriodicTwist P H S hPcop hHcop)
            (fixedProductBooleanPeriodicShift P S hPcop c.1)
            (periodicResidueLength P H c.1 % primeSetProduct S) := by
  classical
  let m := primeSetProduct S
  have hmpos : 0 < m := primeSetProduct_pos hPrime
  letI : NeZero m := ⟨hmpos.ne'⟩
  let u := fixedProductBooleanPeriodicTwist P H S hPcop hHcop
  let v : Fin P → ZMod m :=
    fun c => fixedProductBooleanPeriodicShift P S hPcop c.1
  let L : Fin P → ℕ := fun c => periodicResidueLength P H c.1
  let proper := ((S.powerset.erase S).erase ∅)
  have hfiber : ∀ A ∈ proper,
      (∑ y ∈ Finset.Ioo 0 H,
        if y ≡ H * fixedProductCRTIdempotentNat S A [MOD m]
        then f y else 0) =
      ∑ c : Fin P, f (c.1 + 1) *
        ∑ n : Fin (L c),
          if n.1 ≡
            (((u : (ZMod m)ˣ) : ZMod m) *
                (fixedProductCRTIdempotentNat S A : ZMod m) +
              v c).val [MOD m]
          then (1 : ℝ) else 0 := by
    intro A hA
    rw [periodic_weighted_modEq_sum_decompose hPpos hper]
    apply Fintype.sum_congr
    intro c
    congr 1
    apply Fintype.sum_congr
    intro n
    have hiff := periodic_progression_modEq_iff_affine
      (S := S) (n := n.1) (c := c.1) hmpos hPcop hHcop
      (fixedProductCRTIdempotentNat S A)
    dsimp [L, periodicResidueLength, u, v]
    by_cases hz :
        c.1 + 1 + P * n.1 ≡
          H * fixedProductCRTIdempotentNat S A [MOD m]
    · rw [if_pos hz, if_pos (hiff.mp hz)]
    · rw [if_neg hz, if_neg (fun h => hz (hiff.mpr h))]
  have hmass :
      (∑ y ∈ Finset.Ioo 0 H, f y) =
        ∑ c : Fin P, f (c.1 + 1) * (L c : ℝ) := by
    simpa [L, periodicResidueLength] using
      (periodic_weight_sum_decompose
        (f := f) (P := P) (H := H) hPpos hper)
  have hcentered : ∀ A ∈ proper,
      ((∑ y ∈ Finset.Ioo 0 H,
          if y ≡ H * fixedProductCRTIdempotentNat S A [MOD m]
          then f y else 0) -
        (∑ y ∈ Finset.Ioo 0 H, f y) / (m : ℝ)) =
      ∑ c : Fin P, f (c.1 + 1) *
        ((∑ n : Fin (L c),
            if n.1 ≡
              (((u : (ZMod m)ˣ) : ZMod m) *
                  (fixedProductCRTIdempotentNat S A : ZMod m) +
                v c).val [MOD m]
            then (1 : ℝ) else 0) -
          (L c : ℝ) / (m : ℝ)) := by
    intro A hA
    rw [hfiber A hA, hmass, Finset.sum_div]
    rw [← Finset.sum_sub_distrib]
    apply Fintype.sum_congr
    intro c
    ring
  rw [show primeSetProduct S = m by rfl]
  rw [show fixedProductBooleanPeriodicTwist P H S hPcop hHcop = u by rfl]
  have hsumCentered :
      (∑ A ∈ proper,
        ((∑ y ∈ Finset.Ioo 0 H,
          if y ≡ H * fixedProductCRTIdempotentNat S A [MOD m]
          then f y else 0) -
        (∑ y ∈ Finset.Ioo 0 H, f y) / (m : ℝ))) =
      ∑ A ∈ proper,
        ∑ c : Fin P, f (c.1 + 1) *
          ((∑ n : Fin (L c),
            if n.1 ≡
              (((u : (ZMod m)ˣ) : ZMod m) *
                  (fixedProductCRTIdempotentNat S A : ZMod m) +
                v c).val [MOD m]
            then (1 : ℝ) else 0) -
          (L c : ℝ) / (m : ℝ)) := by
    apply Finset.sum_congr rfl
    intro A hA
    exact hcentered A hA
  rw [show
      (∑ A ∈ ((S.powerset.erase S).erase ∅),
        ((∑ y ∈ Finset.Ioo 0 H,
          if y ≡ H * fixedProductCRTIdempotentNat S A [MOD m]
          then f y else 0) -
        (∑ y ∈ Finset.Ioo 0 H, f y) / (m : ℝ))) =
      ∑ A ∈ proper,
        ((∑ y ∈ Finset.Ioo 0 H,
          if y ≡ H * fixedProductCRTIdempotentNat S A [MOD m]
          then f y else 0) -
        (∑ y ∈ Finset.Ioo 0 H, f y) / (m : ℝ)) by rfl]
  rw [hsumCentered]
  let g : Finset ℕ → Fin P → ℝ := fun A c =>
    (∑ n : Fin (L c),
      if n.1 ≡
        (((u : (ZMod m)ˣ) : ZMod m) *
            (fixedProductCRTIdempotentNat S A : ZMod m) +
          v c).val [MOD m]
      then (1 : ℝ) else 0) -
    (L c : ℝ) / (m : ℝ)
  calc
    ((2 : ℝ) ^ S.card)⁻¹ *
        (∑ A ∈ proper, ∑ c : Fin P, f (c.1 + 1) * g A c)
      = ∑ A ∈ proper,
          ((2 : ℝ) ^ S.card)⁻¹ *
            (∑ c : Fin P, f (c.1 + 1) * g A c) := by
          rw [Finset.mul_sum]
    _ = ∑ c : Fin P, f (c.1 + 1) *
          (((2 : ℝ) ^ S.card)⁻¹ * ∑ A ∈ proper, g A c) := by
          exact finite_weighted_sum_swap
            proper ((2 : ℝ) ^ S.card)⁻¹
            (fun c : Fin P => f (c.1 + 1)) g
    _ = _ := by
      apply Fintype.sum_congr
      intro c
      congr 1
      unfold fixedProductProperAffineRootIntervalDiscrepancy
      dsimp [proper, v, g]
      congr 1
      apply Finset.sum_congr rfl
      intro A hA
      rw [Fin.sum_univ_eq_sum_range
        (fun n : ℕ =>
          if n ≡
            ((((u : (ZMod m)ˣ) : ZMod m) *
              (fixedProductCRTIdempotentNat S A : ZMod m) +
              fixedProductBooleanPeriodicShift P S hPcop c.1).val)
              [MOD m]
          then (1 : ℝ) else 0)
        (L c)]
      have hres := residue_prefix_discrepancy_eq_indicator
        (m := m) (L := L c)
        (t := (((u : (ZMod m)ˣ) : ZMod m) *
          (fixedProductCRTIdempotentNat S A : ZMod m) +
          fixedProductBooleanPeriodicShift P S hPcop c.1).val)
        hmpos (ZMod.val_lt _)
      simpa [L, periodicResidueLength] using hres

theorem fixedQProperWeightedDiscrepancy_eq_periodic_affine_sum
    {q A H : ℕ} {S : Finset ℕ}
    (hq : 0 < q)
    (hActive : ∀ p ∈ S, activeHighPrime q p)
    (hOrd : S ∈ ordinaryTwoDimensionalSet H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H) :
    fixedQProperWeightedDiscrepancy q A H S =
      ∑ c : Fin (fixedQPeriod q),
        occupiedFixedQLowWeight q A H (c.1 + 1) *
          fixedProductProperAffineRootIntervalDiscrepancy
            S (fun p hp => (hActive p hp).1)
            (fixedProductBooleanPeriodicTwist
              (fixedQPeriod q) H S
              (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
              ((ordinary_primeSetProduct_coprime_height_iff
                (fun p hp => (hActive p hp).1)).mp hOrd).symm)
            (fixedProductBooleanPeriodicShift
              (fixedQPeriod q) S
              (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm c.1)
            (periodicResidueLength (fixedQPeriod q) H c.1 %
              primeSetProduct S) := by
  let hPrime : ∀ p ∈ S, p.Prime := fun p hp => (hActive p hp).1
  have hPpos := fixedQPeriod_pos q hq
  have hPcop :=
    (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
  have hHcop : H.Coprime (primeSetProduct S) :=
    ((ordinary_primeSetProduct_coprime_height_iff hPrime).mp hOrd).symm
  rw [fixedQProperWeightedDiscrepancy_eq_fiber_centered hPrime]
  have hfiber : ∀ e1 ∈ ((S.powerset.erase S).erase ∅),
      fixedQBooleanResidueFiberMass q A H S e1 =
        ∑ y ∈ Finset.Ioo 0 H,
          if y ≡ H * fixedProductCRTIdempotentNat S e1
              [MOD primeSetProduct S]
          then occupiedFixedQLowWeight q A H y else 0 := by
    intro e1 he1
    exact fixedQBooleanResidueFiberMass_eq_occupied h2admissible
  have hmass :
      rowWeightMass (fixedQLowWeight q A H) H =
        ∑ y ∈ Finset.Ioo 0 H,
          occupiedFixedQLowWeight q A H y := by
    rw [rowWeightMass_fixedQLowWeight_eq_occupied h2admissible]
    rfl
  rw [hmass]
  have hrewrite :
      (∑ e1 ∈ ((S.powerset.erase S).erase ∅),
        (fixedQBooleanResidueFiberMass q A H S e1 -
          (∑ y ∈ Finset.Ioo 0 H,
            occupiedFixedQLowWeight q A H y) /
              (primeSetProduct S : ℝ))) =
      ∑ e1 ∈ ((S.powerset.erase S).erase ∅),
        ((∑ y ∈ Finset.Ioo 0 H,
          if y ≡ H * fixedProductCRTIdempotentNat S e1
              [MOD primeSetProduct S]
          then occupiedFixedQLowWeight q A H y else 0) -
          (∑ y ∈ Finset.Ioo 0 H,
            occupiedFixedQLowWeight q A H y) /
              (primeSetProduct S : ℝ)) := by
    apply Finset.sum_congr rfl
    intro e1 he1
    rw [hfiber e1 he1]
  rw [hrewrite]
  exact periodic_weighted_proper_discrepancy_eq_affine_sum
    hPrime hPpos (occupiedFixedQLowWeight_periodic q A H) hPcop hHcop

#print axioms ordinaryBooleanInteriorDiscrepancy_eq_pow_mul_properWeighted
#print axioms periodic_weighted_proper_discrepancy_eq_affine_sum
#print axioms fixedQProperWeightedDiscrepancy_eq_periodic_affine_sum

end PaperB.FixedQ
