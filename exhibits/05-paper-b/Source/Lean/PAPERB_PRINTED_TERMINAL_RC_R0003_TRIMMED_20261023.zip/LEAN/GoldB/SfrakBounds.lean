import GoldB.DoubleSum
import GoldB.MinSum

/-!
# GoldB.SfrakBounds — bounds for the geometric-sum factors `𝔖_j`
-/

open Finset

namespace GoldB

lemma gmin_abs (U B m : ℝ) : gmin U (B * m) = gmin U (|B| * m) := by
  rcases le_or_gt 0 B with h | h
  · rw [abs_of_nonneg h]
  · rw [abs_of_neg h, show -B * m = -(B * m) by ring, gmin_neg]

lemma Sfrak_le_trivial (b Q j : ℕ) (Bj : ℝ) (hL : 1 ≤ Lbox b Q j) :
    Sfrak b Q j Bj ≤ 9 * (Lbox b Q j : ℝ) ^ 2 := by
  unfold Sfrak
  set L := Lbox b Q j
  calc ∑ m ∈ Icc (-(L : ℤ)) L, gmin (2 * (L : ℝ) + 1) (Bj * m)
      ≤ ∑ _m ∈ Icc (-(L : ℤ)) L, (2 * (L : ℝ) + 1) := sum_le_sum (fun _ _ => gmin_le_U _ _)
    _ = (2 * (L : ℝ) + 1) ^ 2 := by
        rw [sum_const, nsmul_eq_mul, Int.card_Icc]
        have : ((L : ℤ) + 1 - -(L : ℤ)).toNat = 2 * L + 1 := by omega
        rw [this]; push_cast; ring
    _ ≤ 9 * (L : ℝ) ^ 2 := by
        have : (1 : ℝ) ≤ L := by exact_mod_cast hL
        nlinarith

lemma Sfrak_pos (b Q j : ℕ) (Bj : ℝ) : 0 < Sfrak b Q j Bj := by
  unfold Sfrak
  set L := Lbox b Q j
  have h0 : (0 : ℤ) ∈ Icc (-(L : ℤ)) L := by rw [mem_Icc]; omega
  rw [← add_sum_erase _ _ h0]
  have : gmin (2 * (L : ℝ) + 1) (Bj * ((0 : ℤ) : ℝ)) = 2 * L + 1 := by
    simp [gmin, dz]
  rw [this]
  have : 0 ≤ ∑ x ∈ (Icc (-(L : ℤ)) L).erase 0, gmin (2 * (L : ℝ) + 1) (Bj * x) :=
    sum_nonneg (fun _ _ => gmin_nonneg (by positivity) _)
  have : (0 : ℝ) < 2 * L + 1 := by positivity
  linarith

/-- the selected-order bound -/
lemma Sfrak_le_sel (b Q j : ℕ) (Bj ε ℓ : ℝ) (s : ℕ) (hL : 1 ≤ Lbox b Q j)
    (hβ0 : 0 < |Bj|) (hβ2 : |Bj| ≤ 1 / 2) (hε : 0 < ε) (hβε : |Bj| ≤ ε)
    (hLε : 1 / (Lbox b Q j : ℝ) ≤ 2 ^ s * ε)
    (hβLε : 1 / (|Bj| * (Lbox b Q j : ℝ) ^ 2) ≤ 4 ^ s * ε)
    (hℓ : Real.log (1 / |Bj|) ≤ ℓ) :
    Sfrak b Q j Bj ≤ 28 * 4 ^ s * (1 + ℓ) * (Lbox b Q j : ℝ) ^ 2 * ε := by
  set L : ℝ := (Lbox b Q j : ℝ)
  set β := |Bj|
  have hL1 : (1 : ℝ) ≤ L := by simp only [L]; exact_mod_cast hL
  have hℓ0 : 0 ≤ Real.log (1 / β) := Real.log_nonneg (by rw [le_div_iff₀ hβ0]; linarith)
  have hℓ' : 0 ≤ ℓ := hℓ0.trans hℓ
  have hms := min_sum (2 * L + 1) β (by positivity) hβ0 hβ2 (Lbox b Q j)
  have hS : Sfrak b Q j Bj = ∑ m ∈ Icc (-(Lbox b Q j : ℤ)) (Lbox b Q j), gmin (2 * L + 1) (β * m) := by
    unfold Sfrak; apply sum_congr rfl; intro m _; rw [gmin_abs]
  rw [hS]
  refine hms.trans ?_
  set ℓ0 := Real.log (1 / β)
  -- auxiliary bounds
  have h2s : (1 : ℝ) ≤ 2 ^ s := one_le_pow₀ (by norm_num)
  have h4s : (2 : ℝ) ^ s ≤ 4 ^ s := pow_le_pow_left₀ (by norm_num) (by norm_num) s
  have hinvL : 1 / L ≤ 2 ^ s * ε := hLε
  have hLL : L ≤ L ^ 2 := by nlinarith
  -- each piece
  have p1 : 8 * L ^ 2 * β ≤ 8 * L ^ 2 * ε := by gcongr
  have p2 : 4 * L * β ≤ 4 * L ^ 2 * ε := by nlinarith
  have p3 : 2 * L * (1 + ℓ0) ≤ 2 * (1 + ℓ) * L ^ 2 * (2 ^ s * ε) := by
    have : L = L ^ 2 * (1 / L) := by field_simp
    calc 2 * L * (1 + ℓ0) = 2 * (1 + ℓ0) * L ^ 2 * (1 / L) := by field_simp
      _ ≤ 2 * (1 + ℓ) * L ^ 2 * (2 ^ s * ε) := by gcongr
  have p4 : 8 * L + 4 ≤ 12 * L ^ 2 * (2 ^ s * ε) := by
    have : 8 * L + 4 ≤ 12 * L := by linarith
    calc 8 * L + 4 ≤ 12 * L := this
      _ = 12 * L ^ 2 * (1 / L) := by field_simp
      _ ≤ 12 * L ^ 2 * (2 ^ s * ε) := by gcongr
  have p5 : 2 * (1 + ℓ0) / β ≤ 2 * (1 + ℓ) * L ^ 2 * (4 ^ s * ε) := by
    calc 2 * (1 + ℓ0) / β = 2 * (1 + ℓ0) * L ^ 2 * (1 / (β * L ^ 2)) := by field_simp
      _ ≤ 2 * (1 + ℓ) * L ^ 2 * (4 ^ s * ε) := by gcongr
  have expand : (2 * (Lbox b Q j : ℝ) * β + 2) * (2 * (2 * L + 1) + (1 + ℓ0) / β) =
      8 * L ^ 2 * β + 4 * L * β + 2 * L * (1 + ℓ0) + (8 * L + 4) + 2 * (1 + ℓ0) / β := by
    field_simp; ring
  rw [expand]
  have hε4 : 0 ≤ L ^ 2 * ε := by positivity
  calc 8 * L ^ 2 * β + 4 * L * β + 2 * L * (1 + ℓ0) + (8 * L + 4) + 2 * (1 + ℓ0) / β
      ≤ 8 * L ^ 2 * ε + 4 * L ^ 2 * ε + 2 * (1 + ℓ) * L ^ 2 * (2 ^ s * ε) +
          12 * L ^ 2 * (2 ^ s * ε) + 2 * (1 + ℓ) * L ^ 2 * (4 ^ s * ε) := by linarith
    _ ≤ 28 * 4 ^ s * (1 + ℓ) * L ^ 2 * ε := by
        have a1 : 12 * (L ^ 2 * ε) ≤ 12 * (4 ^ s * (1 + ℓ)) * (L ^ 2 * ε) := by
          apply mul_le_mul_of_nonneg_right _ hε4
          nlinarith [one_le_pow₀ (by norm_num : (1 : ℝ) ≤ 4) (n := s)]
        have a2 : 2 * (1 + ℓ) * (2 ^ s) * (L ^ 2 * ε) ≤ 2 * (1 + ℓ) * 4 ^ s * (L ^ 2 * ε) := by
          gcongr
        have a3 : 12 * (2 ^ s) * (L ^ 2 * ε) ≤ 12 * (4 ^ s * (1 + ℓ)) * (L ^ 2 * ε) := by
          apply mul_le_mul_of_nonneg_right _ hε4
          nlinarith
        nlinarith

end GoldB
