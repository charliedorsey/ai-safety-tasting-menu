import PaperB.Analytic.ReciprocalFiniteOrder

namespace PaperB.Analytic

open Real Finset

/-- Incomplete-interval reciprocal estimate on an arbitrary integer subinterval
of the dyadic block.  The additive linear twist remains completely uniform. -/
theorem reciprocalFiniteOrderInterval
    (k : ℕ) (hk : 2 ≤ k) :
    ∃ C : ℝ, 1 ≤ C ∧
      ∀ (A xi : ℝ) (N : ℕ) (a b : ℤ),
        0 < A → k ≤ N →
        (N : ℤ) ≤ a → b ≤ 2 * (N : ℤ) → a ≤ b →
        let lam :=
          A * (k.factorial : ℝ) *
            (((2 * N + k : ℕ) : ℝ) ^ (k + 1))⁻¹
        ‖∑ n ∈ Finset.Ioc a b,
            eR (A / (n : ℝ) + xi * (n : ℝ))‖
          ≤ C *
            (((b : ℝ) - (a : ℝ)) *
                lam ^ (1 / ((2 : ℝ) ^ k - 2))
              + ((b : ℝ) - (a : ℝ)) ^ (1 - 4 / (2 : ℝ) ^ k) *
                lam ^ (-(1 / ((2 : ℝ) ^ k - 2)))) := by
  obtain ⟨C0, hC01, hC0⟩ := finiteOrderDerivativeTest k hk
  refine ⟨C0 * ((3 : ℝ) ^ (k + 1)) ^ (4 / (2 : ℝ) ^ k), ?_, ?_⟩
  · have h3 : (1 : ℝ) ≤ ((3 : ℝ) ^ (k + 1)) ^ (4 / (2 : ℝ) ^ k) :=
      Real.one_le_rpow (one_le_pow₀ (by norm_num)) (by positivity)
    nlinarith [hC01, h3,
      mul_nonneg (sub_nonneg.mpr hC01) (sub_nonneg.mpr h3)]
  · intro A xi N a b hA hkN haN hb2 hab
    dsimp
    have hN1 : 1 ≤ N := by omega
    have hNR : (0 : ℝ) < (N : ℝ) := by exact_mod_cast hN1
    set lam : ℝ :=
      A * (k.factorial : ℝ) *
        (((2 * N + k : ℕ) : ℝ) ^ (k + 1))⁻¹ with hlam
    have hlampos : 0 < lam := by
      rw [hlam]
      positivity
    set cc : ℝ :=
      ((2 * N + k : ℕ) : ℝ) ^ (k + 1) / (N : ℝ) ^ (k + 1) with hcc
    have hcc1 : 1 ≤ cc := by
      rw [hcc, one_le_div (by positivity)]
      apply pow_le_pow_left₀ (by positivity)
      push_cast
      linarith
    have hratio : ((2 * N + k : ℕ) : ℝ) / (N : ℝ) ≤ 3 := by
      rw [div_le_iff₀ hNR]
      push_cast
      have : (k : ℝ) ≤ (N : ℝ) := by exact_mod_cast hkN
      linarith
    have hcc3 : cc ≤ (3 : ℝ) ^ (k + 1) := by
      rw [hcc, ← div_pow]
      exact pow_le_pow_left₀ (by positivity) hratio _
    have hclam :
        cc * lam =
          A * (k.factorial : ℝ) * ((N : ℝ) ^ (k + 1))⁻¹ := by
      rw [hcc, hlam]
      field_simp
    set phase : ℤ → ℝ := fun m => A / (m : ℝ) + xi * (m : ℝ) with hphase
    set g : ℤ → ℝ := fun m => (-1 : ℝ) ^ k * phase m with hg
    have hgform :
        g = fun m : ℤ =>
          (-1 : ℝ) ^ k * (A / (m : ℝ)) +
            (((-1 : ℝ) ^ k) * xi) * (m : ℝ) := by
      funext m
      simp only [hg, hphase]
      ring
    have hbase := hC0 g a b lam cc hab hlampos hcc1
      (fun n h1 h2 => by
        have hn1 : (N : ℤ) < n := lt_of_le_of_lt haN h1
        have hn2 : n < 2 * (N : ℤ) := lt_of_lt_of_le h2 hb2
        rw [hgform, dk_add_linear
          (fun m : ℤ => (-1 : ℝ) ^ k * (A / (m : ℝ)))
          (((-1 : ℝ) ^ k) * xi) hk n, hlam]
        exact (reciprocal_dk_window A hA k N hk hkN n hn1 hn2).1)
      (fun n h1 h2 => by
        have hn1 : (N : ℤ) < n := lt_of_le_of_lt haN h1
        have hn2 : n < 2 * (N : ℤ) := lt_of_lt_of_le h2 hb2
        rw [hgform, dk_add_linear
          (fun m : ℤ => (-1 : ℝ) ^ k * (A / (m : ℝ)))
          (((-1 : ℝ) ^ k) * xi) hk n, hclam]
        exact (reciprocal_dk_window A hA k N hk hkN n hn1 hn2).2)
    have hnorm :
        ‖∑ n ∈ Finset.Ioc a b, eR (g n)‖ =
          ‖∑ n ∈ Finset.Ioc a b, eR (phase n)‖ := by
      simp only [hg]
      exact norm_sum_eR_signed _ phase k
    rw [hnorm] at hbase
    simp only [hphase] at hbase
    refine le_trans hbase ?_
    have habR : (a : ℝ) ≤ (b : ℝ) := by exact_mod_cast hab
    have hlen0 : 0 ≤ (b : ℝ) - (a : ℝ) := sub_nonneg.mpr habR
    have hX : 0 ≤
        ((b : ℝ) - (a : ℝ)) *
            lam ^ (1 / ((2 : ℝ) ^ k - 2)) +
          ((b : ℝ) - (a : ℝ)) ^ (1 - 4 / (2 : ℝ) ^ k) *
            lam ^ (-(1 / ((2 : ℝ) ^ k - 2))) := by
      exact add_nonneg
        (mul_nonneg hlen0 (Real.rpow_nonneg (le_of_lt hlampos) _))
        (mul_nonneg (Real.rpow_nonneg hlen0 _)
          (Real.rpow_nonneg (le_of_lt hlampos) _))
    apply mul_le_mul_of_nonneg_right _ hX
    apply mul_le_mul_of_nonneg_left _ (le_trans zero_le_one hC01)
    exact Real.rpow_le_rpow (le_trans zero_le_one hcc1) hcc3 (by positivity)

#print axioms reciprocalFiniteOrderInterval

end PaperB.Analytic
