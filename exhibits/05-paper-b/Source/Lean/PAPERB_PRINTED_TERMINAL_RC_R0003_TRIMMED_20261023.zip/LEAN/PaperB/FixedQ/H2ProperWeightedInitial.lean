import PaperB.FixedQ.H2ProperWeightedTrivialBound

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def h2BooleanInitialProperWeightMass
    (q N : ℕ) : ℝ :=
  ∑ S ∈ (h2BooleanActivePrimesLE q (2 * N)).powerset,
    finiteOmegaWeightReal S * (2 : ℝ) ^ S.card

lemma h2BooleanInitialProperWeightMass_nonneg
    (q N : ℕ) :
    0 ≤ h2BooleanInitialProperWeightMass q N := by
  unfold h2BooleanInitialProperWeightMass
  apply Finset.sum_nonneg
  intro S hS
  have hsub := Finset.mem_powerset.mp hS
  have hAct : ∀ p ∈ S, activeHighPrime q p := by
    intro p hp
    exact (Finset.mem_filter.mp (hsub hp)).2
  exact mul_nonneg
    (finiteOmegaWeightReal_nonneg_of_active hAct)
    (pow_nonneg (by norm_num) _)

lemma h2BooleanOrdinaryDyadicSets_subset_initial
    {q H M N : ℕ} (hMN : M ≤ N) :
    h2BooleanOrdinaryDyadicSets q H M ⊆
      (h2BooleanActivePrimesLE q (2 * N)).powerset := by
  intro S hS
  have hm := h2BooleanOrdinaryDyadicSets_mem hS
  have hdy := hm.1
  unfold h2BooleanDyadicSets at hdy
  have hpow := (Finset.mem_filter.mp hdy).1
  have hsubM := Finset.mem_powerset.mp hpow
  apply Finset.mem_powerset.mpr
  intro p hp
  have hpM := hsubM hp
  have hpData := Finset.mem_filter.mp hpM
  apply Finset.mem_filter.mpr
  constructor
  · have hprimeLE := Nat.mem_primesLE.mp hpData.1
    apply Nat.mem_primesLE.mpr
    constructor
    · exact hprimeLE.1.trans (Nat.mul_le_mul_left 2 hMN)
    · exact hprimeLE.2
  · exact hpData.2

theorem h2BooleanProperWeightedDyadicShell_le_initial
    {q A H M N : ℕ}
    (hq : 0 < q)
    (h2 : ¬ 2 ∣ q → 2 ∣ H)
    (hMN : M ≤ N) :
    h2BooleanProperWeightedDyadicShell q A H M ≤
      (12 * (fixedQPeriod q : ℝ)) *
        h2BooleanInitialProperWeightMass q N := by
  let F := h2BooleanOrdinaryDyadicSets q H M
  let G := (h2BooleanActivePrimesLE q (2 * N)).powerset
  let W : Finset ℕ → ℝ := fun S =>
    finiteOmegaWeightReal S * (2 : ℝ) ^ S.card
  have hFG : F ⊆ G := by
    simpa [F, G] using
      h2BooleanOrdinaryDyadicSets_subset_initial
        (q := q) (H := H) hMN
  have hW0G : ∀ S ∈ G, 0 ≤ W S := by
    intro S hS
    have hsub := Finset.mem_powerset.mp hS
    have hAct : ∀ p ∈ S, activeHighPrime q p := by
      intro p hp
      exact (Finset.mem_filter.mp (hsub hp)).2
    dsimp [W]
    exact mul_nonneg
      (finiteOmegaWeightReal_nonneg_of_active hAct)
      (pow_nonneg (by norm_num) _)
  have hpoint : ∀ S ∈ F,
      W S * |fixedQProperWeightedDiscrepancy q A H S| ≤
        W S * (12 * (fixedQPeriod q : ℝ)) := by
    intro S hS
    have hm := h2BooleanOrdinaryDyadicSets_mem hS
    have hAct := h2BooleanDyadicSets_active hm.1
    have hD := fixedQProperWeightedDiscrepancy_abs_le_uniform
      (q := q) (A := A) (H := H) (S := S)
      hq hAct hm.2 h2
    have hW0 : 0 ≤ W S := hW0G S (hFG hS)
    exact mul_le_mul_of_nonneg_left hD hW0
  unfold h2BooleanProperWeightedDyadicShell
  change (∑ S ∈ F,
    W S * |fixedQProperWeightedDiscrepancy q A H S|) ≤ _
  calc
    (∑ S ∈ F,
      W S * |fixedQProperWeightedDiscrepancy q A H S|)
      ≤ ∑ S ∈ F, W S * (12 * (fixedQPeriod q : ℝ)) :=
        Finset.sum_le_sum hpoint
    _ = (∑ S ∈ F, W S) * (12 * (fixedQPeriod q : ℝ)) := by
      rw [Finset.sum_mul]
    _ ≤ (∑ S ∈ G, W S) * (12 * (fixedQPeriod q : ℝ)) := by
      have hP0 : 0 ≤ 12 * (fixedQPeriod q : ℝ) := by positivity
      apply mul_le_mul_of_nonneg_right _ hP0
      exact Finset.sum_le_sum_of_subset_of_nonneg hFG
        (fun S hSG hnot => hW0G S hSG)
    _ = (12 * (fixedQPeriod q : ℝ)) *
        h2BooleanInitialProperWeightMass q N := by
      unfold h2BooleanInitialProperWeightMass
      dsimp [G, W]
      ring

#print axioms h2BooleanInitialProperWeightMass_nonneg
#print axioms h2BooleanOrdinaryDyadicSets_subset_initial
#print axioms h2BooleanProperWeightedDyadicShell_le_initial

end PaperB.FixedQ
