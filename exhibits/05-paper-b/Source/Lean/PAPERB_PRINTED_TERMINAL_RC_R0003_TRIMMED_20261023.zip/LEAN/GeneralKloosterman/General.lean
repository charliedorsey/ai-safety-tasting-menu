import GeneralKloosterman.PrimePower

/-!
# General modulus: CRT assembly and the Weil–Estermann bound

* `kgcd_crt` — the gcd loss is multiplicative across the toolkit's Bézout/CRT splitting
  (the local coefficients are unit multiples of the reductions).
* **`norm_kSum_le`** — for every modulus `N ≥ 1` and all `a, b ∈ ZMod N`:

    `‖S(a,b;N)‖ ≤ τ(N) · √(gcd(a,b,N) · N)`,

  `τ(N) = #N.divisors`. Proof: induction over coprime prime-power factorizations
  (`Nat.recOnPosPrimePosCoprime`), using the local theorem `norm_kSum_primePow_le` at each prime
  power and the toolkit's exact twisted-multiplicativity identity `norm_kloostermanUnitSum_crt`.
* `norm_kloostermanUnitSum_le` — the same in the toolkit's notation.
* `norm_kSum_le_of_isUnit_left/right` — a unit coefficient: `‖S‖ ≤ τ(N) √N`.
-/

open Finset RML.ExpSum.Weil

namespace GenKloosterman

/-- `gcd(z, m)` from the canonical representative. -/
def vg (m : ℕ) (z : ZMod m) : ℕ := Nat.gcd z.val m

theorem gcd_gcd_eq (x y m : ℕ) :
    Nat.gcd (Nat.gcd x y) m = Nat.gcd (Nat.gcd x m) (Nat.gcd y m) := by
  apply Nat.dvd_antisymm
  · exact Nat.dvd_gcd
      (Nat.dvd_gcd ((Nat.gcd_dvd_left _ _).trans (Nat.gcd_dvd_left _ _)) (Nat.gcd_dvd_right _ _))
      (Nat.dvd_gcd ((Nat.gcd_dvd_left _ _).trans (Nat.gcd_dvd_right _ _)) (Nat.gcd_dvd_right _ _))
  · exact Nat.dvd_gcd
      (Nat.dvd_gcd ((Nat.gcd_dvd_left _ _).trans (Nat.gcd_dvd_left _ _))
        ((Nat.gcd_dvd_right _ _).trans (Nat.gcd_dvd_left _ _)))
      ((Nat.gcd_dvd_left _ _).trans (Nat.gcd_dvd_right _ _))

theorem kgcd_eq_vg (m : ℕ) (x y : ZMod m) : kgcd m x y = Nat.gcd (vg m x) (vg m y) :=
  gcd_gcd_eq _ _ _

theorem vg_unit_mul {m : ℕ} [NeZero m] (u z : ZMod m) (hu : IsUnit u) :
    vg m (u * z) = vg m z := by
  obtain ⟨U, rfl⟩ := hu
  unfold vg
  rw [ZMod.val_mul, ← Nat.gcd_rec,
    Nat.Coprime.gcd_mul_left_cancel_right _ (ZMod.val_coe_unit_coprime U), Nat.gcd_comm]

theorem vg_castHom {N m : ℕ} [NeZero N] [NeZero m] (h : m ∣ N) (z : ZMod N) :
    vg m (ZMod.castHom h (ZMod m) z) = Nat.gcd z.val m := by
  unfold vg
  rw [ZMod.castHom_apply, ZMod.cast_eq_val, ZMod.val_natCast, ← Nat.gcd_rec, Nat.gcd_comm]

theorem crt_fst {m n : ℕ} (hcop : m.Coprime n) (z : ZMod (m * n)) :
    (ZMod.chineseRemainder hcop z).1 = ZMod.castHom (dvd_mul_right m n) (ZMod m) z := by
  simp [ZMod.chineseRemainder]

theorem crt_snd {m n : ℕ} (hcop : m.Coprime n) (z : ZMod (m * n)) :
    (ZMod.chineseRemainder hcop z).2 = ZMod.castHom (dvd_mul_left n m) (ZMod n) z := by
  simp [ZMod.chineseRemainder]

/-- The gcd loss across the CRT splitting. -/
theorem kgcd_crt {m n : ℕ} [NeZero m] [NeZero n] [NeZero (m * n)] (hcop : m.Coprime n)
    (a b : ZMod (m * n)) :
    kgcd (m * n) a b =
      kgcd m (((crtLeftCoeff m n : ℤ) : ZMod m) * (ZMod.chineseRemainder hcop a).1)
          (((crtLeftCoeff m n : ℤ) : ZMod m) * (ZMod.chineseRemainder hcop b).1) *
        kgcd n (((crtRightCoeff m n : ℤ) : ZMod n) * (ZMod.chineseRemainder hcop a).2)
          (((crtRightCoeff m n : ℤ) : ZMod n) * (ZMod.chineseRemainder hcop b).2) := by
  rw [kgcd, Nat.Coprime.gcd_mul _ hcop, kgcd_eq_vg, kgcd_eq_vg,
    vg_unit_mul _ _ (crtLeftCoeff_isUnit hcop), vg_unit_mul _ _ (crtLeftCoeff_isUnit hcop),
    vg_unit_mul _ _ (crtRightCoeff_isUnit hcop), vg_unit_mul _ _ (crtRightCoeff_isUnit hcop),
    crt_fst, crt_fst, crt_snd, crt_snd, vg_castHom, vg_castHom, vg_castHom, vg_castHom,
    gcd_gcd_eq a.val b.val m, gcd_gcd_eq a.val b.val n]

theorem card_divisors_prime_pow {p : ℕ} (hp : p.Prime) (k : ℕ) : #(p ^ k).divisors = k + 1 := by
  rw [Nat.divisors_prime_pow hp, card_map, card_range]

theorem sqrt_mul_assemble (t1 t2 g1 g2 m n : ℕ) :
    (t1 : ℝ) * Real.sqrt (g1 * m) * ((t2 : ℝ) * Real.sqrt (g2 * n)) =
      ((t1 * t2 : ℕ) : ℝ) * Real.sqrt (((g1 * g2 : ℕ) : ℝ) * ((m * n : ℕ) : ℝ)) := by
  rw [Nat.cast_mul, Nat.cast_mul, Nat.cast_mul]
  have h : Real.sqrt ((g1 : ℝ) * g2 * (m * n)) = Real.sqrt (g1 * m) * Real.sqrt (g2 * n) := by
    rw [← Real.sqrt_mul (by positivity)]; congr 1; ring
  rw [h]; ring

theorem norm_kSum_le_aux : ∀ N : ℕ, ∀ (_ : NeZero N) (a b : ZMod N),
    ‖kSum N a b‖ ≤ (#N.divisors : ℝ) * Real.sqrt (kgcd N a b * N) := by
  refine Nat.recOnPosPrimePosCoprime ?_ ?_ ?_ ?_
  · intro p k hp hk _ a b
    have : Fact p.Prime := ⟨hp⟩
    have := norm_kSum_primePow_le k (p ^ k) rfl hk a b
    rw [card_divisors_prime_pow hp]
    push_cast at this ⊢
    exact this
  · intro h; exact absurd rfl h.out
  · intro _ a b
    refine (norm_kSum_le_card a b).trans ?_
    simp [kgcd]
  · intro m n hm hn hcop ihm ihn _ a b
    have : NeZero m := ⟨by omega⟩
    have : NeZero n := ⟨by omega⟩
    have h1 := ihm inferInstance (((crtLeftCoeff m n : ℤ) : ZMod m) * (ZMod.chineseRemainder hcop a).1)
      (((crtLeftCoeff m n : ℤ) : ZMod m) * (ZMod.chineseRemainder hcop b).1)
    have h2 := ihn inferInstance (((crtRightCoeff m n : ℤ) : ZMod n) * (ZMod.chineseRemainder hcop a).2)
      (((crtRightCoeff m n : ℤ) : ZMod n) * (ZMod.chineseRemainder hcop b).2)
    rw [kSum_eq_kloostermanUnitSum] at h1 h2
    rw [kSum_eq_kloostermanUnitSum, norm_kloostermanUnitSum_crt hcop, kgcd_crt hcop,
      Nat.Coprime.card_divisors_mul hcop]
    exact (mul_le_mul h1 h2 (norm_nonneg _) (by positivity)).trans
      (le_of_eq (sqrt_mul_assemble _ _ _ _ _ _))

/-- **General-modulus Weil–Estermann bound.** For every `N ≥ 1` and all `a, b ∈ ZMod N`,
`‖S(a,b;N)‖ ≤ τ(N) · √(gcd(a,b,N) · N)`. -/
theorem norm_kSum_le (N : ℕ) [NeZero N] (a b : ZMod N) :
    ‖kSum N a b‖ ≤ (#N.divisors : ℝ) * Real.sqrt (kgcd N a b * N) :=
  norm_kSum_le_aux N inferInstance a b

/-- The same bound in the toolkit's notation `kloostermanUnitSum`. -/
theorem norm_kloostermanUnitSum_le (N : ℕ) [NeZero N] (a b : ZMod N) :
    ‖kloostermanUnitSum N a b‖ ≤
      (#N.divisors : ℝ) * Real.sqrt (Nat.gcd (Nat.gcd a.val b.val) N * N) :=
  norm_kSum_le N a b

theorem kgcd_eq_one_of_isUnit_left {N : ℕ} [NeZero N] (a b : ZMod N) (ha : IsUnit a) :
    kgcd N a b = 1 := by
  obtain ⟨U, rfl⟩ := ha
  have hc := ZMod.val_coe_unit_coprime U
  unfold kgcd
  exact Nat.eq_one_of_dvd_one (hc ▸ Nat.dvd_gcd ((Nat.gcd_dvd_left _ _).trans
    (Nat.gcd_dvd_left _ _)) (Nat.gcd_dvd_right _ _))

theorem kgcd_comm {N : ℕ} (a b : ZMod N) : kgcd N a b = kgcd N b a := by
  unfold kgcd; rw [Nat.gcd_comm a.val]

/-- A unit coefficient: `‖S(a,b;N)‖ ≤ τ(N) √N`. -/
theorem norm_kSum_le_of_isUnit_left {N : ℕ} [NeZero N] (a b : ZMod N) (ha : IsUnit a) :
    ‖kSum N a b‖ ≤ (#N.divisors : ℝ) * Real.sqrt N := by
  have := norm_kSum_le N a b
  rwa [kgcd_eq_one_of_isUnit_left a b ha, Nat.cast_one, one_mul] at this

theorem norm_kSum_le_of_isUnit_right {N : ℕ} [NeZero N] (a b : ZMod N) (hb : IsUnit b) :
    ‖kSum N a b‖ ≤ (#N.divisors : ℝ) * Real.sqrt N := by
  have := norm_kSum_le N a b
  rwa [kgcd_comm, kgcd_eq_one_of_isUnit_left b a hb, Nat.cast_one, one_mul] at this

end GenKloosterman
