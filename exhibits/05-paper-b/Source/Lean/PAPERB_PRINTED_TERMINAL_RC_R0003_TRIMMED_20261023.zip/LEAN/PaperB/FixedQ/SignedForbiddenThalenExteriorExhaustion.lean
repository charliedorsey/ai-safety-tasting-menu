import PaperB.FixedQ.SignedForbiddenTavrenGlobalExteriorSignedHeightSum

open scoped BigOperators
open Filter

namespace PaperB.FixedQ

/-- Source-native finite exhaustion of Tavren's actual reduced signed
exterior. No absolute-value majorization, transformed cutoff, or
decorated reindex is introduced here. -/
theorem thalen_reducedExteriorSignedCore_tendsto_rangePowerset
    {q A H Z : ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2 : ¬ 2 ∣ q → 2 ∣ H)
    (d : Finset ℕ) :
    Tendsto
      (fun N : ℕ =>
        ∑ n ∈ (Finset.range N).powerset,
          if Z < primeSetProduct n then
            dForbiddenReducedBooleanCoreTerm q A H d n
          else 0)
      atTop (nhds (tavrenReducedExteriorSignedCore q A H Z d)) := by
  have hs := tavren_summable_reducedExteriorSignedCore
    (q := q) (A := A) (H := H) (Z := Z) hq hH h2 d
  have hcofinal :
      Tendsto (fun N : ℕ => (Finset.range N).powerset)
        atTop (atTop : Filter (Finset (Finset ℕ))) :=
    Filter.tendsto_finset_powerset_atTop_atTop.comp Filter.tendsto_finset_range
  exact hs.hasSum.comp hcofinal

#print axioms thalen_reducedExteriorSignedCore_tendsto_rangePowerset

end PaperB.FixedQ
