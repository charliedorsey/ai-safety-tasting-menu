import GoldC.QuillonRowFacts
import GoldC.QuillonWEst
import GoldC.QuillonLam

/-!
# Quillon CSC3 F8.6: the W′ cell is `≤ Λ^{−90}` for every fixed `C`, eventually in `h`

* `W_bracket_ev`: the `s`-dependent saving bracket of `WTerm_le` is `≤ 6Λ^{−100}` once
  `log s ≥ 5Λ^σ` and `Λ` is large. It uses:
  - `8^{|C|} ≤ s^{a₀/16}` (`base_pow_card_le`);
  - `LwW/Y ≥ s^{3/4+a₀/2}/2`;
  - `sdecay`.
* `W_term_ev`: each `WTerm` is `≤ Λ^{−95}`.
* `W_final`: the full source W′ cell sum for fixed `C` is `≤ Λ^{−90}`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonWFinal

open GoldC.QuillonEv GoldC.QuillonSetup GoldC.QuillonLam

lemma one_add_log_nonneg {x : ℝ} (hx : 1 ≤ x) : 1 ≤ 1 + Real.log x := by
  have := Real.log_nonneg hx; linarith

/-- the `s`-part of the W′ bracket. -/
theorem W_bracket_ev (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 1 ≤ Λ₀ ∧ ∀ Λ : ℝ, Λ₀ ≤ Λ → ∀ C : Finset ℕ, (∀ p ∈ C, p.Prime) →
      5 * Λ ^ σ₀ ≤ Real.log ((∏ p ∈ C, p : ℕ) : ℝ) →
      2 * (1 + Real.log (Yp δ (∏ p ∈ C, p) : ℝ)) / Real.sqrt ((∏ p ∈ C, p : ℕ) : ℝ) +
        2 * (1 + Real.log (Yp δ (∏ p ∈ C, p) : ℝ)) * (8 : ℝ) ^ C.card *
          Real.sqrt (((∏ p ∈ C, p : ℕ) : ℝ) ^ ((3 : ℝ) / 4) / ((∏ p ∈ C, p : ℕ) : ℝ) +
            ((∏ p ∈ C, p : ℕ) : ℝ) ^ ((3 : ℝ) / 4) * (1 + Real.log ((∏ p ∈ C, p : ℕ) : ℝ)) /
              ((LwW δ (∏ p ∈ C, p) / Yp δ (∏ p ∈ C, p) : ℕ) : ℝ)) ≤ 6 * Λ ^ (-(100 : ℝ)) := by
  have ha0 := a0_pos hδ0 hδ1
  have ha0' := a0_le hδ0
  obtain ⟨L₀, hL₀, h8⟩ := GoldC.QuillonAsymp.base_pow_card_le 8 (by norm_num) (a0 δ / 16) (by positivity)
  obtain ⟨Λ₁, hΛ₁, hs₁⟩ := s_large (max (Real.exp L₀) 36)
  obtain ⟨Λ₂, hΛ₂, hd₁⟩ := sdecay 1 (1 / 2) 100 (by norm_num) (by norm_num)
  obtain ⟨Λ₃, hΛ₃, hd₂⟩ := sdecay 2 (3 * a0 δ / 16) 100 (by positivity) (by norm_num)
  refine ⟨max Λ₁ (max Λ₂ Λ₃), le_trans hΛ₁ (le_max_left _ _), fun Λ hΛ C hC hlog => ?_⟩
  have hΛa : Λ₁ ≤ Λ := le_trans (le_max_left _ _) hΛ
  have hΛb : Λ₂ ≤ Λ := le_trans (le_trans (le_max_left _ _) (le_max_right _ _)) hΛ
  have hΛc : Λ₃ ≤ Λ := le_trans (le_trans (le_max_right _ _) (le_max_right _ _)) hΛ
  set s := ∏ p ∈ C, p with hs
  have hspos : 0 < s := prod_pos fun p hp => (hC p hp).pos
  have hs0 : (0 : ℝ) < s := by exact_mod_cast hspos
  have hsbig := hs₁ Λ hΛa s hs0 hlog
  have hsE : Real.exp L₀ ≤ (s : ℝ) := le_trans (le_max_left _ _) hsbig
  have hs36 : (36 : ℝ) ≤ s := le_trans (le_max_right _ _) hsbig
  have hs1 : (1 : ℝ) ≤ s := by linarith
  have hs1n : 1 ≤ s := by exact_mod_cast hs1
  have hlogL₀ : L₀ ≤ Real.log s := by
    rw [← Real.log_exp L₀]; exact Real.log_le_log (Real.exp_pos _) hsE
  set L := Real.log (s : ℝ) with hL
  have hL0 : 0 ≤ L := Real.log_nonneg hs1
  -- `1 + log Y ≤ 1 + L`
  have hY1 := Yp_pos hδ0 hδ1 hs1n
  have hYR : (1 : ℝ) ≤ Yp δ s := by exact_mod_cast hY1
  have hYs : (Yp δ s : ℝ) ≤ s := by
    refine le_trans (Yp_le δ s) ?_
    calc (s : ℝ) ^ u0 δ ≤ (s : ℝ) ^ (1 : ℝ) :=
          Real.rpow_le_rpow_of_exponent_le hs1 (by unfold u0; linarith)
      _ = s := Real.rpow_one _
  have hlY : 1 + Real.log (Yp δ s : ℝ) ≤ 1 + L := by
    have := Real.log_le_log (by linarith) hYs; linarith
  have hlY0 : 0 ≤ 1 + Real.log (Yp δ s : ℝ) := by have := Real.log_nonneg hYR; linarith
  -- term 1
  have t1 : 2 * (1 + Real.log (Yp δ s : ℝ)) / Real.sqrt s ≤ 2 * Λ ^ (-(100 : ℝ)) := by
    have hd := hd₁ Λ hΛb s hs0 hlog
    rw [pow_one] at hd
    have hsq : Real.sqrt s = (s : ℝ) ^ (1 / 2 : ℝ) := Real.sqrt_eq_rpow _
    have hpos : 0 < Real.sqrt s := Real.sqrt_pos.2 hs0
    rw [div_le_iff₀ hpos]
    have e : (1 + L) * (s : ℝ) ^ (-(1 / 2 : ℝ)) * Real.sqrt s = 1 + L := by
      rw [hsq, mul_assoc, ← Real.rpow_add hs0]; norm_num
    have : 2 * (1 + L) ≤ 2 * Λ ^ (-(100 : ℝ)) * Real.sqrt s := by
      have := mul_le_mul_of_nonneg_right hd hpos.le
      rw [e] at this; nlinarith
    linarith
  -- term 2
  have hβ : 6 ≤ (s : ℝ) ^ (3 / 4 + a0 δ / 2) := by
    calc (6 : ℝ) = (36 : ℝ) ^ (1 / 2 : ℝ) := by
          rw [show (36 : ℝ) = 6 ^ (2 : ℝ) by norm_num, ← Real.rpow_mul (by norm_num)]; norm_num
      _ ≤ (s : ℝ) ^ (1 / 2 : ℝ) := Real.rpow_le_rpow (by norm_num) hs36 (by norm_num)
      _ ≤ (s : ℝ) ^ (3 / 4 + a0 δ / 2) := Real.rpow_le_rpow_of_exponent_le hs1 (by linarith)
  have hdiv := LwW_div_Yp hδ0 hδ1 hs1n hβ
  set D := ((LwW δ s / Yp δ s : ℕ) : ℝ) with hD
  have hDpos : 0 < D := by
    have : (0 : ℝ) < (s : ℝ) ^ (3 / 4 + a0 δ / 2) / 2 := by positivity
    linarith
  have hinner : (s : ℝ) ^ ((3 : ℝ) / 4) / s + (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + L) / D ≤
      3 * (1 + L) * (s : ℝ) ^ (-(a0 δ / 2)) := by
    have e1 : (s : ℝ) ^ ((3 : ℝ) / 4) / s = (s : ℝ) ^ (-(1 / 4 : ℝ)) := by
      rw [div_eq_iff hs0.ne', ← Real.rpow_add_one hs0.ne']; norm_num
    have e2 : (s : ℝ) ^ (-(1 / 4 : ℝ)) ≤ (s : ℝ) ^ (-(a0 δ / 2)) :=
      Real.rpow_le_rpow_of_exponent_le hs1 (by linarith)
    have e3 : (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + L) / D ≤ 2 * (1 + L) * (s : ℝ) ^ (-(a0 δ / 2)) := by
      rw [div_le_iff₀ hDpos]
      have hk : (s : ℝ) ^ ((3 : ℝ) / 4) = (s : ℝ) ^ (-(a0 δ / 2)) * (s : ℝ) ^ (3 / 4 + a0 δ / 2) := by
        rw [← Real.rpow_add hs0]; ring_nf
      rw [hk]
      have hp : 0 ≤ (s : ℝ) ^ (-(a0 δ / 2)) := by positivity
      nlinarith [mul_le_mul_of_nonneg_left hdiv (by positivity : (0 : ℝ) ≤ 2 * (1 + L) * (s : ℝ) ^ (-(a0 δ / 2)))]
    have hp : 0 ≤ (s : ℝ) ^ (-(a0 δ / 2)) := by positivity
    rw [e1]; nlinarith
  have hsqrt : Real.sqrt ((s : ℝ) ^ ((3 : ℝ) / 4) / s + (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + L) / D) ≤
      2 * (1 + L) * (s : ℝ) ^ (-(a0 δ / 4)) := by
    rw [Real.sqrt_le_iff]
    refine ⟨by positivity, le_trans hinner ?_⟩
    have hk : ((s : ℝ) ^ (-(a0 δ / 4))) ^ 2 = (s : ℝ) ^ (-(a0 δ / 2)) := by
      rw [← Real.rpow_natCast, ← Real.rpow_mul hs0.le]; ring_nf
    rw [mul_pow, hk]
    have hp : 0 ≤ (s : ℝ) ^ (-(a0 δ / 2)) := by positivity
    have h3 : 3 * (1 + L) ≤ (2 * (1 + L)) ^ 2 := by nlinarith
    exact mul_le_mul_of_nonneg_right h3 hp
  have h8C : (8 : ℝ) ^ C.card ≤ (s : ℝ) ^ (a0 δ / 16) := h8 C hC hlogL₀
  have t2 : 2 * (1 + Real.log (Yp δ s : ℝ)) * (8 : ℝ) ^ C.card *
      Real.sqrt ((s : ℝ) ^ ((3 : ℝ) / 4) / s + (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + L) / D) ≤
      4 * Λ ^ (-(100 : ℝ)) := by
    have hd := hd₂ Λ hΛc s hs0 hlog
    calc 2 * (1 + Real.log (Yp δ s : ℝ)) * (8 : ℝ) ^ C.card *
          Real.sqrt ((s : ℝ) ^ ((3 : ℝ) / 4) / s + (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + L) / D)
        ≤ 2 * (1 + L) * (s : ℝ) ^ (a0 δ / 16) * (2 * (1 + L) * (s : ℝ) ^ (-(a0 δ / 4))) := by
          gcongr
      _ = 4 * ((1 + L) ^ 2 * (s : ℝ) ^ (-(3 * a0 δ / 16))) := by
          have : (s : ℝ) ^ (a0 δ / 16) * (s : ℝ) ^ (-(a0 δ / 4)) = (s : ℝ) ^ (-(3 * a0 δ / 16)) := by
            rw [← Real.rpow_add hs0]; ring_nf
          rw [← this]; ring
      _ ≤ 4 * Λ ^ (-(100 : ℝ)) := by linarith
  linarith

lemma rpow_shift {Λ : ℝ} (hΛ : 0 < Λ) (a : ℝ) (n : ℕ) : Λ ^ a * Λ ^ n = Λ ^ (a + n) := by
  rw [Real.rpow_add hΛ, Real.rpow_natCast]

lemma LwY_pos {δ : ℝ} (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) {s : ℕ} (hs36 : (36 : ℝ) ≤ s) :
    1 ≤ LwW δ s / Yp δ s := by
  have hs1 : (1 : ℝ) ≤ s := by linarith
  have hs1n : 1 ≤ s := by exact_mod_cast hs1
  have ha0 := a0_pos hδ0 hδ1
  have hβ : 6 ≤ (s : ℝ) ^ (3 / 4 + a0 δ / 2) := by
    calc (6 : ℝ) = (36 : ℝ) ^ (1 / 2 : ℝ) := by
          rw [show (36 : ℝ) = 6 ^ (2 : ℝ) by norm_num, ← Real.rpow_mul (by norm_num)]; norm_num
      _ ≤ (s : ℝ) ^ (1 / 2 : ℝ) := Real.rpow_le_rpow (by norm_num) hs36 (by norm_num)
      _ ≤ (s : ℝ) ^ (3 / 4 + a0 δ / 2) := Real.rpow_le_rpow_of_exponent_le hs1 (by linarith)
  have := LwW_div_Yp hδ0 hδ1 hs1n hβ
  have h2 : (1 : ℝ) ≤ ((LwW δ s / Yp δ s : ℕ) : ℝ) := by linarith
  exact_mod_cast h2

lemma LwW_le_self (δ : ℝ) (hδ0 : 0 < δ) (s : ℕ) : LwW δ s ≤ s := by
  unfold LwW
  have h1 : (s : ℝ) ^ (1 / (1 + δ)) ≤ s := by
    rcases Nat.eq_zero_or_pos s with h0 | hpos
    · rw [h0]; push_cast; rw [Real.zero_rpow (by positivity)]
    · have : (1 : ℝ) ≤ s := by exact_mod_cast hpos
      calc (s : ℝ) ^ (1 / (1 + δ)) ≤ (s : ℝ) ^ (1 : ℝ) :=
            Real.rpow_le_rpow_of_exponent_le this (by rw [div_le_one (by linarith)]; linarith)
        _ = s := Real.rpow_one _
  have := Nat.floor_le_of_le h1 (n := s)
  omega

/-- the final real combination for `W_term_ev`. -/
lemma W_combine (Λ F1 Mr Ab Aw F4 Br WU Xi E : ℝ) (hΛ2 : 2 ≤ Λ) (hM : 0 ≤ Mr) (hAb : 0 ≤ Ab)
    (hF1 : F1 ≤ 5 * Λ) (hF10 : 0 ≤ F1) (hAw : Aw ≤ Λ) (hAw0 : 0 ≤ Aw) (hF4 : F4 ≤ 2 * Λ) (hF40 : 0 ≤ F4)
    (hBr : Br ≤ 8 * Λ ^ (-(100 : ℝ))) (hBr0 : 0 ≤ Br) (hWU : WU ≤ E * Λ ^ (10 : ℝ)) (hWU0 : 0 ≤ WU)
    (hXi : Xi ≤ 12.5 * Λ ^ (-(200 : ℝ))) (hXi0 : 0 ≤ Xi)
    (hK1 : 5 * Mr * (Mr * Ab) * 2 * 8 ≤ Λ ^ (1 : ℝ)) (hK2 : Mr * Ab * 2 * E * 12.5 ≤ Λ ^ (1 : ℝ)) :
    F1 * Mr * (Mr * Ab) * Aw * F4 * Br + Mr * Ab * F4 * WU * Xi ≤ Λ ^ (-(95 : ℝ)) := by
  have hΛ1 : 1 ≤ Λ := by linarith
  have hΛ0 : 0 < Λ := by linarith
  have hMA : 0 ≤ Mr * (Mr * Ab) := by positivity
  have hp100 : 0 ≤ Λ ^ (-(100 : ℝ)) := by positivity
  have hp200 : 0 ≤ Λ ^ (-(200 : ℝ)) := by positivity
  have hp10 : 0 ≤ Λ ^ (10 : ℝ) := by positivity
  have hE0 : 0 ≤ E := by
    have : 0 ≤ E * Λ ^ (10 : ℝ) := le_trans hWU0 hWU
    have hp : 0 < Λ ^ (10 : ℝ) := by positivity
    by_contra hcon; push_neg at hcon; nlinarith
  have t1 : F1 * Mr * (Mr * Ab) * Aw * F4 * Br ≤
      (5 * Λ) * Mr * (Mr * Ab) * Λ * (2 * Λ) * (8 * Λ ^ (-(100 : ℝ))) := by
    have a1 : F1 * Mr * (Mr * Ab) ≤ (5 * Λ) * Mr * (Mr * Ab) := by
      rw [mul_assoc, mul_assoc (5 * Λ)]; exact mul_le_mul_of_nonneg_right hF1 (by positivity)
    have a2 : F1 * Mr * (Mr * Ab) * Aw ≤ (5 * Λ) * Mr * (Mr * Ab) * Λ :=
      mul_le_mul a1 hAw hAw0 (by positivity)
    have a3 : F1 * Mr * (Mr * Ab) * Aw * F4 ≤ (5 * Λ) * Mr * (Mr * Ab) * Λ * (2 * Λ) :=
      mul_le_mul a2 hF4 hF40 (by positivity)
    exact mul_le_mul a3 hBr hBr0 (by positivity)
  have t2 : Mr * Ab * F4 * WU * Xi ≤ Mr * Ab * (2 * Λ) * (E * Λ ^ (10 : ℝ)) * (12.5 * Λ ^ (-(200 : ℝ))) := by
    have a1 : Mr * Ab * F4 ≤ Mr * Ab * (2 * Λ) := mul_le_mul_of_nonneg_left hF4 (by positivity)
    have a2 : Mr * Ab * F4 * WU ≤ Mr * Ab * (2 * Λ) * (E * Λ ^ (10 : ℝ)) :=
      mul_le_mul a1 hWU hWU0 (by positivity)
    exact mul_le_mul a2 hXi hXi0 (by positivity)
  have e1 : (5 * Λ) * Mr * (Mr * Ab) * Λ * (2 * Λ) * (8 * Λ ^ (-(100 : ℝ))) =
      (5 * Mr * (Mr * Ab) * 2 * 8) * Λ ^ (-(97 : ℝ)) := by
    have : Λ ^ (-(97 : ℝ)) = Λ ^ (-(100 : ℝ)) * Λ ^ (3 : ℕ) := by rw [rpow_shift hΛ0]; norm_num
    rw [this]; ring
  have e2 : Mr * Ab * (2 * Λ) * (E * Λ ^ (10 : ℝ)) * (12.5 * Λ ^ (-(200 : ℝ))) =
      (Mr * Ab * 2 * E * 12.5) * Λ ^ (-(189 : ℝ)) := by
    have : Λ ^ (-(189 : ℝ)) = Λ ^ (-(200 : ℝ)) * Λ ^ (10 : ℝ) * Λ ^ (1 : ℕ) := by
      rw [← Real.rpow_add hΛ0, rpow_shift hΛ0]; norm_num
    rw [this]; ring
  have p97 : 0 ≤ Λ ^ (-(97 : ℝ)) := by positivity
  have p189 : 0 ≤ Λ ^ (-(189 : ℝ)) := by positivity
  have f1 : (5 * Mr * (Mr * Ab) * 2 * 8) * Λ ^ (-(97 : ℝ)) ≤ Λ ^ (-(96 : ℝ)) := by
    calc _ ≤ Λ ^ (1 : ℝ) * Λ ^ (-(97 : ℝ)) := mul_le_mul_of_nonneg_right hK1 p97
      _ = Λ ^ (-(96 : ℝ)) := by rw [← Real.rpow_add hΛ0]; norm_num
  have f2 : (Mr * Ab * 2 * E * 12.5) * Λ ^ (-(189 : ℝ)) ≤ Λ ^ (-(96 : ℝ)) := by
    calc _ ≤ Λ ^ (1 : ℝ) * Λ ^ (-(189 : ℝ)) := mul_le_mul_of_nonneg_right hK2 p189
      _ = Λ ^ (-(188 : ℝ)) := by rw [← Real.rpow_add hΛ0]; norm_num
      _ ≤ Λ ^ (-(96 : ℝ)) := Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)
  have f3 : 2 * Λ ^ (-(96 : ℝ)) ≤ Λ ^ (-(95 : ℝ)) := by
    have : Λ ^ (-(95 : ℝ)) = Λ ^ (-(96 : ℝ)) * Λ ^ (1 : ℕ) := by rw [rpow_shift hΛ0]; norm_num
    rw [this, pow_one]
    have : 0 < Λ ^ (-(96 : ℝ)) := by positivity
    nlinarith
  calc F1 * Mr * (Mr * Ab) * Aw * F4 * Br + Mr * Ab * F4 * WU * Xi
      ≤ (5 * Λ) * Mr * (Mr * Ab) * Λ * (2 * Λ) * (8 * Λ ^ (-(100 : ℝ))) +
        Mr * Ab * (2 * Λ) * (E * Λ ^ (10 : ℝ)) * (12.5 * Λ ^ (-(200 : ℝ))) := add_le_add t1 t2
    _ = (5 * Mr * (Mr * Ab) * 2 * 8) * Λ ^ (-(97 : ℝ)) + (Mr * Ab * 2 * E * 12.5) * Λ ^ (-(189 : ℝ)) := by
        rw [e1, e2]
    _ ≤ Λ ^ (-(96 : ℝ)) + Λ ^ (-(96 : ℝ)) := add_le_add f1 f2
    _ = 2 * Λ ^ (-(96 : ℝ)) := by ring
    _ ≤ Λ ^ (-(95 : ℝ)) := f3

section WT

set_option maxHeartbeats 2000000 in
set_option maxHeartbeats 2000000 in
/-- Each `WTerm` is `≤ Λ^{−95}` eventually. -/
theorem W_term_ev (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (h H : ℕ), Λ₀ ≤ Real.log h → H ≤ h →
      ∀ (s M : ℕ) [NeZero s] [NeZero M],
      ∀ (C U : Finset ℕ), (∀ p ∈ C, p.Prime) → s = ∏ p ∈ C, p → M = 6 * q →
        5 * (Real.log h) ^ σ₀ ≤ Real.log (s : ℝ) → (s : ℝ) ≤ h →
        (∀ p ∈ U, p.Prime ∧ 5 ≤ p ∧ p ≤ H ^ 2) →
        ∀ (A : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s),
          (∀ ρ j, 1 ≤ j → ‖A ρ j‖ ≤ (300 * (q : ℝ) ^ 2) / j) →
          (∀ j, 1 ≤ j → C.filter (fun p => (ZMod.cast (c j) : ZMod p) = 0) = C.filter (fun p => p ∣ j)) →
          GoldC.QuillonWCellApp.WTerm C U (Icc 1 (6 * q * h)) A c (Xp h) (Yp δ s) (H ^ 2) (LwW δ s) ≤
            (Real.log h) ^ (-(95 : ℝ)) := by
  set Ab : ℝ := 300 * (q : ℝ) ^ 2 with hAb
  set E : ℝ := Real.exp 10 * (2 * 2 + 1) ^ 10 with hE
  set K1 : ℝ := 5 * (6 * q) * (6 * q * Ab) * 2 * 8 with hK1
  set K2 : ℝ := 6 * q * Ab * 2 * E * 12.5 with hK2
  obtain ⟨Λ₁, hΛ₁, hbr⟩ := W_bracket_ev δ hδ0 hδ1
  obtain ⟨Λ₂, hΛ₂, hAω⟩ := Aω_le 5 (1 / 2) (by norm_num) (by norm_num)
  obtain ⟨Λ₃, hΛ₃, hs36⟩ := s_large 36
  obtain ⟨Λ₄, hΛ₄, hK1Λ⟩ := const_le_rpow K1 1 one_pos
  obtain ⟨Λ₅, hΛ₅, hK2Λ⟩ := const_le_rpow K2 1 one_pos
  set Λ₀ := max 2 (max Λ₁ (max Λ₂ (max Λ₃ (max Λ₄ (max Λ₅ (1 + Real.log (6 * q))))))) with hΛ₀
  refine ⟨Λ₀, le_max_left _ _, ?_⟩
  intro h H hΛ hHh s M _ _ C U hC hsC hM hlog hsh hU A c hA hc
  set Λ := Real.log h with hΛdef
  have hge : ∀ x, x ≤ Λ₀ → x ≤ Λ := fun x hx => le_trans hx hΛ
  have hΛ2 : 2 ≤ Λ := hge _ (le_max_left _ _)
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  have L1 := hge Λ₁ (by simp [hΛ₀])
  have L2 := hge Λ₂ (by simp [hΛ₀])
  have L3 := hge Λ₃ (by simp [hΛ₀])
  have L4 := hge Λ₄ (by simp [hΛ₀])
  have L5 := hge Λ₅ (by simp [hΛ₀])
  have L6 := hge (1 + Real.log (6 * q)) (by simp [hΛ₀])
  have hh1n : 1 ≤ h := by
    rcases Nat.eq_zero_or_pos h with h0 | h0
    · exfalso
      have : Real.log (h : ℝ) = 0 := by rw [h0]; simp
      linarith
    · exact h0
  have hh1 : (1 : ℝ) ≤ h := by exact_mod_cast hh1n
  have hh0 : (0 : ℝ) < h := by linarith
  have hspos : 0 < s := by rw [hsC]; exact prod_pos fun p hp => (hC p hp).pos
  have hs0 : (0 : ℝ) < s := by exact_mod_cast hspos
  have hs36' : (36 : ℝ) ≤ s := hs36 Λ L3 s hs0 hlog
  have hN := LwY_pos hδ0 hδ1 hs36'
  have hX2 : 2 ≤ Xp h := Xp_two hΛ2
  have hW := GoldC.QuillonWEst.WTerm_le (s := s) (M := M) C hC U (fun p hp => (hU p hp).2.1) (6 * q * h) A c Ab
    (by positivity) hA hc (Xp h) (Yp δ s) (H ^ 2) (LwW δ s) (by omega) hN
  refine le_trans hW ?_
  subst hM
  -- factor bounds
  have hmax : ((max (H ^ 2) (LwW δ s) : ℕ) : ℝ) ≤ (h : ℝ) ^ 2 := by
    have h1 : H ^ 2 ≤ h ^ 2 := Nat.pow_le_pow_left hHh 2
    have h2 : (LwW δ s : ℝ) ≤ h := le_trans (by exact_mod_cast LwW_le_self δ hδ0 s) hsh
    have h3 : (h : ℝ) ≤ (h : ℝ) ^ 2 := le_self_pow₀ hh1 (by norm_num)
    rcases le_total (H ^ 2) (LwW δ s) with hle | hle
    · rw [max_eq_right hle]; exact le_trans h2 h3
    · rw [max_eq_left hle]; exact_mod_cast h1
  have hmax0 : (0 : ℝ) < ((max (H ^ 2) (LwW δ s) : ℕ) : ℝ) := by
    have : 0 < LwW δ s := lt_of_lt_of_le (lt_of_lt_of_le Nat.zero_lt_one hN) (Nat.div_le_self _ _)
    exact_mod_cast lt_of_lt_of_le this (le_max_right _ _)
  have hlogmax : Real.log ((max (H ^ 2) (LwW δ s) : ℕ) : ℝ) ≤ 2 * Λ := by
    have := Real.log_le_log hmax0 hmax
    rwa [Real.log_pow, Nat.cast_ofNat] at this
  have b1 : (((Nat.log 2 (max (H ^ 2) (LwW δ s)) + 1 : ℕ)) : ℝ) ≤ 5 * Λ := by
    have := GoldC.QuillonLam.natlog_le_of _ _ hlogmax
    rw [max_eq_left (show (0 : ℝ) ≤ 2 * Λ by linarith)] at this
    push_cast; linarith
  have b2 : (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 * (max (H ^ 2) (LwW δ s)) ^ 2)) : ℝ) ^ 30) ^ 2
      ≤ Λ := by
    have hN2 : Real.log ((2 * (max (H ^ 2) (LwW δ s)) ^ 2 : ℕ) : ℝ) ≤ 5 * Λ := by
      rw [Nat.cast_mul, Nat.cast_pow, Nat.cast_ofNat, Real.log_mul (by norm_num) (by positivity),
        Real.log_pow]
      have : Real.log 2 < 1 := by have := Real.log_two_lt_d9; linarith
      have hl := hlogmax
      push_cast at hl ⊢; linarith
    have h1 := hAω Λ L2 _ hN2
    have h0 : 0 ≤ Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 * (max (H ^ 2) (LwW δ s)) ^ 2)) : ℝ) ^ 30 := by
      positivity
    calc _ ≤ (Λ ^ (1 / 2 : ℝ)) ^ 2 := pow_le_pow_left₀ h0 h1 2
      _ = Λ := by rw [← Real.rpow_natCast, ← Real.rpow_mul hΛ0.le]; norm_num
  have b3 : 1 + Real.log ((6 * q * h : ℕ) : ℝ) ≤ 2 * Λ := by
    push_cast
    rw [Real.log_mul (by positivity) hh0.ne']
    linarith
  have hXge := Xp_ge (h := h) hΛ1
  have hXpos : (0 : ℝ) < Xp h := by
    have : (0 : ℝ) < Λ ^ (200 : ℝ) := by positivity
    linarith
  have b4 : 2 / Real.sqrt (Xp h) ≤ 2 * Λ ^ (-(100 : ℝ)) := by
    have hsq : Λ ^ (100 : ℝ) ≤ Real.sqrt (Xp h) := by
      rw [Real.le_sqrt (by positivity) hXpos.le]
      calc (Λ ^ (100 : ℝ)) ^ 2 = Λ ^ (200 : ℝ) := by
            rw [← Real.rpow_natCast, ← Real.rpow_mul hΛ0.le]; norm_num
        _ ≤ Xp h := hXge
    have hp : 0 < Λ ^ (100 : ℝ) := by positivity
    rw [div_le_iff₀ (lt_of_lt_of_le hp hsq)]
    have e : Λ ^ (-(100 : ℝ)) * Λ ^ (100 : ℝ) = 1 := by
      rw [← Real.rpow_add hΛ0]; norm_num
    have hm : 0 ≤ Λ ^ (-(100 : ℝ)) := by positivity
    calc (2 : ℝ) = 2 * (Λ ^ (-(100 : ℝ)) * Λ ^ (100 : ℝ)) := by rw [e]; ring
      _ ≤ 2 * (Λ ^ (-(100 : ℝ)) * Real.sqrt (Xp h)) := by gcongr
      _ = 2 * Λ ^ (-(100 : ℝ)) * Real.sqrt (Xp h) := by ring
  have b5 := hbr Λ L1 C hC (by rw [← hsC]; exact hlog)
  rw [← hsC] at b5
  have b6 : ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) ≤ E * Λ ^ (10 : ℝ) := by
    have := prodU_le_pow U (fun p hp => ⟨(hU p hp).1, (hU p hp).2.1⟩) (h ^ 2)
      (fun p hp => le_trans (hU p hp).2.2 (Nat.pow_le_pow_left hHh 2)) 2 Λ (by norm_num) hΛ1
      (by push_cast; rw [Real.log_pow]; push_cast; linarith)
    exact this
  have b7 : (12.5 : ℝ) / Xp h ≤ 12.5 * Λ ^ (-(200 : ℝ)) := by
    rw [div_le_iff₀ hXpos]
    have e : Λ ^ (-(200 : ℝ)) * Λ ^ (200 : ℝ) = 1 := by
      rw [← Real.rpow_add hΛ0]; norm_num
    have hp : 0 ≤ Λ ^ (-(200 : ℝ)) := by positivity
    calc (12.5 : ℝ) = 12.5 * (Λ ^ (-(200 : ℝ)) * Λ ^ (200 : ℝ)) := by rw [e]; ring
      _ ≤ 12.5 * (Λ ^ (-(200 : ℝ)) * Xp h) := by gcongr
      _ = 12.5 * Λ ^ (-(200 : ℝ)) * Xp h := by ring
  have hbr0 : 0 ≤ 2 / Real.sqrt (Xp h) := by positivity
  have hlogJ0 : 0 ≤ 1 + Real.log ((6 * q * h : ℕ) : ℝ) := by
    have := Real.log_natCast_nonneg (6 * q * h); linarith
  have hU0 : 0 ≤ ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) := prod_nonneg fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast (hU p hp).2.1
    have : 0 ≤ 1 / ((p : ℝ) - 3) := div_nonneg zero_le_one (by linarith)
    linarith
  have hYge : 0 ≤ 1 + Real.log (Yp δ s : ℝ) := by
    have := Real.log_natCast_nonneg (Yp δ s); linarith
  have hbrk0 : 0 ≤ 2 / Real.sqrt (Xp h) + 2 * (1 + Real.log (Yp δ s : ℝ)) / Real.sqrt s +
          2 * (1 + Real.log (Yp δ s : ℝ)) * (8 : ℝ) ^ C.card *
            Real.sqrt ((s : ℝ) ^ ((3 : ℝ) / 4) / s + (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + Real.log s) /
              (LwW δ s / Yp δ s : ℕ)) := by positivity
  have hq0 : (0 : ℝ) < q := by exact_mod_cast hq
  have hAb0 : 0 ≤ Ab := by positivity
  have hF10 : (0 : ℝ) ≤ (((Nat.log 2 (max (H ^ 2) (LwW δ s)) + 1 : ℕ)) : ℝ) := by positivity
  have hAw0 : 0 ≤ (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 * (max (H ^ 2) (LwW δ s)) ^ 2)) : ℝ) ^ 30) ^ 2 :=
    by positivity
  have hXi0 : (0 : ℝ) ≤ 12.5 / Xp h := by positivity
  refine W_combine Λ _ _ Ab _ _ _ _ _ E hΛ2 (by positivity) hAb0 b1 hF10 b2 hAw0 b3 hlogJ0
    (by linarith) hbrk0 b6 hU0 b7 hXi0 ?_ ?_
  · have := hK1Λ Λ L4; rw [hK1] at this; push_cast; linarith
  · have := hK2Λ Λ L5; rw [hK2] at this; push_cast; linarith

end WT

lemma coprime_6q {q p : ℕ} (hp : p.Prime) (h5 : 5 ≤ p) (hq : ¬ p ∣ q) : p.Coprime (6 * q) := by
  apply Nat.Coprime.mul_right
  · rw [Nat.Prime.coprime_iff_not_dvd hp]
    intro h6
    have := Nat.le_of_dvd (by norm_num) h6
    interval_cases p
    all_goals (revert hp h6; norm_num)
  · exact (Nat.Prime.coprime_iff_not_dvd hp).2 hq

lemma prod_coprime_of {S : Finset ℕ} {m : ℕ} (h : ∀ p ∈ S, p.Coprime m) : (∏ p ∈ S, p).Coprime m :=
  Nat.Coprime.prod_left h

open Classical in
set_option maxHeartbeats 4000000 in
/-- **The W′ cell for a fixed `C` is `≤ 4Λ^{−95}`**, eventually in `h`, uniformly in `a, d, C, Kc`. -/
theorem W_final (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (a h H D : ℕ) (T C : Finset ℕ) (Kc : ℕ → Prop) [DecidablePred Kc],
      Λ₀ ≤ Real.log h → 2 ≤ h → H ≤ h →
      (∀ p ∈ T, p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q ∧ p.Coprime H ∧ p ≤ H ^ 2) → C ⊆ T →
      |∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
          (if (Kc B.card ∧ Geo0 h H δ (∏ p ∈ B, p) (∏ p ∈ C, p)) ∧
              (B ∩ (T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ Yp δ (∏ p ∈ C, p))).Nonempty
            then GoldC.QuillonWContext.ωR B *
              GoldC.QuillonCopyF.foldRow q a D H (∏ p ∈ B, p) (∏ p ∈ C, p) else 0)| ≤
        4 * (Real.log h) ^ (-(95 : ℝ)) := by
  obtain ⟨Λ₁, hΛ₁, hWT⟩ := W_term_ev q hq δ hδ0 hδ1
  obtain ⟨Λ₂, hΛ₂, h36⟩ := s_large 36
  refine ⟨max Λ₁ Λ₂, le_trans hΛ₁ (le_max_left _ _), ?_⟩
  intro a h H D T C Kc _ hΛ hh hHh hT hCT
  have hΛa : Λ₁ ≤ Real.log h := le_trans (le_max_left _ _) hΛ
  have hΛb : Λ₂ ≤ Real.log h := le_trans (le_max_right _ _) hΛ
  set s := ∏ p ∈ C, p with hs
  have hpos4 : 0 ≤ 4 * (Real.log h) ^ (-(95 : ℝ)) := by
    have : 0 ≤ Real.log h := Real.log_nonneg (by exact_mod_cast (by omega : 1 ≤ h))
    positivity
  -- empty case
  by_cases hex : ∃ r, Geo0 h H δ r s
  swap
  · push_neg at hex
    rw [sum_eq_zero fun B _ => by rw [if_neg]; rintro ⟨⟨-, hg⟩, -⟩; exact hex _ hg, abs_zero]
    exact hpos4
  obtain ⟨r₀, hr₀⟩ := hex
  obtain ⟨hlogs, -, -, hs1, -, hsh, -, -, -⟩ := adm h H r₀ s δ hδ0 hδ1 hh hHh hr₀
  have hCp : ∀ p ∈ C, p.Prime := fun p hp => (hT p (hCT hp)).1
  have hspos : 0 < s := prod_pos fun p hp => (hCp p hp).pos
  have hs0 : (0 : ℝ) < s := by exact_mod_cast hspos
  have hsR : (36 : ℝ) ≤ s := h36 _ hΛb s hs0 hlogs
  have hs2 : 2 ≤ s := by
    have : (2 : ℝ) ≤ s := by linarith
    exact_mod_cast this
  haveI : NeZero s := ⟨by omega⟩
  haveI : NeZero (6 * q) := ⟨by omega⟩
  have hTc : ∀ p ∈ T, p.Prime ∧ 5 ≤ p ∧ p.Coprime (6 * q) ∧ p.Coprime H := fun p hp =>
    ⟨(hT p hp).1, (hT p hp).2.1, coprime_6q (hT p hp).1 (hT p hp).2.1 (hT p hp).2.2.1, (hT p hp).2.2.2.1⟩
  have hsM : s.Coprime (6 * q) := prod_coprime_of fun p hp => (hTc p (hCT hp)).2.2.1
  set μ := GoldC.QuillonCopyF.meanWeight q (GoldC.QuillonCopyF.reducedAnchor q a D) H with hμ
  set Γ := GoldC.QuillonCopyF.gammaClass q a D H with hΓ
  have hμb : |μ| ≤ 4 := by
    have := GoldC.QuillonCopyF.meanWeight_bounds q (GoldC.QuillonCopyF.reducedAnchor q a D) H
    rw [abs_le]; constructor <;> linarith
  have hΓb : ∀ b ν, |Γ b ν| ≤ 48 * q := fun b ν => by
    have := GoldC.QuillonCopyF.abs_gammaClass_le q a D H b ν hq
    have e : (8 : ℝ) * (6 * q) = 48 * q := by ring
    linarith
  have hN := LwY_pos hδ0 hδ1 hsR
  have hY1 := Yp_pos hδ0 hδ1 hs1
  have hYL : Yp δ s ≤ LwW δ s := by
    have := (Nat.le_div_iff_mul_le hY1).1 hN
    omega
  have hX2 : 2 ≤ Xp h := Xp_two (le_trans hΛ₁ hΛa)
  have hshn : s ≤ h := by exact_mod_cast hsh
  have hcell := GoldC.QuillonWCellApp.W_cell (s := s) (M := 6 * q) (by omega) H μ Γ T C hTc hCT rfl hs2
    ((T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ Yp δ s)) (filter_subset _ _) (Xp h) (Yp δ s) hX2 hY1
    (fun p hp => (mem_filter.1 hp).2) Kc (fun r => Geo0 h H δ r s) (H ^ 2) (LwW δ s)
    (fun r hG => by
      have h4 := hG.2.1
      have : r ≤ r * s := Nat.le_mul_of_pos_right r hspos
      omega)
    (fun r hG => LwW_lt hδ0 hG) hYL (geo0_convex_r h H δ hδ0.le s)
    (fun r => GoldC.QuillonCopyF.foldRow q a D H r s)
    (fun B hB hne _ => by
      have hBp : ∀ p ∈ B, p.Prime ∧ 5 ≤ p := fun p hp =>
        ⟨(hT p (sdiff_subset (hB hp))).1, (hT p (sdiff_subset (hB hp))).2.1⟩
      obtain ⟨p, hp⟩ := nonempty_iff_ne_empty.2 hne
      have hr2 : 2 ≤ ∏ p ∈ B, p := by
        have h1 : p ∣ ∏ p ∈ B, p := dvd_prod_of_mem _ hp
        have h2 : 0 < ∏ p ∈ B, p := prod_pos fun p hp => (hBp p hp).1.pos
        have := Nat.le_of_dvd h2 h1
        have := (hBp p hp).2; omega
      exact GoldC.QuillonBridge.foldRow_eq_rowAbs q a D H _ s hq hr2 hs2
        (prod_coprime_of fun p hp => (hTc p (sdiff_subset (hB hp))).2.2.1) hsM)
    (6 * q * h) (by nlinarith)
  refine le_trans hcell ?_
  have hU : ∀ p ∈ T \ C, p.Prime ∧ 5 ≤ p ∧ p ≤ H ^ 2 := fun p hp =>
    ⟨(hT p (sdiff_subset hp)).1, (hT p (sdiff_subset hp)).2.1, (hT p (sdiff_subset hp)).2.2.2.2⟩
  have hCH : ∀ p ∈ C, p.Prime ∧ p.Coprime H := fun p hp => ⟨hCp p hp, (hT p (hCT hp)).2.2.2.1⟩
  have hs1' : 1 ≤ s := hs1
  have w1 := hWT h H hΛa hHh s (6 * q) C (T \ C) hCp rfl rfl hlogs hsh hU
    (fun (_ : ZMod (6 * q)) k => ((-(2 * μ) : ℝ) : ℂ) * GoldC.QuillonRowNF.αm k s)
    (fun k => ((((k : ℤ) * H : ℤ)) : ZMod s))
    (fun ρ j hj => GoldC.QuillonRowFacts.coef_main q hq μ hμb s hs1' (6 * q) ρ j hj)
    (GoldC.QuillonRowFacts.hc_gen C hCp rfl (H : ℤ) (GoldC.QuillonRowFacts.not_dvd_H hCH) 1 (Or.inl rfl) _
      (fun j => by congr 1; ring))
  have w2 := hWT h H hΛa hHh s (6 * q) C (T \ C) hCp rfl rfl hlogs hsh hU
    (fun (_ : ZMod (6 * q)) k => -(((-(2 * μ) : ℝ) : ℂ) * GoldC.QuillonRowNF.αm k s))
    (fun k => ((((-(k : ℤ)) * H : ℤ)) : ZMod s))
    (fun ρ j hj => GoldC.QuillonRowFacts.coef_mainN q hq μ hμb s hs1' (6 * q) ρ j hj)
    (GoldC.QuillonRowFacts.hc_gen C hCp rfl (H : ℤ) (GoldC.QuillonRowFacts.not_dvd_H hCH) (-1)
      (Or.inr rfl) _ (fun j => by congr 1; ring))
  have w3 := hWT h H hΛa hHh s (6 * q) C (T \ C) hCp rfl rfl hlogs hsh hU
    (fun (ρ : ZMod (6 * q)) k => GoldC.QuillonRowNF.αm k ((6 * q) * s) *
      GoldC.QuillonRowNF.BclS (6 * q) Γ s (k : ℤ) ρ)
    (fun k => ((((k : ℤ) * H * GoldC.QuillonCopyC.invMod (6 * q) s : ℤ)) : ZMod s))
    (fun ρ j hj => GoldC.QuillonRowFacts.coef_cls q hq Γ hΓb s hs1' (fun k => (k : ℤ)) ρ j hj)
    (GoldC.QuillonRowFacts.hc_gen C hCp rfl _
      (GoldC.QuillonRowFacts.not_dvd_HinvM hCH rfl hs2 hsM.symm) 1 (Or.inl rfl) _
      (fun j => by congr 1; ring))
  have w4 := hWT h H hΛa hHh s (6 * q) C (T \ C) hCp rfl rfl hlogs hsh hU
    (fun (ρ : ZMod (6 * q)) k => -(GoldC.QuillonRowNF.αm k ((6 * q) * s) *
      GoldC.QuillonRowNF.BclS (6 * q) Γ s (-(k : ℤ)) ρ))
    (fun k => ((((-(k : ℤ)) * H * GoldC.QuillonCopyC.invMod (6 * q) s : ℤ)) : ZMod s))
    (fun ρ j hj => GoldC.QuillonRowFacts.coef_clsN q hq Γ hΓb s hs1' (fun k => -(k : ℤ)) ρ j hj)
    (GoldC.QuillonRowFacts.hc_gen C hCp rfl _
      (GoldC.QuillonRowFacts.not_dvd_HinvM hCH rfl hs2 hsM.symm) (-1) (Or.inr rfl) _
      (fun j => by congr 1; ring))
  linarith


end GoldC.QuillonWFinal

#print axioms GoldC.QuillonWFinal.W_bracket_ev
#print axioms GoldC.QuillonWFinal.W_term_ev
#print axioms GoldC.QuillonWFinal.W_final
