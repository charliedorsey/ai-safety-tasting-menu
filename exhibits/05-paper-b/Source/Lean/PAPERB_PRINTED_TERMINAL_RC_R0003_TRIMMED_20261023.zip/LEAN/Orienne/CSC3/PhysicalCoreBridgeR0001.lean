import GoldC.QuillonCoreFinal
import PaperB.Gate3.CentralTransfer.MiddleLongCoreConsumer

/-!
R0014 independent court: genuine production source bridge.
The right side of every bridge is the imported literal curated definition.
No new analytic assumptions, copied observable, or custom axiom.
-/

open scoped BigOperators Classical
namespace Orienne.CSC3

/-- Every copy-level uniform rate is a literal curated rate on the *same* S. -/
theorem copied_rate_to_native
    (S : ℕ → ℕ → ℕ → ℝ)
    (hS : GoldC.QuillonCopyM.SourceUniformSublog S) :
    Merivelle.Central.SourceUniformSublog S := by
  exact hS

/-- The Quillon source-copy CORE and Merivelle's exact selected signed CORE
are definitionally equal, including all parent weights, decorations,
ordered proper orientations, strict inequalities, and the moving source. -/
theorem signed_core_copy_eq_native
    (Jlow Jhigh : ℕ → ℕ) (δ : ℝ) (q a h : ℕ) :
    GoldC.QuillonCopyM.signedCoreMiddle Jlow Jhigh δ q a h =
      Merivelle.Central.signedCoreMiddle Jlow Jhigh δ q a h := by
  rfl

/-- Quillon R0014 supplies the *production* signed CORE SourceUniformSublog. -/
theorem core_source_native_sublog
    (Jlow Jhigh : ℕ → ℕ) (δ : ℝ)
    (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    Merivelle.Central.SourceUniformSublog
      (Merivelle.Central.signedCoreMiddle Jlow Jhigh δ) := by
  have h := GoldC.QuillonCoreFinal.core_sublog Jlow Jhigh δ hδ0 hδ1
  have hcopy :
      GoldC.QuillonCopyM.SourceUniformSublog
        (Merivelle.Central.signedCoreMiddle Jlow Jhigh δ) := by
    convert h using 1
    funext q a x
    exact signed_core_copy_eq_native Jlow Jhigh δ q a x
  exact copied_rate_to_native _ hcopy

#print axioms copied_rate_to_native
#print axioms signed_core_copy_eq_native
#print axioms core_source_native_sublog
end Orienne.CSC3
