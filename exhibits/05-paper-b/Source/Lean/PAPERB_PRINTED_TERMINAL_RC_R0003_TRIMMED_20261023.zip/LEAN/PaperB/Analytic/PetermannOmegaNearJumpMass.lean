import PaperB.Analytic.PetermannOmegaNearJumpSplit
import PaperB.Analytic.VdCorput2
import PaperB.FixedQ.RowReduction
import PaperB.FixedQ.PetermannConvolutionGlobal
import PaperB.FixedQ.PetermannCorrectionMoment
import Mathlib.NumberTheory.ArithmeticFunction.Zeta
import Mathlib.Algebra.Order.Round
import Mathlib.Data.Int.Interval
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.SpecialFunctions.Log.Base

open scoped BigOperators ArithmeticFunction

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset
open ArithmeticFunction




private lemma omega_near_jump_round_bound
    {q e : ℕ} {T S : ℝ} {r : ℤ}
    (hne : ¬ petermannOmegaAwayFromJump q T r S e) :
    let L : ℝ := (Nat.lcm 6 q : ℕ)
    let phase : ℝ := T / L / (e : ℝ) + (r : ℝ) / L
    |phase - (round phase : ℝ)| ≤ 1 / (2 * S) := by
  dsimp
  unfold petermannOmegaAwayFromJump at hne
  rw [abs_sub_round_eq_min]
  rw [sawSmoothHalfWidth] at hne
  push_neg at hne
  by_cases hleft : Int.fract
      (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
        (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) ≤ 1 / (2 * S)
  · exact le_trans (min_le_left _ _) hleft
  · have hlow : 1 / (2 * S) < Int.fract
        (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
          (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) := lt_of_not_ge hleft
    have hright := hne hlow
    exact le_trans (min_le_right _ _) (le_of_lt (by linarith))

private lemma omega_near_jump_integer_bound
    {q e : ℕ} {T S : ℝ} {r : ℤ}
    (hq : 0 < q)
    (he : 1 ≤ e)
    (hne : ¬ petermannOmegaAwayFromJump q T r S e) :
    let L := Nat.lcm 6 q
    let phase : ℝ := T / (L : ℝ) / (e : ℝ) + (r : ℝ) / (L : ℝ)
    let k : ℤ := round phase
    let N : ℤ := (e : ℤ) * ((L : ℤ) * k - r)
    |T - (N : ℝ)| ≤ ((L : ℝ) * (e : ℝ)) / (2 * S) := by
  dsimp
  let L := Nat.lcm 6 q
  let phase : ℝ := T / (L : ℝ) / (e : ℝ) + (r : ℝ) / (L : ℝ)
  let k : ℤ := round phase
  let N : ℤ := (e : ℤ) * ((L : ℤ) * k - r)
  have hL : 0 < L := Nat.lcm_pos (by norm_num) hq
  have he0 : 0 < e := by omega
  have hden : 0 < (L : ℝ) * (e : ℝ) := by positivity
  have hb : |phase - (k : ℝ)| ≤ 1 / (2 * S) := by
    simpa [phase, k, L] using
      (omega_near_jump_round_bound (q := q) (e := e)
        (T := T) (S := S) (r := r) hne)
  have hid :
      phase - (k : ℝ) =
        (T - (N : ℝ)) / ((L : ℝ) * (e : ℝ)) := by
    dsimp [phase, k, N]
    push_cast
    field_simp [ne_of_gt (by exact_mod_cast hL), ne_of_gt (by exact_mod_cast he0)]
    ring
  rw [hid, abs_div, abs_of_pos hden] at hb
  have hmul := (div_le_iff₀ hden).mp hb
  change |T - (N : ℝ)| ≤ ((L : ℝ) * (e : ℝ)) / (2 * S)
  calc
    |T - (N : ℝ)| ≤ (1 / (2 * S)) * ((L : ℝ) * (e : ℝ)) := by
      simpa [div_eq_mul_inv, mul_assoc, mul_left_comm, mul_comm] using hmul
    _ = ((L : ℝ) * (e : ℝ)) / (2 * S) := by ring






private lemma round_mono_real {x y : ℝ} (hxy : x ≤ y) :
    round x ≤ round y := by
  rw [round_eq x, round_eq y]
  exact Int.floor_mono (by linarith)

private lemma omega_near_jump_round_bound_local
    {q e : ℕ} {T S : ℝ} {r : ℤ}
    (hne : ¬ petermannOmegaAwayFromJump q T r S e) :
    let L : ℝ := (Nat.lcm 6 q : ℕ)
    let phase : ℝ := T / L / (e : ℝ) + (r : ℝ) / L
    |phase - (round phase : ℝ)| ≤ 1 / (2 * S) := by
  dsimp
  unfold petermannOmegaAwayFromJump at hne
  rw [abs_sub_round_eq_min, sawSmoothHalfWidth] at *
  push_neg at hne
  by_cases hleft : Int.fract
      (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
        (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) ≤ 1 / (2 * S)
  · exact le_trans (min_le_left _ _) hleft
  · have hlow : 1 / (2 * S) < Int.fract
        (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
          (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) := lt_of_not_ge hleft
    have hright := hne hlow
    exact le_trans (min_le_right _ _) (le_of_lt (by linarith))

private lemma omega_reciprocal_phase_accum_local
    {q E u v : ℕ} {T : ℝ} {r : ℤ}
    (hq : 0 < q) (hT : 0 < T) (hE : 0 < E)
    (hEu : E < u) (huv : u ≤ v) (hv2E : v ≤ 2 * E) :
    let L : ℝ := (Nat.lcm 6 q : ℕ)
    let g : ℕ → ℝ := fun n =>
      -(T / L / (n : ℝ) + (r : ℝ) / L)
    let lam : ℝ := T / (4 * L * (E : ℝ)^2)
    ((v : ℝ) - u) * lam ≤ g v - g u := by
  dsimp
  let L : ℝ := (Nat.lcm 6 q : ℕ)
  have hLnat : 0 < Nat.lcm 6 q := Nat.lcm_pos (by norm_num) hq
  have hL : 0 < L := by
    dsimp [L]
    exact_mod_cast hLnat
  have hu0 : 0 < (u : ℝ) := by exact_mod_cast (lt_trans hE hEu)
  have hv0 : 0 < (v : ℝ) := lt_of_lt_of_le hu0 (by exact_mod_cast huv)
  have hE0 : 0 < (E : ℝ) := by exact_mod_cast hE
  have hu2E : (u : ℝ) ≤ 2 * (E : ℝ) := by
    exact_mod_cast (le_trans huv hv2E)
  have hv2ER : (v : ℝ) ≤ 2 * (E : ℝ) := by exact_mod_cast hv2E
  have hdenPos : 0 < (u : ℝ) * (v : ℝ) := mul_pos hu0 hv0
  have hdenBound :
      (u : ℝ) * (v : ℝ) ≤ 4 * (E : ℝ)^2 := by
    nlinarith
  have hrecip :
      1 / (4 * (E : ℝ)^2) ≤
        1 / ((u : ℝ) * (v : ℝ)) :=
    one_div_le_one_div_of_le hdenPos hdenBound
  have huvR : (u : ℝ) ≤ (v : ℝ) := by exact_mod_cast huv
  have hcoef : 0 ≤ ((v : ℝ) - u) * (T / L) := by positivity
  have hmul := mul_le_mul_of_nonneg_left hrecip hcoef
  calc
    ((v : ℝ) - u) * (T / (4 * L * (E : ℝ)^2)) =
      (((v : ℝ) - u) * (T / L)) *
        (1 / (4 * (E : ℝ)^2)) := by
          field_simp [ne_of_gt hL, ne_of_gt hE0]
    _ ≤ (((v : ℝ) - u) * (T / L)) *
        (1 / ((u : ℝ) * (v : ℝ))) := hmul
    _ = -(T / L / (v : ℝ) + (r : ℝ) / L) -
        (-(T / L / (u : ℝ) + (r : ℝ) / L)) := by
          field_simp [ne_of_gt hL, ne_of_gt hu0, ne_of_gt hv0]
          ring

private noncomputable def petermannOmegaNearJumpBlock
    (q E : ℕ) (T S : ℝ) (r : ℤ) : Finset ℕ := by
  classical
  exact (Finset.Ioc E (2 * E)).filter
    (fun e => ¬ petermannOmegaAwayFromJump q T r S e)

private theorem petermannOmegaNearJump_dyadic_card_le
    (q E : ℕ) (hq : 0 < q) (hE : 0 < E)
    (T S : ℝ) (hT : 0 < T) (hS : 0 < S) (r : ℤ) :
    let L : ℝ := (Nat.lcm 6 q : ℕ)
    ((petermannOmegaNearJumpBlock q E T S r).card : ℝ) ≤
      (T / (L * (E : ℝ)) + 2) *
        (4 * L * (E : ℝ)^2 / (S * T) + 2) := by
  classical
  dsimp
  let L : ℝ := (Nat.lcm 6 q : ℕ)
  let phase : ℕ → ℝ := fun n =>
    T / L / (n : ℝ) + (r : ℝ) / L
  let g : ℕ → ℝ := fun n => - phase n
  let lam : ℝ := T / (4 * L * (E : ℝ)^2)
  let a : ℝ := 1 / (2 * S)
  let lower : ℝ := T / L / (2 * E : ℝ) + (r : ℝ) / L
  let upper : ℝ := T / L / (E : ℝ) + (r : ℝ) / L
  let klo : ℤ := round lower
  let khi : ℤ := round upper
  let K : Finset ℤ := Finset.Icc klo khi
  let B : Finset ℕ := petermannOmegaNearJumpBlock q E T S r
  have hLnat : 0 < Nat.lcm 6 q := Nat.lcm_pos (by norm_num) hq
  have hL : 0 < L := by
    dsimp [L]
    exact_mod_cast hLnat
  have hER : 0 < (E : ℝ) := by exact_mod_cast hE
  have hlam : 0 < lam := by
    dsimp [lam]
    positivity
  have ha0 : 0 ≤ a := by
    dsimp [a]
    positivity
  have hphase_bounds :
      ∀ e ∈ Finset.Ioc E (2 * E),
        lower ≤ phase e ∧ phase e ≤ upper := by
    intro e he
    have heI := Finset.mem_Ioc.mp he
    have he0 : 0 < e := lt_trans hE heI.1
    have heR : 0 < (e : ℝ) := by exact_mod_cast he0
    have hE_e : (E : ℝ) ≤ e := by exact_mod_cast (Nat.le_of_lt heI.1)
    have he_2E : (e : ℝ) ≤ 2 * (E : ℝ) := by exact_mod_cast heI.2
    have hc : 0 ≤ T / L := by positivity
    have hlowrec :
        1 / (2 * (E : ℝ)) ≤ 1 / (e : ℝ) :=
      one_div_le_one_div_of_le heR he_2E
    have hupprec :
        1 / (e : ℝ) ≤ 1 / (E : ℝ) :=
      one_div_le_one_div_of_le hER hE_e
    constructor
    · dsimp [lower, phase]
      have hm := mul_le_mul_of_nonneg_left hlowrec hc
      simpa [div_eq_mul_inv, mul_assoc] using add_le_add_right hm ((r : ℝ) / L)
    · dsimp [upper, phase]
      have hm := mul_le_mul_of_nonneg_left hupprec hc
      simpa [div_eq_mul_inv, mul_assoc] using add_le_add_right hm ((r : ℝ) / L)
  have hlowerupper : lower ≤ upper := by
    have hrec : 1 / (2 * (E : ℝ)) ≤ 1 / (E : ℝ) :=
      one_div_le_one_div_of_le hER (by nlinarith)
    have hc : 0 ≤ T / L := by positivity
    dsimp [lower, upper]
    have hm := mul_le_mul_of_nonneg_left hrec hc
    simpa [div_eq_mul_inv, mul_assoc] using add_le_add_right hm ((r : ℝ) / L)
  have hklohi : klo ≤ khi := by
    dsimp [klo, khi]
    exact round_mono_real hlowerupper
  have hmap : Set.MapsTo (fun e : ℕ => round (phase e)) (↑B : Set ℕ) (↑K : Set ℤ) := by
    intro e heB
    have heMem : e ∈ B := heB
    have heData : e ∈ Finset.Ioc E (2 * E) ∧
        ¬ petermannOmegaAwayFromJump q T r S e := by
      simpa [B, petermannOmegaNearJumpBlock] using heMem
    have heI : e ∈ Finset.Ioc E (2 * E) := heData.1
    have hb := hphase_bounds e heI
    exact Finset.mem_Icc.mpr
      ⟨round_mono_real hb.1, round_mono_real hb.2⟩
  have hfiber :
      ∀ k ∈ K,
        (((B.filter (fun e => round (phase e) = k)).card : ℕ) : ℝ) ≤
          (4 * L * (E : ℝ)^2 / (S * T) + 2) := by
    intro k hk
    let W :=
      (Finset.Ioc E (2 * E)).filter
        (fun e => (-(k : ℝ) - a) ≤ g e ∧
          g e < (-(k : ℝ) - a) + (2 * a + lam))
    have hsub : B.filter (fun e => round (phase e) = k) ⊆ W := by
      intro e he
      have heB : e ∈ B := (Finset.mem_filter.mp he).1
      have hkE : round (phase e) = k := (Finset.mem_filter.mp he).2
      have heData : e ∈ Finset.Ioc E (2 * E) ∧
          ¬ petermannOmegaAwayFromJump q T r S e := by
        simpa [B, petermannOmegaNearJumpBlock] using heB
      have heI : e ∈ Finset.Ioc E (2 * E) := heData.1
      have hnear : ¬ petermannOmegaAwayFromJump q T r S e := heData.2
      have hrnd : |phase e - (k : ℝ)| ≤ a := by
        have h0 := omega_near_jump_round_bound_local
          (q := q) (e := e) (T := T) (S := S) (r := r) hnear
        have h0' : |phase e - (round (phase e) : ℝ)| ≤ a := by
          simpa [phase, L, a] using h0
        rw [hkE] at h0'
        exact h0'
      have habs := abs_le.mp hrnd
      apply Finset.mem_filter.mpr
      refine ⟨heI, ?_, ?_⟩
      · dsimp [g]
        linarith
      · dsimp [g]
        linarith [hlam]
    have hcardSub :
        (((B.filter (fun e => round (phase e) = k)).card : ℕ) : ℝ) ≤
          (W.card : ℝ) := by
      exact_mod_cast Finset.card_le_card hsub
    have hacc :
        ∀ p q', E < p → p ≤ q' → q' ≤ 2 * E →
          ((q' : ℝ) - p) * lam ≤ g q' - g p := by
      intro p q' hp hpq hq'
      simpa [g, phase, lam, L] using
        (omega_reciprocal_phase_accum_local
          (q := q) (E := E) (u := p) (v := q')
          (T := T) (r := r) hq hT hE hp hpq hq')
    have hW := count_window hlam hacc
      (-(k : ℝ) - a) (2 * a + lam) (by positivity)
    have hW' :
        (W.card : ℝ) ≤ (2 * a + lam) / lam + 1 := by
      simpa [W] using hW
    calc
      (((B.filter (fun e => round (phase e) = k)).card : ℕ) : ℝ)
          ≤ (W.card : ℝ) := hcardSub
      _ ≤ (2 * a + lam) / lam + 1 := hW'
      _ = 4 * L * (E : ℝ)^2 / (S * T) + 2 := by
        dsimp [a, lam]
        field_simp [ne_of_gt hS, ne_of_gt hT, ne_of_gt hL, ne_of_gt hER]
        ring
  have hcardK :
      (K.card : ℝ) ≤ T / (L * (E : ℝ)) + 2 := by
    have hcardZ := Int.card_Icc_of_le klo khi (by omega)
    have hcardR :
        (K.card : ℝ) = (khi : ℝ) + 1 - (klo : ℝ) := by
      dsimp [K]
      exact_mod_cast hcardZ
    have hkhi : (khi : ℝ) ≤ upper + 1 / 2 := by
      dsimp [khi]
      exact round_le_add_half upper
    have hklo : lower - 1 / 2 ≤ (klo : ℝ) := by
      dsimp [klo]
      exact le_of_lt (sub_half_lt_round lower)
    rw [hcardR]
    have hrange :
        upper - lower ≤ T / (L * (E : ℝ)) := by
      have hid : upper - lower = T / (2 * L * (E : ℝ)) := by
        dsimp [upper, lower]
        field_simp [ne_of_gt hL, ne_of_gt hER]
        ring
      rw [hid]
      have hden1 : 0 < L * (E : ℝ) := mul_pos hL hER
      have hden2 : L * (E : ℝ) ≤ 2 * L * (E : ℝ) := by nlinarith
      exact div_le_div_of_nonneg_left hT.le hden1 hden2
    linarith
  have hcardFib := Finset.card_eq_sum_card_fiberwise hmap
  have hsum :
      (∑ k ∈ K,
        (((B.filter (fun e => round (phase e) = k)).card : ℕ) : ℝ)) ≤
        (K.card : ℝ) * (4 * L * (E : ℝ)^2 / (S * T) + 2) := by
    calc
      (∑ k ∈ K,
        (((B.filter (fun e => round (phase e) = k)).card : ℕ) : ℝ))
        ≤ ∑ _k ∈ K, (4 * L * (E : ℝ)^2 / (S * T) + 2) := by
          apply Finset.sum_le_sum
          intro k hk
          exact hfiber k hk
      _ = (K.card : ℝ) * (4 * L * (E : ℝ)^2 / (S * T) + 2) := by
          simp
          ring
  have hfac0 : 0 ≤ 4 * L * (E : ℝ)^2 / (S * T) + 2 := by positivity
  change (B.card : ℝ) ≤ _
  calc
    (B.card : ℝ) =
      ∑ k ∈ K,
        (((B.filter (fun e => round (phase e) = k)).card : ℕ) : ℝ) := by
          exact_mod_cast hcardFib
    _ ≤ (K.card : ℝ) * (4 * L * (E : ℝ)^2 / (S * T) + 2) := hsum
    _ ≤ (T / (L * (E : ℝ)) + 2) *
        (4 * L * (E : ℝ)^2 / (S * T) + 2) :=
      mul_le_mul_of_nonneg_right hcardK hfac0

/-- Minimal public dyadic near-jump block exposing only the paid geometry. -/
noncomputable def petermannNearJumpDyadicBlock
    (q E : ℕ) (T S : ℝ) (r : ℤ) : Finset ℕ := by
  classical
  exact (Finset.Ioc E (2 * E)).filter
    (fun e => ¬ petermannOmegaAwayFromJump q T r S e)

/-- Public cardinality wrapper for the paid near-jump dyadic geometry.
    This exposes no omega weight arithmetic. -/
theorem petermannOmegaNearJump_dyadic_card_le_public
    (q E : ℕ) (hq : 0 < q) (hE : 0 < E)
    (T S : ℝ) (hT : 0 < T) (hS : 0 < S) (r : ℤ) :
    let L : ℝ := (Nat.lcm 6 q : ℕ)
    ((petermannNearJumpDyadicBlock q E T S r).card : ℝ) ≤
      (T / (L * (E : ℝ)) + 2) *
        (4 * L * (E : ℝ)^2 / (S * T) + 2) := by
  classical
  simpa [petermannNearJumpDyadicBlock, petermannOmegaNearJumpBlock] using
    (petermannOmegaNearJump_dyadic_card_le
      q E hq hE T S hT hS r)

#print axioms petermannOmegaNearJump_dyadic_card_le_public







private lemma omega_local_pointwise_factor_le
    {p : ℕ} (hp5 : 5 ≤ p) :
    (1 : ℝ) / ((p : ℝ) - 3) ≤
      (((p : ℝ) / ((p : ℝ) - 1)) ^ 5) / (p : ℝ) := by
  have hp : (5 : ℝ) ≤ (p : ℝ) := by exact_mod_cast hp5
  have hp0 : 0 < (p : ℝ) := by linarith
  have hp1 : 0 < (p : ℝ) - 1 := by linarith
  have hp3 : 0 < (p : ℝ) - 3 := by linarith
  field_simp [ne_of_gt hp0, ne_of_gt hp1, ne_of_gt hp3]
  nlinarith [sq_nonneg ((p : ℝ) - 5),
    sq_nonneg ((p : ℝ) - 4),
    sq_nonneg ((p : ℝ) - 3),
    sq_nonneg ((p : ℝ) - 2),
    sq_nonneg ((p : ℝ) - 1)]

private lemma omegaCoeff_le_totient_ratio_pow5_div
    (q e : ℕ) (he16 : 16 ≤ e) :
    omegaCoeff q e ≤
      (((e : ℝ) / (e.totient : ℝ)) ^ 5) / (e : ℝ) := by
  have he0 : e ≠ 0 := by omega
  rw [omegaCoeff, if_neg he0]
  by_cases hsupp : Squarefree e ∧ e.Coprime (6 * q)
  · rw [if_pos hsupp]
    have hsq := hsupp.1
    have hcop := hsupp.2
    have hprod :
        (∏ p ∈ e.primeFactors, (1 : ℝ) / ((p : ℝ) - 3))
          ≤
        ∏ p ∈ e.primeFactors,
          ((((p : ℝ) / ((p : ℝ) - 1)) ^ 5) / (p : ℝ)) := by
      apply Finset.prod_le_prod₀
      · intro p hp
        have hpP := Nat.prime_of_mem_primeFactors hp
        have hpCop : p.Coprime (6 * q) :=
          hcop.coprime_dvd_left (Nat.dvd_of_mem_primeFactors hp)
        have hp5 := omega_rankin_five_le_of_prime_coprime_six hpP hpCop
        exact div_nonneg (by norm_num) (by
          exact sub_nonneg.mpr (by exact_mod_cast (show 3 ≤ p by omega)))
      · intro p hp
        have hpP := Nat.prime_of_mem_primeFactors hp
        have hpCop : p.Coprime (6 * q) :=
          hcop.coprime_dvd_left (Nat.dvd_of_mem_primeFactors hp)
        have hp5 := omega_rankin_five_le_of_prime_coprime_six hpP hpCop
        exact omega_local_pointwise_factor_le hp5
    calc
      (∏ p ∈ e.primeFactors, (1 : ℝ) / ((p : ℝ) - 3))
        ≤ ∏ p ∈ e.primeFactors,
          ((((p : ℝ) / ((p : ℝ) - 1)) ^ 5) / (p : ℝ)) := hprod
      _ =
        ((∏ p ∈ e.primeFactors,
            ((p : ℝ) / ((p : ℝ) - 1))) ^ 5) /
          (∏ p ∈ e.primeFactors, (p : ℝ)) := by
            rw [Finset.prod_div_distrib]
            rw [← Finset.prod_pow]
      _ = (((e : ℝ) / (e.totient : ℝ)) ^ 5) / (e : ℝ) := by
            rw [full_prime_factor_prod_eq_totient_ratio (show 0 < e by omega)]
            rw [← Nat.cast_prod, Nat.prod_primeFactors_of_squarefree hsq]
  · rw [if_neg hsupp]
    positivity

private lemma omegaCoeff_le_weakMertens_pow5_div
    (q e : ℕ) (he16 : 16 ≤ e) :
    omegaCoeff q e ≤
      ((weakMertensC * Real.log (Real.log (e : ℝ))) ^ 5) / (e : ℝ) := by
  have hbase := omegaCoeff_le_totient_ratio_pow5_div q e he16
  have hM := totientRatio_le_weakMertens (h := e) he16
  have hratio0 : 0 ≤ (e : ℝ) / (e.totient : ℝ) := by positivity
  have hM0 : 0 ≤ weakMertensC * Real.log (Real.log (e : ℝ)) := by
    have hll := one_le_log_log_nat_of_sixteen_le he16
    have hC : 0 ≤ weakMertensC := by
      unfold weakMertensC
      positivity
    positivity
  have hp :
      ((e : ℝ) / (e.totient : ℝ)) ^ 5 ≤
        (weakMertensC * Real.log (Real.log (e : ℝ))) ^ 5 := by
    exact pow_le_pow_left₀ hratio0 hM 5
  exact hbase.trans (div_le_div_of_nonneg_right hp (by positivity))

private lemma omegaCoeff_le_dyadic_majorant
    (q E e : ℕ) (hE16 : 16 ≤ E) (hEe : E < e) (he2E : e ≤ 2 * E) :
    omegaCoeff q e ≤
      ((weakMertensC * Real.log (Real.log ((2 * E : ℕ) : ℝ))) ^ 5) /
        (E : ℝ) := by
  have he16 : 16 ≤ e := le_trans hE16 (Nat.le_of_lt hEe)
  have hbase := omegaCoeff_le_weakMertens_pow5_div q e he16
  have he0 : 0 < (e : ℝ) := by exact_mod_cast (show 0 < e by omega)
  have h2E0 : 0 < ((2 * E : ℕ) : ℝ) := by
    exact_mod_cast (show 0 < 2 * E by omega)
  have he2ER : (e : ℝ) ≤ ((2 * E : ℕ) : ℝ) := by exact_mod_cast he2E
  have hlog1 : Real.log (e : ℝ) ≤ Real.log ((2 * E : ℕ) : ℝ) :=
    Real.log_le_log he0 he2ER
  have hloge : 0 < Real.log (e : ℝ) := Real.log_pos (by exact_mod_cast (show 1 < e by omega))
  have hlog2 :
      Real.log (Real.log (e : ℝ)) ≤
        Real.log (Real.log ((2 * E : ℕ) : ℝ)) :=
    Real.log_le_log hloge hlog1
  have hC : 0 ≤ weakMertensC := by
    unfold weakMertensC
    positivity
  have hm :
      weakMertensC * Real.log (Real.log (e : ℝ)) ≤
        weakMertensC * Real.log (Real.log ((2 * E : ℕ) : ℝ)) :=
    mul_le_mul_of_nonneg_left hlog2 hC
  have hleft0 : 0 ≤ weakMertensC * Real.log (Real.log (e : ℝ)) := by
    have hll := one_le_log_log_nat_of_sixteen_le he16
    positivity
  have hp :
      (weakMertensC * Real.log (Real.log (e : ℝ))) ^ 5 ≤
        (weakMertensC * Real.log (Real.log ((2 * E : ℕ) : ℝ))) ^ 5 :=
    pow_le_pow_left₀ hleft0 hm 5
  have hright0 :
      0 ≤ weakMertensC * Real.log (Real.log ((2 * E : ℕ) : ℝ)) :=
    le_trans hleft0 hm
  have hnum0 :
      0 ≤ (weakMertensC * Real.log (Real.log ((2 * E : ℕ) : ℝ))) ^ 5 :=
    pow_nonneg hright0 5
  have hER : 0 < (E : ℝ) := by exact_mod_cast (show 0 < E by omega)
  have hEeR : (E : ℝ) ≤ (e : ℝ) := by exact_mod_cast (Nat.le_of_lt hEe)
  calc
    omegaCoeff q e ≤
        ((weakMertensC * Real.log (Real.log (e : ℝ))) ^ 5) / (e : ℝ) := hbase
    _ ≤ ((weakMertensC * Real.log (Real.log ((2 * E : ℕ) : ℝ))) ^ 5) /
        (e : ℝ) := div_le_div_of_nonneg_right hp he0.le
    _ ≤ ((weakMertensC * Real.log (Real.log ((2 * E : ℕ) : ℝ))) ^ 5) /
        (E : ℝ) := div_le_div_of_nonneg_left hnum0 hER hEeR






private noncomputable def omegaDivisorMass (q N : ℕ) : ℝ :=
  ∑ e ∈ N.divisors, omegaCoeff q e

private lemma omega_local_divisor_factor_le
    {p : ℕ} (hp5 : 5 ≤ p) :
    1 + (1 : ℝ) / ((p : ℝ) - 3) ≤
      ((p : ℝ) / ((p : ℝ) - 1)) ^ 2 := by
  have hp : (5 : ℝ) ≤ (p : ℝ) := by exact_mod_cast hp5
  have hp1 : 0 < (p : ℝ) - 1 := by linarith
  have hp3 : 0 < (p : ℝ) - 3 := by linarith
  rw [div_pow]
  rw [le_div_iff₀ (pow_pos hp1 2)]
  rw [show 1 + (1 : ℝ) / ((p : ℝ) - 3) =
      ((p : ℝ) - 2) / ((p : ℝ) - 3) by
    field_simp [ne_of_gt hp3]
    ring]
  rw [div_mul_eq_mul_div]
  rw [div_le_iff₀ hp3]
  nlinarith

private lemma omegaDivisorMass_eq_convolution
    (q N : ℕ) :
    omegaDivisorMass q N =
      ((omegaArithmetic q) * (↑zeta : ArithmeticFunction ℝ)) N := by
  unfold omegaDivisorMass
  symm
  simpa only [omegaArithmetic_apply] using
    (ArithmeticFunction.coe_mul_zeta_apply
      (f := omegaArithmetic q) (x := N))

private lemma omega_divisor_convolution_prime_pow
    (q : ℕ) {p i : ℕ} (hp : p.Prime) (hi : 1 ≤ i) :
    ((omegaArithmetic q) * (↑zeta : ArithmeticFunction ℝ)) (p ^ i) =
      1 + omegaCoeff q p := by
  rw [← omegaDivisorMass_eq_convolution q (p ^ i)]
  unfold omegaDivisorMass
  rw [Nat.divisors_prime_pow hp i]
  simp only [Finset.sum_map]
  change (∑ j ∈ Finset.range (i + 1), omegaCoeff q (p ^ j)) =
    1 + omegaCoeff q p
  rw [Finset.sum_range_succ']
  have hzero :
      (∑ j ∈ Finset.range i, omegaCoeff q (p ^ (j + 1))) =
        omegaCoeff q p := by
    have hsingle :
        (∑ j ∈ Finset.range i, omegaCoeff q (p ^ (j + 1))) =
          omegaCoeff q (p ^ (0 + 1)) := by
      apply Finset.sum_eq_single_of_mem 0
      · exact Finset.mem_range.mpr (Nat.zero_lt_of_lt hi)
      · intro j hj hj0
        have hsq : ¬ Squarefree (p ^ (j + 1)) := by
          rw [Nat.squarefree_pow_iff hp.ne_one (by omega)]
          intro hs
          exact hj0 (by omega)
        rw [omegaCoeff, if_neg (pow_ne_zero _ hp.ne_zero)]
        rw [if_neg (by
          intro hs
          exact hsq hs.1)]
    simpa using hsingle
  rw [hzero]
  have hone : omegaCoeff q 1 = 1 := by simp [omegaCoeff]
  simp only [pow_zero, hone]
  ring

private lemma omegaDivisorMass_eq_primeFactors_prod
    (q N : ℕ) (hN : N ≠ 0) :
    omegaDivisorMass q N =
      ∏ p ∈ N.primeFactors, (1 + omegaCoeff q p) := by
  rw [omegaDivisorMass_eq_convolution]
  let f : ArithmeticFunction ℝ :=
    (omegaArithmetic q) * (↑zeta : ArithmeticFunction ℝ)
  have hz : (↑zeta : ArithmeticFunction ℝ).IsMultiplicative := by
    constructor
    · simp
    · intro m n hcop
      by_cases hm : m = 0 <;> by_cases hn : n = 0 <;> simp [hm, hn]
  have hf : f.IsMultiplicative :=
    (omegaArithmetic_multiplicative q).mul hz
  rw [hf.multiplicative_factorization f hN]
  rw [Finsupp.prod]
  apply Finset.prod_congr
  · ext p
    simp [Nat.mem_primeFactors]
  · intro p hp
    have hpP : p.Prime := Nat.prime_of_mem_primeFactors hp
    have hfacpos : 1 ≤ N.factorization p := by
      have hs : p ∈ (N.factorization).support := by
        simpa only [Nat.support_factorization] using hp
      have hfacne : N.factorization p ≠ 0 := Finsupp.mem_support_iff.mp hs
      omega
    simpa [f] using
      omega_divisor_convolution_prime_pow q hpP hfacpos

private lemma omegaDivisorMass_le_totient_ratio_sq
    (q N : ℕ) (hN16 : 16 ≤ N) :
    omegaDivisorMass q N ≤
      ((N : ℝ) / (N.totient : ℝ)) ^ 2 := by
  have hN0 : N ≠ 0 := by omega
  rw [omegaDivisorMass_eq_primeFactors_prod q N hN0]
  have hprod :
      (∏ p ∈ N.primeFactors, (1 + omegaCoeff q p)) ≤
        ∏ p ∈ N.primeFactors,
          (((p : ℝ) / ((p : ℝ) - 1)) ^ 2) := by
    apply Finset.prod_le_prod₀
    · intro p hp
      have hpP := Nat.prime_of_mem_primeFactors hp
      have hp2 : 2 ≤ p := hpP.two_le
      have hpR : (2 : ℝ) ≤ p := by exact_mod_cast hp2
      exact add_nonneg zero_le_one (omegaCoeff_nonneg q p)
    · intro p hp
      have hpP := Nat.prime_of_mem_primeFactors hp
      by_cases hcop : p.Coprime (6 * q)
      · have hp5 := omega_rankin_five_le_of_prime_coprime_six hpP hcop
        rw [omegaCoeff, if_neg hpP.ne_zero, if_pos ⟨hpP.squarefree, hcop⟩]
        rw [hpP.primeFactors]
        simp only [Finset.prod_singleton]
        exact omega_local_divisor_factor_le hp5
      · rw [omegaCoeff, if_neg hpP.ne_zero]
        rw [if_neg (by exact fun hs => hcop hs.2)]
        have hp1 : 0 < (p : ℝ) - 1 := by
          have : (1 : ℝ) < p := by exact_mod_cast hpP.one_lt
          linarith
        have hp0 : 0 ≤ (p : ℝ) / ((p : ℝ) - 1) := by positivity
        have hone : 1 ≤ (p : ℝ) / ((p : ℝ) - 1) := by
          rw [le_div_iff₀ hp1]
          linarith
        nlinarith [sq_nonneg ((p : ℝ) / ((p : ℝ) - 1) - 1)]
  calc
    (∏ p ∈ N.primeFactors, (1 + omegaCoeff q p))
      ≤ ∏ p ∈ N.primeFactors,
          (((p : ℝ) / ((p : ℝ) - 1)) ^ 2) := hprod
    _ = (∏ p ∈ N.primeFactors,
          ((p : ℝ) / ((p : ℝ) - 1))) ^ 2 := by
        rw [← Finset.prod_pow]
    _ = ((N : ℝ) / (N.totient : ℝ)) ^ 2 := by
        rw [full_prime_factor_prod_eq_totient_ratio (by omega)]

private theorem omegaDivisorMass_le_weakMertens_sq
    (q N : ℕ) (hN16 : 16 ≤ N) :
    omegaDivisorMass q N ≤
      (weakMertensC * Real.log (Real.log (N : ℝ))) ^ 2 := by
  have hbase := omegaDivisorMass_le_totient_ratio_sq q N hN16
  have hM := totientRatio_le_weakMertens (h := N) hN16
  have hratio0 : 0 ≤ (N : ℝ) / (N.totient : ℝ) := by positivity
  have hM0 : 0 ≤ weakMertensC * Real.log (Real.log (N : ℝ)) := by
    have hll := one_le_log_log_nat_of_sixteen_le hN16
    have hC : 0 ≤ weakMertensC := by
      unfold weakMertensC
      positivity
    positivity
  exact hbase.trans (pow_le_pow_left₀ hratio0 hM 2)






private lemma loglog_pow5_le_sixteen_log_pow3
    {x : ℝ} (hx : Real.exp 1 ≤ x) :
    (Real.log (Real.log x)) ^ 5 ≤
      16 * (Real.log x) ^ 3 := by
  have hxpos : 0 < x := (Real.exp_pos 1).trans_le hx
  have hy1 : 1 ≤ Real.log x := by
    have h := Real.log_le_log (Real.exp_pos 1) hx
    simpa using h
  have hy0 : 0 ≤ Real.log x := le_trans (by norm_num) hy1
  have hll0 : 0 ≤ Real.log (Real.log x) :=
    Real.log_nonneg hy1
  have hhalf : (0 : ℝ) < 1 / 2 := by norm_num
  have hbase := Real.log_le_rpow_div hy0 hhalf
  have hsqrt :
      Real.log (Real.log x) ≤ 2 * Real.sqrt (Real.log x) := by
    rw [← Real.sqrt_eq_rpow] at hbase
    norm_num at hbase ⊢
    linarith
  have hsqrt0 : 0 ≤ Real.sqrt (Real.log x) := Real.sqrt_nonneg _
  have hsqroot : (Real.sqrt (Real.log x)) ^ 2 = Real.log x :=
    Real.sq_sqrt hy0
  have hll2 :
      (Real.log (Real.log x)) ^ 2 ≤ 4 * Real.log x := by
    nlinarith [sq_nonneg (2 * Real.sqrt (Real.log x) -
      Real.log (Real.log x))]
  have hlly :
      Real.log (Real.log x) ≤ Real.log x := by
    have hsub := Real.log_le_sub_one_of_pos (show 0 < Real.log x by linarith)
    linarith
  have hpow4 :
      (Real.log (Real.log x)) ^ 4 ≤
        16 * (Real.log x) ^ 2 := by
    calc
      (Real.log (Real.log x)) ^ 4 =
          ((Real.log (Real.log x)) ^ 2) ^ 2 := by ring
      _ ≤ (4 * Real.log x) ^ 2 := by
        exact pow_le_pow_left₀ (sq_nonneg _) hll2 2
      _ = 16 * (Real.log x) ^ 2 := by ring
  calc
    (Real.log (Real.log x)) ^ 5 =
        (Real.log (Real.log x)) ^ 4 *
          Real.log (Real.log x) := by ring
    _ ≤ (16 * (Real.log x) ^ 2) *
          Real.log (Real.log x) := by
      exact mul_le_mul_of_nonneg_right hpow4 hll0
    _ ≤ (16 * (Real.log x) ^ 2) * Real.log x := by
      exact mul_le_mul_of_nonneg_left hlly (by positivity)
    _ = 16 * (Real.log x) ^ 3 := by ring






private lemma omega_shell_count_le_three_log
    {X : ℕ} {T : ℝ}
    (hX : 1 ≤ X) (hXT : (X : ℝ) ≤ T)
    (hT : Real.exp 1 ≤ T) :
    ((Nat.log 2 X + 1 : ℕ) : ℝ) ≤ 3 * Real.log T := by
  have hXpos : 0 < (X : ℝ) := by exact_mod_cast (show 0 < X by omega)
  have hlogXT : Real.log (X : ℝ) ≤ Real.log T :=
    Real.log_le_log hXpos hXT
  have hlogT1 : 1 ≤ Real.log T := by
    have h := Real.log_le_log (Real.exp_pos 1) hT
    simpa using h
  have hnat := Real.natLog_le_logb X 2
  have hlog2 : (1 : ℝ) / 2 < Real.log 2 := by
    exact (by norm_num : (1 : ℝ) / 2 < 0.6931471803).trans Real.log_two_gt_d9
  have hlog2pos : 0 < Real.log 2 := lt_trans (by norm_num) hlog2
  have hlogX0 : 0 ≤ Real.log (X : ℝ) :=
    Real.log_nonneg (by exact_mod_cast hX)
  have hbase :
      (Nat.log 2 X : ℝ) ≤ 2 * Real.log (X : ℝ) := by
    calc
      (Nat.log 2 X : ℝ) ≤ Real.logb 2 X := hnat
      _ = Real.log (X : ℝ) / Real.log 2 := by rfl
      _ ≤ 2 * Real.log (X : ℝ) := by
        rw [div_le_iff₀ hlog2pos]
        nlinarith
  push_cast
  linarith







private lemma omega_near_small_dvd_round_natAbs
    {q e : ℕ} {T S : ℝ} {r : ℤ}
    (hq : 0 < q) (he : 1 ≤ e) (hS : 0 < S)
    (hsmall : ((Nat.lcm 6 q : ℕ) : ℝ) * (e : ℝ) < S)
    (hne : ¬ petermannOmegaAwayFromJump q T r S e) :
    e ∣ (round T).natAbs := by
  let L := Nat.lcm 6 q
  let phase : ℝ := T / (L : ℝ) / (e : ℝ) + (r : ℝ) / (L : ℝ)
  let k : ℤ := round phase
  let N : ℤ := (e : ℤ) * ((L : ℤ) * k - r)
  have hb : |T - (N : ℝ)| ≤ ((L : ℝ) * (e : ℝ)) / (2 * S) := by
    simpa [L, phase, k, N] using
      (omega_near_jump_integer_bound
        (q := q) (e := e) (T := T) (S := S) (r := r) hq he hne)
  have hhalf :
      ((L : ℝ) * (e : ℝ)) / (2 * S) < (1 : ℝ) / 2 := by
    have h2S : 0 < 2 * S := by positivity
    rw [div_lt_iff₀ h2S]
    have hs := hsmall
    nlinarith
  have hnear : |T - (N : ℝ)| < (1 : ℝ) / 2 :=
    lt_of_le_of_lt hb hhalf
  have habs := (abs_lt.mp hnear)
  have hround : round T = N := by
    rw [round_eq_iff]
    exact ⟨le_of_lt (by linarith [habs.2]), by linarith [habs.1]⟩
  have hdInt : (e : ℤ) ∣ round T := by
    rw [hround]
    dsimp [N]
    exact dvd_mul_right _ _
  have hdNat : (e : ℤ).natAbs ∣ (round T).natAbs :=
    Int.natAbs_dvd_natAbs.mpr hdInt
  simpa using hdNat


private noncomputable def petermannOmegaNearJumpSmallSet
    (q : ℕ) (T : ℝ) (r : ℤ) (X : ℕ) (S : ℝ) : Finset ℕ := by
  classical
  exact ((Finset.Icc 1 X).filter
    (fun e => ¬ petermannOmegaAwayFromJump q T r S e)).filter
      (fun e => ((Nat.lcm 6 q : ℕ) : ℝ) * (e : ℝ) < S)

private lemma round_natAbs_ne_zero_of_one_le
    {T : ℝ} (hT1 : 1 ≤ T) :
    (round T).natAbs ≠ 0 := by
  have hr : T - 1 / 2 < (round T : ℝ) := sub_half_lt_round T
  have hr0R : (0 : ℝ) < (round T : ℝ) := by linarith
  have hr0 : (0 : ℤ) < round T := by exact_mod_cast hr0R
  have hna : 0 < (round T).natAbs := Int.natAbs_pos.mpr (ne_of_gt hr0)
  omega

private lemma petermannOmegaNearJumpSmallMass_le_divisorMass
    (q : ℕ) (hq : 0 < q)
    (T S : ℝ) (hT1 : 1 ≤ T) (hS : 0 < S)
    (r : ℤ) (X : ℕ) :
    (∑ e ∈ petermannOmegaNearJumpSmallSet q T r X S,
      omegaCoeff q e) ≤
      omegaDivisorMass q (round T).natAbs := by
  classical
  have hN0 := round_natAbs_ne_zero_of_one_le hT1
  unfold omegaDivisorMass
  apply Finset.sum_le_sum_of_subset_of_nonneg
  · intro e he
    have heSmall := Finset.mem_filter.mp he
    have heNear := Finset.mem_filter.mp heSmall.1
    have heIcc : e ∈ Finset.Icc 1 X := heNear.1
    have hne : ¬ petermannOmegaAwayFromJump q T r S e := heNear.2
    have hsmall :
        ((Nat.lcm 6 q : ℕ) : ℝ) * (e : ℝ) < S := heSmall.2
    have he1 : 1 ≤ e := (Finset.mem_Icc.mp heIcc).1
    have hd := omega_near_small_dvd_round_natAbs
      (q := q) (e := e) (T := T) (S := S) (r := r)
      hq he1 hS hsmall hne
    exact Nat.mem_divisors.mpr ⟨hd, hN0⟩
  · intro e he _hne
    exact omegaCoeff_nonneg q e


private noncomputable def petermannOmegaNearJumpBlockMass
    (q E : ℕ) (T S : ℝ) (r : ℤ) : ℝ :=
  ∑ e ∈ petermannOmegaNearJumpBlock q E T S r, omegaCoeff q e

private lemma petermannOmegaNearJumpBlockMass_le
    (q E : ℕ) (hq : 0 < q) (hE16 : 16 ≤ E)
    (T S : ℝ) (hT : 0 < T) (hS : 0 < S) (r : ℤ) :
    petermannOmegaNearJumpBlockMass q E T S r ≤
      (T / (((Nat.lcm 6 q : ℕ) : ℝ) * (E : ℝ)) + 2) *
        (4 * ((Nat.lcm 6 q : ℕ) : ℝ) * (E : ℝ)^2 / (S * T) + 2) *
        (((weakMertensC *
          Real.log (Real.log ((2 * E : ℕ) : ℝ))) ^ 5) / (E : ℝ)) := by
  classical
  have hE : 0 < E := by omega
  have hcard := petermannOmegaNearJump_dyadic_card_le
    q E hq hE T S hT hS r
  have hpoint :
      ∀ e ∈ petermannOmegaNearJumpBlock q E T S r,
        omegaCoeff q e ≤
          ((weakMertensC *
            Real.log (Real.log ((2 * E : ℕ) : ℝ))) ^ 5) / (E : ℝ) := by
    intro e he
    have hePair := Finset.mem_filter.mp he
    have heI : e ∈ Finset.Ioc E (2 * E) := hePair.1
    have heBounds := Finset.mem_Ioc.mp heI
    exact omegaCoeff_le_dyadic_majorant q E e hE16 heBounds.1 heBounds.2
  unfold petermannOmegaNearJumpBlockMass
  calc
    (∑ e ∈ petermannOmegaNearJumpBlock q E T S r, omegaCoeff q e)
      ≤ ∑ _e ∈ petermannOmegaNearJumpBlock q E T S r,
          ((weakMertensC *
            Real.log (Real.log ((2 * E : ℕ) : ℝ))) ^ 5) / (E : ℝ) := by
            exact Finset.sum_le_sum hpoint
    _ = ((petermannOmegaNearJumpBlock q E T S r).card : ℝ) *
          (((weakMertensC *
            Real.log (Real.log ((2 * E : ℕ) : ℝ))) ^ 5) / (E : ℝ)) := by
          simp
    _ ≤
      (T / (((Nat.lcm 6 q : ℕ) : ℝ) * (E : ℝ)) + 2) *
        (4 * ((Nat.lcm 6 q : ℕ) : ℝ) * (E : ℝ)^2 / (S * T) + 2) *
        (((weakMertensC *
          Real.log (Real.log ((2 * E : ℕ) : ℝ))) ^ 5) / (E : ℝ)) := by
      have h2E16 : 16 ≤ 2 * E := by omega
      have hll := one_le_log_log_nat_of_sixteen_le h2E16
      have hC : 0 ≤ weakMertensC := by
        unfold weakMertensC
        positivity
      have hbase0 :
          0 ≤ weakMertensC *
            Real.log (Real.log ((2 * E : ℕ) : ℝ)) := by
        positivity
      have hM0 :
          0 ≤ ((weakMertensC *
            Real.log (Real.log ((2 * E : ℕ) : ℝ))) ^ 5) / (E : ℝ) := by
        exact div_nonneg (pow_nonneg hbase0 5) (by positivity)
      exact mul_le_mul_of_nonneg_right hcard hM0


private noncomputable def petermannOmegaNearJumpLargeSet
    (q : ℕ) (T : ℝ) (r : ℤ) (X : ℕ) (S : ℝ) : Finset ℕ := by
  classical
  exact ((Finset.Icc 1 X).filter
    (fun e => ¬ petermannOmegaAwayFromJump q T r S e)).filter
      (fun e => S ≤ ((Nat.lcm 6 q : ℕ) : ℝ) * (e : ℝ))

private lemma petermannOmegaNearJumpMass_eq_small_add_large
    (q : ℕ) (T : ℝ) (r : ℤ) (X : ℕ) (S : ℝ) :
    petermannOmegaNearJumpMass q T r X S =
      (∑ e ∈ petermannOmegaNearJumpSmallSet q T r X S, omegaCoeff q e) +
      (∑ e ∈ petermannOmegaNearJumpLargeSet q T r X S, omegaCoeff q e) := by
  classical
  unfold petermannOmegaNearJumpMass
    petermannOmegaNearJumpSmallSet petermannOmegaNearJumpLargeSet
  have hpart := Finset.sum_filter_add_sum_filter_not
    ((Finset.Icc 1 X).filter
      (fun e => ¬ petermannOmegaAwayFromJump q T r S e))
    (fun e => ((Nat.lcm 6 q : ℕ) : ℝ) * (e : ℝ) < S)
    (fun e => omegaCoeff q e)
  simpa [not_lt] using hpart.symm

private lemma omega_log_shell_subset_endpoint_union_block
    {q X e j : ℕ} {T S : ℝ} {r : ℤ}
    (he : e ∈ petermannOmegaNearJumpLargeSet q T r X S)
    (hj : Nat.log 2 e = j) :
    e ∈ ({2 ^ j} : Finset ℕ) ∪
      petermannOmegaNearJumpBlock q (2 ^ j) T S r := by
  classical
  have heLarge := Finset.mem_filter.mp he
  have heNear := Finset.mem_filter.mp heLarge.1
  have heIcc : e ∈ Finset.Icc 1 X := heNear.1
  have hne : ¬ petermannOmegaAwayFromJump q T r S e := heNear.2
  have he1 : 1 ≤ e := (Finset.mem_Icc.mp heIcc).1
  have he0 : e ≠ 0 := by omega
  have hlo : 2 ^ j ≤ e := by
    have hpow := Nat.pow_log_le_self 2 he0
    simpa [hj] using hpow
  have hhi : e < 2 ^ (j + 1) := by
    have hpow := Nat.lt_pow_succ_log_self Nat.one_lt_two e
    simpa [hj] using hpow
  by_cases heq : e = 2 ^ j
  · subst e
    simp
  · rw [Finset.mem_union]
    right
    apply Finset.mem_filter.mpr
    constructor
    · apply Finset.mem_Ioc.mpr
      constructor
      · omega
      · simpa [pow_succ, Nat.mul_comm] using Nat.le_of_lt hhi
    · exact hne

private lemma omega_large_log_shell_mass_le_endpoint_add_block
    (q X j : ℕ) (T S : ℝ) (r : ℤ) :
    (∑ e ∈ (petermannOmegaNearJumpLargeSet q T r X S).filter
        (fun e => Nat.log 2 e = j), omegaCoeff q e) ≤
      omegaCoeff q (2 ^ j) +
        petermannOmegaNearJumpBlockMass q (2 ^ j) T S r := by
  classical
  let F := (petermannOmegaNearJumpLargeSet q T r X S).filter
    (fun e => Nat.log 2 e = j)
  have hsub :
      F ⊆ ({2 ^ j} : Finset ℕ) ∪
        petermannOmegaNearJumpBlock q (2 ^ j) T S r := by
    intro e heF
    have hp := Finset.mem_filter.mp heF
    exact omega_log_shell_subset_endpoint_union_block hp.1 hp.2
  have hnonneg : ∀ e ∈
      ({2 ^ j} : Finset ℕ) ∪
        petermannOmegaNearJumpBlock q (2 ^ j) T S r,
      0 ≤ omegaCoeff q e := by
    intro e he
    exact omegaCoeff_nonneg q e
  calc
    (∑ e ∈ F, omegaCoeff q e)
      ≤ ∑ e ∈ ({2 ^ j} : Finset ℕ) ∪
          petermannOmegaNearJumpBlock q (2 ^ j) T S r,
          omegaCoeff q e :=
        Finset.sum_le_sum_of_subset_of_nonneg hsub
          (fun e he _ => hnonneg e he)
    _ ≤ (∑ e ∈ ({2 ^ j} : Finset ℕ), omegaCoeff q e) +
          (∑ e ∈ petermannOmegaNearJumpBlock q (2 ^ j) T S r,
            omegaCoeff q e) := by
        have hu := Finset.sum_union_inter
          (s₁ := ({2 ^ j} : Finset ℕ))
          (s₂ := petermannOmegaNearJumpBlock q (2 ^ j) T S r)
          (f := fun e => omegaCoeff q e)
        have hi0 :
            0 ≤ ∑ e ∈ ({2 ^ j} : Finset ℕ) ∩
              petermannOmegaNearJumpBlock q (2 ^ j) T S r,
              omegaCoeff q e := by
          exact Finset.sum_nonneg (fun e he => omegaCoeff_nonneg q e)
        linarith
    _ = omegaCoeff q (2 ^ j) +
          petermannOmegaNearJumpBlockMass q (2 ^ j) T S r := by
        simp [petermannOmegaNearJumpBlockMass, F]




private lemma weakMertens_loglog_pow5_le_Tmajorant
    {m : ℕ} {T : ℝ}
    (hm16 : 16 ≤ m) (hmT : (m : ℝ) ≤ 2 * T)
    (hT : Real.exp 1 ≤ T) :
    (weakMertensC * Real.log (Real.log (m : ℝ))) ^ 5 ≤
      (weakMertensC * Real.log (Real.log (2 * T))) ^ 5 := by
  have hm0 : 0 < (m : ℝ) := by exact_mod_cast (show 0 < m by omega)
  have hlogm0 : 0 < Real.log (m : ℝ) :=
    Real.log_pos (by exact_mod_cast (show 1 < m by omega))
  have hlogmono : Real.log (m : ℝ) ≤ Real.log (2 * T) :=
    Real.log_le_log hm0 hmT
  have hllmono :
      Real.log (Real.log (m : ℝ)) ≤
        Real.log (Real.log (2 * T)) :=
    Real.log_le_log hlogm0 hlogmono
  have hC : 0 ≤ weakMertensC := by
    unfold weakMertensC
    positivity
  have hleft0 : 0 ≤ weakMertensC * Real.log (Real.log (m : ℝ)) := by
    have hll := one_le_log_log_nat_of_sixteen_le hm16
    positivity
  have hmul := mul_le_mul_of_nonneg_left hllmono hC
  exact pow_le_pow_left₀ hleft0 hmul 5

private lemma omega_large_shell_mass_le_uniform
    (q E : ℕ) (hq : 0 < q) (hE16 : 16 ≤ E)
    (T S : ℝ) (hTexp : Real.exp 1 ≤ T) (hS : 0 < S) (r : ℤ)
    (hcut : S ≤ 2 * ((Nat.lcm 6 q : ℕ) : ℝ) * (E : ℝ))
    (hET : (E : ℝ) ≤ T) :
    omegaCoeff q E + petermannOmegaNearJumpBlockMass q E T S r ≤
      (weakMertensC * Real.log (Real.log (2 * T))) ^ 5 *
        (((4 : ℝ) + 18 * ((Nat.lcm 6 q : ℕ) : ℝ)) / S +
          8 * ((Nat.lcm 6 q : ℕ) : ℝ) * T / S^2) := by
  let L : ℝ := ((Nat.lcm 6 q : ℕ) : ℝ)
  let M : ℝ := (weakMertensC * Real.log (Real.log (2 * T))) ^ 5
  have hT : 0 < T := (Real.exp_pos 1).trans_le hTexp
  have hLnat : 0 < Nat.lcm 6 q := Nat.lcm_pos (by norm_num) hq
  have hL : 0 < L := by dsimp [L]; exact_mod_cast hLnat
  have hE : 0 < E := by omega
  have hER : 0 < (E : ℝ) := by exact_mod_cast hE
  have hlog2T1 : 1 ≤ Real.log (2 * T) := by
    have hTle : Real.exp 1 ≤ 2 * T := by linarith
    have h := Real.log_le_log (Real.exp_pos 1) hTle
    simpa using h
  have hll2T0 : 0 ≤ Real.log (Real.log (2 * T)) :=
    Real.log_nonneg hlog2T1
  have hC0 : 0 ≤ weakMertensC := by
    unfold weakMertensC
    positivity
  have hM0 : 0 ≤ M := by
    dsimp [M]
    exact pow_nonneg (mul_nonneg hC0 hll2T0) 5
  have h2ET : (((2 * E : ℕ) : ℝ)) ≤ 2 * T := by
    push_cast
    linarith
  have hME :
      (weakMertensC * Real.log (Real.log (E : ℝ))) ^ 5 ≤ M := by
    dsimp [M]
    exact weakMertens_loglog_pow5_le_Tmajorant hE16 (by linarith) hTexp
  have hM2E :
      (weakMertensC * Real.log (Real.log ((2 * E : ℕ) : ℝ))) ^ 5 ≤ M := by
    dsimp [M]
    exact weakMertens_loglog_pow5_le_Tmajorant (by omega) h2ET hTexp
  have hend0 := omegaCoeff_le_weakMertens_pow5_div q E hE16
  have hend : omegaCoeff q E ≤ M / (E : ℝ) :=
    hend0.trans (div_le_div_of_nonneg_right hME hER.le)
  have hblock0 := petermannOmegaNearJumpBlockMass_le
    q E hq hE16 T S hT hS r
  have hA0 : 0 ≤ T / (L * (E : ℝ)) + 2 := by positivity
  have hB0 : 0 ≤ 4 * L * (E : ℝ)^2 / (S * T) + 2 := by positivity
  have hblock :
      petermannOmegaNearJumpBlockMass q E T S r ≤
        (T / (L * (E : ℝ)) + 2) *
          (4 * L * (E : ℝ)^2 / (S * T) + 2) *
          (M / (E : ℝ)) := by
    refine hblock0.trans ?_
    exact mul_le_mul_of_nonneg_left
      (div_le_div_of_nonneg_right hM2E hER.le)
      (mul_nonneg hA0 hB0)
  have hEinv : 1 / (E : ℝ) ≤ 2 * L / S := by
    rw [div_eq_mul_inv]
    have hSE : S / (2 * L) ≤ (E : ℝ) := by
      rw [div_le_iff₀ (by positivity : 0 < 2 * L)]
      simpa [mul_assoc, mul_left_comm, mul_comm] using hcut
    have hden : 0 < S / (2 * L) := by positivity
    have hi := one_div_le_one_div_of_le hden hSE
    calc
      1 / (E : ℝ) ≤ 1 / (S / (2 * L)) := hi
      _ = 2 * L / S := by field_simp [ne_of_gt hS, ne_of_gt hL]
  have hEinv2 : 1 / ((E : ℝ)^2) ≤ 4 * L^2 / S^2 := by
    have hi0 : 0 ≤ 1 / (E : ℝ) := by positivity
    have hp := pow_le_pow_left₀ hi0 hEinv 2
    calc
      1 / ((E : ℝ)^2) = (1 / (E : ℝ))^2 := by field_simp [ne_of_gt hER]
      _ ≤ (2 * L / S)^2 := hp
      _ = 4 * L^2 / S^2 := by ring
  have hEoverT : (E : ℝ) / T ≤ 1 := by
    rw [div_le_one hT]
    exact hET
  have hblockUniform :
      (T / (L * (E : ℝ)) + 2) *
          (4 * L * (E : ℝ)^2 / (S * T) + 2) *
          (M / (E : ℝ)) ≤
        M * (((4 : ℝ) + 16 * L) / S + 8 * L * T / S^2) := by
    have hid :
        (T / (L * (E : ℝ)) + 2) *
            (4 * L * (E : ℝ)^2 / (S * T) + 2) *
            (M / (E : ℝ)) =
          M * (4 / S + 2 * T / L * (1 / ((E : ℝ)^2)) +
            8 * L / S * ((E : ℝ) / T) + 4 * (1 / (E : ℝ))) := by
      field_simp [ne_of_gt hL, ne_of_gt hER, ne_of_gt hS, ne_of_gt hT]
      ring
    rw [hid]
    apply mul_le_mul_of_nonneg_left _ hM0
    have hterm2 :
        2 * T / L * (1 / ((E : ℝ)^2)) ≤ 8 * L * T / S^2 := by
      have hc : 0 ≤ 2 * T / L := by positivity
      calc
        2 * T / L * (1 / ((E : ℝ)^2))
            ≤ 2 * T / L * (4 * L^2 / S^2) :=
          mul_le_mul_of_nonneg_left hEinv2 hc
        _ = 8 * L * T / S^2 := by field_simp [ne_of_gt hL, ne_of_gt hS]; ring
    have hterm3 :
        8 * L / S * ((E : ℝ) / T) ≤ 8 * L / S := by
      exact mul_le_of_le_one_right (by positivity) hEoverT
    have hterm4 : 4 * (1 / (E : ℝ)) ≤ 8 * L / S := by
      have hh := mul_le_mul_of_nonneg_left hEinv (show 0 ≤ (4 : ℝ) by norm_num)
      convert hh using 1 <;> ring
    have htarget :
        ((4 : ℝ) + 16 * L) / S + 8 * L * T / S^2 =
          4 / S + 8 * L / S + 8 * L / S + 8 * L * T / S^2 := by
      ring
    rw [htarget]
    linarith
  have hendUniform : M / (E : ℝ) ≤ M * (2 * L / S) := by
    simpa [div_eq_mul_inv] using mul_le_mul_of_nonneg_left hEinv hM0
  calc
    omegaCoeff q E + petermannOmegaNearJumpBlockMass q E T S r
      ≤ M / (E : ℝ) +
        (T / (L * (E : ℝ)) + 2) *
          (4 * L * (E : ℝ)^2 / (S * T) + 2) *
          (M / (E : ℝ)) := add_le_add hend hblock
    _ ≤ M * (2 * L / S) +
        M * (((4 : ℝ) + 16 * L) / S + 8 * L * T / S^2) :=
      add_le_add hendUniform hblockUniform
    _ = M * (((4 : ℝ) + 18 * L) / S + 8 * L * T / S^2) := by ring
    _ = (weakMertensC * Real.log (Real.log (2 * T))) ^ 5 *
        (((4 : ℝ) + 18 * ((Nat.lcm 6 q : ℕ) : ℝ)) / S +
          8 * ((Nat.lcm 6 q : ℕ) : ℝ) * T / S^2) := by rfl


private noncomputable def omegaLargeShellIndexSet
    (q X : ℕ) (S : ℝ) : Finset ℕ :=
  (Finset.range (Nat.log 2 X + 1)).filter
    (fun j => 16 ≤ 2 ^ j ∧
      S ≤ 2 * ((Nat.lcm 6 q : ℕ) : ℝ) * ((2 ^ j : ℕ) : ℝ))

private lemma petermannOmegaNearJumpLargeMass_le_uniform
    (q : ℕ) (hq : 0 < q)
    (T S : ℝ) (hTexp : Real.exp 1 ≤ T) (hS : 0 < S)
    (hSbig : 32 * ((Nat.lcm 6 q : ℕ) : ℝ) ≤ S)
    (r : ℤ) (X : ℕ) (hX : 1 ≤ X) (hXT : (X : ℝ) ≤ T) :
    (∑ e ∈ petermannOmegaNearJumpLargeSet q T r X S, omegaCoeff q e) ≤
      3 * Real.log T *
        ((weakMertensC * Real.log (Real.log (2 * T))) ^ 5 *
          (((4 : ℝ) + 18 * ((Nat.lcm 6 q : ℕ) : ℝ)) / S +
            8 * ((Nat.lcm 6 q : ℕ) : ℝ) * T / S^2)) := by
  classical
  let F := petermannOmegaNearJumpLargeSet q T r X S
  let J := omegaLargeShellIndexSet q X S
  let U : ℝ :=
    (weakMertensC * Real.log (Real.log (2 * T))) ^ 5 *
      (((4 : ℝ) + 18 * ((Nat.lcm 6 q : ℕ) : ℝ)) / S +
        8 * ((Nat.lcm 6 q : ℕ) : ℝ) * T / S^2)
  have hT : 0 < T := (Real.exp_pos 1).trans_le hTexp
  have hLnat : 0 < Nat.lcm 6 q := Nat.lcm_pos (by norm_num) hq
  have hLR : 0 < (((Nat.lcm 6 q : ℕ) : ℝ)) := by exact_mod_cast hLnat
  have hmap :
      ∀ e ∈ F, Nat.log 2 e ∈ J := by
    intro e heF
    change e ∈ petermannOmegaNearJumpLargeSet q T r X S at heF
    unfold petermannOmegaNearJumpLargeSet at heF
    rw [Finset.mem_filter] at heF
    have heLarge := heF
    have heNear := Finset.mem_filter.mp heLarge.1
    have heIcc : e ∈ Finset.Icc 1 X := heNear.1
    have he1 : 1 ≤ e := (Finset.mem_Icc.mp heIcc).1
    have heX : e ≤ X := (Finset.mem_Icc.mp heIcc).2
    have hlarge : S ≤ ((Nat.lcm 6 q : ℕ) : ℝ) * (e : ℝ) := heLarge.2
    let j := Nat.log 2 e
    let E := 2 ^ j
    have he0 : e ≠ 0 := by omega
    have hElo : E ≤ e := by
      dsimp [E, j]
      exact Nat.pow_log_le_self 2 he0
    have hEhi : e < 2 * E := by
      have hh := Nat.lt_pow_succ_log_self Nat.one_lt_two e
      dsimp [E, j]
      simpa [pow_succ, Nat.mul_comm] using hh
    have hcut : S ≤ 2 * ((Nat.lcm 6 q : ℕ) : ℝ) * (E : ℝ) := by
      have he2ER : (e : ℝ) ≤ 2 * (E : ℝ) := by exact_mod_cast (Nat.le_of_lt hEhi)
      have hm := mul_le_mul_of_nonneg_left he2ER hLR.le
      linarith
    have hE16 : 16 ≤ E := by
      have h32 :
          32 * ((Nat.lcm 6 q : ℕ) : ℝ) ≤
            2 * ((Nat.lcm 6 q : ℕ) : ℝ) * (E : ℝ) :=
        hSbig.trans hcut
      have hER16 : (16 : ℝ) ≤ (E : ℝ) := by
        nlinarith
      exact_mod_cast hER16
    have hjX : j < Nat.log 2 X + 1 := by
      have hlog := Nat.log_mono_right (b := 2) heX
      dsimp [j]
      omega
    apply Finset.mem_filter.mpr
    refine ⟨Finset.mem_range.mpr hjX, ?_⟩
    simpa [J, omegaLargeShellIndexSet, j, E] using And.intro hE16 hcut
  have hfiber := Finset.sum_fiberwise_of_maps_to hmap (fun e => omegaCoeff q e)
  have hshell :
      ∀ j ∈ J,
        (∑ e ∈ F with Nat.log 2 e = j, omegaCoeff q e) ≤ U := by
    intro j hj
    change j ∈ omegaLargeShellIndexSet q X S at hj
    unfold omegaLargeShellIndexSet at hj
    rw [Finset.mem_filter] at hj
    have hjData := hj
    have hjRange : j ∈ Finset.range (Nat.log 2 X + 1) := hjData.1
    have hE16 : 16 ≤ 2 ^ j := hjData.2.1
    have hcut := hjData.2.2
    have hjle : j ≤ Nat.log 2 X := by
      have := Finset.mem_range.mp hjRange
      omega
    have hpow : 2 ^ j ≤ 2 ^ Nat.log 2 X :=
      Nat.pow_le_pow_right (by norm_num) hjle
    have hX0 : X ≠ 0 := by omega
    have hEX : 2 ^ j ≤ X :=
      hpow.trans (Nat.pow_log_le_self 2 hX0)
    have hET : (((2 ^ j : ℕ) : ℝ)) ≤ T := by
      exact le_trans (by exact_mod_cast hEX) hXT
    have hshell0 := omega_large_log_shell_mass_le_endpoint_add_block
      q X j T S r
    have huniform := omega_large_shell_mass_le_uniform
      q (2 ^ j) hq hE16 T S hTexp hS r hcut hET
    exact hshell0.trans huniform
  have hsumJ :
      (∑ j ∈ J, ∑ e ∈ F with Nat.log 2 e = j, omegaCoeff q e) ≤
        (J.card : ℝ) * U := by
    calc
      (∑ j ∈ J, ∑ e ∈ F with Nat.log 2 e = j, omegaCoeff q e)
          ≤ ∑ _j ∈ J, U := by
        exact Finset.sum_le_sum hshell
      _ = (J.card : ℝ) * U := by simp
  have hJcardNat : J.card ≤ Nat.log 2 X + 1 := by
    have hsub : J ⊆ Finset.range (Nat.log 2 X + 1) := by
      intro j hj
      change j ∈ omegaLargeShellIndexSet q X S at hj
      unfold omegaLargeShellIndexSet at hj
      rw [Finset.mem_filter] at hj
      exact hj.1
    simpa using Finset.card_le_card hsub
  have hJcard : (J.card : ℝ) ≤ 3 * Real.log T := by
    have hcast : (J.card : ℝ) ≤ ((Nat.log 2 X + 1 : ℕ) : ℝ) := by exact_mod_cast hJcardNat
    exact hcast.trans (omega_shell_count_le_three_log hX hXT hTexp)
  have hlog2T1 : 1 ≤ Real.log (2 * T) := by
    have h2T : Real.exp 1 ≤ 2 * T := by linarith
    have h := Real.log_le_log (Real.exp_pos 1) h2T
    simpa using h
  have hC0 : 0 ≤ weakMertensC := by unfold weakMertensC; positivity
  have hU0 : 0 ≤ U := by
    dsimp [U]
    have hll0 : 0 ≤ Real.log (Real.log (2 * T)) := Real.log_nonneg hlog2T1
    positivity
  have hsum : (∑ e ∈ F, omegaCoeff q e) ≤ (J.card : ℝ) * U := by
    rw [← hfiber]
    exact hsumJ
  calc
    (∑ e ∈ petermannOmegaNearJumpLargeSet q T r X S, omegaCoeff q e)
      = ∑ e ∈ F, omegaCoeff q e := by rfl
    _ ≤ (J.card : ℝ) * U := hsum
    _ ≤ (3 * Real.log T) * U := mul_le_mul_of_nonneg_right hJcard hU0
    _ = 3 * Real.log T *
        ((weakMertensC * Real.log (Real.log (2 * T))) ^ 5 *
          (((4 : ℝ) + 18 * ((Nat.lcm 6 q : ℕ) : ℝ)) / S +
            8 * ((Nat.lcm 6 q : ℕ) : ℝ) * T / S^2)) := by rfl


private lemma petermannOmegaNearJumpLargeMass_canonical_le
    (q : ℕ) (hq : 0 < q)
    (T : ℝ) (hTexp : Real.exp 1 ≤ T)
    (hSbig :
      32 * ((Nat.lcm 6 q : ℕ) : ℝ) ≤
        Real.sqrt T * (Real.log (2 * T))^2)
    (r : ℤ) (X : ℕ) (hX : 1 ≤ X) (hXT : (X : ℝ) ≤ T) :
    (∑ e ∈ petermannOmegaNearJumpLargeSet q T r X
        (Real.sqrt T * (Real.log (2 * T))^2), omegaCoeff q e) ≤
      96 * weakMertensC^5 *
          (4 + 18 * ((Nat.lcm 6 q : ℕ) : ℝ)) *
          (Real.log T)^2 / Real.sqrt T +
        384 * weakMertensC^5 * ((Nat.lcm 6 q : ℕ) : ℝ) := by
  let L : ℝ := ((Nat.lcm 6 q : ℕ) : ℝ)
  let l : ℝ := Real.log T
  let l2 : ℝ := Real.log (2 * T)
  let S : ℝ := Real.sqrt T * l2^2
  have hT : 0 < T := (Real.exp_pos 1).trans_le hTexp
  have hT0 : 0 ≤ T := hT.le
  have hl1 : 1 ≤ l := by
    dsimp [l]
    have h := Real.log_le_log (Real.exp_pos 1) hTexp
    simpa using h
  have hl0 : 0 ≤ l := le_trans (by norm_num) hl1
  have hl20 : 0 < l2 := by
    dsimp [l2]
    exact Real.log_pos (by nlinarith [Real.exp_one_gt_d9])
  have hS : 0 < S := by
    dsimp [S]
    exact mul_pos (Real.sqrt_pos.2 hT) (sq_pos_of_pos hl20)
  have hlarge := petermannOmegaNearJumpLargeMass_le_uniform
    q hq T S hTexp hS (by simpa [S, L] using hSbig) r X hX hXT
  have hx2 : Real.exp 1 ≤ 2 * T := by linarith
  have hMraw := loglog_pow5_le_sixteen_log_pow3 hx2
  have hC0 : 0 ≤ weakMertensC := by unfold weakMertensC; positivity
  have hC5 : 0 ≤ weakMertensC^5 := pow_nonneg hC0 5
  have hM :
      (weakMertensC * Real.log (Real.log (2 * T))) ^ 5 ≤
        16 * weakMertensC^5 * l2^3 := by
    calc
      (weakMertensC * Real.log (Real.log (2 * T))) ^ 5 =
          weakMertensC^5 * (Real.log (Real.log (2 * T)))^5 := by ring
      _ ≤ weakMertensC^5 * (16 * (Real.log (2 * T))^3) :=
        mul_le_mul_of_nonneg_left hMraw hC5
      _ = 16 * weakMertensC^5 * l2^3 := by simp [l2]; ring
  have hl2_le : l2 ≤ 2 * l := by
    have hlogmul : Real.log (2 * T) = Real.log 2 + Real.log T := by
      rw [Real.log_mul (by norm_num : (2 : ℝ) ≠ 0) (ne_of_gt hT)]
    have hlog2le : Real.log 2 ≤ l := by
      have hlog2lt1 : Real.log 2 < 1 := Real.log_two_lt_d9.trans (by norm_num)
      linarith
    dsimp [l2, l]
    rw [hlogmul]
    linarith
  have hl_le_l2 : l ≤ l2 := by
    dsimp [l, l2]
    exact Real.log_le_log hT (by linarith)
  have hsqrtpos : 0 < Real.sqrt T := Real.sqrt_pos.2 hT
  have hSsq : S^2 = T * l2^4 := by
    dsimp [S]
    rw [mul_pow, Real.sq_sqrt hT0]
    ring
  have hbracket0 :
      0 ≤ ((4 : ℝ) + 18 * L) / S + 8 * L * T / S^2 := by
    have hL : 0 ≤ L := by dsimp [L]; positivity
    positivity
  have hlarge' :
      (∑ e ∈ petermannOmegaNearJumpLargeSet q T r X S, omegaCoeff q e) ≤
        3 * l *
          ((16 * weakMertensC^5 * l2^3) *
            (((4 : ℝ) + 18 * L) / S + 8 * L * T / S^2)) := by
    calc
      (∑ e ∈ petermannOmegaNearJumpLargeSet q T r X S, omegaCoeff q e)
          ≤ 3 * l *
            ((weakMertensC * Real.log (Real.log (2 * T))) ^ 5 *
              (((4 : ℝ) + 18 * L) / S + 8 * L * T / S^2)) := by
            simpa [l, L] using hlarge
      _ ≤ 3 * l *
            ((16 * weakMertensC^5 * l2^3) *
              (((4 : ℝ) + 18 * L) / S + 8 * L * T / S^2)) := by
            exact mul_le_mul_of_nonneg_left
              (mul_le_mul_of_nonneg_right hM hbracket0)
              (mul_nonneg (by norm_num) hl0)
  have hfirst :
      3 * l * (16 * weakMertensC^5 * l2^3) *
          (((4 : ℝ) + 18 * L) / S) ≤
        96 * weakMertensC^5 * (4 + 18 * L) * l^2 /
          Real.sqrt T := by
    have hcoef0 :
        0 ≤ 48 * weakMertensC^5 * (4 + 18 * L) * l / Real.sqrt T := by
      dsimp [L]
      positivity
    have hm := mul_le_mul_of_nonneg_left hl2_le hcoef0
    dsimp [S]
    convert hm using 1 <;> field_simp [ne_of_gt hsqrtpos, ne_of_gt hl20] <;> ring
  have hsecond :
      3 * l * (16 * weakMertensC^5 * l2^3) *
          (8 * L * T / S^2) ≤
        384 * weakMertensC^5 * L := by
    rw [hSsq]
    have hL0 : 0 ≤ L := by dsimp [L]; positivity
    have hcoef0 : 0 ≤ 384 * weakMertensC^5 * L := by positivity
    have hratio : l / l2 ≤ 1 := by
      rw [div_le_one hl20]
      exact hl_le_l2
    have hTne : T ≠ 0 := ne_of_gt hT
    have hl2ne : l2 ≠ 0 := ne_of_gt hl20
    field_simp [hTne, hl2ne]
    nlinarith
  calc
    (∑ e ∈ petermannOmegaNearJumpLargeSet q T r X
        (Real.sqrt T * (Real.log (2 * T))^2), omegaCoeff q e)
      = ∑ e ∈ petermannOmegaNearJumpLargeSet q T r X S, omegaCoeff q e := by rfl
    _ ≤ 3 * l *
          ((16 * weakMertensC^5 * l2^3) *
            (((4 : ℝ) + 18 * L) / S + 8 * L * T / S^2)) := hlarge'
    _ =
        3 * l * (16 * weakMertensC^5 * l2^3) *
            (((4 : ℝ) + 18 * L) / S) +
          3 * l * (16 * weakMertensC^5 * l2^3) *
            (8 * L * T / S^2) := by ring
    _ ≤ 96 * weakMertensC^5 * (4 + 18 * L) * l^2 /
          Real.sqrt T + 384 * weakMertensC^5 * L :=
      add_le_add hfirst hsecond
    _ = 96 * weakMertensC^5 *
          (4 + 18 * ((Nat.lcm 6 q : ℕ) : ℝ)) *
          (Real.log T)^2 / Real.sqrt T +
        384 * weakMertensC^5 * ((Nat.lcm 6 q : ℕ) : ℝ) := by rfl




private lemma loglog_sq_le_sixteen_sqrt_log_local
    {x : ℝ} (hx : Real.exp 1 ≤ x) :
    (Real.log (Real.log x)) ^ 2 ≤
      16 * Real.sqrt (Real.log x) := by
  have hy1 : 1 ≤ Real.log x := by
    have h := Real.log_le_log (Real.exp_pos 1) hx
    simpa using h
  have hy0 : 0 ≤ Real.log x := le_trans (by norm_num) hy1
  have heps : (0 : ℝ) < 1 / 4 := by norm_num
  have hb := Real.log_le_rpow_div hy0 heps
  have hb' :
      Real.log (Real.log x) ≤ 4 * (Real.log x) ^ ((1 : ℝ) / 4) := by
    norm_num at hb ⊢
    linarith
  have hrpow :
      ((Real.log x) ^ ((1 : ℝ) / 4)) ^ 2 =
        Real.sqrt (Real.log x) := by
    rw [← Real.rpow_natCast]
    rw [← Real.rpow_mul hy0]
    norm_num
    exact (Real.sqrt_eq_rpow _).symm
  have hll0 : 0 ≤ Real.log (Real.log x) := Real.log_nonneg hy1
  have hp := pow_le_pow_left₀ hll0 hb' 2
  calc
    (Real.log (Real.log x)) ^ 2
        ≤ (4 * (Real.log x) ^ ((1 : ℝ) / 4)) ^ 2 := hp
    _ = 16 * Real.sqrt (Real.log x) := by
      rw [mul_pow, hrpow]
      norm_num

private lemma weakMertens_loglog_pow2_le_Tmajorant
    {m : ℕ} {T : ℝ}
    (hm16 : 16 ≤ m) (hmT : (m : ℝ) ≤ 2 * T)
    (hT : Real.exp 1 ≤ T) :
    (weakMertensC * Real.log (Real.log (m : ℝ))) ^ 2 ≤
      (weakMertensC * Real.log (Real.log (2 * T))) ^ 2 := by
  have hm0 : 0 < (m : ℝ) := by exact_mod_cast (show 0 < m by omega)
  have hlogm0 : 0 < Real.log (m : ℝ) :=
    Real.log_pos (by exact_mod_cast (show 1 < m by omega))
  have hlogmono : Real.log (m : ℝ) ≤ Real.log (2 * T) :=
    Real.log_le_log hm0 hmT
  have hllmono :
      Real.log (Real.log (m : ℝ)) ≤ Real.log (Real.log (2 * T)) :=
    Real.log_le_log hlogm0 hlogmono
  have hC : 0 ≤ weakMertensC := by unfold weakMertensC; positivity
  have hleft0 : 0 ≤ weakMertensC * Real.log (Real.log (m : ℝ)) := by
    have hll := one_le_log_log_nat_of_sixteen_le hm16
    positivity
  exact pow_le_pow_left₀ hleft0 (mul_le_mul_of_nonneg_left hllmono hC) 2

private lemma petermannOmegaNearJumpSmallMass_canonical_le
    (q : ℕ) (hq : 0 < q)
    (T : ℝ) (hTexp : Real.exp 1 ≤ T) (hT17 : 17 ≤ T)
    (r : ℤ) (X : ℕ) :
    (∑ e ∈ petermannOmegaNearJumpSmallSet q T r X
        (Real.sqrt T * (Real.log (2 * T))^2), omegaCoeff q e) ≤
      32 * weakMertensC^2 * Real.sqrt (Real.log T) := by
  let S : ℝ := Real.sqrt T * (Real.log (2 * T))^2
  let N : ℕ := (round T).natAbs
  have hT : 0 < T := (Real.exp_pos 1).trans_le hTexp
  have hT1 : 1 ≤ T := by linarith
  have hlogT1 : 1 ≤ Real.log T := by
    have h := Real.log_le_log (Real.exp_pos 1) hTexp
    simpa using h
  have hS : 0 < S := by
    dsimp [S]
    have hl2 : 0 < Real.log (2 * T) := Real.log_pos (by linarith)
    positivity
  have hsmall := petermannOmegaNearJumpSmallMass_le_divisorMass
    q hq T S hT1 hS r X
  have hrlo : T - 1 / 2 < (round T : ℝ) := sub_half_lt_round T
  have hrposR : 0 < (round T : ℝ) := by linarith
  have hrpos : 0 < round T := by exact_mod_cast hrposR
  have hNcastInt : (N : ℤ) = round T := by
    dsimp [N]
    exact Int.natAbs_of_nonneg (le_of_lt hrpos)
  have hNcast : (N : ℝ) = (round T : ℝ) := by
    exact_mod_cast hNcastInt
  have hN16 : 16 ≤ N := by
    have hNR : (16 : ℝ) ≤ (N : ℝ) := by rw [hNcast]; linarith
    exact_mod_cast hNR
  have hrhi : (round T : ℝ) ≤ T + 1 / 2 := round_le_add_half T
  have hN2T : (N : ℝ) ≤ 2 * T := by
    rw [hNcast]
    linarith
  have hdiv := omegaDivisorMass_le_weakMertens_sq q N hN16
  have hmono := weakMertens_loglog_pow2_le_Tmajorant hN16 hN2T hTexp
  have hx2 : Real.exp 1 ≤ 2 * T := by linarith
  have hllsq := loglog_sq_le_sixteen_sqrt_log_local hx2
  have hC2 : 0 ≤ weakMertensC^2 := sq_nonneg _
  have hmass : omegaDivisorMass q N ≤
      16 * weakMertensC^2 * Real.sqrt (Real.log (2 * T)) := by
    calc
      omegaDivisorMass q N
        ≤ (weakMertensC * Real.log (Real.log (N : ℝ))) ^ 2 := hdiv
      _ ≤ (weakMertensC * Real.log (Real.log (2 * T))) ^ 2 := hmono
      _ = weakMertensC^2 * (Real.log (Real.log (2 * T)))^2 := by ring
      _ ≤ weakMertensC^2 * (16 * Real.sqrt (Real.log (2 * T))) :=
        mul_le_mul_of_nonneg_left hllsq hC2
      _ = 16 * weakMertensC^2 * Real.sqrt (Real.log (2 * T)) := by ring
  have hl2_le : Real.log (2 * T) ≤ 2 * Real.log T := by
    have hlogmul : Real.log (2 * T) = Real.log 2 + Real.log T := by
      rw [Real.log_mul (by norm_num : (2 : ℝ) ≠ 0) (ne_of_gt hT)]
    have hlog2lt1 : Real.log 2 < 1 := Real.log_two_lt_d9.trans (by norm_num)
    rw [hlogmul]
    linarith
  have hsqrtcomp :
      Real.sqrt (Real.log (2 * T)) ≤ 2 * Real.sqrt (Real.log T) := by
    rw [Real.sqrt_le_iff]
    constructor
    · positivity
    · have hsqrtSq := Real.sq_sqrt (show 0 ≤ Real.log T by linarith)
      nlinarith [hl2_le]
  calc
    (∑ e ∈ petermannOmegaNearJumpSmallSet q T r X
        (Real.sqrt T * (Real.log (2 * T))^2), omegaCoeff q e)
      = ∑ e ∈ petermannOmegaNearJumpSmallSet q T r X S, omegaCoeff q e := by rfl
    _ ≤ omegaDivisorMass q N := hsmall
    _ ≤ 16 * weakMertensC^2 * Real.sqrt (Real.log (2 * T)) := hmass
    _ ≤ 32 * weakMertensC^2 * Real.sqrt (Real.log T) := by
      have hc : 0 ≤ 16 * weakMertensC^2 := by positivity
      calc
        16 * weakMertensC^2 * Real.sqrt (Real.log (2 * T))
            ≤ 16 * weakMertensC^2 * (2 * Real.sqrt (Real.log T)) :=
          mul_le_mul_of_nonneg_left hsqrtcomp hc
        _ = 32 * weakMertensC^2 * Real.sqrt (Real.log T) := by ring


theorem petermannOmegaNearJumpMass_canonical_le
    (q : ℕ) (hq : 0 < q)
    (T : ℝ) (hTexp : Real.exp 1 ≤ T) (hT17 : 17 ≤ T)
    (hSbig :
      32 * ((Nat.lcm 6 q : ℕ) : ℝ) ≤
        Real.sqrt T * (Real.log (2 * T))^2)
    (r : ℤ) (X : ℕ) (hX : 1 ≤ X) (hXT : (X : ℝ) ≤ T) :
    petermannOmegaNearJumpMass
        q T r X (Real.sqrt T * (Real.log (2 * T))^2)
      ≤
      32 * weakMertensC^2 * Real.sqrt (Real.log T) +
        (96 * weakMertensC^5 *
            (4 + 18 * ((Nat.lcm 6 q : ℕ) : ℝ)) *
            (Real.log T)^2 / Real.sqrt T +
          384 * weakMertensC^5 * ((Nat.lcm 6 q : ℕ) : ℝ)) := by
  let S : ℝ := Real.sqrt T * (Real.log (2 * T))^2
  have hsmall :=
    petermannOmegaNearJumpSmallMass_canonical_le q hq T hTexp hT17 r X
  have hlarge :=
    petermannOmegaNearJumpLargeMass_canonical_le
      q hq T hTexp hSbig r X hX hXT
  have hsplit := petermannOmegaNearJumpMass_eq_small_add_large q T r X S
  rw [hsplit]
  simpa [S] using add_le_add hsmall hlarge

#print axioms petermannOmegaNearJumpMass_canonical_le

theorem petermannOmegaNearJumpMass_le_delta_log
    (q : ℕ) (hq : 0 < q)
    (delta : ℝ) (hdelta : 0 < delta) :
    ∃ T0 : ℝ,
      ∀ (r : ℤ) (T : ℝ) (X : ℕ),
        T0 ≤ T →
        Real.exp 1 ≤ T →
        1 ≤ X →
        (X : ℝ) ≤ T →
        petermannOmegaNearJumpMass
          q T r X
          (Real.sqrt T * (Real.log (2 * T))^2)
        ≤ delta * Real.log T := by
  let L : ℝ := ((Nat.lcm 6 q : ℕ) : ℝ)
  let C : ℝ := weakMertensC
  let B : ℝ :=
    1536 * C^5 * (4 + 18 * L) + 384 * C^5 * L
  let K : ℝ :=
    max 1 (max (4096 * C^4 / delta^2) (2 * B / delta))
  let T0 : ℝ := max 17 (max ((32 * L)^2) (Real.exp K))
  refine ⟨T0, ?_⟩
  intro r T X hT0 hTexp hX hXT
  let S : ℝ := Real.sqrt T * (Real.log (2 * T))^2
  have hT : 0 < T := (Real.exp_pos 1).trans_le hTexp
  have hlog1 : 1 ≤ Real.log T := by
    have h := Real.log_le_log (Real.exp_pos 1) hTexp
    simpa using h
  have hlog0 : 0 ≤ Real.log T := le_trans (by norm_num) hlog1
  have hT17 : (17 : ℝ) ≤ T := le_trans (le_max_left _ _) hT0
  have hTK : Real.exp K ≤ T := by
    have h1 : Real.exp K ≤ max ((32 * L)^2) (Real.exp K) := le_max_right _ _
    have h2 : max ((32 * L)^2) (Real.exp K) ≤ T0 := le_max_right _ _
    exact le_trans (le_trans h1 h2) hT0
  have hKlog : K ≤ Real.log T := by
    have h := Real.log_le_log (Real.exp_pos K) hTK
    simpa using h
  have hsmallThreshold : 4096 * C^4 / delta^2 ≤ Real.log T := by
    have hk : 4096 * C^4 / delta^2 ≤ K := by
      dsimp [K]
      exact le_trans (le_max_left _ _) (le_max_right _ _)
    exact hk.trans hKlog
  have hlargeThreshold : 2 * B / delta ≤ Real.log T := by
    have hk : 2 * B / delta ≤ K := by
      dsimp [K]
      exact le_trans (le_max_right _ _) (le_max_right _ _)
    exact hk.trans hKlog
  have hL0 : 0 ≤ L := by dsimp [L]; positivity
  have hC0 : 0 ≤ C := by dsimp [C, weakMertensC]; positivity
  have hB0 : 0 ≤ B := by dsimp [B]; positivity
  have hTLsq : (32 * L)^2 ≤ T := by
    have h1 : (32 * L)^2 ≤ max ((32 * L)^2) (Real.exp K) := le_max_left _ _
    have h2 : max ((32 * L)^2) (Real.exp K) ≤ T0 := le_max_right _ _
    exact le_trans (le_trans h1 h2) hT0
  have hsqrtL : 32 * L ≤ Real.sqrt T := by
    have hs := Real.sqrt_le_sqrt hTLsq
    have hnon : 0 ≤ 32 * L := by positivity
    simpa [Real.sqrt_sq_eq_abs, abs_of_nonneg hnon] using hs
  have hlog2T1 : 1 ≤ Real.log (2 * T) := by
    have h2T : Real.exp 1 ≤ 2 * T := by linarith
    have h := Real.log_le_log (Real.exp_pos 1) h2T
    simpa using h
  have hSbig :
      32 * ((Nat.lcm 6 q : ℕ) : ℝ) ≤
        Real.sqrt T * (Real.log (2 * T))^2 := by
    have hsq1 : (1 : ℝ) ≤ (Real.log (2 * T))^2 := by
      nlinarith [sq_nonneg (Real.log (2 * T) - 1)]
    have hsqrt0 : 0 ≤ Real.sqrt T := Real.sqrt_nonneg _
    have hm := mul_le_mul_of_nonneg_left hsq1 hsqrt0
    have hb : 32 * L ≤ Real.sqrt T := hsqrtL
    dsimp [L] at hb
    nlinarith
  have hsmall0 :=
    petermannOmegaNearJumpSmallMass_canonical_le q hq T hTexp hT17 r X
  have hdelta2 : 0 < delta^2 := sq_pos_of_pos hdelta
  have hthresholdMul : 4096 * C^4 ≤ delta^2 * Real.log T := by
    have hm := (div_le_iff₀ hdelta2).mp hsmallThreshold
    simpa [mul_comm] using hm
  have hsqrtlog0 : 0 ≤ Real.sqrt (Real.log T) := Real.sqrt_nonneg _
  have hsqrtlogSq : (Real.sqrt (Real.log T))^2 = Real.log T :=
    Real.sq_sqrt hlog0
  have hsmallDom :
      64 * C^2 * Real.sqrt (Real.log T) ≤ delta * Real.log T := by
    have hleft0 : 0 ≤ 64 * C^2 * Real.sqrt (Real.log T) := by positivity
    have hright0 : 0 ≤ delta * Real.log T := by positivity
    have hmul := mul_le_mul_of_nonneg_right hthresholdMul hlog0
    have hsq :
        (64 * C^2 * Real.sqrt (Real.log T))^2 ≤
          (delta * Real.log T)^2 := by
      calc
        (64 * C^2 * Real.sqrt (Real.log T))^2 =
            4096 * C^4 * Real.log T := by
          rw [mul_pow, mul_pow, hsqrtlogSq]
          ring
        _ ≤ delta^2 * (Real.log T)^2 := by
          nlinarith
        _ = (delta * Real.log T)^2 := by ring
    nlinarith [hsq]
  have hsmall :
      (∑ e ∈ petermannOmegaNearJumpSmallSet q T r X S, omegaCoeff q e) ≤
        (delta / 2) * Real.log T := by
    calc
      (∑ e ∈ petermannOmegaNearJumpSmallSet q T r X S, omegaCoeff q e)
          ≤ 32 * C^2 * Real.sqrt (Real.log T) := by
            simpa [C, S] using hsmall0
      _ ≤ (delta / 2) * Real.log T := by nlinarith [hsmallDom]
  have hlarge0 :=
    petermannOmegaNearJumpLargeMass_canonical_le q hq T hTexp hSbig r X hX hXT
  have hquarter : (0 : ℝ) < 1 / 4 := by norm_num
  have hlogRpow := Real.log_le_rpow_div hT.le hquarter
  have hlogQuart : Real.log T ≤ 4 * T ^ ((1 : ℝ) / 4) := by
    norm_num at hlogRpow ⊢
    linarith
  have hrpowSq : (T ^ ((1 : ℝ) / 4))^2 = Real.sqrt T := by
    rw [← Real.rpow_natCast]
    rw [← Real.rpow_mul hT.le]
    norm_num
    exact (Real.sqrt_eq_rpow _).symm
  have hlogSq : (Real.log T)^2 ≤ 16 * Real.sqrt T := by
    calc
      (Real.log T)^2 ≤ (4 * T ^ ((1 : ℝ) / 4))^2 :=
        pow_le_pow_left₀ hlog0 hlogQuart 2
      _ = 16 * Real.sqrt T := by
        rw [mul_pow, hrpowSq]
        norm_num
  have hsqrtTpos : 0 < Real.sqrt T := Real.sqrt_pos.2 hT
  have hfirstConst :
      96 * C^5 * (4 + 18 * L) * (Real.log T)^2 / Real.sqrt T ≤
        1536 * C^5 * (4 + 18 * L) := by
    have hcoef : 0 ≤ 96 * C^5 * (4 + 18 * L) := by positivity
    rw [div_le_iff₀ hsqrtTpos]
    calc
      96 * C^5 * (4 + 18 * L) * (Real.log T)^2
          ≤ 96 * C^5 * (4 + 18 * L) * (16 * Real.sqrt T) :=
        mul_le_mul_of_nonneg_left hlogSq hcoef
      _ = 1536 * C^5 * (4 + 18 * L) * Real.sqrt T := by ring
  have hlargeConst :
      96 * C^5 * (4 + 18 * L) * (Real.log T)^2 / Real.sqrt T +
        384 * C^5 * L ≤ B := by
    dsimp [B]
    exact add_le_add hfirstConst (le_refl _)
  have hBdelta : B ≤ (delta / 2) * Real.log T := by
    have hm := (div_le_iff₀ hdelta).mp hlargeThreshold
    nlinarith
  have hlarge :
      (∑ e ∈ petermannOmegaNearJumpLargeSet q T r X S, omegaCoeff q e) ≤
        (delta / 2) * Real.log T := by
    calc
      (∑ e ∈ petermannOmegaNearJumpLargeSet q T r X S, omegaCoeff q e)
          ≤ 96 * C^5 * (4 + 18 * L) * (Real.log T)^2 / Real.sqrt T +
            384 * C^5 * L := by
              simpa [C, L, S] using hlarge0
      _ ≤ B := hlargeConst
      _ ≤ (delta / 2) * Real.log T := hBdelta
  have hsplit := petermannOmegaNearJumpMass_eq_small_add_large q T r X S
  rw [hsplit]
  calc
    (∑ e ∈ petermannOmegaNearJumpSmallSet q T r X S, omegaCoeff q e) +
        (∑ e ∈ petermannOmegaNearJumpLargeSet q T r X S, omegaCoeff q e)
      ≤ (delta / 2) * Real.log T + (delta / 2) * Real.log T :=
        add_le_add hsmall hlarge
    _ = delta * Real.log T := by ring


end PaperB.Analytic
