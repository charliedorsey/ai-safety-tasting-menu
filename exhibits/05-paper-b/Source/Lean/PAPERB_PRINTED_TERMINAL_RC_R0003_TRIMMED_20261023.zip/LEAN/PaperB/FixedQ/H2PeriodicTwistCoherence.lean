import PaperB.FixedQ.H2PeriodicTwistInterface
import PaperB.FixedQ.H2BooleanDyadicSecondMomentAssembly
import PaperB.FixedQ.H2BooleanPeriodicWeightedET

open scoped BigOperators

namespace PaperB.FixedQ

lemma h2BooleanUnitsCRTEquiv_project_apply
    {T S : Finset ℕ}
    (hTS : T ⊆ S)
    (hPrimeS : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (p : T) :
    (h2BooleanUnitsCRTEquiv T
        (fun r hr => hPrimeS r (hTS hr))
        (zmodUnitProject (primeSetProduct_dvd_of_subset hTS) u)) p =
      (h2BooleanUnitsCRTEquiv S hPrimeS u) ⟨p.1, hTS p.2⟩ := by
  apply Units.ext
  rw [h2BooleanUnitsCRTEquiv_val]
  rw [h2BooleanUnitsCRTEquiv_val]
  rw [h2BooleanRingCRTEquiv_apply]
  rw [h2BooleanRingCRTEquiv_apply]
  change
    ZMod.castHom
        (by
          unfold primeSetProduct
          exact Finset.dvd_prod_of_mem (fun r => r) p.2)
        (ZMod p.1)
        (ZMod.castHom (primeSetProduct_dvd_of_subset hTS)
          (ZMod (primeSetProduct T)) (u : ZMod (primeSetProduct S))) =
      ZMod.castHom
        (by
          unfold primeSetProduct
          exact Finset.dvd_prod_of_mem (fun r => r) (hTS p.2))
        (ZMod p.1) (u : ZMod (primeSetProduct S))
  rw [← RingHom.comp_apply, ZMod.castHom_comp]

#print axioms h2BooleanUnitsCRTEquiv_project_apply

noncomputable def fixedQPeriodicPrimewiseLocalUnit
    (q H p : ℕ) (hA : activeHighPrime q p) :
    (ZMod p)ˣ :=
  if hpH : p ∣ H then 1
  else
    ZMod.unitOfCoprime H
      ((hA.1.coprime_iff_not_dvd.mpr hpH).symm) *
    (ZMod.unitOfCoprime (fixedQPeriod q)
      (activeHighPrime_coprime_fixedQPeriod hA).symm)⁻¹

noncomputable def fixedQPeriodicTotalTwist
    (q H : ℕ) (S : Finset ℕ) :
    (ZMod (primeSetProduct S))ˣ := by
  classical
  by_cases hA : ∀ p ∈ S, activeHighPrime q p
  · exact (h2BooleanUnitsCRTEquiv S
      (fun p hp => (hA p hp).1)).symm
      (fun p : S =>
        fixedQPeriodicPrimewiseLocalUnit q H p.1 (hA p.1 p.2))
  · exact 1

lemma fixedQPeriodicTotalTwist_project
    {q H : ℕ} {T S : Finset ℕ}
    (hTS : T ⊆ S)
    (hA : ∀ p ∈ S, activeHighPrime q p) :
    zmodUnitProject (primeSetProduct_dvd_of_subset hTS)
      (fixedQPeriodicTotalTwist q H S) =
      fixedQPeriodicTotalTwist q H T := by
  classical
  let hAT : ∀ p ∈ T, activeHighPrime q p := fun p hp => hA p (hTS hp)
  let hPrimeS : ∀ p ∈ S, p.Prime := fun p hp => (hA p hp).1
  let hPrimeT : ∀ p ∈ T, p.Prime := fun p hp => (hAT p hp).1
  apply (h2BooleanUnitsCRTEquiv T hPrimeT).injective
  ext p
  rw [h2BooleanUnitsCRTEquiv_project_apply hTS hPrimeS]
  unfold fixedQPeriodicTotalTwist
  rw [dif_pos hA]
  rw [dif_pos hAT]
  simp only [MulEquiv.apply_symm_apply]

#print axioms fixedQPeriodicTotalTwist_project

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma h2BooleanUnitsCRTEquiv_apply_eq_zmodUnitProject
    {S : Finset ℕ} (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ) (p : S) :
    (h2BooleanUnitsCRTEquiv S hPrime u) p =
      zmodUnitProject
        (by
          unfold primeSetProduct
          exact Finset.dvd_prod_of_mem (fun r => r) p.2) u := by
  apply Units.ext
  rw [h2BooleanUnitsCRTEquiv_val]
  rw [h2BooleanRingCRTEquiv_apply]
  rfl

lemma fixedQPeriodicTotalTwist_eq_periodic
    {q H : ℕ} {S : Finset ℕ}
    (hA : ∀ p ∈ S, activeHighPrime q p)
    (hOrd : S ∈ ordinaryTwoDimensionalSet H) :
    fixedQPeriodicTotalTwist q H S =
      fixedProductBooleanPeriodicTwist (fixedQPeriod q) H S
        (activePrimeSetProduct_coprime_fixedQPeriod hA).symm
        ((ordinary_primeSetProduct_coprime_height_iff
          (fun p hp => (hA p hp).1)).mp hOrd).symm := by
  classical
  let hPrime : ∀ p ∈ S, p.Prime := fun p hp => (hA p hp).1
  let hP : (fixedQPeriod q).Coprime (primeSetProduct S) :=
    (activePrimeSetProduct_coprime_fixedQPeriod hA).symm
  let hH : H.Coprime (primeSetProduct S) :=
    ((ordinary_primeSetProduct_coprime_height_iff hPrime).mp hOrd).symm
  apply (h2BooleanUnitsCRTEquiv S hPrime).injective
  ext p
  unfold fixedQPeriodicTotalTwist
  rw [dif_pos hA]
  simp only [MulEquiv.apply_symm_apply]
  rw [h2BooleanUnitsCRTEquiv_apply_eq_zmodUnitProject]
  unfold fixedQPeriodicPrimewiseLocalUnit
  rw [dif_neg ((ordinaryTwoDimensionalSet_iff.mp hOrd) p.1 p.2)]
  unfold fixedProductBooleanPeriodicTwist
  rw [map_mul, map_inv]
  rw [zmodUnitProject_unitOfCoprime, zmodUnitProject_unitOfCoprime]
  simp [mul_comm]

#print axioms h2BooleanUnitsCRTEquiv_apply_eq_zmodUnitProject
#print axioms fixedQPeriodicTotalTwist_eq_periodic

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma h2BooleanBlockCRTEquiv_fst_eq_zmodUnitProject_val
    (T R : Finset ℕ) (hdisj : Disjoint T R)
    (hPrimeT : ∀ p ∈ T, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (u : (ZMod (primeSetProduct (T ∪ R)))ˣ) :
    (h2BooleanBlockCRTEquiv T R hdisj hPrimeT hPrimeR
      (u : ZMod (primeSetProduct (T ∪ R)))).1 =
      ((zmodUnitProject
        (primeSetProduct_dvd_of_subset
          (Finset.subset_union_left : T ⊆ T ∪ R)) u :
        (ZMod (primeSetProduct T))ˣ) : ZMod (primeSetProduct T)) := by
  let hPrimeU : ∀ p ∈ T ∪ R, p.Prime := by
    intro p hp
    rcases Finset.mem_union.mp hp with hpT | hpR
    · exact hPrimeT p hpT
    · exact hPrimeR p hpR
  letI : NeZero (primeSetProduct (T ∪ R)) :=
    ⟨(primeSetProduct_pos hPrimeU).ne'⟩
  letI : NeZero (primeSetProduct T) :=
    ⟨(primeSetProduct_pos hPrimeT).ne'⟩
  conv_lhs =>
    rw [← ZMod.natCast_zmod_val
      (u : ZMod (primeSetProduct (T ∪ R)))]
  rw [h2BooleanBlockCRTEquiv_apply_natCast]
  change
    ((u : ZMod (primeSetProduct (T ∪ R))).val : ZMod (primeSetProduct T)) =
      ZMod.castHom
        (primeSetProduct_dvd_of_subset
          (Finset.subset_union_left : T ⊆ T ∪ R))
        (ZMod (primeSetProduct T))
        (u : ZMod (primeSetProduct (T ∪ R)))
  rw [ZMod.castHom_apply, ZMod.cast_eq_val]

lemma h2BooleanBlockLeftFrequency_natCast_mul_unit_eq_project
    (T R : Finset ℕ) (hdisj : Disjoint T R)
    (hPrimeT : ∀ p ∈ T, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (j : ℕ) (u : (ZMod (primeSetProduct (T ∪ R)))ˣ) :
    h2BooleanBlockLeftFrequency T R hdisj hPrimeT hPrimeR
        ((j : ZMod (primeSetProduct (T ∪ R))) *
          (u : ZMod (primeSetProduct (T ∪ R)))) =
      ((j : ZMod (primeSetProduct T)) *
        ((zmodUnitProject
          (primeSetProduct_dvd_of_subset
            (Finset.subset_union_left : T ⊆ T ∪ R)) u :
          (ZMod (primeSetProduct T))ˣ) :
            ZMod (primeSetProduct T))) *
        (((ZMod.unitOfCoprime (primeSetProduct R)
          (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR).symm)⁻¹ :
            (ZMod (primeSetProduct T))ˣ) :
              ZMod (primeSetProduct T)) := by
  letI : NeZero (primeSetProduct T) :=
    ⟨(primeSetProduct_pos hPrimeT).ne'⟩
  unfold h2BooleanBlockLeftFrequency
  rw [map_mul]
  rw [h2BooleanBlockCRTEquiv_apply_natCast]
  simp only [Prod.fst_mul, Prod.fst]
  rw [h2_crtLeftCoeff_eq_unit_inv
    (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR)]
  rw [h2BooleanBlockCRTEquiv_fst_eq_zmodUnitProject_val]
  ring

#print axioms h2BooleanBlockCRTEquiv_fst_eq_zmodUnitProject_val
#print axioms h2BooleanBlockLeftFrequency_natCast_mul_unit_eq_project

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem fixedQPeriodicTotalTwist_fiberCompatible
    (q H Y M j : ℕ) (T : Finset ℕ) :
    H2BooleanTwistFiberCompatible q Y M j T
      (fixedQPeriodicTotalTwist q H)
      (fixedQPeriodicTotalTwist q H T) := by
  intro S hS
  let R := S.filter (fun p => Y < p)
  have hA := h2BooleanDyadicSmoothFiber_active hS
  have hT := h2BooleanDyadicSmoothFiber_smooth_active hS
  have hR := h2BooleanDyadicSmoothFiber_rough_active hS
  have hdisj : Disjoint T R := h2BooleanDyadicSmoothFiber_disjoint hS
  have hPrimeT : ∀ p ∈ T, p.Prime := fun p hp => (hT p hp).1
  have hPrimeR : ∀ p ∈ R, p.Prime := fun p hp => (hR p hp).1
  have hpart : S = T ∪ R := h2BooleanDyadicSmoothFiber_partition hS
  have hRdef : R = S.filter (fun p => Y < p) := rfl
  clear_value R
  subst S
  have hproj :
      zmodUnitProject
        (primeSetProduct_dvd_of_subset
          (Finset.subset_union_left : T ⊆ T ∪ R))
        (fixedQPeriodicTotalTwist q H (T ∪ R)) =
      fixedQPeriodicTotalTwist q H T :=
    fixedQPeriodicTotalTwist_project
      (Finset.subset_union_left : T ⊆ T ∪ R) hA
  have hfreq :=
    h2BooleanBlockLeftFrequency_natCast_mul_unit_eq_project
      T R hdisj hPrimeT hPrimeR j
      (fixedQPeriodicTotalTwist q H (T ∪ R))
  rw [hproj] at hfreq
  have hblock := norm_sq_fixedProductBooleanFourierCoeff_block_le_left
    T R hdisj hPrimeT hPrimeR
    ((j : ZMod (primeSetProduct (T ∪ R))) *
      ((fixedQPeriodicTotalTwist q H (T ∪ R) :
        (ZMod (primeSetProduct (T ∪ R)))ˣ) :
          ZMod (primeSetProduct (T ∪ R))))
  rw [hfreq] at hblock
  unfold h2BooleanFourierNormSqTwisted
  rw [dif_pos hA]
  convert hblock using 1
  congr 4
  change
    ((primeSetProduct ((T ∪ R).filter (fun p => Y < p)) :
      ZMod (primeSetProduct T))⁻¹) =
    ((primeSetProduct R : ZMod (primeSetProduct T))⁻¹)
  rw [← hRdef]

theorem fixedQPeriodicTotalTwist_familyCompatible
    (q H Y M j : ℕ) :
    H2BooleanTwistFamilyCompatible q Y M j
      (fixedQPeriodicTotalTwist q H) := by
  intro T hT
  exact ⟨fixedQPeriodicTotalTwist q H T,
    fixedQPeriodicTotalTwist_fiberCompatible q H Y M j T⟩

#print axioms fixedQPeriodicTotalTwist_fiberCompatible
#print axioms fixedQPeriodicTotalTwist_familyCompatible

end PaperB.FixedQ
