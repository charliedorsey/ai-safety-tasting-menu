import PaperB.Analytic.ReciprocalFiniteOrderInterval

namespace PaperB.Analytic

open Real Finset
open scoped ComplexConjugate

lemma nat_Ioc_map_intCast (V B : ℕ) :
    (Finset.Ioc V B).map (Nat.castEmbedding : ℕ ↪ ℤ) =
      Finset.Ioc (V : ℤ) (B : ℤ) := by
  ext z
  constructor
  · intro hz
    rw [Finset.mem_map] at hz
    rcases hz with ⟨n, hn, rfl⟩
    have hni := Finset.mem_Ioc.mp hn
    apply Finset.mem_Ioc.mpr
    constructor
    · change (V : ℤ) < (n : ℤ)
      exact_mod_cast hni.1
    · change (n : ℤ) ≤ (B : ℤ)
      exact_mod_cast hni.2
  · intro hz
    have hzI := Finset.mem_Ioc.mp hz
    have hz0 : 0 ≤ z := by
      have hV0 : (0 : ℤ) ≤ (V : ℤ) := by exact_mod_cast Nat.zero_le V
      omega
    let n := z.toNat
    have hzn : (n : ℤ) = z := Int.toNat_of_nonneg hz0
    rw [Finset.mem_map]
    refine ⟨n, ?_, hzn⟩
    apply Finset.mem_Ioc.mpr
    constructor
    · have hVz : (V : ℤ) < (n : ℤ) := by simpa [hzn] using hzI.1
      exact_mod_cast hVz
    · have hzB : (n : ℤ) ≤ (B : ℤ) := by simpa [hzn] using hzI.2
      exact_mod_cast hzB

lemma sum_nat_Ioc_eq_int_Ioc
    (f : ℤ → ℂ) (V B : ℕ) :
    (∑ n ∈ Finset.Ioc V B, f (n : ℤ)) =
      ∑ z ∈ Finset.Ioc (V : ℤ) (B : ℤ), f z := by
  classical
  rw [← nat_Ioc_map_intCast V B, Finset.sum_map]
  simp

theorem reciprocalFiniteOrderNatIcc
    (k : ℕ) (hk : 2 ≤ k) :
    ∃ C : ℝ, 1 ≤ C ∧
      ∀ (A xi : ℝ) (V B : ℕ),
        0 < A → k ≤ V → V ≤ B → B ≤ 2 * V →
        let lam :=
          A * (k.factorial : ℝ) *
            (((2 * V + k : ℕ) : ℝ) ^ (k + 1))⁻¹
        ‖∑ n ∈ Finset.Icc V B,
            eR (A / (n : ℝ) + xi * (n : ℝ))‖
          ≤ 1 + C *
            (((B : ℝ) - (V : ℝ)) *
                lam ^ (1 / ((2 : ℝ) ^ k - 2))
              + ((B : ℝ) - (V : ℝ)) ^ (1 - 4 / (2 : ℝ) ^ k) *
                lam ^ (-(1 / ((2 : ℝ) ^ k - 2)))) := by
  obtain ⟨C, hC1, hC⟩ := reciprocalFiniteOrderInterval k hk
  refine ⟨C, hC1, ?_⟩
  intro A xi V B hA hkV hVB hB2
  dsimp
  have hVpos : 0 < V := lt_of_lt_of_le (by omega) hkV
  have hset : Finset.Icc V B = insert V (Finset.Ioc V B) := by
    ext n
    simp
    omega
  rw [hset, Finset.sum_insert]
  · calc
      ‖eR (A / (V : ℝ) + xi * (V : ℝ)) +
          ∑ n ∈ Finset.Ioc V B,
            eR (A / (n : ℝ) + xi * (n : ℝ))‖
        ≤ ‖eR (A / (V : ℝ) + xi * (V : ℝ))‖ +
            ‖∑ n ∈ Finset.Ioc V B,
              eR (A / (n : ℝ) + xi * (n : ℝ))‖ := norm_add_le _ _
      _ = 1 + ‖∑ n ∈ Finset.Ioc V B,
              eR (A / (n : ℝ) + xi * (n : ℝ))‖ := by
            rw [norm_eR]
      _ ≤ 1 + C *
            (((B : ℝ) - (V : ℝ)) *
                (A * (k.factorial : ℝ) *
                  (((2 * V + k : ℕ) : ℝ) ^ (k + 1))⁻¹) ^
                    (1 / ((2 : ℝ) ^ k - 2))
              + ((B : ℝ) - (V : ℝ)) ^ (1 - 4 / (2 : ℝ) ^ k) *
                (A * (k.factorial : ℝ) *
                  (((2 * V + k : ℕ) : ℝ) ^ (k + 1))⁻¹) ^
                    (-(1 / ((2 : ℝ) ^ k - 2)))) := by
            have hsum :
                (∑ n ∈ Finset.Ioc V B,
                  eR (A / (n : ℝ) + xi * (n : ℝ))) =
                  ∑ z ∈ Finset.Ioc (V : ℤ) (B : ℤ),
                    eR (A / (z : ℝ) + xi * (z : ℝ)) := by
              simpa using sum_nat_Ioc_eq_int_Ioc
                (fun z : ℤ => eR (A / (z : ℝ) + xi * (z : ℝ))) V B
            rw [hsum]
            simpa using hC A xi V (V : ℤ) (B : ℤ)
              hA hkV (by simp) (by exact_mod_cast hB2) (by exact_mod_cast hVB)
  · simp

#print axioms reciprocalFiniteOrderNatIcc

lemma norm_sum_eR_neg_nat (s : Finset ℕ) (a : ℕ → ℝ) :
    ‖∑ n ∈ s, eR (-(a n))‖ = ‖∑ n ∈ s, eR (a n)‖ := by
  have h : conj (∑ n ∈ s, eR (a n)) = ∑ n ∈ s, eR (-(a n)) := by
    rw [map_sum]
    exact Finset.sum_congr rfl (fun n _ => conj_eR (a n))
  rw [← h, RCLike.norm_conj]

theorem reciprocalFiniteOrderNatIcc_abs
    (k : ℕ) (hk : 2 ≤ k) :
    ∃ C : ℝ, 1 ≤ C ∧
      ∀ (A xi : ℝ) (V B : ℕ),
        A ≠ 0 → k ≤ V → V ≤ B → B ≤ 2 * V →
        let lam :=
          |A| * (k.factorial : ℝ) *
            (((2 * V + k : ℕ) : ℝ) ^ (k + 1))⁻¹
        ‖∑ n ∈ Finset.Icc V B,
            eR (A / (n : ℝ) + xi * (n : ℝ))‖
          ≤ 1 + C *
            (((B : ℝ) - (V : ℝ)) *
                lam ^ (1 / ((2 : ℝ) ^ k - 2))
              + ((B : ℝ) - (V : ℝ)) ^ (1 - 4 / (2 : ℝ) ^ k) *
                lam ^ (-(1 / ((2 : ℝ) ^ k - 2)))) := by
  obtain ⟨C, hC1, hC⟩ := reciprocalFiniteOrderNatIcc k hk
  refine ⟨C, hC1, ?_⟩
  intro A xi V B hA hkV hVB hB2
  dsimp
  by_cases hApos : 0 < A
  · simpa [abs_of_pos hApos] using
      hC A xi V B hApos hkV hVB hB2
  · have hAle : A ≤ 0 := le_of_not_gt hApos
    have hAlt : A < 0 := lt_of_le_of_ne hAle hA
    have hneg : 0 < -A := neg_pos.mpr hAlt
    have hbase := hC (-A) (-xi) V B hneg hkV hVB hB2
    have hnorm := norm_sum_eR_neg_nat (Finset.Icc V B)
      (fun n => (-A) / (n : ℝ) + (-xi) * (n : ℝ))
    have hnorm' :
        ‖∑ n ∈ Finset.Icc V B,
            eR (A / (n : ℝ) + xi * (n : ℝ))‖ =
          ‖∑ n ∈ Finset.Icc V B,
            eR ((-A) / (n : ℝ) + (-xi) * (n : ℝ))‖ := by
      simpa only [neg_div, neg_mul, neg_neg, neg_add_rev, add_comm] using hnorm
    rw [hnorm']
    simpa [abs_of_neg hAlt] using hbase

#print axioms reciprocalFiniteOrderNatIcc_abs

end PaperB.Analytic
