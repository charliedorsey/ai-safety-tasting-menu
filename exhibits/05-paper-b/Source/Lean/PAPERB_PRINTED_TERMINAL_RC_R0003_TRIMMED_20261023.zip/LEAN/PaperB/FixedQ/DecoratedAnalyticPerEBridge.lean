import PaperB.FixedQ.DecoratedTwoDimensionalBridge

open scoped BigOperators

namespace PaperB.FixedQ

theorem decoratedAnalyticPerE_eq_height_filter
    {q a h : ℕ} {e : Finset ℕ}
    (hAall : ∀ p ∈ e, activeHighPrime q p) :
    decoratedAnalyticPerE q a h e =
      ∑ e1 ∈ (((e.powerset.erase e).erase (heightPrimePart h e)).filter
        (fun e1 => heightPrimePart h e ⊆ e1)),
        decoratedAnalyticPairTerm q a h e e1 := by
  unfold decoratedAnalyticPerE
  rw [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro e1 he1
  by_cases hh : heightPrimePart h e ⊆ e1
  · simp [hh]
  · have he1ps : e1 ∈ e.powerset :=
      Finset.mem_of_mem_erase (Finset.mem_of_mem_erase he1)
    have he1sub : e1 ⊆ e := Finset.mem_powerset.mp he1ps
    have hmiss : ∃ p ∈ heightPrimePart h e, p ∉ e1 := by
      simpa [Finset.not_subset] using hh
    have hz := pairCoefficient_eq_zero_of_missing_height_prime
      he1sub hAall hmiss
    simp [hh, decoratedAnalyticPairTerm, hz]

theorem decoratedAnalytic_height_filter_sum_eq
    {q a h : ℕ} {e : Finset ℕ}
    (hAall : ∀ p ∈ e, activeHighPrime q p) :
    let d := heightPrimePart h e
    let n := e \ d
    let D := decoratedHeightProduct h e
    let H := decoratedReducedHeight h e
    (∑ e1 ∈ (((e.powerset.erase e).erase d).filter (fun e1 => d ⊆ e1)),
      decoratedAnalyticPairTerm q a h e e1) =
      ∑ A ∈ ((n.powerset.erase n).erase ∅),
        finiteVWeightReal h d * finiteOmegaWeightReal n *
          fixedProductPartitionDiscrepancy
            (fixedQLowWeight q (decoratedReducedAnchor q a D) H)
            H n A := by
  dsimp
  classical
  refine Finset.sum_bij
    (fun e1 he1 => e1 \ heightPrimePart h e)
    ?_ ?_ ?_ ?_
  · intro e1 he1
    have heF := Finset.mem_filter.mp he1
    have heBase := heF.1
    have hdsube1 := heF.2
    have he1ps : e1 ∈ e.powerset :=
      Finset.mem_of_mem_erase (Finset.mem_of_mem_erase heBase)
    have he1sub : e1 ⊆ e := Finset.mem_powerset.mp he1ps
    have hAsub : e1 \ heightPrimePart h e ⊆ e \ heightPrimePart h e := by
      intro p hp
      have hp' := Finset.mem_sdiff.mp hp
      exact Finset.mem_sdiff.mpr ⟨he1sub hp'.1, hp'.2⟩
    apply Finset.mem_erase.mpr
    constructor
    · intro hzero
      have heq : e1 = heightPrimePart h e := by
        ext p
        constructor
        · intro hp
          by_contra hpnotd
          have : p ∈ e1 \ heightPrimePart h e :=
            Finset.mem_sdiff.mpr ⟨hp, hpnotd⟩
          simpa [hzero] using this
        · intro hp
          exact hdsube1 hp
      exact (Finset.mem_erase.mp heBase).1 heq
    · apply Finset.mem_erase.mpr
      constructor
      · intro hfull
        have heq : e1 = e := by
          ext p
          constructor
          · exact fun hp => he1sub hp
          · intro hpE
            by_cases hpd : p ∈ heightPrimePart h e
            · exact hdsube1 hpd
            · have hpN : p ∈ e \ heightPrimePart h e :=
                Finset.mem_sdiff.mpr ⟨hpE, hpd⟩
              have hpA : p ∈ e1 \ heightPrimePart h e := by
                rw [hfull]
                exact hpN
              exact (Finset.mem_sdiff.mp hpA).1
        exact (Finset.mem_erase.mp (Finset.mem_of_mem_erase heBase)).1 heq
      · exact Finset.mem_powerset.mpr hAsub
  · intro e1 he1 e2 he2 hEq
    have h1 := (Finset.mem_filter.mp he1).2
    have h2 := (Finset.mem_filter.mp he2).2
    ext p
    by_cases hpd : p ∈ heightPrimePart h e
    · simp [h1 hpd, h2 hpd]
    · have hpEq : p ∈ e1 \ heightPrimePart h e ↔
          p ∈ e2 \ heightPrimePart h e := by rw [hEq]
      simpa [Finset.mem_sdiff, hpd] using hpEq
  · intro A hA
    have hA0 := Finset.mem_erase.mp hA
    have hAn := Finset.mem_erase.mp hA0.2
    have hAsub : A ⊆ e \ heightPrimePart h e :=
      Finset.mem_powerset.mp hAn.2
    let e1 := heightPrimePart h e ∪ A
    refine ⟨e1, ?_, ?_⟩
    · apply Finset.mem_filter.mpr
      constructor
      · apply Finset.mem_erase.mpr
        constructor
        · intro heqD
          apply hA0.1
          ext p
          constructor
          · intro hpA
            have hpE1 : p ∈ e1 := Finset.mem_union_right _ hpA
            rw [heqD] at hpE1
            have hpnotD := (Finset.mem_sdiff.mp (hAsub hpA)).2
            exact False.elim (hpnotD hpE1)
          · intro hp
            exact False.elim (hA0.1 (by simpa using hp))
        · apply Finset.mem_erase.mpr
          constructor
          · intro heqE
            apply hAn.1
            ext p
            constructor
            · intro hpA
              exact hAsub hpA
            · intro hpN
              have hpE : p ∈ e := (Finset.mem_sdiff.mp hpN).1
              have hpnotD := (Finset.mem_sdiff.mp hpN).2
              have hpE1 : p ∈ e1 := by simpa [heqE] using hpE
              rcases Finset.mem_union.mp hpE1 with hpD | hpA
              · exact False.elim (hpnotD hpD)
              · exact hpA
          · apply Finset.mem_powerset.mpr
            intro p hpE1
            rcases Finset.mem_union.mp hpE1 with hpD | hpA
            · exact (Finset.filter_subset _ _) hpD
            · exact (Finset.mem_sdiff.mp (hAsub hpA)).1
      · exact Finset.subset_union_left
    · ext p
      constructor
      · intro hp
        have hpPair := Finset.mem_sdiff.mp hp
        rcases Finset.mem_union.mp hpPair.1 with hpD | hpA
        · exact False.elim (hpPair.2 hpD)
        · exact hpA
      · intro hpA
        have hpN := hAsub hpA
        exact Finset.mem_sdiff.mpr
          ⟨Finset.mem_union_right _ hpA, (Finset.mem_sdiff.mp hpN).2⟩
  · intro e1 he1
    have heF := Finset.mem_filter.mp he1
    have heBase := heF.1
    have hdsub := heF.2
    have he1ps : e1 ∈ e.powerset :=
      Finset.mem_of_mem_erase (Finset.mem_of_mem_erase heBase)
    have he1sub : e1 ⊆ e := Finset.mem_powerset.mp he1ps
    exact decoratedAnalyticPairTerm_eq_partition he1sub hAall hdsub

#print axioms decoratedAnalyticPerE_eq_height_filter
#print axioms decoratedAnalytic_height_filter_sum_eq

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem decoratedAnalyticPerE_eq_height_weight_mul_boolean
    {q a h : ℕ} {e : Finset ℕ}
    (hAall : ∀ p ∈ e, activeHighPrime q p) :
    let d := heightPrimePart h e
    let n := e \ d
    let D := decoratedHeightProduct h e
    let H := decoratedReducedHeight h e
    decoratedAnalyticPerE q a h e =
      finiteVWeightReal h d * finiteOmegaWeightReal n *
        ordinaryBooleanInteriorDiscrepancy
          (fixedQLowWeight q (decoratedReducedAnchor q a D) H)
          H n := by
  dsimp
  rw [decoratedAnalyticPerE_eq_height_filter hAall]
  rw [decoratedAnalytic_height_filter_sum_eq hAall]
  unfold ordinaryBooleanInteriorDiscrepancy
  rw [Finset.mul_sum]

noncomputable def combinedBooleanFullEndpointTerm
    (q a h : ℕ) (e : Finset ℕ) : ℝ :=
  if heightPrimePart h e = e then 0 else
    decoratedAnalyticPairTerm q a h e e +
      decoratedDensityPairTerm q a h e e

theorem combinedBooleanFullEndpoint_add_pureHeight_eq_pureLeft
    {q a h : ℕ} (hq : 0 < q) (e : Finset ℕ) :
    combinedBooleanFullEndpointTerm q a h e +
      pureHeightSupportTerm q a h e =
        pureLeftPairTerm q a h e := by
  by_cases heq : heightPrimePart h e = e
  · simp [combinedBooleanFullEndpointTerm, pureHeightSupportTerm, heq]
  · rw [combinedBooleanFullEndpointTerm, if_neg heq,
      pureHeightSupportTerm, if_neg heq, add_zero]
    unfold pureLeftPairTerm
    symm
    exact pairTerm_eq_decoratedAnalytic_add_density hq (fun _ hp => hp)

theorem combinedBooleanFullEndpoint_eq_pureLeft_sub_pureHeight
    {q a h : ℕ} (hq : 0 < q) (e : Finset ℕ) :
    combinedBooleanFullEndpointTerm q a h e =
      pureLeftPairTerm q a h e - pureHeightSupportTerm q a h e := by
  linarith [combinedBooleanFullEndpoint_add_pureHeight_eq_pureLeft
    (q := q) (a := a) (h := h) hq e]

theorem summable_combinedBooleanFullEndpointTerm
    {q a h : ℕ} (hq : 0 < q) :
    Summable (combinedBooleanFullEndpointTerm q a h) := by
  exact ((summable_pureLeftPairTerm q a h).sub
    (summable_pureHeightSupportTerm q a h)).congr
      (fun e => (combinedBooleanFullEndpoint_eq_pureLeft_sub_pureHeight hq e).symm)

theorem tsum_combinedBooleanFullEndpoint_eq_pureLeft_sub_pureHeight
    {q a h : ℕ} (hq : 0 < q) :
    (∑' e : Finset ℕ, combinedBooleanFullEndpointTerm q a h e) =
      pureLeftFamily q a h -
        ∑' e : Finset ℕ, pureHeightSupportTerm q a h e := by
  have hp := summable_pureLeftPairTerm q a h
  have hh := summable_pureHeightSupportTerm q a h
  unfold pureLeftFamily
  rw [← hp.tsum_sub hh]
  apply tsum_congr
  intro e
  exact combinedBooleanFullEndpoint_eq_pureLeft_sub_pureHeight hq e

noncomputable def combinedBooleanEmptyEndpointTerm
    (q a h : ℕ) (e : Finset ℕ) : ℝ :=
  if heightPrimePart h e = e then 0 else
    decoratedAnalyticPairTerm q a h e (heightPrimePart h e) +
      decoratedDensityPairTerm q a h e (heightPrimePart h e)

theorem combinedBooleanEmptyEndpoint_eq_heightBoundary
    {q a h : ℕ} (hq : 0 < q) (e : Finset ℕ) :
    combinedBooleanEmptyEndpointTerm q a h e =
      heightBoundaryPairTerm q a h e := by
  by_cases heq : heightPrimePart h e = e
  · simp [combinedBooleanEmptyEndpointTerm, heightBoundaryPairTerm, heq]
  · rw [combinedBooleanEmptyEndpointTerm, if_neg heq,
      heightBoundaryPairTerm, if_neg heq]
    unfold heightSelectedPairTerm
    symm
    exact pairTerm_eq_decoratedAnalytic_add_density hq
      (Finset.filter_subset _ _)

theorem twoDimensionalPerE_eq_zero_of_all_height
    {q a h : ℕ} {e : Finset ℕ}
    (hAall : ∀ p ∈ e, activeHighPrime q p)
    (hall : heightPrimePart h e = e) :
    twoDimensionalPerE q a h e = 0 := by
  rw [twoDimensionalPerE_eq_erased_powerset, hall]
  apply Finset.sum_eq_zero
  intro e1 he1
  have heInner : e1 ∈ e.powerset.erase e :=
    (Finset.mem_erase.mp he1).2
  have he1ps : e1 ∈ e.powerset :=
    (Finset.mem_erase.mp heInner).2
  have he1sub : e1 ⊆ e := Finset.mem_powerset.mp he1ps
  have hne : e1 ≠ e := (Finset.mem_erase.mp heInner).1
  have hmiss : ∃ p ∈ heightPrimePart h e, p ∉ e1 := by
    rw [hall]
    simpa [Finset.not_subset] using
      (show ¬ e ⊆ e1 by
        intro hsub
        exact hne (Finset.Subset.antisymm he1sub hsub))
  rw [pairCoefficient_eq_zero_of_missing_height_prime he1sub hAall hmiss]
  simp

theorem twoDimensionalPerE_eq_completed_boolean_residual
    {q a h : ℕ} (hq : 0 < q) {e : Finset ℕ}
    (hAall : ∀ p ∈ e, activeHighPrime q p)
    (hne : heightPrimePart h e ≠ e) :
    let d := heightPrimePart h e
    let n := e \ d
    let D := decoratedHeightProduct h e
    let H := decoratedReducedHeight h e
    let aD := decoratedReducedAnchor q a D
    twoDimensionalPerE q a h e =
      finiteVWeightReal h d * finiteOmegaWeightReal n *
        ((2 : ℝ) ^ n.card *
          fixedProductBooleanDiscrepancy
            (fixedQLowWeight q aD H) H n)
      +
      (decoratedDensityPerE q a h e +
        decoratedDensityPairTerm q a h e e +
        decoratedDensityPairTerm q a h e d)
      -
      combinedBooleanFullEndpointTerm q a h e
      -
      combinedBooleanEmptyEndpointTerm q a h e := by
  dsimp
  let d := heightPrimePart h e
  let n := e \ d
  let D := decoratedHeightProduct h e
  let H := decoratedReducedHeight h e
  let aD := decoratedReducedAnchor q a D
  have hdsub : d ⊆ e := by
    dsimp [d]
    exact Finset.filter_subset _ _
  have hnne : n.Nonempty := by
    rw [Finset.nonempty_iff_ne_empty]
    intro hn0
    apply hne
    apply Finset.Subset.antisymm hdsub
    intro p hp
    by_contra hpnot
    have : p ∈ n := by
      exact Finset.mem_sdiff.mpr ⟨hp, hpnot⟩
    simpa [hn0] using this
  have hAnalytic :=
    decoratedAnalyticPerE_eq_height_weight_mul_boolean
      (q := q) (a := a) (h := h) (e := e) hAall
  have hBool :=
    ordinaryBooleanInteriorDiscrepancy_eq_full_sub_endpoints
      (fixedQLowWeight q aD H) H hnne
  have hFull :=
    decoratedAnalyticPairTerm_eq_partition
      (q := q) (a := a) (h := h) (e := e) (e1 := e)
      (fun _ hp => hp) hAall hdsub
  have hEmpty :=
    decoratedAnalyticPairTerm_eq_partition
      (q := q) (a := a) (h := h) (e := e)
      (e1 := heightPrimePart h e)
      (Finset.filter_subset _ _) hAall (fun _ hp => hp)
  have hEmpty' :
      decoratedAnalyticPairTerm q a h e (heightPrimePart h e) =
        finiteVWeightReal h (heightPrimePart h e) *
          finiteOmegaWeightReal (e \ heightPrimePart h e) *
          fixedProductPartitionDiscrepancy
            (fixedQLowWeight q
              (decoratedReducedAnchor q a (decoratedHeightProduct h e))
              (decoratedReducedHeight h e))
            (decoratedReducedHeight h e)
            (e \ heightPrimePart h e) ∅ := by
    simpa using hEmpty
  have hTwo := twoDimensionalPerE_eq_decoratedAnalytic_add_density
    (q := q) (a := a) (h := h) hq e
  dsimp [d, n, D, H, aD] at hAnalytic hBool hFull hEmpty' ⊢
  rw [hTwo, hAnalytic, hBool]
  rw [combinedBooleanFullEndpointTerm, if_neg hne]
  rw [combinedBooleanEmptyEndpointTerm, if_neg hne]
  rw [hFull, hEmpty']
  ring

#print axioms decoratedAnalyticPerE_eq_height_weight_mul_boolean
#print axioms combinedBooleanFullEndpoint_add_pureHeight_eq_pureLeft
#print axioms tsum_combinedBooleanFullEndpoint_eq_pureLeft_sub_pureHeight
#print axioms combinedBooleanEmptyEndpoint_eq_heightBoundary
#print axioms twoDimensionalPerE_eq_zero_of_all_height
#print axioms twoDimensionalPerE_eq_completed_boolean_residual

end PaperB.FixedQ
