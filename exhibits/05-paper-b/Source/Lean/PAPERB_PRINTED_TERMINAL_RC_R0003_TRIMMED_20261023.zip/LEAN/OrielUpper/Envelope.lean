import OrielUpper.ReduceB
import OrielUpper.Window

/-!
# Oriel Upper — the envelopes `E1`, `E34`, `Cτ` and the decoration mass
-/

open Finset

namespace OrielUpper

/-- Envelope for `A₁`. -/
noncomputable def envA1 (X : ℕ) : ℝ :=
  4 * Real.exp (10 * Z32) * Real.exp (6 + 4 * Real.log (Nat.log 2 (Nat.log 2 X) + 2))

/-- Envelope for `A_{3/4}`. -/
noncomputable def envA34 (X : ℕ) : ℝ :=
  4 * Real.exp (10 * Z32) * Real.exp (5 * ((Nat.log 2 X : ℕ) : ℝ) ^ (1 / 4 : ℝ))

lemma envA1_nonneg (X : ℕ) : 0 ≤ envA1 X := by unfold envA1; positivity
lemma envA34_nonneg (X : ℕ) : 0 ≤ envA34 X := by unfold envA34; positivity

theorem Asig_one_env {F X : ℕ} (hF : F ≠ 0) (hFX : F ≤ X) (N : ℕ) :
    Asig F N 1 ≤ envA1 X := by
  refine (oriel_Asig_le F N hF (by norm_num) le_rfl).trans ?_
  unfold envA1
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  calc ∏ p ∈ F.primeFactors, (1 + (p : ℝ) ^ (-(1 : ℝ)))
      ≤ Real.exp (∑ p ∈ F.primeFactors, (p : ℝ) ^ (-(1 : ℝ))) :=
        Real.prod_one_add_le_exp_sum _ (fun p => by positivity)
    _ ≤ Real.exp (6 + 4 * Real.log (Nat.log 2 (Nat.log 2 F) + 2)) := by
        apply Real.exp_le_exp.mpr
        have : ∀ p : ℕ, (p : ℝ) ^ (-(1 : ℝ)) = 1 / p := by
          intro p; rw [Real.rpow_neg_one, one_div]
        simp_rw [this]
        exact oriel_primeFactors_recip F
    _ ≤ Real.exp (6 + 4 * Real.log (Nat.log 2 (Nat.log 2 X) + 2)) := by
        apply Real.exp_le_exp.mpr
        have h1 : Nat.log 2 (Nat.log 2 F) ≤ Nat.log 2 (Nat.log 2 X) :=
          Nat.log_mono_right (Nat.log_mono_right hFX)
        have h2 : ((Nat.log 2 (Nat.log 2 F) : ℕ) : ℝ) + 2 ≤ ((Nat.log 2 (Nat.log 2 X) : ℕ) : ℝ) + 2 :=
          by exact_mod_cast Nat.add_le_add_right h1 2
        have := Real.log_le_log (by positivity) h2
        linarith

/-- `n^{-3/4} ≤ 4 ((n)^{1/4} - (n-1)^{1/4})`. -/
lemma rpow_neg_three_quarter_le (k : ℕ) :
    ((k + 1 : ℕ) : ℝ) ^ (-(3 / 4 : ℝ)) ≤
      4 * (((k + 1 : ℕ) : ℝ) ^ (1 / 4 : ℝ) - ((k : ℕ) : ℝ) ^ (1 / 4 : ℝ)) := by
  set x : ℝ := ((k + 1 : ℕ) : ℝ)
  set y : ℝ := ((k : ℕ) : ℝ)
  have hx : 0 < x := by positivity
  have hy : 0 ≤ y := by positivity
  set a := x ^ (1 / 4 : ℝ)
  set b := y ^ (1 / 4 : ℝ)
  have ha : 0 < a := by positivity
  have hb : 0 ≤ b := by positivity
  have ha4 : a ^ 4 = x := by
    rw [← Real.rpow_natCast, ← Real.rpow_mul hx.le]; norm_num
  have hb4 : b ^ 4 = y := by
    rw [← Real.rpow_natCast, ← Real.rpow_mul hy]; norm_num
  have hxy : x = y + 1 := by simp [x, y]
  have hab : b ≤ a := by
    apply Real.rpow_le_rpow hy (by linarith) (by norm_num)
  have hx34 : x ^ (-(3 / 4 : ℝ)) = 1 / a ^ 3 := by
    rw [Real.rpow_neg hx.le, ← Real.rpow_natCast, ← Real.rpow_mul hx.le, one_div]
    norm_num
  rw [hx34, div_le_iff₀ (by positivity)]
  -- 1 = a^4 - b^4 ≤ 4 (a - b) a^3
  have key : a ^ 4 - b ^ 4 = (a - b) * (a ^ 3 + a ^ 2 * b + a * b ^ 2 + b ^ 3) := by ring
  have hbd : a ^ 3 + a ^ 2 * b + a * b ^ 2 + b ^ 3 ≤ 4 * a ^ 3 := by
    have h1 : a ^ 2 * b ≤ a ^ 3 := by
      have := mul_le_mul_of_nonneg_left hab (by positivity : 0 ≤ a ^ 2); nlinarith
    have h2 : a * b ^ 2 ≤ a ^ 3 := by
      have : b ^ 2 ≤ a ^ 2 := pow_le_pow_left₀ hb hab 2
      nlinarith
    have h3 : b ^ 3 ≤ a ^ 3 := pow_le_pow_left₀ hb hab 3
    linarith
  have hsub : 0 ≤ a - b := by linarith
  have : (1 : ℝ) = a ^ 4 - b ^ 4 := by rw [ha4, hb4, hxy]; ring
  nlinarith [mul_le_mul_of_nonneg_left hbd hsub]

lemma sum_Icc_rpow_le (k : ℕ) :
    ∑ n ∈ Icc 1 k, (n : ℝ) ^ (-(3 / 4 : ℝ)) ≤ 4 * (k : ℝ) ^ (1 / 4 : ℝ) := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [sum_Icc_succ_top (by omega)]
    have := rpow_neg_three_quarter_le k
    push_cast at this ⊢
    linarith

/-- `∑_{p ∈ S} p^{-3/4} ≤ 5 |S|^{1/4}` for a set of positive integers. -/
lemma sum_rpow_neg_le_card (S : Finset ℕ) (hS : ∀ p ∈ S, 1 ≤ p) :
    ∑ p ∈ S, (p : ℝ) ^ (-(3 / 4 : ℝ)) ≤ 5 * ((S.card : ℕ) : ℝ) ^ (1 / 4 : ℝ) := by
  set k := S.card
  rcases Nat.eq_zero_or_pos k with hk | hk
  · have : S = ∅ := card_eq_zero.mp hk
    subst this; simp only [sum_empty]; positivity
  have hkr : (0 : ℝ) < k := by exact_mod_cast hk
  rw [← sum_filter_add_sum_filter_not S (fun p => p ≤ k)]
  have h1 : ∑ p ∈ S with p ≤ k, (p : ℝ) ^ (-(3 / 4 : ℝ)) ≤ 4 * (k : ℝ) ^ (1 / 4 : ℝ) := by
    refine le_trans ?_ (sum_Icc_rpow_le k)
    apply sum_le_sum_of_subset_of_nonneg
    · intro p hp
      have := mem_filter.mp hp
      exact mem_Icc.mpr ⟨hS p this.1, this.2⟩
    · intro p _ _; positivity
  have h2 : ∑ p ∈ S with ¬ p ≤ k, (p : ℝ) ^ (-(3 / 4 : ℝ)) ≤ (k : ℝ) ^ (1 / 4 : ℝ) := by
    calc ∑ p ∈ S with ¬ p ≤ k, (p : ℝ) ^ (-(3 / 4 : ℝ))
        ≤ ∑ p ∈ S with ¬ p ≤ k, (k : ℝ) ^ (-(3 / 4 : ℝ)) := by
          apply sum_le_sum; intro p hp
          have := (mem_filter.mp hp).2
          apply Real.rpow_le_rpow_of_nonpos hkr _ (by norm_num)
          exact_mod_cast (show k ≤ p by omega)
      _ ≤ (k : ℝ) * (k : ℝ) ^ (-(3 / 4 : ℝ)) := by
          rw [sum_const, nsmul_eq_mul]
          apply mul_le_mul_of_nonneg_right _ (by positivity)
          exact_mod_cast card_filter_le S _
      _ = (k : ℝ) ^ (1 / 4 : ℝ) := by
          rw [← Real.rpow_one_add' hkr.le (by norm_num)]; norm_num
  linarith

theorem Asig_34_env {F X : ℕ} (hF : F ≠ 0) (hFX : F ≤ X) (N : ℕ) :
    Asig F N (3 / 4) ≤ envA34 X := by
  refine (oriel_Asig_le F N hF le_rfl (by norm_num)).trans ?_
  unfold envA34
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  calc ∏ p ∈ F.primeFactors, (1 + (p : ℝ) ^ (-(3 / 4 : ℝ)))
      ≤ Real.exp (∑ p ∈ F.primeFactors, (p : ℝ) ^ (-(3 / 4 : ℝ))) :=
        Real.prod_one_add_le_exp_sum _ (fun p => by positivity)
    _ ≤ Real.exp (5 * ((Nat.log 2 X : ℕ) : ℝ) ^ (1 / 4 : ℝ)) := by
        apply Real.exp_le_exp.mpr
        refine (sum_rpow_neg_le_card _ (fun p hp => (Nat.prime_of_mem_primeFactors hp).one_le)).trans ?_
        apply mul_le_mul_of_nonneg_left _ (by norm_num)
        apply Real.rpow_le_rpow (by positivity) _ (by norm_num)
        exact_mod_cast (oriel_card_primeFactors_le F).trans (Nat.log_mono_right hFX)

/-- Weighted divisor-count sum. -/
theorem tau_sum_le (F N : ℕ) :
    ∑ r ∈ Icc 1 N, bW F r * ((r.divisors.card : ℝ) / r) ≤ Real.exp (10 * Z32) := by
  have hE := oriel_euler_le (fun r => bW F r * ((r.divisors.card : ℝ) / r))
    (fun n => mul_nonneg (bW_nonneg F n) (by positivity))
    (by simp [bW, gW_one])
    (fun {m n} hmn => by
      rcases Nat.eq_zero_or_pos m with hm | hm
      · subst hm; simp [bW]
      rcases Nat.eq_zero_or_pos n with hn | hn
      · subst hn; simp [bW]
      have hg : gW F (m * n) = gW F m * gW F n := (GW_isMultiplicative F).map_mul_of_coprime hmn
      have hτ : (m * n).divisors.card = m.divisors.card * n.divisors.card :=
        Nat.Coprime.card_divisors_mul hmn
      unfold bW
      rw [hg, hτ]
      push_cast
      field_simp)
    (fun {p k} hp hk => by
      unfold bW
      rw [gW_prime_pow hp (by omega)]; simp) N
  refine hE.trans ?_
  calc ∏ p ∈ (N + 1).primesBelow, (1 + bW F p * ((p.divisors.card : ℝ) / p) +
        bW F (p ^ 2) * (((p ^ 2).divisors.card : ℝ) / ((p ^ 2 : ℕ) : ℝ)))
      ≤ ∏ p ∈ (N + 1).primesBelow, (1 + 10 * (p : ℝ) ^ (-(3 / 2 : ℝ))) := by
        apply prod_le_prod₀
        · intro p _
          have : 0 ≤ bW F p * ((p.divisors.card : ℝ) / p) :=
            mul_nonneg (bW_nonneg F p) (by positivity)
          have : 0 ≤ bW F (p ^ 2) * (((p ^ 2).divisors.card : ℝ) / ((p ^ 2 : ℕ) : ℝ)) :=
            mul_nonneg (bW_nonneg F _) (by positivity)
          linarith
        · intro p hp
          have hpp : p.Prime := (Nat.mem_primesBelow.mp hp).2
          have hb2 : bW F (p ^ 2) = 0 := by unfold bW; rw [gW_prime_pow hpp le_rfl]; simp
          rw [hb2, zero_mul, add_zero, hpp.divisors, card_pair hpp.one_lt.ne]
          unfold bW
          rw [gW_prime F hpp]
          have hpr : (2 : ℝ) ≤ p := by exact_mod_cast hpp.two_le
          split_ifs with ha
          · have h5 : (5 : ℝ) ≤ p := by exact_mod_cast ha.1
            have hd : (0 : ℝ) < (p : ℝ) - 3 := by linarith
            -- p/(p-3)/p * 2/p = 2/(p(p-3)) ≤ 5/p^2 ≤ 10 p^{-3/2}
            have e : (p : ℝ) / ((p : ℝ) - 3) / p * ((2 : ℕ) / (p : ℝ)) =
                2 / ((p : ℝ) * ((p : ℝ) - 3)) := by
              push_cast; field_simp
            rw [e]
            have h1 : 2 / ((p : ℝ) * ((p : ℝ) - 3)) ≤ 5 / (p : ℝ) ^ 2 := by
              rw [div_le_div_iff₀ (by positivity) (by positivity)]; nlinarith
            have h2 : 5 / (p : ℝ) ^ 2 ≤ 10 * (p : ℝ) ^ (-(3 / 2 : ℝ)) := by
              have hp0 : (0 : ℝ) < p := by linarith
              have : (p : ℝ) ^ (-(3 / 2 : ℝ)) = (p : ℝ) ^ (1 / 2 : ℝ) / (p : ℝ) ^ 2 := by
                rw [eq_div_iff (by positivity), ← Real.rpow_natCast, ← Real.rpow_add hp0]
                norm_num
              rw [this, mul_div_assoc', div_le_div_iff_of_pos_right (by positivity)]
              have : (1 : ℝ) ≤ (p : ℝ) ^ (1 / 2 : ℝ) := Real.one_le_rpow (by linarith) (by norm_num)
              linarith
            linarith
          · simp only [zero_div, zero_mul, add_zero]
            have : 0 ≤ 10 * (p : ℝ) ^ (-(3 / 2 : ℝ)) := by positivity
            linarith
    _ ≤ Real.exp (10 * Z32) := prod_allowed_le _

/-- Decoration mass. -/
theorem decor_sum_le (q h : ℕ) :
    ∑ d ∈ (Mirror.decoratedHeightPrimeSet q h).powerset, Mirror.finiteVWeightReal h d ≤
      Real.exp (5 / 3 * (6 + 4 * Real.log (Nat.log 2 (Nat.log 2 h) + 2))) := by
  set S := Mirror.decoratedHeightPrimeSet q h
  have hV : ∀ d ∈ S.powerset, Mirror.finiteVWeightReal h d = ∏ p ∈ d, 1 / ((p : ℝ) - 2) := by
    intro d hd
    unfold Mirror.finiteVWeightReal
    apply prod_congr rfl
    intro p hp
    rw [if_pos (mem_decorated (mem_powerset.mp hd hp)).2.1]
  rw [sum_congr rfl hV, ← prod_one_add]
  have hS5 : ∀ p ∈ S, (5 : ℝ) ≤ p := fun p hp => by exact_mod_cast (mem_decorated hp).2.2.2.1
  have hsub : S ⊆ h.primeFactors := by
    intro p hp
    obtain ⟨hpp, hph, hh0, _⟩ := mem_decorated hp
    exact Nat.mem_primeFactors.mpr ⟨hpp, hph, hh0⟩
  calc ∏ p ∈ S, (1 + 1 / ((p : ℝ) - 2))
      ≤ ∏ p ∈ S, Real.exp (1 / ((p : ℝ) - 2)) := by
        apply prod_le_prod₀
        · intro p hp
          have := hS5 p hp
          have : (0 : ℝ) < (p : ℝ) - 2 := by linarith
          positivity
        · intro p _
          have := Real.add_one_le_exp (1 / ((p : ℝ) - 2)); linarith
    _ = Real.exp (∑ p ∈ S, 1 / ((p : ℝ) - 2)) := (Real.exp_sum _ _).symm
    _ ≤ Real.exp (∑ p ∈ h.primeFactors, 5 / 3 * (1 / (p : ℝ))) := by
        apply Real.exp_le_exp.mpr
        calc ∑ p ∈ S, 1 / ((p : ℝ) - 2) ≤ ∑ p ∈ S, 5 / 3 * (1 / (p : ℝ)) := by
              apply sum_le_sum
              intro p hp
              have := hS5 p hp
              rw [div_le_iff₀ (by linarith : (0 : ℝ) < (p : ℝ) - 2)]
              field_simp
              linarith
          _ ≤ _ := sum_le_sum_of_subset_of_nonneg hsub (fun p _ _ => by positivity)
    _ ≤ _ := by
        apply Real.exp_le_exp.mpr
        rw [← mul_sum]
        exact mul_le_mul_of_nonneg_left (oriel_primeFactors_recip h) (by norm_num)

lemma finiteVWeightReal_nonneg {q h : ℕ} {d : Finset ℕ}
    (hd : d ∈ (Mirror.decoratedHeightPrimeSet q h).powerset) :
    0 ≤ Mirror.finiteVWeightReal h d := by
  unfold Mirror.finiteVWeightReal
  apply prod_nonneg
  intro p hp
  rw [if_pos (mem_decorated (mem_powerset.mp hd hp)).2.1]
  have := (mem_decorated (mem_powerset.mp hd hp)).2.2.2.1
  have : (5 : ℝ) ≤ p := by exact_mod_cast this
  have : (0 : ℝ) < (p : ℝ) - 2 := by linarith
  positivity

end OrielUpper
