import Mathlib.Data.Int.CardIntervalMod
import Mathlib.Algebra.BigOperators.Module
import Mathlib.Algebra.BigOperators.Field
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Algebra.Order.Archimedean.Real.Basic
import Mathlib.Data.Real.Basic

/-!
# Oriel Upper — discrete bounded-variation progression lemma

For any `g : ℕ → ℝ`, modulus `Q ≥ 1`, class `c` and `a ≤ b`:

`|∑_{a<n≤b, n≡c (Q)} g n - (1/Q) ∑_{a<n≤b} g n| ≤ |g b| + ∑_{a<n<b} |g (n+1) - g n|`.

Proof: summation by parts against `χ(n) = 1[n≡c] - 1/Q`, whose partial sums are
bounded by `1` in absolute value.
-/

open Finset

namespace OrielUpper

/-- The count of a residue class in an interval is within `1` of the length over `Q`. -/
theorem oriel_count_class_close {Q : ℕ} (hQ : 0 < Q) (c a j : ℕ) :
    |(((Ioc a (a + j)).filter (fun n => n ≡ c [MOD Q])).card : ℝ) - (j : ℝ) / Q| ≤ 1 := by
  have hcard := Nat.Ioc_filter_modEq_card a (a + j) hQ c
  set X : ℚ := ((a + j : ℕ) - c : ℚ) / Q with hX
  set Y : ℚ := ((a : ℕ) - c : ℚ) / Q with hY
  have hQq : (0 : ℚ) < Q := by exact_mod_cast hQ
  have hXY : X - Y = (j : ℚ) / Q := by rw [hX, hY]; push_cast; field_simp; ring
  have hfl : ⌊Y⌋ ≤ ⌊X⌋ := Int.floor_mono (by
    have : (0 : ℚ) ≤ (j : ℚ) / Q := by positivity
    linarith)
  have hmax : max (⌊X⌋ - ⌊Y⌋) 0 = ⌊X⌋ - ⌊Y⌋ := max_eq_left (by omega)
  rw [hmax] at hcard
  have hq : ((((Ioc a (a + j)).filter (fun n => n ≡ c [MOD Q])).card : ℚ)) =
      (⌊X⌋ : ℚ) - ⌊Y⌋ := by exact_mod_cast hcard
  have h1 := Int.floor_le X
  have h2 := Int.lt_floor_add_one X
  have h3 := Int.floor_le Y
  have h4 := Int.lt_floor_add_one Y
  have key : |((((Ioc a (a + j)).filter (fun n => n ≡ c [MOD Q])).card : ℚ)) - (j : ℚ) / Q| ≤ 1 := by
    rw [hq, ← hXY, abs_le]
    constructor <;> linarith
  have := (Rat.cast_le (K := ℝ)).mpr key
  push_cast at this
  exact this

/-- Discrete BV progression lemma. -/
theorem oriel_bv_progression {Q : ℕ} (hQ : 0 < Q) (c a b : ℕ) (hab : a ≤ b) (g : ℕ → ℝ) :
    |∑ n ∈ (Ioc a b).filter (fun n => n ≡ c [MOD Q]), g n - (∑ n ∈ Ioc a b, g n) / Q| ≤
      |g b| + ∑ i ∈ range (b - a - 1), |g (a + 1 + (i + 1)) - g (a + 1 + i)| := by
  have hQr : (0 : ℝ) < Q := by exact_mod_cast hQ
  have hR0 : 0 ≤ |g b| + ∑ i ∈ range (b - a - 1), |g (a + 1 + (i + 1)) - g (a + 1 + i)| :=
    add_nonneg (abs_nonneg _) (sum_nonneg (fun _ _ => abs_nonneg _))
  rcases Nat.eq_zero_or_pos (b - a) with hba | hba
  · have hb : b = a := by omega
    subst hb
    simp only [Ioc_self, filter_empty, sum_empty, zero_div, sub_zero, abs_zero]
    exact hR0
  obtain ⟨L, hL⟩ : ∃ L, L = b - a := ⟨_, rfl⟩
  set χ : ℕ → ℝ := fun i => (if a + 1 + i ≡ c [MOD Q] then (1 : ℝ) else 0) - 1 / Q with hχ
  set f : ℕ → ℝ := fun i => g (a + 1 + i) with hf
  have hIoc : ∀ φ : ℕ → ℝ, ∑ n ∈ Ioc a b, φ n = ∑ i ∈ range L, φ (a + 1 + i) := by
    intro φ
    rw [← Finset.Ico_add_one_add_one_eq_Ioc, sum_Ico_eq_sum_range]
    rw [show b + 1 - (a + 1) = L by omega]
  have hlhs : ∑ n ∈ (Ioc a b).filter (fun n => n ≡ c [MOD Q]), g n - (∑ n ∈ Ioc a b, g n) / Q =
      ∑ i ∈ range L, f i • χ i := by
    rw [sum_filter, hIoc, hIoc, Finset.sum_div, ← sum_sub_distrib]
    apply sum_congr rfl
    intro i _
    simp only [hf, hχ, smul_eq_mul]
    split_ifs <;> ring
  -- partial sums of χ
  have hcnt : ∀ j, ((range j).filter (fun i => a + 1 + i ≡ c [MOD Q])).card =
      ((Ioc a (a + j)).filter (fun n => n ≡ c [MOD Q])).card := by
    intro j
    apply card_nbij' (fun i => a + 1 + i) (fun n => n - (a + 1))
    · intro i hi
      simp only [mem_coe, mem_filter, mem_range] at hi
      simp only [mem_coe, mem_filter, mem_Ioc]
      exact ⟨⟨by omega, by omega⟩, hi.2⟩
    · intro n hn
      simp only [mem_coe, mem_filter, mem_Ioc] at hn
      simp only [mem_coe, mem_filter, mem_range]
      refine ⟨by omega, ?_⟩
      rw [show a + 1 + (n - (a + 1)) = n by omega]; exact hn.2
    · intro i _; show a + 1 + i - (a + 1) = i; omega
    · intro n hn
      rw [mem_coe, mem_filter, mem_Ioc] at hn
      show a + 1 + (n - (a + 1)) = n; omega
  have hG : ∀ j, |∑ i ∈ range j, χ i| ≤ 1 := by
    intro j
    have hsum : ∑ i ∈ range j, χ i =
        (((Ioc a (a + j)).filter (fun n => n ≡ c [MOD Q])).card : ℝ) - (j : ℝ) / Q := by
      simp only [hχ, sum_sub_distrib, sum_const, card_range, nsmul_eq_mul]
      rw [← sum_filter, sum_const, nsmul_eq_mul, mul_one, hcnt j]
      ring
    rw [hsum]
    exact oriel_count_class_close hQ c a j
  rw [hlhs, sum_range_by_parts]
  have t1 : |f (L - 1) • ∑ i ∈ range L, χ i| ≤ |f (L - 1)| := by
    rw [smul_eq_mul, abs_mul]
    exact mul_le_of_le_one_right (abs_nonneg _) (hG L)
  have t2 : |∑ i ∈ range (L - 1), (f (i + 1) - f i) • ∑ j ∈ range (i + 1), χ j| ≤
      ∑ i ∈ range (L - 1), |f (i + 1) - f i| := by
    refine (Finset.abs_sum_le_sum_abs _ _).trans (sum_le_sum ?_)
    intro i _
    rw [smul_eq_mul, abs_mul]
    exact mul_le_of_le_one_right (abs_nonneg _) (hG (i + 1))
  have hfL : f (L - 1) = g b := by simp only [hf]; congr 1; omega
  have hsumeq : ∑ i ∈ range (L - 1), |f (i + 1) - f i| =
      ∑ i ∈ range (b - a - 1), |g (a + 1 + (i + 1)) - g (a + 1 + i)| := by
    rw [show L - 1 = b - a - 1 by omega]
  calc |f (L - 1) • ∑ i ∈ range L, χ i -
        ∑ i ∈ range (L - 1), (f (i + 1) - f i) • ∑ j ∈ range (i + 1), χ j|
      ≤ |f (L - 1) • ∑ i ∈ range L, χ i| +
        |∑ i ∈ range (L - 1), (f (i + 1) - f i) • ∑ j ∈ range (i + 1), χ j| := abs_sub _ _
    _ ≤ |f (L - 1)| + ∑ i ∈ range (L - 1), |f (i + 1) - f i| := add_le_add t1 t2
    _ = _ := by rw [hfL, hsumeq]

end OrielUpper
