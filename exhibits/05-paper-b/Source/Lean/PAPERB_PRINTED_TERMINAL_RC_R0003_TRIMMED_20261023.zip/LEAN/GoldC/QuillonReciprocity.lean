import GoldC.QuillonRLemma

/-!
# Quillon CSC3: exponential reciprocity for the R route

`invMod`, `mul_invMod_modEq`, `invMod_lt`, `invMod_pos` and `reciprocity` are **verbatim copies** of
`GoldC/RowRounding.lean` (namespace `GoldC.QuillonCopyRec`). Consequence:

    e(A·r̄/s) = e(A/(rs)) · e(−A·s̄/r)        (r, s ≥ 2 coprime, A ∈ ℤ).

No axiom, no `sorry`.
-/

namespace GoldC.QuillonCopyRec

open GoldC.QuillonR

/-- verbatim copy of `GoldC.invMod` -/
noncomputable def invMod (r s : ℕ) : ℕ := ((r : ZMod s)⁻¹).val

lemma mul_invMod_modEq {r s : ℕ} (hs : 2 ≤ s) (h : r.Coprime s) :
    r * invMod r s ≡ 1 [MOD s] := by
  have : NeZero s := ⟨by omega⟩
  rw [← ZMod.natCast_eq_natCast_iff]
  push_cast
  unfold invMod
  rw [ZMod.natCast_val, ZMod.cast_id', id, ZMod.coe_mul_inv_eq_one _ h]

lemma invMod_lt {r s : ℕ} (hs : 2 ≤ s) : invMod r s < s := by
  have : NeZero s := ⟨by omega⟩
  exact ZMod.val_lt _

lemma invMod_pos {r s : ℕ} (hs : 2 ≤ s) (h : r.Coprime s) : 0 < invMod r s := by
  rcases Nat.eq_zero_or_pos (invMod r s) with h0 | h0
  · have := mul_invMod_modEq hs h
    rw [h0, mul_zero] at this
    have h1 : 1 % s = 0 := this.symm
    rw [Nat.one_mod_eq_zero_iff] at h1
    omega
  · exact h0

/-- **Reciprocity**: `r·(r⁻¹ mod s) + s·(s⁻¹ mod r) = rs + 1`. -/
theorem reciprocity {r s : ℕ} (hr : 2 ≤ r) (hs : 2 ≤ s) (h : r.Coprime s) :
    r * invMod r s + s * invMod s r = r * s + 1 := by
  set u := invMod r s
  set v := invMod s r
  have hu := mul_invMod_modEq hs h
  have hv := mul_invMod_modEq hr h.symm
  have hu1 := invMod_lt (r := r) hs
  have hv1 := invMod_lt (r := s) hr
  have hu0 := invMod_pos hs h
  have hv0 := invMod_pos hr h.symm
  -- `X ≡ 1` modulo `s` and modulo `r`
  have h1 : r * u + s * v ≡ 1 [MOD s] := by
    have : s * v ≡ 0 [MOD s] := Nat.modEq_zero_iff_dvd.2 (dvd_mul_right _ _)
    simpa using hu.add this
  have h2 : r * u + s * v ≡ 1 [MOD r] := by
    have : r * u ≡ 0 [MOD r] := Nat.modEq_zero_iff_dvd.2 (dvd_mul_right _ _)
    simpa using this.add hv
  have h3 : r * u + s * v ≡ 1 [MOD r * s] :=
    (Nat.modEq_and_modEq_iff_modEq_mul h).1 ⟨h2, h1⟩
  have hrs : 4 ≤ r * s := by nlinarith
  have hmod : (r * u + s * v) % (r * s) = 1 := by
    rw [h3]; exact Nat.one_mod_eq_one.2 (by omega)
  have hb1 : r * u + r ≤ r * s := by
    have := Nat.mul_le_mul_left r (show u + 1 ≤ s by omega)
    rw [Nat.mul_add, mul_one] at this; exact this
  have hb2 : s * v + s ≤ r * s := by
    have := Nat.mul_le_mul_left s (show v + 1 ≤ r by omega)
    rw [Nat.mul_add, mul_one, mul_comm s r] at this; exact this
  have hl1 : r ≤ r * u := Nat.le_mul_of_pos_right r hu0
  have hl2 : s ≤ s * v := Nat.le_mul_of_pos_right s hv0
  have hdiv := Nat.div_add_mod (r * u + s * v) (r * s)
  rw [hmod] at hdiv
  have hXlt : r * u + s * v < r * s * 2 := by omega
  have hXge : 2 ≤ r * u + s * v := by omega
  generalize hk : (r * u + s * v) / (r * s) = k at hdiv
  have hk2 : k < 2 := by
    by_contra hk'; push Not at hk'
    have : r * s * 2 ≤ r * s * k := Nat.mul_le_mul_left _ hk'
    omega
  have hk1 : k ≠ 0 := by
    rintro rfl; rw [mul_zero] at hdiv; omega
  have : k = 1 := by omega
  rw [this, mul_one] at hdiv
  omega


/-- **Exponential reciprocity.** -/
theorem eR_reciprocity {r s : ℕ} (hr : 2 ≤ r) (hs : 2 ≤ s) (h : r.Coprime s) (A : ℤ) :
    eR ((A : ℝ) * invMod r s / s) = eR ((A : ℝ) / ((r : ℝ) * s)) * eR (-((A : ℝ) * invMod s r / r)) := by
  rw [← eR_add]
  have hrec := reciprocity hr hs h
  have hrR : (r : ℝ) ≠ 0 := by positivity
  have hsR : (s : ℝ) ≠ 0 := by positivity
  have hrecR : (r : ℝ) * invMod r s + s * invMod s r = r * s + 1 := by exact_mod_cast hrec
  -- A u/s = A + A/(rs) − A v/r
  have key : (A : ℝ) * invMod r s / s = (A : ℝ) / ((r : ℝ) * s) + -((A : ℝ) * invMod s r / r) + A := by
    field_simp
    linear_combination (A : ℝ) * hrecR
  rw [key, eR_add]
  have h1 : eR (A : ℝ) = 1 := by
    unfold eR
    rw [show 2 * (Real.pi : ℂ) * Complex.I * ((A : ℝ) : ℂ) = (A : ℂ) * (2 * Real.pi * Complex.I) by
      push_cast; ring]
    exact Complex.exp_int_mul_two_pi_mul_I A
  rw [h1, mul_one]

end GoldC.QuillonCopyRec

#print axioms GoldC.QuillonCopyRec.reciprocity
#print axioms GoldC.QuillonCopyRec.eR_reciprocity
