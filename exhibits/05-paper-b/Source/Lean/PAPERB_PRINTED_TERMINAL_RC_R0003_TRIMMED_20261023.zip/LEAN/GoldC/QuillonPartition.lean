import Mathlib.Data.Nat.Log
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Tactic

/-!
# Quillon CSC3 F7.4f: the near-geometric partition for Type II

`tseq U T`: `t₀ = U`, `t_{j+1} = t_j + ⌊t_j/T⌋ + 1`.

* Monotone, `t_j ≥ U`; `t_{j+1} ≤ 2t_j` (for `T, U ≥ 2`); `2t_j ≤ t_{j+T}`; `2^k U ≤ t_{kT}`.
* `Jstop`: the least `J` with `B < (V+1)·t_J`. It satisfies `Jstop ≤ T(log₂B + 1)` and
  `(V+1)·t_{Jstop} ≤ (V+1)U + 2B`.

No axiom, no `sorry`.
-/

open Finset

namespace GoldC.QuillonPartition

def tseq (U T : ℕ) : ℕ → ℕ
  | 0 => U
  | j + 1 => tseq U T j + tseq U T j / T + 1

variable {U T : ℕ}

lemma tseq_succ (j : ℕ) : tseq U T (j + 1) = tseq U T j + tseq U T j / T + 1 := rfl

lemma tseq_mono : Monotone (tseq U T) :=
  monotone_nat_of_le_succ fun j => by
    rw [tseq_succ]; exact (Nat.le_add_right _ _).trans (Nat.le_succ _)

lemma tseq_ge (j : ℕ) : U ≤ tseq U T j := by
  have := tseq_mono (U := U) (T := T) (Nat.zero_le j); simpa [tseq] using this

lemma tseq_succ_le (hT : 2 ≤ T) (hU : 2 ≤ U) (j : ℕ) : tseq U T (j + 1) ≤ 2 * tseq U T j := by
  rw [tseq_succ]
  have h2 := tseq_ge (U := U) (T := T) j
  have : tseq U T j / T ≤ tseq U T j / 2 := Nat.div_le_div_left hT (by norm_num)
  omega

lemma tseq_add (j : ℕ) : ∀ i, tseq U T j + i * (tseq U T j / T + 1) ≤ tseq U T (j + i)
  | 0 => by simp
  | i + 1 => by
    have ih := tseq_add j i
    rw [← add_assoc, tseq_succ]
    have : tseq U T j / T ≤ tseq U T (j + i) / T :=
      Nat.div_le_div_right (tseq_mono (Nat.le_add_right j i))
    nlinarith

lemma tseq_double (hT : 1 ≤ T) (j : ℕ) : 2 * tseq U T j ≤ tseq U T (j + T) := by
  have h := tseq_add (U := U) (T := T) j T
  have hdm := Nat.div_add_mod (tseq U T j) T
  have hml := Nat.mod_lt (tseq U T j) (by omega : 0 < T)
  nlinarith

lemma tseq_pow (hT : 1 ≤ T) : ∀ k, 2 ^ k * U ≤ tseq U T (k * T)
  | 0 => by simp [tseq]
  | k + 1 => by
    have ih := tseq_pow hT k
    have := tseq_double (U := U) hT (k * T)
    rw [show (k + 1) * T = k * T + T by ring, pow_succ]
    nlinarith

lemma exists_stop (hT : 1 ≤ T) (hU : 1 ≤ U) (V B : ℕ) : ∃ J, B < (V + 1) * tseq U T J := by
  refine ⟨(Nat.log 2 B + 1) * T, ?_⟩
  have h1 := tseq_pow (U := U) hT (Nat.log 2 B + 1)
  have h2 : B < 2 ^ (Nat.log 2 B + 1) := Nat.lt_pow_succ_log_self (by norm_num) B
  have h3 : 2 ^ (Nat.log 2 B + 1) ≤ 2 ^ (Nat.log 2 B + 1) * U := Nat.le_mul_of_pos_right _ hU
  nlinarith

open Classical in
/-- The stopping index. -/
noncomputable def Jstop (U T V B : ℕ) (hT : 1 ≤ T) (hU : 1 ≤ U) : ℕ :=
  Nat.find (exists_stop (U := U) hT hU V B)

lemma Jstop_spec (V B : ℕ) (hT : 1 ≤ T) (hU : 1 ≤ U) :
    B < (V + 1) * tseq U T (Jstop U T V B hT hU) := by
  classical
  unfold Jstop; exact Nat.find_spec (exists_stop hT hU V B)

lemma Jstop_le (V B : ℕ) (hT : 1 ≤ T) (hU : 1 ≤ U) :
    Jstop U T V B hT hU ≤ (Nat.log 2 B + 1) * T := by
  classical
  unfold Jstop
  apply Nat.find_min'
  have h1 := tseq_pow (U := U) hT (Nat.log 2 B + 1)
  have h2 : B < 2 ^ (Nat.log 2 B + 1) := Nat.lt_pow_succ_log_self (by norm_num) B
  have h3 : 2 ^ (Nat.log 2 B + 1) ≤ 2 ^ (Nat.log 2 B + 1) * U := Nat.le_mul_of_pos_right _ hU
  nlinarith

lemma tJstop_le (V B : ℕ) (hT : 2 ≤ T) (hU : 2 ≤ U) :
    (V + 1) * tseq U T (Jstop U T V B (by omega) (by omega)) ≤ (V + 1) * U + 2 * B := by
  classical
  have key : ∀ J, J = Jstop U T V B (by omega) (by omega) →
      (V + 1) * tseq U T J ≤ (V + 1) * U + 2 * B := by
    intro J hJ
    cases J with
    | zero => simp [tseq]
    | succ i =>
      have hlt : i < Nat.find (exists_stop (U := U) (T := T) (by omega) (by omega) V B) := by
        unfold Jstop at hJ; omega
      have hmin := Nat.find_min (exists_stop (U := U) (T := T) (by omega) (by omega) V B) hlt
      have hle := tseq_succ_le (U := U) hT hU i
      rw [not_lt] at hmin
      nlinarith
  exact key _ rfl

end GoldC.QuillonPartition

#print axioms GoldC.QuillonPartition.Jstop_le
#print axioms GoldC.QuillonPartition.tJstop_le
#print axioms GoldC.QuillonPartition.tseq_succ_le
