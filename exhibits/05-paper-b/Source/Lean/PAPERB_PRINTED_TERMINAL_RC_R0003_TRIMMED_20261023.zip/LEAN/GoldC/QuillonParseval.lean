import Mathlib.NumberTheory.LegendreSymbol.AddCharacter
import Mathlib.Analysis.SpecialFunctions.Complex.CircleAddChar
import Mathlib.Tactic

/-!
# Quillon CSC3 F3: Parseval bilinear bound for inverse-type phases mod `s`

For `s ≥ 1`, `ψ = ZMod.stdAddChar` (so `ψ(x) = e(x/s)`), any `c : ZMod s`, finite sets `𝒴, 𝒩` of
naturals with every `y ∈ 𝒴` coprime to `s` and `𝒴 ⊆ [1, Y]`, and coefficients `a, b`:

    ‖Σ_{y∈𝒴} Σ_{n∈𝒩} a_y b_n ψ(c · ȳ · ι(n))‖²
      ≤ (Σ‖a_y‖²) · (Y/s + 1) · s · Σ_{n,n'∈𝒩, c(ι n − ι n')=0} ‖b_n‖‖b_n'‖,

with `ȳ = (y : ZMod s)⁻¹` and any `ι : ℕ → ZMod s`. This is the W/VW Type II engine for
`α ≥ 1+ε`: it needs no Kloosterman bound at all. The last factor is bounded by the caller
(it is `‖b‖²·(N·gcd(c,s)/s + 1)` when `ι n = n̄`).

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonParseval

variable {s : ℕ} [NeZero s]

local notation "ψ" => (ZMod.stdAddChar : AddChar (ZMod s) ℂ)

lemma orth (t : ZMod s) : ∑ x : ZMod s, ψ (x * t) = if t = 0 then (s : ℂ) else 0 := by
  rw [AddChar.sum_mulShift t (ZMod.isPrimitive_stdAddChar s)]
  simp [ZMod.card]

lemma conj_psi (t : ZMod s) : (starRingEnd ℂ) (ψ t) = ψ (-t) := by
  have hR : 0 < ringChar (ZMod s) := by
    rw [ZMod.ringChar_zmod_n]; exact Nat.pos_of_ne_zero (NeZero.ne s)
  rw [AddChar.starComp_apply hR, AddChar.map_neg_eq_inv, AddChar.inv_apply']

/-- Number of `y ∈ [1,Y]` in one residue class mod `s` is at most `Y/s + 1`. -/
lemma card_class_le (Y : ℕ) (x : ZMod s) :
    (((Finset.Icc 1 Y : Finset ℕ).filter (fun y : ℕ => ((y : ZMod s) = x))).card : ℝ) ≤ (Y : ℝ) / s + 1 := by
  have hs : 0 < s := Nat.pos_of_ne_zero (NeZero.ne s)
  have hsR : (0 : ℝ) < s := by exact_mod_cast hs
  -- injection y ↦ y / s into [0, Y/s]
  have hinj : Set.InjOn (fun y => y / s)
      (((Finset.Icc 1 Y : Finset ℕ).filter (fun y : ℕ => ((y : ZMod s) = x))) : Set ℕ) := by
    intro a ha b hb h
    simp only [Finset.coe_filter, Finset.mem_Icc, Set.mem_setOf_eq] at ha hb
    have hmod : a % s = b % s := by
      have := ha.2.trans hb.2.symm
      rwa [ZMod.natCast_eq_natCast_iff'] at this
    have := Nat.div_add_mod a s
    have := Nat.div_add_mod b s
    simp only at h
    rw [h, hmod] at *
    omega
  have hmaps : ∀ y ∈ (Finset.Icc 1 Y : Finset ℕ).filter (fun y : ℕ => ((y : ZMod s) = x)),
      y / s ∈ Finset.range (Y / s + 1) := by
    intro y hy
    rw [Finset.mem_filter, Finset.mem_Icc] at hy
    rw [Finset.mem_range]
    exact Nat.lt_succ_of_le (Nat.div_le_div_right hy.1.2)
  have hc := Finset.card_le_card_of_injOn _ hmaps hinj
  rw [Finset.card_range] at hc
  have : ((Y / s + 1 : ℕ) : ℝ) ≤ (Y : ℝ) / s + 1 := by
    push_cast
    have := Nat.cast_div_le (α := ℝ) (m := Y) (n := s)
    linarith
  exact (by exact_mod_cast hc : (((Finset.Icc 1 Y).filter _).card : ℝ) ≤ ((Y / s + 1 : ℕ) : ℝ)).trans this

theorem parseval_bilinear (c : ZMod s) (ι : ℕ → ZMod s) (Y : ℕ) (𝒴 𝒩 : Finset ℕ)
    (h𝒴 : 𝒴 ⊆ Finset.Icc 1 Y) (hcop : ∀ y ∈ 𝒴, Nat.Coprime y s) (a b : ℕ → ℂ) :
    ‖∑ y ∈ 𝒴, ∑ n ∈ 𝒩, a y * b n * ψ (c * (y : ZMod s)⁻¹ * ι n)‖ ^ 2 ≤
      (∑ y ∈ 𝒴, ‖a y‖ ^ 2) * ((Y : ℝ) / s + 1) * s *
        ∑ n ∈ 𝒩, ∑ n' ∈ 𝒩, (if c * (ι n - ι n') = 0 then ‖b n‖ * ‖b n'‖ else 0) := by
  set F : ZMod s → ℂ := fun x => ∑ n ∈ 𝒩, b n * ψ (c * x * ι n) with hF
  have hB : ∑ y ∈ 𝒴, ∑ n ∈ 𝒩, a y * b n * ψ (c * (y : ZMod s)⁻¹ * ι n) =
      ∑ y ∈ 𝒴, a y * F ((y : ZMod s)⁻¹) := by
    refine Finset.sum_congr rfl fun y _ => ?_
    rw [hF, Finset.mul_sum]; refine Finset.sum_congr rfl fun n _ => by ring
  rw [hB]
  -- Cauchy–Schwarz in y
  have hCS : ‖∑ y ∈ 𝒴, a y * F ((y : ZMod s)⁻¹)‖ ^ 2 ≤
      (∑ y ∈ 𝒴, ‖a y‖ ^ 2) * ∑ y ∈ 𝒴, ‖F ((y : ZMod s)⁻¹)‖ ^ 2 := by
    calc _ ≤ (∑ y ∈ 𝒴, ‖a y‖ * ‖F ((y : ZMod s)⁻¹)‖) ^ 2 := by
          refine pow_le_pow_left₀ (norm_nonneg _) ?_ 2
          exact (norm_sum_le _ _).trans (le_of_eq (Finset.sum_congr rfl fun y _ => norm_mul _ _))
      _ ≤ _ := Finset.sum_mul_sq_le_sq_mul_sq _ _ _
  -- group y by the unit ȳ: each unit x has ≤ Y/s + 1 preimages
  have hgroup : ∑ y ∈ 𝒴, ‖F ((y : ZMod s)⁻¹)‖ ^ 2 ≤
      ((Y : ℝ) / s + 1) * ∑ x : ZMod s, ‖F x‖ ^ 2 := by
    have hfib := Finset.sum_fiberwise_of_maps_to (s := 𝒴)
      (t := (Finset.univ : Finset (ZMod s))) (g := fun y : ℕ => ((y : ZMod s)⁻¹))
      (fun _ _ => Finset.mem_univ _) (f := fun y => ‖F ((y : ZMod s)⁻¹)‖ ^ 2)
    rw [← hfib, Finset.mul_sum]
    refine Finset.sum_le_sum (fun (x : ZMod s) _ => ?_)
    have hconst : ∀ y ∈ 𝒴.filter (fun y : ℕ => (y : ZMod s)⁻¹ = x),
        ‖F ((y : ZMod s)⁻¹)‖ ^ 2 = ‖F x‖ ^ 2 := by
      intro y hy; rw [(Finset.mem_filter.1 hy).2]
    rw [Finset.sum_congr rfl hconst, Finset.sum_const, nsmul_eq_mul]
    refine mul_le_mul_of_nonneg_right ?_ (sq_nonneg _)
    -- the fiber injects into the residue class of x⁻¹
    have hsub : 𝒴.filter (fun y : ℕ => (y : ZMod s)⁻¹ = x) ⊆
        (Finset.Icc 1 Y : Finset ℕ).filter (fun y : ℕ => ((y : ZMod s) = x⁻¹)) := by
      intro y hy
      rw [Finset.mem_filter] at hy ⊢
      refine ⟨h𝒴 hy.1, ?_⟩
      have hyu : (y : ZMod s) = ((ZMod.unitOfCoprime y (hcop y hy.1) : (ZMod s)ˣ) : ZMod s) :=
        (ZMod.coe_unitOfCoprime y (hcop y hy.1)).symm
      rw [← hy.2, hyu, ZMod.inv_coe_unit, ZMod.inv_coe_unit, inv_inv]
    calc ((𝒴.filter (fun y : ℕ => (y : ZMod s)⁻¹ = x)).card : ℝ)
        ≤ (((Finset.Icc 1 Y : Finset ℕ).filter (fun y : ℕ => ((y : ZMod s) = x⁻¹))).card : ℝ) := by
          exact_mod_cast Finset.card_le_card hsub
      _ ≤ _ := card_class_le Y x⁻¹
  -- Parseval over ZMod s
  have hpars : ∑ x : ZMod s, ‖F x‖ ^ 2 ≤
      s * ∑ n ∈ 𝒩, ∑ n' ∈ 𝒩, (if c * (ι n - ι n') = 0 then ‖b n‖ * ‖b n'‖ else 0) := by
    have hexp : ∀ x : ZMod s, ((‖F x‖ ^ 2 : ℝ) : ℂ) =
        ∑ n ∈ 𝒩, ∑ n' ∈ 𝒩, b n * (starRingEnd ℂ) (b n') * ψ (x * (c * (ι n - ι n'))) := by
      intro x
      rw [Complex.ofReal_pow, ← Complex.mul_conj']
      simp only [hF, map_sum, map_mul, conj_psi]
      rw [Finset.sum_mul_sum]
      refine Finset.sum_congr rfl fun n _ => Finset.sum_congr rfl fun n' _ => ?_
      rw [mul_mul_mul_comm, ← AddChar.map_add_eq_mul]
      congr 2; ring
    have hsumC : ((∑ x : ZMod s, ‖F x‖ ^ 2 : ℝ) : ℂ) =
        ∑ n ∈ 𝒩, ∑ n' ∈ 𝒩, b n * (starRingEnd ℂ) (b n') *
          (if c * (ι n - ι n') = 0 then (s : ℂ) else 0) := by
      rw [Complex.ofReal_sum]
      simp_rw [hexp]
      rw [Finset.sum_comm]
      refine Finset.sum_congr rfl fun n _ => ?_
      rw [Finset.sum_comm]
      refine Finset.sum_congr rfl fun n' _ => ?_
      rw [← Finset.mul_sum, orth]
    have hreal : ∑ x : ZMod s, ‖F x‖ ^ 2 = ‖((∑ x : ZMod s, ‖F x‖ ^ 2 : ℝ) : ℂ)‖ := by
      rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (Finset.sum_nonneg fun x _ => by positivity)]
    rw [hreal, hsumC, Finset.mul_sum]
    refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun n _ => ?_)
    rw [Finset.mul_sum]
    refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun n' _ => ?_)
    split_ifs with h
    · rw [norm_mul, norm_mul, Complex.norm_conj, Complex.norm_natCast]; ring_nf; rfl
    · simp
  calc _ ≤ (∑ y ∈ 𝒴, ‖a y‖ ^ 2) * ∑ y ∈ 𝒴, ‖F ((y : ZMod s)⁻¹)‖ ^ 2 := hCS
    _ ≤ (∑ y ∈ 𝒴, ‖a y‖ ^ 2) * (((Y : ℝ) / s + 1) * ∑ x : ZMod s, ‖F x‖ ^ 2) := by
        gcongr
    _ ≤ (∑ y ∈ 𝒴, ‖a y‖ ^ 2) * (((Y : ℝ) / s + 1) * (s * ∑ n ∈ 𝒩, ∑ n' ∈ 𝒩,
          (if c * (ι n - ι n') = 0 then ‖b n‖ * ‖b n'‖ else 0))) := by
        gcongr
    _ = _ := by ring

end GoldC.QuillonParseval

#print axioms GoldC.QuillonParseval.parseval_bilinear
