import PaperB.FixedQ.SignedForbiddenThalenExteriorExhaustion

open scoped BigOperators
open Filter

namespace PaperB.FixedQ

/-- The increasing active ordinary finite support at reduced height H.
The forbidden height decoration d is deleted in this source-safe support. -/
def thalenActiveOrdinaryFiniteSupport
    (q H : ℕ) (d : Finset ℕ) (N : ℕ) : Finset ℕ :=
  (Finset.range N).filter
    (fun p => activeHighPrime q p ∧ ¬ p ∣ H ∧ p ∉ d)

/-- Every subset of the finite support satisfies the literal active
ordinary mask. -/
theorem thalen_activeFiniteSupport_is_active
    (q H N : ℕ) (d n : Finset ℕ)
    (hn : n ∈ (thalenActiveOrdinaryFiniteSupport q H d N).powerset) :
    n ∈ activeOrdinaryTwoDimensionalSet q H := by
  have hnS := Finset.mem_powerset.mp hn
  refine ⟨ordinaryTwoDimensionalSet_iff.mpr ?_, ?_⟩
  · intro p hp
    exact (Finset.mem_filter.mp (hnS hp)).2.2.1
  · intro p hp
    exact (Finset.mem_filter.mp (hnS hp)).2.1

theorem thalen_activeFiniteSupport_disjoint
    (q H N : ℕ) (d : Finset ℕ) :
    Disjoint d (thalenActiveOrdinaryFiniteSupport q H d N) := by
  apply Finset.disjoint_left.mpr
  intro p hpd hp
  exact (Finset.mem_filter.mp hp).2.2.2 hpd

/-- The actual decorated source term vanishes on excluded supports,
including the active gate and the height-forbidden d mask. -/
theorem thalen_dForbidden_zero_outside_activeFiniteSupport
    (q A H N : ℕ) (d n : Finset ℕ)
    (hnrange : n ∈ (Finset.range N).powerset)
    (hnot : n ∉ (thalenActiveOrdinaryFiniteSupport q H d N).powerset) :
    dForbiddenReducedBooleanCoreTerm q A H d n = 0 := by
  by_cases hact : n ∈ activeOrdinaryTwoDimensionalSet q H
  · by_cases hdis : Disjoint d n
    · exfalso
      apply hnot
      apply Finset.mem_powerset.mpr
      intro p hp
      have hpRange : p ∈ Finset.range N :=
        (Finset.mem_powerset.mp hnrange) hp
      have hpActive := hact.2 p hp
      have hpOrd := ordinaryTwoDimensionalSet_iff.mp hact.1 p hp
      have hpDis : p ∉ d := by
        intro hpd
        exact Finset.disjoint_left.mp hdis hpd hp
      exact Finset.mem_filter.mpr
        ⟨hpRange, hpActive, hpOrd, hpDis⟩
    · simp [dForbiddenReducedBooleanCoreTerm, hdis]
  · have hz : ordinaryBooleanCoreTerm q A H n = 0 := by
      simp [ordinaryBooleanCoreTerm, Set.indicator, hact]
    simp [dForbiddenReducedBooleanCoreTerm, hz]

/-- Exact finite support transport: each raw powerset partial sum is
already the cutoff-restricted source on the active, d-disjoint support. -/
theorem thalen_reducedExterior_range_eq_activeFinite
    (q A H Z N : ℕ) (d : Finset ℕ) :
    (∑ n ∈ (Finset.range N).powerset,
      if Z < primeSetProduct n then
        dForbiddenReducedBooleanCoreTerm q A H d n
      else 0) =
    (∑ n ∈ (thalenActiveOrdinaryFiniteSupport q H d N).powerset.filter
         (fun n => Z < primeSetProduct n),
      dForbiddenReducedBooleanCoreTerm q A H d n) := by
  classical
  have hs :
      (thalenActiveOrdinaryFiniteSupport q H d N).powerset ⊆
        (Finset.range N).powerset :=
    Finset.powerset_mono.mpr (Finset.filter_subset _ _)
  calc
    _ = ∑ n ∈ (thalenActiveOrdinaryFiniteSupport q H d N).powerset,
      if Z < primeSetProduct n then
        dForbiddenReducedBooleanCoreTerm q A H d n
      else 0 := by
        symm
        apply Finset.sum_subset hs
        intro n hn hnot
        have hz := thalen_dForbidden_zero_outside_activeFiniteSupport
          q A H N d n hn hnot
        simp [hz]
    _ = _ := by
      rw [Finset.sum_filter]

#print axioms thalen_reducedExterior_range_eq_activeFinite

end PaperB.FixedQ
