import OrielUpper.RowCount
import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.ArithmeticFunction.Zeta
import Mathlib.Data.Nat.Totient
import Mathlib.Data.ZMod.Units

/-!
# Oriel Upper — the periodic row, ψ, and principal cancellation

`Λ : ZMod P → ℝ` is the periodic row weight.  For an orientation `(α, β)`, a fixed
modulus `m` and a pair of residues `(v, t)` we define
`rowF v t u = Λ(α + β v u) · 1[H ≡ t u (mod m)]` and
`ψ v t x = ∑_{1 ≤ u ≤ ⌊x⌋} rowF v t u - μ x / m`.

* `oriel_psi_bound`: `|ψ v t x| ≤ (2P+2) B` uniformly in `m` (for unit `v, t`).
* `oriel_principal_cancellation`: `|∑_{v,t units} ψ v t x| ≤ τ(m) (2P+1) φ(P) B`.
-/

open Finset ArithmeticFunction
open scoped ArithmeticFunction.Moebius ArithmeticFunction.zeta

namespace OrielUpper

variable {P : ℕ} [NeZero P]

/-- Mean of the periodic row. -/
noncomputable def muL (Λ : ZMod P → ℝ) : ℝ := (∑ z, Λ z) / P

/-- The oriented row term. -/
noncomputable def rowF (m H : ℕ) (Λ : ZMod P → ℝ) (α β : ZMod P) (v : ZMod P) (t : ZMod m)
    (u : ℕ) : ℝ :=
  Λ (α + β * v * u) * (if (H : ZMod m) = t * u then 1 else 0)

/-- The centered oriented partial sum ψ. -/
noncomputable def psiR (m H : ℕ) (Λ : ZMod P → ℝ) (α β : ZMod P) (v : ZMod P) (t : ZMod m)
    (x : ℝ) : ℝ :=
  ∑ u ∈ Icc 1 ⌊x⌋₊, rowF m H Λ α β v t u - muL Λ * x / m

lemma abs_muL_le {Λ : ZMod P → ℝ} {B : ℝ} (hB : ∀ z, |Λ z| ≤ B) : |muL Λ| ≤ B := by
  have hP : (0 : ℝ) < P := by exact_mod_cast NeZero.pos P
  unfold muL
  rw [abs_div, abs_of_pos hP, div_le_iff₀ hP]
  calc |∑ z, Λ z| ≤ ∑ z, |Λ z| := abs_sum_le_sum_abs _ _
    _ ≤ ∑ _z : ZMod P, B := sum_le_sum (fun z _ => hB z)
    _ = B * P := by rw [sum_const, card_univ, ZMod.card, nsmul_eq_mul, mul_comm]

/-- The row as a periodic sequence along an arithmetic progression of step a unit. -/
lemma sum_range_affine (Λ : ZMod P → ℝ) (c : ZMod P) (γ : (ZMod P)ˣ) :
    ∑ k ∈ range P, Λ (c + (γ : ZMod P) * (k : ℕ)) = ∑ z, Λ z := by
  rw [oriel_sum_range_zmod (fun z => Λ (c + (γ : ZMod P) * z)), oriel_sum_affine_unit]

/-- Uniform bound on ψ, independent of the modulus `m`. -/
theorem oriel_psi_bound {m H : ℕ} (hm : 0 < m) {Λ : ZMod P → ℝ} {B : ℝ}
    (hB : ∀ z, |Λ z| ≤ B) {α β v : ZMod P} {t : ZMod m}
    (hmP : IsUnit (m : ZMod P)) (hβ : IsUnit β) (hv : IsUnit v) (ht : IsUnit t)
    {x : ℝ} (hx : 0 ≤ x) :
    |psiR m H Λ α β v t x| ≤ (2 * P + 2) * B := by
  haveI : NeZero m := ⟨hm.ne'⟩
  have hP0 : 0 < P := NeZero.pos P
  have hPr : (0 : ℝ) < P := by exact_mod_cast hP0
  have hmr : (0 : ℝ) < m := by exact_mod_cast hm
  have hB0 : 0 ≤ B := le_trans (abs_nonneg _) (hB 0)
  set N := ⌊x⌋₊
  -- the target residue
  obtain ⟨tu, htu⟩ := ht
  set u0 : ℕ := (((tu⁻¹ : (ZMod m)ˣ) : ZMod m) * (H : ZMod m)).val with hu0def
  have hu0 : u0 < m := ZMod.val_lt _
  have hcond : ∀ u : ℕ, ((H : ZMod m) = t * u) ↔ u % m = u0 := by
    intro u
    rw [← htu]
    constructor
    · intro h
      have : (u : ZMod m) = ((tu⁻¹ : (ZMod m)ˣ) : ZMod m) * (H : ZMod m) := by
        rw [h, ← mul_assoc, Units.inv_mul, one_mul]
      rw [hu0def, ← this, ZMod.val_natCast]
    · intro h
      have : (u : ZMod m) = ((tu⁻¹ : (ZMod m)ˣ) : ZMod m) * (H : ZMod m) := by
        rw [← ZMod.natCast_zmod_val (((tu⁻¹ : (ZMod m)ˣ) : ZMod m) * (H : ZMod m)), ← hu0def,
          ← h, ZMod.natCast_mod]
      rw [this, ← mul_assoc, Units.mul_inv, one_mul]
  -- rewrite the row sum along the progression
  have hsum : ∑ u ∈ Icc 1 N, rowF m H Λ α β v t u =
      ∑ k ∈ Ico (kLo u0) (kHi N m u0), Λ (α + β * v * ((u0 + m * k : ℕ) : ZMod P)) := by
    rw [← oriel_sum_filter_mod hm hu0 N (fun u => Λ (α + β * v * (u : ZMod P))), sum_filter]
    apply sum_congr rfl
    intro u _
    unfold rowF
    by_cases h : u % m = u0
    · rw [if_pos ((hcond u).mpr h), if_pos h, mul_one]
    · rw [if_neg (fun h' => h ((hcond u).mp h')), if_neg h, mul_zero]
  -- the periodic sequence along `k`
  obtain ⟨γ, hγ⟩ : ∃ γ : (ZMod P)ˣ, (γ : ZMod P) = β * v * (m : ZMod P) :=
    ⟨(hβ.mul hv).mul hmP |>.unit, rfl⟩
  set h : ℕ → ℝ := fun k => Λ (α + β * v * ((u0 + m * k : ℕ) : ZMod P)) with hh
  have hform : ∀ k : ℕ, h k = Λ ((α + β * v * (u0 : ZMod P)) + (γ : ZMod P) * (k : ℕ)) := by
    intro k; rw [hh, hγ]; push_cast; ring_nf
  have hper : ∀ k, h (k + P) = h k := by
    intro k; rw [hform, hform]; push_cast; rw [ZMod.natCast_self]; ring_nf
  have hbd : ∀ k, |h k| ≤ B := fun k => hB _
  have hfull : ∑ z ∈ range P, h z = ∑ z, Λ z := by
    rw [sum_congr rfl (fun k _ => hform k), sum_range_affine]
  have hab : kLo u0 ≤ kHi N m u0 ∨ kHi N m u0 < kLo u0 := le_or_gt _ _
  -- periodic estimate
  have hper_est : |∑ k ∈ Ico (kLo u0) (kHi N m u0), h k -
      muL Λ * ((kHi N m u0 - kLo u0 : ℕ) : ℝ)| ≤ 2 * P * B := by
    rcases hab with hab | hab
    · have := oriel_periodic_Ico_sum hP0 hper hbd hab
      rw [hfull] at this
      simpa [muL] using this
    · rw [Ico_eq_empty_of_le hab.le, Nat.sub_eq_zero_of_le hab.le]; simp; positivity
  have hcount := oriel_count_mod_close hm hu0 N
  have hNx : |(N : ℝ) / m - x / m| ≤ 1 := by
    rw [← sub_div, abs_div, abs_of_pos hmr, div_le_one hmr]
    have h1 : (N : ℝ) ≤ x := Nat.floor_le hx
    have h2 : x < N + 1 := Nat.lt_floor_add_one x
    have : (1 : ℝ) ≤ m := by exact_mod_cast hm
    rw [abs_le]; constructor <;> linarith
  have hmu := abs_muL_le hB
  unfold psiR
  rw [hsum]
  set c := ((kHi N m u0 - kLo u0 : ℕ) : ℝ)
  have e : ∑ k ∈ Ico (kLo u0) (kHi N m u0), h k - muL Λ * x / m =
      (∑ k ∈ Ico (kLo u0) (kHi N m u0), h k - muL Λ * c) +
        muL Λ * ((c - N / m) + (N / m - x / m)) := by ring
  rw [e]
  calc |(∑ k ∈ Ico (kLo u0) (kHi N m u0), h k - muL Λ * c) +
        muL Λ * ((c - N / m) + (N / m - x / m))|
      ≤ |∑ k ∈ Ico (kLo u0) (kHi N m u0), h k - muL Λ * c| +
        |muL Λ| * (|c - N / m| + |N / m - x / m|) := by
        refine (abs_add_le _ _).trans ?_
        rw [abs_mul]
        gcongr
        exact abs_add_le _ _
    _ ≤ 2 * P * B + B * (1 + 1) := by gcongr
    _ = (2 * P + 2) * B := by ring

/-! ### Möbius tools -/

/-- Coprimality indicator via Möbius over divisors of `m`. -/
theorem oriel_coprime_indicator {m : ℕ} (hm : m ≠ 0) (u : ℕ) :
    (if Nat.Coprime u m then (1 : ℝ) else 0) =
      ∑ d ∈ m.divisors with d ∣ u, (μ d : ℝ) := by
  have hg : Nat.gcd u m ≠ 0 := Nat.gcd_ne_zero_right hm
  have hdiv : (m.divisors.filter (· ∣ u)) = (Nat.gcd u m).divisors := by
    ext d
    simp only [mem_filter, Nat.mem_divisors]
    constructor
    · rintro ⟨⟨hdm, _⟩, hdu⟩; exact ⟨Nat.dvd_gcd hdu hdm, hg⟩
    · rintro ⟨hd, _⟩
      exact ⟨⟨hd.trans (Nat.gcd_dvd_right u m), hm⟩, hd.trans (Nat.gcd_dvd_left u m)⟩
  rw [hdiv]
  have h := congrArg (fun f : ArithmeticFunction ℝ => f (Nat.gcd u m))
    (coe_moebius_mul_coe_zeta (R := ℝ))
  simp only [coe_mul_zeta_apply, one_apply] at h
  rw [show (∑ d ∈ (Nat.gcd u m).divisors, (μ d : ℝ)) =
      ∑ d ∈ (Nat.gcd u m).divisors, ((μ : ArithmeticFunction ℝ) d) by simp]
  rw [h]

/-- `φ(m) = ∑_{d∣m} μ(d) (m/d)`. -/
theorem oriel_totient_moebius {m : ℕ} (hm : m ≠ 0) :
    (Nat.totient m : ℝ) = ∑ d ∈ m.divisors, (μ d : ℝ) * ((m / d : ℕ) : ℝ) := by
  have h1 : (Nat.totient m : ℝ) = ∑ u ∈ Icc 1 m, (if Nat.Coprime u m then (1 : ℝ) else 0) := by
    rw [sum_ite, sum_const_zero, add_zero, sum_const, nsmul_eq_mul, mul_one]
    congr 1
    rw [← Nat.filter_coprime_Ico_eq_totient m 1]
    congr 1
    ext u; simp only [mem_filter, mem_Icc, mem_Ico]
    constructor
    · rintro ⟨⟨h1, h2⟩, h3⟩; exact ⟨⟨h1, by omega⟩, Nat.Coprime.symm h3⟩
    · rintro ⟨⟨h1, h2⟩, h3⟩; exact ⟨⟨h1, by omega⟩, Nat.Coprime.symm h3⟩
  rw [h1]
  simp_rw [oriel_coprime_indicator hm]
  rw [sum_comm' (t' := m.divisors) (s' := fun d => (Icc 1 m).filter (d ∣ ·))]
  · apply sum_congr rfl
    intro d hd
    rw [sum_const, nsmul_eq_mul, mul_comm]
    congr 1
    have : (Icc 1 m).filter (d ∣ ·) = (Ioc 0 m).filter (d ∣ ·) := by
      ext u; simp only [mem_filter, mem_Icc, mem_Ioc]; omega
    rw [this, Nat.Ioc_filter_dvd_card_eq_div]
  · intro u d
    simp only [mem_filter, mem_Icc]
    tauto

end OrielUpper
