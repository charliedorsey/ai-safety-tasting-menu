import PaperB.FixedQ.H2BooleanFinalAssembly

namespace PaperB.FixedQ

noncomputable def sourceVaalerCutoff (M : ℕ) : ℕ :=
  ⌊(Real.log (M : ℝ)) ^ (10 : ℕ)⌋₊

lemma sourceVaalerCutoff_one_le
    {M : ℕ} (hlog : 1 ≤ Real.log (M : ℝ)) :
    1 ≤ sourceVaalerCutoff M := by
  unfold sourceVaalerCutoff
  apply (Nat.one_le_floor_iff _).2
  have hp : (1 : ℝ) ≤ (Real.log (M : ℝ)) ^ (10 : ℕ) := by
    exact one_le_pow₀ hlog
  exact hp

lemma sourceVaalerCutoff_cast_le_log_pow
    {M : ℕ} (hlog0 : 0 ≤ Real.log (M : ℝ)) :
    (sourceVaalerCutoff M : ℝ) ≤
      (Real.log (M : ℝ)) ^ (10 : ℕ) := by
  unfold sourceVaalerCutoff
  exact Nat.floor_le (pow_nonneg hlog0 _)

lemma sourceVaalerCutoff_half_log_pow_le
    {M : ℕ} (hlog : 2 ≤ Real.log (M : ℝ)) :
    ((Real.log (M : ℝ)) ^ (10 : ℕ)) / 2 ≤
      (sourceVaalerCutoff M : ℝ) := by
  unfold sourceVaalerCutoff
  let X : ℝ := (Real.log (M : ℝ)) ^ (10 : ℕ)
  have hX2 : 2 ≤ X := by
    dsimp [X]
    have hpow : (2 : ℝ) ^ (10 : ℕ) ≤
        (Real.log (M : ℝ)) ^ (10 : ℕ) :=
      pow_le_pow_left₀ (by norm_num) hlog 10
    norm_num at hpow ⊢
    linarith
  have hsub : X - 1 < (⌊X⌋₊ : ℝ) := by
    exact_mod_cast Nat.sub_one_lt_floor X
  dsimp [X] at hsub ⊢
  linarith

lemma sourceVaalerCutoff_log_le_ten_loglog
    {M : ℕ}
    (hlog : 1 ≤ Real.log (M : ℝ)) :
    Real.log (sourceVaalerCutoff M : ℝ) ≤
      10 * Real.log (Real.log (M : ℝ)) := by
  have hJ1 := sourceVaalerCutoff_one_le hlog
  have hJpos : (0 : ℝ) < sourceVaalerCutoff M := by
    exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hJ1)
  have hLpos : 0 < Real.log (M : ℝ) := lt_of_lt_of_le zero_lt_one hlog
  have hPowPos : 0 < (Real.log (M : ℝ)) ^ (10 : ℕ) := pow_pos hLpos _
  have hle := sourceVaalerCutoff_cast_le_log_pow
    (le_trans (by norm_num) hlog)
  calc
    Real.log (sourceVaalerCutoff M : ℝ)
      ≤ Real.log ((Real.log (M : ℝ)) ^ (10 : ℕ)) :=
        Real.strictMonoOn_log.monotoneOn hJpos hPowPos hle
    _ = 10 * Real.log (Real.log (M : ℝ)) := by
      rw [Real.log_pow]
      norm_num

#print axioms sourceVaalerCutoff_half_log_pow_le
#print axioms sourceVaalerCutoff_log_le_ten_loglog

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma sourceVaalerCutoff_one_add_log_le_eleven_loglog
    {M : ℕ}
    (hlog : 1 ≤ Real.log (M : ℝ))
    (hll : 1 ≤ Real.log (Real.log (M : ℝ))) :
    1 + Real.log (sourceVaalerCutoff M : ℝ) ≤
      11 * Real.log (Real.log (M : ℝ)) := by
  have hcut := sourceVaalerCutoff_log_le_ten_loglog hlog
  linarith

lemma sourceVaalerCutoff_loglog_power_le_four
    {M : ℕ}
    (hlog : 1 ≤ Real.log (M : ℝ))
    (hll : 1 ≤ Real.log (Real.log (M : ℝ))) :
    (1 + Real.log (sourceVaalerCutoff M : ℝ)) ^
        (h2BooleanV0 / 2 + 2) ≤
      (11 : ℝ) ^ (h2BooleanV0 / 2 + 2) *
        (Real.log (Real.log (M : ℝ))) ^ (4 : ℝ) := by
  let L := Real.log (Real.log (M : ℝ))
  have hL0 : 0 ≤ L := le_trans (by norm_num) hll
  have hleft0 :
      0 ≤ 1 + Real.log (sourceVaalerCutoff M : ℝ) := by
    have hJ1 := sourceVaalerCutoff_one_le hlog
    have hJ1R : (1 : ℝ) ≤ (sourceVaalerCutoff M : ℝ) := by
      exact_mod_cast hJ1
    have hlogJ0 := Real.log_nonneg hJ1R
    linarith
  have hbase := sourceVaalerCutoff_one_add_log_le_eleven_loglog hlog hll
  have hexp0 : 0 ≤ h2BooleanV0 / 2 + 2 := by
    have := h2BooleanV0_nonneg
    linarith
  calc
    (1 + Real.log (sourceVaalerCutoff M : ℝ)) ^
        (h2BooleanV0 / 2 + 2)
      ≤ (11 * L) ^ (h2BooleanV0 / 2 + 2) :=
        Real.rpow_le_rpow hleft0 hbase hexp0
    _ = (11 : ℝ) ^ (h2BooleanV0 / 2 + 2) *
        L ^ (h2BooleanV0 / 2 + 2) := by
          rw [Real.mul_rpow (by norm_num) hL0]
    _ ≤ (11 : ℝ) ^ (h2BooleanV0 / 2 + 2) * L ^ (4 : ℝ) := by
          apply mul_le_mul_of_nonneg_left
          · exact Real.rpow_le_rpow_of_exponent_le hll
              h2BooleanV0_half_add_two_le_four
          · positivity
    _ = _ := by rfl

#print axioms sourceVaalerCutoff_loglog_power_le_four

end PaperB.FixedQ
