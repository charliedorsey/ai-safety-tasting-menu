import PaperB.FixedQ.SignedForbiddenActiveSourceBridge
import PaperB.FixedQ.SignedForbiddenMainRate

namespace PaperB.FixedQ

theorem abs_sourceForbiddenBooleanMainTerm_le_empty
    {q a H : ℕ} {d n : Finset ℕ} :
    |sourceForbiddenBooleanMainTerm q a H d n| ≤
      |sourceForbiddenBooleanMainTerm q a H ∅ n| := by
  classical
  by_cases hne : n.Nonempty
  · by_cases hcopD :
      (primeSetProduct n).Coprime
        (H * (6 * q) * primeSetProduct d)
    · have hcopBase :
        (primeSetProduct n).Coprime (H * (6 * q)) :=
        (Nat.coprime_mul_iff_right.mp hcopD).1
      have hcop0 :
        (primeSetProduct n).Coprime
          (H * (6 * q) * primeSetProduct ∅) := by
        simpa [primeSetProduct] using hcopBase
      rw [sourceForbiddenBooleanMainTerm, if_pos ⟨hcopD, hne⟩]
      rw [sourceForbiddenBooleanMainTerm, if_pos ⟨hcop0, hne⟩]
    · rw [sourceForbiddenBooleanMainTerm, if_neg (fun hc => hcopD hc.1)]
      simpa using (abs_nonneg (sourceForbiddenBooleanMainTerm q a H ∅ n))
  · simp [sourceForbiddenBooleanMainTerm, hne]

#print axioms abs_sourceForbiddenBooleanMainTerm_le_empty

end PaperB.FixedQ
