import PaperB.FixedQ.PrincipalOneDimensionalCancellation

namespace PaperB.FixedQ

lemma eidra_freeReduced_period_eq_zero
    (q r : ℕ) :
    freeReducedFixedQLowWeight q r (fixedQPeriod q) =
      freeReducedFixedQLowWeight q r 0 := by
  have h := (freeReducedFixedQLowWeight_periodic q r) 0
  simpa using h

lemma eidra_freeReduced_zero_eq_lowFactor
    {q r : ℕ} (hr : q.Coprime r) :
    freeReducedFixedQLowWeight q r 0 = freeLowPrimeFactor q 0 := by
  unfold freeReducedFixedQLowWeight freeFixedQLowWeight freeLowPrimeFactor
  simp [hr]

lemma eidra_freeReduced_period_eq_lowFactor
    {q r : ℕ} (hr : q.Coprime r) :
    freeReducedFixedQLowWeight q r (fixedQPeriod q) =
      freeLowPrimeFactor q 0 := by
  rw [eidra_freeReduced_period_eq_zero]
  exact eidra_freeReduced_zero_eq_lowFactor hr

theorem s1PrincipalCoefficient_eq_explicit
    (q r : ℕ) (hq : 0 < q) [NeZero (fixedQPeriod q)] :
    freeHighBaseline q *
        principalBoundaryAverage (fixedQPeriod q)
          (freeReducedFixedQLowWeight q r) *
        logarithmicEulerResidue (etaCoeff q) =
      - (1 / 2 : ℝ) *
        ((Nat.totient (fixedQPeriod q) : ℝ) /
          (fixedQPeriod q : ℝ)) *
        freeReducedFixedQLowWeight q r (fixedQPeriod q) := by
  rw [principalBoundaryAverage_eq_zero_residue]
  have hhigh := principalHighCoefficient_eta q hq
  calc
    freeHighBaseline q *
        (-(1 / 2 : ℝ) *
          freeReducedFixedQLowWeight q r (fixedQPeriod q)) *
        logarithmicEulerResidue (etaCoeff q) =
      -(1 / 2 : ℝ) *
        freeReducedFixedQLowWeight q r (fixedQPeriod q) *
        (freeHighBaseline q * logarithmicEulerResidue (etaCoeff q)) := by ring
    _ = -(1 / 2 : ℝ) *
        freeReducedFixedQLowWeight q r (fixedQPeriod q) *
        ((Nat.totient (fixedQPeriod q) : ℝ) /
          (fixedQPeriod q : ℝ)) := by rw [hhigh]
    _ = _ := by ring

theorem s1PrincipalCoefficient_eq_fixedQ
    {q r : ℕ} (hq : 0 < q) [NeZero (fixedQPeriod q)]
    (hr : q.Coprime r) :
    freeHighBaseline q *
        principalBoundaryAverage (fixedQPeriod q)
          (freeReducedFixedQLowWeight q r) *
        logarithmicEulerResidue (etaCoeff q) =
      - (1 / 2 : ℝ) *
        ((Nat.totient (fixedQPeriod q) : ℝ) /
          (fixedQPeriod q : ℝ)) *
        freeLowPrimeFactor q 0 := by
  rw [s1PrincipalCoefficient_eq_explicit q r hq]
  rw [eidra_freeReduced_period_eq_lowFactor hr]

#print axioms s1PrincipalCoefficient_eq_fixedQ

end PaperB.FixedQ
