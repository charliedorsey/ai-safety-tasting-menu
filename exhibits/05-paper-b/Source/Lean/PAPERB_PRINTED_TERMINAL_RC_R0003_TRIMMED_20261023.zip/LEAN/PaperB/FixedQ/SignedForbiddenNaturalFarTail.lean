import PaperB.FixedQ.SignedForbiddenNaturalBridge

open scoped BigOperators

namespace PaperB.FixedQ

lemma rowConstrainedMass_eq_zero_of_height_le_left
    (lambda : ℕ → ℝ) {H e1 e2 : ℕ}
    (hHe : H ≤ e1) :
    rowConstrainedMass lambda H e1 e2 = 0 := by
  unfold rowConstrainedMass
  apply Finset.sum_eq_zero
  intro y hy
  have hyI := Finset.mem_Ioo.mp hy
  by_cases hc : e1 ∣ y ∧ e2 ∣ H - y
  · rw [if_pos hc]
    have he1y : e1 ≤ y := Nat.le_of_dvd hyI.1 hc.1
    omega
  · rw [if_neg hc]

lemma rowConstrainedMass_eq_zero_of_height_le_right
    (lambda : ℕ → ℝ) {H e1 e2 : ℕ}
    (hHe : H ≤ e2) :
    rowConstrainedMass lambda H e1 e2 = 0 := by
  unfold rowConstrainedMass
  apply Finset.sum_eq_zero
  intro y hy
  have hyI := Finset.mem_Ioo.mp hy
  by_cases hc : e1 ∣ y ∧ e2 ∣ H - y
  · rw [if_pos hc]
    have hsubpos : 0 < H - y := Nat.sub_pos_of_lt hyI.2
    have he2sub : e2 ≤ H - y := Nat.le_of_dvd hsubpos hc.2
    omega
  · rw [if_neg hc]

lemma rowDiscrepancy_eq_neg_density_of_height_le
    (lambda : ℕ → ℝ) {H e1 e2 : ℕ}
    (h : H ≤ e1 ∨ H ≤ e2) :
    rowDiscrepancy lambda H e1 e2 =
      - rowWeightMass lambda H / ((e1 : ℝ) * (e2 : ℝ)) := by
  unfold rowDiscrepancy
  rcases h with h | h
  · rw [rowConstrainedMass_eq_zero_of_height_le_left lambda h]
    ring
  · rw [rowConstrainedMass_eq_zero_of_height_le_right lambda h]
    ring

lemma fixedProductPartitionDiscrepancy_eq_neg_density_of_product_gt_sq
    (lambda : ℕ → ℝ) {H : ℕ} {S A : Finset ℕ}
    (hPrime : ∀ p ∈ S, p.Prime)
    (hA : A ⊆ S)
    (hgt : H ^ 2 < primeSetProduct S) :
    fixedProductPartitionDiscrepancy lambda H S A =
      - rowWeightMass lambda H / (primeSetProduct S : ℝ) := by
  let e1 := primeSetProduct A
  let e2 := primeSetProduct (S \ A)
  have hprod : e1 * e2 = primeSetProduct S := by
    simpa [e1, e2, fixedProductModulus] using
      pair_moduli_product_eq_fixedProduct hA hPrime
  have hlarge : H ≤ e1 ∨ H ≤ e2 := by
    by_contra h
    push_neg at h
    have hmul : e1 * e2 < H ^ 2 := by
      nlinarith
    omega
  unfold fixedProductPartitionDiscrepancy
  rw [rowDiscrepancy_eq_neg_density_of_height_le lambda hlarge]
  rw [← Nat.cast_mul, hprod]

theorem fixedProductBooleanDiscrepancy_eq_neg_density_of_product_gt_sq
    (lambda : ℕ → ℝ) {H : ℕ} {S : Finset ℕ}
    (hPrime : ∀ p ∈ S, p.Prime)
    (hgt : H ^ 2 < primeSetProduct S) :
    fixedProductBooleanDiscrepancy lambda H S =
      - rowWeightMass lambda H / (primeSetProduct S : ℝ) := by
  have hpow0 : (2 : ℝ) ^ S.card ≠ 0 := by positivity
  unfold fixedProductBooleanDiscrepancy
  have hsum :
      (∑ A ∈ S.powerset,
        fixedProductPartitionDiscrepancy lambda H S A) =
      (S.powerset.card : ℝ) *
        (- rowWeightMass lambda H / (primeSetProduct S : ℝ)) := by
    calc
      (∑ A ∈ S.powerset,
        fixedProductPartitionDiscrepancy lambda H S A)
        = ∑ A ∈ S.powerset,
            (- rowWeightMass lambda H / (primeSetProduct S : ℝ)) := by
              apply Finset.sum_congr rfl
              intro A hA
              exact fixedProductPartitionDiscrepancy_eq_neg_density_of_product_gt_sq
                lambda hPrime (Finset.mem_powerset.mp hA) hgt
      _ = (S.powerset.card : ℝ) *
          (- rowWeightMass lambda H / (primeSetProduct S : ℝ)) := by
            rw [Finset.sum_const, nsmul_eq_mul]
  rw [hsum, Finset.card_powerset]
  norm_cast
  field_simp [hpow0]

#print axioms fixedProductBooleanDiscrepancy_eq_neg_density_of_product_gt_sq

end PaperB.FixedQ
