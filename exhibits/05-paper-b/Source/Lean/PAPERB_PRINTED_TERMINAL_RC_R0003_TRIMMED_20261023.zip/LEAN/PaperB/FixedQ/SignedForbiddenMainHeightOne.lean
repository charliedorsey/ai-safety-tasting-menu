import PaperB.FixedQ.SignedForbiddenMainSmallHeight

namespace PaperB.FixedQ

theorem rowDiscrepancy_height_one
    (lambda : ℕ → ℝ) (e1 e2 : ℕ) :
    rowDiscrepancy lambda 1 e1 e2 = 0 := by
  have hempty : Finset.Ioo 0 1 = ∅ := by
    ext y
    simp
    omega
  simp [rowDiscrepancy, rowConstrainedMass, rowWeightMass, hempty]

theorem fixedProductPartitionDiscrepancy_height_one
    (lambda : ℕ → ℝ) (S A : Finset ℕ) :
    fixedProductPartitionDiscrepancy lambda 1 S A = 0 := by
  unfold fixedProductPartitionDiscrepancy
  exact rowDiscrepancy_height_one _ _ _

theorem fixedProductBooleanDiscrepancy_height_one
    (lambda : ℕ → ℝ) (S : Finset ℕ) :
    fixedProductBooleanDiscrepancy lambda 1 S = 0 := by
  unfold fixedProductBooleanDiscrepancy
  simp [fixedProductPartitionDiscrepancy_height_one]

theorem dForbiddenBooleanMainTerm_height_one
    (q A : ℕ) (d n : Finset ℕ) :
    dForbiddenBooleanMainTerm q A 1 d n = 0 := by
  unfold dForbiddenBooleanMainTerm
  split_ifs with h
  · simp [fixedProductBooleanDiscrepancy_height_one]
  · rfl

theorem tsum_dForbiddenBooleanMainTerm_height_one
    (q A : ℕ) (d : Finset ℕ) :
    (∑' n : Finset ℕ, dForbiddenBooleanMainTerm q A 1 d n) = 0 := by
  simp [dForbiddenBooleanMainTerm_height_one]

#print axioms tsum_dForbiddenBooleanMainTerm_height_one

end PaperB.FixedQ
