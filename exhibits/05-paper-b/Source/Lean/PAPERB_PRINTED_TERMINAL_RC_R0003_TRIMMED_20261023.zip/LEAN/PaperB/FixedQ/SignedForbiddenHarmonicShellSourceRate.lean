import PaperB.FixedQ.SignedForbiddenHarmonicShell
import PaperB.FixedQ.SignedForbiddenPeriodicTwistMoment
import PaperB.FixedQ.H2BooleanRateNormalization
import PaperB.FixedQ.SignedForbiddenSourceVaalerCutoff

open scoped BigOperators

namespace PaperB.FixedQ

theorem sourcePeriodicHarmonicShell_sourceCutoff_le_rate_of_conditions
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ M0 : ℕ,
      0 ≤ C ∧
      ∀ H M : ℕ,
        M0 ≤ M →
        3 ≤ M →
        4 ≤ h2BooleanRoughCutoff M →
        3 ≤ Nat.nthRoot 4 M →
        (h2BooleanRoughCutoff M) ^ 2 ≤ M →
        ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
        ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
        2 ≤ Real.log (M : ℝ) →
        1 ≤ Real.log (Real.log (M : ℝ)) →
        h2BooleanTailCorrectionConst ≤
          (1 / 8 : ℝ) *
            (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) →
        Real.exp (-(1 / 8 : ℝ) *
            (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) ≤
          (Real.log (M : ℝ)) ^ (-4 : ℝ) →
        (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
          finiteOmegaWeightReal S * (2 : ℝ) ^ S.card *
            sourcePeriodicHarmonicMass
              q H (sourceVaalerCutoff M) S) ≤
          C * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
            (Real.log (Real.log (M : ℝ))) ^ 2 := by
  rcases h2BooleanDyadicFirstWeightMoment_le_log_rate q hq with
    ⟨C1, M1, hC1, hFirst⟩
  rcases fixedQPeriodicTotalTwist_dyadicSecondMoment_le q hq with
    ⟨M2, hMoment⟩
  let C2 : ℝ :=
    h2BooleanSecondMomentRateConstant q *
      (11 : ℝ) ^ (h2BooleanV0 / 2 + 2)
  let C : ℝ := C1 * C2 + 1
  refine ⟨C, max M1 M2, ?_, ?_⟩
  · dsimp [C, C2]
    have hC2 : 0 ≤
        h2BooleanSecondMomentRateConstant q *
          (11 : ℝ) ^ (h2BooleanV0 / 2 + 2) := by
      exact mul_nonneg
        (h2BooleanSecondMomentRateConstant_nonneg_public q)
        (Real.rpow_nonneg (by norm_num) _)
    nlinarith [mul_nonneg hC1 hC2]
  · intro H M hM0 hM3 hY4 hroot hYsq hquarter hqM
      hlog2 hll hTail hdec
    have hM2 : 2 ≤ M := by omega
    have hM1 : M1 ≤ M := (le_max_left M1 M2).trans hM0
    have hM2' : M2 ≤ M := (le_max_right M1 M2).trans hM0
    have hlog1 : 1 ≤ Real.log (M : ℝ) := by linarith
    let J : ℕ := sourceVaalerCutoff M
    have hJ1 : 1 ≤ J := by
      dsimp [J]
      exact sourceVaalerCutoff_one_le hlog1
    let G := h2BooleanDyadicSets q M
    let F := h2BooleanOrdinaryDyadicSets q H M
    let X : ℝ := (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1)
    let LL : ℝ := Real.log (Real.log (M : ℝ))
    let Shell : ℝ :=
      ∑ S ∈ F,
        finiteOmegaWeightReal S * (2 : ℝ) ^ S.card *
          sourcePeriodicHarmonicMass q H J S
    have hFirstRate :
        (∑ S ∈ G,
          finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) ≤
          C1 * X := by
      simpa [G, X] using
        hFirst M hM1 hM2 hquarter hqM hlog1
    have hMomentPoint : ∀ j ∈ Finset.Icc 1 J,
        h2BooleanDyadicFrequencySecondMomentTwisted
            q M j (fixedQPeriodicTotalTwist q H) ≤
          h2BooleanFrequencySecondMomentMajorantAll q M j := by
      intro j hj
      have hj1 := (Finset.mem_Icc.mp hj).1
      exact hMoment H M j hM2' hM2 hY4 hj1 hroot hYsq
        hquarter hqM hlog1 hTail
    have hMomentSum :
        (∑ j ∈ Finset.Icc 1 J,
          h2BooleanDyadicFrequencySecondMomentTwisted
            q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ)) ≤
        ∑ j ∈ Finset.Icc 1 J,
          h2BooleanFrequencySecondMomentMajorantAll q M j / (j : ℝ) := by
      apply Finset.sum_le_sum
      intro j hj
      have hj1 := (Finset.mem_Icc.mp hj).1
      have hj0 : (0 : ℝ) ≤ (j : ℝ) := by positivity
      exact div_le_div_of_nonneg_right (hMomentPoint j hj) hj0
    have hlogJ0 : 0 ≤ 1 + Real.log (J : ℝ) := by
      have hJR : (1 : ℝ) ≤ (J : ℝ) := by exact_mod_cast hJ1
      linarith [Real.log_nonneg hJR]
    have hMomentET :
        (1 + Real.log (J : ℝ)) *
          (∑ j ∈ Finset.Icc 1 J,
            h2BooleanDyadicFrequencySecondMomentTwisted
              q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ)) ≤
        h2BooleanSecondMomentRateConstant q *
          (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
          (1 + Real.log (J : ℝ)) ^ (h2BooleanV0 / 2 + 2) := by
      calc
        (1 + Real.log (J : ℝ)) *
            (∑ j ∈ Finset.Icc 1 J,
              h2BooleanDyadicFrequencySecondMomentTwisted
                q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ))
          ≤ (1 + Real.log (J : ℝ)) *
            (∑ j ∈ Finset.Icc 1 J,
              h2BooleanFrequencySecondMomentMajorantAll q M j /
                (j : ℝ)) :=
              mul_le_mul_of_nonneg_left hMomentSum hlogJ0
        _ ≤ _ := h2BooleanETMomentMajorant_le_rate
          q M J hM3 hlog1 hJ1 hdec
    have hETpow :
        (1 + Real.log (J : ℝ)) ^ (h2BooleanV0 / 2 + 2) ≤
          (11 : ℝ) ^ (h2BooleanV0 / 2 + 2) *
            LL ^ (4 : ℝ) := by
      simpa [J, LL] using
        sourceVaalerCutoff_loglog_power_le_four hlog1 hll
    have hX0 : 0 ≤ X := by
      dsimp [X]
      exact Real.rpow_nonneg (Real.log_nonneg (by
        exact_mod_cast (show 1 ≤ M by omega))) _
    have hRateConst0 :
        0 ≤ h2BooleanSecondMomentRateConstant q *
          (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) := by
      exact mul_nonneg
        (h2BooleanSecondMomentRateConstant_nonneg_public q) hX0
    have hMomentRate :
        (1 + Real.log (J : ℝ)) *
          (∑ j ∈ Finset.Icc 1 J,
            h2BooleanDyadicFrequencySecondMomentTwisted
              q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ)) ≤
          C2 * X * LL ^ (4 : ℝ) := by
      calc
        _ ≤ h2BooleanSecondMomentRateConstant q *
            (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
            (1 + Real.log (J : ℝ)) ^ (h2BooleanV0 / 2 + 2) :=
              hMomentET
        _ ≤ h2BooleanSecondMomentRateConstant q *
            (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
            ((11 : ℝ) ^ (h2BooleanV0 / 2 + 2) * LL ^ (4 : ℝ)) := by
              exact mul_le_mul_of_nonneg_left hETpow hRateConst0
        _ = C2 * X * LL ^ (4 : ℝ) := by
              dsimp [C2, X]
              ring
    have hShellSq :
        Shell ^ 2 ≤
          (∑ S ∈ G,
            finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) *
          ((1 + Real.log (J : ℝ)) *
            (∑ j ∈ Finset.Icc 1 J,
              h2BooleanDyadicFrequencySecondMomentTwisted
                q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ))) := by
      simpa [Shell, F, G, J] using
        sourcePeriodicHarmonicMass_shell_sq_le q H M J hJ1
    have hMomentRate0 : 0 ≤
        (1 + Real.log (J : ℝ)) *
          (∑ j ∈ Finset.Icc 1 J,
            h2BooleanDyadicFrequencySecondMomentTwisted
              q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ)) := by
      exact mul_nonneg hlogJ0 (by
        apply Finset.sum_nonneg
        intro j hj
        exact div_nonneg
          (by
            unfold h2BooleanDyadicFrequencySecondMomentTwisted
            apply Finset.sum_nonneg
            intro S hS
            have hActive := h2BooleanDyadicSets_active hS
            exact mul_nonneg
              (mul_nonneg
                (finiteOmegaWeightReal_nonneg_of_active hActive)
                (pow_nonneg h2BooleanV0_nonneg _))
              (h2BooleanFourierNormSqTwisted_nonneg
                q S j (fixedQPeriodicTotalTwist q H S)))
          (by positivity))
    have hC1X0 : 0 ≤ C1 * X := mul_nonneg hC1 hX0
    have hSq :
        Shell ^ 2 ≤ (C1 * X) * (C2 * X * LL ^ (4 : ℝ)) := by
      calc
        Shell ^ 2
          ≤ (∑ S ∈ G,
              finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) *
            ((1 + Real.log (J : ℝ)) *
              (∑ j ∈ Finset.Icc 1 J,
                h2BooleanDyadicFrequencySecondMomentTwisted
                  q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ))) :=
            hShellSq
        _ ≤ (C1 * X) *
            ((1 + Real.log (J : ℝ)) *
              (∑ j ∈ Finset.Icc 1 J,
                h2BooleanDyadicFrequencySecondMomentTwisted
                  q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ))) :=
            mul_le_mul_of_nonneg_right hFirstRate hMomentRate0
        _ ≤ (C1 * X) * (C2 * X * LL ^ (4 : ℝ)) :=
            mul_le_mul_of_nonneg_left hMomentRate hC1X0
    have hLL1 : 1 ≤ LL := by simpa [LL] using hll
    have hLL0 : 0 ≤ LL := le_trans (by norm_num) hLL1
    have hLL4 : LL ^ (4 : ℝ) = LL ^ (4 : ℕ) := Real.rpow_natCast LL 4
    let K : ℝ := C1 * C2
    let Z : ℝ := X ^ 2 * LL ^ (4 : ℕ)
    have hC2 : 0 ≤ C2 := by
      dsimp [C2]
      exact mul_nonneg
        (h2BooleanSecondMomentRateConstant_nonneg_public q)
        (Real.rpow_nonneg (by norm_num) _)
    have hK0 : 0 ≤ K := by dsimp [K]; exact mul_nonneg hC1 hC2
    have hZ0 : 0 ≤ Z := by dsimp [Z]; positivity
    have hKle : K ≤ (K + 1)^2 := by nlinarith [sq_nonneg K]
    have hProd :
        (C1 * X) * (C2 * X * LL ^ (4 : ℝ)) ≤
          (C * X * LL ^ 2)^2 := by
      have hleft :
          (C1 * X) * (C2 * X * LL ^ (4 : ℝ)) = K * Z := by
        rw [hLL4]
        dsimp [K, Z]
        ring
      have hright :
          (C * X * LL ^ 2)^2 = (K + 1)^2 * Z := by
        dsimp [C, K, Z]
        ring
      rw [hleft, hright]
      exact mul_le_mul_of_nonneg_right hKle hZ0
    have hC0 : 0 ≤ C := by
      dsimp [C]
      exact add_nonneg (mul_nonneg hC1 hC2) (by norm_num)
    have hTarget0 : 0 ≤ C * X * LL ^ 2 :=
      mul_nonneg (mul_nonneg hC0 hX0) (sq_nonneg LL)
    have hShell : Shell ≤ C * X * LL ^ 2 :=
      le_of_sq_le_sq (hSq.trans hProd) hTarget0
    simpa [Shell, F, J, C, X, LL] using hShell

#print axioms sourcePeriodicHarmonicShell_sourceCutoff_le_rate_of_conditions

end PaperB.FixedQ
