import PaperB.FixedQ.H2BooleanAffineET

open scoped BigOperators ComplexConjugate

namespace PaperB.FixedQ

noncomputable def fixedProductProperFourierCoeff
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (t : ZMod (primeSetProduct S)) : ℂ := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  exact ((2 : ℂ) ^ S.card)⁻¹ *
    ∑ A ∈ ((S.powerset.erase S).erase ∅),
      ZMod.stdAddChar
        (t * (fixedProductCRTIdempotentNat S A :
          ZMod (primeSetProduct S)))

lemma fixedProductCRTIdempotentNat_full_cast
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime) :
    (fixedProductCRTIdempotentNat S S :
      ZMod (primeSetProduct S)) = 0 := by
  have hspec :=
    fixedProductCRTIdempotentNat_specs
      (S := S) (A := S) (by simp) hPrime
  have hmod :
      fixedProductCRTIdempotentNat S S ≡ 0 [MOD primeSetProduct S] :=
    hspec.1
  simpa using
    (ZMod.natCast_eq_natCast_iff
      (fixedProductCRTIdempotentNat S S) 0 (primeSetProduct S)).2 hmod

lemma fixedProductCRTIdempotentNat_empty_cast
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime) :
    (fixedProductCRTIdempotentNat S ∅ :
      ZMod (primeSetProduct S)) = 1 := by
  have hspec :=
    fixedProductCRTIdempotentNat_specs
      (S := S) (A := ∅) (by simp) hPrime
  have hmod :
      fixedProductCRTIdempotentNat S ∅ ≡ 1 [MOD primeSetProduct S] := by
    simpa using hspec.2
  simpa using
    (ZMod.natCast_eq_natCast_iff
      (fixedProductCRTIdempotentNat S ∅) 1 (primeSetProduct S)).2 hmod

theorem fixedProductProperFourierCoeff_eq_full_sub_endpoints
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (hS : S.Nonempty)
    (t : ZMod (primeSetProduct S)) :
    fixedProductProperFourierCoeff S hPrime t =
      fixedProductBooleanFourierCoeff S hPrime t -
        ((2 : ℂ) ^ S.card)⁻¹ *
          (1 + ZMod.stdAddChar t) := by
  classical
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  let F : Finset ℕ → ℂ := fun A =>
    ZMod.stdAddChar
      (t * (fixedProductCRTIdempotentNat S A :
        ZMod (primeSetProduct S)))
  have hSne : S ≠ ∅ := Finset.nonempty_iff_ne_empty.mp hS
  have hSmem : S ∈ S.powerset :=
    Finset.mem_powerset.mpr (by simp)
  have h0mem : ∅ ∈ S.powerset.erase S := by
    exact Finset.mem_erase.mpr
      ⟨by simpa [eq_comm] using hSne,
        Finset.mem_powerset.mpr (by simp)⟩
  have hsumS := Finset.sum_erase_add S.powerset F hSmem
  have hsum0 := Finset.sum_erase_add (S.powerset.erase S) F h0mem
  have hFS : F S = 1 := by
    dsimp [F]
    rw [fixedProductCRTIdempotentNat_full_cast S hPrime]
    simp
  have hF0 : F ∅ = ZMod.stdAddChar t := by
    dsimp [F]
    rw [fixedProductCRTIdempotentNat_empty_cast S hPrime]
    simp
  have hsum :
      (∑ A ∈ S.powerset, F A) =
        (∑ A ∈ ((S.powerset.erase S).erase ∅), F A) +
          (1 + ZMod.stdAddChar t) := by
    calc
      (∑ A ∈ S.powerset, F A) =
          (∑ A ∈ S.powerset.erase S, F A) + F S := hsumS.symm
      _ = ((∑ A ∈ ((S.powerset.erase S).erase ∅), F A) + F ∅) +
          F S := by rw [hsum0]
      _ = _ := by rw [hFS, hF0]; ring
  unfold fixedProductProperFourierCoeff fixedProductBooleanFourierCoeff
  rw [show
    (∑ A ∈ S.powerset,
      ZMod.stdAddChar
        (t * (fixedProductCRTIdempotentNat S A :
          ZMod (primeSetProduct S)))) =
      ∑ A ∈ S.powerset, F A by rfl]
  rw [show
    (∑ A ∈ ((S.powerset.erase S).erase ∅),
      ZMod.stdAddChar
        (t * (fixedProductCRTIdempotentNat S A :
          ZMod (primeSetProduct S)))) =
      ∑ A ∈ ((S.powerset.erase S).erase ∅), F A by rfl]
  rw [hsum]
  ring

noncomputable def fixedProductProperMass (S : Finset ℕ) : ℝ :=
  ((2 : ℝ) ^ S.card)⁻¹ *
    (((S.powerset.erase S).erase ∅).card : ℝ)

noncomputable def fixedProductProperRootIntervalDiscrepancy
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (r : ℕ) : ℝ :=
  ((2 : ℝ) ^ S.card)⁻¹ *
    ∑ A ∈ ((S.powerset.erase S).erase ∅),
      ((if (fixedProductCRTIdempotentNat S A) %
          (primeSetProduct S) < r then 1 else 0) -
        (r : ℝ) / (primeSetProduct S : ℝ))

theorem properRootIntervalRaw_eq_pow_mul_discrepancy
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (r : ℕ) :
    (∑ A ∈ ((S.powerset.erase S).erase ∅),
      ((if (fixedProductCRTIdempotentNat S A) %
          (primeSetProduct S) < r then 1 else 0) -
        (r : ℝ) / (primeSetProduct S : ℝ))) =
      (2 : ℝ) ^ S.card *
        fixedProductProperRootIntervalDiscrepancy S hPrime r := by
  unfold fixedProductProperRootIntervalDiscrepancy
  have hp : (2 : ℝ) ^ S.card ≠ 0 := by positivity
  field_simp [hp]

noncomputable def fixedProductProperAffineRootIntervalDiscrepancy
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S)) (r : ℕ) : ℝ :=
  ((2 : ℝ) ^ S.card)⁻¹ *
    ∑ A ∈ ((S.powerset.erase S).erase ∅),
      ((if (((u : ZMod (primeSetProduct S)) *
            (fixedProductCRTIdempotentNat S A :
              ZMod (primeSetProduct S)) + v).val) < r then 1 else 0) -
        (r : ℝ) / (primeSetProduct S : ℝ))

theorem properAffineRootIntervalRaw_eq_pow_mul_discrepancy
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S)) (r : ℕ) :
    (∑ A ∈ ((S.powerset.erase S).erase ∅),
      ((if (((u : ZMod (primeSetProduct S)) *
            (fixedProductCRTIdempotentNat S A :
              ZMod (primeSetProduct S)) + v).val) < r then 1 else 0) -
        (r : ℝ) / (primeSetProduct S : ℝ))) =
      (2 : ℝ) ^ S.card *
        fixedProductProperAffineRootIntervalDiscrepancy S hPrime u v r := by
  unfold fixedProductProperAffineRootIntervalDiscrepancy
  have hp : (2 : ℝ) ^ S.card ≠ 0 := by positivity
  field_simp [hp]

#print axioms fixedProductCRTIdempotentNat_full_cast
#print axioms fixedProductCRTIdempotentNat_empty_cast
#print axioms fixedProductProperFourierCoeff_eq_full_sub_endpoints
#print axioms properRootIntervalRaw_eq_pow_mul_discrepancy
#print axioms properAffineRootIntervalRaw_eq_pow_mul_discrepancy

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def calderProperRootAverageR
    (S : Finset ℕ) (f : ZMod (primeSetProduct S) → ℝ) : ℝ :=
  ((2 : ℝ) ^ S.card)⁻¹ *
    ∑ A ∈ ((S.powerset.erase S).erase ∅),
      f (fixedProductCRTIdempotentNat S A : ZMod (primeSetProduct S))

noncomputable def calderProperRootAverageC
    (S : Finset ℕ) (f : ZMod (primeSetProduct S) → ℂ) : ℂ :=
  (((2 : ℝ) ^ S.card)⁻¹ : ℝ) •
    ∑ A ∈ ((S.powerset.erase S).erase ∅),
      f (fixedProductCRTIdempotentNat S A : ZMod (primeSetProduct S))

lemma calderProperRootAverageR_const
    (S : Finset ℕ) (c : ℝ) :
    calderProperRootAverageR S (fun _ => c) =
      fixedProductProperMass S * c := by
  unfold calderProperRootAverageR fixedProductProperMass
  rw [Finset.sum_const]
  simp only [nsmul_eq_mul]
  ring

lemma calderProperRootAverageC_const
    (S : Finset ℕ) (c : ℂ) :
    calderProperRootAverageC S (fun _ => c) =
      (fixedProductProperMass S : ℂ) * c := by
  unfold calderProperRootAverageC fixedProductProperMass
  rw [Finset.sum_const, Algebra.smul_def]
  simp only [nsmul_eq_mul]
  push_cast
  ring

lemma fixedProductProperMass_nonneg (S : Finset ℕ) :
    0 ≤ fixedProductProperMass S := by
  unfold fixedProductProperMass
  positivity

lemma fixedProductProperMass_le_one (S : Finset ℕ) :
    fixedProductProperMass S ≤ 1 := by
  unfold fixedProductProperMass
  have hcard :
      (((S.powerset.erase S).erase ∅).card : ℝ) ≤
        (S.powerset.card : ℝ) := by
    exact_mod_cast
      (Finset.card_le_card
        ((Finset.erase_subset _ _).trans (Finset.erase_subset _ _)))
  rw [Finset.card_powerset] at hcard
  push_cast at hcard
  have hp : 0 < (2 : ℝ) ^ S.card := by positivity
  calc
    ((2 : ℝ) ^ S.card)⁻¹ *
        (((S.powerset.erase S).erase ∅).card : ℝ)
      ≤ ((2 : ℝ) ^ S.card)⁻¹ * (2 : ℝ) ^ S.card := by
        gcongr
    _ = 1 := by field_simp

lemma fixedProductProperFourierCoeff_zero_eq_mass
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime) :
    fixedProductProperFourierCoeff S hPrime
      (0 : ZMod (primeSetProduct S)) =
        (fixedProductProperMass S : ℂ) := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  unfold fixedProductProperFourierCoeff fixedProductProperMass
  simp only [zero_mul, AddChar.map_zero_eq_one, Finset.sum_const,
    nsmul_eq_mul]
  push_cast
  ring

lemma norm_fixedProductProperFourierCoeff_zero_le_one
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime) :
    ‖fixedProductProperFourierCoeff S hPrime
      (0 : ZMod (primeSetProduct S))‖ ≤ 1 := by
  rw [fixedProductProperFourierCoeff_zero_eq_mass]
  rw [Complex.norm_real, Real.norm_eq_abs,
    abs_of_nonneg (fixedProductProperMass_nonneg S)]
  exact fixedProductProperMass_le_one S

lemma calder_properFourierCoeff_neg
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (t : ZMod (primeSetProduct S)) :
    fixedProductProperFourierCoeff S hPrime (-t) =
      conj (fixedProductProperFourierCoeff S hPrime t) := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  unfold fixedProductProperFourierCoeff
  rw [map_mul]
  simp only [map_inv₀, map_pow, map_ofNat]
  congr 1
  rw [map_sum]
  apply Finset.sum_congr rfl
  intro A hA
  have harg :
      -t * (fixedProductCRTIdempotentNat S A :
          ZMod (primeSetProduct S)) =
        -(t * (fixedProductCRTIdempotentNat S A :
          ZMod (primeSetProduct S))) := by ring
  rw [harg, AddChar.map_neg_eq_inv]
  exact Complex.inv_eq_conj
    (norm_stdAddChar_eq_one (primeSetProduct S)
      (t * (fixedProductCRTIdempotentNat S A :
        ZMod (primeSetProduct S))))

lemma calder_properFrequencyMass_neg
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (t : ZMod (primeSetProduct S)) :
    ‖fixedProductProperFourierCoeff S hPrime (-t)‖ =
      ‖fixedProductProperFourierCoeff S hPrime t‖ := by
  rw [calder_properFourierCoeff_neg]
  simpa using norm_conj (fixedProductProperFourierCoeff S hPrime t)

lemma calderProperRootAverageR_add
    (S : Finset ℕ)
    (f g : ZMod (primeSetProduct S) → ℝ) :
    calderProperRootAverageR S (fun x => f x + g x) =
      calderProperRootAverageR S f + calderProperRootAverageR S g := by
  unfold calderProperRootAverageR
  simp_rw [Finset.sum_add_distrib]
  ring

lemma calderProperRootAverageR_sub
    (S : Finset ℕ)
    (f g : ZMod (primeSetProduct S) → ℝ) :
    calderProperRootAverageR S (fun x => f x - g x) =
      calderProperRootAverageR S f - calderProperRootAverageR S g := by
  unfold calderProperRootAverageR
  simp_rw [Finset.sum_sub_distrib]
  ring

lemma calderProperRootAverageR_const_mul
    (S : Finset ℕ) (c : ℝ)
    (f : ZMod (primeSetProduct S) → ℝ) :
    calderProperRootAverageR S (fun x => c * f x) =
      c * calderProperRootAverageR S f := by
  unfold calderProperRootAverageR
  have hsum :
      (∑ A ∈ ((S.powerset.erase S).erase ∅),
        c * f (fixedProductCRTIdempotentNat S A :
          ZMod (primeSetProduct S))) =
      c * ∑ A ∈ ((S.powerset.erase S).erase ∅),
        f (fixedProductCRTIdempotentNat S A :
          ZMod (primeSetProduct S)) := by
    rw [Finset.mul_sum]
  rw [hsum]
  ring

lemma calderProperRootAverageR_neg
    (S : Finset ℕ)
    (f : ZMod (primeSetProduct S) → ℝ) :
    calderProperRootAverageR S (fun x => -f x) =
      -calderProperRootAverageR S f := by
  simpa using calderProperRootAverageR_const_mul S (-1) f

lemma calderProperRootAverageR_sum
    (S : Finset ℕ) {ι : Type} (T : Finset ι)
    (f : ι → ZMod (primeSetProduct S) → ℝ) :
    calderProperRootAverageR S (fun x => ∑ i ∈ T, f i x) =
      ∑ i ∈ T, calderProperRootAverageR S (f i) := by
  classical
  induction T using Finset.induction_on with
  | empty => simp [calderProperRootAverageR]
  | @insert i T hi ih =>
      simp only [Finset.sum_insert hi]
      rw [calderProperRootAverageR_add, ih]

lemma calderProperRootAverageR_mono
    (S : Finset ℕ)
    {f g : ZMod (primeSetProduct S) → ℝ}
    (hfg : ∀ x, f x ≤ g x) :
    calderProperRootAverageR S f ≤
      calderProperRootAverageR S g := by
  unfold calderProperRootAverageR
  apply mul_le_mul_of_nonneg_left
  · apply Finset.sum_le_sum
    intro A hA
    exact hfg _
  · positivity

lemma calderProperRootAverageC_add
    (S : Finset ℕ)
    (f g : ZMod (primeSetProduct S) → ℂ) :
    calderProperRootAverageC S (fun x => f x + g x) =
      calderProperRootAverageC S f + calderProperRootAverageC S g := by
  unfold calderProperRootAverageC
  simp_rw [Finset.sum_add_distrib, smul_add]

lemma calderProperRootAverageC_sum
    (S : Finset ℕ) {ι : Type} (T : Finset ι)
    (f : ι → ZMod (primeSetProduct S) → ℂ) :
    calderProperRootAverageC S (fun x => ∑ i ∈ T, f i x) =
      ∑ i ∈ T, calderProperRootAverageC S (f i) := by
  classical
  induction T using Finset.induction_on with
  | empty => simp [calderProperRootAverageC]
  | @insert i T hi ih =>
      simp only [Finset.sum_insert hi]
      rw [calderProperRootAverageC_add, ih]

lemma calderProperRootAverageC_const_mul
    (S : Finset ℕ) (c : ℂ)
    (f : ZMod (primeSetProduct S) → ℂ) :
    calderProperRootAverageC S (fun x => c * f x) =
      c * calderProperRootAverageC S f := by
  unfold calderProperRootAverageC
  simp only [Algebra.smul_def]
  have hsum :
      (∑ A ∈ ((S.powerset.erase S).erase ∅),
        c * f (fixedProductCRTIdempotentNat S A :
          ZMod (primeSetProduct S))) =
      c * ∑ A ∈ ((S.powerset.erase S).erase ∅),
        f (fixedProductCRTIdempotentNat S A :
          ZMod (primeSetProduct S)) := by
    rw [Finset.mul_sum]
  rw [hsum]
  ring

lemma calderProperRootAverageC_ofReal
    (S : Finset ℕ)
    (f : ZMod (primeSetProduct S) → ℝ) :
    calderProperRootAverageC S (fun x => (f x : ℂ)) =
      (calderProperRootAverageR S f : ℂ) := by
  unfold calderProperRootAverageC calderProperRootAverageR
  rw [Algebra.smul_def]
  push_cast
  congr 1

lemma calderProperRootAverageR_im
    (S : Finset ℕ)
    (f : ZMod (primeSetProduct S) → ℂ) :
    calderProperRootAverageR S (fun x => (f x).im) =
      (calderProperRootAverageC S f).im := by
  unfold calderProperRootAverageR calderProperRootAverageC
  change
    ((2 : ℝ) ^ S.card)⁻¹ *
      (∑ A ∈ ((S.powerset.erase S).erase ∅),
        (f (fixedProductCRTIdempotentNat S A :
          ZMod (primeSetProduct S))).im) =
    Complex.imCLM
      ((((2 : ℝ) ^ S.card)⁻¹ : ℝ) •
        ∑ A ∈ ((S.powerset.erase S).erase ∅),
          f (fixedProductCRTIdempotentNat S A :
            ZMod (primeSetProduct S)))
  rw [map_smul]
  simp only [Complex.imCLM_apply, smul_eq_mul]
  have him :
      (∑ A ∈ ((S.powerset.erase S).erase ∅),
        f (fixedProductCRTIdempotentNat S A :
          ZMod (primeSetProduct S))).im =
      ∑ A ∈ ((S.powerset.erase S).erase ∅),
        (f (fixedProductCRTIdempotentNat S A :
          ZMod (primeSetProduct S))).im := by
    simp_rw [← Complex.imCLM_apply]
    rw [map_sum]
  rw [him]

lemma calderProperRootAverageC_stdAddChar
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (t : ZMod (primeSetProduct S)) :
    calderProperRootAverageC S
      (fun x => ZMod.stdAddChar (t * x)) =
      fixedProductProperFourierCoeff S hPrime t := by
  unfold calderProperRootAverageC fixedProductProperFourierCoeff
  rw [Algebra.smul_def]
  congr 1
  norm_num

lemma calderProperRootAverageC_stdAddChar_affine_translate
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (u : (ZMod (primeSetProduct S))ˣ)
    (v t c : ZMod (primeSetProduct S)) :
    calderProperRootAverageC S
      (fun x => ZMod.stdAddChar
        (t * (((u : ZMod (primeSetProduct S)) * x + v) - c))) =
      ZMod.stdAddChar (t * (v - c)) *
        fixedProductProperFourierCoeff S hPrime
          (t * (u : ZMod (primeSetProduct S))) := by
  have hfun :
      (fun x : ZMod (primeSetProduct S) =>
        ZMod.stdAddChar
          (t * (((u : ZMod (primeSetProduct S)) * x + v) - c))) =
      (fun x =>
        ZMod.stdAddChar (t * (v - c)) *
          ZMod.stdAddChar
            ((t * (u : ZMod (primeSetProduct S))) * x)) := by
    funext x
    rw [← AddChar.map_add_eq_mul]
    congr 1
    ring
  rw [hfun, calderProperRootAverageC_const_mul,
    calderProperRootAverageC_stdAddChar]

#print axioms fixedProductProperFourierCoeff_zero_eq_mass
#print axioms norm_fixedProductProperFourierCoeff_zero_le_one
#print axioms calder_properFourierCoeff_neg
#print axioms calderProperRootAverageC_stdAddChar_affine_translate

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def fixedProductProperTwistedFrequencyMass
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ) (j : ℕ) : ℝ :=
  ‖fixedProductProperFourierCoeff S hPrime
      ((j : ZMod (primeSetProduct S)) * (u : ZMod (primeSetProduct S)))‖

lemma calder_properFrequencyMass_neg_mul_unit
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (t : ZMod (primeSetProduct S)) :
    ‖fixedProductProperFourierCoeff S hPrime
      ((-t) * (u : ZMod (primeSetProduct S)))‖ =
      ‖fixedProductProperFourierCoeff S hPrime
        (t * (u : ZMod (primeSetProduct S)))‖ := by
  rw [show (-t) * (u : ZMod (primeSetProduct S)) =
      -(t * (u : ZMod (primeSetProduct S))) by ring]
  exact calder_properFrequencyMass_neg S hPrime
    (t * (u : ZMod (primeSetProduct S)))

lemma calder_properCoeff_row_norm_twisted_le
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (J b : ℕ) (hb : b < J + 1) :
    (∑ a ∈ Finset.range (J + 1),
      ‖fixedProductProperFourierCoeff S hPrime
        (((a : ZMod (primeSetProduct S)) -
          (b : ZMod (primeSetProduct S))) *
          (u : ZMod (primeSetProduct S)))‖) ≤
      1 + 2 * ∑ j ∈ Finset.Icc 1 J,
        fixedProductProperTwistedFrequencyMass S hPrime u j := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  let F : ℕ → ℝ :=
    fun j => fixedProductProperTwistedFrequencyMass S hPrime u j
  let g : ℕ → ℝ := fun a =>
    ‖fixedProductProperFourierCoeff S hPrime
      (((a : ZMod (primeSetProduct S)) -
        (b : ZMod (primeSetProduct S))) *
        (u : ZMod (primeSetProduct S)))‖
  have hbJ : b ≤ J := by omega
  have hF0 : ∀ j ∈ Finset.Icc 1 J, 0 ≤ F j := by
    intro j hj
    exact norm_nonneg _
  have hdiag : g b ≤ 1 := by
    dsimp [g]
    rw [sub_self, zero_mul]
    exact norm_fixedProductProperFourierCoeff_zero_le_one S hPrime
  have hleft :
      (∑ a ∈ Finset.range b, g a) ≤
        ∑ j ∈ Finset.Icc 1 J, F j := by
    calc
      (∑ a ∈ Finset.range b, g a) =
          ∑ a ∈ Finset.range b, F (b - a) := by
            apply Finset.sum_congr rfl
            intro a ha
            have hab : a < b := Finset.mem_range.mp ha
            dsimp [g, F, fixedProductProperTwistedFrequencyMass]
            have hcast :
                ((b - a : ℕ) : ZMod (primeSetProduct S)) =
                  (b : ZMod (primeSetProduct S)) -
                    (a : ZMod (primeSetProduct S)) := by
              rw [Nat.cast_sub (Nat.le_of_lt hab)]
            have hneg :
                ((a : ZMod (primeSetProduct S)) -
                    (b : ZMod (primeSetProduct S))) *
                    (u : ZMod (primeSetProduct S)) =
                  -(((b - a : ℕ) : ZMod (primeSetProduct S)) *
                    (u : ZMod (primeSetProduct S))) := by
              rw [hcast]
              ring
            rw [hneg, calder_properFrequencyMass_neg]
      _ = ∑ k ∈ Finset.range b, F (k + 1) := by
            rw [← Finset.sum_range_reflect (fun k => F (k + 1)) b]
            apply Finset.sum_congr rfl
            intro a ha
            congr 1
            have hab : a < b := Finset.mem_range.mp ha
            omega
      _ = ∑ j ∈ Finset.Icc 1 b, F j :=
            calder_sum_range_succ_shift_eq_Icc F b
      _ ≤ ∑ j ∈ Finset.Icc 1 J, F j :=
            calder_sum_Icc_mono_of_nonneg F hbJ hF0
  have hright :
      (∑ k ∈ Finset.range (J - b), g (b + (1 + k))) ≤
        ∑ j ∈ Finset.Icc 1 J, F j := by
    calc
      (∑ k ∈ Finset.range (J - b), g (b + (1 + k))) =
          ∑ k ∈ Finset.range (J - b), F (k + 1) := by
            apply Finset.sum_congr rfl
            intro k hk
            dsimp [g, F, fixedProductProperTwistedFrequencyMass]
            simp only [Nat.cast_add, Nat.cast_one]
            congr 2
            ring
      _ = ∑ j ∈ Finset.Icc 1 (J - b), F j :=
            calder_sum_range_succ_shift_eq_Icc F (J - b)
      _ ≤ ∑ j ∈ Finset.Icc 1 J, F j :=
            calder_sum_Icc_mono_of_nonneg F (Nat.sub_le J b) hF0
  have hsplit :
      (∑ a ∈ Finset.range (J + 1), g a) =
        (∑ a ∈ Finset.range b, g a) + g b +
          ∑ k ∈ Finset.range (J - b), g (b + (1 + k)) := by
    rw [show J + 1 = b + (1 + (J - b)) by omega]
    rw [Finset.sum_range_add, Finset.sum_range_add]
    simp
    ring
  rw [show (∑ a ∈ Finset.range (J + 1),
      ‖fixedProductProperFourierCoeff S hPrime
        (((a : ZMod (primeSetProduct S)) -
          (b : ZMod (primeSetProduct S))) *
          (u : ZMod (primeSetProduct S)))‖) =
      ∑ a ∈ Finset.range (J + 1), g a by rfl]
  rw [hsplit]
  dsimp [F] at hleft hright ⊢
  linarith

#print axioms calder_properCoeff_row_norm_twisted_le

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma calder_properAverage_fejer_normsq_affine_translate_eq_double
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S))
    (L : ℕ) (c : ZMod (primeSetProduct S)) :
    ((calderProperRootAverageR S
      (fun x : ZMod (primeSetProduct S) =>
        ‖∑ k ∈ Finset.range L,
          (ZMod.stdAddChar (((u : ZMod (primeSetProduct S)) * x + v) - c)) ^ k‖ ^ 2) : ℝ) : ℂ) =
      ∑ b ∈ Finset.range L, ∑ a ∈ Finset.range L,
        ZMod.stdAddChar
          ((((a : ZMod (primeSetProduct S)) -
              (b : ZMod (primeSetProduct S))) * (v - c))) *
        fixedProductProperFourierCoeff S hPrime
          (((a : ZMod (primeSetProduct S)) -
              (b : ZMod (primeSetProduct S))) *
            (u : ZMod (primeSetProduct S))) := by
  rw [← calderProperRootAverageC_ofReal]
  have hpoint :
      (fun x : ZMod (primeSetProduct S) =>
        ((‖∑ k ∈ Finset.range L,
          (ZMod.stdAddChar (((u : ZMod (primeSetProduct S)) * x + v) - c)) ^ k‖ ^ 2 : ℝ) : ℂ)) =
      (fun x =>
        ∑ b ∈ Finset.range L, ∑ a ∈ Finset.range L,
          ZMod.stdAddChar
            ((((a : ZMod (primeSetProduct S)) -
              (b : ZMod (primeSetProduct S)))) *
                (((u : ZMod (primeSetProduct S)) * x + v) - c))) := by
    funext x
    exact calder_fejer_norm_sq_expand
      (((u : ZMod (primeSetProduct S)) * x + v) - c)
  rw [hpoint, calderProperRootAverageC_sum]
  apply Finset.sum_congr rfl
  intro b hb
  rw [calderProperRootAverageC_sum]
  apply Finset.sum_congr rfl
  intro a ha
  exact calderProperRootAverageC_stdAddChar_affine_translate
    S hPrime u v
      ((a : ZMod (primeSetProduct S)) - (b : ZMod (primeSetProduct S))) c

lemma calder_properAverage_fejer_normsq_affine_translate_le
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S))
    (J : ℕ) (c : ZMod (primeSetProduct S)) :
    calderProperRootAverageR S
      (fun x : ZMod (primeSetProduct S) =>
        ‖∑ k ∈ Finset.range (J + 1),
          (ZMod.stdAddChar (((u : ZMod (primeSetProduct S)) * x + v) - c)) ^ k‖ ^ 2) ≤
      (J + 1 : ℝ) *
        (1 + 2 * ∑ j ∈ Finset.Icc 1 J,
          fixedProductProperTwistedFrequencyMass S hPrime u j) := by
  let A : ℝ :=
    calderProperRootAverageR S
      (fun x : ZMod (primeSetProduct S) =>
        ‖∑ k ∈ Finset.range (J + 1),
          (ZMod.stdAddChar (((u : ZMod (primeSetProduct S)) * x + v) - c)) ^ k‖ ^ 2)
  let T : ℝ := ∑ j ∈ Finset.Icc 1 J,
    fixedProductProperTwistedFrequencyMass S hPrime u j
  have hA0 : 0 ≤ A := by
    dsimp [A, calderProperRootAverageR]
    positivity
  have heq :=
    calder_properAverage_fejer_normsq_affine_translate_eq_double
      S hPrime u v (J + 1) c
  have hnorm : A = ‖(A : ℂ)‖ := by
    rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg hA0]
  change A ≤ ((J : ℝ) + 1) * (1 + 2 * T)
  rw [hnorm]
  rw [show (A : ℂ) =
      ∑ b ∈ Finset.range (J + 1), ∑ a ∈ Finset.range (J + 1),
        ZMod.stdAddChar
          ((((a : ZMod (primeSetProduct S)) -
              (b : ZMod (primeSetProduct S))) * (v - c))) *
        fixedProductProperFourierCoeff S hPrime
          (((a : ZMod (primeSetProduct S)) -
              (b : ZMod (primeSetProduct S))) *
            (u : ZMod (primeSetProduct S))) by
      simpa [A] using heq]
  calc
    ‖∑ b ∈ Finset.range (J + 1), ∑ a ∈ Finset.range (J + 1),
        ZMod.stdAddChar
          ((((a : ZMod (primeSetProduct S)) -
              (b : ZMod (primeSetProduct S))) * (v - c))) *
        fixedProductProperFourierCoeff S hPrime
          (((a : ZMod (primeSetProduct S)) -
              (b : ZMod (primeSetProduct S))) *
            (u : ZMod (primeSetProduct S)))‖
      ≤ ∑ b ∈ Finset.range (J + 1),
          ‖∑ a ∈ Finset.range (J + 1),
            ZMod.stdAddChar
              ((((a : ZMod (primeSetProduct S)) -
                (b : ZMod (primeSetProduct S))) * (v - c))) *
            fixedProductProperFourierCoeff S hPrime
              (((a : ZMod (primeSetProduct S)) -
                (b : ZMod (primeSetProduct S))) *
                (u : ZMod (primeSetProduct S)))‖ := norm_sum_le _ _
    _ ≤ ∑ b ∈ Finset.range (J + 1),
          ∑ a ∈ Finset.range (J + 1),
            ‖fixedProductProperFourierCoeff S hPrime
              (((a : ZMod (primeSetProduct S)) -
                (b : ZMod (primeSetProduct S))) *
                (u : ZMod (primeSetProduct S)))‖ := by
        apply Finset.sum_le_sum
        intro b hb
        calc
          ‖∑ a ∈ Finset.range (J + 1),
            ZMod.stdAddChar
              ((((a : ZMod (primeSetProduct S)) -
                (b : ZMod (primeSetProduct S))) * (v - c))) *
            fixedProductProperFourierCoeff S hPrime
              (((a : ZMod (primeSetProduct S)) -
                (b : ZMod (primeSetProduct S))) *
                (u : ZMod (primeSetProduct S)))‖
            ≤ ∑ a ∈ Finset.range (J + 1),
              ‖ZMod.stdAddChar
                ((((a : ZMod (primeSetProduct S)) -
                  (b : ZMod (primeSetProduct S))) * (v - c))) *
              fixedProductProperFourierCoeff S hPrime
                (((a : ZMod (primeSetProduct S)) -
                  (b : ZMod (primeSetProduct S))) *
                  (u : ZMod (primeSetProduct S)))‖ := norm_sum_le _ _
          _ = ∑ a ∈ Finset.range (J + 1),
              ‖fixedProductProperFourierCoeff S hPrime
                (((a : ZMod (primeSetProduct S)) -
                  (b : ZMod (primeSetProduct S))) *
                  (u : ZMod (primeSetProduct S)))‖ := by
              apply Finset.sum_congr rfl
              intro a ha
              rw [norm_mul, norm_stdAddChar_eq_one, one_mul]
    _ ≤ ∑ b ∈ Finset.range (J + 1), (1 + 2 * T) := by
        apply Finset.sum_le_sum
        intro b hb
        have hb' : b < J + 1 := Finset.mem_range.mp hb
        simpa [T] using
          calder_properCoeff_row_norm_twisted_le S hPrime u J b hb'
    _ = (J + 1 : ℝ) * (1 + 2 * T) := by
        simp [nsmul_eq_mul]
        ring
    _ = _ := by ring

lemma calderProperRootAverageR_stdAddChar_affine_translate_im
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (u : (ZMod (primeSetProduct S))ˣ)
    (v t c : ZMod (primeSetProduct S)) :
    calderProperRootAverageR S
      (fun x =>
        (ZMod.stdAddChar
          (t * (((u : ZMod (primeSetProduct S)) * x + v) - c))).im) =
      (ZMod.stdAddChar (t * (v - c)) *
        fixedProductProperFourierCoeff S hPrime
          (t * (u : ZMod (primeSetProduct S)))).im := by
  rw [calderProperRootAverageR_im]
  rw [calderProperRootAverageC_stdAddChar_affine_translate]

lemma calder_properAverage_h3VaalerApprox_affine_translate_eq
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S))
    (J : ℕ) (c : ZMod (primeSetProduct S)) :
    calderProperRootAverageR S
      (fun x : ZMod (primeSetProduct S) =>
        h3VaalerApprox (primeSetProduct S) J
          (((u : ZMod (primeSetProduct S)) * x + v) - c)) =
      - ∑ j ∈ Finset.Icc 1 J,
        (h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
          (ZMod.stdAddChar
              ((j : ZMod (primeSetProduct S)) * (v - c)) *
            fixedProductProperFourierCoeff S hPrime
              ((j : ZMod (primeSetProduct S)) *
                (u : ZMod (primeSetProduct S)))).im := by
  unfold h3VaalerApprox
  rw [calderProperRootAverageR_neg]
  rw [calderProperRootAverageR_sum]
  congr 1
  apply Finset.sum_congr rfl
  intro j hj
  rw [calderProperRootAverageR_const_mul]
  rw [calderProperRootAverageR_stdAddChar_affine_translate_im]

lemma calder_abs_properAverage_h3VaalerApprox_affine_translate_le
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S))
    (J : ℕ) (c : ZMod (primeSetProduct S)) :
    |calderProperRootAverageR S
      (fun x : ZMod (primeSetProduct S) =>
        h3VaalerApprox (primeSetProduct S) J
          (((u : ZMod (primeSetProduct S)) * x + v) - c))| ≤
      ∑ j ∈ Finset.Icc 1 J,
        fixedProductProperTwistedFrequencyMass S hPrime u j / (j : ℝ) := by
  rw [calder_properAverage_h3VaalerApprox_affine_translate_eq
    S hPrime u v J c]
  rw [abs_neg]
  calc
    |∑ j ∈ Finset.Icc 1 J,
        (h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
          (ZMod.stdAddChar
              ((j : ZMod (primeSetProduct S)) * (v - c)) *
            fixedProductProperFourierCoeff S hPrime
              ((j : ZMod (primeSetProduct S)) *
                (u : ZMod (primeSetProduct S)))).im|
      ≤ ∑ j ∈ Finset.Icc 1 J,
          |(h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
            (ZMod.stdAddChar
                ((j : ZMod (primeSetProduct S)) * (v - c)) *
              fixedProductProperFourierCoeff S hPrime
                ((j : ZMod (primeSetProduct S)) *
                  (u : ZMod (primeSetProduct S)))).im| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ j ∈ Finset.Icc 1 J,
        fixedProductProperTwistedFrequencyMass S hPrime u j / (j : ℝ) := by
      apply Finset.sum_le_sum
      intro j hj
      have hw := calder_vaaler_weight_le_one_div hj
      have him :
          |(ZMod.stdAddChar
              ((j : ZMod (primeSetProduct S)) * (v - c)) *
            fixedProductProperFourierCoeff S hPrime
              ((j : ZMod (primeSetProduct S)) *
                (u : ZMod (primeSetProduct S)))).im| ≤
            fixedProductProperTwistedFrequencyMass S hPrime u j := by
        calc
          |(ZMod.stdAddChar
              ((j : ZMod (primeSetProduct S)) * (v - c)) *
            fixedProductProperFourierCoeff S hPrime
              ((j : ZMod (primeSetProduct S)) *
                (u : ZMod (primeSetProduct S)))).im|
            ≤ ‖ZMod.stdAddChar
                ((j : ZMod (primeSetProduct S)) * (v - c)) *
              fixedProductProperFourierCoeff S hPrime
                ((j : ZMod (primeSetProduct S)) *
                  (u : ZMod (primeSetProduct S)))‖ :=
              Complex.abs_im_le_norm _
          _ = fixedProductProperTwistedFrequencyMass S hPrime u j := by
              rw [norm_mul, norm_stdAddChar_eq_one, one_mul]
              rfl
      rw [abs_mul, abs_of_nonneg hw.1]
      calc
        (h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
            |(ZMod.stdAddChar
                ((j : ZMod (primeSetProduct S)) * (v - c)) *
              fixedProductProperFourierCoeff S hPrime
                ((j : ZMod (primeSetProduct S)) *
                  (u : ZMod (primeSetProduct S)))).im|
          ≤ (1 / (j : ℝ)) *
              fixedProductProperTwistedFrequencyMass S hPrime u j := by
                exact mul_le_mul hw.2 him (abs_nonneg _) (by positivity)
        _ = fixedProductProperTwistedFrequencyMass S hPrime u j / (j : ℝ) := by
              ring

lemma calder_properAverage_h3VaalerError_affine_translate_le
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S))
    (J : ℕ) (c : ZMod (primeSetProduct S)) :
    calderProperRootAverageR S
      (fun x : ZMod (primeSetProduct S) =>
        h3VaalerError (primeSetProduct S) J
          (((u : ZMod (primeSetProduct S)) * x + v) - c)) ≤
      (1 + 2 * ∑ j ∈ Finset.Icc 1 J,
        fixedProductProperTwistedFrequencyMass S hPrime u j) /
        (2 * ((J + 1 : ℕ) : ℝ)) := by
  let M : ℝ := ∑ j ∈ Finset.Icc 1 J,
    fixedProductProperTwistedFrequencyMass S hPrime u j
  have hN :=
    calder_properAverage_fejer_normsq_affine_translate_le
      S hPrime u v J c
  have hJpos : (0 : ℝ) < ((J + 1 : ℕ) : ℝ) := by positivity
  unfold h3VaalerError h3FejerKernel
  rw [calderProperRootAverageR_const_mul]
  rw [calderProperRootAverageR_const_mul]
  calc
    (1 / (2 * ((J + 1 : ℕ) : ℝ))) *
        ((((J + 1 : ℕ) : ℝ))⁻¹ *
          calderProperRootAverageR S
            (fun x : ZMod (primeSetProduct S) =>
              ‖∑ k ∈ Finset.range (J + 1),
                (ZMod.stdAddChar
                  (((u : ZMod (primeSetProduct S)) * x + v) - c)) ^ k‖ ^ 2))
      ≤ (1 / (2 * ((J + 1 : ℕ) : ℝ))) *
          ((((J + 1 : ℕ) : ℝ))⁻¹ *
            (((J + 1 : ℕ) : ℝ) * (1 + 2 * M))) := by
              gcongr
              simpa [M] using hN
    _ = (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) := by
          field_simp [hJpos.ne']
    _ = _ := by rfl

#print axioms calder_properAverage_fejer_normsq_affine_translate_le
#print axioms calder_abs_properAverage_h3VaalerApprox_affine_translate_le
#print axioms calder_properAverage_h3VaalerError_affine_translate_le



lemma calder_proper_affine_discrepancy_eq_rootAverage_indicator_sub
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S)) (r : ℕ) :
    fixedProductProperAffineRootIntervalDiscrepancy S hPrime u v r =
      calderProperRootAverageR S
        (fun x : ZMod (primeSetProduct S) =>
          h3HalfOpenIntervalIndicator r
            ((u : ZMod (primeSetProduct S)) * x + v)) -
      fixedProductProperMass S *
        ((r : ℝ) / (primeSetProduct S : ℝ)) := by
  unfold fixedProductProperAffineRootIntervalDiscrepancy
    calderProperRootAverageR fixedProductProperMass
    h3HalfOpenIntervalIndicator
  rw [Finset.sum_sub_distrib, Finset.sum_const]
  simp only [nsmul_eq_mul]
  ring

#print axioms calder_proper_affine_discrepancy_eq_rootAverage_indicator_sub

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem fixedProductProperAffineRootInterval_erdosTuran_of_grid_error
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S))
    (r J : ℕ)
    (hr : r < primeSetProduct S)
    (hJ : 1 ≤ J)
    (hGrid : @H3VaalerGridErrorSpec (primeSetProduct S) J
      ⟨(primeSetProduct_pos hPrime).ne'⟩) :
    |fixedProductProperAffineRootIntervalDiscrepancy S hPrime u v r| ≤
      4 / (J : ℝ) +
        4 * ∑ j ∈ Finset.Icc 1 J,
          fixedProductProperTwistedFrequencyMass S hPrime u j / (j : ℝ) := by
  let N := primeSetProduct S
  letI : NeZero N := ⟨(primeSetProduct_pos hPrime).ne'⟩
  let R : ZMod N := (r : ZMod N)
  let H : ℝ := ∑ j ∈ Finset.Icc 1 J,
    fixedProductProperTwistedFrequencyMass S hPrime u j / (j : ℝ)
  let M : ℝ := ∑ j ∈ Finset.Icc 1 J,
    fixedProductProperTwistedFrequencyMass S hPrime u j
  have hH0 : 0 ≤ H := by
    dsimp [H]
    apply Finset.sum_nonneg
    intro j hj
    exact div_nonneg (norm_nonneg _) (by positivity)
  have hM0 : 0 ≤ M := by
    dsimp [M]
    apply Finset.sum_nonneg
    intro j hj
    exact norm_nonneg _
  have hJpos : (0 : ℝ) < (J : ℝ) := by
    exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hJ)
  have hJ1pos : (0 : ℝ) < ((J + 1 : ℕ) : ℝ) := by positivity
  have hInd :
      fixedProductProperAffineRootIntervalDiscrepancy S hPrime u v r =
        calderProperRootAverageR S
          (fun x : ZMod N =>
            h3HalfOpenIntervalIndicator r ((u : ZMod N) * x + v)) -
          fixedProductProperMass S * ((r : ℝ) / (N : ℝ)) := by
    simpa [N] using
      calder_proper_affine_discrepancy_eq_rootAverage_indicator_sub
        S hPrime u v r
  have hSand : ∀ x : ZMod N,
      h3IntervalLowerMinorant N r J ((u : ZMod N) * x + v) ≤
          h3HalfOpenIntervalIndicator r ((u : ZMod N) * x + v) ∧
      h3HalfOpenIntervalIndicator r ((u : ZMod N) * x + v) ≤
          h3IntervalUpperMajorant N r J ((u : ZMod N) * x + v) := by
    intro x
    exact fixedProductBooleanRootInterval_selberg_majorant_of_grid_error
      (N := N) (r := r) (J := J) (by simpa [N] using hr) hGrid
      ((u : ZMod N) * x + v)
  have hLow := calderProperRootAverageR_mono S (fun x => (hSand x).1)
  have hUp := calderProperRootAverageR_mono S (fun x => (hSand x).2)
  have hSawR :=
    calder_abs_properAverage_h3VaalerApprox_affine_translate_le
      S hPrime u v J R
  have hSaw0 :=
    calder_abs_properAverage_h3VaalerApprox_affine_translate_le
      S hPrime u v J (0 : ZMod N)
  have hErrR :=
    calder_properAverage_h3VaalerError_affine_translate_le
      S hPrime u v J R
  have hErr0 :=
    calder_properAverage_h3VaalerError_affine_translate_le
      S hPrime u v J (0 : ZMod N)
  have hA0 :
      calderProperRootAverageR S
        (fun x : ZMod N =>
          h3VaalerApprox N J ((u : ZMod N) * x + v)) =
      calderProperRootAverageR S
        (fun x : ZMod N =>
          h3VaalerApprox N J (((u : ZMod N) * x + v) - (0 : ZMod N))) := by
    congr 1
    funext x
    simp
  rw [← hA0] at hSaw0
  have hE0 :
      calderProperRootAverageR S
        (fun x : ZMod N =>
          h3VaalerError N J ((u : ZMod N) * x + v)) =
      calderProperRootAverageR S
        (fun x : ZMod N =>
          h3VaalerError N J (((u : ZMod N) * x + v) - (0 : ZMod N))) := by
    congr 1
    funext x
    simp
  rw [← hE0] at hErr0
  have hM_to_H :
      M / ((J + 1 : ℕ) : ℝ) ≤ H := by
    have hrewrite :
        M / ((J + 1 : ℕ) : ℝ) =
          ∑ j ∈ Finset.Icc 1 J,
            fixedProductProperTwistedFrequencyMass S hPrime u j /
              ((J + 1 : ℕ) : ℝ) := by
      dsimp [M]
      rw [Finset.sum_div]
    rw [hrewrite]
    dsimp [H]
    apply Finset.sum_le_sum
    intro j hj
    have hjJ : j ≤ J := (Finset.mem_Icc.mp hj).2
    have hjpos : (0 : ℝ) < (j : ℝ) := by
      have hj1 : 1 ≤ j := (Finset.mem_Icc.mp hj).1
      exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hj1)
    have hm0 : 0 ≤ fixedProductProperTwistedFrequencyMass S hPrime u j :=
      norm_nonneg _
    have hden : (j : ℝ) ≤ ((J + 1 : ℕ) : ℝ) := by
      exact_mod_cast Nat.le_succ_of_le hjJ
    have hinv :
        1 / ((J + 1 : ℕ) : ℝ) ≤ 1 / (j : ℝ) :=
      one_div_le_one_div_of_le hjpos hden
    calc
      fixedProductProperTwistedFrequencyMass S hPrime u j /
          ((J + 1 : ℕ) : ℝ)
        = fixedProductProperTwistedFrequencyMass S hPrime u j *
            (1 / ((J + 1 : ℕ) : ℝ)) := by ring
      _ ≤ fixedProductProperTwistedFrequencyMass S hPrime u j *
            (1 / (j : ℝ)) := mul_le_mul_of_nonneg_left hinv hm0
      _ = fixedProductProperTwistedFrequencyMass S hPrime u j / (j : ℝ) := by ring
  have hErrSum :
      calderProperRootAverageR S
          (fun x : ZMod N =>
            h3VaalerError N J (((u : ZMod N) * x + v) - R)) +
        calderProperRootAverageR S
          (fun x : ZMod N =>
            h3VaalerError N J ((u : ZMod N) * x + v)) ≤
        1 / ((J + 1 : ℕ) : ℝ) + 2 * H := by
    have hs := add_le_add hErrR hErr0
    have hs' :
        calderProperRootAverageR S
            (fun x : ZMod N =>
              h3VaalerError N J (((u : ZMod N) * x + v) - R)) +
          calderProperRootAverageR S
            (fun x : ZMod N =>
              h3VaalerError N J ((u : ZMod N) * x + v)) ≤
          (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) +
          (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) := by
      simpa [N, M] using hs
    have hcalc :
        (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) +
          (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) =
          1 / ((J + 1 : ℕ) : ℝ) +
            2 * (M / ((J + 1 : ℕ) : ℝ)) := by
      field_simp [hJ1pos.ne']
      ring
    calc
      calderProperRootAverageR S
          (fun x : ZMod N =>
            h3VaalerError N J (((u : ZMod N) * x + v) - R)) +
        calderProperRootAverageR S
          (fun x : ZMod N =>
            h3VaalerError N J ((u : ZMod N) * x + v))
        ≤ (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) +
          (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) := hs'
      _ = 1 / ((J + 1 : ℕ) : ℝ) +
            2 * (M / ((J + 1 : ℕ) : ℝ)) := hcalc
      _ ≤ 1 / ((J + 1 : ℕ) : ℝ) + 2 * H := by
            gcongr
  have hSawDiff :
      |calderProperRootAverageR S
          (fun x : ZMod N =>
            h3VaalerApprox N J (((u : ZMod N) * x + v) - R)) -
        calderProperRootAverageR S
          (fun x : ZMod N =>
            h3VaalerApprox N J ((u : ZMod N) * x + v))| ≤ 2 * H := by
    calc
      |calderProperRootAverageR S
          (fun x : ZMod N =>
            h3VaalerApprox N J (((u : ZMod N) * x + v) - R)) -
        calderProperRootAverageR S
          (fun x : ZMod N =>
            h3VaalerApprox N J ((u : ZMod N) * x + v))|
        ≤ |calderProperRootAverageR S
            (fun x : ZMod N =>
              h3VaalerApprox N J (((u : ZMod N) * x + v) - R))| +
          |calderProperRootAverageR S
            (fun x : ZMod N =>
              h3VaalerApprox N J ((u : ZMod N) * x + v))| := abs_sub _ _
      _ ≤ H + H := by
        exact add_le_add
          (by simpa [N, H, fixedProductProperTwistedFrequencyMass] using hSawR)
          (by simpa [N, H, fixedProductProperTwistedFrequencyMass] using hSaw0)
      _ = 2 * H := by ring
  have hCenteredUp :
      fixedProductProperAffineRootIntervalDiscrepancy S hPrime u v r ≤
        (calderProperRootAverageR S
            (fun x : ZMod N =>
              h3VaalerApprox N J (((u : ZMod N) * x + v) - R)) -
          calderProperRootAverageR S
            (fun x : ZMod N =>
              h3VaalerApprox N J ((u : ZMod N) * x + v))) +
        calderProperRootAverageR S
            (fun x : ZMod N =>
              h3VaalerError N J (((u : ZMod N) * x + v) - R)) +
        calderProperRootAverageR S
            (fun x : ZMod N =>
              h3VaalerError N J ((u : ZMod N) * x + v)) := by
    rw [hInd]
    have hUp' := hUp
    unfold h3IntervalUpperMajorant h3IntervalUpperCentered at hUp'
    rw [calderProperRootAverageR_add] at hUp'
    rw [calderProperRootAverageR_add] at hUp'
    rw [calderProperRootAverageR_add] at hUp'
    rw [calderProperRootAverageR_sub] at hUp'
    rw [calderProperRootAverageR_const] at hUp'
    dsimp [R] at hUp' ⊢
    linarith
  have hCenteredLow :
      - fixedProductProperAffineRootIntervalDiscrepancy S hPrime u v r ≤
        -(calderProperRootAverageR S
            (fun x : ZMod N =>
              h3VaalerApprox N J (((u : ZMod N) * x + v) - R)) -
          calderProperRootAverageR S
            (fun x : ZMod N =>
              h3VaalerApprox N J ((u : ZMod N) * x + v))) +
        calderProperRootAverageR S
            (fun x : ZMod N =>
              h3VaalerError N J (((u : ZMod N) * x + v) - R)) +
        calderProperRootAverageR S
            (fun x : ZMod N =>
              h3VaalerError N J ((u : ZMod N) * x + v)) := by
    rw [hInd]
    have hLow' := hLow
    unfold h3IntervalLowerMinorant h3IntervalLowerCentered at hLow'
    rw [calderProperRootAverageR_add] at hLow'
    rw [calderProperRootAverageR_sub] at hLow'
    rw [calderProperRootAverageR_sub] at hLow'
    rw [calderProperRootAverageR_sub] at hLow'
    rw [calderProperRootAverageR_const] at hLow'
    dsimp [R] at hLow' ⊢
    linarith
  have hCore :
      |fixedProductProperAffineRootIntervalDiscrepancy S hPrime u v r| ≤
        1 / ((J + 1 : ℕ) : ℝ) + 4 * H := by
    rw [abs_le]
    have hSawLower := (abs_le.mp hSawDiff).1
    have hSawUpper := (abs_le.mp hSawDiff).2
    constructor <;> linarith [hCenteredLow, hCenteredUp, hErrSum]
  calc
    |fixedProductProperAffineRootIntervalDiscrepancy S hPrime u v r|
      ≤ 1 / ((J + 1 : ℕ) : ℝ) + 4 * H := hCore
    _ ≤ 4 / (J : ℝ) + 4 * H := by
      have hden : (J : ℝ) ≤ ((J + 1 : ℕ) : ℝ) := by
        exact_mod_cast Nat.le_succ J
      have hinv :
          1 / ((J + 1 : ℕ) : ℝ) ≤ 1 / (J : ℝ) :=
        one_div_le_one_div_of_le hJpos hden
      have hposinv : 0 < 1 / (J : ℝ) := one_div_pos.mpr hJpos
      have h1to4 : 1 / (J : ℝ) ≤ 4 / (J : ℝ) := by
        calc
          1 / (J : ℝ) = 1 * (1 / (J : ℝ)) := by ring
          _ ≤ 4 * (1 / (J : ℝ)) :=
            mul_le_mul_of_nonneg_right (by norm_num) hposinv.le
          _ = 4 / (J : ℝ) := by ring
      exact add_le_add (hinv.trans h1to4) (le_refl (4 * H))
    _ = _ := by rfl

theorem fixedProductProperAffineRootInterval_erdosTuran
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S))
    (r J : ℕ)
    (hr : r < primeSetProduct S)
    (hJ : 1 ≤ J) :
    |fixedProductProperAffineRootIntervalDiscrepancy S hPrime u v r| ≤
      4 / (J : ℝ) +
        4 * ∑ j ∈ Finset.Icc 1 J,
          fixedProductProperTwistedFrequencyMass S hPrime u j / (j : ℝ) := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  exact fixedProductProperAffineRootInterval_erdosTuran_of_grid_error
    S hPrime u v r J hr hJ
    (h3VaalerGridErrorSpec_holds (primeSetProduct S) J)

theorem fixedProductProperAffineRootInterval_erdosTuran_sq
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S))
    (r J : ℕ)
    (hr : r < primeSetProduct S)
    (hJ : 1 ≤ J) :
    (fixedProductProperAffineRootIntervalDiscrepancy S hPrime u v r) ^ 2 ≤
      32 / ((J : ℝ) ^ 2) +
      32 * (1 + Real.log (J : ℝ)) *
        (∑ j ∈ Finset.Icc 1 J,
          (fixedProductProperTwistedFrequencyMass S hPrime u j) ^ 2 /
            (j : ℝ)) := by
  apply erdosTuran_square_after_boolean_average
    (fixedProductProperAffineRootIntervalDiscrepancy S hPrime u v r)
    (fun j => fixedProductProperTwistedFrequencyMass S hPrime u j) J hJ
  · intro j hj
    exact norm_nonneg _
  · exact fixedProductProperAffineRootInterval_erdosTuran
      S hPrime u v r J hr hJ

#print axioms fixedProductProperAffineRootInterval_erdosTuran
#print axioms fixedProductProperAffineRootInterval_erdosTuran_sq

end PaperB.FixedQ
