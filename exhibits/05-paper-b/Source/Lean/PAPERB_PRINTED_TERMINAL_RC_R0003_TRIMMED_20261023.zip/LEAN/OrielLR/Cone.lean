import OrielLR.ShortLong

/-!
# Oriel L/R — arithmetic of the asymmetric cone

With the short variable `m > 1`, long range `(a, b]`, `a = max(Z/m, m²)`, `b = W/m`,
and a cube root `Y³ ≤ Z` of the actual cutoff: the cone forces the long variable past
the head threshold `(N₀+1) P m D` and the height past `2 D (P m)²`.
-/

open Finset

namespace OrielUpper

theorem cone_conditions {Zh W H m Y N0 P D : ℕ} (hm1 : 1 < m) (hWH : W ≤ H)
    (hY : Y ^ 3 ≤ Zh) (hYN : (N0 + 1) * P * D ≤ Y) (hYD : 2 * D * P ^ 2 + 1 ≤ Y)
    (hab : max (Zh / m) (m ^ 2) < W / m) :
    (N0 + 1) * (P * m) * D ≤ max (Zh / m) (m ^ 2) ∧ 2 * D * (P * m) ^ 2 ≤ H - 1 ∧
      1 ≤ max (Zh / m) (m ^ 2) ∧ W / m ≤ H ∧ W / m * m ≤ W := by
  have hm0 : 0 < m := by omega
  have h1 : m ^ 2 < W / m := lt_of_le_of_lt (le_max_right _ _) hab
  have h2 : Zh / m < W / m := lt_of_le_of_lt (le_max_left _ _) hab
  have hWm3 : m ^ 3 < W := by
    have : m ^ 2 + 1 ≤ W / m := h1
    have := (Nat.le_div_iff_mul_le hm0).mp this
    nlinarith
  have hWZ : Zh < W := by
    by_contra hc
    push_neg at hc
    have := Nat.div_le_div_right (c := m) hc
    omega
  have hY3W : Y ^ 3 < W := lt_of_le_of_lt hY hWZ
  have hmm : 4 ≤ m ^ 2 := by nlinarith
  refine ⟨?_, ?_, ?_, ?_, Nat.div_mul_le_self _ _⟩
  · rcases le_or_gt m Y with hmY | hmY
    · apply le_trans _ (le_max_left _ _)
      apply le_trans _ (Nat.div_le_div_right (c := m) hY)
      apply (Nat.le_div_iff_mul_le hm0).mpr
      have hA : (N0 + 1) * P * D * (m * m) ≤ Y * (Y * Y) :=
        Nat.mul_le_mul hYN (Nat.mul_le_mul hmY hmY)
      calc (N0 + 1) * (P * m) * D * m = (N0 + 1) * P * D * (m * m) := by ring
        _ ≤ Y * (Y * Y) := hA
        _ = Y ^ 3 := by ring
    · apply le_trans _ (le_max_right _ _)
      have : (N0 + 1) * P * D ≤ m := by omega
      calc (N0 + 1) * (P * m) * D = (N0 + 1) * P * D * m := by ring
        _ ≤ m * m := Nat.mul_le_mul_right m this
        _ = m ^ 2 := by ring
  · rcases le_or_gt m Y with hmY | hmY
    · have hA : (2 * D * P ^ 2 + 1) * (m * m) ≤ Y * (Y * Y) :=
        Nat.mul_le_mul hYD (Nat.mul_le_mul hmY hmY)
      have : 2 * D * (P * m) ^ 2 + 1 ≤ Y ^ 3 := by
        have e : (2 * D * P ^ 2 + 1) * (m * m) = 2 * D * (P * m) ^ 2 + m * m := by ring
        have e2 : Y * (Y * Y) = Y ^ 3 := by ring
        rw [e] at hA; rw [← e2]; nlinarith
      omega
    · have hA : (2 * D * P ^ 2 + 1) * (m * m) ≤ m * (m * m) :=
        Nat.mul_le_mul_right _ (by omega)
      have : 2 * D * (P * m) ^ 2 + 1 ≤ m ^ 3 := by
        have e : (2 * D * P ^ 2 + 1) * (m * m) = 2 * D * (P * m) ^ 2 + m * m := by ring
        have e2 : m * (m * m) = m ^ 3 := by ring
        rw [e] at hA; rw [← e2]; nlinarith
      omega
  · exact le_trans (by omega) (le_max_right _ _)
  · exact le_trans (Nat.div_le_self _ _) hWH

end OrielUpper
