import PaperB.FixedQ.FixedProductAverage
import Mathlib.NumberTheory.Harmonic.Bounds
import Mathlib.Algebra.Order.BigOperators.Ring.Finset

open scoped BigOperators
open Finset

namespace PaperB.FixedQ

lemma frequency_harmonic_cauchy
    (F : ℕ → ℝ) (J : ℕ)
    (hF : ∀ j ∈ Finset.Icc 1 J, 0 ≤ F j) :
    (∑ j ∈ Finset.Icc 1 J, F j / (j : ℝ)) ^ 2 ≤
      (∑ j ∈ Finset.Icc 1 J, (1 : ℝ) / (j : ℝ)) *
      (∑ j ∈ Finset.Icc 1 J, (F j) ^ 2 / (j : ℝ)) := by
  let S := Finset.Icc 1 J
  let r : ℕ → ℝ := fun j => F j / (j : ℝ)
  let f : ℕ → ℝ := fun j => (1 : ℝ) / (j : ℝ)
  let g : ℕ → ℝ := fun j => (F j) ^ 2 / (j : ℝ)
  have hf : ∀ j ∈ S, 0 ≤ f j := by
    intro j hj
    dsimp [S] at hj
    dsimp [f]
    positivity
  have hg : ∀ j ∈ S, 0 ≤ g j := by
    intro j hj
    dsimp [S] at hj
    dsimp [g]
    positivity
  have ht : ∀ j ∈ S, (r j) ^ 2 ≤ f j * g j := by
    intro j hj
    have hj1 : 1 ≤ j := (Finset.mem_Icc.mp hj).1
    have hjpos : (0 : ℝ) < (j : ℝ) := by exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hj1)
    dsimp [r, f, g]
    field_simp [hjpos.ne']
    nlinarith [sq_nonneg (F j)]
  simpa [S, r, f, g] using
    (Finset.sum_sq_le_sum_mul_sum_of_sq_le_mul S hf hg ht)

lemma frequency_harmonic_factor_le_log
    (J : ℕ) :
    (∑ j ∈ Finset.Icc 1 J, (1 : ℝ) / (j : ℝ)) ≤
      1 + Real.log (J : ℝ) := by
  simpa [harmonic_eq_sum_Icc] using harmonic_le_one_add_log J

end PaperB.FixedQ
namespace PaperB.FixedQ

lemma erdosTuran_square_after_boolean_average
    (D : ℝ) (F : ℕ → ℝ) (J : ℕ)
    (hJ : 1 ≤ J)
    (hF : ∀ j ∈ Finset.Icc 1 J, 0 ≤ F j)
    (hET :
      |D| ≤ 4 / (J : ℝ) +
        4 * ∑ j ∈ Finset.Icc 1 J, F j / (j : ℝ)) :
    D ^ 2 ≤
      32 / ((J : ℝ) ^ 2) +
      32 * (1 + Real.log (J : ℝ)) *
        (∑ j ∈ Finset.Icc 1 J, (F j) ^ 2 / (j : ℝ)) := by
  let S : ℝ := ∑ j ∈ Finset.Icc 1 J, F j / (j : ℝ)
  let Q : ℝ := ∑ j ∈ Finset.Icc 1 J, (F j) ^ 2 / (j : ℝ)
  have hJpos : (0 : ℝ) < (J : ℝ) := by
    exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hJ)
  have hS0 : 0 ≤ S := by
    dsimp [S]
    apply Finset.sum_nonneg
    intro j hj
    exact div_nonneg (hF j hj) (by positivity)
  have hA0 : 0 ≤ 4 / (J : ℝ) := by positivity
  have hR0 : 0 ≤ 4 / (J : ℝ) + 4 * S := by positivity
  have hET' : |D| ≤ 4 / (J : ℝ) + 4 * S := by
    simpa [S] using hET
  have hsqET :
      |D| ^ 2 ≤ (4 / (J : ℝ) + 4 * S) ^ 2 := by
    simpa [pow_two] using
      (mul_self_le_mul_self (abs_nonneg D) hET')
  have hsplit :
      (4 / (J : ℝ) + 4 * S) ^ 2 ≤
        32 / ((J : ℝ) ^ 2) + 32 * S ^ 2 := by
    have hs := sq_nonneg (4 / (J : ℝ) - 4 * S)
    field_simp [hJpos.ne'] at hs ⊢
    nlinarith
  have hcauchy :
      S ^ 2 ≤
        (∑ j ∈ Finset.Icc 1 J, (1 : ℝ) / (j : ℝ)) * Q := by
    simpa [S, Q] using frequency_harmonic_cauchy F J hF
  have hharm :
      (∑ j ∈ Finset.Icc 1 J, (1 : ℝ) / (j : ℝ)) ≤
        1 + Real.log (J : ℝ) :=
    frequency_harmonic_factor_le_log J
  have hQ0 : 0 ≤ Q := by
    dsimp [Q]
    apply Finset.sum_nonneg
    intro j hj
    positivity
  have hfreq :
      S ^ 2 ≤ (1 + Real.log (J : ℝ)) * Q := by
    exact hcauchy.trans
      (mul_le_mul_of_nonneg_right hharm hQ0)
  have habs : |D| ^ 2 = D ^ 2 := by
    exact sq_abs D
  rw [← habs]
  calc
    |D| ^ 2 ≤ (4 / (J : ℝ) + 4 * S) ^ 2 := hsqET
    _ ≤ 32 / ((J : ℝ) ^ 2) + 32 * S ^ 2 := hsplit
    _ ≤ 32 / ((J : ℝ) ^ 2) +
        32 * ((1 + Real.log (J : ℝ)) * Q) := by
      gcongr
    _ = _ := by
      dsimp [Q]
      ring

#print axioms frequency_harmonic_cauchy
#print axioms erdosTuran_square_after_boolean_average

end PaperB.FixedQ
