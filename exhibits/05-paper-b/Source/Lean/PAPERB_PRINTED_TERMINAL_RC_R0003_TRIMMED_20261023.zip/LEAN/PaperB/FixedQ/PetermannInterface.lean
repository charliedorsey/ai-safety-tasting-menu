import PaperB.FixedQ.CStarBound

open scoped BigOperators

namespace PaperB.FixedQ

/-- Fixed low period from the frozen manuscript. -/
def petermannPeriod (q : ℕ) : ℕ := Nat.lcm 6 q

/-- Exact manuscript sawtooth convention: integer arguments map to -1/2. -/
noncomputable def petermannSawtooth (x : ℝ) : ℝ :=
  x - (Int.floor x : ℝ) - (1 / 2 : ℝ)

inductive PetermannBase
  | omega
  | eta
deriving DecidableEq

noncomputable def omegaCoeff (q e : ℕ) : ℝ :=
  if e = 0 then 0
  else if Squarefree e ∧ e.Coprime (6 * q) then
    ∏ p ∈ e.primeFactors, 1 / ((p : ℝ) - 3)
  else 0

noncomputable def etaCoeff (q e : ℕ) : ℝ :=
  if e = 0 then 0
  else if Squarefree e ∧ e.Coprime (6 * q) then
    ∏ p ∈ e.primeFactors, 1 / ((p : ℝ) - 2)
  else 0

noncomputable def movingVCoeff (q h e : ℕ) : ℝ :=
  if e = 0 then 0
  else if Squarefree e ∧ e.Coprime (6 * q) then
    ∏ p ∈ e.primeFactors,
      if p ∣ h then 1 / ((p : ℝ) - 2)
      else 1 / ((p : ℝ) - 3)
  else 0

noncomputable def petermannBaseCoeff
    (q : ℕ) : PetermannBase → ℕ → ℝ
  | PetermannBase.omega => omegaCoeff q
  | PetermannBase.eta => etaCoeff q

noncomputable def petermannMajorant (T : ℝ) : ℝ :=
  (Real.log (3 * T)) ^ (3 / 4 : ℝ) +
  (Real.log (3 * T)) ^ (2 / 3 : ℝ) *
    (Real.log (Real.log (3 * T))) ^ (4 / 3 : ℝ) +
  Real.log (Real.log (3 * T)) + 1

@[simp] theorem omegaCoeff_zero (q : ℕ) :
    omegaCoeff q 0 = 0 := by
  simp [omegaCoeff]

@[simp] theorem etaCoeff_zero (q : ℕ) :
    etaCoeff q 0 = 0 := by
  simp [etaCoeff]

@[simp] theorem movingVCoeff_zero (q h : ℕ) :
    movingVCoeff q h 0 = 0 := by
  simp [movingVCoeff]

theorem omegaCoeff_eq_finiteOmegaWeightReal
    {q e : ℕ} (he0 : e ≠ 0)
    (hsq : Squarefree e) (hcop : e.Coprime (6 * q)) :
    omegaCoeff q e = finiteOmegaWeightReal e.primeFactors := by
  rw [omegaCoeff, if_neg he0, if_pos ⟨hsq, hcop⟩]
  rfl

theorem movingVCoeff_eq_finiteVWeightReal
    {q h e : ℕ} (he0 : e ≠ 0)
    (hsq : Squarefree e) (hcop : e.Coprime (6 * q)) :
    movingVCoeff q h e = finiteVWeightReal h e.primeFactors := by
  rw [movingVCoeff, if_neg he0, if_pos ⟨hsq, hcop⟩]
  rfl

#print axioms omegaCoeff_eq_finiteOmegaWeightReal
#print axioms movingVCoeff_eq_finiteVWeightReal

end PaperB.FixedQ
