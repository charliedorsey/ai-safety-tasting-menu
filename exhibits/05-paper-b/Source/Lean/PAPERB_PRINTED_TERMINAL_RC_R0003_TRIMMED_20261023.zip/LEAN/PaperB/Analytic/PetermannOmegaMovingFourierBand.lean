import PaperB.Analytic.SawtoothTruncation
import Mathlib.Algebra.BigOperators.Module
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Complex

open scoped BigOperators

namespace PaperB.Analytic

open Real Finset

lemma sawSmoothFreq_neg (n : ℤ) :
    sawSmoothFreq (-n) = - sawSmoothFreq n := by
  rw [sawSmoothFreq, sawSmoothFreq]
  push_cast
  ring

lemma sawSmoothCoeff_neg
    {S : ℝ} (hS : 1 < S) {n : ℤ} (hn : n ≠ 0) :
    sawSmoothCoeff S (-n) = - sawSmoothCoeff S n := by
  rw [sawSmoothCoeff_eq_exp_difference hS (neg_ne_zero.mpr hn)]
  rw [sawSmoothCoeff_eq_exp_difference hS hn]
  rw [sawSmoothFreq_neg]
  ring_nf

lemma sawSmoothPair_eq_coeff_mul_fourier_sub
    {S : ℝ} (hS : 1 < S) (k : ℕ)
    (x : AddCircle (1 : ℝ)) :
    sawSmoothPair S k x =
      sawSmoothCoeff S (k + 1 : ℕ) *
        (fourier (k + 1 : ℕ) x - fourier (-((k + 1 : ℕ) : ℤ)) x) := by
  unfold sawSmoothPair sawSmoothMode
  have hn : ((k + 1 : ℕ) : ℤ) ≠ 0 := by omega
  rw [sawSmoothCoeff_neg hS hn]
  simp only [smul_eq_mul]
  ring


lemma sawSmoothCoeff_eq_sine
    {S : ℝ} (hS : 1 < S) {n : ℤ} (hn : n ≠ 0) :
    sawSmoothCoeff S n =
      (((S * Real.sin (Real.pi * (n : ℝ) / S)) /
          (2 * Real.pi ^ 2 * (n : ℝ) ^ 2) : ℝ) : ℂ) * Complex.I := by
  rw [sawSmoothCoeff_eq_exp_difference hS hn]
  rw [sawSmoothFreq, sawSmoothHalfWidth]
  have hS0 : S ≠ 0 := ne_of_gt (lt_trans zero_lt_one hS)
  have hnR : (n : ℝ) ≠ 0 := by exact_mod_cast hn
  have hpi : Real.pi ≠ 0 := Real.pi_ne_zero
  have hpos :
      Complex.exp
          ((-(2 : ℂ) * (Real.pi : ℂ) * Complex.I * (n : ℂ)) *
            ((1 / (2 * S) : ℝ) : ℂ)) =
        (Real.cos (Real.pi * (n : ℝ) / S) : ℂ) -
          (Real.sin (Real.pi * (n : ℝ) / S) : ℂ) * Complex.I := by
    rw [show
      (-(2 : ℂ) * (Real.pi : ℂ) * Complex.I * (n : ℂ)) *
          ((1 / (2 * S) : ℝ) : ℂ) =
        ((-(Real.pi * (n : ℝ) / S) : ℝ) : ℂ) * Complex.I by
          push_cast
          field_simp [hS0]]
    rw [Complex.exp_ofReal_mul_I]
    simp [Real.cos_neg, Real.sin_neg, sub_eq_add_neg]
  have hneg :
      Complex.exp
          (-((-(2 : ℂ) * (Real.pi : ℂ) * Complex.I * (n : ℂ)) *
            ((1 / (2 * S) : ℝ) : ℂ))) =
        (Real.cos (Real.pi * (n : ℝ) / S) : ℂ) +
          (Real.sin (Real.pi * (n : ℝ) / S) : ℂ) * Complex.I := by
    rw [show
      -((-(2 : ℂ) * (Real.pi : ℂ) * Complex.I * (n : ℂ)) *
          ((1 / (2 * S) : ℝ) : ℂ)) =
        (((Real.pi * (n : ℝ) / S) : ℝ) : ℂ) * Complex.I by
          push_cast
          field_simp [hS0]]
    rw [Complex.exp_ofReal_mul_I]
  rw [hpos, hneg]
  push_cast
  field_simp [hS0, hnR, hpi]
  simp
  ring


lemma fourier_sub_neg_eq_sine
    (n : ℕ) (x : ℝ) :
    fourier (n : ℤ) (x : AddCircle (1 : ℝ)) -
        fourier (-((n : ℕ) : ℤ)) (x : AddCircle (1 : ℝ)) =
      ((2 * Real.sin (2 * Real.pi * (n : ℝ) * x) : ℝ) : ℂ) * Complex.I := by
  rw [fourier_coe_apply, fourier_coe_apply]
  simp only [Int.cast_neg, Int.cast_natCast, Complex.ofReal_one, div_one]
  have hpos :
      Complex.exp (2 * (Real.pi : ℂ) * Complex.I * (n : ℂ) * (x : ℂ)) =
        (Real.cos (2 * Real.pi * (n : ℝ) * x) : ℂ) +
          (Real.sin (2 * Real.pi * (n : ℝ) * x) : ℂ) * Complex.I := by
    rw [show
      2 * (Real.pi : ℂ) * Complex.I * (n : ℂ) * (x : ℂ) =
        (((2 * Real.pi * (n : ℝ) * x : ℝ) : ℂ) * Complex.I) by
          push_cast
          ring]
    rw [Complex.exp_ofReal_mul_I]
  have hneg :
      Complex.exp (2 * (Real.pi : ℂ) * Complex.I * (-(n : ℂ)) * (x : ℂ)) =
        (Real.cos (2 * Real.pi * (n : ℝ) * x) : ℂ) -
          (Real.sin (2 * Real.pi * (n : ℝ) * x) : ℂ) * Complex.I := by
    rw [show
      2 * (Real.pi : ℂ) * Complex.I * (-(n : ℂ)) * (x : ℂ) =
        (((-(2 * Real.pi * (n : ℝ) * x) : ℝ) : ℂ) * Complex.I) by
          push_cast
          ring]
    rw [Complex.exp_ofReal_mul_I]
    simp [Real.cos_neg, Real.sin_neg, sub_eq_add_neg]
  rw [hpos, hneg]
  push_cast
  ring

lemma sawSmoothPair_coe_eq_sine_product
    {S : ℝ} (hS : 1 < S) (k : ℕ) (x : ℝ) :
    sawSmoothPair S k (x : AddCircle (1 : ℝ)) =
      ((-(S *
          Real.sin (Real.pi * ((k + 1 : ℕ) : ℝ) / S) *
          Real.sin (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * x) /
          (Real.pi ^ 2 * ((k + 1 : ℕ) : ℝ) ^ 2)) : ℝ) : ℂ) := by
  rw [sawSmoothPair_eq_coeff_mul_fourier_sub hS]
  have hn : (((k + 1 : ℕ) : ℤ)) ≠ 0 := by omega
  rw [sawSmoothCoeff_eq_sine hS hn]
  rw [fourier_sub_neg_eq_sine]
  push_cast
  have hpi : Real.pi ≠ 0 := Real.pi_ne_zero
  have hk : (((k + 1 : ℕ) : ℝ)) ≠ 0 := by positivity
  field_simp [hpi, hk]
  simp


lemma sine_shift_prefix_bound
    (theta : ℝ) (hsin : Real.sin (theta / 2) ≠ 0) (N : ℕ) :
    |∑ i ∈ Finset.range N, Real.sin (theta * (i + 1 : ℕ))| ≤
      1 / |Real.sin (theta / 2)| := by
  have hnonres : ∀ k : ℤ, theta ≠ (k : ℝ) * (2 * Real.pi) := by
    intro k hEq
    apply hsin
    have hs := congrArg (fun z : ℝ => Real.sin (z / 2)) hEq
    have harg : ((k : ℝ) * (2 * Real.pi)) / 2 = (k : ℝ) * Real.pi := by ring
    rw [harg, Real.sin_int_mul_pi] at hs
    exact hs
  have hsum := Real.sum_sin N hnonres theta
  have hrewrite :
      (∑ i ∈ Finset.range N, Real.sin (theta * (i + 1 : ℕ))) =
        ∑ i ∈ Finset.range N, Real.sin (theta * (i : ℝ) + theta) := by
    apply Finset.sum_congr rfl
    intro i hi
    congr 1
    push_cast
    ring
  rw [hrewrite, hsum, abs_div]
  have hden : 0 < |Real.sin (theta / 2)| := abs_pos.mpr hsin
  have hnum :
      |Real.sin ((N : ℝ) * theta / 2) *
        Real.sin (((N : ℝ) - 1) * theta / 2 + theta)| ≤ 1 := by
    rw [abs_mul]
    calc
      |Real.sin ((N : ℝ) * theta / 2)| *
          |Real.sin (((N : ℝ) - 1) * theta / 2 + theta)|
        ≤ 1 * 1 := mul_le_mul
          (Real.abs_sin_le_one _)
          (Real.abs_sin_le_one _)
          (abs_nonneg _)
          (by norm_num)
      _ = 1 := by norm_num
  exact (div_le_div_iff_of_pos_right hden).2 (by simpa using hnum)

#print axioms sine_shift_prefix_bound

#print axioms sawSmoothCoeff_neg
#print axioms sawSmoothPair_eq_coeff_mul_fourier_sub

end PaperB.Analytic

namespace PaperB.Analytic

lemma harmonic_sine_Ico_bound
    (theta : ℝ) (hsin : Real.sin (theta / 2) ≠ 0)
    (m n : ℕ) (hmn : m < n) :
    |∑ i ∈ Finset.Ico m n,
        (1 / ((i + 1 : ℕ) : ℝ)) * Real.sin (theta * (i + 1 : ℕ))|
      ≤ 2 / (((m + 1 : ℕ) : ℝ) * |Real.sin (theta / 2)|) := by
  let f : ℕ → ℝ := fun i => 1 / ((i + 1 : ℕ) : ℝ)
  let g : ℕ → ℝ := fun i => Real.sin (theta * (i + 1 : ℕ))
  have hparts := Finset.sum_Ico_by_parts f g hmn
  have hprefix : ∀ j : ℕ,
      |∑ i ∈ Finset.range j, g i| ≤ 1 / |Real.sin (theta / 2)| := by
    intro j
    simpa [g] using sine_shift_prefix_bound theta hsin j
  have hfnonneg : ∀ i, 0 ≤ f i := by
    intro i
    dsimp [f]
    positivity
  have hfanti : ∀ i, f (i + 1) ≤ f i := by
    intro i
    dsimp [f]
    apply one_div_le_one_div_of_le
    · positivity
    · norm_num
  have hdiff : ∀ i, |f (i + 1) - f i| = f i - f (i + 1) := by
    intro i
    rw [abs_of_nonpos]
    · ring
    · exact sub_nonpos.mpr (hfanti i)
  change |∑ i ∈ Finset.Ico m n, f i * g i| ≤ _
  simp_rw [← smul_eq_mul]
  rw [hparts]
  simp_rw [smul_eq_mul]
  have hA :
      |f (n - 1) * (∑ i ∈ Finset.range n, g i)|
        ≤ f (n - 1) * (1 / |Real.sin (theta / 2)|) := by
    rw [abs_mul, abs_of_nonneg (hfnonneg (n - 1))]
    gcongr
    exact hprefix n
  have hB :
      |f m * (∑ i ∈ Finset.range m, g i)|
        ≤ f m * (1 / |Real.sin (theta / 2)|) := by
    rw [abs_mul, abs_of_nonneg (hfnonneg m)]
    gcongr
    exact hprefix m
  have hC :
      |∑ i ∈ Finset.Ico m (n - 1),
          (f (i + 1) - f i) * (∑ j ∈ Finset.range (i + 1), g j)|
        ≤ (f m - f (n - 1)) * (1 / |Real.sin (theta / 2)|) := by
    calc
      |∑ i ∈ Finset.Ico m (n - 1),
          (f (i + 1) - f i) * (∑ j ∈ Finset.range (i + 1), g j)|
        ≤ ∑ i ∈ Finset.Ico m (n - 1),
            |(f (i + 1) - f i) * (∑ j ∈ Finset.range (i + 1), g j)| := by
              exact Finset.abs_sum_le_sum_abs _ _
      _ ≤ ∑ i ∈ Finset.Ico m (n - 1),
            (f i - f (i + 1)) * (1 / |Real.sin (theta / 2)|) := by
              apply Finset.sum_le_sum
              intro i hi
              rw [abs_mul]
              have hd : 0 ≤ f i - f (i + 1) := sub_nonneg.mpr (hfanti i)
              have habs : |f (i + 1) - f i| = f i - f (i + 1) := hdiff i
              rw [habs]
              exact mul_le_mul_of_nonneg_left (hprefix (i + 1)) hd
      _ = (f m - f (n - 1)) * (1 / |Real.sin (theta / 2)|) := by
            rw [← Finset.sum_mul]
            have htel := Finset.sum_Ico_sub f (Nat.le_sub_one_of_lt hmn)
            have htel' :
                (∑ i ∈ Finset.Ico m (n - 1), (f i - f (i + 1))) =
                  f m - f (n - 1) := by
              calc
                ∑ i ∈ Finset.Ico m (n - 1), (f i - f (i + 1))
                    = -(∑ i ∈ Finset.Ico m (n - 1), (f (i + 1) - f i)) := by
                        rw [← Finset.sum_neg_distrib]
                        apply Finset.sum_congr rfl
                        intro i hi
                        ring
                _ = -(f (n - 1) - f m) := by rw [htel]
                _ = f m - f (n - 1) := by ring
            rw [htel']
  calc
    |f (n - 1) * (∑ i ∈ Finset.range n, g i) -
        f m * (∑ i ∈ Finset.range m, g i) -
        ∑ i ∈ Finset.Ico m (n - 1),
          (f (i + 1) - f i) * (∑ j ∈ Finset.range (i + 1), g j)|
      ≤ |f (n - 1) * (∑ i ∈ Finset.range n, g i)| +
          |f m * (∑ i ∈ Finset.range m, g i)| +
          |∑ i ∈ Finset.Ico m (n - 1),
            (f (i + 1) - f i) * (∑ j ∈ Finset.range (i + 1), g j)| := by
            calc
              |f (n - 1) * (∑ i ∈ Finset.range n, g i) -
                  f m * (∑ i ∈ Finset.range m, g i) -
                  ∑ i ∈ Finset.Ico m (n - 1),
                    (f (i + 1) - f i) * (∑ j ∈ Finset.range (i + 1), g j)|
                ≤ |f (n - 1) * (∑ i ∈ Finset.range n, g i) -
                    f m * (∑ i ∈ Finset.range m, g i)| +
                    |∑ i ∈ Finset.Ico m (n - 1),
                      (f (i + 1) - f i) * (∑ j ∈ Finset.range (i + 1), g j)| :=
                      abs_sub _ _
              _ ≤ (|f (n - 1) * (∑ i ∈ Finset.range n, g i)| +
                    |f m * (∑ i ∈ Finset.range m, g i)|) +
                    |∑ i ∈ Finset.Ico m (n - 1),
                      (f (i + 1) - f i) * (∑ j ∈ Finset.range (i + 1), g j)| := by
                      gcongr
                      exact abs_sub _ _
    _ ≤ f (n - 1) * (1 / |Real.sin (theta / 2)|) +
          f m * (1 / |Real.sin (theta / 2)|) +
          (f m - f (n - 1)) * (1 / |Real.sin (theta / 2)|) := by
            gcongr
    _ = 2 / (((m + 1 : ℕ) : ℝ) * |Real.sin (theta / 2)|) := by
          dsimp [f]
          have hmpos : (0 : ℝ) < ((m + 1 : ℕ) : ℝ) := by positivity
          have hspos : (0 : ℝ) < |Real.sin (theta / 2)| := abs_pos.mpr hsin
          field_simp [ne_of_gt hmpos, ne_of_gt hspos]
          ring

#print axioms harmonic_sine_Ico_bound

end PaperB.Analytic

namespace PaperB.Analytic

lemma abs_sin_nat_mul_le (theta : ℝ) :
    ∀ n : ℕ, |Real.sin ((n : ℝ) * theta)| ≤ (n : ℝ) * |Real.sin theta| := by
  intro n
  induction n with
  | zero =>
      simp
  | succ n ih =>
      rw [Nat.cast_succ]
      have hadd :
          Real.sin (((n : ℝ) + 1) * theta) =
            Real.sin ((n : ℝ) * theta) * Real.cos theta +
              Real.cos ((n : ℝ) * theta) * Real.sin theta := by
        rw [show ((n : ℝ) + 1) * theta = (n : ℝ) * theta + theta by ring]
        exact Real.sin_add _ _
      rw [hadd]
      calc
        |Real.sin ((n : ℝ) * theta) * Real.cos theta +
            Real.cos ((n : ℝ) * theta) * Real.sin theta|
          ≤ |Real.sin ((n : ℝ) * theta) * Real.cos theta| +
              |Real.cos ((n : ℝ) * theta) * Real.sin theta| := abs_add_le _ _
        _ = |Real.sin ((n : ℝ) * theta)| * |Real.cos theta| +
              |Real.cos ((n : ℝ) * theta)| * |Real.sin theta| := by
                rw [abs_mul, abs_mul]
        _ ≤ |Real.sin ((n : ℝ) * theta)| + |Real.sin theta| := by
              apply add_le_add
              · simpa using
                  (mul_le_mul_of_nonneg_left
                    (Real.abs_cos_le_one theta) (abs_nonneg _))
              · have h :=
                  mul_le_mul_of_nonneg_right
                    (Real.abs_cos_le_one ((n : ℝ) * theta))
                    (abs_nonneg (Real.sin theta))
                simpa using h
        _ ≤ (n : ℝ) * |Real.sin theta| + |Real.sin theta| := by
              exact add_le_add ih le_rfl
        _ = ((n : ℝ) + 1) * |Real.sin theta| := by ring

lemma abs_sin_le_two_abs_sin_half (theta : ℝ) :
    |Real.sin theta| ≤ 2 * |Real.sin (theta / 2)| := by
  have heq :
      Real.sin theta =
        2 * Real.sin (theta / 2) * Real.cos (theta / 2) := by
    rw [← Real.sin_two_mul]
    congr 1
    ring
  rw [heq, abs_mul, abs_mul]
  norm_num
  have h :=
    mul_le_mul_of_nonneg_left
      (Real.abs_cos_le_one (theta / 2))
      (show 0 ≤ 2 * |Real.sin (theta / 2)| by positivity)
  simpa [mul_assoc] using h


lemma harmonic_sine_range_uniform
    (theta : ℝ) (hsin : Real.sin (theta / 2) ≠ 0) (N : ℕ) :
    |∑ i ∈ Finset.range N,
        (1 / ((i + 1 : ℕ) : ℝ)) * Real.sin (theta * (i + 1 : ℕ))|
      ≤ 6 := by
  let s : ℝ := |Real.sin (theta / 2)|
  let J : ℕ := Nat.ceil (1 / s)
  have hspos : 0 < s := by
    dsimp [s]
    exact abs_pos.mpr hsin
  have hsle : s ≤ 1 := by
    dsimp [s]
    exact Real.abs_sin_le_one _
  have hJlower : 1 / s ≤ (J : ℝ) := by
    dsimp [J]
    exact Nat.le_ceil _
  have hJs1 : 1 ≤ (J : ℝ) * s := by
    have := mul_le_mul_of_nonneg_right hJlower hspos.le
    have hsne : s ≠ 0 := ne_of_gt hspos
    calc
      1 = (1 / s) * s := by field_simp [hsne]
      _ ≤ (J : ℝ) * s := this
  have hJupper : (J : ℝ) < 1 / s + 1 := by
    dsimp [J]
    exact Nat.ceil_lt_add_one (by positivity)
  have hJs_lt_two : (J : ℝ) * s < 2 := by
    have hm := mul_lt_mul_of_pos_right hJupper hspos
    have hsne : s ≠ 0 := ne_of_gt hspos
    calc
      (J : ℝ) * s < (1 / s + 1) * s := hm
      _ = 1 + s := by field_simp [hsne]
      _ ≤ 2 := by linarith
  let term : ℕ → ℝ := fun i =>
    (1 / ((i + 1 : ℕ) : ℝ)) * Real.sin (theta * (i + 1 : ℕ))
  have hterm : ∀ i : ℕ, |term i| ≤ 2 * s := by
    intro i
    have hnat := abs_sin_nat_mul_le theta (i + 1)
    have hsin2 := abs_sin_le_two_abs_sin_half theta
    have hi : (0 : ℝ) < ((i + 1 : ℕ) : ℝ) := by positivity
    have hsinN :
        |Real.sin (theta * ((i + 1 : ℕ) : ℝ))|
          ≤ ((i + 1 : ℕ) : ℝ) * (2 * s) := by
      have hnat' :
          |Real.sin (theta * ((i + 1 : ℕ) : ℝ))|
            ≤ ((i + 1 : ℕ) : ℝ) * |Real.sin theta| := by
        simpa [mul_comm] using hnat
      exact le_trans hnat'
        (mul_le_mul_of_nonneg_left
          (by simpa [s] using hsin2) hi.le)
    dsimp [term]
    rw [abs_mul, abs_of_nonneg (by positivity : 0 ≤ (1 / ((i + 1 : ℕ) : ℝ)))]
    rw [one_div]
    have hm := mul_le_mul_of_nonneg_left hsinN (inv_nonneg.mpr hi.le)
    calc
      (((i + 1 : ℕ) : ℝ))⁻¹ *
          |Real.sin (theta * ((i + 1 : ℕ) : ℝ))|
        ≤ (((i + 1 : ℕ) : ℝ))⁻¹ *
            (((i + 1 : ℕ) : ℝ) * (2 * s)) := hm
      _ = 2 * s := by field_simp [ne_of_gt hi]
  have hhead : ∀ M : ℕ, M ≤ J →
      |∑ i ∈ Finset.range M, term i| ≤ 4 := by
    intro M hMJ
    calc
      |∑ i ∈ Finset.range M, term i|
        ≤ ∑ i ∈ Finset.range M, |term i| :=
          Finset.abs_sum_le_sum_abs _ _
      _ ≤ ∑ _i ∈ Finset.range M, (2 * s) := by
          apply Finset.sum_le_sum
          intro i hi
          exact hterm i
      _ = (M : ℝ) * (2 * s) := by simp
      _ ≤ (J : ℝ) * (2 * s) := by
          exact mul_le_mul_of_nonneg_right
            (by exact_mod_cast hMJ) (by positivity)
      _ ≤ 4 := le_of_lt (by nlinarith)
  by_cases hNJ : N ≤ J
  · exact le_trans (by simpa [term] using hhead N hNJ) (by norm_num)
  · have hJN : J < N := lt_of_not_ge hNJ
    have hsplit := Finset.sum_range_add_sum_Ico term (Nat.le_of_lt hJN)
    have htail := harmonic_sine_Ico_bound theta hsin J N hJN
    have htail2 :
        |∑ i ∈ Finset.Ico J N, term i| ≤ 2 := by
      have hden : 1 ≤ (((J + 1 : ℕ) : ℝ) * s) := by
        have hcast : (J : ℝ) ≤ ((J + 1 : ℕ) : ℝ) := by
          exact_mod_cast Nat.le_succ J
        have hm := mul_le_mul_of_nonneg_right hcast hspos.le
        exact le_trans hJs1 hm
      have hposden : 0 < (((J + 1 : ℕ) : ℝ) * s) := lt_of_lt_of_le zero_lt_one hden
      have htwo :
          2 / (((J + 1 : ℕ) : ℝ) * s) ≤ 2 := by
        rw [div_le_iff₀ hposden]
        nlinarith
      exact le_trans (by simpa [term, s] using htail) htwo
    have hh := hhead J le_rfl
    rw [← hsplit]
    calc
      |(∑ i ∈ Finset.range J, term i) +
          (∑ i ∈ Finset.Ico J N, term i)|
        ≤ |∑ i ∈ Finset.range J, term i| +
            |∑ i ∈ Finset.Ico J N, term i| := abs_add_le _ _
      _ ≤ 4 + 2 := add_le_add hh htail2
      _ = 6 := by norm_num


lemma harmonic_sine_range_uniform_all (theta : ℝ) (N : ℕ) :
    |∑ i ∈ Finset.range N,
        (1 / ((i + 1 : ℕ) : ℝ)) * Real.sin (theta * (i + 1 : ℕ))|
      ≤ 6 := by
  by_cases hsin : Real.sin (theta / 2) = 0
  · obtain ⟨z, hz⟩ := Real.sin_eq_zero_iff.mp hsin
    have htheta : theta = (z : ℝ) * (2 * Real.pi) := by
      have : theta / 2 = (z : ℝ) * Real.pi := hz.symm
      linarith
    have hzero : ∀ i : ℕ,
        Real.sin (theta * ((i + 1 : ℕ) : ℝ)) = 0 := by
      intro i
      rw [htheta]
      have harg :
          (z : ℝ) * (2 * Real.pi) * ((i + 1 : ℕ) : ℝ) =
            ((z * (i + 1 : ℕ)) : ℤ) * (2 * Real.pi) := by
        push_cast
        ring
      rw [harg]
      simpa using Real.sin_add_int_mul_two_pi 0 (z * (i + 1 : ℕ))
    have hzero' : ∀ i : ℕ,
        Real.sin (theta * ((i : ℝ) + 1)) = 0 := by
      intro i
      simpa using hzero i
    simp [hzero']
  · exact harmonic_sine_range_uniform theta hsin N

lemma harmonic_sine_Ico_uniform_all
    (theta : ℝ) (m n : ℕ) (hmn : m ≤ n) :
    |∑ i ∈ Finset.Ico m n,
        (1 / ((i + 1 : ℕ) : ℝ)) * Real.sin (theta * (i + 1 : ℕ))|
      ≤ 12 := by
  let term : ℕ → ℝ := fun i =>
    (1 / ((i + 1 : ℕ) : ℝ)) * Real.sin (theta * (i + 1 : ℕ))
  have hEq := Finset.sum_Ico_eq_sub term hmn
  rw [hEq]
  calc
    |(∑ i ∈ Finset.range n, term i) -
        (∑ i ∈ Finset.range m, term i)|
      ≤ |∑ i ∈ Finset.range n, term i| +
          |∑ i ∈ Finset.range m, term i| := abs_sub _ _
    _ ≤ 6 + 6 := add_le_add
      (by simpa [term] using harmonic_sine_range_uniform_all theta n)
      (by simpa [term] using harmonic_sine_range_uniform_all theta m)
    _ = 12 := by norm_num


lemma integral_cos_linear {c a b : ℝ} (hc : c ≠ 0) :
    (∫ t : ℝ in a..b, Real.cos (c * t)) =
      Real.sin (c * b) / c - Real.sin (c * a) / c := by
  let F : ℝ → ℝ := fun t => Real.sin (c * t) / c
  have hderiv : ∀ x ∈ Set.uIcc a b,
      HasDerivAt F (Real.cos (c * x)) x := by
    intro x hx
    have hlin : HasDerivAt (fun y : ℝ => c * y) c x := by
      simpa using (hasDerivAt_id x).const_mul c
    have hs := (Real.hasDerivAt_sin (c * x)).comp x hlin
    have hd := hs.div_const c
    dsimp [F] at hd ⊢
    convert hd using 1
    field_simp [hc]
  have hint : IntervalIntegrable (fun t : ℝ => Real.cos (c * t))
      MeasureTheory.volume a b := by
    apply Continuous.intervalIntegrable
    fun_prop
  simpa [F] using
    (intervalIntegral.integral_eq_sub_of_hasDerivAt hderiv hint)

lemma saw_sinc_box_average
    {S : ℝ} (hS : 0 < S) (n : ℕ) (hn : 1 ≤ n) :
    S * (∫ t : ℝ in -(1 / (2 * S))..(1 / (2 * S)),
      Real.cos (2 * Real.pi * (n : ℝ) * t)) =
      S * Real.sin (Real.pi * (n : ℝ) / S) /
        (Real.pi * (n : ℝ)) := by
  have hpi : Real.pi ≠ 0 := Real.pi_ne_zero
  have hn0 : (n : ℝ) ≠ 0 := by
    exact_mod_cast (Nat.ne_of_gt (lt_of_lt_of_le Nat.zero_lt_one hn))
  have hc : 2 * Real.pi * (n : ℝ) ≠ 0 := by positivity
  rw [integral_cos_linear hc]
  have hargp :
      (2 * Real.pi * (n : ℝ)) * (1 / (2 * S)) =
        Real.pi * (n : ℝ) / S := by
    field_simp [ne_of_gt hS]
  have hargn :
      (2 * Real.pi * (n : ℝ)) * (-(1 / (2 * S))) =
        -(Real.pi * (n : ℝ) / S) := by
    rw [mul_neg, hargp]
  rw [hargp, hargn, Real.sin_neg]
  field_simp [hpi, hn0]
  ring


noncomputable def sawSmoothPairReal
    (S : ℝ) (k : ℕ) (x : ℝ) : ℝ :=
  -(S *
      Real.sin (Real.pi * ((k + 1 : ℕ) : ℝ) / S) *
      Real.sin (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * x) /
      (Real.pi ^ 2 * ((k + 1 : ℕ) : ℝ) ^ 2))

lemma sawSmoothPairReal_eq_box_integral
    {S : ℝ} (hS : 0 < S) (k : ℕ) (x : ℝ) :
    sawSmoothPairReal S k x =
      -(S / Real.pi) *
        (∫ t : ℝ in -(1 / (2 * S))..(1 / (2 * S)),
          (1 / ((k + 1 : ℕ) : ℝ)) *
            Real.sin (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * x) *
            Real.cos (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * t)) := by
  let n : ℕ := k + 1
  have hn : 1 ≤ n := by dsimp [n]; omega
  have hnR : (0 : ℝ) < (n : ℝ) := by exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hn)
  have hpi : Real.pi ≠ 0 := Real.pi_ne_zero
  have hsinc := saw_sinc_box_average hS n hn
  have hint :
      (∫ t : ℝ in -(1 / (2 * S))..(1 / (2 * S)),
        (1 / (n : ℝ)) *
          Real.sin (2 * Real.pi * (n : ℝ) * x) *
          Real.cos (2 * Real.pi * (n : ℝ) * t)) =
        ((1 / (n : ℝ)) *
          Real.sin (2 * Real.pi * (n : ℝ) * x)) *
          (∫ t : ℝ in -(1 / (2 * S))..(1 / (2 * S)),
            Real.cos (2 * Real.pi * (n : ℝ) * t)) := by
    rw [← intervalIntegral.integral_const_mul]
  rw [hint]
  unfold sawSmoothPairReal
  dsimp [n] at *
  have hS0 : S ≠ 0 := ne_of_gt hS
  have hkR : (0 : ℝ) < ((k + 1 : ℕ) : ℝ) := by positivity
  have hk0 : (((k + 1 : ℕ) : ℝ)) ≠ 0 := ne_of_gt hkR
  field_simp [hpi, hS0, hk0] at hsinc ⊢
  rw [← hsinc]


lemma harmonic_sine_cos_Ico_uniform
    (x t : ℝ) (K H : ℕ) (hKH : K ≤ H) :
    |∑ k ∈ Finset.Ico K H,
        (1 / ((k + 1 : ℕ) : ℝ)) *
          Real.sin (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * x) *
          Real.cos (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * t)|
      ≤ 12 := by
  let gp : ℕ → ℝ := fun k =>
    (1 / ((k + 1 : ℕ) : ℝ)) *
      Real.sin ((2 * Real.pi * (x + t)) * ((k + 1 : ℕ) : ℝ))
  let gm : ℕ → ℝ := fun k =>
    (1 / ((k + 1 : ℕ) : ℝ)) *
      Real.sin ((2 * Real.pi * (x - t)) * ((k + 1 : ℕ) : ℝ))
  have heq :
      (∑ k ∈ Finset.Ico K H,
        (1 / ((k + 1 : ℕ) : ℝ)) *
          Real.sin (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * x) *
          Real.cos (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * t)) =
        ((∑ k ∈ Finset.Ico K H, gp k) +
          (∑ k ∈ Finset.Ico K H, gm k)) / 2 := by
    calc
      (∑ k ∈ Finset.Ico K H,
        (1 / ((k + 1 : ℕ) : ℝ)) *
          Real.sin (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * x) *
          Real.cos (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * t))
        = ∑ k ∈ Finset.Ico K H, (gp k + gm k) / 2 := by
            apply Finset.sum_congr rfl
            intro k hk
            dsimp [gp, gm]
            have htrig := Real.two_mul_sin_mul_cos
              (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * x)
              (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * t)
            have hargs1 :
                2 * Real.pi * ((k + 1 : ℕ) : ℝ) * x -
                    2 * Real.pi * ((k + 1 : ℕ) : ℝ) * t =
                  (2 * Real.pi * (x - t)) * ((k + 1 : ℕ) : ℝ) := by ring
            have hargs2 :
                2 * Real.pi * ((k + 1 : ℕ) : ℝ) * x +
                    2 * Real.pi * ((k + 1 : ℕ) : ℝ) * t =
                  (2 * Real.pi * (x + t)) * ((k + 1 : ℕ) : ℝ) := by ring
            rw [hargs1, hargs2] at htrig
            calc
              (1 / ((k + 1 : ℕ) : ℝ)) *
                    Real.sin (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * x) *
                    Real.cos (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * t)
                = (1 / ((k + 1 : ℕ) : ℝ)) *
                    (2 * Real.sin (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * x) *
                      Real.cos (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * t)) / 2 := by ring
              _ = (1 / ((k + 1 : ℕ) : ℝ)) *
                    (Real.sin ((2 * Real.pi * (x - t)) * ((k + 1 : ℕ) : ℝ)) +
                      Real.sin ((2 * Real.pi * (x + t)) * ((k + 1 : ℕ) : ℝ))) / 2 := by
                    rw [htrig]
              _ = ((1 / ((k + 1 : ℕ) : ℝ)) *
                    Real.sin ((2 * Real.pi * (x + t)) * ((k + 1 : ℕ) : ℝ)) +
                    (1 / ((k + 1 : ℕ) : ℝ)) *
                    Real.sin ((2 * Real.pi * (x - t)) * ((k + 1 : ℕ) : ℝ))) / 2 := by ring
      _ = (∑ k ∈ Finset.Ico K H, (gp k + gm k)) / 2 := by
            rw [Finset.sum_div]
      _ = ((∑ k ∈ Finset.Ico K H, gp k) +
          (∑ k ∈ Finset.Ico K H, gm k)) / 2 := by
            rw [Finset.sum_add_distrib]
  rw [heq, abs_div]
  norm_num
  have hp :
      |∑ k ∈ Finset.Ico K H, gp k| ≤ 12 := by
    simpa [gp, mul_comm, mul_left_comm, mul_assoc] using
      harmonic_sine_Ico_uniform_all (2 * Real.pi * (x + t)) K H hKH
  have hm :
      |∑ k ∈ Finset.Ico K H, gm k| ≤ 12 := by
    simpa [gm, mul_comm, mul_left_comm, mul_assoc] using
      harmonic_sine_Ico_uniform_all (2 * Real.pi * (x - t)) K H hKH
  calc
    |(∑ k ∈ Finset.Ico K H, gp k) +
        (∑ k ∈ Finset.Ico K H, gm k)| / 2
      ≤ (|∑ k ∈ Finset.Ico K H, gp k| +
          |∑ k ∈ Finset.Ico K H, gm k|) / 2 := by
            gcongr
            exact abs_add_le _ _
    _ ≤ (12 + 12) / 2 := by gcongr
    _ = 12 := by norm_num


lemma sum_sawSmoothPairReal_eq_box_integral
    {S : ℝ} (hS : 0 < S) (x : ℝ) (K H : ℕ) :
    (∑ k ∈ Finset.Ico K H, sawSmoothPairReal S k x) =
      -(S / Real.pi) *
        (∫ t : ℝ in -(1 / (2 * S))..(1 / (2 * S)),
          ∑ k ∈ Finset.Ico K H,
            (1 / ((k + 1 : ℕ) : ℝ)) *
              Real.sin (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * x) *
              Real.cos (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * t)) := by
  calc
    (∑ k ∈ Finset.Ico K H, sawSmoothPairReal S k x)
      = ∑ k ∈ Finset.Ico K H,
          (-(S / Real.pi)) *
            (∫ t : ℝ in -(1 / (2 * S))..(1 / (2 * S)),
              (1 / ((k + 1 : ℕ) : ℝ)) *
                Real.sin (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * x) *
                Real.cos (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * t)) := by
          apply Finset.sum_congr rfl
          intro k hk
          exact sawSmoothPairReal_eq_box_integral hS k x
    _ = (-(S / Real.pi)) *
          ∑ k ∈ Finset.Ico K H,
            (∫ t : ℝ in -(1 / (2 * S))..(1 / (2 * S)),
              (1 / ((k + 1 : ℕ) : ℝ)) *
                Real.sin (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * x) *
                Real.cos (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * t)) := by
          rw [Finset.mul_sum]
    _ = (-(S / Real.pi)) *
        (∫ t : ℝ in -(1 / (2 * S))..(1 / (2 * S)),
          ∑ k ∈ Finset.Ico K H,
            (1 / ((k + 1 : ℕ) : ℝ)) *
              Real.sin (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * x) *
              Real.cos (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * t)) := by
          congr 1
          symm
          apply intervalIntegral.integral_finsetSum
          intro k hk
          apply Continuous.intervalIntegrable
          fun_prop


theorem sum_sawSmoothPairReal_Ico_uniform
    {S : ℝ} (hS : 0 < S) (x : ℝ) (K H : ℕ) (hKH : K ≤ H) :
    |∑ k ∈ Finset.Ico K H, sawSmoothPairReal S k x|
      ≤ 12 / Real.pi := by
  rw [sum_sawSmoothPairReal_eq_box_integral hS]
  let F : ℝ → ℝ := fun t =>
    ∑ k ∈ Finset.Ico K H,
      (1 / ((k + 1 : ℕ) : ℝ)) *
        Real.sin (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * x) *
        Real.cos (2 * Real.pi * ((k + 1 : ℕ) : ℝ) * t)
  have hF : ∀ t : ℝ, |F t| ≤ 12 := by
    intro t
    simpa [F] using harmonic_sine_cos_Ico_uniform x t K H hKH
  have hInt :
      ‖∫ t : ℝ in -(1 / (2 * S))..(1 / (2 * S)), F t‖
        ≤ 12 * |(1 / (2 * S)) - (-(1 / (2 * S)))| := by
    exact intervalIntegral.norm_integral_le_of_norm_le_const
      (fun t ht => by simpa [Real.norm_eq_abs] using hF t)
  have hwidth :
      |(1 / (2 * S)) - (-(1 / (2 * S)))| = 1 / S := by
    have hS0 : S ≠ 0 := ne_of_gt hS
    have hhalf : 0 < (1 / (2 * S) : ℝ) := by positivity
    rw [abs_of_pos (by linarith)]
    field_simp [hS0]
    norm_num
  rw [hwidth] at hInt
  rw [abs_mul, abs_neg, abs_of_pos (div_pos hS Real.pi_pos)]
  rw [show
    (∫ t : ℝ in -(1 / (2 * S))..(1 / (2 * S)),
      ∑ k ∈ Finset.Ico K H,
        1 / ↑(k + 1) *
          Real.sin (2 * Real.pi * ↑(k + 1) * x) *
          Real.cos (2 * Real.pi * ↑(k + 1) * t)) =
      ∫ t : ℝ in -(1 / (2 * S))..(1 / (2 * S)), F t by rfl]
  have hIntAbs :
      |∫ t : ℝ in -(1 / (2 * S))..(1 / (2 * S)), F t|
        ≤ 12 * (1 / S) := by
    simpa [Real.norm_eq_abs] using hInt
  have hcoef : 0 ≤ S / Real.pi := (div_pos hS Real.pi_pos).le
  have hm := mul_le_mul_of_nonneg_left hIntAbs hcoef
  calc
    (S / Real.pi) *
        |∫ t : ℝ in -(1 / (2 * S))..(1 / (2 * S)), F t|
      ≤ (S / Real.pi) * (12 * (1 / S)) := hm
    _ = 12 / Real.pi := by
      field_simp [ne_of_gt hS, Real.pi_ne_zero]


theorem omega_low_transition_moving_fourier_band_uniform
    {S : ℝ} (hS : 1 < S) (x : ℝ) (K H : ℕ) (hKH : K ≤ H) :
    ‖∑ k ∈ Finset.Ico K H,
        sawSmoothPair S k (x : AddCircle (1 : ℝ))‖
      ≤ 12 / Real.pi := by
  have hS0 : 0 < S := lt_trans zero_lt_one hS
  have hreal := sum_sawSmoothPairReal_Ico_uniform hS0 x K H hKH
  have heq :
      (∑ k ∈ Finset.Ico K H,
        sawSmoothPair S k (x : AddCircle (1 : ℝ))) =
        (((∑ k ∈ Finset.Ico K H, sawSmoothPairReal S k x) : ℝ) : ℂ) := by
    rw [Complex.ofReal_sum]
    apply Finset.sum_congr rfl
    intro k hk
    rw [sawSmoothPair_coe_eq_sine_product hS]
    rfl
  rw [heq, Complex.norm_real, Real.norm_eq_abs]
  exact hreal

#print axioms omega_low_transition_moving_fourier_band_uniform

#print axioms sum_sawSmoothPairReal_Ico_uniform

#print axioms sum_sawSmoothPairReal_eq_box_integral

#print axioms harmonic_sine_cos_Ico_uniform

#print axioms sawSmoothPairReal_eq_box_integral

#print axioms integral_cos_linear
#print axioms saw_sinc_box_average

#print axioms harmonic_sine_range_uniform_all
#print axioms harmonic_sine_Ico_uniform_all

#print axioms harmonic_sine_range_uniform

#print axioms abs_sin_nat_mul_le
#print axioms abs_sin_le_two_abs_sin_half

end PaperB.Analytic
