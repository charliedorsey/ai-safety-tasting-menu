import OrielUpper.ShellB

/-!
# Oriel Upper — the three sectors of a product window

For the window `a < r s ≤ b` (with `r, s > 1`) and a cut `R ≥ 1` with `R² ≤ a`:

* S1 `= ∑_{1<r≤R} ∑_{a/r < s ≤ b/r}`,
* S2 `= ∑_{1<s≤R} ∑_{max(a/s,R) < r ≤ b/s}`,
* S3 (`r, s > R`) is dominated by `∑_{R<r≤b/(R+1)} ∑_{max(a/r,1) < s ≤ b/r}`.
-/

open Finset

namespace OrielUpper

/-- The window condition. -/
def winC (a b r s : ℕ) : Prop := 1 < r ∧ 1 < s ∧ a < r * s ∧ r * s ≤ b

instance (a b r s : ℕ) : Decidable (winC a b r s) := by unfold winC; infer_instance

lemma lt_mul_iff_div_lt {a r s : ℕ} (hr : 0 < r) : a < r * s ↔ a / r < s := by
  rw [Nat.div_lt_iff_lt_mul hr, mul_comm]

lemma mul_le_iff_le_div {b r s : ℕ} (hr : 0 < r) : r * s ≤ b ↔ s ≤ b / r := by
  rw [Nat.le_div_iff_mul_le hr, mul_comm]

lemma sector_one (f : ℕ → ℕ → ℝ) {a b R : ℕ} (hR1 : 1 ≤ R) (hRa : R * R ≤ a) (hab : a ≤ b) :
    ∑ r ∈ Icc 1 b, ∑ s ∈ Icc 1 b, (if winC a b r s ∧ r ≤ R then f r s else 0) =
      ∑ r ∈ Ioc 1 R, ∑ s ∈ Ioc (a / r) (b / r), f r s := by
  have hRb : R ≤ b := by nlinarith
  have hin : ∀ r ∈ Icc 1 b, ∑ s ∈ Icc 1 b, (if winC a b r s ∧ r ≤ R then f r s else 0) =
      if 1 < r ∧ r ≤ R then ∑ s ∈ Ioc (a / r) (b / r), f r s else 0 := by
    intro r hr
    by_cases hc : 1 < r ∧ r ≤ R
    · rw [if_pos hc]
      have hr0 : 0 < r := by omega
      have hra : r ≤ a := by nlinarith
      have hA1 : 1 ≤ a / r := (Nat.one_le_div_iff hr0).mpr hra
      apply sum_ite_iff
      intro s
      simp only [mem_Icc, mem_Ioc, winC]
      rw [lt_mul_iff_div_lt hr0, mul_le_iff_le_div hr0]
      have := Nat.div_le_self b r
      constructor
      · rintro ⟨_, ⟨_, _, h1, h2⟩, _⟩; exact ⟨h1, h2⟩
      · rintro ⟨h1, h2⟩; refine ⟨⟨by omega, by omega⟩, ⟨hc.1, by omega, h1, h2⟩, hc.2⟩
    · rw [if_neg hc]
      apply sum_eq_zero
      intro s _
      rw [if_neg]
      rintro ⟨⟨h1, _⟩, h2⟩
      exact hc ⟨h1, h2⟩
  rw [sum_congr rfl hin]
  apply sum_ite_iff
  intro r
  simp only [mem_Icc, mem_Ioc]
  omega

lemma sector_two (f : ℕ → ℕ → ℝ) {a b R : ℕ} (hR1 : 1 ≤ R) (hRa : R * R ≤ a) (hab : a ≤ b) :
    ∑ r ∈ Icc 1 b, ∑ s ∈ Icc 1 b, (if winC a b r s ∧ R < r ∧ s ≤ R then f r s else 0) =
      ∑ s ∈ Ioc 1 R, ∑ r ∈ Ioc (max (a / s) R) (b / s), f r s := by
  have hRb : R ≤ b := by nlinarith
  rw [sum_comm]
  have hin : ∀ s ∈ Icc 1 b,
      ∑ r ∈ Icc 1 b, (if winC a b r s ∧ R < r ∧ s ≤ R then f r s else 0) =
      if 1 < s ∧ s ≤ R then ∑ r ∈ Ioc (max (a / s) R) (b / s), f r s else 0 := by
    intro s hs
    by_cases hc : 1 < s ∧ s ≤ R
    · rw [if_pos hc]
      have hs0 : 0 < s := by omega
      apply sum_ite_iff
      intro r
      simp only [mem_Icc, mem_Ioc, winC, max_lt_iff]
      rw [mul_comm r s, lt_mul_iff_div_lt hs0, mul_le_iff_le_div hs0]
      have := Nat.div_le_self b s
      constructor
      · rintro ⟨_, ⟨_, _, h1, h2⟩, h3, _⟩; exact ⟨⟨h1, h3⟩, h2⟩
      · rintro ⟨⟨h1, h3⟩, h2⟩; refine ⟨⟨by omega, by omega⟩, ⟨by omega, hc.1, h1, h2⟩, h3, hc.2⟩
    · rw [if_neg hc]
      apply sum_eq_zero
      intro r _
      rw [if_neg]
      rintro ⟨⟨_, h1, _⟩, _, h2⟩
      exact hc ⟨h1, h2⟩
  rw [sum_congr rfl hin]
  apply sum_ite_iff
  intro s
  simp only [mem_Icc, mem_Ioc]
  omega

lemma sector_three (f g : ℕ → ℕ → ℝ) (hfg : ∀ r s, |f r s| ≤ g r s) (hg : ∀ r s, 0 ≤ g r s)
    {a b R : ℕ} (hR1 : 1 ≤ R) :
    |∑ r ∈ Icc 1 b, ∑ s ∈ Icc 1 b, (if winC a b r s ∧ R < r ∧ R < s then f r s else 0)| ≤
      ∑ r ∈ Ioc R (b / (R + 1)), ∑ s ∈ Ioc (max (a / r) 1) (b / r), g r s := by
  refine (abs_sum_le_sum_abs _ _).trans ?_
  have hin : ∀ r ∈ Icc 1 b,
      |∑ s ∈ Icc 1 b, (if winC a b r s ∧ R < r ∧ R < s then f r s else 0)| ≤
      if R < r ∧ r ≤ b / (R + 1) then ∑ s ∈ Ioc (max (a / r) 1) (b / r), g r s else 0 := by
    intro r hr
    refine (abs_sum_le_sum_abs _ _).trans ?_
    by_cases hc : R < r ∧ r ≤ b / (R + 1)
    · rw [if_pos hc]
      have hr0 : 0 < r := by omega
      rw [← sum_ite_iff (s := Icc 1 b) (p := fun s => s ∈ Ioc (max (a / r) 1) (b / r))
        (fun s => g r s) (by
          intro s; simp only [mem_Icc, mem_Ioc]
          have := Nat.div_le_self b r
          constructor
          · rintro ⟨_, h⟩; exact h
          · rintro ⟨h1, h2⟩; refine ⟨⟨by omega, by omega⟩, h1, h2⟩)]
      apply sum_le_sum
      intro s _
      rw [abs_ite, abs_zero]
      apply ite_le_ite_of
      · rintro ⟨⟨_, h1, h2, h3⟩, _, _⟩
        simp only [mem_Ioc, max_lt_iff]
        rw [lt_mul_iff_div_lt hr0] at h2
        rw [mul_le_iff_le_div hr0] at h3
        exact ⟨⟨h2, h1⟩, h3⟩
      · intro _; exact hfg r s
      · intro _; exact hg r s
    · rw [if_neg hc]
      apply le_of_eq
      apply sum_eq_zero
      intro s _
      rw [if_neg, abs_zero]
      rintro ⟨⟨_, _, _, h3⟩, h4, h5⟩
      apply hc
      refine ⟨h4, ?_⟩
      rw [Nat.le_div_iff_mul_le (by omega)]
      calc r * (R + 1) ≤ r * s := Nat.mul_le_mul_left r h5
        _ ≤ b := h3
  refine (sum_le_sum hin).trans (le_of_eq ?_)
  apply sum_ite_iff
  intro r
  simp only [mem_Icc, mem_Ioc]
  have := Nat.div_le_self b (R + 1)
  omega

end OrielUpper
