import PaperB.FixedQ.OmegaLinearMean
import PaperB.FixedQ.MovingCoefficientLedger

namespace PaperB.Analytic

open PaperB.FixedQ
open Real

theorem omegaPartialSum_le_const_mul_log
    (q X : ℕ) (hq : 0 < q) (hX : 1 ≤ X)
    (T : ℝ) (hXT : (X : ℝ) ≤ T) (hT : Real.exp 1 ≤ T) :
    omegaPartialSum q X ≤
      ((2 * (6 * q) + 10 : ℕ) : ℝ) * omegaRankinBound * Real.log T := by
  have hmean := omegaPrincipalLogMean_bound q X hq hX
  let R : ℝ := logarithmicEulerResidue (omegaCoeff q)
  let C : ℝ := ((2 * (6 * q) + 9 : ℕ) : ℝ) * omegaRankinBound
  have hR := abs_logarithmicEulerResidue_omega_le_rankin q hq
  have hR0 : 0 ≤ omegaRankinBound := by
    unfold omegaRankinBound
    positivity
  have hXR : (0 : ℝ) < X := by exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hX)
  have hlogX0 : 0 ≤ Real.log (X : ℝ) := Real.log_nonneg (by exact_mod_cast hX)
  have hTpos : 0 < T := (Real.exp_pos 1).trans_le hT
  have hlogXT : Real.log (X : ℝ) ≤ Real.log T :=
    Real.log_le_log hXR hXT
  have hlogT1 : 1 ≤ Real.log T := by
    have hm := Real.log_le_log (Real.exp_pos 1) hT
    simpa using hm
  have hupper :
      omegaPartialSum q X ≤ R * Real.log X + C := by
    have hs :
        omegaPartialSum q X - R * Real.log X ≤ C := by
      have := le_trans (le_abs_self
        (omegaPartialSum q X - R * Real.log X)) hmean
      simpa [R, C] using this
    linarith
  have hRterm :
      R * Real.log X ≤ omegaRankinBound * Real.log T := by
    calc
      R * Real.log X ≤ |R| * Real.log X := by
        exact mul_le_mul_of_nonneg_right (le_abs_self R) hlogX0
      _ ≤ omegaRankinBound * Real.log X := by
        exact mul_le_mul_of_nonneg_right (by simpa [R] using hR) hlogX0
      _ ≤ omegaRankinBound * Real.log T := by
        exact mul_le_mul_of_nonneg_left hlogXT hR0
  have hC0 : 0 ≤ C := by
    dsimp [C]
    positivity
  have hCterm : C ≤ C * Real.log T := by
    nlinarith
  calc
    omegaPartialSum q X
      ≤ R * Real.log X + C := hupper
    _ ≤ omegaRankinBound * Real.log T + C * Real.log T :=
      add_le_add hRterm hCterm
    _ = ((2 * (6 * q) + 10 : ℕ) : ℝ) *
          omegaRankinBound * Real.log T := by
      dsimp [C]
      push_cast
      ring

#print axioms omegaPartialSum_le_const_mul_log

end PaperB.Analytic
