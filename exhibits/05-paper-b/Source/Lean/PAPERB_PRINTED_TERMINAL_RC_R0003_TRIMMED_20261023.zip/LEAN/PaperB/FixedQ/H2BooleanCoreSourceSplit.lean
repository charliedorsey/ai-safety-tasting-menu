import PaperB.FixedQ.H2BooleanGlobalSourceSplit

open scoped BigOperators
open Filter Real Asymptotics

namespace PaperB.FixedQ

/--
Terminal-route exterior: keep the ordinary Boolean core term itself on the
large-product branch.  The older full+endpoint exterior remains available in
`H2BooleanGlobalSourceSplit`, but is not used below.
-/
noncomputable def h2BooleanCoreExteriorTerm
    (q A H N : ℕ) (S : Finset ℕ) : ℝ :=
  if S.Nonempty ∧ N < primeSetProduct S then
    |ordinaryBooleanCoreTerm q A H S|
  else 0

noncomputable def h2BooleanCoreExteriorMajorant
    (q A H N : ℕ) : ℝ :=
  ∑' S : Finset ℕ, h2BooleanCoreExteriorTerm q A H N S

theorem summable_h2BooleanCoreExteriorTerm
    {q A H N : ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H) :
    Summable (h2BooleanCoreExteriorTerm q A H N) := by
  have hAbs := summable_abs_ordinaryBooleanCoreTerm
    (q := q) (a := A) (h := H) hq hH h2admissible
  let E : Set (Finset ℕ) :=
    {S | S.Nonempty ∧ N < primeSetProduct S}
  have hInd : Summable
      (E.indicator (fun S : Finset ℕ =>
        |ordinaryBooleanCoreTerm q A H S|)) :=
    hAbs.indicator E
  exact hInd.congr (fun S => by
    simp [E, h2BooleanCoreExteriorTerm, Set.indicator])

lemma h2BooleanGlobalSmallSummand_nonneg
    (q A H N : ℕ) (S : Finset ℕ) :
    0 ≤
      (if S ∈ h2BooleanGlobalSmallSets q H N then
        ordinaryBooleanFullAbsTerm q A H S +
          ordinaryBooleanFullEndpointAbsTerm q A H S +
          ordinaryBooleanEmptyEndpointAbsTerm q A H S
      else 0) := by
  split_ifs
  · exact h2BooleanCombinedAbsTerm_nonneg q A H S
  · exact le_rfl

lemma abs_ordinaryBooleanCoreTerm_le_small_or_coreExterior
    {q A H N : ℕ} (S : Finset ℕ) :
    |ordinaryBooleanCoreTerm q A H S| ≤
      (if S ∈ h2BooleanGlobalSmallSets q H N then
        ordinaryBooleanFullAbsTerm q A H S +
          ordinaryBooleanFullEndpointAbsTerm q A H S +
          ordinaryBooleanEmptyEndpointAbsTerm q A H S
      else 0) +
      h2BooleanCoreExteriorTerm q A H N S := by
  classical
  by_cases hne : S.Nonempty
  · by_cases hgt : N < primeSetProduct S
    · have hExt :
          h2BooleanCoreExteriorTerm q A H N S =
            |ordinaryBooleanCoreTerm q A H S| := by
        simp [h2BooleanCoreExteriorTerm, hne, hgt]
      rw [hExt]
      exact le_add_of_nonneg_left
        (h2BooleanGlobalSmallSummand_nonneg q A H N S)
    · have hle : primeSetProduct S ≤ N := by omega
      have hExt : h2BooleanCoreExteriorTerm q A H N S = 0 := by
        simp [h2BooleanCoreExteriorTerm, hne, hgt]
      rw [hExt, add_zero]
      by_cases hAct : S ∈ activeOrdinaryTwoDimensionalSet q H
      · have hsmall := h2BooleanGlobalSmallSets_of_active_le hAct hne hle
        rw [if_pos hsmall]
        exact abs_ordinaryBooleanCoreTerm_le_full_add_endpoints q A H S
      · have hz : ordinaryBooleanCoreTerm q A H S = 0 := by
          simp [ordinaryBooleanCoreTerm, Set.indicator, hAct]
        rw [hz, abs_zero]
        exact h2BooleanGlobalSmallSummand_nonneg q A H N S
  · have hS0 : S = ∅ := Finset.not_nonempty_iff_eq_empty.mp hne
    subst S
    rw [ordinaryBooleanCoreTerm_empty, abs_zero]
    have hExt0 : h2BooleanCoreExteriorTerm q A H N ∅ = 0 := by
      simp [h2BooleanCoreExteriorTerm]
    rw [hExt0, add_zero]
    exact h2BooleanGlobalSmallSummand_nonneg q A H N ∅

theorem ordinaryBooleanAbsFamily_le_small_plus_coreExterior
    {q A H N : ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H) :
    ordinaryBooleanAbsFamily q A H ≤
      h2BooleanGlobalSmallMajorant q A H N +
        h2BooleanCoreExteriorMajorant q A H N := by
  classical
  let F := h2BooleanGlobalSmallSets q H N
  let small : Finset ℕ → ℝ := fun S =>
    if S ∈ F then
      ordinaryBooleanFullAbsTerm q A H S +
        ordinaryBooleanFullEndpointAbsTerm q A H S +
        ordinaryBooleanEmptyEndpointAbsTerm q A H S
    else 0
  have hSmall : Summable small := by
    apply summable_of_hasFiniteSupport
    refine F.finite_toSet.subset ?_
    intro S hSupp
    by_contra hmem
    change S ∉ F at hmem
    have hz : small S = 0 := by simp [small, hmem]
    exact hSupp hz
  have hAbs := summable_abs_ordinaryBooleanCoreTerm
    (q := q) (a := A) (h := H) hq hH h2admissible
  have hExt := summable_h2BooleanCoreExteriorTerm
    (q := q) (A := A) (H := H) (N := N) hq hH h2admissible
  have hsum : Summable (fun S =>
      small S + h2BooleanCoreExteriorTerm q A H N S) :=
    hSmall.add hExt
  unfold ordinaryBooleanAbsFamily
  calc
    (∑' S : Finset ℕ, |ordinaryBooleanCoreTerm q A H S|)
      ≤ ∑' S : Finset ℕ,
          (small S + h2BooleanCoreExteriorTerm q A H N S) := by
        exact hAbs.tsum_le_tsum
          (fun S => by
            simpa [small, F] using
              abs_ordinaryBooleanCoreTerm_le_small_or_coreExterior
                (q := q) (A := A) (H := H) (N := N) S)
          hsum
    _ = (∑' S : Finset ℕ, small S) +
        h2BooleanCoreExteriorMajorant q A H N := by
          rw [hSmall.tsum_add hExt]
          rfl
    _ = h2BooleanGlobalSmallMajorant q A H N +
        h2BooleanCoreExteriorMajorant q A H N := by
          congr 1
          rw [tsum_eq_sum (s := F)]
          · unfold h2BooleanGlobalSmallMajorant
            apply Finset.sum_congr
            · rfl
            · intro S hS
              have hSF : S ∈ F := by simpa [F] using hS
              simp [small, hSF]
          · intro S hS
            simp [small, hS]

theorem ordinaryBooleanAbsFamily_le_finite_shells_plus_coreExterior
    {q A H N : ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H) :
    ordinaryBooleanAbsFamily q A H ≤
      (∑ i ∈ Finset.range N,
        h2BooleanCombinedDyadicShell q A H i) +
      h2BooleanCoreExteriorMajorant q A H N := by
  exact (ordinaryBooleanAbsFamily_le_small_plus_coreExterior
    hq hH h2admissible).trans
      (add_le_add h2BooleanGlobalSmallMajorant_le_dyadic_sum
        (le_refl (h2BooleanCoreExteriorMajorant q A H N)))

def H2BooleanCoreExteriorGlobalBound (q : ℕ) : Prop :=
  ∃ Cext : ℝ, ∃ H0 : ℕ,
    0 ≤ Cext ∧
    ∀ A H : ℕ,
      q.Coprime A →
      0 < H →
      (¬ 2 ∣ q → 2 ∣ H) →
      H0 ≤ H →
      h2BooleanCoreExteriorMajorant
          q A H (h2BooleanSourceCutoff H) ≤
        Cext *
          (Real.log (H : ℝ)) ^
            (h2BooleanSigma * h2BooleanX0) *
          (Real.log (Real.log (H : ℝ))) ^ 2

theorem ordinaryBooleanAbsFamily_source_split_of_coreExterior_bound
    {q A H : ℕ} (hq : 0 < q)
    (hH : 0 < H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H)
    {Cext : ℝ}
    (hExt :
      h2BooleanCoreExteriorMajorant
          q A H (h2BooleanSourceCutoff H) ≤
        Cext *
          (Real.log (H : ℝ)) ^
            (h2BooleanSigma * h2BooleanX0) *
          (Real.log (Real.log (H : ℝ))) ^ 2) :
    (h2BooleanSourceCutoff H : ℝ) ≤
        (Real.log (H : ℝ)) ^ h2BooleanSigma
    ∧
    ordinaryBooleanAbsFamily q A H ≤
      (∑ i ∈ Finset.range (h2BooleanSourceCutoff H),
        h2BooleanCombinedDyadicShell q A H i) +
      h2BooleanCoreExteriorMajorant
        q A H (h2BooleanSourceCutoff H)
    ∧
    h2BooleanCoreExteriorMajorant
        q A H (h2BooleanSourceCutoff H) ≤
      Cext *
        (Real.log (H : ℝ)) ^
          (h2BooleanSigma * h2BooleanX0) *
        (Real.log (Real.log (H : ℝ))) ^ 2 := by
  refine ⟨h2BooleanSourceCutoff_cast_le hH, ?_, hExt⟩
  exact ordinaryBooleanAbsFamily_le_finite_shells_plus_coreExterior
    hq hH h2admissible

theorem ordinaryBooleanAbsFamily_le_source_shells_plus_coreExterior_rate_of_auren
    (q : ℕ) (hq : 0 < q)
    (hAuren : H2BooleanCoreExteriorGlobalBound q) :
    ∃ Cext : ℝ, ∃ H0 : ℕ,
      0 ≤ Cext ∧
      ∀ A H : ℕ,
        q.Coprime A →
        0 < H →
        (¬ 2 ∣ q → 2 ∣ H) →
        H0 ≤ H →
        let N := h2BooleanSourceCutoff H
        (N : ℝ) ≤ (Real.log (H : ℝ)) ^ h2BooleanSigma
        ∧
        ordinaryBooleanAbsFamily q A H ≤
          (∑ i ∈ Finset.range N,
            h2BooleanCombinedDyadicShell q A H i) +
          h2BooleanCoreExteriorMajorant q A H N
        ∧
        h2BooleanCoreExteriorMajorant q A H N ≤
          Cext *
            (Real.log (H : ℝ)) ^
              (h2BooleanSigma * h2BooleanX0) *
            (Real.log (Real.log (H : ℝ))) ^ 2 := by
  rcases hAuren with ⟨Cext, H0, hCext, hExt⟩
  refine ⟨Cext, H0, hCext, ?_⟩
  intro A H hA hH h2 hH0
  dsimp
  exact ordinaryBooleanAbsFamily_source_split_of_coreExterior_bound
    hq hH h2 (hExt A H hA hH h2 hH0)

#print axioms summable_h2BooleanCoreExteriorTerm
#print axioms ordinaryBooleanAbsFamily_le_finite_shells_plus_coreExterior
#print axioms ordinaryBooleanAbsFamily_source_split_of_coreExterior_bound
#print axioms ordinaryBooleanAbsFamily_le_source_shells_plus_coreExterior_rate_of_auren

end PaperB.FixedQ
