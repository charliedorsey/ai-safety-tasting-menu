import Orienne.CSC3.CorePaidTerminalConsumerR0001
import Orienne.Central.HighCardRateR0002

/-! Literal terminal reduction with independently verified native CORE
and original physical HIGH. Remaining source rates: LOW and LONG. -/

open scoped BigOperators Classical
namespace Orienne.CSC3

theorem paperB_terminal_of_native_low_long
    (Jlow : ℕ → ℕ) (δ : ℝ)
    (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3)
    (hord : ∀ h, Jlow h ≤ GoldC.orienneCentralHighCut h)
    (hLow : Merivelle.Central.SourceUniformSublog
      (Merivelle.Central.lowSector Jlow))
    (hLong : Merivelle.Central.SourceUniformSublog
      (Merivelle.Central.signedLongMiddle Jlow GoldC.orienneCentralHighCut δ)) :
    PaperB.Closure.PaperBTerminalStatement :=
  paperB_terminal_of_native_low_high_long
    Jlow GoldC.orienneCentralHighCut δ hδ0 hδ1
    hord hLow Merivelle.Central.orienne_highSector_sublog hLong

#print axioms paperB_terminal_of_native_low_long
end Orienne.CSC3
