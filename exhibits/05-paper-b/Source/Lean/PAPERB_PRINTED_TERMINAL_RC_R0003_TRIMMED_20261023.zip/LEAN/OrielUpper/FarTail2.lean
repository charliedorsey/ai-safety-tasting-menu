import OrielUpper.FarTail

/-!
# Oriel Upper — far tail assembly
-/

open Finset

namespace OrielUpper

variable {P : ℕ} [NeZero P]

lemma abs_rowMass_le {F H : ℕ} {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {B : ℝ}
    (hR : RowHyp P F H w Λ B) (r s : ℕ) :
    |rowMass w H r s| ≤ B * ∑ y ∈ Ioo 0 H, (if r ∣ y ∧ s ∣ H - y then (1 : ℝ) else 0) := by
  unfold rowMass
  refine (abs_sum_le_sum_abs _ _).trans ?_
  rw [mul_sum]
  apply sum_le_sum
  intro y hy
  have hy' := mem_Ioo.mp hy
  split_ifs
  · rw [hR.hw y hy'.1 hy'.2, mul_one]; exact hR.hB _
  · simp

lemma abs_rowW_le {F H : ℕ} {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {B : ℝ}
    (hR : RowHyp P F H w Λ B) : |rowW w H| ≤ B * H := by
  unfold rowW
  refine (abs_sum_le_sum_abs _ _).trans ?_
  calc ∑ y ∈ Ioo 0 H, |w y| ≤ ∑ y ∈ Ioo 0 H, B := by
        apply sum_le_sum; intro y hy
        have hy' := mem_Ioo.mp hy
        rw [hR.hw y hy'.1 hy'.2]; exact hR.hB _
    _ = B * ((H - 1 : ℕ) : ℝ) := by
        rw [sum_const, Nat.card_Ioo, nsmul_eq_mul, mul_comm]; simp
    _ ≤ B * H := by
        apply mul_le_mul_of_nonneg_left _ hR.B_nonneg
        exact_mod_cast Nat.sub_le H 1

lemma tail_pt {F H : ℕ} {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {B : ℝ}
    (hR : RowHyp P F H w Λ B) {Y r s : ℕ} (hY : 1 ≤ Y) (hrs : Y < r * s) :
    |pairTerm F H w r s| ≤
      B / Y * (gW F r * gW F s *
        ∑ y ∈ Ioo 0 H, (if r ∣ y ∧ s ∣ H - y then (1 : ℝ) else 0)) +
      B * H / Y * (bW F r * bW F s) := by
  have hB0 := hR.B_nonneg
  have hr0 : 0 < r := Nat.pos_of_ne_zero (by rintro rfl; simp at hrs)
  have hs0 : 0 < s := Nat.pos_of_ne_zero (by rintro rfl; simp at hrs)
  have hYr : (0 : ℝ) < Y := by exact_mod_cast (show 0 < Y by omega)
  have hrsr : (Y : ℝ) < (r : ℝ) * s := by exact_mod_cast hrs
  have hrsp : (0 : ℝ) < (r : ℝ) * s := by linarith
  set I := ∑ y ∈ Ioo 0 H, (if r ∣ y ∧ s ∣ H - y then (1 : ℝ) else 0)
  have hI : 0 ≤ I := sum_nonneg (fun y _ => by split_ifs <;> norm_num)
  have hgr := gW_nonneg F r
  have hgs := gW_nonneg F s
  have hbb : 0 ≤ bW F r * bW F s := mul_nonneg (bW_nonneg F r) (bW_nonneg F s)
  have h1 : |pairTerm F H w r s| ≤ bW F r * bW F s * |rowDisc w H r s| := by
    unfold pairTerm
    rw [abs_mul, abs_of_nonneg (mul_nonneg (bW_nonneg _ _) (bW_nonneg _ _))]
    apply mul_le_mul_of_nonneg_right _ (abs_nonneg _)
    exact mul_le_mul_of_nonneg_left (bW_mul_le F r s) (bW_nonneg F r)
  have h2 : |rowDisc w H r s| ≤ B * I + B * H / ((r : ℝ) * s) := by
    unfold rowDisc
    refine (abs_sub _ _).trans (add_le_add (abs_rowMass_le hR r s) ?_)
    rw [abs_div, abs_of_pos hrsp]
    exact div_le_div_of_nonneg_right (abs_rowW_le hR) hrsp.le
  have hbW : bW F r * bW F s = gW F r * gW F s / ((r : ℝ) * s) := by
    unfold bW; field_simp
  calc |pairTerm F H w r s| ≤ bW F r * bW F s * (B * I + B * H / ((r : ℝ) * s)) :=
        h1.trans (mul_le_mul_of_nonneg_left h2 hbb)
    _ = gW F r * gW F s * (B * I) / ((r : ℝ) * s) +
          bW F r * bW F s * (B * H) / ((r : ℝ) * s) := by rw [hbW]; ring
    _ ≤ gW F r * gW F s * (B * I) / Y + bW F r * bW F s * (B * H) / Y := by
        gcongr
    _ = _ := by ring

theorem far_tail {F H : ℕ} {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {B : ℝ}
    (hR : RowHyp P F H w Λ B) {Y U : ℕ} (hY : 1 ≤ Y) (hU : 1 ≤ U) {E1 : ℝ}
    (hE1 : ∀ N, Asig F N 1 ≤ E1) :
    |pairWin F H w Y U| ≤ B * H / Y * (PiH H + (1 + E1 * (1 + Real.log U)) ^ 2) := by
  have hB0 := hR.B_nonneg
  have hYr : (0 : ℝ) < Y := by exact_mod_cast (show 0 < Y by omega)
  unfold pairWin
  refine (abs_sum_le_sum_abs _ _).trans ?_
  set J := fun r s => ∑ y ∈ Ioo 0 H, (if r ∣ y ∧ s ∣ H - y then (1 : ℝ) else 0)
  have hpt : ∀ r ∈ Icc 1 U, |∑ s ∈ Icc 1 U, if winC Y U r s then pairTerm F H w r s else 0| ≤
      ∑ s ∈ Icc 1 U, (B / Y * (gW F r * gW F s * J r s) + B * H / Y * (bW F r * bW F s)) := by
    intro r _
    refine (abs_sum_le_sum_abs _ _).trans (sum_le_sum ?_)
    intro s _
    have hJ : 0 ≤ J r s := sum_nonneg (fun y _ => by split_ifs <;> norm_num)
    have hnn : 0 ≤ B / Y * (gW F r * gW F s * J r s) + B * H / Y * (bW F r * bW F s) := by
      have := gW_nonneg F r; have := gW_nonneg F s
      have := bW_nonneg F r; have := bW_nonneg F s
      positivity
    split_ifs with hc
    · exact tail_pt hR hY hc.2.2.1
    · simpa using hnn
  refine (sum_le_sum hpt).trans ?_
  simp only [sum_add_distrib]
  -- part 1: constrained mass
  have hP1 : ∑ r ∈ Icc 1 U, ∑ s ∈ Icc 1 U, B / (Y : ℝ) * (gW F r * gW F s * J r s) ≤
      B / (Y : ℝ) * ((H : ℝ) * PiH H) := by
    have e : ∑ r ∈ Icc 1 U, ∑ s ∈ Icc 1 U, B / (Y : ℝ) * (gW F r * gW F s * J r s) =
        B / (Y : ℝ) * ∑ y ∈ Ioo 0 H,
          (∑ r ∈ Icc 1 U, if r ∣ y then gW F r else 0) *
            (∑ s ∈ Icc 1 U, if s ∣ H - y then gW F s else 0) := by
      calc ∑ r ∈ Icc 1 U, ∑ s ∈ Icc 1 U, B / (Y : ℝ) * (gW F r * gW F s * J r s)
          = ∑ r ∈ Icc 1 U, ∑ s ∈ Icc 1 U, ∑ y ∈ Ioo 0 H,
              B / (Y : ℝ) * (gW F r * gW F s * (if r ∣ y ∧ s ∣ H - y then (1 : ℝ) else 0)) := by
            simp only [J, mul_sum]
        _ = ∑ r ∈ Icc 1 U, ∑ y ∈ Ioo 0 H, ∑ s ∈ Icc 1 U,
              B / (Y : ℝ) * (gW F r * gW F s * (if r ∣ y ∧ s ∣ H - y then (1 : ℝ) else 0)) := by
            apply sum_congr rfl; intro r _; rw [sum_comm]
        _ = ∑ y ∈ Ioo 0 H, ∑ r ∈ Icc 1 U, ∑ s ∈ Icc 1 U,
              B / (Y : ℝ) * (gW F r * gW F s * (if r ∣ y ∧ s ∣ H - y then (1 : ℝ) else 0)) := by
            rw [sum_comm]
        _ = _ := by
            rw [mul_sum]
            apply sum_congr rfl; intro y _
            rw [sum_mul_sum, mul_sum]
            apply sum_congr rfl; intro r _
            rw [mul_sum]
            apply sum_congr rfl; intro s _
            by_cases h1 : r ∣ y <;> by_cases h2 : s ∣ H - y <;> simp [h1, h2]
    rw [e]
    apply mul_le_mul_of_nonneg_left _ (by positivity)
    refine le_trans ?_ (cross_moment F H)
    apply sum_le_sum
    intro y hy
    have hy' := mem_Ioo.mp hy
    have hG : ∀ n, 0 < n → (∑ r ∈ Icc 1 U, if r ∣ n then gW F r else 0) ≤ Gdiv F n := by
      intro n hn
      unfold Gdiv
      rw [← sum_filter]
      apply sum_le_sum_of_subset_of_nonneg
      · intro r hr
        simp only [mem_filter, mem_Icc] at hr
        exact Nat.mem_divisors.mpr ⟨hr.2, hn.ne'⟩
      · intro r _ _; exact gW_nonneg F r
    have h0 : ∀ n, 0 ≤ ∑ r ∈ Icc 1 U, (if r ∣ n then gW F r else 0) :=
      fun n => sum_nonneg (fun r _ => by split_ifs; exact gW_nonneg F r; exact le_rfl)
    exact mul_le_mul (hG y hy'.1) (hG (H - y) (by omega)) (h0 _) (Gdiv_nonneg F y)
  -- part 2: the centering mass
  have hP2 : ∑ r ∈ Icc 1 U, ∑ s ∈ Icc 1 U, B * (H : ℝ) / (Y : ℝ) * (bW F r * bW F s) ≤
      B * (H : ℝ) / (Y : ℝ) * (1 + E1 * (1 + Real.log U)) ^ 2 := by
    have e : ∑ r ∈ Icc 1 U, ∑ s ∈ Icc 1 U, B * (H : ℝ) / (Y : ℝ) * (bW F r * bW F s) =
        B * (H : ℝ) / (Y : ℝ) * (∑ r ∈ Icc 1 U, bW F r) ^ 2 := by
      rw [pow_two, sum_mul_sum, mul_sum]
      apply sum_congr rfl; intro r _; rw [mul_sum]
    rw [e]
    apply mul_le_mul_of_nonneg_left _ (by positivity)
    have hs : ∑ r ∈ Icc 1 U, bW F r ≤ 1 + E1 * (1 + Real.log U) := by
      have hIcc : Icc 1 U = insert 1 (Ioc 1 U) := by
        ext r; simp only [mem_Icc, mem_insert, mem_Ioc]; omega
      rw [hIcc, sum_insert (by simp)]
      have h1 : bW F 1 = 1 := by simp [bW, gW_one]
      rw [h1]
      linarith [sum_bW_Ioc_one_le (F := F) hU (hE1 U)]
    exact pow_le_pow_left₀ (sum_nonneg (fun r _ => bW_nonneg F r)) hs 2
  calc _ ≤ B / (Y : ℝ) * ((H : ℝ) * PiH H) + B * (H : ℝ) / (Y : ℝ) * (1 + E1 * (1 + Real.log U)) ^ 2 :=
        add_le_add hP1 hP2
    _ = _ := by ring

end OrielUpper
