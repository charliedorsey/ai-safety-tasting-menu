import PaperB.Analytic.SawtoothSmoothing
import Mathlib.Analysis.Complex.RealDeriv
import Mathlib.Analysis.SpecialFunctions.Integrals.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds

open Real Set MeasureTheory

namespace PaperB.Analytic

lemma exp_linear_hasDerivAt (c : ℂ) (x : ℝ) :
    HasDerivAt (fun y : ℝ => Complex.exp (c * (y : ℂ)))
      (Complex.exp (c * (x : ℂ)) * c) x := by
  have hlin : HasDerivAt (fun z : ℂ => c * z) c (x : ℂ) := by
    simpa using (hasDerivAt_id (x : ℂ)).const_mul c
  have h := (Complex.hasDerivAt_exp (c * (x : ℂ))).comp (x : ℂ) hlin
  simpa [Function.comp_def, mul_assoc] using h.comp_ofReal

lemma affine_complex_hasDerivAt (m d : ℝ) (x : ℝ) :
    HasDerivAt (fun y : ℝ => ((m * y + d : ℝ) : ℂ)) (m : ℂ) x := by
  have hreal : HasDerivAt (fun y : ℝ => m * y + d) m x := by
    simpa using ((hasDerivAt_id x).const_mul m).const_add d
  simpa using hreal.ofReal_comp

lemma exp_div_hasDerivAt (c : ℂ) (hc : c ≠ 0) (x : ℝ) :
    HasDerivAt (fun y : ℝ => Complex.exp (c * (y : ℂ)) / c)
      (Complex.exp (c * (x : ℂ))) x := by
  have h := (exp_linear_hasDerivAt c x).div_const c
  convert h using 1
  field_simp [hc]

lemma integral_exp_mul_affine
    (a b m d : ℝ) (c : ℂ) (hc : c ≠ 0) :
    (∫ x : ℝ in a..b,
      Complex.exp (c * (x : ℂ)) * ((m * x + d : ℝ) : ℂ)) =
      (((m * b + d : ℝ) : ℂ) * (Complex.exp (c * (b : ℂ)) / c)
       - ((m * a + d : ℝ) : ℂ) * (Complex.exp (c * (a : ℂ)) / c))
      - (m : ℂ) / c *
          ((Complex.exp (c * (b : ℂ)) - Complex.exp (c * (a : ℂ))) / c) := by
  let u : ℝ → ℂ := fun x => ((m * x + d : ℝ) : ℂ)
  let v : ℝ → ℂ := fun x => Complex.exp (c * (x : ℂ)) / c
  have hu : ∀ x ∈ Set.uIcc a b, HasDerivAt u (m : ℂ) x := by
    intro x hx
    exact affine_complex_hasDerivAt m d x
  have hv : ∀ x ∈ Set.uIcc a b,
      HasDerivAt v (Complex.exp (c * (x : ℂ))) x := by
    intro x hx
    exact exp_div_hasDerivAt c hc x
  have hu' : IntervalIntegrable (fun _ : ℝ => (m : ℂ)) volume a b :=
    continuous_const.intervalIntegrable _ _
  have hv' : IntervalIntegrable
      (fun x : ℝ => Complex.exp (c * (x : ℂ))) volume a b := by
    apply Continuous.intervalIntegrable
    fun_prop
  have hibp := intervalIntegral.integral_mul_deriv_eq_deriv_mul
    hu hv hu' hv'
  have hrem :
      (∫ x : ℝ in a..b, (m : ℂ) * v x) =
        (m : ℂ) / c *
          ((Complex.exp (c * (b : ℂ)) - Complex.exp (c * (a : ℂ))) / c) := by
    calc
      (∫ x : ℝ in a..b, (m : ℂ) * v x)
          = ∫ x : ℝ in a..b, ((m : ℂ) / c) *
              Complex.exp (c * (x : ℂ)) := by
                apply intervalIntegral.integral_congr
                intro x hx
                dsimp [v]
                field_simp [hc]
      _ = ((m : ℂ) / c) *
          (∫ x : ℝ in a..b, Complex.exp (c * (x : ℂ))) := by
            rw [intervalIntegral.integral_const_mul]
      _ = (m : ℂ) / c *
          ((Complex.exp (c * (b : ℂ)) - Complex.exp (c * (a : ℂ))) / c) := by
            rw [integral_exp_mul_complex hc]
  dsimp [u, v] at hibp
  rw [hrem] at hibp
  simpa [mul_comm] using hibp


noncomputable def sawSmoothFreq (n : ℤ) : ℂ :=
  -2 * (Real.pi : ℂ) * Complex.I * (n : ℂ)

noncomputable def sawSmoothCoeff (T : ℝ) (n : ℤ) : ℂ :=
  ∫ x : ℝ in 0..1,
    Complex.exp (sawSmoothFreq n * (x : ℂ)) * (smoothedSawCell T x : ℂ)

lemma sawSmoothFreq_ne_zero {n : ℤ} (hn : n ≠ 0) :
    sawSmoothFreq n ≠ 0 := by
  rw [sawSmoothFreq]
  have hpi : (Real.pi : ℂ) ≠ 0 := by exact_mod_cast Real.pi_ne_zero
  have hnC : (n : ℂ) ≠ 0 := by exact_mod_cast hn
  exact mul_ne_zero (mul_ne_zero (mul_ne_zero (by norm_num) hpi) Complex.I_ne_zero) hnC

lemma exp_sawSmoothFreq_one (n : ℤ) :
    Complex.exp (sawSmoothFreq n) = 1 := by
  rw [sawSmoothFreq]
  have h := Complex.exp_int_mul_two_pi_mul_I (-n)
  convert h using 1 <;> push_cast <;> ring_nf

lemma smoothedSawCell_left_eq {T x : ℝ} (hx : x ≤ sawSmoothHalfWidth T) :
    smoothedSawCell T x = (1 - T) * x := by
  rw [smoothedSawCell, if_pos hx]

lemma smoothedSawCell_middle_eq {T x : ℝ} (hT : 1 < T)
    (hx1 : sawSmoothHalfWidth T ≤ x)
    (hx2 : x ≤ 1 - sawSmoothHalfWidth T) :
    smoothedSawCell T x = x - 1 / 2 := by
  by_cases heq : x = sawSmoothHalfWidth T
  · subst x
    rw [smoothedSawCell, if_pos le_rfl]
    have hT0 : 0 < T := lt_trans zero_lt_one hT
    have hTne : T ≠ 0 := ne_of_gt hT0
    rw [sawSmoothHalfWidth]
    field_simp [hTne]
  · rw [smoothedSawCell, if_neg (not_le.mpr (lt_of_le_of_ne hx1 (Ne.symm heq))),
      if_pos hx2]

lemma smoothedSawCell_right_eq {T x : ℝ} (hT : 1 < T)
    (hx : 1 - sawSmoothHalfWidth T ≤ x) :
    smoothedSawCell T x = (1 - T) * (x - 1) := by
  by_cases heq : x = 1 - sawSmoothHalfWidth T
  · subst x
    rw [smoothedSawCell]
    have ha := sawSmoothHalfWidth_lt_half hT
    have hnot : ¬ (1 - sawSmoothHalfWidth T ≤ sawSmoothHalfWidth T) := by linarith
    rw [if_neg hnot, if_pos le_rfl]
    have hT0 : 0 < T := lt_trans zero_lt_one hT
    have hTne : T ≠ 0 := ne_of_gt hT0
    rw [sawSmoothHalfWidth]
    field_simp [hTne]
    ring
  · have hgt : 1 - sawSmoothHalfWidth T < x := lt_of_le_of_ne hx (Ne.symm heq)
    have ha := sawSmoothHalfWidth_lt_half hT
    have hnot1 : ¬ x ≤ sawSmoothHalfWidth T := by linarith
    have hnot2 : ¬ x ≤ 1 - sawSmoothHalfWidth T := not_le.mpr hgt
    rw [smoothedSawCell, if_neg hnot1, if_neg hnot2]

lemma sawSmoothCoeff_eq_exp_difference
    {T : ℝ} (hT : 1 < T) {n : ℤ} (hn : n ≠ 0) :
    sawSmoothCoeff T n =
      T / (sawSmoothFreq n) ^ 2 *
        (Complex.exp (sawSmoothFreq n * (sawSmoothHalfWidth T : ℂ)) -
         Complex.exp (-(sawSmoothFreq n * (sawSmoothHalfWidth T : ℂ)))) := by
  let a : ℝ := sawSmoothHalfWidth T
  let b : ℝ := 1 - sawSmoothHalfWidth T
  let c : ℂ := sawSmoothFreq n
  let F : ℝ → ℂ := fun x =>
    Complex.exp (c * (x : ℂ)) * (smoothedSawCell T x : ℂ)
  have hT0 : 0 < T := lt_trans zero_lt_one hT
  have ha0 : 0 ≤ a := (sawSmoothHalfWidth_pos hT0).le
  have hab : a ≤ b := sawSmoothHalfWidth_le_one_sub hT.le
  have hb1 : b ≤ 1 := by
    dsimp [b]
    linarith [sawSmoothHalfWidth_pos hT0]
  have hc : c ≠ 0 := by
    dsimp [c]
    exact sawSmoothFreq_ne_zero hn
  have hFcont : Continuous F := by
    dsimp [F]
    have hexp : Continuous (fun x : ℝ => Complex.exp (c * (x : ℂ))) := by
      fun_prop
    have hcell : Continuous (fun x : ℝ => (smoothedSawCell T x : ℂ)) := by
      simpa [Function.comp_def] using
        Complex.continuous_ofReal.comp (continuous_smoothedSawCell hT)
    exact hexp.mul hcell
  have hFint : ∀ u v : ℝ, IntervalIntegrable F volume u v :=
    fun u v => hFcont.intervalIntegrable u v
  have hleft :
      (∫ x : ℝ in 0..a, F x) =
        ∫ x : ℝ in 0..a,
          Complex.exp (c * (x : ℂ)) * (((1 - T) * x : ℝ) : ℂ) := by
    apply intervalIntegral.integral_congr
    intro x hx
    rw [Set.uIcc_of_le ha0] at hx
    dsimp [F]
    rw [smoothedSawCell_left_eq hx.2]
  have hmid :
      (∫ x : ℝ in a..b, F x) =
        ∫ x : ℝ in a..b,
          Complex.exp (c * (x : ℂ)) * (((x - 1/2 : ℝ)) : ℂ) := by
    apply intervalIntegral.integral_congr
    intro x hx
    rw [Set.uIcc_of_le hab] at hx
    dsimp [F]
    rw [smoothedSawCell_middle_eq hT hx.1 hx.2]
  have hright :
      (∫ x : ℝ in b..1, F x) =
        ∫ x : ℝ in b..1,
          Complex.exp (c * (x : ℂ)) * ((((1 - T) * (x - 1) : ℝ)) : ℂ) := by
    apply intervalIntegral.integral_congr
    intro x hx
    rw [Set.uIcc_of_le hb1] at hx
    dsimp [F]
    rw [smoothedSawCell_right_eq hT hx.1]
  have hsplit1 := intervalIntegral.integral_add_adjacent_intervals
    (hFint 0 a) (hFint a b)
  have habInt : IntervalIntegrable F volume 0 b := (hFint 0 a).trans (hFint a b)
  have hsplit2 := intervalIntegral.integral_add_adjacent_intervals habInt (hFint b 1)
  have h01 :
      (∫ x : ℝ in 0..1, F x) =
        (∫ x : ℝ in 0..a, F x) +
        (∫ x : ℝ in a..b, F x) +
        (∫ x : ℝ in b..1, F x) := by
    rw [← hsplit2, ← hsplit1]
  rw [sawSmoothCoeff]
  change (∫ x : ℝ in 0..1, F x) = _
  rw [h01, hleft, hmid, hright]
  have hI1 := integral_exp_mul_affine 0 a (1 - T) 0 c hc
  have hI2 := integral_exp_mul_affine a b 1 (-1/2) c hc
  have hI3 := integral_exp_mul_affine b 1 (1 - T) (T - 1) c hc
  have hI1' :
      (∫ x : ℝ in 0..a,
        Complex.exp (c * (x : ℂ)) * (((1 - T) * x : ℝ) : ℂ)) =
        (((((1 - T) * a + 0 : ℝ) : ℂ) * (Complex.exp (c * (a : ℂ)) / c)
          - ((((1 - T) * 0 + 0 : ℝ) : ℂ) * (Complex.exp (c * (0 : ℂ)) / c)))
        - (((1 - T : ℝ) : ℂ) / c) *
          ((Complex.exp (c * (a : ℂ)) - Complex.exp (c * (0 : ℂ))) / c)) := by
    simpa using hI1
  have hI2' :
      (∫ x : ℝ in a..b,
        Complex.exp (c * (x : ℂ)) * (((x - 1/2 : ℝ)) : ℂ)) =
        ((((1 * b + (-1/2) : ℝ) : ℂ) * (Complex.exp (c * (b : ℂ)) / c)
          - (((1 * a + (-1/2) : ℝ) : ℂ) * (Complex.exp (c * (a : ℂ)) / c)))
        - ((1 : ℂ) / c) *
          ((Complex.exp (c * (b : ℂ)) - Complex.exp (c * (a : ℂ))) / c)) := by
    convert hI2 using 1 <;> ring
  have hI3' :
      (∫ x : ℝ in b..1,
        Complex.exp (c * (x : ℂ)) * ((((1 - T) * (x - 1) : ℝ)) : ℂ)) =
        (((((1 - T) * 1 + (T - 1) : ℝ) : ℂ) * (Complex.exp (c * (1 : ℂ)) / c)
          - ((((1 - T) * b + (T - 1) : ℝ) : ℂ) * (Complex.exp (c * (b : ℂ)) / c)))
        - (((1 - T : ℝ) : ℂ) / c) *
          ((Complex.exp (c * (1 : ℂ)) - Complex.exp (c * (b : ℂ))) / c)) := by
    convert hI3 using 1 <;> ring
  rw [hI1', hI2', hI3']
  dsimp [a, b, c]
  simp only [Complex.ofReal_zero, Complex.ofReal_one, mul_zero, mul_one,
    Complex.exp_zero, zero_add, add_zero, sub_zero, one_mul]
  rw [exp_sawSmoothFreq_one n]
  have hneg :
      Complex.exp (sawSmoothFreq n * ((1 - sawSmoothHalfWidth T : ℝ) : ℂ)) =
        Complex.exp (-(sawSmoothFreq n * (sawSmoothHalfWidth T : ℂ))) := by
    rw [show sawSmoothFreq n * ((1 - sawSmoothHalfWidth T : ℝ) : ℂ)
      = sawSmoothFreq n + (-(sawSmoothFreq n * (sawSmoothHalfWidth T : ℂ))) by
        push_cast; ring, Complex.exp_add, exp_sawSmoothFreq_one, one_mul]
  rw [hneg]
  rw [sawSmoothHalfWidth]
  have hTne : (T : ℂ) ≠ 0 := by
    exact_mod_cast (ne_of_gt hT0)
  field_simp [sawSmoothFreq_ne_zero hn, hTne]
  norm_num
  push_cast
  ring


lemma sawSmoothFreq_norm {n : ℤ} :
    ‖sawSmoothFreq n‖ = 2 * Real.pi * |(n : ℝ)| := by
  simp [sawSmoothFreq, norm_mul, Complex.norm_real, Real.norm_eq_abs,
    abs_of_pos Real.pi_pos]

lemma sawSmoothCoeff_le_quadratic
    {T : ℝ} (hT : 1 < T) {n : ℤ} (hn : n ≠ 0) :
    ‖sawSmoothCoeff T n‖ ≤
      T / (2 * Real.pi ^ 2 * ((n : ℝ) ^ 2)) := by
  rw [sawSmoothCoeff_eq_exp_difference hT hn, norm_mul, norm_div, norm_pow,
    sawSmoothFreq_norm]
  have hT0 : 0 < T := lt_trans zero_lt_one hT
  have hn0 : (n : ℝ) ≠ 0 := by exact_mod_cast hn
  have hnabs : 0 < |(n : ℝ)| := abs_pos.mpr hn0
  have hnum :
      ‖Complex.exp (sawSmoothFreq n * (sawSmoothHalfWidth T : ℂ)) -
        Complex.exp (-(sawSmoothFreq n * (sawSmoothHalfWidth T : ℂ)))‖ ≤ 2 := by
    calc
      _ ≤ ‖Complex.exp (sawSmoothFreq n * (sawSmoothHalfWidth T : ℂ))‖ +
          ‖Complex.exp (-(sawSmoothFreq n * (sawSmoothHalfWidth T : ℂ)))‖ :=
            norm_sub_le _ _
      _ = 2 := by
        rw [Complex.norm_exp, Complex.norm_exp]
        have h1 :
            (sawSmoothFreq n * (sawSmoothHalfWidth T : ℂ)).re = 0 := by
          rw [sawSmoothFreq]
          norm_num
        have h2 :
            (-(sawSmoothFreq n * (sawSmoothHalfWidth T : ℂ))).re = 0 := by
          simp [h1]
        rw [h1, h2]
        norm_num
  rw [Complex.norm_real, Real.norm_eq_abs, abs_of_pos hT0]
  calc
    T / (2 * Real.pi * |(n : ℝ)|) ^ 2 *
        ‖Complex.exp (sawSmoothFreq n * (sawSmoothHalfWidth T : ℂ)) -
          Complex.exp (-(sawSmoothFreq n * (sawSmoothHalfWidth T : ℂ)))‖
      ≤ T / (2 * Real.pi * |(n : ℝ)|) ^ 2 * 2 := by
          gcongr
    _ = T / (2 * Real.pi ^ 2 * ((n : ℝ) ^ 2)) := by
      field_simp [Real.pi_ne_zero, hn0]
      nlinarith [sq_abs (n : ℝ)]

lemma sawSmoothCoeff_le_linear
    {T : ℝ} (hT : 1 < T) {n : ℤ} (hn : n ≠ 0) :
    ‖sawSmoothCoeff T n‖ ≤ 1 / (2 * Real.pi * |(n : ℝ)|) := by
  rw [sawSmoothCoeff_eq_exp_difference hT hn]
  let z : ℂ := sawSmoothFreq n * (sawSmoothHalfWidth T : ℂ)
  have hfac :
      Complex.exp z - Complex.exp (-z) =
        Complex.exp (-z) * (Complex.exp (2*z) - 1) := by
    rw [mul_sub, mul_one, ← Complex.exp_add]
    congr 1 <;> ring
  have hzre : z.re = 0 := by
    dsimp [z, sawSmoothFreq]
    norm_num
  rw [norm_mul]
  rw [show sawSmoothFreq n * (sawSmoothHalfWidth T : ℂ) = z by rfl,
      hfac, norm_mul, Complex.norm_exp]
  have hnegzre : (-z).re = 0 := by simp [hzre]
  rw [hnegzre, Real.exp_zero, one_mul]
  have hT0 : 0 < T := lt_trans zero_lt_one hT
  have hzform : 2 * z =
      Complex.I * ((-2 * Real.pi * (n : ℝ) / T) : ℝ) := by
    dsimp [z, sawSmoothFreq, sawSmoothHalfWidth]
    push_cast
    field_simp [ne_of_gt hT0]
  rw [hzform]
  have hexp := Real.norm_exp_I_mul_ofReal_sub_one_le
    (x := (-2 * Real.pi * (n : ℝ) / T))
  rw [norm_div, norm_pow, sawSmoothFreq_norm,
    Complex.norm_real, Real.norm_eq_abs]
  rw [abs_of_pos hT0]
  have hn0 : (n : ℝ) ≠ 0 := by exact_mod_cast hn
  have hnabs : 0 < |(n : ℝ)| := abs_pos.mpr hn0
  have harg :
      ‖-2 * Real.pi * (n : ℝ) / T‖ =
        2 * Real.pi * |(n : ℝ)| / T := by
    rw [Real.norm_eq_abs, abs_div, abs_mul, abs_mul, abs_neg,
      abs_of_nonneg (by norm_num : (0:ℝ) ≤ 2), abs_of_pos Real.pi_pos,
      abs_of_pos hT0]
  rw [harg] at hexp
  calc
    T / (2 * Real.pi * |(n : ℝ)|) ^ 2 *
        ‖Complex.exp (Complex.I * ((-2 * Real.pi * (n : ℝ) / T) : ℝ)) - 1‖
      ≤ T / (2 * Real.pi * |(n : ℝ)|) ^ 2 *
        (2 * Real.pi * |(n : ℝ)| / T) := by
          gcongr
    _ = 1 / (2 * Real.pi * |(n : ℝ)|) := by
      field_simp [Real.pi_ne_zero, ne_of_gt hT0, hn0]

theorem sawSmoothCoeff_min_bound
    {T : ℝ} (hT : 1 < T) {n : ℤ} (hn : n ≠ 0) :
    ‖sawSmoothCoeff T n‖ ≤
      min (1 / (2 * Real.pi * |(n : ℝ)|))
        (T / (2 * Real.pi ^ 2 * ((n : ℝ) ^ 2))) := by
  rw [le_min_iff]
  exact ⟨sawSmoothCoeff_le_linear hT hn,
    sawSmoothCoeff_le_quadratic hT hn⟩

#print axioms sawSmoothCoeff_eq_exp_difference
#print axioms sawSmoothCoeff_min_bound

end PaperB.Analytic
