import OrielLR.InnerA

/-!
# Oriel L/R — inner sum bound from the classical input
-/

open Finset

namespace OrielUpper

variable {P : ℕ} [NeZero P]

/-- The hypothesis body with explicit constants. -/
def KarBound (cK Ck : ℝ) : Prop :=
  ∀ X : ℝ, 2 ≤ X → ∀ N : ℕ, 1 ≤ N → ∀ ϑ : ℝ, 0 ≤ ϑ → ϑ ≤ 1 → ∀ γ : ℝ,
    ∀ U : ℕ, U ≤ 2 * N →
      |∑ m ∈ Ioc N U, saw (X / ((m : ℝ) + ϑ) + γ)| ≤
        Ck * ((N : ℝ) * Real.exp (-(cK * Real.log N ^ 3 / Real.log X ^ 2)) + (N : ℝ) ^ 2 / X)

lemma ShiftedKaratsuba.elim (h : ShiftedKaratsuba) :
    ∃ cK Ck : ℝ, 0 < cK ∧ 0 ≤ Ck ∧ KarBound cK Ck := h

/-- `E₀(N, X) = exp(-c (log N)^3 / (log X)^2)`. -/
noncomputable def karE (cK : ℝ) (N : ℕ) (X : ℝ) : ℝ :=
  Real.exp (-(cK * Real.log N ^ 3 / Real.log X ^ 2))

theorem inner_vk {m H : ℕ} [NeZero m] {Λ : ZMod P → ℝ} {B : ℝ} (hB : ∀ z, |Λ z| ≤ B)
    {α β : ZMod P} (hβ : IsUnit β) (hmP : Nat.Coprime m P) (hH : IsUnit (H : ZMod m))
    (hm1 : 1 < m) {cK Ck : ℝ} (hcK : 0 < cK) (hCk : 0 ≤ Ck) (hK : KarBound cK Ck)
    {X0 : ℝ} {A Bn e N0 Lb : ℕ} (he : 1 ≤ e) (heQ : Nat.Coprime e (P * m))
    (hN0 : 1 ≤ N0) (hA : (N0 + 1) * (P * m) ≤ A / e) (hAB : A ≤ Bn)
    (hX : 2 * (e : ℝ) * ((P * m : ℕ) : ℝ) ^ 2 ≤ X0) (hLb : Bn ≤ 2 ^ Lb) :
    |innerS m H Λ α β X0 A Bn e| ≤
      ((P * m : ℕ) * ((P : ℝ) + 1) * B / ((A / e : ℕ) : ℝ) +
        ((P : ℝ) + 1) * B * Lb * Ck * (karE cK N0 X0 + Bn * ((P * m : ℕ) : ℝ) / X0)) / e := by
  set Q := P * m with hQdef
  have hQ : 0 < Q := Nat.mul_pos (NeZero.pos P) (NeZero.pos m)
  have hQr : (0 : ℝ) < Q := by exact_mod_cast hQ
  have hB0 : 0 ≤ B := le_trans (abs_nonneg _) (hB 0)
  have her : (0 : ℝ) < e := by exact_mod_cast (show 0 < e by omega)
  have hX0pos : 0 < X0 := by
    have : 0 < 2 * (e : ℝ) * (Q : ℝ) ^ 2 := by positivity
    linarith
  set A' := A / e
  set B' := Bn / e
  have hA'1 : 1 ≤ A' := by
    have : 1 ≤ (N0 + 1) * Q := Nat.one_le_iff_ne_zero.mpr (by positivity)
    omega
  have hQA' : Q ≤ A' := by
    have : Q ≤ (N0 + 1) * Q := Nat.le_mul_of_pos_left _ (by omega)
    omega
  have hA'B' : A' ≤ B' := Nat.div_le_div_right hAB
  have hA'r : (0 : ℝ) < A' := by exact_mod_cast (show 0 < A' by omega)
  have hmH : ¬ m ∣ H := by
    intro hd
    have : (H : ZMod m) = 0 := (ZMod.natCast_eq_zero_iff H m).mpr hd
    rw [this] at hH
    haveI : Fact (1 < m) := ⟨hm1⟩
    exact not_isUnit_zero hH
  have hmPu : IsUnit (m : ZMod P) := (ZMod.isUnit_iff_coprime m P).mpr hmP
  set U := (range Q).filter (fun c => Nat.Coprime c Q)
  set K : ℕ → Finset ℕ := fun c => (Ioc A' B').filter (fun k => k ≡ c [MOD Q])
  set v : ℕ → ZMod P := fun c => ((e * c : ℕ) : ZMod P)
  set t : ℕ → ZMod m := fun c => ((e * c : ℕ) : ZMod m)
  have hunit : ∀ c ∈ U, IsUnit (v c) ∧ IsUnit (t c) := by
    intro c hc
    have hc' : Nat.Coprime (e * c) Q :=
      Nat.coprime_mul_iff_left.mpr ⟨heQ, (mem_filter.mp hc).2⟩
    exact ⟨isUnit_of_coprime_mul_left hc', isUnit_of_coprime_mul_right hc'⟩
  rw [innerS_classes heQ]
  -- sawtooth form of every class term
  have hphi : ∀ c ∈ U, ∀ k ∈ K c, phiC m H Λ α β X0 e c k =
      sawC m H Λ α β (v c) (t c) * (1 / ((e : ℝ) * k)) -
        sawOsc m H Λ α β (v c) (t c) (X0 / ((e : ℝ) * k)) / ((e : ℝ) * k) := by
    intro c hc k hk
    unfold phiC
    have hk1 : 1 ≤ k := by
      have := (mem_Ioc.mp (mem_filter.mp hk).1).1; omega
    have hx : 0 ≤ X0 / ((e : ℝ) * k) := by positivity
    rw [sawtooth_identity (NeZero.pos m) hB hmPu hβ (hunit c hc).1 (hunit c hc).2 hx]
    ring
  have hsplit : ∑ c ∈ U, ∑ k ∈ K c, phiC m H Λ α β X0 e c k =
      ∑ c ∈ U, sawC m H Λ α β (v c) (t c) * ∑ k ∈ K c, 1 / ((e : ℝ) * k) -
        ∑ c ∈ U, ∑ k ∈ K c, sawOsc m H Λ α β (v c) (t c) (X0 / ((e : ℝ) * k)) / ((e : ℝ) * k) := by
    rw [← sum_sub_distrib]
    apply sum_congr rfl; intro c hc
    rw [mul_sum, ← sum_sub_distrib]
    exact sum_congr rfl (hphi c hc)
  rw [hsplit]
  -- (I) complete-class cancellation
  have hzero : ∑ c ∈ U, sawC m H Λ α β (v c) (t c) = 0 := by
    have := oriel_crt_units_sum (P := P) (m := m) hmP.symm heQ
      (fun v t => sawC m H Λ α β v t)
    rw [this]
    exact sawC_class_sum_zero hmH Λ α β
  set Wbar : ℝ := (∑ k ∈ Ioc A' B', 1 / ((e : ℝ) * k)) / Q
  have hI : |∑ c ∈ U, sawC m H Λ α β (v c) (t c) * ∑ k ∈ K c, 1 / ((e : ℝ) * k)| ≤
      (Q : ℝ) * ((P : ℝ) + 1) * B / A' / e := by
    have e1 : ∑ c ∈ U, sawC m H Λ α β (v c) (t c) * ∑ k ∈ K c, 1 / ((e : ℝ) * k) =
        ∑ c ∈ U, sawC m H Λ α β (v c) (t c) * (∑ k ∈ K c, 1 / ((e : ℝ) * k) - Wbar) := by
      have : ∑ c ∈ U, sawC m H Λ α β (v c) (t c) * Wbar = 0 := by rw [← sum_mul, hzero, zero_mul]
      rw [← sub_zero (∑ c ∈ U, _), ← this, ← sum_sub_distrib]
      apply sum_congr rfl; intro c _; ring
    rw [e1]
    refine (abs_sum_le_sum_abs _ _).trans ?_
    have hc_bd : ∀ c ∈ U, |sawC m H Λ α β (v c) (t c) * (∑ k ∈ K c, 1 / ((e : ℝ) * k) - Wbar)| ≤
        (((P : ℝ) + 1) * B / 2) * (2 / A' / e) := by
      intro c hc
      rw [abs_mul]
      apply mul_le_mul _ _ (abs_nonneg _) (by positivity)
      · exact (abs_sawC_le hB).trans (by
          have := sum_abs_rowF_le hB (H := H) (α := α) (β := β) (v := v c) (hunit c hc).2
          linarith)
      · have hcl := class_harmonic_close hQ c hA'1 hA'B'
        have eK : ∑ k ∈ K c, 1 / ((e : ℝ) * k) - Wbar =
            (1 / (e : ℝ)) * (∑ k ∈ (Ioc A' B').filter (fun k => k ≡ c [MOD Q]), (1 : ℝ) / k -
              (∑ k ∈ Ioc A' B', (1 : ℝ) / k) / Q) := by
          simp only [K, Wbar]
          rw [mul_sub, mul_sum, mul_div_assoc', mul_sum]
          congr 1
          · apply sum_congr rfl; intro k _; field_simp
          · congr 1; apply sum_congr rfl; intro k _; field_simp
        rw [eK, abs_mul, abs_of_pos (by positivity : (0 : ℝ) < 1 / e)]
        calc 1 / (e : ℝ) * |∑ k ∈ (Ioc A' B').filter (fun k => k ≡ c [MOD Q]), (1 : ℝ) / k -
              (∑ k ∈ Ioc A' B', (1 : ℝ) / k) / Q|
            ≤ 1 / (e : ℝ) * (2 / A') := mul_le_mul_of_nonneg_left hcl (by positivity)
          _ = 2 / A' / e := by ring
    refine (sum_le_sum hc_bd).trans ?_
    rw [sum_const, nsmul_eq_mul]
    have hU : (U.card : ℝ) ≤ Q := by
      have : U.card ≤ Q := (card_filter_le _ _).trans (card_range Q).le
      exact_mod_cast this
    calc (U.card : ℝ) * ((((P : ℝ) + 1) * B / 2) * (2 / A' / e))
        ≤ (Q : ℝ) * ((((P : ℝ) + 1) * B / 2) * (2 / A' / e)) :=
          mul_le_mul_of_nonneg_right hU (by positivity)
      _ = (Q : ℝ) * ((P : ℝ) + 1) * B / A' / e := by field_simp
  -- (II) the reciprocal sawtooth
  set X : ℝ := X0 / ((e : ℝ) * (Q : ℝ) ^ 2)
  have hX2 : 2 ≤ X := by
    simp only [X]; rw [le_div_iff₀ (by positivity)]; push_cast at hX ⊢; linarith
  set V : ℝ := Lb * (Ck / ((e : ℝ) * Q) * (karE cK N0 X0 + Bn * (Q : ℝ) / X0))
  have hV0 : 0 ≤ V := by
    simp only [V, karE]; positivity
  have hS : ∀ c ∈ U, ∀ j ∈ Icc 1 Q,
      |∑ k ∈ K c, saw ((X0 / ((e : ℝ) * k) - j) / (Q : ℕ)) / ((e : ℝ) * k)| ≤ V := by
    intro c hc j _
    have hcQ : c < Q := mem_range.mp (mem_filter.mp hc).1
    have hcA : c ≤ A' := by omega
    rw [show K c = (Ioc A' B').filter (fun k => k ≡ c [MOD Q]) from rfl,
      sum_class_reindex hQ hcQ hcA]
    set i1 := (A' - c) / Q
    set i2 := (B' - c) / Q
    have hi1 : N0 ≤ i1 := by
      apply (Nat.le_div_iff_mul_le hQ).mpr
      have : (N0 + 1) * Q = N0 * Q + Q := by ring
      omega
    have hi1' : 1 ≤ i1 := le_trans hN0 hi1
    have hi2B : i2 * Q ≤ B' := by
      simp only [i2]; exact le_trans (Nat.div_mul_le_self _ _) (Nat.sub_le _ _)
    have hB'e : B' * e ≤ Bn := Nat.div_mul_le_self Bn e
    have hLb' : i2 ≤ i1 * 2 ^ Lb := by
      have h1 : i2 ≤ B' := by
        have : i2 ≤ i2 * Q := Nat.le_mul_of_pos_right _ hQ
        omega
      have h2 : B' ≤ Bn := Nat.div_le_self _ _
      have h3 : 2 ^ Lb ≤ i1 * 2 ^ Lb := Nat.le_mul_of_pos_left _ (by omega)
      omega
    have econv : ∀ i ∈ Ioc i1 i2,
        saw ((X0 / ((e : ℝ) * ((c + Q * i : ℕ) : ℝ)) - j) / (Q : ℕ)) / ((e : ℝ) * ((c + Q * i : ℕ) : ℝ)) =
        saw (X / ((i : ℝ) + (c : ℝ) / Q) + (-(j : ℝ) / Q)) / ((e : ℝ) * ((c : ℝ) + Q * i)) := by
      intro i _
      push_cast
      congr 2
      simp only [X]
      field_simp
      ring
    rw [sum_congr rfl econv]
    have hpv := prog_vk hcK hCk hK hX2 hQ hcQ her hi1' hLb' (-(j : ℝ) / Q)
    refine hpv.trans ?_
    simp only [V]
    apply mul_le_mul_of_nonneg_left _ (Nat.cast_nonneg _)
    apply mul_le_mul_of_nonneg_left _ (by positivity)
    apply add_le_add
    · unfold karE
      apply Real.exp_le_exp.mpr
      apply neg_le_neg
      have hlX : 0 < Real.log X := Real.log_pos (by linarith)
      have hlXX0 : Real.log X ≤ Real.log X0 := by
        apply Real.log_le_log (by linarith)
        simp only [X]
        rw [div_le_iff₀ (by positivity)]
        have : (1 : ℝ) ≤ (e : ℝ) * (Q : ℝ) ^ 2 := by
          have h1 : (1 : ℝ) ≤ e := by exact_mod_cast he
          have h2 : (1 : ℝ) ≤ (Q : ℝ) ^ 2 := one_le_pow₀ (by exact_mod_cast hQ)
          nlinarith
        nlinarith
      have hlN0 : 0 ≤ Real.log N0 := Real.log_nonneg (by exact_mod_cast hN0)
      have hlN : Real.log N0 ≤ Real.log i1 :=
        Real.log_le_log (by exact_mod_cast hN0) (by exact_mod_cast hi1)
      have hnum : cK * Real.log N0 ^ 3 ≤ cK * Real.log i1 ^ 3 :=
        mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hlN0 hlN 3) hcK.le
      have hden : Real.log X ^ 2 ≤ Real.log X0 ^ 2 := pow_le_pow_left₀ hlX.le hlXX0 2
      calc cK * Real.log N0 ^ 3 / Real.log X0 ^ 2 ≤ cK * Real.log i1 ^ 3 / Real.log X0 ^ 2 :=
            div_le_div_of_nonneg_right hnum (by positivity)
        _ ≤ cK * Real.log i1 ^ 3 / Real.log X ^ 2 :=
            div_le_div_of_nonneg_left (by positivity) (by positivity) hden
    · simp only [X]
      rw [div_div_eq_mul_div, div_le_div_iff₀ hX0pos hX0pos]
      have h1 : ((i2 * Q : ℕ) : ℝ) ≤ B' := by exact_mod_cast hi2B
      have h2 : ((B' * e : ℕ) : ℝ) ≤ Bn := by exact_mod_cast hB'e
      push_cast at h1 h2
      have : (i2 : ℝ) * ((e : ℝ) * (Q : ℝ) ^ 2) ≤ Bn * Q := by
        calc (i2 : ℝ) * ((e : ℝ) * (Q : ℝ) ^ 2) = ((i2 : ℝ) * Q) * ((e : ℝ) * Q) := by ring
          _ ≤ (B' : ℝ) * ((e : ℝ) * Q) := mul_le_mul_of_nonneg_right h1 (by positivity)
          _ = ((B' : ℝ) * e) * Q := by ring
          _ ≤ Bn * Q := mul_le_mul_of_nonneg_right h2 (by positivity)
      nlinarith
  have hII : |∑ c ∈ U, ∑ k ∈ K c,
      sawOsc m H Λ α β (v c) (t c) (X0 / ((e : ℝ) * k)) / ((e : ℝ) * k)| ≤
      (Q : ℝ) * (((P : ℝ) + 1) * B) * V := by
    have e2 : ∀ c ∈ U, ∑ k ∈ K c,
        sawOsc m H Λ α β (v c) (t c) (X0 / ((e : ℝ) * k)) / ((e : ℝ) * k) =
        ∑ j ∈ Icc 1 Q, rowF m H Λ α β (v c) (t c) j *
          ∑ k ∈ K c, saw ((X0 / ((e : ℝ) * k) - j) / (Q : ℕ)) / ((e : ℝ) * k) := by
      intro c _
      unfold sawOsc
      simp_rw [sum_div, mul_sum]
      rw [sum_comm]
      apply sum_congr rfl; intro j _; apply sum_congr rfl; intro k _; ring
    rw [sum_congr rfl e2]
    refine (abs_sum_le_sum_abs _ _).trans ?_
    have hc : ∀ c ∈ U, |∑ j ∈ Icc 1 Q, rowF m H Λ α β (v c) (t c) j *
        ∑ k ∈ K c, saw ((X0 / ((e : ℝ) * k) - j) / (Q : ℕ)) / ((e : ℝ) * k)| ≤
        ((P : ℝ) + 1) * B * V := by
      intro c hc
      refine (abs_sum_le_sum_abs _ _).trans ?_
      calc ∑ j ∈ Icc 1 Q, |rowF m H Λ α β (v c) (t c) j *
            ∑ k ∈ K c, saw ((X0 / ((e : ℝ) * k) - j) / (Q : ℕ)) / ((e : ℝ) * k)|
          ≤ ∑ j ∈ Icc 1 Q, |rowF m H Λ α β (v c) (t c) j| * V := by
            apply sum_le_sum; intro j hj
            rw [abs_mul]
            exact mul_le_mul_of_nonneg_left (hS c hc j hj) (abs_nonneg _)
        _ = (∑ j ∈ Icc 1 Q, |rowF m H Λ α β (v c) (t c) j|) * V := by rw [sum_mul]
        _ ≤ ((P : ℝ) + 1) * B * V :=
            mul_le_mul_of_nonneg_right (sum_abs_rowF_le hB (hunit c hc).2) hV0
    refine (sum_le_sum hc).trans ?_
    rw [sum_const, nsmul_eq_mul]
    have hU : (U.card : ℝ) ≤ Q := by
      have : U.card ≤ Q := (card_filter_le _ _).trans (card_range Q).le
      exact_mod_cast this
    calc (U.card : ℝ) * (((P : ℝ) + 1) * B * V) ≤ (Q : ℝ) * (((P : ℝ) + 1) * B * V) :=
          mul_le_mul_of_nonneg_right hU (by positivity)
      _ = (Q : ℝ) * (((P : ℝ) + 1) * B) * V := by ring
  refine (abs_sub _ _).trans ((add_le_add hI hII).trans (le_of_eq ?_))
  simp only [V]
  field_simp

end OrielUpper
