import OrielUpper.Weights

/-!
# Oriel Upper — pair weights

`bW (F*r) s = [gcd(r,s)=1] · bW F s`, hence the ordered-pair weight
`bW F r · bW (F r) s` is symmetric, and `bW (F r) s ≤ bW F s`.
-/

open Finset

namespace OrielUpper

lemma allowedP_mul_iff {F r p : ℕ} (hp : p.Prime) :
    allowedP (F * r) p ↔ allowedP F p ∧ ¬ p ∣ r := by
  unfold allowedP
  rw [hp.dvd_mul]
  tauto

lemma bW_zero_right (F : ℕ) : bW F 0 = 0 := by simp [bW]

lemma bW_mul_left (F : ℕ) (r s : ℕ) :
    bW (F * r) s = if Nat.Coprime r s then bW F s else 0 := by
  by_cases hs0 : s = 0
  · subst hs0; simp [bW_zero_right]
  unfold bW gW
  have key : (∀ p ∈ s.primeFactors, allowedP (F * r) p) ↔
      ((∀ p ∈ s.primeFactors, allowedP F p) ∧ Nat.Coprime r s) := by
    constructor
    · intro h
      refine ⟨fun p hp =>
        ((allowedP_mul_iff (Nat.prime_of_mem_primeFactors hp)).mp (h p hp)).1, ?_⟩
      apply Nat.coprime_of_dvd
      intro k hk hkr hks
      have hmem : k ∈ s.primeFactors := Nat.mem_primeFactors.mpr ⟨hk, hks, hs0⟩
      exact ((allowedP_mul_iff hk).mp (h k hmem)).2 hkr
    · rintro ⟨h, hc⟩ p hp
      have hpp := Nat.prime_of_mem_primeFactors hp
      refine (allowedP_mul_iff hpp).mpr ⟨h p hp, ?_⟩
      intro hpr
      have hps := Nat.dvd_of_mem_primeFactors hp
      have : p ∣ Nat.gcd r s := Nat.dvd_gcd hpr hps
      rw [hc] at this
      exact hpp.one_lt.ne' (Nat.eq_one_of_dvd_one this)
  by_cases hc : Nat.Coprime r s
  · rw [if_pos hc]
    have : (Squarefree s ∧ ∀ p ∈ s.primeFactors, allowedP (F * r) p) ↔
        (Squarefree s ∧ ∀ p ∈ s.primeFactors, allowedP F p) := by
      rw [key]; tauto
    simp only [this]
  · rw [if_neg hc]
    rw [if_neg (fun h => hc (key.mp h.2).2)]
    simp

lemma bW_mul_le (F r s : ℕ) : bW (F * r) s ≤ bW F s := by
  rw [bW_mul_left]
  split_ifs
  · exact le_rfl
  · exact bW_nonneg F s

lemma bW_pair_symm (F r s : ℕ) : bW F r * bW (F * r) s = bW F s * bW (F * s) r := by
  rw [bW_mul_left, bW_mul_left]
  by_cases hc : Nat.Coprime r s
  · rw [if_pos hc, if_pos hc.symm, mul_comm]
  · rw [if_neg hc, if_neg (fun h => hc h.symm)]; simp

lemma bW_ne_zero_imp {F n : ℕ} (h : bW F n ≠ 0) :
    n ≠ 0 ∧ Squarefree n ∧ ∀ p ∈ n.primeFactors, allowedP F p := by
  unfold bW gW at h
  by_cases hc : Squarefree n ∧ ∀ p ∈ n.primeFactors, allowedP F p
  · refine ⟨?_, hc⟩
    rintro rfl; simp at h
  · rw [if_neg hc] at h; simp at h

/-- A nonzero weight forces coprimality to any `P` whose primes are `< 5` or divide `F`. -/
lemma bW_ne_zero_coprime {F P n : ℕ} (hP : ∀ p, p.Prime → p ∣ P → p < 5 ∨ p ∣ F)
    (h : bW F n ≠ 0) : Nat.Coprime n P := by
  obtain ⟨hn0, _, hall⟩ := bW_ne_zero_imp h
  apply Nat.coprime_of_dvd
  intro k hk hkn hkP
  have hmem : k ∈ n.primeFactors := Nat.mem_primeFactors.mpr ⟨hk, hkn, hn0⟩
  have ha := hall k hmem
  unfold allowedP at ha
  rcases hP k hk hkP with h5 | hF
  · omega
  · exact ha.2 hF

end OrielUpper
