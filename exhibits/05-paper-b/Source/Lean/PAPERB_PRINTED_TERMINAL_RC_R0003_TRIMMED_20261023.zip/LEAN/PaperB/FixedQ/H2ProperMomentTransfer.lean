import PaperB.FixedQ.H2BooleanFinalAssembly

open scoped BigOperators ComplexConjugate

namespace PaperB.FixedQ

private lemma h2Proper_X0_one_le : 1 ≤ h2BooleanX0 := by
  unfold h2BooleanX0 h2BooleanA0
  have hnon : 0 ≤ (101 / 200 : ℝ) := by norm_num
  have hs0 : 0 ≤ Real.sqrt (101 / 200 : ℝ) := Real.sqrt_nonneg _
  have hs2 : (Real.sqrt (101 / 200 : ℝ)) ^ 2 = (101 / 200 : ℝ) :=
    Real.sq_sqrt hnon
  nlinarith

private lemma h2Proper_log_two_mul_le_two_log
    {M : ℕ} (hM : 2 ≤ M) :
    Real.log ((2 * M : ℕ) : ℝ) ≤ 2 * Real.log (M : ℝ) := by
  have hnat : 2 * M ≤ M ^ 2 := by nlinarith
  have hpos1 : (0 : ℝ) < ((2 * M : ℕ) : ℝ) := by positivity
  have hpos2 : (0 : ℝ) < ((M ^ 2 : ℕ) : ℝ) := by positivity
  have hcast : (((2 * M : ℕ) : ℝ)) ≤ (((M ^ 2 : ℕ) : ℝ)) := by
    exact_mod_cast hnat
  have hlog := Real.strictMonoOn_log.monotoneOn hpos1 hpos2 hcast
  calc
    Real.log ((2 * M : ℕ) : ℝ) ≤ Real.log (((M ^ 2 : ℕ) : ℝ)) := hlog
    _ = Real.log ((M : ℝ) ^ 2) := by norm_num
    _ = 2 * Real.log (M : ℝ) := by rw [Real.log_pow]; norm_num

/-- Pure pointwise transfer from the proper-coefficient endpoint identity.
Riven supplies the concrete identity for `fixedProductProperFourierCoeff`. -/
theorem properCoeffSquare_le_full_add_endpoint_correction
    {k : ℕ} {P F chi : ℂ}
    (hP : P = F - ((2 : ℂ) ^ k)⁻¹ * (1 + chi))
    (hchi : ‖chi‖ = 1) :
    ‖P‖ ^ 2 ≤ 2 * ‖F‖ ^ 2 + 8 * (((4 : ℝ) ^ k)⁻¹) := by
  have h2pow : ‖((2 : ℂ) ^ k)⁻¹‖ = (((2 : ℝ) ^ k)⁻¹) := by
    rw [norm_inv, norm_pow]
    norm_num
  have hcorr : ‖((2 : ℂ) ^ k)⁻¹ * (1 + chi)‖ ≤
      2 * (((2 : ℝ) ^ k)⁻¹) := by
    rw [norm_mul, h2pow]
    have hadd : ‖(1 : ℂ) + chi‖ ≤ 2 := by
      calc
        ‖(1 : ℂ) + chi‖ ≤ ‖(1 : ℂ)‖ + ‖chi‖ := norm_add_le _ _
        _ = 2 := by rw [norm_one, hchi]; norm_num
    have hinv0 : 0 ≤ (((2 : ℝ) ^ k)⁻¹) :=
      inv_nonneg.mpr (pow_nonneg (by norm_num) k)
    simpa [mul_comm] using mul_le_mul_of_nonneg_left hadd hinv0
  rw [hP]
  have htri : ‖F - ((2 : ℂ) ^ k)⁻¹ * (1 + chi)‖ ≤
      ‖F‖ + ‖((2 : ℂ) ^ k)⁻¹ * (1 + chi)‖ := norm_sub_le _ _
  have hn0 : 0 ≤ ‖F - ((2 : ℂ) ^ k)⁻¹ * (1 + chi)‖ := norm_nonneg _
  have hsum0 : 0 ≤ ‖F‖ + ‖((2 : ℂ) ^ k)⁻¹ * (1 + chi)‖ := by positivity
  have hsquare := (sq_le_sq₀ hn0 hsum0).2 htri
  calc
    ‖F - ((2 : ℂ) ^ k)⁻¹ * (1 + chi)‖ ^ 2
      ≤ (‖F‖ + ‖((2 : ℂ) ^ k)⁻¹ * (1 + chi)‖) ^ 2 := hsquare
    _ ≤ 2 * ‖F‖ ^ 2 +
        2 * ‖((2 : ℂ) ^ k)⁻¹ * (1 + chi)‖ ^ 2 := by
          nlinarith [sq_nonneg (‖F‖ - ‖((2 : ℂ) ^ k)⁻¹ * (1 + chi)‖)]
    _ ≤ 2 * ‖F‖ ^ 2 + 2 * (2 * (((2 : ℝ) ^ k)⁻¹)) ^ 2 := by
      gcongr
    _ = 2 * ‖F‖ ^ 2 + 8 * (((4 : ℝ) ^ k)⁻¹) := by
      rw [show (4 : ℝ) ^ k = ((2 : ℝ) ^ k) ^ 2 by
        calc
          (4 : ℝ) ^ k = (((2 : ℝ) ^ 2) ^ k) := by norm_num
          _ = (2 : ℝ) ^ (2 * k) := by rw [pow_mul]
          _ = (2 : ℝ) ^ (k * 2) := by rw [Nat.mul_comm]
          _ = ((2 : ℝ) ^ k) ^ 2 := by rw [pow_mul]]
      have hne : (2 : ℝ) ^ k ≠ 0 := by positivity
      field_simp [hne]
      ring

/-- The endpoint correction weight is below the already-paid first-moment
base. -/
theorem h2BooleanV0_div_four_le_X0 :
    h2BooleanV0 / 4 ≤ h2BooleanX0 := by
  unfold h2BooleanV0 h2BooleanX0 h2BooleanA0
  have hnon : 0 ≤ (101 / 200 : ℝ) := by norm_num
  have hspos : 0 < Real.sqrt (101 / 200 : ℝ) := by positivity
  have hs2 : (Real.sqrt (101 / 200 : ℝ)) ^ 2 = (101 / 200 : ℝ) :=
    Real.sq_sqrt hnon
  calc
    2 / Real.sqrt (101 / 200 : ℝ) / 4
      = 1 / (2 * Real.sqrt (101 / 200 : ℝ)) := by
        field_simp [hspos.ne']
        norm_num
    _ ≤ 2 * Real.sqrt (101 / 200 : ℝ) := by
      rw [div_le_iff₀ (mul_pos (by norm_num) hspos)]
      nlinarith

private lemma h2Boolean_correction_card_weight_le (k : ℕ) :
    h2BooleanV0 ^ k * (((4 : ℝ) ^ k)⁻¹) ≤
      h2BooleanX0 ^ k := by
  have hbase0 : 0 ≤ h2BooleanV0 / 4 :=
    div_nonneg h2BooleanV0_nonneg (by norm_num)
  have hpow := pow_le_pow_left₀ hbase0 h2BooleanV0_div_four_le_X0 k
  have hid : h2BooleanV0 ^ k * (((4 : ℝ) ^ k)⁻¹) =
      (h2BooleanV0 / 4) ^ k := by
    rw [div_eq_mul_inv, mul_pow, inv_pow]
  rw [hid]
  exact hpow

/-- The full endpoint correction in the proper Fourier square is paid by
exactly eight copies of the existing first moment. -/
theorem h2BooleanProperCorrectionSum_le_firstMoment
    {q M : ℕ} :
    (∑ S ∈ h2BooleanDyadicSets q M,
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
        (8 * (((4 : ℝ) ^ S.card)⁻¹))) ≤
      8 * (∑ S ∈ h2BooleanDyadicSets q M,
        finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) := by
  calc
    _ = 8 * (∑ S ∈ h2BooleanDyadicSets q M,
        finiteOmegaWeightReal S *
          (h2BooleanV0 ^ S.card * (((4 : ℝ) ^ S.card)⁻¹))) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro S hS
      ring
    _ ≤ 8 * (∑ S ∈ h2BooleanDyadicSets q M,
        finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) := by
      apply mul_le_mul_of_nonneg_left
      · apply Finset.sum_le_sum
        intro S hS
        have hA := h2BooleanDyadicSets_active hS
        exact mul_le_mul_of_nonneg_left
          (h2Boolean_correction_card_weight_le S.card)
          (finiteOmegaWeightReal_nonneg_of_active hA)
      · norm_num

/-- Generic dyadic proper-moment transfer.  Riven instantiates `properSq S`
with the squared norm of her proper Fourier coefficient at the coherent
unit-twisted frequency. -/
theorem h2BooleanDyadicProperFrequencySecondMomentTwisted_le_transfer
    {q M j : ℕ}
    (u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ)
    (properSq : Finset ℕ → ℝ)
    (hproper : ∀ S ∈ h2BooleanDyadicSets q M,
      properSq S ≤
        2 * h2BooleanFourierNormSqTwisted q S j (u S) +
        8 * (((4 : ℝ) ^ S.card)⁻¹)) :
    (∑ S ∈ h2BooleanDyadicSets q M,
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * properSq S) ≤
      2 * h2BooleanDyadicFrequencySecondMomentTwisted q M j u +
      8 * (∑ S ∈ h2BooleanDyadicSets q M,
        finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) := by
  have hpoint :
      (∑ S ∈ h2BooleanDyadicSets q M,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * properSq S) ≤
      ∑ S ∈ h2BooleanDyadicSets q M,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
          (2 * h2BooleanFourierNormSqTwisted q S j (u S) +
            8 * (((4 : ℝ) ^ S.card)⁻¹)) := by
    apply Finset.sum_le_sum
    intro S hS
    have hA := h2BooleanDyadicSets_active hS
    exact mul_le_mul_of_nonneg_left (hproper S hS)
      (mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hA)
        (pow_nonneg h2BooleanV0_nonneg _))
  calc
    (∑ S ∈ h2BooleanDyadicSets q M,
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * properSq S)
      ≤ ∑ S ∈ h2BooleanDyadicSets q M,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
          (2 * h2BooleanFourierNormSqTwisted q S j (u S) +
            8 * (((4 : ℝ) ^ S.card)⁻¹)) := hpoint
    _ = 2 * h2BooleanDyadicFrequencySecondMomentTwisted q M j u +
        (∑ S ∈ h2BooleanDyadicSets q M,
          finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
            (8 * (((4 : ℝ) ^ S.card)⁻¹))) := by
      unfold h2BooleanDyadicFrequencySecondMomentTwisted
      simp_rw [mul_add]
      rw [Finset.sum_add_distrib, Finset.mul_sum]
      congr 1
      apply Finset.sum_congr rfl
      intro S hS
      ring
    _ ≤ 2 * h2BooleanDyadicFrequencySecondMomentTwisted q M j u +
      8 * (∑ S ∈ h2BooleanDyadicSets q M,
        finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) := by
      gcongr
      exact h2BooleanProperCorrectionSum_le_firstMoment

/-- Exact quantitative handoff: the proper dyadic moment costs two copies of
Riven's coherent-twist second moment plus eight copies of the paid first
moment, with no new M3 input. -/
theorem h2BooleanDyadicProperFrequencySecondMomentTwisted_le_quantitative_all
    (q : ℕ) (hq : 0 < q) :
    ∃ M0 : ℕ, ∀ M j : ℕ,
      ∀ u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ,
      ∀ properSq : Finset ℕ → ℝ,
      (∀ S ∈ h2BooleanDyadicSets q M,
        properSq S ≤
          2 * h2BooleanFourierNormSqTwisted q S j (u S) +
          8 * (((4 : ℝ) ^ S.card)⁻¹)) →
      H2BooleanTwistFamilyCompatible
        q (h2BooleanRoughCutoff M) M j u →
      M0 ≤ M →
      2 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      1 ≤ j →
      3 ≤ Nat.nthRoot 4 M →
      (h2BooleanRoughCutoff M) ^ 2 ≤ M →
      ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
      ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
      1 ≤ Real.log (M : ℝ) →
      h2BooleanTailCorrectionConst ≤
        (1 / 8 : ℝ) * (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) →
      (∑ S ∈ h2BooleanDyadicSets q M,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * properSq S) ≤
        2 * h2BooleanFrequencySecondMomentMajorantAll q M j +
        8 * ((M : ℝ)⁻¹ *
          (∑ n ∈ Finset.Ioc M (2 * M),
            h2BooleanTiltLift q h2BooleanFirstTilt n)) := by
  rcases h2BooleanDyadicFrequencySecondMomentTwisted_le_quantitative_all q hq with
    ⟨M0, hsecond⟩
  refine ⟨M0, ?_⟩
  intro M j u properSq hproper hcompat hM0le hM2 hY4 hj hroot hYsq
    hquarter hk hlog hC
  have hMpos : 0 < M := by omega
  have htransfer :=
    h2BooleanDyadicProperFrequencySecondMomentTwisted_le_transfer
      u properSq hproper
  have h2 := hsecond M j u hcompat hM0le hM2 hY4 hj hroot hYsq
    hquarter hk hlog hC
  have h1 := h2BooleanDyadicFirstMoment_le_interval
    (q := q) (M := M) hMpos
  exact htransfer.trans (add_le_add
    (mul_le_mul_of_nonneg_left h2 (by norm_num))
    (mul_le_mul_of_nonneg_left h1 (by norm_num)))

/-- Rate form of the proper dyadic second moment.  The log-frequency factor
is the same harmless one already present in the Boolean majorant, while the
log-M exponent remains exactly `h2BooleanX0 - 1`. -/
theorem h2BooleanDyadicProperFrequencySecondMomentTwisted_le_rate
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ M0 : ℕ, ∀ M j : ℕ,
      ∀ u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ,
      ∀ properSq : Finset ℕ → ℝ,
      (∀ S ∈ h2BooleanDyadicSets q M,
        properSq S ≤
          2 * h2BooleanFourierNormSqTwisted q S j (u S) +
          8 * (((4 : ℝ) ^ S.card)⁻¹)) →
      H2BooleanTwistFamilyCompatible
        q (h2BooleanRoughCutoff M) M j u →
      M0 ≤ M →
      3 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      1 ≤ j →
      3 ≤ Nat.nthRoot 4 M →
      (h2BooleanRoughCutoff M) ^ 2 ≤ M →
      ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
      ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
      1 ≤ Real.log (M : ℝ) →
      h2BooleanTailCorrectionConst ≤
        (1 / 8 : ℝ) * (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) →
      Real.exp (-(1 / 8 : ℝ) *
        (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) ≤
          (Real.log (M : ℝ)) ^ (-4 : ℝ) →
      (∑ S ∈ h2BooleanDyadicSets q M,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * properSq S) ≤
        C * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
          (1 + Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by
  rcases h2BooleanDyadicFrequencySecondMomentTwisted_le_quantitative_all q hq with
    ⟨MS, hsecond⟩
  rcases h2BooleanDyadicFirstWeightMoment_le_log_rate q hq with
    ⟨CF, MF, hCF0, hfirst⟩
  let C : ℝ := 2 * h2BooleanSecondMomentRateConstant q + 8 * CF
  refine ⟨C, max MS MF, ?_⟩
  intro M j u properSq hproper hcompat hM0 hM3 hY4 hj hroot hYsq
    hquarter hk hlog hC hdec
  have hMS : MS ≤ M := (le_max_left MS MF).trans hM0
  have hMF : MF ≤ M := (le_max_right MS MF).trans hM0
  have hM2 : 2 ≤ M := by omega
  have htrans := h2BooleanDyadicProperFrequencySecondMomentTwisted_le_transfer
    u properSq hproper
  have hsecond' := hsecond M j u hcompat hMS hM2 hY4 hj hroot hYsq
    hquarter hk hlog hC
  have hfirstRate := hfirst M hMF hM2 hquarter hk hlog
  have hlogM0 : 0 ≤ Real.log (M : ℝ) :=
    le_trans (by norm_num) hlog
  have hpow0 : 0 ≤ (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) :=
    Real.rpow_nonneg hlogM0 _
  have hlogj0 : 0 ≤ Real.log (j : ℝ) :=
    Real.log_nonneg (by exact_mod_cast hj)
  have hL1 : 1 ≤ 1 + Real.log (j : ℝ) := by linarith
  have hhalf0 : 0 ≤ h2BooleanV0 / 2 :=
    div_nonneg h2BooleanV0_nonneg (by norm_num)
  have hLpow1 : 1 ≤ (1 + Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) :=
    Real.one_le_rpow hL1 hhalf0
  have hrate2 := h2BooleanFrequencySecondMomentMajorantAll_le_rate_exact
    q M j hM3 hlog hj hdec
  have hfirstFinal :
      8 * (∑ S ∈ h2BooleanDyadicSets q M,
        finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) ≤
        8 * CF * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
          (1 + Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by
    calc
      _ ≤ 8 * (CF * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1)) := by
            gcongr
      _ ≤ 8 * CF * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
          (1 + Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by
            have hbase0 :
                0 ≤ 8 * CF * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) :=
              mul_nonneg (mul_nonneg (by norm_num) hCF0) hpow0
            nlinarith [mul_le_mul_of_nonneg_left hLpow1 hbase0]
  have hsecondFinal :
      2 * h2BooleanDyadicFrequencySecondMomentTwisted q M j u ≤
        2 * h2BooleanSecondMomentRateConstant q *
          (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
          (1 + Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by
    calc
      2 * h2BooleanDyadicFrequencySecondMomentTwisted q M j u
        ≤ 2 * h2BooleanFrequencySecondMomentMajorantAll q M j := by
            gcongr
      _ ≤ 2 * (h2BooleanSecondMomentRateConstant q *
          (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
          (1 + Real.log (j : ℝ)) ^ (h2BooleanV0 / 2)) := by
            gcongr
      _ = _ := by ring
  calc
    (∑ S ∈ h2BooleanDyadicSets q M,
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * properSq S)
      ≤ 2 * h2BooleanDyadicFrequencySecondMomentTwisted q M j u +
        8 * (∑ S ∈ h2BooleanDyadicSets q M,
          finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) := htrans
    _ ≤ (2 * h2BooleanSecondMomentRateConstant q + 8 * CF) *
        (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
        (1 + Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by
          calc
            _ ≤ (2 * h2BooleanSecondMomentRateConstant q *
                (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
                (1 + Real.log (j : ℝ)) ^ (h2BooleanV0 / 2)) +
              (8 * CF * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
                (1 + Real.log (j : ℝ)) ^ (h2BooleanV0 / 2)) :=
                  add_le_add hsecondFinal hfirstFinal
            _ = _ := by ring
    _ = C * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
        (1 + Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by rfl

#print axioms properCoeffSquare_le_full_add_endpoint_correction
#print axioms h2BooleanV0_div_four_le_X0
#print axioms h2BooleanProperCorrectionSum_le_firstMoment
#print axioms h2BooleanDyadicProperFrequencySecondMomentTwisted_le_transfer
#print axioms h2BooleanDyadicProperFrequencySecondMomentTwisted_le_quantitative_all
#print axioms h2BooleanDyadicProperFrequencySecondMomentTwisted_le_rate

end PaperB.FixedQ
