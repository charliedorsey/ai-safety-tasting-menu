import PaperB.FixedQ.SignedForbiddenExactAggregateRateJoin
import PaperB.FixedQ.SignedForbiddenAggregateRateTerminal

namespace PaperB.FixedQ

/--
Terminal-facing wrapper for the exact aggregate-rate join.

This theorem contains no new estimate.  It packages the global family of
moderate Vaaler-main splits and the four already-normalized component-rate
receipts into the exact signed-forbidden aggregate-rate hypothesis consumed by
`paperBTerminal_of_signedForbiddenAggregateRate`.
-/
theorem paperBTerminal_of_vaalerMain_split_component_rates
    (centered signedMean : ℕ → ℕ → ℕ → ℝ)
    (hMainSplit :
      ∀ q : ℕ, 0 < q → Squarefree q →
      ∀ a b h : ℕ,
        q.Coprime a →
        q.Coprime b →
        Nat.ModEq q (a + h) b →
        (¬ 2 ∣ q → 2 ∣ h) →
        0 < h →
        cStarReal q h *
            signedForbiddenCompletedModerateVaalerMainAggregate q a h =
          centered q a h + signedMean q a h)
    (hCentered :
      ∀ q : ℕ, 0 < q → Squarefree q →
      ∃ C : ℝ, ∃ H0 : ℕ,
        0 ≤ C ∧
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          H0 ≤ h →
          |centered q a h| ≤
            C * (Real.log (h : ℝ)) ^
                (h2BooleanSigma * h2BooleanX0) *
              (Real.log (Real.log (h : ℝ))) ^ 2)
    (hMean :
      ∀ q : ℕ, 0 < q → Squarefree q →
      ∃ C : ℝ, ∃ H0 : ℕ,
        0 ≤ C ∧
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          H0 ≤ h →
          |signedMean q a h - signedMainB1Principal q (h / 2)| ≤
            C * (Real.log (h : ℝ)) ^
                (h2BooleanSigma * h2BooleanX0) *
              (Real.log (Real.log (h : ℝ))) ^ 2)
    (hVaaler :
      ∀ q : ℕ, 0 < q → Squarefree q →
      ∃ C : ℝ, ∃ H0 : ℕ,
        0 ≤ C ∧
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          H0 ≤ h →
          |cStarReal q h *
              signedForbiddenCompletedVaalerResidualAggregate q a h| ≤
            C * (Real.log (h : ℝ)) ^
                (h2BooleanSigma * h2BooleanX0) *
              (Real.log (Real.log (h : ℝ))) ^ 2)
    (hFar :
      ∀ q : ℕ, 0 < q → Squarefree q →
      ∃ C : ℝ, ∃ H0 : ℕ,
        0 ≤ C ∧
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          H0 ≤ h →
          |cStarReal q h *
              signedForbiddenCompletedNaturalFarTailAggregate q a h| ≤
            C * (Real.log (h : ℝ)) ^
                (h2BooleanSigma * h2BooleanX0) *
              (Real.log (Real.log (h : ℝ))) ^ 2) :
    PaperB.Closure.PaperBTerminalStatement := by
  apply paperBTerminal_of_signedForbiddenAggregateRate
  intro q hq hsq
  exact signedForbiddenAggregateRate_of_vaalerMain_split_component_rates
    hq hsq
    (centered q) (signedMean q)
    (hMainSplit q hq hsq)
    (hCentered q hq hsq)
    (hMean q hq hsq)
    (hVaaler q hq hsq)
    (hFar q hq hsq)

#print axioms paperBTerminal_of_vaalerMain_split_component_rates

end PaperB.FixedQ
