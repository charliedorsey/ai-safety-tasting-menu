import PaperB.Analytic.PetermannCauchyPhase

namespace PaperB.Analytic

open Finset
open scoped ComplexConjugate

lemma phase_sum_norm_sq_complex
    {α : Type*} [DecidableEq α]
    (Q : Finset α) (phi : α → ℝ) :
    (((‖∑ q ∈ Q, eR (phi q)‖ ^ 2 : ℝ) : ℂ)) =
      ∑ q ∈ Q, ∑ q1 ∈ Q, eR (phi q - phi q1) := by
  let S : ℂ := ∑ q ∈ Q, eR (phi q)
  calc
    (((‖S‖ ^ 2 : ℝ) : ℂ))
      = (Complex.normSq S : ℂ) := by
          rw [Complex.normSq_eq_norm_sq]
    _ = S * (starRingEnd ℂ) S := by
          symm
          exact Complex.mul_conj S
    _ = (∑ q ∈ Q, eR (phi q)) *
          (starRingEnd ℂ) (∑ q1 ∈ Q, eR (phi q1)) := by rfl
    _ = (∑ q ∈ Q, eR (phi q)) *
          (∑ q1 ∈ Q, (starRingEnd ℂ) (eR (phi q1))) := by
          rw [map_sum]
    _ = ∑ q ∈ Q, ∑ q1 ∈ Q,
          eR (phi q) * (starRingEnd ℂ) (eR (phi q1)) := by
          simp_rw [Finset.sum_mul, Finset.mul_sum]
    _ = ∑ q ∈ Q, ∑ q1 ∈ Q, eR (phi q - phi q1) := by
          apply Finset.sum_congr rfl
          intro q hq
          apply Finset.sum_congr rfl
          intro q1 hq1
          exact eR_mul_conj _ _

#print axioms phase_sum_norm_sq_complex

end PaperB.Analytic
