import Mathlib.Analysis.Calculus.Taylor
import Mathlib.Analysis.Calculus.IteratedDeriv.Lemmas
import Mathlib.Tactic

/-!
# GoldB.TaylorAux

Taylor's theorem with Lagrange remainder in `iteratedDeriv` form, for a function
that is `C^{k+1}` at every point of `[a, a+t]`, and the reflection identity.
-/

open Set

namespace GoldB

theorem taylor_iteratedDeriv_bound (f : ℝ → ℝ) (k : ℕ) (a t C : ℝ) (ht : 0 ≤ t)
    (hf : ∀ x ∈ Icc a (a + t), ContDiffAt ℝ (k + 1) f x)
    (hC : ∀ x ∈ Icc a (a + t), |iteratedDeriv (k + 1) f x| / (k + 1).factorial ≤ C) :
    |f (a + t) - ∑ s ∈ Finset.range (k + 1), iteratedDeriv s f a / s.factorial * t ^ s| ≤
      C * t ^ (k + 1) := by
  rcases eq_or_lt_of_le ht with h0 | hpos
  · subst h0
    rw [Finset.sum_range_succ']
    simp
  · have hne : a ≠ a + t := by linarith
    have huIcc : uIcc a (a + t) = Icc a (a + t) := uIcc_of_le (by linarith)
    have hcd : ContDiffOn ℝ (k + 1) f (uIcc a (a + t)) := by
      rw [huIcc]; intro x hx; exact (hf x hx).contDiffWithinAt
    obtain ⟨x', hx', heq⟩ := taylor_mean_remainder_lagrange_iteratedDeriv hne hcd
    have hu : UniqueDiffOn ℝ (uIcc a (a + t)) := uniqueDiffOn_uIcc hne
    have hpoly : taylorWithinEval f k (uIcc a (a + t)) a (a + t) =
        ∑ s ∈ Finset.range (k + 1), iteratedDeriv s f a / s.factorial * t ^ s := by
      rw [taylor_within_apply]
      apply Finset.sum_congr rfl; intro s hs
      have hsk : s ≤ k + 1 := by have := Finset.mem_range.mp hs; omega
      have ha : a ∈ uIcc a (a + t) := by rw [huIcc]; exact ⟨le_refl _, by linarith⟩
      have hcda : ContDiffAt ℝ s f a :=
        (hf a ⟨le_refl _, by linarith⟩).of_le (by exact_mod_cast hsk)
      rw [iteratedDerivWithin_eq_iteratedDeriv hu hcda ha]
      simp only [smul_eq_mul, add_sub_cancel_left]
      ring
    rw [← hpoly, heq]
    have hx'I : x' ∈ Icc a (a + t) := by
      have : x' ∈ uIcc a (a + t) := (uIoo_subset_uIcc_self hx')
      rwa [huIcc] at this
    have hb := hC x' hx'I
    rw [add_sub_cancel_left, abs_div, abs_mul, abs_pow, abs_of_pos hpos]
    have hfac : (0 : ℝ) < (k + 1).factorial := by exact_mod_cast Nat.factorial_pos _
    rw [abs_of_pos hfac]
    calc |iteratedDeriv (k + 1) f x'| * t ^ (k + 1) / ((k + 1).factorial : ℝ)
        = (|iteratedDeriv (k + 1) f x'| / ((k + 1).factorial : ℝ)) * t ^ (k + 1) := by ring
      _ ≤ C * t ^ (k + 1) := mul_le_mul_of_nonneg_right hb (by positivity)

lemma iteratedDeriv_reflect (f : ℝ → ℝ) (j : ℕ) (x : ℝ) :
    |iteratedDeriv j (fun y => f (-y)) x| = |iteratedDeriv j f (-x)| := by
  rw [iteratedDeriv_comp_neg]
  simp [abs_mul]

lemma contDiffAt_reflect (f : ℝ → ℝ) (n : ℕ) (x : ℝ) (h : ContDiffAt ℝ n f (-x)) :
    ContDiffAt ℝ n (fun y => f (-y)) x :=
  h.comp x (contDiffAt_id.neg)

end GoldB
