import PaperB.Analytic.ReciprocalFiniteOrderInterval
import Mathlib.NumberTheory.ArithmeticFunction.Moebius

open scoped BigOperators ArithmeticFunction.Moebius

namespace PaperB.Analytic

open Finset Nat
open ArithmeticFunction

lemma sum_moebius_divisors_eq_coprime_indicator
    {n P : ℕ} (hP : P ≠ 0) :
    (∑ d ∈ (n.gcd P).divisors, μ d) =
      if n.Coprime P then 1 else 0 := by
  have hconv := congrArg (fun f : ArithmeticFunction ℤ => f (n.gcd P))
    moebius_mul_coe_zeta
  rw [coe_mul_zeta_apply, one_apply] at hconv
  simpa [Nat.coprime_iff_gcd_eq_one] using hconv

lemma sum_moebius_divisors_gcd_eq_divisor_indicator
    {n P : ℕ} (hP : P ≠ 0) :
    (∑ d ∈ (n.gcd P).divisors, μ d) =
      ∑ d ∈ P.divisors, if d ∣ n then μ d else 0 := by
  let f : ℕ → ℤ := fun d => if d ∣ n then μ d else 0
  have hg : n.gcd P ≠ 0 := Nat.gcd_ne_zero_right hP
  calc
    (∑ d ∈ (n.gcd P).divisors, μ d)
      = ∑ d ∈ (n.gcd P).divisors, f d := by
          apply Finset.sum_congr rfl
          intro d hd
          have hdg := (Nat.mem_divisors.mp hd).1
          have hdn : d ∣ n := dvd_trans hdg (Nat.gcd_dvd_left n P)
          simp [f, hdn]
    _ = ∑ d ∈ P.divisors, f d := by
          apply Finset.sum_subset
          · intro d hd
            have hdg := (Nat.mem_divisors.mp hd).1
            exact Nat.mem_divisors.mpr
              ⟨dvd_trans hdg (Nat.gcd_dvd_right n P), hP⟩
          · intro d hdP hdg
            have hdP' := (Nat.mem_divisors.mp hdP).1
            have hndiv : ¬ d ∣ n := by
              intro hdn
              apply hdg
              exact Nat.mem_divisors.mpr
                ⟨Nat.dvd_gcd hdn hdP', hg⟩
            simp [f, hndiv]
    _ = ∑ d ∈ P.divisors, if d ∣ n then μ d else 0 := rfl

lemma sum_Icc_dvd_reindex
    {M : Type*} [AddCommMonoid M]
    (F : ℕ → M) {d X : ℕ} (hd : 0 < d) :
    (∑ n ∈ (Finset.Icc 1 X).filter (fun n => d ∣ n), F n) =
      ∑ m ∈ Finset.Icc 1 (X / d), F (d * m) := by
  classical
  apply Finset.sum_bij
    (fun n hn => n / d)
  · intro n hn
    have hnF := Finset.mem_filter.mp hn
    have hnI := Finset.mem_Icc.mp hnF.1
    have hdn := hnF.2
    apply Finset.mem_Icc.mpr
    constructor
    · apply (Nat.one_le_div_iff hd).2
      exact Nat.le_of_dvd hnI.1 hdn
    · exact Nat.div_le_div_right hnI.2
  · intro n1 hn1 n2 hn2 heq
    have hd1 := (Finset.mem_filter.mp hn1).2
    have hd2 := (Finset.mem_filter.mp hn2).2
    calc
      n1 = d * (n1 / d) := (Nat.mul_div_cancel' hd1).symm
      _ = d * (n2 / d) := by rw [heq]
      _ = n2 := Nat.mul_div_cancel' hd2
  · intro m hm
    have hmI := Finset.mem_Icc.mp hm
    refine ⟨d * m, ?_, ?_⟩
    · apply Finset.mem_filter.mpr
      constructor
      · apply Finset.mem_Icc.mpr
        constructor
        · exact mul_pos hd (lt_of_lt_of_le Nat.zero_lt_one hmI.1)
        · have hmX : m * d ≤ X :=
            (Nat.le_div_iff_mul_le hd).mp hmI.2
          simpa [mul_comm] using hmX
      · exact dvd_mul_right d m
    · exact Nat.mul_div_cancel_left m hd
  · intro n hn
    have hdn := (Finset.mem_filter.mp hn).2
    exact congrArg F (Nat.mul_div_cancel' hdn).symm

theorem petermann_fixedK1_moebius_reduction
    (F : ℕ → ℂ) {P X : ℕ} (hP : P ≠ 0) :
    (∑ n ∈ Finset.Icc 1 X,
        (if n.Coprime P then F n else 0)) =
      ∑ d ∈ P.divisors,
        ((μ d : ℤ) : ℂ) *
          (∑ m ∈ Finset.Icc 1 (X / d), F (d * m)) := by
  classical
  calc
    (∑ n ∈ Finset.Icc 1 X,
        (if n.Coprime P then F n else 0))
      = ∑ n ∈ Finset.Icc 1 X,
          (((∑ d ∈ (n.gcd P).divisors, μ d : ℤ) : ℂ) * F n) := by
          apply Finset.sum_congr rfl
          intro n hn
          rw [sum_moebius_divisors_eq_coprime_indicator hP]
          split_ifs <;> simp
    _ = ∑ n ∈ Finset.Icc 1 X,
          ((∑ d ∈ P.divisors,
              if d ∣ n then (((μ d : ℤ) : ℂ)) else 0) * F n) := by
          apply Finset.sum_congr rfl
          intro n hn
          rw [sum_moebius_divisors_gcd_eq_divisor_indicator hP]
          push_cast
          rfl
    _ = ∑ d ∈ P.divisors,
          (((μ d : ℤ) : ℂ) *
            (∑ n ∈ (Finset.Icc 1 X).filter (fun n => d ∣ n), F n)) := by
          simp_rw [Finset.sum_mul]
          rw [Finset.sum_comm]
          apply Finset.sum_congr rfl
          intro d hd
          rw [Finset.mul_sum, Finset.sum_filter]
          apply Finset.sum_congr rfl
          intro n hn
          by_cases hdn : d ∣ n
          · simp [hdn]
          · simp [hdn]
    _ = ∑ d ∈ P.divisors,
          (((μ d : ℤ) : ℂ) *
            (∑ m ∈ Finset.Icc 1 (X / d), F (d * m))) := by
          apply Finset.sum_congr rfl
          intro d hd
          have hdpos : 0 < d := Nat.pos_of_mem_divisors hd
          rw [sum_Icc_dvd_reindex F hdpos]

#print axioms sum_moebius_divisors_eq_coprime_indicator
#print axioms sum_Icc_dvd_reindex
#print axioms petermann_fixedK1_moebius_reduction

end PaperB.Analytic
