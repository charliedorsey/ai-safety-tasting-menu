import PaperB.FixedQ.H2BooleanGlobalSourceSplit

open Filter Real Asymptotics

namespace PaperB.FixedQ

theorem exists_h2BooleanSourceCutoff_ge (N0 : ℕ) :
    ∃ H0 : ℕ, ∀ H : ℕ, H0 ≤ H →
      N0 ≤ h2BooleanSourceCutoff H := by
  have hlog :
      Tendsto (fun H : ℕ => Real.log (H : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hpow :
      Tendsto
        (fun H : ℕ => (Real.log (H : ℝ)) ^ h2BooleanSigma)
        atTop atTop :=
    (tendsto_rpow_atTop h2BooleanSigma_pos).comp hlog
  have hev :
      ∀ᶠ H : ℕ in atTop,
        (N0 : ℝ) ≤ (Real.log (H : ℝ)) ^ h2BooleanSigma :=
    hpow.eventually (eventually_ge_atTop (N0 : ℝ))
  rw [eventually_atTop] at hev
  rcases hev with ⟨H0, hH0⟩
  refine ⟨H0, ?_⟩
  intro H hH
  unfold h2BooleanSourceCutoff
  exact Nat.le_floor (hH0 H hH)

#print axioms exists_h2BooleanSourceCutoff_ge

end PaperB.FixedQ
