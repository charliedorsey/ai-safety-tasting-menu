import OrielUpper.ShellD
import OrielUpper.Mertens
import OrielUpper.Euler

/-!
# Oriel Upper — the far tail `r s > Y`

`|∑_{Y < rs ≤ U} b(r) b_r(s) Δ(r,s)| ≤ (B H / Y) (Π_H + (1 + E1 (1 + log U))²)`

with `Π_H = exp(45/4 · (5 + 4 log(log₂ H + 2)))`.  The constrained mass is handled
by the second moment `∑_{0<y<H} G(y)² ≤ H Π_H` of `G(n) = ∑_{r ∣ n} g(r)`.
-/

open Finset ArithmeticFunction
open scoped ArithmeticFunction.zeta

namespace OrielUpper

/-- Generic squarefree allowed weight with local factor `φ`. -/
noncomputable def wtF (φ : ℕ → ℝ) (F n : ℕ) : ℝ :=
  if Squarefree n ∧ ∀ p ∈ n.primeFactors, allowedP F p then ∏ p ∈ n.primeFactors, φ p else 0

lemma wtF_zero (φ : ℕ → ℝ) (F : ℕ) : wtF φ F 0 = 0 := by simp [wtF]

lemma wtF_one (φ : ℕ → ℝ) (F : ℕ) : wtF φ F 1 = 1 := by simp [wtF]

lemma wtF_mul (φ : ℕ → ℝ) (F : ℕ) {m n : ℕ} (hmn : Nat.Coprime m n) :
    wtF φ F (m * n) = wtF φ F m * wtF φ F n := by
  rcases Nat.eq_zero_or_pos m with hm | hm
  · subst hm; simp [wtF_zero]
  rcases Nat.eq_zero_or_pos n with hn | hn
  · subst hn; simp [wtF_zero]
  have hpf : (m * n).primeFactors = m.primeFactors ∪ n.primeFactors :=
    Nat.primeFactors_mul hm.ne' hn.ne'
  have hdisj : Disjoint m.primeFactors n.primeFactors := hmn.disjoint_primeFactors
  have key : (Squarefree (m * n) ∧ ∀ p ∈ (m * n).primeFactors, allowedP F p) ↔
      ((Squarefree m ∧ ∀ p ∈ m.primeFactors, allowedP F p) ∧
        (Squarefree n ∧ ∀ p ∈ n.primeFactors, allowedP F p)) := by
    rw [hpf, Nat.squarefree_mul_iff]
    constructor
    · rintro ⟨⟨_, hsm, hsn⟩, hall⟩
      exact ⟨⟨hsm, fun p hp => hall p (mem_union_left _ hp)⟩,
        ⟨hsn, fun p hp => hall p (mem_union_right _ hp)⟩⟩
    · rintro ⟨⟨hsm, h1⟩, ⟨hsn, h2⟩⟩
      refine ⟨⟨hmn, hsm, hsn⟩, ?_⟩
      intro p hp
      rcases mem_union.mp hp with hp | hp
      · exact h1 p hp
      · exact h2 p hp
  unfold wtF
  by_cases h1 : Squarefree m ∧ ∀ p ∈ m.primeFactors, allowedP F p
  · by_cases h2 : Squarefree n ∧ ∀ p ∈ n.primeFactors, allowedP F p
    · rw [if_pos (key.mpr ⟨h1, h2⟩), if_pos h1, if_pos h2, hpf, prod_union hdisj]
    · rw [if_neg (fun h => h2 (key.mp h).2), if_neg h2, mul_zero]
  · rw [if_neg (fun h => h1 (key.mp h).1), if_neg h1, zero_mul]

lemma wtF_prime (φ : ℕ → ℝ) (F : ℕ) {p : ℕ} (hp : p.Prime) :
    wtF φ F p = if allowedP F p then φ p else 0 := by
  unfold wtF
  rw [hp.primeFactors]
  simp only [mem_singleton, forall_eq, prod_singleton]
  by_cases h : allowedP F p
  · rw [if_pos ⟨hp.squarefree, h⟩, if_pos h]
  · rw [if_neg (fun h' => h h'.2), if_neg h]

lemma wtF_prime_pow (φ : ℕ → ℝ) (F : ℕ) {p k : ℕ} (hp : p.Prime) (hk : 2 ≤ k) :
    wtF φ F (p ^ k) = 0 := by
  unfold wtF
  rw [if_neg]
  rintro ⟨hsq, _⟩
  have : p * p ∣ p ^ k := by rw [← pow_two]; exact Nat.pow_dvd_pow p hk
  have := hsq p this
  exact hp.one_lt.ne' (Nat.isUnit_iff.mp this)

/-- As an arithmetic function. -/
noncomputable def WtA (φ : ℕ → ℝ) (F : ℕ) : ArithmeticFunction ℝ := ⟨wtF φ F, wtF_zero φ F⟩

@[simp] lemma WtA_apply (φ : ℕ → ℝ) (F n : ℕ) : WtA φ F n = wtF φ F n := rfl

lemma WtA_isMultiplicative (φ : ℕ → ℝ) (F : ℕ) : (WtA φ F).IsMultiplicative :=
  ⟨by simp [wtF_one], fun hmn => by simp only [WtA_apply]; exact wtF_mul φ F hmn⟩

lemma gW_eq_wtF (F n : ℕ) : gW F n = wtF (fun p => (p : ℝ) / ((p : ℝ) - 3)) F n := rfl

/-- `∑_{j ≤ i} f(p^j) = f 1 + f p` when `f` vanishes on higher powers. -/
lemma sum_range_pow_two {f : ℕ → ℝ} {p : ℕ} (hf : ∀ k, 2 ≤ k → f (p ^ k) = 0) {i : ℕ}
    (hi : 1 ≤ i) : ∑ j ∈ range (i + 1), f (p ^ j) = f 1 + f p := by
  induction i, hi using Nat.le_induction with
  | base => simp [sum_range_succ]
  | succ i hi ih => rw [sum_range_succ, ih, hf (i + 1) (by omega), add_zero]

lemma mul_zeta_prime_pow (φ : ℕ → ℝ) (F : ℕ) {p : ℕ} (hp : p.Prime) {i : ℕ} (hi : 1 ≤ i) :
    (WtA φ F * ζ) (p ^ i) = 1 + wtF φ F p := by
  rw [coe_mul_zeta_apply, Nat.divisors_prime_pow hp i, sum_map]
  simp only [Function.Embedding.coeFn_mk, WtA_apply]
  rw [sum_range_pow_two (f := wtF φ F) (fun k hk => wtF_prime_pow φ F hp hk) hi, wtF_one]

/-- `G(n) = ∑_{r ∣ n} g(r)`. -/
noncomputable def Gdiv (F n : ℕ) : ℝ := ∑ r ∈ n.divisors, gW F r

/-- Local factor of the second moment. -/
noncomputable def kφ (p : ℕ) : ℝ := (1 + (p : ℝ) / ((p : ℝ) - 3)) ^ 2 - 1

theorem Gdiv_sq (F n : ℕ) :
    Gdiv F n ^ 2 = ∑ d ∈ n.divisors, wtF kφ F d := by
  set g := WtA (fun p => (p : ℝ) / ((p : ℝ) - 3)) F
  set k := WtA kφ F
  have hG : (g * ζ).pmul (g * ζ) = k * ζ := by
    rw [IsMultiplicative.eq_iff_eq_on_prime_powers _
      (((WtA_isMultiplicative _ F).mul isMultiplicative_zeta.natCast).pmul
        ((WtA_isMultiplicative _ F).mul isMultiplicative_zeta.natCast)) _
      ((WtA_isMultiplicative _ F).mul isMultiplicative_zeta.natCast)]
    intro p i hp
    rcases Nat.eq_zero_or_pos i with h0 | hi
    · subst h0
      simp only [pow_zero, pmul_apply]
      rw [(((WtA_isMultiplicative _ F).mul isMultiplicative_zeta.natCast)).map_one,
        (((WtA_isMultiplicative _ F).mul isMultiplicative_zeta.natCast)).map_one]
      ring
    rw [pmul_apply, mul_zeta_prime_pow _ F hp hi, mul_zeta_prime_pow _ F hp hi,
      wtF_prime _ F hp, wtF_prime _ F hp]
    unfold kφ
    split_ifs <;> ring
  have := congrArg (fun f : ArithmeticFunction ℝ => f n) hG
  simp only [pmul_apply, coe_mul_zeta_apply, g, k, WtA_apply] at this
  unfold Gdiv
  simp_rw [gW_eq_wtF]
  rw [pow_two]
  exact this

lemma kφ_le {p : ℕ} (hp : 5 ≤ p) : kφ p ≤ 45 / 4 := by
  unfold kφ
  have hp' : (5 : ℝ) ≤ p := by exact_mod_cast hp
  have hd : (0 : ℝ) < (p : ℝ) - 3 := by linarith
  have h1 : (p : ℝ) / ((p : ℝ) - 3) ≤ 5 / 2 := by
    rw [div_le_iff₀ hd]; linarith
  have h0 : 0 ≤ (p : ℝ) / ((p : ℝ) - 3) := by positivity
  nlinarith

lemma kφ_nonneg {p : ℕ} (hp : 5 ≤ p) : 0 ≤ kφ p := by
  unfold kφ
  have hp' : (5 : ℝ) ≤ p := by exact_mod_cast hp
  have hd : (0 : ℝ) < (p : ℝ) - 3 := by linarith
  have h0 : 0 ≤ (p : ℝ) / ((p : ℝ) - 3) := by positivity
  nlinarith

lemma wtF_kφ_nonneg (F n : ℕ) : 0 ≤ wtF kφ F n := by
  unfold wtF
  split_ifs with h
  · apply prod_nonneg
    intro p hp
    exact kφ_nonneg (h.2 p hp).1
  · exact le_rfl

lemma primesBelow_succ_eq (N : ℕ) : (N + 1).primesBelow = primesLe N := by
  ext p
  rw [Nat.mem_primesBelow, mem_primesLe]
  constructor <;> rintro ⟨h1, h2⟩ <;> exact ⟨by omega, h2⟩

/-- The Mertens-type envelope `Π_H`. -/
noncomputable def PiH (H : ℕ) : ℝ := Real.exp (45 / 4 * (5 + 4 * Real.log (Nat.log 2 H + 2)))

lemma PiH_pos (H : ℕ) : 0 < PiH H := Real.exp_pos _

theorem sum_wtF_kφ_div_le (F N : ℕ) :
    ∑ d ∈ Icc 1 N, wtF kφ F d / d ≤ PiH N := by
  have hE := oriel_euler_le (fun d => wtF kφ F d / d)
    (fun n => div_nonneg (wtF_kφ_nonneg F n) (Nat.cast_nonneg n))
    (by simp [wtF_one])
    (fun {m n} hmn => by
      rw [wtF_mul kφ F hmn, Nat.cast_mul]
      rcases Nat.eq_zero_or_pos m with hm | hm
      · subst hm; simp [wtF_zero]
      rcases Nat.eq_zero_or_pos n with hn | hn
      · subst hn; simp [wtF_zero]
      field_simp)
    (fun {p k} hp hk => by rw [wtF_prime_pow kφ F hp (by omega), zero_div]) N
  refine hE.trans ?_
  rw [primesBelow_succ_eq]
  have hloc : ∀ p ∈ primesLe N, 1 + wtF kφ F p / p + wtF kφ F (p ^ 2) / ((p ^ 2 : ℕ) : ℝ) ≤
      1 + (45 / 4) * (1 / (p : ℝ)) := by
    intro p hp
    have hpp := (mem_primesLe.mp hp).2
    rw [wtF_prime_pow kφ F hpp le_rfl, zero_div, add_zero, wtF_prime kφ F hpp]
    have hpr : (0 : ℝ) < p := by exact_mod_cast hpp.pos
    split_ifs with ha
    · have := kφ_le ha.1
      have : kφ p / p ≤ (45 / 4) * (1 / (p : ℝ)) := by
        rw [mul_one_div]; exact div_le_div_of_nonneg_right this hpr.le
      linarith
    · simp only [zero_div, add_zero]
      have : 0 ≤ (45 / 4 : ℝ) * (1 / (p : ℝ)) := by positivity
      linarith
  calc ∏ p ∈ primesLe N, (1 + wtF kφ F p / p + wtF kφ F (p ^ 2) / ((p ^ 2 : ℕ) : ℝ))
      ≤ ∏ p ∈ primesLe N, (1 + (45 / 4) * (1 / (p : ℝ))) := by
        apply prod_le_prod₀
        · intro p hp
          have hpp := (mem_primesLe.mp hp).2
          have : 0 ≤ wtF kφ F p / p := div_nonneg (wtF_kφ_nonneg F p) (Nat.cast_nonneg _)
          have : 0 ≤ wtF kφ F (p ^ 2) / ((p ^ 2 : ℕ) : ℝ) :=
            div_nonneg (wtF_kφ_nonneg F _) (Nat.cast_nonneg _)
          linarith
        · exact hloc
    _ ≤ Real.exp (∑ p ∈ primesLe N, (45 / 4) * (1 / (p : ℝ))) :=
        Real.prod_one_add_le_exp_sum _ (fun p => by positivity)
    _ ≤ PiH N := by
        unfold PiH
        apply Real.exp_le_exp.mpr
        rw [← mul_sum]
        exact mul_le_mul_of_nonneg_left (oriel_mertens N) (by norm_num)

/-- Second moment of `G`. -/
theorem second_moment (F H : ℕ) :
    ∑ y ∈ Ioo 0 H, Gdiv F y ^ 2 ≤ H * PiH H := by
  have hIoo : Ioo 0 H = Ioc 0 (H - 1) := by ext y; simp only [mem_Ioo, mem_Ioc]; omega
  simp_rw [Gdiv_sq]
  rw [hIoo, oriel_divisor_exchange 0 (H - 1) (fun d _ => wtF kφ F d)]
  simp only [Nat.zero_div, sum_const, Nat.card_Ioc, Nat.sub_zero, nsmul_eq_mul]
  calc ∑ d ∈ Icc 1 (H - 1), (((H - 1) / d : ℕ) : ℝ) * wtF kφ F d
      ≤ ∑ d ∈ Icc 1 (H - 1), (H : ℝ) * (wtF kφ F d / d) := by
        apply sum_le_sum
        intro d hd
        have hd0 : (0 : ℝ) < d := by
          have := (mem_Icc.mp hd).1; exact_mod_cast (show 0 < d by omega)
        have h1 : (((H - 1) / d : ℕ) : ℝ) ≤ (H : ℝ) / d := by
          calc (((H - 1) / d : ℕ) : ℝ) ≤ ((H - 1 : ℕ) : ℝ) / d := Nat.cast_div_le
            _ ≤ (H : ℝ) / d := by
              apply div_le_div_of_nonneg_right _ hd0.le
              exact_mod_cast Nat.sub_le H 1
        calc (((H - 1) / d : ℕ) : ℝ) * wtF kφ F d ≤ ((H : ℝ) / d) * wtF kφ F d :=
              mul_le_mul_of_nonneg_right h1 (wtF_kφ_nonneg F d)
          _ = (H : ℝ) * (wtF kφ F d / d) := by ring
    _ = H * ∑ d ∈ Icc 1 (H - 1), wtF kφ F d / d := by rw [mul_sum]
    _ ≤ H * PiH (H - 1) := by
        apply mul_le_mul_of_nonneg_left (sum_wtF_kφ_div_le F (H - 1)) (Nat.cast_nonneg _)
    _ ≤ H * PiH H := by
        apply mul_le_mul_of_nonneg_left _ (Nat.cast_nonneg _)
        unfold PiH
        apply Real.exp_le_exp.mpr
        apply mul_le_mul_of_nonneg_left _ (by norm_num)
        have h1 : Nat.log 2 (H - 1) ≤ Nat.log 2 H := Nat.log_mono_right (Nat.sub_le H 1)
        have h2 : ((Nat.log 2 (H - 1) : ℕ) : ℝ) + 2 ≤ ((Nat.log 2 H : ℕ) : ℝ) + 2 := by
          exact_mod_cast Nat.add_le_add_right h1 2
        have := Real.log_le_log (by positivity) h2
        linarith

lemma Gdiv_nonneg (F n : ℕ) : 0 ≤ Gdiv F n := sum_nonneg (fun r _ => gW_nonneg F r)

/-- Reflection `y ↦ H - y` preserves `Ioo 0 H`. -/
lemma sum_Ioo_reflect (H : ℕ) (f : ℕ → ℝ) :
    ∑ y ∈ Ioo 0 H, f (H - y) = ∑ y ∈ Ioo 0 H, f y := by
  apply Finset.sum_nbij' (fun y => H - y) (fun y => H - y)
  · intro y hy; simp only [mem_Ioo, coe_Ioo, Set.mem_Ioo] at hy ⊢; omega
  · intro y hy; simp only [mem_Ioo, coe_Ioo, Set.mem_Ioo] at hy ⊢; omega
  · intro y hy; simp only [mem_Ioo, coe_Ioo, Set.mem_Ioo] at hy ⊢; omega
  · intro y hy; simp only [mem_Ioo, coe_Ioo, Set.mem_Ioo] at hy ⊢; omega
  · intro y _; rfl

theorem cross_moment (F H : ℕ) :
    ∑ y ∈ Ioo 0 H, Gdiv F y * Gdiv F (H - y) ≤ H * PiH H := by
  have h := second_moment F H
  have hr := sum_Ioo_reflect H (fun y => Gdiv F y ^ 2)
  calc ∑ y ∈ Ioo 0 H, Gdiv F y * Gdiv F (H - y)
      ≤ ∑ y ∈ Ioo 0 H, (Gdiv F y ^ 2 + Gdiv F (H - y) ^ 2) / 2 := by
        apply sum_le_sum; intro y _
        nlinarith [sq_nonneg (Gdiv F y - Gdiv F (H - y))]
    _ = (∑ y ∈ Ioo 0 H, Gdiv F y ^ 2 + ∑ y ∈ Ioo 0 H, Gdiv F (H - y) ^ 2) / 2 := by
        rw [← sum_add_distrib, sum_div]
    _ ≤ H * PiH H := by rw [hr]; linarith

end OrielUpper
