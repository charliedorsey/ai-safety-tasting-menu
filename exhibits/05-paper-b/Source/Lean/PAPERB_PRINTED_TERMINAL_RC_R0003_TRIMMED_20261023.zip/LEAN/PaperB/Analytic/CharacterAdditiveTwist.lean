import PaperB.FixedQ.PetermannInterface
import PaperB.Analytic.Basic
import Mathlib.Analysis.Fourier.ZMod

namespace PaperB.Analytic

open PaperB.FixedQ

lemma dirichletCharacter_additive_fourier_inversion
    {L : ℕ} [NeZero L]
    (chi : DirichletCharacter ℂ L) (n : ℕ) :
    chi n =
      (L : ℂ)⁻¹ *
        ∑ h : ZMod L,
          ZMod.stdAddChar (h * (n : ZMod L)) *
            ZMod.dft (fun x : ZMod L => chi x) h := by
  have hInv := congrFun
    (ZMod.dft.symm_apply_apply (fun x : ZMod L => chi x)) (n : ZMod L)
  rw [ZMod.invDFT_apply] at hInv
  simpa [smul_eq_mul, mul_comm, mul_left_comm, mul_assoc] using hInv.symm

lemma zmod_stdAddChar_eq_eR
    {L : ℕ} [NeZero L] (h : ZMod L) :
    ZMod.stdAddChar h = eR ((h.val : ℝ) / (L : ℝ)) := by
  rw [ZMod.stdAddChar_apply, ZMod.toCircle_apply]
  unfold eR
  congr 1
  push_cast
  field_simp

lemma eR_nat_mul (x : ℝ) (n : ℕ) :
    eR (x * (n : ℝ)) = (eR x) ^ n := by
  induction n with
  | zero =>
      simp [eR]
  | succ n ih =>
      rw [Nat.cast_succ]
      rw [mul_add, mul_one, eR_add, ih]
      simp [pow_succ]

lemma zmod_stdAddChar_mul_nat_eq_eR
    {L : ℕ} [NeZero L] (h : ZMod L) (n : ℕ) :
    ZMod.stdAddChar (h * (n : ZMod L)) =
      eR (((h.val : ℝ) / (L : ℝ)) * (n : ℝ)) := by
  have hadd :
      ZMod.stdAddChar (h * (n : ZMod L)) =
        (ZMod.stdAddChar h) ^ n := by
    have hmul : h * (n : ZMod L) = n • h := by
      simp [nsmul_eq_mul, mul_comm]
    rw [hmul]
    exact AddChar.map_nsmul_eq_pow ZMod.stdAddChar n h
  rw [hadd, zmod_stdAddChar_eq_eR]
  rw [← eR_nat_mul]

lemma dirichletCharacter_additive_eR_inversion
    {L : ℕ} [NeZero L]
    (chi : DirichletCharacter ℂ L) (n : ℕ) :
    chi n =
      (L : ℂ)⁻¹ *
        ∑ h : ZMod L,
          eR (((h.val : ℝ) / (L : ℝ)) * (n : ℝ)) *
            ZMod.dft (fun x : ZMod L => chi x) h := by
  rw [dirichletCharacter_additive_fourier_inversion]
  congr 1
  apply Finset.sum_congr rfl
  intro h hh
  rw [zmod_stdAddChar_mul_nat_eq_eR]

#print axioms dirichletCharacter_additive_fourier_inversion
#print axioms zmod_stdAddChar_eq_eR
#print axioms zmod_stdAddChar_mul_nat_eq_eR
#print axioms dirichletCharacter_additive_eR_inversion

end PaperB.Analytic
