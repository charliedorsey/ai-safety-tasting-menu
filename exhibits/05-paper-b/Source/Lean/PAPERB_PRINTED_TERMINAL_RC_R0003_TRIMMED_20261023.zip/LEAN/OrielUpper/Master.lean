import OrielUpper.Envelope
import Mathlib.Analysis.SpecialFunctions.Log.Base

/-!
# Oriel Upper — the master per-height bound

`|R0056(Z, q, a, h; Upper)| ≤ Vb(h) · W(q, h)` for every cutoff `Z`, every `a`, and
every `h ≥ 1`, with explicit `Vb, W` depending only on `q, h`.
-/

open Finset
open OrielUpper.Mirror

namespace OrielUpper

/-- `D = exp(40 (log h)^{1/4})`. -/
noncomputable def Dh (h : ℕ) : ℝ := Real.exp (40 * (Real.log (h : ℝ)) ^ (1/4 : ℝ))

/-- Far-tail threshold factor `Λ = (log h + 2)^50`. -/
noncomputable def Lf (h : ℕ) : ℝ := (Real.log (h : ℝ) + 2) ^ 50

/-- Number of dyadic shells. -/
noncomputable def Jh (h : ℕ) : ℕ := ⌈Real.logb 2 (2 * vkM h * Lf h)⌉₊

/-- Decoration envelope. -/
noncomputable def Vb (h : ℕ) : ℝ :=
  Real.exp (5 / 3 * (6 + 4 * Real.log (Nat.log 2 (Nat.log 2 h) + 2)))

/-- Per-slice envelope. -/
noncomputable def Wq (q h : ℕ) : ℝ :=
  (Jh h : ℝ) * shellU (6 * q) 3 (envA1 (q * h ^ 3)) (envA34 (q * h ^ 3))
      (Real.exp (10 * Z32)) (vkM h) (Dh h) (h ^ 2) +
    3 / Lf h * (PiH h + (1 + envA1 (q * h ^ 3) * (1 + Real.log ((h ^ 2 : ℕ) : ℝ))) ^ 2)

section Quarter
open scoped Classical

theorem quarter_eq (Z : ℕ → ℕ) {q a h : ℕ} (hq : 0 < q) (hh : 0 < h) :
    auvrenR0056CompleteQuarter Z q a h virelleR0037Upper =
      ∑ d ∈ (decoratedHeightPrimeSet q h).powerset, finiteVWeightReal h d *
        pairWin (q * (h / primeSetProduct d) * primeSetProduct d) (h / primeSetProduct d)
          (fixedQLowWeight q (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d))
          (sliceT Z h (h / primeSetProduct d)) ((h / primeSetProduct d) ^ 2 / 4) := by
  unfold auvrenR0056CompleteQuarter
  apply sum_congr rfl
  intro d hd
  congr 1
  exact slice_eq_pairWin Z hq hh (mem_powerset.mp hd)

end Quarter

lemma vkM_ge_one (h : ℕ) : 1 ≤ vkM h := by
  unfold vkM
  apply Real.one_le_exp
  rcases Nat.eq_zero_or_pos h with h0 | hpos
  · subst h0; simp
  · have : 0 ≤ Real.log (h : ℝ) := Real.log_nonneg (by exact_mod_cast hpos)
    positivity

lemma Dh_ge_one (h : ℕ) : 1 ≤ Dh h := by
  unfold Dh
  apply Real.one_le_exp
  rcases Nat.eq_zero_or_pos h with h0 | hpos
  · subst h0; simp
  · have : 0 ≤ Real.log (h : ℝ) := Real.log_nonneg (by exact_mod_cast hpos)
    positivity

lemma Lf_pos {h : ℕ} (hh : 1 ≤ h) : 0 < Lf h := by
  unfold Lf
  have : 0 ≤ Real.log (h : ℝ) := Real.log_nonneg (by exact_mod_cast hh)
  positivity

lemma two_pow_Jh {h : ℕ} (hh : 1 ≤ h) : 2 * vkM h * Lf h ≤ (2 : ℝ) ^ Jh h := by
  have hx : 0 < 2 * vkM h * Lf h := by
    have := vkM_ge_one h; have := Lf_pos hh; positivity
  unfold Jh
  calc 2 * vkM h * Lf h = (2 : ℝ) ^ (Real.logb 2 (2 * vkM h * Lf h)) :=
        (Real.rpow_logb (by norm_num) (by norm_num) hx).symm
    _ ≤ (2 : ℝ) ^ ((⌈Real.logb 2 (2 * vkM h * Lf h)⌉₊ : ℕ) : ℝ) :=
        Real.rpow_le_rpow_of_exponent_le (by norm_num) (Nat.le_ceil _)
    _ = (2 : ℝ) ^ ⌈Real.logb 2 (2 * vkM h * Lf h)⌉₊ := Real.rpow_natCast _ _

lemma floor_half {x : ℝ} (hx : 0 ≤ x) : x ≤ 2 * (max ⌊x⌋₊ 1 : ℕ) := by
  have h1 := Nat.lt_floor_add_one x
  have h2 : ((⌊x⌋₊ : ℕ) : ℝ) ≤ (max ⌊x⌋₊ 1 : ℕ) := by exact_mod_cast le_max_left _ _
  have h3 : (1 : ℝ) ≤ (max ⌊x⌋₊ 1 : ℕ) := by exact_mod_cast le_max_right _ _
  linarith

lemma shellU_nonneg {P : ℕ} {B E1 E34 Cτ M D : ℝ} {U : ℕ} (hB : 0 ≤ B) (hE1 : 0 ≤ E1)
    (hE34 : 0 ≤ E34) (hCτ : 0 ≤ Cτ) (hM : 1 ≤ M) (hD : 1 ≤ D) (hU : 1 ≤ U) :
    0 ≤ shellU P B E1 E34 Cτ M D U := by
  unfold shellU budget3
  have : 0 ≤ Real.log 4 := Real.log_nonneg (by norm_num)
  have : 0 ≤ Real.log U := Real.log_nonneg (by exact_mod_cast hU)
  have : 0 ≤ Real.log (8 * M * D) := Real.log_nonneg (by nlinarith)
  have : 0 < M := by linarith
  positivity

lemma shellU_mono {P : ℕ} {B E1 E34 Cτ M D : ℝ} {U U' : ℕ} (hB : 0 ≤ B) (hE1 : 0 ≤ E1)
    (hE34 : 0 ≤ E34) (hM : 1 ≤ M) (hD : 1 ≤ D) (hUU : U ≤ U') (hU' : 1 ≤ U') :
    shellU P B E1 E34 Cτ M D U ≤ shellU P B E1 E34 Cτ M D U' := by
  unfold shellU
  have hl : Real.log U ≤ Real.log U' := by
    rcases Nat.eq_zero_or_pos U with h0 | hpos
    · subst h0; simp only [Nat.cast_zero, Real.log_zero]
      exact Real.log_nonneg (by exact_mod_cast hU')
    · exact Real.log_le_log (by exact_mod_cast hpos) (by exact_mod_cast hUU)
  have : 0 ≤ Real.log 4 := Real.log_nonneg (by norm_num)
  have hM0 : 0 < M := by linarith
  have hc : 0 ≤ (2 * P * B * (8 * M + 4 * P + 5) / M + (2 * P + 2) * B * (1 + Real.log 4)) *
      D ^ (-(1 / 4 : ℝ)) := by positivity
  have : E34 * E1 * (1 + Real.log U) *
      (2 * P * B * (8 * M + 4 * P + 5) / M + (2 * P + 2) * B * (1 + Real.log 4)) *
        D ^ (-(1 / 4 : ℝ)) ≤ E34 * E1 * (1 + Real.log U') *
      (2 * P * B * (8 * M + 4 * P + 5) / M + (2 * P + 2) * B * (1 + Real.log 4)) *
        D ^ (-(1 / 4 : ℝ)) := by
    have e : ∀ X : ℝ, E34 * E1 * X *
        (2 * P * B * (8 * M + 4 * P + 5) / M + (2 * P + 2) * B * (1 + Real.log 4)) *
          D ^ (-(1 / 4 : ℝ)) = (E34 * E1) * X *
        ((2 * P * B * (8 * M + 4 * P + 5) / M + (2 * P + 2) * B * (1 + Real.log 4)) *
          D ^ (-(1 / 4 : ℝ))) := fun X => by ring
    rw [e, e]
    apply mul_le_mul_of_nonneg_right _ hc
    apply mul_le_mul_of_nonneg_left _ (by positivity)
    linarith
  linarith

lemma PiH_mono {H h : ℕ} (hHh : H ≤ h) : PiH H ≤ PiH h := by
  unfold PiH
  apply Real.exp_le_exp.mpr
  apply mul_le_mul_of_nonneg_left _ (by norm_num)
  have h1 : Nat.log 2 H ≤ Nat.log 2 h := Nat.log_mono_right hHh
  have h2 : ((Nat.log 2 H : ℕ) : ℝ) + 2 ≤ ((Nat.log 2 h : ℕ) : ℝ) + 2 := by
    exact_mod_cast Nat.add_le_add_right h1 2
  have := Real.log_le_log (by positivity) h2
  linarith

theorem slice_bound (Z : ℕ → ℕ) {q a h : ℕ} (hq : 0 < q) (hh : 1 ≤ h) {d : Finset ℕ}
    (hd : d ⊆ decoratedHeightPrimeSet q h) :
    |pairWin (q * (h / primeSetProduct d) * primeSetProduct d) (h / primeSetProduct d)
        (fixedQLowWeight q (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d))
        (sliceT Z h (h / primeSetProduct d)) ((h / primeSetProduct d) ^ 2 / 4)| ≤ Wq q h := by
  haveI : NeZero (6 * q) := ⟨by omega⟩
  set H := h / primeSetProduct d with hHdef
  set A := decoratedReducedAnchor q a (primeSetProduct d)
  set F := q * H * primeSetProduct d with hFdef
  have hdP : ∀ p ∈ d, p.Prime := fun p hp => (mem_decorated (hd hp)).1
  have hdpos : 0 < primeSetProduct d := primeSetProduct_pos' hdP
  have hHh : H ≤ h := Nat.div_le_self _ _
  have hHd : H * primeSetProduct d ≤ h := Nat.div_mul_le_self _ _
  have hF0 : F ≠ 0 := by
    have hd_dvd : primeSetProduct d ∣ h := by
      unfold primeSetProduct
      apply Finset.prod_primes_dvd
      · intro p hp; exact (hdP p hp).prime
      · intro p hp; exact (mem_decorated (hd hp)).2.1
    have hH : 0 < H := Nat.div_pos (Nat.le_of_dvd (by omega) hd_dvd) hdpos
    positivity
  have hR := rowHyp_source (A := A) (H := H) (F := F) hq
    (show q ∣ F from ⟨H * primeSetProduct d, by rw [hFdef]; ring⟩)
    (show H ∣ F from ⟨q * primeSetProduct d, by rw [hFdef]; ring⟩)
  set M := vkM h
  set x := (H : ℝ) / M
  have hM1 : 1 ≤ M := vkM_ge_one h
  have hx0 : 0 ≤ x := by positivity
  have hT1 : ((max (sliceT Z h H) 1 : ℕ) : ℝ) ≥ ((max ⌊x⌋₊ 1 : ℕ) : ℝ) := by
    have : max ⌊x⌋₊ 1 ≤ max (sliceT Z h H) 1 := by
      apply max_le_max _ le_rfl
      unfold sliceT; exact le_max_right _ _
    exact_mod_cast this
  have hHM : (H : ℝ) ≤ 2 * M * (max (sliceT Z h H) 1 : ℕ) := by
    have h1 := floor_half hx0
    have h2 : (H : ℝ) = M * x := by
      simp only [x]; field_simp
    rw [h2]
    have : 0 < M := by linarith
    nlinarith
  have hJ : Lf h * H ≤ ((max (sliceT Z h H) 1 : ℕ) : ℝ) * 2 ^ Jh h := by
    have h2J := two_pow_Jh hh
    have hLf := Lf_pos hh
    have : 0 ≤ ((max (sliceT Z h H) 1 : ℕ) : ℝ) := by positivity
    nlinarith
  have hFm : ∀ m, m ≤ H ^ 2 / 4 → F * m ≤ q * h ^ 3 := by
    intro m hm
    have h1 : m ≤ h ^ 2 := le_trans hm (le_trans (Nat.div_le_self _ _) (Nat.pow_le_pow_left hHh 2))
    have h2 : F ≤ q * h := by
      rw [hFdef, mul_assoc]; exact Nat.mul_le_mul_left q hHd
    calc F * m ≤ (q * h) * h ^ 2 := Nat.mul_le_mul h2 h1
      _ = q * h ^ 3 := by ring
  have hwb := window_bound hR (T := sliceT Z h H) (U := H ^ 2 / 4) (J := Jh h) (M := M)
    (D := Dh h) (Λf := Lf h) (E1 := envA1 (q * h ^ 3)) (E34 := envA34 (q * h ^ 3))
    (Cτ := Real.exp (10 * Z32)) hM1 (Dh_ge_one h) (Lf_pos hh) hHM hJ
    (fun m N h1 h2 => Asig_one_env (mul_ne_zero hF0 (by omega)) (hFm m h2) N)
    (fun m N h1 h2 => Asig_34_env (mul_ne_zero hF0 (by omega)) (hFm m h2) N)
    (tau_sum_le F) (envA1_nonneg _) (envA34_nonneg _)
  refine hwb.trans ?_
  unfold Wq
  have hU : H ^ 2 / 4 ≤ h ^ 2 := le_trans (Nat.div_le_self _ _) (Nat.pow_le_pow_left hHh 2)
  have hh2 : 1 ≤ h ^ 2 := Nat.one_le_pow _ _ (by omega)
  have hs := shellU_mono (P := 6 * q) (Cτ := Real.exp (10 * Z32)) (by norm_num : (0 : ℝ) ≤ 3)
    (envA1_nonneg (q * h ^ 3)) (envA34_nonneg (q * h ^ 3)) hM1 (Dh_ge_one h) hU hh2
  have hJ0 : (0 : ℝ) ≤ Jh h := Nat.cast_nonneg _
  have hfar : (3 : ℝ) / Lf h * (PiH H + (1 + envA1 (q * h ^ 3) *
      (1 + Real.log ((H ^ 2 / 4 : ℕ) : ℝ))) ^ 2) ≤
      3 / Lf h * (PiH h + (1 + envA1 (q * h ^ 3) * (1 + Real.log ((h ^ 2 : ℕ) : ℝ))) ^ 2) := by
    apply mul_le_mul_of_nonneg_left _ (by have := Lf_pos hh; positivity)
    have hE := envA1_nonneg (q * h ^ 3)
    have hl : Real.log ((H ^ 2 / 4 : ℕ) : ℝ) ≤ Real.log ((h ^ 2 : ℕ) : ℝ) := by
      rcases Nat.eq_zero_or_pos (H ^ 2 / 4) with h0 | hpos
      · rw [h0]; simp only [Nat.cast_zero, Real.log_zero]
        exact Real.log_nonneg (by exact_mod_cast hh2)
      · exact Real.log_le_log (by exact_mod_cast hpos) (by exact_mod_cast hU)
    have hl0 : 0 ≤ Real.log ((H ^ 2 / 4 : ℕ) : ℝ) := by
      rcases Nat.eq_zero_or_pos (H ^ 2 / 4) with h0 | hpos
      · rw [h0]; simp
      · exact Real.log_nonneg (by exact_mod_cast hpos)
    have h1 : 1 + envA1 (q * h ^ 3) * (1 + Real.log ((H ^ 2 / 4 : ℕ) : ℝ)) ≤
        1 + envA1 (q * h ^ 3) * (1 + Real.log ((h ^ 2 : ℕ) : ℝ)) := by nlinarith
    have h0 : 0 ≤ 1 + envA1 (q * h ^ 3) * (1 + Real.log ((H ^ 2 / 4 : ℕ) : ℝ)) := by positivity
    have := pow_le_pow_left₀ h0 h1 2
    linarith [PiH_mono hHh]
  have := mul_le_mul_of_nonneg_left hs hJ0
  push_cast at this hfar ⊢
  linarith

theorem master_bound (Z : ℕ → ℕ) {q : ℕ} (hq : 0 < q) (a : ℕ) {h : ℕ} (hh : 1 ≤ h) :
    |auvrenR0056CompleteQuarter Z q a h virelleR0037Upper| ≤ Vb h * Wq q h := by
  rw [quarter_eq Z hq (by omega)]
  refine (abs_sum_le_sum_abs _ _).trans ?_
  have hW0 : 0 ≤ Wq q h := by
    have hd : (∅ : Finset ℕ) ⊆ decoratedHeightPrimeSet q h := empty_subset _
    exact le_trans (abs_nonneg _) (slice_bound Z (a := a) hq hh hd)
  calc ∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
        |finiteVWeightReal h d *
          pairWin (q * (h / primeSetProduct d) * primeSetProduct d) (h / primeSetProduct d)
            (fixedQLowWeight q (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d))
            (sliceT Z h (h / primeSetProduct d)) ((h / primeSetProduct d) ^ 2 / 4)|
      ≤ ∑ d ∈ (decoratedHeightPrimeSet q h).powerset, finiteVWeightReal h d * Wq q h := by
        apply sum_le_sum
        intro d hd
        rw [abs_mul, abs_of_nonneg (finiteVWeightReal_nonneg hd)]
        exact mul_le_mul_of_nonneg_left (slice_bound Z hq hh (mem_powerset.mp hd))
          (finiteVWeightReal_nonneg hd)
    _ = (∑ d ∈ (decoratedHeightPrimeSet q h).powerset, finiteVWeightReal h d) * Wq q h := by
        rw [sum_mul]
    _ ≤ Vb h * Wq q h := mul_le_mul_of_nonneg_right (decor_sum_le q h) hW0

end OrielUpper
