import PaperB.FixedQ.H2BooleanWToV
import PaperB.FixedQ.H2BooleanM3Grouping
import Mathlib.Data.ZMod.QuotientRing

open scoped BigOperators
open Function

namespace PaperB.FixedQ

lemma fixedProductCRTIdempotentNat_mod_prime_eq_bit
    {S A : Finset ℕ} (hA : A ⊆ S)
    (hPrime : ∀ p ∈ S, p.Prime)
    {p : ℕ} (hpS : p ∈ S) :
    (fixedProductCRTIdempotentNat S A : ZMod p) =
      if p ∈ A then 0 else 1 := by
  letI : NeZero p := ⟨(hPrime p hpS).ne_zero⟩
  have hspec := fixedProductCRTIdempotentNat_specs hA hPrime
  by_cases hpA : p ∈ A
  · rw [if_pos hpA]
    have hpdiv : p ∣ primeSetProduct A := by
      unfold primeSetProduct
      exact Finset.dvd_prod_of_mem (fun x => x) hpA
    have hmod : fixedProductCRTIdempotentNat S A ≡ 0 [MOD p] :=
      hspec.1.of_dvd hpdiv
    simpa using (ZMod.natCast_eq_natCast_iff
      (fixedProductCRTIdempotentNat S A) 0 p).2 hmod
  · rw [if_neg hpA]
    have hpD : p ∈ S \ A := Finset.mem_sdiff.mpr ⟨hpS, hpA⟩
    have hpdiv : p ∣ primeSetProduct (S \ A) := by
      unfold primeSetProduct
      exact Finset.dvd_prod_of_mem (fun x => x) hpD
    have hmod : fixedProductCRTIdempotentNat S A ≡ 1 [MOD p] :=
      hspec.2.of_dvd hpdiv
    simpa using (ZMod.natCast_eq_natCast_iff
      (fixedProductCRTIdempotentNat S A) 1 p).2 hmod

#print axioms fixedProductCRTIdempotentNat_mod_prime_eq_bit


lemma sum_powerset_prod_sdiff
    {R : Type*} [CommSemiring R]
    (S : Finset ℕ) (f : ℕ → R) :
    (∑ A ∈ S.powerset, ∏ p ∈ S \ A, f p) =
      ∏ p ∈ S, (1 + f p) := by
  classical
  have hcomp :
      (∑ A ∈ S.powerset, ∏ p ∈ S \ A, f p) =
        ∑ B ∈ S.powerset, ∏ p ∈ B, f p := by
    exact Finset.sum_bij'
      (fun A _ => S \ A)
      (fun B _ => S \ B)
      (fun A hA => Finset.mem_powerset.mpr Finset.sdiff_subset)
      (fun B hB => Finset.mem_powerset.mpr Finset.sdiff_subset)
      (fun A hA => by
        have hAS := Finset.mem_powerset.mp hA
        ext x
        simp [hAS])
      (fun B hB => by
        have hBS := Finset.mem_powerset.mp hB
        ext x
        simp [hBS])
      (fun A hA => rfl)
  rw [hcomp]
  exact (Finset.prod_one_add (s := S) (f := f)).symm

#print axioms sum_powerset_prod_sdiff


lemma h2_modEq_primeSetProduct_of_modEq_primes
    {S : Finset ℕ} (hPrime : ∀ p ∈ S, p.Prime)
    {a b : ℕ}
    (hmod : ∀ p ∈ S, a ≡ b [MOD p]) :
    a ≡ b [MOD primeSetProduct S] := by
  induction S using Finset.induction_on with
  | empty =>
      rw [show primeSetProduct ∅ = 1 by rfl]
      rw [Nat.modEq_iff_dvd]
      exact one_dvd _
  | @insert p S hp ih =>
      have hpPrime : p.Prime := hPrime p (by simp)
      have hSPrime : ∀ q ∈ S, q.Prime := by
        intro q hq
        exact hPrime q (by simp [hq])
      have hcop : p.Coprime (primeSetProduct S) := by
        unfold primeSetProduct
        apply Nat.Coprime.prod_right
        intro q hq
        exact (Nat.coprime_primes hpPrime (hSPrime q hq)).2 (by
          intro hpq
          apply hp
          simpa [hpq] using hq)
      have hpmod : a ≡ b [MOD p] := hmod p (by simp)
      have hsmod : a ≡ b [MOD primeSetProduct S] := by
        apply ih hSPrime
        intro q hq
        exact hmod q (by simp [hq])
      have hprod :=
        (Nat.modEq_and_modEq_iff_modEq_mul hcop).mp ⟨hpmod, hsmod⟩
      simpa [primeSetProduct, Finset.prod_insert hp] using hprod

lemma fixedProductCRTIdempotent_eq_sum_prime_basis
    {S A : Finset ℕ} (hA : A ⊆ S)
    (hPrime : ∀ p ∈ S, p.Prime) :
    (fixedProductCRTIdempotentNat S A :
      ZMod (primeSetProduct S)) =
      ∑ p ∈ S \ A,
        (fixedProductCRTIdempotentNat S (S \ {p}) :
          ZMod (primeSetProduct S)) := by
  rw [← Nat.cast_sum]
  apply (ZMod.natCast_eq_natCast_iff
    (fixedProductCRTIdempotentNat S A)
    (∑ p ∈ S \ A, fixedProductCRTIdempotentNat S (S \ {p}))
    (primeSetProduct S)).2
  apply h2_modEq_primeSetProduct_of_modEq_primes hPrime
  intro q hqS
  apply (ZMod.natCast_eq_natCast_iff
    (fixedProductCRTIdempotentNat S A)
    (∑ p ∈ S \ A, fixedProductCRTIdempotentNat S (S \ {p}))
    q).1
  rw [Nat.cast_sum]
  rw [fixedProductCRTIdempotentNat_mod_prime_eq_bit hA hPrime hqS]
  by_cases hqA : q ∈ A
  · rw [if_pos hqA]
    rw [Finset.sum_eq_zero]
    intro p hp
    have hpD := Finset.mem_sdiff.mp hp
    have hqmem : q ∈ S \ {p} := by
      simp [hqS]
      intro hqp
      subst p
      exact hpD.2 hqA
    rw [fixedProductCRTIdempotentNat_mod_prime_eq_bit
      (Finset.sdiff_subset) hPrime hqS]
    rw [if_pos hqmem]
  · rw [if_neg hqA]
    have hqD : q ∈ S \ A := Finset.mem_sdiff.mpr ⟨hqS, hqA⟩
    rw [Finset.sum_eq_single q]
    · rw [fixedProductCRTIdempotentNat_mod_prime_eq_bit
        (Finset.sdiff_subset) hPrime hqS]
      simp
    · intro p hp hpq
      have hqmem : q ∈ S \ {p} := by simp [hqS, Ne.symm hpq]
      rw [fixedProductCRTIdempotentNat_mod_prime_eq_bit
        (Finset.sdiff_subset) hPrime hqS]
      rw [if_pos hqmem]
    · intro hnot
      exact (hnot hqD).elim

#print axioms fixedProductCRTIdempotent_eq_sum_prime_basis


lemma stdAddChar_sum_eq_prod
    {N : ℕ} [NeZero N]
    (s : Finset ℕ) (f : ℕ → ZMod N) :
    ZMod.stdAddChar (∑ x ∈ s, f x) =
      ∏ x ∈ s, ZMod.stdAddChar (f x) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert a s ha ih =>
      rw [Finset.sum_insert ha, Finset.prod_insert ha]
      rw [AddChar.map_add_eq_mul, ih]

noncomputable def h2BooleanPrimeBasis
    (S : Finset ℕ) (p : ℕ) : ℕ :=
  fixedProductCRTIdempotentNat S (S \ {p})

noncomputable def h2BooleanLocalFourierFactor
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (t : ZMod (primeSetProduct S)) (p : ℕ) : ℂ := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  exact (2 : ℂ)⁻¹ *
    (1 + ZMod.stdAddChar
      (t * (h2BooleanPrimeBasis S p :
        ZMod (primeSetProduct S))))

lemma fixedProductBooleanFourierCoeff_eq_prod_local
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (t : ZMod (primeSetProduct S)) :
    fixedProductBooleanFourierCoeff S hPrime t =
      ∏ p ∈ S, h2BooleanLocalFourierFactor S hPrime t p := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  unfold fixedProductBooleanFourierCoeff
  have hterm :
      ∀ A ∈ S.powerset,
        ZMod.stdAddChar
          (t * (fixedProductCRTIdempotentNat S A :
            ZMod (primeSetProduct S))) =
        ∏ p ∈ S \ A,
          ZMod.stdAddChar
            (t * (h2BooleanPrimeBasis S p :
              ZMod (primeSetProduct S))) := by
    intro A hA
    have hAS := Finset.mem_powerset.mp hA
    rw [fixedProductCRTIdempotent_eq_sum_prime_basis hAS hPrime]
    rw [Finset.mul_sum]
    exact stdAddChar_sum_eq_prod (S \ A)
      (fun p => t * (h2BooleanPrimeBasis S p :
        ZMod (primeSetProduct S)))
  rw [show
      (∑ A ∈ S.powerset,
        ZMod.stdAddChar
          (t * (fixedProductCRTIdempotentNat S A :
            ZMod (primeSetProduct S)))) =
        ∑ A ∈ S.powerset,
          ∏ p ∈ S \ A,
            ZMod.stdAddChar
              (t * (h2BooleanPrimeBasis S p :
                ZMod (primeSetProduct S))) by
      apply Finset.sum_congr rfl
      intro A hA
      exact hterm A hA]
  rw [sum_powerset_prod_sdiff]
  unfold h2BooleanLocalFourierFactor
  rw [Finset.prod_mul_distrib]
  rw [Finset.prod_const]
  simpa [one_div] using
    (mul_comm
      ((2 : ℂ)⁻¹ ^ S.card)
      (∏ p ∈ S,
        (1 + ZMod.stdAddChar
          (t * (h2BooleanPrimeBasis S p :
            ZMod (primeSetProduct S))))))

#print axioms fixedProductBooleanFourierCoeff_eq_prod_local

end PaperB.FixedQ
