import GoldC.QuillonWContext

/-!
# Quillon CSC3 F7.5i: reusable Ramaré split (main bilinear part minus the `p ∈ B'` terms)

For `J ⊆ U` (primes `≥ 5`) and any row `Φ(r, k)`:

    Σ_{B⊆U, B∩J≠∅} ω(B) Φ(∏B, |B|) = Σ_{p∈J} Σ_{B'⊆U} g(p,B') − Σ_{p∈J} Σ_{B'⊆U, p∈B'} g(p,B'),

with `g(p,B') = ω(p)·ω(B')/(1+|B'∩J|)·Φ(p∏B', |B'|+1)`.

The subtracted part is at most `‖Φ‖_∞·∏_U(1+1/(p−3))·Σ_{p∈J}ω(p)²` (`ramare_err_le`).

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonRamareSplit

open GoldC.QuillonWContext GoldC.QuillonRamare

/-- The Ramaré bilinear summand. -/
noncomputable def gR (J : Finset ℕ) (Φ : ℕ → ℕ → ℂ) (p : ℕ) (B' : Finset ℕ) : ℂ :=
  ((1 / ((p : ℝ) - 3) : ℝ) : ℂ) * (((ωR B' / (1 + ((B' ∩ J).card : ℝ)) : ℝ) : ℂ) *
    Φ (p * ∏ q ∈ B', q) (B'.card + 1))

theorem ramare_split (U J : Finset ℕ) (hJU : J ⊆ U) (Φ : ℕ → ℕ → ℂ) :
    ∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty), (ωR B : ℂ) * Φ (∏ p ∈ B, p) B.card =
      ∑ p ∈ J, ∑ B' ∈ U.powerset, gR J Φ p B' -
        ∑ p ∈ J, ∑ B' ∈ U.powerset.filter (fun B' => p ∈ B'), gR J Φ p B' := by
  classical
  rw [ramare U J hJU, ← sum_sub_distrib]
  refine sum_congr rfl fun p hp => ?_
  rw [erase_powerset_eq, eq_sub_iff_add_eq,
    ← sum_filter_add_sum_filter_not U.powerset (fun B' => p ∈ B'), add_comm]
  congr 1
  refine sum_congr rfl fun B' hB' => ?_
  have hpB' : p ∉ B' := (mem_filter.1 hB').2
  simp only [gR]
  rw [ωR_insert p B' hpB', prod_insert hpB', card_insert_of_notMem hpB']
  push_cast
  ring

theorem ramare_err_le (U J : Finset ℕ) (hJU : J ⊆ U) (hU : ∀ p ∈ U, p.Prime ∧ 5 ≤ p)
    (Φ : ℕ → ℕ → ℂ) (Φmax : ℝ) (hΦ : ∀ r k, ‖Φ r k‖ ≤ Φmax) :
    ‖∑ p ∈ J, ∑ B' ∈ U.powerset.filter (fun B' => p ∈ B'), gR J Φ p B'‖ ≤
      Φmax * (∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3))) * ∑ p ∈ J, (1 / ((p : ℝ) - 3)) ^ 2 := by
  classical
  set WU : ℝ := ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) with hWU
  have hΦ0 : 0 ≤ Φmax := (norm_nonneg _).trans (hΦ 0 0)
  have hsubB : ∀ p ∈ J, ∑ B' ∈ U.powerset.filter (fun B' => p ∈ B'), ωR B' ≤
      (1 / ((p : ℝ) - 3)) * WU := by
    intro p hp
    have hpU := hJU hp
    rw [powerset_filter_mem_eq_image U p hpU, sum_image]
    · calc ∑ B'' ∈ (U.erase p).powerset, ωR (insert p B'')
          = (1 / ((p : ℝ) - 3)) * ∑ B'' ∈ (U.erase p).powerset, ωR B'' := by
            rw [mul_sum]
            refine sum_congr rfl fun B'' hB'' => ?_
            have : p ∉ B'' := fun h => by have := mem_powerset.1 hB'' h; simp at this
            rw [ωR_insert p B'' this]
        _ ≤ (1 / ((p : ℝ) - 3)) * ∑ B ∈ U.powerset, ωR B := by
            have h5 : (5 : ℝ) ≤ p := by exact_mod_cast (hU p hpU).2
            apply mul_le_mul_of_nonneg_left _ (by apply div_nonneg zero_le_one; linarith)
            exact sum_le_sum_of_subset_of_nonneg (powerset_mono.2 (erase_subset _ _))
              fun B hB _ => ωR_nonneg B fun q hq => (hU q (mem_powerset.1 hB hq)).2
        _ = _ := by rw [sum_ωR_powerset]
    · intro B₁ h₁ B₂ h₂ heq
      have hp₁ : p ∉ B₁ := fun h => by have := (mem_powerset.1 h₁) h; simp at this
      have hp₂ : p ∉ B₂ := fun h => by have := (mem_powerset.1 h₂) h; simp at this
      have := congrArg (fun B => B.erase p) heq
      simpa [erase_insert hp₁, erase_insert hp₂] using this
  have hWU0 : 0 ≤ WU := prod_nonneg fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast (hU p hp).2
    have : 0 ≤ 1 / ((p : ℝ) - 3) := by apply div_nonneg zero_le_one; linarith
    linarith
  calc _ ≤ ∑ p ∈ J, ∑ B' ∈ U.powerset.filter (fun B' => p ∈ B'), ‖gR J Φ p B'‖ :=
        (norm_sum_le _ _).trans (sum_le_sum fun p _ => norm_sum_le _ _)
    _ ≤ ∑ p ∈ J, ∑ B' ∈ U.powerset.filter (fun B' => p ∈ B'),
          (1 / ((p : ℝ) - 3)) * (ωR B' * Φmax) := by
        refine sum_le_sum fun p hp => sum_le_sum fun B' hB' => ?_
        have hB'U := mem_powerset.1 (mem_filter.1 hB').1
        have h5 : (5 : ℝ) ≤ p := by exact_mod_cast (hU p (hJU hp)).2
        have hω0 := ωR_nonneg B' fun q hq => (hU q (hB'U hq)).2
        simp only [gR]
        rw [norm_mul, norm_mul, Complex.norm_real, Complex.norm_real, Real.norm_eq_abs,
          Real.norm_eq_abs, abs_of_nonneg (by apply div_nonneg zero_le_one; linarith),
          abs_of_nonneg (by positivity)]
        apply mul_le_mul_of_nonneg_left _ (by apply div_nonneg zero_le_one; linarith)
        apply mul_le_mul _ (hΦ _ _) (norm_nonneg _) hω0
        exact div_le_self hω0 (by linarith [(Nat.cast_nonneg _ : (0 : ℝ) ≤ (B' ∩ J).card)])
    _ = Φmax * ∑ p ∈ J, (1 / ((p : ℝ) - 3)) *
          ∑ B' ∈ U.powerset.filter (fun B' => p ∈ B'), ωR B' := by
        rw [mul_sum]; refine sum_congr rfl fun p _ => ?_
        rw [mul_sum, mul_sum]; refine sum_congr rfl fun B' _ => by ring
    _ ≤ Φmax * ∑ p ∈ J, (1 / ((p : ℝ) - 3)) * ((1 / ((p : ℝ) - 3)) * WU) := by
        apply mul_le_mul_of_nonneg_left _ hΦ0
        refine sum_le_sum fun p hp => ?_
        have h5 : (5 : ℝ) ≤ p := by exact_mod_cast (hU p (hJU hp)).2
        exact mul_le_mul_of_nonneg_left (hsubB p hp) (by apply div_nonneg zero_le_one; linarith)
    _ = Φmax * WU * ∑ p ∈ J, (1 / ((p : ℝ) - 3)) ^ 2 := by
        rw [mul_assoc, mul_sum, mul_sum, mul_sum]; refine sum_congr rfl fun p _ => by ring

end GoldC.QuillonRamareSplit

#print axioms GoldC.QuillonRamareSplit.ramare_split
#print axioms GoldC.QuillonRamareSplit.ramare_err_le
