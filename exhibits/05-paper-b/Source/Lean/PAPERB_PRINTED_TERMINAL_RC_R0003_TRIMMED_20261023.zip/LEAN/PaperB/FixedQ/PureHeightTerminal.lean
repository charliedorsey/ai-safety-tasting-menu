import PaperB.FixedQ.TwoDimensionalClosure
import PaperB.FixedQ.CStarBound
import PaperB.FixedQ.RowReduction

/-!
# Pure-height terminal sublog

MATHEMATICS = MORION
PRODUCTION TRANSPLANT = CALDER

This module is a mechanical production transplant of Morion's independently
validated pure-height argument. No semantic strengthening or redesign.
-/


open scoped BigOperators

namespace PaperB.FixedQ

open Real Finset Nat Filter

lemma morion_decorated_subset_active_height
    {q h : ℕ} {e : Finset ℕ}
    (he : e ∈ (decoratedHeightPrimeSet q h).powerset) :
    (∀ p ∈ e, activeHighPrime q p) ∧
    (∀ p ∈ e, p ∣ h) := by
  have hsub := Finset.mem_powerset.mp he
  constructor
  · intro p hp
    have hpS := Finset.mem_filter.mp (hsub hp)
    exact ⟨Nat.prime_of_mem_primeFactors hpS.1, hpS.2.1, hpS.2.2⟩
  · intro p hp
    have hpS := Finset.mem_filter.mp (hsub hp)
    exact Nat.dvd_of_mem_primeFactors hpS.1

lemma morion_etaCoeff_primeSetProduct_eq_finiteV
    {q h : ℕ} {e : Finset ℕ}
    (he : e ∈ (decoratedHeightPrimeSet q h).powerset) :
    etaCoeff q (primeSetProduct e) = finiteVWeightReal h e := by
  rcases morion_decorated_subset_active_height he with ⟨hA, hH⟩
  have hPrime : ∀ p ∈ e, p.Prime := fun p hp => (hA p hp).1
  have hpos : 0 < primeSetProduct e := primeSetProduct_pos hPrime
  have hsq : Squarefree (primeSetProduct e) := primeSetProduct_squarefree hPrime
  have hcop : (primeSetProduct e).Coprime (6 * q) :=
    activePrimeSetProduct_coprime hA
  have hpf : (primeSetProduct e).primeFactors = e := by
    unfold primeSetProduct
    exact Nat.primeFactors_prod hPrime
  unfold etaCoeff
  rw [if_neg (Nat.ne_of_gt hpos), if_pos ⟨hsq, hcop⟩, hpf]
  unfold finiteVWeightReal
  apply Finset.prod_congr rfl
  intro p hp
  rw [if_pos (hH p hp)]

lemma morion_factorized_row_delta_abs_le_uniform
    {q a h D H : ℕ}
    (hq : 0 < q)
    (hfact : D * H = h)
    (hDpos : 0 < D) (hHpos : 0 < H)
    (hDq : D.Coprime q)
    (h2D : (2 : ℕ).Coprime D)
    (h3D : (3 : ℕ).Coprime D)
    (hHpar : ¬ 2 ∣ q → 2 ∣ H) :
    |fixedQRowDelta q a h D 1| ≤
      genericFixedQPeriodicDensityBound q := by
  let aD := decoratedReducedAnchor q a D
  have hmod : D * aD ≡ a [MOD q] := by
    dsimp [aD]
    exact decoratedReducedAnchor_modEq hq hDq
  have hred := fixedQRowReduction_dilate_exact
    (q := q) (a := a) (aD := aD) (d := D) (H := H)
    (r := 1) (e2 := 1) hmod hDpos (by norm_num) (by norm_num)
    hDq h2D h3D (by simp)
  have hrow :
      fixedQRowDelta q a h D 1 =
        rowPeriodicDensityDelta (fixedQLowWeight q aD H) H
          (admissibleInteriorCount q a h : ℝ) D := by
    simpa [hfact, rowDiscrepancy_one_one_zero] using hred
  rw [hrow]
  simpa [hfact] using
    (abs_generic_fixedQRowPeriodicDensityDelta_le_uniform
      (q := q) (a := a) (aD := aD) (d := D) (H := H)
      hq hDpos hHpos hHpar)

lemma morion_height_row_delta_abs_le_uniform
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h)
    {e : Finset ℕ}
    (he : e ∈ (decoratedHeightPrimeSet q h).powerset) :
    |fixedQRowDelta q a h (primeSetProduct e) 1| ≤
      genericFixedQPeriodicDensityBound q := by
  rcases morion_decorated_subset_active_height he with ⟨hA, hHmem⟩
  have hall : heightPrimePart h e = e := by
    ext p
    simp only [heightPrimePart, Finset.mem_filter]
    constructor
    · intro hp
      exact hp.1
    · intro hp
      exact ⟨hp, hHmem p hp⟩
  let D := decoratedHeightProduct h e
  let H := decoratedReducedHeight h e
  have hDeq : D = primeSetProduct e := by
    dsimp [D, decoratedHeightProduct]
    rw [hall]
  have hDpos : 0 < D := decoratedHeightProduct_pos hA
  have hfact : D * H = h := decoratedHeightProduct_mul_reducedHeight hA
  have hHpos : 0 < H := by
    by_contra hzero
    have hHz : H = 0 := Nat.eq_zero_of_not_pos hzero
    rw [hHz, mul_zero] at hfact
    exact (Nat.ne_of_gt hh) hfact.symm
  have hDq : D.Coprime q := decoratedHeightProduct_coprime_q hA
  have h2D : (2 : ℕ).Coprime D := two_coprime_decoratedHeightProduct hA
  have h3D : (3 : ℕ).Coprime D := three_coprime_decoratedHeightProduct hA
  have hHpar : ¬ 2 ∣ q → 2 ∣ H :=
    decoratedReducedHeight_parity_admissible hA h2admissible
  rw [← hDeq]
  exact morion_factorized_row_delta_abs_le_uniform
    hq hfact hDpos hHpos hDq h2D h3D hHpar

theorem morion_pure_height_finite_majorant
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    |∑ e ∈ (decoratedHeightPrimeSet q h).powerset,
        etaCoeff q (primeSetProduct e) *
          fixedQRowDelta q a h (primeSetProduct e) 1| ≤
      genericFixedQPeriodicDensityBound q *
        ∑ e ∈ (decoratedHeightPrimeSet q h).powerset,
          finiteVWeightReal h e := by
  calc
    |∑ e ∈ (decoratedHeightPrimeSet q h).powerset,
        etaCoeff q (primeSetProduct e) *
          fixedQRowDelta q a h (primeSetProduct e) 1|
      ≤ ∑ e ∈ (decoratedHeightPrimeSet q h).powerset,
          |etaCoeff q (primeSetProduct e) *
            fixedQRowDelta q a h (primeSetProduct e) 1| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ e ∈ (decoratedHeightPrimeSet q h).powerset,
          genericFixedQPeriodicDensityBound q * finiteVWeightReal h e := by
      apply Finset.sum_le_sum
      intro e he
      rw [morion_etaCoeff_primeSetProduct_eq_finiteV he, abs_mul]
      have hv0 : 0 ≤ finiteVWeightReal h e := by
        apply finiteVWeightReal_nonneg_of_active
        exact (morion_decorated_subset_active_height he).1
      rw [abs_of_nonneg hv0]
      calc
        finiteVWeightReal h e *
            |fixedQRowDelta q a h (primeSetProduct e) 1|
          ≤ finiteVWeightReal h e *
              genericFixedQPeriodicDensityBound q :=
            mul_le_mul_of_nonneg_left
              (morion_height_row_delta_abs_le_uniform hq hh h2admissible he) hv0
        _ = genericFixedQPeriodicDensityBound q * finiteVWeightReal h e := by ring
    _ = genericFixedQPeriodicDensityBound q *
        ∑ e ∈ (decoratedHeightPrimeSet q h).powerset,
          finiteVWeightReal h e := by
      rw [Finset.mul_sum]

lemma morion_pureHeightSupportTerm_eq_eta_row
    {q a h : ℕ} {e : Finset ℕ}
    (he : e ∈ (decoratedHeightPrimeSet q h).powerset) :
    pureHeightSupportTerm q a h e =
      etaCoeff q (primeSetProduct e) *
        fixedQRowDelta q a h (primeSetProduct e) 1 := by
  rcases morion_decorated_subset_active_height he with ⟨hA, hH⟩
  have hPrime : ∀ p ∈ e, p.Prime := fun p hp => (hA p hp).1
  have hall : heightPrimePart h e = e := by
    ext p
    simp only [heightPrimePart, Finset.mem_filter]
    constructor
    · intro hp
      exact hp.1
    · intro hp
      exact ⟨hp, hH p hp⟩
  have hpure := pureLeftPairTerm_eq_moving_nat
    q a h (⟨e, hPrime⟩ : PrimeFinset)
  have hsq : Squarefree (primeSetProduct e) :=
    primeSetProduct_squarefree hPrime
  have hpos : primeSetProduct e ≠ 0 :=
    Nat.ne_of_gt (primeSetProduct_pos hPrime)
  have hcop : (primeSetProduct e).Coprime (6 * q) :=
    activePrimeSetProduct_coprime hA
  have hmove := movingVCoeff_eq_finiteVWeightReal
    (q := q) (h := h) (e := primeSetProduct e) hpos hsq hcop
  have hpf : (primeSetProduct e).primeFactors = e := by
    unfold primeSetProduct
    exact Nat.primeFactors_prod hPrime
  rw [hpf] at hmove
  have heta := morion_etaCoeff_primeSetProduct_eq_finiteV he
  rw [pureHeightSupportTerm, if_pos hall, hpure, hmove, heta]

lemma morion_pureHeightSupportTerm_eq_zero_of_not_mem
    {q a h : ℕ} (hh : 0 < h) {e : Finset ℕ}
    (he : e ∉ (decoratedHeightPrimeSet q h).powerset) :
    pureHeightSupportTerm q a h e = 0 := by
  by_cases hall : heightPrimePart h e = e
  · by_cases hA : ∀ p ∈ e, activeHighPrime q p
    · have hsub : e ⊆ decoratedHeightPrimeSet q h := by
        intro p hp
        have hpH : p ∣ h := by
          have hpHeight : p ∈ heightPrimePart h e := by
            rw [hall]
            exact hp
          exact (Finset.mem_filter.mp hpHeight).2
        apply Finset.mem_filter.mpr
        constructor
        · exact Nat.mem_primeFactors.mpr
            ⟨(hA p hp).1, hpH, Nat.ne_of_gt hh⟩
        · exact ⟨(hA p hp).2.1, (hA p hp).2.2⟩
      exact False.elim (he (Finset.mem_powerset.mpr hsub))
    · unfold pureHeightSupportTerm
      rw [if_pos hall]
      unfold pureLeftPairTerm pairCoefficient
      rw [if_neg hA]
      simp
  · simp [pureHeightSupportTerm, hall]

theorem morion_tsum_pureHeightSupportTerm_eq_finite_row_sum
    {q a h : ℕ} (hh : 0 < h) :
    (∑' e : Finset ℕ, pureHeightSupportTerm q a h e) =
      ∑ e ∈ (decoratedHeightPrimeSet q h).powerset,
        etaCoeff q (primeSetProduct e) *
          fixedQRowDelta q a h (primeSetProduct e) 1 := by
  rw [tsum_eq_sum (s := (decoratedHeightPrimeSet q h).powerset)]
  · apply Finset.sum_congr rfl
    intro e he
    exact morion_pureHeightSupportTerm_eq_eta_row he
  · intro e he
    exact morion_pureHeightSupportTerm_eq_zero_of_not_mem hh he

theorem morion_abs_tsum_pureHeightSupportTerm_le_mass
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    |∑' e : Finset ℕ, pureHeightSupportTerm q a h e| ≤
      genericFixedQPeriodicDensityBound q *
        ∑ e ∈ (decoratedHeightPrimeSet q h).powerset,
          finiteVWeightReal h e := by
  rw [morion_tsum_pureHeightSupportTerm_eq_finite_row_sum hh]
  exact morion_pure_height_finite_majorant hq hh h2admissible
noncomputable def morionPureHeightLogLogConstant (q : ℕ) : ℝ :=
  genericFixedQPeriodicDensityBound q * weakDecoratedMertensC

lemma morionPureHeightLogLogConstant_nonneg (q : ℕ) :
    0 ≤ morionPureHeightLogLogConstant q := by
  unfold morionPureHeightLogLogConstant
  have hB0 : 0 ≤ genericFixedQPeriodicDensityBound q := by
    unfold genericFixedQPeriodicDensityBound fixedQDensityDefectUniformBound
      admissibleCountMeanErrorBound
    positivity
  have hW0 : 0 ≤ weakDecoratedMertensC := by
    unfold weakDecoratedMertensC weakMertensC
    positivity
  positivity

theorem morion_abs_tsum_pureHeightSupportTerm_le_loglog
    {q a h : ℕ} (hq : 0 < q) (hh : 16 ≤ h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    |∑' e : Finset ℕ, pureHeightSupportTerm q a h e| ≤
      morionPureHeightLogLogConstant q *
        Real.log (Real.log (h : ℝ)) := by
  have hhpos : 0 < h := by omega
  have hbase :=
    morion_abs_tsum_pureHeightSupportTerm_le_mass
      (q := q) (a := a) hq hhpos h2admissible
  have hmass :
      (∑ e ∈ (decoratedHeightPrimeSet q h).powerset,
        finiteVWeightReal h e) ≤
        weakDecoratedMertensC * Real.log (Real.log (h : ℝ)) :=
    (sum_decorated_finiteVWeightReal_lt_weakMertens
      (q := q) hh).le
  have hB0 : 0 ≤ genericFixedQPeriodicDensityBound q := by
    unfold genericFixedQPeriodicDensityBound fixedQDensityDefectUniformBound
      admissibleCountMeanErrorBound
    positivity
  calc
    |∑' e : Finset ℕ, pureHeightSupportTerm q a h e|
      ≤ genericFixedQPeriodicDensityBound q *
          ∑ e ∈ (decoratedHeightPrimeSet q h).powerset,
            finiteVWeightReal h e := hbase
    _ ≤ genericFixedQPeriodicDensityBound q *
          (weakDecoratedMertensC * Real.log (Real.log (h : ℝ))) := by
      exact mul_le_mul_of_nonneg_left hmass hB0
    _ = morionPureHeightLogLogConstant q *
        Real.log (Real.log (h : ℝ)) := by
      unfold morionPureHeightLogLogConstant
      ring

theorem pureHeight_terminal_sublog
    (q : ℕ) (hq : 0 < q) :
    ∀ ε : ℝ, 0 < ε →
      ∃ h0 : ℕ,
        ∀ a h : ℕ,
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          h0 ≤ h →
          |cStarReal q h *
            (∑' e : Finset ℕ, pureHeightSupportTerm q a h e)| ≤
              ε * Real.log (h : ℝ) := by
  intro ε hε
  let C : ℝ := morionPureHeightLogLogConstant q
  have hlo0 :
      (fun x : ℝ => Real.log (Real.log x)) =o[Filter.atTop]
        Real.log := by
    simpa [Function.comp_def] using
      Real.isLittleO_log_id_atTop.comp_tendsto Real.tendsto_log_atTop
  have hlo :
      (fun x : ℝ => C * Real.log (Real.log x)) =o[Filter.atTop]
        Real.log :=
    hlo0.const_mul_left C
  have hev := hlo.bound hε
  rw [Filter.eventually_atTop] at hev
  obtain ⟨T, hT⟩ := hev
  obtain ⟨N, hN⟩ := exists_nat_ge T
  refine ⟨max 16 N, ?_⟩
  intro a h h2admissible hh hlarge
  have hh16 : 16 ≤ h :=
    (le_max_left 16 N).trans hlarge
  have hNh : N ≤ h :=
    (le_max_right 16 N).trans hlarge
  have hTR : T ≤ (h : ℝ) :=
    hN.trans (by exact_mod_cast hNh)
  have hasym := hT (h : ℝ) hTR
  have hloglog0 : 0 ≤ Real.log (Real.log (h : ℝ)) := by
    have h1 := one_le_log_log_nat_of_sixteen_le hh16
    linarith
  have hlog0 : 0 ≤ Real.log (h : ℝ) :=
    Real.log_nonneg (by exact_mod_cast (show 1 ≤ h by omega))
  have hC0 : 0 ≤ C := by
    dsimp [C]
    exact morionPureHeightLogLogConstant_nonneg q
  rw [Real.norm_eq_abs,
    abs_of_nonneg (mul_nonneg hC0 hloglog0),
    Real.norm_eq_abs, abs_of_nonneg hlog0] at hasym
  have hpure :=
    morion_abs_tsum_pureHeightSupportTerm_le_loglog
      (q := q) (a := a) hq hh16 h2admissible
  have hc := abs_cStarReal_le_one q h
  rw [abs_mul]
  calc
    |cStarReal q h| *
        |∑' e : Finset ℕ, pureHeightSupportTerm q a h e|
      ≤ 1 * (C * Real.log (Real.log (h : ℝ))) := by
        exact mul_le_mul hc hpure
          (abs_nonneg _)
          (by positivity)
    _ = C * Real.log (Real.log (h : ℝ)) := by ring
    _ ≤ ε * Real.log (h : ℝ) := hasym

#print axioms morion_decorated_subset_active_height
#print axioms morion_etaCoeff_primeSetProduct_eq_finiteV
#print axioms morion_height_row_delta_abs_le_uniform
#print axioms morion_pure_height_finite_majorant
#print axioms morion_pureHeightSupportTerm_eq_eta_row
#print axioms morion_pureHeightSupportTerm_eq_zero_of_not_mem
#print axioms morion_tsum_pureHeightSupportTerm_eq_finite_row_sum
#print axioms morion_abs_tsum_pureHeightSupportTerm_le_mass
#print axioms morion_abs_tsum_pureHeightSupportTerm_le_loglog
#print axioms pureHeight_terminal_sublog

end PaperB.FixedQ
