import GoldC.QuillonSieve
import Mathlib.NumberTheory.Harmonic.Bounds

/-!
# Quillon CSC3 F6b: harmonic-scale prime sums and the rough-number mass bound

* `sum_inv_primes_dyadic_harmonic`: `Σ_{2^{K₁} ≤ p < 2^{K₂}} 1/p ≤ 4·(H_{K₂−1} − H_{K₁−1})`, where `H`
  is harmonic. Consequently `Σ_{2^{K₁} ≤ p < 2^{K₂}} 1/p ≤ 4(1 + log(K₂/K₁))`.
* `prod_one_add_inv_primes_le`: `∏_{p∈B}(1 + 1/p) ≤ exp(Σ_{p∈B} 1/p)`.

These give, for a set `B` of primes in `[2^{K₁}, 2^{K₂})`, the bound
`Σ_{B'⊆B} 1/∏B' = ∏_{p∈B}(1+1/p) ≤ e⁴·(K₂/K₁)⁴`. That is the polynomial `w^{−4}` rough factor:
no Brun or Selberg sieve is needed.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonSieve

open GoldC.QuillonCopyG

theorem sum_inv_primes_dyadic_harmonic (K₁ K₂ : ℕ) (hK₁ : 1 ≤ K₁) (h : K₁ ≤ K₂) :
    ∑ p ∈ (Ico (2 ^ K₁) (2 ^ K₂)).filter Nat.Prime, (1 / (p : ℝ)) ≤
      4 * ∑ k ∈ Ico K₁ K₂, (1 / (k : ℝ)) := by
  rw [primes_Ico_pow_eq K₁ K₂ h]
  have hdisj : (↑(Ico K₁ K₂) : Set ℕ).PairwiseDisjoint block := by
    intro a _ b _ hab
    simp only [Function.onFun]
    rw [Finset.disjoint_left]
    intro p hpa hpb
    simp only [block, mem_filter, mem_Ico] at hpa hpb
    apply hab
    rw [← Nat.log_eq_of_pow_le_of_lt_pow hpa.1.1 hpa.1.2,
      ← Nat.log_eq_of_pow_le_of_lt_pow hpb.1.1 hpb.1.2]
  rw [Finset.sum_biUnion hdisj, Finset.mul_sum]
  refine Finset.sum_le_sum fun k hk => ?_
  have hk' := mem_Ico.1 hk
  refine (block_sum_le k (by omega)).trans (le_of_eq ?_)
  ring

lemma sum_inv_Ico_le_log (K₁ K₂ : ℕ) (hK₁ : 1 ≤ K₁) (h : K₁ ≤ K₂) :
    ∑ k ∈ Ico K₁ K₂, (1 / (k : ℝ)) ≤ 1 + Real.log ((K₂ : ℝ) / K₁) := by
  -- Σ_{Ico K₁ K₂} = H_{K₂−1} − H_{K₁−1}
  have hsplit : ∑ k ∈ Icc 1 (K₂ - 1), (1 / (k : ℝ)) =
      ∑ k ∈ Icc 1 (K₁ - 1), (1 / (k : ℝ)) + ∑ k ∈ Ico K₁ K₂, (1 / (k : ℝ)) := by
    rw [← Finset.sum_union]
    · congr 1; ext k; simp only [mem_Icc, mem_union, mem_Ico]; omega
    · rw [Finset.disjoint_left]; intro k h1 h2; simp only [mem_Icc, mem_Ico] at h1 h2; omega
  have hH2 := harmonic_le_one_add_log (K₂ - 1)
  have hH1 := log_add_one_le_harmonic (K₁ - 1)
  rw [harmonic_eq_sum_Icc] at hH2 hH1
  push_cast at hH2 hH1
  simp only [one_div] at hsplit ⊢
  have hc1 : ((K₁ - 1 : ℕ) : ℝ) + 1 = K₁ := by rw [Nat.cast_sub hK₁]; ring
  rw [hc1] at hH1
  have hK₁R : (0 : ℝ) < K₁ := by exact_mod_cast hK₁
  rcases Nat.eq_or_lt_of_le h with heq | hlt
  · subst heq; simp
  · have hK₂R : (0 : ℝ) < K₂ := by exact_mod_cast (show 0 < K₂ by omega)
    have hlog : Real.log (((K₂ - 1 : ℕ) : ℝ)) ≤ Real.log (K₂ : ℝ) := by
      apply Real.log_le_log (by exact_mod_cast (show 0 < K₂ - 1 by omega))
      exact_mod_cast Nat.sub_le K₂ 1
    rw [Real.log_div hK₂R.ne' hK₁R.ne']
    linarith

/-- Primes in a dyadic-type window `[Y, 2Y)` (`Y ≥ 2`) have `1/p`-mass `≤ 8/log₂ Y`. -/
theorem sum_inv_primes_window (Y : ℕ) (hY : 2 ≤ Y) :
    ∑ p ∈ (Ico Y (2 * Y)).filter Nat.Prime, (1 / (p : ℝ)) ≤ 8 / (Nat.log 2 Y : ℝ) := by
  set K := Nat.log 2 Y
  have hK : 1 ≤ K := Nat.le_log_of_pow_le (by norm_num) (by simpa using hY)
  have hsub : (Ico Y (2 * Y)).filter Nat.Prime ⊆ (Ico (2 ^ K) (2 ^ (K + 2))).filter Nat.Prime := by
    intro p hp
    simp only [mem_filter, mem_Ico] at hp ⊢
    refine ⟨⟨le_trans (Nat.pow_log_le_self 2 (by omega)) hp.1.1, ?_⟩, hp.2⟩
    have h2 : Y < 2 ^ K * 2 := by
      have := Nat.lt_pow_succ_log_self (b := 2) (by norm_num) Y
      rw [pow_succ] at this; exact this
    calc p < 2 * Y := hp.1.2
      _ < 2 * (2 ^ K * 2) := by omega
      _ = 2 ^ (K + 2) := by ring
  calc ∑ p ∈ (Ico Y (2 * Y)).filter Nat.Prime, (1 / (p : ℝ))
      ≤ ∑ p ∈ (Ico (2 ^ K) (2 ^ (K + 2))).filter Nat.Prime, (1 / (p : ℝ)) :=
        Finset.sum_le_sum_of_subset_of_nonneg hsub fun _ _ _ => by positivity
    _ ≤ 4 * ((K + 2 - K : ℕ) : ℝ) / K := sum_inv_primes_dyadic_range K (K + 2) hK (by omega)
    _ = 8 / (K : ℝ) := by rw [show K + 2 - K = 2 by omega]; push_cast; ring

/-- Subset sum of reciprocal products is the Euler product, `≤ exp(Σ 1/p)`. -/
theorem sum_inv_prod_subsets_le (T : Finset ℕ) :
    ∑ B ∈ T.powerset, (1 / (∏ p ∈ B, (p : ℝ))) ≤ Real.exp (∑ p ∈ T, (1 / (p : ℝ))) := by
  have h1 : ∑ B ∈ T.powerset, (1 / (∏ p ∈ B, (p : ℝ))) = ∏ p ∈ T, (1 + 1 / (p : ℝ)) := by
    rw [Finset.prod_one_add]
    refine Finset.sum_congr rfl fun B _ => ?_
    rw [one_div, ← Finset.prod_inv_distrib]; simp [one_div]
  rw [h1]
  exact GoldC.QuillonCopyG.prod_one_add_le_exp_sum T _ fun p _ => by positivity

/-- Splitting a nonempty set by its maximum. -/
lemma sum_nonempty_by_max {R : Type*} [AddCommMonoid R] (T : Finset ℕ) (f : Finset ℕ → R) :
    ∑ B ∈ T.powerset.filter (fun B => B.Nonempty), f B =
      ∑ p ∈ T, ∑ B' ∈ (T.filter (· < p)).powerset, f (insert p B') := by
  rw [Finset.sum_sigma']
  refine Finset.sum_bij' (fun B hB => ⟨B.max' (mem_filter.1 hB).2, B.erase (B.max' (mem_filter.1 hB).2)⟩)
    (fun x _ => insert x.1 x.2) ?_ ?_ ?_ ?_ ?_
  · intro B hB
    rw [mem_filter, mem_powerset] at hB
    simp only [mem_sigma, mem_powerset]
    refine ⟨hB.1 (B.max'_mem hB.2), fun q hq => ?_⟩
    rw [mem_erase] at hq
    rw [mem_filter]
    exact ⟨hB.1 hq.2, lt_of_le_of_ne (B.le_max' q hq.2) hq.1⟩
  · intro x hx
    simp only [mem_sigma, mem_powerset] at hx
    rw [mem_filter, mem_powerset]
    exact ⟨insert_subset hx.1 (fun q hq => (mem_filter.1 (hx.2 hq)).1), insert_nonempty _ _⟩
  · intro B hB
    exact insert_erase (B.max'_mem (mem_filter.1 hB).2)
  · intro x hx
    simp only [mem_sigma, mem_powerset] at hx
    have hnot : x.1 ∉ x.2 := fun h => by have := (mem_filter.1 (hx.2 h)).2; omega
    have hmax : (insert x.1 x.2).max' (insert_nonempty _ _) = x.1 := by
      apply le_antisymm
      · apply Finset.max'_le
        intro q hq
        rw [mem_insert] at hq
        rcases hq with rfl | hq
        · exact le_rfl
        · exact (mem_filter.1 (hx.2 hq)).2.le
      · exact Finset.le_max' _ _ (mem_insert_self _ _)
    refine Sigma.ext hmax (heq_of_eq ?_)
    simp only [hmax, erase_insert hnot]
  · intro B hB
    simp only [insert_erase (B.max'_mem (mem_filter.1 hB).2)]

/-- **Rough-number mass** (largest-prime decomposition). For a set `T` of primes all `≥ z`
(`z ≥ 4`) and any `X`:
`Σ_{∅≠B⊆T, X ≤ ∏B < 2X} 1/∏B ≤ (8/(log₂ z − 1))·Σ_{B'⊆T_{<2X}} 1/∏B'`. -/
theorem rough_mass (T : Finset ℕ) (hT : ∀ p ∈ T, p.Prime) (z X : ℕ) (hz : 4 ≤ z)
    (hTz : ∀ p ∈ T, z ≤ p) :
    ∑ B ∈ (T.powerset.filter (fun B => B.Nonempty)).filter
        (fun B => X ≤ ∏ p ∈ B, p ∧ ∏ p ∈ B, p < 2 * X), (1 / (∏ p ∈ B, (p : ℝ))) ≤
      (8 / ((Nat.log 2 z : ℝ) - 1)) *
        ∑ B' ∈ (T.filter (· < 2 * X)).powerset, (1 / (∏ p ∈ B', (p : ℝ))) := by
  have hlogz : (2 : ℝ) ≤ Nat.log 2 z := by
    have : 2 ≤ Nat.log 2 z := Nat.le_log_of_pow_le (by norm_num) (by simpa using hz)
    exact_mod_cast this
  have hden : (0 : ℝ) < (Nat.log 2 z : ℝ) - 1 := by linarith
  rw [Finset.sum_filter, sum_nonempty_by_max]
  -- each (p, B') term: drop B' ⊆ T_{<p} to B' ⊆ T_{<2X} (nonnegative terms)
  have step1 : ∀ p ∈ T, ∑ B' ∈ (T.filter (· < p)).powerset,
      (if X ≤ ∏ q ∈ insert p B', q ∧ ∏ q ∈ insert p B', q < 2 * X then
        1 / (∏ q ∈ insert p B', (q : ℝ)) else 0) ≤
      ∑ B' ∈ (T.filter (· < 2 * X)).powerset,
        (if X ≤ p * ∏ q ∈ B', q ∧ p * ∏ q ∈ B', q < 2 * X then
          (1 / (p : ℝ)) * (1 / (∏ q ∈ B', (q : ℝ))) else 0) := by
    intro p hp
    -- terms with a nonzero value have B' ⊆ T_{<2X} and the same value
    calc _ = ∑ B' ∈ (T.filter (· < p)).powerset,
          (if X ≤ p * ∏ q ∈ B', q ∧ p * ∏ q ∈ B', q < 2 * X then
            (1 / (p : ℝ)) * (1 / (∏ q ∈ B', (q : ℝ))) else 0) := by
          refine Finset.sum_congr rfl fun B' hB' => ?_
          rw [mem_powerset] at hB'
          have hpnot : p ∉ B' := fun h => by have := (mem_filter.1 (hB' h)).2; omega
          rw [prod_insert hpnot, prod_insert hpnot]
          split_ifs <;> simp [mul_comm]
      _ ≤ _ := by
          rw [← Finset.sum_filter_add_sum_filter_not (T.filter (· < p)).powerset
            (fun B' => B' ⊆ T.filter (· < 2 * X))]
          have hzero : ∑ B' ∈ (T.filter (· < p)).powerset.filter (fun B' => ¬ B' ⊆ T.filter (· < 2 * X)),
              (if X ≤ p * ∏ q ∈ B', q ∧ p * ∏ q ∈ B', q < 2 * X then
                (1 / (p : ℝ)) * (1 / (∏ q ∈ B', (q : ℝ))) else 0) = 0 := by
            refine Finset.sum_eq_zero fun B' hB' => ?_
            rw [mem_filter, mem_powerset] at hB'
            rw [if_neg]
            rintro ⟨-, h2⟩
            apply hB'.2
            intro q hq
            rw [mem_filter]
            refine ⟨(mem_filter.1 (hB'.1 hq)).1, ?_⟩
            have hqle : q ≤ ∏ r ∈ B', r := by
              apply Finset.single_le_prod' (fun r hr => (hT r (mem_filter.1 (hB'.1 hr)).1).one_le) hq
            have hp1 : 1 ≤ p := (hT p hp).one_le
            nlinarith
          rw [hzero, add_zero]
          apply Finset.sum_le_sum_of_subset_of_nonneg
          · intro B' hB'; rw [mem_filter, mem_powerset] at hB'; exact mem_powerset.2 hB'.2
          · intro B' _ _; split_ifs <;> positivity
  refine (Finset.sum_le_sum step1).trans ?_
  rw [Finset.sum_comm, Finset.mul_sum]
  refine Finset.sum_le_sum fun B' hB' => ?_
  set m := ∏ q ∈ B', q with hm
  have hmpos : 0 < m := Finset.prod_pos fun q hq =>
    (hT q (mem_filter.1 (mem_powerset.1 hB' hq)).1).pos
  have hmR : (0 : ℝ) < ∏ q ∈ B', (q : ℝ) := by rw [← Nat.cast_prod]; exact_mod_cast hmpos
  -- inner p-sum ≤ (1/∏B')·8/(log₂ z − 1)
  have hinner : ∑ p ∈ T, (if X ≤ p * m ∧ p * m < 2 * X then
        (1 / (p : ℝ)) * (1 / (∏ q ∈ B', (q : ℝ))) else 0) ≤
      (8 / ((Nat.log 2 z : ℝ) - 1)) * (1 / (∏ q ∈ B', (q : ℝ))) := by
    rw [← Finset.sum_filter]
    simp_rw [← Finset.sum_mul]
    refine mul_le_mul_of_nonneg_right ?_ (by positivity)
    set W := T.filter (fun p => X ≤ p * m ∧ p * m < 2 * X)
    rcases W.eq_empty_or_nonempty with hW | hW
    · rw [hW, sum_empty]; positivity
    · -- Y = ⌈X/m⌉; all p ∈ W lie in [Y, 2Y), and Y ≥ z/2
      set Y := (X + m - 1) / m with hY
      have hWsub : W ⊆ (Ico Y (2 * Y)).filter Nat.Prime := by
        intro p hp
        rw [mem_filter] at hp
        rw [mem_filter, mem_Ico]
        refine ⟨⟨?_, ?_⟩, hT p hp.1⟩
        · rw [hY, Nat.div_le_iff_le_mul_add_pred hmpos]
          have : p * m = m * p := Nat.mul_comm _ _
          have := hp.2.1
          omega
        · have h1 : p * m < 2 * X := hp.2.2
          have h2 : X ≤ m * Y := by
            have h3 := Nat.div_add_mod (X + m - 1) m
            have h4 := Nat.mod_lt (X + m - 1) hmpos
            rw [hY]; omega
          have h5 : p * m < (2 * Y) * m := by
            calc p * m < 2 * X := h1
              _ ≤ 2 * (m * Y) := by omega
              _ = (2 * Y) * m := by ring
          exact Nat.lt_of_mul_lt_mul_right h5
      obtain ⟨p₀, hp₀⟩ := hW
      have hp₀' := mem_filter.1 hp₀
      have hYz : z ≤ 2 * Y := by
        have := mem_Ico.1 (mem_filter.1 (hWsub hp₀)).1
        have := hTz p₀ hp₀'.1; omega
      have hY2 : 2 ≤ Y := by omega
      have hlogY : (Nat.log 2 z : ℝ) - 1 ≤ Nat.log 2 Y := by
        have : Nat.log 2 z ≤ Nat.log 2 Y + 1 := by
          have h1 := Nat.log_mono_right (b := 2) hYz
          have h2 : Nat.log 2 (2 * Y) = Nat.log 2 Y + 1 := by
            rw [mul_comm, Nat.log_mul_base (by norm_num) (by omega)]
          omega
        have : ((Nat.log 2 z : ℕ) : ℝ) ≤ ((Nat.log 2 Y + 1 : ℕ) : ℝ) := by exact_mod_cast this
        push_cast at this; linarith
      calc ∑ p ∈ W, (1 / (p : ℝ))
          ≤ ∑ p ∈ (Ico Y (2 * Y)).filter Nat.Prime, (1 / (p : ℝ)) :=
            Finset.sum_le_sum_of_subset_of_nonneg hWsub fun _ _ _ => by positivity
        _ ≤ 8 / (Nat.log 2 Y : ℝ) := sum_inv_primes_window Y hY2
        _ ≤ 8 / ((Nat.log 2 z : ℝ) - 1) := by
            apply div_le_div_of_nonneg_left (by norm_num) hden hlogY
  exact hinner

end GoldC.QuillonSieve

#print axioms GoldC.QuillonSieve.sum_inv_primes_dyadic_harmonic
#print axioms GoldC.QuillonSieve.sum_inv_Ico_le_log
#print axioms GoldC.QuillonSieve.sum_inv_primes_window
#print axioms GoldC.QuillonSieve.sum_inv_prod_subsets_le
#print axioms GoldC.QuillonSieve.rough_mass
