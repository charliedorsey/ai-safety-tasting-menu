import Mathlib.Data.ZMod.Units
import Mathlib.Data.ZMod.Basic
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Data.Real.Basic
import Mathlib.Algebra.Order.Archimedean.Real.Basic
import Mathlib.Order.Interval.Finset.Nat

/-!
# Oriel Upper — partial sums of periodic sequences

* `oriel_sum_Ico_period`: any `P` consecutive terms of a `P`-periodic sequence sum to the
  same value.
* `oriel_periodic_partial_sum`: for `P`-periodic `h` with `|h| ≤ M` and real `y ≥ 0`,
  `|∑_{1 ≤ u ≤ ⌊y⌋} h u - (S/P) y| ≤ (2P+1) M`, `S = ∑_{z<P} h z`.
* `oriel_sum_range_zmod`: `∑_{k<P} f (k : ZMod P) = ∑_{z : ZMod P} f z`.
* `oriel_sum_affine_unit`: `∑_{z} Λ (c + γ z) = ∑_z Λ z` for a unit `γ`.
-/

open Finset

namespace OrielUpper

theorem oriel_sum_Ico_period {P : ℕ} {h : ℕ → ℝ} (hper : ∀ n, h (n + P) = h n) (a : ℕ) :
    ∑ u ∈ Ico a (a + P), h u = ∑ u ∈ range P, h u := by
  induction a with
  | zero => rw [zero_add, Finset.range_eq_Ico]
  | succ a ih =>
    have e1 : ∑ u ∈ Ico a (a + P), h u + h (a + P) =
        h a + ∑ u ∈ Ico (a + 1) (a + 1 + P), h u := by
      rcases Nat.eq_zero_or_pos P with hP | hP
      · subst hP; simp
      rw [sum_eq_sum_Ico_succ_bot (by omega), show a + 1 + P = a + P + 1 by ring,
        sum_Ico_succ_top (by omega)]
      ring
    rw [hper a] at e1
    linarith

theorem oriel_sum_Ico_mul_period {P : ℕ} {h : ℕ → ℝ} (hper : ∀ n, h (n + P) = h n)
    (a q : ℕ) : ∑ u ∈ Ico a (a + q * P), h u = q * ∑ u ∈ range P, h u := by
  induction q with
  | zero => simp
  | succ q ih =>
    rw [show a + (q + 1) * P = (a + q * P) + P by ring,
      ← sum_Ico_consecutive _ (by omega : a ≤ a + q * P) (by omega : a + q * P ≤ a + q * P + P),
      ih, oriel_sum_Ico_period hper]
    push_cast; ring

/-- Partial sums of a periodic sequence against its mean. -/
theorem oriel_periodic_partial_sum {P : ℕ} (hP : 0 < P) {h : ℕ → ℝ}
    (hper : ∀ n, h (n + P) = h n) {M : ℝ} (hM : ∀ n, |h n| ≤ M) {y : ℝ} (hy : 0 ≤ y) :
    |∑ u ∈ Icc 1 ⌊y⌋₊, h u - (∑ z ∈ range P, h z) / P * y| ≤ (2 * P + 1) * M := by
  set N := ⌊y⌋₊
  set S := ∑ z ∈ range P, h z
  have hM0 : 0 ≤ M := le_trans (abs_nonneg _) (hM 0)
  have hPr : (0 : ℝ) < P := by exact_mod_cast hP
  obtain ⟨q, ρ, hρ, hN⟩ : ∃ q ρ, ρ < P ∧ N = q * P + ρ :=
    ⟨N / P, N % P, Nat.mod_lt _ hP, by rw [Nat.div_add_mod' N P]⟩
  have hIcc : Icc 1 N = Ico 1 (1 + N) := by
    ext u; simp [Nat.lt_succ_iff]; omega
  have hsplit : ∑ u ∈ Icc 1 N, h u = q * S + ∑ u ∈ Ico (1 + q * P) (1 + N), h u := by
    rw [hIcc, ← sum_Ico_consecutive _ (by omega : 1 ≤ 1 + q * P) (by omega : 1 + q * P ≤ 1 + N),
      oriel_sum_Ico_mul_period hper]
  have hrem : |∑ u ∈ Ico (1 + q * P) (1 + N), h u| ≤ ρ * M := by
    calc |∑ u ∈ Ico (1 + q * P) (1 + N), h u| ≤ ∑ u ∈ Ico (1 + q * P) (1 + N), |h u| :=
          abs_sum_le_sum_abs _ _
      _ ≤ ∑ u ∈ Ico (1 + q * P) (1 + N), M := sum_le_sum (fun u _ => hM u)
      _ = ρ * M := by
          have hc : 1 + N - (1 + q * P) = ρ := by omega
          rw [sum_const, Nat.card_Ico, nsmul_eq_mul, hc]
  have hS : |S| ≤ P * M := by
    calc |S| ≤ ∑ z ∈ range P, |h z| := abs_sum_le_sum_abs _ _
      _ ≤ ∑ z ∈ range P, M := sum_le_sum (fun z _ => hM z)
      _ = P * M := by rw [sum_const, card_range, nsmul_eq_mul]
  have hNy : (N : ℝ) ≤ y ∧ y < N + 1 := ⟨Nat.floor_le hy, Nat.lt_floor_add_one y⟩
  have hqP : |(q : ℝ) * P - y| ≤ P := by
    have : (N : ℝ) = q * P + ρ := by rw [hN]; push_cast; ring
    have hρ' : (ρ : ℝ) + 1 ≤ P := by exact_mod_cast hρ
    rw [abs_le]; constructor <;> nlinarith [hNy.1, hNy.2]
  have hmain : |(q : ℝ) * S - S / P * y| ≤ P * M := by
    have : (q : ℝ) * S - S / P * y = S / P * ((q : ℝ) * P - y) := by field_simp
    rw [this, abs_mul, abs_div, abs_of_pos hPr]
    calc |S| / P * |(q : ℝ) * P - y| ≤ (P * M) / P * P := by
          gcongr
      _ = P * M := by field_simp
  have hρM : (ρ : ℝ) * M ≤ P * M := by
    have : (ρ : ℝ) ≤ P := by exact_mod_cast hρ.le
    nlinarith
  rw [hsplit]
  calc |↑q * S + ∑ u ∈ Ico (1 + q * P) (1 + N), h u - S / ↑P * y|
      = |(↑q * S - S / ↑P * y) + ∑ u ∈ Ico (1 + q * P) (1 + N), h u| := by ring_nf
    _ ≤ |↑q * S - S / ↑P * y| + |∑ u ∈ Ico (1 + q * P) (1 + N), h u| := abs_add_le _ _
    _ ≤ P * M + ρ * M := add_le_add hmain hrem
    _ ≤ (2 * P + 1) * M := by nlinarith

/-- Sum over `range P` of a function of the residue equals the sum over `ZMod P`. -/
theorem oriel_sum_range_zmod {P : ℕ} [NeZero P] (f : ZMod P → ℝ) :
    ∑ k ∈ range P, f (k : ZMod P) = ∑ z : ZMod P, f z := by
  apply Finset.sum_nbij' (s := range P) (t := univ) (fun k : ℕ => (k : ZMod P))
    (fun z : ZMod P => z.val)
  · intro k _; exact mem_univ _
  · intro z _; exact mem_range.mpr (ZMod.val_lt z)
  · intro k hk
    simp only [ZMod.val_natCast]
    exact Nat.mod_eq_of_lt (mem_range.mp hk)
  · intro z _; exact ZMod.natCast_zmod_val z
  · intro k _; rfl

/-- Affine reindexing by a unit. -/
theorem oriel_sum_affine_unit {P : ℕ} [NeZero P] (Λ : ZMod P → ℝ) (c : ZMod P) (γ : (ZMod P)ˣ) :
    ∑ z : ZMod P, Λ (c + (γ : ZMod P) * z) = ∑ z : ZMod P, Λ z := by
  apply Fintype.sum_equiv ((Units.mulLeft γ).trans (Equiv.addLeft c))
  intro z; rfl

end OrielUpper
