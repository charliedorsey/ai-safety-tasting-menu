import PaperB.FixedQ.RowReflection
import PaperB.FixedQ.DivisorExpansion

namespace PaperB.FixedQ

lemma dvd_sub_iff_of_dvd_left
    {p h y : ℕ} (hph : p ∣ h) (hy : y ≤ h) :
    p ∣ h - y ↔ p ∣ y := by
  constructor
  · intro hsub
    apply (Nat.dvd_add_iff_left hsub).mpr
    simpa [Nat.add_sub_of_le hy] using hph
  · intro hpy
    exact Nat.dvd_sub hph hpy

lemma not_dvd_sub_of_not_dvd_left_and_dvd_right
    {p h y : ℕ} (hph : ¬ p ∣ h) (hpy : p ∣ y) (hy : y ≤ h) :
    ¬ p ∣ h - y := by
  intro hsub
  apply hph
  have hadd : p ∣ y + (h - y) := dvd_add hpy hsub
  simpa [Nat.add_sub_of_le hy] using hadd

theorem highPrimeLocalRatio_reflect
    (p h y : ℕ) (hy : y ≤ h) :
    highPrimeLocalRatio p h (h - y) =
      highPrimeLocalRatio p h y := by
  unfold highPrimeLocalRatio
  by_cases hph : p ∣ h
  · have hiff := dvd_sub_iff_of_dvd_left hph hy
    by_cases hpy : p ∣ y
    · have hsub : p ∣ h - y := hiff.mpr hpy
      simp [hph, hpy, hsub]
    · have hsub : ¬ p ∣ h - y := by
        exact fun hs => hpy (hiff.mp hs)
      simp [hph, hpy, hsub]
  · by_cases hpy : p ∣ y
    · have hsub : ¬ p ∣ h - y :=
        not_dvd_sub_of_not_dvd_left_and_dvd_right hph hpy hy
      simp [hph, hpy, hsub, Nat.sub_sub_self hy]
    · by_cases hsub : p ∣ h - y
      · simp [hph, hpy, hsub, Nat.sub_sub_self hy]
      · simp [hph, hpy, hsub, Nat.sub_sub_self hy]

theorem activeHighLocalRatio_reflect
    (q p h y : ℕ) (hy : y ≤ h) :
    activeHighLocalRatio q h (h - y) p =
      activeHighLocalRatio q h y p := by
  unfold activeHighLocalRatio
  by_cases ha : activeHighPrime q p
  · rw [if_pos ha, if_pos ha]
    exact_mod_cast highPrimeLocalRatio_reflect p h y hy
  · simp [ha]

theorem lowPrimeLocalRatio_reflect
    (p h y : ℕ) (hy : y ≤ h) :
    lowPrimeLocalRatio p h (h - y) =
      lowPrimeLocalRatio p h y := by
  unfold lowPrimeLocalRatio
  exact_mod_cast highPrimeLocalRatio_reflect p h y hy

theorem lowPrimeProduct_reflect
    (q h y : ℕ) (hy : y ≤ h) :
    (∏ p ∈ lowPrimeSet,
        if p ∣ q then 1 else lowPrimeLocalRatio p h (h - y)) =
      ∏ p ∈ lowPrimeSet,
        if p ∣ q then 1 else lowPrimeLocalRatio p h y := by
  apply Finset.prod_congr rfl
  intro p hp
  by_cases hpq : p ∣ q
  · simp [hpq]
  · simp [hpq, lowPrimeLocalRatio_reflect p h y hy]

#print axioms highPrimeLocalRatio_reflect
#print axioms activeHighLocalRatio_reflect
#print axioms lowPrimeProduct_reflect

end PaperB.FixedQ
