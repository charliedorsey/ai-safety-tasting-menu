import PaperB.FixedQ.H3DecoratedAnalyticShell
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics

open Filter Real Asymptotics
open scoped BigOperators

namespace PaperB.FixedQ

def BooleanL1LogPowerSaving (q : ℕ) : Prop :=
  ∃ C rho : ℝ, ∃ k H0 : ℕ,
    0 ≤ C ∧ rho < 1 ∧
      ∀ h A H : ℕ,
        q.Coprime A →
        0 < H →
        (¬ 2 ∣ q → 2 ∣ H) →
        H ≤ h →
        H0 ≤ H →
        ordinaryBooleanAbsFamily q A H ≤
          C * (Real.log (h : ℝ)) ^ rho *
            (Real.log (Real.log (h : ℝ))) ^ k

theorem loglog_pow_mul_log_rpow_isLittleO
    (rho : ℝ) (k : ℕ) (hrho : rho < 1) :
    (fun x : ℝ =>
      (Real.log (Real.log x)) ^ ((k + 1 : ℕ) : ℝ) *
        (Real.log x) ^ rho) =o[atTop] Real.log := by
  have hs : 0 < 1 - rho := sub_pos.mpr hrho
  have h0 :
      (fun t : ℝ => Real.log t ^ ((k + 1 : ℕ) : ℝ)) =o[atTop]
        (fun t : ℝ => t ^ (1 - rho)) :=
    isLittleO_log_rpow_rpow_atTop (((k + 1 : ℕ) : ℝ)) hs
  have hsame :
      (fun t : ℝ => t ^ rho) =O[atTop] (fun t : ℝ => t ^ rho) :=
    isBigO_refl _ _
  have hm := h0.mul_isBigO hsame
  have hm' :
      (fun t : ℝ => Real.log t ^ ((k + 1 : ℕ) : ℝ) * t ^ rho) =o[atTop]
        (fun t : ℝ => t) := by
    refine hm.congr' ?_ ?_
    · filter_upwards with t
      rfl
    · filter_upwards [eventually_gt_atTop (0 : ℝ)] with t ht
      rw [← Real.rpow_add ht]
      ring_nf
      simp
  have hc := hm'.comp_tendsto Real.tendsto_log_atTop
  simpa [Function.comp_def] using hc

theorem eventually_const_mul_loglog_pow_mul_log_rpow_le
    {C rho : ℝ} {k : ℕ}
    (hC : 0 ≤ C) (hrho : rho < 1) :
    ∀ eps : ℝ, 0 < eps →
      ∃ h0 : ℕ, ∀ h : ℕ, h0 ≤ h →
        C * (Real.log (Real.log (h : ℝ))) ^ ((k + 1 : ℕ) : ℝ) *
              (Real.log (h : ℝ)) ^ rho
          ≤ eps * Real.log (h : ℝ) := by
  intro eps heps
  have hlo := (loglog_pow_mul_log_rpow_isLittleO rho k hrho).const_mul_left C
  have hev := hlo.bound heps
  rw [Filter.eventually_atTop] at hev
  obtain ⟨T, hT⟩ := hev
  obtain ⟨N, hN⟩ := exists_nat_ge T
  refine ⟨max 16 N, ?_⟩
  intro h hh
  have hh16 : 16 ≤ h := (le_max_left 16 N).trans hh
  have hNh : N ≤ h := (le_max_right 16 N).trans hh
  have hTR : T ≤ (h : ℝ) := hN.trans (by exact_mod_cast hNh)
  have hb := hT (h : ℝ) hTR
  have hll0 : 0 ≤ Real.log (Real.log (h : ℝ)) := by
    have h1 := one_le_log_log_nat_of_sixteen_le hh16
    linarith
  have hl0 : 0 ≤ Real.log (h : ℝ) :=
    Real.log_nonneg (by exact_mod_cast (show 1 ≤ h by omega))
  have hpowll0 :
      0 ≤ (Real.log (Real.log (h : ℝ))) ^ ((k + 1 : ℕ) : ℝ) :=
    Real.rpow_nonneg hll0 _
  have hpow0 : 0 ≤ (Real.log (h : ℝ)) ^ rho :=
    Real.rpow_nonneg hl0 _
  rw [Real.norm_eq_abs,
    abs_of_nonneg (mul_nonneg hC (mul_nonneg hpowll0 hpow0)),
    Real.norm_eq_abs, abs_of_nonneg hl0] at hb
  simpa [mul_assoc] using hb

theorem eventually_const_mul_loglog_le
    {C : ℝ} (hC : 0 ≤ C) :
    ∀ eps : ℝ, 0 < eps →
      ∃ h0 : ℕ, ∀ h : ℕ, h0 ≤ h →
        C * Real.log (Real.log (h : ℝ)) ≤
          eps * Real.log (h : ℝ) := by
  intro eps heps
  obtain ⟨h0, hh⟩ :=
    eventually_const_mul_loglog_pow_mul_log_rpow_le
      (C := C) (rho := (0 : ℝ)) (k := 0) hC (by norm_num) eps heps
  refine ⟨h0, ?_⟩
  intro h hlarge
  have hb := hh h hlarge
  simpa using hb

theorem decoratedAnalytic_sublog_of_boolean_l1_log_power
    (q : ℕ) (hq : 0 < q)
    (hRate : BooleanL1LogPowerSaving q) :
    ∀ eps : ℝ, 0 < eps →
      ∃ h0 : ℕ,
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          h0 ≤ h →
          |cStarReal q h * decoratedAnalyticRemainder q a h| ≤
            eps * Real.log (h : ℝ) := by
  rcases hRate with ⟨C, rho, k, H0, hC, hrho, hRate⟩
  rcases ordinaryBooleanCore_abs_l1_smallHeight_uniform q H0 hq with
    ⟨B, hB, hSmall⟩
  have hW : 0 ≤ weakDecoratedMertensC := by
    unfold weakDecoratedMertensC weakMertensC
    positivity
  intro eps heps
  have heps2 : 0 < eps / 2 := by positivity
  obtain ⟨hMain, hhMain⟩ :=
    eventually_const_mul_loglog_pow_mul_log_rpow_le
      (C := weakDecoratedMertensC * C) (rho := rho) (k := k)
      (mul_nonneg hW hC) hrho (eps / 2) heps2
  obtain ⟨hSmall0, hhSmall⟩ :=
    eventually_const_mul_loglog_le
      (C := weakDecoratedMertensC * B) (mul_nonneg hW hB)
      (eps / 2) heps2
  refine ⟨max 16 (max hMain hSmall0), ?_⟩
  intro a b h ha hb hab h2admissible hh hlarge
  have hh16 : 16 ≤ h := (le_max_left 16 (max hMain hSmall0)).trans hlarge
  have hhMain' : hMain ≤ h :=
    (le_trans (le_max_left hMain hSmall0)
      ((le_max_right 16 (max hMain hSmall0)).trans hlarge))
  have hhSmall' : hSmall0 ≤ h :=
    (le_trans (le_max_right hMain hSmall0)
      ((le_max_right 16 (max hMain hSmall0)).trans hlarge))
  let Q : ℝ :=
    C * (Real.log (h : ℝ)) ^ rho *
      (Real.log (Real.log (h : ℝ))) ^ k
  have hll0 : 0 ≤ Real.log (Real.log (h : ℝ)) := by
    have h1 := one_le_log_log_nat_of_sixteen_le hh16
    linarith
  have hQ0 : 0 ≤ Q := by
    dsimp [Q]
    positivity
  have hLargeLocal :
      ∀ A H : ℕ,
        q.Coprime A →
        0 < H →
        (¬ 2 ∣ q → 2 ∣ H) →
        H ≤ h →
        H0 ≤ H →
        ordinaryBooleanAbsFamily q A H ≤ Q := by
    intro A H hA hH h2H hHh hH0
    exact hRate h A H hA hH h2H hHh hH0
  have hshell :=
    abs_cStar_mul_decoratedAnalyticRemainder_le_height_mass_of_boolean_l1_split
      (q := q) (a := a) (h := h) (H0 := H0) (Q := Q) (B := B)
      hq ha hh16 h2admissible hQ0 hB hLargeLocal
      (by
        intro A H hA hH h2H hlt
        simpa [ordinaryBooleanAbsFamily] using hSmall A H hA h2H hH hlt)
  have hmain0 := hhMain h hhMain'
  have hsmall0 := hhSmall h hhSmall'
  have hpowSucc :
      (Real.log (Real.log (h : ℝ))) ^ ((k + 1 : ℕ) : ℝ) =
        Real.log (Real.log (h : ℝ)) *
          (Real.log (Real.log (h : ℝ))) ^ k := by
    rw [Real.rpow_natCast]
    rw [pow_succ']
  have hmain :
      weakDecoratedMertensC * Real.log (Real.log (h : ℝ)) * Q ≤
        (eps / 2) * Real.log (h : ℝ) := by
    dsimp [Q]
    rw [hpowSucc] at hmain0
    nlinarith [hmain0]
  have hsmall :
      weakDecoratedMertensC * Real.log (Real.log (h : ℝ)) * B ≤
        (eps / 2) * Real.log (h : ℝ) := by
    nlinarith [hsmall0]
  calc
    |cStarReal q h * decoratedAnalyticRemainder q a h|
      ≤ (weakDecoratedMertensC * Real.log (Real.log (h : ℝ))) * (Q + B) :=
        hshell
    _ = weakDecoratedMertensC * Real.log (Real.log (h : ℝ)) * Q +
        weakDecoratedMertensC * Real.log (Real.log (h : ℝ)) * B := by ring
    _ ≤ (eps / 2) * Real.log (h : ℝ) +
        (eps / 2) * Real.log (h : ℝ) := add_le_add hmain hsmall
    _ = eps * Real.log (h : ℝ) := by ring

theorem decoratedAnalyticContract_of_boolean_l1_log_power
    (hRate :
      ∀ q : ℕ, 0 < q → Squarefree q →
        BooleanL1LogPowerSaving q) :
    PaperB.Closure.DecoratedAnalyticContract := by
  intro q hq hsq eps heps
  exact decoratedAnalytic_sublog_of_boolean_l1_log_power
    q hq (hRate q hq hsq) eps heps

theorem abs_ordinaryBooleanCore_le_absFamily
    {q a h : ℕ}
    (hq : 0 < q)
    (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    |ordinaryBooleanCore q a h| ≤ ordinaryBooleanAbsFamily q a h := by
  have hs := summable_ordinaryBooleanCoreTerm
    (q := q) (a := a) (h := h) hq hh h2admissible
  change |∑' e : Finset ℕ, ordinaryBooleanCoreTerm q a h e| ≤
    ∑' e : Finset ℕ, |ordinaryBooleanCoreTerm q a h e|
  simpa [Real.norm_eq_abs] using norm_tsum_le_tsum_norm hs.norm

theorem abs_cStar_mul_ordinaryBooleanCore_le_absFamily
    {q a h : ℕ}
    (hq : 0 < q)
    (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    |cStarReal q h * ordinaryBooleanCore q a h| ≤
      ordinaryBooleanAbsFamily q a h := by
  rw [abs_mul]
  calc
    |cStarReal q h| * |ordinaryBooleanCore q a h|
      ≤ 1 * |ordinaryBooleanCore q a h| := by
          exact mul_le_mul_of_nonneg_right
            (abs_cStarReal_le_one q h) (abs_nonneg _)
    _ = |ordinaryBooleanCore q a h| := one_mul _
    _ ≤ ordinaryBooleanAbsFamily q a h :=
      abs_ordinaryBooleanCore_le_absFamily hq hh h2admissible

theorem loglog_pow_mul_log_rpow_isLittleO_no_extra
    (rho : ℝ) (k : ℕ) (hrho : rho < 1) :
    (fun x : ℝ =>
      (Real.log (Real.log x)) ^ (k : ℝ) *
        (Real.log x) ^ rho) =o[atTop] Real.log := by
  have hs : 0 < 1 - rho := sub_pos.mpr hrho
  have h0 :
      (fun t : ℝ => Real.log t ^ (k : ℝ)) =o[atTop]
        (fun t : ℝ => t ^ (1 - rho)) :=
    isLittleO_log_rpow_rpow_atTop (k : ℝ) hs
  have hsame :
      (fun t : ℝ => t ^ rho) =O[atTop] (fun t : ℝ => t ^ rho) :=
    isBigO_refl _ _
  have hm := h0.mul_isBigO hsame
  have hm' :
      (fun t : ℝ => Real.log t ^ (k : ℝ) * t ^ rho) =o[atTop]
        (fun t : ℝ => t) := by
    refine hm.congr' ?_ ?_
    · filter_upwards with t
      rfl
    · filter_upwards [eventually_gt_atTop (0 : ℝ)] with t ht
      rw [← Real.rpow_add ht]
      ring_nf
      simp
  have hc := hm'.comp_tendsto Real.tendsto_log_atTop
  simpa [Function.comp_def] using hc

theorem eventually_const_mul_loglog_pow_mul_log_rpow_le_no_extra
    {C rho : ℝ} {k : ℕ}
    (hC : 0 ≤ C) (hrho : rho < 1) :
    ∀ eps : ℝ, 0 < eps →
      ∃ h0 : ℕ, ∀ h : ℕ, h0 ≤ h →
        C * (Real.log (Real.log (h : ℝ))) ^ k *
              (Real.log (h : ℝ)) ^ rho
          ≤ eps * Real.log (h : ℝ) := by
  intro eps heps
  have hlo :=
    (loglog_pow_mul_log_rpow_isLittleO_no_extra rho k hrho).const_mul_left C
  have hev := hlo.bound heps
  rw [Filter.eventually_atTop] at hev
  obtain ⟨T, hT⟩ := hev
  obtain ⟨N, hN⟩ := exists_nat_ge T
  refine ⟨max 16 N, ?_⟩
  intro h hh
  have hh16 : 16 ≤ h := (le_max_left 16 N).trans hh
  have hNh : N ≤ h := (le_max_right 16 N).trans hh
  have hTR : T ≤ (h : ℝ) := hN.trans (by exact_mod_cast hNh)
  have hb := hT (h : ℝ) hTR
  have hll0 : 0 ≤ Real.log (Real.log (h : ℝ)) := by
    have h1 := one_le_log_log_nat_of_sixteen_le hh16
    linarith
  have hl0 : 0 ≤ Real.log (h : ℝ) :=
    Real.log_nonneg (by exact_mod_cast (show 1 ≤ h by omega))
  have hpowll0R :
      0 ≤ (Real.log (Real.log (h : ℝ))) ^ (k : ℝ) :=
    Real.rpow_nonneg hll0 _
  have hpow0 : 0 ≤ (Real.log (h : ℝ)) ^ rho :=
    Real.rpow_nonneg hl0 _
  rw [Real.norm_eq_abs,
    abs_of_nonneg (mul_nonneg hC (mul_nonneg hpowll0R hpow0)),
    Real.norm_eq_abs, abs_of_nonneg hl0] at hb
  simpa [mul_assoc, Real.rpow_natCast] using hb

theorem ordinaryBooleanCore_sublog_of_boolean_l1_log_power
    (q : ℕ) (hq : 0 < q)
    (hRate : BooleanL1LogPowerSaving q) :
    ∀ eps : ℝ, 0 < eps →
      ∃ h0 : ℕ,
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          h0 ≤ h →
          |cStarReal q h * ordinaryBooleanCore q a h| ≤
            eps * Real.log (h : ℝ) := by
  rcases hRate with ⟨C, rho, k, H0, hC, hrho, hRate⟩
  intro eps heps
  obtain ⟨hAbsorb, hhAbsorb⟩ :=
    eventually_const_mul_loglog_pow_mul_log_rpow_le_no_extra
      (C := C) (rho := rho) (k := k) hC hrho eps heps
  refine ⟨max H0 hAbsorb, ?_⟩
  intro a b h ha hb hab h2admissible hh hlarge
  have hH0 : H0 ≤ h := (le_max_left H0 hAbsorb).trans hlarge
  have hAbs : hAbsorb ≤ h := (le_max_right H0 hAbsorb).trans hlarge
  have hL1 :
      ordinaryBooleanAbsFamily q a h ≤
        C * (Real.log (h : ℝ)) ^ rho *
          (Real.log (Real.log (h : ℝ))) ^ k := by
    exact hRate h a h ha hh h2admissible (le_refl h) hH0
  have hcore :=
    abs_cStar_mul_ordinaryBooleanCore_le_absFamily
      (q := q) (a := a) (h := h) hq hh h2admissible
  have hgrowth := hhAbsorb h hAbs
  calc
    |cStarReal q h * ordinaryBooleanCore q a h|
      ≤ ordinaryBooleanAbsFamily q a h := hcore
    _ ≤ C * (Real.log (h : ℝ)) ^ rho *
          (Real.log (Real.log (h : ℝ))) ^ k := hL1
    _ = C * (Real.log (Real.log (h : ℝ))) ^ k *
          (Real.log (h : ℝ)) ^ rho := by ring
    _ ≤ eps * Real.log (h : ℝ) := hgrowth

theorem ordinaryBooleanCoreContract_of_boolean_l1_log_power
    (hRate :
      ∀ q : ℕ, 0 < q → Squarefree q →
        BooleanL1LogPowerSaving q) :
    PaperB.Closure.OrdinaryBooleanCoreContract := by
  intro q hq hsq eps heps
  exact ordinaryBooleanCore_sublog_of_boolean_l1_log_power
    q hq (hRate q hq hsq) eps heps


#print axioms abs_ordinaryBooleanCore_le_absFamily
#print axioms abs_cStar_mul_ordinaryBooleanCore_le_absFamily
#print axioms ordinaryBooleanCore_sublog_of_boolean_l1_log_power
#print axioms ordinaryBooleanCoreContract_of_boolean_l1_log_power

#print axioms loglog_pow_mul_log_rpow_isLittleO
#print axioms eventually_const_mul_loglog_pow_mul_log_rpow_le
#print axioms eventually_const_mul_loglog_le
#print axioms decoratedAnalytic_sublog_of_boolean_l1_log_power
#print axioms decoratedAnalyticContract_of_boolean_l1_log_power

end PaperB.FixedQ
