import OrielUpper.Main

/-!
# Oriel L/R — the exact sawtooth form of the oriented row discrepancy

For a fixed modulus `m` (coprime to `P`), `Q = P m`, unit residues `v, t`, and `x ≥ 0`:

`psiR m H Λ α β v t x = C(v,t) - ∑_{j=1}^{Q} rowF(j) · saw((x - j)/Q)`,
`C(v,t) = ∑_{j=1}^{Q} rowF(j) (1/2 - j/Q)`, `saw y = {y} - 1/2`.
-/

open Finset

namespace OrielUpper

/-- The centred sawtooth `ψ(y) = {y} - 1/2`. -/
noncomputable def saw (y : ℝ) : ℝ := Int.fract y - 1 / 2

lemma abs_saw_le (y : ℝ) : |saw y| ≤ 1 / 2 := by
  unfold saw
  have h0 := Int.fract_nonneg y
  have h1 := Int.fract_lt_one y
  rw [abs_le]; constructor <;> linarith

lemma saw_add_one (y : ℝ) : saw (y + 1) = saw y := by
  unfold saw; rw [Int.fract_add_one]

/-- Count of `u ∈ [1, ⌊x⌋]` in the class of `j ∈ [1, Q]`. -/
lemma card_class_Icc {Q j N : ℕ} (hQ : 0 < Q) (hj1 : 1 ≤ j) (hjQ : j ≤ Q) :
    ((Icc 1 N).filter (fun u => u % Q = j % Q)).card = (N + Q - j) / Q := by
  rw [← card_range ((N + Q - j) / Q)]
  symm
  apply Finset.card_bij (fun k _ => j + Q * k)
  · intro k hk
    rw [mem_range] at hk
    rw [mem_filter, mem_Icc]
    refine ⟨⟨by omega, ?_⟩, ?_⟩
    · have h := (Nat.le_div_iff_mul_le hQ).mp (show k + 1 ≤ (N + Q - j) / Q from hk)
      rw [Nat.succ_mul, mul_comm k Q] at h
      generalize Q * k = A at h ⊢
      omega
    · rw [Nat.add_mul_mod_self_left]
  · intro a _ b _ h; have : Q * a = Q * b := by omega
    exact Nat.eq_of_mul_eq_mul_left hQ this
  · intro u hu
    rw [mem_filter, mem_Icc] at hu
    obtain ⟨⟨hu1, huN⟩, hmod⟩ := hu
    have hju : j ≤ u ∨ u < j := le_or_gt j u
    rcases hju with hju | hju
    · refine ⟨(u - j) / Q, ?_, ?_⟩
      · have hd : Q ∣ u - j := by
          have := Nat.sub_mod_eq_zero_of_mod_eq hmod
          exact Nat.dvd_of_mod_eq_zero this
        obtain ⟨c, hc⟩ := hd
        rw [mem_range, hc, Nat.mul_div_cancel_left c hQ]
        apply Nat.lt_of_lt_of_le (Nat.lt_succ_self c)
        apply (Nat.le_div_iff_mul_le hQ).mpr
        rw [Nat.succ_mul, mul_comm c Q]
        generalize Q * c = A at hc ⊢
        omega
      · have hd : Q ∣ u - j := Nat.dvd_of_mod_eq_zero (Nat.sub_mod_eq_zero_of_mod_eq hmod)
        rw [Nat.mul_div_cancel' hd]; omega
    · exfalso
      -- u < j ≤ Q and u ≥ 1: residues differ
      have h1 : u % Q = u := Nat.mod_eq_of_lt (by omega)
      rcases Nat.lt_or_ge j Q with hjQ' | hjQ'
      · have h2 : j % Q = j := Nat.mod_eq_of_lt hjQ'
        omega
      · have : j = Q := by omega
        subst this
        rw [Nat.mod_self] at hmod; omega

/-- Real form of the class count. -/
lemma card_class_real {Q j : ℕ} (hQ : 0 < Q) (hj1 : 1 ≤ j) (hjQ : j ≤ Q) {x : ℝ} (hx : 0 ≤ x) :
    (((Icc 1 ⌊x⌋₊).filter (fun u => u % Q = j % Q)).card : ℝ) =
      (x - j) / Q + 1 / 2 - saw ((x - j) / Q) := by
  rw [card_class_Icc hQ hj1 hjQ]
  have hQr : (0 : ℝ) < Q := by exact_mod_cast hQ
  set y : ℝ := (x + ((Q - j : ℕ) : ℝ)) / Q
  have hy0 : 0 ≤ y := by positivity
  have hfl : ((⌊x⌋₊ + Q - j) / Q : ℕ) = ⌊y⌋₊ := by
    rw [Nat.floor_div_natCast, Nat.floor_add_natCast hx]
    congr 1; omega
  rw [hfl]
  have hcast : ((⌊y⌋₊ : ℕ) : ℝ) = y - Int.fract y := by
    rw [Int.self_sub_fract, natCast_floor_eq_intCast_floor hy0]
  rw [hcast]
  have hyx : y = (x - j) / Q + 1 := by
    simp only [y]; rw [Nat.cast_sub hjQ]; field_simp; ring
  rw [hyx, Int.fract_add_one]
  unfold saw; ring

/-- `Q`-periodic functions on `ℕ` depend only on the residue. -/
lemma periodic_mod {Q : ℕ} {g : ℕ → ℝ} (hper : ∀ n, g (n + Q) = g n) (n : ℕ) :
    g n = g (n % Q) := by
  conv_lhs => rw [← Nat.mod_add_div n Q]
  generalize n / Q = k
  induction k with
  | zero => simp
  | succ k ih => rw [Nat.mul_succ, ← add_assoc, hper, ih]

/-- Residue decomposition of a periodic partial sum. -/
lemma sum_Icc_periodic {Q : ℕ} (hQ : 0 < Q) {g : ℕ → ℝ} (hper : ∀ n, g (n + Q) = g n) (N : ℕ) :
    ∑ u ∈ Icc 1 N, g u =
      ∑ j ∈ Icc 1 Q, g j * (((Icc 1 N).filter (fun u => u % Q = j % Q)).card : ℝ) := by
  set key : ℕ → ℕ := fun u => if u % Q = 0 then Q else u % Q
  have hkey : ∀ u, key u ∈ Icc 1 Q := by
    intro u; simp only [key, mem_Icc]
    split_ifs with h
    · exact ⟨hQ, le_rfl⟩
    · exact ⟨Nat.pos_of_ne_zero h, (Nat.mod_lt u hQ).le⟩
  have hfib : ∀ j ∈ Icc 1 Q, ∀ u, key u = j ↔ u % Q = j % Q := by
    intro j hj u
    rw [mem_Icc] at hj
    simp only [key]
    have hlt := Nat.mod_lt u hQ
    rcases Nat.lt_or_ge j Q with hjQ | hjQ
    · have hjm : j % Q = j := Nat.mod_eq_of_lt hjQ
      rw [hjm]
      by_cases h : u % Q = 0
      · rw [if_pos h]; constructor <;> intro h' <;> omega
      · rw [if_neg h]
    · have hjq : j = Q := by omega
      rw [hjq, Nat.mod_self]
      by_cases h : u % Q = 0
      · rw [if_pos h]; simp [h]
      · rw [if_neg h]; constructor <;> intro h' <;> omega
  rw [← sum_fiberwise_of_maps_to (fun u _ => hkey u)]
  apply sum_congr rfl
  intro j hj
  have : (Icc 1 N).filter (fun u => key u = j) = (Icc 1 N).filter (fun u => u % Q = j % Q) :=
    filter_congr (fun u _ => hfib j hj u)
  rw [this, mul_comm, ← nsmul_eq_mul, ← sum_const]
  apply sum_congr rfl
  intro u hu
  rw [mem_filter] at hu
  rw [periodic_mod hper u, hu.2, ← periodic_mod hper j]

variable {P : ℕ} [NeZero P]

lemma rowF_periodic {m H : ℕ} {Λ : ZMod P → ℝ} {α β v : ZMod P} {t : ZMod m} (n : ℕ) :
    rowF m H Λ α β v t (n + P * m) = rowF m H Λ α β v t n := by
  unfold rowF
  push_cast
  have h1 : ((P : ZMod P)) = 0 := ZMod.natCast_self P
  have h2 : ((m : ZMod m)) = 0 := ZMod.natCast_self m
  rw [h1, h2]; ring_nf

/-- The sawtooth constant. -/
noncomputable def sawC (m H : ℕ) (Λ : ZMod P → ℝ) (α β v : ZMod P) (t : ZMod m) : ℝ :=
  ∑ j ∈ Icc 1 (P * m), rowF m H Λ α β v t j * (1 / 2 - (j : ℝ) / (P * m : ℕ))

/-- The sawtooth oscillation. -/
noncomputable def sawOsc (m H : ℕ) (Λ : ZMod P → ℝ) (α β v : ZMod P) (t : ZMod m) (x : ℝ) : ℝ :=
  ∑ j ∈ Icc 1 (P * m), rowF m H Λ α β v t j * saw ((x - j) / (P * m : ℕ))

lemma sawtooth_raw {m H : ℕ} (hm : 0 < m) (Λ : ZMod P → ℝ) (α β v : ZMod P) (t : ZMod m)
    {x : ℝ} (hx : 0 ≤ x) :
    psiR m H Λ α β v t x =
      sawC m H Λ α β v t - sawOsc m H Λ α β v t x +
        ((∑ j ∈ Icc 1 (P * m), rowF m H Λ α β v t j) / (P * m : ℕ) - muL Λ / m) * x := by
  have hQ : 0 < P * m := Nat.mul_pos (NeZero.pos P) hm
  have hQr : (0 : ℝ) < (P * m : ℕ) := by exact_mod_cast hQ
  have hmr : (0 : ℝ) < m := by exact_mod_cast hm
  unfold psiR sawC sawOsc
  rw [sum_Icc_periodic hQ (fun n => rowF_periodic n) ⌊x⌋₊]
  have : ∀ j ∈ Icc 1 (P * m), rowF m H Λ α β v t j *
      (((Icc 1 ⌊x⌋₊).filter (fun u => u % (P * m) = j % (P * m))).card : ℝ) =
      rowF m H Λ α β v t j * ((x - j) / (P * m : ℕ) + 1 / 2 - saw ((x - j) / (P * m : ℕ))) := by
    intro j hj
    rw [mem_Icc] at hj
    rw [card_class_real hQ hj.1 hj.2 hx]
  rw [sum_congr rfl this, sum_div]
  rw [show muL Λ * x / m = muL Λ / m * x by ring]
  have e : ∀ j ∈ Icc 1 (P * m), rowF m H Λ α β v t j *
      ((x - j) / (P * m : ℕ) + 1 / 2 - saw ((x - j) / (P * m : ℕ))) =
      rowF m H Λ α β v t j * (1 / 2 - (j : ℝ) / (P * m : ℕ)) -
        rowF m H Λ α β v t j * saw ((x - j) / (P * m : ℕ)) +
        rowF m H Λ α β v t j / (P * m : ℕ) * x := by
    intro j _; field_simp; ring
  rw [sum_congr rfl e, sum_add_distrib, sum_sub_distrib, ← sum_mul]
  ring

lemma abs_sawC_le {m H : ℕ} {Λ : ZMod P → ℝ} {B : ℝ} (hB : ∀ z, |Λ z| ≤ B)
    {α β v : ZMod P} {t : ZMod m} :
    |sawC m H Λ α β v t| ≤ (∑ j ∈ Icc 1 (P * m), |rowF m H Λ α β v t j|) / 2 := by
  unfold sawC
  refine (abs_sum_le_sum_abs _ _).trans ?_
  rw [sum_div]
  apply sum_le_sum
  intro j hj
  rw [mem_Icc] at hj
  rw [abs_mul]
  have hQ : (0 : ℝ) < (P * m : ℕ) := by
    have : 0 < P * m := by omega
    exact_mod_cast this
  have h1 : |1 / 2 - (j : ℝ) / (P * m : ℕ)| ≤ 1 / 2 := by
    have : (j : ℝ) / (P * m : ℕ) ≤ 1 := by
      rw [div_le_one hQ]; exact_mod_cast hj.2
    have : 0 ≤ (j : ℝ) / (P * m : ℕ) := by positivity
    rw [abs_le]; constructor <;> linarith
  nlinarith [abs_nonneg (rowF m H Λ α β v t j)]

lemma abs_sawOsc_le {m H : ℕ} {Λ : ZMod P → ℝ} {α β v : ZMod P} {t : ZMod m} (x : ℝ) :
    |sawOsc m H Λ α β v t x| ≤ (∑ j ∈ Icc 1 (P * m), |rowF m H Λ α β v t j|) / 2 := by
  unfold sawOsc
  refine (abs_sum_le_sum_abs _ _).trans ?_
  rw [sum_div]
  apply sum_le_sum
  intro j _
  rw [abs_mul]
  nlinarith [abs_saw_le ((x - j) / (P * m : ℕ)), abs_nonneg (rowF m H Λ α β v t j)]

/-- **Exact sawtooth identity** (unit residues): the linear drift vanishes. -/
theorem sawtooth_identity {m H : ℕ} (hm : 0 < m) {Λ : ZMod P → ℝ} {B : ℝ}
    (hB : ∀ z, |Λ z| ≤ B) {α β v : ZMod P} {t : ZMod m}
    (hmP : IsUnit (m : ZMod P)) (hβ : IsUnit β) (hv : IsUnit v) (ht : IsUnit t)
    {x : ℝ} (hx : 0 ≤ x) :
    psiR m H Λ α β v t x = sawC m H Λ α β v t - sawOsc m H Λ α β v t x := by
  set κ := (∑ j ∈ Icc 1 (P * m), rowF m H Λ α β v t j) / (P * m : ℕ) - muL Λ / m
  have hκ : κ = 0 := by
    by_contra hne
    set K := (2 * P + 2) * B + ∑ j ∈ Icc 1 (P * m), |rowF m H Λ α β v t j|
    have hK0 : 0 ≤ K := by
      have : 0 ≤ B := le_trans (abs_nonneg _) (hB 0)
      have : 0 ≤ ∑ j ∈ Icc 1 (P * m), |rowF m H Λ α β v t j| :=
        sum_nonneg (fun _ _ => abs_nonneg _)
      positivity
    have hκpos : 0 < |κ| := abs_pos.mpr hne
    set y := (K + 1) / |κ|
    have hy : 0 ≤ y := by positivity
    have hraw := sawtooth_raw hm Λ α β v t hy (H := H)
    have hpsi := oriel_psi_bound hm hB (H := H) (α := α) hmP hβ hv ht hy
    have hc := abs_sawC_le hB (H := H) (α := α) (β := β) (v := v) (t := t)
    have ho := abs_sawOsc_le (H := H) (Λ := Λ) (α := α) (β := β) (v := v) (t := t) y
    have hlin : κ * y = psiR m H Λ α β v t y - sawC m H Λ α β v t + sawOsc m H Λ α β v t y := by
      rw [hraw]; ring
    have h1 : |κ * y| ≤ K := by
      rw [hlin]
      calc |psiR m H Λ α β v t y - sawC m H Λ α β v t + sawOsc m H Λ α β v t y|
          ≤ |psiR m H Λ α β v t y| + |sawC m H Λ α β v t| + |sawOsc m H Λ α β v t y| := by
            refine (abs_add_le _ _).trans ?_
            gcongr
            exact abs_sub _ _
        _ ≤ K := by simp only [K]; linarith
    have h2 : |κ * y| = K + 1 := by
      rw [abs_mul, abs_of_nonneg hy]; simp only [y]; field_simp
    linarith
  rw [sawtooth_raw hm Λ α β v t hx]
  change sawC m H Λ α β v t - sawOsc m H Λ α β v t x + κ * x = _
  rw [hκ, zero_mul, add_zero]

end OrielUpper
