import PaperB.FixedQ.GlobalProperAnalyticBridge
import PaperB.FixedQ.GlobalProperAnalyticTerminal
import PaperB.FixedQ.H2BooleanGlobalSourceSplit

open Filter Real Asymptotics
open scoped BigOperators

namespace PaperB.FixedQ

/-- Number of geometric product blocks in the Boolean range.
It is a fixed multiple of the already-paid source scale
floor((log h)^sigma), hence O((log h)^sigma). -/
noncomputable def globalProperBooleanBlockCount (h : ℕ) : ℕ :=
  20 * (h2BooleanSourceCutoff h + 1)

/-- Dyadic Boolean product cutoff.  This is exp(O((log h)^sigma)),
the same scale as the manuscript's Z = X^2, but normalized to a power
of two so geometric reaggregation is exact. -/
noncomputable def globalProperBooleanProductCutoff (h : ℕ) : ℕ :=
  2 ^ globalProperBooleanBlockCount h

def globalProperSmallSet (h Z : ℕ) : Set (Finset ℕ) :=
  {e | primeSetProduct (e \ heightPrimePart h e) ≤ Z}

noncomputable def globalProperSmallAnalytic
    (q a h Z : ℕ) : ℝ :=
  ∑' e : Finset ℕ,
    (globalProperSmallSet h Z).indicator
      (decoratedAnalyticPerE q a h) e

noncomputable def globalProperExteriorAnalytic
    (q a h Z : ℕ) : ℝ :=
  ∑' e : Finset ℕ,
    (globalProperSmallSet h Z)ᶜ.indicator
      (decoratedAnalyticPerE q a h) e

theorem summable_globalProperSmallAnalyticTerm
    {q a r h Z : ℕ}
    (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h)
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    Summable ((globalProperSmallSet h Z).indicator
      (decoratedAnalyticPerE q a h)) := by
  exact (summable_global_decoratedAnalyticPerE
    (q := q) (a := a) (r := r) hq hh h2 hreflect).indicator _

theorem summable_globalProperExteriorAnalyticTerm
    {q a r h Z : ℕ}
    (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h)
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    Summable ((globalProperSmallSet h Z)ᶜ.indicator
      (decoratedAnalyticPerE q a h)) := by
  exact (summable_global_decoratedAnalyticPerE
    (q := q) (a := a) (r := r) hq hh h2 hreflect).indicator _

theorem globalProperAnalytic_tsum_eq_small_add_exterior
    {q a r h Z : ℕ}
    (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h)
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    (∑' e : Finset ℕ, decoratedAnalyticPerE q a h e) =
      globalProperSmallAnalytic q a h Z +
        globalProperExteriorAnalytic q a h Z := by
  have hs := summable_globalProperSmallAnalyticTerm
    (q := q) (a := a) (r := r) (h := h) (Z := Z)
    hq hh h2 hreflect
  have he := summable_globalProperExteriorAnalyticTerm
    (q := q) (a := a) (r := r) (h := h) (Z := Z)
    hq hh h2 hreflect
  unfold globalProperSmallAnalytic globalProperExteriorAnalytic
  rw [← hs.tsum_add he]
  apply tsum_congr
  intro e
  by_cases hm : e ∈ globalProperSmallSet h Z
  · simp [Set.indicator, hm]
  · simp [Set.indicator, hm]

theorem globalProperAnalytic_eq_small_add_exterior
    {q a r h Z : ℕ}
    (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h)
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    ordinaryBooleanCore q a h +
        decoratedAnalyticRemainder q a h =
      globalProperSmallAnalytic q a h Z +
        globalProperExteriorAnalytic q a h Z := by
  rw [← tsum_decoratedAnalyticPerE_eq_globalProperAnalytic
    hq hh h2 hreflect]
  exact globalProperAnalytic_tsum_eq_small_add_exterior
    hq hh h2 hreflect

def GlobalProperSmallBoxLogPowerSaving (q : ℕ) : Prop :=
  ∃ C rho : ℝ, ∃ k H0 : ℕ,
    0 ≤ C ∧ rho < 1 ∧
      ∀ a h : ℕ,
        q.Coprime a →
        0 < h →
        (¬ 2 ∣ q → 2 ∣ h) →
        H0 ≤ h →
        |globalProperSmallAnalytic q a h
          (globalProperBooleanProductCutoff h)| ≤
          C * (Real.log (h : ℝ)) ^ rho *
            (Real.log (Real.log (h : ℝ))) ^ k

def GlobalProperExteriorSublog (q : ℕ) : Prop :=
  ∀ eps : ℝ, 0 < eps →
    ∃ H0 : ℕ, ∀ a h : ℕ,
      q.Coprime a →
      0 < h →
      (¬ 2 ∣ q → 2 ∣ h) →
      H0 ≤ h →
      |globalProperExteriorAnalytic q a h
        (globalProperBooleanProductCutoff h)| ≤
        eps * Real.log (h : ℝ)

theorem globalProperAnalytic_sublog_of_split
    (q : ℕ) (hq : 0 < q)
    (hSmall : GlobalProperSmallBoxLogPowerSaving q)
    (hExt : GlobalProperExteriorSublog q) :
    ∀ eps : ℝ, 0 < eps →
      ∃ H0 : ℕ, ∀ a b h : ℕ,
        q.Coprime a →
        q.Coprime b →
        Nat.ModEq q (a + h) b →
        (¬ 2 ∣ q → 2 ∣ h) →
        0 < h →
        H0 ≤ h →
        |cStarReal q h *
          (ordinaryBooleanCore q a h +
            decoratedAnalyticRemainder q a h)| ≤
          eps * Real.log (h : ℝ) := by
  intro eps heps
  let delta : ℝ := eps / 2
  have hdelta : 0 < delta := by
    dsimp [delta]
    positivity
  rcases hSmall with ⟨C, rho, k, HS, hC, hrho, hSmallRate⟩
  obtain ⟨HA, hAbsorb⟩ :=
    eventually_const_mul_loglog_pow_mul_log_rpow_le_no_extra
      (C := C) (rho := rho) (k := k) hC hrho delta hdelta
  obtain ⟨HE, hExtRate⟩ := hExt delta hdelta
  refine ⟨max HS (max HA HE), ?_⟩
  intro a b h ha hb hcompat h2 hh hlarge
  have hSh : HS ≤ h :=
    (le_max_left HS (max HA HE)).trans hlarge
  have hAh : HA ≤ h :=
    (le_max_left HA HE).trans
      ((le_max_right HS (max HA HE)).trans hlarge)
  have hEh : HE ≤ h :=
    (le_max_right HA HE).trans
      ((le_max_right HS (max HA HE)).trans hlarge)
  have hsmall0 := hSmallRate a h ha hh h2 hSh
  have hsmall :
      |globalProperSmallAnalytic q a h
        (globalProperBooleanProductCutoff h)| ≤
        delta * Real.log (h : ℝ) := by
    exact hsmall0.trans (by
      have habs := hAbsorb h hAh
      calc
        C * (Real.log (h : ℝ)) ^ rho *
            (Real.log (Real.log (h : ℝ))) ^ k =
          C * (Real.log (Real.log (h : ℝ))) ^ k *
            (Real.log (h : ℝ)) ^ rho := by ring
        _ ≤ delta * Real.log (h : ℝ) := habs)
  have hext := hExtRate a h ha hh h2 hEh
  have hreflect := PaperB.Closure.reflected_coprime_equiv hq hcompat
  have hsplit := globalProperAnalytic_eq_small_add_exterior
    (q := q) (a := a) (r := PaperB.Closure.reflectedResidue q b)
    (h := h) (Z := globalProperBooleanProductCutoff h)
    hq hh h2 hreflect
  rw [hsplit, abs_mul]
  have hc := abs_cStarReal_le_one q h
  calc
    |cStarReal q h| *
        |globalProperSmallAnalytic q a h
            (globalProperBooleanProductCutoff h) +
          globalProperExteriorAnalytic q a h
            (globalProperBooleanProductCutoff h)|
      ≤ 1 *
        (|globalProperSmallAnalytic q a h
            (globalProperBooleanProductCutoff h)| +
          |globalProperExteriorAnalytic q a h
            (globalProperBooleanProductCutoff h)|) := by
          gcongr
          exact abs_add_le _ _
    _ ≤ delta * Real.log (h : ℝ) +
          delta * Real.log (h : ℝ) := by
        simpa using add_le_add hsmall hext
    _ = eps * Real.log (h : ℝ) := by
        dsimp [delta]
        ring

#print axioms globalProperAnalytic_tsum_eq_small_add_exterior
#print axioms globalProperAnalytic_eq_small_add_exterior
#print axioms globalProperAnalytic_sublog_of_split

end PaperB.FixedQ
