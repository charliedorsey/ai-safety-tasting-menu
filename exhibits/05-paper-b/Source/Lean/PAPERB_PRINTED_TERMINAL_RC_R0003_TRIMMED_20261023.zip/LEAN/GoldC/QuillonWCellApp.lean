import GoldC.QuillonWContext
import GoldC.QuillonRowNF
import GoldC.QuillonCells

/-!
# Quillon CSC3 F7.7b: the W′ cell for a fixed `s` (from the source mask to an explicit bound)

For fixed `C` (`s = ∏C`), universe `U = T∖C`, W′ set `J ⊆ U ∩ [X, Y]` and an `r`-mask `Geo`
(convex, `≤ N`, `> Lw ≥ Y`), with the row equal to `rowAbs` on masked `r`:

    |Σ_{B⊆U, B≠∅} 1[Kc(|B|) ∧ Geo(∏B) ∧ B∩J≠∅]·ω(B)·F(∏B)| ≤ WB,

where `WB` is the sum, over the four row types (`rowAbs_eq_rowW`), of the `W_context` bound with
`(I₀, I₁)` replaced by explicit monotone majorants: `Nlow = Lw/Y` and `max N Lw`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonWCellApp

open GoldC.QuillonWContext GoldC.QuillonWBilinear GoldC.QuillonRowNF GoldC.QuillonCells
  GoldC.QuillonVW GoldC.QuillonR

/-- A cell sum over `B ≠ ∅` with a Ramaré condition, rewritten in `Ioc` form. -/
lemma cell_sum_Ioc (U J : Finset ℕ) (Kc : ℕ → Prop) [DecidablePred Kc] (Geo : ℕ → Prop)
    [DecidablePred Geo] (I₀ I₁ : ℕ) (hGeo : ∀ r, Geo r ↔ r ∈ Ioc I₀ I₁) (g : Finset ℕ → ℝ) :
    ∑ B ∈ U.powerset.filter (fun B => B ≠ ∅),
        (if (Kc B.card ∧ Geo (∏ p ∈ B, p)) ∧ (B ∩ J).Nonempty then g B else 0) =
      ∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty),
        (if (∏ p ∈ B, p) ∈ Ioc I₀ I₁ ∧ B.card ∈ (range (U.card + 1)).filter Kc then g B else 0) := by
  classical
  rw [sum_filter, sum_filter]
  refine sum_congr rfl fun B hB => ?_
  have hcard : B.card < U.card + 1 := Nat.lt_succ_of_le (card_le_card (mem_powerset.1 hB))
  by_cases hJ : (B ∩ J).Nonempty
  · have hne : B ≠ ∅ := by
      rintro rfl; simp at hJ
    simp only [hne, hJ, ne_eq, not_false_eq_true, if_true, and_true, mem_filter, mem_range, hcard,
      true_and, hGeo]
    by_cases h1 : Kc B.card <;> by_cases h2 : (∏ p ∈ B, p) ∈ Ioc I₀ I₁ <;> simp [h1, h2]
  · simp [hJ]

section W
variable {s : ℕ} [NeZero s] {M : ℕ} [NeZero M]

/-- The W′ bound for one row type. -/
noncomputable def WTerm (P : Finset ℕ) (U : Finset ℕ) (𝒥 : Finset ℕ) (A : ZMod M → ℕ → ℂ)
    (c : ℕ → ZMod s) (X Y Nb Lw : ℕ) : ℝ :=
  ((Nat.log 2 (max Nb Lw) + 1 : ℕ) : ℝ) * M * ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖A ρ j‖ *
      ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 * (max Nb Lw) ^ 2)) : ℝ) ^ 30) ^ 2 *
        Real.sqrt (2 * WPsi P (c j) X Y (Lw / Y))) +
    (∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖A ρ j‖) * (∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3))) * ((12.5 : ℝ) / X)

lemma WTerm_nonneg (P U 𝒥 : Finset ℕ) (A : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s) (X Y Nb Lw : ℕ)
    (hU : ∀ p ∈ U, 5 ≤ p) : 0 ≤ WTerm P U 𝒥 A c X Y Nb Lw := by
  unfold WTerm
  have h1 : 0 ≤ ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) := prod_nonneg fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast hU p hp
    have : 0 ≤ 1 / ((p : ℝ) - 3) := by apply div_nonneg zero_le_one; linarith
    linarith
  have h2 : 0 ≤ ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖A ρ j‖ * ((Real.exp 37.5 *
      (1 + Nat.log 2 (Nat.log 2 (2 * (max Nb Lw) ^ 2)) : ℝ) ^ 30) ^ 2 *
        Real.sqrt (2 * WPsi P (c j) X Y (Lw / Y))) :=
    sum_nonneg fun _ _ => sum_nonneg fun _ _ => by positivity
  have h3 : 0 ≤ ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖A ρ j‖ := sum_nonneg fun _ _ => sum_nonneg fun _ _ => norm_nonneg _
  positivity

/-- `W_context` with explicit majorants for `(I₀, I₁)`. -/
lemma W_context_explicit (hs2 : 2 ≤ s) (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p)
    (𝒥 : Finset ℕ) (Acoef : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s)
    (U J : Finset ℕ) (hJU : J ⊆ U) (hU : ∀ p ∈ U, p.Prime ∧ 5 ≤ p)
    (hUs : ∀ p ∈ U, Nat.Coprime p s) (hUM : ∀ p ∈ U, Nat.Coprime p M)
    (X Y I₀ I₁ Nb Lw : ℕ) (hX : 2 ≤ X) (hY1 : 1 ≤ Y) (hJ : ∀ p ∈ J, X ≤ p ∧ p ≤ Y)
    (hYL : Y ≤ Lw) (hLI : Lw ≤ I₀) (hI : I₀ < I₁) (hI₁ : I₁ ≤ max Nb Lw) (Kset : Finset ℕ) :
    ‖∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty), (ωR B : ℂ) *
        (if (∏ p ∈ B, p) ∈ Ioc I₀ I₁ ∧ B.card ∈ Kset then rowW 𝒥 Acoef c (∏ p ∈ B, p) else 0)‖ ≤
      WTerm P U 𝒥 Acoef c X Y Nb Lw := by
  refine (W_context hs2 P hP hsP 𝒥 Acoef c U J hJU hU hUs hUM X Y I₀ I₁ hX hY1 hJ
    (hYL.trans hLI) Kset).trans ?_
  unfold WTerm
  have hlog : Nat.log 2 I₁ ≤ Nat.log 2 (max Nb Lw) := Nat.log_mono_right hI₁
  have hN₀ : I₀ / Y ≤ I₁ := (Nat.div_le_self _ _).trans hI.le
  have harg : 2 ^ (Nat.log 2 I₁ + 1) * (I₀ / Y) ≤ 2 * (max Nb Lw) ^ 2 := by
    have h1 : 2 ^ (Nat.log 2 I₁ + 1) ≤ 2 * I₁ := by
      rw [pow_succ, mul_comm]
      exact Nat.mul_le_mul_left 2 (Nat.pow_log_le_self 2 (by omega))
    calc 2 ^ (Nat.log 2 I₁ + 1) * (I₀ / Y) ≤ 2 * I₁ * I₁ := Nat.mul_le_mul h1 hN₀
      _ ≤ 2 * (max Nb Lw) * (max Nb Lw) := Nat.mul_le_mul (Nat.mul_le_mul_left 2 hI₁) hI₁
      _ = 2 * (max Nb Lw) ^ 2 := by ring
  have hAω : (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 ^ (Nat.log 2 I₁ + 1) * (I₀ / Y))) : ℝ) ^ 30) ^ 2
      ≤ (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 * (max Nb Lw) ^ 2)) : ℝ) ^ 30) ^ 2 := by
    have hm : Nat.log 2 (Nat.log 2 (2 ^ (Nat.log 2 I₁ + 1) * (I₀ / Y))) ≤
        Nat.log 2 (Nat.log 2 (2 * (max Nb Lw) ^ 2)) :=
      Nat.log_mono_right (Nat.log_mono_right harg)
    have hm' : (Nat.log 2 (Nat.log 2 (2 ^ (Nat.log 2 I₁ + 1) * (I₀ / Y))) : ℝ) ≤
        Nat.log 2 (Nat.log 2 (2 * (max Nb Lw) ^ 2)) := by exact_mod_cast hm
    gcongr
  have hNlow : 1 ≤ Lw / Y := (Nat.one_le_div_iff (by omega)).2 hYL
  have hdiv : Lw / Y ≤ I₀ / Y := Nat.div_le_div_right hLI
  have hW : ∀ j, WPsi P (c j) X Y (I₀ / Y) ≤ WPsi P (c j) X Y (Lw / Y) :=
    fun j => WPsi_anti P (c j) X Y (Lw / Y) (I₀ / Y) hNlow hdiv
  have hWnn : ∀ j, 0 ≤ WPsi P (c j) X Y (I₀ / Y) := fun j => WPsi_nonneg _ _ _ _ _
  refine add_le_add ?_ le_rfl
  have hlogR : ((Nat.log 2 I₁ + 1 : ℕ) : ℝ) ≤ ((Nat.log 2 (max Nb Lw) + 1 : ℕ) : ℝ) := by
    exact_mod_cast Nat.add_le_add_right hlog 1
  have hS : ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ *
      ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 ^ (Nat.log 2 I₁ + 1) * (I₀ / Y))) : ℝ) ^ 30) ^ 2 *
        Real.sqrt (2 * WPsi P (c j) X Y (I₀ / Y))) ≤
      ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ *
      ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 * (max Nb Lw) ^ 2)) : ℝ) ^ 30) ^ 2 *
        Real.sqrt (2 * WPsi P (c j) X Y (Lw / Y))) := by
    refine sum_le_sum fun ρ _ => sum_le_sum fun j _ => ?_
    apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
    apply mul_le_mul hAω _ (Real.sqrt_nonneg _) (by positivity)
    exact Real.sqrt_le_sqrt (by linarith [hW j])
  have hS0 : 0 ≤ ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ *
      ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 ^ (Nat.log 2 I₁ + 1) * (I₀ / Y))) : ℝ) ^ 30) ^ 2 *
        Real.sqrt (2 * WPsi P (c j) X Y (I₀ / Y))) :=
    sum_nonneg fun _ _ => sum_nonneg fun _ _ => by positivity
  have hM0 : (0 : ℝ) ≤ M := Nat.cast_nonneg _
  calc ((Nat.log 2 I₁ + 1 : ℕ) : ℝ) * M * _ ≤ ((Nat.log 2 (max Nb Lw) + 1 : ℕ) : ℝ) * M * _ :=
        mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hlogR hM0) hS0
    _ ≤ _ := mul_le_mul_of_nonneg_left hS (by positivity)

lemma coprime_prod_primes (B C : Finset ℕ) (hB : ∀ p ∈ B, p.Prime) (hC : ∀ p ∈ C, p.Prime)
    (hd : Disjoint B C) : (∏ p ∈ B, p).Coprime (∏ p ∈ C, p) := by
  refine Nat.Coprime.prod_left fun p hp => Nat.Coprime.prod_right fun q hq => ?_
  refine (Nat.coprime_primes (hB p hp) (hC q hq)).2 ?_
  rintro rfl; exact (disjoint_left.1 hd hp) hq

/-- **The W′ cell for a fixed `s`.** -/
theorem W_cell (hM : 2 ≤ M) (H : ℕ) (μ : ℝ) (Γ : ℕ → ℕ → ℝ) (T C : Finset ℕ)
    (hT : ∀ p ∈ T, p.Prime ∧ 5 ≤ p ∧ p.Coprime M ∧ p.Coprime H) (hCT : C ⊆ T)
    (hsC : s = ∏ p ∈ C, p) (hs2 : 2 ≤ s)
    (J : Finset ℕ) (hJU : J ⊆ T \ C) (X Y : ℕ) (hX : 2 ≤ X) (hY1 : 1 ≤ Y)
    (hJ : ∀ p ∈ J, X ≤ p ∧ p ≤ Y)
    (Kc : ℕ → Prop) [DecidablePred Kc] (Geo : ℕ → Prop) [DecidablePred Geo] (Nb Lw : ℕ)
    (hbdd : ∀ r, Geo r → r ≤ Nb) (hlow : ∀ r, Geo r → Lw < r) (hYL : Y ≤ Lw)
    (hconv : ∀ a b c, a ≤ b → b ≤ c → Geo a → Geo c → Geo b)
    (F : ℕ → ℝ) (hF : ∀ B ⊆ T \ C, B ≠ ∅ → Geo (∏ p ∈ B, p) → F (∏ p ∈ B, p) = rowAbs M H μ Γ (∏ p ∈ B, p) s)
    (Jm : ℕ) (hJm : M * s ≤ 2 * Jm) :
    |∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
        (if (Kc B.card ∧ Geo (∏ p ∈ B, p)) ∧ (B ∩ J).Nonempty then ωR B * F (∏ p ∈ B, p) else 0)| ≤
      WTerm C (T \ C) (Icc 1 Jm) (fun (_ : ZMod M) k => ((-(2 * μ) : ℝ) : ℂ) * αm k s)
          (fun k => ((((k : ℤ) * H : ℤ)) : ZMod s)) X Y Nb Lw +
        WTerm C (T \ C) (Icc 1 Jm) (fun (_ : ZMod M) k => -(((-(2 * μ) : ℝ) : ℂ) * αm k s))
          (fun k => ((((-(k : ℤ)) * H : ℤ)) : ZMod s)) X Y Nb Lw +
        WTerm C (T \ C) (Icc 1 Jm) (fun (ρ : ZMod M) k => αm k (M * s) * BclS M Γ s (k : ℤ) ρ)
          (fun k => ((((k : ℤ) * H * GoldC.QuillonCopyC.invMod M s : ℤ)) : ZMod s)) X Y Nb Lw +
        WTerm C (T \ C) (Icc 1 Jm) (fun (ρ : ZMod M) k => -(αm k (M * s) * BclS M Γ s (-(k : ℤ)) ρ))
          (fun k => ((((-(k : ℤ)) * H * GoldC.QuillonCopyC.invMod M s : ℤ)) : ZMod s)) X Y Nb Lw := by
  classical
  set U := T \ C with hUdef
  have hU5 : ∀ p ∈ U, 5 ≤ p := fun p hp => (hT p (sdiff_subset hp)).2.1
  have hRHS0 : 0 ≤ WTerm C U (Icc 1 Jm) (fun (_ : ZMod M) k => ((-(2 * μ) : ℝ) : ℂ) * αm k s)
          (fun k => ((((k : ℤ) * H : ℤ)) : ZMod s)) X Y Nb Lw +
        WTerm C U (Icc 1 Jm) (fun (_ : ZMod M) k => -(((-(2 * μ) : ℝ) : ℂ) * αm k s))
          (fun k => ((((-(k : ℤ)) * H : ℤ)) : ZMod s)) X Y Nb Lw +
        WTerm C U (Icc 1 Jm) (fun (ρ : ZMod M) k => αm k (M * s) * BclS M Γ s (k : ℤ) ρ)
          (fun k => ((((k : ℤ) * H * GoldC.QuillonCopyC.invMod M s : ℤ)) : ZMod s)) X Y Nb Lw +
        WTerm C U (Icc 1 Jm) (fun (ρ : ZMod M) k => -(αm k (M * s) * BclS M Γ s (-(k : ℤ)) ρ))
          (fun k => ((((-(k : ℤ)) * H * GoldC.QuillonCopyC.invMod M s : ℤ)) : ZMod s)) X Y Nb Lw := by
    have := WTerm_nonneg (s := s) (M := M) C U (Icc 1 Jm); 
    linarith [WTerm_nonneg (s := s) (M := M) C U (Icc 1 Jm)
        (fun (_ : ZMod M) k => ((-(2 * μ) : ℝ) : ℂ) * αm k s)
          (fun k => ((((k : ℤ) * H : ℤ)) : ZMod s)) X Y Nb Lw hU5,
      WTerm_nonneg (s := s) (M := M) C U (Icc 1 Jm)
        (fun (_ : ZMod M) k => -(((-(2 * μ) : ℝ) : ℂ) * αm k s))
          (fun k => ((((-(k : ℤ)) * H : ℤ)) : ZMod s)) X Y Nb Lw hU5,
      WTerm_nonneg (s := s) (M := M) C U (Icc 1 Jm)
        (fun (ρ : ZMod M) k => αm k (M * s) * BclS M Γ s (k : ℤ) ρ)
          (fun k => ((((k : ℤ) * H * GoldC.QuillonCopyC.invMod M s : ℤ)) : ZMod s)) X Y Nb Lw hU5,
      WTerm_nonneg (s := s) (M := M) C U (Icc 1 Jm)
        (fun (ρ : ZMod M) k => -(αm k (M * s) * BclS M Γ s (-(k : ℤ)) ρ))
          (fun k => ((((-(k : ℤ)) * H * GoldC.QuillonCopyC.invMod M s : ℤ)) : ZMod s)) X Y Nb Lw hU5]
  obtain ⟨I₀, I₁, hLI, hI₁, hGeo⟩ := exists_Ioc_of_convex Geo Nb Lw hbdd hlow hconv
  rw [cell_sum_Ioc U J Kc Geo I₀ I₁ hGeo (fun B => ωR B * F (∏ p ∈ B, p))]
  rcases le_or_gt I₁ I₀ with hI | hI
  · rw [sum_eq_zero fun B _ => by
      rw [if_neg]; rintro ⟨h1, _⟩; have := mem_Ioc.1 h1; omega]
    rw [abs_zero]; exact hRHS0
  -- coprimality facts
  have hTp : ∀ p ∈ T, p.Prime := fun p hp => (hT p hp).1
  have hsM : s.Coprime M := by
    rw [hsC]; exact Nat.Coprime.prod_left fun q hq => (hT q (hCT hq)).2.2.1
  have hHs : H.Coprime s := by
    rw [hsC]; exact Nat.Coprime.prod_right fun q hq => ((hT q (hCT hq)).2.2.2).symm
  have hUs : ∀ p ∈ U, Nat.Coprime p s := by
    intro p hp
    have hpT := sdiff_subset hp
    have hpC : p ∉ C := (mem_sdiff.1 hp).2
    have := coprime_prod_primes {p} C (by simpa using (hT p hpT).1)
      (fun q hq => hTp q (hCT hq)) (by simpa using hpC)
    simpa [hsC] using this
  have hUM : ∀ p ∈ U, Nat.Coprime p M := fun p hp => (hT p (sdiff_subset hp)).2.2.1
  have hUP : ∀ p ∈ U, p.Prime ∧ 5 ≤ p := fun p hp => ⟨(hT p (sdiff_subset hp)).1, hU5 p hp⟩
  have hCp : ∀ p ∈ C, p.Prime := fun p hp => hTp p (hCT hp)
  -- pass to ℂ and expand the row
  set Rτ : (ZMod M → ℕ → ℂ) → (ℕ → ZMod s) → ℂ := fun A c =>
    ∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty), (ωR B : ℂ) *
      (if (∏ p ∈ B, p) ∈ Ioc I₀ I₁ ∧ B.card ∈ (range (U.card + 1)).filter Kc then
        rowW (Icc 1 Jm) A c (∏ p ∈ B, p) else 0) with hRτ
  have hexp : ((∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty),
      (if (∏ p ∈ B, p) ∈ Ioc I₀ I₁ ∧ B.card ∈ (range (U.card + 1)).filter Kc then
        ωR B * F (∏ p ∈ B, p) else 0) : ℝ) : ℂ) =
      Rτ (fun (_ : ZMod M) k => ((-(2 * μ) : ℝ) : ℂ) * αm k s)
          (fun k => ((((k : ℤ) * H : ℤ)) : ZMod s)) +
        Rτ (fun (_ : ZMod M) k => -(((-(2 * μ) : ℝ) : ℂ) * αm k s))
          (fun k => ((((-(k : ℤ)) * H : ℤ)) : ZMod s)) +
        Rτ (fun (ρ : ZMod M) k => αm k (M * s) * BclS M Γ s (k : ℤ) ρ)
          (fun k => ((((k : ℤ) * H * GoldC.QuillonCopyC.invMod M s : ℤ)) : ZMod s)) +
        Rτ (fun (ρ : ZMod M) k => -(αm k (M * s) * BclS M Γ s (-(k : ℤ)) ρ))
          (fun k => ((((-(k : ℤ)) * H * GoldC.QuillonCopyC.invMod M s : ℤ)) : ZMod s)) := by
    simp only [hRτ, ← sum_add_distrib]
    rw [Complex.ofReal_sum]
    refine sum_congr rfl fun B hB => ?_
    have hBU := mem_powerset.1 (mem_filter.1 hB).1
    have hBne : B ≠ ∅ := by
      rintro rfl; have := (mem_filter.1 hB).2; simp at this
    by_cases hmB : (∏ p ∈ B, p) ∈ Ioc I₀ I₁ ∧ B.card ∈ (range (U.card + 1)).filter Kc
    · simp only [if_pos hmB]
      have hgeo : Geo (∏ p ∈ B, p) := (hGeo _).2 hmB.1
      have hrs : (∏ p ∈ B, p).Coprime s := by
        rw [hsC]; exact coprime_prod_primes B C (fun p hp => hTp p (sdiff_subset (hBU hp))) hCp
          (by rw [disjoint_left]; intro p hp hpC; exact (mem_sdiff.1 (hBU hp)).2 hpC)
      rw [Complex.ofReal_mul, hF B hBU hBne hgeo, rowAbs_eq_rowW hM hs2 H μ Γ _ hrs hsM hHs Jm hJm]
      ring
    · simp only [if_neg hmB, Complex.ofReal_zero]; ring
  rw [← Real.norm_eq_abs, ← Complex.norm_real, hexp]
  refine (norm_add_le _ _).trans (add_le_add ((norm_add_le _ _).trans (add_le_add
    ((norm_add_le _ _).trans (add_le_add ?_ ?_)) ?_)) ?_) <;>
  exact W_context_explicit hs2 C hCp hsC (Icc 1 Jm) _ _ U J hJU hUP hUs hUM X Y I₀ I₁ Nb Lw hX hY1 hJ
    hYL hLI hI hI₁ _

end W

end GoldC.QuillonWCellApp

#print axioms GoldC.QuillonWCellApp.cell_sum_Ioc
#print axioms GoldC.QuillonWCellApp.W_context_explicit
#print axioms GoldC.QuillonWCellApp.W_cell
