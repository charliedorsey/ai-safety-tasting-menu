import GeneralKloosterman.PrimePowerLocal

/-!
# Unit coefficients modulo `p ^ k`: square-root cancellation

* `Sep p e` — "twice a unit is nonzero modulo `p^(e+1)`"; `sep_of_ne_two` (`e` arbitrary, `p` odd),
  `sep_two` (`p = 2`, `e = 1`).
* `sq_eq_sq_split` — if `y² = y0²` in `ZMod (p^n)` with `y0` a unit, then `y ≡ ±y0 (mod p^(n-e))`.
* `card_sqClass_le` — a set of residues mod `p^k` whose reductions mod `p^m` all square to the same
  unit has at most `2 p^(k-(m-e))` elements.
* `norm_kSum_unit_le_count` — `k ≥ 2`, `a, b` units: `‖S(a,b;p^k)‖ ≤ 2 p^(k-(⌊k/2⌋-e))`.
* **`norm_kSum_unit_odd_le`** — `p` odd, `k ≥ 2`, `a, b` units: `‖S(a,b;p^k)‖ ≤ 2 √(p^k)`.
-/

open Finset ComplexConjugate

namespace GenKloosterman

local notation "ψ" => ZMod.stdAddChar

variable {p : ℕ} [hp : Fact p.Prime]

/-- Twice a unit is nonzero modulo `p ^ (e + 1)`. -/
def Sep (p e : ℕ) : Prop := ∀ y z : ZMod (p ^ (e + 1)), y * z = 1 → 2 * y ≠ 0

omit hp in
theorem sep_of_ne_two (hp' : p.Prime) (hp2 : p ≠ 2) (e : ℕ) : Sep p e := by
  intro y z hyz h2
  have h20 : (2 : ZMod (p ^ (e + 1))) = 0 := by
    have : (2 : ZMod (p ^ (e + 1))) * (y * z) = 0 := by rw [← mul_assoc, h2, zero_mul]
    rwa [hyz, mul_one] at this
  have : p ^ (e + 1) ∣ 2 := by
    rw [← ZMod.natCast_eq_zero_iff]; exact_mod_cast h20
  have hp2' : p ∣ 2 := (dvd_pow_self p (by omega)).trans this
  have := Nat.le_of_dvd two_pos hp2'
  have := hp'.two_le
  omega

theorem sep_two : Sep 2 1 := by
  unfold Sep; decide

/-- Square roots modulo `p ^ n` split into two classes modulo `p ^ (n - e)`. -/
theorem sq_eq_sq_split {n e : ℕ} (hsep : Sep p e) (y y0 : ZMod (p ^ n)) (hy0 : IsUnit y0)
    (hsq : y ^ 2 = y0 ^ 2) :
    p ^ (n - e) ∣ (y - y0).val ∨ p ^ (n - e) ∣ (y + y0).val := by
  have hAB : (y - y0) * (y + y0) = 0 := by linear_combination hsq
  have hdvd : p ^ n ∣ (y - y0).val * (y + y0).val := by
    rw [← ZMod.natCast_eq_zero_iff]; push_cast
    rw [ZMod.natCast_zmod_val, ZMod.natCast_zmod_val]; exact hAB
  obtain ⟨k1, k2, h1, h2, hk⟩ := dvd_mul.1 hdvd
  have hk1 : k1 ∣ p ^ n := ⟨k2, hk⟩
  have hk2 : k2 ∣ p ^ n := ⟨k1, by rw [hk, mul_comm]⟩
  obtain ⟨i, hi, rfl⟩ := (Nat.dvd_prime_pow hp.out).1 hk1
  obtain ⟨l, hl, rfl⟩ := (Nat.dvd_prime_pow hp.out).1 hk2
  have hil : n = i + l := by
    rw [← pow_add] at hk; exact Nat.pow_right_injective hp.out.two_le hk
  by_cases hA : n - e ≤ i
  · exact Or.inl ((pow_dvd_pow p hA).trans h1)
  by_cases hB : n - e ≤ l
  · exact Or.inr ((pow_dvd_pow p hB).trans h2)
  exfalso
  have hei : e + 1 ≤ n := by omega
  have hA' : p ^ (e + 1) ∣ (y - y0).val := (pow_dvd_pow p (by omega)).trans h1
  have hB' : p ^ (e + 1) ∣ (y + y0).val := (pow_dvd_pow p (by omega)).trans h2
  rw [← red_eq_zero_iff hei] at hA' hB'
  have hy : IsUnit y := by
    have : IsUnit (y ^ 2) := hsq ▸ hy0.pow 2
    exact (isUnit_pow_iff two_ne_zero).1 this
  obtain ⟨u, rfl⟩ := hy
  apply hsep (red (e + 1) hei (u : ZMod (p ^ n))) (red (e + 1) hei ((u⁻¹ : (ZMod (p ^ n))ˣ) : ZMod (p ^ n)))
    (by rw [← map_mul, Units.mul_inv, map_one])
  calc 2 * red (e + 1) hei (u : ZMod (p ^ n))
      = red (e + 1) hei ((u : ZMod (p ^ n)) - y0) + red (e + 1) hei ((u : ZMod (p ^ n)) + y0) := by
        rw [← map_add, show (u : ZMod (p ^ n)) - y0 + ((u : ZMod (p ^ n)) + y0) =
          2 * (u : ZMod (p ^ n)) by ring, map_mul, map_ofNat]
    _ = 0 := by rw [hA', hB', add_zero]

theorem red_dvd_val_iff {k m n : ℕ} (hm : m ≤ k) (hn : n ≤ m) (z : ZMod (p ^ k)) :
    p ^ n ∣ (red m hm z).val ↔ p ^ n ∣ z.val := by
  rw [val_red]
  exact (Nat.dvd_mod_iff (pow_dvd_pow p hn))

/-- Counting residues with a prescribed unit square modulo `p ^ m`. -/
theorem card_sqClass_le {k m e : ℕ} (hm : m ≤ k) (hsep : Sep p e)
    (c : ZMod (p ^ m)) (hc : IsUnit c) (T : Finset (ZMod (p ^ k)))
    (hT : ∀ x ∈ T, red m hm x ^ 2 = c) :
    #T ≤ 2 * p ^ (k - (m - e)) := by
  classical
  rcases T.eq_empty_or_nonempty with hT0 | ⟨x0, hx0⟩
  · simp [hT0]
  have hn : m - e ≤ k := by omega
  have hn' : m - e ≤ m := by omega
  let T1 : Finset (ZMod (p ^ k)) := {x | red (m - e) hn x = red (m - e) hn x0}
  let T2 : Finset (ZMod (p ^ k)) := {x | red (m - e) hn x = red (m - e) hn (-x0)}
  have hsub : T ⊆ T1 ∪ T2 := by
    intro x hx
    have hsq : red m hm x ^ 2 = red m hm x0 ^ 2 := by rw [hT x hx, hT x0 hx0]
    have hu : IsUnit (red m hm x0) := by
      have : IsUnit (red m hm x0 ^ 2) := by rw [hT x0 hx0]; exact hc
      exact (isUnit_pow_iff two_ne_zero).1 this
    rcases sq_eq_sq_split hsep _ _ hu hsq with h | h
    · rw [← map_sub, red_dvd_val_iff hm hn', ← red_eq_zero_iff hn, map_sub, sub_eq_zero] at h
      exact mem_union_left _ (mem_filter.2 ⟨mem_univ _, h⟩)
    · rw [← map_add, red_dvd_val_iff hm hn', ← red_eq_zero_iff hn, map_add,
        add_eq_zero_iff_eq_neg, ← map_neg] at h
      exact mem_union_right _ (mem_filter.2 ⟨mem_univ _, h⟩)
  have hc1 : #T1 = p ^ (k - (m - e)) := by
    rw [card_fiber_castHom, Nat.pow_div hn hp.out.pos]
  have hc2 : #T2 = p ^ (k - (m - e)) := by
    rw [card_fiber_castHom, Nat.pow_div hn hp.out.pos]
  calc #T ≤ #(T1 ∪ T2) := card_le_card hsub
    _ ≤ #T1 + #T2 := card_union_le _ _
    _ = 2 * p ^ (k - (m - e)) := by rw [hc1, hc2]; ring

/-- The stationary set: `p ^ (k - m) · (b x - a x⁻¹) = 0`. -/
def StatSet (k m : ℕ) (a b : ZMod (p ^ k)) (x : (ZMod (p ^ k))ˣ) : Prop :=
  (p : ZMod (p ^ k)) ^ (k - m) * (b * (x : ZMod (p ^ k)) - a * ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k))) = 0

instance (k m : ℕ) (a b : ZMod (p ^ k)) : DecidablePred (StatSet (p := p) k m a b) :=
  fun _ => by unfold StatSet; infer_instance

theorem card_statSet_le {k m e : ℕ} (hm : m ≤ k) (hsep : Sep p e) (a b : ZMod (p ^ k))
    (ha : IsUnit a) (hb : IsUnit b) :
    #{x : (ZMod (p ^ k))ˣ | StatSet k m a b x} ≤ 2 * p ^ (k - (m - e)) := by
  classical
  obtain ⟨bu, rfl⟩ := hb
  let T : Finset (ZMod (p ^ k)) := ({x : (ZMod (p ^ k))ˣ | StatSet k m a bu x} :
    Finset (ZMod (p ^ k))ˣ).map ⟨Units.val, Units.val_injective⟩
  have hcard : #T = #{x : (ZMod (p ^ k))ˣ | StatSet k m a bu x} := card_map _
  rw [← hcard]
  refine card_sqClass_le hm hsep (red m hm (a * ((bu⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k))))
    ((ha.mul (bu⁻¹).isUnit).map _) T ?_
  intro y hy
  simp only [T, mem_map, mem_filter, mem_univ, true_and, Function.Embedding.coeFn_mk] at hy
  obtain ⟨x, hx, rfl⟩ := hy
  unfold StatSet at hx
  rw [pow_mul_eq_zero_iff (by omega), show k - (k - m) = m by omega, ← red_eq_zero_iff hm] at hx
  have hxx : (x : ZMod (p ^ k)) * ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k)) = 1 := by simp
  have hbb : (bu : ZMod (p ^ k)) * ((bu⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k)) = 1 := by simp
  have key : (x : ZMod (p ^ k)) ^ 2 - a * ((bu⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k)) =
      (bu * (x : ZMod (p ^ k)) - a * ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k))) *
        ((x : ZMod (p ^ k)) * ((bu⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k))) := by
    linear_combination (-(x : ZMod (p ^ k)) ^ 2) * hbb +
      a * ((bu⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k)) * hxx
  have := congrArg (red m hm) key
  rw [map_mul, hx, zero_mul, map_sub, sub_eq_zero, map_pow] at this
  exact this

theorem norm_sum_ite_le {ι : Type*} [Fintype ι] (P : ι → Prop) [DecidablePred P] (g : ι → ℂ)
    (hg : ∀ i, ‖g i‖ = 1) :
    ‖∑ i, if P i then g i else 0‖ ≤ #{i | P i} := by
  refine (norm_sum_le _ _).trans ?_
  rw [card_filter, Nat.cast_sum]
  refine sum_le_sum fun i _ => ?_
  split_ifs <;> simp [hg]

/-- **Unit coefficients, `k ≥ 2`: stationary-phase count bound.** -/
theorem norm_kSum_unit_le_count {k e : ℕ} (hk : 2 ≤ k) (hsep : Sep p e)
    (a b : ZMod (p ^ k)) (ha : IsUnit a) (hb : IsUnit b) :
    ‖kSum (p ^ k) a b‖ ≤ 2 * p ^ (k - (k / 2 - e)) := by
  classical
  have hh : ((p : ZMod (p ^ k)) ^ (k - k / 2)) ^ 2 = 0 := by
    rw [← pow_mul]; exact pow_eq_zero_of_le (by omega)
  rw [kSum_eq_sum_stationary _ hh]
  refine (norm_sum_ite_le (StatSet k (k / 2) a b) _ (fun _ => norm_stdAddChar _)).trans ?_
  have := card_statSet_le (k := k) (m := k / 2) (by omega) hsep a b ha hb
  exact_mod_cast this

/-! ### Odd `p`: Weyl differencing for odd exponents -/

theorem sqrt_pow_two_mul (x : ℝ) (hx : 0 ≤ x) (n : ℕ) : Real.sqrt (x ^ (2 * n)) = x ^ n := by
  rw [pow_mul', Real.sqrt_sq (pow_nonneg hx n)]

theorem sqrt_pow_two_mul_add_one (x : ℝ) (hx : 0 ≤ x) (n : ℕ) :
    Real.sqrt (x ^ (2 * n + 1)) = x ^ n * Real.sqrt x := by
  rw [pow_succ, Real.sqrt_mul (pow_nonneg hx _), sqrt_pow_two_mul x hx]

theorem isUnit_two_of_ne_two (hp2 : p ≠ 2) (k : ℕ) : IsUnit (2 : ZMod (p ^ k)) := by
  have : ((2 : ℕ) : ZMod (p ^ k)) = 2 := by norm_cast
  rw [← this, ZMod.isUnit_iff_coprime]
  apply Nat.Coprime.pow_right
  exact (Nat.coprime_primes Nat.prime_two hp.out).2 (Ne.symm hp2)

theorem card_twoMul_eq_zero (hp2 : p ≠ 2) {k m : ℕ} (hkm : k = 2 * m + 1) (v : ZMod (p ^ k))
    (hv : IsUnit v) :
    #{u : ZMod (p ^ k) | 2 * (((p : ZMod (p ^ k)) ^ m) ^ 2 * v) * u = 0} = p ^ (2 * m) := by
  classical
  obtain ⟨w, hw⟩ := (isUnit_two_of_ne_two hp2 k).mul hv
  have hk1 : 1 ≤ k := by omega
  have hset : (univ.filter fun u : ZMod (p ^ k) =>
      2 * (((p : ZMod (p ^ k)) ^ m) ^ 2 * v) * u = 0) =
      (univ.filter fun u : ZMod (p ^ k) => red (k := k) 1 hk1 u = red (k := k) 1 hk1 0) := by
    ext u
    simp only [mem_filter, mem_univ, true_and, map_zero]
    have key : red (k := k) 1 hk1 u = 0 ↔ (p : ZMod (p ^ k)) ^ (2 * m) * u = 0 := by
      rw [red_eq_zero_iff, pow_mul_eq_zero_iff (by omega), show k - 2 * m = 1 by omega]
    rw [key, ← pow_mul, mul_comm m 2]
    constructor
    · intro h
      have hw' : ((w⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k)) * (2 * v) = 1 := by
        rw [← hw]; simp
      linear_combination ((w⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k)) * h -
        ((p : ZMod (p ^ k)) ^ (2 * m) * u) * hw'
    · intro h
      linear_combination 2 * v * h
  rw [hset, card_fiber_castHom, Nat.pow_div hk1 hp.out.pos]
  congr 1; omega

/-- Odd `p`, odd exponent `k = 2m + 1 ≥ 3`. -/
theorem norm_kSum_unit_odd_exp (hp2 : p ≠ 2) {k m : ℕ} (hkm : k = 2 * m + 1) (hm1 : 1 ≤ m)
    (a b : ZMod (p ^ k)) (ha : IsUnit a) (hb : IsUnit b) :
    ‖kSum (p ^ k) a b‖ ≤ 2 * Real.sqrt ((p : ℝ) ^ k) := by
  classical
  have hsep := sep_of_ne_two hp.out hp2 0
  have hp0 : (0 : ℝ) ≤ p := Nat.cast_nonneg p
  let h1 : ZMod (p ^ k) := (p : ZMod (p ^ k)) ^ (k - m)
  let h : ZMod (p ^ k) := (p : ZMod (p ^ k)) ^ m
  have hh1 : h1 ^ 2 = 0 := by
    simp only [h1]; rw [← pow_mul]; exact pow_eq_zero_of_le (by omega)
  have hh : h ^ 3 = 0 := by
    simp only [h]; rw [← pow_mul]; exact pow_eq_zero_of_le (by omega)
  have hh1h : h1 * h = 0 := by
    simp only [h1, h]; rw [← pow_add]; exact pow_eq_zero_of_le (by omega)
  let P : (ZMod (p ^ k))ˣ → Prop := fun x =>
    h1 * (b * (x : ZMod (p ^ k)) - a * ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k))) = 0
  let w : (ZMod (p ^ k))ˣ → ℂ := fun x => if P x then 1 else 0
  have hS : kSum (p ^ k) a b = ∑ x : (ZMod (p ^ k))ˣ,
      w x * ψ (b * (x : ZMod (p ^ k)) + a * ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k))) := by
    rw [kSum_eq_sum_stationary h1 hh1]
    refine sum_congr rfl fun x _ => ?_
    simp only [w, P]; split_ifs <;> simp
  have hw : ∀ t x, w (x * shiftUnit h hh t) = w x := by
    intro t x
    have : P (x * shiftUnit h hh t) ↔ P x := by
      simp only [P, Units.val_mul, mul_inv_rev, shiftUnit]
      change h1 * (b * (x * (1 + h * t)) - a * ((1 - h * t + h ^ 2 * t ^ 2) *
          ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k)))) = 0 ↔ _
      have e : h1 * (b * (x * (1 + h * t)) - a * ((1 - h * t + h ^ 2 * t ^ 2) *
          ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k)))) =
          h1 * (b * (x : ZMod (p ^ k)) - a * ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k))) := by
        linear_combination (t * (b * (x : ZMod (p ^ k)) + a * ((x⁻¹ : (ZMod (p ^ k))ˣ) :
          ZMod (p ^ k))) - h * t ^ 2 * a * ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k))) * hh1h
      rw [e]
    simp only [w]; exact if_congr this rfl rfl
  have havg := averaging_identity h hh a b w hw
  rw [← hS] at havg
  have hK : ∀ x : (ZMod (p ^ k))ˣ,
      ‖quadSum (h * (b * (x : ZMod (p ^ k)) - a * ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k))))
        (h ^ 2 * (a * ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k))))‖ ≤
      Real.sqrt ((p : ℝ) ^ k * (p : ℝ) ^ (2 * m)) := by
    intro x
    refine (norm_quadSum_le _ _).trans ?_
    have hc : #{u : ZMod (p ^ k) | 2 * (h ^ 2 * (a * ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k)))) *
        u = 0} = p ^ (2 * m) :=
      card_twoMul_eq_zero hp2 hkm (a * ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k)))
        (ha.mul (x⁻¹).isUnit)
    rw [hc]; push_cast; exact le_rfl
  have hcount := card_statSet_le (k := k) (m := m) (by omega) hsep a b ha hb
  rw [show k - (m - 0) = m + 1 by omega] at hcount
  have hPset : (#(univ.filter P) : ℝ) ≤ 2 * (p : ℝ) ^ (m + 1) := by
    have : univ.filter P = univ.filter (StatSet k m a b) := by
      ext x; simp only [mem_filter, mem_univ, true_and, P, StatSet, h1]
    rw [this]; exact_mod_cast hcount
  have hNS : (p : ℝ) ^ k * ‖kSum (p ^ k) a b‖ ≤
      2 * (p : ℝ) ^ (m + 1) * Real.sqrt ((p : ℝ) ^ k * (p : ℝ) ^ (2 * m)) := by
    have e1 : (p : ℝ) ^ k * ‖kSum (p ^ k) a b‖ = ‖((p ^ k : ℕ) : ℂ) * kSum (p ^ k) a b‖ := by
      rw [norm_mul, Complex.norm_natCast]; push_cast; ring
    rw [e1, havg]
    calc ‖∑ x : (ZMod (p ^ k))ˣ, w x * ψ (b * (x : ZMod (p ^ k)) +
            a * ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k))) *
          quadSum (h * (b * (x : ZMod (p ^ k)) - a * ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k))))
            (h ^ 2 * (a * ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k))))‖
        ≤ ∑ x : (ZMod (p ^ k))ˣ, (if P x then (1 : ℝ) else 0) *
            Real.sqrt ((p : ℝ) ^ k * (p : ℝ) ^ (2 * m)) := by
          refine (norm_sum_le _ _).trans (sum_le_sum fun x _ => ?_)
          rw [norm_mul, norm_mul, norm_stdAddChar, mul_one]
          simp only [w]
          split_ifs
          · simpa using hK x
          · simp
      _ = (#(univ.filter P) : ℝ) * Real.sqrt ((p : ℝ) ^ k * (p : ℝ) ^ (2 * m)) := by
          rw [← sum_mul]; congr 1; rw [card_filter]; push_cast; rfl
      _ ≤ 2 * (p : ℝ) ^ (m + 1) * Real.sqrt ((p : ℝ) ^ k * (p : ℝ) ^ (2 * m)) := by
          gcongr
  have hsq1 : Real.sqrt ((p : ℝ) ^ k * (p : ℝ) ^ (2 * m)) = (p : ℝ) ^ (2 * m) * Real.sqrt p := by
    rw [← pow_add, show k + 2 * m = 2 * (2 * m) + 1 by omega, sqrt_pow_two_mul_add_one _ hp0]
  have hsq2 : Real.sqrt ((p : ℝ) ^ k) = (p : ℝ) ^ m * Real.sqrt p := by
    rw [hkm]; exact sqrt_pow_two_mul_add_one _ hp0 m
  rw [hsq1] at hNS
  rw [hsq2]
  have hpk : (0 : ℝ) < (p : ℝ) ^ k := pow_pos (by exact_mod_cast hp.out.pos) k
  have : (p : ℝ) ^ k * ‖kSum (p ^ k) a b‖ ≤ (p : ℝ) ^ k * (2 * ((p : ℝ) ^ m * Real.sqrt p)) := by
    refine hNS.trans (le_of_eq ?_)
    rw [hkm]; ring
  exact le_of_mul_le_mul_left this hpk

/-- **Odd `p`, unit coefficients, `k ≥ 2`: `‖S(a,b;p^k)‖ ≤ 2 √(p^k)`.** -/
theorem norm_kSum_unit_odd_le (hp2 : p ≠ 2) {k : ℕ} (hk : 2 ≤ k)
    (a b : ZMod (p ^ k)) (ha : IsUnit a) (hb : IsUnit b) :
    ‖kSum (p ^ k) a b‖ ≤ 2 * Real.sqrt ((p : ℝ) ^ k) := by
  have hsep := sep_of_ne_two hp.out hp2 0
  have hp0 : (0 : ℝ) ≤ p := Nat.cast_nonneg p
  obtain ⟨m, hm⟩ := Nat.even_or_odd' k
  rcases hm with hm | hm
  · subst hm
    have h := norm_kSum_unit_le_count hk hsep a b ha hb
    rw [show 2 * m - (2 * m / 2 - 0) = m by omega] at h
    rw [sqrt_pow_two_mul _ hp0]
    exact_mod_cast h
  · exact norm_kSum_unit_odd_exp hp2 hm (by omega) a b ha hb

end GenKloosterman
