import OrielUpper.AsympA

/-!
# Oriel Upper — asymptotics of the shell budget, shell count and far tail
-/

open Finset

namespace OrielUpper

lemma vkM_eq (h : ℕ) : vkM h = Real.exp (tH h) := rfl

lemma Dh_eq (h : ℕ) : Dh h = Real.exp (40 * tH h) := rfl

lemma Dh_rpow (h : ℕ) : Dh h ^ (-(1 / 4 : ℝ)) = Real.exp (-(10 * tH h)) := by
  rw [Dh_eq, ← Real.exp_mul]; ring_nf

/-- `6^{1/4} ≤ 8/5`. -/
lemma six_rpow_le : (6 : ℝ) ^ (1 / 4 : ℝ) ≤ 8 / 5 := by
  have h : (6 : ℝ) ≤ (8 / 5) ^ (4 : ℝ) := by norm_num
  calc (6 : ℝ) ^ (1 / 4 : ℝ) ≤ ((8 / 5) ^ (4 : ℝ)) ^ (1 / 4 : ℝ) :=
        Real.rpow_le_rpow (by norm_num) h (by norm_num)
    _ = 8 / 5 := by rw [← Real.rpow_mul (by norm_num)]; norm_num

noncomputable def k34 (q : ℕ) : ℝ :=
  4 * Real.exp (10 * Z32) * Real.exp (5 * (2 * Real.log (q : ℝ)) ^ (1 / 4 : ℝ))

lemma envA34_D_le {q h : ℕ} (hq : 1 ≤ q) (hh : 1 ≤ h) :
    envA34 (q * h ^ 3) * Dh h ^ (-(1 / 4 : ℝ)) ≤ k34 q * Real.exp (-(2 * tH h)) := by
  unfold envA34 k34
  rw [Dh_rpow]
  have hL := logh_nonneg hh
  have hlq := logq_nonneg hq
  have hn := natlog2_le_two_log (q * h ^ 3)
  rw [log_qh3 hq hh] at hn
  have h1 : ((Nat.log 2 (q * h ^ 3) : ℕ) : ℝ) ^ (1 / 4 : ℝ) ≤
      (2 * Real.log q) ^ (1 / 4 : ℝ) + (8 / 5) * tH h := by
    calc ((Nat.log 2 (q * h ^ 3) : ℕ) : ℝ) ^ (1 / 4 : ℝ)
        ≤ (2 * Real.log q + 6 * Real.log h) ^ (1 / 4 : ℝ) :=
          Real.rpow_le_rpow (Nat.cast_nonneg _) (by linarith) (by norm_num)
      _ ≤ (2 * Real.log q) ^ (1 / 4 : ℝ) + (6 * Real.log h) ^ (1 / 4 : ℝ) :=
          Real.rpow_add_le_add_rpow (by positivity) (by positivity) (by norm_num) (by norm_num)
      _ = (2 * Real.log q) ^ (1 / 4 : ℝ) + (6 : ℝ) ^ (1 / 4 : ℝ) * tH h := by
          rw [Real.mul_rpow (by norm_num) hL]; rfl
      _ ≤ (2 * Real.log q) ^ (1 / 4 : ℝ) + (8 / 5) * tH h := by
          have := tH_nonneg h
          have := six_rpow_le
          nlinarith
  have key : Real.exp (5 * ((Nat.log 2 (q * h ^ 3) : ℕ) : ℝ) ^ (1 / 4 : ℝ)) *
      Real.exp (-(10 * tH h)) ≤
      Real.exp (5 * (2 * Real.log (q : ℝ)) ^ (1 / 4 : ℝ)) * Real.exp (-(2 * tH h)) := by
    rw [← Real.exp_add, ← Real.exp_add]
    apply Real.exp_le_exp.mpr
    linarith
  have hc : 0 ≤ 4 * Real.exp (10 * Z32) := by positivity
  calc 4 * Real.exp (10 * Z32) * Real.exp (5 * ((Nat.log 2 (q * h ^ 3) : ℕ) : ℝ) ^ (1 / 4 : ℝ)) *
        Real.exp (-(10 * tH h))
      = 4 * Real.exp (10 * Z32) * (Real.exp (5 * ((Nat.log 2 (q * h ^ 3) : ℕ) : ℝ) ^ (1 / 4 : ℝ)) *
        Real.exp (-(10 * tH h))) := by ring
    _ ≤ 4 * Real.exp (10 * Z32) * (Real.exp (5 * (2 * Real.log (q : ℝ)) ^ (1 / 4 : ℝ)) *
        Real.exp (-(2 * tH h))) := mul_le_mul_of_nonneg_left key hc
    _ = _ := by ring

lemma log_h2 (h : ℕ) : Real.log ((h ^ 2 : ℕ) : ℝ) = 2 * Real.log h := by
  push_cast; rw [Real.log_pow]; push_cast; ring

lemma poly_exp_le {h : ℕ} (hh : 1 ≤ h) :
    (1 + Real.log ((h ^ 2 : ℕ) : ℝ)) * Real.exp (-(2 * tH h)) ≤ 4 := by
  rw [log_h2, ← tH_pow4 hh]
  have ht := tH_nonneg h
  have h1 := Real.pow_div_factorial_le_exp (2 * tH h) (show 0 ≤ 2 * tH h by positivity) 4
  have h4 : (Nat.factorial 4 : ℝ) = 24 := by norm_num [Nat.factorial]
  rw [h4] at h1
  have h2 : 1 ≤ Real.exp (2 * tH h) := Real.one_le_exp (by positivity)
  have h3 : 1 + 2 * tH h ^ 4 ≤ 4 * Real.exp (2 * tH h) := by
    have : (2 * tH h) ^ 4 / 24 = 16 * tH h ^ 4 / 24 := by ring
    nlinarith
  have hpos : 0 < Real.exp (2 * tH h) := Real.exp_pos _
  rw [Real.exp_neg, ← div_eq_mul_inv, div_le_iff₀ hpos]
  exact h3

lemma log4_le : Real.log 4 ≤ 3 := by
  have := Real.log_le_sub_one_of_pos (show (0 : ℝ) < 4 by norm_num); linarith

lemma log8_le : Real.log 8 ≤ 7 := by
  have := Real.log_le_sub_one_of_pos (show (0 : ℝ) < 8 by norm_num); linarith

/-- Explicit shell budget. -/
lemma shellU_explicit {P : ℕ} {E1 E34 Cτ c34 : ℝ} {h : ℕ} (hE1 : 1 ≤ E1) (hE34 : 0 ≤ E34)
    (hCτ : 0 ≤ Cτ)
    (h34 : E34 * Dh h ^ (-(1 / 4 : ℝ)) * (1 + Real.log ((h ^ 2 : ℕ) : ℝ)) ≤ c34)
    (hh : 1 ≤ h) :
    shellU P 3 E1 E34 Cτ (vkM h) (Dh h) (h ^ 2) ≤
      2 * ((2 * P + 1) * 12 * E1 * (Cτ + 2 * E1) +
        c34 * E1 * (6 * P * (4 * P + 13) + (2 * P + 2) * 12)) +
      (4 * P + 3) * 12 * E1 * E1 * (8 + 41 * tH h) := by
  unfold shellU budget3
  have hl4 := log4_le
  have hl4' : 0 ≤ Real.log 4 := Real.log_nonneg (by norm_num)
  have hM := vkM_ge_one h
  have hD := Dh_ge_one h
  have hM0 : 0 < vkM h := by linarith
  have hP : (0 : ℝ) ≤ P := Nat.cast_nonneg P
  have hlU : 0 ≤ Real.log ((h ^ 2 : ℕ) : ℝ) :=
    Real.log_nonneg (by exact_mod_cast Nat.one_le_pow _ _ (by omega))
  have hDm : 0 ≤ Dh h ^ (-(1 / 4 : ℝ)) := by positivity
  -- (8M + 4P + 5)/M ≤ 4P + 13
  have hfrac : 2 * P * 3 * (8 * vkM h + 4 * P + 5) / vkM h ≤ 6 * P * (4 * P + 13) := by
    rw [div_le_iff₀ hM0]
    nlinarith [mul_nonneg (mul_nonneg hP hP) (sub_nonneg.mpr hM), mul_nonneg hP (sub_nonneg.mpr hM)]
  have hK : 2 * P * 3 * (8 * vkM h + 4 * P + 5) / vkM h + (2 * P + 2) * 3 * (1 + Real.log 4) ≤
      6 * P * (4 * P + 13) + (2 * P + 2) * 12 := by nlinarith
  have hK0 : 0 ≤ 2 * P * 3 * (8 * vkM h + 4 * P + 5) / vkM h +
      (2 * P + 2) * 3 * (1 + Real.log 4) := by positivity
  have hmid : E34 * E1 * (1 + Real.log ((h ^ 2 : ℕ) : ℝ)) *
      (2 * P * 3 * (8 * vkM h + 4 * P + 5) / vkM h + (2 * P + 2) * 3 * (1 + Real.log 4)) *
        Dh h ^ (-(1 / 4 : ℝ)) ≤ c34 * E1 * (6 * P * (4 * P + 13) + (2 * P + 2) * 12) := by
    have e : E34 * E1 * (1 + Real.log ((h ^ 2 : ℕ) : ℝ)) *
        (2 * P * 3 * (8 * vkM h + 4 * P + 5) / vkM h + (2 * P + 2) * 3 * (1 + Real.log 4)) *
          Dh h ^ (-(1 / 4 : ℝ)) =
        (E34 * Dh h ^ (-(1 / 4 : ℝ)) * (1 + Real.log ((h ^ 2 : ℕ) : ℝ))) * E1 *
          (2 * P * 3 * (8 * vkM h + 4 * P + 5) / vkM h + (2 * P + 2) * 3 * (1 + Real.log 4)) := by
      ring
    rw [e]
    have hc0 : 0 ≤ E34 * Dh h ^ (-(1 / 4 : ℝ)) * (1 + Real.log ((h ^ 2 : ℕ) : ℝ)) := by positivity
    calc (E34 * Dh h ^ (-(1 / 4 : ℝ)) * (1 + Real.log ((h ^ 2 : ℕ) : ℝ))) * E1 *
          (2 * P * 3 * (8 * vkM h + 4 * P + 5) / vkM h + (2 * P + 2) * 3 * (1 + Real.log 4))
        ≤ c34 * E1 * (2 * P * 3 * (8 * vkM h + 4 * P + 5) / vkM h +
            (2 * P + 2) * 3 * (1 + Real.log 4)) := by
          apply mul_le_mul_of_nonneg_right _ hK0
          exact mul_le_mul_of_nonneg_right h34 (by linarith)
      _ ≤ c34 * E1 * (6 * P * (4 * P + 13) + (2 * P + 2) * 12) := by
          apply mul_le_mul_of_nonneg_left hK
          have : 0 ≤ c34 := le_trans hc0 h34
          positivity
  have hlog8 : Real.log (8 * vkM h * Dh h) ≤ 7 + 41 * tH h := by
    rw [Real.log_mul (by positivity) (by positivity), Real.log_mul (by positivity) (by positivity),
      vkM_eq, Dh_eq, Real.log_exp, Real.log_exp]
    linarith [log8_le]
  have hfirst : (2 * P + 1) * 3 * (1 + Real.log 4) * E1 * (Real.exp (10 * Z32) * 0 + Cτ + 2 * E1) =
      (2 * P + 1) * 3 * (1 + Real.log 4) * E1 * (Cτ + 2 * E1) := by ring
  have hA : (2 * (P : ℝ) + 1) * 3 * (1 + Real.log 4) * E1 * (Cτ + 2 * E1) ≤
      (2 * P + 1) * 12 * E1 * (Cτ + 2 * E1) := by
    have : 0 ≤ (2 * (P : ℝ) + 1) * E1 * (Cτ + 2 * E1) := by positivity
    nlinarith
  have hC : (4 * (P : ℝ) + 3) * 3 * (1 + Real.log 4) * E1 * E1 * (1 + Real.log (8 * vkM h * Dh h)) ≤
      (4 * P + 3) * 12 * E1 * E1 * (8 + 41 * tH h) := by
    have h1 : 0 ≤ 1 + Real.log (8 * vkM h * Dh h) := by
      have : 0 ≤ Real.log (8 * vkM h * Dh h) := Real.log_nonneg (by nlinarith)
      linarith
    have h2 : (4 * (P : ℝ) + 3) * 3 * (1 + Real.log 4) * E1 * E1 ≤ (4 * P + 3) * 12 * E1 * E1 := by
      have : 0 ≤ (4 * (P : ℝ) + 3) * E1 * E1 := by positivity
      nlinarith
    calc (4 * (P : ℝ) + 3) * 3 * (1 + Real.log 4) * E1 * E1 * (1 + Real.log (8 * vkM h * Dh h))
        ≤ (4 * P + 3) * 12 * E1 * E1 * (1 + Real.log (8 * vkM h * Dh h)) :=
          mul_le_mul_of_nonneg_right h2 h1
      _ ≤ (4 * P + 3) * 12 * E1 * E1 * (8 + 41 * tH h) := by
          apply mul_le_mul_of_nonneg_left (by linarith) (by positivity)
  push_cast at hmid ⊢
  nlinarith

lemma Jh_le {h : ℕ} (hh : 1 ≤ h) : (Jh h : ℝ) ≤ 6405 * thH h ^ 16 := by
  have hθ := thH_ge_one hh
  have ht := tH_le hh
  have hk := kappa_le hh
  have hL := logh_nonneg hh
  have hLf := Lf_pos hh
  have hx1 : 1 ≤ 2 * vkM h * Lf h := by
    have := vkM_ge_one h
    have : 1 ≤ Lf h := by
      unfold Lf; apply one_le_pow₀; linarith
    nlinarith
  have hlb : 0 ≤ Real.logb 2 (2 * vkM h * Lf h) :=
    Real.logb_nonneg (by norm_num) hx1
  have h1 : (Jh h : ℝ) ≤ Real.logb 2 (2 * vkM h * Lf h) + 1 := by
    unfold Jh; exact (Nat.ceil_lt_add_one hlb).le
  have hM0 : 0 < vkM h := by linarith [vkM_ge_one h]
  have h2 : Real.log (2 * vkM h * Lf h) = Real.log 2 + tH h + 50 * Real.log (Real.log h + 2) := by
    rw [Real.log_mul (by positivity) hLf.ne', Real.log_mul (by norm_num) hM0.ne',
      vkM_eq, Real.log_exp]
    unfold Lf; rw [Real.log_pow]; push_cast; ring
  have hl2 := Real.log_two_gt_d9
  have hl2' : Real.log 2 < 1 := by
    have := Real.log_two_lt_d9; linarith
  have h3 : Real.logb 2 (2 * vkM h * Lf h) ≤ 2 * Real.log (2 * vkM h * Lf h) := by
    unfold Real.logb
    have hlx : 0 ≤ Real.log (2 * vkM h * Lf h) := Real.log_nonneg hx1
    rw [div_le_iff₀ (by linarith)]
    nlinarith
  have hθ16 : 1 ≤ thH h ^ 16 := one_le_pow₀ hθ
  have hθle : thH h ≤ thH h ^ 16 := by
    calc thH h = thH h ^ 1 := (pow_one _).symm
      _ ≤ thH h ^ 16 := pow_le_pow_right₀ hθ (by norm_num)
  have ht0 := tH_nonneg h
  nlinarith

lemma PiH_le {h : ℕ} (hh : 1 ≤ h) :
    PiH h ≤ Real.exp (225 / 4) * 2 ^ 45 * (Real.log h + 2) ^ 45 := by
  unfold PiH
  set y := ((Nat.log 2 h : ℕ) : ℝ) + 2
  have hy : 0 < y := by positivity
  have e : Real.exp (45 / 4 * (5 + 4 * Real.log y)) = Real.exp (225 / 4) * y ^ 45 := by
    have := exp_add_mul_log (c := 225 / 4) hy 45
    rw [← this]; congr 1; push_cast; ring
  rw [e]
  have hyl : y ≤ 2 * (Real.log h + 2) := by
    have := natlog2_le_two_log h
    simp only [y]; linarith
  have : y ^ 45 ≤ (2 * (Real.log h + 2)) ^ 45 := pow_le_pow_left₀ hy.le hyl 45
  rw [mul_pow] at this
  have hc : 0 ≤ Real.exp (225 / 4) := by positivity
  calc Real.exp (225 / 4) * y ^ 45 ≤ Real.exp (225 / 4) * (2 ^ 45 * (Real.log h + 2) ^ 45) :=
        mul_le_mul_of_nonneg_left this hc
    _ = _ := by ring

lemma far_le {h : ℕ} (hh : 1 ≤ h) {E1 : ℝ} (hE1 : 1 ≤ E1) :
    3 / Lf h * (PiH h + (1 + E1 * (1 + Real.log ((h ^ 2 : ℕ) : ℝ))) ^ 2) ≤
      3 * Real.exp (225 / 4) * 2 ^ 45 + 27 * E1 ^ 2 := by
  have hL := logh_nonneg hh
  set ℓ := Real.log (h : ℝ) + 2
  have hℓ : 2 ≤ ℓ := by simp only [ℓ]; linarith
  have hLf : Lf h = ℓ ^ 50 := rfl
  have hLf0 : 0 < ℓ ^ 50 := by positivity
  rw [hLf, log_h2]
  have h45 : ℓ ^ 45 ≤ ℓ ^ 50 := pow_le_pow_right₀ (by linarith) (by norm_num)
  have h2 : ℓ ^ 2 ≤ ℓ ^ 50 := pow_le_pow_right₀ (by linarith) (by norm_num)
  have hP := PiH_le hh
  have hsq : (1 + E1 * (1 + 2 * Real.log h)) ^ 2 ≤ 9 * E1 ^ 2 * ℓ ^ 2 := by
    have : 1 + E1 * (1 + 2 * Real.log h) ≤ 3 * E1 * ℓ := by
      simp only [ℓ]; nlinarith
    have h0 : 0 ≤ 1 + E1 * (1 + 2 * Real.log h) := by positivity
    calc (1 + E1 * (1 + 2 * Real.log h)) ^ 2 ≤ (3 * E1 * ℓ) ^ 2 := pow_le_pow_left₀ h0 this 2
      _ = 9 * E1 ^ 2 * ℓ ^ 2 := by ring
  rw [div_mul_eq_mul_div, div_le_iff₀ hLf0]
  have hc : 0 ≤ Real.exp (225 / 4) * 2 ^ 45 := by positivity
  have hE : 0 ≤ E1 ^ 2 := by positivity
  nlinarith [mul_le_mul_of_nonneg_left h45 hc, mul_le_mul_of_nonneg_left h2 hE]

end OrielUpper
