import PaperB.FixedQ.SignedForbiddenPrincipalRateTerminal
import PaperB.FixedQ.SignedForbiddenCompletedMainAggregateBridge

namespace PaperB.FixedQ

/--
Consumer-facing B5/B6 adapter.

Any log-power estimate for the exact signed-forbidden completed-main aggregate,
with the manuscript principal term kept signed, transports directly to the
public `CompletedMainPrincipalLogPowerSaving` contract.
-/
theorem completedMainPrincipalLogPowerSaving_of_signedForbiddenAggregateRate
    {q : ℕ} (hq : 0 < q)
    (hRate :
      ∃ C rho : ℝ, ∃ k H0 : ℕ,
        0 ≤ C ∧ rho < 1 ∧
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          H0 ≤ h →
          |cStarReal q h * signedForbiddenCompletedMainAggregate q a h -
              signedMainB1Principal q (h / 2)| ≤
            C * (Real.log (h : ℝ)) ^ rho *
              (Real.log (Real.log (h : ℝ))) ^ k) :
    CompletedMainPrincipalLogPowerSaving q := by
  rcases hRate with ⟨C, rho, k, H0, hC, hrho, hRate⟩
  refine ⟨C, rho, k, H0, hC, hrho, ?_⟩
  intro a b h ha hb hcompat h2 hh hH0
  rw [completedBooleanMain_eq_signedForbiddenCompletedMainAggregate hq ha hh h2]
  exact hRate a b h ha hb hcompat h2 hh hH0

#print axioms completedMainPrincipalLogPowerSaving_of_signedForbiddenAggregateRate

end PaperB.FixedQ
