import PaperB.FixedQ.SignedForbiddenCenteredConductorGamma

open scoped BigOperators

namespace PaperB.FixedQ

theorem sourceCenteredConductorEnhancedEulerProduct_uniform_bound
    (S : Finset ℕ) :
    (∏ p ∈ S, (1 + sourceCenteredConductorEnhancedPrimeMajorant p)) ≤
      Real.exp (∑' n : ℕ, sourceCenteredConductorEnhancedPrimeMajorant n) := by
  have hprod :
      (∏ p ∈ S, (1 + sourceCenteredConductorEnhancedPrimeMajorant p)) ≤
        ∏ p ∈ S, Real.exp (sourceCenteredConductorEnhancedPrimeMajorant p) := by
    induction S using Finset.induction_on with
    | empty => simp
    | @insert a S ha ih =>
        rw [Finset.prod_insert ha, Finset.prod_insert ha]
        have hlocal :
            1 + sourceCenteredConductorEnhancedPrimeMajorant a ≤
              Real.exp (sourceCenteredConductorEnhancedPrimeMajorant a) := by
          simpa [add_comm] using
            Real.add_one_le_exp (sourceCenteredConductorEnhancedPrimeMajorant a)
        have hleft :
            0 ≤ ∏ p ∈ S,
              (1 + sourceCenteredConductorEnhancedPrimeMajorant p) := by
          apply Finset.prod_nonneg
          intro p hp
          linarith [sourceCenteredConductorEnhancedPrimeMajorant_nonneg p]
        exact mul_le_mul hlocal ih hleft (Real.exp_pos _).le
  calc
    (∏ p ∈ S, (1 + sourceCenteredConductorEnhancedPrimeMajorant p))
      ≤ ∏ p ∈ S, Real.exp (sourceCenteredConductorEnhancedPrimeMajorant p) :=
        hprod
    _ = Real.exp (∑ p ∈ S, sourceCenteredConductorEnhancedPrimeMajorant p) := by
      rw [Real.exp_sum]
    _ ≤ Real.exp (∑' n : ℕ, sourceCenteredConductorEnhancedPrimeMajorant n) := by
      apply Real.exp_monotone
      exact summable_sourceCenteredConductorEnhancedPrimeMajorant.sum_le_tsum S
        (fun n hn => sourceCenteredConductorEnhancedPrimeMajorant_nonneg n)

theorem sourceCenteredConductorEnhancedPowerset_uniform_bound
    (S : Finset ℕ) :
    (∑ s ∈ S.powerset,
      ∏ p ∈ s, sourceCenteredConductorEnhancedPrimeMajorant p) ≤
      Real.exp (∑' n : ℕ, sourceCenteredConductorEnhancedPrimeMajorant n) := by
  calc
    (∑ s ∈ S.powerset,
      ∏ p ∈ s, sourceCenteredConductorEnhancedPrimeMajorant p)
      = ∏ p ∈ S, (1 + sourceCenteredConductorEnhancedPrimeMajorant p) := by
          symm
          simpa [add_comm] using
            (Finset.prod_one_add
              (s := S)
              (f := sourceCenteredConductorEnhancedPrimeMajorant))
    _ ≤ Real.exp (∑' n : ℕ, sourceCenteredConductorEnhancedPrimeMajorant n) :=
      sourceCenteredConductorEnhancedEulerProduct_uniform_bound S

theorem sourceCenteredConductorEnhancedSplitPowerset_uniform_bound
    (S Rset : Finset ℕ) (hdis : Disjoint S Rset) :
    (∑ s ∈ S.powerset,
      ∏ p ∈ (s ∪ Rset),
        sourceCenteredConductorEnhancedPrimeMajorant p) ≤
      Real.exp (∑' n : ℕ, sourceCenteredConductorEnhancedPrimeMajorant n) ^
        (2 : ℕ) := by
  let E : ℝ :=
    Real.exp (∑' n : ℕ, sourceCenteredConductorEnhancedPrimeMajorant n)
  have hS :
      (∑ s ∈ S.powerset,
        ∏ p ∈ s, sourceCenteredConductorEnhancedPrimeMajorant p) ≤ E := by
    simpa [E] using sourceCenteredConductorEnhancedPowerset_uniform_bound S
  have hRprod :
      (∏ p ∈ Rset, sourceCenteredConductorEnhancedPrimeMajorant p) ≤ E := by
    have hpoint : ∀ p ∈ Rset,
        sourceCenteredConductorEnhancedPrimeMajorant p ≤
          1 + sourceCenteredConductorEnhancedPrimeMajorant p := by
      intro p hp
      linarith
    have hprod :
        (∏ p ∈ Rset, sourceCenteredConductorEnhancedPrimeMajorant p) ≤
          ∏ p ∈ Rset, (1 + sourceCenteredConductorEnhancedPrimeMajorant p) := by
      apply Finset.prod_le_prod₀
      · intro p hp
        exact sourceCenteredConductorEnhancedPrimeMajorant_nonneg p
      · exact hpoint
    exact hprod.trans
      (by simpa [E] using
        sourceCenteredConductorEnhancedEulerProduct_uniform_bound Rset)
  have hR0 :
      0 ≤ ∏ p ∈ Rset, sourceCenteredConductorEnhancedPrimeMajorant p := by
    exact Finset.prod_nonneg
      (fun p hp => sourceCenteredConductorEnhancedPrimeMajorant_nonneg p)
  have hS0 :
      0 ≤ ∑ s ∈ S.powerset,
        ∏ p ∈ s, sourceCenteredConductorEnhancedPrimeMajorant p := by
    apply Finset.sum_nonneg
    intro s hs
    exact Finset.prod_nonneg
      (fun p hp => sourceCenteredConductorEnhancedPrimeMajorant_nonneg p)
  have hE0 : 0 ≤ E := by
    dsimp [E]
    exact (Real.exp_pos _).le
  calc
    (∑ s ∈ S.powerset,
      ∏ p ∈ (s ∪ Rset),
        sourceCenteredConductorEnhancedPrimeMajorant p)
      = (∏ p ∈ Rset, sourceCenteredConductorEnhancedPrimeMajorant p) *
          (∑ s ∈ S.powerset,
            ∏ p ∈ s, sourceCenteredConductorEnhancedPrimeMajorant p) := by
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro s hs
          have hsub : s ⊆ S := Finset.mem_powerset.mp hs
          have hdis' : Disjoint s Rset := hdis.mono_left hsub
          rw [Finset.prod_union hdis']
          ring
    _ ≤ E * E := mul_le_mul hRprod hS hS0 hE0
    _ = E ^ (2 : ℕ) := by ring

theorem sourceCenteredConductorEnhancedOuter_uniform_bound
    (S Rset : Finset ℕ) (hdis : Disjoint S Rset)
    (channel : Finset ℕ → ℝ)
    {K : ℝ} (hK : 0 ≤ K)
    (hchan : ∀ s ∈ S.powerset,
      |channel s| ≤
        K * (∏ p ∈ (s ∪ Rset),
          sourceCenteredConductorEnhancedPrimeMajorant p)) :
    |∑ s ∈ S.powerset, channel s| ≤
      K * Real.exp
        (∑' n : ℕ, sourceCenteredConductorEnhancedPrimeMajorant n) ^ (2 : ℕ) := by
  calc
    |∑ s ∈ S.powerset, channel s|
      ≤ ∑ s ∈ S.powerset, |channel s| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ s ∈ S.powerset,
        K * (∏ p ∈ (s ∪ Rset),
          sourceCenteredConductorEnhancedPrimeMajorant p) := by
        apply Finset.sum_le_sum
        intro s hs
        exact hchan s hs
    _ = K * (∑ s ∈ S.powerset,
        ∏ p ∈ (s ∪ Rset),
          sourceCenteredConductorEnhancedPrimeMajorant p) := by
        rw [Finset.mul_sum]
    _ ≤ K * Real.exp
        (∑' n : ℕ, sourceCenteredConductorEnhancedPrimeMajorant n) ^ (2 : ℕ) := by
        exact mul_le_mul_of_nonneg_left
          (sourceCenteredConductorEnhancedSplitPowerset_uniform_bound
            S Rset hdis) hK

#print axioms sourceCenteredConductorEnhancedEulerProduct_uniform_bound
#print axioms sourceCenteredConductorEnhancedPowerset_uniform_bound
#print axioms sourceCenteredConductorEnhancedSplitPowerset_uniform_bound
#print axioms sourceCenteredConductorEnhancedOuter_uniform_bound

end PaperB.FixedQ
