import PaperB.Analytic.FixedBetaExponentLedger

namespace PaperB.Analytic

open Real

theorem exists_fixedBeta_order
    {beta : ℝ} (hb0 : 0 < beta) (hb1 : beta < 1) :
    ∃ k : ℕ, 2 ≤ k ∧
      beta⁻¹ < (k + 1 : ℝ) ∧
      (k + 1 : ℝ) - beta⁻¹ <
        4 - 8 / (2 : ℝ)^k := by
  let x : ℝ := beta⁻¹
  let n : ℕ := ⌊x⌋₊
  let k : ℕ := n + 1
  have hx0 : 0 ≤ x := by
    dsimp [x]
    positivity
  have hx1 : 1 < x := by
    dsimp [x]
    exact (one_lt_inv₀ hb0).2 hb1
  have hn1 : 1 ≤ n := by
    by_contra h
    have hn0 : n = 0 := by omega
    have hxlt : x < (n : ℝ) + 1 := by
      dsimp [n]
      simpa using (Nat.lt_floor_add_one x)
    rw [hn0] at hxlt
    norm_num at hxlt
    linarith
  have hk2 : 2 ≤ k := by
    dsimp [k]
    omega
  have hfloor : (n : ℝ) ≤ x := by
    dsimp [n]
    exact Nat.floor_le hx0
  have hltfloor : x < (n : ℝ) + 1 := by
    dsimp [n]
    simpa using (Nat.lt_floor_add_one x)
  have horder : x < (k + 1 : ℕ) := by
    dsimp [k]
    norm_num at hltfloor ⊢
    linarith
  refine ⟨k, hk2, ?_, ?_⟩
  · simpa [x] using horder
  · have hdiff_le : (k + 1 : ℝ) - x ≤ 2 := by
      dsimp [k]
      norm_num
      linarith
    by_cases hkEq : k = 2
    · rw [hkEq]
      norm_num
      dsimp [x] at hx1
      linarith
    · have hk3 : 3 ≤ k := by omega
      have hpow8 : (8 : ℝ) ≤ (2 : ℝ)^k := by
        have hmono := pow_le_pow_right₀ (a := (2 : ℝ)) (by norm_num) hk3
        norm_num at hmono ⊢
        exact hmono
      have hpowpos : 0 < (2 : ℝ)^k := by positivity
      have hfrac : 8 / (2 : ℝ)^k ≤ 1 := by
        rw [div_le_one hpowpos]
        exact hpow8
      have hrhs : 3 ≤ 4 - 8 / (2 : ℝ)^k := by linarith
      have hstrict : (k + 1 : ℝ) - x < 3 := lt_of_le_of_lt hdiff_le (by norm_num)
      exact lt_of_lt_of_le hstrict hrhs

theorem exists_fixedBeta_exponent_ledger
    {beta : ℝ} (hb0 : 0 < beta) (hb1 : beta < 1) :
    ∃ k : ℕ, 2 ≤ k ∧
      fixedBetaFirstExponent beta k < 1 ∧
      fixedBetaSecondExponent beta k < 1 := by
  obtain ⟨k, hk, horder, hwindow⟩ := exists_fixedBeta_order hb0 hb1
  exact ⟨k, hk, fixedBeta_exponent_ledger hk horder hwindow⟩

#print axioms exists_fixedBeta_order
#print axioms exists_fixedBeta_exponent_ledger

end PaperB.Analytic
