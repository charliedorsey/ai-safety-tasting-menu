import Mathlib.NumberTheory.Harmonic.Bounds
import Mathlib.NumberTheory.Divisors
import Mathlib.Analysis.SpecialFunctions.Log.Basic

/-!
# Quillon CSC3 F7.4e: elementary divisor moments

* `sum_inv_multiples`: `Σ_{d ≤ x, l ∣ d} 1/d ≤ (1/l)(1 + log x)`.
* `tau_sq_moment`: `Σ_{d ≤ x} τ(d)²/d ≤ (1 + log x)⁴`.

The proof uses `τ(d)² = #{(a,b) : a,b ∣ d}`, the bound `1/lcm(a,b) = gcd(a,b)/(ab)`, and
`gcd(a,b) ≤ Σ_{g∣a, g∣b} g`. No Euler product and no Mertens is needed.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonDivisorMoment

lemma harm_Ioc_le' (U : ℕ) : ∑ d ∈ Ioc 0 U, (1 / (d : ℝ)) ≤ 1 + Real.log U := by
  have := harmonic_le_one_add_log U
  rw [harmonic_eq_sum_Icc] at this; push_cast at this
  have e : Ioc 0 U = Icc 1 U := by ext d; simp only [mem_Ioc, mem_Icc]; omega
  rw [e]; simpa [one_div] using this

lemma one_add_log_nonneg (x : ℕ) : 0 ≤ 1 + Real.log x := by
  have := Real.log_natCast_nonneg x; linarith

lemma sum_inv_multiples (l x : ℕ) (hl : 1 ≤ l) :
    ∑ d ∈ (Ioc 0 x).filter (fun d => l ∣ d), (1 / (d : ℝ)) ≤ (1 / (l : ℝ)) * (1 + Real.log x) := by
  have hset : (Ioc 0 x).filter (fun d => l ∣ d) = (Ioc 0 (x / l)).image (fun k => l * k) := by
    ext d
    simp only [mem_filter, mem_Ioc, mem_image]
    constructor
    · rintro ⟨⟨hd0, hdx⟩, ⟨k, rfl⟩⟩
      refine ⟨k, ⟨Nat.pos_of_ne_zero (by rintro rfl; simp at hd0), ?_⟩, rfl⟩
      rw [Nat.le_div_iff_mul_le (by omega), mul_comm]; exact hdx
    · rintro ⟨k, ⟨hk0, hkx⟩, rfl⟩
      refine ⟨⟨Nat.mul_pos (by omega) hk0, ?_⟩, dvd_mul_right l k⟩
      rw [Nat.le_div_iff_mul_le (by omega), mul_comm] at hkx; exact hkx
  rw [hset, sum_image (fun a _ b _ h => Nat.eq_of_mul_eq_mul_left (by omega) h)]
  have hlR : (0 : ℝ) < l := by exact_mod_cast hl
  calc ∑ k ∈ Ioc 0 (x / l), (1 / ((l * k : ℕ) : ℝ))
      = (1 / (l : ℝ)) * ∑ k ∈ Ioc 0 (x / l), (1 / (k : ℝ)) := by
        rw [mul_sum]; refine sum_congr rfl fun k _ => ?_
        push_cast; rw [one_div_mul_one_div]
    _ ≤ (1 / (l : ℝ)) * (1 + Real.log (x / l : ℕ)) :=
        mul_le_mul_of_nonneg_left (harm_Ioc_le' _) (by positivity)
    _ ≤ _ := by
        apply mul_le_mul_of_nonneg_left _ (by positivity)
        have : Real.log ((x / l : ℕ) : ℝ) ≤ Real.log x := by
          rcases Nat.eq_zero_or_pos (x / l) with h | h
          · rw [h, Nat.cast_zero, Real.log_zero]; exact Real.log_natCast_nonneg x
          · exact Real.log_le_log (by exact_mod_cast h) (by exact_mod_cast Nat.div_le_self x l)
        linarith

lemma divisors_eq_filter (d x : ℕ) (hd : d ∈ Ioc 0 x) :
    d.divisors = (Ioc 0 x).filter (fun a => a ∣ d) := by
  have hd' := mem_Ioc.1 hd
  ext a
  simp only [Nat.mem_divisors, mem_filter, mem_Ioc]
  constructor
  · rintro ⟨had, _⟩
    exact ⟨⟨Nat.pos_of_dvd_of_pos had hd'.1, (Nat.le_of_dvd hd'.1 had).trans hd'.2⟩, had⟩
  · rintro ⟨_, had⟩; exact ⟨had, by omega⟩

/-- `Σ_{a,b ≤ x} 1/lcm(a,b) ≤ (1+log x)³`. -/
lemma sum_inv_lcm (x : ℕ) :
    ∑ a ∈ Ioc 0 x, ∑ b ∈ Ioc 0 x, (1 / ((Nat.lcm a b : ℕ) : ℝ)) ≤ (1 + Real.log x) ^ 3 := by
  have hL := one_add_log_nonneg x
  -- 1/lcm ≤ (1/(ab)) Σ_{g ≤ x, g∣a, g∣b} g
  have hpt : ∀ a ∈ Ioc 0 x, ∀ b ∈ Ioc 0 x, (1 / ((Nat.lcm a b : ℕ) : ℝ)) ≤
      ∑ g ∈ Ioc 0 x, (if g ∣ a ∧ g ∣ b then (g : ℝ) * ((1 / (a : ℝ)) * (1 / (b : ℝ))) else 0) := by
    intro a ha b hb
    have ha' := mem_Ioc.1 ha; have hb' := mem_Ioc.1 hb
    have hgpos : 0 < Nat.gcd a b := Nat.gcd_pos_of_pos_left _ ha'.1
    have hgmem : Nat.gcd a b ∈ Ioc 0 x :=
      mem_Ioc.2 ⟨hgpos, (Nat.le_of_dvd ha'.1 (Nat.gcd_dvd_left a b)).trans ha'.2⟩
    have hval : (1 / ((Nat.lcm a b : ℕ) : ℝ)) = (Nat.gcd a b : ℝ) * ((1 / (a : ℝ)) * (1 / (b : ℝ))) := by
      have h := Nat.gcd_mul_lcm a b
      have hR : ((Nat.gcd a b : ℕ) : ℝ) * ((Nat.lcm a b : ℕ) : ℝ) = (a : ℝ) * b := by exact_mod_cast h
      have haR : (0 : ℝ) < a := by exact_mod_cast ha'.1
      have hbR : (0 : ℝ) < b := by exact_mod_cast hb'.1
      have hlR : (0 : ℝ) < ((Nat.lcm a b : ℕ) : ℝ) := by
        exact_mod_cast Nat.lcm_pos ha'.1 hb'.1
      field_simp
      linarith [hR]
    rw [hval]
    have := single_le_sum (f := fun g => if g ∣ a ∧ g ∣ b then (g : ℝ) * ((1 / (a : ℝ)) * (1 / (b : ℝ)))
      else 0) (fun g _ => by split_ifs <;> positivity) hgmem
    simp only [if_pos (And.intro (Nat.gcd_dvd_left a b) (Nat.gcd_dvd_right a b))] at this
    exact this
  calc _ ≤ ∑ a ∈ Ioc 0 x, ∑ b ∈ Ioc 0 x, ∑ g ∈ Ioc 0 x,
        (if g ∣ a ∧ g ∣ b then (g : ℝ) * ((1 / (a : ℝ)) * (1 / (b : ℝ))) else 0) :=
        sum_le_sum fun a ha => sum_le_sum fun b hb => hpt a ha b hb
    _ = ∑ g ∈ Ioc 0 x, (g : ℝ) * ((∑ a ∈ (Ioc 0 x).filter (fun a => g ∣ a), (1 / (a : ℝ))) *
          (∑ b ∈ (Ioc 0 x).filter (fun b => g ∣ b), (1 / (b : ℝ)))) := by
        rw [sum_comm]
        refine (sum_congr rfl fun b _ => sum_comm).trans ?_
        rw [sum_comm]
        refine sum_congr rfl fun g _ => ?_
        rw [sum_filter, sum_mul_sum, mul_sum]
        conv_lhs => rw [sum_comm]
        refine sum_congr rfl fun a _ => ?_
        rw [mul_sum]
        refine sum_congr rfl fun b _ => ?_
        by_cases ha : g ∣ a <;> by_cases hb : g ∣ b <;> simp [ha, hb]
    _ ≤ ∑ g ∈ Ioc 0 x, (g : ℝ) * (((1 / (g : ℝ)) * (1 + Real.log x)) *
          ((1 / (g : ℝ)) * (1 + Real.log x))) := by
        refine sum_le_sum fun g hg => ?_
        have hg1 : 1 ≤ g := (mem_Ioc.1 hg).1
        apply mul_le_mul_of_nonneg_left _ (by positivity)
        exact mul_le_mul (sum_inv_multiples g x hg1) (sum_inv_multiples g x hg1)
          (sum_nonneg fun _ _ => by positivity) (by positivity)
    _ = (1 + Real.log x) ^ 2 * ∑ g ∈ Ioc 0 x, (1 / (g : ℝ)) := by
        rw [mul_sum]; refine sum_congr rfl fun g hg => ?_
        have : (g : ℝ) ≠ 0 := by have := (mem_Ioc.1 hg).1; positivity
        field_simp
    _ ≤ (1 + Real.log x) ^ 2 * (1 + Real.log x) :=
        mul_le_mul_of_nonneg_left (harm_Ioc_le' x) (by positivity)
    _ = _ := by ring

/-- **Divisor moment.** `Σ_{d ≤ x} τ(d)²/d ≤ (1 + log x)⁴`. -/
theorem tau_sq_moment (x : ℕ) :
    ∑ d ∈ Ioc 0 x, ((d.divisors.card : ℝ)) ^ 2 * (1 / (d : ℝ)) ≤ (1 + Real.log x) ^ 4 := by
  have hL := one_add_log_nonneg x
  calc _ = ∑ d ∈ Ioc 0 x, ∑ a ∈ Ioc 0 x, ∑ b ∈ Ioc 0 x,
        (if a ∣ d ∧ b ∣ d then (1 / (d : ℝ)) else 0) := by
        refine sum_congr rfl fun d hd => ?_
        rw [divisors_eq_filter d x hd, card_filter, sq]
        push_cast
        rw [sum_mul_sum, sum_mul]
        refine sum_congr rfl fun a _ => ?_
        rw [sum_mul]
        refine sum_congr rfl fun b _ => ?_
        by_cases ha : a ∣ d <;> by_cases hb : b ∣ d <;> simp [ha, hb]
    _ = ∑ a ∈ Ioc 0 x, ∑ b ∈ Ioc 0 x, ∑ d ∈ (Ioc 0 x).filter (fun d => Nat.lcm a b ∣ d),
          (1 / (d : ℝ)) := by
        rw [sum_comm]
        refine (sum_congr rfl fun a _ => sum_comm).trans ?_
        refine sum_congr rfl fun a _ => sum_congr rfl fun b _ => ?_
        rw [sum_filter]
        refine sum_congr rfl fun d _ => ?_
        simp only [Nat.lcm_dvd_iff]
    _ ≤ ∑ a ∈ Ioc 0 x, ∑ b ∈ Ioc 0 x, (1 / ((Nat.lcm a b : ℕ) : ℝ)) * (1 + Real.log x) := by
        refine sum_le_sum fun a ha => sum_le_sum fun b hb => ?_
        exact sum_inv_multiples _ x (Nat.lcm_pos (mem_Ioc.1 ha).1 (mem_Ioc.1 hb).1)
    _ = (∑ a ∈ Ioc 0 x, ∑ b ∈ Ioc 0 x, (1 / ((Nat.lcm a b : ℕ) : ℝ))) * (1 + Real.log x) := by
        rw [sum_mul]; refine sum_congr rfl fun a _ => by rw [sum_mul]
    _ ≤ (1 + Real.log x) ^ 3 * (1 + Real.log x) :=
        mul_le_mul_of_nonneg_right (sum_inv_lcm x) hL
    _ = _ := by ring

end GoldC.QuillonDivisorMoment

#print axioms GoldC.QuillonDivisorMoment.tau_sq_moment
