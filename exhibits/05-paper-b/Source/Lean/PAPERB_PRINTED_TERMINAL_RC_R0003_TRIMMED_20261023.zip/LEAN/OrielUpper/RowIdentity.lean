import OrielUpper.Principal

/-!
# Oriel Upper — exact row identity (Identity II) in both orientations

Source objects (verbatim bodies of Paper B `rowConstrainedMass`, `rowWeightMass`,
`rowDiscrepancy`):

`rowMass w H a b = ∑_{0<y<H} [a ∣ y ∧ b ∣ H - y] w y`,
`rowW w H = ∑_{0<y<H} w y`, `rowDisc = rowMass - rowW/(a b)`.

If `w y = Λ (y mod P)` on `0 < y < H` then, exactly,

* (fixed `r`, varying `s`)
  `rowDisc w H r s = ψ_{r}(v = s, t = s; (H-1)/s) + (μ(H-1) - W)/(rs)` with orientation
  `α = H, β = -1`;
* (fixed `s`, varying `r`)
  `rowDisc w H r s = ψ_{s}(v = r, t = r; (H-1)/r) + (μ(H-1) - W)/(rs)` with orientation
  `α = 0, β = 1`;

and the centering defect satisfies `|μ(H-1) - W| ≤ (2P+1) B`.
No coprimality is needed for the identities themselves.
-/

open Finset

namespace OrielUpper

/-- Source `rowConstrainedMass` (verbatim body). -/
noncomputable def rowMass (w : ℕ → ℝ) (H a b : ℕ) : ℝ :=
  ∑ y ∈ Ioo 0 H, if a ∣ y ∧ b ∣ H - y then w y else 0

/-- Source `rowWeightMass` (verbatim body). -/
noncomputable def rowW (w : ℕ → ℝ) (H : ℕ) : ℝ := ∑ y ∈ Ioo 0 H, w y

/-- Source `rowDiscrepancy` (verbatim body). -/
noncomputable def rowDisc (w : ℕ → ℝ) (H a b : ℕ) : ℝ :=
  rowMass w H a b - rowW w H / ((a : ℝ) * (b : ℝ))

variable {P : ℕ} [NeZero P]

lemma natCast_dvd_iff_zmod {r y : ℕ} : r ∣ y ↔ (y : ZMod r) = 0 :=
  (ZMod.natCast_eq_zero_iff y r).symm

/-- Orientation 1: fixed `r`, substitute `y = H - s u`. -/
theorem oriel_rowMass_left {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {H : ℕ}
    (hw : ∀ y, 0 < y → y < H → w y = Λ (y : ZMod P)) {r s : ℕ} (hs : 0 < s) :
    rowMass w H r s = ∑ u ∈ Icc 1 ((H - 1) / s),
      rowF r H Λ (H : ZMod P) (-1) (s : ZMod P) (s : ZMod r) u := by
  unfold rowMass rowF
  rw [← sum_filter]
  have hR : ∀ u ∈ Icc 1 ((H - 1) / s),
      Λ ((H : ZMod P) + -1 * (s : ZMod P) * (u : ZMod P)) *
        (if (H : ZMod r) = (s : ZMod r) * (u : ZMod r) then 1 else 0) =
      if (H : ZMod r) = (s : ZMod r) * (u : ZMod r)
        then Λ ((H : ZMod P) + -1 * (s : ZMod P) * (u : ZMod P)) else 0 := by
    intro u _; split_ifs <;> simp
  rw [sum_congr rfl hR, ← sum_filter]
  symm
  apply Finset.sum_nbij' (fun u => H - s * u) (fun y => (H - y) / s)
  · intro u hu
    rw [mem_filter, mem_Icc] at hu
    rw [mem_filter, mem_Ioo]
    have h1 : s * u ≤ H - 1 := by
      have := (Nat.le_div_iff_mul_le hs).mp hu.1.2; rw [Nat.mul_comm]; exact this
    have hsu : 1 ≤ s * u := Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero hs.ne' (by omega))
    refine ⟨⟨by omega, by omega⟩, ?_, ?_⟩
    · rw [natCast_dvd_iff_zmod, Nat.cast_sub (by omega), hu.2]; push_cast; ring
    · rw [show H - (H - s * u) = s * u by omega]; exact dvd_mul_right s u
  · intro y hy
    rw [mem_filter, mem_Ioo] at hy
    rw [mem_filter, mem_Icc]
    obtain ⟨k, hk⟩ := hy.2.2
    have hk' : (H - y) / s = k := by rw [hk, Nat.mul_div_cancel_left _ hs]
    rw [hk']
    have hk1 : 1 ≤ k := by
      rcases Nat.eq_zero_or_pos k with h | h
      · subst h; simp at hk; omega
      · exact h
    refine ⟨⟨hk1, ?_⟩, ?_⟩
    · apply (Nat.le_div_iff_mul_le hs).mpr; rw [Nat.mul_comm]; omega
    · have hy0 : (y : ZMod r) = 0 := natCast_dvd_iff_zmod.mp hy.2.1
      have : H = y + s * k := by omega
      rw [this]; push_cast; rw [hy0, zero_add]
  · intro u hu
    rw [mem_filter, mem_Icc] at hu
    have h1 : s * u ≤ H - 1 := by
      have := (Nat.le_div_iff_mul_le hs).mp hu.1.2; rw [Nat.mul_comm]; exact this
    rw [show H - (H - s * u) = s * u by omega, Nat.mul_div_cancel_left _ hs]
  · intro y hy
    rw [mem_filter, mem_Ioo] at hy
    obtain ⟨k, hk⟩ := hy.2.2
    show H - s * ((H - y) / s) = y
    rw [hk, Nat.mul_div_cancel_left _ hs]
    omega
  · intro u hu
    rw [mem_filter, mem_Icc] at hu
    have h1 : s * u ≤ H - 1 := by
      have := (Nat.le_div_iff_mul_le hs).mp hu.1.2; rw [Nat.mul_comm]; exact this
    have hsu : 1 ≤ s * u := Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero hs.ne' (by omega))
    rw [hw (H - s * u) (by omega) (by omega), Nat.cast_sub (by omega)]
    push_cast; ring_nf

/-- Orientation 2: fixed `s`, substitute `y = r u`. -/
theorem oriel_rowMass_right {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {H : ℕ}
    (hw : ∀ y, 0 < y → y < H → w y = Λ (y : ZMod P)) {r s : ℕ} (hr : 0 < r) :
    rowMass w H r s = ∑ u ∈ Icc 1 ((H - 1) / r),
      rowF s H Λ 0 1 (r : ZMod P) (r : ZMod s) u := by
  unfold rowMass rowF
  rw [← sum_filter]
  have hR : ∀ u ∈ Icc 1 ((H - 1) / r),
      Λ ((0 : ZMod P) + 1 * (r : ZMod P) * (u : ZMod P)) *
        (if (H : ZMod s) = (r : ZMod s) * (u : ZMod s) then 1 else 0) =
      if (H : ZMod s) = (r : ZMod s) * (u : ZMod s)
        then Λ ((0 : ZMod P) + 1 * (r : ZMod P) * (u : ZMod P)) else 0 := by
    intro u _; split_ifs <;> simp
  rw [sum_congr rfl hR, ← sum_filter]
  symm
  apply Finset.sum_nbij' (fun u => r * u) (fun y => y / r)
  · intro u hu
    rw [mem_filter, mem_Icc] at hu
    rw [mem_filter, mem_Ioo]
    have h1 : r * u ≤ H - 1 := by
      have := (Nat.le_div_iff_mul_le hr).mp hu.1.2; rw [Nat.mul_comm]; exact this
    have hru : 1 ≤ r * u := Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero hr.ne' (by omega))
    refine ⟨⟨by omega, by omega⟩, dvd_mul_right r u, ?_⟩
    rw [natCast_dvd_iff_zmod, Nat.cast_sub (by omega), hu.2]; push_cast; ring
  · intro y hy
    rw [mem_filter, mem_Ioo] at hy
    rw [mem_filter, mem_Icc]
    obtain ⟨k, rfl⟩ := hy.2.1
    rw [Nat.mul_div_cancel_left _ hr]
    have hk1 : 1 ≤ k := by
      rcases Nat.eq_zero_or_pos k with h | h
      · subst h; simp at hy
      · exact h
    refine ⟨⟨hk1, ?_⟩, ?_⟩
    · apply (Nat.le_div_iff_mul_le hr).mpr; rw [Nat.mul_comm]; omega
    · have h0 : ((H - r * k : ℕ) : ZMod s) = 0 := natCast_dvd_iff_zmod.mp hy.2.2
      rw [Nat.cast_sub (by omega)] at h0
      push_cast at h0
      exact sub_eq_zero.mp h0
  · intro u _; exact Nat.mul_div_cancel_left u hr
  · intro y hy
    rw [mem_filter] at hy
    exact Nat.mul_div_cancel' hy.2.1
  · intro u hu
    rw [mem_filter, mem_Icc] at hu
    have h1 : r * u ≤ H - 1 := by
      have := (Nat.le_div_iff_mul_le hr).mp hu.1.2; rw [Nat.mul_comm]; exact this
    have hru : 1 ≤ r * u := Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero hr.ne' (by omega))
    rw [hw (r * u) (by omega) (by omega)]
    push_cast; ring_nf

lemma floor_natCast_div (a b : ℕ) : ⌊((a : ℕ) : ℝ) / b⌋₊ = a / b := Nat.floor_div_eq_div a b

/-- Identity II, fixed `r`. -/
theorem oriel_rowDisc_left {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {H : ℕ}
    (hw : ∀ y, 0 < y → y < H → w y = Λ (y : ZMod P)) {r s : ℕ} (hr : 0 < r) (hs : 0 < s) :
    rowDisc w H r s =
      psiR r H Λ (H : ZMod P) (-1) (s : ZMod P) (s : ZMod r) (((H - 1 : ℕ) : ℝ) / s) +
        (muL Λ * ((H - 1 : ℕ) : ℝ) - rowW w H) / ((r : ℝ) * s) := by
  have hrr : (r : ℝ) ≠ 0 := by exact_mod_cast hr.ne'
  have hsr : (s : ℝ) ≠ 0 := by exact_mod_cast hs.ne'
  unfold rowDisc psiR
  rw [oriel_rowMass_left hw hs, floor_natCast_div]
  field_simp
  ring

/-- Identity II, fixed `s`. -/
theorem oriel_rowDisc_right {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {H : ℕ}
    (hw : ∀ y, 0 < y → y < H → w y = Λ (y : ZMod P)) {r s : ℕ} (hr : 0 < r) (hs : 0 < s) :
    rowDisc w H r s =
      psiR s H Λ 0 1 (r : ZMod P) (r : ZMod s) (((H - 1 : ℕ) : ℝ) / r) +
        (muL Λ * ((H - 1 : ℕ) : ℝ) - rowW w H) / ((r : ℝ) * s) := by
  have hrr : (r : ℝ) ≠ 0 := by exact_mod_cast hr.ne'
  have hsr : (s : ℝ) ≠ 0 := by exact_mod_cast hs.ne'
  unfold rowDisc psiR
  rw [oriel_rowMass_right hw hr, floor_natCast_div]
  field_simp
  ring

/-- Centering defect `|μ(H-1) - W| ≤ (2P+1) B`. -/
theorem oriel_centering {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {H : ℕ}
    (hw : ∀ y, 0 < y → y < H → w y = Λ (y : ZMod P)) {B : ℝ} (hB : ∀ z, |Λ z| ≤ B) :
    |muL Λ * ((H - 1 : ℕ) : ℝ) - rowW w H| ≤ (2 * P + 1) * B := by
  have hP0 : 0 < P := NeZero.pos P
  have hW : rowW w H = ∑ u ∈ Icc 1 ⌊((H - 1 : ℕ) : ℝ)⌋₊, Λ (u : ZMod P) := by
    rw [Nat.floor_natCast]
    unfold rowW
    have : Ioo 0 H = Icc 1 (H - 1) := by ext u; simp only [mem_Ioo, mem_Icc]; omega
    rw [this]
    apply sum_congr rfl
    intro u hu; rw [mem_Icc] at hu
    exact hw u (by omega) (by omega)
  have hper : ∀ n, (fun u : ℕ => Λ (u : ZMod P)) (n + P) = Λ (n : ZMod P) := by
    intro n; simp [ZMod.natCast_self]
  have := oriel_periodic_partial_sum hP0 hper (fun n => hB _) (Nat.cast_nonneg (H - 1))
  rw [oriel_sum_range_zmod (fun z => Λ z)] at this
  rw [hW, abs_sub_comm]
  unfold muL
  exact this

end OrielUpper
