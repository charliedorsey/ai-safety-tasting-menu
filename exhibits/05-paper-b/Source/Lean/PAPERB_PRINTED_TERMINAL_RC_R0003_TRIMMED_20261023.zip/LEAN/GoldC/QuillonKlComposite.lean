import Mathlib.NumberTheory.LegendreSymbol.AddCharacter
import Mathlib.Analysis.SpecialFunctions.Complex.CircleAddChar
import Mathlib.Data.ZMod.Units
import GoldC.QuillonKloosterman
import Mathlib.Tactic

/-!
# Quillon CSC3 F1b: twisted multiplicativity of Kloosterman sums (CRT)

`K_s(a,b) = Σ_{x ∈ (ℤ/s)ˣ} e((a x + b x⁻¹)/s)`, with `e(·/s) = ZMod.stdAddChar`.

* `stdAddChar_crt`: for coprime `m, n ≥ 1` and `z : ZMod (m n)`,
  `e(z/(mn)) = e(z·n̄/m) · e(z·m̄/n)`.
* `K_mul`: `K_{mn}(a,b) = K_m(a n̄, b n̄) · K_n(a m̄, b m̄)`. The residues of `a, b` are taken by cast.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonKl

/-- Kloosterman sum over the units of `ZMod s`. -/
noncomputable def K (s : ℕ) [NeZero s] (a b : ZMod s) : ℂ :=
  ∑ x : (ZMod s)ˣ, ZMod.stdAddChar (a * (x : ZMod s) + b * ((x⁻¹ : (ZMod s)ˣ) : ZMod s))

lemma crt_unit_sum {m n : ℕ} [NeZero m] [NeZero n] (h : m.Coprime n) :
    ∃ k : ℤ, ((n * ((n : ZMod m)⁻¹).val + m * ((m : ZMod n)⁻¹).val : ℕ) : ℤ) = 1 + m * n * k := by
  set n' := ((n : ZMod m)⁻¹).val
  set m' := ((m : ZMod n)⁻¹).val
  have hmn : 0 < m * n := Nat.mul_pos (Nat.pos_of_ne_zero (NeZero.ne m))
    (Nat.pos_of_ne_zero (NeZero.ne n))
  rcases Nat.lt_or_ge 1 (m * n) with hlt | hle
  · have h1 : n * n' + m * m' ≡ 1 [MOD m] := by
      rw [← ZMod.natCast_eq_natCast_iff]
      push_cast
      rw [ZMod.natCast_self, zero_mul, add_zero, ZMod.natCast_val, ZMod.cast_id', id,
        ZMod.coe_mul_inv_eq_one n h.symm]
    have h2 : n * n' + m * m' ≡ 1 [MOD n] := by
      rw [← ZMod.natCast_eq_natCast_iff]
      push_cast
      rw [ZMod.natCast_self, zero_mul, zero_add, ZMod.natCast_val, ZMod.cast_id', id,
        ZMod.coe_mul_inv_eq_one m h]
    have h3 : n * n' + m * m' ≡ 1 [MOD m * n] :=
      (Nat.modEq_and_modEq_iff_modEq_mul h).1 ⟨h1, h2⟩
    refine ⟨((n * n' + m * m') / (m * n) : ℕ), ?_⟩
    have := Nat.div_add_mod (n * n' + m * m') (m * n)
    unfold Nat.ModEq at h3
    rw [h3, Nat.mod_eq_of_lt hlt] at this
    have : ((n * n' + m * m' : ℕ) : ℤ) = ((m * n * ((n * n' + m * m') / (m * n)) + 1 : ℕ) : ℤ) := by
      rw [this]
    rw [this]; push_cast; ring
  · have h11 : m * n = 1 := by omega
    have hm1 : m = 1 := Nat.eq_one_of_mul_eq_one_right h11
    have hn1 : n = 1 := Nat.eq_one_of_mul_eq_one_left h11
    subst hm1; subst hn1
    have hn' : n' = 0 := Nat.lt_one_iff.mp (ZMod.val_lt _)
    have hm' : m' = 0 := Nat.lt_one_iff.mp (ZMod.val_lt _)
    refine ⟨-1, ?_⟩
    rw [hn', hm']; norm_num

/-- The standard character factors through CRT. -/
theorem stdAddChar_crt {m n : ℕ} [NeZero m] [NeZero n] (h : m.Coprime n) (z : ZMod (m * n)) :
    haveI : NeZero (m * n) := ⟨Nat.mul_ne_zero (NeZero.ne m) (NeZero.ne n)⟩
    ZMod.stdAddChar z =
      ZMod.stdAddChar ((ZMod.castHom (dvd_mul_right m n) (ZMod m) z) * (n : ZMod m)⁻¹) *
      ZMod.stdAddChar ((ZMod.castHom (dvd_mul_left n m) (ZMod n) z) * (m : ZMod n)⁻¹) := by
  haveI : NeZero (m * n) := ⟨Nat.mul_ne_zero (NeZero.ne m) (NeZero.ne n)⟩
  obtain ⟨k, hk⟩ := crt_unit_sum (m := m) (n := n) h
  set n' := ((n : ZMod m)⁻¹).val
  set m' := ((m : ZMod n)⁻¹).val
  set v := z.val
  have hz : z = ((v : ℤ) : ZMod (m * n)) := by simp [v]
  have h1 : (ZMod.castHom (dvd_mul_right m n) (ZMod m) z) * (n : ZMod m)⁻¹ =
      (((v * n' : ℕ) : ℤ) : ZMod m) := by
    rw [hz]; simp [n']
  have h2 : (ZMod.castHom (dvd_mul_left n m) (ZMod n) z) * (m : ZMod n)⁻¹ =
      (((v * m' : ℕ) : ℤ) : ZMod n) := by
    rw [hz]; simp [m']
  rw [h1, h2, hz, ZMod.stdAddChar_coe, ZMod.stdAddChar_coe, ZMod.stdAddChar_coe,
    ← Complex.exp_add]
  -- exponent difference is 2πi·(v k)
  have hmR : (m : ℂ) ≠ 0 := by exact_mod_cast NeZero.ne m
  have hnR : (n : ℂ) ≠ 0 := by exact_mod_cast NeZero.ne n
  have hkC : (n : ℂ) * n' + (m : ℂ) * m' = 1 + (m : ℂ) * n * k := by
    have := congrArg (fun t : ℤ => (t : ℂ)) hk
    push_cast at this; exact this
  have key : 2 * (Real.pi : ℂ) * Complex.I * (((v * n' : ℕ) : ℤ) : ℂ) / (m : ℂ) +
      2 * (Real.pi : ℂ) * Complex.I * (((v * m' : ℕ) : ℤ) : ℂ) / (n : ℂ) =
      2 * (Real.pi : ℂ) * Complex.I * (((v : ℕ) : ℤ) : ℂ) / ((m * n : ℕ) : ℂ) +
        ((v : ℤ) * k : ℤ) * (2 * Real.pi * Complex.I) := by
    push_cast
    calc 2 * (Real.pi : ℂ) * Complex.I * ((v : ℂ) * n') / m +
          2 * (Real.pi : ℂ) * Complex.I * ((v : ℂ) * m') / n
        = 2 * (Real.pi : ℂ) * Complex.I * v * ((n : ℂ) * n' + (m : ℂ) * m') / ((m : ℂ) * n) := by
          field_simp; try ring
      _ = 2 * (Real.pi : ℂ) * Complex.I * v * (1 + (m : ℂ) * n * k) / ((m : ℂ) * n) := by
          rw [hkC]
      _ = _ := by field_simp; try ring
  rw [key, Complex.exp_add, Complex.exp_int_mul_two_pi_mul_I, mul_one]

/-- **Twisted multiplicativity.** -/
theorem K_mul {m n : ℕ} [NeZero m] [NeZero n] (h : m.Coprime n) (a b : ZMod (m * n)) :
    haveI : NeZero (m * n) := ⟨Nat.mul_ne_zero (NeZero.ne m) (NeZero.ne n)⟩
    K (m * n) a b =
      K m (ZMod.castHom (dvd_mul_right m n) (ZMod m) a * (n : ZMod m)⁻¹)
          (ZMod.castHom (dvd_mul_right m n) (ZMod m) b * (n : ZMod m)⁻¹) *
        K n (ZMod.castHom (dvd_mul_left n m) (ZMod n) a * (m : ZMod n)⁻¹)
          (ZMod.castHom (dvd_mul_left n m) (ZMod n) b * (m : ZMod n)⁻¹) := by
  haveI : NeZero (m * n) := ⟨Nat.mul_ne_zero (NeZero.ne m) (NeZero.ne n)⟩
  set f₁ := ZMod.castHom (dvd_mul_right m n) (ZMod m)
  set f₂ := ZMod.castHom (dvd_mul_left n m) (ZMod n)
  -- the unit equivalence
  let E : (ZMod (m * n))ˣ ≃ (ZMod m)ˣ × (ZMod n)ˣ :=
    ((Units.mapEquiv (ZMod.chineseRemainder h).toMulEquiv).trans MulEquiv.prodUnits).toEquiv
  have hE1 : ∀ x : (ZMod (m * n))ˣ, ((E x).1 : ZMod m) = f₁ (x : ZMod (m * n)) := by
    intro x; simp [E, f₁, ZMod.chineseRemainder, MulEquiv.prodUnits, ZMod.castHom_apply]
  have hE2 : ∀ x : (ZMod (m * n))ˣ, ((E x).2 : ZMod n) = f₂ (x : ZMod (m * n)) := by
    intro x; simp [E, f₂, ZMod.chineseRemainder, MulEquiv.prodUnits, ZMod.castHom_apply]
  unfold K
  rw [← Equiv.sum_comp E.symm, Fintype.sum_prod_type, Finset.sum_mul_sum]
  refine Finset.sum_congr rfl fun x₁ _ => Finset.sum_congr rfl fun x₂ _ => ?_
  set y := E.symm (x₁, x₂)
  have hy : E y = (x₁, x₂) := by simp [y]
  have hy1 : (x₁ : ZMod m) = f₁ (y : ZMod (m * n)) := by rw [← hE1, hy]
  have hy2 : (x₂ : ZMod n) = f₂ (y : ZMod (m * n)) := by rw [← hE2, hy]
  have hyi1 : ((x₁⁻¹ : (ZMod m)ˣ) : ZMod m) = f₁ ((y⁻¹ : (ZMod (m * n))ˣ) : ZMod (m * n)) := by
    have : f₁ ((y⁻¹ : (ZMod (m * n))ˣ) : ZMod (m * n)) * f₁ (y : ZMod (m * n)) = 1 := by
      rw [← map_mul, Units.inv_mul, map_one]
    calc ((x₁⁻¹ : (ZMod m)ˣ) : ZMod m)
        = ((x₁⁻¹ : (ZMod m)ˣ) : ZMod m) * (f₁ ((y⁻¹ : (ZMod (m * n))ˣ) : ZMod (m * n)) *
            f₁ (y : ZMod (m * n))) := by rw [this, mul_one]
      _ = f₁ ((y⁻¹ : (ZMod (m * n))ˣ) : ZMod (m * n)) *
            (((x₁⁻¹ : (ZMod m)ˣ) : ZMod m) * (x₁ : ZMod m)) := by rw [hy1]; ring
      _ = _ := by rw [Units.inv_mul, mul_one]
  have hyi2 : ((x₂⁻¹ : (ZMod n)ˣ) : ZMod n) = f₂ ((y⁻¹ : (ZMod (m * n))ˣ) : ZMod (m * n)) := by
    have : f₂ ((y⁻¹ : (ZMod (m * n))ˣ) : ZMod (m * n)) * f₂ (y : ZMod (m * n)) = 1 := by
      rw [← map_mul, Units.inv_mul, map_one]
    calc ((x₂⁻¹ : (ZMod n)ˣ) : ZMod n)
        = ((x₂⁻¹ : (ZMod n)ˣ) : ZMod n) * (f₂ ((y⁻¹ : (ZMod (m * n))ˣ) : ZMod (m * n)) *
            f₂ (y : ZMod (m * n))) := by rw [this, mul_one]
      _ = f₂ ((y⁻¹ : (ZMod (m * n))ˣ) : ZMod (m * n)) *
            (((x₂⁻¹ : (ZMod n)ˣ) : ZMod n) * (x₂ : ZMod n)) := by rw [hy2]; ring
      _ = _ := by rw [Units.inv_mul, mul_one]
  rw [stdAddChar_crt h, hy1, hy2, hyi1, hyi2]
  congr 1
  · congr 1; simp only [map_add, map_mul]; ring
  · congr 1; simp only [map_add, map_mul]; ring


/-! ## Prime moduli: link to `QuillonKloosterman` and the pointwise bound -/

/-- Over a prime field, the units sum is the nonzero-element sum. -/
lemma K_prime_eq_kl (p : ℕ) [Fact p.Prime] (a b : ZMod p) :
    K p a b = GoldC.QuillonKloosterman.kl ZMod.stdAddChar a b := by
  unfold K GoldC.QuillonKloosterman.kl
  refine Finset.sum_bij' (fun x _ => (x : ZMod p))
    (fun y hy => Units.mk0 y (Finset.ne_of_mem_erase hy)) ?_ ?_ ?_ ?_ ?_
  · intro x _; exact Finset.mem_erase.2 ⟨x.ne_zero, Finset.mem_univ _⟩
  · intro y _; exact Finset.mem_univ _
  · intro x _; exact Units.mk0_val x _
  · intro y _; rfl
  · intro x _; rw [Units.val_inv_eq_inv_val]

lemma norm_K_le_card (s : ℕ) [NeZero s] (a b : ZMod s) : ‖K s a b‖ ≤ s := by
  unfold K
  refine (norm_sum_le _ _).trans ?_
  have h1 : ∀ x : (ZMod s)ˣ, ‖ZMod.stdAddChar (a * (x : ZMod s) +
      b * ((x⁻¹ : (ZMod s)ˣ) : ZMod s))‖ = 1 := fun x =>
    by simp [ZMod.stdAddChar_apply]
  rw [Finset.sum_congr rfl fun x _ => h1 x, Finset.sum_const, Finset.card_univ, nsmul_eq_mul,
    mul_one]
  have : Fintype.card (ZMod s)ˣ ≤ s := by
    rw [ZMod.card_units_eq_totient]; exact Nat.totient_le s
  exact_mod_cast this

/-- **Prime bound**: `‖K_p(a,b)‖⁴ ≤ 3p³·(p if a = 0 else 1)`. -/
theorem K_prime_bound (p : ℕ) [hp : Fact p.Prime] (a b : ZMod p) :
    ‖K p a b‖ ^ 4 ≤ 3 * (p : ℝ) ^ 3 * (if a = 0 then (p : ℝ) else 1) := by
  have hp2 : (2 : ℝ) ≤ p := by exact_mod_cast hp.out.two_le
  split_ifs with ha
  · have := norm_K_le_card p a b
    calc ‖K p a b‖ ^ 4 ≤ (p : ℝ) ^ 4 := by gcongr
      _ ≤ 3 * (p : ℝ) ^ 3 * p := by nlinarith [pow_pos (show (0:ℝ) < p by linarith) 3]
  · rw [K_prime_eq_kl]
    have hscale := GoldC.QuillonKloosterman.kl_scale ZMod.stdAddChar a (a * b) ha
    rw [show a * b * a⁻¹ = b by field_simp] at hscale
    rw [hscale]
    have hb := GoldC.QuillonKloosterman.kloosterman_bound (F := ZMod p) ZMod.stdAddChar
      (ZMod.isPrimitive_stdAddChar p) (a * b)
    rw [ZMod.card] at hb
    calc _ ≤ 3 * (p : ℝ) ^ 2 * ((p : ℝ) - 1) := hb
      _ ≤ 3 * (p : ℝ) ^ 3 * 1 := by nlinarith [sq_nonneg (p : ℝ)]

/-- Casting through an intermediate modulus. -/
lemma cast_cast_dvd {q m n : ℕ} [NeZero n] [NeZero m] (hqm : q ∣ m) (hmn : m ∣ n) (a : ZMod n) :
    (ZMod.cast (ZMod.cast a : ZMod m) : ZMod q) = (ZMod.cast a : ZMod q) := by
  have := ZMod.castHom_comp hqm hmn
  have h2 := congrArg (fun f => f a) this
  simpa only [RingHom.comp_apply, ZMod.castHom_apply] using h2

/-- **Squarefree bound** (by CRT induction): for `s = ∏_{p∈P} p` with distinct primes,
`‖K_s(a,b)‖⁴ ≤ ∏_{p∈P} 3p³·(p if p ∣ a else 1)`. -/
theorem K_squarefree_bound (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) :
    ∀ (s : ℕ) (hs : s = ∏ p ∈ P, p) [NeZero s] (a b : ZMod s),
      ‖K s a b‖ ^ 4 ≤ ∏ p ∈ P,
        (3 * (p : ℝ) ^ 3 * (if (ZMod.cast a : ZMod p) = 0 then (p : ℝ) else 1)) := by
  induction P using Finset.induction_on with
  | empty =>
    intro s hs _ a b
    simp only [Finset.prod_empty] at hs ⊢
    subst hs
    have := norm_K_le_card 1 a b
    have h0 : (0 : ℝ) ≤ ‖K 1 a b‖ := norm_nonneg _
    push_cast at this
    calc ‖K 1 a b‖ ^ 4 ≤ 1 ^ 4 := by gcongr
      _ = 1 := by norm_num
  | insert p P' hpP' ih =>
    intro s hs _ a b
    have hp : p.Prime := hP p (Finset.mem_insert_self _ _)
    have hP' : ∀ q ∈ P', q.Prime := fun q hq => hP q (Finset.mem_insert_of_mem hq)
    rw [Finset.prod_insert hpP'] at hs
    set s' := ∏ q ∈ P', q with hs'
    have hs'0 : s' ≠ 0 := Finset.prod_ne_zero_iff.2 fun q hq => (hP' q hq).ne_zero
    haveI : NeZero s' := ⟨hs'0⟩
    haveI : NeZero p := ⟨hp.ne_zero⟩
    haveI : Fact p.Prime := ⟨hp⟩
    have hcop : p.Coprime s' := by
      rw [hs']
      refine Nat.Coprime.prod_right fun q hq => ?_
      rw [Nat.coprime_primes hp (hP' q hq)]
      exact fun h => hpP' (h ▸ hq)
    subst hs
    rw [K_mul hcop, norm_mul, mul_pow, Finset.prod_insert hpP']
    have h0 : 0 ≤ ‖K p (ZMod.castHom (dvd_mul_right p s') (ZMod p) a * (s' : ZMod p)⁻¹)
        (ZMod.castHom (dvd_mul_right p s') (ZMod p) b * (s' : ZMod p)⁻¹)‖ ^ 4 := by positivity
    gcongr
    · -- prime factor
      refine (K_prime_bound p _ _).trans (le_of_eq ?_)
      congr 2
      have hu : (s' : ZMod p) * (s' : ZMod p)⁻¹ = 1 := ZMod.coe_mul_inv_eq_one s' hcop.symm
      apply propext
      rw [ZMod.castHom_apply]
      constructor
      · intro h
        have := congrArg (· * (s' : ZMod p)) h
        simp only [zero_mul] at this
        rwa [mul_assoc, mul_comm _ (s' : ZMod p), hu, mul_one] at this
      · intro h; rw [h, zero_mul]
    · -- the cofactor, by induction
      refine (ih hP' s' hs' _ _).trans (le_of_eq ?_)
      refine Finset.prod_congr rfl fun q hq => ?_
      have hq : q.Prime := hP' q hq
      haveI : NeZero q := ⟨hq.ne_zero⟩
      have hqs' : q ∣ s' := Finset.dvd_prod_of_mem _ (by assumption)
      have hqp : q.Coprime p := by
        rw [Nat.coprime_primes hq hp]; intro h; exact hpP' (h ▸ by assumption)
      congr 2
      apply propext
      rw [ZMod.castHom_apply, ZMod.cast_mul hqs', cast_cast_dvd hqs' (dvd_mul_left s' p)]
      have hu : (p : ZMod s') * (p : ZMod s')⁻¹ = 1 := ZMod.coe_mul_inv_eq_one p hcop
      have hu' : (p : ZMod q) * (ZMod.cast ((p : ZMod s')⁻¹) : ZMod q) = 1 := by
        have := congrArg (fun x : ZMod s' => (ZMod.cast x : ZMod q)) hu
        simp only [ZMod.cast_mul hqs', ZMod.cast_natCast hqs'] at this
        rw [this, ZMod.cast_one hqs']
      constructor
      · intro h
        have := congrArg ((p : ZMod q) * ·) h
        simp only [mul_zero] at this
        rwa [mul_comm, mul_assoc, mul_comm _ (p : ZMod q), hu', mul_one] at this
      · intro h; rw [h, zero_mul]

end GoldC.QuillonKl

#print axioms GoldC.QuillonKl.stdAddChar_crt
#print axioms GoldC.QuillonKl.K_mul
#print axioms GoldC.QuillonKl.K_prime_bound
#print axioms GoldC.QuillonKl.K_squarefree_bound
