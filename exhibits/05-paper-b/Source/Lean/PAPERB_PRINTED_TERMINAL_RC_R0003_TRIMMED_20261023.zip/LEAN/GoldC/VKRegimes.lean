import GoldC.VKCore
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds

/-!
# `GoldC.VKRegimes` — every Type I regime, conditional only on the uniform Vinogradov estimate

Mathlib-only.  **No axiom, no `sorry`.**

* `kusmin_landau_discrete` (**proved, unconditional**): if `z_{i+1} = z_i e(Δ_i)`, `|z_i| = 1`,
  `λ ≤ Δ_i ≤ 1 - λ` and `Δ` is nondecreasing, then `|Σ_{i ≤ m} z_i| ≤ 2 + 3/(2λ)`.
* `recipSum_small_T` (**proved, unconditional**): for the reciprocal phase in the window
  `x+θ ∈ [L, 2L]` with `0 < T ≤ L/2`: `|Σ e(TL/(x+θ))| ≤ 8L/T`.  (The Kusmin–Landau regime,
  derived from exact difference algebra; no mean value theorem.)
* `recipSum_all_regimes` (**conditional only on `UniformVinogradovEstimate`**): for every `A`,
  all large `L`, all `T > 0` (with `log L ≥ (log T)^σ` when `T ≥ L`):
  `|Σ e(TL/(x+θ))| ≤ L (log L)^{-A} + 8L/T`.
* `typeI_class_sum_all_regimes`: the same with the harmonic weights `1/(Q(j+θ))`.
-/

open scoped BigOperators
open Real Filter Topology Finset

namespace GoldC.VK

lemma eAdd_add (x y : ℝ) : eAdd (x + y) = eAdd x * eAdd y := by
  unfold eAdd; push_cast; rw [← Complex.exp_add]; ring_nf

lemma eAdd_int (m : ℤ) : eAdd m = 1 := by
  unfold eAdd
  have : 2 * (Real.pi : ℂ) * Complex.I * ((m : ℝ) : ℂ) = (m : ℂ) * (2 * Real.pi * Complex.I) := by
    push_cast; ring
  rw [this, Complex.exp_int_mul_two_pi_mul_I]

lemma eAdd_nat (m : ℕ) : eAdd m = 1 := by exact_mod_cast eAdd_int m

/-! ## The Kusmin–Landau coefficient -/

/-- `1/(e(Δ) - 1) = -1/2 - (i/2) cot(πΔ)` for `0 < Δ < 1`. -/
lemma inv_eAdd_sub_one {Δ : ℝ} (h0 : 0 < Δ) (h1 : Δ < 1) :
    (eAdd Δ - 1)⁻¹ = -(1 / 2 : ℂ) - Complex.I / 2 *
      ((Real.cos (π * Δ) / Real.sin (π * Δ) : ℝ) : ℂ) := by
  have hs : 0 < Real.sin (π * Δ) :=
    Real.sin_pos_of_pos_of_lt_pi (mul_pos Real.pi_pos h0) (by nlinarith [Real.pi_pos])
  have he : eAdd Δ = ((Real.cos (2 * (π * Δ)) : ℝ) : ℂ) +
      ((Real.sin (2 * (π * Δ)) : ℝ) : ℂ) * Complex.I := by
    unfold eAdd
    have : 2 * (Real.pi : ℂ) * Complex.I * ((Δ : ℝ) : ℂ) = ((2 * (π * Δ) : ℝ) : ℂ) * Complex.I := by
      push_cast; ring
    rw [this, Complex.exp_mul_I, ← Complex.ofReal_cos, ← Complex.ofReal_sin]
  apply inv_eq_of_mul_eq_one_left
  rw [he, Real.cos_two_mul', Real.sin_two_mul]
  set s := Real.sin (π * Δ)
  set c := Real.cos (π * Δ)
  have hsc : s ^ 2 + c ^ 2 = 1 := Real.sin_sq_add_cos_sq _
  have hs0 : (s : ℂ) ≠ 0 := by exact_mod_cast hs.ne'
  push_cast
  field_simp
  have hsc' : (s : ℂ) ^ 2 + (c : ℂ) ^ 2 = 1 := by exact_mod_cast hsc
  linear_combination ((s : ℂ) - Complex.I * (c : ℂ)) * hsc' +
    (-2 * (s : ℂ) * (c : ℂ) ^ 2) * Complex.I_sq

/-- `cot(πΔ)` is nonincreasing on `(0,1)`. -/
lemma cot_pi_antitone {x y : ℝ} (hx : 0 < x) (hxy : x ≤ y) (hy : y < 1) :
    Real.cos (π * y) / Real.sin (π * y) ≤ Real.cos (π * x) / Real.sin (π * x) := by
  have hsx : 0 < Real.sin (π * x) :=
    Real.sin_pos_of_pos_of_lt_pi (mul_pos Real.pi_pos hx) (by nlinarith [Real.pi_pos])
  have hsy : 0 < Real.sin (π * y) :=
    Real.sin_pos_of_pos_of_lt_pi (mul_pos Real.pi_pos (by linarith)) (by nlinarith [Real.pi_pos])
  rw [div_le_div_iff₀ hsy hsx]
  have hd : 0 ≤ Real.sin (π * y - π * x) :=
    Real.sin_nonneg_of_nonneg_of_le_pi (by nlinarith [Real.pi_pos]) (by nlinarith [Real.pi_pos])
  rw [Real.sin_sub] at hd
  linarith

/-- `sin(πΔ) ≥ 2λ` when `λ ≤ Δ ≤ 1 - λ`, `0 < λ ≤ 1/2`. -/
lemma sin_pi_ge {lam Δ : ℝ} (hl : 0 < lam) (hΔ0 : lam ≤ Δ) (hΔ1 : Δ ≤ 1 - lam) :
    2 * lam ≤ Real.sin (π * Δ) := by
  rcases le_total Δ (1 / 2) with h | h
  · have := Real.mul_le_sin (x := π * Δ) (by nlinarith [Real.pi_pos]) (by nlinarith [Real.pi_pos])
    have e : 2 / π * (π * Δ) = 2 * Δ := by field_simp
    rw [e] at this; linarith
  · have hsym : Real.sin (π * Δ) = Real.sin (π * (1 - Δ)) := by
      rw [show π * (1 - Δ) = π - π * Δ by ring, Real.sin_pi_sub]
    have := Real.mul_le_sin (x := π * (1 - Δ)) (by nlinarith [Real.pi_pos])
      (by nlinarith [Real.pi_pos])
    have e : 2 / π * (π * (1 - Δ)) = 2 * (1 - Δ) := by field_simp
    rw [e] at this; rw [hsym]; linarith

/-- Summation by parts with `Z 0 = 0`. -/
lemma sum_by_parts_zero (c Z : ℕ → ℂ) (hZ : Z 0 = 0) (m : ℕ) :
    ∑ i ∈ range (m + 1), c i * (Z (i + 1) - Z i) =
      c m * Z (m + 1) - ∑ i ∈ range m, (c (i + 1) - c i) * Z (i + 1) := by
  induction m with
  | zero => simp [hZ]
  | succ m ih =>
    rw [sum_range_succ, ih, sum_range_succ]
    ring

/-- **Discrete Kusmin–Landau.** -/
theorem kusmin_landau_discrete {z : ℕ → ℂ} {Δ : ℕ → ℝ} {lam : ℝ} (m : ℕ)
    (hl : 0 < lam) (hl2 : lam ≤ 1 / 2)
    (hz : ∀ i, ‖z i‖ = 1)
    (hstep : ∀ i < m, z (i + 1) = z i * eAdd (Δ i))
    (hΔ : ∀ i < m, lam ≤ Δ i ∧ Δ i ≤ 1 - lam)
    (hmono : ∀ i, i + 1 < m → Δ i ≤ Δ (i + 1)) :
    ‖∑ i ∈ range (m + 1), z i‖ ≤ 2 + 3 / (2 * lam) := by
  rcases Nat.eq_zero_or_pos m with rfl | hm
  · simp [hz]
    have : 0 ≤ 3 / (2 * lam) := div_nonneg (by norm_num) (by linarith)
    linarith
  obtain ⟨m', rfl⟩ : ∃ m', m = m' + 1 := ⟨m - 1, by omega⟩
  -- coefficients
  set ct : ℕ → ℝ := fun i => Real.cos (π * Δ i) / Real.sin (π * Δ i) with hct
  set c : ℕ → ℂ := fun i => (eAdd (Δ i) - 1)⁻¹ with hc
  have hΔ01 : ∀ i < m' + 1, 0 < Δ i ∧ Δ i < 1 := fun i hi =>
    ⟨lt_of_lt_of_le hl (hΔ i hi).1, by linarith [(hΔ i hi).2]⟩
  have hcform : ∀ i < m' + 1, c i = -(1 / 2 : ℂ) - Complex.I / 2 * (ct i : ℂ) := fun i hi =>
    inv_eAdd_sub_one (hΔ01 i hi).1 (hΔ01 i hi).2
  have hsin : ∀ i < m' + 1, 2 * lam ≤ Real.sin (π * Δ i) := fun i hi =>
    sin_pi_ge hl (hΔ i hi).1 (hΔ i hi).2
  have hspos : ∀ i < m' + 1, 0 < Real.sin (π * Δ i) := fun i hi =>
    lt_of_lt_of_le (by linarith) (hsin i hi)
  -- |cot| ≤ 1/sin ≤ 1/(2λ)
  have hct_abs : ∀ i < m' + 1, |ct i| ≤ 1 / (2 * lam) := by
    intro i hi
    simp only [hct]
    rw [abs_div, abs_of_pos (hspos i hi), div_le_div_iff₀ (hspos i hi) (by linarith)]
    have := Real.abs_cos_le_one (π * Δ i)
    nlinarith [hsin i hi]
  -- |c_i| = 1/(2 sin) ≤ 1/(4λ)... we only need ≤ 1/(2λ) crude: |c| ≤ 1/2 + |ct|/2
  have hc_abs : ∀ i < m' + 1, ‖c i‖ ≤ 1 / 2 + 1 / (4 * lam) := by
    intro i hi
    rw [hcform i hi]
    calc ‖-(1 / 2 : ℂ) - Complex.I / 2 * (ct i : ℂ)‖ ≤ ‖-(1 / 2 : ℂ)‖ + ‖Complex.I / 2 * (ct i : ℂ)‖ :=
          norm_sub_le _ _
      _ = 1 / 2 + |ct i| / 2 := by
          have e1 : ‖-(1 / 2 : ℂ)‖ = 1 / 2 := by
            rw [norm_neg, norm_div, norm_one, Complex.norm_two]
          have e2 : ‖Complex.I / 2 * ((ct i : ℝ) : ℂ)‖ = |ct i| / 2 := by
            rw [norm_mul, norm_div, Complex.norm_I, Complex.norm_two, Complex.norm_real,
              Real.norm_eq_abs]
            ring
          rw [e1, e2]
      _ ≤ 1 / 2 + 1 / (4 * lam) := by
          have := hct_abs i hi
          have e : 1 / (2 * lam) / 2 = 1 / (4 * lam) := by field_simp; ring
          linarith
  -- z_i = c_i (z_{i+1} - z_i)
  have hzc : ∀ i < m' + 1, z i = c i * (z (i + 1) - z i) := by
    intro i hi
    have hne : eAdd (Δ i) - 1 ≠ 0 := by
      intro h0
      have : c i = 0 := by simp only [hc]; rw [h0, inv_zero]
      rw [hcform i hi] at this
      have hre := congrArg Complex.re this
      simp at hre
    rw [hstep i hi]
    simp only [hc]
    field_simp
  -- Z_k = z_k - z_0
  set Z : ℕ → ℂ := fun k => z k - z 0 with hZ
  have hsum : ∑ i ∈ range (m' + 1), z i = ∑ i ∈ range (m' + 1), c i * (Z (i + 1) - Z i) := by
    refine sum_congr rfl fun i hi => ?_
    rw [hzc i (mem_range.1 hi)]
    simp only [hZ]; ring
  have hparts := sum_by_parts_zero c Z (by simp [hZ]) m'
  have hZn : ∀ k, ‖Z k‖ ≤ 2 := by
    intro k
    calc ‖z k - z 0‖ ≤ ‖z k‖ + ‖z 0‖ := norm_sub_le _ _
      _ = 2 := by rw [hz, hz]; norm_num
  -- differences of c are purely imaginary: c_{i+1} - c_i = -(I/2)(ct_{i+1} - ct_i)
  have hdiff : ∀ i < m', ‖c (i + 1) - c i‖ = (ct i - ct (i + 1)) / 2 := by
    intro i hi
    rw [hcform (i + 1) (by omega), hcform i (by omega)]
    have hmon : ct (i + 1) ≤ ct i := by
      simp only [hct]
      exact cot_pi_antitone (hΔ01 i (by omega)).1 (hmono i (by omega)) (hΔ01 (i + 1) (by omega)).2
    have e : -(1 / 2 : ℂ) - Complex.I / 2 * (ct (i + 1) : ℂ) -
        (-(1 / 2 : ℂ) - Complex.I / 2 * (ct i : ℂ)) = Complex.I / 2 * ((ct i - ct (i + 1) : ℝ) : ℂ) := by
      push_cast; ring
    rw [e, norm_mul, norm_div, Complex.norm_I, Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (by linarith)]
    norm_num; ring
  have htel : ∀ k ≤ m', ∑ i ∈ range k, (ct i - ct (i + 1)) / 2 = (ct 0 - ct k) / 2 := by
    intro k hk
    induction k with
    | zero => simp
    | succ k ih => rw [sum_range_succ, ih (by omega)]; ring
  have hlast : ‖z (m' + 1)‖ = 1 := hz _
  rw [sum_range_succ, hsum, hparts]
  calc ‖c m' * Z (m' + 1) - ∑ i ∈ range m', (c (i + 1) - c i) * Z (i + 1) + z (m' + 1)‖
      ≤ ‖c m' * Z (m' + 1)‖ + ‖∑ i ∈ range m', (c (i + 1) - c i) * Z (i + 1)‖ + ‖z (m' + 1)‖ := by
        refine (norm_add_le _ _).trans ?_
        gcongr
        exact norm_sub_le _ _
    _ ≤ (1 / 2 + 1 / (4 * lam)) * 2 + (∑ i ∈ range m', (ct i - ct (i + 1)) / 2) * 2 + 1 := by
        gcongr
        · rw [norm_mul]
          exact mul_le_mul (hc_abs m' (by omega)) (hZn _) (norm_nonneg _)
            (add_nonneg (by norm_num) (div_nonneg (by norm_num) (by linarith)))
        · rw [sum_mul]
          refine (norm_sum_le _ _).trans (sum_le_sum fun i hi => ?_)
          rw [norm_mul, hdiff i (mem_range.1 hi)]
          have hnn : 0 ≤ (ct i - ct (i + 1)) / 2 := by
            rw [← hdiff i (mem_range.1 hi)]; exact norm_nonneg _
          exact mul_le_mul_of_nonneg_left (hZn _) hnn
        · exact hlast.le
    _ = (1 / 2 + 1 / (4 * lam)) * 2 + (ct 0 - ct m') + 1 := by
        rw [htel m' le_rfl]; ring
    _ ≤ 2 + 3 / (2 * lam) := by
        have h0 := hct_abs 0 (by omega)
        have hm := hct_abs m' (by omega)
        have e1 : 1 / (4 * lam) * 2 = 1 / (2 * lam) := by field_simp; ring
        have e2 : 3 / (2 * lam) = 1 / (2 * lam) + 2 * (1 / (2 * lam)) := by ring
        have hl1 : 1 ≤ 1 / (2 * lam) := by rw [le_div_iff₀ (by linarith)]; linarith
        rw [abs_le] at h0 hm
        nlinarith

/-! ## Small `T`: the reciprocal phase in the Kusmin–Landau regime (unconditional) -/

/-- **Small-`T` regime, unconditional.** In the window `x + θ ∈ [L, 2L]` with `0 < T ≤ L/2`:
`|Σ e(TL/(x+θ))| ≤ 8L/T`. -/
theorem recipSum_small_T {L T θ : ℝ} (a : ℤ) (n : ℕ) (hL : 0 < L) (hT : 0 < T)
    (hTL : T ≤ L / 2) (hwin : ∀ x ∈ runIcc a n, L ≤ x + θ ∧ x + θ ≤ 2 * L) :
    ‖expSum (recipPhase (T * L) θ) a n‖ ≤ 8 * L / T := by
  have h8 : 1 ≤ 8 * L / T := by rw [le_div_iff₀ hT]; linarith
  rcases Nat.eq_zero_or_pos n with rfl | hn
  · simp [expSum]; linarith
  obtain ⟨m, rfl⟩ : ∃ m, n = m + 1 := ⟨n - 1, by omega⟩
  set y : ℕ → ℝ := fun i => (a : ℝ) + i + θ with hy
  have hyw : ∀ i ≤ m, L ≤ y i ∧ y i ≤ 2 * L := by
    intro i hi
    have hx : (a : ℝ) + i ∈ runIcc a (m + 1) := by
      refine ⟨by simp, ?_⟩
      have : (i : ℝ) ≤ m := by exact_mod_cast hi
      push_cast; linarith
    have := hwin _ hx
    simp only [hy]; exact this
  set g : ℕ → ℝ := fun i => recipPhase (T * L) θ ((a : ℝ) + i) + ((a : ℝ) + i) with hg
  set z : ℕ → ℂ := fun i => eAdd (g i) with hz
  set Δ : ℕ → ℝ := fun i => g (i + 1) - g i with hΔ
  set lam : ℝ := T / (4 * L) with hlam
  have hlampos : 0 < lam := div_pos hT (by linarith)
  have hlamle : lam ≤ 1 / 2 := by
    rw [hlam, div_le_iff₀ (by linarith)]; nlinarith
  -- the sum equals Σ z_i
  have hsum : expSum (recipPhase (T * L) θ) a (m + 1) = ∑ i ∈ range (m + 1), z i := by
    unfold expSum
    refine sum_congr rfl fun i _ => ?_
    simp only [hz, hg]
    rw [eAdd_add]
    have : eAdd ((a : ℝ) + i) = 1 := by
      have := eAdd_int (a + i); push_cast at this; exact this
    rw [this, mul_one]
  -- for i < m both y_i and y_i + 1 lie in the window
  have hyi1 : ∀ i, y (i + 1) = y i + 1 := by intro i; simp only [hy]; push_cast; ring
  have hwin2 : ∀ i < m, L ≤ y i ∧ y i + 1 ≤ 2 * L := by
    intro i hi
    exact ⟨(hyw i hi.le).1, by rw [← hyi1]; exact (hyw (i + 1) hi).2⟩
  have hΔform : ∀ i < m, Δ i = 1 - T * L / (y i * (y i + 1)) := by
    intro i hi
    have hpos : 0 < y i := lt_of_lt_of_le hL (hwin2 i hi).1
    simp only [hΔ, hg, recipPhase]
    have e1 : (a : ℝ) + ((i + 1 : ℕ) : ℝ) + θ = y i + 1 := by simp only [hy]; push_cast; ring
    have e2 : (a : ℝ) + (i : ℝ) + θ = y i := rfl
    rw [e1, e2]
    have hp1 : 0 < y i + 1 := by linarith
    field_simp
    push_cast
    ring
  have hden : ∀ i < m, L * L ≤ y i * (y i + 1) ∧ y i * (y i + 1) ≤ (2 * L) * (2 * L) := by
    intro i hi
    obtain ⟨h1, h2⟩ := hwin2 i hi
    have h0 : 0 ≤ y i := by linarith
    constructor
    · nlinarith
    · have : y i ≤ 2 * L := by linarith
      nlinarith
  have hq : ∀ i < m, T / (4 * L) ≤ T * L / (y i * (y i + 1)) ∧
      T * L / (y i * (y i + 1)) ≤ T / L := by
    intro i hi
    obtain ⟨d1, d2⟩ := hden i hi
    have hdpos : 0 < y i * (y i + 1) := lt_of_lt_of_le (mul_pos hL hL) d1
    constructor
    · rw [div_le_div_iff₀ (by linarith) hdpos]; nlinarith
    · rw [div_le_div_iff₀ hdpos hL]; nlinarith
  have hΔb : ∀ i < m, lam ≤ Δ i ∧ Δ i ≤ 1 - lam := by
    intro i hi
    rw [hΔform i hi]
    obtain ⟨q1, q2⟩ := hq i hi
    have hTL' : T / L ≤ 1 / 2 := by rw [div_le_iff₀ hL]; linarith
    constructor
    · linarith
    · simp only [hlam]; linarith
  have hmono : ∀ i, i + 1 < m → Δ i ≤ Δ (i + 1) := by
    intro i hi
    rw [hΔform i (by omega), hΔform (i + 1) hi, hyi1]
    obtain ⟨d1, _⟩ := hden i (by omega)
    have hdpos : 0 < y i * (y i + 1) := lt_of_lt_of_le (mul_pos hL hL) d1
    have hyp : 0 ≤ y i := by linarith [(hwin2 i (by omega)).1]
    have hle : y i * (y i + 1) ≤ (y i + 1) * (y i + 1 + 1) := by nlinarith
    have : T * L / ((y i + 1) * (y i + 1 + 1)) ≤ T * L / (y i * (y i + 1)) :=
      div_le_div_of_nonneg_left (mul_nonneg hT.le hL.le) hdpos hle
    linarith
  have hstep : ∀ i < m, z (i + 1) = z i * eAdd (Δ i) := by
    intro i _
    simp only [hz, hΔ]
    rw [← eAdd_add]
    congr 1
    ring
  have hKL := kusmin_landau_discrete (z := z) (Δ := Δ) m hlampos hlamle (fun i => norm_eAdd _)
    hstep hΔb hmono
  rw [hsum]
  refine hKL.trans ?_
  have e : 3 / (2 * lam) = 6 * L / T := by simp only [hlam]; field_simp; ring
  rw [e]
  have h2 : 2 ≤ L / T := by rw [le_div_iff₀ hT]; linarith
  have : 2 ≤ 2 * L / T := by
    have : L / T ≤ 2 * L / T := by
      rw [div_le_div_iff_of_pos_right hT]; linarith
    linarith
  calc 2 + 6 * L / T ≤ 2 * L / T + 6 * L / T := by linarith
    _ = 8 * L / T := by ring

/-! ## Middle regime and all regimes together -/

/-- Middle regime `L/2 < T ≤ L`: the uniform estimate with `k = 1`, `B₀ = 2`. -/
theorem recipSum_middle_T (hV : UniformVinogradovEstimate) :
    ∃ c C : ℝ, 0 < c ∧ 0 ≤ C ∧ ∀ (L T θ : ℝ) (a : ℤ) (n : ℕ),
      2 ≤ L → L / 2 < T → T ≤ L →
      (∀ x ∈ runIcc a n, L ≤ x + θ ∧ x + θ ≤ 2 * L) →
      ‖expSum (recipPhase (T * L) θ) a n‖ ≤ C * L * L ^ (-c) := by
  obtain ⟨c, C, hc, hC, hb⟩ := hV 2 2 (by norm_num) (by norm_num)
  refine ⟨c, C, hc, hC, fun L T θ a n hL hT1 hT2 hwin => ?_⟩
  have hLpos : 0 < L := by linarith
  have hlen : (n : ℝ) - 1 ≤ L := by
    rcases Nat.eq_zero_or_pos n with rfl | hn
    · simp; linarith
    have hn1 : (1 : ℝ) ≤ n := by exact_mod_cast hn
    have ha : (a : ℝ) ∈ runIcc a n := ⟨le_refl _, by linarith⟩
    have hb' : (a : ℝ) + n - 1 ∈ runIcc a n := ⟨by linarith, le_refl _⟩
    linarith [(hwin _ ha).1, (hwin _ hb').2]
  have hsub : runIcc a n ⊆ Set.Ioi (-θ) := fun x hx => by
    have := (hwin x hx).1; show -θ < x; linarith
  have hder : DerivHyp 2 L T (recipPhase (T * L) θ) (runIcc a n) := by
    have h := recipPhase_derivHyp (X := T * L) (θ := θ) (mul_nonneg (by linarith) hLpos.le)
      hLpos (runIcc a n) hwin
    rwa [mul_div_assoc, div_self hLpos.ne', mul_one] at h
  have := hb L T 1 (recipPhase (T * L) θ) a n (Set.Ioi (-θ)) hL (by linarith) le_rfl
    (by simpa using hT2) hlen isOpen_Ioi hsub (recipPhase_contDiffOn _ _) hder
  simpa using this

/-- **All Type I regimes, conditional only on `UniformVinogradovEstimate`.**
For every `A > 0` and all large `L`, every `T > 0` (with `log L ≥ (log T)^σ` required only when
`T ≥ L`), every shift and every run in the window `x+θ ∈ [L, 2L]`:
`|Σ e(TL/(x+θ))| ≤ L (log L)^{-A} + 8L/T`. -/
theorem recipSum_all_regimes {σ : ℝ} (hσ : 2 / 3 < σ) (hV : UniformVinogradovEstimate)
    (A : ℝ) (hA : 0 < A) :
    ∃ L₁ : ℝ, ∀ (L T θ : ℝ) (a : ℤ) (n : ℕ),
      L₁ ≤ L → 0 < T → (L ≤ T → Real.log T ^ σ ≤ Real.log L) →
      (∀ x ∈ runIcc a n, L ≤ x + θ ∧ x + θ ≤ 2 * L) →
      ‖expSum (recipPhase (T * L) θ) a n‖ ≤ L * Real.log L ^ (-A) + 8 * L / T := by
  obtain ⟨T₀, hT₀⟩ := reciprocalPhaseVK_of_uniform hσ hV A hA
  obtain ⟨c, C, hc, hC, hmid⟩ := recipSum_middle_T hV
  obtain ⟨y₀, hy₀1, hy₀⟩ := eventually_const_mul_exp_neg_le C c 1 A hc one_pos
  refine ⟨max (max T₀ 2) (Real.exp y₀), fun L T θ a n hL hT hσL hwin => ?_⟩
  have hL2 : 2 ≤ L := ((le_max_right _ _).trans (le_max_left _ _)).trans hL
  have hLT₀ : T₀ ≤ L := ((le_max_left _ _).trans (le_max_left _ _)).trans hL
  have hLpos : 0 < L := by linarith
  have hlogL : y₀ ≤ Real.log L := by
    rw [Real.le_log_iff_exp_le hLpos]; exact (le_max_right _ _).trans hL
  have hlogLpos : 0 < Real.log L := lt_of_lt_of_le (by linarith) hlogL
  have hpow_nn : 0 ≤ L * Real.log L ^ (-A) := mul_nonneg hLpos.le (Real.rpow_nonneg hlogLpos.le _)
  have h8 : 0 ≤ 8 * L / T := div_nonneg (by linarith) hT.le
  rcases le_or_gt T (L / 2) with hsmall | hbig
  · have := recipSum_small_T a n hLpos hT hsmall hwin
    linarith
  rcases le_or_gt T L with hmidT | hlarge
  · have hm := hmid L T θ a n hL2 hbig hmidT hwin
    have hy := hy₀ (Real.log L) hlogL
    have hrp : L ^ (-c) = Real.exp (-(c * Real.log L ^ (1 : ℝ))) := by
      rw [Real.rpow_one, Real.rpow_def_of_pos hLpos]; ring_nf
    calc ‖expSum (recipPhase (T * L) θ) a n‖ ≤ C * L * L ^ (-c) := hm
      _ = L * (C * Real.exp (-(c * Real.log L ^ (1 : ℝ)))) := by rw [hrp]; ring
      _ ≤ L * Real.log L ^ (-A) := mul_le_mul_of_nonneg_left hy hLpos.le
      _ ≤ L * Real.log L ^ (-A) + 8 * L / T := by linarith
  · have hvk := hT₀ L T θ a n (hLT₀.trans hlarge.le) hL2 hlarge.le (hσL hlarge.le) hwin
    have hmono : Real.log T ^ (-A) ≤ Real.log L ^ (-A) :=
      Real.rpow_le_rpow_of_nonpos hlogLpos (Real.log_le_log hLpos hlarge.le) (by linarith)
    calc ‖expSum (recipPhase (T * L) θ) a n‖ ≤ L * Real.log T ^ (-A) := hvk
      _ ≤ L * Real.log L ^ (-A) := mul_le_mul_of_nonneg_left hmono hLpos.le
      _ ≤ L * Real.log L ^ (-A) + 8 * L / T := by linarith

/-- **Harmonic-weighted Type I class sum, all regimes, conditional only on the uniform
Vinogradov estimate:** `|Σ_j e(TL/(j+θ)) / (Q(j+θ))| ≤ ((log L)^{-A} + 8/T)/Q`. -/
theorem typeI_class_sum_all_regimes {σ : ℝ} (hσ : 2 / 3 < σ) (hV : UniformVinogradovEstimate)
    (A : ℝ) (hA : 0 < A) :
    ∃ L₁ : ℝ, ∀ (L T θ Q : ℝ) (a : ℤ) (n : ℕ),
      L₁ ≤ L → 0 < T → (L ≤ T → Real.log T ^ σ ≤ Real.log L) → 0 < Q →
      (∀ x ∈ runIcc a n, L ≤ x + θ ∧ x + θ ≤ 2 * L) →
      ‖∑ i ∈ range n, ((1 / (Q * ((a : ℝ) + i + θ)) : ℝ) : ℂ) *
          eAdd (recipPhase (T * L) θ ((a : ℝ) + i))‖ ≤
        (Real.log L ^ (-A) + 8 / T) / Q := by
  obtain ⟨L₁, hL₁⟩ := recipSum_all_regimes hσ hV A hA
  refine ⟨max L₁ 1, fun L T θ Q a n hL hT hσL hQ hwin => ?_⟩
  have hLpos : 0 < L := lt_of_lt_of_le one_pos ((le_max_right _ _).trans hL)
  have hprefix : ∀ m ≤ n, ∀ x ∈ runIcc a m, L ≤ x + θ ∧ x + θ ≤ 2 * L := by
    intro m hm x hx
    apply hwin
    refine ⟨hx.1, hx.2.trans ?_⟩
    have : (m : ℝ) ≤ n := by exact_mod_cast hm
    linarith
  by_cases hn : n = 0
  · subst hn
    simp only [range_zero, sum_empty, norm_zero]
    have : 0 ≤ Real.log L ^ (-A) := Real.rpow_nonneg (Real.log_nonneg
      ((le_max_right _ _).trans hL)) _
    exact div_nonneg (add_nonneg this (div_nonneg (by norm_num) hT.le)) hQ.le
  have haθ : L ≤ (a : ℝ) + θ := by
    have ha : (a : ℝ) ∈ runIcc a n := by
      refine ⟨le_refl _, ?_⟩
      have : (1 : ℝ) ≤ n := by exact_mod_cast Nat.one_le_iff_ne_zero.2 hn
      linarith
    exact (hwin _ ha).1
  have hpos : ∀ i : ℕ, 0 < (a : ℝ) + i + θ := by
    intro i; have : (0 : ℝ) ≤ i := Nat.cast_nonneg i; linarith
  set w : ℕ → ℝ := fun i => 1 / (Q * ((a : ℝ) + i + θ)) with hw
  have hw0 : ∀ i, 0 ≤ w i := fun i => by
    simp only [hw]; exact div_nonneg zero_le_one (mul_pos hQ (hpos i)).le
  have hwm : ∀ i, w (i + 1) ≤ w i := fun i => by
    simp only [hw]
    apply one_div_le_one_div_of_le (mul_pos hQ (hpos i))
    apply mul_le_mul_of_nonneg_left _ hQ.le
    push_cast; linarith
  have hB : ∀ m ≤ n, ‖∑ i ∈ range m, eAdd (recipPhase (T * L) θ ((a : ℝ) + i))‖ ≤
      L * Real.log L ^ (-A) + 8 * L / T := fun m hm =>
    hL₁ L T θ a m ((le_max_left _ _).trans hL) hT hσL (hprefix m hm)
  have habel := abel_antitone (z := fun i => eAdd (recipPhase (T * L) θ ((a : ℝ) + i)))
    (w := w) n hw0 hwm hB
  have hw0le : w 0 ≤ 1 / (Q * L) := by
    simp only [hw]
    apply one_div_le_one_div_of_le (mul_pos hQ hLpos)
    apply mul_le_mul_of_nonneg_left _ hQ.le
    simpa using haθ
  have hBnn : 0 ≤ L * Real.log L ^ (-A) + 8 * L / T := by
    have : 0 ≤ Real.log L ^ (-A) := Real.rpow_nonneg (Real.log_nonneg
      ((le_max_right _ _).trans hL)) _
    exact add_nonneg (mul_nonneg hLpos.le this) (div_nonneg (by linarith) hT.le)
  calc ‖∑ i ∈ range n, ((1 / (Q * ((a : ℝ) + i + θ)) : ℝ) : ℂ) *
          eAdd (recipPhase (T * L) θ ((a : ℝ) + i))‖
      = ‖∑ i ∈ range n, (w i : ℂ) * eAdd (recipPhase (T * L) θ ((a : ℝ) + i))‖ := rfl
    _ ≤ w 0 * (L * Real.log L ^ (-A) + 8 * L / T) := habel
    _ ≤ 1 / (Q * L) * (L * Real.log L ^ (-A) + 8 * L / T) :=
        mul_le_mul_of_nonneg_right hw0le hBnn
    _ = (Real.log L ^ (-A) + 8 / T) / Q := by field_simp

end GoldC.VK
