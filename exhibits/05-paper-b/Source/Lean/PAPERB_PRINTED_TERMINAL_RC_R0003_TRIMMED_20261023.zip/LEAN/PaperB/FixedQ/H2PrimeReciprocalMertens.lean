import PaperB.M4A.CoprimeHarmonicLog
import PaperB.FixedQ.RowReduction

open scoped BigOperators
open Finset Nat Real

namespace PaperB.FixedQ

noncomputable def h2PrimePrimorial (N : ℕ) : ℕ :=
  ∏ p ∈ N.primesLE, p

lemma h2PrimePrimorial_pos (N : ℕ) :
    0 < h2PrimePrimorial N := by
  unfold h2PrimePrimorial
  exact Finset.prod_pos fun p hp =>
    (Nat.prime_of_mem_primesLE hp).pos

lemma h2PrimePrimorial_primeFactors (N : ℕ) :
    (h2PrimePrimorial N).primeFactors = N.primesLE := by
  unfold h2PrimePrimorial
  exact Nat.primeFactors_prod
    (fun p hp => Nat.prime_of_mem_primesLE hp)

lemma h2PrimePrimorial_coprimeHarmonic_eq_one
    {N : ℕ} (hN : 1 ≤ N) :
    PaperB.M4A.coprimeHarmonic N (h2PrimePrimorial N) = 1 := by
  unfold PaperB.M4A.coprimeHarmonic
  have hfilter :
      (Finset.Icc 1 N).filter
          (fun m => m.Coprime (h2PrimePrimorial N)) = {1} := by
    ext m
    simp only [Finset.mem_filter, Finset.mem_Icc,
      Finset.mem_singleton]
    constructor
    · intro hmem
      have hm1 : 1 ≤ m := hmem.1.1
      have hmN : m ≤ N := hmem.1.2
      have hcop : m.Coprime (h2PrimePrimorial N) := hmem.2
      apply (Nat.eq_one_iff_not_exists_prime_dvd).2
      intro p hpPrime hpm
      have hmpos : 0 < m := by omega
      have hpLeM : p ≤ m :=
        Nat.le_of_dvd hmpos hpm
      have hpLeN : p ≤ N := hpLeM.trans hmN
      have hpMem : p ∈ N.primesLE :=
        Nat.mem_primesLE.mpr ⟨hpLeN, hpPrime⟩
      have hpK : p ∣ h2PrimePrimorial N := by
        unfold h2PrimePrimorial
        exact Finset.dvd_prod_of_mem (fun x => x) hpMem
      exact
        (Nat.not_coprime_of_dvd_of_dvd hpPrime.one_lt hpm hpK)
          hcop
    · intro hm
      rw [hm]
      exact ⟨⟨by norm_num, hN⟩, by simp⟩
  rw [hfilter]
  simp

lemma h2PrimePrimorial_totient_ratio_ge_log
    {N : ℕ} (hN : 1 ≤ N) :
    Real.log ((N + 1 : ℕ) : ℝ) ≤
      (h2PrimePrimorial N : ℝ) /
        ((h2PrimePrimorial N).totient : ℝ) := by
  let K := h2PrimePrimorial N
  have hKpos : 0 < K := h2PrimePrimorial_pos N
  have hcop :=
    PaperB.M4A.coprimeHarmonic_log_lower N K hKpos
  have hcop1 :
      ((K.totient : ℝ) / (K : ℝ)) *
          Real.log ((N + 1 : ℕ) : ℝ) ≤ 1 := by
    rw [← h2PrimePrimorial_coprimeHarmonic_eq_one hN]
    simpa [K, Nat.cast_add, Nat.cast_one] using hcop
  have hphi : (0 : ℝ) < (K.totient : ℝ) := by
    exact_mod_cast (Nat.totient_pos.mpr hKpos)
  have hKR : (0 : ℝ) < (K : ℝ) := by exact_mod_cast hKpos
  apply (le_div_iff₀ hphi).2
  have hscaled := mul_le_mul_of_nonneg_left hcop1 hKR.le
  field_simp [hKR.ne'] at hscaled
  simpa [K, mul_comm, mul_left_comm, mul_assoc] using hscaled
lemma h2PrimeEulerProduct_ge_log
    {N : ℕ} (hN : 1 ≤ N) :
    Real.log ((N + 1 : ℕ) : ℝ) ≤
      ∏ p ∈ N.primesLE,
        (p : ℝ) / ((p : ℝ) - 1) := by
  have hK := h2PrimePrimorial_totient_ratio_ge_log hN
  have hprod :=
    full_prime_factor_prod_eq_totient_ratio
      (h2PrimePrimorial_pos N)
  rw [h2PrimePrimorial_primeFactors] at hprod
  rw [hprod]
  exact hK

lemma h2PrimeEulerProduct_pos (N : ℕ) :
    0 < ∏ p ∈ N.primesLE,
      (p : ℝ) / ((p : ℝ) - 1) := by
  apply Finset.prod_pos
  intro p hp
  have hpP := Nat.prime_of_mem_primesLE hp
  have hp1 : (1 : ℝ) < p := by exact_mod_cast hpP.one_lt
  positivity

lemma h2PrimeEulerLogSum_ge_loglog
    {N : ℕ} (hN : 2 ≤ N) :
    Real.log (Real.log ((N + 1 : ℕ) : ℝ)) ≤
      ∑ p ∈ N.primesLE,
        Real.log ((1 - (p : ℝ)⁻¹)⁻¹) := by
  have hN1 : 1 ≤ N := by omega
  have hprod := h2PrimeEulerProduct_ge_log hN1
  have hlogNpos :
      0 < Real.log ((N + 1 : ℕ) : ℝ) := by
    apply Real.log_pos
    exact_mod_cast (show 1 < N + 1 by omega)
  have hprodpos := h2PrimeEulerProduct_pos N
  have hlogmono :
      Real.log (Real.log ((N + 1 : ℕ) : ℝ)) ≤
        Real.log
          (∏ p ∈ N.primesLE,
            (p : ℝ) / ((p : ℝ) - 1)) :=
    Real.log_le_log hlogNpos hprod
  have hrewrite :
      Real.log
          (∏ p ∈ N.primesLE,
            (p : ℝ) / ((p : ℝ) - 1)) =
        ∑ p ∈ N.primesLE,
          Real.log ((1 - (p : ℝ)⁻¹)⁻¹) := by
    rw [Real.log_prod]
    · apply Finset.sum_congr rfl
      intro p hp
      have hpP := Nat.prime_of_mem_primesLE hp
      rw [prime_totient_factor_eq_euler hpP]
    · intro p hp
      have hpP := Nat.prime_of_mem_primesLE hp
      have hp1 : (1 : ℝ) < p := by exact_mod_cast hpP.one_lt
      positivity
  rw [hrewrite] at hlogmono
  exact hlogmono

theorem h2_sum_prime_recip_ge_loglog_sub_one
    {N : ℕ} (hN : 2 ≤ N) :
    Real.log (Real.log ((N + 1 : ℕ) : ℝ)) - 1 ≤
      ∑ p ∈ N.primesLE, (1 : ℝ) / p := by
  have hlog := h2PrimeEulerLogSum_ge_loglog hN
  have hterm :
      (∑ p ∈ N.primesLE,
        Real.log ((1 - (p : ℝ)⁻¹)⁻¹)) ≤
      (∑ p ∈ N.primesLE, (1 : ℝ) / p) +
        (∑ p ∈ N.primesLE,
          1 / ((p : ℝ) * ((p : ℝ) - 1))) := by
    calc
      (∑ p ∈ N.primesLE,
          Real.log ((1 - (p : ℝ)⁻¹)⁻¹))
          ≤ ∑ p ∈ N.primesLE,
              ((1 : ℝ) / p +
                1 / ((p : ℝ) * ((p : ℝ) - 1))) := by
            apply Finset.sum_le_sum
            intro p hp
            exact prime_euler_log_factor_le
              (Nat.prime_of_mem_primesLE hp)
      _ = (∑ p ∈ N.primesLE, (1 : ℝ) / p) +
          (∑ p ∈ N.primesLE,
            1 / ((p : ℝ) * ((p : ℝ) - 1))) := by
            rw [Finset.sum_add_distrib]
  have hcorr :=
    sum_prime_euler_correction_le_one (N := N) hN
  linarith

#print axioms h2PrimePrimorial_coprimeHarmonic_eq_one
#print axioms h2_sum_prime_recip_ge_loglog_sub_one

end PaperB.FixedQ
