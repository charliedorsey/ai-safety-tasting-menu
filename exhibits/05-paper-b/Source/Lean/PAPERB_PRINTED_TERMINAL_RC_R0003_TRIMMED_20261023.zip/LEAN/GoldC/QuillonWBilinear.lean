import GoldC.QuillonWRoute
import GoldC.QuillonVWClass

/-!
# Quillon CSC3 F7.5e: the full W′ bilinear bound (dyadic `n`, classes mod `M`, modes)

Row: `Φ(r) = Σ_{ρ:ZMod M} 1[r ≡ ρ] Σ_{j∈𝒥} A(ρ,j)·kphase(c_j, r)`.

For `𝒴` (with `X ≤ y ≤ Y`, units mod `s` and mod `M`), `𝒩 ⊆ (N₀, 2^K N₀]` (units mod `M`),
`‖α_y‖ ≤ A/y`, `‖β_n‖ ≤ A/n`:

    ‖Σ_n β_n Σ_y α_y 1[yn∈I] Φ(yn)‖ ≤ K·M·Σ_ρ Σ_j ‖A(ρ,j)‖·A²·√(2Ψ(c_j, N₀)).

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonWBilinear

open GoldC.QuillonWRoute GoldC.QuillonVW

variable {s : ℕ} [NeZero s]

/-- The W′ saving function `Ψ`. -/
noncomputable def WPsi (P : Finset ℕ) (c₀ : ZMod s) (X Y N : ℕ) : ℝ :=
  2 / X + 2 * (1 + Real.log Y) ^ 2 / s +
    2 * (1 + Real.log Y) ^ 2 * (∏ p ∈ P, (1 + (p : ℝ) ^ (-(3 : ℝ) / 4))) *
      ((3 : ℝ) ^ ((P.card : ℝ) / 4) *
        (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 4)) *
      ((s : ℝ) ^ ((3 : ℝ) / 4) / s + (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + Real.log s) / N)

lemma WPsi_nonneg (P : Finset ℕ) (c₀ : ZMod s) (X Y N : ℕ) : 0 ≤ WPsi P c₀ X Y N := by
  unfold WPsi
  have : (0 : ℝ) ≤ Real.log s := by
    rcases Nat.eq_zero_or_pos s with h | h
    · simp [h]
    · exact Real.log_nonneg (by exact_mod_cast h)
  have : (0 : ℝ) ≤ ∏ p ∈ P, (1 + (p : ℝ) ^ (-(3 : ℝ) / 4)) := prod_nonneg fun _ _ => by positivity
  have : (0 : ℝ) ≤ (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) :=
    prod_nonneg fun _ _ => by positivity
  positivity

lemma WPsi_anti (P : Finset ℕ) (c₀ : ZMod s) (X Y N N' : ℕ) (hN : 1 ≤ N) (hNN' : N ≤ N') :
    WPsi P c₀ X Y N' ≤ WPsi P c₀ X Y N := by
  unfold WPsi
  have hlogs : (0 : ℝ) ≤ Real.log s := by
    rcases Nat.eq_zero_or_pos s with h | h
    · simp [h]
    · exact Real.log_nonneg (by exact_mod_cast h)
  have h1 : (0 : ℝ) ≤ 2 * (1 + Real.log Y) ^ 2 * (∏ p ∈ P, (1 + (p : ℝ) ^ (-(3 : ℝ) / 4))) *
      ((3 : ℝ) ^ ((P.card : ℝ) / 4) *
        (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 4)) := by
    have : (0 : ℝ) ≤ ∏ p ∈ P, (1 + (p : ℝ) ^ (-(3 : ℝ) / 4)) := prod_nonneg fun _ _ => by positivity
    have : (0 : ℝ) ≤ (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) :=
      prod_nonneg fun _ _ => by positivity
    positivity
  have hNR : (0 : ℝ) < N := by exact_mod_cast hN
  have hNN'R : (N : ℝ) ≤ N' := by exact_mod_cast hNN'
  have h2 : (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + Real.log s) / N' ≤
      (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + Real.log s) / N :=
    div_le_div_of_nonneg_left (by positivity) hNR hNN'R
  gcongr

section full
variable {M : ℕ} [NeZero M]

/-- The class/mode row. -/
noncomputable def rowW (𝒥 : Finset ℕ) (Acoef : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s) (r : ℕ) : ℂ :=
  ∑ ρ : ZMod M, if (r : ZMod M) = ρ then ∑ j ∈ 𝒥, Acoef ρ j * kphase (c j) r else 0

lemma class_split_unit (ρ : ZMod M) (y n : ℕ) (hy : IsUnit (y : ZMod M)) :
    (if ((y * n : ℕ) : ZMod M) = ρ then (1 : ℂ) else 0) =
      ∑ ρ₁ : ZMod M, (if (y : ZMod M) = ρ₁ then (1 : ℂ) else 0) *
        (if (n : ZMod M) = ρ * ρ₁⁻¹ then (1 : ℂ) else 0) := by
  rw [Finset.sum_eq_single (y : ZMod M)]
  · rw [if_pos rfl, one_mul]
    have h1 : (y : ZMod M) * (y : ZMod M)⁻¹ = 1 := ZMod.mul_inv_of_unit _ hy
    push_cast
    by_cases h : (y : ZMod M) * n = ρ
    · rw [if_pos h, if_pos (by rw [← h, mul_comm (y : ZMod M), mul_assoc, h1, mul_one])]
    · rw [if_neg h, if_neg (fun h' => h (by rw [h', mul_comm, mul_assoc, mul_comm _ (y : ZMod M), h1,
        mul_one]))]
  · intro b _ hb; rw [if_neg (fun h => hb h.symm), zero_mul]
  · intro h; exact absurd (mem_univ _) h

lemma sum_dyadic (𝒩 : Finset ℕ) (t : ℕ → ℕ) (htm : Monotone t) (K : ℕ)
    (h𝒩 : 𝒩 ⊆ Ioc (t 0) (t K)) (G : ℕ → ℂ) :
    ∑ n ∈ 𝒩, G n = ∑ k ∈ range K, ∑ n ∈ 𝒩.filter (fun n => n ∈ Ioc (t k) (t (k + 1))), G n := by
  classical
  have e1 : ∑ n ∈ 𝒩, G n = ∑ n ∈ Ioc (t 0) (t K), (if n ∈ 𝒩 then G n else 0) := by
    rw [← sum_filter]
    apply sum_congr _ (fun _ _ => rfl)
    ext n; simp only [mem_filter]
    exact ⟨fun h => ⟨h𝒩 h, h⟩, fun h => h.2⟩
  rw [e1, GoldC.QuillonTypeII.sum_Ioc_telescope _ t htm K]
  refine sum_congr rfl fun k _ => ?_
  rw [← sum_filter]
  apply sum_congr _ (fun _ _ => rfl)
  ext n; simp only [mem_filter]; tauto

lemma sum5 {α β γ δ ε : Type*} (sn : Finset α) (sy : Finset β) (sρ : Finset γ) (sj : Finset δ)
    (sr : Finset ε) (f : α → β → γ → δ → ε → ℂ) :
    ∑ n ∈ sn, ∑ y ∈ sy, ∑ ρ ∈ sρ, ∑ j ∈ sj, ∑ r ∈ sr, f n y ρ j r =
      ∑ ρ ∈ sρ, ∑ j ∈ sj, ∑ r ∈ sr, ∑ n ∈ sn, ∑ y ∈ sy, f n y ρ j r := by
  calc _ = ∑ n ∈ sn, ∑ ρ ∈ sρ, ∑ y ∈ sy, ∑ j ∈ sj, ∑ r ∈ sr, f n y ρ j r :=
        sum_congr rfl fun n _ => sum_comm
    _ = ∑ ρ ∈ sρ, ∑ n ∈ sn, ∑ y ∈ sy, ∑ j ∈ sj, ∑ r ∈ sr, f n y ρ j r := sum_comm
    _ = ∑ ρ ∈ sρ, ∑ n ∈ sn, ∑ j ∈ sj, ∑ y ∈ sy, ∑ r ∈ sr, f n y ρ j r :=
        sum_congr rfl fun ρ _ => sum_congr rfl fun n _ => sum_comm
    _ = ∑ ρ ∈ sρ, ∑ j ∈ sj, ∑ n ∈ sn, ∑ y ∈ sy, ∑ r ∈ sr, f n y ρ j r :=
        sum_congr rfl fun ρ _ => sum_comm
    _ = ∑ ρ ∈ sρ, ∑ j ∈ sj, ∑ n ∈ sn, ∑ r ∈ sr, ∑ y ∈ sy, f n y ρ j r :=
        sum_congr rfl fun ρ _ => sum_congr rfl fun j _ => sum_congr rfl fun n _ => sum_comm
    _ = _ := sum_congr rfl fun ρ _ => sum_congr rfl fun j _ => sum_comm

theorem W_bilinear_full (hs2 : 2 ≤ s) (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime)
    (hsP : s = ∏ p ∈ P, p) (𝒥 : Finset ℕ) (Acoef : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s)
    (𝒴 𝒩 : Finset ℕ) (X Y N₀ K I₀ I₁ : ℕ) (hX : 2 ≤ X) (hN₀ : 1 ≤ N₀)
    (h𝒴 : ∀ y ∈ 𝒴, X ≤ y ∧ y ≤ Y) (hus : ∀ y ∈ 𝒴, IsUnit (y : ZMod s))
    (huM : ∀ y ∈ 𝒴, IsUnit (y : ZMod M)) (h𝒩 : 𝒩 ⊆ Ioc N₀ (2 ^ K * N₀))
    (α β : ℕ → ℂ) (A : ℝ) (hA : 0 ≤ A) (hα : ∀ y ∈ 𝒴, ‖α y‖ ≤ A / y)
    (hβ : ∀ n ∈ 𝒩, ‖β n‖ ≤ A / n) :
    ‖∑ n ∈ 𝒩, β n * ∑ y ∈ 𝒴, α y *
        (if y * n ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (y * n) else 0)‖ ≤
      K * M * ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ *
        (A ^ 2 * Real.sqrt (2 * WPsi P (c j) X Y N₀)) := by
  classical
  set t : ℕ → ℕ := fun k => 2 ^ k * N₀ with ht
  have htm : Monotone t := fun a b hab =>
    Nat.mul_le_mul_right _ (Nat.pow_le_pow_right (by norm_num) hab)
  have h𝒩' : 𝒩 ⊆ Ioc (t 0) (t K) := by simpa [ht] using h𝒩
  rw [sum_dyadic 𝒩 t htm K h𝒩' _]
  -- piece notation
  set Kp : ℕ → ℕ → ℕ → ℂ := fun j n y =>
    if y * n ∈ Ioc I₀ I₁ then kphase (c j) (y * n) else 0 with hKp
  set bρ : ZMod M → ZMod M → ℕ → ℂ := fun ρ ρ₁ n =>
    β n * (if (n : ZMod M) = ρ * ρ₁⁻¹ then (1 : ℂ) else 0) with hbρ
  set aρ : ZMod M → ℕ → ℂ := fun ρ₁ y => α y * (if (y : ZMod M) = ρ₁ then (1 : ℂ) else 0) with haρ
  have hpt : ∀ n y, y ∈ 𝒴 → β n * (α y *
      (if y * n ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (y * n) else 0)) =
      ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ∑ ρ₁ : ZMod M, Acoef ρ j * (bρ ρ ρ₁ n * (aρ ρ₁ y * Kp j n y)) := by
    intro n y hy
    have h1 : ∀ ρ j, ∑ ρ₁ : ZMod M, Acoef ρ j * (bρ ρ ρ₁ n * (aρ ρ₁ y * Kp j n y)) =
        Acoef ρ j * β n * α y * Kp j n y *
          (if ((y * n : ℕ) : ZMod M) = ρ then (1 : ℂ) else 0) := by
      intro ρ j
      rw [class_split_unit ρ y n (huM y hy), mul_sum]
      refine sum_congr rfl fun ρ₁ _ => ?_
      simp only [hbρ, haρ]; ring
    simp only [h1]
    simp only [hKp, rowW]
    by_cases hI : y * n ∈ Ioc I₀ I₁
    · simp only [if_pos hI]
      rw [mul_sum, mul_sum]
      refine sum_congr rfl fun ρ _ => ?_
      by_cases hρ : ((y * n : ℕ) : ZMod M) = ρ
      · rw [if_pos hρ, mul_sum, mul_sum]
        refine sum_congr rfl fun j _ => ?_
        rw [if_pos hρ]; ring
      · rw [if_neg hρ, mul_zero, mul_zero]
        symm; refine sum_eq_zero fun j _ => ?_
        rw [if_neg hρ, mul_zero]
    · simp only [if_neg hI, mul_zero]
      symm
      exact sum_eq_zero fun ρ _ => sum_eq_zero fun j _ => by ring
  -- per block
  have hblock : ∀ k ∈ range K,
      ‖∑ n ∈ 𝒩.filter (fun n => n ∈ Ioc (t k) (t (k + 1))), β n * ∑ y ∈ 𝒴, α y *
        (if y * n ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (y * n) else 0)‖ ≤
      M * ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ * (A ^ 2 * Real.sqrt (2 * WPsi P (c j) X Y N₀)) := by
    intro k _
    set 𝒩k := 𝒩.filter (fun n => n ∈ Ioc (t k) (t (k + 1)))
    have hexp : ∑ n ∈ 𝒩k, β n * ∑ y ∈ 𝒴, α y *
        (if y * n ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (y * n) else 0) =
        ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ∑ ρ₁ : ZMod M, Acoef ρ j *
          ∑ n ∈ 𝒩k, bρ ρ ρ₁ n * ∑ y ∈ 𝒴, aρ ρ₁ y * Kp j n y := by
      have e1 : ∑ n ∈ 𝒩k, β n * ∑ y ∈ 𝒴, α y *
          (if y * n ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (y * n) else 0) =
          ∑ n ∈ 𝒩k, ∑ y ∈ 𝒴, ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ∑ ρ₁ : ZMod M,
            Acoef ρ j * (bρ ρ ρ₁ n * (aρ ρ₁ y * Kp j n y)) := by
        refine sum_congr rfl fun n _ => ?_
        rw [mul_sum]
        exact sum_congr rfl fun y hy => hpt n y hy
      rw [e1, sum5]
      refine sum_congr rfl fun ρ _ => sum_congr rfl fun j _ => sum_congr rfl fun ρ₁ _ => ?_
      rw [mul_sum]
      refine sum_congr rfl fun n _ => ?_
      rw [mul_sum, mul_sum]
    rw [hexp]
    have hNk : 1 ≤ 2 ^ k * N₀ := Nat.one_le_iff_ne_zero.2 (by positivity)
    have hpiece : ∀ ρ ρ₁ j, ‖∑ n ∈ 𝒩k, bρ ρ ρ₁ n * ∑ y ∈ 𝒴, aρ ρ₁ y * Kp j n y‖ ≤
        A ^ 2 * Real.sqrt (2 * WPsi P (c j) X Y N₀) := by
      intro ρ ρ₁ j
      have hsub : 𝒩k ⊆ Ioc (2 ^ k * N₀) (2 * (2 ^ k * N₀)) := by
        intro n hn
        have := (mem_filter.1 hn).2
        simp only [ht, pow_succ] at this
        simpa [mul_comm, mul_assoc, mul_left_comm] using this
      have hW := W_piece hs2 P hP hsP (c j) 𝒴 𝒩k X Y (2 ^ k * N₀) I₀ I₁ hX hNk h𝒴 hsub hus
        (aρ ρ₁) (bρ ρ ρ₁) A hA
        (fun y hy => by
          simp only [haρ]; split_ifs
          · rw [mul_one]; exact hα y hy
          · rw [mul_zero, norm_zero]; have := hy; positivity)
        (fun n hn => by
          simp only [hbρ]; split_ifs
          · rw [mul_one]; exact hβ n ((mem_filter.1 hn).1)
          · rw [mul_zero, norm_zero]; positivity)
      have hle : 2 * A ^ 4 * WPsi P (c j) X Y (2 ^ k * N₀) ≤ (A ^ 2 * Real.sqrt (2 * WPsi P (c j) X Y N₀)) ^ 2 := by
        rw [mul_pow, Real.sq_sqrt (by have := WPsi_nonneg P (c j) X Y N₀; positivity)]
        have := WPsi_anti P (c j) X Y N₀ (2 ^ k * N₀) hN₀ (Nat.le_mul_of_pos_left _ (by positivity))
        nlinarith [pow_two_nonneg (A ^ 2), sq_nonneg A]
      have hW2 : ‖∑ n ∈ 𝒩k, bρ ρ ρ₁ n * ∑ y ∈ 𝒴, aρ ρ₁ y * Kp j n y‖ ^ 2 ≤
          2 * A ^ 4 * WPsi P (c j) X Y (2 ^ k * N₀) := by
        unfold WPsi; exact hW
      have hW' : ‖∑ n ∈ 𝒩k, bρ ρ ρ₁ n * ∑ y ∈ 𝒴, aρ ρ₁ y * Kp j n y‖ ^ 2 ≤
          (A ^ 2 * Real.sqrt (2 * WPsi P (c j) X Y N₀)) ^ 2 := hW2.trans hle
      exact (pow_le_pow_iff_left₀ (norm_nonneg _) (by positivity) (by norm_num)).1 hW'
    calc _ ≤ ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ∑ ρ₁ : ZMod M, ‖Acoef ρ j‖ *
          (A ^ 2 * Real.sqrt (2 * WPsi P (c j) X Y N₀)) := by
          refine (norm_sum_le _ _).trans (sum_le_sum fun ρ _ => ?_)
          refine (norm_sum_le _ _).trans (sum_le_sum fun j _ => ?_)
          refine (norm_sum_le _ _).trans (sum_le_sum fun ρ₁ _ => ?_)
          rw [norm_mul]
          exact mul_le_mul_of_nonneg_left (hpiece ρ ρ₁ j) (norm_nonneg _)
      _ = _ := by
          rw [mul_sum]
          refine sum_congr rfl fun ρ _ => ?_
          rw [mul_sum]
          refine sum_congr rfl fun j _ => ?_
          rw [sum_const, card_univ, ZMod.card, nsmul_eq_mul]
  calc _ ≤ ∑ k ∈ range K, ‖∑ n ∈ 𝒩.filter (fun n => n ∈ Ioc (t k) (t (k + 1))), β n *
        ∑ y ∈ 𝒴, α y * (if y * n ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (y * n) else 0)‖ :=
        norm_sum_le _ _
    _ ≤ ∑ _k ∈ range K, (M : ℝ) * ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ *
          (A ^ 2 * Real.sqrt (2 * WPsi P (c j) X Y N₀)) := sum_le_sum hblock
    _ = _ := by rw [sum_const, card_range, nsmul_eq_mul]; ring

end full

end GoldC.QuillonWBilinear

#print axioms GoldC.QuillonWBilinear.WPsi_anti
#print axioms GoldC.QuillonWBilinear.W_bilinear_full
