import GoldC.QuillonWContext
import GoldC.QuillonTypeIIGen

/-!
# Quillon CSC3 F7.5g: Parseval-W in context (region α ≥ 1+ε, `r = p·n`, `p` large, `n ≥ X`)

* `TIIb`: the closed-form Type II bound of `typeII_eval_gen`, as a function.
* `P_block`: one dyadic `p`-block `(P_k, 2P_k]` with a dyadic `r`-range `(I₀, I₁]`, `I₁ ≤ 2I₀`:
  rescale `α`, `β` to `typeII_gen` normalisation, then `‖·‖ ≤ (2A²/I₀)·TIIb`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset ArithmeticFunction

namespace GoldC.QuillonPContext

open GoldC.QuillonVW GoldC.QuillonTypeIIGen GoldC.QuillonPartition GoldC.QuillonWBilinear

variable {s : ℕ} [NeZero s]

/-- The closed-form Type II bound. -/
noncomputable def TIIb (P : Finset ℕ) (c : ZMod s) (U V T B : ℕ) : ℝ :=
  Real.sqrt (2 * (1 + Real.log (tseq (max U 2) (max T 2)
      (Jstop (max U 2) (max T 2) V B (by omega) (by omega)))) ^ 4) *
    Real.sqrt (Real.log B ^ 2 * B * (Jstop (max U 2) (max T 2) V B (by omega) (by omega) : ℝ) *
      (2 * B / ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ) +
        2 * (tseq (max U 2) (max T 2) (Jstop (max U 2) (max T 2) V B (by omega) (by omega)) : ℝ) +
        s * B / (U * ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ)) +
        s)) +
  Real.log B * (1 + Real.log (tseq (max U 2) (max T 2)
      (Jstop (max U 2) (max T 2) V B (by omega) (by omega)))) ^ 4 *
    (2 * B / T + 2 * B / U + 2 * (tseq (max U 2) (max T 2)
      (Jstop (max U 2) (max T 2) V B (by omega) (by omega)) : ℝ))

lemma typeII_TIIb (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p)
    (c : ZMod s) (U V T A B : ℕ) (hAB : A ≤ B) (hU : 2 ≤ U) (hT : 2 ≤ T)
    (α β : ℕ → ℂ) (hα0 : ∀ d, d ≤ U → α d = 0)
    (hαb : ∀ d, ‖α d‖ ≤ (d.divisors.card : ℝ)) (hβ0 : ∀ m, m ≤ V → β m = 0)
    (hβb : ∀ m, m ≤ B → ‖β m‖ ≤ Real.log B) :
    ‖∑ d ∈ Ioc 0 B, α d * ∑ m ∈ Ioc (A / d) (B / d), β m * kphase c (d * m)‖ ≤
      TIIb P c U V T B := by
  have h := typeII_eval_gen P hP hsP c U V T A B hAB hU hT α β hα0 hαb hβ0 hβb
  have hU' : max U 2 = U := max_eq_left hU
  have hT' : max T 2 = T := max_eq_left hT
  unfold TIIb
  convert h using 3 <;> simp only [hU', hT']

lemma mem_Ioc_div_iff (I₀ I₁ p n : ℕ) (hp : 1 ≤ p) :
    n ∈ Ioc (I₀ / p) (I₁ / p) ↔ p * n ∈ Ioc I₀ I₁ := by
  simp only [mem_Ioc]
  constructor
  · rintro ⟨h1, h2⟩
    refine ⟨?_, ?_⟩
    · rw [Nat.div_lt_iff_lt_mul (by omega)] at h1; linarith [mul_comm n p]
    · rw [Nat.le_div_iff_mul_le (by omega)] at h2; linarith [mul_comm n p]
  · rintro ⟨h1, h2⟩
    refine ⟨?_, ?_⟩
    · rw [Nat.div_lt_iff_lt_mul (by omega)]; linarith [mul_comm n p]
    · rw [Nat.le_div_iff_mul_le (by omega)]; linarith [mul_comm n p]

/-- Scaled form of `typeII_TIIb`. -/
lemma typeII_TIIb_scaled (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p)
    (c : ZMod s) (U V T A B : ℕ) (hAB : A ≤ B) (hU : 2 ≤ U) (hT : 2 ≤ T)
    (α β : ℕ → ℂ) (a b : ℝ) (ha : 0 < a) (hb : 0 < b) (hα0 : ∀ d, d ≤ U → α d = 0)
    (hαb : ∀ d, ‖α d‖ ≤ a * (d.divisors.card : ℝ)) (hβ0 : ∀ m, m ≤ V → β m = 0)
    (hβb : ∀ m, m ≤ B → ‖β m‖ ≤ b * Real.log B) :
    ‖∑ d ∈ Ioc 0 B, α d * ∑ m ∈ Ioc (A / d) (B / d), β m * kphase c (d * m)‖ ≤
      a * b * TIIb P c U V T B := by
  have h := typeII_TIIb P hP hsP c U V T A B hAB hU hT (fun d => α d / (a : ℂ))
    (fun m => β m / (b : ℂ))
    (fun d hd => by simp [hα0 d hd]) (fun d => by
      rw [norm_div, Complex.norm_real, Real.norm_eq_abs, abs_of_pos ha, div_le_iff₀ ha, mul_comm]
      exact hαb d)
    (fun m hm => by simp [hβ0 m hm]) (fun m hm => by
      rw [norm_div, Complex.norm_real, Real.norm_eq_abs, abs_of_pos hb, div_le_iff₀ hb, mul_comm]
      exact hβb m hm)
  have heq : ∑ d ∈ Ioc 0 B, α d * ∑ m ∈ Ioc (A / d) (B / d), β m * kphase c (d * m) =
      ((a * b : ℝ) : ℂ) * ∑ d ∈ Ioc 0 B, (α d / (a : ℂ)) * ∑ m ∈ Ioc (A / d) (B / d),
        (β m / (b : ℂ)) * kphase c (d * m) := by
    have ha' : (a : ℂ) ≠ 0 := by exact_mod_cast ha.ne'
    have hb' : (b : ℂ) ≠ 0 := by exact_mod_cast hb.ne'
    simp only [mul_sum]
    refine sum_congr rfl fun d _ => sum_congr rfl fun m _ => ?_
    push_cast; field_simp
  rw [heq, norm_mul, Complex.norm_real, Real.norm_eq_abs, abs_of_pos (mul_pos ha hb)]
  exact mul_le_mul_of_nonneg_left h (mul_pos ha hb).le

/-- **One Parseval block.** -/
theorem P_block (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p)
    (c : ZMod s) (𝒴 𝒩 : Finset ℕ) (Pk X T I₀ I₁ : ℕ) (hPk : 2 ≤ Pk) (hT : 2 ≤ T)
    (hI : I₀ ≤ I₁) (hI0 : 1 ≤ I₀) (hI₁3 : 3 ≤ I₁)
    (h𝒴 : 𝒴 ⊆ Ioc Pk (2 * Pk)) (h𝒩 : ∀ n ∈ 𝒩, X ≤ n) (hX : 1 ≤ X)
    (α β : ℕ → ℂ) (A : ℝ) (hA : 0 < A) (hα : ∀ p ∈ 𝒴, ‖α p‖ ≤ A / p)
    (hβ : ∀ n ∈ 𝒩, ‖β n‖ ≤ A / n) :
    ‖∑ n ∈ 𝒩, β n * ∑ p ∈ 𝒴, α p *
        (if p * n ∈ Ioc I₀ I₁ then kphase c (p * n) else 0)‖ ≤
      2 * A ^ 2 / I₀ * TIIb P c Pk (X - 1) T I₁ := by
  classical
  set α' : ℕ → ℂ := fun d => if d ∈ 𝒴 then α d else 0 with hα'
  set β' : ℕ → ℂ := fun m => if m ∈ 𝒩 ∧ I₀ < m * (2 * Pk) then β m else 0 with hβ'
  have hconv : ∑ n ∈ 𝒩, β n * ∑ p ∈ 𝒴, α p *
      (if p * n ∈ Ioc I₀ I₁ then kphase c (p * n) else 0) =
      ∑ d ∈ Ioc 0 I₁, α' d * ∑ m ∈ Ioc (I₀ / d) (I₁ / d), β' m * kphase c (d * m) := by
    have e1 : ∑ n ∈ 𝒩, β n * ∑ p ∈ 𝒴, α p *
        (if p * n ∈ Ioc I₀ I₁ then kphase c (p * n) else 0) =
        ∑ p ∈ 𝒴, α p * ∑ n ∈ 𝒩, β n * (if p * n ∈ Ioc I₀ I₁ then kphase c (p * n) else 0) := by
      simp only [mul_sum]; rw [sum_comm]
      refine sum_congr rfl fun p _ => sum_congr rfl fun n _ => by ring
    rw [e1]
    have e2 : ∑ d ∈ Ioc 0 I₁, α' d * ∑ m ∈ Ioc (I₀ / d) (I₁ / d), β' m * kphase c (d * m) =
        ∑ d ∈ 𝒴, α d * ∑ m ∈ Ioc (I₀ / d) (I₁ / d), β' m * kphase c (d * m) := by
      rw [← sum_filter_add_sum_filter_not (Ioc 0 I₁) (fun d => d ∈ 𝒴)]
      have hz : ∑ d ∈ (Ioc 0 I₁).filter (fun d => d ∉ 𝒴), α' d *
          ∑ m ∈ Ioc (I₀ / d) (I₁ / d), β' m * kphase c (d * m) = 0 :=
        sum_eq_zero fun d hd => by simp only [hα', if_neg (mem_filter.1 hd).2, zero_mul]
      rw [hz, add_zero]
      symm
      rw [← sum_filter_add_sum_filter_not 𝒴 (fun d => d ≤ I₁)]
      have hz2 : ∑ d ∈ 𝒴.filter (fun d => ¬ d ≤ I₁), α d *
          ∑ m ∈ Ioc (I₀ / d) (I₁ / d), β' m * kphase c (d * m) = 0 := by
        refine sum_eq_zero fun d hd => ?_
        have : I₁ / d = 0 := Nat.div_eq_of_lt (by have := (mem_filter.1 hd).2; omega)
        rw [this]
        have : I₀ / d = 0 := Nat.div_eq_of_lt (by have := (mem_filter.1 hd).2; omega)
        rw [this, Ioc_self, sum_empty, mul_zero]
      rw [hz2, add_zero]
      apply sum_congr
      · ext d
        simp only [mem_filter, mem_Ioc]
        constructor
        · rintro ⟨hd, hdI⟩
          have := mem_Ioc.1 (h𝒴 hd)
          exact ⟨⟨by omega, hdI⟩, hd⟩
        · rintro ⟨⟨_, hdI⟩, hd⟩; exact ⟨hd, hdI⟩
      · intro d hd
        simp only [hα', if_pos (mem_filter.1 hd).2]
    rw [e2]
    refine sum_congr rfl fun p hp => ?_
    congr 1
    have hp1 := mem_Ioc.1 (h𝒴 hp)
    rw [← sum_filter_add_sum_filter_not 𝒩 (fun n => p * n ∈ Ioc I₀ I₁)]
    have hz : ∑ n ∈ 𝒩.filter (fun n => ¬ p * n ∈ Ioc I₀ I₁), β n *
        (if p * n ∈ Ioc I₀ I₁ then kphase c (p * n) else 0) = 0 :=
      sum_eq_zero fun n hn => by rw [if_neg (mem_filter.1 hn).2, mul_zero]
    rw [hz, add_zero]
    rw [← sum_filter_add_sum_filter_not (Ioc (I₀ / p) (I₁ / p)) (fun m => m ∈ 𝒩 ∧ I₀ < m * (2 * Pk))]
    have hz2 : ∑ m ∈ (Ioc (I₀ / p) (I₁ / p)).filter (fun m => ¬ (m ∈ 𝒩 ∧ I₀ < m * (2 * Pk))),
        β' m * kphase c (p * m) = 0 :=
      sum_eq_zero fun m hm => by simp only [hβ', if_neg (mem_filter.1 hm).2, zero_mul]
    rw [hz2, add_zero]
    apply sum_congr
    · ext n
      simp only [mem_filter]
      rw [mem_Ioc_div_iff I₀ I₁ p n (by omega)]
      constructor
      · rintro ⟨hn, hI'⟩
        refine ⟨hI', hn, ?_⟩
        have := (mem_Ioc.1 hI').1
        have : p * n ≤ 2 * Pk * n := Nat.mul_le_mul_right n hp1.2
        nlinarith
      · rintro ⟨hI', hn, _⟩; exact ⟨hn, hI'⟩
    · intro n hn
      have hn' := mem_filter.1 hn
      have hI' : p * n ∈ Ioc I₀ I₁ := (mem_Ioc_div_iff I₀ I₁ p n (by omega)).1 hn'.1
      simp only [hβ', if_pos hn'.2, if_pos hI']
  rw [hconv]
  have hPkR : (0 : ℝ) < Pk := by exact_mod_cast (show 0 < Pk by omega)
  have hI0R : (0 : ℝ) < I₀ := by exact_mod_cast hI0
  have hlogB : (1 : ℝ) ≤ Real.log I₁ := by
    rw [Real.le_log_iff_exp_le (by positivity)]
    have : Real.exp 1 < 3 := by
      have := Real.exp_one_lt_d9; norm_num at this ⊢; linarith
    have h3 : (3 : ℝ) ≤ I₁ := by exact_mod_cast hI₁3
    linarith
  have h := typeII_TIIb_scaled P hP hsP c Pk (X - 1) T I₀ I₁ hI hPk hT α' β'
    (A / Pk) (2 * A * Pk / I₀) (by positivity) (by positivity)
    (fun d hd => by
      simp only [hα']
      rw [if_neg]; intro hd'; have := (mem_Ioc.1 (h𝒴 hd')).1; omega)
    (fun d => by
      simp only [hα']
      split_ifs with hd
      · have hdP := (mem_Ioc.1 (h𝒴 hd)).1
        have hdR : (Pk : ℝ) < d := by exact_mod_cast hdP
        have h1 : (1 : ℝ) ≤ (d.divisors.card : ℝ) := by
          have : 1 ≤ d.divisors.card := Finset.card_pos.2 ⟨1, Nat.one_mem_divisors.2 (by omega)⟩
          exact_mod_cast this
        calc ‖α d‖ ≤ A / d := hα d hd
          _ ≤ A / Pk := div_le_div_of_nonneg_left hA.le hPkR hdR.le
          _ = A / Pk * 1 := (mul_one _).symm
          _ ≤ A / Pk * (d.divisors.card : ℝ) := mul_le_mul_of_nonneg_left h1 (by positivity)
      · rw [norm_zero]; positivity)
    (fun m hm => by
      simp only [hβ']
      rw [if_neg]; rintro ⟨hm', _⟩; have := h𝒩 m hm'; omega)
    (fun m _ => by
      simp only [hβ']
      split_ifs with hm
      · have hmR : (0 : ℝ) < m := by
          have := h𝒩 m hm.1; exact_mod_cast (show 0 < m by omega)
        have hlt : (I₀ : ℝ) < m * (2 * Pk) := by exact_mod_cast hm.2
        calc ‖β m‖ ≤ A / m := hβ m hm.1
          _ ≤ 2 * A * Pk / I₀ := by
              rw [div_le_div_iff₀ hmR hI0R]; nlinarith
          _ = 2 * A * Pk / I₀ * 1 := (mul_one _).symm
          _ ≤ _ := mul_le_mul_of_nonneg_left hlogB (by positivity)
      · rw [norm_zero]; positivity)
  refine h.trans (le_of_eq ?_)
  field_simp

section full
variable {M : ℕ} [NeZero M]

/-- **Parseval-W, all classes and modes, dyadic `p`-blocks, one dyadic `r`-range.** -/
theorem P_bilinear_full (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p)
    (𝒥 : Finset ℕ) (Acoef : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s)
    (𝒴 𝒩 : Finset ℕ) (P₀ Kp X T I₀ I₁ : ℕ) (hP₀ : 2 ≤ P₀) (hT : 2 ≤ T) (hX : 1 ≤ X)
    (hI : I₀ ≤ I₁) (hI0 : 1 ≤ I₀) (hI₁3 : 3 ≤ I₁)
    (h𝒴 : 𝒴 ⊆ Ioc P₀ (2 ^ Kp * P₀)) (huM : ∀ y ∈ 𝒴, IsUnit (y : ZMod M))
    (h𝒩 : ∀ n ∈ 𝒩, X ≤ n)
    (α β : ℕ → ℂ) (A : ℝ) (hA : 0 < A) (hα : ∀ p ∈ 𝒴, ‖α p‖ ≤ A / p)
    (hβ : ∀ n ∈ 𝒩, ‖β n‖ ≤ A / n) :
    ‖∑ n ∈ 𝒩, β n * ∑ p ∈ 𝒴, α p *
        (if p * n ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (p * n) else 0)‖ ≤
      ∑ k ∈ range Kp, (M : ℝ) * ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ *
        (2 * A ^ 2 / I₀ * TIIb P (c j) (2 ^ k * P₀) (X - 1) T I₁) := by
  classical
  set t : ℕ → ℕ := fun k => 2 ^ k * P₀ with ht
  have htm : Monotone t := fun a b hab =>
    Nat.mul_le_mul_right _ (Nat.pow_le_pow_right (by norm_num) hab)
  have h𝒴' : 𝒴 ⊆ Ioc (t 0) (t Kp) := by simpa [ht] using h𝒴
  set E : ℕ → ℕ → ℂ := fun p n =>
    if p * n ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (p * n) else 0 with hE
  -- dyadic split in p
  have hsplit : ∑ n ∈ 𝒩, β n * ∑ p ∈ 𝒴, α p * E p n =
      ∑ k ∈ range Kp, ∑ n ∈ 𝒩, β n *
        ∑ p ∈ 𝒴.filter (fun p => p ∈ Ioc (t k) (t (k + 1))), α p * E p n := by
    rw [sum_comm]
    refine sum_congr rfl fun n _ => ?_
    rw [GoldC.QuillonWBilinear.sum_dyadic 𝒴 t htm Kp h𝒴' (fun p => α p * E p n), mul_sum]
  rw [hsplit]
  refine (norm_sum_le _ _).trans (sum_le_sum fun k _ => ?_)
  set 𝒴k := 𝒴.filter (fun p => p ∈ Ioc (t k) (t (k + 1)))
  have hPk : 2 ≤ 2 ^ k * P₀ := le_trans hP₀ (Nat.le_mul_of_pos_left _ (by positivity))
  have h𝒴k : 𝒴k ⊆ Ioc (2 ^ k * P₀) (2 * (2 ^ k * P₀)) := by
    intro p hp
    have := (mem_filter.1 hp).2
    simp only [ht, pow_succ] at this
    simpa [mul_comm, mul_assoc, mul_left_comm] using this
  -- class and mode expansion (as in `W_bilinear_full`)
  set Kp' : ℕ → ℕ → ℕ → ℂ := fun j n y =>
    if y * n ∈ Ioc I₀ I₁ then kphase (c j) (y * n) else 0 with hKp
  set bρ : ZMod M → ZMod M → ℕ → ℂ := fun ρ ρ₁ n =>
    β n * (if (n : ZMod M) = ρ * ρ₁⁻¹ then (1 : ℂ) else 0) with hbρ
  set aρ : ZMod M → ℕ → ℂ := fun ρ₁ y => α y * (if (y : ZMod M) = ρ₁ then (1 : ℂ) else 0) with haρ
  have hpt : ∀ n y, y ∈ 𝒴 → β n * (α y * E y n) =
      ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ∑ ρ₁ : ZMod M, Acoef ρ j * (bρ ρ ρ₁ n * (aρ ρ₁ y * Kp' j n y)) := by
    intro n y hy
    have h1 : ∀ ρ j, ∑ ρ₁ : ZMod M, Acoef ρ j * (bρ ρ ρ₁ n * (aρ ρ₁ y * Kp' j n y)) =
        Acoef ρ j * β n * α y * Kp' j n y *
          (if ((y * n : ℕ) : ZMod M) = ρ then (1 : ℂ) else 0) := by
      intro ρ j
      rw [class_split_unit ρ y n (huM y hy), mul_sum]
      refine sum_congr rfl fun ρ₁ _ => ?_
      simp only [hbρ, haρ]; ring
    simp only [h1]
    simp only [hKp, hE, rowW]
    by_cases hI' : y * n ∈ Ioc I₀ I₁
    · simp only [if_pos hI']
      rw [mul_sum, mul_sum]
      refine sum_congr rfl fun ρ _ => ?_
      by_cases hρ : ((y * n : ℕ) : ZMod M) = ρ
      · rw [if_pos hρ, mul_sum, mul_sum]
        refine sum_congr rfl fun j _ => ?_
        rw [if_pos hρ]; ring
      · rw [if_neg hρ, mul_zero, mul_zero]
        symm; refine sum_eq_zero fun j _ => ?_
        rw [if_neg hρ, mul_zero]
    · simp only [if_neg hI', mul_zero]
      symm
      exact sum_eq_zero fun ρ _ => sum_eq_zero fun j _ => by ring
  have hexp : ∑ n ∈ 𝒩, β n * ∑ p ∈ 𝒴k, α p * E p n =
      ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ∑ ρ₁ : ZMod M, Acoef ρ j *
        ∑ n ∈ 𝒩, bρ ρ ρ₁ n * ∑ y ∈ 𝒴k, aρ ρ₁ y * Kp' j n y := by
    have e1 : ∑ n ∈ 𝒩, β n * ∑ p ∈ 𝒴k, α p * E p n =
        ∑ n ∈ 𝒩, ∑ y ∈ 𝒴k, ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ∑ ρ₁ : ZMod M,
          Acoef ρ j * (bρ ρ ρ₁ n * (aρ ρ₁ y * Kp' j n y)) := by
      refine sum_congr rfl fun n _ => ?_
      rw [mul_sum]
      exact sum_congr rfl fun y hy => hpt n y (mem_filter.1 hy).1
    rw [e1, GoldC.QuillonWBilinear.sum5]
    refine sum_congr rfl fun ρ _ => sum_congr rfl fun j _ => sum_congr rfl fun ρ₁ _ => ?_
    rw [mul_sum]
    refine sum_congr rfl fun n _ => ?_
    rw [mul_sum, mul_sum]
  rw [hexp]
  have hpiece : ∀ ρ ρ₁ j, ‖∑ n ∈ 𝒩, bρ ρ ρ₁ n * ∑ y ∈ 𝒴k, aρ ρ₁ y * Kp' j n y‖ ≤
      2 * A ^ 2 / I₀ * TIIb P (c j) (2 ^ k * P₀) (X - 1) T I₁ := by
    intro ρ ρ₁ j
    exact P_block P hP hsP (c j) 𝒴k 𝒩 (2 ^ k * P₀) X T I₀ I₁ hPk hT hI hI0 hI₁3 h𝒴k h𝒩 hX
      (aρ ρ₁) (bρ ρ ρ₁) A hA
      (fun y hy => by
        simp only [haρ]; split_ifs
        · rw [mul_one]; exact hα y (mem_filter.1 hy).1
        · rw [mul_zero, norm_zero]
          have := (mem_Ioc.1 (h𝒴k hy)).1
          have : (0 : ℝ) < y := by exact_mod_cast (show 0 < y by omega)
          positivity)
      (fun n hn => by
        simp only [hbρ]; split_ifs
        · rw [mul_one]; exact hβ n hn
        · rw [mul_zero, norm_zero]
          have := h𝒩 n hn
          have : (0 : ℝ) < n := by exact_mod_cast (show 0 < n by omega)
          positivity)
  calc _ ≤ ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ∑ ρ₁ : ZMod M, ‖Acoef ρ j‖ *
        (2 * A ^ 2 / I₀ * TIIb P (c j) (2 ^ k * P₀) (X - 1) T I₁) := by
        refine (norm_sum_le _ _).trans (sum_le_sum fun ρ _ => ?_)
        refine (norm_sum_le _ _).trans (sum_le_sum fun j _ => ?_)
        refine (norm_sum_le _ _).trans (sum_le_sum fun ρ₁ _ => ?_)
        rw [norm_mul]
        exact mul_le_mul_of_nonneg_left (hpiece ρ ρ₁ j) (norm_nonneg _)
    _ = _ := by
        rw [mul_sum]
        refine sum_congr rfl fun ρ _ => ?_
        rw [mul_sum]
        refine sum_congr rfl fun j _ => ?_
        rw [sum_const, card_univ, ZMod.card, nsmul_eq_mul]

end full

end GoldC.QuillonPContext

#print axioms GoldC.QuillonPContext.typeII_TIIb
#print axioms GoldC.QuillonPContext.P_block
#print axioms GoldC.QuillonPContext.P_bilinear_full
