import GoldC.QuillonResPhysical

/-!
# Quillon CSC3 F8.14: **CORE end to end** — `SourceUniformSublog (signedCoreMiddle Jlow Jhigh δ)`

* `split5`: exact five-way split of a masked summand (instance-agnostic).
* `pair_decomp`: for every decoration `d`,

      regionPairSumMiddleWhere (CORE) d (foldRow …) = WPart + CPart + RPart + ResAPart + BandPart.

  This is exact: `pairSum_eq_double` followed by the pointwise `split5`.
* `core_pair_le`: `|regionPairSumMiddleWhere (CORE) d (foldRow …)| ≤ 5Λ^{0.998}`, eventually,
  uniformly in `a`, `d ⊆ primeFactors h`, `Jlow`, `Jhigh`.
* **`core_sublog`**: `SourceUniformSublog (fun q a h => signedCoreMiddle Jlow Jhigh δ q a h)` for
  `0 < δ < 1/3`. Lemma G (`decoration_mass_le_loglog_pow`) controls the decoration mass.

All definitions are the verbatim source copies (`QuillonCopyS/G/F/M`).
No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonCoreFinal

open Classical
open GoldC.QuillonEv GoldC.QuillonSetup GoldC.QuillonLam GoldC.QuillonCEv GoldC.QuillonCFinal
  GoldC.QuillonREv GoldC.QuillonWContext GoldC.QuillonRPhysical GoldC.QuillonResPhysical
  GoldC.QuillonCPhysical
open GoldC.QuillonCopyS GoldC.QuillonCopyF GoldC.QuillonCopyM GoldC.QuillonWPhysical

lemma split5 {e1 e2 e3 m w g sm j : Prop} (f : ℝ) (i0 : Decidable (e1 ∧ e2 ∧ e3 ∧ m))
    (i1 : Decidable (e1 ∧ e2 ∧ e3 ∧ (m ∧ w))) (i2 : Decidable (e1 ∧ e2 ∧ e3 ∧ (m ∧ ¬ w ∧ g)))
    (i3 : Decidable (e1 ∧ e2 ∧ e3 ∧ (m ∧ ¬ w ∧ ¬ g ∧ sm ∧ j)))
    (i4 : Decidable (e1 ∧ e2 ∧ e3 ∧ (m ∧ ¬ w ∧ ¬ g ∧ sm ∧ ¬ j)))
    (i5 : Decidable (e1 ∧ e2 ∧ e3 ∧ (m ∧ ¬ w ∧ ¬ g ∧ ¬ sm))) :
    @ite _ (e1 ∧ e2 ∧ e3 ∧ m) i0 f 0 =
      @ite _ _ i1 f 0 + @ite _ _ i2 f 0 + @ite _ _ i3 f 0 + @ite _ _ i4 f 0 + @ite _ _ i5 f 0 := by
  by_cases ha : e1 ∧ e2 ∧ e3 ∧ m
  · obtain ⟨h1, h2, h3, hm⟩ := ha
    by_cases hw : w
    · simp [h1, h2, h3, hm, hw]
    by_cases hg : g
    · simp [h1, h2, h3, hm, hw, hg]
    by_cases hs : sm
    · by_cases hj : j
      · simp [h1, h2, h3, hm, hw, hg, hs, hj]
      · simp [h1, h2, h3, hm, hw, hg, hs, hj]
    · simp [h1, h2, h3, hm, hw, hg, hs]
  · have n1 : ¬ (e1 ∧ e2 ∧ e3 ∧ (m ∧ w)) := fun ⟨a, b, c, d, _⟩ => ha ⟨a, b, c, d⟩
    have n2 : ¬ (e1 ∧ e2 ∧ e3 ∧ (m ∧ ¬ w ∧ g)) := fun ⟨a, b, c, d, _⟩ => ha ⟨a, b, c, d⟩
    have n3 : ¬ (e1 ∧ e2 ∧ e3 ∧ (m ∧ ¬ w ∧ ¬ g ∧ sm ∧ j)) := fun ⟨a, b, c, d, _⟩ => ha ⟨a, b, c, d⟩
    have n4 : ¬ (e1 ∧ e2 ∧ e3 ∧ (m ∧ ¬ w ∧ ¬ g ∧ sm ∧ ¬ j)) := fun ⟨a, b, c, d, _⟩ => ha ⟨a, b, c, d⟩
    have n5 : ¬ (e1 ∧ e2 ∧ e3 ∧ (m ∧ ¬ w ∧ ¬ g ∧ ¬ sm)) := fun ⟨a, b, c, d, _⟩ => ha ⟨a, b, c, d⟩
    rw [if_neg ha, if_neg n1, if_neg n2, if_neg n3, if_neg n4, if_neg n5]; ring

/-- **Exact five-cell decomposition of the CORE pair sum at decoration `d`.** -/
theorem pair_decomp (Jlow Jhigh q a h : ℕ) (δ : ℝ) (d : Finset ℕ) :
    regionPairSumMiddleWhere Jlow Jhigh q h (centralGate h) (fun r s => ¬ longEither δ r s) d
        (foldRow q a (primeSetProduct d)) =
      WPart Jlow Jhigh q a h δ d + CPart Jlow Jhigh q a h δ d + RPart Jlow Jhigh q a h δ d +
        ResAPart Jlow Jhigh q a h δ d + BandPart Jlow Jhigh q a h δ d := by
  rw [pairSum_eq_double]
  unfold WPart CPart RPart ResAPart BandPart Tsrc
  simp only [← sum_add_distrib]
  refine sum_congr rfl fun B _ => sum_congr rfl fun C _ => ?_
  unfold pairTerm
  exact split5 _ _ _ _ _ _ _


/-- **The CORE pair sum at any decoration is `≤ 5Λ^{0.998}`**, eventually, uniformly. -/
theorem core_pair_le (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (Jlow Jhigh a h : ℕ) (d : Finset ℕ), Λ₀ ≤ Real.log h → 2 ≤ h →
      d ⊆ h.primeFactors →
      |regionPairSumMiddleWhere Jlow Jhigh q h (centralGate h) (fun r s => ¬ longEither δ r s) d
          (foldRow q a (primeSetProduct d))| ≤ 5 * (Real.log h) ^ (998 / 1000 : ℝ) := by
  obtain ⟨Λ₁, hΛ₁, hW⟩ := W_physical q hq δ hδ0 hδ1
  obtain ⟨Λ₂, hΛ₂, hC⟩ := C_physical q hq δ hδ0 hδ1
  obtain ⟨Λ₃, hΛ₃, hR⟩ := R_physical q hq δ hδ0 hδ1
  obtain ⟨Λ₄, hΛ₄, hA⟩ := ResA_physical q hq δ hδ0 hδ1
  obtain ⟨Λ₅, hΛ₅, hB⟩ := Band_physical q hq δ hδ0 hδ1
  refine ⟨max Λ₁ (max Λ₂ (max Λ₃ (max Λ₄ Λ₅))), le_trans hΛ₁ (le_max_left _ _), ?_⟩
  intro Jlow Jhigh a h d hΛ hh hd
  have L1 : Λ₁ ≤ Real.log h := le_trans (by simp) hΛ
  have L2 : Λ₂ ≤ Real.log h := le_trans (by simp) hΛ
  have L3 : Λ₃ ≤ Real.log h := le_trans (by simp) hΛ
  have L4 : Λ₄ ≤ Real.log h := le_trans (by simp) hΛ
  have L5 : Λ₅ ≤ Real.log h := le_trans (by simp) hΛ
  have hΛ1 : 1 ≤ Real.log h := by linarith
  rw [pair_decomp]
  have w := hW Jlow Jhigh a h d L1 hh
  have c := hC Jlow Jhigh a h d L2 hh hd
  have r := hR Jlow Jhigh a h d L3 hh
  have ra := hA Jlow Jhigh a h d L4 hh
  have b := hB Jlow Jhigh a h d L5 hh
  have m1 : (Real.log h) ^ (-(80 : ℝ)) ≤ (Real.log h) ^ (998 / 1000 : ℝ) :=
    Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)
  have m2 : (Real.log h) ^ (-(15 : ℝ)) ≤ (Real.log h) ^ (998 / 1000 : ℝ) :=
    Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)
  have m3 : (Real.log h) ^ (-(75 : ℝ)) ≤ (Real.log h) ^ (998 / 1000 : ℝ) :=
    Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)
  have m4 : (Real.log h) ^ (1 / 10 : ℝ) ≤ (Real.log h) ^ (998 / 1000 : ℝ) :=
    Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)
  calc _ ≤ |WPart Jlow Jhigh q a h δ d| + |CPart Jlow Jhigh q a h δ d| + |RPart Jlow Jhigh q a h δ d| +
        |ResAPart Jlow Jhigh q a h δ d| + |BandPart Jlow Jhigh q a h δ d| := by
        have := abs_add_le (WPart Jlow Jhigh q a h δ d + CPart Jlow Jhigh q a h δ d +
          RPart Jlow Jhigh q a h δ d + ResAPart Jlow Jhigh q a h δ d) (BandPart Jlow Jhigh q a h δ d)
        have := abs_add_le (WPart Jlow Jhigh q a h δ d + CPart Jlow Jhigh q a h δ d +
          RPart Jlow Jhigh q a h δ d) (ResAPart Jlow Jhigh q a h δ d)
        have := abs_add_le (WPart Jlow Jhigh q a h δ d + CPart Jlow Jhigh q a h δ d)
          (RPart Jlow Jhigh q a h δ d)
        have := abs_add_le (WPart Jlow Jhigh q a h δ d) (CPart Jlow Jhigh q a h δ d)
        linarith
    _ ≤ 5 * (Real.log h) ^ (998 / 1000 : ℝ) := by linarith

/-- **CORE (δ < 1/3) end to end.** `signedCoreMiddle Jlow Jhigh δ` is uniformly sublogarithmic,
for arbitrary cutoff functions `Jlow` and `Jhigh`. -/
theorem core_sublog (Jlow Jhigh : ℕ → ℕ) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    SourceUniformSublog (fun q a h => signedCoreMiddle Jlow Jhigh δ q a h) := by
  intro q hq _hsq eps heps
  obtain ⟨Λ₁, hΛ₁, hP⟩ := core_pair_le q hq δ hδ0 hδ1
  obtain ⟨Λ₂, hΛ₂, hpl⟩ := polylog_le 8 (1 / 1000) (by norm_num)
  obtain ⟨Λ₃, hΛ₃, hK⟩ := const_le_rpow (1280 * Real.exp 10 / eps) (1 / 1000) (by norm_num)
  set Λs := max Λ₁ (max Λ₂ Λ₃) with hΛs
  refine ⟨⌈Real.exp Λs⌉₊ + 16, ?_⟩
  intro a h _ha _hh0 _hpar hH0
  have hh16 : 16 ≤ h := by omega
  have hh0 : (0 : ℝ) < h := by exact_mod_cast (show 0 < h by omega)
  have hlog : Λs ≤ Real.log h := by
    have h1 : Real.exp Λs ≤ h := by
      have : (⌈Real.exp Λs⌉₊ : ℝ) ≤ h := by exact_mod_cast (show ⌈Real.exp Λs⌉₊ ≤ h by omega)
      exact le_trans (Nat.le_ceil _) this
    calc Λs = Real.log (Real.exp Λs) := (Real.log_exp _).symm
      _ ≤ Real.log h := Real.log_le_log (Real.exp_pos _) h1
  have L1 : Λ₁ ≤ Real.log h := le_trans (by simp [hΛs]) hlog
  have L2 : Λ₂ ≤ Real.log h := le_trans (by simp [hΛs]) hlog
  have L3 : Λ₃ ≤ Real.log h := le_trans (by simp [hΛs]) hlog
  set Λ := Real.log h with hΛdef
  have hΛ2 : 2 ≤ Λ := le_trans hΛ₁ L1
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  -- unfold the CORE sum
  show |signedCoreMiddle Jlow Jhigh δ q a h| ≤ eps * Λ
  unfold signedCoreMiddle regionSumMiddleWhere regionDecorations
  set P := GoldC.QuillonCopyG.decoratedHeightPrimeSet q h with hPdef
  have hV0 : ∀ d ∈ P.powerset, 0 ≤ GoldC.QuillonCopyG.decorationWeight h d := by
    intro d hd
    unfold GoldC.QuillonCopyG.decorationWeight
    refine prod_nonneg fun p hp => ?_
    have h5 := (GoldC.QuillonCopyG.mem_P (mem_powerset.1 hd hp)).2.2.1
    have : (5 : ℝ) ≤ p := by exact_mod_cast h5
    split_ifs
    · exact div_nonneg zero_le_one (by linarith)
    · exact div_nonneg zero_le_one (by linarith)
  have hdpf : ∀ d ∈ P.powerset, d ⊆ h.primeFactors := by
    intro d hd p hp
    obtain ⟨hpp, hph, -, hh0'⟩ := GoldC.QuillonCopyG.mem_P (mem_powerset.1 hd hp)
    exact Nat.mem_primeFactors.2 ⟨hpp, hph, hh0'⟩
  have hG := GoldC.QuillonCopyG.decoration_mass_le_loglog_pow q h hh16
  rw [← hPdef] at hG
  have hll : (Real.log Λ / Real.log 2 + 1) ^ 8 ≤ 256 * (1 + Real.log Λ) ^ 8 := by
    have hl2 : (1 / 2 : ℝ) < Real.log 2 := GoldC.QuillonLam.log2_gt_half
    have hlΛ : 0 ≤ Real.log Λ := Real.log_nonneg hΛ1
    have h1 : Real.log Λ / Real.log 2 + 1 ≤ 2 * (1 + Real.log Λ) := by
      have : Real.log Λ / Real.log 2 ≤ 2 * Real.log Λ := by
        rw [div_le_iff₀ (by linarith)]; nlinarith
      linarith
    calc (Real.log Λ / Real.log 2 + 1) ^ 8 ≤ (2 * (1 + Real.log Λ)) ^ 8 :=
          pow_le_pow_left₀ (by positivity) h1 8
      _ = 256 * (1 + Real.log Λ) ^ 8 := by ring
  have hpl' := hpl Λ L2
  have hK' := hK Λ L3
  calc |∑ d ∈ P.powerset, GoldC.QuillonCopyG.decorationWeight h d *
          regionPairSumMiddleWhere (Jlow h) (Jhigh h) q h (centralGate h) (fun r s => ¬ longEither δ r s) d
            (foldRow q a (primeSetProduct d))|
      ≤ ∑ d ∈ P.powerset, GoldC.QuillonCopyG.decorationWeight h d * (5 * Λ ^ (998 / 1000 : ℝ)) := by
        refine le_trans (abs_sum_le_sum_abs _ _) (sum_le_sum fun d hd => ?_)
        rw [abs_mul, abs_of_nonneg (hV0 d hd)]
        exact mul_le_mul_of_nonneg_left (hP (Jlow h) (Jhigh h) a h d L1 (by omega) (hdpf d hd)) (hV0 d hd)
    _ = (∑ d ∈ P.powerset, GoldC.QuillonCopyG.decorationWeight h d) * (5 * Λ ^ (998 / 1000 : ℝ)) := by
        rw [sum_mul]
    _ ≤ (Real.exp 10 * (256 * Λ ^ (1 / 1000 : ℝ))) * (5 * Λ ^ (998 / 1000 : ℝ)) := by
        apply mul_le_mul_of_nonneg_right _ (by positivity)
        refine le_trans hG ?_
        apply mul_le_mul_of_nonneg_left _ (Real.exp_pos _).le
        exact le_trans hll (by linarith)
    _ = 1280 * Real.exp 10 * Λ ^ (999 / 1000 : ℝ) := by
        rw [show Λ ^ (999 / 1000 : ℝ) = Λ ^ (1 / 1000 : ℝ) * Λ ^ (998 / 1000 : ℝ) by
          rw [← Real.rpow_add hΛ0]; norm_num]
        ring
    _ ≤ eps * Λ := by
        have e : Λ = Λ ^ (1 / 1000 : ℝ) * Λ ^ (999 / 1000 : ℝ) := by
          rw [← Real.rpow_add hΛ0]; norm_num
        have hp : 0 ≤ Λ ^ (999 / 1000 : ℝ) := by positivity
        have h1 : 1280 * Real.exp 10 ≤ eps * Λ ^ (1 / 1000 : ℝ) := by
          rw [div_le_iff₀ heps] at hK'; linarith
        calc 1280 * Real.exp 10 * Λ ^ (999 / 1000 : ℝ) ≤ eps * Λ ^ (1 / 1000 : ℝ) * Λ ^ (999 / 1000 : ℝ) :=
              mul_le_mul_of_nonneg_right h1 hp
          _ = eps * Λ := by rw [mul_assoc, ← e]

end GoldC.QuillonCoreFinal

#print axioms GoldC.QuillonCoreFinal.split5
#print axioms GoldC.QuillonCoreFinal.pair_decomp
#print axioms GoldC.QuillonCoreFinal.core_pair_le
#print axioms GoldC.QuillonCoreFinal.core_sublog
