import GoldC.QuillonAP
import GoldC.QuillonTypeIIGen
import GoldC.QuillonVWSum

/-!
# Quillon CSC3 F7.4k: Vaughan for `Σ_{n ≡ ρ (Q)} Λ(n) e(c n̄/s)`, `(Q,s) = 1`, `ρ` a unit mod `Q`

* `typeI1_class`, `typeI2_class`: Type I with the class restriction, via `ap_kphase_bound_w`.
* `typeII_class`: Type II, split over `δ = d mod Q`, using `typeII_eval_gen` (factor `Q`).
* **`vw_lambda_class`**: the assembled bound.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset ArithmeticFunction

namespace GoldC.QuillonVWClass

open GoldC.QuillonVW GoldC.QuillonTypeII GoldC.QuillonPartition GoldC.QuillonTypeIIEval
  GoldC.QuillonTypeIIGen GoldC.QuillonVWSum GoldC.QuillonAP

section classes
variable {Q : ℕ} [NeZero Q]

lemma natCast_eq_iff_mod (m : ℕ) (x : ZMod Q) : (m : ZMod Q) = x ↔ m % Q = x.val := by
  constructor
  · intro h; rw [← h, ZMod.val_natCast]
  · intro h
    apply ZMod.val_injective
    rw [ZMod.val_natCast, h]

lemma class_mul_iff (ρ : ZMod Q) (d m : ℕ) (hd : IsUnit (d : ZMod Q)) :
    ((d * m : ℕ) : ZMod Q) = ρ ↔ m % Q = (ρ * (d : ZMod Q)⁻¹).val := by
  rw [← natCast_eq_iff_mod, Nat.cast_mul]
  have h1 : (d : ZMod Q) * (d : ZMod Q)⁻¹ = 1 := ZMod.mul_inv_of_unit _ hd
  constructor
  · intro h; rw [← h, mul_comm (d : ZMod Q), mul_assoc, h1, mul_one]
  · intro h; rw [h, mul_comm, mul_assoc, mul_comm _ (d : ZMod Q), h1, mul_one]

lemma class_mul_nonunit (ρ : ZMod Q) (hρ : IsUnit ρ) (d m : ℕ) (hd : ¬ IsUnit (d : ZMod Q)) :
    ((d * m : ℕ) : ZMod Q) ≠ ρ := by
  intro h
  rw [Nat.cast_mul] at h
  exact hd (isUnit_of_mul_isUnit_left (h ▸ hρ))

end classes

lemma typeI_outer_gen (B D₀ : ℕ) (S L : ℝ) (hS : 0 < S) :
    ∑ d ∈ Ioc 0 D₀, (((B / d : ℕ) : ℝ) / S + 1 + L) ≤ B * (1 + Real.log D₀) / S + D₀ * (1 + L) := by
  calc _ ≤ ∑ d ∈ Ioc 0 D₀, ((B : ℝ) / S * (1 / (d : ℝ)) + (1 + L)) := by
        refine sum_le_sum fun d hd => ?_
        have hdR : (0 : ℝ) < d := by exact_mod_cast (mem_Ioc.1 hd).1
        have h1 : ((B / d : ℕ) : ℝ) ≤ (B : ℝ) / d := Nat.cast_div_le
        have : ((B / d : ℕ) : ℝ) / S ≤ (B : ℝ) / S * (1 / (d : ℝ)) := by
          rw [div_mul_div_comm, mul_one, mul_comm S]
          calc ((B / d : ℕ) : ℝ) / S ≤ ((B : ℝ) / d) / S := div_le_div_of_nonneg_right h1 hS.le
            _ = _ := by rw [div_div]
        linarith
    _ = (B : ℝ) / S * ∑ d ∈ Ioc 0 D₀, (1 / (d : ℝ)) + D₀ * (1 + L) := by
        rw [sum_add_distrib, ← mul_sum, sum_const, Nat.card_Ioc, nsmul_eq_mul]; simp only [Nat.sub_zero]
    _ ≤ (B : ℝ) / S * (1 + Real.log D₀) + D₀ * (1 + L) := by
        gcongr; exact harm_Ioc_le D₀
    _ = _ := by ring

lemma log_nat_mono : Monotone (fun n : ℕ => Real.log n) := fun a b hab => by
  rcases Nat.eq_zero_or_pos a with h | h
  · simp [h, Real.log_natCast_nonneg]
  · exact Real.log_le_log (by exact_mod_cast h) (by exact_mod_cast hab)

section main
variable {s : ℕ} [NeZero s] {Q : ℕ} [NeZero Q]

/-- The class-restricted phase. -/
noncomputable def cphase (ρ : ZMod Q) (c : ZMod s) (n : ℕ) : ℂ :=
  if (n : ZMod Q) = ρ then kphase c n else 0

lemma norm_cphase_le (ρ : ZMod Q) (c : ZMod s) (n : ℕ) : ‖cphase ρ c n‖ ≤ 1 := by
  unfold cphase; split_ifs
  · exact norm_kphase_le c n
  · simp

/-- Inner class-restricted sum with a monotone weight, for fixed `d`. -/
lemma inner_class_bound (hs : 2 ≤ s) (c : ZMod s) (ρ : ZMod Q) (hρ : IsUnit ρ)
    (hcop : Nat.Coprime Q s) (d X Y : ℕ) (hXY : X ≤ Y) (Kmax : ℝ)
    (hK : ∀ u : ZMod s, IsUnit u → ∀ b : ZMod s, ‖GoldC.QuillonKl.K s b (c * u)‖ ≤ Kmax)
    (hK0 : 0 ≤ Kmax) (g : ℕ → ℝ) (hg0 : ∀ n, 0 ≤ g n) (hgm : Monotone g) :
    ‖∑ m ∈ Ioc X Y, (g m : ℂ) * cphase ρ c (d * m)‖ ≤
      g Y * (1 + 2 * Kmax * (((Y - X : ℕ) : ℝ) / (Q * s) + 1 + Real.log s)) := by
  have hlogs : 0 ≤ Real.log s := Real.log_nonneg (by exact_mod_cast (show 1 ≤ s by omega))
  have hRHS : 0 ≤ g Y * (1 + 2 * Kmax * (((Y - X : ℕ) : ℝ) / (Q * s) + 1 + Real.log s)) := by
    have := hg0 Y; positivity
  by_cases hdQ : IsUnit (d : ZMod Q)
  · by_cases hds : IsUnit (d : ZMod s)
    · have hrw : ∑ m ∈ Ioc X Y, (g m : ℂ) * cphase ρ c (d * m) =
          ∑ m ∈ (Ioc X Y).filter (fun m => m % Q = (ρ * (d : ZMod Q)⁻¹).val),
            (g m : ℂ) * kphase (c * (d : ZMod s)⁻¹) m := by
        rw [sum_filter]
        refine sum_congr rfl fun m _ => ?_
        simp only [cphase]
        by_cases hm : m % Q = (ρ * (d : ZMod Q)⁻¹).val
        · rw [if_pos ((class_mul_iff ρ d m hdQ).2 hm), if_pos hm, kphase_mul, if_pos hds]
        · rw [if_neg (fun h => hm ((class_mul_iff ρ d m hdQ).1 h)), if_neg hm, mul_zero]
      rw [hrw]
      have hQ1 : 1 ≤ Q := Nat.one_le_iff_ne_zero.2 (NeZero.ne Q)
      exact ap_kphase_bound_w hs _ Q _ X Y hQ1 (ZMod.val_lt _) hcop hXY Kmax
        (hK _ (unit_inv_isUnit hds)) g hg0 hgm
    · have : ∑ m ∈ Ioc X Y, (g m : ℂ) * cphase ρ c (d * m) = 0 := by
        refine sum_eq_zero fun m _ => ?_
        simp only [cphase, kphase_mul, if_neg hds, ite_self, mul_zero]
      rw [this, norm_zero]; exact hRHS
  · have : ∑ m ∈ Ioc X Y, (g m : ℂ) * cphase ρ c (d * m) = 0 := by
      refine sum_eq_zero fun m _ => ?_
      simp only [cphase, if_neg (class_mul_nonunit ρ hρ d m hdQ), mul_zero]
    rw [this, norm_zero]; exact hRHS

/-- **Type I₁ with class restriction.** -/
theorem typeI1_class (hs : 2 ≤ s) (c : ZMod s) (ρ : ZMod Q) (hρ : IsUnit ρ)
    (hcop : Nat.Coprime Q s) (U A B : ℕ) (hAB : A ≤ B) (Kmax : ℝ)
    (hK : ∀ u : ZMod s, IsUnit u → ∀ b : ZMod s, ‖GoldC.QuillonKl.K s b (c * u)‖ ≤ Kmax)
    (hK0 : 0 ≤ Kmax) :
    ‖∑ n ∈ Ioc A B, ((((GoldC.QuillonVaughan.trunc U μR) * log) n : ℝ) : ℂ) * cphase ρ c n‖ ≤
      Real.log B * (U + 2 * Kmax * (B * (1 + Real.log U) / (Q * s) + U * (1 + Real.log s))) := by
  rw [sum_Ioc_conv_twist_AB _ _ _ A B hAB]
  have hlogs : 0 ≤ Real.log s := Real.log_nonneg (by exact_mod_cast (show 1 ≤ s by omega))
  have hlogB : 0 ≤ Real.log B := Real.log_natCast_nonneg B
  have hQs : (0 : ℝ) < Q * s := by
    have h1 : (0 : ℝ) < Q := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne Q)
    have h2 : (0 : ℝ) < s := by exact_mod_cast (show 0 < s by omega)
    positivity
  have hpt : ∀ d ∈ Ioc 0 B,
      ‖((GoldC.QuillonVaughan.trunc U μR d : ℝ) : ℂ) *
          ∑ m ∈ Ioc (A / d) (B / d), ((log m : ℝ) : ℂ) * cphase ρ c (d * m)‖ ≤
        (if d ≤ U then 1 else 0) *
          (Real.log B * (1 + 2 * Kmax * (((B / d : ℕ) : ℝ) / (Q * s) + 1 + Real.log s))) := by
    intro d hd
    rw [GoldC.QuillonVaughan.trunc_apply]
    split_ifs with hdU
    · rw [norm_mul, one_mul]
      have hμ : ‖((μR d : ℝ) : ℂ)‖ ≤ 1 := by
        rw [Complex.norm_real, Real.norm_eq_abs]
        simp only [μR, intCoe_apply]
        exact_mod_cast abs_moebius_le_one
      have hin := inner_class_bound hs c ρ hρ hcop d (A / d) (B / d) (Nat.div_le_div_right hAB)
        Kmax hK hK0 (fun m => Real.log m) (fun m => Real.log_natCast_nonneg m) log_nat_mono
      simp only [log_apply] at hin ⊢
      have h2 : ((B / d - A / d : ℕ) : ℝ) / (Q * s) ≤ ((B / d : ℕ) : ℝ) / (Q * s) :=
        div_le_div_of_nonneg_right (by exact_mod_cast Nat.sub_le _ _) hQs.le
      calc _ ≤ 1 * (Real.log ((B / d : ℕ) : ℝ) *
            (1 + 2 * Kmax * (((B / d - A / d : ℕ) : ℝ) / (Q * s) + 1 + Real.log s))) :=
            mul_le_mul hμ hin (norm_nonneg _) zero_le_one
        _ ≤ _ := by
            rw [one_mul]
            have hl := log_nat_div_le B d
            have hld : 0 ≤ Real.log ((B / d : ℕ) : ℝ) := Real.log_natCast_nonneg _
            gcongr
    · rw [Complex.ofReal_zero, zero_mul, norm_zero, zero_mul]
  refine (norm_sum_le _ _).trans ((sum_le_sum hpt).trans ?_)
  calc ∑ d ∈ Ioc 0 B, (if d ≤ U then (1 : ℝ) else 0) *
        (Real.log B * (1 + 2 * Kmax * (((B / d : ℕ) : ℝ) / (Q * s) + 1 + Real.log s)))
      ≤ ∑ d ∈ Ioc 0 U, Real.log B * (1 + 2 * Kmax * (((B / d : ℕ) : ℝ) / (Q * s) + 1 + Real.log s)) := by
        simp only [ite_mul, one_mul, zero_mul]
        rw [← sum_filter]
        apply sum_le_sum_of_subset_of_nonneg
        · intro d hd; simp only [mem_filter, mem_Ioc] at hd ⊢; omega
        · intro d _ _; positivity
    _ = Real.log B * (U + 2 * Kmax * ∑ d ∈ Ioc 0 U, (((B / d : ℕ) : ℝ) / (Q * s) + 1 + Real.log s)) := by
        rw [← mul_sum, sum_add_distrib, sum_const, Nat.card_Ioc, nsmul_eq_mul, mul_one, ← mul_sum]
        simp only [Nat.sub_zero]
    _ ≤ _ := by
        gcongr
        exact typeI_outer_gen B U (Q * s) (Real.log s) hQs

/-- **Type I₂ with class restriction.** -/
theorem typeI2_class (hs : 2 ≤ s) (c : ZMod s) (ρ : ZMod Q) (hρ : IsUnit ρ)
    (hcop : Nat.Coprime Q s) (U V A B : ℕ) (hAB : A ≤ B) (Kmax : ℝ)
    (hK : ∀ u : ZMod s, IsUnit u → ∀ b : ZMod s, ‖GoldC.QuillonKl.K s b (c * u)‖ ≤ Kmax)
    (hK0 : 0 ≤ Kmax) :
    ‖∑ n ∈ Ioc A B, ((((GoldC.QuillonVaughan.trunc U μR) *
        (GoldC.QuillonVaughan.trunc V vonMangoldt) * ζR) n : ℝ) : ℂ) * cphase ρ c n‖ ≤
      Real.log B * ((U * V : ℕ) + 2 * Kmax * (B * (1 + Real.log (U * V : ℕ)) / (Q * s) +
        (U * V : ℕ) * (1 + Real.log s))) := by
  rw [sum_Ioc_conv_twist_AB _ _ _ A B hAB]
  have hlogs : 0 ≤ Real.log s := Real.log_nonneg (by exact_mod_cast (show 1 ≤ s by omega))
  have hlogB : 0 ≤ Real.log B := Real.log_natCast_nonneg B
  have hQs : (0 : ℝ) < Q * s := by
    have h1 : (0 : ℝ) < Q := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne Q)
    have h2 : (0 : ℝ) < s := by exact_mod_cast (show 0 < s by omega)
    positivity
  set lam := (GoldC.QuillonVaughan.trunc U μR) * (GoldC.QuillonVaughan.trunc V vonMangoldt)
  have hpt : ∀ d ∈ Ioc 0 B,
      ‖((lam d : ℝ) : ℂ) * ∑ m ∈ Ioc (A / d) (B / d), ((ζR m : ℝ) : ℂ) * cphase ρ c (d * m)‖ ≤
        (if d ≤ U * V then 1 else 0) *
          (Real.log B * (1 + 2 * Kmax * (((B / d : ℕ) : ℝ) / (Q * s) + 1 + Real.log s))) := by
    intro d hd
    have hd1 := mem_Ioc.1 hd
    split_ifs with hdUV
    · rw [norm_mul, one_mul]
      have hζ : ∑ m ∈ Ioc (A / d) (B / d), ((ζR m : ℝ) : ℂ) * cphase ρ c (d * m) =
          ∑ m ∈ Ioc (A / d) (B / d), (((fun _ : ℕ => (1 : ℝ)) m : ℝ) : ℂ) * cphase ρ c (d * m) := by
        refine sum_congr rfl fun m hm => ?_
        have hm0 : m ≠ 0 := Nat.pos_iff_ne_zero.1 (lt_of_le_of_lt (Nat.zero_le _) (mem_Ioc.1 hm).1)
        simp only [ζR, natCoe_apply, zeta_apply, if_neg hm0, Nat.cast_one]
      rw [hζ]
      have hl : ‖((lam d : ℝ) : ℂ)‖ ≤ Real.log B := by
        rw [Complex.norm_real, Real.norm_eq_abs]
        exact (lam_bound U V d).trans (Real.log_le_log (by exact_mod_cast hd1.1)
          (by exact_mod_cast hd1.2))
      have hin := inner_class_bound hs c ρ hρ hcop d (A / d) (B / d) (Nat.div_le_div_right hAB)
        Kmax hK hK0 (fun _ => (1 : ℝ)) (fun _ => zero_le_one) (fun _ _ _ => le_rfl)
      have h2 : ((B / d - A / d : ℕ) : ℝ) / (Q * s) ≤ ((B / d : ℕ) : ℝ) / (Q * s) :=
        div_le_div_of_nonneg_right (by exact_mod_cast Nat.sub_le _ _) hQs.le
      calc _ ≤ Real.log B * (1 * (1 + 2 * Kmax * (((B / d - A / d : ℕ) : ℝ) / (Q * s) + 1 +
            Real.log s))) := mul_le_mul hl hin (norm_nonneg _) hlogB
        _ ≤ _ := by rw [one_mul]; gcongr
    · rw [lam_support U V d (lt_of_not_ge hdUV), Complex.ofReal_zero, zero_mul, norm_zero, zero_mul]
  refine (norm_sum_le _ _).trans ((sum_le_sum hpt).trans ?_)
  calc ∑ d ∈ Ioc 0 B, (if d ≤ U * V then (1 : ℝ) else 0) *
        (Real.log B * (1 + 2 * Kmax * (((B / d : ℕ) : ℝ) / (Q * s) + 1 + Real.log s)))
      ≤ ∑ d ∈ Ioc 0 (U * V), Real.log B * (1 + 2 * Kmax * (((B / d : ℕ) : ℝ) / (Q * s) + 1 +
          Real.log s)) := by
        simp only [ite_mul, one_mul, zero_mul]
        rw [← sum_filter]
        apply sum_le_sum_of_subset_of_nonneg
        · intro d hd; simp only [mem_filter, mem_Ioc] at hd ⊢; omega
        · intro d _ _; positivity
    _ = Real.log B * ((U * V : ℕ) + 2 * Kmax * ∑ d ∈ Ioc 0 (U * V),
          (((B / d : ℕ) : ℝ) / (Q * s) + 1 + Real.log s)) := by
        rw [← mul_sum, sum_add_distrib, sum_const, Nat.card_Ioc, nsmul_eq_mul, mul_one, ← mul_sum]
        simp only [Nat.sub_zero]
    _ ≤ _ := by
        gcongr
        exact typeI_outer_gen B (U * V) (Q * s) (Real.log s) hQs

lemma cphase_split (ρ : ZMod Q) (hρ : IsUnit ρ) (c : ZMod s) (d m : ℕ) :
    cphase ρ c (d * m) = ∑ δ : ZMod Q, (if (d : ZMod Q) = δ then (1 : ℂ) else 0) *
      ((if IsUnit δ ∧ (m : ZMod Q) = ρ * δ⁻¹ then (1 : ℂ) else 0) * kphase c (d * m)) := by
  rw [Finset.sum_eq_single (d : ZMod Q)]
  · rw [if_pos rfl, one_mul]
    simp only [cphase]
    by_cases hd : IsUnit (d : ZMod Q)
    · have e := class_mul_iff ρ d m hd
      by_cases hm : (m : ZMod Q) = ρ * (d : ZMod Q)⁻¹
      · rw [if_pos (e.2 ((natCast_eq_iff_mod m _).1 hm)), if_pos ⟨hd, hm⟩, one_mul]
      · rw [if_neg (fun h => hm ((natCast_eq_iff_mod m _).2 (e.1 h))), if_neg (fun h => hm h.2),
          zero_mul]
    · rw [if_neg (class_mul_nonunit ρ hρ d m hd), if_neg (fun h => hd h.1), zero_mul]
  · intro δ _ hδ
    rw [if_neg (fun h => hδ h.symm), zero_mul]
  · intro h; exact absurd (Finset.mem_univ _) h

/-- **Type II with class restriction** (factor `Q` from the split over `d mod Q`). -/
theorem typeII_class (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p)
    (c : ZMod s) (ρ : ZMod Q) (hρ : IsUnit ρ) (U V T A B : ℕ) (hAB : A ≤ B) (hU : 2 ≤ U)
    (hT : 2 ≤ T) :
    ‖∑ n ∈ Ioc A B, ((((GoldC.QuillonVaughan.upper U μR) *
        (GoldC.QuillonVaughan.upper V vonMangoldt) * ζR) n : ℝ) : ℂ) * cphase ρ c n‖ ≤
      Q * (Real.sqrt (2 * (1 + Real.log (tseq U T (Jstop U T V B (by omega) (by omega)))) ^ 4) *
        Real.sqrt (Real.log B ^ 2 * B * (Jstop U T V B (by omega) (by omega) : ℝ) *
          (2 * B / ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ) +
            2 * (tseq U T (Jstop U T V B (by omega) (by omega)) : ℝ) +
            s * B / (U * ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ)) +
            s)) +
      Real.log B * (1 + Real.log (tseq U T (Jstop U T V B (by omega) (by omega)))) ^ 4 *
        (2 * B / T + 2 * B / U + 2 * (tseq U T (Jstop U T V B (by omega) (by omega)) : ℝ))) := by
  classical
  set a := (GoldC.QuillonVaughan.upper U μR) * ζR with ha
  set b := GoldC.QuillonVaughan.upper V vonMangoldt with hb
  rw [convII_eq, sum_Ioc_conv_twist_AB _ _ _ A B hAB]
  set αδ : ZMod Q → ℕ → ℂ := fun δ d => if (d : ZMod Q) = δ then (a d : ℂ) else 0 with hαδ
  set βδ : ZMod Q → ℕ → ℂ := fun δ m =>
    if IsUnit δ ∧ (m : ZMod Q) = ρ * δ⁻¹ then (b m : ℂ) else 0 with hβδ
  have key : ∑ d ∈ Ioc 0 B, (a d : ℂ) * ∑ m ∈ Ioc (A / d) (B / d), (b m : ℂ) * cphase ρ c (d * m) =
      ∑ δ : ZMod Q, ∑ d ∈ Ioc 0 B, αδ δ d * ∑ m ∈ Ioc (A / d) (B / d), βδ δ m * kphase c (d * m) := by
    simp only [mul_sum]
    conv_rhs => rw [sum_comm]
    refine sum_congr rfl fun d _ => ?_
    conv_rhs => rw [sum_comm]
    refine sum_congr rfl fun m _ => ?_
    rw [cphase_split ρ hρ c d m, mul_sum, mul_sum]
    refine sum_congr rfl fun δ _ => ?_
    simp only [hαδ, hβδ]
    split_ifs <;> ring
  rw [key]
  refine (norm_sum_le _ _).trans ?_
  have hcard : (Finset.univ : Finset (ZMod Q)).card = Q := ZMod.card Q
  rw [show (Q : ℝ) = ((Finset.univ : Finset (ZMod Q)).card : ℝ) by rw [hcard], ← nsmul_eq_mul,
    ← sum_const]
  refine sum_le_sum fun δ _ => ?_
  apply typeII_eval_gen P hP hsP c U V T A B hAB hU hT (αδ δ) (βδ δ)
  · intro d hd; simp only [hαδ, ha, coefII_support U d hd, Complex.ofReal_zero, ite_self]
  · intro d; simp only [hαδ]; split_ifs
    · rw [Complex.norm_real, Real.norm_eq_abs]; exact coefII_bound U d
    · rw [norm_zero]; positivity
  · intro m hm
    simp only [hβδ, hb, GoldC.QuillonVaughan.upper_apply, if_pos hm, Complex.ofReal_zero, ite_self]
  · intro m hm; simp only [hβδ]; split_ifs
    · exact upperΛ_le V m B hm
    · rw [norm_zero]; exact Real.log_natCast_nonneg B

/-- **Vaughan assembly with class restriction.** -/
theorem vw_lambda_class (hs2 : 2 ≤ s) (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime)
    (hsP : s = ∏ p ∈ P, p) (c : ZMod s) (ρ : ZMod Q) (hρ : IsUnit ρ) (hcop : Nat.Coprime Q s)
    (U V T A B : ℕ) (hVA : V ≤ A) (hAB : A ≤ B) (hU : 2 ≤ U) (hT : 2 ≤ T) :
    ‖∑ n ∈ Ioc A B, ((vonMangoldt n : ℝ) : ℂ) * cphase ρ c n‖ ≤
      Real.log B * (U + 2 * Kmax P c * (B * (1 + Real.log U) / (Q * s) + U * (1 + Real.log s))) +
      Real.log B * ((U * V : ℕ) + 2 * Kmax P c * (B * (1 + Real.log (U * V : ℕ)) / (Q * s) +
        (U * V : ℕ) * (1 + Real.log s))) +
      Q * (Real.sqrt (2 * (1 + Real.log (tseq U T (Jstop U T V B (by omega) (by omega)))) ^ 4) *
        Real.sqrt (Real.log B ^ 2 * B * (Jstop U T V B (by omega) (by omega) : ℝ) *
          (2 * B / ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ) +
            2 * (tseq U T (Jstop U T V B (by omega) (by omega)) : ℝ) +
            s * B / (U * ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ)) +
            s)) +
      Real.log B * (1 + Real.log (tseq U T (Jstop U T V B (by omega) (by omega)))) ^ 4 *
        (2 * B / T + 2 * B / U + 2 * (tseq U T (Jstop U T V B (by omega) (by omega)) : ℝ))) := by
  have hsplit : ∑ n ∈ Ioc A B, ((vonMangoldt n : ℝ) : ℂ) * cphase ρ c n =
      ∑ n ∈ Ioc A B, ((((GoldC.QuillonVaughan.trunc U μR) * log) n : ℝ) : ℂ) * cphase ρ c n -
      ∑ n ∈ Ioc A B, ((((GoldC.QuillonVaughan.trunc U μR) *
        (GoldC.QuillonVaughan.trunc V vonMangoldt) * ζR) n : ℝ) : ℂ) * cphase ρ c n +
      ∑ n ∈ Ioc A B, ((((GoldC.QuillonVaughan.upper U μR) *
        (GoldC.QuillonVaughan.upper V vonMangoldt) * ζR) n : ℝ) : ℂ) * cphase ρ c n := by
    rw [← sum_sub_distrib, ← sum_add_distrib]
    refine sum_congr rfl fun n hn => ?_
    have hn' : V < n := lt_of_le_of_lt hVA (mem_Ioc.1 hn).1
    rw [GoldC.QuillonVaughan.vaughan_apply U V n hn']
    push_cast; ring
  rw [hsplit]
  have hK := Kmax_bound P hP hsP c
  have hK0 := Kmax_nonneg P c
  refine (norm_add_le _ _).trans (add_le_add ((norm_sub_le _ _).trans (add_le_add ?_ ?_)) ?_)
  · exact typeI1_class hs2 c ρ hρ hcop U A B hAB (Kmax P c) hK hK0
  · exact typeI2_class hs2 c ρ hρ hcop U V A B hAB (Kmax P c) hK hK0
  · exact typeII_class P hP hsP c ρ hρ U V T A B hAB hU hT

end main

end GoldC.QuillonVWClass

#print axioms GoldC.QuillonVWClass.typeI1_class
#print axioms GoldC.QuillonVWClass.typeI2_class
#print axioms GoldC.QuillonVWClass.typeII_class
#print axioms GoldC.QuillonVWClass.vw_lambda_class
