import GoldB.Basic
import Mathlib.Data.Fintype.BigOperators

/-!
# GoldB.Grid

Power-sum vectors, Vinogradov counts, and the finite-grid orthogonality that
replaces integration over the `k`-torus: for integer vectors `v` with
`|v j| < M`, the average over `a ∈ (Fin k → Fin M)` of `e(⟨a,v⟩/M)` is `[v = 0]`.
-/

open Finset Complex

namespace GoldB

/-- power-sum vector: component `j` is `∑ i, x i ^ (j+1)`. -/
def psv (k : ℕ) {n : ℕ} (x : Fin n → ℤ) : Fin k → ℤ := fun j => ∑ i, x i ^ (j.val + 1)

/-- the moment map of a single integer -/
def pw (k : ℕ) (x : ℤ) : Fin k → ℤ := fun j => x ^ (j.val + 1)

lemma psv_eq_sum_pw (k : ℕ) {n : ℕ} (x : Fin n → ℤ) : psv k x = ∑ i, pw k (x i) := by
  ext j; simp [psv, pw, Finset.sum_apply]

/-- tuples with entries in `A` -/
abbrev tup (n : ℕ) (A : Finset ℤ) : Finset (Fin n → ℤ) := Fintype.piFinset fun _ => A

/-- Vinogradov count `J_{n,k}(A)`. -/
def Jc (k n : ℕ) (A : Finset ℤ) : ℕ :=
  ((tup n A ×ˢ tup n A).filter fun xy => psv k xy.1 = psv k xy.2).card

/-- representation count of a difference vector -/
def Rc (k n : ℕ) (A : Finset ℤ) (l : Fin k → ℤ) : ℕ :=
  ((tup n A ×ˢ tup n A).filter fun xy => psv k xy.1 = psv k xy.2 + l).card

lemma card_tup (n : ℕ) (A : Finset ℤ) : (tup n A).card = A.card ^ n := by
  simp [tup, Fintype.card_piFinset]

/-! ## grid characters -/

variable {k : ℕ}

/-- grid character -/
noncomputable def gch (M : ℕ) (a : Fin k → Fin M) (v : Fin k → ℤ) : ℂ :=
  ee ((∑ j, ((a j : ℕ) : ℝ) * (v j : ℝ)) / M)

lemma gch_add (M : ℕ) (a : Fin k → Fin M) (v w : Fin k → ℤ) :
    gch M a (v + w) = gch M a v * gch M a w := by
  unfold gch; rw [← ee_add]; congr 1
  simp only [Pi.add_apply, Int.cast_add, mul_add, Finset.sum_add_distrib, add_div]

lemma gch_neg (M : ℕ) (a : Fin k → Fin M) (v : Fin k → ℤ) :
    gch M a (-v) = (starRingEnd ℂ) (gch M a v) := by
  unfold gch; rw [← ee_neg]; congr 1
  simp only [Pi.neg_apply, Int.cast_neg, mul_neg, Finset.sum_neg_distrib, neg_div]

lemma gch_sub (M : ℕ) (a : Fin k → Fin M) (v w : Fin k → ℤ) :
    gch M a (v - w) = gch M a v * (starRingEnd ℂ) (gch M a w) := by
  rw [sub_eq_add_neg, gch_add, gch_neg]

@[simp] lemma gch_zero (M : ℕ) (a : Fin k → Fin M) : gch M a 0 = 1 := by
  simp [gch]

@[simp] lemma norm_gch (M : ℕ) (a : Fin k → Fin M) (v : Fin k → ℤ) : ‖gch M a v‖ = 1 := by
  simp [gch]

lemma gch_sum {ι : Type*} (s : Finset ι) (M : ℕ) (a : Fin k → Fin M) (v : ι → Fin k → ℤ) :
    gch M a (∑ i ∈ s, v i) = ∏ i ∈ s, gch M a (v i) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | insert b s hb ih => rw [sum_insert hb, prod_insert hb, gch_add, ih]

/-- one-variable orthogonality -/
lemma sum_fin_ee (M : ℕ) (hM : 0 < M) (l : ℤ) :
    ∑ a : Fin M, ee (((a : ℕ) : ℝ) * (l : ℝ) / M) = if (M : ℤ) ∣ l then (M : ℂ) else 0 := by
  split_ifs with h
  · obtain ⟨c, rfl⟩ := h
    have : ∀ a : Fin M, ee (((a : ℕ) : ℝ) * (((M : ℤ) * c : ℤ) : ℝ) / M) = 1 := by
      intro a
      have : ((a : ℕ) : ℝ) * (((M : ℤ) * c : ℤ) : ℝ) / M = (((a : ℕ) * c : ℤ) : ℝ) := by
        push_cast; field_simp
      rw [this, ee_int]
    simp only [this, Finset.sum_const_zero]
    simp
  · set r := ee ((l : ℝ) / M) with hr
    have hterm : ∀ a : Fin M, ee (((a : ℕ) : ℝ) * (l : ℝ) / M) = r ^ (a : ℕ) := by
      intro a
      induction (a : ℕ) with
      | zero => simp
      | succ m ih =>
        rw [pow_succ, ← ih, hr, ← ee_add]; congr 1; push_cast; ring
    have hr1 : r ≠ 1 := by
      intro h1
      rw [hr, ee, Complex.exp_eq_one_iff] at h1
      obtain ⟨n, hn⟩ := h1
      have hpi : (2 * Real.pi * Complex.I : ℂ) ≠ 0 := by
        simp [Real.pi_ne_zero, Complex.I_ne_zero]
      have h2 : (((l : ℝ) / (M : ℝ) : ℝ) : ℂ) = (n : ℂ) := by
        have heq : (2 * Real.pi * Complex.I : ℂ) * (((l : ℝ) / M : ℝ) : ℂ) =
            (2 * Real.pi * Complex.I : ℂ) * (n : ℂ) := by
          calc
            (2 * Real.pi * Complex.I : ℂ) * (((l : ℝ) / M : ℝ) : ℂ)
                = (n : ℂ) * (2 * Real.pi * Complex.I : ℂ) := hn
            _ = (2 * Real.pi * Complex.I : ℂ) * n := by ring
        exact (mul_left_cancel₀ hpi heq)
      have h3 : (l : ℝ) = n * M := by
        have hM' : (M : ℝ) ≠ 0 := by positivity
        have := congrArg Complex.re h2
        simp at this
        field_simp at this
        linarith
      apply h
      refine ⟨n, ?_⟩
      have : ((l : ℤ) : ℝ) = ((M * n : ℤ) : ℝ) := by push_cast; linarith
      exact_mod_cast this
    have hrM : r ^ M = 1 := by
      rw [hr]
      have : ∀ m : ℕ, ee ((l : ℝ) / M) ^ m = ee ((m : ℝ) * l / M) := by
        intro m
        induction m with
        | zero => simp
        | succ m ih => rw [pow_succ, ih, ← ee_add]; congr 1; push_cast; ring
      rw [this M]
      have : (M : ℝ) * l / M = (l : ℤ) := by field_simp
      rw [this, ee_int]
    simp_rw [hterm]
    rw [Fin.sum_univ_eq_sum_range (fun i => r ^ i) M, geom_sum_eq hr1, hrM, sub_self, zero_div]

/-- multi-variable orthogonality -/
lemma sum_gch (M : ℕ) (hM : 0 < M) (v : Fin k → ℤ) :
    ∑ a : Fin k → Fin M, gch M a v = if ∀ j, (M : ℤ) ∣ v j then (M : ℂ) ^ k else 0 := by
  have h1 : ∀ a : Fin k → Fin M, gch M a v = ∏ j, ee ((((a j) : ℕ) : ℝ) * (v j : ℝ) / M) := by
    intro a; unfold gch; rw [Finset.sum_div, ee_sum]
  simp_rw [h1]
  rw [← Fintype.prod_sum (fun j (b : Fin M) => ee (((b : ℕ) : ℝ) * (v j : ℝ) / M))]
  simp_rw [sum_fin_ee M hM]
  split_ifs with h
  · rw [Finset.prod_congr rfl (fun j _ => if_pos (h j))]; simp
  · push_neg at h
    obtain ⟨j, hj⟩ := h
    exact Finset.prod_eq_zero (Finset.mem_univ j) (if_neg hj)

lemma sum_gch_of_small (M : ℕ) (hM : 0 < M) (v : Fin k → ℤ) (hv : ∀ j, |v j| < M) :
    ∑ a : Fin k → Fin M, gch M a v = if v = 0 then (M : ℂ) ^ k else 0 := by
  rw [sum_gch M hM]
  congr 1
  apply propext
  constructor
  · intro h; ext j
    obtain ⟨c, hc⟩ := h j
    have := hv j
    rw [hc] at this ⊢
    rcases eq_or_ne c 0 with h0 | h0
    · simp [h0]
    · exfalso
      have : (M : ℤ) ≤ |(M : ℤ) * c| := by
        rw [abs_mul, abs_of_nonneg (by positivity : (0:ℤ) ≤ M)]
        exact le_mul_of_one_le_right (by positivity) (Int.one_le_abs h0)
      omega
  · intro h j; rw [h]; simp

/-- exponential sum attached to a finite set with a vector-valued map -/
noncomputable def esum (M : ℕ) {α : Type*} (X : Finset α) (φ : α → Fin k → ℤ)
    (a : Fin k → Fin M) : ℂ :=
  ∑ x ∈ X, gch M a (φ x)

/-- **grid counting identity** -/
theorem grid_count (M : ℕ) (hM : 0 < M) {α β : Type*} (X : Finset α) (Y : Finset β)
    (φ : α → Fin k → ℤ) (ψ : β → Fin k → ℤ)
    (hb : ∀ x ∈ X, ∀ y ∈ Y, ∀ j, |φ x j - ψ y j| < M) :
    ∑ a : Fin k → Fin M, esum M X φ a * (starRingEnd ℂ) (esum M Y ψ a) =
      (M : ℂ) ^ k * ((X ×ˢ Y).filter fun p => φ p.1 = ψ p.2).card := by
  classical
  simp only [esum, map_sum, Finset.sum_mul_sum]
  rw [Finset.sum_comm]
  have : ∀ x ∈ X, ∀ y ∈ Y,
      ∑ a : Fin k → Fin M, gch M a (φ x) * (starRingEnd ℂ) (gch M a (ψ y)) =
        if φ x = ψ y then (M : ℂ) ^ k else 0 := by
    intro x hx y hy
    simp_rw [← gch_sub]
    rw [show φ x - ψ y = fun j => φ x j - ψ y j from rfl]
    rw [sum_gch_of_small M hM _ (fun j => hb x hx y hy j)]
    change (if φ x - ψ y = 0 then (M : ℂ) ^ k else 0) =
      (if φ x = ψ y then (M : ℂ) ^ k else 0)
    simp only [sub_eq_zero]
  calc
    ∑ x ∈ X, ∑ a : Fin k → Fin M, ∑ y ∈ Y, gch M a (φ x) * (starRingEnd ℂ) (gch M a (ψ y))
        = ∑ x ∈ X, ∑ y ∈ Y, ∑ a : Fin k → Fin M, gch M a (φ x) * (starRingEnd ℂ) (gch M a (ψ y)) := by
            apply Finset.sum_congr rfl
            intro x hx
            exact Finset.sum_comm
    _ = ∑ x ∈ X, ∑ y ∈ Y, if φ x = ψ y then (M : ℂ) ^ k else 0 := by
            apply Finset.sum_congr rfl
            intro x hx
            apply Finset.sum_congr rfl
            intro y hy
            exact this x hx y hy
    _ = (M : ℂ) ^ k * ((X ×ˢ Y).filter fun p => φ p.1 = ψ p.2).card := by
      rw [← Finset.sum_product']
      simp [Finset.sum_ite, Finset.sum_const, mul_comm]

/-- products of exponential sums are exponential sums over products -/
lemma esum_product (M : ℕ) {α β : Type*} (X : Finset α) (Y : Finset β)
    (φ : α → Fin k → ℤ) (ψ : β → Fin k → ℤ) (a : Fin k → Fin M) :
    esum M (X ×ˢ Y) (fun p => φ p.1 + ψ p.2) a = esum M X φ a * esum M Y ψ a := by
  simp only [esum, Finset.sum_mul_sum, gch_add]
  rw [Finset.sum_product]

/-- powers of exponential sums are sums over tuples -/
lemma esum_tup (M : ℕ) (n : ℕ) (A : Finset ℤ) (a : Fin k → Fin M) :
    esum M (tup n A) (psv k) a = esum M A (pw k) a ^ n := by
  unfold esum
  simp only [psv_eq_sum_pw, gch_sum]
  simpa [tup] using
    (Finset.sum_pow' A (fun x : ℤ => gch M a (pw k x)) n).symm

/-- tuples with coordinate-dependent ranges -/
lemma esum_pi (M : ℕ) (n : ℕ) (A : Fin n → Finset ℤ) (a : Fin k → Fin M) :
    esum M (Fintype.piFinset A) (psv k) a = ∏ i, esum M (A i) (pw k) a := by
  unfold esum
  rw [Finset.prod_univ_sum]
  apply Finset.sum_congr rfl
  intro x _
  rw [psv_eq_sum_pw, gch_sum]

lemma esum_filter_add (M : ℕ) {α : Type*} (X : Finset α) (P : α → Prop) [DecidablePred P]
    (φ : α → Fin k → ℤ) (a : Fin k → Fin M) :
    esum M X φ a = esum M (X.filter P) φ a + esum M (X.filter fun x => ¬ P x) φ a := by
  unfold esum; rw [Finset.sum_filter_add_sum_filter_not]

lemma norm_esum_le (M : ℕ) {α : Type*} (X : Finset α) (φ : α → Fin k → ℤ)
    (a : Fin k → Fin M) : ‖esum M X φ a‖ ≤ X.card := by
  unfold esum
  calc ‖∑ x ∈ X, gch M a (φ x)‖ ≤ ∑ x ∈ X, ‖gch M a (φ x)‖ := norm_sum_le _ _
    _ = X.card := by simp

/-- real form of the counting identity for a "square" -/
theorem grid_count_sq (M : ℕ) (hM : 0 < M) {α : Type*} (X : Finset α)
    (φ : α → Fin k → ℤ) (hb : ∀ x ∈ X, ∀ y ∈ X, ∀ j, |φ x j - φ y j| < M) :
    ∑ a : Fin k → Fin M, ‖esum M X φ a‖ ^ 2 =
      (M : ℝ) ^ k * ((X ×ˢ X).filter fun p => φ p.1 = φ p.2).card := by
  have h := grid_count M hM X X φ φ hb
  have h2 : ∀ a : Fin k → Fin M, esum M X φ a * (starRingEnd ℂ) (esum M X φ a) =
      ((‖esum M X φ a‖ ^ 2 : ℝ) : ℂ) := by
    intro a; rw [Complex.mul_conj, Complex.normSq_eq_norm_sq]
  simp_rw [h2] at h
  have := congrArg Complex.re h
  simp only [Complex.re_sum, Complex.ofReal_re] at this
  rw [this]
  simp [← Complex.ofReal_natCast, ← Complex.ofReal_pow, ← Complex.ofReal_mul]

/-- `J_{n,k}(A)` as a grid moment -/
theorem Jc_eq_grid (M : ℕ) (hM : 0 < M) (n : ℕ) (A : Finset ℤ)
    (hb : ∀ x ∈ tup n A, ∀ y ∈ tup n A, ∀ j : Fin k, |psv k x j - psv k y j| < M) :
    ∑ a : Fin k → Fin M, ‖esum M A (pw k) a‖ ^ (2 * n) = (M : ℝ) ^ k * Jc k n A := by
  have := grid_count_sq M hM (tup n A) (psv k) hb
  simp_rw [esum_tup, norm_pow, ← pow_mul, mul_comm n 2] at this
  rw [this]; rfl

/-- `R(λ) ≤ J` -/
theorem Rc_le_Jc (n : ℕ) (A : Finset ℤ) (l : Fin k → ℤ) : Rc k n A l ≤ Jc k n A := by
  classical
  -- choose a large grid
  set B : ℕ := ((tup n A ×ˢ tup n A).sup fun xy =>
      ∑ j, ((psv k xy.1 j - psv k xy.2 j - l j).natAbs + (psv k xy.1 j - psv k xy.2 j).natAbs))
  set M := B + 1
  have hM : 0 < M := Nat.succ_pos _
  have hbound : ∀ x ∈ tup n A, ∀ y ∈ tup n A, ∀ j,
      ((psv k x j - psv k y j - l j).natAbs + (psv k x j - psv k y j).natAbs) ≤ B := by
    intro x hx y hy j
    have h1 : (x, y) ∈ tup n A ×ˢ tup n A := Finset.mem_product.mpr ⟨hx, hy⟩
    have h2 := Finset.le_sup (f := fun xy : (Fin n → ℤ) × (Fin n → ℤ) =>
      ∑ j, ((psv k xy.1 j - psv k xy.2 j - l j).natAbs + (psv k xy.1 j - psv k xy.2 j).natAbs)) h1
    exact le_trans (Finset.single_le_sum (f := fun j =>
      ((psv k x j - psv k y j - l j).natAbs + (psv k x j - psv k y j).natAbs))
      (fun _ _ => Nat.zero_le _) (Finset.mem_univ j)) h2
  have hJ := grid_count M hM (tup n A) (tup n A) (psv k) (psv k) (by
    intro x hx y hy j
    have := hbound x hx y hy j
    have : (psv k x j - psv k y j).natAbs < M := by omega
    rw [← Int.natCast_natAbs]; exact_mod_cast this)
  have hR := grid_count M hM (tup n A) (tup n A) (psv k) (fun y => psv k y + l) (by
    intro x hx y hy j
    have := hbound x hx y hy j
    have : (psv k x j - psv k y j - l j).natAbs < M := by omega
    simp only [Pi.add_apply]
    rw [show psv k x j - (psv k y j + l j) = psv k x j - psv k y j - l j by ring]
    rw [← Int.natCast_natAbs]; exact_mod_cast this)
  -- rewrite the R-sum as a twisted J-sum
  have htw : ∀ a : Fin k → Fin M, esum M (tup n A) (fun y => psv k y + l) a =
      esum M (tup n A) (psv k) a * gch M a l := by
    intro a; unfold esum; rw [Finset.sum_mul]
    exact Finset.sum_congr rfl (fun y _ => gch_add M a _ _)
  simp_rw [htw, map_mul, ← mul_assoc] at hR
  have hRnorm : (M : ℝ) ^ k * (Rc k n A l) ≤ (M : ℝ) ^ k * (Jc k n A) := by
    have e1 : ((M : ℂ) ^ k * (Rc k n A l : ℂ)) =
        ∑ a : Fin k → Fin M, esum M (tup n A) (psv k) a *
          (starRingEnd ℂ) (esum M (tup n A) (psv k) a) * (starRingEnd ℂ) (gch M a l) := by
      rw [hR]; rfl
    have e2 : ((M : ℂ) ^ k * (Jc k n A : ℂ)) =
        ∑ a : Fin k → Fin M, esum M (tup n A) (psv k) a *
          (starRingEnd ℂ) (esum M (tup n A) (psv k) a) := by
      rw [hJ]; rfl
    have n1 : ‖((M : ℂ) ^ k * (Rc k n A l : ℂ))‖ ≤ ‖((M : ℂ) ^ k * (Jc k n A : ℂ))‖ := by
      rw [e1, e2]
      have hreal : ∀ a : Fin k → Fin M, esum M (tup n A) (psv k) a *
          (starRingEnd ℂ) (esum M (tup n A) (psv k) a) =
            ((‖esum M (tup n A) (psv k) a‖ ^ 2 : ℝ) : ℂ) := by
        intro a; rw [Complex.mul_conj, Complex.normSq_eq_norm_sq]
      simp_rw [hreal]
      calc ‖∑ a : Fin k → Fin M, ((‖esum M (tup n A) (psv k) a‖ ^ 2 : ℝ) : ℂ) *
              (starRingEnd ℂ) (gch M a l)‖
          ≤ ∑ a : Fin k → Fin M, ‖((‖esum M (tup n A) (psv k) a‖ ^ 2 : ℝ) : ℂ) *
              (starRingEnd ℂ) (gch M a l)‖ := norm_sum_le _ _
        _ = ∑ a : Fin k → Fin M, ‖esum M (tup n A) (psv k) a‖ ^ 2 := by
          apply Finset.sum_congr rfl; intro a _
          rw [norm_mul, Complex.norm_conj, norm_gch, mul_one, Complex.norm_real,
            Real.norm_eq_abs, abs_of_nonneg (by positivity)]
        _ = ‖∑ a : Fin k → Fin M, ((‖esum M (tup n A) (psv k) a‖ ^ 2 : ℝ) : ℂ)‖ := by
          rw [← Complex.ofReal_sum, Complex.norm_real, Real.norm_eq_abs,
            abs_of_nonneg (Finset.sum_nonneg (fun _ _ => by positivity))]
    simpa [norm_mul, norm_pow] using n1
  have hMk : (0 : ℝ) < (M : ℝ) ^ k := by positivity
  have := le_of_mul_le_mul_left hRnorm hMk
  exact_mod_cast this

end GoldB
