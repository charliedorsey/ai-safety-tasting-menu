import Mathlib

/-! Independently buildable transcription of the GOLD C literal source.
No analytics assumed. This module is an interface, not a substitute for
replaying the production source equality on return. -/
open scoped BigOperators Classical
namespace GoldC

def primeSetProduct (s : Finset ℕ) : ℕ := ∏ p ∈ s, p

def activeHighPrime (q p : ℕ) : Prop := p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q

def decoratedHeightPrimeSet (q h : ℕ) : Finset ℕ :=
  h.primeFactors.filter (fun p => 5 ≤ p ∧ ¬ p ∣ q)

noncomputable def omegaWeight (s : Finset ℕ) : ℝ :=
  ∏ p ∈ s, 1 / ((p : ℝ) - 3)

noncomputable def decorationWeight (h : ℕ) (s : Finset ℕ) : ℝ :=
  ∏ p ∈ s, if p ∣ h then 1 / ((p : ℝ) - 2) else 1 / ((p : ℝ) - 3)

noncomputable def booleanSigma : ℝ := 2 / 3 + 1 / 100
noncomputable def booleanSourceCutoff (h : ℕ) : ℕ :=
  ⌊(Real.log (h : ℝ)) ^ booleanSigma⌋₊
noncomputable def originalZ (h : ℕ) : ℕ :=
  2 ^ (20 * (booleanSourceCutoff h + 1))

noncomputable def ordinaryFiniteSupport (q H : ℕ) (d : Finset ℕ) (N : ℕ) : Finset ℕ :=
  (Finset.range N).filter
    (fun p => activeHighPrime q p ∧ ¬ p ∣ H ∧ p ∉ d)

noncomputable def quarterParents
    (q h H : ℕ) (d : Finset ℕ) (N : ℕ) : Finset (Finset ℕ) :=
  ((ordinaryFiniteSupport q H d N).powerset).filter
    (fun e => originalZ h < primeSetProduct e ∧
      4 * primeSetProduct e ≤ H ^ 2)

def centralGate (h H r s : ℕ) : Prop :=
  (r * s : ℝ) ≤ (H : ℝ) /
    Real.exp ((Real.log (h : ℝ)) ^ (1/4 : ℝ)) ∧
  s ≤ r ^ 2 ∧ r ≤ s ^ 2

noncomputable def reducedAnchor (q a D : ℕ) : ℕ :=
  if hDq : D.Coprime q then
    (((((ZMod.unitOfCoprime D hDq)⁻¹ : (ZMod q)ˣ) : ZMod q) *
      (a : ZMod q)).val)
  else 0

def lowPrimeSet : Finset ℕ := {2, 3}
def endpointOccupiedCount (p H : ℕ) : ℕ :=
  ({0 % p, H % p} : Finset ℕ).card
def tripleOccupiedCount (p H y : ℕ) : ℕ :=
  ({0 % p, y % p, H % p} : Finset ℕ).card
noncomputable def occupiedLocalRatio (p H y : ℕ) : ℝ :=
  ((1 - (tripleOccupiedCount p H y : ℝ) / (p : ℝ)) /
      (1 - (endpointOccupiedCount p H : ℝ) / (p : ℝ))) /
    (1 - 1 / (p : ℝ))

noncomputable def occupiedWeight (q a H y : ℕ) : ℝ :=
  (if q.Coprime (a + y) then 1 else 0) *
    ∏ p ∈ lowPrimeSet,
      if p ∣ q then 1 else occupiedLocalRatio p H y

noncomputable def rowWeightMass (lambda : ℕ → ℝ) (H : ℕ) : ℝ :=
  ∑ y ∈ Finset.Ioo 0 H, lambda y
noncomputable def rowConstrainedMass
    (lambda : ℕ → ℝ) (H r s : ℕ) : ℝ :=
  ∑ y ∈ Finset.Ioo 0 H,
    if r ∣ y ∧ s ∣ H - y then lambda y else 0
noncomputable def rowDiscrepancy
    (lambda : ℕ → ℝ) (H r s : ℕ) : ℝ :=
  rowConstrainedMass lambda H r s -
    rowWeightMass lambda H / ((r : ℝ) * (s : ℝ))

noncomputable def activeDecoration (h H : ℕ) : Prop :=
  (originalZ h : ℝ) *
    Real.exp ((Real.log (h : ℝ)) ^ (1/4 : ℝ)) < (H : ℝ)

/-! Source-facing signed covariance: BOTH ordered orientations, source
Z(h), actual quarter mask, modular reduced anchor, p=2,3 occupancy,
and density subtraction exactly once for every gated oriented pair. -/
noncomputable def literalCentral (q a h : ℕ) : ℝ :=
  ∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
    decorationWeight h d *
      (∑ e ∈ quarterParents q h
            (h / primeSetProduct d) d
            ((h / primeSetProduct d)^2 + 1),
        ∑ B ∈ ((e.powerset.erase e).erase ∅),
          if centralGate h (h / primeSetProduct d)
              (primeSetProduct B) (primeSetProduct (e \ B)) then
            omegaWeight e *
              rowDiscrepancy
                (occupiedWeight q
                  (reducedAnchor q a (primeSetProduct d))
                  (h / primeSetProduct d))
                (h / primeSetProduct d)
                (primeSetProduct B) (primeSetProduct (e \ B))
          else 0)

noncomputable def activeCentral (q a h : ℕ) : ℝ :=
  ∑ d ∈ ((decoratedHeightPrimeSet q h).powerset.filter
      (fun d => activeDecoration h (h / primeSetProduct d))),
    decorationWeight h d *
      (∑ e ∈ quarterParents q h
            (h / primeSetProduct d) d
            ((h / primeSetProduct d)^2 + 1),
        ∑ B ∈ ((e.powerset.erase e).erase ∅),
          if centralGate h (h / primeSetProduct d)
              (primeSetProduct B) (primeSetProduct (e \ B)) then
            omegaWeight e *
              rowDiscrepancy
                (occupiedWeight q
                  (reducedAnchor q a (primeSetProduct d))
                  (h / primeSetProduct d))
                (h / primeSetProduct d)
                (primeSetProduct B) (primeSetProduct (e \ B))
          else 0)
end GoldC
