import PaperB.FixedQ.EtaCorrectionRankin
import PaperB.FixedQ.PetermannMovingTransfer
import PaperB.FixedQ.FixedConductorCompletion
import PaperB.FixedQ.PrincipalOneDimensionalCancellation
import Mathlib.Data.Nat.Totient
import Mathlib.Analysis.Normed.Group.FunctionSeries

open scoped BigOperators

namespace PaperB.FixedQ

def coprimeCountIco (L start len : ℕ) : ℕ :=
  ((Finset.Ico start (start + len)).filter fun n => L.Coprime n).card

theorem coprimeCountIco_period (L start : ℕ) :
    coprimeCountIco L start L = Nat.totient L := by
  simp [coprimeCountIco, Nat.filter_coprime_Ico_eq_totient]

theorem coprimeCountIco_mul_period
    (L start k : ℕ) :
    coprimeCountIco L start (k * L) = k * Nat.totient L := by
  induction k with
  | zero =>
      simp [coprimeCountIco]
  | succ k ih =>
      have hsplit :
          Finset.Ico start (start + (Nat.succ k) * L) =
            Finset.Ico start (start + k * L) ∪
              Finset.Ico (start + k * L) (start + k * L + L) := by
        ext n
        simp [Nat.succ_mul]
        omega
      have hdis :
          Disjoint
            (Finset.Ico start (start + k * L))
            (Finset.Ico (start + k * L) (start + k * L + L)) := by
        exact Finset.disjoint_left.mpr (by
          intro n hn1 hn2
          simp at hn1 hn2
          omega)
      unfold coprimeCountIco at *
      have hsplit' :
          Finset.Ico start (start + k * L + L) =
            Finset.Ico start (start + k * L) ∪
              Finset.Ico (start + k * L) (start + k * L + L) := by
        simpa [Nat.succ_mul, Nat.add_assoc] using hsplit
      rw [show start + (Nat.succ k) * L = start + k * L + L by
        simp [Nat.succ_mul, Nat.add_assoc]]
      rw [hsplit', Finset.filter_union,
        Finset.card_union_of_disjoint (hdis.mono
          (Finset.filter_subset _ _) (Finset.filter_subset _ _))]
      rw [Nat.filter_coprime_Ico_eq_totient, ih]
      simp [Nat.add_mul]

end PaperB.FixedQ


namespace PaperB.FixedQ

def coprimePrefixCount (L X : ℕ) : ℕ :=
  ((Finset.Icc 1 X).filter fun n => L.Coprime n).card

theorem coprimePrefixCount_eq_blocks_remainder
    (L X : ℕ) (hL : 0 < L) :
    coprimePrefixCount L X =
      (X / L) * Nat.totient L +
        coprimeCountIco L (X / L * L + 1) (X % L) := by
  have hdecomp : X = (X / L) * L + X % L := by
    simpa [Nat.mul_comm] using (Nat.div_add_mod X L).symm
  unfold coprimePrefixCount coprimeCountIco
  have hsplit :
      Finset.Icc 1 X =
        Finset.Ico 1 (X / L * L + 1) ∪
          Finset.Ico (X / L * L + 1) (X + 1) := by
    ext n
    simp only [Finset.mem_Icc, Finset.mem_union, Finset.mem_Ico]
    omega
  have hdis :
      Disjoint
        (Finset.Ico 1 (X / L * L + 1))
        (Finset.Ico (X / L * L + 1) (X + 1)) := by
    exact Finset.disjoint_left.mpr (by
      intro n hn1 hn2
      simp at hn1 hn2
      omega)
  rw [hsplit, Finset.filter_union,
    Finset.card_union_of_disjoint (hdis.mono
      (Finset.filter_subset _ _) (Finset.filter_subset _ _))]
  have hfirst :
      ((Finset.Ico 1 (X / L * L + 1)).filter fun n => L.Coprime n).card =
        (X / L) * Nat.totient L := by
    simpa [coprimeCountIco, Nat.add_comm] using
      coprimeCountIco_mul_period L 1 (X / L)
  have hsecond :
      Finset.Ico (X / L * L + 1) (X + 1) =
        Finset.Ico (X / L * L + 1)
          (X / L * L + 1 + X % L) := by
    ext n
    simp only [Finset.mem_Ico]
    omega
  rw [hfirst, hsecond]

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem coprimeCountIco_le_len
    (L start len : ℕ) :
    coprimeCountIco L start len ≤ len := by
  unfold coprimeCountIco
  calc
    ((Finset.Ico start (start + len)).filter fun n => L.Coprime n).card
        ≤ (Finset.Ico start (start + len)).card :=
      Finset.card_filter_le _ _
    _ = len := by simp

theorem coprimePrefixCount_discrepancy_le
    (L X : ℕ) (hL : 0 < L) :
    |(coprimePrefixCount L X : ℝ) -
        ((Nat.totient L : ℝ) / (L : ℝ)) * X| ≤ L := by
  rw [coprimePrefixCount_eq_blocks_remainder L X hL]
  let k := X / L
  let r := X % L
  let R := coprimeCountIco L (k * L + 1) r
  have hdecomp : X = k * L + r := by
    dsimp [k, r]
    simpa [Nat.mul_comm] using (Nat.div_add_mod X L).symm
  have hrlt : r < L := by
    dsimp [r]
    exact Nat.mod_lt _ hL
  have hRle : R ≤ r := by
    dsimp [R]
    exact coprimeCountIco_le_len L (k * L + 1) r
  have hphi : Nat.totient L ≤ L := Nat.totient_le L
  have hLR : (0 : ℝ) < L := by exact_mod_cast hL
  have hratio0 : 0 ≤ (Nat.totient L : ℝ) / (L : ℝ) := by positivity
  have hratio1 : (Nat.totient L : ℝ) / (L : ℝ) ≤ 1 := by
    rw [div_le_one hLR]
    exact_mod_cast hphi
  have hr0 : (0 : ℝ) ≤ r := by positivity
  have hR0 : (0 : ℝ) ≤ R := by positivity
  have hRr : (R : ℝ) ≤ r := by exact_mod_cast hRle
  have hrL : (r : ℝ) ≤ L := by
    exact_mod_cast (Nat.le_of_lt hrlt)
  have hmain :
      ((k * Nat.totient L + R : ℕ) : ℝ) -
          ((Nat.totient L : ℝ) / (L : ℝ)) * X =
        (R : ℝ) -
          ((Nat.totient L : ℝ) / (L : ℝ)) * r := by
    rw [hdecomp]
    push_cast
    field_simp [ne_of_gt hLR]
    ring
  rw [hmain]
  apply abs_le.mpr
  constructor
  · have hratio_r :
        ((Nat.totient L : ℝ) / (L : ℝ)) * r ≤ r := by
      nlinarith
    nlinarith
  · have hratio_r0 :
        0 ≤ ((Nat.totient L : ℝ) / (L : ℝ)) * r := by positivity
    nlinarith

#print axioms coprimePrefixCount_discrepancy_le

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem card_shifted_coprime_range_eq_prefix
    (L X : ℕ) :
    ((Finset.range X).filter fun j => L.Coprime (j + 1)).card =
      coprimePrefixCount L X := by
  unfold coprimePrefixCount
  refine Finset.card_bij
    (fun j hj => j + 1)
    ?_ ?_ ?_
  · intro j hj
    rw [Finset.mem_filter] at hj ⊢
    exact ⟨by
      rw [Finset.mem_Icc]
      constructor
      · omega
      · exact Finset.mem_range.mp hj.1, hj.2⟩
  · intro j1 hj1 j2 hj2 h
    omega
  · intro n hn
    rw [Finset.mem_filter, Finset.mem_Icc] at hn
    refine ⟨n - 1, ?_, ?_⟩
    · rw [Finset.mem_filter]
      constructor
      · rw [Finset.mem_range]
        omega
      · simpa [Nat.sub_add_cancel hn.1.1] using hn.2
    · omega

noncomputable def coprimeCenteredReal (L j : ℕ) : ℝ :=
  (if L.Coprime (j + 1) then (1 : ℝ) else 0) -
    (Nat.totient L : ℝ) / (L : ℝ)

noncomputable def coprimeCenteredCoeff (L j : ℕ) : ℂ :=
  (coprimeCenteredReal L j : ℂ)

theorem coprimeCenteredReal_prefix_eq
    (L X : ℕ) :
    (∑ j ∈ Finset.range X, coprimeCenteredReal L j) =
      (coprimePrefixCount L X : ℝ) -
        ((Nat.totient L : ℝ) / (L : ℝ)) * X := by
  unfold coprimeCenteredReal
  rw [Finset.sum_sub_distrib]
  have hind :
      (∑ j ∈ Finset.range X,
        (if L.Coprime (j + 1) then (1 : ℝ) else 0)) =
          (coprimePrefixCount L X : ℝ) := by
    rw [Finset.sum_boole]
    exact_mod_cast card_shifted_coprime_range_eq_prefix L X
  rw [hind]
  simp
  ring

theorem norm_coprimeCenteredCoeff_prefix_le
    (L X : ℕ) (hL : 0 < L) :
    ‖∑ j ∈ Finset.range X, coprimeCenteredCoeff L j‖ ≤ L := by
  unfold coprimeCenteredCoeff
  rw [← Complex.ofReal_sum]
  rw [Complex.norm_real]
  rw [Real.norm_eq_abs, coprimeCenteredReal_prefix_eq]
  simpa using coprimePrefixCount_discrepancy_le L X hL

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem norm_coprimeCentered_harmonic_sum_le
    (L X : ℕ) (hL : 0 < L) :
    ‖∑ j ∈ Finset.range X,
        coprimeCenteredCoeff L j * reciprocalNatWeight 1 j‖ ≤
      2 * L := by
  have hprefix :
      ∀ k ≤ X,
        ‖∑ j ∈ Finset.range k, coprimeCenteredCoeff L j‖ ≤ (L : ℝ) := by
    intro k hk
    exact_mod_cast norm_coprimeCenteredCoeff_prefix_le L k hL
  have h :=
    partialSummation_reciprocal_weight_le
      1 X (by norm_num) (coprimeCenteredCoeff L)
      (C := (L : ℝ)) (by positivity) hprefix
  simpa using h

theorem shifted_coprime_harmonic_decomposition
    (L X : ℕ) :
    (∑ j ∈ Finset.range X,
      ((if L.Coprime (j + 1) then (1 : ℝ) else 0) /
        (j + 1 : ℝ))) =
      ((Nat.totient L : ℝ) / (L : ℝ)) *
        ∑ j ∈ Finset.range X, (1 / (j + 1 : ℝ)) +
      (∑ j ∈ Finset.range X,
        coprimeCenteredReal L j / (j + 1 : ℝ)) := by
  unfold coprimeCenteredReal
  rw [Finset.mul_sum, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro j hj
  ring

theorem abs_shifted_coprime_harmonic_error_le
    (L X : ℕ) (hL : 0 < L) :
    |(∑ j ∈ Finset.range X,
        (if L.Coprime (j + 1) then (1 : ℝ) else 0) /
          (j + 1 : ℝ)) -
      ((Nat.totient L : ℝ) / (L : ℝ)) *
        ∑ j ∈ Finset.range X, (1 / (j + 1 : ℝ))| ≤
      2 * L := by
  rw [shifted_coprime_harmonic_decomposition]
  ring_nf
  have hcomplex := norm_coprimeCentered_harmonic_sum_le L X hL
  have hterm :
      ∀ j : ℕ,
        coprimeCenteredCoeff L j * reciprocalNatWeight 1 j =
          ((coprimeCenteredReal L j / (j + 1 : ℝ) : ℝ) : ℂ) := by
    intro j
    unfold coprimeCenteredCoeff reciprocalNatWeight
    simp [div_eq_mul_inv, add_comm]
  have hsumcast :
      Complex.ofReal
        (∑ j ∈ Finset.range X,
          coprimeCenteredReal L j / (j + 1 : ℝ)) =
      (∑ j ∈ Finset.range X,
        coprimeCenteredCoeff L j * reciprocalNatWeight 1 j) := by
    rw [Complex.ofReal_sum]
    apply Finset.sum_congr rfl
    intro j hj
    exact (hterm j).symm
  have hwhole :
      ‖Complex.ofReal
        (∑ j ∈ Finset.range X,
          coprimeCenteredReal L j / (j + 1 : ℝ))‖ ≤
          2 * L := by
    rw [hsumcast]
    exact hcomplex
  rw [Complex.norm_real] at hwhole
  simpa [Real.norm_eq_abs, mul_comm, div_eq_mul_inv, add_comm] using hwhole

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def etaLinearPartialSum (q X : ℕ) : ℝ :=
  ∑ n ∈ Finset.Icc 1 X, etaLinearArithmetic q n

theorem etaLinearPartialSum_eq_correction_coprime
    (q X : ℕ) :
    etaLinearPartialSum q X =
      ∑ d ∈ Finset.Icc 1 X,
        etaLinearCorrectionArithmetic q d *
          (coprimePrefixCount (6 * q) (X / d) : ℝ) := by
  classical
  unfold etaLinearPartialSum
  calc
    (∑ n ∈ Finset.Icc 1 X, etaLinearArithmetic q n)
      = ∑ n ∈ Finset.Icc 1 X,
          (coprimeIndicatorArithmetic q *
            etaLinearCorrectionArithmetic q) n := by
          apply Finset.sum_congr rfl
          intro n hn
          have hfun := etaLinearArithmetic_eq_correction_mul_coprime q
          have hnval := congrArg (fun f : ArithmeticFunction ℝ => f n) hfun
          simpa [mul_comm] using hnval
    _ = ∑ n ∈ Finset.Icc 1 X,
          ∑ ds ∈ n.divisorsAntidiagonal,
            etaLinearCorrectionArithmetic q ds.2 *
              coprimeIndicatorArithmetic q ds.1 := by
          apply Finset.sum_congr rfl
          intro n hn
          rw [ArithmeticFunction.mul_apply]
          apply Finset.sum_congr rfl
          intro ds hds
          ring
    _ = ∑ x ∈ petermannDivisorSigma X,
          etaLinearCorrectionArithmetic q x.2.2 *
            coprimeIndicatorArithmetic q x.2.1 := by
          rw [petermannDivisorSigma, Finset.sum_sigma']
    _ = ∑ d ∈ Finset.Icc 1 X,
          ∑ m ∈ Finset.Icc 1 (X / d),
            etaLinearCorrectionArithmetic q d *
              coprimeIndicatorArithmetic q m := by
          exact sum_petermannDivisorSigma_eq_nested X
            (fun d m =>
              etaLinearCorrectionArithmetic q d *
                coprimeIndicatorArithmetic q m)
    _ = ∑ d ∈ Finset.Icc 1 X,
        etaLinearCorrectionArithmetic q d *
          (coprimePrefixCount (6 * q) (X / d) : ℝ) := by
          apply Finset.sum_congr rfl
          intro d hd
          have hind :
              (∑ m ∈ Finset.Icc 1 (X / d),
                coprimeIndicatorArithmetic q m) =
                (coprimePrefixCount (6 * q) (X / d) : ℝ) := by
            unfold coprimePrefixCount
            have hterm :
                ∀ m ∈ Finset.Icc 1 (X / d),
                  coprimeIndicatorArithmetic q m =
                    (if (6 * q).Coprime m then (1 : ℝ) else 0) := by
              intro m hm
              rw [coprimeIndicatorArithmetic_apply]
              have hm0 : m ≠ 0 := by
                rw [Finset.mem_Icc] at hm
                omega
              rw [coprimeIndicatorCoeff, if_neg hm0]
              simpa [Nat.coprime_comm]
            calc
              (∑ m ∈ Finset.Icc 1 (X / d),
                coprimeIndicatorArithmetic q m)
                  = ∑ m ∈ Finset.Icc 1 (X / d),
                      (if (6 * q).Coprime m then (1 : ℝ) else 0) := by
                        apply Finset.sum_congr rfl
                        intro m hm
                        exact hterm m hm
              _ = (((Finset.Icc 1 (X / d)).filter
                    (fun m => (6 * q).Coprime m)).card : ℝ) := by
                      exact Finset.sum_boole _ _

          rw [← hind, Finset.mul_sum]

#print axioms etaLinearPartialSum_eq_correction_coprime

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def etaCorrectionInvTerm (q n : ℕ) : ℝ :=
  etaLinearCorrectionArithmetic q n / (n : ℝ)

noncomputable def etaCorrectionInvMass (q : ℕ) : ℝ :=
  ∑' n : ℕ, etaCorrectionInvTerm q n

theorem norm_etaCorrectionInvTerm_le_rankin
    (q n : ℕ) :
    ‖etaCorrectionInvTerm q n‖ ≤ etaCorrectionRankin q n := by
  by_cases hn0 : n = 0
  · subst n
    simp [etaCorrectionInvTerm, etaCorrectionRankin,
      etaLinearCorrectionArithmetic, etaLinearCorrectionCoeff]
  · have hn1 : 1 ≤ n := Nat.one_le_iff_ne_zero.mpr hn0
    have hnR : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn1
    have hpow :
        (n : ℝ) ^ (-1 : ℝ) ≤ (n : ℝ) ^ (-3 / 4 : ℝ) :=
      Real.rpow_le_rpow_of_exponent_le hnR (by norm_num)
    rw [etaCorrectionInvTerm, Real.norm_eq_abs, abs_div]
    rw [etaCorrectionRankin, if_neg hn0]
    have hnpos : (0 : ℝ) < n := by positivity
    rw [abs_of_pos hnpos, div_eq_mul_inv, ← Real.rpow_neg_one]
    exact mul_le_mul_of_nonneg_left hpow (abs_nonneg _)

theorem summable_etaCorrectionInvTerm (q : ℕ) :
    Summable (etaCorrectionInvTerm q) := by
  exact (summable_etaCorrectionRankin q).of_norm_bounded
    (norm_etaCorrectionInvTerm_le_rankin q)

theorem tsum_abs_etaCorrectionInvTerm_le_bound (q : ℕ) :
    (∑' n : ℕ, |etaCorrectionInvTerm q n|) ≤ etaRankinBound := by
  calc
    (∑' n : ℕ, |etaCorrectionInvTerm q n|)
        ≤ ∑' n : ℕ, etaCorrectionRankin q n := by
          exact (summable_etaCorrectionInvTerm q).abs.tsum_le_tsum
            (fun n => by
              simpa [Real.norm_eq_abs] using
                norm_etaCorrectionInvTerm_le_rankin q n)
            (summable_etaCorrectionRankin q)
    _ ≤ etaRankinBound := tsum_etaCorrectionRankin_le_bound q

#print axioms summable_etaCorrectionInvTerm

end PaperB.FixedQ


namespace PaperB.FixedQ

@[simp] theorem etaCorrectionInvTerm_zero (q : ℕ) :
    etaCorrectionInvTerm q 0 = 0 := by
  simp [etaCorrectionInvTerm]

@[simp] theorem etaCorrectionInvTerm_one (q : ℕ) :
    etaCorrectionInvTerm q 1 = 1 := by
  simp [etaCorrectionInvTerm, etaLinearCorrectionArithmetic,
    etaLinearCorrectionCoeff]

theorem etaCorrectionInvTerm_mul_of_coprime
    (q : ℕ) {m n : ℕ} (hcop : m.Coprime n) :
    etaCorrectionInvTerm q (m * n) =
      etaCorrectionInvTerm q m * etaCorrectionInvTerm q n := by
  by_cases hm0 : m = 0
  · subst m
    have hn1 : n = 1 := by simpa using hcop
    subst n
    simp
  · by_cases hn0 : n = 0
    · subst n
      have hm1 : m = 1 := by simpa using hcop
      subst m
      simp
    · unfold etaCorrectionInvTerm
      rw [(etaLinearCorrectionArithmetic_multiplicative q).map_mul_of_coprime hcop]
      have hmR : (m : ℝ) ≠ 0 := by exact_mod_cast hm0
      have hnR : (n : ℝ) ≠ 0 := by exact_mod_cast hn0
      push_cast
      field_simp [hmR, hnR]

theorem etaCorrectionInvTerm_prime_pow_zero_of_three_le
    (q : ℕ) {p nu : ℕ} (hp : p.Prime) (hnu : 3 ≤ nu) :
    etaCorrectionInvTerm q (p ^ nu) = 0 := by
  unfold etaCorrectionInvTerm
  rw [etaLinearCorrectionArithmetic_prime_pow q hp]
  have h0 : nu ≠ 0 := by omega
  have h1 : nu ≠ 1 := by omega
  have h2 : nu ≠ 2 := by omega
  simp [etaLinearCorrectionLocal, hp, h0, h1, h2]


end PaperB.FixedQ


namespace PaperB.FixedQ

theorem etaCorrectionInvTerm_prime_active
    (q : ℕ) {p : ℕ} (hp : p.Prime) (hcop : p.Coprime (6 * q)) :
    etaCorrectionInvTerm q p =
      2 / ((p : ℝ) * ((p : ℝ) - 2)) := by
  unfold etaCorrectionInvTerm
  have hlocal :=
    etaLinearCorrectionArithmetic_prime_pow (q := q) (p := p) (i := 1) hp
  have hcoeff :
      etaLinearCorrectionArithmetic q p = 2 / ((p : ℝ) - 2) := by
    have h := hlocal
    simp [etaLinearCorrectionLocal, hp] at h
    rw [if_pos hcop] at h
    simpa using h
  rw [hcoeff]
  have hpR : (p : ℝ) ≠ 0 := by exact_mod_cast hp.ne_zero
  field_simp [hpR]

theorem etaCorrectionInvTerm_prime_sq_active
    (q : ℕ) {p : ℕ} (hp : p.Prime) (hcop : p.Coprime (6 * q)) :
    etaCorrectionInvTerm q (p ^ 2) =
      -1 / ((p : ℝ) * ((p : ℝ) - 2)) := by
  unfold etaCorrectionInvTerm
  have hlocal :=
    etaLinearCorrectionArithmetic_prime_pow (q := q) (p := p) (i := 2) hp
  have hcoeff :
      etaLinearCorrectionArithmetic q (p ^ 2) =
        -(p : ℝ) / ((p : ℝ) - 2) := by
    have h := hlocal
    simp [etaLinearCorrectionLocal, hp] at h
    rw [if_pos hcop] at h
    simpa using h
  rw [hcoeff]
  have hpR : (p : ℝ) ≠ 0 := by exact_mod_cast hp.ne_zero
  rw [Nat.cast_pow]
  field_simp [hpR]

theorem etaCorrectionInvTerm_prime_inactive
    (q : ℕ) {p : ℕ} (hp : p.Prime) (hcop : ¬ p.Coprime (6 * q)) :
    etaCorrectionInvTerm q p = 0 := by
  unfold etaCorrectionInvTerm
  have hlocal :=
    etaLinearCorrectionArithmetic_prime_pow (q := q) (p := p) (i := 1) hp
  have hcoeff : etaLinearCorrectionArithmetic q p = 0 := by
    have h := hlocal
    simp [etaLinearCorrectionLocal, hp] at h
    rw [if_neg hcop] at h
    simpa using h
  rw [hcoeff]
  simp

theorem etaCorrectionInvTerm_prime_sq_inactive
    (q : ℕ) {p : ℕ} (hp : p.Prime) (hcop : ¬ p.Coprime (6 * q)) :
    etaCorrectionInvTerm q (p ^ 2) = 0 := by
  unfold etaCorrectionInvTerm
  have hlocal :=
    etaLinearCorrectionArithmetic_prime_pow (q := q) (p := p) (i := 2) hp
  have hcoeff : etaLinearCorrectionArithmetic q (p ^ 2) = 0 := by
    have h := hlocal
    simp [etaLinearCorrectionLocal, hp] at h
    rw [if_neg hcop] at h
    simpa using h
  rw [hcoeff]
  simp

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem tsum_etaCorrectionInvTerm_prime_pow
    (q : ℕ) {p : ℕ} (hp : p.Prime) :
    (∑' nu : ℕ, etaCorrectionInvTerm q (p ^ nu)) =
      1 + normalizationCorrection q 0 p := by
  rw [tsum_eq_sum (s := ({0, 1, 2} : Finset ℕ))]
  · by_cases hactive : p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q
    · have hcop : p.Coprime (6 * q) := by
        apply hp.coprime_iff_not_dvd.mpr
        intro hd
        rcases hp.dvd_mul.mp hd with h6 | hq
        · have hp6 : p ∣ 2 * 3 := by simpa using h6
          rcases hp.dvd_mul.mp hp6 with h2 | h3
          · have : p ≤ 2 := Nat.le_of_dvd (by norm_num) h2
            omega
          · have : p ≤ 3 := Nat.le_of_dvd (by norm_num) h3
            omega
        · exact hactive.2.2 hq
      rw [show normalizationCorrection q 0 p =
          1 / ((p : ℝ) * ((p : ℝ) - 2)) by
        simp [normalizationCorrection, hactive]]
      simp [etaCorrectionInvTerm_one,
        etaCorrectionInvTerm_prime_active q hp hcop,
        etaCorrectionInvTerm_prime_sq_active q hp hcop]
      have hp0 : (p : ℝ) ≠ 0 := by exact_mod_cast hp.ne_zero
      have hp2 : (p : ℝ) - 2 ≠ 0 := by
        exact sub_ne_zero.mpr (by exact_mod_cast (show p ≠ 2 by omega))
      field_simp [hp0, hp2]
      norm_num
    · have hnotcop : ¬ p.Coprime (6 * q) := by
        intro hcop
        have hp5 : 5 ≤ p := eta_rankin_five_le_of_prime_coprime_six hp hcop
        have hpq : ¬ p ∣ q := by
          intro hd
          exact (hp.coprime_iff_not_dvd.mp hcop)
            (dvd_mul_of_dvd_right hd 6)
        exact hactive ⟨hp, hp5, hpq⟩
      rw [show normalizationCorrection q 0 p = 0 by
        simp [normalizationCorrection, hactive]]
      simp [etaCorrectionInvTerm_one,
        etaCorrectionInvTerm_prime_inactive q hp hnotcop,
        etaCorrectionInvTerm_prime_sq_inactive q hp hnotcop]
  · intro nu hnu
    have hnot : nu ∉ ({0, 1, 2} : Finset ℕ) := hnu
    have hge : 3 ≤ nu := by
      simp at hnot
      omega
    exact etaCorrectionInvTerm_prime_pow_zero_of_three_le q hp hge

#print axioms tsum_etaCorrectionInvTerm_prime_pow

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem etaCorrectionInvMass_eq_correction_tprod
    (q : ℕ) :
    etaCorrectionInvMass q =
      ∏' p : ℕ, (1 + normalizationCorrection q 0 p) := by
  have hEP :=
    EulerProduct.eulerProduct_hasProd_mulIndicator
      (etaCorrectionInvTerm_one q)
      (fun {_m _n} hcop => etaCorrectionInvTerm_mul_of_coprime q hcop)
      (summable_etaCorrectionInvTerm q).norm
      (etaCorrectionInvTerm_zero q)
  have heq :
      Set.mulIndicator {p : ℕ | p.Prime}
        (fun p => ∑' nu : ℕ, etaCorrectionInvTerm q (p ^ nu)) =
      (fun p : ℕ => 1 + normalizationCorrection q 0 p) := by
    funext p
    by_cases hp : p.Prime
    · simp [Set.mulIndicator, hp, tsum_etaCorrectionInvTerm_prime_pow q hp]
    · simp [Set.mulIndicator, hp, normalizationCorrection]
  have ht := hEP.tprod_eq
  rw [heq] at ht
  unfold etaCorrectionInvMass
  exact ht.symm

theorem freeHighBaseline_mul_etaCorrectionInvMass
    (q : ℕ) :
    freeHighBaseline q * etaCorrectionInvMass q = 1 := by
  unfold freeHighBaseline cStarReal
  rw [etaCorrectionInvMass_eq_correction_tprod q]
  exact normalizationBaseline_tprod_mul_correction_tprod q 0

#print axioms etaCorrectionInvMass_eq_correction_tprod
#print axioms freeHighBaseline_mul_etaCorrectionInvMass

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem primeFactors_fixedQPeriod_eq_six_mul
    (q : ℕ) (hq : 0 < q) :
    (fixedQPeriod q).primeFactors = (6 * q).primeFactors := by
  ext p
  have hL0 : fixedQPeriod q ≠ 0 :=
    Nat.ne_of_gt (Nat.lcm_pos (by norm_num) hq)
  have h6q0 : 6 * q ≠ 0 := mul_ne_zero (by norm_num) (Nat.ne_of_gt hq)
  rw [Nat.mem_primeFactors, Nat.mem_primeFactors]
  constructor
  · rintro ⟨hp, hd, _⟩
    have hsplit := (prime_dvd_fixedQPeriod_iff hp).mp hd
    exact ⟨hp, (hp.dvd_mul).mpr hsplit, h6q0⟩
  · rintro ⟨hp, hd, _⟩
    have hsplit := (hp.dvd_mul).mp hd
    exact ⟨hp, (prime_dvd_fixedQPeriod_iff hp).mpr hsplit, hL0⟩

theorem totient_div_eq_prod_primeFactors
    (n : ℕ) (hn : 0 < n) :
    (Nat.totient n : ℝ) / (n : ℝ) =
      ∏ p ∈ n.primeFactors, (1 - 1 / (p : ℝ)) := by
  have hq := Nat.totient_eq_mul_prod_factors n
  have hq' := congrArg (fun x : ℚ => (x : ℝ)) hq
  push_cast at hq'
  have hn0 : (n : ℝ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hn)
  rw [hq']
  simpa [one_div] using
    (mul_div_cancel_left₀
      (∏ p ∈ n.primeFactors, (1 - (p : ℝ)⁻¹)) hn0)

theorem fixedQPeriod_density_eq_six_mul_density
    (q : ℕ) (hq : 0 < q) :
    (Nat.totient (fixedQPeriod q) : ℝ) / (fixedQPeriod q : ℝ) =
      (Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ) := by
  rw [totient_div_eq_prod_primeFactors (fixedQPeriod q)
        (Nat.lcm_pos (by norm_num) hq)]
  rw [totient_div_eq_prod_primeFactors (6 * q)
        (mul_pos (by norm_num) hq)]
  rw [primeFactors_fixedQPeriod_eq_six_mul q hq]

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem six_mul_density_mul_etaCorrectionInvMass_eq_residue
    (q : ℕ) (hq : 0 < q) :
    ((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
        etaCorrectionInvMass q =
      logarithmicEulerResidue (etaCoeff q) := by
  have hFR := freeHighBaseline_mul_logarithmicEulerResidue_eta q hq
  rw [tprod_lambdaResidualLocal_eq_totient_div q hq] at hFR
  have hFI := freeHighBaseline_mul_etaCorrectionInvMass q
  have hD := fixedQPeriod_density_eq_six_mul_density q hq
  calc
    ((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
        etaCorrectionInvMass q
        = ((Nat.totient (fixedQPeriod q) : ℝ) /
            (fixedQPeriod q : ℝ)) * etaCorrectionInvMass q := by
              rw [hD]
    _ = (freeHighBaseline q *
          logarithmicEulerResidue (etaCoeff q)) *
          etaCorrectionInvMass q := by rw [hFR]
    _ = logarithmicEulerResidue (etaCoeff q) *
          (freeHighBaseline q * etaCorrectionInvMass q) := by ring
    _ = logarithmicEulerResidue (etaCoeff q) := by rw [hFI, mul_one]

#print axioms six_mul_density_mul_etaCorrectionInvMass_eq_residue

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def shiftedHarmonicReal (X : ℕ) : ℝ :=
  ∑ j ∈ Finset.range X, (1 / (j + 1 : ℝ))

noncomputable def shiftedCoprimeHarmonicReal (L X : ℕ) : ℝ :=
  ∑ j ∈ Finset.range X,
    (if L.Coprime (j + 1) then (1 : ℝ) else 0) / (j + 1 : ℝ)

theorem shiftedHarmonicReal_eq_harmonic
    (X : ℕ) :
    shiftedHarmonicReal X = (harmonic X : ℝ) := by
  unfold shiftedHarmonicReal harmonic
  push_cast
  apply Finset.sum_congr rfl
  intro j hj
  simp [div_eq_mul_inv]

theorem abs_shiftedHarmonicReal_sub_log_le_one
    (X : ℕ) :
    |shiftedHarmonicReal X - Real.log X| ≤ 1 := by
  by_cases hX0 : X = 0
  · subst X
    simp [shiftedHarmonicReal]
  · have hX : 1 ≤ X := Nat.one_le_iff_ne_zero.mpr hX0
    rw [shiftedHarmonicReal_eq_harmonic]
    have hlo : Real.log (X : ℝ) ≤ (harmonic X : ℝ) := by
      have h := log_le_harmonic_floor (X : ℝ) (by positivity)
      simpa using h
    have hhi : (harmonic X : ℝ) ≤ 1 + Real.log (X : ℝ) := by
      simpa using harmonic_le_one_add_log X
    rw [abs_le]
    constructor <;> linarith

theorem abs_shiftedCoprimeHarmonic_sub_log_main_le
    (L X : ℕ) (hL : 0 < L) :
    |shiftedCoprimeHarmonicReal L X -
      ((Nat.totient L : ℝ) / (L : ℝ)) * Real.log X| ≤
      2 * L + 1 := by
  have hcenter := abs_shifted_coprime_harmonic_error_le L X hL
  have hH := abs_shiftedHarmonicReal_sub_log_le_one X
  have htot : Nat.totient L ≤ L := Nat.totient_le L
  have hLR : (0 : ℝ) < L := by exact_mod_cast hL
  have hD0 : 0 ≤ (Nat.totient L : ℝ) / (L : ℝ) := by positivity
  have hD1 : (Nat.totient L : ℝ) / (L : ℝ) ≤ 1 := by
    rw [div_le_one hLR]
    exact_mod_cast htot
  unfold shiftedCoprimeHarmonicReal shiftedHarmonicReal at *
  have hsplit :
      (∑ j ∈ Finset.range X,
          (if L.Coprime (j + 1) then (1 : ℝ) else 0) / (j + 1 : ℝ)) -
        ((Nat.totient L : ℝ) / (L : ℝ)) * Real.log X =
      ((∑ j ∈ Finset.range X,
          (if L.Coprime (j + 1) then (1 : ℝ) else 0) / (j + 1 : ℝ)) -
        ((Nat.totient L : ℝ) / (L : ℝ)) *
          ∑ j ∈ Finset.range X, (1 / (j + 1 : ℝ))) +
      ((Nat.totient L : ℝ) / (L : ℝ)) *
        ((∑ j ∈ Finset.range X, (1 / (j + 1 : ℝ))) - Real.log X) := by
    ring
  rw [hsplit]
  calc
    |((∑ j ∈ Finset.range X,
        (if L.Coprime (j + 1) then (1 : ℝ) else 0) / (j + 1 : ℝ)) -
      ((Nat.totient L : ℝ) / (L : ℝ)) *
        ∑ j ∈ Finset.range X, (1 / (j + 1 : ℝ))) +
      ((Nat.totient L : ℝ) / (L : ℝ)) *
        ((∑ j ∈ Finset.range X, (1 / (j + 1 : ℝ))) - Real.log X)|
        ≤
      |(∑ j ∈ Finset.range X,
        (if L.Coprime (j + 1) then (1 : ℝ) else 0) / (j + 1 : ℝ)) -
        ((Nat.totient L : ℝ) / (L : ℝ)) *
          ∑ j ∈ Finset.range X, (1 / (j + 1 : ℝ))| +
      |((Nat.totient L : ℝ) / (L : ℝ)) *
        ((∑ j ∈ Finset.range X, (1 / (j + 1 : ℝ))) - Real.log X)| :=
      abs_add_le _ _
    _ ≤ 2 * L + 1 := by
      rw [abs_mul, abs_of_nonneg hD0]
      nlinarith [hcenter, hH, abs_nonneg
        ((∑ j ∈ Finset.range X, (1 / (j + 1 : ℝ))) - Real.log X)]

#print axioms abs_shiftedCoprimeHarmonic_sub_log_main_le

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def coprimeHarmonicIccReal (L X : ℕ) : ℝ :=
  ∑ m ∈ Finset.Icc 1 X,
    (if L.Coprime m then (1 : ℝ) else 0) / (m : ℝ)

theorem coprimeHarmonicIccReal_eq_shifted
    (L X : ℕ) :
    coprimeHarmonicIccReal L X =
      shiftedCoprimeHarmonicReal L X := by
  unfold coprimeHarmonicIccReal shiftedCoprimeHarmonicReal
  refine Finset.sum_bij
    (fun m hm => m - 1)
    ?_ ?_ ?_ ?_
  · intro m hm
    rw [Finset.mem_Icc] at hm
    rw [Finset.mem_range]
    omega
  · intro m1 hm1 m2 hm2 h
    rw [Finset.mem_Icc] at hm1 hm2
    omega
  · intro j hj
    rw [Finset.mem_range] at hj
    refine ⟨j + 1, ?_, ?_⟩
    · rw [Finset.mem_Icc]
      omega
    · omega
  · intro m hm
    rw [Finset.mem_Icc] at hm
    have hpos : 1 ≤ m := hm.1
    have hcast : ((m - 1 : ℕ) : ℝ) + 1 = (m : ℝ) := by
      exact_mod_cast Nat.sub_add_cancel hpos
    rw [hcast]
    simp [Nat.sub_add_cancel hpos]

theorem abs_coprimeHarmonicIcc_sub_log_main_le
    (L X : ℕ) (hL : 0 < L) :
    |coprimeHarmonicIccReal L X -
      ((Nat.totient L : ℝ) / (L : ℝ)) * Real.log X| ≤
      2 * L + 1 := by
  rw [coprimeHarmonicIccReal_eq_shifted]
  exact abs_shiftedCoprimeHarmonic_sub_log_main_le L X hL

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem etaCoeff_eq_etaLinearArithmetic_div
    (q n : ℕ) (hn : n ≠ 0) :
    etaCoeff q n = etaLinearArithmetic q n / (n : ℝ) := by
  change etaCoeff q n =
    ((n : ℝ) * etaCoeff q n) / (n : ℝ)
  have hnR : (n : ℝ) ≠ 0 := by exact_mod_cast hn
  field_simp [hnR]

theorem etaCoeff_eq_correction_divisor_sum
    (q n : ℕ) (hn : n ≠ 0) :
    etaCoeff q n =
      ∑ ds ∈ n.divisorsAntidiagonal,
        etaCorrectionInvTerm q ds.2 *
          (coprimeIndicatorArithmetic q ds.1 / (ds.1 : ℝ)) := by
  rw [etaCoeff_eq_etaLinearArithmetic_div q n hn]
  have hfun := etaLinearArithmetic_eq_correction_mul_coprime q
  have hnval := congrArg (fun f : ArithmeticFunction ℝ => f n) hfun
  rw [hnval]
  rw [mul_comm]
  rw [ArithmeticFunction.mul_apply]
  rw [Finset.sum_div]
  apply Finset.sum_congr rfl
  intro ds hds
  have hprod : ds.1 * ds.2 = n :=
    (Nat.mem_divisorsAntidiagonal.mp hds).1
  have hleft : ds.1 ≠ 0 :=
    Nat.left_ne_zero_of_mem_divisorsAntidiagonal hds
  have hright : ds.2 ≠ 0 :=
    Nat.right_ne_zero_of_mem_divisorsAntidiagonal hds
  unfold etaCorrectionInvTerm
  rw [show (n : ℝ) = (ds.1 : ℝ) * (ds.2 : ℝ) by
    exact_mod_cast hprod.symm]
  have hlR : (ds.1 : ℝ) ≠ 0 := by exact_mod_cast hleft
  have hrR : (ds.2 : ℝ) ≠ 0 := by exact_mod_cast hright
  field_simp [hlR, hrR]

#print axioms etaCoeff_eq_correction_divisor_sum

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def etaPartialSum (q X : ℕ) : ℝ :=
  ∑ n ∈ Finset.Icc 1 X, etaCoeff q n

theorem etaPartialSum_eq_correction_harmonic
    (q X : ℕ) :
    etaPartialSum q X =
      ∑ d ∈ Finset.Icc 1 X,
        etaCorrectionInvTerm q d *
          coprimeHarmonicIccReal (6 * q) (X / d) := by
  classical
  unfold etaPartialSum
  calc
    (∑ n ∈ Finset.Icc 1 X, etaCoeff q n)
      = ∑ n ∈ Finset.Icc 1 X,
          ∑ ds ∈ n.divisorsAntidiagonal,
            etaCorrectionInvTerm q ds.2 *
              (coprimeIndicatorArithmetic q ds.1 / (ds.1 : ℝ)) := by
          apply Finset.sum_congr rfl
          intro n hn
          have hn0 : n ≠ 0 := by
            rw [Finset.mem_Icc] at hn
            omega
          exact etaCoeff_eq_correction_divisor_sum q n hn0
    _ = ∑ x ∈ petermannDivisorSigma X,
          etaCorrectionInvTerm q x.2.2 *
            (coprimeIndicatorArithmetic q x.2.1 / (x.2.1 : ℝ)) := by
          rw [petermannDivisorSigma, Finset.sum_sigma']
    _ = ∑ d ∈ Finset.Icc 1 X,
          ∑ m ∈ Finset.Icc 1 (X / d),
            etaCorrectionInvTerm q d *
              (coprimeIndicatorArithmetic q m / (m : ℝ)) := by
          exact sum_petermannDivisorSigma_eq_nested X
            (fun d m =>
              etaCorrectionInvTerm q d *
                (coprimeIndicatorArithmetic q m / (m : ℝ)))
    _ = ∑ d ∈ Finset.Icc 1 X,
        etaCorrectionInvTerm q d *
          coprimeHarmonicIccReal (6 * q) (X / d) := by
          apply Finset.sum_congr rfl
          intro d hd
          rw [← Finset.mul_sum]
          congr 1
          unfold coprimeHarmonicIccReal
          apply Finset.sum_congr rfl
          intro m hm
          have hm0 : m ≠ 0 := by
            rw [Finset.mem_Icc] at hm
            omega
          rw [coprimeIndicatorArithmetic_apply]
          rw [coprimeIndicatorCoeff, if_neg hm0]
          simpa [Nat.coprime_comm]

#print axioms etaPartialSum_eq_correction_harmonic

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem abs_coprimeHarmonicIcc_sub_density_harmonic_le
    (L X : ℕ) (hL : 0 < L) :
    |coprimeHarmonicIccReal L X -
      ((Nat.totient L : ℝ) / (L : ℝ)) * (harmonic X : ℝ)| ≤
      2 * L := by
  rw [coprimeHarmonicIccReal_eq_shifted]
  unfold shiftedCoprimeHarmonicReal
  rw [← shiftedHarmonicReal_eq_harmonic X]
  unfold shiftedHarmonicReal
  exact abs_shifted_coprime_harmonic_error_le L X hL

theorem abs_coprimeHarmonicIcc_sub_log_ratio_le
    (L X d : ℕ) (hL : 0 < L)
    (hd1 : 1 ≤ d) (hdX : d ≤ X) :
    |coprimeHarmonicIccReal L (X / d) -
      ((Nat.totient L : ℝ) / (L : ℝ)) *
        (Real.log X - Real.log d)| ≤
      2 * L + 1 := by
  let y : ℝ := (X : ℝ) / (d : ℝ)
  have hd0 : d ≠ 0 := Nat.ne_of_gt (lt_of_lt_of_le Nat.zero_lt_one hd1)
  have hX0 : X ≠ 0 := by omega
  have hdR : (0 : ℝ) < d := by positivity
  have hXR : (0 : ℝ) < X := by positivity
  have hy1 : (1 : ℝ) ≤ y := by
    dsimp [y]
    rw [le_div_iff₀ hdR]
    simpa using (show (d : ℝ) ≤ (X : ℝ) by exact_mod_cast hdX)
  have hfloor : ⌊y⌋₊ = X / d := by
    dsimp [y]
    exact Nat.floor_div_eq_div X d
  have hlo : Real.log y ≤ (harmonic (X / d) : ℝ) := by
    have h := log_le_harmonic_floor y (by positivity)
    rw [hfloor] at h
    exact h
  have hhi : (harmonic (X / d) : ℝ) ≤ 1 + Real.log y := by
    have h := harmonic_floor_le_one_add_log y hy1
    rw [hfloor] at h
    exact h
  have hH : |(harmonic (X / d) : ℝ) - Real.log y| ≤ 1 := by
    rw [abs_le]
    constructor <;> linarith
  have hcenter :=
    abs_coprimeHarmonicIcc_sub_density_harmonic_le L (X / d) hL
  have htot : Nat.totient L ≤ L := Nat.totient_le L
  have hLR : (0 : ℝ) < L := by exact_mod_cast hL
  have hD0 : 0 ≤ (Nat.totient L : ℝ) / (L : ℝ) := by positivity
  have hD1 : (Nat.totient L : ℝ) / (L : ℝ) ≤ 1 := by
    rw [div_le_one hLR]
    exact_mod_cast htot
  have hlog :
      Real.log y = Real.log X - Real.log d := by
    dsimp [y]
    exact Real.log_div (by positivity) (by positivity)
  rw [← hlog]
  have hsplit :
      coprimeHarmonicIccReal L (X / d) -
        ((Nat.totient L : ℝ) / (L : ℝ)) * Real.log y =
      (coprimeHarmonicIccReal L (X / d) -
        ((Nat.totient L : ℝ) / (L : ℝ)) * (harmonic (X / d) : ℝ)) +
      ((Nat.totient L : ℝ) / (L : ℝ)) *
        ((harmonic (X / d) : ℝ) - Real.log y) := by
    ring
  rw [hsplit]
  calc
    |(coprimeHarmonicIccReal L (X / d) -
        ((Nat.totient L : ℝ) / (L : ℝ)) * (harmonic (X / d) : ℝ)) +
      ((Nat.totient L : ℝ) / (L : ℝ)) *
        ((harmonic (X / d) : ℝ) - Real.log y)|
        ≤
      |coprimeHarmonicIccReal L (X / d) -
        ((Nat.totient L : ℝ) / (L : ℝ)) * (harmonic (X / d) : ℝ)| +
      |((Nat.totient L : ℝ) / (L : ℝ)) *
        ((harmonic (X / d) : ℝ) - Real.log y)| :=
      abs_add_le _ _
    _ ≤ 2 * L + 1 := by
      rw [abs_mul, abs_of_nonneg hD0]
      nlinarith [hcenter, hH,
        abs_nonneg ((harmonic (X / d) : ℝ) - Real.log y)]

#print axioms abs_coprimeHarmonicIcc_sub_log_ratio_le

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem sum_Icc_abs_etaCorrectionInvTerm_le_bound
    (q X : ℕ) :
    (∑ n ∈ Finset.Icc 1 X, |etaCorrectionInvTerm q n|) ≤
      etaRankinBound := by
  calc
    (∑ n ∈ Finset.Icc 1 X, |etaCorrectionInvTerm q n|)
        ≤ ∑' n : ℕ, |etaCorrectionInvTerm q n| := by
          exact (summable_etaCorrectionInvTerm q).abs.sum_le_tsum
            (Finset.Icc 1 X) (fun n hn => abs_nonneg _)
    _ ≤ etaRankinBound := tsum_abs_etaCorrectionInvTerm_le_bound q

theorem abs_etaCorrectionInvTerm_mul_log_le_four_rankin
    (q n : ℕ) :
    |etaCorrectionInvTerm q n * Real.log n| ≤
      4 * etaCorrectionRankin q n := by
  by_cases hn0 : n = 0
  · subst n
    simp
  · have hnpos : (0 : ℝ) < n := by positivity
    have hn1 : 1 ≤ n := Nat.one_le_iff_ne_zero.mpr hn0
    have hlog0 : 0 ≤ Real.log (n : ℝ) :=
      Real.log_nonneg (by exact_mod_cast hn1)
    have hlog :=
      Real.log_natCast_le_rpow_div n
        (show (0 : ℝ) < (1 / 4 : ℝ) by norm_num)
    rw [etaCorrectionInvTerm, etaCorrectionRankin, if_neg hn0]
    rw [abs_mul, abs_div, abs_of_pos hnpos, abs_of_nonneg hlog0]
    have hpow :
        (n : ℝ)⁻¹ * ((n : ℝ) ^ (1 / 4 : ℝ)) =
          (n : ℝ) ^ (-3 / 4 : ℝ) := by
      rw [← Real.rpow_neg_one]
      rw [← Real.rpow_add hnpos]
      norm_num
    calc
      |etaLinearCorrectionArithmetic q n| / (n : ℝ) *
          Real.log (n : ℝ)
          ≤ |etaLinearCorrectionArithmetic q n| / (n : ℝ) *
              ((n : ℝ) ^ (1 / 4 : ℝ) / (1 / 4 : ℝ)) := by
                exact mul_le_mul_of_nonneg_left hlog
                  (div_nonneg (abs_nonneg _) hnpos.le)
      _ = |etaLinearCorrectionArithmetic q n| * (n : ℝ)⁻¹ *
          ((n : ℝ) ^ (1 / 4 : ℝ) * 4) := by
            rw [div_eq_mul_inv, div_eq_mul_inv]
            norm_num
      _ = 4 * (|etaLinearCorrectionArithmetic q n| *
          ((n : ℝ)⁻¹ * (n : ℝ) ^ (1 / 4 : ℝ))) := by ring
      _ = 4 * (|etaLinearCorrectionArithmetic q n| *
          (n : ℝ) ^ (-3 / 4 : ℝ)) := by rw [hpow]

theorem sum_Icc_abs_etaCorrectionInvTerm_mul_log_le
    (q X : ℕ) :
    (∑ n ∈ Finset.Icc 1 X,
      |etaCorrectionInvTerm q n * Real.log n|) ≤
      4 * etaRankinBound := by
  calc
    (∑ n ∈ Finset.Icc 1 X,
      |etaCorrectionInvTerm q n * Real.log n|)
        ≤ ∑ n ∈ Finset.Icc 1 X,
            4 * etaCorrectionRankin q n := by
              exact Finset.sum_le_sum fun n hn =>
                abs_etaCorrectionInvTerm_mul_log_le_four_rankin q n
    _ = 4 * ∑ n ∈ Finset.Icc 1 X,
          etaCorrectionRankin q n := by
            rw [Finset.mul_sum]
    _ ≤ 4 * etaRankinBound := by
      apply mul_le_mul_of_nonneg_left _ (by norm_num)
      calc
        (∑ n ∈ Finset.Icc 1 X, etaCorrectionRankin q n)
            ≤ ∑' n : ℕ, etaCorrectionRankin q n := by
              exact (summable_etaCorrectionRankin q).sum_le_tsum
                (Finset.Icc 1 X)
                (fun n hn => etaCorrectionRankin_nonneg q n)
        _ ≤ etaRankinBound := tsum_etaCorrectionRankin_le_bound q

#print axioms abs_etaCorrectionInvTerm_mul_log_le_four_rankin

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem abs_log_mul_etaCorrectionInv_tail_le
    (q X : ℕ) (hX : 1 ≤ X) :
    |Real.log X *
      ((∑ d ∈ Finset.Icc 1 X, etaCorrectionInvTerm q d) -
        etaCorrectionInvMass q)| ≤
      4 * etaRankinBound := by
  let s : Finset ℕ := Finset.Icc 1 X
  have hsum := summable_etaCorrectionInvTerm q
  have hdecomp := hsum.sum_add_tsum_subtype_compl s
  unfold etaCorrectionInvMass at hdecomp
  have htail :
      (∑ d ∈ s, etaCorrectionInvTerm q d) -
          (∑' d : ℕ, etaCorrectionInvTerm q d) =
        -(∑' d : {d // d ∉ s}, etaCorrectionInvTerm q d) := by
    linarith
  rw [show (∑ d ∈ Finset.Icc 1 X, etaCorrectionInvTerm q d) =
      ∑ d ∈ s, etaCorrectionInvTerm q d by rfl]
  unfold etaCorrectionInvMass
  rw [htail]
  have hlog0 : 0 ≤ Real.log (X : ℝ) :=
    Real.log_nonneg (by exact_mod_cast hX)
  have hpoint :
      ∀ d : {d // d ∉ s},
        ‖Real.log (X : ℝ) * etaCorrectionInvTerm q d.1‖ ≤
          4 * etaCorrectionRankin q d.1 := by
    intro d
    by_cases hd0 : d.1 = 0
    · simp [hd0]
    · have hdnot : d.1 ∉ Finset.Icc 1 X := d.2
      have hd1 : 1 ≤ d.1 := Nat.one_le_iff_ne_zero.mpr hd0
      have hXd : X < d.1 := by
        rw [Finset.mem_Icc] at hdnot
        push_neg at hdnot
        exact hdnot hd1
      have hlogle : Real.log (X : ℝ) ≤ Real.log (d.1 : ℝ) := by
        exact Real.log_le_log
          (by positivity : (0 : ℝ) < X)
          (by exact_mod_cast hXd.le)
      have hlogd0 : 0 ≤ Real.log (d.1 : ℝ) :=
        Real.log_nonneg (by exact_mod_cast hd1)
      have hbase :=
        abs_etaCorrectionInvTerm_mul_log_le_four_rankin q d.1
      rw [Real.norm_eq_abs, abs_mul, abs_of_nonneg hlog0]
      rw [abs_mul, abs_of_nonneg hlogd0] at hbase
      exact (mul_le_mul_of_nonneg_right hlogle (abs_nonneg _)).trans
        (by simpa [mul_comm] using hbase)
  have hsubsum :
      Summable (fun d : {d // d ∉ s} =>
        Real.log (X : ℝ) * etaCorrectionInvTerm q d.1) := by
    exact (hsum.subtype _).mul_left _
  have hnorm0 :
      ‖∑' d : {d // d ∉ s},
          Real.log (X : ℝ) * etaCorrectionInvTerm q d.1‖ ≤
        ∑' d : {d // d ∉ s},
          ‖Real.log (X : ℝ) * etaCorrectionInvTerm q d.1‖ :=
    norm_tsum_le_tsum_norm hsubsum.norm
  have hnorm1 :
      (∑' d : {d // d ∉ s},
          ‖Real.log (X : ℝ) * etaCorrectionInvTerm q d.1‖) ≤
        ∑' d : {d // d ∉ s}, 4 * etaCorrectionRankin q d.1 := by
    exact hsubsum.norm.tsum_le_tsum hpoint
      ((summable_etaCorrectionRankin q).subtype _ |>.mul_left 4)
  have hnorm := hnorm0.trans hnorm1
  have hmajor :
      (∑' d : {d // d ∉ s}, 4 * etaCorrectionRankin q d.1) ≤
        4 * etaRankinBound := by
    rw [tsum_mul_left]
    have hrankDecomp :=
      (summable_etaCorrectionRankin q).sum_add_tsum_subtype_compl s
    have hfin0 :
        0 ≤ ∑ d ∈ s, etaCorrectionRankin q d := by
      exact Finset.sum_nonneg (fun d hd => etaCorrectionRankin_nonneg q d)
    have hsub :
        (∑' d : {d // d ∉ s}, etaCorrectionRankin q d.1) ≤
          ∑' d : ℕ, etaCorrectionRankin q d := by
      linarith
    exact mul_le_mul_of_nonneg_left
      (hsub.trans (tsum_etaCorrectionRankin_le_bound q)) (by norm_num)
  have htotal := hnorm.trans hmajor
  rw [mul_neg, abs_neg]
  rw [← tsum_mul_left]
  simpa [Real.norm_eq_abs] using htotal

#print axioms abs_log_mul_etaCorrectionInv_tail_le

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def etaHarmonicError (q X d : ℕ) : ℝ :=
  coprimeHarmonicIccReal (6 * q) (X / d) -
    ((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
      (Real.log X - Real.log d)

theorem abs_etaHarmonicError_le
    (q X d : ℕ) (hq : 0 < q)
    (hd1 : 1 ≤ d) (hdX : d ≤ X) :
    |etaHarmonicError q X d| ≤ 2 * (6 * q) + 1 := by
  unfold etaHarmonicError
  simpa [Nat.cast_mul] using
    (abs_coprimeHarmonicIcc_sub_log_ratio_le
      (6 * q) X d (mul_pos (by norm_num) hq) hd1 hdX)

theorem etaPrincipalError_decomposition
    (q X : ℕ) (hq : 0 < q) :
    etaPartialSum q X -
        logarithmicEulerResidue (etaCoeff q) * Real.log X =
      (∑ d ∈ Finset.Icc 1 X,
        etaCorrectionInvTerm q d * etaHarmonicError q X d) -
      ((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
        (∑ d ∈ Finset.Icc 1 X,
          etaCorrectionInvTerm q d * Real.log d) +
      ((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
        Real.log X *
        ((∑ d ∈ Finset.Icc 1 X, etaCorrectionInvTerm q d) -
          etaCorrectionInvMass q) := by
  rw [etaPartialSum_eq_correction_harmonic]
  have hR :=
    six_mul_density_mul_etaCorrectionInvMass_eq_residue q hq
  rw [← hR]
  let D : ℝ := (Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)
  have hsumerr :
      (∑ d ∈ Finset.Icc 1 X,
        etaCorrectionInvTerm q d * etaHarmonicError q X d) =
      (∑ d ∈ Finset.Icc 1 X,
        etaCorrectionInvTerm q d *
          coprimeHarmonicIccReal (6 * q) (X / d)) -
      D * Real.log X *
        (∑ d ∈ Finset.Icc 1 X, etaCorrectionInvTerm q d) +
      D * (∑ d ∈ Finset.Icc 1 X,
        etaCorrectionInvTerm q d * Real.log d) := by
    calc
      (∑ d ∈ Finset.Icc 1 X,
        etaCorrectionInvTerm q d * etaHarmonicError q X d)
          = ∑ d ∈ Finset.Icc 1 X,
              (etaCorrectionInvTerm q d *
                coprimeHarmonicIccReal (6 * q) (X / d) -
               D * Real.log X * etaCorrectionInvTerm q d +
               D * (etaCorrectionInvTerm q d * Real.log d)) := by
                apply Finset.sum_congr rfl
                intro d hd
                unfold etaHarmonicError D
                ring
      _ = (∑ d ∈ Finset.Icc 1 X,
              etaCorrectionInvTerm q d *
                coprimeHarmonicIccReal (6 * q) (X / d)) -
            D * Real.log X *
              (∑ d ∈ Finset.Icc 1 X, etaCorrectionInvTerm q d) +
            D * (∑ d ∈ Finset.Icc 1 X,
              etaCorrectionInvTerm q d * Real.log d) := by
                rw [Finset.sum_add_distrib, Finset.sum_sub_distrib]
                rw [← Finset.mul_sum, ← Finset.mul_sum]
  rw [hsumerr]
  dsimp [D]
  ring

theorem abs_etaHarmonicErrorSum_le
    (q X : ℕ) (hq : 0 < q) :
    |∑ d ∈ Finset.Icc 1 X,
        etaCorrectionInvTerm q d * etaHarmonicError q X d| ≤
      (2 * (6 * q) + 1) * etaRankinBound := by
  calc
    |∑ d ∈ Finset.Icc 1 X,
        etaCorrectionInvTerm q d * etaHarmonicError q X d|
        ≤ ∑ d ∈ Finset.Icc 1 X,
            |etaCorrectionInvTerm q d * etaHarmonicError q X d| := by
              exact Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ d ∈ Finset.Icc 1 X,
          (2 * (6 * q) + 1) * |etaCorrectionInvTerm q d| := by
            apply Finset.sum_le_sum
            intro d hd
            rw [abs_mul]
            have hmem := Finset.mem_Icc.mp hd
            have hE := abs_etaHarmonicError_le q X d hq hmem.1 hmem.2
            have ha0 := abs_nonneg (etaCorrectionInvTerm q d)
            nlinarith
    _ = (2 * (6 * q) + 1) *
          ∑ d ∈ Finset.Icc 1 X, |etaCorrectionInvTerm q d| := by
            rw [Finset.mul_sum]
    _ ≤ (2 * (6 * q) + 1) * etaRankinBound := by
      apply mul_le_mul_of_nonneg_left
      · exact sum_Icc_abs_etaCorrectionInvTerm_le_bound q X
      · positivity

theorem abs_etaLogMomentTerm_le
    (q X : ℕ) (hq : 0 < q) :
    |((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
      (∑ d ∈ Finset.Icc 1 X,
        etaCorrectionInvTerm q d * Real.log d)| ≤
      4 * etaRankinBound := by
  let D : ℝ := (Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)
  have hLpos : 0 < 6 * q := mul_pos (by norm_num) hq
  have hD0 : 0 ≤ D := by
    dsimp [D]
    positivity
  have hD1 : D ≤ 1 := by
    dsimp [D]
    rw [div_le_one (by positivity : (0 : ℝ) < (6 * q : ℕ))]
    exact_mod_cast Nat.totient_le (6 * q)
  have hsum :
      |∑ d ∈ Finset.Icc 1 X,
        etaCorrectionInvTerm q d * Real.log d| ≤
      4 * etaRankinBound := by
    calc
      |∑ d ∈ Finset.Icc 1 X,
        etaCorrectionInvTerm q d * Real.log d|
          ≤ ∑ d ∈ Finset.Icc 1 X,
              |etaCorrectionInvTerm q d * Real.log d| := by
                exact Finset.abs_sum_le_sum_abs _ _
      _ ≤ 4 * etaRankinBound :=
        sum_Icc_abs_etaCorrectionInvTerm_mul_log_le q X
  change |D * (∑ d ∈ Finset.Icc 1 X,
    etaCorrectionInvTerm q d * Real.log d)| ≤ _
  rw [abs_mul, abs_of_nonneg hD0]
  have hB0 : 0 ≤ etaRankinBound := by
    unfold etaRankinBound
    positivity
  nlinarith [abs_nonneg
    (∑ d ∈ Finset.Icc 1 X,
      etaCorrectionInvTerm q d * Real.log d)]

theorem abs_etaTailTerm_le
    (q X : ℕ) (hq : 0 < q) (hX : 1 ≤ X) :
    |((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
      Real.log X *
      ((∑ d ∈ Finset.Icc 1 X, etaCorrectionInvTerm q d) -
        etaCorrectionInvMass q)| ≤
      4 * etaRankinBound := by
  let D : ℝ := (Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)
  have hD0 : 0 ≤ D := by
    dsimp [D]
    positivity
  have hD1 : D ≤ 1 := by
    dsimp [D]
    rw [div_le_one (by positivity : (0 : ℝ) < (6 * q : ℕ))]
    exact_mod_cast Nat.totient_le (6 * q)
  have htail := abs_log_mul_etaCorrectionInv_tail_le q X hX
  change |D * Real.log X *
      ((∑ d ∈ Finset.Icc 1 X, etaCorrectionInvTerm q d) -
        etaCorrectionInvMass q)| ≤ _
  rw [show D * Real.log X *
      ((∑ d ∈ Finset.Icc 1 X, etaCorrectionInvTerm q d) -
        etaCorrectionInvMass q) =
      D * (Real.log X *
        ((∑ d ∈ Finset.Icc 1 X, etaCorrectionInvTerm q d) -
          etaCorrectionInvMass q)) by ring]
  rw [abs_mul, abs_of_nonneg hD0]
  have hB0 : 0 ≤ etaRankinBound := by
    unfold etaRankinBound
    positivity
  nlinarith [abs_nonneg
    (Real.log X *
      ((∑ d ∈ Finset.Icc 1 X, etaCorrectionInvTerm q d) -
        etaCorrectionInvMass q))]

theorem etaPrincipalLogMean_bound
    (q X : ℕ) (hq : 0 < q) (hX : 1 ≤ X) :
    |etaPartialSum q X -
      logarithmicEulerResidue (etaCoeff q) * Real.log X| ≤
      (2 * (6 * q) + 9) * etaRankinBound := by
  rw [etaPrincipalError_decomposition q X hq]
  have hA := abs_etaHarmonicErrorSum_le q X hq
  have hB := abs_etaLogMomentTerm_le q X hq
  have hC := abs_etaTailTerm_le q X hq hX
  calc
    |(∑ d ∈ Finset.Icc 1 X,
        etaCorrectionInvTerm q d * etaHarmonicError q X d) -
      ((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
        (∑ d ∈ Finset.Icc 1 X,
          etaCorrectionInvTerm q d * Real.log d) +
      ((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
        Real.log X *
        ((∑ d ∈ Finset.Icc 1 X, etaCorrectionInvTerm q d) -
          etaCorrectionInvMass q)|
      ≤
      |∑ d ∈ Finset.Icc 1 X,
        etaCorrectionInvTerm q d * etaHarmonicError q X d| +
      |((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
        (∑ d ∈ Finset.Icc 1 X,
          etaCorrectionInvTerm q d * Real.log d)| +
      |((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
        Real.log X *
        ((∑ d ∈ Finset.Icc 1 X, etaCorrectionInvTerm q d) -
          etaCorrectionInvMass q)| := by
            calc
              |((∑ d ∈ Finset.Icc 1 X,
                etaCorrectionInvTerm q d * etaHarmonicError q X d) -
                ((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
                  (∑ d ∈ Finset.Icc 1 X,
                    etaCorrectionInvTerm q d * Real.log d)) +
                ((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
                  Real.log X *
                  ((∑ d ∈ Finset.Icc 1 X, etaCorrectionInvTerm q d) -
                    etaCorrectionInvMass q)|
                  ≤
                |(∑ d ∈ Finset.Icc 1 X,
                  etaCorrectionInvTerm q d * etaHarmonicError q X d) -
                  ((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
                    (∑ d ∈ Finset.Icc 1 X,
                      etaCorrectionInvTerm q d * Real.log d)| +
                |((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
                  Real.log X *
                  ((∑ d ∈ Finset.Icc 1 X, etaCorrectionInvTerm q d) -
                    etaCorrectionInvMass q)| :=
                    abs_add_le _ _
              _ ≤
                |∑ d ∈ Finset.Icc 1 X,
                  etaCorrectionInvTerm q d * etaHarmonicError q X d| +
                |((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
                  (∑ d ∈ Finset.Icc 1 X,
                    etaCorrectionInvTerm q d * Real.log d)| +
                |((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
                  Real.log X *
                  ((∑ d ∈ Finset.Icc 1 X, etaCorrectionInvTerm q d) -
                    etaCorrectionInvMass q)| := by
                    have hsub := abs_sub
                      (∑ d ∈ Finset.Icc 1 X,
                        etaCorrectionInvTerm q d * etaHarmonicError q X d)
                      (((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
                        (∑ d ∈ Finset.Icc 1 X,
                          etaCorrectionInvTerm q d * Real.log d))
                    linarith
    _ ≤ (2 * (6 * q) + 9) * etaRankinBound := by
      have hR0 : 0 ≤ etaRankinBound := by
        unfold etaRankinBound
        positivity
      nlinarith

#print axioms etaPrincipalLogMean_bound

end PaperB.FixedQ
