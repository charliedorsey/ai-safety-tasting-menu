import PaperB.FixedQ.OneDimensionalBracket
import PaperB.FixedQ.H2BooleanPeriodicWeightedET
import PaperB.FixedQ.H2BooleanInteriorEndpointBridge

open scoped BigOperators

namespace PaperB.FixedQ

lemma kairn_periodicWeightMass_eq_rowPrefixMass
    {P : ℕ} (w : ℕ → ℝ) (hP : 0 < P)
    (hper : Function.Periodic w P) :
    periodicWeightMass P w = rowPrefixMass w P := by
  unfold periodicWeightMass rowPrefixMass
  have hshift := calder_sum_range_succ_shift_eq_Icc w P
  rw [← hshift]
  have h1 := Finset.sum_range_succ w P
  have h2 := Finset.sum_range_succ' w P
  have hper0 := hper 0
  simp only [zero_add] at hper0
  rw [hper0] at h1
  linarith

#print axioms kairn_periodicWeightMass_eq_rowPrefixMass

noncomputable def h2EndpointRowConst (q : ℕ) : ℝ :=
  9 * (fixedQPeriod q : ℝ) +
    ((fixedQPeriod q : ℝ) * (6 + |fixedQDensityMean q|) + 6) +
    |fixedQDensityMean q|

lemma rowDiscrepancy_fixedQLowWeight_eq_occupied
    {q A H m : ℕ}
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H) :
    rowDiscrepancy (fixedQLowWeight q A H) H m 1 =
      rowDiscrepancy (occupiedFixedQLowWeight q A H) H m 1 := by
  unfold rowDiscrepancy rowConstrainedMass rowWeightMass
  congr 1
  · apply Finset.sum_congr rfl
    intro y hy
    have hyI := Finset.mem_Ioo.mp hy
    by_cases hc : m ∣ y ∧ 1 ∣ H - y
    · simp only [hc, if_true]
      exact fixedQLowWeight_eq_occupied (Nat.le_of_lt hyI.2) h2admissible
    · simp only [hc, if_false]
  · congr 1
    apply Finset.sum_congr rfl
    intro y hy
    have hyI := Finset.mem_Ioo.mp hy
    exact fixedQLowWeight_eq_occupied (Nat.le_of_lt hyI.2) h2admissible

theorem abs_rowDiscrepancy_fixedQLowWeight_full_endpoint_le
    {q A H : ℕ} {e : Finset ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H)
    (hActive : ∀ p ∈ e, activeHighPrime q p) :
    |rowDiscrepancy (fixedQLowWeight q A H) H
        (primeSetProduct e) 1| ≤ h2EndpointRowConst q := by
  let P := fixedQPeriod q
  let m := primeSetProduct e
  let w := occupiedFixedQLowWeight q A H
  let mu := fixedQDensityMean q
  have hP : 0 < P := fixedQPeriod_pos q hq
  letI : NeZero P := ⟨hP.ne'⟩
  have hm : 0 < m := primeSetProduct_pos (fun p hp => (hActive p hp).1)
  have hcop : m.Coprime P := activePrimeSetProduct_coprime_fixedQPeriod hActive
  have hper : Function.Periodic w P := occupiedFixedQLowWeight_periodic q A H
  have hw : ∀ c ∈ Finset.Icc 1 P, |w c| ≤ 6 := by
    intro c hc
    exact abs_occupiedFixedQLowWeight_le_six q A H c h2admissible
  have hperiod :
      periodicWeightMass P w = mu * (P : ℝ) := by
    rw [kairn_periodicWeightMass_eq_rowPrefixMass w hP hper]
    dsimp [P, w, mu]
    exact rowPrefixMass_occupiedFixedQLowWeight_mean hq h2admissible
  have hrow :
      |rowWeightMass w H - mu * (H : ℝ)| ≤
        (P : ℝ) * (6 + |mu|) + 6 := by
    have hbase := abs_rowWeightMass_error_le
      w mu P H hP hH hper
      (by
        dsimp [P, w, mu]
        exact rowPrefixMass_occupiedFixedQLowWeight_mean hq h2admissible)
    have hperr := rowPrefixPeriodErrorBound_occupied_le q A H h2admissible
    dsimp [P, w, mu] at hbase hperr ⊢
    have hw0 := abs_occupiedFixedQLowWeight_le_six q A H 0 h2admissible
    exact hbase.trans (add_le_add hperr hw0)
  have hdecomp :
      rowDiscrepancy w H m 1 =
        mu * (((H - 1 : ℕ) : ℝ) / (m : ℝ)) +
          manuscriptBoundaryTerm P w (ZMod.unitOfCoprime m hcop) -
          manuscriptSawtoothTerm P w (ZMod.unitOfCoprime m hcop)
            (((H - 1 : ℕ) : ℝ) / (m : ℝ)) -
          rowWeightMass w H / (m : ℝ) := by
    unfold rowDiscrepancy
    rw [rowConstrainedMass_one_eq_dilate_prefix w H m hH hm]
    rw [exactManuscriptPeriodicFloorDecomposition_realDiv
      (w := w) (L := P) (e := m) (X := H - 1)
      hcop (Nat.one_le_iff_ne_zero.mpr hm.ne') hper]
    rw [hperiod]
    have hPR : (P : ℝ) ≠ 0 := by exact_mod_cast hP.ne'
    field_simp [hPR]
    ring
  have hB := abs_manuscriptBoundaryTerm_le P w hw
    (ZMod.unitOfCoprime m hcop)
  have hS := abs_manuscriptSawtoothTerm_le P w hw
    (ZMod.unitOfCoprime m hcop)
    (((H - 1 : ℕ) : ℝ) / (m : ℝ))
  have hH1 : 1 ≤ H := Nat.one_le_iff_ne_zero.mpr hH.ne'
  have hsub : (((H - 1 : ℕ) : ℝ)) = (H : ℝ) - 1 := by
    rw [Nat.cast_sub hH1]
    norm_num
  have hE0 : 0 ≤ (P : ℝ) * (6 + |mu|) + 6 := by positivity
  have hnum :
      |mu * (((H - 1 : ℕ) : ℝ)) - rowWeightMass w H| ≤
        ((P : ℝ) * (6 + |mu|) + 6) + |mu| := by
    rw [hsub]
    have htri := abs_sub
      (-(rowWeightMass w H - mu * (H : ℝ))) mu
    have heq :
        mu * ((H : ℝ) - 1) - rowWeightMass w H =
          -(rowWeightMass w H - mu * (H : ℝ)) - mu := by ring
    rw [heq]
    calc
      |-(rowWeightMass w H - mu * (H : ℝ)) - mu|
        ≤ |-(rowWeightMass w H - mu * (H : ℝ))| + |mu| := htri
      _ = |rowWeightMass w H - mu * (H : ℝ)| + |mu| := by rw [abs_neg]
      _ ≤ ((P : ℝ) * (6 + |mu|) + 6) + |mu| := by
        simpa [add_comm, add_left_comm, add_assoc] using
          (add_le_add_right hrow |mu|)
  have hmR : (1 : ℝ) ≤ m := by exact_mod_cast (Nat.one_le_iff_ne_zero.mpr hm.ne')
  have hmPosR : (0 : ℝ) < m := lt_of_lt_of_le zero_lt_one hmR
  have hmain :
      |mu * (((H - 1 : ℕ) : ℝ) / (m : ℝ)) -
          rowWeightMass w H / (m : ℝ)| ≤
        ((P : ℝ) * (6 + |mu|) + 6) + |mu| := by
    have heq :
        mu * (((H - 1 : ℕ) : ℝ) / (m : ℝ)) -
            rowWeightMass w H / (m : ℝ) =
          (mu * (((H - 1 : ℕ) : ℝ)) - rowWeightMass w H) / (m : ℝ) := by
      field_simp [ne_of_gt hmPosR]
    rw [heq, abs_div, abs_of_pos hmPosR]
    have hden0 : 0 ≤ ((P : ℝ) * (6 + |mu|) + 6) + |mu| := by positivity
    calc
      |mu * (((H - 1 : ℕ) : ℝ)) - rowWeightMass w H| / (m : ℝ)
        ≤ (((P : ℝ) * (6 + |mu|) + 6) + |mu|) / (m : ℝ) :=
          div_le_div_of_nonneg_right hnum hmPosR.le
      _ ≤ ((P : ℝ) * (6 + |mu|) + 6) + |mu| := by
        exact (div_le_iff₀ hmPosR).2
          (by nlinarith)
  rw [rowDiscrepancy_fixedQLowWeight_eq_occupied h2admissible]
  rw [hdecomp]
  have htri :
      |mu * (((H - 1 : ℕ) : ℝ) / (m : ℝ)) +
          manuscriptBoundaryTerm P w (ZMod.unitOfCoprime m hcop) -
          manuscriptSawtoothTerm P w (ZMod.unitOfCoprime m hcop)
            (((H - 1 : ℕ) : ℝ) / (m : ℝ)) -
          rowWeightMass w H / (m : ℝ)|
        ≤ |mu * (((H - 1 : ℕ) : ℝ) / (m : ℝ)) -
              rowWeightMass w H / (m : ℝ)| +
            |manuscriptBoundaryTerm P w (ZMod.unitOfCoprime m hcop)| +
            |manuscriptSawtoothTerm P w (ZMod.unitOfCoprime m hcop)
              (((H - 1 : ℕ) : ℝ) / (m : ℝ))| := by
    have h1 := abs_add_le
      (mu * (((H - 1 : ℕ) : ℝ) / (m : ℝ)) -
        rowWeightMass w H / (m : ℝ))
      (manuscriptBoundaryTerm P w (ZMod.unitOfCoprime m hcop) -
        manuscriptSawtoothTerm P w (ZMod.unitOfCoprime m hcop)
          (((H - 1 : ℕ) : ℝ) / (m : ℝ)))
    have h2 := abs_sub
      (manuscriptBoundaryTerm P w (ZMod.unitOfCoprime m hcop))
      (manuscriptSawtoothTerm P w (ZMod.unitOfCoprime m hcop)
        (((H - 1 : ℕ) : ℝ) / (m : ℝ)))
    have heq :
        mu * (((H - 1 : ℕ) : ℝ) / (m : ℝ)) +
            manuscriptBoundaryTerm P w (ZMod.unitOfCoprime m hcop) -
            manuscriptSawtoothTerm P w (ZMod.unitOfCoprime m hcop)
              (((H - 1 : ℕ) : ℝ) / (m : ℝ)) -
            rowWeightMass w H / (m : ℝ) =
          (mu * (((H - 1 : ℕ) : ℝ) / (m : ℝ)) -
            rowWeightMass w H / (m : ℝ)) +
          (manuscriptBoundaryTerm P w (ZMod.unitOfCoprime m hcop) -
            manuscriptSawtoothTerm P w (ZMod.unitOfCoprime m hcop)
              (((H - 1 : ℕ) : ℝ) / (m : ℝ))) := by ring
    rw [heq]
    linarith
  calc
    _ ≤ |mu * (((H - 1 : ℕ) : ℝ) / (m : ℝ)) -
              rowWeightMass w H / (m : ℝ)| +
            |manuscriptBoundaryTerm P w (ZMod.unitOfCoprime m hcop)| +
            |manuscriptSawtoothTerm P w (ZMod.unitOfCoprime m hcop)
              (((H - 1 : ℕ) : ℝ) / (m : ℝ))| := htri
    _ ≤ (((P : ℝ) * (6 + |mu|) + 6) + |mu|) +
          6 * P + 3 * P := by linarith
    _ = h2EndpointRowConst q := by
      dsimp [P, mu, h2EndpointRowConst]
      ring

#print axioms abs_rowDiscrepancy_fixedQLowWeight_full_endpoint_le

theorem abs_rowDiscrepancy_fixedQLowWeight_empty_endpoint_le
    {q A H : ℕ} {e : Finset ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H)
    (hActive : ∀ p ∈ e, activeHighPrime q p) :
    |rowDiscrepancy (fixedQLowWeight q A H) H
        1 (primeSetProduct e)| ≤ h2EndpointRowConst q := by
  let r := PaperB.Closure.reflectedResidue q (A + H)
  have hrefC :
      ∀ z ∈ Finset.Ioo 0 H,
        q.Coprime (A + (H - z)) ↔ q.Coprime (r + z) := by
    dsimp [r]
    exact PaperB.Closure.reflected_coprime_equiv hq (Nat.ModEq.refl (A + H))
  have hrefW :
      ∀ z ∈ Finset.Ioo 0 H,
        fixedQLowWeight q A H (H - z) =
          fixedQLowWeight q r H z := by
    intro z hz
    have hzI := Finset.mem_Ioo.mp hz
    exact fixedQLowWeight_reflect_of_coprime
      (Nat.le_of_lt hzI.2) (hrefC z hz)
  rw [rowDiscrepancy_reflect
    (fixedQLowWeight q A H) (fixedQLowWeight q r H)
    H 1 (primeSetProduct e) hrefW]
  exact abs_rowDiscrepancy_fixedQLowWeight_full_endpoint_le
    hq hH h2admissible hActive

#print axioms abs_rowDiscrepancy_fixedQLowWeight_empty_endpoint_le

end PaperB.FixedQ
