import PaperB.FixedQ.PetermannConvolutionLocal

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def petermannHeightCorrection
    (h p : ℕ) : ℝ :=
  if p ∣ h then petermannB p - petermannA p else 0

noncomputable def finitePetermannCorrection
    (h : ℕ) (s : Finset ℕ) : ℝ :=
  ∏ p ∈ s, petermannHeightCorrection h p

theorem movingLocalFactor_eq_base_add_correction
    (h p : ℕ) :
    (if p ∣ h then petermannB p else petermannA p) =
      petermannA p + petermannHeightCorrection h p := by
  unfold petermannHeightCorrection
  by_cases hph : p ∣ h
  · rw [if_pos hph, if_pos hph]
    ring
  · rw [if_neg hph, if_neg hph]
    ring

theorem finiteVWeightReal_eq_subset_convolution
    (h : ℕ) (s : Finset ℕ) :
    finiteVWeightReal h s =
      ∑ t ∈ s.powerset,
        finiteOmegaWeightReal t *
          finitePetermannCorrection h (s \ t) := by
  unfold finiteVWeightReal finiteOmegaWeightReal
  rw [show
      (∏ p ∈ s,
          if p ∣ h then 1 / ((p : ℝ) - 2)
          else 1 / ((p : ℝ) - 3)) =
        ∏ p ∈ s,
          (petermannA p + petermannHeightCorrection h p) by
    apply Finset.prod_congr rfl
    intro p hp
    simpa [petermannA, petermannB] using
      movingLocalFactor_eq_base_add_correction h p]
  rw [Finset.prod_add]
  apply Finset.sum_congr rfl
  intro t ht
  unfold finitePetermannCorrection
  simp [petermannA, mul_comm]

theorem finitePetermannCorrection_eq_zero_of_nonheight
    {h : ℕ} {s : Finset ℕ}
    (hp : ∃ p ∈ s, ¬ p ∣ h) :
    finitePetermannCorrection h s = 0 := by
  rcases hp with ⟨p, hps, hph⟩
  unfold finitePetermannCorrection
  apply Finset.prod_eq_zero hps
  simp [petermannHeightCorrection, hph]

theorem finitePetermannCorrection_eq_prod
    {h : ℕ} {s : Finset ℕ}
    (hs : ∀ p ∈ s, p ∣ h) :
    finitePetermannCorrection h s =
      ∏ p ∈ s, (petermannB p - petermannA p) := by
  unfold finitePetermannCorrection
  apply Finset.prod_congr rfl
  intro p hp
  simp [petermannHeightCorrection, hs p hp]

#print axioms movingLocalFactor_eq_base_add_correction
#print axioms finiteVWeightReal_eq_subset_convolution
#print axioms finitePetermannCorrection_eq_zero_of_nonheight
#print axioms finitePetermannCorrection_eq_prod

end PaperB.FixedQ
