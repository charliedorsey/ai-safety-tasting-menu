import GoldC.QuillonSieve2
import GoldC.QuillonWContext
import GoldC.QuillonOmega

/-!
# Quillon CSC3 F7.8a: rough-number masses for the residues (crude sieve only)

* `omega_le_kappa_inv_prod`: `ω(B) ≤ e^{3|B|/(z−3)}/∏B` when all primes are `≥ z ≥ 4`.
* `block_rough`: one dyadic block `∏B ∈ [2^i, 2^{i+1})` of a set whose primes are all `≥ 2^k`
  (`k ≥ 3`, `k ≤ i`) has `1/∏`-mass `≤ (12/k)·e⁴((i+1)/k)⁴` (`rough_mass` + harmonic prime sums).
* `selfrough_mass`: if all primes of `B` exceed `(∏B)^u` and `z₀ = 2^{k₀}` (`k₀ ≥ 3`),
  `∏B ≤ N₁ < 2^{I+1}`, then `Σ ω(B) ≤ κ·e⁴·2916·(1 + log(I+1))/u⁵`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonResidue

open GoldC.QuillonSieve GoldC.QuillonWContext

/-- `ω(B)·∏B = ∏ p/(p−3) ≤ exp(3|B|/(z−3))` when all primes are `≥ z ≥ 4`. -/
lemma omega_mul_prod_le (B : Finset ℕ) (z : ℕ) (hz : 4 ≤ z) (hB : ∀ p ∈ B, z ≤ p) :
    ωR B * ∏ p ∈ B, (p : ℝ) ≤ Real.exp (3 * B.card / ((z : ℝ) - 3)) := by
  have hzR : (4 : ℝ) ≤ z := by exact_mod_cast hz
  unfold ωR
  rw [← prod_mul_distrib]
  have h1 : ∀ p ∈ B, 1 / ((p : ℝ) - 3) * p ≤ Real.exp (3 / ((z : ℝ) - 3)) := by
    intro p hp
    have hpR : (z : ℝ) ≤ p := by exact_mod_cast hB p hp
    have hp3 : (0 : ℝ) < (p : ℝ) - 3 := by linarith
    have : 1 / ((p : ℝ) - 3) * p = 1 + 3 / ((p : ℝ) - 3) := by field_simp; ring
    rw [this]
    refine (Real.add_one_le_exp _).trans' ?_
    have : 3 / ((p : ℝ) - 3) ≤ 3 / ((z : ℝ) - 3) :=
      div_le_div_of_nonneg_left (by norm_num) (by linarith) (by linarith)
    linarith
  calc ∏ p ∈ B, (1 / ((p : ℝ) - 3) * p) ≤ ∏ _p ∈ B, Real.exp (3 / ((z : ℝ) - 3)) :=
        prod_le_prod₀ (fun p hp => by
          have hpR : (z : ℝ) ≤ p := by exact_mod_cast hB p hp
          have hp3 : (0 : ℝ) < (p : ℝ) - 3 := by linarith
          positivity) h1
    _ = Real.exp (3 * B.card / ((z : ℝ) - 3)) := by
        rw [prod_const, ← Real.exp_nat_mul]; congr 1; ring

/-- The `1/∏`-mass of all subsets of a prime set `S` is `≤ exp(Σ_S 1/p)`. -/
lemma powerset_inv_mass (S : Finset ℕ) :
    ∑ B' ∈ S.powerset, (1 / (∏ p ∈ B', (p : ℝ))) ≤ Real.exp (∑ p ∈ S, (1 / (p : ℝ))) :=
  sum_inv_prod_subsets_le S

/-- One dyadic block of a `2^k`-rough set. -/
lemma block_rough (T : Finset ℕ) (hT : ∀ p ∈ T, p.Prime) (k i : ℕ) (hk : 3 ≤ k) (hki : k ≤ i + 1)
    (hTk : ∀ p ∈ T, 2 ^ k ≤ p) :
    ∑ B ∈ (T.powerset.filter (fun B => B.Nonempty)).filter
        (fun B => 2 ^ i ≤ ∏ p ∈ B, p ∧ ∏ p ∈ B, p < 2 * 2 ^ i), (1 / (∏ p ∈ B, (p : ℝ))) ≤
      (12 / (k : ℝ)) * (Real.exp 4 * (((i + 1 : ℕ) : ℝ) / k) ^ 4) := by
  have hz : 4 ≤ 2 ^ k := by
    calc 4 = 2 ^ 2 := by norm_num
      _ ≤ 2 ^ k := Nat.pow_le_pow_right (by norm_num) (by omega)
  have h := rough_mass T hT (2 ^ k) (2 ^ i) hz hTk
  rw [Nat.log_pow (by norm_num)] at h
  refine h.trans ?_
  have hkR : (3 : ℝ) ≤ k := by exact_mod_cast hk
  have h8 : 8 / ((k : ℝ) - 1) ≤ 12 / (k : ℝ) := by
    rw [div_le_div_iff₀ (by linarith) (by linarith)]; linarith
  -- the second factor
  have hS : ∑ B' ∈ (T.filter (· < 2 * 2 ^ i)).powerset, (1 / (∏ p ∈ B', (p : ℝ))) ≤
      Real.exp 4 * (((i + 1 : ℕ) : ℝ) / k) ^ 4 := by
    refine (powerset_inv_mass _).trans ?_
    have hsub : T.filter (· < 2 * 2 ^ i) ⊆ (Ico (2 ^ k) (2 ^ (i + 1))).filter Nat.Prime := by
      intro p hp
      rw [mem_filter] at hp
      rw [mem_filter, mem_Ico, pow_succ, mul_comm]
      exact ⟨⟨hTk p hp.1, hp.2⟩, hT p hp.1⟩
    have h1 : ∑ p ∈ T.filter (· < 2 * 2 ^ i), (1 / (p : ℝ)) ≤
        ∑ p ∈ (Ico (2 ^ k) (2 ^ (i + 1))).filter Nat.Prime, (1 / (p : ℝ)) :=
      sum_le_sum_of_subset_of_nonneg hsub fun _ _ _ => by positivity
    have h2 := sum_inv_primes_dyadic_harmonic k (i + 1) (by omega) hki
    have h3 := sum_inv_Ico_le_log k (i + 1) (by omega) hki
    have hkpos : (0 : ℝ) < k := by linarith
    have hratio : (0 : ℝ) < ((i + 1 : ℕ) : ℝ) / k := by
      have : (0 : ℝ) < ((i + 1 : ℕ) : ℝ) := by positivity
      positivity
    calc Real.exp (∑ p ∈ T.filter (· < 2 * 2 ^ i), (1 / (p : ℝ)))
        ≤ Real.exp (4 * (1 + Real.log (((i + 1 : ℕ) : ℝ) / k))) := by
          apply Real.exp_le_exp.2; linarith
      _ = Real.exp 4 * (((i + 1 : ℕ) : ℝ) / k) ^ 4 := by
          rw [mul_add, mul_one, Real.exp_add]
          congr 1
          rw [show (4 : ℝ) * Real.log (((i + 1 : ℕ) : ℝ) / k) = ((4 : ℕ) : ℝ) * Real.log (((i + 1 : ℕ) : ℝ) / k) by
            norm_num, ← Real.log_pow, Real.exp_log (by positivity)]
  have hS0 : 0 ≤ ∑ B' ∈ (T.filter (· < 2 * 2 ^ i)).powerset, (1 / (∏ p ∈ B', (p : ℝ))) :=
    sum_nonneg fun B' _ => by
      have : 0 ≤ ∏ p ∈ B', (p : ℝ) := prod_nonneg fun _ _ => Nat.cast_nonneg _
      positivity
  calc 8 / ((k : ℝ) - 1) * _ ≤ 12 / (k : ℝ) * _ := mul_le_mul_of_nonneg_right h8 hS0
    _ ≤ _ := mul_le_mul_of_nonneg_left hS (by positivity)

lemma k_lower (i : ℕ) (u : ℝ) (hu0 : 0 < u) (hu1 : u ≤ 1) (k₀ : ℕ) (hk₀ : 3 ≤ k₀) :
    u * ((i : ℝ) + 1) / 3 ≤ (max ⌊(i : ℝ) * u⌋₊ k₀ : ℕ) := by
  have hfl : (i : ℝ) * u < ⌊(i : ℝ) * u⌋₊ + 1 := Nat.lt_floor_add_one _
  have hiu0 : 0 ≤ (i : ℝ) * u := by positivity
  have hmax1 : (⌊(i : ℝ) * u⌋₊ : ℝ) ≤ (max ⌊(i : ℝ) * u⌋₊ k₀ : ℕ) := by exact_mod_cast le_max_left _ _
  have hmax2 : (k₀ : ℝ) ≤ (max ⌊(i : ℝ) * u⌋₊ k₀ : ℕ) := by exact_mod_cast le_max_right _ _
  have hk₀R : (3 : ℝ) ≤ k₀ := by exact_mod_cast hk₀
  rcases le_or_gt 2 ⌊(i : ℝ) * u⌋₊ with h2 | h2
  · have h2R : (2 : ℝ) ≤ ⌊(i : ℝ) * u⌋₊ := by exact_mod_cast h2
    nlinarith
  · have : (i : ℝ) * u < 2 := by
      have : (⌊(i : ℝ) * u⌋₊ : ℝ) ≤ 1 := by exact_mod_cast (show ⌊(i : ℝ) * u⌋₊ ≤ 1 by omega)
      linarith
    nlinarith

/-- **Self-rough mass.** -/
theorem selfrough_mass (T : Finset ℕ) (hT : ∀ p ∈ T, p.Prime) (u : ℝ) (hu0 : 0 < u) (hu1 : u ≤ 1)
    (k₀ : ℕ) (hk₀ : 3 ≤ k₀) (hTk : ∀ p ∈ T, 2 ^ k₀ ≤ p) (N₁ I : ℕ) (hNI : N₁ < 2 ^ (I + 1))
    (κ : ℝ) (hκ0 : 0 ≤ κ) (hκ : ∀ B ⊆ T, ∏ p ∈ B, p ≤ N₁ → ωR B * ∏ p ∈ B, (p : ℝ) ≤ κ) :
    ∑ B ∈ T.powerset, (if B.Nonempty ∧ ∏ p ∈ B, p ≤ N₁ ∧ ∀ p ∈ B, ((∏ q ∈ B, q : ℕ) : ℝ) ^ u < p
        then ωR B else 0) ≤
      κ * Real.exp 4 * 2916 * (1 + Real.log ((I : ℝ) + 1)) / u ^ 5 := by
  classical
  have hT5 : ∀ p ∈ T, 5 ≤ p := fun p hp => by
    have := hTk p hp
    have : 2 ^ 3 ≤ 2 ^ k₀ := Nat.pow_le_pow_right (by norm_num) hk₀
    omega
  have hprodpos : ∀ B ⊆ T, 0 < ∏ p ∈ B, p := fun B hB => prod_pos fun p hp => (hT p (hB hp)).pos
  set cond : Finset ℕ → Prop := fun B => B.Nonempty ∧ ∏ p ∈ B, p ≤ N₁ ∧
    ∀ p ∈ B, ((∏ q ∈ B, q : ℕ) : ℝ) ^ u < p with hcond
  -- step 1: fibre by `i = log₂ ∏B`
  have e1 : ∑ B ∈ T.powerset, (if cond B then ωR B else 0) =
      ∑ i ∈ range (I + 1), ∑ B ∈ T.powerset,
        (if cond B ∧ Nat.log 2 (∏ p ∈ B, p) = i then ωR B else 0) := by
    rw [sum_comm]
    refine sum_congr rfl fun B hB => ?_
    by_cases hc : cond B
    · have hlt : Nat.log 2 (∏ p ∈ B, p) < I + 1 := by
        have h1 : ∏ p ∈ B, p < 2 ^ (I + 1) := lt_of_le_of_lt hc.2.1 hNI
        exact (Nat.log_lt_iff_lt_pow (by norm_num) (hprodpos B (mem_powerset.1 hB)).ne').2 h1
      rw [if_pos hc]
      simp only [hc, true_and]
      rw [sum_ite_eq]
      simp [hlt]
    · rw [if_neg hc]; symm; exact sum_eq_zero fun i _ => by rw [if_neg (fun h => hc h.1)]
  rw [e1]
  -- step 2: each fibre
  have hblock : ∀ i ∈ range (I + 1), ∑ B ∈ T.powerset,
      (if cond B ∧ Nat.log 2 (∏ p ∈ B, p) = i then ωR B else 0) ≤
      κ * Real.exp 4 * (3 / u) ^ 4 * (36 / (u * ((i : ℝ) + 1))) := by
    intro i _
    set ki := max ⌊(i : ℝ) * u⌋₊ k₀ with hki
    have hki3 : 3 ≤ ki := le_trans hk₀ (le_max_right _ _)
    have hkiR := k_lower i u hu0 hu1 k₀ hk₀
    rw [← hki] at hkiR
    set Ti := T.filter (fun p => 2 ^ ki ≤ p) with hTi
    -- terms are supported on `B ⊆ Ti` with `∏B ∈ [2^i, 2^{i+1})`
    have hpt : ∀ B ∈ T.powerset, (if cond B ∧ Nat.log 2 (∏ p ∈ B, p) = i then ωR B else 0) ≤
        (if B ⊆ Ti ∧ B.Nonempty ∧ (2 ^ i ≤ ∏ p ∈ B, p ∧ ∏ p ∈ B, p < 2 * 2 ^ i) then
          κ * (1 / (∏ p ∈ B, (p : ℝ))) else 0) := by
      intro B hB
      have hBT := mem_powerset.1 hB
      by_cases hc : cond B ∧ Nat.log 2 (∏ p ∈ B, p) = i
      · rw [if_pos hc]
        have hpos := hprodpos B hBT
        have hlow : 2 ^ i ≤ ∏ p ∈ B, p := by
          rw [← hc.2]; exact Nat.pow_log_le_self 2 hpos.ne'
        have hup : ∏ p ∈ B, p < 2 * 2 ^ i := by
          rw [← hc.2, ← pow_succ']; exact Nat.lt_pow_succ_log_self (by norm_num) _
        have hsub : B ⊆ Ti := by
          intro p hp
          rw [hTi, mem_filter]
          refine ⟨hBT hp, ?_⟩
          rcases le_total ⌊(i : ℝ) * u⌋₊ k₀ with hm | hm
          · rw [hki, max_eq_right hm]; exact hTk p (hBT hp)
          · rw [hki, max_eq_left hm]
            have h1 : ((∏ q ∈ B, q : ℕ) : ℝ) ^ u < p := hc.1.2.2 p hp
            have h2 : (2 : ℝ) ^ (i : ℝ) ≤ ((∏ q ∈ B, q : ℕ) : ℝ) := by
              rw [Real.rpow_natCast]; exact_mod_cast hlow
            have h3 : ((2 : ℝ) ^ (i : ℝ)) ^ u ≤ ((∏ q ∈ B, q : ℕ) : ℝ) ^ u :=
              Real.rpow_le_rpow (by positivity) h2 hu0.le
            have h4 : (2 : ℝ) ^ ((⌊(i : ℝ) * u⌋₊ : ℕ) : ℝ) ≤ ((2 : ℝ) ^ (i : ℝ)) ^ u := by
              rw [← Real.rpow_mul (by norm_num)]
              exact Real.rpow_le_rpow_of_exponent_le (by norm_num) (Nat.floor_le (by positivity))
            have h5 : ((2 ^ ⌊(i : ℝ) * u⌋₊ : ℕ) : ℝ) < p := by
              rw [Nat.cast_pow, ← Real.rpow_natCast]; push_cast; linarith
            exact_mod_cast h5.le
        rw [if_pos ⟨hsub, hc.1.1, hlow, hup⟩]
        have hprodR : (0 : ℝ) < ∏ p ∈ B, (p : ℝ) := by
          rw [← Nat.cast_prod]; exact_mod_cast hpos
        have := hκ B hBT hc.1.2.1
        rw [mul_one_div, le_div_iff₀ hprodR]; exact this
      · rw [if_neg hc]; split_ifs <;> [positivity; exact le_rfl]
    refine (sum_le_sum hpt).trans ?_
    -- move to the `Ti`-powerset and apply `block_rough`
    have hsupp : ∑ B ∈ T.powerset, (if B ⊆ Ti ∧ B.Nonempty ∧
        (2 ^ i ≤ ∏ p ∈ B, p ∧ ∏ p ∈ B, p < 2 * 2 ^ i) then κ * (1 / (∏ p ∈ B, (p : ℝ))) else 0) =
        κ * ∑ B ∈ (Ti.powerset.filter (fun B => B.Nonempty)).filter
          (fun B => 2 ^ i ≤ ∏ p ∈ B, p ∧ ∏ p ∈ B, p < 2 * 2 ^ i), (1 / (∏ p ∈ B, (p : ℝ))) := by
      rw [mul_sum, sum_filter, sum_filter]
      symm
      rw [← sum_subset (powerset_mono.2 (filter_subset _ T : Ti ⊆ T)) (fun B hB hBn => ?_)]
      · refine sum_congr rfl fun B hB => ?_
        have hBTi : B ⊆ Ti := mem_powerset.1 hB
        by_cases h1 : B.Nonempty <;> by_cases h2 : (2 ^ i ≤ ∏ p ∈ B, p ∧ ∏ p ∈ B, p < 2 * 2 ^ i)
        · rw [if_pos h1, if_pos h2, if_pos ⟨hBTi, h1, h2⟩]
        · rw [if_pos h1, if_neg h2, if_neg (fun h => h2 h.2.2)]
        · rw [if_neg h1, if_neg (fun h => h1 h.2.1)]
        · rw [if_neg h1, if_neg (fun h => h1 h.2.1)]
      · have : ¬ B ⊆ Ti := fun h => hBn (mem_powerset.2 h)
        simp [this]
    rw [hsupp]
    rcases le_or_gt ki (i + 1) with hle | hgt
    · have hb := block_rough Ti (fun p hp => hT p (filter_subset _ _ hp)) ki i hki3 hle
        (fun p hp => (mem_filter.1 hp).2)
      have hkiRpos : (0 : ℝ) < ki := by exact_mod_cast (show 0 < ki by omega)
      have hu3 : ((i + 1 : ℕ) : ℝ) / ki ≤ 3 / u := by
        rw [div_le_div_iff₀ hkiRpos hu0]; push_cast; nlinarith
      have h12 : 12 / (ki : ℝ) ≤ 36 / (u * ((i : ℝ) + 1)) := by
        rw [div_le_div_iff₀ hkiRpos (by positivity)]; nlinarith
      have hr0 : 0 ≤ ((i + 1 : ℕ) : ℝ) / ki := by positivity
      calc κ * _ ≤ κ * ((12 / (ki : ℝ)) * (Real.exp 4 * (((i + 1 : ℕ) : ℝ) / ki) ^ 4)) :=
            mul_le_mul_of_nonneg_left hb hκ0
        _ ≤ κ * ((36 / (u * ((i : ℝ) + 1))) * (Real.exp 4 * (3 / u) ^ 4)) := by
            apply mul_le_mul_of_nonneg_left _ hκ0
            apply mul_le_mul h12 _ (by positivity) (by positivity)
            exact mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hr0 hu3 4) (by positivity)
        _ = κ * Real.exp 4 * (3 / u) ^ 4 * (36 / (u * ((i : ℝ) + 1))) := by ring
    · -- the block is empty
      rw [sum_eq_zero fun B hB => ?_]
      · rw [mul_zero]; positivity
      · exfalso
        rw [mem_filter, mem_filter, mem_powerset] at hB
        obtain ⟨⟨hBTi, ⟨p, hp⟩⟩, _, hup⟩ := hB
        have h1 : p ≤ ∏ q ∈ B, q := Nat.le_of_dvd (prod_pos fun q hq =>
          (hT q (filter_subset _ _ (hBTi hq))).pos) (dvd_prod_of_mem _ hp)
        have h2 : 2 ^ ki ≤ p := (mem_filter.1 (hBTi hp)).2
        have h3 : 2 * 2 ^ i ≤ 2 ^ ki := by
          rw [← pow_succ']; exact Nat.pow_le_pow_right (by norm_num) (by omega)
        omega
  refine (sum_le_sum hblock).trans ?_
  have hharm : ∑ i ∈ range (I + 1), (1 / ((i : ℝ) + 1)) ≤ 1 + Real.log ((I : ℝ) + 1) := by
    have h := harmonic_le_one_add_log (I + 1)
    have e : ((harmonic (I + 1) : ℚ) : ℝ) = ∑ i ∈ range (I + 1), (1 / ((i : ℝ) + 1)) := by
      unfold harmonic; push_cast; simp [one_div]
    rw [← e]; push_cast at h ⊢; exact h
  calc ∑ i ∈ range (I + 1), κ * Real.exp 4 * (3 / u) ^ 4 * (36 / (u * ((i : ℝ) + 1)))
      = κ * Real.exp 4 * (3 / u) ^ 4 * (36 / u) * ∑ i ∈ range (I + 1), (1 / ((i : ℝ) + 1)) := by
        rw [mul_sum]; refine sum_congr rfl fun i _ => ?_; field_simp
    _ ≤ κ * Real.exp 4 * (3 / u) ^ 4 * (36 / u) * (1 + Real.log ((I : ℝ) + 1)) :=
        mul_le_mul_of_nonneg_left hharm (by positivity)
    _ = κ * Real.exp 4 * 2916 * (1 + Real.log ((I : ℝ) + 1)) / u ^ 5 := by
        field_simp; ring

/-! ## Splitting into the smooth and the rough part -/

lemma ωR_union (B₁ B₂ : Finset ℕ) (h : Disjoint B₁ B₂) : ωR (B₁ ∪ B₂) = ωR B₁ * ωR B₂ := by
  unfold ωR; rw [prod_union h]

lemma powerset_split_sum (T : Finset ℕ) (X : ℕ) (f : Finset ℕ → ℝ) :
    ∑ B ∈ T.powerset, f B =
      ∑ B₁ ∈ (T.filter (· < X)).powerset, ∑ B₂ ∈ (T.filter (X ≤ ·)).powerset, f (B₁ ∪ B₂) := by
  classical
  rw [← sum_product']
  refine sum_nbij' (fun B => (B.filter (· < X), B.filter (X ≤ ·))) (fun x => x.1 ∪ x.2) ?_ ?_ ?_ ?_ ?_
  · intro B hB
    simp only [mem_coe, mem_powerset] at hB
    simp only [mem_coe, mem_product, mem_powerset]
    exact ⟨filter_subset_filter _ hB, filter_subset_filter _ hB⟩
  · rintro ⟨B₁, B₂⟩ h
    simp only [mem_coe, mem_product, mem_powerset] at h
    simp only [mem_coe, mem_powerset]
    exact union_subset (h.1.trans (filter_subset _ _)) (h.2.trans (filter_subset _ _))
  · intro B _
    ext p; simp only [mem_union, mem_filter]
    constructor
    · rintro (⟨h, _⟩ | ⟨h, _⟩) <;> exact h
    · intro h; by_cases hx : p < X
      · exact Or.inl ⟨h, hx⟩
      · exact Or.inr ⟨h, by omega⟩
  · rintro ⟨B₁, B₂⟩ h
    simp only [mem_coe, mem_product, mem_powerset] at h
    have h1 : ∀ p ∈ B₁, p < X := fun p hp => (mem_filter.1 (h.1 hp)).2
    have h2 : ∀ p ∈ B₂, X ≤ p := fun p hp => (mem_filter.1 (h.2 hp)).2
    simp only [Prod.mk.injEq]
    constructor
    · ext p; simp only [mem_filter, mem_union]
      constructor
      · rintro ⟨h3 | h3, h4⟩
        · exact h3
        · exact absurd (h2 p h3) (by omega)
      · intro h3; exact ⟨Or.inl h3, h1 p h3⟩
    · ext p; simp only [mem_filter, mem_union]
      constructor
      · rintro ⟨h3 | h3, h4⟩
        · exact absurd (h1 p h3) (by omega)
        · exact h3
      · intro h3; exact ⟨Or.inr h3, h2 p h3⟩
  · intro B _
    simp only
    congr 1; ext p; simp only [mem_union, mem_filter]
    constructor
    · intro h; by_cases hx : p < X
      · exact Or.inl ⟨h, hx⟩
      · exact Or.inr ⟨h, by omega⟩
    · rintro (⟨h, _⟩ | ⟨h, _⟩) <;> exact h

/-- The mass of a condition splits into the smooth part times the rough condition. -/
theorem split_mass (T : Finset ℕ) (hT : ∀ p ∈ T, 5 ≤ p) (X : ℕ) (cond cond₂ : Finset ℕ → Prop)
    [DecidablePred cond] [DecidablePred cond₂]
    (h : ∀ B₁ ⊆ T.filter (· < X), ∀ B₂ ⊆ T.filter (X ≤ ·), cond (B₁ ∪ B₂) → cond₂ B₂) :
    ∑ B ∈ T.powerset, (if cond B then ωR B else 0) ≤
      (∑ B₁ ∈ (T.filter (· < X)).powerset, ωR B₁) *
        ∑ B₂ ∈ (T.filter (X ≤ ·)).powerset, (if cond₂ B₂ then ωR B₂ else 0) := by
  classical
  rw [powerset_split_sum T X, sum_mul_sum]
  refine sum_le_sum fun B₁ hB₁ => sum_le_sum fun B₂ hB₂ => ?_
  have hB₁T := mem_powerset.1 hB₁
  have hB₂T := mem_powerset.1 hB₂
  have hdisj : Disjoint B₁ B₂ := by
    rw [disjoint_left]; intro p h1 h2
    have := (mem_filter.1 (hB₁T h1)).2; have := (mem_filter.1 (hB₂T h2)).2; omega
  have hω1 := ωR_nonneg B₁ fun p hp => hT p (filter_subset _ _ (hB₁T hp))
  have hω2 := ωR_nonneg B₂ fun p hp => hT p (filter_subset _ _ (hB₂T hp))
  by_cases hc : cond (B₁ ∪ B₂)
  · rw [if_pos hc, if_pos (h B₁ hB₁T B₂ hB₂T hc), ωR_union B₁ B₂ hdisj]
  · rw [if_neg hc]; split_ifs <;> positivity

/-- The smooth mass, from the dyadic Mertens-type bound. -/
theorem smooth_mass (V : Finset ℕ) (hV : ∀ p ∈ V, p.Prime ∧ 5 ≤ p) (K : ℕ)
    (hVK : ∀ p ∈ V, p < 2 ^ (K + 1)) :
    ∑ B ∈ V.powerset, ωR B ≤ Real.exp 10 * ((K : ℝ) + 1) ^ 10 := by
  rw [sum_ωR_powerset]
  have h1 : ∏ p ∈ V, (1 + 1 / ((p : ℝ) - 3)) ≤ Real.exp (∑ p ∈ V, 1 / ((p : ℝ) - 3)) :=
    GoldC.QuillonCopyG.prod_one_add_le_exp_sum V _ fun p hp => by
      have : (5 : ℝ) ≤ p := by exact_mod_cast (hV p hp).2
      apply div_nonneg zero_le_one; linarith
  have h2 : ∑ p ∈ V, 1 / ((p : ℝ) - 3) ≤ 2.5 * ∑ p ∈ GoldC.QuillonCopyG.primesBelowPow (K + 1), (1 / (p : ℝ)) := by
    rw [mul_sum]
    calc ∑ p ∈ V, 1 / ((p : ℝ) - 3) ≤ ∑ p ∈ V, 2.5 * (1 / (p : ℝ)) := by
          refine sum_le_sum fun p hp => ?_
          have : (5 : ℝ) ≤ p := by exact_mod_cast (hV p hp).2
          rw [div_le_iff₀ (by linarith)]; field_simp; linarith
      _ ≤ _ := by
          refine sum_le_sum_of_subset_of_nonneg ?_ fun _ _ _ => by positivity
          intro p hp
          simp only [GoldC.QuillonCopyG.primesBelowPow, mem_filter, mem_range]
          exact ⟨hVK p hp, (hV p hp).1⟩
  have h3 := GoldC.QuillonCopyG.sum_inv_primes_below_two_pow K
  have h4 : ((harmonic K : ℚ) : ℝ) ≤ 1 + Real.log ((K : ℝ) + 1) := by
    have := harmonic_le_one_add_log K
    have hl : Real.log (K : ℝ) ≤ Real.log ((K : ℝ) + 1) := by
      rcases Nat.eq_zero_or_pos K with h0 | hpos
      · rw [h0]; simp
      · exact Real.log_le_log (by exact_mod_cast hpos) (by linarith)
    linarith
  calc ∏ p ∈ V, (1 + 1 / ((p : ℝ) - 3)) ≤ Real.exp (10 * (1 + Real.log ((K : ℝ) + 1))) := by
        refine h1.trans (Real.exp_le_exp.2 ?_)
        linarith
    _ = Real.exp 10 * ((K : ℝ) + 1) ^ 10 := by
        rw [mul_add, mul_one, Real.exp_add]
        congr 1
        rw [show (10 : ℝ) * Real.log ((K : ℝ) + 1) = ((10 : ℕ) : ℝ) * Real.log ((K : ℝ) + 1) by norm_num,
          ← Real.log_pow, Real.exp_log (by positivity)]

/-- `Σ_{n∈(a,b]} 1/n ≤ 1 + log(b/a)` for `1 ≤ a ≤ b`. -/
lemma harmonic_add_Ioc (a : ℕ) : ∀ d, ((harmonic (a + d) : ℚ) : ℝ) =
    ((harmonic a : ℚ) : ℝ) + ∑ n ∈ Ioc a (a + d), (1 / (n : ℝ))
  | 0 => by simp
  | d + 1 => by
    have hI : Ioc a (a + (d + 1)) = insert (a + d + 1) (Ioc a (a + d)) := by
      ext n; simp only [mem_Ioc, mem_insert]; omega
    have hnot : a + d + 1 ∉ Ioc a (a + d) := by simp
    rw [hI, sum_insert hnot, show a + (d + 1) = (a + d) + 1 by ring, harmonic_succ, Rat.cast_add,
      harmonic_add_Ioc a d]
    push_cast; ring

/-- `Σ_{n∈(a,b]} 1/n ≤ 1 + log(b/a)` for `1 ≤ a ≤ b`. -/
lemma sum_Ioc_inv_le (a b : ℕ) (ha : 1 ≤ a) (hab : a ≤ b) :
    ∑ n ∈ Ioc a b, (1 / (n : ℝ)) ≤ 1 + Real.log ((b : ℝ) / a) := by
  have hsplit := harmonic_add_Ioc a (b - a)
  rw [show a + (b - a) = b by omega] at hsplit
  have h1 := harmonic_le_one_add_log b
  have h2 := log_add_one_le_harmonic a
  have haR : (0 : ℝ) < a := by exact_mod_cast ha
  have hbR : (0 : ℝ) < b := by exact_mod_cast (show 0 < b by omega)
  have hl : Real.log (a : ℝ) ≤ Real.log ((a + 1 : ℕ) : ℝ) :=
    Real.log_le_log haR (by push_cast; linarith)
  rw [Real.log_div hbR.ne' haR.ne']
  linarith

/-- **Interval mass**: `Σ_{C, ∏C ∈ (a,b]} ω(C) ≤ Aω(b)·(1 + log(b/a))`. -/
theorem interval_mass (T : Finset ℕ) (hT : ∀ p ∈ T, p.Prime ∧ 5 ≤ p) (a b : ℕ) (ha : 1 ≤ a)
    (hab : a ≤ b) :
    ∑ C ∈ T.powerset, (if (∏ p ∈ C, p) ∈ Ioc a b then ωR C else 0) ≤
      Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30 * (1 + Real.log ((b : ℝ) / a)) := by
  classical
  set Aω : ℝ := Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30 with hAω
  have hTp : ∀ p ∈ T, p.Prime := fun p hp => (hT p hp).1
  have hpt : ∀ C ∈ T.powerset, (if (∏ p ∈ C, p) ∈ Ioc a b then ωR C else 0) ≤
      (if (∏ p ∈ C, p) ∈ Ioc a b then Aω * (1 / ((∏ p ∈ C, p : ℕ) : ℝ)) else 0) := by
    intro C hC
    split_ifs with h
    · have hCT := mem_powerset.1 hC
      have := GoldC.QuillonOmega.omega_pointwise C (fun p hp => hT p (hCT hp)) b (mem_Ioc.1 h).2
      unfold ωR; rw [Nat.cast_prod, mul_one_div]; exact this
    · exact le_rfl
  refine (sum_le_sum hpt).trans ?_
  rw [← sum_filter]
  have hinj := prod_injOn T hTp
  rw [show ∑ C ∈ T.powerset.filter (fun C => (∏ p ∈ C, p) ∈ Ioc a b),
      Aω * (1 / ((∏ p ∈ C, p : ℕ) : ℝ)) =
      ∑ n ∈ (T.powerset.filter (fun C => (∏ p ∈ C, p) ∈ Ioc a b)).image (fun C => ∏ p ∈ C, p),
        Aω * (1 / (n : ℝ)) by
    rw [sum_image (fun C₁ h₁ C₂ h₂ heq => hinj (mem_filter.1 h₁).1 (mem_filter.1 h₂).1 heq)]]
  rw [← mul_sum]
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  refine (sum_le_sum_of_subset_of_nonneg ?_ fun _ _ _ => by positivity).trans (sum_Ioc_inv_le a b ha hab)
  intro n hn
  obtain ⟨C, hC, rfl⟩ := mem_image.1 hn
  exact (mem_filter.1 hC).2

/-- **Total rough mass**: subsets `B ⊆ T` with `R₀ ≤ ∏B ≤ N₁` and no prime in `[X, (∏B)^u]`. -/
theorem rough_total (T : Finset ℕ) (hT : ∀ p ∈ T, p.Prime ∧ 5 ≤ p) (X : ℕ) (u : ℝ) (hu0 : 0 < u)
    (hu1 : u ≤ 1) (R₀ N₁ k₀ K I : ℕ) (hk₀ : 3 ≤ k₀) (hR₀ : (2 : ℝ) ^ k₀ ≤ (R₀ : ℝ) ^ u)
    (hXK : ∀ p ∈ T, p < X → p < 2 ^ (K + 1)) (hNI : N₁ < 2 ^ (I + 1)) :
    ∑ B ∈ T.powerset, (if R₀ ≤ ∏ p ∈ B, p ∧ ∏ p ∈ B, p ≤ N₁ ∧
        ∀ p ∈ B, p < X ∨ ((∏ q ∈ B, q : ℕ) : ℝ) ^ u < p then ωR B else 0) ≤
      Real.exp 10 * ((K : ℝ) + 1) ^ 10 *
        (1 + Real.exp (3 * (Nat.log 2 N₁ : ℝ) / ((2 : ℝ) ^ k₀ - 3)) * Real.exp 4 * 2916 *
          (1 + Real.log ((I : ℝ) + 1)) / u ^ 5) := by
  classical
  set κ := Real.exp (3 * (Nat.log 2 N₁ : ℝ) / ((2 : ℝ) ^ k₀ - 3)) with hκ
  have hT5 : ∀ p ∈ T, 5 ≤ p := fun p hp => (hT p hp).2
  set T₂' := (T.filter (X ≤ ·)).filter (fun p => 2 ^ k₀ ≤ p) with hT₂'
  set cond₂ : Finset ℕ → Prop := fun B₂ => B₂ = ∅ ∨ (B₂ ⊆ T₂' ∧ B₂.Nonempty ∧ ∏ p ∈ B₂, p ≤ N₁ ∧
      ∀ p ∈ B₂, ((∏ q ∈ B₂, q : ℕ) : ℝ) ^ u < p) with hcond₂
  have hsplit := split_mass T hT5 X (fun B => R₀ ≤ ∏ p ∈ B, p ∧ ∏ p ∈ B, p ≤ N₁ ∧
      ∀ p ∈ B, p < X ∨ ((∏ q ∈ B, q : ℕ) : ℝ) ^ u < p) cond₂ (by
    intro B₁ hB₁ B₂ hB₂ hc
    rcases B₂.eq_empty_or_nonempty with h0 | hne
    · exact Or.inl h0
    · right
      have hdisj : Disjoint B₁ B₂ := by
        rw [disjoint_left]; intro p h1 h2
        have := (mem_filter.1 (hB₁ h1)).2; have := (mem_filter.1 (hB₂ h2)).2; omega
      have hprod : ∏ p ∈ B₁ ∪ B₂, p = (∏ p ∈ B₁, p) * ∏ p ∈ B₂, p := prod_union hdisj
      have hB₁pos : 0 < ∏ p ∈ B₁, p := prod_pos fun p hp => (hT p (filter_subset _ _ (hB₁ hp))).1.pos
      have hle : ∏ p ∈ B₂, p ≤ ∏ p ∈ B₁ ∪ B₂, p := by
        rw [hprod]; exact Nat.le_mul_of_pos_left _ hB₁pos
      have hlarge : ∀ p ∈ B₂, ((∏ q ∈ B₁ ∪ B₂, q : ℕ) : ℝ) ^ u < p := by
        intro p hp
        rcases hc.2.2 p (mem_union_right _ hp) with h | h
        · have := (mem_filter.1 (hB₂ hp)).2; omega
        · exact h
      refine ⟨fun p hp => ?_, hne, hle.trans hc.2.1, fun p hp => ?_⟩
      · rw [hT₂', mem_filter]
        refine ⟨hB₂ hp, ?_⟩
        have h1 := hlarge p hp
        have h2 : (R₀ : ℝ) ^ u ≤ ((∏ q ∈ B₁ ∪ B₂, q : ℕ) : ℝ) ^ u :=
          Real.rpow_le_rpow (Nat.cast_nonneg _) (by exact_mod_cast hc.1) hu0.le
        have : ((2 ^ k₀ : ℕ) : ℝ) < p := by push_cast; linarith
        exact_mod_cast this.le
      · have h1 := hlarge p hp
        have h2 : ((∏ q ∈ B₂, q : ℕ) : ℝ) ^ u ≤ ((∏ q ∈ B₁ ∪ B₂, q : ℕ) : ℝ) ^ u :=
          Real.rpow_le_rpow (Nat.cast_nonneg _) (by exact_mod_cast hle) hu0.le
        linarith)
  refine hsplit.trans ?_
  have hsm := smooth_mass (T.filter (· < X)) (fun p hp => hT p (filter_subset _ _ hp)) K
    (fun p hp => hXK p (filter_subset _ _ hp) (mem_filter.1 hp).2)
  have hsm0 : 0 ≤ ∑ B₁ ∈ (T.filter (· < X)).powerset, ωR B₁ :=
    sum_nonneg fun B hB => ωR_nonneg B fun p hp => hT5 p (filter_subset _ _ ((mem_powerset.1 hB) hp))
  have hk8 : (8 : ℝ) ≤ (2 : ℝ) ^ k₀ := by
    have : (2 : ℝ) ^ 3 ≤ (2 : ℝ) ^ k₀ := pow_le_pow_right₀ (by norm_num) hk₀
    norm_num at this; linarith
  have hκ0 : 0 ≤ κ := (Real.exp_pos _).le
  -- the rough factor
  have hrough : ∑ B₂ ∈ (T.filter (X ≤ ·)).powerset, (if cond₂ B₂ then ωR B₂ else 0) ≤
      1 + κ * Real.exp 4 * 2916 * (1 + Real.log ((I : ℝ) + 1)) / u ^ 5 := by
    have hemp : ∅ ∈ (T.filter (X ≤ ·)).powerset := empty_mem_powerset _
    rw [← add_sum_erase _ _ hemp]
    have h0 : (if cond₂ ∅ then ωR ∅ else 0) = 1 := by
      rw [if_pos (Or.inl rfl)]; simp [ωR]
    rw [h0]
    refine add_le_add le_rfl ?_
    have hT₂'p : ∀ p ∈ T₂', p.Prime := fun p hp => (hT p (filter_subset _ _ (filter_subset _ _ hp))).1
    have hsr := selfrough_mass T₂' hT₂'p u hu0 hu1 k₀ hk₀ (fun p hp => (mem_filter.1 hp).2) N₁ I hNI κ hκ0
      (by
        intro B hB hBN
        have hz : 4 ≤ 2 ^ k₀ := le_trans (by norm_num) (Nat.pow_le_pow_right (by norm_num) hk₀)
        refine (omega_mul_prod_le B (2 ^ k₀) hz fun p hp => (mem_filter.1 (hB hp)).2).trans ?_
        apply Real.exp_le_exp.2
        have hcard : B.card ≤ Nat.log 2 N₁ := by
          rcases Nat.eq_zero_or_pos B.card with h | h
          · omega
          · apply Nat.le_log_of_pow_le (by norm_num)
            calc 2 ^ B.card = ∏ _p ∈ B, 2 := by rw [prod_const]
              _ ≤ ∏ p ∈ B, p := prod_le_prod' fun p hp => (hT₂'p p (hB hp)).two_le
              _ ≤ N₁ := hBN
        have hcR : (B.card : ℝ) ≤ Nat.log 2 N₁ := by exact_mod_cast hcard
        push_cast
        apply div_le_div_of_nonneg_right _ (by linarith)
        linarith)
    refine le_trans ?_ hsr
    -- terms on the erased powerset are supported on `T₂'`
    calc ∑ B₂ ∈ ((T.filter (X ≤ ·)).powerset).erase ∅, (if cond₂ B₂ then ωR B₂ else 0)
        ≤ ∑ B₂ ∈ (T.filter (X ≤ ·)).powerset, (if B₂ ⊆ T₂' ∧ (B₂.Nonempty ∧ ∏ p ∈ B₂, p ≤ N₁ ∧
            ∀ p ∈ B₂, ((∏ q ∈ B₂, q : ℕ) : ℝ) ^ u < p) then ωR B₂ else 0) := by
          refine (sum_le_sum fun B₂ hB₂ => ?_).trans (sum_le_sum_of_subset_of_nonneg (erase_subset _ _)
            fun B₂ hB₂ _ => ?_)
          · have hne : B₂ ≠ ∅ := ne_of_mem_erase hB₂
            by_cases hc : cond₂ B₂
            · rcases hc with h | h
              · exact absurd h hne
              · rw [if_pos (Or.inr h), if_pos h]
            · rw [if_neg hc]; split_ifs
              · exact ωR_nonneg B₂ fun p hp => hT5 p (filter_subset _ _
                  ((mem_powerset.1 (mem_of_mem_erase hB₂)) hp))
              · exact le_rfl
          · split_ifs
            · exact ωR_nonneg B₂ fun p hp => hT5 p (filter_subset _ _ ((mem_powerset.1 hB₂) hp))
            · exact le_rfl
      _ = ∑ B₂ ∈ T₂'.powerset, (if B₂.Nonempty ∧ ∏ p ∈ B₂, p ≤ N₁ ∧
            ∀ p ∈ B₂, ((∏ q ∈ B₂, q : ℕ) : ℝ) ^ u < p then ωR B₂ else 0) := by
          rw [← sum_filter, ← sum_filter]
          congr 1
          ext B₂
          simp only [mem_filter, mem_powerset]
          constructor
          · rintro ⟨_, h1, h2⟩; exact ⟨h1, h2⟩
          · rintro ⟨h1, h2⟩; exact ⟨h1.trans (filter_subset _ _), h1, h2⟩
  have hr0 : 0 ≤ ∑ B₂ ∈ (T.filter (X ≤ ·)).powerset, (if cond₂ B₂ then ωR B₂ else 0) :=
    sum_nonneg fun B₂ hB₂ => by
      split_ifs
      · exact ωR_nonneg B₂ fun p hp => hT5 p (filter_subset _ _ ((mem_powerset.1 hB₂) hp))
      · exact le_rfl
  exact mul_le_mul hsm hrough hr0 (by positivity)

end GoldC.QuillonResidue

#print axioms GoldC.QuillonResidue.omega_mul_prod_le
#print axioms GoldC.QuillonResidue.block_rough
#print axioms GoldC.QuillonResidue.selfrough_mass
#print axioms GoldC.QuillonResidue.split_mass
#print axioms GoldC.QuillonResidue.smooth_mass
#print axioms GoldC.QuillonResidue.interval_mass
#print axioms GoldC.QuillonResidue.rough_total
