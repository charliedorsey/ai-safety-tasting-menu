import GoldC.QuillonLWeil
import GoldC.QuillonWEst

/-!
# Quillon LONG L6: the Weil-strength W′ chain (piece → bilinear → context → cell → closed form)

Exact copies of `W_piece`, `WPsi`, `W_bilinear_full`, `W_context`, `WTerm`, `W_context_explicit`,
`W_cell`, `sqrt_WPsi_le`, `WTerm_le`, with the Kloosterman supplier replaced by the Weil majorant
of `QuillonLWeil.W_cell_coupled_W`:

    s^{3/4} → s^{1/2},   3^{|P|/4} → 4^{|P|/2} = τ(s),   G₀^{1/4} → G₀^{1/2},
    ∏(1+p^{−3/4}) → ∏(1+p^{−1/2}),   mode gcd exponent 1/8 → 1/4.

All gcd/zero-mode terms stay explicit and are summed by `gcd_mode_sum` (exponent `1/4`).
Every theorem takes the Weil input `(hW : WeilHyp)` explicitly.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonLWeilB

open GoldC.QuillonWRoute GoldC.QuillonWCoupled GoldC.QuillonWCell GoldC.QuillonVW GoldC.QuillonOmega
  GoldC.QuillonWBilinear GoldC.QuillonWContext GoldC.QuillonRamare GoldC.QuillonRowNF GoldC.QuillonCells
  GoldC.QuillonWCellApp GoldC.QuillonAsymp GoldC.QuillonWEst GoldC.QuillonLWeil

variable {s : ℕ} [NeZero s] {M : ℕ} [NeZero M]

theorem W_piece_W (hs2 : 2 ≤ s) (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p) (hW : WeilHyp)
    (c₀ : ZMod s) (𝒴 𝒩 : Finset ℕ) (X Y N I₀ I₁ : ℕ) (hX : 2 ≤ X) (hN : 1 ≤ N)
    (h𝒴 : ∀ y ∈ 𝒴, X ≤ y ∧ y ≤ Y) (h𝒩 : 𝒩 ⊆ Ioc N (2 * N))
    (hunit : ∀ y ∈ 𝒴, IsUnit (y : ZMod s)) (α β : ℕ → ℂ) (A : ℝ)
    (hA : 0 ≤ A) (hα : ∀ y ∈ 𝒴, ‖α y‖ ≤ A / y) (hβ : ∀ n ∈ 𝒩, ‖β n‖ ≤ A / n) :
    ‖∑ n ∈ 𝒩, β n * ∑ y ∈ 𝒴, α y *
        (if y * n ∈ Ioc I₀ I₁ then kphase c₀ (y * n) else 0)‖ ^ 2 ≤
      2 * A ^ 4 * (2 / X + 2 * (1 + Real.log Y) ^ 2 / s +
        2 * (1 + Real.log Y) ^ 2 * (∏ p ∈ P, (1 + (p : ℝ) ^ (-(1 : ℝ) / 2))) *
          ((4 : ℝ) ^ ((P.card : ℝ) / 2) *
            (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 2)) *
          ((s : ℝ) ^ ((1 : ℝ) / 2) / s + (s : ℝ) ^ ((1 : ℝ) / 2) * (1 + Real.log s) / N)) := by
  classical
  have hy1 : ∀ y ∈ 𝒴, 1 ≤ y := fun y hy => le_trans (by omega) (h𝒴 y hy).1
  have hrw : ∑ n ∈ 𝒩, β n * ∑ y ∈ 𝒴, α y *
        (if y * n ∈ Ioc I₀ I₁ then kphase c₀ (y * n) else 0) =
      ∑ n ∈ 𝒩, β n * ∑ y ∈ 𝒴, α y * gI c₀ (fun y => I₀ / y) (fun y => I₁ / y) y n := by
    refine sum_congr rfl fun n _ => ?_
    congr 1
    refine sum_congr rfl fun y hy => ?_
    rw [gI_eq_kphase c₀ I₀ I₁ y n (hy1 y hy)]
  rw [hrw]
  have h𝒴' : 𝒴 ⊆ Icc 1 Y := fun y hy => mem_Icc.2 ⟨hy1 y hy, (h𝒴 y hy).2⟩
  have hW := W_cell_coupled_W hs2 P hP hsP hW c₀ 𝒴 𝒩 Y N (2 * N) (by omega) h𝒩 h𝒴' hunit α β A hα
    (fun y => I₀ / y) (fun y => I₁ / y)
  refine hW.trans ?_
  set L := (1 + Real.log Y) ^ 2 with hL
  set Pf := ∏ p ∈ P, (1 + (p : ℝ) ^ (-(1 : ℝ) / 2)) with hPf
  set KF := (4 : ℝ) ^ ((P.card : ℝ) / 2) *
    (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 2) with hKF
  have hsR : (0 : ℝ) < s := by exact_mod_cast (show 0 < s by omega)
  have hNR : (0 : ℝ) < N := by exact_mod_cast hN
  have hXR : (0 : ℝ) < X := by exact_mod_cast (show 0 < X by omega)
  have hlogs : 0 ≤ Real.log s := Real.log_nonneg (by exact_mod_cast (show 1 ≤ s by omega))
  have hL0 : 0 ≤ L := by positivity
  have hPf0 : 0 ≤ Pf := prod_nonneg fun p _ => by positivity
  have hKF0 : 0 ≤ KF := by positivity
  have hMN : ((2 * N - N : ℕ) : ℝ) = N := by rw [show 2 * N - N = N by omega]
  rw [hMN]
  -- Σβ² ≤ 2A²/N
  have hSβ : ∑ n ∈ 𝒩, ‖β n‖ ^ 2 ≤ 2 * A ^ 2 / N := by
    calc ∑ n ∈ 𝒩, ‖β n‖ ^ 2 ≤ ∑ n ∈ 𝒩, A ^ 2 * (1 / ((n : ℝ) ^ 2)) := by
          refine sum_le_sum fun n hn => ?_
          have hnR : (0 : ℝ) < n := by
            have := (mem_Ioc.1 (h𝒩 hn)).1; exact_mod_cast (show 0 < n by omega)
          calc ‖β n‖ ^ 2 ≤ (A / n) ^ 2 := pow_le_pow_left₀ (norm_nonneg _) (hβ n hn) 2
            _ = _ := by field_simp
      _ = A ^ 2 * ∑ n ∈ 𝒩.filter (fun n => N + 1 ≤ n), (1 / ((n : ℝ) ^ 2)) := by
          rw [← mul_sum]; congr 1
          rw [filter_true_of_mem (p := fun n => N + 1 ≤ n) fun n hn => (mem_Ioc.1 (h𝒩 hn)).1]
      _ ≤ A ^ 2 * (2 / ((N + 1 : ℕ) : ℝ)) :=
          mul_le_mul_of_nonneg_left (sum_inv_sq_tail 𝒩 (N + 1) (by omega)) (sq_nonneg A)
      _ ≤ 2 * A ^ 2 / N := by
          rw [mul_div_assoc', mul_comm (A ^ 2) 2]
          apply div_le_div_of_nonneg_left (by positivity) hNR
          push_cast; linarith
  -- Σα² ≤ 2A²/X
  have hSα : ∑ y ∈ 𝒴, ‖α y‖ ^ 2 ≤ 2 * A ^ 2 / X := by
    calc ∑ y ∈ 𝒴, ‖α y‖ ^ 2 ≤ ∑ y ∈ 𝒴, A ^ 2 * (1 / ((y : ℝ) ^ 2)) := by
          refine sum_le_sum fun y hy => ?_
          have hyR : (0 : ℝ) < y := by exact_mod_cast hy1 y hy
          calc ‖α y‖ ^ 2 ≤ (A / y) ^ 2 := pow_le_pow_left₀ (norm_nonneg _) (hα y hy) 2
            _ = _ := by field_simp
      _ = A ^ 2 * ∑ y ∈ 𝒴.filter (fun y => X ≤ y), (1 / ((y : ℝ) ^ 2)) := by
          rw [← mul_sum]; congr 1
          rw [filter_true_of_mem fun y hy => (h𝒴 y hy).1]
      _ ≤ A ^ 2 * (2 / (X : ℝ)) :=
          mul_le_mul_of_nonneg_left (sum_inv_sq_tail 𝒴 X hX) (sq_nonneg A)
      _ = 2 * A ^ 2 / X := by ring
  have hsq34 : (s : ℝ) ^ ((1 : ℝ) / 2) * (((N : ℝ) / s + 1 + Real.log s)) / N =
      (s : ℝ) ^ ((1 : ℝ) / 2) / s + (s : ℝ) ^ ((1 : ℝ) / 2) * (1 + Real.log s) / N := by
    field_simp; ring
  have hinner : (N : ℝ) * ∑ y ∈ 𝒴, ‖α y‖ ^ 2 +
      A ^ 2 * ((N : ℝ) * (2 * (1 + Real.log Y) ^ 2 / s) +
        (4 : ℝ) ^ ((P.card : ℝ) / 2) * (s : ℝ) ^ ((1 : ℝ) / 2) *
          (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 2) *
          ((N : ℝ) / s + 1 + Real.log s) *
          (2 * (1 + Real.log Y) ^ 2 * ∏ p ∈ P, (1 + (p : ℝ) ^ (-(1 : ℝ) / 2)))) ≤
      N * A ^ 2 * (2 / X + 2 * L / s + 2 * L * Pf * KF *
        ((s : ℝ) ^ ((1 : ℝ) / 2) / s + (s : ℝ) ^ ((1 : ℝ) / 2) * (1 + Real.log s) / N)) := by
    rw [← hsq34]
    have e : (N : ℝ) * A ^ 2 * (2 / X + 2 * L / s + 2 * L * Pf * KF *
        ((s : ℝ) ^ ((1 : ℝ) / 2) * (((N : ℝ) / s + 1 + Real.log s)) / N)) =
        (N : ℝ) * (2 * A ^ 2 / X) + A ^ 2 * ((N : ℝ) * (2 * L / s) +
          KF * (s : ℝ) ^ ((1 : ℝ) / 2) * ((N : ℝ) / s + 1 + Real.log s) * (2 * L * Pf)) := by
      field_simp; ring
    rw [e, hKF, hL, hPf]
    have := mul_le_mul_of_nonneg_left hSα hNR.le
    have hrest : (4 : ℝ) ^ ((P.card : ℝ) / 2) * (s : ℝ) ^ ((1 : ℝ) / 2) *
          (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 2) =
        (4 : ℝ) ^ ((P.card : ℝ) / 2) *
          (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 2) *
          (s : ℝ) ^ ((1 : ℝ) / 2) := by ring
    rw [hrest]
    linarith
  have hin0 : 0 ≤ (N : ℝ) * ∑ y ∈ 𝒴, ‖α y‖ ^ 2 +
      A ^ 2 * ((N : ℝ) * (2 * (1 + Real.log Y) ^ 2 / s) +
        (4 : ℝ) ^ ((P.card : ℝ) / 2) * (s : ℝ) ^ ((1 : ℝ) / 2) *
          (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 2) *
          ((N : ℝ) / s + 1 + Real.log s) *
          (2 * (1 + Real.log Y) ^ 2 * ∏ p ∈ P, (1 + (p : ℝ) ^ (-(1 : ℝ) / 2)))) := by
    have : (0 : ℝ) ≤ ∑ y ∈ 𝒴, ‖α y‖ ^ 2 := sum_nonneg fun _ _ => by positivity
    positivity
  calc _ ≤ (2 * A ^ 2 / N) * (N * A ^ 2 * (2 / X + 2 * L / s + 2 * L * Pf * KF *
        ((s : ℝ) ^ ((1 : ℝ) / 2) / s + (s : ℝ) ^ ((1 : ℝ) / 2) * (1 + Real.log s) / N))) :=
        mul_le_mul hSβ hinner hin0 (by positivity)
    _ = _ := by rw [hL, hPf, hKF]; field_simp

/-- The W′ saving function `Ψ`. -/
noncomputable def WPsiW (P : Finset ℕ) (c₀ : ZMod s) (X Y N : ℕ) : ℝ :=
  2 / X + 2 * (1 + Real.log Y) ^ 2 / s +
    2 * (1 + Real.log Y) ^ 2 * (∏ p ∈ P, (1 + (p : ℝ) ^ (-(1 : ℝ) / 2))) *
      ((4 : ℝ) ^ ((P.card : ℝ) / 2) *
        (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 2)) *
      ((s : ℝ) ^ ((1 : ℝ) / 2) / s + (s : ℝ) ^ ((1 : ℝ) / 2) * (1 + Real.log s) / N)

lemma WPsiW_nonneg (P : Finset ℕ) (c₀ : ZMod s) (X Y N : ℕ) : 0 ≤ WPsiW P c₀ X Y N := by
  unfold WPsiW
  have : (0 : ℝ) ≤ Real.log s := by
    rcases Nat.eq_zero_or_pos s with h | h
    · simp [h]
    · exact Real.log_nonneg (by exact_mod_cast h)
  have : (0 : ℝ) ≤ ∏ p ∈ P, (1 + (p : ℝ) ^ (-(1 : ℝ) / 2)) := prod_nonneg fun _ _ => by positivity
  have : (0 : ℝ) ≤ (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) :=
    prod_nonneg fun _ _ => by positivity
  positivity

lemma WPsiW_anti (P : Finset ℕ) (c₀ : ZMod s) (X Y N N' : ℕ) (hN : 1 ≤ N) (hNN' : N ≤ N') :
    WPsiW P c₀ X Y N' ≤ WPsiW P c₀ X Y N := by
  unfold WPsiW
  have hlogs : (0 : ℝ) ≤ Real.log s := by
    rcases Nat.eq_zero_or_pos s with h | h
    · simp [h]
    · exact Real.log_nonneg (by exact_mod_cast h)
  have h1 : (0 : ℝ) ≤ 2 * (1 + Real.log Y) ^ 2 * (∏ p ∈ P, (1 + (p : ℝ) ^ (-(1 : ℝ) / 2))) *
      ((4 : ℝ) ^ ((P.card : ℝ) / 2) *
        (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 2)) := by
    have : (0 : ℝ) ≤ ∏ p ∈ P, (1 + (p : ℝ) ^ (-(1 : ℝ) / 2)) := prod_nonneg fun _ _ => by positivity
    have : (0 : ℝ) ≤ (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) :=
      prod_nonneg fun _ _ => by positivity
    positivity
  have hNR : (0 : ℝ) < N := by exact_mod_cast hN
  have hNN'R : (N : ℝ) ≤ N' := by exact_mod_cast hNN'
  have h2 : (s : ℝ) ^ ((1 : ℝ) / 2) * (1 + Real.log s) / N' ≤
      (s : ℝ) ^ ((1 : ℝ) / 2) * (1 + Real.log s) / N :=
    div_le_div_of_nonneg_left (by positivity) hNR hNN'R
  gcongr

theorem W_bilinear_full_W (hs2 : 2 ≤ s) (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime)
    (hsP : s = ∏ p ∈ P, p) (hW : WeilHyp) (𝒥 : Finset ℕ) (Acoef : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s)
    (𝒴 𝒩 : Finset ℕ) (X Y N₀ K I₀ I₁ : ℕ) (hX : 2 ≤ X) (hN₀ : 1 ≤ N₀)
    (h𝒴 : ∀ y ∈ 𝒴, X ≤ y ∧ y ≤ Y) (hus : ∀ y ∈ 𝒴, IsUnit (y : ZMod s))
    (huM : ∀ y ∈ 𝒴, IsUnit (y : ZMod M)) (h𝒩 : 𝒩 ⊆ Ioc N₀ (2 ^ K * N₀))
    (α β : ℕ → ℂ) (A : ℝ) (hA : 0 ≤ A) (hα : ∀ y ∈ 𝒴, ‖α y‖ ≤ A / y)
    (hβ : ∀ n ∈ 𝒩, ‖β n‖ ≤ A / n) :
    ‖∑ n ∈ 𝒩, β n * ∑ y ∈ 𝒴, α y *
        (if y * n ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (y * n) else 0)‖ ≤
      K * M * ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ *
        (A ^ 2 * Real.sqrt (2 * WPsiW P (c j) X Y N₀)) := by
  classical
  set t : ℕ → ℕ := fun k => 2 ^ k * N₀ with ht
  have htm : Monotone t := fun a b hab =>
    Nat.mul_le_mul_right _ (Nat.pow_le_pow_right (by norm_num) hab)
  have h𝒩' : 𝒩 ⊆ Ioc (t 0) (t K) := by simpa [ht] using h𝒩
  rw [sum_dyadic 𝒩 t htm K h𝒩' _]
  -- piece notation
  set Kp : ℕ → ℕ → ℕ → ℂ := fun j n y =>
    if y * n ∈ Ioc I₀ I₁ then kphase (c j) (y * n) else 0 with hKp
  set bρ : ZMod M → ZMod M → ℕ → ℂ := fun ρ ρ₁ n =>
    β n * (if (n : ZMod M) = ρ * ρ₁⁻¹ then (1 : ℂ) else 0) with hbρ
  set aρ : ZMod M → ℕ → ℂ := fun ρ₁ y => α y * (if (y : ZMod M) = ρ₁ then (1 : ℂ) else 0) with haρ
  have hpt : ∀ n y, y ∈ 𝒴 → β n * (α y *
      (if y * n ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (y * n) else 0)) =
      ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ∑ ρ₁ : ZMod M, Acoef ρ j * (bρ ρ ρ₁ n * (aρ ρ₁ y * Kp j n y)) := by
    intro n y hy
    have h1 : ∀ ρ j, ∑ ρ₁ : ZMod M, Acoef ρ j * (bρ ρ ρ₁ n * (aρ ρ₁ y * Kp j n y)) =
        Acoef ρ j * β n * α y * Kp j n y *
          (if ((y * n : ℕ) : ZMod M) = ρ then (1 : ℂ) else 0) := by
      intro ρ j
      rw [class_split_unit ρ y n (huM y hy), mul_sum]
      refine sum_congr rfl fun ρ₁ _ => ?_
      simp only [hbρ, haρ]; ring
    simp only [h1]
    simp only [hKp, rowW]
    by_cases hI : y * n ∈ Ioc I₀ I₁
    · simp only [if_pos hI]
      rw [mul_sum, mul_sum]
      refine sum_congr rfl fun ρ _ => ?_
      by_cases hρ : ((y * n : ℕ) : ZMod M) = ρ
      · rw [if_pos hρ, mul_sum, mul_sum]
        refine sum_congr rfl fun j _ => ?_
        rw [if_pos hρ]; ring
      · rw [if_neg hρ, mul_zero, mul_zero]
        symm; refine sum_eq_zero fun j _ => ?_
        rw [if_neg hρ, mul_zero]
    · simp only [if_neg hI, mul_zero]
      symm
      exact sum_eq_zero fun ρ _ => sum_eq_zero fun j _ => by ring
  -- per block
  have hblock : ∀ k ∈ range K,
      ‖∑ n ∈ 𝒩.filter (fun n => n ∈ Ioc (t k) (t (k + 1))), β n * ∑ y ∈ 𝒴, α y *
        (if y * n ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (y * n) else 0)‖ ≤
      M * ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ * (A ^ 2 * Real.sqrt (2 * WPsiW P (c j) X Y N₀)) := by
    intro k _
    set 𝒩k := 𝒩.filter (fun n => n ∈ Ioc (t k) (t (k + 1)))
    have hexp : ∑ n ∈ 𝒩k, β n * ∑ y ∈ 𝒴, α y *
        (if y * n ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (y * n) else 0) =
        ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ∑ ρ₁ : ZMod M, Acoef ρ j *
          ∑ n ∈ 𝒩k, bρ ρ ρ₁ n * ∑ y ∈ 𝒴, aρ ρ₁ y * Kp j n y := by
      have e1 : ∑ n ∈ 𝒩k, β n * ∑ y ∈ 𝒴, α y *
          (if y * n ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (y * n) else 0) =
          ∑ n ∈ 𝒩k, ∑ y ∈ 𝒴, ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ∑ ρ₁ : ZMod M,
            Acoef ρ j * (bρ ρ ρ₁ n * (aρ ρ₁ y * Kp j n y)) := by
        refine sum_congr rfl fun n _ => ?_
        rw [mul_sum]
        exact sum_congr rfl fun y hy => hpt n y hy
      rw [e1, sum5]
      refine sum_congr rfl fun ρ _ => sum_congr rfl fun j _ => sum_congr rfl fun ρ₁ _ => ?_
      rw [mul_sum]
      refine sum_congr rfl fun n _ => ?_
      rw [mul_sum, mul_sum]
    rw [hexp]
    have hNk : 1 ≤ 2 ^ k * N₀ := Nat.one_le_iff_ne_zero.2 (by positivity)
    have hpiece : ∀ ρ ρ₁ j, ‖∑ n ∈ 𝒩k, bρ ρ ρ₁ n * ∑ y ∈ 𝒴, aρ ρ₁ y * Kp j n y‖ ≤
        A ^ 2 * Real.sqrt (2 * WPsiW P (c j) X Y N₀) := by
      intro ρ ρ₁ j
      have hsub : 𝒩k ⊆ Ioc (2 ^ k * N₀) (2 * (2 ^ k * N₀)) := by
        intro n hn
        have := (mem_filter.1 hn).2
        simp only [ht, pow_succ] at this
        simpa [mul_comm, mul_assoc, mul_left_comm] using this
      have hW := W_piece_W hs2 P hP hsP hW (c j) 𝒴 𝒩k X Y (2 ^ k * N₀) I₀ I₁ hX hNk h𝒴 hsub hus
        (aρ ρ₁) (bρ ρ ρ₁) A hA
        (fun y hy => by
          simp only [haρ]; split_ifs
          · rw [mul_one]; exact hα y hy
          · rw [mul_zero, norm_zero]; have := hy; positivity)
        (fun n hn => by
          simp only [hbρ]; split_ifs
          · rw [mul_one]; exact hβ n ((mem_filter.1 hn).1)
          · rw [mul_zero, norm_zero]; positivity)
      have hle : 2 * A ^ 4 * WPsiW P (c j) X Y (2 ^ k * N₀) ≤ (A ^ 2 * Real.sqrt (2 * WPsiW P (c j) X Y N₀)) ^ 2 := by
        rw [mul_pow, Real.sq_sqrt (by have := WPsiW_nonneg P (c j) X Y N₀; positivity)]
        have := WPsiW_anti P (c j) X Y N₀ (2 ^ k * N₀) hN₀ (Nat.le_mul_of_pos_left _ (by positivity))
        nlinarith [pow_two_nonneg (A ^ 2), sq_nonneg A]
      have hW2 : ‖∑ n ∈ 𝒩k, bρ ρ ρ₁ n * ∑ y ∈ 𝒴, aρ ρ₁ y * Kp j n y‖ ^ 2 ≤
          2 * A ^ 4 * WPsiW P (c j) X Y (2 ^ k * N₀) := by
        unfold WPsiW; exact hW
      have hW' : ‖∑ n ∈ 𝒩k, bρ ρ ρ₁ n * ∑ y ∈ 𝒴, aρ ρ₁ y * Kp j n y‖ ^ 2 ≤
          (A ^ 2 * Real.sqrt (2 * WPsiW P (c j) X Y N₀)) ^ 2 := hW2.trans hle
      exact (pow_le_pow_iff_left₀ (norm_nonneg _) (by positivity) (by norm_num)).1 hW'
    calc _ ≤ ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ∑ ρ₁ : ZMod M, ‖Acoef ρ j‖ *
          (A ^ 2 * Real.sqrt (2 * WPsiW P (c j) X Y N₀)) := by
          refine (norm_sum_le _ _).trans (sum_le_sum fun ρ _ => ?_)
          refine (norm_sum_le _ _).trans (sum_le_sum fun j _ => ?_)
          refine (norm_sum_le _ _).trans (sum_le_sum fun ρ₁ _ => ?_)
          rw [norm_mul]
          exact mul_le_mul_of_nonneg_left (hpiece ρ ρ₁ j) (norm_nonneg _)
      _ = _ := by
          rw [mul_sum]
          refine sum_congr rfl fun ρ _ => ?_
          rw [mul_sum]
          refine sum_congr rfl fun j _ => ?_
          rw [sum_const, card_univ, ZMod.card, nsmul_eq_mul]
  calc _ ≤ ∑ k ∈ range K, ‖∑ n ∈ 𝒩.filter (fun n => n ∈ Ioc (t k) (t (k + 1))), β n *
        ∑ y ∈ 𝒴, α y * (if y * n ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (y * n) else 0)‖ :=
        norm_sum_le _ _
    _ ≤ ∑ _k ∈ range K, (M : ℝ) * ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ *
          (A ^ 2 * Real.sqrt (2 * WPsiW P (c j) X Y N₀)) := sum_le_sum hblock
    _ = _ := by rw [sum_const, card_range, nsmul_eq_mul]; ring

theorem W_context_W (hs2 : 2 ≤ s) (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p) (hW : WeilHyp)
    (𝒥 : Finset ℕ) (Acoef : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s)
    (U J : Finset ℕ) (hJU : J ⊆ U) (hU : ∀ p ∈ U, p.Prime ∧ 5 ≤ p)
    (hUs : ∀ p ∈ U, Nat.Coprime p s) (hUM : ∀ p ∈ U, Nat.Coprime p M)
    (X Y I₀ I₁ : ℕ) (hX : 2 ≤ X) (hY1 : 1 ≤ Y) (hJ : ∀ p ∈ J, X ≤ p ∧ p ≤ Y) (hYI : Y ≤ I₀)
    (Kset : Finset ℕ) :
    ‖∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty), (ωR B : ℂ) *
        (if (∏ p ∈ B, p) ∈ Ioc I₀ I₁ ∧ B.card ∈ Kset then rowW 𝒥 Acoef c (∏ p ∈ B, p) else 0)‖ ≤
      ((Nat.log 2 I₁ + 1 : ℕ) : ℝ) * M * ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ *
        ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 ^ (Nat.log 2 I₁ + 1) * (I₀ / Y))) : ℝ) ^ 30) ^ 2 *
          Real.sqrt (2 * WPsiW P (c j) X Y (I₀ / Y))) +
      (∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖) * (∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3))) * ((12.5 : ℝ) / X) := by
  classical
  set Kd := Nat.log 2 I₁ + 1 with hKd
  set N₀ := I₀ / Y with hN₀def
  set Aω : ℝ := Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 ^ Kd * N₀)) : ℝ) ^ 30 with hAω
  set Atot : ℝ := ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ with hAtot
  set WU : ℝ := ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) with hWU
  set Φ : ℕ → ℕ → ℂ := fun r k => if r ∈ Ioc I₀ I₁ ∧ k ∈ Kset then rowW 𝒥 Acoef c r else 0 with hΦ
  have hΦle : ∀ r k, ‖Φ r k‖ ≤ Atot := by
    intro r k; simp only [hΦ]; split_ifs
    · exact norm_rowW_le 𝒥 Acoef c r
    · rw [norm_zero]; exact sum_nonneg fun _ _ => sum_nonneg fun _ _ => norm_nonneg _
  have hN₀1 : 1 ≤ N₀ := (Nat.one_le_div_iff (by omega)).2 hYI
  have hAω0 : 0 ≤ Aω := by positivity
  set g : ℕ → Finset ℕ → ℂ := fun p B' =>
    ((1 / ((p : ℝ) - 3) : ℝ) : ℂ) * (((ωR B' / (1 + ((B' ∩ J).card : ℝ)) : ℝ) : ℂ) *
      Φ (p * ∏ q ∈ B', q) (B'.card + 1)) with hg
  -- step 1–3: Ramaré and the subtraction
  have hS : ∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty), (ωR B : ℂ) * Φ (∏ p ∈ B, p) B.card =
      ∑ p ∈ J, ∑ B' ∈ U.powerset, g p B' - ∑ p ∈ J, ∑ B' ∈ U.powerset.filter (fun B' => p ∈ B'), g p B' := by
    rw [ramare U J hJU, ← sum_sub_distrib]
    refine sum_congr rfl fun p hp => ?_
    rw [erase_powerset_eq, eq_sub_iff_add_eq, ← sum_filter_add_sum_filter_not U.powerset (fun B' => p ∈ B'),
      add_comm]
    congr 1
    refine sum_congr rfl fun B' hB' => ?_
    have hpB' : p ∉ B' := (mem_filter.1 hB').2
    simp only [hg]
    rw [ωR_insert p B' hpB', prod_insert hpB', card_insert_of_notMem hpB']
    push_cast
    ring
  have hrewrite : ∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty), (ωR B : ℂ) *
      (if (∏ p ∈ B, p) ∈ Ioc I₀ I₁ ∧ B.card ∈ Kset then rowW 𝒥 Acoef c (∏ p ∈ B, p) else 0) =
      ∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty), (ωR B : ℂ) * Φ (∏ p ∈ B, p) B.card := rfl
  rw [hrewrite, hS]
  refine (norm_sub_le _ _).trans (add_le_add ?_ ?_)
  · -- main bilinear term
    set α : ℕ → ℂ := fun p => ((1 / ((p : ℝ) - 3) : ℝ) : ℂ) with hα
    set β' : Finset ℕ → ℂ := fun B' => ((ωR B' / (1 + ((B' ∩ J).card : ℝ)) : ℝ) : ℂ) *
      (if B'.card + 1 ∈ Kset then (1 : ℂ) else 0) with hβ'
    set β : ℕ → ℂ := fun n => β' n.primeFactors with hβ
    set G : ℕ → ℂ := fun n => ∑ p ∈ J, α p *
      (if p * n ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (p * n) else 0) with hG
    have hUp : ∀ p ∈ U, p.Prime := fun p hp => (hU p hp).1
    have e1 : ∑ p ∈ J, ∑ B' ∈ U.powerset, g p B' = ∑ B' ∈ U.powerset, β' B' * G (∏ q ∈ B', q) := by
      rw [sum_comm]
      refine sum_congr rfl fun B' _ => ?_
      rw [hG, mul_sum]
      refine sum_congr rfl fun p _ => ?_
      simp only [hg, hΦ, hβ', hα]
      by_cases h1 : p * ∏ q ∈ B', q ∈ Ioc I₀ I₁ <;> by_cases h2 : B'.card + 1 ∈ Kset <;>
        simp [h1, h2] <;> ring
    have e2 : ∑ B' ∈ U.powerset, β' B' * G (∏ q ∈ B', q) =
        ∑ n ∈ U.powerset.image (fun B => ∏ q ∈ B, q), β n * G n := by
      rw [sum_image (prod_injOn U hUp)]
      refine sum_congr rfl fun B' hB' => ?_
      simp only [hβ]
      rw [Nat.primeFactors_prod fun q hq => hUp q (mem_powerset.1 hB' hq)]
    set 𝒩 := (U.powerset.image (fun B => ∏ q ∈ B, q)).filter (fun n => n ∈ Ioc N₀ (2 ^ Kd * N₀))
      with h𝒩def
    have hpow : I₁ < 2 ^ Kd := Nat.lt_pow_succ_log_self (by norm_num) I₁
    have e3 : ∑ n ∈ U.powerset.image (fun B => ∏ q ∈ B, q), β n * G n = ∑ n ∈ 𝒩, β n * G n := by
      rw [h𝒩def, sum_filter]
      refine sum_congr rfl fun n _ => ?_
      split_ifs with hn
      · rfl
      · have hG0 : G n = 0 := by
          simp only [hG]
          refine sum_eq_zero fun p hp => ?_
          have hpY := (hJ p hp).2
          have hp1 : 1 ≤ p := le_trans (by omega) (hJ p hp).1
          rw [if_neg, mul_zero]
          intro hI
          simp only [mem_Ioc] at hI hn
          push Not at hn
          rcases le_or_gt n N₀ with h | h
          · have : p * n ≤ Y * N₀ := Nat.mul_le_mul hpY h
            have : Y * N₀ ≤ I₀ := by rw [hN₀def]; exact Nat.mul_div_le I₀ Y
            omega
          · have h2 := hn h
            have : 2 ^ Kd ≤ 2 ^ Kd * N₀ := Nat.le_mul_of_pos_right _ (by omega)
            have : n ≤ p * n := Nat.le_mul_of_pos_left n (by omega)
            omega
        rw [hG0, mul_zero]
    rw [e1, e2, e3]
    have hW := W_bilinear_full_W hs2 P hP hsP hW 𝒥 Acoef c J 𝒩 X Y N₀ Kd I₀ I₁ hX hN₀1
      (fun p hp => hJ p hp)
      (fun p hp => (ZMod.isUnit_iff_coprime p s).2 (hUs p (hJU hp)))
      (fun p hp => (ZMod.isUnit_iff_coprime p M).2 (hUM p (hJU hp)))
      (fun n hn => (mem_filter.1 hn).2) α β Aω hAω0
      (fun p hp => by
        have h5 : (5 : ℝ) ≤ p := by exact_mod_cast (hU p (hJU hp)).2
        simp only [hα]
        rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (by apply div_nonneg zero_le_one; linarith)]
        rw [div_le_div_iff₀ (by linarith) (by linarith)]
        have hA1 : (2.5 : ℝ) ≤ Aω := by
          have : (2.5 : ℝ) ≤ Real.exp 37.5 := by
            have := Real.add_one_le_exp (37.5 : ℝ); linarith
          have : (1 : ℝ) ≤ (1 + Nat.log 2 (Nat.log 2 (2 ^ Kd * N₀)) : ℝ) ^ 30 :=
            one_le_pow₀ (by linarith [(Nat.cast_nonneg _ : (0 : ℝ) ≤ Nat.log 2 (Nat.log 2 (2 ^ Kd * N₀)))])
          nlinarith [Real.exp_pos 37.5]
        nlinarith)
      (fun n hn => by
        have hn' := mem_filter.1 hn
        obtain ⟨B', hB', rfl⟩ := mem_image.1 hn'.1
        have hB'U := mem_powerset.1 hB'
        simp only [hβ]
        rw [Nat.primeFactors_prod fun q hq => hUp q (hB'U hq)]
        simp only [hβ']
        have hω0 := ωR_nonneg B' fun q hq => (hU q (hB'U hq)).2
        have hωle := omega_pointwise B' (fun q hq => hU q (hB'U hq)) (2 ^ Kd * N₀) (mem_Ioc.1 hn'.2).2
        rw [norm_mul]
        calc ‖((ωR B' / (1 + ((B' ∩ J).card : ℝ)) : ℝ) : ℂ)‖ *
              ‖(if B'.card + 1 ∈ Kset then (1 : ℂ) else 0)‖
            ≤ ωR B' * 1 := by
              apply mul_le_mul _ (by split_ifs <;> simp) (norm_nonneg _) hω0
              rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (by positivity)]
              exact div_le_self hω0 (by linarith [(Nat.cast_nonneg _ : (0 : ℝ) ≤ (B' ∩ J).card)])
          _ ≤ Aω / ((∏ q ∈ B', q : ℕ) : ℝ) := by
              rw [mul_one, Nat.cast_prod]; exact hωle)
    exact hW
  · -- the subtracted terms
    have hsubB : ∀ p ∈ J, ∑ B' ∈ U.powerset.filter (fun B' => p ∈ B'), ωR B' ≤
        (1 / ((p : ℝ) - 3)) * WU := by
      intro p hp
      have hpU := hJU hp
      rw [powerset_filter_mem_eq_image U p hpU, sum_image]
      · calc ∑ B'' ∈ (U.erase p).powerset, ωR (insert p B'')
            = (1 / ((p : ℝ) - 3)) * ∑ B'' ∈ (U.erase p).powerset, ωR B'' := by
              rw [mul_sum]
              refine sum_congr rfl fun B'' hB'' => ?_
              have : p ∉ B'' := fun h => by have := mem_powerset.1 hB'' h; simp at this
              rw [ωR_insert p B'' this]
          _ ≤ (1 / ((p : ℝ) - 3)) * ∑ B ∈ U.powerset, ωR B := by
              have h5 : (5 : ℝ) ≤ p := by exact_mod_cast (hU p hpU).2
              apply mul_le_mul_of_nonneg_left _ (by apply div_nonneg zero_le_one; linarith)
              exact sum_le_sum_of_subset_of_nonneg (powerset_mono.2 (erase_subset _ _))
                fun B hB _ => ωR_nonneg B fun q hq => (hU q (mem_powerset.1 hB hq)).2
          _ = _ := by rw [sum_ωR_powerset]
      · intro B₁ h₁ B₂ h₂ heq
        have hp₁ : p ∉ B₁ := fun h => by have := (mem_powerset.1 h₁) h; simp at this
        have hp₂ : p ∉ B₂ := fun h => by have := (mem_powerset.1 h₂) h; simp at this
        have := congrArg (fun B => B.erase p) heq
        simpa [erase_insert hp₁, erase_insert hp₂] using this
    have hAt0 : 0 ≤ Atot := sum_nonneg fun _ _ => sum_nonneg fun _ _ => norm_nonneg _
    have hWU0 : 0 ≤ WU := prod_nonneg fun p hp => by
      have : (5 : ℝ) ≤ p := by exact_mod_cast (hU p hp).2
      have : 0 ≤ 1 / ((p : ℝ) - 3) := by apply div_nonneg zero_le_one; linarith
      linarith
    calc _ ≤ ∑ p ∈ J, ∑ B' ∈ U.powerset.filter (fun B' => p ∈ B'), ‖g p B'‖ :=
          (norm_sum_le _ _).trans (sum_le_sum fun p _ => norm_sum_le _ _)
      _ ≤ ∑ p ∈ J, ∑ B' ∈ U.powerset.filter (fun B' => p ∈ B'),
            (1 / ((p : ℝ) - 3)) * (ωR B' * Atot) := by
          refine sum_le_sum fun p hp => sum_le_sum fun B' hB' => ?_
          have hB'U := mem_powerset.1 (mem_filter.1 hB').1
          have h5 : (5 : ℝ) ≤ p := by exact_mod_cast (hU p (hJU hp)).2
          have hω0 := ωR_nonneg B' fun q hq => (hU q (hB'U hq)).2
          simp only [hg]
          rw [norm_mul, norm_mul, Complex.norm_real, Complex.norm_real, Real.norm_eq_abs,
            Real.norm_eq_abs, abs_of_nonneg (by apply div_nonneg zero_le_one; linarith),
            abs_of_nonneg (by positivity)]
          apply mul_le_mul_of_nonneg_left _ (by apply div_nonneg zero_le_one; linarith)
          apply mul_le_mul _ (hΦle _ _) (norm_nonneg _) hω0
          exact div_le_self hω0 (by linarith [(Nat.cast_nonneg _ : (0 : ℝ) ≤ (B' ∩ J).card)])
      _ = Atot * ∑ p ∈ J, (1 / ((p : ℝ) - 3)) *
            ∑ B' ∈ U.powerset.filter (fun B' => p ∈ B'), ωR B' := by
          rw [mul_sum]; refine sum_congr rfl fun p _ => ?_
          rw [mul_sum, mul_sum]; refine sum_congr rfl fun B' _ => by ring
      _ ≤ Atot * ∑ p ∈ J, (1 / ((p : ℝ) - 3)) * ((1 / ((p : ℝ) - 3)) * WU) := by
          apply mul_le_mul_of_nonneg_left _ hAt0
          refine sum_le_sum fun p hp => ?_
          have h5 : (5 : ℝ) ≤ p := by exact_mod_cast (hU p (hJU hp)).2
          exact mul_le_mul_of_nonneg_left (hsubB p hp) (by apply div_nonneg zero_le_one; linarith)
      _ = Atot * WU * ∑ p ∈ J, (1 / ((p : ℝ) - 3)) ^ 2 := by
          rw [mul_assoc, mul_sum, mul_sum, mul_sum]; refine sum_congr rfl fun p _ => by ring
      _ ≤ Atot * WU * ((12.5 : ℝ) / X) := by
          apply mul_le_mul_of_nonneg_left _ (mul_nonneg hAt0 hWU0)
          exact sum_inv_sub3_sq J X hX fun p hp => ⟨(hJ p hp).1, (hU p (hJU hp)).2⟩

/-- The W′ bound for one row type. -/
noncomputable def WTermW (P : Finset ℕ) (U : Finset ℕ) (𝒥 : Finset ℕ) (A : ZMod M → ℕ → ℂ)
    (c : ℕ → ZMod s) (X Y Nb Lw : ℕ) : ℝ :=
  ((Nat.log 2 (max Nb Lw) + 1 : ℕ) : ℝ) * M * ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖A ρ j‖ *
      ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 * (max Nb Lw) ^ 2)) : ℝ) ^ 30) ^ 2 *
        Real.sqrt (2 * WPsiW P (c j) X Y (Lw / Y))) +
    (∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖A ρ j‖) * (∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3))) * ((12.5 : ℝ) / X)

lemma WTermW_nonneg (P U 𝒥 : Finset ℕ) (A : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s) (X Y Nb Lw : ℕ)
    (hU : ∀ p ∈ U, 5 ≤ p) : 0 ≤ WTermW P U 𝒥 A c X Y Nb Lw := by
  unfold WTermW
  have h1 : 0 ≤ ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) := prod_nonneg fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast hU p hp
    have : 0 ≤ 1 / ((p : ℝ) - 3) := by apply div_nonneg zero_le_one; linarith
    linarith
  have h2 : 0 ≤ ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖A ρ j‖ * ((Real.exp 37.5 *
      (1 + Nat.log 2 (Nat.log 2 (2 * (max Nb Lw) ^ 2)) : ℝ) ^ 30) ^ 2 *
        Real.sqrt (2 * WPsiW P (c j) X Y (Lw / Y))) :=
    sum_nonneg fun _ _ => sum_nonneg fun _ _ => by positivity
  have h3 : 0 ≤ ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖A ρ j‖ := sum_nonneg fun _ _ => sum_nonneg fun _ _ => norm_nonneg _
  positivity

/-- `W_context_W` with explicit majorants for `(I₀, I₁)`. -/
lemma W_context_explicit_W (hs2 : 2 ≤ s) (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p) (hW : WeilHyp)
    (𝒥 : Finset ℕ) (Acoef : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s)
    (U J : Finset ℕ) (hJU : J ⊆ U) (hU : ∀ p ∈ U, p.Prime ∧ 5 ≤ p)
    (hUs : ∀ p ∈ U, Nat.Coprime p s) (hUM : ∀ p ∈ U, Nat.Coprime p M)
    (X Y I₀ I₁ Nb Lw : ℕ) (hX : 2 ≤ X) (hY1 : 1 ≤ Y) (hJ : ∀ p ∈ J, X ≤ p ∧ p ≤ Y)
    (hYL : Y ≤ Lw) (hLI : Lw ≤ I₀) (hI : I₀ < I₁) (hI₁ : I₁ ≤ max Nb Lw) (Kset : Finset ℕ) :
    ‖∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty), (ωR B : ℂ) *
        (if (∏ p ∈ B, p) ∈ Ioc I₀ I₁ ∧ B.card ∈ Kset then rowW 𝒥 Acoef c (∏ p ∈ B, p) else 0)‖ ≤
      WTermW P U 𝒥 Acoef c X Y Nb Lw := by
  refine (W_context_W hs2 P hP hsP hW 𝒥 Acoef c U J hJU hU hUs hUM X Y I₀ I₁ hX hY1 hJ
    (hYL.trans hLI) Kset).trans ?_
  unfold WTermW
  have hlog : Nat.log 2 I₁ ≤ Nat.log 2 (max Nb Lw) := Nat.log_mono_right hI₁
  have hN₀ : I₀ / Y ≤ I₁ := (Nat.div_le_self _ _).trans hI.le
  have harg : 2 ^ (Nat.log 2 I₁ + 1) * (I₀ / Y) ≤ 2 * (max Nb Lw) ^ 2 := by
    have h1 : 2 ^ (Nat.log 2 I₁ + 1) ≤ 2 * I₁ := by
      rw [pow_succ, mul_comm]
      exact Nat.mul_le_mul_left 2 (Nat.pow_log_le_self 2 (by omega))
    calc 2 ^ (Nat.log 2 I₁ + 1) * (I₀ / Y) ≤ 2 * I₁ * I₁ := Nat.mul_le_mul h1 hN₀
      _ ≤ 2 * (max Nb Lw) * (max Nb Lw) := Nat.mul_le_mul (Nat.mul_le_mul_left 2 hI₁) hI₁
      _ = 2 * (max Nb Lw) ^ 2 := by ring
  have hAω : (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 ^ (Nat.log 2 I₁ + 1) * (I₀ / Y))) : ℝ) ^ 30) ^ 2
      ≤ (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 * (max Nb Lw) ^ 2)) : ℝ) ^ 30) ^ 2 := by
    have hm : Nat.log 2 (Nat.log 2 (2 ^ (Nat.log 2 I₁ + 1) * (I₀ / Y))) ≤
        Nat.log 2 (Nat.log 2 (2 * (max Nb Lw) ^ 2)) :=
      Nat.log_mono_right (Nat.log_mono_right harg)
    have hm' : (Nat.log 2 (Nat.log 2 (2 ^ (Nat.log 2 I₁ + 1) * (I₀ / Y))) : ℝ) ≤
        Nat.log 2 (Nat.log 2 (2 * (max Nb Lw) ^ 2)) := by exact_mod_cast hm
    gcongr
  have hNlow : 1 ≤ Lw / Y := (Nat.one_le_div_iff (by omega)).2 hYL
  have hdiv : Lw / Y ≤ I₀ / Y := Nat.div_le_div_right hLI
  have hW : ∀ j, WPsiW P (c j) X Y (I₀ / Y) ≤ WPsiW P (c j) X Y (Lw / Y) :=
    fun j => WPsiW_anti P (c j) X Y (Lw / Y) (I₀ / Y) hNlow hdiv
  have hWnn : ∀ j, 0 ≤ WPsiW P (c j) X Y (I₀ / Y) := fun j => WPsiW_nonneg _ _ _ _ _
  refine add_le_add ?_ le_rfl
  have hlogR : ((Nat.log 2 I₁ + 1 : ℕ) : ℝ) ≤ ((Nat.log 2 (max Nb Lw) + 1 : ℕ) : ℝ) := by
    exact_mod_cast Nat.add_le_add_right hlog 1
  have hS : ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ *
      ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 ^ (Nat.log 2 I₁ + 1) * (I₀ / Y))) : ℝ) ^ 30) ^ 2 *
        Real.sqrt (2 * WPsiW P (c j) X Y (I₀ / Y))) ≤
      ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ *
      ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 * (max Nb Lw) ^ 2)) : ℝ) ^ 30) ^ 2 *
        Real.sqrt (2 * WPsiW P (c j) X Y (Lw / Y))) := by
    refine sum_le_sum fun ρ _ => sum_le_sum fun j _ => ?_
    apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
    apply mul_le_mul hAω _ (Real.sqrt_nonneg _) (by positivity)
    exact Real.sqrt_le_sqrt (by linarith [hW j])
  have hS0 : 0 ≤ ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ *
      ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 ^ (Nat.log 2 I₁ + 1) * (I₀ / Y))) : ℝ) ^ 30) ^ 2 *
        Real.sqrt (2 * WPsiW P (c j) X Y (I₀ / Y))) :=
    sum_nonneg fun _ _ => sum_nonneg fun _ _ => by positivity
  have hM0 : (0 : ℝ) ≤ M := Nat.cast_nonneg _
  calc ((Nat.log 2 I₁ + 1 : ℕ) : ℝ) * M * _ ≤ ((Nat.log 2 (max Nb Lw) + 1 : ℕ) : ℝ) * M * _ :=
        mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hlogR hM0) hS0
    _ ≤ _ := mul_le_mul_of_nonneg_left hS (by positivity)

/-- **The W′ cell for a fixed `s`.** -/
theorem W_cell_W (hW : WeilHyp) (hM : 2 ≤ M) (H : ℕ) (μ : ℝ) (Γ : ℕ → ℕ → ℝ) (T C : Finset ℕ)
    (hT : ∀ p ∈ T, p.Prime ∧ 5 ≤ p ∧ p.Coprime M ∧ p.Coprime H) (hCT : C ⊆ T)
    (hsC : s = ∏ p ∈ C, p) (hs2 : 2 ≤ s)
    (J : Finset ℕ) (hJU : J ⊆ T \ C) (X Y : ℕ) (hX : 2 ≤ X) (hY1 : 1 ≤ Y)
    (hJ : ∀ p ∈ J, X ≤ p ∧ p ≤ Y)
    (Kc : ℕ → Prop) [DecidablePred Kc] (Geo : ℕ → Prop) [DecidablePred Geo] (Nb Lw : ℕ)
    (hbdd : ∀ r, Geo r → r ≤ Nb) (hlow : ∀ r, Geo r → Lw < r) (hYL : Y ≤ Lw)
    (hconv : ∀ a b c, a ≤ b → b ≤ c → Geo a → Geo c → Geo b)
    (F : ℕ → ℝ) (hF : ∀ B ⊆ T \ C, B ≠ ∅ → Geo (∏ p ∈ B, p) → F (∏ p ∈ B, p) = rowAbs M H μ Γ (∏ p ∈ B, p) s)
    (Jm : ℕ) (hJm : M * s ≤ 2 * Jm) :
    |∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
        (if (Kc B.card ∧ Geo (∏ p ∈ B, p)) ∧ (B ∩ J).Nonempty then ωR B * F (∏ p ∈ B, p) else 0)| ≤
      WTermW C (T \ C) (Icc 1 Jm) (fun (_ : ZMod M) k => ((-(2 * μ) : ℝ) : ℂ) * αm k s)
          (fun k => ((((k : ℤ) * H : ℤ)) : ZMod s)) X Y Nb Lw +
        WTermW C (T \ C) (Icc 1 Jm) (fun (_ : ZMod M) k => -(((-(2 * μ) : ℝ) : ℂ) * αm k s))
          (fun k => ((((-(k : ℤ)) * H : ℤ)) : ZMod s)) X Y Nb Lw +
        WTermW C (T \ C) (Icc 1 Jm) (fun (ρ : ZMod M) k => αm k (M * s) * BclS M Γ s (k : ℤ) ρ)
          (fun k => ((((k : ℤ) * H * GoldC.QuillonCopyC.invMod M s : ℤ)) : ZMod s)) X Y Nb Lw +
        WTermW C (T \ C) (Icc 1 Jm) (fun (ρ : ZMod M) k => -(αm k (M * s) * BclS M Γ s (-(k : ℤ)) ρ))
          (fun k => ((((-(k : ℤ)) * H * GoldC.QuillonCopyC.invMod M s : ℤ)) : ZMod s)) X Y Nb Lw := by
  classical
  set U := T \ C with hUdef
  have hU5 : ∀ p ∈ U, 5 ≤ p := fun p hp => (hT p (sdiff_subset hp)).2.1
  have hRHS0 : 0 ≤ WTermW C U (Icc 1 Jm) (fun (_ : ZMod M) k => ((-(2 * μ) : ℝ) : ℂ) * αm k s)
          (fun k => ((((k : ℤ) * H : ℤ)) : ZMod s)) X Y Nb Lw +
        WTermW C U (Icc 1 Jm) (fun (_ : ZMod M) k => -(((-(2 * μ) : ℝ) : ℂ) * αm k s))
          (fun k => ((((-(k : ℤ)) * H : ℤ)) : ZMod s)) X Y Nb Lw +
        WTermW C U (Icc 1 Jm) (fun (ρ : ZMod M) k => αm k (M * s) * BclS M Γ s (k : ℤ) ρ)
          (fun k => ((((k : ℤ) * H * GoldC.QuillonCopyC.invMod M s : ℤ)) : ZMod s)) X Y Nb Lw +
        WTermW C U (Icc 1 Jm) (fun (ρ : ZMod M) k => -(αm k (M * s) * BclS M Γ s (-(k : ℤ)) ρ))
          (fun k => ((((-(k : ℤ)) * H * GoldC.QuillonCopyC.invMod M s : ℤ)) : ZMod s)) X Y Nb Lw := by
    have := WTermW_nonneg (s := s) (M := M) C U (Icc 1 Jm); 
    linarith [WTermW_nonneg (s := s) (M := M) C U (Icc 1 Jm)
        (fun (_ : ZMod M) k => ((-(2 * μ) : ℝ) : ℂ) * αm k s)
          (fun k => ((((k : ℤ) * H : ℤ)) : ZMod s)) X Y Nb Lw hU5,
      WTermW_nonneg (s := s) (M := M) C U (Icc 1 Jm)
        (fun (_ : ZMod M) k => -(((-(2 * μ) : ℝ) : ℂ) * αm k s))
          (fun k => ((((-(k : ℤ)) * H : ℤ)) : ZMod s)) X Y Nb Lw hU5,
      WTermW_nonneg (s := s) (M := M) C U (Icc 1 Jm)
        (fun (ρ : ZMod M) k => αm k (M * s) * BclS M Γ s (k : ℤ) ρ)
          (fun k => ((((k : ℤ) * H * GoldC.QuillonCopyC.invMod M s : ℤ)) : ZMod s)) X Y Nb Lw hU5,
      WTermW_nonneg (s := s) (M := M) C U (Icc 1 Jm)
        (fun (ρ : ZMod M) k => -(αm k (M * s) * BclS M Γ s (-(k : ℤ)) ρ))
          (fun k => ((((-(k : ℤ)) * H * GoldC.QuillonCopyC.invMod M s : ℤ)) : ZMod s)) X Y Nb Lw hU5]
  obtain ⟨I₀, I₁, hLI, hI₁, hGeo⟩ := exists_Ioc_of_convex Geo Nb Lw hbdd hlow hconv
  rw [cell_sum_Ioc U J Kc Geo I₀ I₁ hGeo (fun B => ωR B * F (∏ p ∈ B, p))]
  rcases le_or_gt I₁ I₀ with hI | hI
  · rw [sum_eq_zero fun B _ => by
      rw [if_neg]; rintro ⟨h1, _⟩; have := mem_Ioc.1 h1; omega]
    rw [abs_zero]; exact hRHS0
  -- coprimality facts
  have hTp : ∀ p ∈ T, p.Prime := fun p hp => (hT p hp).1
  have hsM : s.Coprime M := by
    rw [hsC]; exact Nat.Coprime.prod_left fun q hq => (hT q (hCT hq)).2.2.1
  have hHs : H.Coprime s := by
    rw [hsC]; exact Nat.Coprime.prod_right fun q hq => ((hT q (hCT hq)).2.2.2).symm
  have hUs : ∀ p ∈ U, Nat.Coprime p s := by
    intro p hp
    have hpT := sdiff_subset hp
    have hpC : p ∉ C := (mem_sdiff.1 hp).2
    have := coprime_prod_primes {p} C (by simpa using (hT p hpT).1)
      (fun q hq => hTp q (hCT hq)) (by simpa using hpC)
    simpa [hsC] using this
  have hUM : ∀ p ∈ U, Nat.Coprime p M := fun p hp => (hT p (sdiff_subset hp)).2.2.1
  have hUP : ∀ p ∈ U, p.Prime ∧ 5 ≤ p := fun p hp => ⟨(hT p (sdiff_subset hp)).1, hU5 p hp⟩
  have hCp : ∀ p ∈ C, p.Prime := fun p hp => hTp p (hCT hp)
  -- pass to ℂ and expand the row
  set Rτ : (ZMod M → ℕ → ℂ) → (ℕ → ZMod s) → ℂ := fun A c =>
    ∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty), (ωR B : ℂ) *
      (if (∏ p ∈ B, p) ∈ Ioc I₀ I₁ ∧ B.card ∈ (range (U.card + 1)).filter Kc then
        rowW (Icc 1 Jm) A c (∏ p ∈ B, p) else 0) with hRτ
  have hexp : ((∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty),
      (if (∏ p ∈ B, p) ∈ Ioc I₀ I₁ ∧ B.card ∈ (range (U.card + 1)).filter Kc then
        ωR B * F (∏ p ∈ B, p) else 0) : ℝ) : ℂ) =
      Rτ (fun (_ : ZMod M) k => ((-(2 * μ) : ℝ) : ℂ) * αm k s)
          (fun k => ((((k : ℤ) * H : ℤ)) : ZMod s)) +
        Rτ (fun (_ : ZMod M) k => -(((-(2 * μ) : ℝ) : ℂ) * αm k s))
          (fun k => ((((-(k : ℤ)) * H : ℤ)) : ZMod s)) +
        Rτ (fun (ρ : ZMod M) k => αm k (M * s) * BclS M Γ s (k : ℤ) ρ)
          (fun k => ((((k : ℤ) * H * GoldC.QuillonCopyC.invMod M s : ℤ)) : ZMod s)) +
        Rτ (fun (ρ : ZMod M) k => -(αm k (M * s) * BclS M Γ s (-(k : ℤ)) ρ))
          (fun k => ((((-(k : ℤ)) * H * GoldC.QuillonCopyC.invMod M s : ℤ)) : ZMod s)) := by
    simp only [hRτ, ← sum_add_distrib]
    rw [Complex.ofReal_sum]
    refine sum_congr rfl fun B hB => ?_
    have hBU := mem_powerset.1 (mem_filter.1 hB).1
    have hBne : B ≠ ∅ := by
      rintro rfl; have := (mem_filter.1 hB).2; simp at this
    by_cases hmB : (∏ p ∈ B, p) ∈ Ioc I₀ I₁ ∧ B.card ∈ (range (U.card + 1)).filter Kc
    · simp only [if_pos hmB]
      have hgeo : Geo (∏ p ∈ B, p) := (hGeo _).2 hmB.1
      have hrs : (∏ p ∈ B, p).Coprime s := by
        rw [hsC]; exact coprime_prod_primes B C (fun p hp => hTp p (sdiff_subset (hBU hp))) hCp
          (by rw [disjoint_left]; intro p hp hpC; exact (mem_sdiff.1 (hBU hp)).2 hpC)
      rw [Complex.ofReal_mul, hF B hBU hBne hgeo, rowAbs_eq_rowW hM hs2 H μ Γ _ hrs hsM hHs Jm hJm]
      ring
    · simp only [if_neg hmB, Complex.ofReal_zero]; ring
  rw [← Real.norm_eq_abs, ← Complex.norm_real, hexp]
  refine (norm_add_le _ _).trans (add_le_add ((norm_add_le _ _).trans (add_le_add
    ((norm_add_le _ _).trans (add_le_add ?_ ?_)) ?_)) ?_) <;>
  exact W_context_explicit_W hs2 C hCp hsC hW (Icc 1 Jm) _ _ U J hJU hUP hUs hUM X Y I₀ I₁ Nb Lw hX hY1 hJ
    hYL hLI hI hI₁ _

/-- The W′ saving factor for one mode, with the gcd made explicit. -/
lemma sqrt_WPsiW_le (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (c₀ : ZMod s) (X Y N : ℕ) (hX : 1 ≤ X) (hN : 1 ≤ N)
    (G : ℕ) (hG : P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0) = P.filter (fun p => p ∣ G)) :
    Real.sqrt (2 * WPsiW P c₀ X Y N) ≤
      2 / Real.sqrt X + 2 * (1 + Real.log Y) / Real.sqrt s +
        2 * (1 + Real.log Y) * Real.sqrt (∏ p ∈ P, (1 + (p : ℝ) ^ (-(1 : ℝ) / 2))) *
          (4 : ℝ) ^ ((P.card : ℝ) / 4) *
          (((∏ p ∈ P.filter (fun p => p ∣ G), p : ℕ) : ℝ) ^ ((1 : ℝ) / 4)) *
          Real.sqrt ((s : ℝ) ^ ((1 : ℝ) / 2) / s + (s : ℝ) ^ ((1 : ℝ) / 2) * (1 + Real.log s) / N) := by
  unfold WPsiW
  rw [hG]
  have hXR : (0 : ℝ) < X := by exact_mod_cast hX
  have hsR : (0 : ℝ) < s := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne s)
  have hlY : 0 ≤ 1 + Real.log Y := by
    have := Real.log_natCast_nonneg Y; linarith
  have hls : 0 ≤ 1 + Real.log s := by
    have := Real.log_natCast_nonneg s; linarith
  set Pi34 := ∏ p ∈ P, (1 + (p : ℝ) ^ (-(1 : ℝ) / 2)) with hPi
  have hPi0 : 0 ≤ Pi34 := prod_nonneg fun _ _ => by positivity
  set Gp := ∏ p ∈ P.filter (fun p => p ∣ G), (p : ℝ) with hGp
  have hGp0 : 0 ≤ Gp := prod_nonneg fun _ _ => Nat.cast_nonneg _
  have hGpN : Gp = ((∏ p ∈ P.filter (fun p => p ∣ G), p : ℕ) : ℝ) := by rw [Nat.cast_prod]
  set Q := (s : ℝ) ^ ((1 : ℝ) / 2) / s + (s : ℝ) ^ ((1 : ℝ) / 2) * (1 + Real.log s) / N with hQ
  have hQ0 : 0 ≤ Q := by positivity
  have h3 : (0 : ℝ) ≤ (4 : ℝ) ^ ((P.card : ℝ) / 2) := by positivity
  have hG4 : (0 : ℝ) ≤ Gp ^ ((1 : ℝ) / 2) := by positivity
  rw [show 2 * (2 / (X : ℝ) + 2 * (1 + Real.log Y) ^ 2 / s +
      2 * (1 + Real.log Y) ^ 2 * Pi34 * ((4 : ℝ) ^ ((P.card : ℝ) / 2) * Gp ^ ((1 : ℝ) / 2)) * Q) =
      4 / (X : ℝ) + 4 * (1 + Real.log Y) ^ 2 / s +
      4 * (1 + Real.log Y) ^ 2 * Pi34 * ((4 : ℝ) ^ ((P.card : ℝ) / 2) * Gp ^ ((1 : ℝ) / 2)) * Q by ring]
  refine (sqrt_add3_le _ _ _ (by positivity) (by positivity) (by positivity)).trans ?_
  apply add_le_add (add_le_add ?_ ?_) ?_
  · rw [Real.sqrt_div' _ hXR.le, show (4 : ℝ) = 2 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
  · rw [Real.sqrt_div' _ hsR.le, show 4 * (1 + Real.log Y) ^ 2 = (2 * (1 + Real.log Y)) ^ 2 by ring,
      Real.sqrt_sq (by positivity)]
  · have e3 : Real.sqrt ((4 : ℝ) ^ ((P.card : ℝ) / 2)) = (4 : ℝ) ^ ((P.card : ℝ) / 4) := by
      rw [Real.sqrt_eq_rpow, ← Real.rpow_mul (by norm_num)]; congr 1; ring
    have eG : Real.sqrt (Gp ^ ((1 : ℝ) / 2)) = Gp ^ ((1 : ℝ) / 4) := by
      rw [Real.sqrt_eq_rpow, ← Real.rpow_mul hGp0]; congr 1; ring
    rw [show 4 * (1 + Real.log Y) ^ 2 * Pi34 * ((4 : ℝ) ^ ((P.card : ℝ) / 2) * Gp ^ ((1 : ℝ) / 2)) * Q =
        (2 * (1 + Real.log Y)) ^ 2 * Pi34 * (4 : ℝ) ^ ((P.card : ℝ) / 2) * Gp ^ ((1 : ℝ) / 2) * Q by ring]
    rw [Real.sqrt_mul (by positivity), Real.sqrt_mul (by positivity), Real.sqrt_mul (by positivity),
      Real.sqrt_mul (by positivity), Real.sqrt_sq (by positivity), e3, eG, ← hGpN]

/-- **The W′ term in closed form.** -/
theorem WTermW_le (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (U : Finset ℕ) (hU : ∀ p ∈ U, 5 ≤ p)
    (Jm : ℕ) (A : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s) (Ab : ℝ) (hAb : 0 ≤ Ab)
    (hA : ∀ ρ j, 1 ≤ j → ‖A ρ j‖ ≤ Ab / j)
    (hc : ∀ j, 1 ≤ j → P.filter (fun p => (ZMod.cast (c j) : ZMod p) = 0) = P.filter (fun p => p ∣ j))
    (X Y Nb Lw : ℕ) (hX : 1 ≤ X) (hN : 1 ≤ Lw / Y) :
    WTermW P U (Icc 1 Jm) A c X Y Nb Lw ≤
      ((Nat.log 2 (max Nb Lw) + 1 : ℕ) : ℝ) * M * (M * Ab) *
        (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 * (max Nb Lw) ^ 2)) : ℝ) ^ 30) ^ 2 *
        (1 + Real.log Jm) *
        (2 / Real.sqrt X + 2 * (1 + Real.log Y) / Real.sqrt s +
          2 * (1 + Real.log Y) * (8 : ℝ) ^ P.card *
            Real.sqrt ((s : ℝ) ^ ((1 : ℝ) / 2) / s + (s : ℝ) ^ ((1 : ℝ) / 2) * (1 + Real.log s) / (Lw / Y : ℕ))) +
      M * Ab * (1 + Real.log Jm) * (∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3))) * ((12.5 : ℝ) / X) := by
  unfold WTermW
  set K₁ : ℝ := ((Nat.log 2 (max Nb Lw) + 1 : ℕ) : ℝ) with hK₁
  set Aω : ℝ := (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 * (max Nb Lw) ^ 2)) : ℝ) ^ 30) ^ 2 with hAω
  set WU : ℝ := ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) with hWU
  have hWU0 : 0 ≤ WU := prod_nonneg fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast hU p hp
    have : 0 ≤ 1 / ((p : ℝ) - 3) := by apply div_nonneg zero_le_one; linarith
    linarith
  have hlJ : 0 ≤ 1 + Real.log Jm := GoldC.QuillonDivisorMoment.one_add_log_nonneg Jm
  have hsR : (0 : ℝ) < s := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne s)
  have hlY : 0 ≤ 1 + Real.log Y := by have := Real.log_natCast_nonneg Y; linarith
  set Q := (s : ℝ) ^ ((1 : ℝ) / 2) / s + (s : ℝ) ^ ((1 : ℝ) / 2) * (1 + Real.log s) / (Lw / Y : ℕ) with hQ
  have hQ0 : 0 ≤ Q := by
    have : 0 ≤ 1 + Real.log s := by have := Real.log_natCast_nonneg s; linarith
    positivity
  set Pi34 := ∏ p ∈ P, (1 + (p : ℝ) ^ (-(1 : ℝ) / 2)) with hPi34
  have hPi34 : Real.sqrt Pi34 ≤ 2 ^ P.card := by
    have h := prod_one_add_rpow_le P hP (-(1 : ℝ) / 2) (by norm_num)
    have h1 : (1 : ℝ) ≤ 2 ^ P.card := one_le_pow₀ (by norm_num)
    calc Real.sqrt Pi34 ≤ Real.sqrt (2 ^ P.card) := Real.sqrt_le_sqrt h
      _ ≤ 2 ^ P.card := by
          rw [Real.sqrt_le_left (by positivity)]; nlinarith
  have h3 : (4 : ℝ) ^ ((P.card : ℝ) / 4) ≤ 2 ^ P.card := by
    rw [show (2 : ℝ) ^ P.card = (2 : ℝ) ^ (P.card : ℝ) by rw [Real.rpow_natCast]]
    calc (4 : ℝ) ^ ((P.card : ℝ) / 4) ≤ (4 : ℝ) ^ ((P.card : ℝ) / 2) :=
          Real.rpow_le_rpow_of_exponent_le (by norm_num) (by
            have : (0 : ℝ) ≤ P.card := Nat.cast_nonneg _; linarith)
      _ = (Real.sqrt 4) ^ (P.card : ℝ) := by
          rw [Real.sqrt_eq_rpow, ← Real.rpow_mul (by norm_num)]; congr 1; ring
      _ ≤ (2 : ℝ) ^ (P.card : ℝ) := by
          apply Real.rpow_le_rpow (Real.sqrt_nonneg _) _ (Nat.cast_nonneg _)
          rw [Real.sqrt_le_left (by norm_num)]; norm_num
  -- per-mode bound
  have hmode : ∀ j ∈ Icc 1 Jm, Real.sqrt (2 * WPsiW P (c j) X Y (Lw / Y)) ≤
      2 / Real.sqrt X + 2 * (1 + Real.log Y) / Real.sqrt s +
        2 * (1 + Real.log Y) * (4 : ℝ) ^ P.card *
          (((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 4)) * Real.sqrt Q := by
    intro j hj
    have hj1 : 1 ≤ j := (mem_Icc.1 hj).1
    refine (sqrt_WPsiW_le P hP (c j) X Y (Lw / Y) hX hN j (hc j hj1)).trans ?_
    have hG0 : (0 : ℝ) ≤ ((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 4) := by positivity
    have h4 : Real.sqrt Pi34 * (4 : ℝ) ^ ((P.card : ℝ) / 4) ≤ (4 : ℝ) ^ P.card := by
      rw [show (4 : ℝ) ^ P.card = 2 ^ P.card * 2 ^ P.card by rw [← mul_pow]; norm_num]
      exact mul_le_mul hPi34 h3 (by positivity) (by positivity)
    have := Real.sqrt_nonneg Q
    have hsPi : 0 ≤ Real.sqrt Pi34 := Real.sqrt_nonneg _
    have h3' : (0 : ℝ) ≤ (4 : ℝ) ^ ((P.card : ℝ) / 4) := by positivity
    have hsQ := Real.sqrt_nonneg Q
    have hk : 2 * (1 + Real.log Y) * (Real.sqrt Pi34 * (4 : ℝ) ^ ((P.card : ℝ) / 4)) *
        ((((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 4)) * Real.sqrt Q) ≤
        2 * (1 + Real.log Y) * (4 : ℝ) ^ P.card *
        ((((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 4)) * Real.sqrt Q) :=
      mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left h4 (by positivity)) (by positivity)
    have e1 : 2 * (1 + Real.log Y) * Real.sqrt Pi34 * (4 : ℝ) ^ ((P.card : ℝ) / 4) *
        (((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 4)) * Real.sqrt Q =
        2 * (1 + Real.log Y) * (Real.sqrt Pi34 * (4 : ℝ) ^ ((P.card : ℝ) / 4)) *
        ((((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 4)) * Real.sqrt Q) := by ring
    have e2 : 2 * (1 + Real.log Y) * (4 : ℝ) ^ P.card *
        (((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 4)) * Real.sqrt Q =
        2 * (1 + Real.log Y) * (4 : ℝ) ^ P.card *
        ((((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 4)) * Real.sqrt Q) := by ring
    rw [e1, e2]
    linarith
  -- mode sums
  have hsum1 : ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) ≤ 1 + Real.log Jm := harm_Icc_le Jm
  have hsum2 := gcd_mode_sum P hP Jm (1 / 4) (by norm_num) (by norm_num)
  have hPi78 : ∏ p ∈ P, (1 + (p : ℝ) ^ ((1 : ℝ) / 4 - 1)) ≤ 2 ^ P.card :=
    prod_one_add_rpow_le P hP _ (by norm_num)
  have hS : ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * Real.sqrt (2 * WPsiW P (c j) X Y (Lw / Y)) ≤
      (1 + Real.log Jm) *
        (2 / Real.sqrt X + 2 * (1 + Real.log Y) / Real.sqrt s +
          2 * (1 + Real.log Y) * (8 : ℝ) ^ P.card * Real.sqrt Q) := by
    calc ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * Real.sqrt (2 * WPsiW P (c j) X Y (Lw / Y))
        ≤ ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * (2 / Real.sqrt X + 2 * (1 + Real.log Y) / Real.sqrt s +
            2 * (1 + Real.log Y) * (4 : ℝ) ^ P.card *
              (((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 4)) * Real.sqrt Q) :=
          sum_le_sum fun j hj => mul_le_mul_of_nonneg_left (hmode j hj) (by positivity)
      _ = (∑ j ∈ Icc 1 Jm, (1 / (j : ℝ))) * (2 / Real.sqrt X + 2 * (1 + Real.log Y) / Real.sqrt s) +
          2 * (1 + Real.log Y) * (4 : ℝ) ^ P.card * Real.sqrt Q *
            ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * (((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 4)) := by
          rw [sum_mul, mul_sum, ← sum_add_distrib]
          refine sum_congr rfl fun j _ => by ring
      _ ≤ (1 + Real.log Jm) * (2 / Real.sqrt X + 2 * (1 + Real.log Y) / Real.sqrt s) +
          2 * (1 + Real.log Y) * (4 : ℝ) ^ P.card * Real.sqrt Q * ((1 + Real.log Jm) * 2 ^ P.card) := by
          have h0 : 0 ≤ 2 / Real.sqrt X + 2 * (1 + Real.log Y) / Real.sqrt s := by positivity
          have hb : 0 ≤ 2 * (1 + Real.log Y) * (4 : ℝ) ^ P.card * Real.sqrt Q := by positivity
          exact add_le_add (mul_le_mul_of_nonneg_right hsum1 h0)
            (mul_le_mul_of_nonneg_left (hsum2.trans (mul_le_mul_of_nonneg_left hPi78 hlJ)) hb)
      _ = _ := by
          rw [show (8 : ℝ) ^ P.card = 4 ^ P.card * 2 ^ P.card by rw [← mul_pow]; norm_num]; ring
  -- assemble
  have hρ : ∀ (f : ℕ → ℝ), (∀ j, 0 ≤ f j) → ∑ ρ : ZMod M, ∑ j ∈ Icc 1 Jm, ‖A ρ j‖ * f j ≤
      M * (Ab * ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * f j) := by
    intro f hf
    calc ∑ ρ : ZMod M, ∑ j ∈ Icc 1 Jm, ‖A ρ j‖ * f j ≤ ∑ _ρ : ZMod M, Ab * ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * f j := by
          refine sum_le_sum fun ρ _ => ?_
          rw [mul_sum]
          refine sum_le_sum fun j hj => ?_
          have hj1 : 1 ≤ j := (mem_Icc.1 hj).1
          calc ‖A ρ j‖ * f j ≤ Ab / j * f j := mul_le_mul_of_nonneg_right (hA ρ j hj1) (hf j)
            _ = Ab * (1 / (j : ℝ) * f j) := by ring
      _ = M * (Ab * ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * f j) := by
          rw [sum_const, card_univ, ZMod.card, nsmul_eq_mul]
  have hfirst := hρ (fun j => Aω * Real.sqrt (2 * WPsiW P (c j) X Y (Lw / Y))) (fun j => by positivity)
  have hsecond := hρ (fun _ => 1) (fun _ => by norm_num)
  simp only [mul_one] at hsecond
  have hM0 : (0 : ℝ) ≤ M := Nat.cast_nonneg _
  have hK0 : (0 : ℝ) ≤ K₁ := Nat.cast_nonneg _
  have e1 : ∑ ρ : ZMod M, ∑ j ∈ Icc 1 Jm, ‖A ρ j‖ * (Aω * Real.sqrt (2 * WPsiW P (c j) X Y (Lw / Y))) =
      ∑ ρ : ZMod M, ∑ j ∈ Icc 1 Jm, ‖A ρ j‖ * (Real.exp 37.5 *
        (1 + Nat.log 2 (Nat.log 2 (2 * (max Nb Lw) ^ 2)) : ℝ) ^ 30) ^ 2 *
        Real.sqrt (2 * WPsiW P (c j) X Y (Lw / Y)) := by
    refine sum_congr rfl fun ρ _ => sum_congr rfl fun j _ => by rw [hAω]; ring
  have hfirst' : ∑ ρ : ZMod M, ∑ j ∈ Icc 1 Jm, ‖A ρ j‖ * ((Real.exp 37.5 *
        (1 + Nat.log 2 (Nat.log 2 (2 * (max Nb Lw) ^ 2)) : ℝ) ^ 30) ^ 2 *
        Real.sqrt (2 * WPsiW P (c j) X Y (Lw / Y))) ≤
      M * (Ab * (Aω * ((1 + Real.log Jm) *
        (2 / Real.sqrt X + 2 * (1 + Real.log Y) / Real.sqrt s +
          2 * (1 + Real.log Y) * (8 : ℝ) ^ P.card * Real.sqrt Q)))) := by
    refine hfirst.trans ?_
    apply mul_le_mul_of_nonneg_left _ hM0
    apply mul_le_mul_of_nonneg_left _ hAb
    rw [show ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * (Aω * Real.sqrt (2 * WPsiW P (c j) X Y (Lw / Y))) =
        Aω * ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * Real.sqrt (2 * WPsiW P (c j) X Y (Lw / Y)) by
      rw [mul_sum]; exact sum_congr rfl fun j _ => by ring]
    exact mul_le_mul_of_nonneg_left hS (by positivity)
  have hsecond' : ∑ ρ : ZMod M, ∑ j ∈ Icc 1 Jm, ‖A ρ j‖ ≤ M * (Ab * (1 + Real.log Jm)) :=
    hsecond.trans (mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left hsum1 hAb) hM0)
  have h12 : (0 : ℝ) ≤ 12.5 / X := by positivity
  calc K₁ * M * _ + _ * WU * (12.5 / X)
      ≤ K₁ * M * (M * (Ab * (Aω * ((1 + Real.log Jm) *
          (2 / Real.sqrt X + 2 * (1 + Real.log Y) / Real.sqrt s +
            2 * (1 + Real.log Y) * (8 : ℝ) ^ P.card * Real.sqrt Q))))) +
        M * (Ab * (1 + Real.log Jm)) * WU * (12.5 / X) := by
        gcongr
    _ = _ := by ring

end GoldC.QuillonLWeilB

#print axioms GoldC.QuillonLWeilB.W_piece_W
#print axioms GoldC.QuillonLWeilB.W_bilinear_full_W
#print axioms GoldC.QuillonLWeilB.W_context_W
#print axioms GoldC.QuillonLWeilB.W_cell_W
#print axioms GoldC.QuillonLWeilB.WTermW_le
