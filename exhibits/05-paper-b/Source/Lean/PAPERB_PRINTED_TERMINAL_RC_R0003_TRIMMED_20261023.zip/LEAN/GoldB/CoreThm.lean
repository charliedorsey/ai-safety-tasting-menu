import GoldB.Core

/-!
# GoldB.CoreThm — the order-uniform double-sum bound
-/

open Finset

namespace GoldB

lemma sum_fin_succ_cast (k : ℕ) : ∑ j : Fin k, ((j : ℕ) + 1 : ℝ) = (k : ℝ) * (k + 1) / 2 := by
  induction k with
  | zero => simp
  | succ n ih => rw [Fin.sum_univ_castSucc]; simp [ih]; push_cast; ring

namespace KParams

variable (K : KParams)

/-- per-order bound on `𝔖_j`, uniform form -/
lemma Sfrak_uniform (k : ℕ) (hk : 1 ≤ k) (P : ℝ) (hP1 : 1 < P) (hP : 2 ≤ P ^ K.c3)
    (B : Fin k → ℝ) (S : Finset (Fin k))
    (hB : ∀ j ∈ S, P ^ (-(K.c2 * ((j : ℕ) + 1))) ≤ |B j| ∧ |B j| ≤ P ^ (-(K.c3 * ((j : ℕ) + 1))))
    (j : Fin k) :
    Sfrak (k * K.tau k) (K.QQ k P) j (B j) ≤
      28 * 4 ^ ((j : ℕ) + 1) * (1 + k * Real.log P) *
        (Lbox (k * K.tau k) (K.QQ k P) j : ℝ) ^ 2 *
          (if j ∈ S then P ^ (-(K.ρ * ((j : ℕ) + 1))) else 1) := by
  set b := k * K.tau k
  set Q := K.QQ k P
  set s : ℕ := (j : ℕ) + 1
  have hP0 : 0 < P := by linarith
  have hlP : 0 < Real.log P := Real.log_pos hP1
  have hb1 : 1 ≤ b := Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero (by omega)
    (by have := K.tau_ge k; omega))
  have hP2 : 1 ≤ K.P2 k P := K.P2_ge_one k hP1.le
  have hLdef : (Lbox b Q j : ℝ) = b * (K.P2 k P : ℝ) ^ s := by
    simp [Lbox, Q, QQ, s]
  have hL1 : 1 ≤ Lbox b Q j := by
    unfold Lbox; simp only [Q, QQ, Nat.add_sub_cancel]
    exact Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero (by omega)
      (pow_ne_zero _ (by omega)))
  have hL1r : (1 : ℝ) ≤ Lbox b Q j := by exact_mod_cast hL1
  have hstuff : (9 : ℝ) ≤ 28 * 4 ^ s * (1 + k * Real.log P) := by
    have : (1 : ℝ) ≤ 4 ^ s := one_le_pow₀ (by norm_num)
    have : 0 ≤ (k : ℝ) * Real.log P := by positivity
    nlinarith
  split_ifs with hj
  · obtain ⟨hlo, hhi⟩ := hB j hj
    have hβ0 : 0 < |B j| := lt_of_lt_of_le (Real.rpow_pos_of_pos hP0 _) hlo
    have hsr : (1 : ℝ) ≤ s := by simp [s]
    have hβ2 : |B j| ≤ 1 / 2 := by
      calc |B j| ≤ P ^ (-(K.c3 * s)) := by simpa [s] using hhi
        _ ≤ P ^ (-K.c3) := Real.rpow_le_rpow_of_exponent_le hP1.le (by
            have := K.h3; nlinarith)
        _ = 1 / P ^ K.c3 := by rw [Real.rpow_neg hP0.le, one_div]
        _ ≤ 1 / 2 := one_div_le_one_div_of_le (by norm_num) hP
    have hε : 0 < P ^ (-(K.ρ * s)) := Real.rpow_pos_of_pos hP0 _
    have hβε : |B j| ≤ P ^ (-(K.ρ * s)) := by
      calc |B j| ≤ P ^ (-(K.c3 * s)) := by simpa [s] using hhi
        _ ≤ P ^ (-(K.ρ * s)) := Real.rpow_le_rpow_of_exponent_le hP1.le (by
            have := K.ρ_le_c3; nlinarith)
    -- 1/L ≤ 2^s P^{-ρ s}
    have hu1 := K.uu_ge_one k hP1.le
    have hu2 := K.uu_le_two_P2 k hP1.le
    have hP2r : (1 : ℝ) ≤ K.P2 k P := by exact_mod_cast hP2
    have hinvP2 : 1 / (K.P2 k P : ℝ) ≤ 2 * P ^ (-K.aexp k) := by
      rw [Real.rpow_neg hP0.le, div_le_iff₀ (by linarith)]
      have : K.uu k P = P ^ K.aexp k := rfl
      rw [← this]
      have hupos : 0 < K.uu k P := by linarith
      field_simp
      linarith
    have hLε : 1 / (Lbox b Q j : ℝ) ≤ 2 ^ s * P ^ (-(K.ρ * s)) := by
      rw [hLdef]
      have hbr : (1 : ℝ) ≤ b := by exact_mod_cast hb1
      calc 1 / ((b : ℝ) * (K.P2 k P : ℝ) ^ s) ≤ 1 / (K.P2 k P : ℝ) ^ s := by
            apply one_div_le_one_div_of_le (by positivity); nlinarith [pow_pos (by linarith : (0:ℝ) < K.P2 k P) s]
        _ = (1 / (K.P2 k P : ℝ)) ^ s := by rw [one_div_pow]
        _ ≤ (2 * P ^ (-K.aexp k)) ^ s := pow_le_pow_left₀ (by positivity) hinvP2 s
        _ = 2 ^ s * P ^ (-(K.aexp k * s)) := by
            rw [mul_pow, ← Real.rpow_natCast (P ^ (-K.aexp k)), ← Real.rpow_mul hP0.le]; ring_nf
        _ ≤ 2 ^ s * P ^ (-(K.ρ * s)) := by
            apply mul_le_mul_of_nonneg_left _ (by positivity)
            apply Real.rpow_le_rpow_of_exponent_le hP1.le
            have := K.ρ_le_aexp k; nlinarith
    have hβLε : 1 / (|B j| * (Lbox b Q j : ℝ) ^ 2) ≤ 4 ^ s * P ^ (-(K.ρ * s)) := by
      have h1 : 1 / |B j| ≤ P ^ (K.c2 * s) := by
        rw [div_le_iff₀ hβ0]
        calc (1 : ℝ) = P ^ (K.c2 * s) * P ^ (-(K.c2 * s)) := by
              rw [← Real.rpow_add hP0]; simp
          _ ≤ P ^ (K.c2 * s) * |B j| := by
              apply mul_le_mul_of_nonneg_left _ (by positivity); simpa [s] using hlo
      have h2 : 1 / (Lbox b Q j : ℝ) ^ 2 ≤ 4 ^ s * P ^ (-(2 * K.aexp k * s)) := by
        rw [hLdef]
        have hbr : (1 : ℝ) ≤ b := by exact_mod_cast hb1
        calc 1 / ((b : ℝ) * (K.P2 k P : ℝ) ^ s) ^ 2 ≤ 1 / ((K.P2 k P : ℝ) ^ s) ^ 2 := by
              apply one_div_le_one_div_of_le (by positivity)
              apply pow_le_pow_left₀ (by positivity)
              nlinarith [pow_pos (by linarith : (0:ℝ) < K.P2 k P) s]
          _ = ((1 / (K.P2 k P : ℝ)) ^ s) ^ 2 := by rw [one_div_pow, one_div_pow]
          _ ≤ ((2 * P ^ (-K.aexp k)) ^ s) ^ 2 := by
              apply pow_le_pow_left₀ (by positivity)
              exact pow_le_pow_left₀ (by positivity) hinvP2 s
          _ = 4 ^ s * P ^ (-(2 * K.aexp k * s)) := by
              rw [mul_pow, ← Real.rpow_natCast (P ^ (-K.aexp k)), ← Real.rpow_mul hP0.le,
                mul_pow, ← Real.rpow_natCast (P ^ (-K.aexp k * s)), ← Real.rpow_mul hP0.le,
                ← pow_mul, show (4 : ℝ) = 2 ^ 2 by norm_num, ← pow_mul]
              ring_nf
      calc 1 / (|B j| * (Lbox b Q j : ℝ) ^ 2) = (1 / |B j|) * (1 / (Lbox b Q j : ℝ) ^ 2) := by
            field_simp
        _ ≤ P ^ (K.c2 * s) * (4 ^ s * P ^ (-(2 * K.aexp k * s))) :=
            mul_le_mul h1 h2 (by positivity) (by positivity)
        _ = 4 ^ s * P ^ (-((2 * K.aexp k - K.c2) * s)) := by
            rw [mul_left_comm, ← Real.rpow_add hP0]; ring_nf
        _ ≤ 4 ^ s * P ^ (-(K.ρ * s)) := by
            apply mul_le_mul_of_nonneg_left _ (by positivity)
            apply Real.rpow_le_rpow_of_exponent_le hP1.le
            have := K.two_aexp_gap k; nlinarith
    have hℓ : Real.log (1 / |B j|) ≤ k * Real.log P := by
      rw [one_div, Real.log_inv, neg_le]
      have : Real.log (P ^ (-(K.c2 * s))) ≤ Real.log |B j| := Real.log_le_log
        (Real.rpow_pos_of_pos hP0 _) (by simpa [s] using hlo)
      rw [Real.log_rpow hP0] at this
      have hc2 : K.c2 < 1 := by linarith [K.h21, K.h1]
      have hc20 : 0 < K.c2 := lt_of_lt_of_le K.h3 K.h32
      have hsk : (s : ℝ) ≤ k := by simp only [s]; exact_mod_cast j.isLt
      have hlogP : 0 ≤ Real.log P := Real.log_nonneg hP1.le
      have hs0 : (0 : ℝ) ≤ s := by positivity
      have hcs : K.c2 * s ≤ k := by nlinarith
      have h1 : K.c2 * s * Real.log P ≤ k * Real.log P := mul_le_mul_of_nonneg_right hcs hlogP
      nlinarith
    have hfin := Sfrak_le_sel b Q j (B j) (P ^ (-(K.ρ * (s : ℝ)))) (k * Real.log P) s hL1 hβ0
      hβ2 hε hβε hLε hβLε hℓ
    have hscast : ((s : ℕ) : ℝ) = ((j : ℕ) : ℝ) + 1 := by simp only [s]; push_cast; ring
    rw [hscast] at hfin
    exact hfin
  · calc Sfrak b Q j (B j) ≤ 9 * (Lbox b Q j : ℝ) ^ 2 := Sfrak_le_trivial b Q j (B j) hL1
      _ ≤ 28 * 4 ^ s * (1 + k * Real.log P) * (Lbox b Q j : ℝ) ^ 2 * 1 := by
          rw [mul_one]; exact mul_le_mul_of_nonneg_right hstuff (by positivity)

end KParams

end GoldB
