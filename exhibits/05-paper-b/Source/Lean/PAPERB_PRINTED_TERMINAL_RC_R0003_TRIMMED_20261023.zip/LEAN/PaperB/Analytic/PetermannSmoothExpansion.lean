import PaperB.Analytic.SawtoothBridge

namespace PaperB.Analytic

open Real Finset

lemma sawSmoothPartial_eq_pair_sum
    {S : ℝ} (hS : 1 < S) (H : ℕ) (y : AddCircle (1 : ℝ)) :
    sawSmoothPartial S H y =
      ∑ k ∈ Finset.range H, sawSmoothPair S k y := by
  unfold sawSmoothPartial sawSmoothMode
  rw [sawSmoothCoeff_zero hS]
  simp

lemma eR_mul_sawSmoothPair_petermann_phase
    (S xi T : ℝ) (L : ℕ) (k e : ℕ) (r : ℤ) :
    eR (xi * (e : ℝ)) *
        sawSmoothPair S k
          ((T / (L : ℝ) / (e : ℝ) + (r : ℝ) / (L : ℝ) :
            ℝ) : AddCircle (1 : ℝ)) =
      sawSmoothCoeff S (k + 1 : ℕ) *
        eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) / (L : ℝ)) *
        eR ((((((k + 1 : ℕ) : ℝ) * T) / (L : ℝ)) / (e : ℝ)) +
          xi * (e : ℝ)) +
      sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
        eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) / (L : ℝ)) *
        eR ((((-((k + 1 : ℕ) : ℤ) : ℝ) * T) / (L : ℝ)) / (e : ℝ) +
          xi * (e : ℝ)) := by
  unfold sawSmoothPair
  rw [mul_add]
  rw [eR_mul_sawSmoothMode_petermann_phase,
    eR_mul_sawSmoothMode_petermann_phase]
  push_cast
  rfl

lemma eR_mul_sawSmoothPartial_petermann_phase
    {S : ℝ} (hS : 1 < S)
    (xi T : ℝ) (L H e : ℕ) (r : ℤ) :
    eR (xi * (e : ℝ)) *
        sawSmoothPartial S H
          ((T / (L : ℝ) / (e : ℝ) + (r : ℝ) / (L : ℝ) :
            ℝ) : AddCircle (1 : ℝ)) =
      ∑ k ∈ Finset.range H,
        (sawSmoothCoeff S (k + 1 : ℕ) *
          eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) / (L : ℝ)) *
          eR (((((k + 1 : ℕ) : ℝ) * T) / (L : ℝ)) / (e : ℝ) +
            xi * (e : ℝ)) +
        sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
          eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) / (L : ℝ)) *
          eR (((-((k + 1 : ℕ) : ℤ) : ℝ) * T) / (L : ℝ) / (e : ℝ) +
            xi * (e : ℝ))) := by
  rw [sawSmoothPartial_eq_pair_sum hS]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro k hk
  exact eR_mul_sawSmoothPair_petermann_phase
    S xi T L k e r

#print axioms sawSmoothPartial_eq_pair_sum
#print axioms eR_mul_sawSmoothPair_petermann_phase
#print axioms eR_mul_sawSmoothPartial_petermann_phase

end PaperB.Analytic
