import ScratchElowrynFoldedHighCard
import ScratchElowrynHighEventualNumericalR0003

open scoped BigOperators
open Filter Real

namespace GoldC

/-!
# Physical high-cardinality Central: the growing cutoff.

This module consumes Elowryn's independently kernel-checked **physical**
Rankin envelope and her independently checked numerical large-cutoff
inequality. The source is the actual `regionSumCard`, with all
decorations and both orientations, not an abstract Euler model.
-/

noncomputable def orienneCentralHighCut (h : ℕ) : ℕ :=
  elowrynHighCutFromY (Real.log (((h ^ 2 : ℕ) : ℝ)))

/-- Entire physical folded high-card source is bounded uniformly in h and a,
at the growing natural-cardinality cutoff. The bound depends only on q. -/
theorem orienne_physical_highCard_uniform
    (q a h : ℕ) (hq : 0 < q) (hh : 3 ≤ h)
    (gate : ℕ → ℕ → ℕ → Prop) :
    |regionSumCard (orienneCentralHighCut h) true q h gate
      (foldRow q a)| ≤
      (4 + 48 * (q : ℝ)) * (8 * Real.exp 75) := by
  let Y : ℝ := Real.log (((h ^ 2 : ℕ) : ℝ))
  let H : ℝ := Real.log (h : ℝ)
  let C : ℝ := (4 + 48 * (q : ℝ))
  let w : ℝ := |regionSumCard (orienneCentralHighCut h) true q h gate
      (foldRow q a)|
  have hhpos : (0 : ℝ) < h := by
    exact_mod_cast (show 0 < h by omega)
  have hhthree : (3 : ℝ) ≤ ((h ^ 2 : ℕ) : ℝ) := by
    exact_mod_cast (show 3 ≤ h ^ 2 by nlinarith)
  have hExp : Real.exp (1 : ℝ) ≤ ((h ^ 2 : ℕ) : ℝ) :=
    Real.exp_one_lt_three.le.trans hhthree
  have hY : 1 ≤ Y := by
    dsimp [Y]
    calc
      (1 : ℝ) = Real.log (Real.exp 1) := (Real.log_exp 1).symm
      _ ≤ Real.log (((h ^ 2 : ℕ) : ℝ)) :=
        Real.log_le_log (Real.exp_pos _) hExp
  have hH : 0 ≤ H := by
    dsimp [H]
    exact Real.log_nonneg (by exact_mod_cast (show 1 ≤ h by omega))
  have hHY : H ≤ Y := by
    dsimp [H, Y]
    have hsq : h ≤ h ^ 2 := by nlinarith
    have hle : (h : ℝ) ≤ ((h ^ 2 : ℕ) : ℝ) := by exact_mod_cast hsq
    exact Real.log_le_log hhpos hle
  have hC : 0 ≤ C := by dsimp [C]; positivity
  have hw : 0 ≤ w := by dsimp [w]; positivity
  have hRankin :
      (Real.exp 1) ^ (elowrynHighCutFromY Y) * w ≤
        C * (1 + H)^3 *
          Real.exp ((Real.exp 1) * (5 * (Real.log Y + 5))) := by
    have hsource :=
      elowryn_folded_highCard_rankin_cubic q a h
        (orienneCentralHighCut h) hq (by omega : 2 ≤ h)
        (Real.exp 1)
        (Real.one_le_exp (by norm_num : (0 : ℝ) ≤ 1)) gate
    simpa only [orienneCentralHighCut, Y, H, C, w] using hsource
  exact elowryn_high_rankin_uniform_constant
    Y H C w hY hH hHY hC hw hRankin

#print axioms orienne_physical_highCard_uniform
end GoldC
