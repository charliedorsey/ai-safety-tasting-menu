import GeneralKloosterman.PrimePowerUnit
import rml.weil.contracts

/-!
# The prime-power theorem with the exact gcd loss

`kgcd N a b = gcd(a, b, N)` (computed from the canonical representatives).

* `kSum_eq_kloostermanUnitSum` — `kSum` is the toolkit's `kloostermanUnitSum` (`rfl`).
* `norm_kSum_prime_le` — `k = 1`, all coefficients: from the toolkit's Weil bound `prime_bound`
  (and the trivial bound when `a = b = 0`).
* `norm_kSum_unit_primePow_le` — unit coefficients, `k ≥ 2`, every prime `p` (including `2`):
  `‖S(a,b;p^k)‖ ≤ (k+1) √(p^k)`.
* **`norm_kSum_primePow_le`** — every `k ≥ 1`, all `a, b`:
  `‖S(a,b;p^k)‖ ≤ τ(p^k) · √(gcd(a,b,p^k) · p^k)` with `τ(p^k) = k + 1`,
  by induction on `k`: units (cancellation) / exactly one coefficient divisible by `p` (vanishing) /
  both divisible (`S(pa',pb';p^k) = p·S(a',b';p^(k-1))`, the gcd absorbing the factor `p`).
-/

open Finset RML.ExpSum.Weil

namespace GenKloosterman

theorem kSum_eq_kloostermanUnitSum (N : ℕ) [NeZero N] (a b : ZMod N) :
    kSum N a b = kloostermanUnitSum N a b := rfl

/-- `gcd(a, b, N)`. -/
def kgcd (N : ℕ) (a b : ZMod N) : ℕ := Nat.gcd (Nat.gcd a.val b.val) N

theorem kgcd_pos (N : ℕ) [NeZero N] (a b : ZMod N) : 0 < kgcd N a b :=
  Nat.gcd_pos_of_pos_right _ (Nat.pos_of_ne_zero (NeZero.ne N))

theorem sqrt_le_sqrt_kgcd (N : ℕ) [NeZero N] (a b : ZMod N) :
    Real.sqrt N ≤ Real.sqrt (kgcd N a b * N) := by
  apply Real.sqrt_le_sqrt
  have : (1 : ℝ) ≤ kgcd N a b := by exact_mod_cast kgcd_pos N a b
  nlinarith [(Nat.cast_nonneg N : (0 : ℝ) ≤ N)]

/-- Descent with the modulus given by an equation. -/
theorem kSum_descent' {N d M : ℕ} [NeZero N] [NeZero M] (hN : N = d * M) (a' b' : ZMod N) :
    kSum N ((d : ZMod N) * a') ((d : ZMod N) * b') =
      ((Nat.totient N / Nat.totient M : ℕ) : ℂ) *
        kSum M (ZMod.castHom (hN ▸ Dvd.intro_left d rfl : M ∣ N) (ZMod M) a')
          (ZMod.castHom (hN ▸ Dvd.intro_left d rfl : M ∣ N) (ZMod M) b') := by
  subst hN
  exact kSum_descent a' b'

variable {p : ℕ} [hp : Fact p.Prime]

/-- `k = 1`: Weil's bound (toolkit) and the trivial case `a = b = 0`. -/
theorem norm_kSum_prime_le (a b : ZMod p) :
    ‖kSum p a b‖ ≤ 2 * Real.sqrt (kgcd p a b * p) := by
  by_cases h0 : a = 0 ∧ b = 0
  · obtain ⟨rfl, rfl⟩ := h0
    have hk : kgcd p 0 0 = p := by simp [kgcd]
    rw [hk, ← sq, Real.sqrt_sq (Nat.cast_nonneg _)]
    refine (norm_kSum_le_card _ _).trans ?_
    have : (Nat.totient p : ℝ) ≤ p := by exact_mod_cast Nat.totient_le p
    linarith [(Nat.cast_nonneg p : (0 : ℝ) ≤ p)]
  · have hnot : a ≠ 0 ∨ b ≠ 0 := by tauto
    rw [kSum_eq_kloostermanUnitSum]
    refine (kloostermanUnitSum_prime_le_two_sqrt_of_not_both_zero prime_bound p a b hnot).trans ?_
    exact mul_le_mul_of_nonneg_left (sqrt_le_sqrt_kgcd p a b) (by norm_num)

theorem sqrt_two_mul_gt : (8 : ℝ) ≤ 6 * Real.sqrt 2 := by
  have h := Real.sq_sqrt (show (0 : ℝ) ≤ 2 by norm_num)
  nlinarith [Real.sqrt_nonneg 2]

/-- Unit coefficients, `k ≥ 2`, any prime: `‖S‖ ≤ (k+1) √(p^k)`. -/
theorem norm_kSum_unit_primePow_le {k : ℕ} (hk : 2 ≤ k) (a b : ZMod (p ^ k))
    (ha : IsUnit a) (hb : IsUnit b) :
    ‖kSum (p ^ k) a b‖ ≤ (k + 1) * Real.sqrt ((p : ℝ) ^ k) := by
  have hp0 : (0 : ℝ) ≤ p := Nat.cast_nonneg p
  have hs0 : 0 ≤ Real.sqrt ((p : ℝ) ^ k) := Real.sqrt_nonneg _
  by_cases hp2 : p = 2
  · subst hp2
    have h2 : (0 : ℝ) ≤ 2 := by norm_num
    by_cases hk4 : 4 ≤ k
    · have h := norm_kSum_unit_le_count hk sep_two a b ha hb
      obtain ⟨m, hm | hm⟩ := Nat.even_or_odd' k
      · subst hm
        rw [show 2 * m - (2 * m / 2 - 1) = m + 1 by omega] at h
        push_cast at h ⊢
        rw [sqrt_pow_two_mul _ h2]
        have hm2 : (2 : ℝ) ≤ m := by exact_mod_cast (show 2 ≤ m by omega)
        calc ‖kSum (2 ^ (2 * m)) a b‖ ≤ 2 * 2 ^ (m + 1) := h
          _ = 4 * 2 ^ m := by ring
          _ ≤ (2 * m + 1) * 2 ^ m := by gcongr; linarith
      · subst hm
        rw [show 2 * m + 1 - ((2 * m + 1) / 2 - 1) = m + 2 by omega] at h
        push_cast at h ⊢
        rw [sqrt_pow_two_mul_add_one _ h2]
        have hm2 : (2 : ℝ) ≤ m := by exact_mod_cast (show 2 ≤ m by omega)
        have hs := sqrt_two_mul_gt
        have hpos : (0 : ℝ) < 2 ^ m := by positivity
        calc ‖kSum (2 ^ (2 * m + 1)) a b‖ ≤ 2 * 2 ^ (m + 2) := h
          _ = 8 * 2 ^ m := by ring
          _ ≤ 6 * Real.sqrt 2 * 2 ^ m := by gcongr
          _ ≤ (2 * m + 1 + 1) * (2 ^ m * Real.sqrt 2) := by
            nlinarith [mul_nonneg (show (0 : ℝ) ≤ 2 * m + 2 - 6 by linarith)
              (mul_nonneg hpos.le (Real.sqrt_nonneg 2))]
    · -- `k ∈ {2, 3}`: the trivial bound
      refine (norm_kSum_le_card a b).trans ?_
      rw [Nat.totient_prime_pow Nat.prime_two (by omega)]
      interval_cases k <;> norm_num
  · calc ‖kSum (p ^ k) a b‖ ≤ 2 * Real.sqrt ((p : ℝ) ^ k) := norm_kSum_unit_odd_le hp2 hk a b ha hb
      _ ≤ (k + 1) * Real.sqrt ((p : ℝ) ^ k) := by
        gcongr
        have : (2 : ℝ) ≤ k := by exact_mod_cast hk
        linarith

/-- **Prime-power Weil–Estermann bound with the exact gcd loss.** -/
theorem norm_kSum_primePow_le : ∀ (k N : ℕ) [NeZero N], N = p ^ k → 1 ≤ k →
    ∀ a b : ZMod N, ‖kSum N a b‖ ≤ (k + 1) * Real.sqrt (kgcd N a b * N) := by
  intro k
  induction k with
  | zero => intro N _ _ h; omega
  | succ k ih =>
    intro N _ hN _ a b
    rcases Nat.eq_zero_or_pos k with hk0 | hkpos
    · subst hk0
      rw [pow_one] at hN
      subst hN
      have := norm_kSum_prime_le a b
      push_cast
      linarith
    subst hN
    have hk2 : 2 ≤ k + 1 := by omega
    have hpos : (0 : ℝ) ≤ Real.sqrt (kgcd (p ^ (k + 1)) a b * ((p ^ (k + 1) : ℕ) : ℝ)) :=
      Real.sqrt_nonneg _
    by_cases hpa : p ∣ a.val
    · by_cases hpb : p ∣ b.val
      · -- descent
        set A := a.val / p with hA
        set B := b.val / p with hB
        have haA : a = (p : ZMod (p ^ (k + 1))) * (A : ZMod (p ^ (k + 1))) := by
          rw [← Nat.cast_mul, Nat.mul_div_cancel' hpa, ZMod.natCast_zmod_val]
        have hbB : b = (p : ZMod (p ^ (k + 1))) * (B : ZMod (p ^ (k + 1))) := by
          rw [← Nat.cast_mul, Nat.mul_div_cancel' hpb, ZMod.natCast_zmod_val]
        have hAlt : A < p ^ k := by
          rw [hA, Nat.div_lt_iff_lt_mul hp.out.pos, ← pow_succ]; exact ZMod.val_lt a
        have hBlt : B < p ^ k := by
          rw [hB, Nat.div_lt_iff_lt_mul hp.out.pos, ← pow_succ]; exact ZMod.val_lt b
        have hdesc := kSum_descent' (N := p ^ (k + 1)) (d := p) (M := p ^ k) (pow_succ' p k)
          (A : ZMod (p ^ (k + 1))) (B : ZMod (p ^ (k + 1)))
        rw [← haA, ← hbB] at hdesc
        rw [hdesc, show Nat.totient (p ^ (k + 1)) / Nat.totient (p ^ k) = p by
          rw [pow_succ']; exact totient_pow_succ_div k hkpos]
        rw [ZMod.castHom_apply, ZMod.castHom_apply, ZMod.cast_natCast (pow_dvd_pow p (by omega)),
          ZMod.cast_natCast (pow_dvd_pow p (by omega))]
        have hih := ih (p ^ k) rfl hkpos (A : ZMod (p ^ k)) (B : ZMod (p ^ k))
        have hg : kgcd (p ^ (k + 1)) a b = p * kgcd (p ^ k) (A : ZMod (p ^ k)) (B : ZMod (p ^ k)) := by
          unfold kgcd
          rw [ZMod.val_cast_of_lt hAlt, ZMod.val_cast_of_lt hBlt,
            ← Nat.mul_div_cancel' hpa, ← Nat.mul_div_cancel' hpb, ← hA, ← hB,
            Nat.gcd_mul_left, pow_succ', Nat.gcd_mul_left]
        rw [norm_mul, Complex.norm_natCast, hg]
        have hp0 : (0 : ℝ) ≤ p := Nat.cast_nonneg p
        have hsq : Real.sqrt (((p * kgcd (p ^ k) (A : ZMod (p ^ k)) (B : ZMod (p ^ k)) : ℕ) : ℝ) *
            ((p ^ (k + 1) : ℕ) : ℝ)) =
            p * Real.sqrt ((kgcd (p ^ k) (A : ZMod (p ^ k)) (B : ZMod (p ^ k)) : ℝ) *
              ((p ^ k : ℕ) : ℝ)) := by
          rw [show (((p * kgcd (p ^ k) (A : ZMod (p ^ k)) (B : ZMod (p ^ k)) : ℕ) : ℝ) *
              ((p ^ (k + 1) : ℕ) : ℝ)) = (p : ℝ) ^ 2 *
                ((kgcd (p ^ k) (A : ZMod (p ^ k)) (B : ZMod (p ^ k)) : ℝ) * ((p ^ k : ℕ) : ℝ)) by
            push_cast; ring]
          rw [Real.sqrt_mul (sq_nonneg _), Real.sqrt_sq hp0]
        rw [hsq]
        push_cast at hih ⊢
        have hs0 : 0 ≤ Real.sqrt ((kgcd (p ^ k) (A : ZMod (p ^ k)) (B : ZMod (p ^ k)) : ℝ) *
            (p : ℝ) ^ k) := Real.sqrt_nonneg _
        calc (p : ℝ) * ‖kSum (p ^ k) (A : ZMod (p ^ k)) (B : ZMod (p ^ k))‖
            ≤ p * ((k + 1) * Real.sqrt ((kgcd (p ^ k) (A : ZMod (p ^ k)) (B : ZMod (p ^ k)) : ℝ) *
                (p : ℝ) ^ k)) := by gcongr
          _ ≤ (k + 1 + 1) * (p * Real.sqrt ((kgcd (p ^ k) (A : ZMod (p ^ k)) (B : ZMod (p ^ k)) : ℝ) *
                (p : ℝ) ^ k)) := by nlinarith [mul_nonneg hp0 hs0]
      · -- `p ∣ a`, `b` a unit: vanishing
        have hb : IsUnit b := (isUnit_iff_not_dvd (by omega) b).2 hpb
        rw [kSum_eq_zero_of_dvd_left hk2 a b hpa hb, norm_zero]
        positivity
    · have ha : IsUnit a := (isUnit_iff_not_dvd (by omega) a).2 hpa
      by_cases hpb : p ∣ b.val
      · rw [kSum_eq_zero_of_dvd_right hk2 a b ha hpb, norm_zero]
        positivity
      · have hb : IsUnit b := (isUnit_iff_not_dvd (by omega) b).2 hpb
        have h := norm_kSum_unit_primePow_le hk2 a b ha hb
        have hmono := sqrt_le_sqrt_kgcd (p ^ (k + 1)) a b
        push_cast at h hmono ⊢
        calc ‖kSum (p ^ (k + 1)) a b‖ ≤ (k + 1 + 1) * Real.sqrt ((p : ℝ) ^ (k + 1)) := by
              exact_mod_cast h
          _ ≤ (k + 1 + 1) * Real.sqrt (kgcd (p ^ (k + 1)) a b * (p : ℝ) ^ (k + 1)) := by
              gcongr

end GenKloosterman
