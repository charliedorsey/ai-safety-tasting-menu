import OrielUpper.ReduceA

/-!
# Oriel Upper — exact reduction of one decoration slice to a product window

For a decoration `d ⊆ decoratedHeightPrimeSet q h`, with `H = h / ∏d`,
`F = q H ∏d` and `T = max (Z h) ⌊H / exp((log h)^{1/4})⌋₊`, the source double sum
over parents `e` and proper nonempty splits `B` equals `pairWin F H λ T (H²/4)`,
via `(e, B) ↦ (∏B, ∏(e∖B))`.
-/

open Finset
open OrielUpper.Mirror

namespace OrielUpper

lemma mem_decorated {q h p : ℕ} (hp : p ∈ decoratedHeightPrimeSet q h) :
    p.Prime ∧ p ∣ h ∧ h ≠ 0 ∧ 5 ≤ p ∧ ¬ p ∣ q := by
  unfold decoratedHeightPrimeSet at hp
  rw [mem_filter, Nat.mem_primeFactors] at hp
  exact ⟨hp.1.1, hp.1.2.1, hp.1.2.2, hp.2.1, hp.2.2⟩

lemma prime_dvd_primeSetProduct {d : Finset ℕ} (hd : ∀ p ∈ d, p.Prime) {p : ℕ} (hp : p.Prime) :
    p ∣ primeSetProduct d ↔ p ∈ d := by
  unfold primeSetProduct
  rw [Prime.dvd_finset_prod_iff hp.prime]
  constructor
  · rintro ⟨a, ha, hpa⟩
    rwa [(Nat.prime_dvd_prime_iff_eq hp (hd a ha)).mp hpa]
  · intro h; exact ⟨p, h, dvd_rfl⟩

lemma primeSetProduct_pos' {s : Finset ℕ} (hs : ∀ p ∈ s, p.Prime) : 0 < primeSetProduct s := by
  unfold primeSetProduct
  exact prod_pos (fun p hp => (hs p hp).pos)

lemma one_lt_primeSetProduct {s : Finset ℕ} (hs : ∀ p ∈ s, p.Prime) (hne : s.Nonempty) :
    1 < primeSetProduct s := by
  obtain ⟨p, hp⟩ := hne
  have hdvd : p ∣ primeSetProduct s := dvd_prod_of_mem _ hp
  have := Nat.le_of_dvd (primeSetProduct_pos' hs) hdvd
  have := (hs p hp).two_le
  omega

lemma primeSetProduct_sdiff_mul {e B : Finset ℕ} (hB : B ⊆ e) :
    primeSetProduct B * primeSetProduct (e \ B) = primeSetProduct e := by
  unfold primeSetProduct
  rw [mul_comm, prod_sdiff hB]

lemma coprime_primeSetProduct_disjoint {s t : Finset ℕ} (hs : ∀ p ∈ s, p.Prime)
    (ht : ∀ p ∈ t, p.Prime) (hst : Disjoint s t) :
    Nat.Coprime (primeSetProduct s) (primeSetProduct t) := by
  unfold primeSetProduct
  apply Nat.Coprime.prod_left
  intro p hp
  apply Nat.Coprime.prod_right
  intro r hr
  exact (Nat.coprime_primes (hs p hp) (ht r hr)).mpr
    (fun h => disjoint_left.mp hst hp (h ▸ hr))

section Slice

variable (Z : ℕ → ℕ) (q a h : ℕ) (d : Finset ℕ)

/-- The VK cutoff. -/
noncomputable def vkM (h : ℕ) : ℝ := Real.exp ((Real.log (h : ℝ)) ^ (1/4 : ℝ))

/-- The window floor. -/
noncomputable def sliceT (Z : ℕ → ℕ) (h H : ℕ) : ℕ := max (Z h) ⌊(H : ℝ) / vkM h⌋₊

lemma upper_iff_floor {h H r s : ℕ} :
    virelleR0037Upper h H r s ↔ ⌊(H : ℝ) / vkM h⌋₊ < r * s := by
  unfold virelleR0037Upper elarinR0031VKLowProduct
  have hx : 0 ≤ (H : ℝ) / vkM h := by unfold vkM; positivity
  rw [Nat.floor_lt hx, not_le, Nat.cast_mul]
  rfl

end Slice

/-- Allowed primes for `F = q H ∏d`. -/
lemma allowed_slice_iff {q H : ℕ} {d : Finset ℕ} (hd : ∀ p ∈ d, p.Prime) (hq : 0 < q)
    (hH : 0 < H) {p : ℕ} (hp : p.Prime) :
    allowedP (q * H * primeSetProduct d) p ↔ (5 ≤ p ∧ ¬ p ∣ q) ∧ ¬ p ∣ H ∧ p ∉ d := by
  unfold allowedP
  rw [hp.dvd_mul, hp.dvd_mul, prime_dvd_primeSetProduct hd hp]
  tauto

theorem slice_eq_pairWin (Z : ℕ → ℕ) {q a h : ℕ} (hq : 0 < q) (hh : 0 < h) {d : Finset ℕ}
    (hd : d ⊆ decoratedHeightPrimeSet q h) :
    (∑ e ∈ edrinR0051QuarterParents Z q h
        (h / primeSetProduct d) d ((h / primeSetProduct d) ^ 2 + 1),
      ∑ B ∈ ((e.powerset.erase e).erase ∅),
        @ite ℝ (virelleR0037Upper h (h / primeSetProduct d)
          (primeSetProduct B) (primeSetProduct (e \ B)))
          (Classical.propDecidable _)
        (edrinParentPairRow q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) e B) 0) =
      pairWin (q * (h / primeSetProduct d) * primeSetProduct d) (h / primeSetProduct d)
        (fixedQLowWeight q (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d))
        (sliceT Z h (h / primeSetProduct d)) ((h / primeSetProduct d) ^ 2 / 4) := by
  set H := h / primeSetProduct d with hHdef
  set A := decoratedReducedAnchor q a (primeSetProduct d)
  set F := q * H * primeSetProduct d with hFdef
  set w := fixedQLowWeight q A H
  set T := sliceT Z h H
  set U := H ^ 2 / 4
  have hdP : ∀ p ∈ d, p.Prime := fun p hp => (mem_decorated (hd hp)).1
  have hdpos : 0 < primeSetProduct d := primeSetProduct_pos' hdP
  have hd_dvd : primeSetProduct d ∣ h := by
    unfold primeSetProduct
    apply Finset.prod_primes_dvd
    · intro p hp; exact (hdP p hp).prime
    · intro p hp; exact (mem_decorated (hd hp)).2.1
  have hH : 0 < H := Nat.div_pos (Nat.le_of_dvd hh hd_dvd) hdpos
  -- membership in parents
  have hE : ∀ e, e ∈ edrinR0051QuarterParents Z q h H d (H ^ 2 + 1) ↔
      (∀ p ∈ e, p < H ^ 2 + 1 ∧ p.Prime ∧ allowedP F p) ∧
        Z h < primeSetProduct e ∧ 4 * primeSetProduct e ≤ H ^ 2 := by
    intro e
    unfold edrinR0051QuarterParents thalenActiveOrdinaryFiniteSupport
    rw [mem_filter, mem_powerset]
    constructor
    · rintro ⟨hsub, h1, h2⟩
      refine ⟨fun p hp => ?_, h1, h2⟩
      have := hsub hp
      rw [mem_filter, mem_range] at this
      obtain ⟨hlt, ⟨hpp, h5, hpq⟩, hpH, hpd⟩ := this
      exact ⟨hlt, hpp, (allowed_slice_iff hdP hq hH hpp).mpr ⟨⟨h5, hpq⟩, hpH, hpd⟩⟩
    · rintro ⟨hall, h1, h2⟩
      refine ⟨fun p hp => ?_, h1, h2⟩
      obtain ⟨hlt, hpp, hal⟩ := hall p hp
      have := (allowed_slice_iff hdP hq hH hpp).mp hal
      rw [mem_filter, mem_range]
      exact ⟨hlt, ⟨hpp, this.1.1, this.1.2⟩, this.2.1, this.2.2⟩
  have hBmem : ∀ e B : Finset ℕ, B ∈ ((e.powerset.erase e).erase ∅) ↔ B ⊆ e ∧ B ≠ e ∧ B ≠ ∅ := by
    intro e B
    rw [mem_erase, mem_erase, mem_powerset]
    tauto
  -- weight identity
  have hweight : ∀ e B : Finset ℕ, (∀ p ∈ e, p.Prime ∧ allowedP F p) → B ⊆ e →
      bW F (primeSetProduct B) * bW (F * primeSetProduct B) (primeSetProduct (e \ B)) =
        finiteOmegaWeightReal e := by
    intro e B he hB
    have hBp : ∀ p ∈ B, p.Prime ∧ allowedP F p := fun p hp => he p (hB hp)
    have hCp : ∀ p ∈ e \ B, p.Prime ∧ allowedP F p := fun p hp => he p (mem_sdiff.mp hp).1
    rw [bW_mul_left F (primeSetProduct B), if_pos (coprime_primeSetProduct_disjoint (fun p hp => (hBp p hp).1)
      (fun p hp => (hCp p hp).1) disjoint_sdiff)]
    unfold primeSetProduct finiteOmegaWeightReal
    rw [bW_prod_primes F hBp, bW_prod_primes F hCp, mul_comm, prod_sdiff hB]
  -- reorganize both sides as single sums
  rw [sum_sigma']
  unfold pairWin
  rw [← sum_product']
  apply Finset.sum_bij_ne_zero (fun x _ _ => (primeSetProduct x.2, primeSetProduct (x.1 \ x.2)))
  · -- lands in the box
    rintro ⟨e, B⟩ hx hf
    rw [mem_sigma] at hx
    dsimp only at hx
    obtain ⟨he, hB⟩ := hx
    rw [hE] at he
    rw [hBmem] at hB
    have hep : ∀ p ∈ e, p.Prime := fun p hp => (he.1 p hp).2.1
    have hmul := primeSetProduct_sdiff_mul hB.1
    have h1 := primeSetProduct_pos' (fun p hp => hep p (hB.1 hp))
    have h2 := primeSetProduct_pos' (s := e \ B) (fun p hp => hep p (mem_sdiff.mp hp).1)
    have hU : primeSetProduct e ≤ U := by
      show primeSetProduct e ≤ H ^ 2 / 4
      rw [Nat.le_div_iff_mul_le (by norm_num)]; linarith [he.2.2]
    rw [mem_product, mem_Icc, mem_Icc]
    refine ⟨⟨h1, ?_⟩, ⟨h2, ?_⟩⟩
    · calc primeSetProduct B ≤ primeSetProduct B * primeSetProduct (e \ B) :=
            Nat.le_mul_of_pos_right _ h2
        _ ≤ U := hmul ▸ hU
    · calc primeSetProduct (e \ B) ≤ primeSetProduct B * primeSetProduct (e \ B) :=
            Nat.le_mul_of_pos_left _ h1
        _ ≤ U := hmul ▸ hU
  · -- injective
    rintro ⟨e1, B1⟩ hx1 _ ⟨e2, B2⟩ hx2 _ heq
    rw [mem_sigma, hE, hBmem] at hx1 hx2
    dsimp only at hx1 hx2
    simp only [Prod.mk.injEq] at heq
    have hp1 : ∀ p ∈ e1, p.Prime := fun p hp => (hx1.1.1 p hp).2.1
    have hp2 : ∀ p ∈ e2, p.Prime := fun p hp => (hx2.1.1 p hp).2.1
    have hB : B1 = B2 := by
      have := congrArg Nat.primeFactors heq.1
      unfold primeSetProduct at this
      rwa [Nat.primeFactors_prod (fun p hp => hp1 p (hx1.2.1 hp)),
        Nat.primeFactors_prod (fun p hp => hp2 p (hx2.2.1 hp))] at this
    have hC : e1 \ B1 = e2 \ B2 := by
      have := congrArg Nat.primeFactors heq.2
      unfold primeSetProduct at this
      rwa [Nat.primeFactors_prod (fun p hp => hp1 p (mem_sdiff.mp hp).1),
        Nat.primeFactors_prod (fun p hp => hp2 p (mem_sdiff.mp hp).1)] at this
    have he : e1 = e2 := by
      rw [← union_sdiff_of_subset hx1.2.1, ← union_sdiff_of_subset hx2.2.1, hC, hB]
    subst he; subst hB; rfl
  · -- surjective onto the nonzero terms
    rintro ⟨r, s⟩ hrs hg
    rw [mem_product, mem_Icc, mem_Icc] at hrs
    simp only at hg
    have hc : winC T U r s := by by_contra hc; exact hg (if_neg hc)
    rw [if_pos hc] at hg
    unfold pairTerm at hg
    have hrW : bW F r ≠ 0 := fun h0 => hg (by rw [h0]; ring)
    have hsW' : bW (F * r) s ≠ 0 := fun h0 => hg (by rw [h0]; ring)
    obtain ⟨hsW, hcop⟩ := bW_mul_ne_zero hsW'
    obtain ⟨hr0, hrsq, hrall⟩ := bW_ne_zero_imp hrW
    obtain ⟨hs0, hssq, hsall⟩ := bW_ne_zero_imp hsW
    have hrprod : primeSetProduct r.primeFactors = r := Nat.prod_primeFactors_of_squarefree hrsq
    have hsprod : primeSetProduct s.primeFactors = s := Nat.prod_primeFactors_of_squarefree hssq
    have hdisj : Disjoint r.primeFactors s.primeFactors := hcop.disjoint_primeFactors
    have hsd : (r.primeFactors ∪ s.primeFactors) \ r.primeFactors = s.primeFactors := by
      rw [union_sdiff_left, sdiff_eq_self_of_disjoint hdisj.symm]
    have heprod : primeSetProduct (r.primeFactors ∪ s.primeFactors) = r * s := by
      unfold primeSetProduct at hrprod hsprod ⊢
      rw [prod_union hdisj, hrprod, hsprod]
    obtain ⟨hr1, hs1, hT, hUb⟩ := hc
    have hmemE : r.primeFactors ∪ s.primeFactors ∈
        edrinR0051QuarterParents Z q h H d (H ^ 2 + 1) := by
      rw [hE]
      refine ⟨fun p hp => ?_, ?_, ?_⟩
      · have hpp : p.Prime := by
          rcases mem_union.mp hp with h' | h'
          · exact Nat.prime_of_mem_primeFactors h'
          · exact Nat.prime_of_mem_primeFactors h'
        have hal : allowedP F p := by
          rcases mem_union.mp hp with h' | h'
          · exact hrall p h'
          · exact hsall p h'
        have hle : p ≤ r * s := by
          rcases mem_union.mp hp with h' | h'
          · exact (Nat.le_of_dvd hr0.bot_lt (Nat.dvd_of_mem_primeFactors h')).trans
              (Nat.le_mul_of_pos_right _ hs0.bot_lt)
          · exact (Nat.le_of_dvd hs0.bot_lt (Nat.dvd_of_mem_primeFactors h')).trans
              (Nat.le_mul_of_pos_left _ hr0.bot_lt)
        have : U ≤ H ^ 2 := Nat.div_le_self _ _
        exact ⟨by omega, hpp, hal⟩
      · rw [heprod]; exact lt_of_le_of_lt (le_max_left _ _) hT
      · rw [heprod]
        have := (Nat.le_div_iff_mul_le (by norm_num : 0 < 4)).mp hUb
        linarith
    have hBm : r.primeFactors ∈ (((r.primeFactors ∪ s.primeFactors).powerset.erase
        (r.primeFactors ∪ s.primeFactors)).erase ∅) := by
      rw [hBmem]
      refine ⟨subset_union_left, ?_, ?_⟩
      · intro heq
        have hne : s.primeFactors.Nonempty := Nat.nonempty_primeFactors.mpr hs1
        obtain ⟨p, hp⟩ := hne
        have : p ∈ r.primeFactors := heq ▸ mem_union_right _ hp
        exact disjoint_left.mp hdisj this hp
      · intro h0
        have hne : r.primeFactors.Nonempty := Nat.nonempty_primeFactors.mpr hr1
        rw [h0] at hne; exact not_nonempty_empty hne
    refine ⟨⟨r.primeFactors ∪ s.primeFactors, r.primeFactors⟩, mem_sigma.mpr ⟨hmemE, hBm⟩, ?_, ?_⟩
    · simp only
      have hup : virelleR0037Upper h H (primeSetProduct r.primeFactors)
          (primeSetProduct ((r.primeFactors ∪ s.primeFactors) \ r.primeFactors)) := by
        rw [upper_iff_floor, hsd, hrprod, hsprod]
        exact lt_of_le_of_lt (le_max_right _ _) hT
      rw [if_pos hup]
      unfold edrinParentPairRow
      rw [hsd, hrprod, hsprod]
      have hall : ∀ p ∈ r.primeFactors ∪ s.primeFactors, p.Prime ∧ allowedP F p := by
        intro p hp
        rcases mem_union.mp hp with h' | h'
        · exact ⟨Nat.prime_of_mem_primeFactors h', hrall p h'⟩
        · exact ⟨Nat.prime_of_mem_primeFactors h', hsall p h'⟩
      have hw := hweight _ _ hall subset_union_left
      rw [hsd, hrprod, hsprod] at hw
      rw [← hw]
      show bW F r * bW (F * r) s * rowDisc w H r s ≠ 0
      exact hg
    · simp only [Prod.mk.injEq]
      rw [hsd, hrprod, hsprod]; exact ⟨rfl, rfl⟩
  · -- values agree
    rintro ⟨e, B⟩ hx hf
    rw [mem_sigma, hE, hBmem] at hx
    dsimp only at hx hf
    simp only
    have hup : virelleR0037Upper h H (primeSetProduct B) (primeSetProduct (e \ B)) := by
      by_contra hu; exact hf (if_neg hu)
    rw [if_pos hup]
    have hep : ∀ p ∈ e, p.Prime := fun p hp => (hx.1.1 p hp).2.1
    have hBne : B.Nonempty := nonempty_iff_ne_empty.mpr hx.2.2.2
    have hCne : (e \ B).Nonempty := by
      rw [sdiff_nonempty]
      intro hsub; exact hx.2.2.1 (Subset.antisymm hx.2.1 hsub)
    have hmul := primeSetProduct_sdiff_mul hx.2.1
    have hwin : winC T U (primeSetProduct B) (primeSetProduct (e \ B)) := by
      refine ⟨one_lt_primeSetProduct (fun p hp => hep p (hx.2.1 hp)) hBne,
        one_lt_primeSetProduct (fun p hp => hep p (mem_sdiff.mp hp).1) hCne, ?_, ?_⟩
      · show max (Z h) ⌊(H : ℝ) / vkM h⌋₊ < _
        rw [max_lt_iff]
        refine ⟨hmul ▸ hx.1.2.1, ?_⟩
        exact upper_iff_floor.mp hup
      · show _ ≤ H ^ 2 / 4
        rw [hmul, Nat.le_div_iff_mul_le (by norm_num)]; linarith [hx.1.2.2]
    rw [if_pos hwin]
    unfold edrinParentPairRow pairTerm
    rw [hweight e B (fun p hp => ⟨(hx.1.1 p hp).2.1, (hx.1.1 p hp).2.2⟩) hx.2.1]
    rfl

end OrielUpper
