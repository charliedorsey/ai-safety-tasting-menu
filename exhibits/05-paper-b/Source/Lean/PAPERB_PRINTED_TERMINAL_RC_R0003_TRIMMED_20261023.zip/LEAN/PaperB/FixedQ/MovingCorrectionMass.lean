import PaperB.FixedQ.PetermannCorrectionMoment
import PaperB.FixedQ.DivisorExpansion

open scoped BigOperators

namespace PaperB.FixedQ

lemma summable_petermannCorrectionPrimePower_signed
    {p : ℕ} (hp5 : 5 ≤ p) :
    Summable (fun nu : ℕ => petermannCorrectionPrimePower p nu) := by
  apply Summable.of_norm
  simpa [Real.norm_eq_abs] using
    (summable_abs_petermannCorrectionPrimePower hp5)

lemma tsum_petermannCorrectionPrimePower_eq
    {p : ℕ} (hp5 : 5 ≤ p) :
    (∑' nu : ℕ, petermannCorrectionPrimePower p nu) =
      1 - 1 / ((p : ℝ) - 2)^2 := by
  have hpR : (5 : ℝ) ≤ p := by exact_mod_cast hp5
  have hp3pos : 0 < (p : ℝ) - 3 := by linarith
  have hr0 : 0 ≤ 1 / ((p : ℝ) - 3) := by positivity
  have hr1 : 1 / ((p : ℝ) - 3) < 1 := by
    exact (div_lt_one hp3pos).2 (by linarith)
  have hs := summable_petermannCorrectionPrimePower_signed hp5
  rw [hs.tsum_eq_zero_add]
  simp [petermannCorrectionPrimePower_zero]
  rw [show (fun nu : ℕ => petermannCorrectionPrimePower p (nu + 1)) =
      fun nu => (petermannB p - petermannA p) * (-petermannA p)^nu by
    funext nu
    exact petermannCorrectionPrimePower_succ p nu]
  rw [tsum_mul_left]
  have hneg : |-petermannA p| < 1 := by
    unfold petermannA
    rw [abs_neg, abs_of_pos (one_div_pos.mpr hp3pos)]
    exact hr1
  rw [tsum_geometric_of_norm_lt_one hneg]
  unfold petermannA petermannB
  have hp2 : (p : ℝ) - 2 ≠ 0 := by linarith
  have hp3 : (p : ℝ) - 3 ≠ 0 := by linarith
  have hsumden : 1 + 1 / ((p : ℝ) - 3) ≠ 0 := by
    positivity
  field_simp [hp2, hp3, hsumden]
  ring_nf
  rw [show (-2 : ℝ) + (p : ℝ) = (p : ℝ) - 2 by ring]
  field_simp [hp2]
  ring

#print axioms tsum_petermannCorrectionPrimePower_eq

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem summable_petermannCorrectionArithmetic_signed
    (q h : ℕ) (hh : h ≠ 0) :
    Summable (fun n : ℕ => petermannCorrectionArithmetic q h n) := by
  apply Summable.of_norm
  simpa [Real.norm_eq_abs] using
    (summable_abs_petermannCorrectionArithmetic q h hh)

noncomputable def petermannCorrectionMass (q h : ℕ) : ℝ :=
  ∑' n : ℕ, petermannCorrectionArithmetic q h n

theorem petermannCorrectionMass_eq_prod
    (q h : ℕ) (hh : h ≠ 0) :
    petermannCorrectionMass q h =
      ∏ p ∈ petermannCorrectionPrimeSet q h,
        (1 - 1 / ((p : ℝ) - 2)^2) := by
  let s := petermannCorrectionPrimeSet q h
  let f : ℕ → ℝ := fun n => petermannCorrectionArithmetic q h n
  have hs := EulerProduct.summable_and_hasSum_factoredNumbers_prod_filter_prime_tsum
    (f := f)
    (by simp [f, petermannCorrectionArithmetic, petermannCorrectionCoeff])
    (fun {_m _n} hcop =>
      (petermannCorrectionArithmetic_multiplicative q h).map_mul_of_coprime hcop)
    (fun {_p} hp => by
      apply Summable.of_norm
      simpa [f, Real.norm_eq_abs] using
        summable_abs_petermannCorrectionArithmetic_prime_pow q h hp)
    s
  have hlocal :
      ∀ p ∈ s, (∑' nu : ℕ, f (p ^ nu)) =
        1 - 1 / ((p : ℝ) - 2)^2 := by
    intro p hp
    have hp5 : 5 ≤ p := by
      apply five_le_of_mem_petermannCorrectionPrimeSet
      simpa [s] using hp
    have hpeq :
        ∀ nu : ℕ, f (p ^ nu) = petermannCorrectionPrimePower p nu := by
      intro nu
      simp only [f]
      exact petermannCorrectionArithmetic_prime_pow_eq_of_mem
        (by simpa [s] using hp)
    rw [show (fun nu : ℕ => f (p ^ nu)) =
        fun nu => petermannCorrectionPrimePower p nu by
      funext nu
      exact hpeq nu]
    exact tsum_petermannCorrectionPrimePower_eq hp5
  have hprime : ∀ p ∈ s, p.Prime := by
    intro p hp
    apply prime_of_mem_petermannCorrectionPrimeSet
    simpa [s] using hp
  have hprod :
      (∏ p ∈ s with p.Prime, ∑' nu : ℕ, f (p ^ nu)) =
        ∏ p ∈ s, (1 - 1 / ((p : ℝ) - 2)^2) := by
    rw [Finset.filter_eq_self.mpr hprime]
    apply Finset.prod_congr rfl
    intro p hp
    exact hlocal p hp
  have hsubtsum :
      (∑' m : Nat.factoredNumbers s, f m) =
        ∏ p ∈ s, (1 - 1 / ((p : ℝ) - 2)^2) := by
    rw [← hprod]
    exact hs.2.tsum_eq
  unfold petermannCorrectionMass
  calc
    (∑' n : ℕ, petermannCorrectionArithmetic q h n)
      = ∑' n : ℕ, f n := rfl
    _ = ∑' m : Nat.factoredNumbers s, f m := by
      rw [tsum_subtype]
      apply tsum_congr
      intro n
      by_cases hnmem : n ∈ Nat.factoredNumbers s
      · simp [Set.indicator, hnmem, f]
      · have hz : petermannCorrectionArithmetic q h n = 0 := by
          apply petermannCorrectionArithmetic_eq_zero_of_not_factored hh
          simpa [s] using hnmem
        have hz' : petermannCorrectionCoeff q h n = 0 := by
          simpa [petermannCorrectionArithmetic_apply] using hz
        simp [Set.indicator, hnmem, f, hz, hz',
          petermannCorrectionArithmetic_apply]
    _ = ∏ p ∈ s, (1 - 1 / ((p : ℝ) - 2)^2) := hsubtsum
    _ = ∏ p ∈ petermannCorrectionPrimeSet q h,
          (1 - 1 / ((p : ℝ) - 2)^2) := by rfl

#print axioms petermannCorrectionMass_eq_prod

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def petermannSignedLocalFactor (q h p : ℕ) : ℝ :=
  if p ∈ petermannCorrectionPrimeSet q h then
    1 - 1 / ((p : ℝ) - 2)^2
  else 1

theorem normalizationBaseline_mul_signedLocalFactor
    (q h p : ℕ) (hh : h ≠ 0) :
    normalizationBaseline q h p * petermannSignedLocalFactor q h p =
      normalizationBaseline q 1 p := by
  by_cases ha : p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q
  · have hp := ha.1
    have hp5 := ha.2.1
    have hp0 : (p : ℝ) ≠ 0 := by exact_mod_cast hp.ne_zero
    have hp1 : (p : ℝ) - 1 ≠ 0 := by
      exact sub_ne_zero.mpr (by exact_mod_cast (show p ≠ 1 by omega))
    have hp2 : (p : ℝ) - 2 ≠ 0 := by
      exact sub_ne_zero.mpr (by exact_mod_cast (show p ≠ 2 by omega))
    have hp3 : (p : ℝ) - 3 ≠ 0 := by
      exact sub_ne_zero.mpr (by exact_mod_cast (show p ≠ 3 by omega))
    have hcop : p.Coprime (6 * q) := by
      apply hp.coprime_iff_not_dvd.mpr
      intro hd
      rcases hp.dvd_mul.mp hd with h6 | hq
      · have hp6 : p ∣ 2 * 3 := by simpa using h6
        rcases hp.dvd_mul.mp hp6 with h2 | h3
        · have : p ≤ 2 := Nat.le_of_dvd (by norm_num) h2
          omega
        · have : p ≤ 3 := Nat.le_of_dvd (by norm_num) h3
          omega
      · exact ha.2.2 hq
    by_cases hph : p ∣ h
    · have hmem : p ∈ petermannCorrectionPrimeSet q h := by
        rw [mem_petermannCorrectionPrimeSet_iff]
        exact ⟨Nat.mem_primeFactors.mpr ⟨hp, hph, hh⟩, hcop⟩
      have hpnot1 : ¬ p ∣ 1 := hp.not_dvd_one
      rw [petermannSignedLocalFactor, if_pos hmem]
      simp [normalizationBaseline, ha, hph, hpnot1]
      field_simp [hp0, hp1, hp2, hp3]
      ring
    · have hnotmem : p ∉ petermannCorrectionPrimeSet q h := by
        intro hm
        exact hph (dvd_height_of_mem_petermannCorrectionPrimeSet hm)
      have hpnot1 : ¬ p ∣ 1 := hp.not_dvd_one
      simp [petermannSignedLocalFactor, hnotmem,
        normalizationBaseline, ha, hph, hpnot1]
  · have hnotmem : p ∉ petermannCorrectionPrimeSet q h := by
      intro hm
      have hp := prime_of_mem_petermannCorrectionPrimeSet hm
      have hp5 := five_le_of_mem_petermannCorrectionPrimeSet hm
      have hcop := coprime_of_mem_petermannCorrectionPrimeSet hm
      have hpq : ¬ p ∣ q := by
        intro hd
        exact (hp.coprime_iff_not_dvd.mp hcop)
          (dvd_mul_of_dvd_right hd 6)
      exact ha ⟨hp, hp5, hpq⟩
    simp [petermannSignedLocalFactor, hnotmem,
      normalizationBaseline, ha]

#print axioms normalizationBaseline_mul_signedLocalFactor

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem cStar_mul_petermannCorrectionMass_eq_cStar_one
    (q h : ℕ) (hh : h ≠ 0) :
    cStarReal q h * petermannCorrectionMass q h =
      cStarReal q 1 := by
  let s := petermannCorrectionPrimeSet q h
  let g : ℕ → ℝ := fun p => 1 - 1 / ((p : ℝ) - 2)^2
  let F : ℕ → ℝ := (s : Set ℕ).mulIndicator g
  have hF :
      ∀ p : ℕ, F p = petermannSignedLocalFactor q h p := by
    intro p
    by_cases hp : p ∈ s
    · simp [F, g, petermannSignedLocalFactor, s, hp]
    · simp [F, g, petermannSignedLocalFactor, s, hp]
  have hfinite : Function.HasFiniteMulSupport F := by
    rw [Function.HasFiniteMulSupport]
    rw [show Function.mulSupport F =
        (s : Set ℕ) ∩ Function.mulSupport g by
      simpa [F] using (Set.mulSupport_mulIndicator
        (s := (s : Set ℕ)) (f := g))]
    exact Set.Finite.subset s.finite_toSet (by
      intro p hp
      exact hp.1)
  have hmultF : Multipliable F :=
    multipliable_of_hasFiniteMulSupport hfinite
  have hb := multipliable_normalizationBaseline' q h
  have hprod :
      petermannCorrectionMass q h = ∏' p : ℕ, F p := by
    rw [petermannCorrectionMass_eq_prod q h hh]
    rw [prod_eq_tprod_mulIndicator]
  unfold cStarReal
  rw [hprod, ← hb.tprod_mul hmultF]
  apply tprod_congr
  intro p
  rw [hF]
  exact normalizationBaseline_mul_signedLocalFactor q h p hh

#print axioms cStar_mul_petermannCorrectionMass_eq_cStar_one

end PaperB.FixedQ
