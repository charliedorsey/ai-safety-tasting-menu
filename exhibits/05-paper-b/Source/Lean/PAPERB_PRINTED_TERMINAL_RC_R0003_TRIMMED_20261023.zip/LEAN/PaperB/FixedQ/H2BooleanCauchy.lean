import PaperB.FixedQ.TwoDimensionalClosure

open scoped BigOperators

namespace PaperB.FixedQ

/-- Source parameter a = 1 - 0.99/2 = 0.505, represented exactly. -/
noncomputable def h2BooleanA0 : ℝ := 101 / 200

/-- First reciprocal Cauchy tilt from the audited Boolean/Shiu ledger. -/
noncomputable def h2BooleanX0 : ℝ := 2 * Real.sqrt h2BooleanA0

/-- Second reciprocal Cauchy tilt from the audited Boolean/Shiu ledger. -/
noncomputable def h2BooleanV0 : ℝ := 2 / Real.sqrt h2BooleanA0

lemma h2BooleanA0_pos : 0 < h2BooleanA0 := by
  norm_num [h2BooleanA0]

lemma h2BooleanX0_nonneg : 0 ≤ h2BooleanX0 := by
  unfold h2BooleanX0
  positivity

lemma h2BooleanV0_nonneg : 0 ≤ h2BooleanV0 := by
  unfold h2BooleanV0
  positivity

lemma h2BooleanX0_mul_V0 : h2BooleanX0 * h2BooleanV0 = 4 := by
  unfold h2BooleanX0 h2BooleanV0
  have hs : Real.sqrt h2BooleanA0 ≠ 0 := by
    exact ne_of_gt (Real.sqrt_pos.2 h2BooleanA0_pos)
  field_simp [hs]
  ring

/-- Exact finite weighted Cauchy inequality used by the ordinary Boolean
consumer. The two tilts are left abstract except for x*v=4. -/
theorem ordinaryBooleanWeightedCauchy
    (F : Finset (Finset ℕ)) (D : Finset ℕ → ℝ)
    (x v : ℝ) (hx : 0 ≤ x) (hv : 0 ≤ v) (hxv : x * v = 4)
    (hw : ∀ e ∈ F, 0 ≤ finiteOmegaWeightReal e) :
    (∑ e ∈ F,
        finiteOmegaWeightReal e * (2 : ℝ) ^ e.card * |D e|) ^ 2 ≤
      (∑ e ∈ F, finiteOmegaWeightReal e * x ^ e.card) *
      (∑ e ∈ F,
        finiteOmegaWeightReal e * v ^ e.card * |D e| ^ 2) := by
  let r : Finset ℕ → ℝ := fun e =>
    finiteOmegaWeightReal e * (2 : ℝ) ^ e.card * |D e|
  let f : Finset ℕ → ℝ := fun e =>
    finiteOmegaWeightReal e * x ^ e.card
  let g : Finset ℕ → ℝ := fun e =>
    finiteOmegaWeightReal e * v ^ e.card * |D e| ^ 2
  have hf : ∀ e ∈ F, 0 ≤ f e := by
    intro e he
    exact mul_nonneg (hw e he) (pow_nonneg hx _)
  have hg : ∀ e ∈ F, 0 ≤ g e := by
    intro e he
    exact mul_nonneg
      (mul_nonneg (hw e he) (pow_nonneg hv _))
      (sq_nonneg _)
  have ht : ∀ e ∈ F, (r e) ^ 2 = f e * g e := by
    intro e he
    dsimp [r, f, g]
    have htwo : ((2 : ℝ) ^ e.card) ^ 2 = (4 : ℝ) ^ e.card := by
      calc
        ((2 : ℝ) ^ e.card) ^ 2 = (2 : ℝ) ^ (e.card * 2) := by rw [pow_mul]
        _ = (2 : ℝ) ^ (2 * e.card) := by rw [Nat.mul_comm]
        _ = ((2 : ℝ) ^ 2) ^ e.card := by rw [pow_mul]
        _ = (4 : ℝ) ^ e.card := by norm_num
    have htilt : x ^ e.card * v ^ e.card = (4 : ℝ) ^ e.card := by
      rw [← mul_pow, hxv]
    rw [mul_pow, mul_pow, htwo]
    rw [← htilt]
    ring
  simpa [r, f, g] using
    (Finset.sum_sq_le_sum_mul_sum_of_sq_eq_mul F hf hg ht)

/-- Consumer-specialized reciprocal-tilt Cauchy inequality at the audited
Boolean optimizer. -/
theorem ordinaryBooleanWeightedCauchy_source_tilts
    (F : Finset (Finset ℕ)) (D : Finset ℕ → ℝ)
    (hw : ∀ e ∈ F, 0 ≤ finiteOmegaWeightReal e) :
    (∑ e ∈ F,
        finiteOmegaWeightReal e * (2 : ℝ) ^ e.card * |D e|) ^ 2 ≤
      (∑ e ∈ F,
        finiteOmegaWeightReal e * h2BooleanX0 ^ e.card) *
      (∑ e ∈ F,
        finiteOmegaWeightReal e * h2BooleanV0 ^ e.card * |D e| ^ 2) := by
  exact ordinaryBooleanWeightedCauchy
    F D h2BooleanX0 h2BooleanV0
    h2BooleanX0_nonneg h2BooleanV0_nonneg h2BooleanX0_mul_V0 hw

#print axioms ordinaryBooleanWeightedCauchy
#print axioms ordinaryBooleanWeightedCauchy_source_tilts

end PaperB.FixedQ
