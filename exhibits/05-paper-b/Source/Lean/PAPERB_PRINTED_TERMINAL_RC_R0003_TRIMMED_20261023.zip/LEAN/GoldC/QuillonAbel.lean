import Mathlib.Analysis.Complex.Basic
import Mathlib.Tactic

/-!
# Quillon CSC3 F5c: Abel summation with a bounded-variation amplitude

For `N ≤ M`, sequences `A b : ℕ → ℂ`, and partial sums `B(j) = Σ_{n∈(N,j]} b n`:

    Σ_{n∈(N,M]} A n · b n = A M · B M − Σ_{n∈[N+1, M)} (A (n+1) − A n) · B n      (exact)

Hence, if `‖B j‖ ≤ β` for all `j`,

    ‖Σ_{n∈(N,M]} A n · b n‖ ≤ (‖A M‖ + Σ_{n∈[N+1,M)} ‖A(n+1) − A n‖) · β.

This is used by the R route: the exact DFT coefficients `a_{vu}(k)` depend on `u`, and they enter
the Cauchy-expanded `u`-sum as an amplitude of bounded variation. The VK bound applies to every
initial segment `(N, j]`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonAbel

/-- Partial sums from `N`. -/
noncomputable def psum (b : ℕ → ℂ) (N j : ℕ) : ℂ := ∑ n ∈ Ioc N j, b n

theorem abel_identity (A b : ℕ → ℂ) (N : ℕ) :
    ∀ M, N ≤ M → ∑ n ∈ Ioc N M, A n * b n =
      A M * psum b N M - ∑ n ∈ Ico (N + 1) M, (A (n + 1) - A n) * psum b N n := by
  intro M hM
  induction M, hM using Nat.le_induction with
  | base => simp [psum]
  | succ M hNM ih =>
    have hsplit : Ioc N (M + 1) = insert (M + 1) (Ioc N M) := by
      ext x; simp only [mem_Ioc, mem_insert]; omega
    have hnot : M + 1 ∉ Ioc N M := by simp
    have hpsum : psum b N (M + 1) = psum b N M + b (M + 1) := by
      unfold psum; rw [hsplit, sum_insert hnot]; ring
    rw [hsplit, sum_insert hnot, ih, hpsum]
    rcases Nat.eq_or_lt_of_le hNM with h | h
    · subst h
      have h0 : psum b N N = 0 := by simp [psum]
      simp [h0]
    · have hIco : Ico (N + 1) (M + 1) = insert M (Ico (N + 1) M) := by
        ext x; simp only [mem_Ico, mem_insert]; omega
      have hnot' : M ∉ Ico (N + 1) M := by simp
      rw [hIco, sum_insert hnot']
      ring

theorem abel_bound (A b : ℕ → ℂ) (N M : ℕ) (hNM : N ≤ M) (β : ℝ)
    (hB : ∀ j, N ≤ j → j ≤ M → ‖psum b N j‖ ≤ β) :
    ‖∑ n ∈ Ioc N M, A n * b n‖ ≤
      (‖A M‖ + ∑ n ∈ Ico (N + 1) M, ‖A (n + 1) - A n‖) * β := by
  rw [abel_identity A b N M hNM]
  have hβ : 0 ≤ β := (norm_nonneg _).trans (hB N le_rfl hNM)
  refine (norm_sub_le _ _).trans ?_
  rw [add_mul, Finset.sum_mul]
  refine add_le_add ?_ ?_
  · rw [norm_mul]; exact mul_le_mul_of_nonneg_left (hB M hNM le_rfl) (norm_nonneg _)
  · refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun n hn => ?_)
    rw [Finset.mem_Ico] at hn
    rw [norm_mul]
    exact mul_le_mul_of_nonneg_left (hB n (by omega) hn.2.le) (norm_nonneg _)

/-- Variation of a monotone real sequence telescopes. -/
lemma variation_monotone (f : ℕ → ℝ) (N M : ℕ) (hNM : N + 1 ≤ M)
    (hmono : ∀ n, N + 1 ≤ n → n < M → f n ≤ f (n + 1)) :
    ∑ n ∈ Ico (N + 1) M, ‖((f (n + 1) : ℂ) - f n)‖ = f M - f (N + 1) := by
  induction M, hNM using Nat.le_induction with
  | base => simp
  | succ M hM ih =>
    rw [Finset.sum_Ico_succ_top hM, ih (fun n h1 h2 => hmono n h1 (by omega))]
    have := hmono M hM (by omega)
    rw [← Complex.ofReal_sub, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (by linarith)]
    ring

lemma variation_antitone (f : ℕ → ℝ) (N M : ℕ) (hNM : N + 1 ≤ M)
    (hmono : ∀ n, N + 1 ≤ n → n < M → f (n + 1) ≤ f n) :
    ∑ n ∈ Ico (N + 1) M, ‖((f (n + 1) : ℂ) - f n)‖ = f (N + 1) - f M := by
  have := variation_monotone (fun n => -f n) N M hNM (fun n h1 h2 => by
    simp only [neg_le_neg_iff]; exact hmono n h1 h2)
  simp only [Complex.ofReal_neg] at this
  have e : f (N + 1) - f M = -f M - -f (N + 1) := by ring
  rw [e, ← this]
  refine Finset.sum_congr rfl fun n _ => ?_
  rw [← norm_neg]; congr 1; ring

end GoldC.QuillonAbel

#print axioms GoldC.QuillonAbel.abel_identity
#print axioms GoldC.QuillonAbel.abel_bound
#print axioms GoldC.QuillonAbel.variation_monotone
#print axioms GoldC.QuillonAbel.variation_antitone
