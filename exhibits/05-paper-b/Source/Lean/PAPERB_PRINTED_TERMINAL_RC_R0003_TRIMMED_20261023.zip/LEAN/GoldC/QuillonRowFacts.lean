import GoldC.QuillonCoef
import GoldC.QuillonEv

/-!
# Quillon CSC3 F8.5: the source row data for the fixed-`s` route bounds

For `M = 6q`, `μ = meanWeight`, `Γ = gammaClass` (`|μ| ≤ 4`, `|Γ| ≤ 48q`):

* `coef_main`, `coef_mainN`, `coef_cls`, `coef_clsN`: the four `rowW` coefficients satisfy
  `‖A ρ j‖ ≤ 300q²/j`.
* `hc_main`, `hc_mainN`, `hc_cls`, `hc_clsN`: their gcd sets are `{p ∈ C : p ∣ j}`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonRowFacts

open GoldC.QuillonRowNF GoldC.QuillonCoef

lemma coef_main (q : ℕ) (hq : 0 < q) (μ : ℝ) (hμ : |μ| ≤ 4) (s : ℕ) (hs : 1 ≤ s) (M : ℕ) :
    ∀ (ρ : ZMod M) j, 1 ≤ j → ‖((-(2 * μ) : ℝ) : ℂ) * αm j s‖ ≤ (300 * (q : ℝ) ^ 2) / j := by
  intro ρ j hj
  have h1 := norm_main_le μ j s hj hs
  have hjR : (0 : ℝ) < j := by exact_mod_cast hj
  have hq1 : (1 : ℝ) ≤ q := by exact_mod_cast hq
  refine h1.trans (div_le_div_of_nonneg_right ?_ hjR.le)
  nlinarith

lemma coef_mainN (q : ℕ) (hq : 0 < q) (μ : ℝ) (hμ : |μ| ≤ 4) (s : ℕ) (hs : 1 ≤ s) (M : ℕ) :
    ∀ (ρ : ZMod M) j, 1 ≤ j → ‖-(((-(2 * μ) : ℝ) : ℂ) * αm j s)‖ ≤ (300 * (q : ℝ) ^ 2) / j := by
  intro ρ j hj; rw [norm_neg]; exact coef_main q hq μ hμ s hs M ρ j hj

lemma coef_cls (q : ℕ) (hq : 0 < q) (Γ : ℕ → ℕ → ℝ) (hΓ : ∀ b ν, |Γ b ν| ≤ 48 * q) (s : ℕ)
    (hs : 1 ≤ s) (zf : ℕ → ℤ) :
    ∀ (ρ : ZMod (6 * q)) j, 1 ≤ j →
      ‖αm j ((6 * q) * s) * BclS (6 * q) Γ s (zf j) ρ‖ ≤ (300 * (q : ℝ) ^ 2) / j := by
  intro ρ j hj
  have hMs : 1 ≤ (6 * q) * s := by nlinarith
  have h1 := norm_class_le (6 * q) Γ (48 * q) hΓ s j (zf j) ρ hj hMs
  have hjR : (0 : ℝ) < j := by exact_mod_cast hj
  refine h1.trans (div_le_div_of_nonneg_right ?_ hjR.le)
  push_cast; nlinarith

lemma coef_clsN (q : ℕ) (hq : 0 < q) (Γ : ℕ → ℕ → ℝ) (hΓ : ∀ b ν, |Γ b ν| ≤ 48 * q) (s : ℕ)
    (hs : 1 ≤ s) (zf : ℕ → ℤ) :
    ∀ (ρ : ZMod (6 * q)) j, 1 ≤ j →
      ‖-(αm j ((6 * q) * s) * BclS (6 * q) Γ s (zf j) ρ)‖ ≤ (300 * (q : ℝ) ^ 2) / j := by
  intro ρ j hj; rw [norm_neg]; exact coef_cls q hq Γ hΓ s hs zf ρ j hj

lemma hc_gen {s : ℕ} (C : Finset ℕ) (hC : ∀ p ∈ C, p.Prime) (hsC : s = ∏ p ∈ C, p) (u : ℤ)
    (hu : ∀ p ∈ C, ¬ (p : ℤ) ∣ u) (σ : ℤ) (hσ : σ = 1 ∨ σ = -1) (c : ℕ → ZMod s)
    (hcdef : ∀ j, c j = ((((σ * j) * u : ℤ)) : ZMod s)) :
    ∀ j, 1 ≤ j → C.filter (fun p => (ZMod.cast (c j) : ZMod p) = 0) = C.filter (fun p => p ∣ j) := by
  intro j _
  simp only [hcdef]
  exact filter_cast_eq C hC hsC u hu σ hσ j

lemma not_dvd_H {C : Finset ℕ} {H : ℕ} (hC : ∀ p ∈ C, p.Prime ∧ p.Coprime H) :
    ∀ p ∈ C, ¬ (p : ℤ) ∣ (H : ℤ) := by
  intro p hp hd
  have hd' : p ∣ H := Int.natCast_dvd_natCast.1 hd
  have := Nat.Coprime.eq_one_of_dvd (hC p hp).2 hd'
  exact (hC p hp).1.one_lt.ne' this

lemma not_dvd_HinvM {C : Finset ℕ} {H M s : ℕ} (hC : ∀ p ∈ C, p.Prime ∧ p.Coprime H)
    (hsC : s = ∏ p ∈ C, p) (hs : 2 ≤ s) (hMs : M.Coprime s) :
    ∀ p ∈ C, ¬ (p : ℤ) ∣ ((H : ℤ) * (GoldC.QuillonCopyC.invMod M s : ℤ)) := by
  intro p hp hd
  have hpp := (hC p hp).1
  rcases Int.Prime.dvd_mul' hpp hd with h1 | h1
  · exact not_dvd_H hC p hp h1
  · have h1' : p ∣ GoldC.QuillonCopyC.invMod M s := Int.natCast_dvd_natCast.1 h1
    have hps : p ∣ s := hsC ▸ dvd_prod_of_mem _ hp
    have hmod := GoldC.QuillonCopyC.mul_invMod_modEq hs hMs
    have : p ∣ M * GoldC.QuillonCopyC.invMod M s := Dvd.dvd.mul_left h1' M
    have h2 : M * GoldC.QuillonCopyC.invMod M s ≡ 1 [MOD p] := Nat.ModEq.of_dvd hps hmod
    have h3 : 1 % p = 0 := by
      rw [Nat.ModEq] at h2; rw [← h2]; exact Nat.eq_zero_of_dvd_of_lt (by
        exact (Nat.dvd_mod_iff (dvd_refl p)).2 this) (Nat.mod_lt _ hpp.pos) |>.symm ▸ rfl
    rw [Nat.one_mod_eq_zero_iff] at h3
    exact hpp.one_lt.ne' h3

end GoldC.QuillonRowFacts

#print axioms GoldC.QuillonRowFacts.coef_cls
#print axioms GoldC.QuillonRowFacts.hc_gen
#print axioms GoldC.QuillonRowFacts.not_dvd_HinvM
