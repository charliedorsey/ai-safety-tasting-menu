import PaperB.Analytic.PetermannEtaHarmonicShellPower

open scoped BigOperators

namespace PaperB.Analytic

open Real Finset Nat

private lemma eta_geom_sum_contract2
    {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) (M : ℕ) :
    (∑ i ∈ Finset.range M, q ^ i) ≤ 1 / (1 - q) := by
  have hqne : q ≠ 1 := ne_of_lt hq1
  have hden : 0 < 1 - q := sub_pos.mpr hq1
  have hgeom :
      (∑ i ∈ Finset.range M, q ^ i) =
        (1 - q ^ M) / (1 - q) := by
    calc
      _ = (q ^ M - 1) / (q - 1) := geom_sum_eq hqne M
      _ = _ := by
        field_simp [hqne]
        ring
  rw [hgeom]
  have hp : 0 ≤ q ^ M := pow_nonneg hq0 M
  exact (div_le_div_iff_of_pos_right hden).2 (by linarith)

private lemma eta_geom_sum_growing_endpoint2
    {x r : ℝ} {M : ℕ}
    (hx : 0 ≤ x) (hr : 1 < r) (hM : 0 < M)
    (hlast : x * r ^ (M - 1) ≤ 1) :
    x * (∑ i ∈ Finset.range M, r ^ i) ≤ r / (r - 1) := by
  have hrne : r ≠ 1 := ne_of_gt hr
  have hden : 0 < r - 1 := sub_pos.mpr hr
  have hgeom :
      (∑ i ∈ Finset.range M, r ^ i) =
        (r ^ M - 1) / (r - 1) := geom_sum_eq hrne M
  rw [hgeom]
  have hr0 : 0 ≤ r := le_trans (by norm_num) hr.le
  have hpowM : x * r ^ M ≤ r := by
    have hMsplit : M = (M - 1) + 1 := by omega
    rw [hMsplit, pow_add, pow_one]
    calc
      x * (r ^ (M - 1) * r)
        = (x * r ^ (M - 1)) * r := by ring
      _ ≤ 1 * r := mul_le_mul_of_nonneg_right hlast hr0
      _ = r := by ring
  have hnum : r ^ M - 1 ≤ r ^ M := by linarith
  calc
    x * ((r ^ M - 1) / (r - 1))
      ≤ x * (r ^ M / (r - 1)) := by gcongr
    _ = (x * r ^ M) / (r - 1) := by ring
    _ ≤ r / (r - 1) :=
      (div_le_div_iff_of_pos_right hden).2 hpowM

noncomputable def etaShellP (k : ℕ) : ℝ :=
  (k + 1 : ℝ) * fixedBetaA k

noncomputable def etaShellQ (k : ℕ) : ℝ :=
  (2 : ℝ) ^ (-(etaShellP k))

noncomputable def etaShellR (k : ℕ) : ℝ :=
  (2 : ℝ) ^ (etaShellDelta k)

lemma etaShellP_pos {k : ℕ} (hk : 2 ≤ k) :
    0 < etaShellP k := by
  unfold etaShellP
  exact mul_pos (by positivity) (fixedBetaA_pos hk)

lemma etaShellQ_mem_Ioo {k : ℕ} (hk : 2 ≤ k) :
    0 < etaShellQ k ∧ etaShellQ k < 1 := by
  constructor
  · unfold etaShellQ
    exact Real.rpow_pos_of_pos (by norm_num) _
  · unfold etaShellQ
    have hp := etaShellP_pos hk
    exact Real.rpow_lt_one_of_one_lt_of_neg (by norm_num) (by linarith)

lemma etaShellR_gt_one {k : ℕ} (hk : 2 ≤ k) :
    1 < etaShellR k := by
  unfold etaShellR
  exact Real.one_lt_rpow (by norm_num) (etaShellDelta_pos hk)

lemma eta_dyadic_rpow2
    {W e : ℝ} (hW : 0 ≤ W) (i : ℕ) :
    (W * ((2 ^ i : ℕ) : ℝ)) ^ e =
      W ^ e * (((2 : ℝ) ^ e) ^ i) := by
  have htwo : 0 ≤ (((2 ^ i : ℕ) : ℝ)) := by positivity
  rw [Real.mul_rpow hW htwo]
  congr 1
  rw [Nat.cast_pow, Nat.cast_ofNat]
  rw [← Real.rpow_natCast]
  rw [← Real.rpow_mul (by norm_num : (0 : ℝ) ≤ 2)]
  rw [mul_comm]
  rw [Real.rpow_mul (by norm_num : (0 : ℝ) ≤ 2)]
  rw [Real.rpow_natCast]

lemma eta_dyadic_reciprocal2
    {W : ℝ} (hW : 0 < W) (i : ℕ) :
    2 / (W * ((2 ^ i : ℕ) : ℝ)) =
      (2 / W) * ((1 / 2 : ℝ) ^ i) := by
  rw [Nat.cast_pow, Nat.cast_ofNat]
  have htwo : (2 : ℝ) ≠ 0 := by norm_num
  field_simp [hW.ne', htwo]
  rw [← mul_pow]
  norm_num

noncomputable def etaPowerBandGeomConst (k H : ℕ) : ℝ :=
  4 +
    etaShellC1 k H / (1 - etaShellQ k) +
    etaShellC2 k * etaShellR k / (etaShellR k - 1)

theorem eta_power_band_majorant_geometric_sum
    {k H M : ℕ} (hk : 2 ≤ k)
    {A W : ℝ} (hA : 0 < A) (hW1 : 1 ≤ W)
    (hfirst0 :
      A ^ fixedBetaA k *
        W ^ (-(etaShellP k)) ≤ 1)
    (hlast0 :
      A ^ (-(fixedBetaA k)) *
        (W * ((2 ^ (M - 1) : ℕ) : ℝ)) ^ etaShellDelta k ≤ 1) :
    (∑ i ∈ Finset.range M,
      (2 / (W * ((2 ^ i : ℕ) : ℝ)) +
        etaShellC1 k H * A ^ fixedBetaA k *
          (W * ((2 ^ i : ℕ) : ℝ)) ^ (-(etaShellP k)) +
        etaShellC2 k * A ^ (-(fixedBetaA k)) *
          (W * ((2 ^ i : ℕ) : ℝ)) ^ etaShellDelta k))
      ≤ etaPowerBandGeomConst k H := by
  have hW : 0 < W := lt_of_lt_of_le (by norm_num) hW1
  have hW0 : 0 ≤ W := hW.le
  have hq := etaShellQ_mem_Ioo hk
  have hr := etaShellR_gt_one hk
  have hCk0 : 0 ≤ reciprocalFiniteOrderConst k :=
    le_trans (by norm_num) (reciprocalFiniteOrderConst_ge_one k)
  have hC10 : 0 ≤ etaShellC1 k H := by
    unfold etaShellC1
    exact mul_nonneg
      (mul_nonneg (by norm_num) hCk0)
      (Real.rpow_nonneg
        (mul_nonneg (by positivity) (fixedBetaUpperConst_pos k).le) _)
  have hC20 : 0 ≤ etaShellC2 k := by
    unfold etaShellC2
    exact mul_nonneg
      (mul_nonneg (by norm_num) hCk0)
      (Real.rpow_nonneg (fixedBetaLowerConst_pos k).le _)
  by_cases hM0 : M = 0
  · subst M
    simp only [Finset.range_zero, Finset.sum_empty]
    unfold etaPowerBandGeomConst
    have hdq : 0 < 1 - etaShellQ k := sub_pos.mpr hq.2
    have hdr : 0 < etaShellR k - 1 := sub_pos.mpr hr
    have ht1 : 0 ≤ etaShellC1 k H / (1 - etaShellQ k) :=
      div_nonneg hC10 hdq.le
    have hr0 : 0 ≤ etaShellR k := le_trans (by norm_num) hr.le
    have ht2 :
        0 ≤ etaShellC2 k * etaShellR k / (etaShellR k - 1) :=
      div_nonneg (mul_nonneg hC20 hr0) hdr.le
    linarith
  · have hM : 0 < M := Nat.pos_of_ne_zero hM0
    have hsumhalf := eta_geom_sum_contract2 (q := (1 / 2 : ℝ))
      (by norm_num) (by norm_num) M
    norm_num at hsumhalf
    have hcoef : 2 / W ≤ 2 := by
      rw [div_le_iff₀ hW]
      nlinarith
    have hS0 :
        (∑ i ∈ Finset.range M,
          2 / (W * ((2 ^ i : ℕ) : ℝ))) ≤ 4 := by
      simp_rw [eta_dyadic_reciprocal2 hW]
      rw [← Finset.mul_sum]
      calc
        (2 / W) * (∑ i ∈ Finset.range M, (1 / 2 : ℝ) ^ i)
          ≤ 2 * (∑ i ∈ Finset.range M, (1 / 2 : ℝ) ^ i) := by
            gcongr
        _ ≤ 2 * 2 := by gcongr
        _ = 4 := by norm_num
    have hSq := eta_geom_sum_contract2 hq.1.le hq.2 M
    have hSq0 :
        0 ≤ ∑ i ∈ Finset.range M, etaShellQ k ^ i :=
      Finset.sum_nonneg (fun i hi => pow_nonneg hq.1.le i)
    have hS1 :
        (∑ i ∈ Finset.range M,
          etaShellC1 k H * A ^ fixedBetaA k *
            (W * ((2 ^ i : ℕ) : ℝ)) ^ (-(etaShellP k)))
          ≤ etaShellC1 k H / (1 - etaShellQ k) := by
      have hscale : ∀ i : ℕ,
          (W * ((2 ^ i : ℕ) : ℝ)) ^ (-(etaShellP k)) =
            W ^ (-(etaShellP k)) * etaShellQ k ^ i := by
        intro i
        simpa [etaShellQ] using
          (eta_dyadic_rpow2 (W := W) (e := -(etaShellP k)) hW0 i)
      simp_rw [hscale]
      rw [← Finset.mul_sum]
      rw [← Finset.mul_sum]
      have hx :
          A ^ fixedBetaA k * W ^ (-(etaShellP k)) *
              (∑ i ∈ Finset.range M, etaShellQ k ^ i)
            ≤
          (∑ i ∈ Finset.range M, etaShellQ k ^ i) := by
        simpa [one_mul] using
          (mul_le_mul_of_nonneg_right hfirst0 hSq0)
      calc
        etaShellC1 k H * A ^ fixedBetaA k *
            (W ^ (-(etaShellP k)) *
              ∑ i ∈ Finset.range M, etaShellQ k ^ i)
          =
        etaShellC1 k H *
            (A ^ fixedBetaA k *
              (W ^ (-(etaShellP k)) *
                ∑ i ∈ Finset.range M, etaShellQ k ^ i)) := by ring
        _ =
        etaShellC1 k H *
            ((A ^ fixedBetaA k * W ^ (-(etaShellP k))) *
              (∑ i ∈ Finset.range M, etaShellQ k ^ i)) := by ring
        _ ≤ etaShellC1 k H *
            (∑ i ∈ Finset.range M, etaShellQ k ^ i) := by gcongr
        _ ≤ etaShellC1 k H * (1 / (1 - etaShellQ k)) := by gcongr
        _ = etaShellC1 k H / (1 - etaShellQ k) := by ring
    have hlast :
        (A ^ (-(fixedBetaA k)) * W ^ etaShellDelta k) *
          etaShellR k ^ (M - 1) ≤ 1 := by
      have hscale := eta_dyadic_rpow2
        (W := W) (e := etaShellDelta k) hW0 (M - 1)
      rw [hscale] at hlast0
      simpa [etaShellR, mul_assoc] using hlast0
    have hx20 :
        0 ≤ A ^ (-(fixedBetaA k)) * W ^ etaShellDelta k := by
      positivity
    have hgrow := eta_geom_sum_growing_endpoint2
      hx20 hr hM hlast
    have hS2 :
        (∑ i ∈ Finset.range M,
          etaShellC2 k * A ^ (-(fixedBetaA k)) *
            (W * ((2 ^ i : ℕ) : ℝ)) ^ etaShellDelta k)
          ≤ etaShellC2 k * etaShellR k / (etaShellR k - 1) := by
      have hscale : ∀ i : ℕ,
          (W * ((2 ^ i : ℕ) : ℝ)) ^ etaShellDelta k =
            W ^ etaShellDelta k * etaShellR k ^ i := by
        intro i
        simpa [etaShellR] using
          (eta_dyadic_rpow2 (W := W) (e := etaShellDelta k) hW0 i)
      simp_rw [hscale]
      rw [← Finset.mul_sum]
      rw [← Finset.mul_sum]
      calc
        etaShellC2 k * A ^ (-(fixedBetaA k)) *
            (W ^ etaShellDelta k *
              ∑ i ∈ Finset.range M, etaShellR k ^ i)
          =
        etaShellC2 k *
            (A ^ (-(fixedBetaA k)) *
              (W ^ etaShellDelta k *
                ∑ i ∈ Finset.range M, etaShellR k ^ i)) := by ring
        _ =
        etaShellC2 k *
            ((A ^ (-(fixedBetaA k)) * W ^ etaShellDelta k) *
              (∑ i ∈ Finset.range M, etaShellR k ^ i)) := by ring
        _ ≤ etaShellC2 k * (etaShellR k / (etaShellR k - 1)) := by
          gcongr
        _ = etaShellC2 k * etaShellR k / (etaShellR k - 1) := by ring
    rw [Finset.sum_add_distrib, Finset.sum_add_distrib]
    unfold etaPowerBandGeomConst
    linarith

lemma eta_band_lower_normalized2
    {k : ℕ} (hk : 2 ≤ k)
    {A W : ℝ} (hA : 0 < A)
    (hLower : A ^ (1 / (k + 1 : ℝ)) ≤ W) :
    A ^ fixedBetaA k *
      W ^ (-(etaShellP k)) ≤ 1 := by
  have hk1 : 0 < (k + 1 : ℝ) := by positivity
  have hp : 0 < etaShellP k := etaShellP_pos hk
  have hroot : 0 < A ^ (1 / (k + 1 : ℝ)) :=
    Real.rpow_pos_of_pos hA _
  have hW : 0 < W := lt_of_lt_of_le hroot hLower
  have hpow := Real.rpow_le_rpow hroot.le hLower hp.le
  have hrootpow :
      (A ^ (1 / (k + 1 : ℝ))) ^ etaShellP k =
        A ^ fixedBetaA k := by
    rw [← Real.rpow_mul hA.le]
    unfold etaShellP
    congr 1
    field_simp [hk1.ne']
  rw [hrootpow] at hpow
  have hWp : 0 < W ^ etaShellP k := Real.rpow_pos_of_pos hW _
  rw [Real.rpow_neg hW.le]
  rw [← div_eq_mul_inv]
  exact (div_le_one hWp).2 hpow

lemma eta_band_upper_normalized2
    {k : ℕ} (hk : 3 ≤ k)
    {A U : ℝ} (hA1 : 1 ≤ A) (hU0 : 0 ≤ U)
    (hUpper : U ≤ A ^ (1 / (k : ℝ))) :
    A ^ (-(fixedBetaA k)) * U ^ etaShellDelta k ≤ 1 := by
  have hk2 : 2 ≤ k := by omega
  have hkpos : 0 < (k : ℝ) := by exact_mod_cast (show 0 < k by omega)
  have hd : 0 < etaShellDelta k := etaShellDelta_pos hk2
  have hpow := Real.rpow_le_rpow hU0 hUpper hd.le
  have hApow :
      (A ^ (1 / (k : ℝ))) ^ etaShellDelta k =
        A ^ (etaShellDelta k / (k : ℝ)) := by
    rw [← Real.rpow_mul (le_trans (by norm_num) hA1)]
    congr 1
    field_simp [hkpos.ne']
  rw [hApow] at hpow
  have hmul :
      A ^ (-(fixedBetaA k)) * U ^ etaShellDelta k
        ≤
      A ^ (-(fixedBetaA k)) *
        A ^ (etaShellDelta k / (k : ℝ)) := by
    exact mul_le_mul_of_nonneg_left hpow
      (Real.rpow_nonneg (le_trans (by norm_num) hA1) _)
  have hcombine :
      A ^ (-(fixedBetaA k)) *
        A ^ (etaShellDelta k / (k : ℝ)) =
      A ^ (-(fixedBetaA k) + etaShellDelta k / (k : ℝ)) := by
    rw [← Real.rpow_add (lt_of_lt_of_le (by norm_num) hA1)]
  rw [hcombine] at hmul
  have hexp := etaShell_upper_edge_exponent_nonpos hk
  have hone :
      A ^ (-(fixedBetaA k) + etaShellDelta k / (k : ℝ)) ≤
        A ^ (0 : ℝ) :=
    Real.rpow_le_rpow_of_exponent_le hA1 hexp
  simpa using hmul.trans hone

theorem eta_power_band_majorant_sum_ge_three
    {k H M : ℕ} (hk : 3 ≤ k)
    {A W : ℝ} (hA1 : 1 ≤ A) (hW1 : 1 ≤ W)
    (hLower : A ^ (1 / (k + 1 : ℝ)) ≤ W)
    (hUpper :
      W * ((2 ^ (M - 1) : ℕ) : ℝ) ≤
        A ^ (1 / (k : ℝ))) :
    (∑ i ∈ Finset.range M,
      (2 / (W * ((2 ^ i : ℕ) : ℝ)) +
        etaShellC1 k H * A ^ fixedBetaA k *
          (W * ((2 ^ i : ℕ) : ℝ)) ^ (-(etaShellP k)) +
        etaShellC2 k * A ^ (-(fixedBetaA k)) *
          (W * ((2 ^ i : ℕ) : ℝ)) ^ etaShellDelta k))
      ≤ etaPowerBandGeomConst k H := by
  have hk2 : 2 ≤ k := by omega
  have hA : 0 < A := lt_of_lt_of_le (by norm_num) hA1
  have hfirst := eta_band_lower_normalized2 hk2 hA hLower
  have hU0 :
      0 ≤ W * ((2 ^ (M - 1) : ℕ) : ℝ) := by positivity
  have hlast := eta_band_upper_normalized2 hk hA1 hU0 hUpper
  exact eta_power_band_majorant_geometric_sum hk2 hA hW1 hfirst hlast

theorem eta_power_band_majorant_sum_two
    {H M : ℕ}
    {A W : ℝ} (hA1 : 1 ≤ A) (hW1 : 1 ≤ W)
    (hLower : A ^ (1 / (3 : ℝ)) ≤ W)
    (hUpper :
      W * ((2 ^ (M - 1) : ℕ) : ℝ) ≤ A) :
    (∑ i ∈ Finset.range M,
      (2 / (W * ((2 ^ i : ℕ) : ℝ)) +
        etaShellC1 2 H * A ^ fixedBetaA 2 *
          (W * ((2 ^ i : ℕ) : ℝ)) ^ (-(etaShellP 2)) +
        etaShellC2 2 * A ^ (-(fixedBetaA 2)) *
          (W * ((2 ^ i : ℕ) : ℝ)) ^ etaShellDelta 2))
      ≤ etaPowerBandGeomConst 2 H := by
  have hA : 0 < A := lt_of_lt_of_le (by norm_num) hA1
  have hLower' :
      A ^ (1 / ((2 : ℝ) + 1)) ≤ W := by
    convert hLower using 1 <;> norm_num
  have hfirst := eta_band_lower_normalized2
    (k := 2) (by norm_num) hA hLower'
  have hU0 :
      0 ≤ W * ((2 ^ (M - 1) : ℕ) : ℝ) := by positivity
  have hlast := etaShell_two_terminal_le_one hA hU0 hUpper
  exact eta_power_band_majorant_geometric_sum
    (k := 2) (H := H) (M := M) (by norm_num)
    hA hW1 hfirst hlast

#print axioms eta_power_band_majorant_sum_ge_three
#print axioms eta_power_band_majorant_sum_two

#print axioms eta_power_band_majorant_geometric_sum

end PaperB.Analytic
