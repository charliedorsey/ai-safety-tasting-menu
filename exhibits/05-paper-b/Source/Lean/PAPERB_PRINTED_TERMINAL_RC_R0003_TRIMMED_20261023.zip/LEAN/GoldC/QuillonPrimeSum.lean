import GoldC.QuillonVWClass
import Mathlib.Algebra.IsPrimePow

/-!
# Quillon CSC3 F7.4l: prime sums with weight `1/(p−3)` from `Λ`-sums

* `card_prime_pow_le`: `#{n ≤ x : n = p^k, k ≥ 2} ≤ √x · log₂ x`.
* `prime_sum_class`: if `‖Σ_{n∈(X,j]} Λ(n) f(n)‖ ≤ β` for all `j ∈ [X, X']`, where `‖f‖ ≤ 1`, then
  `‖Σ_{p∈(X,X'] prime} f(p)/(p−3)‖ ≤ (β + log X'·√X'·log₂X') / ((X+1) log(X+1)) + 6/X` (`X ≥ 6`).

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset ArithmeticFunction

namespace GoldC.QuillonPrimeSum

open GoldC.QuillonVW

/-- Proper prime powers up to `x`. -/
def properPP (x : ℕ) : Finset ℕ := (Ioc 0 x).filter (fun n => IsPrimePow n ∧ ¬ n.Prime)

lemma card_properPP_le (x : ℕ) : (properPP x).card ≤ Nat.sqrt x * Nat.log 2 x := by
  classical
  have hsub : properPP x ⊆ ((Icc 2 (Nat.sqrt x)) ×ˢ (Icc 2 (Nat.log 2 x))).image
      (fun pk => pk.1 ^ pk.2) := by
    intro n hn
    simp only [properPP, mem_filter, mem_Ioc] at hn
    obtain ⟨⟨hn0, hnx⟩, hpp, hnp⟩ := hn
    obtain ⟨p, k, hp, hk, rfl⟩ := (isPrimePow_nat_iff _).1 hpp
    have hk2 : 2 ≤ k := by
      by_contra h
      have : k = 1 := by omega
      rw [this, pow_one] at hnp; exact hnp hp
    have hp2 := hp.two_le
    have hpp2 : p * p ≤ p ^ k := by
      calc p * p = p ^ 2 := (sq p).symm
        _ ≤ p ^ k := Nat.pow_le_pow_right (by omega) hk2
    have h2k : 2 ^ k ≤ p ^ k := Nat.pow_le_pow_left hp2 k
    refine mem_image.2 ⟨(p, k), ?_, rfl⟩
    simp only [mem_product, mem_Icc]
    refine ⟨⟨hp2, Nat.le_sqrt.2 (hpp2.trans hnx)⟩, ⟨hk2, ?_⟩⟩
    exact Nat.le_log_of_pow_le (by norm_num) (h2k.trans hnx)
  calc (properPP x).card ≤ _ := card_le_card hsub
    _ ≤ ((Icc 2 (Nat.sqrt x)) ×ˢ (Icc 2 (Nat.log 2 x))).card := card_image_le
    _ = (Nat.sqrt x + 1 - 2) * (Nat.log 2 x + 1 - 2) := by rw [card_product, Nat.card_Icc, Nat.card_Icc]
    _ ≤ Nat.sqrt x * Nat.log 2 x := Nat.mul_le_mul (by omega) (by omega)

/-- `Σ Λ f` versus `Σ_{p} log p · f`: the proper prime powers contribute at most
`log Y · √Y · log₂ Y`. -/
lemma lambda_vs_primes (f : ℕ → ℂ) (hf : ∀ n, ‖f n‖ ≤ 1) (X Y : ℕ) :
    ‖∑ n ∈ Ioc X Y, ((vonMangoldt n : ℝ) : ℂ) * f n -
      ∑ n ∈ (Ioc X Y).filter Nat.Prime, ((Real.log n : ℝ) : ℂ) * f n‖ ≤
        Real.log Y * (Nat.sqrt Y * Nat.log 2 Y) := by
  classical
  have hsplit : ∑ n ∈ Ioc X Y, ((vonMangoldt n : ℝ) : ℂ) * f n =
      ∑ n ∈ (Ioc X Y).filter Nat.Prime, ((Real.log n : ℝ) : ℂ) * f n +
      ∑ n ∈ (Ioc X Y).filter (fun n => ¬ n.Prime), ((vonMangoldt n : ℝ) : ℂ) * f n := by
    rw [← sum_filter_add_sum_filter_not (Ioc X Y) Nat.Prime]
    congr 1
    refine sum_congr rfl fun n hn => ?_
    rw [vonMangoldt_apply_prime (mem_filter.1 hn).2]
  rw [hsplit, add_sub_cancel_left]
  have hlogY : 0 ≤ Real.log Y := Real.log_natCast_nonneg Y
  calc _ ≤ ∑ n ∈ (Ioc X Y).filter (fun n => ¬ n.Prime), ‖((vonMangoldt n : ℝ) : ℂ) * f n‖ :=
        norm_sum_le _ _
    _ ≤ ∑ n ∈ properPP Y, Real.log Y := by
        rw [← sum_filter_add_sum_filter_not ((Ioc X Y).filter (fun n => ¬ n.Prime))
          (fun n => IsPrimePow n)]
        have hz : ∑ n ∈ ((Ioc X Y).filter (fun n => ¬ n.Prime)).filter (fun n => ¬ IsPrimePow n),
            ‖((vonMangoldt n : ℝ) : ℂ) * f n‖ = 0 := by
          refine sum_eq_zero fun n hn => ?_
          have : vonMangoldt n = 0 := by
            by_contra h; exact (mem_filter.1 hn).2 (vonMangoldt_ne_zero_iff.1 h)
          simp [this]
        rw [hz, add_zero]
        refine (sum_le_sum fun n hn => ?_).trans (sum_le_sum_of_subset_of_nonneg ?_ fun _ _ _ => hlogY)
        · have hn' := mem_filter.1 hn
          have hn'' := mem_filter.1 hn'.1
          rw [norm_mul, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg vonMangoldt_nonneg]
          calc vonMangoldt n * ‖f n‖ ≤ vonMangoldt n * 1 :=
                mul_le_mul_of_nonneg_left (hf n) vonMangoldt_nonneg
            _ ≤ Real.log Y := by
                rw [mul_one]
                refine vonMangoldt_le_log.trans ?_
                have h0 := (mem_Ioc.1 hn''.1)
                exact Real.log_le_log (by exact_mod_cast (show 0 < n by omega))
                  (by exact_mod_cast h0.2)
        · intro n hn
          have hn' := mem_filter.1 hn
          have hn'' := mem_filter.1 hn'.1
          simp only [properPP, mem_filter, mem_Ioc]
          exact ⟨⟨by have := (mem_Ioc.1 hn''.1).1; omega, (mem_Ioc.1 hn''.1).2⟩, hn'.2, hn''.2⟩
    _ = (properPP Y).card * Real.log Y := by rw [sum_const, nsmul_eq_mul]
    _ ≤ (Nat.sqrt Y * Nat.log 2 Y : ℕ) * Real.log Y := by
        gcongr; exact_mod_cast card_properPP_le Y
    _ = _ := by push_cast; ring

/-- The partial-summation weight `1/(n log n)` (frozen below `2`). -/
noncomputable def wt (n : ℕ) : ℝ := 1 / (((max n 2 : ℕ) : ℝ) * Real.log ((max n 2 : ℕ) : ℝ))

lemma wt_pos_aux (n : ℕ) : 0 < ((max n 2 : ℕ) : ℝ) * Real.log ((max n 2 : ℕ) : ℝ) := by
  have h2 : (2 : ℝ) ≤ ((max n 2 : ℕ) : ℝ) := by exact_mod_cast le_max_right n 2
  have hl : 0 < Real.log ((max n 2 : ℕ) : ℝ) := Real.log_pos (by linarith)
  positivity

lemma wt_nonneg (n : ℕ) : 0 ≤ wt n := by unfold wt; exact (one_div_pos.2 (wt_pos_aux n)).le

lemma wt_antitone : Antitone wt := by
  intro a b hab
  unfold wt
  apply one_div_le_one_div_of_le (wt_pos_aux a)
  have h2 : (2 : ℝ) ≤ ((max a 2 : ℕ) : ℝ) := by exact_mod_cast le_max_right a 2
  have hab' : ((max a 2 : ℕ) : ℝ) ≤ ((max b 2 : ℕ) : ℝ) := by exact_mod_cast max_le_max hab le_rfl
  have hl : 0 < Real.log ((max a 2 : ℕ) : ℝ) := Real.log_pos (by linarith)
  have hl' : Real.log ((max a 2 : ℕ) : ℝ) ≤ Real.log ((max b 2 : ℕ) : ℝ) :=
    Real.log_le_log (by linarith) hab'
  exact mul_le_mul hab' hl' hl.le (by linarith)

lemma wt_mul_log (n : ℕ) (hn : 2 ≤ n) : wt n * Real.log n = 1 / n := by
  unfold wt
  rw [max_eq_left hn]
  have hnR : (2 : ℝ) ≤ n := by exact_mod_cast hn
  have hl : 0 < Real.log n := Real.log_pos (by linarith)
  field_simp

/-- Partial summation from `Λ`-sums to `Σ_p f(p)/p`. -/
theorem prime_sum_recip (f : ℕ → ℂ) (hf : ∀ n, ‖f n‖ ≤ 1) (X X' : ℕ) (hX : 1 ≤ X)
    (hXX' : X ≤ X') (β : ℝ)
    (hβ : ∀ j, X ≤ j → j ≤ X' → ‖∑ n ∈ Ioc X j, ((vonMangoldt n : ℝ) : ℂ) * f n‖ ≤ β) :
    ‖∑ p ∈ (Ioc X X').filter Nat.Prime, ((1 / (p : ℝ) : ℝ) : ℂ) * f p‖ ≤
      wt (X + 1) * (β + Real.log X' * (Nat.sqrt X' * Nat.log 2 X')) := by
  classical
  set b : ℕ → ℂ := fun n => if n.Prime then ((Real.log n : ℝ) : ℂ) * f n else 0 with hb
  have hrw : ∑ p ∈ (Ioc X X').filter Nat.Prime, ((1 / (p : ℝ) : ℝ) : ℂ) * f p =
      ∑ n ∈ Ioc X X', ((wt n : ℝ) : ℂ) * b n := by
    rw [sum_filter]
    refine sum_congr rfl fun n _ => ?_
    simp only [hb]
    split_ifs with hp
    · rw [← mul_assoc, ← Complex.ofReal_mul, wt_mul_log n hp.two_le]
    · rw [mul_zero]
  rw [hrw]
  refine abel_dec wt wt_nonneg wt_antitone b X X' hXX' _ fun j hj1 hj2 => ?_
  have hpsum : GoldC.QuillonAbel.psum b X j =
      ∑ n ∈ (Ioc X j).filter Nat.Prime, ((Real.log n : ℝ) : ℂ) * f n := by
    unfold GoldC.QuillonAbel.psum; rw [sum_filter]
  rw [hpsum]
  have h1 := lambda_vs_primes f hf X j
  have h2 := hβ j hj1 hj2
  have hmono : Real.log j * (Nat.sqrt j * Nat.log 2 j) ≤
      Real.log X' * (Nat.sqrt X' * Nat.log 2 X') := by
    have hlj : Real.log j ≤ Real.log X' := by
      rcases Nat.eq_zero_or_pos j with h | h
      · simp [h, Real.log_natCast_nonneg]
      · exact Real.log_le_log (by exact_mod_cast h) (by exact_mod_cast hj2)
    have hs : (Nat.sqrt j : ℝ) ≤ Nat.sqrt X' := by exact_mod_cast Nat.sqrt_le_sqrt hj2
    have hl2 : (Nat.log 2 j : ℝ) ≤ Nat.log 2 X' := by exact_mod_cast Nat.log_mono_right hj2
    have : 0 ≤ Real.log j := Real.log_natCast_nonneg j
    gcongr
  calc ‖∑ n ∈ (Ioc X j).filter Nat.Prime, ((Real.log n : ℝ) : ℂ) * f n‖
      ≤ ‖∑ n ∈ Ioc X j, ((vonMangoldt n : ℝ) : ℂ) * f n‖ +
        ‖∑ n ∈ Ioc X j, ((vonMangoldt n : ℝ) : ℂ) * f n -
          ∑ n ∈ (Ioc X j).filter Nat.Prime, ((Real.log n : ℝ) : ℂ) * f n‖ := by
        have := norm_sub_le (∑ n ∈ Ioc X j, ((vonMangoldt n : ℝ) : ℂ) * f n)
          (∑ n ∈ Ioc X j, ((vonMangoldt n : ℝ) : ℂ) * f n -
            ∑ n ∈ (Ioc X j).filter Nat.Prime, ((Real.log n : ℝ) : ℂ) * f n)
        rwa [sub_sub_cancel] at this
    _ ≤ β + Real.log X' * (Nat.sqrt X' * Nat.log 2 X') := add_le_add h2 (h1.trans hmono)

lemma telescope_inv (X : ℕ) (hX : 1 ≤ X) : ∀ Y, X ≤ Y →
    ∑ n ∈ Ioc X Y, (1 / ((n : ℝ) * ((n : ℝ) - 1))) = 1 / (X : ℝ) - 1 / (Y : ℝ) := by
  intro Y hY
  induction Y, hY using Nat.le_induction with
  | base => simp
  | succ Y hXY ih =>
    rw [sum_Ioc_succ_top (by omega), ih]
    have hY1 : (1 : ℝ) ≤ Y := by exact_mod_cast hX.trans hXY
    have hY0 : (Y : ℝ) ≠ 0 := by positivity
    have hY0' : (Y : ℝ) + 1 ≠ 0 := by positivity
    push_cast
    have e : ((Y : ℝ) + 1) - 1 = Y := by ring
    rw [e]
    field_simp
    ring

/-- **Prime sum with the source weight `1/(p−3)`.** -/
theorem prime_sum_omega (f : ℕ → ℂ) (hf : ∀ n, ‖f n‖ ≤ 1) (X X' : ℕ) (hX : 6 ≤ X)
    (hXX' : X ≤ X') (β : ℝ)
    (hβ : ∀ j, X ≤ j → j ≤ X' → ‖∑ n ∈ Ioc X j, ((vonMangoldt n : ℝ) : ℂ) * f n‖ ≤ β) :
    ‖∑ p ∈ (Ioc X X').filter Nat.Prime, ((1 / ((p : ℝ) - 3) : ℝ) : ℂ) * f p‖ ≤
      wt (X + 1) * (β + Real.log X' * (Nat.sqrt X' * Nat.log 2 X')) + 6 / X := by
  have hsplit : ∑ p ∈ (Ioc X X').filter Nat.Prime, ((1 / ((p : ℝ) - 3) : ℝ) : ℂ) * f p =
      ∑ p ∈ (Ioc X X').filter Nat.Prime, ((1 / (p : ℝ) : ℝ) : ℂ) * f p +
      ∑ p ∈ (Ioc X X').filter Nat.Prime, ((3 / ((p : ℝ) * ((p : ℝ) - 3)) : ℝ) : ℂ) * f p := by
    rw [← sum_add_distrib]
    refine sum_congr rfl fun p hp => ?_
    have hp6 : (6 : ℝ) < p := by
      have := (mem_Ioc.1 (mem_filter.1 hp).1).1; exact_mod_cast (show 6 < p by omega)
    rw [← add_mul, ← Complex.ofReal_add]
    congr 2
    have h1 : (p : ℝ) ≠ 0 := by positivity
    have h2 : (p : ℝ) - 3 ≠ 0 := by linarith
    field_simp
    ring
  rw [hsplit]
  refine (norm_add_le _ _).trans (add_le_add (prime_sum_recip f hf X X' (by omega) hXX' β hβ) ?_)
  calc _ ≤ ∑ p ∈ (Ioc X X').filter Nat.Prime, ‖((3 / ((p : ℝ) * ((p : ℝ) - 3)) : ℝ) : ℂ) * f p‖ :=
        norm_sum_le _ _
    _ ≤ ∑ n ∈ Ioc X X', 6 * (1 / ((n : ℝ) * ((n : ℝ) - 1))) := by
        refine (sum_le_sum fun p hp => ?_).trans (sum_le_sum_of_subset_of_nonneg (filter_subset _ _)
          fun n hn _ => ?_)
        · have hp6 : (6 : ℝ) < p := by
            have := (mem_Ioc.1 (mem_filter.1 hp).1).1; exact_mod_cast (show 6 < p by omega)
          rw [norm_mul, Complex.norm_real, Real.norm_eq_abs,
            abs_of_nonneg (by apply div_nonneg <;> nlinarith)]
          calc 3 / ((p : ℝ) * ((p : ℝ) - 3)) * ‖f p‖ ≤ 3 / ((p : ℝ) * ((p : ℝ) - 3)) * 1 :=
                mul_le_mul_of_nonneg_left (hf p) (by apply div_nonneg <;> nlinarith)
            _ ≤ 6 * (1 / ((p : ℝ) * ((p : ℝ) - 1))) := by
                rw [mul_one, mul_one_div, div_le_div_iff₀ (by nlinarith) (by nlinarith)]
                nlinarith
        · have hn6 : (6 : ℝ) < n := by
            have := (mem_Ioc.1 hn).1; exact_mod_cast (show 6 < n by omega)
          apply mul_nonneg (by norm_num); apply div_nonneg zero_le_one; nlinarith
    _ = 6 * (1 / (X : ℝ) - 1 / (X' : ℝ)) := by rw [← mul_sum, telescope_inv X (by omega) X' hXX']
    _ ≤ 6 / X := by
        have : (0 : ℝ) ≤ 1 / (X' : ℝ) := by positivity
        rw [mul_sub, mul_one_div]; linarith

end GoldC.QuillonPrimeSum

#print axioms GoldC.QuillonPrimeSum.card_properPP_le
#print axioms GoldC.QuillonPrimeSum.lambda_vs_primes
#print axioms GoldC.QuillonPrimeSum.prime_sum_omega
