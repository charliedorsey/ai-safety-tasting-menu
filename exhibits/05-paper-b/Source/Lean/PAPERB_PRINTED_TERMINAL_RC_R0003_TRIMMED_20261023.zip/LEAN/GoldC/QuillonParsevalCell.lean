import GoldC.QuillonParseval
import GoldC.QuillonWCell

/-!
# Quillon CSC3 F7.4b: the Parseval-W cell bound

For `s = ∏P` (distinct primes), `c : ZMod s`, `𝒴 ⊆ [1,Y]` coprime to `s`, `𝒩 ⊆ [1,N']` units mod `s`
and `‖b_n‖ ≤ B/n`:

    ‖Σ_y Σ_n a_y b_n e(c ȳ n̄ / s)‖² ≤ (Σ‖a‖²)(Y/s + 1)s·(Σ‖b_n‖² + B²·2(1+log N')²/g'),

where `g' = ∏_{p∈P, p∤c} p`. Uses no Kloosterman bound.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonParsevalCell

open GoldC.QuillonWCell

/-- Pairs with `c(n̄ − n̄') = 0` are congruent modulo `g' = ∏_{p∤c} p`. -/
lemma freq_zero_dvd {s : ℕ} (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hs : s = ∏ p ∈ P, p)
    (c : ZMod s) (n n' : ℕ) (hn : IsUnit (n : ZMod s)) (hn' : IsUnit (n' : ZMod s))
    (h : c * ((n : ZMod s)⁻¹ - (n' : ZMod s)⁻¹) = 0) :
    ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℤ) ∣ (n : ℤ) - n' := by
  apply prime_prod_dvd _ (fun p hp => hP p (filter_subset _ _ hp))
  intro p hp
  rw [mem_filter] at hp
  have hps : p ∣ s := by rw [hs]; exact Finset.dvd_prod_of_mem _ hp.1
  have h0 : (ZMod.cast (c * ((n : ZMod s)⁻¹ - (n' : ZMod s)⁻¹)) : ZMod p) = 0 := by
    rw [h]; exact ZMod.cast_zero
  rcases cast_freq_zero p (hP p hp.1) hps c n n' hn hn' h0 with h1 | h1
  · exact absurd h1 hp.2
  · exact h1

theorem parseval_cell {s : ℕ} [NeZero s] (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime)
    (hsP : s = ∏ p ∈ P, p) (c : ZMod s) (Y N' : ℕ) (𝒴 𝒩 : Finset ℕ)
    (h𝒴 : 𝒴 ⊆ Icc 1 Y) (hcop : ∀ y ∈ 𝒴, Nat.Coprime y s) (h𝒩 : 𝒩 ⊆ Icc 1 N')
    (hn : ∀ n ∈ 𝒩, IsUnit (n : ZMod s)) (a b : ℕ → ℂ) (B : ℝ) (hb : ∀ n ∈ 𝒩, ‖b n‖ ≤ B / n) :
    ‖∑ y ∈ 𝒴, ∑ n ∈ 𝒩, a y * b n *
        ZMod.stdAddChar (c * (y : ZMod s)⁻¹ * (n : ZMod s)⁻¹)‖ ^ 2 ≤
      (∑ y ∈ 𝒴, ‖a y‖ ^ 2) * ((Y : ℝ) / s + 1) * s *
        (∑ n ∈ 𝒩, ‖b n‖ ^ 2 + B ^ 2 * (2 * (1 + Real.log N') ^ 2 /
          ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ))) := by
  classical
  refine (GoldC.QuillonParseval.parseval_bilinear c (fun n => (n : ZMod s)⁻¹) Y 𝒴 𝒩 h𝒴 hcop
    a b).trans ?_
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  set g : ℕ := ∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p with hg
  have hg1 : 1 ≤ g := Nat.one_le_iff_ne_zero.2 (Finset.prod_ne_zero_iff.2 fun p hp =>
    (hP p (filter_subset _ _ hp)).ne_zero)
  have hB : ∀ n ∈ 𝒩, 0 ≤ B / n := fun n hn => (norm_nonneg _).trans (hb n hn)
  set T2 : ℕ → ℕ → ℝ := fun n n' =>
    if n ≠ n' ∧ ((g : ℕ) : ℤ) ∣ (n : ℤ) - n' then 1 / ((n : ℝ) * n') else 0 with hT2
  have hT2n : ∀ n n', 0 ≤ T2 n n' := fun n n' => by simp only [hT2]; split_ifs <;> positivity
  have hpt : ∀ n ∈ 𝒩, ∀ n' ∈ 𝒩,
      (if c * ((n : ZMod s)⁻¹ - (n' : ZMod s)⁻¹) = 0 then ‖b n‖ * ‖b n'‖ else 0) ≤
        (if n = n' then ‖b n‖ ^ 2 else 0) + B ^ 2 * T2 n n' := by
    intro n hn1 n' hn1'
    have hB2 : 0 ≤ B ^ 2 * T2 n n' := mul_nonneg (sq_nonneg B) (hT2n n n')
    by_cases hnn : n = n'
    · subst hnn; rw [if_pos (by ring), if_pos rfl]; nlinarith [norm_nonneg (b n)]
    · rw [if_neg hnn, zero_add]
      split_ifs with h0
      · have hd := freq_zero_dvd P hP hsP c n n' (hn n hn1) (hn n' hn1') h0
        have hT : T2 n n' = 1 / ((n : ℝ) * n') := if_pos (And.intro hnn hd)
        rw [hT]
        calc ‖b n‖ * ‖b n'‖ ≤ (B / n) * (B / n') :=
              mul_le_mul (hb n hn1) (hb n' hn1') (norm_nonneg _) (hB n hn1)
          _ = _ := by ring
      · exact hB2
  calc _ ≤ ∑ n ∈ 𝒩, ∑ n' ∈ 𝒩, ((if n = n' then ‖b n‖ ^ 2 else 0) + B ^ 2 * T2 n n') :=
        sum_le_sum fun n hn1 => sum_le_sum fun n' hn1' => hpt n hn1 n' hn1'
    _ = ∑ n ∈ 𝒩, ‖b n‖ ^ 2 + B ^ 2 * ∑ n ∈ 𝒩, ∑ n' ∈ 𝒩, T2 n n' := by
        simp only [sum_add_distrib, mul_sum]
        congr 1
        refine sum_congr rfl fun n hn1 => ?_
        rw [sum_ite_eq 𝒩 n (fun _ => ‖b n‖ ^ 2), if_pos hn1]
    _ ≤ _ := by
        have e2 : ∑ n ∈ 𝒩, ∑ n' ∈ 𝒩, T2 n n' ≤ 2 * (1 + Real.log N') ^ 2 / (g : ℝ) := by
          calc _ ≤ ∑ n ∈ Icc 1 N', ∑ n' ∈ Icc 1 N', T2 n n' := by
                refine (sum_le_sum fun n _ => sum_le_sum_of_subset_of_nonneg h𝒩
                  fun n' _ _ => hT2n n n').trans ?_
                exact sum_le_sum_of_subset_of_nonneg h𝒩 fun n _ _ => sum_nonneg fun n' _ => hT2n n n'
            _ = ∑ n ∈ Icc 1 N', ∑ n' ∈ (Icc 1 N').filter (fun n' => n ≠ n' ∧
                  ((g : ℕ) : ℤ) ∣ (n : ℤ) - n'), (1 / ((n : ℝ) * n')) := by
                refine sum_congr rfl fun n _ => ?_
                rw [sum_filter]
            _ ≤ _ := gcd_pair_sum_sym g N' hg1
        have := mul_le_mul_of_nonneg_left e2 (sq_nonneg B)
        linarith

/-- `s = G₀ · g'` where `G₀ = ∏_{p∣c} p` and `g' = ∏_{p∤c} p`. -/
lemma s_eq_split {s : ℕ} (P : Finset ℕ) (hsP : s = ∏ p ∈ P, p) (c : ZMod s) :
    (s : ℝ) = (∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) = 0), (p : ℝ)) *
      ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ) := by
  rw [Nat.cast_prod, Finset.prod_filter_mul_prod_filter_not, hsP, Nat.cast_prod]

end GoldC.QuillonParsevalCell

#print axioms GoldC.QuillonParsevalCell.parseval_cell
#print axioms GoldC.QuillonParsevalCell.s_eq_split
