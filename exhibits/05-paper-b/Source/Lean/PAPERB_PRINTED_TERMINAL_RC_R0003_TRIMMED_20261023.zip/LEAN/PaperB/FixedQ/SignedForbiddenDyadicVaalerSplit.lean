import PaperB.FixedQ.SignedForbiddenExteriorDyadic
import PaperB.FixedQ.SignedForbiddenMainCompletion

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def sourceForbiddenNaturalVaalerMainDyadicBlock
    (q A H D M J : ℕ) : ℝ :=
  ∑ m ∈ Finset.Ioc M (2 * M),
    sourceForbiddenNaturalVaalerMain q A H D m J

noncomputable def sourceForbiddenNaturalVaalerErrorDyadicBlock
    (q A H D M J : ℕ) : ℝ :=
  ∑ m ∈ Finset.Ioc M (2 * M),
    sourceForbiddenNaturalVaalerError q A H D m J

lemma sourceForbiddenNaturalVaalerError_nonneg
    (q A H D m J : ℕ) :
    0 ≤ sourceForbiddenNaturalVaalerError q A H D m J := by
  classical
  by_cases hs : 1 < m ∧ Squarefree m ∧ m.Coprime (H * (6 * q) * D)
  · rw [sourceForbiddenNaturalVaalerError, dif_pos hs]
    have hweight : 0 ≤ fixedQShiuWeight q m :=
      fixedQShiuWeight_nonneg q m
    apply mul_nonneg hweight
    apply Finset.sum_nonneg
    intro c hc
    exact mul_nonneg (abs_nonneg _)
      (sourceAffineVaalerError_nonneg _ _ _ _ _ _)
  · rw [sourceForbiddenNaturalVaalerError, dif_neg hs]

theorem sourceForbiddenNaturalDyadicBlock_sub_vaalerMain_abs_le_error
    {q A H D M J : ℕ}
    (hq : 0 < q)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H) :
    |sourceForbiddenNaturalDyadicBlock q A H D M -
        sourceForbiddenNaturalVaalerMainDyadicBlock q A H D M J| ≤
      sourceForbiddenNaturalVaalerErrorDyadicBlock q A H D M J := by
  unfold sourceForbiddenNaturalDyadicBlock
  unfold sourceForbiddenNaturalVaalerMainDyadicBlock
  unfold sourceForbiddenNaturalVaalerErrorDyadicBlock
  rw [← Finset.sum_sub_distrib]
  calc
    |∑ m ∈ Finset.Ioc M (2 * M),
        (sourceForbiddenBooleanNaturalTerm q A H D m -
          sourceForbiddenNaturalVaalerMain q A H D m J)|
      ≤ ∑ m ∈ Finset.Ioc M (2 * M),
          |sourceForbiddenBooleanNaturalTerm q A H D m -
            sourceForbiddenNaturalVaalerMain q A H D m J| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ m ∈ Finset.Ioc M (2 * M),
          sourceForbiddenNaturalVaalerError q A H D m J := by
        apply Finset.sum_le_sum
        intro m hm
        exact sourceForbiddenBooleanNaturalTerm_sub_vaalerMain_abs_le_error
          (q := q) (a := A) (H := H) (D := D)
          (m := m) (J := J) hq h2admissible

theorem sourceForbiddenNaturalDyadicBlock_abs_le_main_add_error
    {q A H D M J : ℕ}
    (hq : 0 < q)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H) :
    |sourceForbiddenNaturalDyadicBlock q A H D M| ≤
      |sourceForbiddenNaturalVaalerMainDyadicBlock q A H D M J| +
        sourceForbiddenNaturalVaalerErrorDyadicBlock q A H D M J := by
  have h :=
    sourceForbiddenNaturalDyadicBlock_sub_vaalerMain_abs_le_error
      (q := q) (A := A) (H := H) (D := D) (M := M) (J := J)
      hq h2admissible
  have htri :
      |sourceForbiddenNaturalDyadicBlock q A H D M| ≤
        |sourceForbiddenNaturalDyadicBlock q A H D M -
          sourceForbiddenNaturalVaalerMainDyadicBlock q A H D M J| +
        |sourceForbiddenNaturalVaalerMainDyadicBlock q A H D M J| := by
    have := abs_add_le
      (sourceForbiddenNaturalDyadicBlock q A H D M -
        sourceForbiddenNaturalVaalerMainDyadicBlock q A H D M J)
      (sourceForbiddenNaturalVaalerMainDyadicBlock q A H D M J)
    simpa [sub_add_cancel] using this
  linarith

#print axioms sourceForbiddenNaturalDyadicBlock_sub_vaalerMain_abs_le_error
#print axioms sourceForbiddenNaturalDyadicBlock_abs_le_main_add_error

end PaperB.FixedQ
