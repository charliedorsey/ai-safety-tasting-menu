import PaperB.FixedQ.SignedForbiddenThalenOuterSubsetReaggregation

open scoped BigOperators

namespace PaperB.FixedQ

/-- The exact centered product for disjoint shifted prime indicators.
This pays the pointwise disjointness adapter, not a source cutoff. -/
theorem thalen_disjoint_euler_eq_centered_packets
    (S : Finset ℕ) (w L R : ℕ → ℝ)
    (hdisjoint : ∀ p ∈ S, L p * R p = 0) :
    (∏ p ∈ S, (1 + w p * (L p + R p))) -
      (∏ p ∈ S, (1 + w p * L p)) -
      (∏ p ∈ S, (1 + w p * R p)) + 1 =
    ((∏ p ∈ S, (1 + w p * L p)) - 1) *
      ((∏ p ∈ S, (1 + w p * R p)) - 1) := by
  have hp :
      (∏ p ∈ S, (1 + w p * (L p + R p))) =
      (∏ p ∈ S, (1 + w p * L p)) *
        (∏ p ∈ S, (1 + w p * R p)) := by
    rw [← Finset.prod_mul_distrib]
    apply Finset.prod_congr rfl
    intro p hp
    have h := hdisjoint p hp
    calc
      1 + w p * (L p + R p) =
          1 + w p * (L p + R p) + (w p) ^ 2 * (L p * R p) := by
            rw [h]
            ring
      _ = (1 + w p * L p) * (1 + w p * R p) := by ring
  rw [hp]
  ring

/-- Consume the GREEN outer proper-support theorem at a disjoint
coordinate pair. No source normalization or cutoff is changed. -/
theorem thalen_outer_proper_eq_centered_packets
    (S : Finset ℕ) (w L R : ℕ → ℝ)
    (hdisjoint : ∀ p ∈ S, L p * R p = 0) :
    (∑ e ∈ S.powerset,
      (∏ p ∈ e, w p) *
        (∑ A ∈ ((e.powerset.erase e).erase ∅),
          (∏ p ∈ A, L p) * (∏ p ∈ e \ A, R p))) =
      ((∏ p ∈ S, (1 + w p * L p)) - 1) *
        ((∏ p ∈ S, (1 + w p * R p)) - 1) := by
  rw [thalen_outer_support_proper_euler]
  exact thalen_disjoint_euler_eq_centered_packets S w L R hdisjoint

#print axioms thalen_outer_proper_eq_centered_packets

end PaperB.FixedQ
