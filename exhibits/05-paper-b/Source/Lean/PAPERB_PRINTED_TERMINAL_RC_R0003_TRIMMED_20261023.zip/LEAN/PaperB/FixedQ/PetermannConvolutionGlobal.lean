import PaperB.FixedQ.PetermannConvolutionFinite

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def petermannSupportedCoeff
    (q : ℕ) (fac : ℕ → ℝ) (n : ℕ) : ℝ :=
  if n = 0 then 0
  else if Squarefree n ∧ n.Coprime (6 * q) then
    ∏ p ∈ n.primeFactors, fac p
  else 0

noncomputable def petermannSupportedArithmetic
    (q : ℕ) (fac : ℕ → ℝ) : ArithmeticFunction ℝ :=
  ⟨petermannSupportedCoeff q fac, by simp [petermannSupportedCoeff]⟩

@[simp] theorem petermannSupportedArithmetic_apply
    (q : ℕ) (fac : ℕ → ℝ) (n : ℕ) :
    petermannSupportedArithmetic q fac n =
      petermannSupportedCoeff q fac n := rfl

theorem petermannSupportedArithmetic_multiplicative
    (q : ℕ) (fac : ℕ → ℝ) :
    (petermannSupportedArithmetic q fac).IsMultiplicative := by
  constructor
  · change petermannSupportedCoeff q fac 1 = 1
    simp [petermannSupportedCoeff]
  · intro m n hcop
    change petermannSupportedCoeff q fac (m * n) =
      petermannSupportedCoeff q fac m * petermannSupportedCoeff q fac n
    by_cases hm0 : m = 0
    · subst m
      have hn1 : n = 1 := by simpa using hcop
      subst n
      simp [petermannSupportedCoeff]
    · by_cases hn0 : n = 0
      · subst n
        have hm1 : m = 1 := by simpa using hcop
        subst m
        simp [petermannSupportedCoeff]
      · have hmn0 : m * n ≠ 0 := mul_ne_zero hm0 hn0
        have hsq := Nat.squarefree_mul hcop
        have hunit : (m * n).Coprime (6 * q) ↔
            m.Coprime (6 * q) ∧ n.Coprime (6 * q) :=
          Nat.coprime_mul_iff_left
        have hpf : (m * n).primeFactors =
            m.primeFactors ∪ n.primeFactors :=
          Nat.primeFactors_mul hm0 hn0
        have hdisj : Disjoint m.primeFactors n.primeFactors := by
          rw [Finset.disjoint_left]
          intro p hpm hpn
          have hpd : p ∣ m.gcd n :=
            Nat.dvd_gcd (Nat.dvd_of_mem_primeFactors hpm)
              (Nat.dvd_of_mem_primeFactors hpn)
          rw [hcop.gcd_eq_one] at hpd
          exact (Nat.prime_of_mem_primeFactors hpm).not_dvd_one hpd
        by_cases hm : Squarefree m ∧ m.Coprime (6 * q)
        · by_cases hn : Squarefree n ∧ n.Coprime (6 * q)
          · have hmn : Squarefree (m * n) ∧ (m * n).Coprime (6 * q) :=
              ⟨hsq.mpr ⟨hm.1, hn.1⟩, hunit.mpr ⟨hm.2, hn.2⟩⟩
            rw [petermannSupportedCoeff, if_neg hmn0, if_pos hmn,
              petermannSupportedCoeff, if_neg hm0, if_pos hm,
              petermannSupportedCoeff, if_neg hn0, if_pos hn, hpf,
              Finset.prod_union hdisj]
          · have hmn : ¬ (Squarefree (m * n) ∧
                (m * n).Coprime (6 * q)) := by
              intro h
              apply hn
              exact ⟨(hsq.mp h.1).2, (hunit.mp h.2).2⟩
            rw [petermannSupportedCoeff, if_neg hmn0, if_neg hmn,
              petermannSupportedCoeff, if_neg hm0, if_pos hm,
              petermannSupportedCoeff, if_neg hn0, if_neg hn]
            ring
        · have hmn : ¬ (Squarefree (m * n) ∧
              (m * n).Coprime (6 * q)) := by
            intro h
            apply hm
            exact ⟨(hsq.mp h.1).1, (hunit.mp h.2).1⟩
          rw [petermannSupportedCoeff, if_neg hmn0, if_neg hmn,
            petermannSupportedCoeff, if_neg hm0, if_neg hm]
          ring

noncomputable def omegaArithmetic (q : ℕ) : ArithmeticFunction ℝ :=
  petermannSupportedArithmetic q petermannA

noncomputable def movingVArithmetic (q h : ℕ) : ArithmeticFunction ℝ :=
  petermannSupportedArithmetic q
    (fun p => if p ∣ h then petermannB p else petermannA p)

@[simp] theorem omegaArithmetic_apply (q n : ℕ) :
    omegaArithmetic q n = omegaCoeff q n := by
  simp [omegaArithmetic, petermannSupportedArithmetic,
    petermannSupportedCoeff, omegaCoeff, petermannA]

@[simp] theorem movingVArithmetic_apply (q h n : ℕ) :
    movingVArithmetic q h n = movingVCoeff q h n := by
  simp [movingVArithmetic, petermannSupportedArithmetic,
    petermannSupportedCoeff, movingVCoeff, petermannA, petermannB]

theorem omegaArithmetic_multiplicative (q : ℕ) :
    (omegaArithmetic q).IsMultiplicative :=
  petermannSupportedArithmetic_multiplicative q petermannA

theorem movingVArithmetic_multiplicative (q h : ℕ) :
    (movingVArithmetic q h).IsMultiplicative :=
  petermannSupportedArithmetic_multiplicative q
    (fun p => if p ∣ h then petermannB p else petermannA p)

noncomputable def petermannCorrectionLocal
    (q h p nu : ℕ) : ℝ :=
  if nu = 0 then 1
  else if p.Prime ∧ p.Coprime (6 * q) ∧ p ∣ h then
    petermannCorrectionPrimePower p nu
  else 0

noncomputable def petermannCorrectionCoeff
    (q h n : ℕ) : ℝ :=
  if n = 0 then 0
  else ∏ p ∈ n.primeFactors,
    petermannCorrectionLocal q h p (n.factorization p)

noncomputable def petermannCorrectionArithmetic
    (q h : ℕ) : ArithmeticFunction ℝ :=
  ⟨petermannCorrectionCoeff q h, by simp [petermannCorrectionCoeff]⟩

@[simp] theorem petermannCorrectionArithmetic_apply
    (q h n : ℕ) :
    petermannCorrectionArithmetic q h n =
      petermannCorrectionCoeff q h n := rfl

theorem petermannCorrectionArithmetic_multiplicative
    (q h : ℕ) :
    (petermannCorrectionArithmetic q h).IsMultiplicative := by
  constructor
  · change petermannCorrectionCoeff q h 1 = 1
    simp [petermannCorrectionCoeff]
  · intro m n hcop
    change petermannCorrectionCoeff q h (m * n) =
      petermannCorrectionCoeff q h m * petermannCorrectionCoeff q h n
    by_cases hm0 : m = 0
    · subst m
      have hn1 : n = 1 := by simpa using hcop
      subst n
      simp [petermannCorrectionCoeff]
    · by_cases hn0 : n = 0
      · subst n
        have hm1 : m = 1 := by simpa using hcop
        subst m
        simp [petermannCorrectionCoeff]
      · have hmn0 : m * n ≠ 0 := mul_ne_zero hm0 hn0
        have hpf : (m * n).primeFactors =
            m.primeFactors ∪ n.primeFactors :=
          Nat.primeFactors_mul hm0 hn0
        have hdisj : Disjoint m.primeFactors n.primeFactors := by
          rw [Finset.disjoint_left]
          intro p hpm hpn
          have hpd : p ∣ m.gcd n :=
            Nat.dvd_gcd (Nat.dvd_of_mem_primeFactors hpm)
              (Nat.dvd_of_mem_primeFactors hpn)
          rw [hcop.gcd_eq_one] at hpd
          exact (Nat.prime_of_mem_primeFactors hpm).not_dvd_one hpd
        rw [petermannCorrectionCoeff, if_neg hmn0,
          petermannCorrectionCoeff, if_neg hm0,
          petermannCorrectionCoeff, if_neg hn0, hpf,
          Finset.prod_union hdisj]
        congr 1
        · apply Finset.prod_congr rfl
          intro p hp
          have hpL : p ∈ m.primeFactorsList :=
            Nat.mem_primeFactors_iff_mem_primeFactorsList.mp hp
          rw [Nat.factorization_eq_of_coprime_left hcop hpL]
        · apply Finset.prod_congr rfl
          intro p hp
          have hpL : p ∈ n.primeFactorsList :=
            Nat.mem_primeFactors_iff_mem_primeFactorsList.mp hp
          rw [Nat.factorization_eq_of_coprime_right hcop hpL]

#print axioms petermannSupportedArithmetic_multiplicative
#print axioms omegaArithmetic_multiplicative
#print axioms movingVArithmetic_multiplicative
#print axioms petermannCorrectionArithmetic_multiplicative

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem petermannSupportedArithmetic_prime_pow
    (q : ℕ) (fac : ℕ → ℝ) {p i : ℕ} (hp : p.Prime) :
    petermannSupportedArithmetic q fac (p ^ i) =
      if i = 0 then 1
      else if i = 1 ∧ p.Coprime (6 * q) then fac p
      else 0 := by
  by_cases hi0 : i = 0
  · subst i
    simp [petermannSupportedArithmetic, petermannSupportedCoeff]
  · by_cases hi1 : i = 1
    · subst i
      simp [petermannSupportedArithmetic, petermannSupportedCoeff,
        hp, hp.ne_zero, hp.squarefree]
    · have hsq : ¬ Squarefree (p ^ i) := by
        rw [Nat.squarefree_pow_iff hp.ne_one hi0]
        simp [hi1]
      have hp0 : p ^ i ≠ 0 := pow_ne_zero _ hp.ne_zero
      simp [petermannSupportedArithmetic, petermannSupportedCoeff,
        hi0, hi1, hsq, hp0]

theorem omegaArithmetic_prime_pow
    (q : ℕ) {p i : ℕ} (hp : p.Prime) :
    omegaArithmetic q (p ^ i) =
      if i = 0 then 1
      else if i = 1 ∧ p.Coprime (6 * q) then petermannA p
      else 0 := by
  exact petermannSupportedArithmetic_prime_pow q petermannA hp

theorem movingVArithmetic_prime_pow
    (q h : ℕ) {p i : ℕ} (hp : p.Prime) :
    movingVArithmetic q h (p ^ i) =
      if i = 0 then 1
      else if i = 1 ∧ p.Coprime (6 * q) then
        (if p ∣ h then petermannB p else petermannA p)
      else 0 := by
  exact petermannSupportedArithmetic_prime_pow q
    (fun p => if p ∣ h then petermannB p else petermannA p) hp

theorem petermannCorrectionArithmetic_prime_pow
    (q h : ℕ) {p i : ℕ} (hp : p.Prime) :
    petermannCorrectionArithmetic q h (p ^ i) =
      if i = 0 then 1
      else if p.Coprime (6 * q) ∧ p ∣ h then
        petermannCorrectionPrimePower p i
      else 0 := by
  by_cases hi0 : i = 0
  · subst i
    simp [petermannCorrectionArithmetic, petermannCorrectionCoeff]
  · have hp0 : p ^ i ≠ 0 := pow_ne_zero _ hp.ne_zero
    rw [petermannCorrectionArithmetic_apply,
      petermannCorrectionCoeff, if_neg hp0,
      Nat.primeFactors_prime_pow hi0 hp]
    simp [petermannCorrectionLocal, hp, hi0]

#print axioms petermannSupportedArithmetic_prime_pow
#print axioms petermannCorrectionArithmetic_prime_pow

end PaperB.FixedQ

namespace PaperB.FixedQ

private lemma sum_range_zero_one
    (a : ℝ) (f : ℕ → ℝ) :
    ∀ i : ℕ,
      (∑ j ∈ Finset.range (i + 1),
        (if j = 0 then 1 else if j = 1 then a else 0) * f j) =
      if i = 0 then f 0 else f 0 + a * f 1 := by
  intro i
  induction i with
  | zero => simp
  | succ i ih =>
      rw [Finset.sum_range_succ, ih]
      cases i with
      | zero => simp
      | succ k =>
          have h0 : Nat.succ (Nat.succ k) ≠ 0 := by omega
          have h1 : Nat.succ (Nat.succ k) ≠ 1 := by omega
          simp [h0, h1]

theorem omega_mul_petermannCorrection_prime_pow
    (q h : ℕ) {p i : ℕ} (hp : p.Prime) :
    (omegaArithmetic q * petermannCorrectionArithmetic q h) (p ^ i) =
      movingVArithmetic q h (p ^ i) := by
  rw [ArithmeticFunction.mul_apply,
    Nat.sum_divisorsAntidiagonal
      (fun a b => omegaArithmetic q a * petermannCorrectionArithmetic q h b),
    Nat.sum_divisors_prime_pow hp]
  have hdiv :
      ∀ j ∈ Finset.range (i + 1), p ^ i / p ^ j = p ^ (i - j) := by
    intro j hj
    have hji : j ≤ i := by
      simpa [Finset.mem_range] using hj
    have hpow : p ^ j * p ^ (i - j) = p ^ i :=
      pow_mul_pow_sub p hji
    rw [← hpow]
    exact Nat.mul_div_cancel_left _ (pow_pos hp.pos _)
  by_cases hcop : p.Coprime (6 * q)
  · have homega (j : ℕ) :
        omegaArithmetic q (p ^ j) =
          if j = 0 then 1 else if j = 1 then petermannA p else 0 := by
      rw [omegaArithmetic_prime_pow q hp]
      by_cases hj0 : j = 0
      · simp [hj0]
      · by_cases hj1 : j = 1
        · simp [hj0, hj1, hcop]
        · simp [hj0, hj1]
    have hsum :
        (∑ j ∈ Finset.range (i + 1),
          omegaArithmetic q (p ^ j) *
            petermannCorrectionArithmetic q h (p ^ i / p ^ j)) =
        ∑ j ∈ Finset.range (i + 1),
          (if j = 0 then 1 else if j = 1 then petermannA p else 0) *
            petermannCorrectionArithmetic q h (p ^ (i - j)) := by
      apply Finset.sum_congr rfl
      intro j hj
      rw [homega j, hdiv j hj]
    rw [hsum, sum_range_zero_one]
    simp only [Nat.sub_zero]
    by_cases hph : p ∣ h
    · have hcorr (n : ℕ) :
          petermannCorrectionArithmetic q h (p ^ n) =
            petermannCorrectionPrimePower p n := by
        rw [petermannCorrectionArithmetic_prime_pow q h hp]
        by_cases hn0 : n = 0
        · subst n
          simp [petermannCorrectionPrimePower_zero]
        · simp [hn0, hcop, hph]
      rw [hcorr i, hcorr (i - 1), movingVArithmetic_prime_pow q h hp]
      have hlocal := petermannLocalConvolution_coeff p i
      by_cases hi0 : i = 0
      · subst i
        simpa [hcop, hph, petermannCorrectionPrimePower_zero] using hlocal
      · by_cases hi1 : i = 1
        · subst i
          simp [hcop, hph, petermannCorrectionPrimePower_zero,
            petermannLocalConvolution_degree_one]
        · simpa [hi0, hi1, hcop, hph] using hlocal
    · rw [movingVArithmetic_prime_pow q h hp]
      by_cases hi0 : i = 0
      · subst i
        rw [petermannCorrectionArithmetic_prime_pow
          (q := q) (h := h) (p := p) (i := 0) hp]
        simp [hcop, hph]
      · by_cases hi1 : i = 1
        · subst i
          rw [petermannCorrectionArithmetic_prime_pow
            (q := q) (h := h) (p := p) (i := 1) hp]
          rw [petermannCorrectionArithmetic_prime_pow
            (q := q) (h := h) (p := p) (i := 0) hp]
          simp [hcop, hph]
        · have hi2 : 2 ≤ i := by omega
          have hi1sub : i - 1 ≠ 0 := by omega
          rw [petermannCorrectionArithmetic_prime_pow
            (q := q) (h := h) (p := p) (i := i) hp]
          rw [petermannCorrectionArithmetic_prime_pow
            (q := q) (h := h) (p := p) (i := i - 1) hp]
          simp [hi0, hi1, hi1sub, hcop, hph]
  · have homega (j : ℕ) :
        omegaArithmetic q (p ^ j) = if j = 0 then 1 else 0 := by
      rw [omegaArithmetic_prime_pow q hp]
      by_cases hj0 : j = 0
      · simp [hj0]
      · simp [hj0, hcop]
    have hsum :
        (∑ j ∈ Finset.range (i + 1),
          omegaArithmetic q (p ^ j) *
            petermannCorrectionArithmetic q h (p ^ i / p ^ j)) =
        ∑ j ∈ Finset.range (i + 1),
          (if j = 0 then 1 else 0) *
            petermannCorrectionArithmetic q h (p ^ (i - j)) := by
      apply Finset.sum_congr rfl
      intro j hj
      rw [homega j, hdiv j hj]
    rw [hsum]
    have hzero :
        (∑ j ∈ Finset.range (i + 1),
          (if j = 0 then 1 else 0) *
            petermannCorrectionArithmetic q h (p ^ (i - j))) =
        petermannCorrectionArithmetic q h (p ^ i) := by
      simpa using (sum_range_zero_one 0
        (fun j => petermannCorrectionArithmetic q h (p ^ (i - j))) i)
    rw [hzero, movingVArithmetic_prime_pow q h hp,
      petermannCorrectionArithmetic_prime_pow q h hp]
    by_cases hi0 : i = 0
    · subst i
      simp
    · simp [hi0, hcop]

theorem movingVArithmetic_eq_omega_mul_petermannCorrection
    (q h : ℕ) :
    movingVArithmetic q h =
      omegaArithmetic q * petermannCorrectionArithmetic q h := by
  symm
  apply (ArithmeticFunction.IsMultiplicative.eq_iff_eq_on_prime_powers
    (omegaArithmetic q * petermannCorrectionArithmetic q h)
    ((omegaArithmetic_multiplicative q).mul
      (petermannCorrectionArithmetic_multiplicative q h))
    (movingVArithmetic q h)
    (movingVArithmetic_multiplicative q h)).2
  intro p i hp
  exact omega_mul_petermannCorrection_prime_pow q h hp

#print axioms omega_mul_petermannCorrection_prime_pow
#print axioms movingVArithmetic_eq_omega_mul_petermannCorrection

end PaperB.FixedQ
