import PaperB.FixedQ.H2ProperWeightedFinalAssembly
import PaperB.FixedQ.H2EndpointSmallProduct

open Filter Real Asymptotics
open scoped BigOperators

namespace PaperB.FixedQ

lemma eventually_h2Boolean_log_two :
    ∀ᶠ M : ℕ in atTop, 2 ≤ Real.log (M : ℝ) := by
  have ht : Tendsto (fun M : ℕ => Real.log (M : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  exact ht.eventually (eventually_ge_atTop 2)

lemma eventually_h2Boolean_loglog_one :
    ∀ᶠ M : ℕ in atTop, 1 ≤ Real.log (Real.log (M : ℝ)) := by
  have hlog : Tendsto (fun M : ℕ => Real.log (M : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hll : Tendsto (fun M : ℕ => Real.log (Real.log (M : ℝ))) atTop atTop :=
    Real.tendsto_log_atTop.comp hlog
  exact hll.eventually (eventually_ge_atTop 1)

lemma eventually_h2BooleanRoughCutoff_four :
    ∀ᶠ M : ℕ in atTop, 4 ≤ h2BooleanRoughCutoff M := by
  have hlog : Tendsto (fun M : ℕ => Real.log (M : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hp : Tendsto
      (fun M : ℕ => (Real.log (M : ℝ)) ^ h2BooleanTheta)
      atTop atTop :=
    (tendsto_rpow_atTop h2BooleanTheta_pos).comp hlog
  have he : Tendsto
      (fun M : ℕ => Real.exp ((Real.log (M : ℝ)) ^ h2BooleanTheta))
      atTop atTop :=
    Real.tendsto_exp_atTop.comp hp
  have h4 := he.eventually (eventually_ge_atTop (4 : ℝ))
  filter_upwards [h4] with M hM
  unfold h2BooleanRoughCutoff
  exact Nat.le_floor hM

lemma eventually_h2BooleanRoughCutoff_sq_le :
    ∀ᶠ M : ℕ in atTop, (h2BooleanRoughCutoff M) ^ 2 ≤ M := by
  have hlog : Tendsto (fun M : ℕ => Real.log (M : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hsmallpow : Tendsto
      (fun M : ℕ => (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta))
      atTop atTop :=
    (tendsto_rpow_atTop h2Boolean_one_sub_theta_pos).comp hlog
  have htwo : ∀ᶠ M : ℕ in atTop,
      2 ≤ (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) :=
    hsmallpow.eventually (eventually_ge_atTop 2)
  have hlogpos : ∀ᶠ M : ℕ in atTop, 0 < Real.log (M : ℝ) :=
    hlog.eventually (eventually_gt_atTop (0 : ℝ))
  filter_upwards [htwo, hlogpos, eventually_ge_atTop 1] with M htwo hLpos hM1
  have htheta :
      2 * (Real.log (M : ℝ)) ^ h2BooleanTheta ≤ Real.log (M : ℝ) := by
    have hid :
        (Real.log (M : ℝ)) ^ h2BooleanTheta *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) =
          Real.log (M : ℝ) := by
      rw [← Real.rpow_add hLpos]
      ring_nf
      simp [Real.rpow_one]
    have htwo0 :
        0 ≤ (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) := by
      linarith
    nlinarith [mul_nonneg
      (Real.rpow_nonneg hLpos.le h2BooleanTheta) htwo0]
  have hcut := h2BooleanRoughCutoff_cast_le_exp M
  have hsquareR :
      ((h2BooleanRoughCutoff M : ℝ) ^ 2) ≤ (M : ℝ) := by
    calc
      ((h2BooleanRoughCutoff M : ℝ) ^ 2)
        ≤ (Real.exp ((Real.log (M : ℝ)) ^ h2BooleanTheta)) ^ 2 := by
          gcongr
      _ = Real.exp ((2 : ℝ) * (Real.log (M : ℝ)) ^ h2BooleanTheta) := by
        rw [← Real.exp_nat_mul]
        norm_num
      _ ≤ Real.exp (Real.log (M : ℝ)) := Real.exp_le_exp.mpr htheta
      _ = (M : ℝ) := Real.exp_log
        (by exact_mod_cast (show 0 < M by omega))
  exact_mod_cast hsquareR

lemma eventually_h2Boolean_nthRoot_four_three :
    ∀ᶠ M : ℕ in atTop, 3 ≤ Nat.nthRoot 4 M := by
  filter_upwards [eventually_ge_atTop (3 ^ 4)] with M hM
  exact (Nat.le_nthRoot_iff (by norm_num : 4 ≠ 0)).2 (by simpa using hM)

theorem exists_h2BooleanProperShellConditionThreshold (q : ℕ) :
    ∃ M0 : ℕ, ∀ M : ℕ, M0 ≤ M →
      3 ≤ M ∧
      4 ≤ h2BooleanRoughCutoff M ∧
      3 ≤ Nat.nthRoot 4 M ∧
      (h2BooleanRoughCutoff M) ^ 2 ≤ M ∧
      ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) ∧
      ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) ∧
      2 ≤ Real.log (M : ℝ) ∧
      1 ≤ Real.log (Real.log (M : ℝ)) ∧
      h2BooleanTailCorrectionConst ≤
        (1 / 8 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) ∧
      Real.exp (-(1 / 8 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) ≤
        (Real.log (M : ℝ)) ^ (-4 : ℝ) := by
  obtain ⟨MT, hMT⟩ := exists_h2BooleanTailCorrection_budget
  obtain ⟨MD, hMD⟩ := exists_h2Boolean_bad_exp_decay_threshold
  have hEv :
      ∀ᶠ M : ℕ in atTop,
        3 ≤ M ∧
        4 ≤ h2BooleanRoughCutoff M ∧
        3 ≤ Nat.nthRoot 4 M ∧
        (h2BooleanRoughCutoff M) ^ 2 ≤ M ∧
        ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) ∧
        ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) ∧
        2 ≤ Real.log (M : ℝ) ∧
        1 ≤ Real.log (Real.log (M : ℝ)) := by
    filter_upwards [
      eventually_ge_atTop 3,
      eventually_h2BooleanRoughCutoff_four,
      eventually_h2Boolean_nthRoot_four_three,
      eventually_h2BooleanRoughCutoff_sq_le,
      eventually_ge_atTop 2,
      eventually_ge_atTop ((6 * q) ^ 4 + 1),
      eventually_h2Boolean_log_two,
      eventually_h2Boolean_loglog_one
    ] with M hM3 hY4 hroot hYsq hM2 hMq hlog hll
    exact ⟨hM3, hY4, hroot, hYsq,
      h2Endpoint_quarter_condition hM2,
      h2Endpoint_three_quarter_condition hMq,
      hlog, hll⟩
  obtain ⟨ME, hME⟩ :
      ∃ ME : ℕ, ∀ M : ℕ, ME ≤ M →
        3 ≤ M ∧
        4 ≤ h2BooleanRoughCutoff M ∧
        3 ≤ Nat.nthRoot 4 M ∧
        (h2BooleanRoughCutoff M) ^ 2 ≤ M ∧
        ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) ∧
        ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) ∧
        2 ≤ Real.log (M : ℝ) ∧
        1 ≤ Real.log (Real.log (M : ℝ)) := by
    simpa only [eventually_atTop] using hEv
  refine ⟨max ME (max MT MD), ?_⟩
  intro M hM
  have hME' : ME ≤ M := (le_max_left ME (max MT MD)).trans hM
  have hMT' : MT ≤ M :=
    (le_max_left MT MD).trans ((le_max_right ME (max MT MD)).trans hM)
  have hMD' : MD ≤ M :=
    (le_max_right MT MD).trans ((le_max_right ME (max MT MD)).trans hM)
  rcases hME M hME' with
    ⟨hM3, hY4, hroot, hYsq, hquarter, hthree, hlog, hll⟩
  have htail := (hMT M hMT').2.2
  have hdec := hMD M hMD'
  exact ⟨hM3, hY4, hroot, hYsq, hquarter, hthree, hlog, hll, htail, hdec⟩

theorem h2BooleanProperWeightedDyadicShell_le_rate_eventually
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ M0 : ℕ,
      0 ≤ C ∧
      ∀ A H M : ℕ,
        (¬ 2 ∣ q → 2 ∣ H) →
        M0 ≤ M →
        h2BooleanProperWeightedDyadicShell q A H M ≤
          C * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
            (Real.log (Real.log (M : ℝ))) ^ 2 := by
  rcases h2BooleanProperWeightedDyadicShell_le_rate_of_conditions q hq with
    ⟨C, Mbase, hC, hrate⟩
  obtain ⟨Mcond, hcond⟩ := exists_h2BooleanProperShellConditionThreshold q
  refine ⟨C, max Mbase Mcond, hC, ?_⟩
  intro A H M h2 hM
  have hb : Mbase ≤ M := (le_max_left Mbase Mcond).trans hM
  have hc : Mcond ≤ M := (le_max_right Mbase Mcond).trans hM
  rcases hcond M hc with
    ⟨hM3, hY4, hroot, hYsq, hquarter, hthree, hlog, hll, htail, hdec⟩
  exact hrate A H M h2 hb hM3 hY4 hroot hYsq
    hquarter hthree hlog hll htail hdec

#print axioms exists_h2BooleanProperShellConditionThreshold
#print axioms h2BooleanProperWeightedDyadicShell_le_rate_eventually

end PaperB.FixedQ
