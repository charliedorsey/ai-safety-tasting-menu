import GoldC.QuillonWLemma
import GoldC.QuillonDecorationGronwall
import Mathlib.RingTheory.Coprime.Lemmas
import Mathlib.Analysis.SpecialFunctions.Pow.NNReal

/-!
# Quillon CSC3 F7.4a: the W′ cell bound with explicit gcd moment

For `s = ∏_{p∈P} p` (distinct primes), set
`KB(c) := (∏_{p∈P} 3p³·(p if p ∣ c else 1))^{1/4}`.

* `norm_K_le_KB`: `‖K_s(b, c)‖ ≤ KB(c)` for all `b`. This combines `K_symm` and `K_squarefree_bound`.
* `KB_le`: `KB(c) ≤ 3^{|P|/4}·s^{3/4}·(∏_{p∈P, p|c} p)^{1/4}`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonWCell

open GoldC.QuillonKl GoldC.QuillonCompletion

/-- The Kloosterman majorant. -/
noncomputable def KB (P : Finset ℕ) {s : ℕ} [NeZero s] (c : ZMod s) : ℝ :=
  (∏ p ∈ P, (3 * (p : ℝ) ^ 3 * (if (ZMod.cast c : ZMod p) = 0 then (p : ℝ) else 1))) ^ ((1 : ℝ) / 4)

lemma KB_base_nonneg (P : Finset ℕ) {s : ℕ} [NeZero s] (c : ZMod s) :
    0 ≤ ∏ p ∈ P, (3 * (p : ℝ) ^ 3 * (if (ZMod.cast c : ZMod p) = 0 then (p : ℝ) else 1)) :=
  Finset.prod_nonneg fun p _ => by split_ifs <;> positivity

theorem norm_K_le_KB (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (s : ℕ) (hs : s = ∏ p ∈ P, p)
    [NeZero s] (b c : ZMod s) : ‖K s b c‖ ≤ KB P c := by
  rw [K_symm]
  have h4 := K_squarefree_bound P hP s hs c b
  have h0 := KB_base_nonneg P c
  unfold KB
  have : ‖K s c b‖ = (‖K s c b‖ ^ (4 : ℝ)) ^ ((1 : ℝ) / 4) := by
    rw [← Real.rpow_mul (norm_nonneg _)]; norm_num
  rw [this]
  apply Real.rpow_le_rpow (by positivity) _ (by norm_num)
  rw [show (4 : ℝ) = ((4 : ℕ) : ℝ) by norm_num, Real.rpow_natCast]
  exact h4

theorem KB_le (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) {s : ℕ} [NeZero s] (c : ZMod s) :
    KB P c ≤ (3 : ℝ) ^ ((P.card : ℝ) / 4) * ((∏ p ∈ P, (p : ℝ)) ^ ((3 : ℝ) / 4)) *
      (∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 4) := by
  unfold KB
  have hsplit : ∏ p ∈ P, (3 * (p : ℝ) ^ 3 * (if (ZMod.cast c : ZMod p) = 0 then (p : ℝ) else 1)) =
      (3 : ℝ) ^ P.card * (∏ p ∈ P, (p : ℝ)) ^ 3 *
        ∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) = 0), (p : ℝ) := by
    rw [Finset.prod_mul_distrib, Finset.prod_mul_distrib, Finset.prod_const, Finset.prod_pow,
      Finset.prod_ite, Finset.prod_const_one, mul_one]
  rw [hsplit]
  have h1 : (0 : ℝ) ≤ (3 : ℝ) ^ P.card := by positivity
  have h2 : (0 : ℝ) ≤ (∏ p ∈ P, (p : ℝ)) ^ 3 := by
    have : (0 : ℝ) ≤ ∏ p ∈ P, (p : ℝ) := Finset.prod_nonneg fun p _ => by positivity
    positivity
  have h3 : (0 : ℝ) ≤ ∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) = 0), (p : ℝ) :=
    Finset.prod_nonneg fun p _ => by positivity
  have hP0 : (0 : ℝ) ≤ ∏ p ∈ P, (p : ℝ) := Finset.prod_nonneg fun p _ => by positivity
  rw [Real.mul_rpow (by positivity) h3, Real.mul_rpow h1 h2]
  apply le_of_eq
  congr 2
  · rw [← Real.rpow_natCast, ← Real.rpow_mul (by norm_num)]; congr 1; ring
  · rw [← Real.rpow_natCast, ← Real.rpow_mul hP0]; congr 1; norm_num

/-! ## The gcd moment -/

/-- Symmetric form of the pair count: ordered pairs `y ≠ y'` with `g ∣ y − y'`. -/
lemma gcd_pair_sum_sym (g Y : ℕ) (hg : 1 ≤ g) :
    ∑ y ∈ Icc 1 Y, ∑ y' ∈ (Icc 1 Y).filter (fun y' => y ≠ y' ∧ (g : ℤ) ∣ (y : ℤ) - y'),
      (1 / ((y : ℝ) * y')) ≤ 2 * (1 + Real.log Y) ^ 2 / g := by
  have hbase := GoldC.QuillonCopyG.gcd_pair_sum_le g Y hg
  -- split y ≠ y' into y < y' and y' < y
  have hsplit : ∀ y ∈ Icc 1 Y, ∑ y' ∈ (Icc 1 Y).filter (fun y' => y ≠ y' ∧ (g : ℤ) ∣ (y : ℤ) - y'),
      (1 / ((y : ℝ) * y')) =
      ∑ y' ∈ (Icc 1 Y).filter (fun y' => y < y' ∧ g ∣ y' - y), (1 / ((y : ℝ) * y')) +
      ∑ y' ∈ (Icc 1 Y).filter (fun y' => y' < y ∧ g ∣ y - y'), (1 / ((y : ℝ) * y')) := by
    intro y _
    rw [← Finset.sum_union]
    · apply Finset.sum_congr _ (fun _ _ => rfl)
      ext y'
      simp only [mem_filter, mem_union, mem_Icc]
      constructor
      · rintro ⟨hy', hne, hdvd⟩
        rcases lt_or_gt_of_ne hne with h | h
        · left; refine ⟨hy', h, ?_⟩
          have : (g : ℤ) ∣ ((y' - y : ℕ) : ℤ) := by
            rw [Nat.cast_sub h.le]; rw [← dvd_neg]; convert hdvd using 1; ring
          exact_mod_cast this
        · right; refine ⟨hy', h, ?_⟩
          have : (g : ℤ) ∣ ((y - y' : ℕ) : ℤ) := by rw [Nat.cast_sub h.le]; exact hdvd
          exact_mod_cast this
      · rintro (⟨hy', h, hdvd⟩ | ⟨hy', h, hdvd⟩)
        · refine ⟨hy', h.ne, ?_⟩
          have : (g : ℤ) ∣ ((y' - y : ℕ) : ℤ) := by exact_mod_cast hdvd
          rw [Nat.cast_sub h.le] at this; rw [← dvd_neg]; convert this using 1; ring
        · refine ⟨hy', h.ne', ?_⟩
          have : (g : ℤ) ∣ ((y - y' : ℕ) : ℤ) := by exact_mod_cast hdvd
          rw [Nat.cast_sub h.le] at this; exact this
    · rw [Finset.disjoint_left]
      intro y' h1 h2; simp only [mem_filter] at h1 h2; omega
  rw [Finset.sum_congr rfl hsplit, Finset.sum_add_distrib]
  -- the second double sum equals the first after swapping (y, y')
  have hswap : ∑ y ∈ Icc 1 Y, ∑ y' ∈ (Icc 1 Y).filter (fun y' => y' < y ∧ g ∣ y - y'),
      (1 / ((y : ℝ) * y')) =
      ∑ y ∈ Icc 1 Y, ∑ y' ∈ (Icc 1 Y).filter (fun y' => y < y' ∧ g ∣ y' - y),
        (1 / ((y : ℝ) * y')) := by
    rw [Finset.sum_comm' (t' := Icc 1 Y) (s' := fun y' => (Icc 1 Y).filter (fun y => y' < y ∧ g ∣ y - y'))]
    · refine Finset.sum_congr rfl fun y' _ => Finset.sum_congr rfl fun y _ => by ring
    · intro y y'
      simp only [mem_Icc, mem_filter]
      tauto
  rw [hswap]
  have hg' : (0 : ℝ) < g := by exact_mod_cast hg
  have : 2 * (1 + Real.log Y) ^ 2 / g = (1 + Real.log Y) ^ 2 / g + (1 + Real.log Y) ^ 2 / g := by
    ring
  rw [this]
  exact add_le_add hbase hbase

/-- Expanding `(∏_{p∈S} p)^{1/4}` over subsets. -/
lemma prod_rpow_quarter_eq (S : Finset ℕ) :
    (∏ p ∈ S, (p : ℝ)) ^ ((1 : ℝ) / 4) =
      ∑ D ∈ S.powerset, ∏ p ∈ D, ((p : ℝ) ^ ((1 : ℝ) / 4) - 1) := by
  rw [← Real.finsetProd_rpow S _ (fun p _ => by positivity), ← Finset.prod_one_add]
  exact Finset.prod_congr rfl fun p _ => by ring

lemma prime_prod_dvd (D : Finset ℕ) (hD : ∀ p ∈ D, p.Prime) (z : ℤ)
    (h : ∀ p ∈ D, (p : ℤ) ∣ z) : ((∏ p ∈ D, p : ℕ) : ℤ) ∣ z := by
  push_cast
  apply Finset.prod_dvd_of_coprime _ h
  intro p hp q hq hpq
  simp only [Function.onFun]
  rw [Nat.isCoprime_iff_coprime]
  exact (Nat.coprime_primes (hD p hp) (hD q hq)).2 hpq

/-- **W4 (gcd moment).** For distinct primes `P`,
`Σ_{y≠y' ≤ Y} (1/(yy'))·(∏_{p∈P, p∣y−y'} p)^{1/4} ≤ 2(1+log Y)²·∏_{p∈P}(1+p^{−3/4})`. -/
theorem gcd_moment (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (Y : ℕ) :
    ∑ y ∈ Icc 1 Y, ∑ y' ∈ (Icc 1 Y).filter (fun y' => y ≠ y'),
      (1 / ((y : ℝ) * y')) *
        (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^ ((1 : ℝ) / 4)
    ≤ 2 * (1 + Real.log Y) ^ 2 * ∏ p ∈ P, (1 + (p : ℝ) ^ (-(3 : ℝ) / 4)) := by
  classical
  set a : Finset ℕ → ℝ := fun D => ∏ p ∈ D, ((p : ℝ) ^ ((1 : ℝ) / 4) - 1) with ha_def
  have hq : ∀ p ∈ P, (1 : ℝ) ≤ (p : ℝ) ^ ((1 : ℝ) / 4) := fun p hp =>
    Real.one_le_rpow (by exact_mod_cast (hP p hp).one_lt.le) (by norm_num)
  have ha : ∀ D ∈ P.powerset, 0 ≤ a D := fun D hD => prod_nonneg fun p hp => by
    have := hq p (mem_powerset.1 hD hp); linarith
  set ind : Finset ℕ → ℕ → ℕ → ℝ := fun D y y' =>
    if ((∏ p ∈ D, p : ℕ) : ℤ) ∣ (y : ℤ) - y' then 1 else 0 with hind
  have step1 : ∀ y y' : ℕ,
      (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^ ((1 : ℝ) / 4) ≤
        ∑ D ∈ P.powerset, a D * ind D y y' := by
    intro y y'
    rw [prod_rpow_quarter_eq]
    simp only [hind, mul_ite, mul_one, mul_zero]
    rw [← Finset.sum_filter]
    apply Finset.sum_le_sum_of_subset_of_nonneg
    · intro D hD
      rw [mem_powerset] at hD
      rw [mem_filter, mem_powerset]
      refine ⟨hD.trans (filter_subset _ _), ?_⟩
      apply prime_prod_dvd D (fun p hp => hP p (filter_subset _ _ (hD hp)))
      intro p hp; exact (mem_filter.1 (hD hp)).2
    · intro D hD _
      exact ha D (mem_filter.1 hD).1
  have hY := fun (D : Finset ℕ) (hD : D ∈ P.powerset) =>
    gcd_pair_sum_sym (∏ p ∈ D, p) Y
      (Nat.one_le_iff_ne_zero.2 (Finset.prod_ne_zero_iff.2 fun p hp =>
        (hP p (mem_powerset.1 hD hp)).ne_zero))
  calc _ ≤ ∑ y ∈ Icc 1 Y, ∑ y' ∈ (Icc 1 Y).filter (fun y' => y ≠ y'),
        ∑ D ∈ P.powerset, a D * ((1 / ((y : ℝ) * y')) * ind D y y') := by
        refine sum_le_sum fun y hy => sum_le_sum fun y' hy' => ?_
        have hpos : (0 : ℝ) ≤ 1 / ((y : ℝ) * y') := by positivity
        calc _ ≤ (1 / ((y : ℝ) * y')) * ∑ D ∈ P.powerset, a D * ind D y y' :=
              mul_le_mul_of_nonneg_left (step1 y y') hpos
          _ = _ := by rw [mul_sum]; exact sum_congr rfl fun D _ => by ring
    _ = ∑ D ∈ P.powerset, a D * ∑ y ∈ Icc 1 Y,
          ∑ y' ∈ (Icc 1 Y).filter (fun y' => y ≠ y' ∧
            ((∏ p ∈ D, p : ℕ) : ℤ) ∣ (y : ℤ) - y'), (1 / ((y : ℝ) * y')) := by
        rw [sum_congr rfl fun y _ => sum_comm, sum_comm]
        refine sum_congr rfl fun D _ => ?_
        rw [mul_sum]
        refine sum_congr rfl fun y _ => ?_
        rw [mul_sum, ← filter_filter,
          Finset.sum_filter (p := fun y' : ℕ => ((∏ p ∈ D, p : ℕ) : ℤ) ∣ (y : ℤ) - y')]
        refine sum_congr rfl fun y' _ => ?_
        simp only [hind]; split_ifs <;> simp
    _ ≤ ∑ D ∈ P.powerset, a D * (2 * (1 + Real.log Y) ^ 2 / ((∏ p ∈ D, p : ℕ) : ℝ)) :=
        sum_le_sum fun D hD => mul_le_mul_of_nonneg_left (hY D hD) (ha D hD)
    _ ≤ ∑ D ∈ P.powerset, 2 * (1 + Real.log Y) ^ 2 * ∏ p ∈ D, (p : ℝ) ^ (-(3 : ℝ) / 4) := by
        refine sum_le_sum fun D hD => ?_
        have hDP := mem_powerset.1 hD
        have hC : (0 : ℝ) ≤ 2 * (1 + Real.log Y) ^ 2 := by positivity
        have key : a D / ((∏ p ∈ D, p : ℕ) : ℝ) ≤ ∏ p ∈ D, (p : ℝ) ^ (-(3 : ℝ) / 4) := by
          rw [ha_def, Nat.cast_prod, ← prod_div_distrib]
          apply Finset.prod_le_prod₀
          · intro p hp
            have := hq p (hDP hp)
            have : (0 : ℝ) < p := by exact_mod_cast (hP p (hDP hp)).pos
            apply div_nonneg <;> linarith
          · intro p hp
            have hp0 : (0 : ℝ) < p := by exact_mod_cast (hP p (hDP hp)).pos
            calc ((p : ℝ) ^ ((1 : ℝ) / 4) - 1) / p ≤ (p : ℝ) ^ ((1 : ℝ) / 4) / p :=
                  div_le_div_of_nonneg_right (by linarith) hp0.le
              _ = (p : ℝ) ^ (-(3 : ℝ) / 4) := by
                  rw [← Real.rpow_sub_one hp0.ne']; norm_num
        calc a D * (2 * (1 + Real.log Y) ^ 2 / ((∏ p ∈ D, p : ℕ) : ℝ))
            = 2 * (1 + Real.log Y) ^ 2 * (a D / ((∏ p ∈ D, p : ℕ) : ℝ)) := by ring
          _ ≤ _ := mul_le_mul_of_nonneg_left key hC
    _ = _ := by rw [← mul_sum, ← Finset.prod_one_add]

/-! ## W3: which primes divide the off-diagonal frequency -/

lemma cast_freq_zero {s : ℕ} (p : ℕ) (hp : p.Prime) (hps : p ∣ s) (c₀ : ZMod s) (y y' : ℕ)
    (hy : IsUnit (y : ZMod s)) (hy' : IsUnit (y' : ZMod s))
    (h : (ZMod.cast (c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹)) : ZMod p) = 0) :
    (ZMod.cast c₀ : ZMod p) = 0 ∨ (p : ℤ) ∣ (y : ℤ) - y' := by
  have := Fact.mk hp
  set φ := ZMod.castHom hps (ZMod p)
  have hφ : ∀ x : ZMod s, (ZMod.cast x : ZMod p) = φ x := fun x => (ZMod.castHom_apply x).symm
  rw [hφ, map_mul, map_sub, mul_eq_zero] at h
  rcases h with h | h
  · left; rw [hφ]; exact h
  · right
    have e1 : (y : ZMod p) * φ ((y : ZMod s)⁻¹) = 1 := by
      have := congrArg φ (ZMod.mul_inv_of_unit _ hy); rwa [map_mul, map_natCast, map_one] at this
    have e2 : (y' : ZMod p) * φ ((y' : ZMod s)⁻¹) = 1 := by
      have := congrArg φ (ZMod.mul_inv_of_unit _ hy'); rwa [map_mul, map_natCast, map_one] at this
    have hyy : (y : ZMod p) = y' := by
      have h' : φ ((y : ZMod s)⁻¹) = φ ((y' : ZMod s)⁻¹) := sub_eq_zero.1 h
      calc (y : ZMod p) = y * ((y' : ZMod p) * φ ((y' : ZMod s)⁻¹)) := by rw [e2, mul_one]
        _ = y' * ((y : ZMod p) * φ ((y : ZMod s)⁻¹)) := by rw [h']; ring
        _ = y' := by rw [e1, mul_one]
    have : ((y' : ℤ) : ZMod p) = ((y : ℤ) : ZMod p) := by
      push_cast; exact hyy.symm
    exact (ZMod.intCast_eq_intCast_iff_dvd_sub _ _ _).1 this

/-- Product form of W3: `∏_{p∈P, p∣c} p ≤ G₀(c₀) · ∏_{p∈P, p∣y−y'} p`. -/
lemma prod_freq_le {s : ℕ} (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hs : s = ∏ p ∈ P, p)
    (c₀ : ZMod s) (y y' : ℕ) (hy : IsUnit (y : ZMod s)) (hy' : IsUnit (y' : ZMod s)) :
    ∏ p ∈ P.filter (fun p => (ZMod.cast (c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹)) : ZMod p) = 0),
        (p : ℝ) ≤
      (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) *
        ∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ) := by
  classical
  set B := P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0)
  set C := P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y')
  have h1 : ∀ p ∈ P, (1 : ℝ) ≤ p := fun p hp => by exact_mod_cast (hP p hp).one_lt.le
  have hsub : P.filter (fun p => (ZMod.cast (c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹)) :
      ZMod p) = 0) ⊆ B ∪ C := by
    intro p hp
    rw [mem_filter] at hp
    have hps : p ∣ s := by rw [hs]; exact Finset.dvd_prod_of_mem _ hp.1
    rcases cast_freq_zero p (hP p hp.1) hps c₀ y y' hy hy' hp.2 with h | h
    · exact mem_union_left _ (mem_filter.2 ⟨hp.1, h⟩)
    · exact mem_union_right _ (mem_filter.2 ⟨hp.1, h⟩)
  calc _ ≤ ∏ p ∈ B ∪ C, (p : ℝ) :=
        Finset.prod_le_prod_of_subset_of_one_le₀ hsub (fun p _ => by positivity) fun p hp _ =>
          h1 p (by rcases mem_union.1 hp with h | h <;> exact (mem_filter.1 h).1)
    _ ≤ (∏ p ∈ B ∪ C, (p : ℝ)) * ∏ p ∈ B ∩ C, (p : ℝ) := by
        apply le_mul_of_one_le_right (prod_nonneg fun p _ => by positivity)
        exact Finset.one_le_prod₀ fun p hp => h1 p (mem_filter.1 (mem_inter.1 hp).1).1
    _ = _ := Finset.prod_union_inter

/-- Off-diagonal Kloosterman majorant: `KB(c₀(ȳ−ȳ')) ≤ 3^{|P|/4}s^{3/4}G₀^{1/4}(∏_{p∣y−y'}p)^{1/4}`. -/
lemma KB_offdiag {s : ℕ} [NeZero s] (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hs : s = ∏ p ∈ P, p)
    (c₀ : ZMod s) (y y' : ℕ) (hy : IsUnit (y : ZMod s)) (hy' : IsUnit (y' : ZMod s)) :
    KB P (c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹)) ≤
      (3 : ℝ) ^ ((P.card : ℝ) / 4) * (s : ℝ) ^ ((3 : ℝ) / 4) *
        (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 4) *
        (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^ ((1 : ℝ) / 4) := by
  refine (KB_le P hP _).trans ?_
  have hsR : (∏ p ∈ P, (p : ℝ)) = (s : ℝ) := by rw [hs, Nat.cast_prod]
  rw [hsR, mul_assoc _ (_ ^ ((1 : ℝ) / 4)), ← Real.mul_rpow (prod_nonneg fun p _ => by positivity)
    (prod_nonneg fun p _ => by positivity)]
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  exact Real.rpow_le_rpow (prod_nonneg fun p _ => by positivity)
    (prod_freq_le P hP hs c₀ y y' hy hy') (by norm_num)

/-- **W5 (the W′ cell bound).** For `s = ∏P` (distinct primes), `𝒴 ⊆ [1, Y]` units mod `s`,
`𝒩 ⊆ (N, M]` and `‖α_y‖ ≤ A/y`:

    ‖Σ_n β_n Σ_y α_y g(y,n)‖² ≤ (Σ‖β‖²)·[(M−N)·Σ_y‖α_y‖² + A²·((M−N)·2(1+log Y)²/s
        + 3^{|P|/4}s^{3/4}G₀^{1/4}((M−N)/s + 1 + log s)·2(1+log Y)²∏(1+p^{−3/4}))],

where `G₀ = ∏_{p∈P, p∣c₀} p`. -/
theorem W_cell {s : ℕ} [NeZero s] (hs2 : 2 ≤ s) (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime)
    (hsP : s = ∏ p ∈ P, p) (c₀ : ZMod s) (𝒴 𝒩 : Finset ℕ) (Y N M : ℕ) (hNM : N ≤ M)
    (h𝒩 : 𝒩 ⊆ Ioc N M) (h𝒴 : 𝒴 ⊆ Icc 1 Y) (hunit : ∀ y ∈ 𝒴, IsUnit (y : ZMod s))
    (α β : ℕ → ℂ) (A : ℝ) (hα : ∀ y ∈ 𝒴, ‖α y‖ ≤ A / y) :
    ‖∑ n ∈ 𝒩, β n * ∑ y ∈ 𝒴, α y * GoldC.QuillonW.g c₀ y n‖ ^ 2 ≤
      (∑ n ∈ 𝒩, ‖β n‖ ^ 2) * (((M - N : ℕ) : ℝ) * ∑ y ∈ 𝒴, ‖α y‖ ^ 2 +
        A ^ 2 * (((M - N : ℕ) : ℝ) * (2 * (1 + Real.log Y) ^ 2 / s) +
          (3 : ℝ) ^ ((P.card : ℝ) / 4) * (s : ℝ) ^ ((3 : ℝ) / 4) *
            (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 4) *
            (((M - N : ℕ) : ℝ) / s + 1 + Real.log s) *
            (2 * (1 + Real.log Y) ^ 2 * ∏ p ∈ P, (1 + (p : ℝ) ^ (-(3 : ℝ) / 4))))) := by
  classical
  refine (GoldC.QuillonW.W_cauchy hs2 c₀ 𝒴 𝒩 hNM h𝒩 hunit α β (KB P)
    (fun c b => norm_K_le_KB P hP s hsP b c)).trans ?_
  apply mul_le_mul_of_nonneg_left _ (sum_nonneg fun n _ => by positivity)
  set L : ℝ := ((M - N : ℕ) : ℝ) with hL
  set G : ℝ := (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 4)
    with hG
  set Kc : ℝ := (3 : ℝ) ^ ((P.card : ℝ) / 4) * (s : ℝ) ^ ((3 : ℝ) / 4) * G *
    (L / s + 1 + Real.log s) with hKc
  have hL0 : 0 ≤ L := by positivity
  have hsR : (1 : ℝ) ≤ s := by exact_mod_cast (show 1 ≤ s by omega)
  have hlogs : 0 ≤ Real.log s := Real.log_nonneg hsR
  have hG0 : 0 ≤ G := by positivity
  have hKc0 : 0 ≤ Kc := by positivity
  have hA : ∀ y ∈ 𝒴, 0 ≤ A / y := fun y hy => (norm_nonneg _).trans (hα y hy)
  set T1 : ℕ → ℕ → ℝ := fun y y' => if y = y' then L * ‖α y‖ ^ 2 else 0 with hT1
  set T2 : ℕ → ℕ → ℝ := fun y y' =>
    if y ≠ y' ∧ ((s : ℕ) : ℤ) ∣ (y : ℤ) - y' then 1 / ((y : ℝ) * y') else 0 with hT2
  set T3 : ℕ → ℕ → ℝ := fun y y' => if y ≠ y' then (1 / ((y : ℝ) * y')) *
    (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^ ((1 : ℝ) / 4) else 0
    with hT3
  have hT2n : ∀ y y', 0 ≤ T2 y y' := fun y y' => by simp only [hT2]; split_ifs <;> positivity
  have hT3n : ∀ y y', 0 ≤ T3 y y' := fun y y' => by simp only [hT3]; split_ifs <;> positivity
  have hT1n : ∀ y y', 0 ≤ T1 y y' := fun y y' => by simp only [hT1]; split_ifs <;> positivity
  -- pointwise
  have hpt : ∀ y ∈ 𝒴, ∀ y' ∈ 𝒴, ‖α y‖ * ‖α y'‖ *
      (if (y : ZMod s) = y' then L else
        KB P (c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹)) * (L / s + 1 + Real.log s)) ≤
      T1 y y' + A ^ 2 * L * T2 y y' + A ^ 2 * Kc * T3 y y' := by
    intro y hy y' hy'
    have hy1 : 1 ≤ y := (mem_Icc.1 (h𝒴 hy)).1
    have hy1' : 1 ≤ y' := (mem_Icc.1 (h𝒴 hy')).1
    have hprod : ‖α y‖ * ‖α y'‖ ≤ A ^ 2 * (1 / ((y : ℝ) * y')) := by
      calc ‖α y‖ * ‖α y'‖ ≤ (A / y) * (A / y') :=
            mul_le_mul (hα y hy) (hα y' hy') (norm_nonneg _) (hA y hy)
        _ = _ := by ring
    have h2 := hT2n y y'; have h3 := hT3n y y'; have h1 := hT1n y y'
    have hA2 : 0 ≤ A ^ 2 := sq_nonneg A
    by_cases hyy : y = y'
    · subst hyy
      rw [if_pos rfl]
      have hT1v : T1 y y = L * ‖α y‖ ^ 2 := if_pos rfl
      have : ‖α y‖ * ‖α y‖ * L = L * ‖α y‖ ^ 2 := by ring
      rw [this, hT1v]
      have := mul_nonneg (mul_nonneg hA2 hL0) h2
      have := mul_nonneg (mul_nonneg hA2 hKc0) h3
      linarith
    · have hT1z : T1 y y' = 0 := by simp only [hT1, if_neg hyy]
      rw [hT1z, zero_add]
      split_ifs with hcong
      · -- congruent distinct pair
        have hdvd : ((s : ℕ) : ℤ) ∣ (y : ℤ) - y' := by
          have : ((y' : ℤ) : ZMod s) = ((y : ℤ) : ZMod s) := by push_cast; exact hcong.symm
          exact (ZMod.intCast_eq_intCast_iff_dvd_sub _ _ _).1 this
        have hT2v : T2 y y' = 1 / ((y : ℝ) * y') := if_pos (And.intro hyy hdvd)
        rw [hT2v]
        have := mul_nonneg (mul_nonneg hA2 hKc0) h3
        calc ‖α y‖ * ‖α y'‖ * L ≤ A ^ 2 * (1 / ((y : ℝ) * y')) * L :=
              mul_le_mul_of_nonneg_right hprod hL0
          _ = A ^ 2 * L * (1 / ((y : ℝ) * y')) := by ring
          _ ≤ _ := by linarith
      · have hT3v : T3 y y' = (1 / ((y : ℝ) * y')) *
            (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^ ((1 : ℝ) / 4) := by
          simp only [hT3, if_neg (not_not.2 hyy), if_pos hyy]
        rw [hT3v]
        have hKB := KB_offdiag P hP hsP c₀ y y' (hunit y hy) (hunit y' hy')
        have hLf : 0 ≤ L / s + 1 + Real.log s := by positivity
        have hKB0 : 0 ≤ KB P (c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹)) := by
          unfold KB; exact Real.rpow_nonneg (KB_base_nonneg P _) _
        have := mul_nonneg (mul_nonneg hA2 hL0) h2
        calc ‖α y‖ * ‖α y'‖ * (KB P (c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹)) *
              (L / s + 1 + Real.log s))
            ≤ A ^ 2 * (1 / ((y : ℝ) * y')) * ((3 : ℝ) ^ ((P.card : ℝ) / 4) *
                (s : ℝ) ^ ((3 : ℝ) / 4) * G *
                (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^ ((1 : ℝ) / 4) *
                (L / s + 1 + Real.log s)) :=
              mul_le_mul hprod (mul_le_mul_of_nonneg_right hKB hLf) (by positivity) (by positivity)
          _ = A ^ 2 * Kc * ((1 / ((y : ℝ) * y')) *
              (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^ ((1 : ℝ) / 4)) := by
              rw [hKc]; ring
          _ ≤ _ := by linarith
  -- sum the pointwise bound
  calc _ ≤ ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, (T1 y y' + A ^ 2 * L * T2 y y' + A ^ 2 * Kc * T3 y y') :=
        sum_le_sum fun y hy => sum_le_sum fun y' hy' => hpt y hy y' hy'
    _ = ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, T1 y y' + A ^ 2 * L * ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, T2 y y' +
          A ^ 2 * Kc * ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, T3 y y' := by
        simp only [sum_add_distrib, mul_sum]
    _ ≤ L * ∑ y ∈ 𝒴, ‖α y‖ ^ 2 + A ^ 2 * L * (2 * (1 + Real.log Y) ^ 2 / s) +
          A ^ 2 * Kc * (2 * (1 + Real.log Y) ^ 2 * ∏ p ∈ P, (1 + (p : ℝ) ^ (-(3 : ℝ) / 4))) := by
        have e1 : ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, T1 y y' = L * ∑ y ∈ 𝒴, ‖α y‖ ^ 2 := by
          rw [mul_sum]; refine sum_congr rfl fun y hy => ?_
          simp only [hT1]; rw [sum_ite_eq 𝒴 y (fun _ => L * ‖α y‖ ^ 2), if_pos hy]
        have e2 : ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, T2 y y' ≤ 2 * (1 + Real.log Y) ^ 2 / s := by
          calc _ ≤ ∑ y ∈ Icc 1 Y, ∑ y' ∈ Icc 1 Y, T2 y y' := by
                refine (sum_le_sum fun y _ => sum_le_sum_of_subset_of_nonneg h𝒴
                  fun y' _ _ => hT2n y y').trans ?_
                exact sum_le_sum_of_subset_of_nonneg h𝒴 fun y _ _ => sum_nonneg fun y' _ => hT2n y y'
            _ = ∑ y ∈ Icc 1 Y, ∑ y' ∈ (Icc 1 Y).filter (fun y' => y ≠ y' ∧
                  ((s : ℕ) : ℤ) ∣ (y : ℤ) - y'), (1 / ((y : ℝ) * y')) := by
                refine sum_congr rfl fun y _ => ?_
                rw [sum_filter]
            _ ≤ _ := gcd_pair_sum_sym s Y (by omega)
        have e3 : ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, T3 y y' ≤
            2 * (1 + Real.log Y) ^ 2 * ∏ p ∈ P, (1 + (p : ℝ) ^ (-(3 : ℝ) / 4)) := by
          calc _ ≤ ∑ y ∈ Icc 1 Y, ∑ y' ∈ Icc 1 Y, T3 y y' := by
                refine (sum_le_sum fun y _ => sum_le_sum_of_subset_of_nonneg h𝒴
                  fun y' _ _ => hT3n y y').trans ?_
                exact sum_le_sum_of_subset_of_nonneg h𝒴 fun y _ _ => sum_nonneg fun y' _ => hT3n y y'
            _ = ∑ y ∈ Icc 1 Y, ∑ y' ∈ (Icc 1 Y).filter (fun y' => y ≠ y'),
                  (1 / ((y : ℝ) * y')) *
                    (∏ p ∈ P.filter (fun p : ℕ => (p : ℤ) ∣ (y : ℤ) - y'), (p : ℝ)) ^
                      ((1 : ℝ) / 4) := by
                refine sum_congr rfl fun y _ => ?_
                rw [sum_filter]
            _ ≤ _ := gcd_moment P hP Y
        rw [e1]
        have hAL : 0 ≤ A ^ 2 * L := by positivity
        have hAK : 0 ≤ A ^ 2 * Kc := by positivity
        have := mul_le_mul_of_nonneg_left e2 hAL
        have := mul_le_mul_of_nonneg_left e3 hAK
        linarith
    _ = _ := by rw [hKc]; ring

end GoldC.QuillonWCell

#print axioms GoldC.QuillonWCell.norm_K_le_KB
#print axioms GoldC.QuillonWCell.KB_le
#print axioms GoldC.QuillonWCell.gcd_pair_sum_sym
#print axioms GoldC.QuillonWCell.gcd_moment
#print axioms GoldC.QuillonWCell.prod_freq_le
#print axioms GoldC.QuillonWCell.W_cell
