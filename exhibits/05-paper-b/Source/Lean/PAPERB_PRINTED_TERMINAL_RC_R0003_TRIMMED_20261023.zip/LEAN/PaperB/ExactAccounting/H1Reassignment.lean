import PaperB.Closure
import PaperB.FixedQ.PureHeightReflection

open scoped BigOperators

namespace PaperB.ExactAccounting

open PaperB.FixedQ

/-- Exact terminal accounting after assigning the pure-height overlap to the
reflected one-dimensional boundary package.  This is an equality only: it
states no analytic estimate and introduces no terminal contract. -/
theorem manuscriptA1Kernel_sub_manuscriptB1Kernel_eq_reassigned_boundary_ledger
    {q a b h : ℕ}
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    manuscriptA1Kernel q a h -
      PaperB.Closure.manuscriptB1Kernel q a b h
    =
      (cStarReal q h * pureLeftFamily q a h -
        PaperB.Closure.manuscriptS1Kernel q a h)
      +
      (cStarReal q h *
          (heightBoundaryFamily q a h +
            ∑' e : Finset ℕ, pureHeightSupportTerm q a h e)
        - PaperB.Closure.manuscriptS1Kernel q
            (PaperB.Closure.reflectedResidue q b) h)
      +
      cStarReal q h *
        (twoDimensionalFamilyRemainder q a h -
          ∑' e : Finset ℕ, pureHeightSupportTerm q a h e) := by
  have hA :=
    manuscriptA1Kernel_eq_boundary_families_add_twoDimensional
      (q := q) (a := a) (h := h) h2admissible
  unfold PaperB.Closure.manuscriptB1Kernel
  rw [hA]
  ring

#print axioms manuscriptA1Kernel_sub_manuscriptB1Kernel_eq_reassigned_boundary_ledger

end PaperB.ExactAccounting
