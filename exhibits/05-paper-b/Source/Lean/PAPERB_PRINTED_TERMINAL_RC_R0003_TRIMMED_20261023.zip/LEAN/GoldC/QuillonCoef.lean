import GoldC.QuillonRowNF
import GoldC.QuillonRCellApp

/-!
# Quillon CSC3 F7.9e: mode coefficients and gcd identification for the four row types

* `norm_main_le`, `norm_class_le`: the `rowW` coefficients satisfy `‖A ρ k‖ ≤ (|μ| + M·Gb)/k`.
* `filter_cast_eq`: for `c_k = ±k·H·u` with `p ∤ H`, `p ∤ u` (`p | s` prime),
  `cast(c_k) = 0` in `ZMod p` iff `p | k`. So `G₀(c_k) = ∏_{p|s, p|k} p`.
* `norm_βk`, `norm_coefR_le`: the `rowR` coefficients satisfy `‖coef k‖ ≤ (|μ| + 2M·Gb + 1)/k`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonCoef

open GoldC.QuillonRowNF GoldC.QuillonR

lemma norm_main_le (μ : ℝ) (k s : ℕ) (hk : 1 ≤ k) (hs : 1 ≤ s) :
    ‖((-(2 * μ) : ℝ) : ℂ) * αm k s‖ ≤ |μ| / k := by
  rw [norm_mul, Complex.norm_real, Real.norm_eq_abs, abs_neg, abs_mul, abs_two]
  have h := norm_αm_le k s hk hs
  have hkR : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hpi : (2 : ℝ) ≤ Real.pi := Real.two_le_pi
  calc 2 * |μ| * ‖αm k s‖ ≤ 2 * |μ| * (1 / (2 * Real.pi * k)) := by gcongr
    _ ≤ |μ| / k := by
        rw [div_eq_mul_one_div |μ|]
        have : 2 * |μ| * (1 / (2 * Real.pi * k)) = |μ| * (1 / (Real.pi * k)) := by field_simp
        rw [this]
        apply mul_le_mul_of_nonneg_left _ (abs_nonneg _)
        apply one_div_le_one_div_of_le (by positivity); nlinarith

lemma norm_bS_le (M : ℕ) (Γ : ℕ → ℕ → ℝ) (Gb : ℝ) (hGb : ∀ b ν, |Γ b ν| ≤ Gb) (s b : ℕ) (z : ℤ)
    (ρ : ZMod M) : ‖bS M Γ s b z ρ‖ ≤ 2 * Gb := by
  unfold bS
  rw [norm_mul, norm_mul, norm_eR, one_mul, Complex.norm_real, Real.norm_eq_abs]
  have h1 : ‖eR ((z : ℝ) * ((M - 1 : ℕ) : ℝ) / M) - 1‖ ≤ 2 := by
    calc _ ≤ ‖eR ((z : ℝ) * ((M - 1 : ℕ) : ℝ) / M)‖ + ‖(1 : ℂ)‖ := norm_sub_le _ _
      _ = 2 := by rw [norm_eR, norm_one]; norm_num
  have h0 : 0 ≤ Gb := (abs_nonneg _).trans (hGb b 0)
  calc |Γ b ((ρ.val * s) % M)| * ‖eR ((z : ℝ) * ((M - 1 : ℕ) : ℝ) / M) - 1‖ ≤ Gb * 2 := by
        gcongr; exact hGb _ _
    _ = 2 * Gb := by ring

lemma norm_BclS_le (M : ℕ) (Γ : ℕ → ℕ → ℝ) (Gb : ℝ) (hGb : ∀ b ν, |Γ b ν| ≤ Gb) (s : ℕ) (z : ℤ)
    (ρ : ZMod M) : ‖BclS M Γ s z ρ‖ ≤ 2 * M * Gb := by
  unfold BclS
  refine (norm_sum_le _ _).trans ?_
  calc ∑ b ∈ range M, ‖bS M Γ s b z ρ‖ ≤ ∑ _b ∈ range M, 2 * Gb :=
        sum_le_sum fun b _ => norm_bS_le M Γ Gb hGb s b z ρ
    _ = 2 * M * Gb := by rw [sum_const, card_range, nsmul_eq_mul]; ring

lemma norm_class_le (M : ℕ) (Γ : ℕ → ℕ → ℝ) (Gb : ℝ) (hGb : ∀ b ν, |Γ b ν| ≤ Gb) (s k : ℕ) (z : ℤ)
    (ρ : ZMod M) (hk : 1 ≤ k) (hMs : 1 ≤ M * s) :
    ‖αm k (M * s) * BclS M Γ s z ρ‖ ≤ M * Gb / k := by
  rw [norm_mul]
  have h1 := norm_αm_le k (M * s) hk hMs
  have h2 := norm_BclS_le M Γ Gb hGb s z ρ
  have h0 : 0 ≤ Gb := (abs_nonneg _).trans (hGb 0 0)
  have hkR : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hpi : (2 : ℝ) ≤ Real.pi := Real.two_le_pi
  calc ‖αm k (M * s)‖ * ‖BclS M Γ s z ρ‖ ≤ (1 / (2 * Real.pi * k)) * (2 * M * Gb) :=
        mul_le_mul h1 h2 (norm_nonneg _) (by positivity)
    _ ≤ M * Gb / k := by
        rw [div_eq_mul_one_div (M * Gb : ℝ)]
        have : 1 / (2 * Real.pi * k) * (2 * M * Gb) = (M * Gb : ℝ) * (1 / (Real.pi * k)) := by field_simp
        rw [this]
        apply mul_le_mul_of_nonneg_left _ (by positivity)
        apply one_div_le_one_div_of_le (by positivity); nlinarith

/-- `cast(z·u) = 0` in `ZMod p` iff `p | z`, for a unit factor `u` coprime to `p`. -/
lemma cast_int_eq_zero_iff {s : ℕ} (p : ℕ) (hp : p.Prime) (hps : p ∣ s) (z u : ℤ)
    (hu : ¬ (p : ℤ) ∣ u) :
    ((ZMod.cast (((z * u : ℤ)) : ZMod s) : ZMod p) = 0 ↔ (p : ℤ) ∣ z) := by
  rw [ZMod.cast_intCast hps, ZMod.intCast_zmod_eq_zero_iff_dvd]
  constructor
  · intro h
    rcases (Int.Prime.dvd_mul' hp h) with h1 | h1
    · exact h1
    · exact absurd h1 hu
  · intro h; exact Dvd.dvd.mul_right h u

lemma filter_cast_eq {s : ℕ} (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p)
    (u : ℤ) (hu : ∀ p ∈ P, ¬ (p : ℤ) ∣ u) (σ : ℤ) (hσ : σ = 1 ∨ σ = -1) (k : ℕ) :
    P.filter (fun p => (ZMod.cast ((((σ * k) * u : ℤ)) : ZMod s) : ZMod p) = 0) =
      P.filter (fun p => p ∣ k) := by
  ext p
  simp only [mem_filter]
  constructor
  · rintro ⟨hpP, h⟩
    refine ⟨hpP, ?_⟩
    have hps : p ∣ s := hsP ▸ dvd_prod_of_mem _ hpP
    have := (cast_int_eq_zero_iff p (hP p hpP) hps (σ * k) u (hu p hpP)).1 h
    rcases hσ with rfl | rfl
    · rw [one_mul] at this; exact_mod_cast this
    · rw [neg_one_mul, Int.dvd_neg] at this; exact_mod_cast this
  · rintro ⟨hpP, h⟩
    refine ⟨hpP, ?_⟩
    have hps : p ∣ s := hsP ▸ dvd_prod_of_mem _ hpP
    refine (cast_int_eq_zero_iff p (hP p hpP) hps (σ * k) u (hu p hpP)).2 ?_
    exact Dvd.dvd.mul_left (Int.natCast_dvd_natCast.2 h) σ

lemma norm_βk (k : ℕ) (hk : 1 ≤ k) : ‖βk k‖ ≤ 1 / k := by
  unfold βk
  rw [norm_div, Complex.norm_I]
  have hkR : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hpi : (2 : ℝ) ≤ Real.pi := Real.two_le_pi
  have e : ‖(2 * (Real.pi : ℂ) * (k : ℂ))‖ = 2 * Real.pi * k := by
    rw [show (2 * (Real.pi : ℂ) * (k : ℂ)) = ((2 * Real.pi * k : ℝ) : ℂ) by push_cast; ring,
      Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (by positivity)]
  rw [e]
  apply one_div_le_one_div_of_le (by positivity); nlinarith

end GoldC.QuillonCoef

#print axioms GoldC.QuillonCoef.norm_main_le
#print axioms GoldC.QuillonCoef.norm_class_le
#print axioms GoldC.QuillonCoef.filter_cast_eq
#print axioms GoldC.QuillonCoef.norm_βk
