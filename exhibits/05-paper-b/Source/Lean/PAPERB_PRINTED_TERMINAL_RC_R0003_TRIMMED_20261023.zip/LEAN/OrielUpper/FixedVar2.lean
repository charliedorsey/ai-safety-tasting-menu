import OrielUpper.FixedVar

/-!
# Oriel Upper — the head bound for the inner sums
-/

open Finset
open scoped ArithmeticFunction.Moebius

namespace OrielUpper

variable {P : ℕ} [NeZero P]

/-- Class-wise summand. -/
noncomputable def phiC (m H : ℕ) (Λ : ZMod P → ℝ) (α β : ZMod P) (X0 : ℝ) (e c k : ℕ) : ℝ :=
  psiR m H Λ α β ((e * c : ℕ) : ZMod P) ((e * c : ℕ) : ZMod m) (X0 / ((e : ℝ) * k)) /
    ((e : ℝ) * k)

lemma coprime_mod_iff {k Q : ℕ} : Nat.Coprime (k % Q) Q ↔ Nat.Coprime k Q := by
  show Nat.gcd (k % Q) Q = 1 ↔ Nat.gcd k Q = 1
  rw [← Nat.gcd_rec, Nat.gcd_comm]

/-- Residue-class decomposition of the inner sum. -/
lemma innerS_classes {m H : ℕ} [NeZero m] {Λ : ZMod P → ℝ} {α β : ZMod P} {X0 : ℝ}
    {A Bn e : ℕ} (heQ : Nat.Coprime e (P * m)) :
    innerS m H Λ α β X0 A Bn e =
      ∑ c ∈ (range (P * m)).filter (fun c => Nat.Coprime c (P * m)),
        ∑ k ∈ (Ioc (A / e) (Bn / e)).filter (fun k => k ≡ c [MOD P * m]),
          phiC m H Λ α β X0 e c k := by
  set Q := P * m
  have hQ : 0 < Q := Nat.mul_pos (NeZero.pos P) (NeZero.pos m)
  unfold innerS
  rw [sum_comm' (t' := Ioc (A / e) (Bn / e))
    (s' := fun k => ((range Q).filter (fun c => Nat.Coprime c Q)).filter (fun c => k ≡ c [MOD Q]))]
  · apply sum_congr rfl
    intro k _
    have hfilt : ((range Q).filter (fun c => Nat.Coprime c Q)).filter (fun c => k ≡ c [MOD Q]) =
        if Nat.Coprime k Q then {k % Q} else ∅ := by
      ext c
      simp only [mem_filter, mem_range]
      split_ifs with hk
      · simp only [mem_singleton]
        constructor
        · rintro ⟨⟨hc, _⟩, hkc⟩
          have : k % Q = c % Q := hkc
          rw [Nat.mod_eq_of_lt hc] at this; exact this.symm
        · rintro rfl
          exact ⟨⟨Nat.mod_lt _ hQ, coprime_mod_iff.mpr hk⟩, by
            show k % Q = k % Q % Q; rw [Nat.mod_mod]⟩
      · simp only [notMem_empty, iff_false, not_and]
        intro ⟨hc, hcc⟩ hkc
        have : k % Q = c := by
          have := hkc; unfold Nat.ModEq at this; rw [Nat.mod_eq_of_lt hc] at this; exact this
        apply hk; rw [← coprime_mod_iff, this]; exact hcc
    rw [hfilt]
    have hcop : Nat.Coprime (e * k) Q ↔ Nat.Coprime k Q := by
      rw [Nat.coprime_mul_iff_left]; exact ⟨fun h => h.2, fun h => ⟨heQ, h⟩⟩
    by_cases hk : Nat.Coprime k Q
    · rw [if_pos (hcop.mpr hk), if_pos hk, sum_singleton]
      unfold phiC
      have hP : ((e * (k % Q) : ℕ) : ZMod P) = ((e * k : ℕ) : ZMod P) := by
        rw [ZMod.natCast_eq_natCast_iff']
        rw [Nat.mul_mod, Nat.mod_mod_of_dvd _ (dvd_mul_right P m), ← Nat.mul_mod]
      have hm : ((e * (k % Q) : ℕ) : ZMod m) = ((e * k : ℕ) : ZMod m) := by
        rw [ZMod.natCast_eq_natCast_iff']
        rw [Nat.mul_mod, Nat.mod_mod_of_dvd _ (dvd_mul_left m P), ← Nat.mul_mod]
      rw [hP, hm]
      push_cast; rfl
    · rw [if_neg (fun h => hk (hcop.mp h)), if_neg hk, sum_empty]
  · intro k c
    simp only [mem_filter]
    tauto

theorem oriel_inner_head {m H : ℕ} [NeZero m] {Λ : ZMod P → ℝ} {B : ℝ}
    (hB : ∀ z, |Λ z| ≤ B) {α β : ZMod P} (hβ : IsUnit β) (hmP : Nat.Coprime m P)
    (hH : IsUnit (H : ZMod m)) {X0 : ℝ} (hX0 : 0 ≤ X0) {A Bn e : ℕ} (hA : 1 ≤ A)
    (hAB : A ≤ Bn) (he : 1 ≤ e) (heQ : Nat.Coprime e (P * m)) :
    |innerS m H Λ α β X0 A Bn e| ≤
      (m.divisors.card : ℝ) * (2 * P + 1) * B * (1 + Real.log ((Bn : ℝ) / A)) / (m * e) +
        (P * m) * (B / A * (2 * (X0 / A) / m + 4 * P + 5)) := by
  set Q := P * m with hQdef
  have hP0 : 0 < P := NeZero.pos P
  have hm0 : 0 < m := NeZero.pos m
  have hQ : 0 < Q := Nat.mul_pos hP0 hm0
  have hQr : (0 : ℝ) < Q := by exact_mod_cast hQ
  have hmr : (0 : ℝ) < m := by exact_mod_cast hm0
  have hPr : (0 : ℝ) < P := by exact_mod_cast hP0
  have her : (0 : ℝ) < e := by exact_mod_cast (show 0 < e by omega)
  have hAr : (0 : ℝ) < A := by exact_mod_cast (show 0 < A by omega)
  have hB0 : 0 ≤ B := le_trans (abs_nonneg _) (hB 0)
  have hmPu : IsUnit (m : ZMod P) := (ZMod.isUnit_iff_coprime m P).mpr hmP
  have hcopPm : Nat.Coprime P m := Nat.Coprime.symm hmP
  set ℓ := 1 + Real.log ((Bn : ℝ) / A) with hℓ
  have hℓ0 : 0 ≤ ℓ := by
    have : 0 ≤ Real.log ((Bn : ℝ) / A) := Real.log_nonneg (by
      rw [le_div_iff₀ hAr, one_mul]; exact_mod_cast hAB)
    linarith
  set CQ := (range Q).filter (fun c => Nat.Coprime c Q)
  set a := A / e
  set b := Bn / e
  set W' : ℝ := B / A * (2 * (X0 / A) / m + 4 * P + 5)
  -- lower end of the scale
  have hEA : (A : ℝ) ≤ e * (a + 1) := by
    have h := Nat.lt_div_mul_add (a := A) (show 0 < e by omega)
    have : (A : ℝ) < (a : ℝ) * e + e := by exact_mod_cast h
    nlinarith
  rw [innerS_classes heQ]
  -- error terms
  set E : ℕ → ℝ := fun c =>
    ∑ k ∈ (Ioc a b).filter (fun k => k ≡ c [MOD Q]), phiC m H Λ α β X0 e c k -
      (∑ k ∈ Ioc a b, phiC m H Λ α β X0 e c k) / Q with hE
  have hEc : ∀ c ∈ CQ, |E c| ≤ W' := by
    intro c hc
    have hcQ : Nat.Coprime c Q := (mem_filter.mp hc).2
    have hecQ : Nat.Coprime (e * c) Q := Nat.coprime_mul_iff_left.mpr ⟨heQ, hcQ⟩
    rcases le_or_gt b a with hba | hab
    · simp only [hE, Ioc_eq_empty_of_le hba, filter_empty, sum_empty, zero_div, sub_zero,
        abs_zero]
      positivity
    have hbv := oriel_bv_progression hQ c a b hab.le (fun k => phiC m H Λ α β X0 e c k)
    have hvar := oriel_variation (m := m) (H := H) hB (α := α) hmPu hβ
      (isUnit_of_coprime_mul_left hecQ) (isUnit_of_coprime_mul_right hecQ) hX0 he hab
    refine hbv.trans ?_
    simp only [phiC]
    refine le_trans ?_ (hvar.trans ?_)
    · apply le_of_eq; push_cast; ring_nf
    · -- monotonicity in the scale e(a+1) ≥ A
      have hE0 : (0 : ℝ) < e * (a + 1) := by positivity
      have h1 : B / (e * (a + 1)) ≤ B / A := div_le_div_of_nonneg_left hB0 hAr hEA
      have h2 : X0 / (e * (a + 1)) ≤ X0 / A := div_le_div_of_nonneg_left hX0 hAr hEA
      have h3 : 0 ≤ 2 * (X0 / (e * (a + 1))) / m + 4 * P + 5 := by positivity
      calc B / (e * (a + 1)) * (2 * (X0 / (e * (a + 1))) / m + 4 * P + 5)
          ≤ B / A * (2 * (X0 / (e * (a + 1))) / m + 4 * P + 5) :=
            mul_le_mul_of_nonneg_right h1 h3
        _ ≤ B / A * (2 * (X0 / A) / m + 4 * P + 5) := by
            apply mul_le_mul_of_nonneg_left _ (by positivity)
            have : 2 * (X0 / (e * (a + 1))) / m ≤ 2 * (X0 / A) / m := by gcongr
            linarith
  -- main term via CRT + principal cancellation
  have hmain : |∑ c ∈ CQ, (∑ k ∈ Ioc a b, phiC m H Λ α β X0 e c k) / Q| ≤
      (m.divisors.card : ℝ) * (2 * P + 1) * B * ℓ / (m * e) := by
    rw [← sum_div, sum_comm]
    have hk : ∀ k ∈ Ioc a b, ∑ c ∈ CQ, phiC m H Λ α β X0 e c k =
        (∑ v : (ZMod P)ˣ, ∑ t : (ZMod m)ˣ,
          psiR m H Λ α β (v : ZMod P) (t : ZMod m) (X0 / ((e : ℝ) * k))) / ((e : ℝ) * k) := by
      intro k _
      unfold phiC
      rw [← sum_div]
      congr 1
      exact oriel_crt_units_sum hcopPm heQ
        (fun v t => psiR m H Λ α β v t (X0 / ((e : ℝ) * k)))
    rw [sum_congr rfl hk, abs_div, abs_of_pos hQr]
    have hpc : ∀ k ∈ Ioc a b, |(∑ v : (ZMod P)ˣ, ∑ t : (ZMod m)ˣ,
          psiR m H Λ α β (v : ZMod P) (t : ZMod m) (X0 / ((e : ℝ) * k))) / ((e : ℝ) * k)| ≤
        (m.divisors.card : ℝ) * ((2 * P + 1) * (Nat.totient P * B)) / e * (1 / k) := by
      intro k hk'
      have hk1 : 1 ≤ k := Nat.lt_of_le_of_lt (Nat.zero_le _) (mem_Ioc.mp hk').1
      have hkr : (0 : ℝ) < k := by exact_mod_cast (show 0 < k by omega)
      rw [abs_div, abs_of_pos (by positivity : (0 : ℝ) < e * k)]
      have := oriel_principal_cancellation (P := P) (m := m) (H := H) hB (α := α) hmP hβ hH
        (x := X0 / ((e : ℝ) * k)) (by positivity)
      calc _ ≤ (m.divisors.card : ℝ) * ((2 * P + 1) * (Nat.totient P * B)) / (e * k) :=
            div_le_div_of_nonneg_right this (by positivity)
        _ = _ := by field_simp
    have hsum : |∑ k ∈ Ioc a b, (∑ v : (ZMod P)ˣ, ∑ t : (ZMod m)ˣ,
          psiR m H Λ α β (v : ZMod P) (t : ZMod m) (X0 / ((e : ℝ) * k))) / ((e : ℝ) * k)| ≤
        (m.divisors.card : ℝ) * ((2 * P + 1) * (Nat.totient P * B)) / e * ℓ := by
      refine (abs_sum_le_sum_abs _ _).trans ?_
      refine (sum_le_sum hpc).trans ?_
      rw [← mul_sum]
      apply mul_le_mul_of_nonneg_left (oriel_harmonic_div hA hAB he) (by positivity)
    have htot : (Nat.totient P : ℝ) ≤ P := by exact_mod_cast Nat.totient_le P
    calc |∑ k ∈ Ioc a b, (∑ v : (ZMod P)ˣ, ∑ t : (ZMod m)ˣ,
          psiR m H Λ α β (v : ZMod P) (t : ZMod m) (X0 / ((e : ℝ) * k))) / ((e : ℝ) * k)| / Q
        ≤ (m.divisors.card : ℝ) * ((2 * P + 1) * (Nat.totient P * B)) / e * ℓ / Q :=
          div_le_div_of_nonneg_right hsum hQr.le
      _ ≤ (m.divisors.card : ℝ) * ((2 * P + 1) * (P * B)) / e * ℓ / Q := by gcongr
      _ = (m.divisors.card : ℝ) * (2 * P + 1) * B * ℓ / (m * e) := by
          rw [hQdef]; push_cast; field_simp
  -- assemble
  have hsplit : ∑ c ∈ CQ, ∑ k ∈ (Ioc a b).filter (fun k => k ≡ c [MOD Q]),
      phiC m H Λ α β X0 e c k =
      ∑ c ∈ CQ, (∑ k ∈ Ioc a b, phiC m H Λ α β X0 e c k) / Q + ∑ c ∈ CQ, E c := by
    rw [← sum_add_distrib]; apply sum_congr rfl; intro c _; simp only [hE]; ring
  rw [hsplit]
  have hCQ : (CQ.card : ℝ) ≤ P * m := by
    have : CQ.card ≤ Q := (card_filter_le _ _).trans (by simp)
    exact_mod_cast this
  calc |∑ c ∈ CQ, (∑ k ∈ Ioc a b, phiC m H Λ α β X0 e c k) / Q + ∑ c ∈ CQ, E c|
      ≤ |∑ c ∈ CQ, (∑ k ∈ Ioc a b, phiC m H Λ α β X0 e c k) / Q| + |∑ c ∈ CQ, E c| :=
        abs_add_le _ _
    _ ≤ (m.divisors.card : ℝ) * (2 * P + 1) * B * ℓ / (m * e) + CQ.card * W' := by
        apply add_le_add hmain
        refine (abs_sum_le_sum_abs _ _).trans ?_
        calc ∑ c ∈ CQ, |E c| ≤ ∑ _c ∈ CQ, W' := sum_le_sum hEc
          _ = CQ.card * W' := by rw [sum_const, nsmul_eq_mul]
    _ ≤ (m.divisors.card : ℝ) * (2 * P + 1) * B * ℓ / (m * e) + (P * m) * W' := by
        have : 0 ≤ W' := by positivity
        gcongr

end OrielUpper
