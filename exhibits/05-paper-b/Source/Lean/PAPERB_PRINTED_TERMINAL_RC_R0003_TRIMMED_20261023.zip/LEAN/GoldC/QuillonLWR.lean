import GoldC.QuillonLWeilB
import GoldC.QuillonLR

/-!
# Quillon LONG L7: LONG-right Weil W′ parameters and the eventual Weil bracket

On LONG-right (`r^{1+δ} < s ≤ r²`) the W′ route uses modulus `s`, Ramaré primes `y ∈ [X, Y]` with
`Y = ⌊s^η⌋`, `η = Λ^{−1/10}`, and `r ≥ s^{1/2+3η}` (so the cofactor range is `≥ s^{1/2+2η}/2`).
* `yfacts`: deterministic facts on `Y`, `Lw = ⌊s^{1/2+3η}⌋ − 1`, `Lw/Y`.
* `W_bracketW_ev`: the Weil bracket
  `2(1+log Y)/√s + 2(1+log Y)·8^k·√(s^{1/2}/s + s^{1/2}(1+log s)/(Lw/Y)) ≤ 6Λ^{−100}`
  once `4Λ^σ ≤ log s ≤ Λ` and `8^k ≤ 8Λ^{208}`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonLWR

open GoldC.QuillonEv GoldC.QuillonSetup GoldC.QuillonLam GoldC.QuillonLSetup GoldC.QuillonCopyM

/-- `η = Λ^{−1/10}`. -/
noncomputable def ηp (h : ℕ) : ℝ := (Real.log h) ^ (-(1 / 10 : ℝ))
noncomputable def Yη (η : ℝ) (s : ℕ) : ℕ := ⌊(s : ℝ) ^ η⌋₊
noncomputable def Lwη (η : ℝ) (s : ℕ) : ℕ := ⌊(s : ℝ) ^ ((1 : ℝ) / 2 + 3 * η)⌋₊ - 1
noncomputable def YL (h s : ℕ) : ℕ := Yη (ηp h) s
noncomputable def LwL (h s : ℕ) : ℕ := Lwη (ηp h) s

lemma yfacts (η : ℝ) (hη0 : 0 < η) (hη : η ≤ 1 / 8) (s : ℕ) (hs : 0 < s)
    (h8 : (8 : ℝ) ≤ (s : ℝ) ^ η) :
    1 ≤ Yη η s ∧ (Yη η s : ℝ) ≤ (s : ℝ) ^ η ∧ Yη η s ≤ Lwη η s ∧
      (s : ℝ) ^ ((1 : ℝ) / 2 + 2 * η) / 2 ≤ ((Lwη η s / Yη η s : ℕ) : ℝ) ∧
      1 ≤ Lwη η s / Yη η s ∧ (Lwη η s : ℝ) ≤ (s : ℝ) := by
  have hs1 : (1 : ℝ) ≤ s := by exact_mod_cast hs
  set a := (s : ℝ) ^ η with ha
  set b := (s : ℝ) ^ ((1 : ℝ) / 2 + 2 * η) with hb
  have hab : (s : ℝ) ^ ((1 : ℝ) / 2 + 3 * η) = a * b := by
    rw [ha, hb, ← Real.rpow_add (by linarith)]; ring_nf
  have hba : a ≤ b := Real.rpow_le_rpow_of_exponent_le hs1 (by linarith)
  have hY1 : 1 ≤ Yη η s := by unfold Yη; apply Nat.le_floor; push_cast; linarith
  have hYa : (Yη η s : ℝ) ≤ a := Nat.floor_le (by positivity)
  have hY0 : (0 : ℝ) < Yη η s := by exact_mod_cast hY1
  have hfl := Nat.lt_floor_add_one (a * b)
  have hfl1 : 1 ≤ ⌊a * b⌋₊ := by apply Nat.le_floor; push_cast; nlinarith
  have hLw : a * b - 2 < (Lwη η s : ℝ) := by
    unfold Lwη; rw [hab, Nat.cast_sub hfl1]; push_cast; linarith
  have hLwle : (Lwη η s : ℝ) ≤ a * b := by
    unfold Lwη; rw [hab]
    have : ((⌊a * b⌋₊ - 1 : ℕ) : ℝ) ≤ (⌊a * b⌋₊ : ℝ) := by exact_mod_cast Nat.sub_le _ _
    linarith [Nat.floor_le (show 0 ≤ a * b by positivity)]
  have hdivR : b - 1 / 4 ≤ (Lwη η s : ℝ) / Yη η s := by
    have h1 : (a * b - 2) / a ≤ (Lwη η s : ℝ) / Yη η s := by
      calc (a * b - 2) / a ≤ (Lwη η s : ℝ) / a :=
            div_le_div_of_nonneg_right hLw.le (by linarith)
        _ ≤ (Lwη η s : ℝ) / Yη η s :=
            div_le_div_of_nonneg_left (by linarith) hY0 hYa
    have h2 : (a * b - 2) / a = b - 2 / a := by field_simp
    have h3 : 2 / a ≤ 1 / 4 := by rw [div_le_iff₀ (by linarith)]; linarith
    linarith
  have hnd := GoldC.QuillonEv.natdiv_ge (Lwη η s) (Yη η s) hY1
  have hD : b / 2 ≤ ((Lwη η s / Yη η s : ℕ) : ℝ) := by linarith
  refine ⟨hY1, hYa, ?_, hD, ?_, ?_⟩
  · have : (Yη η s : ℝ) ≤ Lwη η s := by nlinarith
    exact_mod_cast this
  · have : (1 : ℝ) ≤ ((Lwη η s / Yη η s : ℕ) : ℝ) := by linarith
    exact_mod_cast this
  · have : (s : ℝ) ^ ((1 : ℝ) / 2 + 3 * η) ≤ s := by
      calc (s : ℝ) ^ ((1 : ℝ) / 2 + 3 * η) ≤ (s : ℝ) ^ (1 : ℝ) :=
            Real.rpow_le_rpow_of_exponent_le hs1 (by linarith)
        _ = s := Real.rpow_one _
    linarith

/-- eventual admissibility of the LONG-right Weil parameters. -/
lemma yl_ev : ∃ Λ₀ : ℝ, 1 ≤ Λ₀ ∧ ∀ Λ : ℝ, Λ₀ ≤ Λ → ∀ s : ℕ, 0 < s → 4 * Λ ^ σ₀ ≤ Real.log s →
    0 < Λ ^ (-(1 / 10 : ℝ)) ∧ Λ ^ (-(1 / 10 : ℝ)) ≤ 1 / 8 ∧ (8 : ℝ) ≤ (s : ℝ) ^ (Λ ^ (-(1 / 10 : ℝ))) ∧
      Real.exp (4 * Λ ^ (σ₀ - 1 / 10)) ≤ (s : ℝ) ^ (Λ ^ (-(1 / 10 : ℝ))) := by
  have hτ : 0 < σ₀ - 1 / 10 := by unfold σ₀; norm_num
  obtain ⟨Λ₁, hΛ₁, h1⟩ := GoldC.QuillonLam.exp_ge 8 4 (σ₀ - 1 / 10) (by norm_num) hτ
  obtain ⟨Λ₂, hΛ₂, h2⟩ := GoldC.QuillonLam.const_le_rpow 8 (1 / 10) (by norm_num)
  refine ⟨max Λ₁ Λ₂, le_trans hΛ₁ (le_max_left _ _), fun Λ hΛ s hs hlog => ?_⟩
  have hΛ0 : 0 < Λ := by linarith [le_max_left Λ₁ Λ₂]
  have hη0 : 0 < Λ ^ (-(1 / 10 : ℝ)) := by positivity
  have hs0 : (0 : ℝ) < s := by exact_mod_cast hs
  have hkey : Real.exp (4 * Λ ^ (σ₀ - 1 / 10)) ≤ (s : ℝ) ^ (Λ ^ (-(1 / 10 : ℝ))) := by
    rw [Real.rpow_def_of_pos hs0]
    apply Real.exp_le_exp.2
    have e : Λ ^ (-(1 / 10 : ℝ)) * (4 * Λ ^ σ₀) = 4 * Λ ^ (σ₀ - 1 / 10) := by
      rw [mul_left_comm, ← Real.rpow_add hΛ0]; ring_nf
    rw [← e, mul_comm (Real.log s)]
    exact mul_le_mul_of_nonneg_left hlog hη0.le
  refine ⟨hη0, ?_, le_trans (h1 Λ (le_trans (le_max_left _ _) hΛ)) hkey, hkey⟩
  have h8 := h2 Λ (le_trans (le_max_right _ _) hΛ)
  rw [Real.rpow_neg hΛ0.le, inv_le_comm₀ (by positivity) (by norm_num)]
  linarith

lemma sqrt_le_three (Λ : ℝ) (hΛ : 1 ≤ Λ) : Real.sqrt (5 * Λ) ≤ 3 * Λ := by
  rw [Real.sqrt_le_left (by linarith)]; nlinarith

set_option maxHeartbeats 4000000 in
/-- **The LONG-right Weil bracket.** -/
theorem W_bracketW_ev :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ Λ : ℝ, Λ₀ ≤ Λ → ∀ s : ℕ, 0 < s → 4 * Λ ^ σ₀ ≤ Real.log s →
      Real.log s ≤ Λ → ∀ k : ℕ, (8 : ℝ) ^ k ≤ 8 * Λ ^ (208 : ℝ) →
      2 * (1 + Real.log (Yη (Λ ^ (-(1 / 10 : ℝ))) s : ℝ)) / Real.sqrt s +
        2 * (1 + Real.log (Yη (Λ ^ (-(1 / 10 : ℝ))) s : ℝ)) * (8 : ℝ) ^ k *
          Real.sqrt ((s : ℝ) ^ ((1 : ℝ) / 2) / s + (s : ℝ) ^ ((1 : ℝ) / 2) * (1 + Real.log s) /
            ((Lwη (Λ ^ (-(1 / 10 : ℝ))) s / Yη (Λ ^ (-(1 / 10 : ℝ))) s : ℕ) : ℝ)) ≤
        6 * Λ ^ (-(100 : ℝ)) := by
  have hτ : 0 < σ₀ - 1 / 10 := by unfold σ₀; norm_num
  obtain ⟨Λ₁, hΛ₁, hY⟩ := yl_ev
  obtain ⟨Λ₂, hΛ₂, hd1⟩ := decay 1 102 2 σ₀ (by norm_num) (by norm_num) σ₀_pos
  obtain ⟨Λ₃, hΛ₃, hd2⟩ := decay 210 102 4 (σ₀ - 1 / 10) (by norm_num) (by norm_num) hτ
  refine ⟨max 20 (max Λ₁ (max Λ₂ Λ₃)), le_trans (by norm_num) (le_max_left _ _), ?_⟩
  intro Λ hΛ s hs hlog hlogle k hk
  have L0 : (20 : ℝ) ≤ Λ := le_trans (le_max_left _ _) hΛ
  have L1 : Λ₁ ≤ Λ := le_trans (by simp) hΛ
  have L2 : Λ₂ ≤ Λ := le_trans (by simp) hΛ
  have L3 : Λ₃ ≤ Λ := le_trans (by simp) hΛ
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  set η := Λ ^ (-(1 / 10 : ℝ)) with hηdef
  obtain ⟨hη0, hη8, h8s, hexpη⟩ := hY Λ L1 s hs hlog
  obtain ⟨hY1, hYa, -, hD, -, -⟩ := yfacts η hη0 hη8 s hs h8s
  set Y := Yη η s
  set D := ((Lwη η s / Yη η s : ℕ) : ℝ) with hDdef
  have hs0 : (0 : ℝ) < s := by exact_mod_cast hs
  have hs1 : (1 : ℝ) ≤ s := by exact_mod_cast hs
  set L := Real.log s with hL
  have hL0 : 0 ≤ L := Real.log_nonneg hs1
  -- `1 + log Y ≤ 2Λ`
  have hlY : 1 + Real.log Y ≤ 2 * Λ := by
    have hY0 : (0 : ℝ) < Y := by exact_mod_cast hY1
    have h1 : Real.log Y ≤ Real.log ((s : ℝ) ^ η) := Real.log_le_log hY0 hYa
    rw [Real.log_rpow hs0] at h1
    have : η * L ≤ L := by nlinarith
    linarith
  have hlY0 : 0 ≤ 1 + Real.log Y := by
    have := Real.log_natCast_nonneg Y; linarith
  -- `1/√s ≤ exp(−2Λ^σ)`
  have hsq : 1 / Real.sqrt s ≤ Real.exp (-(2 * Λ ^ σ₀)) := by
    have e : Real.sqrt s = Real.exp (L / 2) := by
      rw [Real.sqrt_eq_rpow, Real.rpow_def_of_pos hs0, hL]; ring_nf
    rw [e, one_div, ← Real.exp_neg]
    exact Real.exp_le_exp.2 (by linarith)
  -- `s^{−η} ≤ exp(−4Λ^{σ−1/10})`
  have hsη : ((s : ℝ) ^ η)⁻¹ ≤ Real.exp (-(4 * Λ ^ (σ₀ - 1 / 10))) := by
    rw [Real.exp_neg]; exact inv_anti₀ (Real.exp_pos _) hexpη
  have hsηpos : 0 < (s : ℝ) ^ η := by positivity
  -- `Q ≤ 5Λ s^{−2η}`
  have hDpos : 0 < D := lt_of_lt_of_le (by positivity) hD
  have hQ : (s : ℝ) ^ ((1 : ℝ) / 2) / s + (s : ℝ) ^ ((1 : ℝ) / 2) * (1 + L) / D ≤
      5 * Λ * ((s : ℝ) ^ η)⁻¹ ^ 2 := by
    have e1 : (s : ℝ) ^ ((1 : ℝ) / 2) / s = ((s : ℝ) ^ ((1 : ℝ) / 2))⁻¹ := by
      have hsq2 : (s : ℝ) ^ ((1 : ℝ) / 2) * (s : ℝ) ^ ((1 : ℝ) / 2) = s := by
        rw [← Real.rpow_add hs0]; norm_num
      have hp : 0 < (s : ℝ) ^ ((1 : ℝ) / 2) := by positivity
      calc (s : ℝ) ^ ((1 : ℝ) / 2) / s =
            (s : ℝ) ^ ((1 : ℝ) / 2) / ((s : ℝ) ^ ((1 : ℝ) / 2) * (s : ℝ) ^ ((1 : ℝ) / 2)) := by rw [hsq2]
        _ = _ := by field_simp
    have e2 : ((s : ℝ) ^ η)⁻¹ ^ 2 = ((s : ℝ) ^ (2 * η))⁻¹ := by
      rw [inv_pow, ← Real.rpow_natCast, ← Real.rpow_mul hs0.le]; ring_nf
    rw [e2]
    have hs2η : (s : ℝ) ^ (2 * η) ≤ (s : ℝ) ^ ((1 : ℝ) / 2) :=
      Real.rpow_le_rpow_of_exponent_le hs1 (by linarith)
    have hp2 : 0 < (s : ℝ) ^ (2 * η) := by positivity
    have t1 : ((s : ℝ) ^ ((1 : ℝ) / 2))⁻¹ ≤ ((s : ℝ) ^ (2 * η))⁻¹ := inv_anti₀ hp2 hs2η
    have hbsplit : (s : ℝ) ^ ((1 : ℝ) / 2 + 2 * η) = (s : ℝ) ^ ((1 : ℝ) / 2) * (s : ℝ) ^ (2 * η) :=
      Real.rpow_add hs0 _ _
    have t2 : (s : ℝ) ^ ((1 : ℝ) / 2) * (1 + L) / D ≤ 2 * (1 + L) * ((s : ℝ) ^ (2 * η))⁻¹ := by
      rw [div_le_iff₀ hDpos]
      have hp1 : 0 < (s : ℝ) ^ ((1 : ℝ) / 2) := by positivity
      calc (s : ℝ) ^ ((1 : ℝ) / 2) * (1 + L) =
            2 * (1 + L) * ((s : ℝ) ^ (2 * η))⁻¹ * ((s : ℝ) ^ ((1 : ℝ) / 2 + 2 * η) / 2) := by
            rw [hbsplit]; field_simp
        _ ≤ 2 * (1 + L) * ((s : ℝ) ^ (2 * η))⁻¹ * D :=
            mul_le_mul_of_nonneg_left hD (by positivity)
    rw [e1]
    have hinv0 : 0 ≤ ((s : ℝ) ^ (2 * η))⁻¹ := by positivity
    have : 1 + 2 * (1 + L) ≤ 5 * Λ := by linarith
    nlinarith
  have hQ0 : 0 ≤ (s : ℝ) ^ ((1 : ℝ) / 2) / s + (s : ℝ) ^ ((1 : ℝ) / 2) * (1 + L) / D := by positivity
  have hsqQ : Real.sqrt ((s : ℝ) ^ ((1 : ℝ) / 2) / s + (s : ℝ) ^ ((1 : ℝ) / 2) * (1 + L) / D) ≤
      3 * Λ * ((s : ℝ) ^ η)⁻¹ := by
    calc _ ≤ Real.sqrt (5 * Λ * ((s : ℝ) ^ η)⁻¹ ^ 2) := Real.sqrt_le_sqrt hQ
      _ = Real.sqrt (5 * Λ) * ((s : ℝ) ^ η)⁻¹ := by
          rw [Real.sqrt_mul (by linarith), Real.sqrt_sq (by positivity)]
      _ ≤ 3 * Λ * ((s : ℝ) ^ η)⁻¹ :=
          mul_le_mul_of_nonneg_right (sqrt_le_three Λ hΛ1) (by positivity)
  -- decay
  have hd1' := hd1 Λ L2
  have hd2' := hd2 Λ L3
  rw [Real.rpow_one] at hd1'
  have e102 : Λ ^ (-(102 : ℝ)) * Λ ^ (2 : ℝ) = Λ ^ (-(100 : ℝ)) := by
    rw [← Real.rpow_add hΛ0]; norm_num
  have hΛ2 : (400 : ℝ) ≤ Λ ^ (2 : ℝ) := by
    rw [show Λ ^ (2 : ℝ) = Λ * Λ by rw [show (2 : ℝ) = (2 : ℕ) by norm_num, Real.rpow_natCast]; ring]
    nlinarith
  have hp102 : 0 ≤ Λ ^ (-(102 : ℝ)) := by positivity
  have e210 : Λ ^ (210 : ℝ) = Λ * Λ ^ (208 : ℝ) * Λ := by
    rw [show Λ * Λ ^ (208 : ℝ) * Λ = Λ ^ (1 : ℝ) * Λ ^ (208 : ℝ) * Λ ^ (1 : ℝ) by rw [Real.rpow_one],
      ← Real.rpow_add hΛ0, ← Real.rpow_add hΛ0]; norm_num
  have h8k0 : 0 ≤ (8 : ℝ) ^ k := by positivity
  have T1 : 2 * (1 + Real.log Y) / Real.sqrt s ≤ 4 * Λ ^ (-(102 : ℝ)) := by
    calc 2 * (1 + Real.log Y) / Real.sqrt s = 2 * (1 + Real.log Y) * (1 / Real.sqrt s) := by ring
      _ ≤ 2 * (2 * Λ) * Real.exp (-(2 * Λ ^ σ₀)) :=
          mul_le_mul (by linarith) hsq (by positivity) (by positivity)
      _ = 4 * (Λ * Real.exp (-(2 * Λ ^ σ₀))) := by ring
      _ ≤ 4 * Λ ^ (-(102 : ℝ)) := by linarith
  have T2 : 2 * (1 + Real.log Y) * (8 : ℝ) ^ k *
      Real.sqrt ((s : ℝ) ^ ((1 : ℝ) / 2) / s + (s : ℝ) ^ ((1 : ℝ) / 2) * (1 + L) / D) ≤
      96 * Λ ^ (-(102 : ℝ)) := by
    calc _ ≤ 2 * (2 * Λ) * (8 * Λ ^ (208 : ℝ)) * (3 * Λ * Real.exp (-(4 * Λ ^ (σ₀ - 1 / 10)))) := by
          apply mul_le_mul (mul_le_mul (by linarith) hk h8k0 (by positivity)) _ (Real.sqrt_nonneg _)
            (by positivity)
          exact hsqQ.trans (mul_le_mul_of_nonneg_left hsη (by positivity))
      _ = 96 * (Λ ^ (210 : ℝ) * Real.exp (-(4 * Λ ^ (σ₀ - 1 / 10)))) := by rw [e210]; ring
      _ ≤ 96 * Λ ^ (-(102 : ℝ)) := by linarith
  calc _ ≤ 4 * Λ ^ (-(102 : ℝ)) + 96 * Λ ^ (-(102 : ℝ)) := add_le_add T1 T2
    _ = 100 * Λ ^ (-(102 : ℝ)) := by ring
    _ ≤ 6 * (Λ ^ (-(102 : ℝ)) * Λ ^ (2 : ℝ)) := by
        have := mul_le_mul_of_nonneg_left hΛ2 hp102; linarith
    _ = 6 * Λ ^ (-(100 : ℝ)) := by rw [e102]

open GoldC.QuillonWFinal in
set_option maxHeartbeats 4000000 in
/-- Each `WTerm` is `≤ Λ^{−95}` eventually. -/
theorem W_term_ev_LR (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (h H : ℕ), Λ₀ ≤ Real.log h → H ≤ h →
      ∀ (s M : ℕ) [NeZero s] [NeZero M],
      ∀ (C U : Finset ℕ), (∀ p ∈ C, p.Prime) → s = ∏ p ∈ C, p → M = 6 * q →
        4 * (Real.log h) ^ σ₀ ≤ Real.log (s : ℝ) → (s : ℝ) ≤ h →
        (8 : ℝ) ^ C.card ≤ 8 * (Real.log h) ^ (208 : ℝ) →
        (∀ p ∈ U, p.Prime ∧ 5 ≤ p ∧ p ≤ H ^ 2) →
        ∀ (A : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s),
          (∀ ρ j, 1 ≤ j → ‖A ρ j‖ ≤ (300 * (q : ℝ) ^ 2) / j) →
          (∀ j, 1 ≤ j → C.filter (fun p => (ZMod.cast (c j) : ZMod p) = 0) = C.filter (fun p => p ∣ j)) →
          GoldC.QuillonLWeilB.WTermW C U (Icc 1 (6 * q * h)) A c (Xp h) (YL h s) (H ^ 2) (LwL h s) ≤
            (Real.log h) ^ (-(95 : ℝ)) := by
  set Ab : ℝ := 300 * (q : ℝ) ^ 2 with hAb
  set E : ℝ := Real.exp 10 * (2 * 2 + 1) ^ 10 with hE
  set K1 : ℝ := 5 * (6 * q) * (6 * q * Ab) * 2 * 8 with hK1
  set K2 : ℝ := 6 * q * Ab * 2 * E * 12.5 with hK2
  obtain ⟨Λ₁, hΛ₁, hbr⟩ := W_bracketW_ev
  obtain ⟨Λ₂, hΛ₂, hAω⟩ := Aω_le 5 (1 / 2) (by norm_num) (by norm_num)
  obtain ⟨Λ₃, hΛ₃, hyl⟩ := yl_ev
  obtain ⟨Λ₄, hΛ₄, hK1Λ⟩ := const_le_rpow K1 1 one_pos
  obtain ⟨Λ₅, hΛ₅, hK2Λ⟩ := const_le_rpow K2 1 one_pos
  set Λ₀ := max 2 (max Λ₁ (max Λ₂ (max Λ₃ (max Λ₄ (max Λ₅ (1 + Real.log (6 * q))))))) with hΛ₀
  refine ⟨Λ₀, le_max_left _ _, ?_⟩
  intro h H hΛ hHh s M _ _ C U hC hsC hM hlog hsh h8C hU A c hA hc
  set Λ := Real.log h with hΛdef
  have hge : ∀ x, x ≤ Λ₀ → x ≤ Λ := fun x hx => le_trans hx hΛ
  have hΛ2 : 2 ≤ Λ := hge _ (le_max_left _ _)
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  have L1 := hge Λ₁ (by simp [hΛ₀])
  have L2 := hge Λ₂ (by simp [hΛ₀])
  have L3 := hge Λ₃ (by simp [hΛ₀])
  have L4 := hge Λ₄ (by simp [hΛ₀])
  have L5 := hge Λ₅ (by simp [hΛ₀])
  have L6 := hge (1 + Real.log (6 * q)) (by simp [hΛ₀])
  have hh1n : 1 ≤ h := by
    rcases Nat.eq_zero_or_pos h with h0 | h0
    · exfalso
      have : Real.log (h : ℝ) = 0 := by rw [h0]; simp
      linarith
    · exact h0
  have hh1 : (1 : ℝ) ≤ h := by exact_mod_cast hh1n
  have hh0 : (0 : ℝ) < h := by linarith
  have hspos : 0 < s := by rw [hsC]; exact prod_pos fun p hp => (hC p hp).pos
  have hs0 : (0 : ℝ) < s := by exact_mod_cast hspos
  obtain ⟨hη0, hη8, h8s, -⟩ := hyl Λ L3 s hspos hlog
  obtain ⟨-, -, -, -, hN0, hLws0⟩ := yfacts (Λ ^ (-(1 / 10 : ℝ))) hη0 hη8 s hspos h8s
  have hN : 1 ≤ LwL h s / YL h s := hN0
  have hLws : (LwL h s : ℝ) ≤ s := hLws0
  have hX2 : 2 ≤ Xp h := Xp_two hΛ2
  have hW := GoldC.QuillonLWeilB.WTermW_le (s := s) (M := M) C hC U (fun p hp => (hU p hp).2.1) (6 * q * h) A c Ab
    (by positivity) hA hc (Xp h) (YL h s) (H ^ 2) (LwL h s) (by omega) hN
  refine le_trans hW ?_
  subst hM
  -- factor bounds
  have hmax : ((max (H ^ 2) (LwL h s) : ℕ) : ℝ) ≤ (h : ℝ) ^ 2 := by
    have h1 : H ^ 2 ≤ h ^ 2 := Nat.pow_le_pow_left hHh 2
    have h2 : (LwL h s : ℝ) ≤ h := le_trans hLws hsh
    have h3 : (h : ℝ) ≤ (h : ℝ) ^ 2 := le_self_pow₀ hh1 (by norm_num)
    rcases le_total (H ^ 2) (LwL h s) with hle | hle
    · rw [max_eq_right hle]; exact le_trans h2 h3
    · rw [max_eq_left hle]; exact_mod_cast h1
  have hmax0 : (0 : ℝ) < ((max (H ^ 2) (LwL h s) : ℕ) : ℝ) := by
    have : 0 < LwL h s := lt_of_lt_of_le (lt_of_lt_of_le Nat.zero_lt_one hN) (Nat.div_le_self _ _)
    exact_mod_cast lt_of_lt_of_le this (le_max_right _ _)
  have hlogmax : Real.log ((max (H ^ 2) (LwL h s) : ℕ) : ℝ) ≤ 2 * Λ := by
    have := Real.log_le_log hmax0 hmax
    rwa [Real.log_pow, Nat.cast_ofNat] at this
  have b1 : (((Nat.log 2 (max (H ^ 2) (LwL h s)) + 1 : ℕ)) : ℝ) ≤ 5 * Λ := by
    have := GoldC.QuillonLam.natlog_le_of _ _ hlogmax
    rw [max_eq_left (show (0 : ℝ) ≤ 2 * Λ by linarith)] at this
    push_cast; linarith
  have b2 : (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 * (max (H ^ 2) (LwL h s)) ^ 2)) : ℝ) ^ 30) ^ 2
      ≤ Λ := by
    have hN2 : Real.log ((2 * (max (H ^ 2) (LwL h s)) ^ 2 : ℕ) : ℝ) ≤ 5 * Λ := by
      rw [Nat.cast_mul, Nat.cast_pow, Nat.cast_ofNat, Real.log_mul (by norm_num) (by positivity),
        Real.log_pow]
      have : Real.log 2 < 1 := by have := Real.log_two_lt_d9; linarith
      have hl := hlogmax
      push_cast at hl ⊢; linarith
    have h1 := hAω Λ L2 _ hN2
    have h0 : 0 ≤ Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 * (max (H ^ 2) (LwL h s)) ^ 2)) : ℝ) ^ 30 := by
      positivity
    calc _ ≤ (Λ ^ (1 / 2 : ℝ)) ^ 2 := pow_le_pow_left₀ h0 h1 2
      _ = Λ := by rw [← Real.rpow_natCast, ← Real.rpow_mul hΛ0.le]; norm_num
  have b3 : 1 + Real.log ((6 * q * h : ℕ) : ℝ) ≤ 2 * Λ := by
    push_cast
    rw [Real.log_mul (by positivity) hh0.ne']
    linarith
  have hXge := Xp_ge (h := h) hΛ1
  have hXpos : (0 : ℝ) < Xp h := by
    have : (0 : ℝ) < Λ ^ (200 : ℝ) := by positivity
    linarith
  have b4 : 2 / Real.sqrt (Xp h) ≤ 2 * Λ ^ (-(100 : ℝ)) := by
    have hsq : Λ ^ (100 : ℝ) ≤ Real.sqrt (Xp h) := by
      rw [Real.le_sqrt (by positivity) hXpos.le]
      calc (Λ ^ (100 : ℝ)) ^ 2 = Λ ^ (200 : ℝ) := by
            rw [← Real.rpow_natCast, ← Real.rpow_mul hΛ0.le]; norm_num
        _ ≤ Xp h := hXge
    have hp : 0 < Λ ^ (100 : ℝ) := by positivity
    rw [div_le_iff₀ (lt_of_lt_of_le hp hsq)]
    have e : Λ ^ (-(100 : ℝ)) * Λ ^ (100 : ℝ) = 1 := by
      rw [← Real.rpow_add hΛ0]; norm_num
    have hm : 0 ≤ Λ ^ (-(100 : ℝ)) := by positivity
    calc (2 : ℝ) = 2 * (Λ ^ (-(100 : ℝ)) * Λ ^ (100 : ℝ)) := by rw [e]; ring
      _ ≤ 2 * (Λ ^ (-(100 : ℝ)) * Real.sqrt (Xp h)) := by gcongr
      _ = 2 * Λ ^ (-(100 : ℝ)) * Real.sqrt (Xp h) := by ring
  have hlogle : Real.log s ≤ Λ := Real.log_le_log hs0 hsh
  have b5 : 2 * (1 + Real.log (YL h s : ℝ)) / Real.sqrt s +
        2 * (1 + Real.log (YL h s : ℝ)) * (8 : ℝ) ^ C.card *
          Real.sqrt ((s : ℝ) ^ ((1 : ℝ) / 2) / s + (s : ℝ) ^ ((1 : ℝ) / 2) * (1 + Real.log s) /
            ((LwL h s / YL h s : ℕ) : ℝ)) ≤ 6 * Λ ^ (-(100 : ℝ)) :=
    hbr Λ L1 s hspos hlog hlogle C.card h8C
  have b6 : ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) ≤ E * Λ ^ (10 : ℝ) := by
    have := prodU_le_pow U (fun p hp => ⟨(hU p hp).1, (hU p hp).2.1⟩) (h ^ 2)
      (fun p hp => le_trans (hU p hp).2.2 (Nat.pow_le_pow_left hHh 2)) 2 Λ (by norm_num) hΛ1
      (by push_cast; rw [Real.log_pow]; push_cast; linarith)
    exact this
  have b7 : (12.5 : ℝ) / Xp h ≤ 12.5 * Λ ^ (-(200 : ℝ)) := by
    rw [div_le_iff₀ hXpos]
    have e : Λ ^ (-(200 : ℝ)) * Λ ^ (200 : ℝ) = 1 := by
      rw [← Real.rpow_add hΛ0]; norm_num
    have hp : 0 ≤ Λ ^ (-(200 : ℝ)) := by positivity
    calc (12.5 : ℝ) = 12.5 * (Λ ^ (-(200 : ℝ)) * Λ ^ (200 : ℝ)) := by rw [e]; ring
      _ ≤ 12.5 * (Λ ^ (-(200 : ℝ)) * Xp h) := by gcongr
      _ = 12.5 * Λ ^ (-(200 : ℝ)) * Xp h := by ring
  have hbr0 : 0 ≤ 2 / Real.sqrt (Xp h) := by positivity
  have hlogJ0 : 0 ≤ 1 + Real.log ((6 * q * h : ℕ) : ℝ) := by
    have := Real.log_natCast_nonneg (6 * q * h); linarith
  have hU0 : 0 ≤ ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) := prod_nonneg fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast (hU p hp).2.1
    have : 0 ≤ 1 / ((p : ℝ) - 3) := div_nonneg zero_le_one (by linarith)
    linarith
  have hYge : 0 ≤ 1 + Real.log (YL h s : ℝ) := by
    have := Real.log_natCast_nonneg (YL h s); linarith
  have hbrk0 : 0 ≤ 2 / Real.sqrt (Xp h) + 2 * (1 + Real.log (YL h s : ℝ)) / Real.sqrt s +
          2 * (1 + Real.log (YL h s : ℝ)) * (8 : ℝ) ^ C.card *
            Real.sqrt ((s : ℝ) ^ ((1 : ℝ) / 2) / s + (s : ℝ) ^ ((1 : ℝ) / 2) * (1 + Real.log s) /
              (LwL h s / YL h s : ℕ)) := by positivity
  have hq0 : (0 : ℝ) < q := by exact_mod_cast hq
  have hAb0 : 0 ≤ Ab := by positivity
  have hF10 : (0 : ℝ) ≤ (((Nat.log 2 (max (H ^ 2) (LwL h s)) + 1 : ℕ)) : ℝ) := by positivity
  have hAw0 : 0 ≤ (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 * (max (H ^ 2) (LwL h s)) ^ 2)) : ℝ) ^ 30) ^ 2 :=
    by positivity
  have hXi0 : (0 : ℝ) ≤ 12.5 / Xp h := by positivity
  refine W_combine Λ _ _ Ab _ _ _ _ _ E hΛ2 (by positivity) hAb0 b1 hF10 b2 hAw0 b3 hlogJ0
    (by linarith) hbrk0 b6 hU0 b7 hXi0 ?_ ?_
  · have := hK1Λ Λ L4; rw [hK1] at this; push_cast; linarith
  · have := hK2Λ Λ L5; rw [hK2] at this; push_cast; linarith

/-- `K₀ = ⌈100 log Λ⌉`: the many-prime-factor threshold. -/
noncomputable def K0 (h : ℕ) : ℕ := ⌈100 * Real.log (Real.log h)⌉₊

lemma eight_ev : ∃ Λ₀ : ℝ, 1 ≤ Λ₀ ∧ ∀ h : ℕ, Λ₀ ≤ Real.log h → ∀ k : ℕ, k < K0 h →
    (8 : ℝ) ^ k ≤ 8 * (Real.log h) ^ (208 : ℝ) := by
  refine ⟨1, le_rfl, fun h hΛ k hk => ?_⟩
  set Λ := Real.log h
  have hΛ0 : 0 < Λ := by linarith
  have hlΛ : 0 ≤ Real.log Λ := Real.log_nonneg hΛ
  have hk' : (k : ℝ) < 100 * Real.log Λ := Nat.lt_ceil.1 hk
  have hl8 : Real.log 8 ≤ 2.08 := by
    have : Real.log 8 = 3 * Real.log 2 := by
      rw [show (8 : ℝ) = 2 ^ 3 by norm_num, Real.log_pow]; norm_num
    rw [this]; have := Real.log_two_lt_d9; linarith
  have hl80 : 0 ≤ Real.log 8 := Real.log_nonneg (by norm_num)
  have e : (8 : ℝ) ^ k = Real.exp (k * Real.log 8) := by
    rw [Real.exp_nat_mul, Real.exp_log (by norm_num)]
  have h1 : (8 : ℝ) ^ k ≤ Λ ^ (208 : ℝ) := by
    rw [e, Real.rpow_def_of_pos hΛ0]
    apply Real.exp_le_exp.2
    calc (k : ℝ) * Real.log 8 ≤ (100 * Real.log Λ) * 2.08 :=
          mul_le_mul hk'.le hl8 hl80 (by positivity)
      _ = Real.log Λ * 208 := by ring
  have : (1 : ℝ) ≤ 8 := by norm_num
  nlinarith [Real.rpow_nonneg hΛ0.le (208 : ℝ)]

lemma geoLR_convex_r (h H : ℕ) (δ : ℝ) (hδ : 0 ≤ δ) (s : ℕ) :
    ∀ a b c, a ≤ b → b ≤ c → GeoLR h H δ a s → GeoLR h H δ c s → GeoLR h H δ b s := by
  intro a b c hab hbc ha hc
  obtain ⟨ha1, ha2, ha3, ha4, ha5, ha6⟩ := ha
  obtain ⟨hc1, hc2, hc3, hc4, hc5, hc6⟩ := hc
  unfold longInverseRight at ha3 hc3
  have hbcR : (b : ℝ) ≤ c := by exact_mod_cast hbc
  refine ⟨lt_of_lt_of_le ha1 (Nat.mul_le_mul_right _ hab), le_trans (by
    have := Nat.mul_le_mul_right s hbc; omega) hc2, ?_, ?_, ?_, ?_⟩
  · unfold longInverseRight
    exact lt_of_le_of_lt (Real.rpow_le_rpow (by positivity) hbcR (by linarith)) hc3
  · exact le_trans (by exact_mod_cast Nat.mul_le_mul_right s hbc) hc4
  · exact le_trans ha5 (Nat.pow_le_pow_left hab 2)
  · exact le_trans hbc hc6

lemma Kvp_mono (h : ℕ) {b c : ℕ} (hbc : b ≤ c) : GoldC.QuillonREv.Kvp h b ≤ GoldC.QuillonREv.Kvp h c := by
  unfold GoldC.QuillonREv.Kvp
  have hε : 0 ≤ GoldC.QuillonCEv.εp h := by
    unfold GoldC.QuillonCEv.εp; exact Real.rpow_nonneg (Real.log_natCast_nonneg h) _
  have : (b : ℝ) ^ GoldC.QuillonCEv.εp h ≤ (c : ℝ) ^ GoldC.QuillonCEv.εp h :=
    Real.rpow_le_rpow (by positivity) (by exact_mod_cast hbc) hε
  have := Nat.log_mono_right (b := 2) (Nat.ceil_mono this)
  omega

/-- The LONG-right Weil W′ `r`-mask for fixed `C` (`s = ∏C`). -/
def GeoWR (h H : ℕ) (δ : ℝ) (C : Finset ℕ) (r : ℕ) : Prop :=
  GeoLR h H δ r (∏ p ∈ C, p) ∧ ((∏ p ∈ C, p : ℕ) : ℝ) ^ ((1 : ℝ) / 2 + 3 * ηp h) ≤ r ∧
    ¬ (C.filter (fun p => Xp h < p ∧ p ≤ 2 ^ GoldC.QuillonREv.Kvp h r * Xp h)).Nonempty ∧
    C.card < K0 h

lemma geoWR_convex (h H : ℕ) (δ : ℝ) (hδ : 0 ≤ δ) (C : Finset ℕ) :
    ∀ a b c, a ≤ b → b ≤ c → GeoWR h H δ C a → GeoWR h H δ C c → GeoWR h H δ C b := by
  intro a b c hab hbc ha hc
  refine ⟨geoLR_convex_r h H δ hδ _ a b c hab hbc ha.1 hc.1, le_trans ha.2.1 (by exact_mod_cast hab), ?_, ha.2.2.2⟩
  rintro ⟨p, hp⟩
  apply hc.2.2.1
  refine ⟨p, mem_filter.2 ⟨(mem_filter.1 hp).1, (mem_filter.1 hp).2.1, le_trans (mem_filter.1 hp).2.2 ?_⟩⟩
  exact Nat.mul_le_mul_right _ (Nat.pow_le_pow_right (by norm_num) (Kvp_mono h hbc))

lemma LwL_lt {h H : ℕ} {δ : ℝ} {C : Finset ℕ} {r : ℕ} (hG : GeoWR h H δ C r) : LwL h (∏ p ∈ C, p) < r := by
  have hZ := hG.1.1
  have hr1 : 1 ≤ r := by
    rcases Nat.eq_zero_or_pos r with h0 | h0
    · rw [h0] at hZ; simp at hZ
    · exact h0
  have : ⌊((∏ p ∈ C, p : ℕ) : ℝ) ^ ((1 : ℝ) / 2 + 3 * ηp h)⌋₊ ≤ r := Nat.floor_le_of_le hG.2.1
  unfold LwL Lwη; omega

open GoldC.QuillonWFinal GoldC.QuillonWContext in
open Classical in
set_option maxHeartbeats 4000000 in
/-- **The W′ cell for a fixed `C` is `≤ 4Λ^{−95}`**, eventually in `h`, uniformly in `a, d, C, Kc`. -/
theorem W_final_LR (hW : GoldC.QuillonLWeil.WeilHyp) (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (a h H D : ℕ) (T C : Finset ℕ) (Kc : ℕ → Prop) [DecidablePred Kc],
      Λ₀ ≤ Real.log h → 2 ≤ h → H ≤ h →
      (∀ p ∈ T, p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q ∧ p.Coprime H ∧ p ≤ H ^ 2) → C ⊆ T →
      |∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
          (if (Kc B.card ∧ GeoWR h H δ C (∏ p ∈ B, p)) ∧
              (B ∩ (T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ YL h (∏ p ∈ C, p))).Nonempty
            then GoldC.QuillonWContext.ωR B *
              GoldC.QuillonCopyF.foldRow q a D H (∏ p ∈ B, p) (∏ p ∈ C, p) else 0)| ≤
        4 * (Real.log h) ^ (-(95 : ℝ)) := by
  obtain ⟨Λ₁, hΛ₁, hWT⟩ := W_term_ev_LR q hq δ hδ0 hδ1
  obtain ⟨Λ₂, hΛ₂, h36⟩ := s_large4 36
  obtain ⟨Λ₄, hΛ₄, hyl⟩ := yl_ev
  obtain ⟨Λ₅, hΛ₅, hK8⟩ := eight_ev
  refine ⟨max Λ₁ (max Λ₂ (max Λ₄ Λ₅)), le_trans hΛ₁ (le_max_left _ _), ?_⟩
  intro a h H D T C Kc _ hΛ hh hHh hT hCT
  have hΛa : Λ₁ ≤ Real.log h := le_trans (le_max_left _ _) hΛ
  have hΛb : Λ₂ ≤ Real.log h := le_trans (by simp) hΛ
  have hΛd : Λ₄ ≤ Real.log h := le_trans (by simp) hΛ
  have hΛe : Λ₅ ≤ Real.log h := le_trans (by simp) hΛ
  set s := ∏ p ∈ C, p with hs
  have hpos4 : 0 ≤ 4 * (Real.log h) ^ (-(95 : ℝ)) := by
    have : 0 ≤ Real.log h := Real.log_nonneg (by exact_mod_cast (by omega : 1 ≤ h))
    positivity
  -- empty case
  by_cases hex : ∃ r, GeoWR h H δ C r
  swap
  · push_neg at hex
    rw [sum_eq_zero fun B _ => by rw [if_neg]; rintro ⟨⟨-, hg⟩, -⟩; exact hex _ hg, abs_zero]
    exact hpos4
  obtain ⟨r₀, hr₀⟩ := hex
  obtain ⟨-, hlogs, -, hs1, -, hsh, -, -, -⟩ := admLR h H r₀ s δ hδ0 hh hHh hr₀.1
  have h8C : (8 : ℝ) ^ C.card ≤ 8 * (Real.log h) ^ (208 : ℝ) := hK8 h hΛe C.card hr₀.2.2.2
  have hCp : ∀ p ∈ C, p.Prime := fun p hp => (hT p (hCT hp)).1
  have hspos : 0 < s := prod_pos fun p hp => (hCp p hp).pos
  have hs0 : (0 : ℝ) < s := by exact_mod_cast hspos
  have hsR : (36 : ℝ) ≤ s := h36 _ hΛb s hs0 hlogs
  have hs2 : 2 ≤ s := by
    have : (2 : ℝ) ≤ s := by linarith
    exact_mod_cast this
  haveI : NeZero s := ⟨by omega⟩
  haveI : NeZero (6 * q) := ⟨by omega⟩
  have hTc : ∀ p ∈ T, p.Prime ∧ 5 ≤ p ∧ p.Coprime (6 * q) ∧ p.Coprime H := fun p hp =>
    ⟨(hT p hp).1, (hT p hp).2.1, coprime_6q (hT p hp).1 (hT p hp).2.1 (hT p hp).2.2.1, (hT p hp).2.2.2.1⟩
  have hsM : s.Coprime (6 * q) := prod_coprime_of fun p hp => (hTc p (hCT hp)).2.2.1
  set μ := GoldC.QuillonCopyF.meanWeight q (GoldC.QuillonCopyF.reducedAnchor q a D) H with hμ
  set Γ := GoldC.QuillonCopyF.gammaClass q a D H with hΓ
  have hμb : |μ| ≤ 4 := by
    have := GoldC.QuillonCopyF.meanWeight_bounds q (GoldC.QuillonCopyF.reducedAnchor q a D) H
    rw [abs_le]; constructor <;> linarith
  have hΓb : ∀ b ν, |Γ b ν| ≤ 48 * q := fun b ν => by
    have := GoldC.QuillonCopyF.abs_gammaClass_le q a D H b ν hq
    have e : (8 : ℝ) * (6 * q) = 48 * q := by ring
    linarith
  obtain ⟨hη0, hη8, h8s, -⟩ := hyl (Real.log h) hΛd s hspos hlogs
  obtain ⟨hY10, -, hYL0, -, -, -⟩ := yfacts ((Real.log h) ^ (-(1 / 10 : ℝ))) hη0 hη8 s hspos h8s
  have hY1 : 1 ≤ YL h s := hY10
  have hYL : YL h s ≤ LwL h s := hYL0
  have hX2 : 2 ≤ Xp h := Xp_two (le_trans hΛ₁ hΛa)
  have hshn : s ≤ h := by exact_mod_cast hsh
  have hcell := GoldC.QuillonLWeilB.W_cell_W (s := s) (M := 6 * q) hW (by omega) H μ Γ T C hTc hCT rfl hs2
    ((T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ YL h s)) (filter_subset _ _) (Xp h) (YL h s) hX2 hY1
    (fun p hp => (mem_filter.1 hp).2) Kc (fun r => GeoWR h H δ C r) (H ^ 2) (LwL h s)
    (fun r hG => by
      have h4 : 4 * (r * s) ≤ H ^ 2 := hG.1.2.1
      have : r ≤ r * s := Nat.le_mul_of_pos_right r hspos
      omega)
    (fun r hG => LwL_lt hG) hYL (geoWR_convex h H δ hδ0.le C)
    (fun r => GoldC.QuillonCopyF.foldRow q a D H r s)
    (fun B hB hne _ => by
      have hBp : ∀ p ∈ B, p.Prime ∧ 5 ≤ p := fun p hp =>
        ⟨(hT p (sdiff_subset (hB hp))).1, (hT p (sdiff_subset (hB hp))).2.1⟩
      obtain ⟨p, hp⟩ := nonempty_iff_ne_empty.2 hne
      have hr2 : 2 ≤ ∏ p ∈ B, p := by
        have h1 : p ∣ ∏ p ∈ B, p := dvd_prod_of_mem _ hp
        have h2 : 0 < ∏ p ∈ B, p := prod_pos fun p hp => (hBp p hp).1.pos
        have := Nat.le_of_dvd h2 h1
        have := (hBp p hp).2; omega
      exact GoldC.QuillonBridge.foldRow_eq_rowAbs q a D H _ s hq hr2 hs2
        (prod_coprime_of fun p hp => (hTc p (sdiff_subset (hB hp))).2.2.1) hsM)
    (6 * q * h) (by nlinarith)
  refine le_trans hcell ?_
  have hU : ∀ p ∈ T \ C, p.Prime ∧ 5 ≤ p ∧ p ≤ H ^ 2 := fun p hp =>
    ⟨(hT p (sdiff_subset hp)).1, (hT p (sdiff_subset hp)).2.1, (hT p (sdiff_subset hp)).2.2.2.2⟩
  have hCH : ∀ p ∈ C, p.Prime ∧ p.Coprime H := fun p hp => ⟨hCp p hp, (hT p (hCT hp)).2.2.2.1⟩
  have hs1' : 1 ≤ s := hs1
  have w1 := hWT h H hΛa hHh s (6 * q) C (T \ C) hCp rfl rfl hlogs hsh h8C hU
    (fun (_ : ZMod (6 * q)) k => ((-(2 * μ) : ℝ) : ℂ) * GoldC.QuillonRowNF.αm k s)
    (fun k => ((((k : ℤ) * H : ℤ)) : ZMod s))
    (fun ρ j hj => GoldC.QuillonRowFacts.coef_main q hq μ hμb s hs1' (6 * q) ρ j hj)
    (GoldC.QuillonRowFacts.hc_gen C hCp rfl (H : ℤ) (GoldC.QuillonRowFacts.not_dvd_H hCH) 1 (Or.inl rfl) _
      (fun j => by congr 1; ring))
  have w2 := hWT h H hΛa hHh s (6 * q) C (T \ C) hCp rfl rfl hlogs hsh h8C hU
    (fun (_ : ZMod (6 * q)) k => -(((-(2 * μ) : ℝ) : ℂ) * GoldC.QuillonRowNF.αm k s))
    (fun k => ((((-(k : ℤ)) * H : ℤ)) : ZMod s))
    (fun ρ j hj => GoldC.QuillonRowFacts.coef_mainN q hq μ hμb s hs1' (6 * q) ρ j hj)
    (GoldC.QuillonRowFacts.hc_gen C hCp rfl (H : ℤ) (GoldC.QuillonRowFacts.not_dvd_H hCH) (-1)
      (Or.inr rfl) _ (fun j => by congr 1; ring))
  have w3 := hWT h H hΛa hHh s (6 * q) C (T \ C) hCp rfl rfl hlogs hsh h8C hU
    (fun (ρ : ZMod (6 * q)) k => GoldC.QuillonRowNF.αm k ((6 * q) * s) *
      GoldC.QuillonRowNF.BclS (6 * q) Γ s (k : ℤ) ρ)
    (fun k => ((((k : ℤ) * H * GoldC.QuillonCopyC.invMod (6 * q) s : ℤ)) : ZMod s))
    (fun ρ j hj => GoldC.QuillonRowFacts.coef_cls q hq Γ hΓb s hs1' (fun k => (k : ℤ)) ρ j hj)
    (GoldC.QuillonRowFacts.hc_gen C hCp rfl _
      (GoldC.QuillonRowFacts.not_dvd_HinvM hCH rfl hs2 hsM.symm) 1 (Or.inl rfl) _
      (fun j => by congr 1; ring))
  have w4 := hWT h H hΛa hHh s (6 * q) C (T \ C) hCp rfl rfl hlogs hsh h8C hU
    (fun (ρ : ZMod (6 * q)) k => -(GoldC.QuillonRowNF.αm k ((6 * q) * s) *
      GoldC.QuillonRowNF.BclS (6 * q) Γ s (-(k : ℤ)) ρ))
    (fun k => ((((-(k : ℤ)) * H * GoldC.QuillonCopyC.invMod (6 * q) s : ℤ)) : ZMod s))
    (fun ρ j hj => GoldC.QuillonRowFacts.coef_clsN q hq Γ hΓb s hs1' (fun k => -(k : ℤ)) ρ j hj)
    (GoldC.QuillonRowFacts.hc_gen C hCp rfl _
      (GoldC.QuillonRowFacts.not_dvd_HinvM hCH rfl hs2 hsM.symm) (-1) (Or.inr rfl) _
      (fun j => by congr 1; ring))
  linarith

end GoldC.QuillonLWR

#print axioms GoldC.QuillonLWR.yfacts
#print axioms GoldC.QuillonLWR.W_bracketW_ev
#print axioms GoldC.QuillonLWR.W_term_ev_LR
#print axioms GoldC.QuillonLWR.W_final_LR
