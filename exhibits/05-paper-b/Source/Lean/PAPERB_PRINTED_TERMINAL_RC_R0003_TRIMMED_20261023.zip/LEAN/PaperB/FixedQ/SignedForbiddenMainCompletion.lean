import PaperB.FixedQ.SignedForbiddenChannelBridge
import PaperB.FixedQ.SignedForbiddenCompletionBridge
import PaperB.FixedQ.H3VaalerPeriodizationCloseout

open scoped BigOperators ComplexConjugate

namespace PaperB.FixedQ

noncomputable def sourceAffineVaalerMain
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S)) (r J : ℕ) : ℝ := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  exact calderBooleanRootAverageR S
    (fun x : ZMod (primeSetProduct S) =>
      h3VaalerApprox (primeSetProduct S) J
          (((u : ZMod (primeSetProduct S)) * x + v) -
            (r : ZMod (primeSetProduct S))) -
        h3VaalerApprox (primeSetProduct S) J
          ((u : ZMod (primeSetProduct S)) * x + v))

noncomputable def sourceAffineVaalerError
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S)) (r J : ℕ) : ℝ := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  exact calderBooleanRootAverageR S
    (fun x : ZMod (primeSetProduct S) =>
      h3VaalerError (primeSetProduct S) J
          (((u : ZMod (primeSetProduct S)) * x + v) -
            (r : ZMod (primeSetProduct S))) +
        h3VaalerError (primeSetProduct S) J
          ((u : ZMod (primeSetProduct S)) * x + v))

lemma sourceAffineVaalerError_nonneg
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S)) (r J : ℕ) :
    0 ≤ sourceAffineVaalerError S hPrime u v r J := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  unfold sourceAffineVaalerError calderBooleanRootAverageR
  apply mul_nonneg (by positivity)
  apply Finset.sum_nonneg
  intro A hA
  exact add_nonneg
    (h3VaalerError_nonneg (primeSetProduct S) J _)
    (h3VaalerError_nonneg (primeSetProduct S) J _)

lemma sourceAffineVaalerError_le_frequencyMass
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S)) (r J : ℕ) :
    sourceAffineVaalerError S hPrime u v r J ≤
      (1 + 2 * ∑ j ∈ Finset.Icc 1 J,
        fixedProductBooleanTwistedFrequencyMass S hPrime u j) /
        ((J + 1 : ℕ) : ℝ) := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  let M : ℝ := ∑ j ∈ Finset.Icc 1 J,
    fixedProductBooleanTwistedFrequencyMass S hPrime u j
  have hR :=
    calder_booleanAverage_h3VaalerError_affine_translate_le
      S hPrime u v J (r : ZMod (primeSetProduct S))
  have h0 :=
    calder_booleanAverage_h3VaalerError_affine_translate_le
      S hPrime u v J (0 : ZMod (primeSetProduct S))
  unfold sourceAffineVaalerError
  rw [calderBooleanRootAverageR_add]
  have hz :
      calderBooleanRootAverageR S
          (fun x : ZMod (primeSetProduct S) =>
            h3VaalerError (primeSetProduct S) J
              ((u : ZMod (primeSetProduct S)) * x + v)) =
        calderBooleanRootAverageR S
          (fun x : ZMod (primeSetProduct S) =>
            h3VaalerError (primeSetProduct S) J
              (((u : ZMod (primeSetProduct S)) * x + v) -
                (0 : ZMod (primeSetProduct S)))) := by
    congr 1
    funext x
    simp
  rw [hz]
  have hJ : (0 : ℝ) < ((J + 1 : ℕ) : ℝ) := by positivity
  calc
    calderBooleanRootAverageR S
          (fun x : ZMod (primeSetProduct S) =>
            h3VaalerError (primeSetProduct S) J
              (((u : ZMod (primeSetProduct S)) * x + v) -
                (r : ZMod (primeSetProduct S)))) +
        calderBooleanRootAverageR S
          (fun x : ZMod (primeSetProduct S) =>
            h3VaalerError (primeSetProduct S) J
              (((u : ZMod (primeSetProduct S)) * x + v) -
                (0 : ZMod (primeSetProduct S))))
      ≤ (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) +
          (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) := add_le_add hR h0
    _ = (1 + 2 * M) / ((J + 1 : ℕ) : ℝ) := by
          field_simp [hJ.ne']
          ring
    _ = _ := by rfl

#print axioms sourceAffineVaalerError_le_frequencyMass

lemma source_small_channel_rescale_completion
    {G C U D Y F : ℝ}
    (hG : 0 ≤ G) (hC : 0 ≤ C)
    (hU : 0 < U) (hD : 0 < D) (hY : 0 < Y) (hF : 0 < F)
    (hscale : U ≤ D * F ^ 2 * Y)
    {Z : ℝ} (hZ : Z ≤ C / Y) :
    (G / (D * F ^ 2)) * Z ≤ G * C / U := by
  have hDF : 0 < D * F ^ 2 := by positivity
  have hleft :
      (G / (D * F ^ 2)) * Z ≤
        (G / (D * F ^ 2)) * (C / Y) := by
    exact mul_le_mul_of_nonneg_left hZ (by positivity)
  have hratio :
      (G / (D * F ^ 2)) * (C / Y) =
        G * C / (D * F ^ 2 * Y) := by
    field_simp [hDF.ne', hY.ne']
  have hinv :
      (D * F ^ 2 * Y)⁻¹ ≤ U⁻¹ := by
    simpa [one_div] using
      (one_div_le_one_div_of_le hU hscale)
  have hGC : 0 ≤ G * C := mul_nonneg hG hC
  calc
    (G / (D * F ^ 2)) * Z
      ≤ (G / (D * F ^ 2)) * (C / Y) := hleft
    _ = G * C / (D * F ^ 2 * Y) := hratio
    _ ≤ G * C / U := by
      simp only [div_eq_mul_inv]
      exact mul_le_mul_of_nonneg_left hinv hGC

lemma source_large_channel_rescale_completion
    {G D F Z : ℝ}
    (hG : 0 ≤ G) (hD : 0 < D) (hF : 0 < F)
    (hZ : Z ≤ 1) :
    (G / (D * F ^ 2)) * Z ≤
      (G / D) * F⁻¹ ^ 2 := by
  have hcoef : 0 ≤ G / (D * F ^ 2) := by positivity
  calc
    (G / (D * F ^ 2)) * Z
      ≤ (G / (D * F ^ 2)) * 1 :=
        mul_le_mul_of_nonneg_left hZ hcoef
    _ = (G / D) * F⁻¹ ^ 2 := by
      field_simp [hD.ne', hF.ne']

theorem source_fixed_dc_channel_estimate_from_kernel_bounds
    (S : Finset ℕ) (h5 : ∀ p ∈ S, 5 ≤ p)
    {c F M : ℕ} {U C s0 : ℝ}
    (hcpos : 0 < c)
    (hU : 0 < U) (hC : 0 < C) (hs0 : 0 < s0)
    (hsq :
      s0 ^ 2 =
        U / (((primeSetProduct S : ℕ) : ℝ) * (c : ℝ) * C))
    (hsF : s0 ≤ (F : ℝ)) (hF2 : (F : ℝ) ≤ 2 * s0)
    (kernel : ℕ → ℝ)
    (Y : ℕ → ℝ)
    (hY : ∀ f ∈ Finset.Icc 1 F, 0 < Y f)
    (hscale : ∀ f ∈ Finset.Icc 1 F,
      U ≤ (((primeSetProduct S : ℕ) : ℝ) * (c : ℝ)) *
        (f : ℝ) ^ 2 * Y f)
    (hcompletion : ∀ f ∈ Finset.Icc 1 F,
      kernel f ≤ C / Y f)
    (hunit : ∀ f ∈ Finset.Icc (F + 1) M,
      kernel f ≤ 1) :
    (∑ f ∈ Finset.Icc 1 F,
        (sourceGammaFinsetWeight S /
          (((primeSetProduct S : ℕ) : ℝ) * (c : ℝ) * (f : ℝ)^2)) *
          kernel f) +
      (∑ f ∈ Finset.Icc (F + 1) M,
        (sourceGammaFinsetWeight S /
          (((primeSetProduct S : ℕ) : ℝ) * (c : ℝ) * (f : ℝ)^2)) *
          kernel f) ≤
      (3 * Real.sqrt C * (Real.sqrt U)⁻¹) *
        (∏ p ∈ S, gammaPrimeTerm p) * invSqrtNat c := by
  let smallTerm : ℕ → ℝ := fun f =>
    (sourceGammaFinsetWeight S /
      (((primeSetProduct S : ℕ) : ℝ) * (c : ℝ) * (f : ℝ)^2)) *
      kernel f
  let largeTerm : ℕ → ℝ := smallTerm
  have hdposN : 0 < primeSetProduct S := by
    unfold primeSetProduct
    exact Finset.prod_pos fun p hp => lt_of_lt_of_le (by norm_num) (h5 p hp)
  have hdpos : (0 : ℝ) < primeSetProduct S := by exact_mod_cast hdposN
  have hcposR : (0 : ℝ) < c := by exact_mod_cast hcpos
  have hD : 0 < ((primeSetProduct S : ℕ) : ℝ) * (c : ℝ) :=
    mul_pos hdpos hcposR
  have hG : 0 ≤ sourceGammaFinsetWeight S := by
    rw [sourceGammaFinsetWeight_eq_prod_gammaPrime_mul_sqrt S h5]
    exact mul_nonneg
      (Finset.prod_nonneg fun p hp => gammaPrimeTerm_nonneg p)
      (Real.sqrt_nonneg _)
  have hsmall : ∀ f ∈ Finset.Icc 1 F,
      smallTerm f ≤ sourceGammaFinsetWeight S * C / U := by
    intro f hf
    have hfposN : 0 < f := by
      have := (Finset.mem_Icc.mp hf).1
      omega
    have hfpos : (0 : ℝ) < f := by exact_mod_cast hfposN
    have hz := source_small_channel_rescale_completion
      hG hC.le hU hD (hY f hf) hfpos (hscale f hf)
      (hcompletion f hf)
    dsimp [smallTerm] at hz ⊢
    convert hz using 1 <;> ring
  have hlarge : ∀ f ∈ Finset.Icc (F + 1) M,
      largeTerm f ≤
        (sourceGammaFinsetWeight S /
          (((primeSetProduct S : ℕ) : ℝ) * (c : ℝ))) *
          ((f : ℝ)⁻¹ ^ 2) := by
    intro f hf
    have hfposN : 0 < f := by
      have := (Finset.mem_Icc.mp hf).1
      omega
    have hfpos : (0 : ℝ) < f := by exact_mod_cast hfposN
    have hz := source_large_channel_rescale_completion
      hG hD hfpos (hunit f hf)
    dsimp [largeTerm, smallTerm] at hz ⊢
    convert hz using 1 <;> ring
  simpa [smallTerm, largeTerm] using
    source_fixed_dc_channel_estimate_from_f_split
      S h5 hcpos hU hC hs0 hsq hsF hF2
      smallTerm largeTerm hsmall hlarge

#print axioms source_fixed_dc_channel_estimate_from_kernel_bounds

lemma source_sum_divisors_eq_Icc_indicator
    {M : Type*} [AddCommMonoid M]
    {n X : ℕ} (hn0 : n ≠ 0) (hnX : n ≤ X)
    (F : ℕ → M) :
    (∑ f ∈ n.divisors, F f) =
      ∑ f ∈ Finset.Icc 1 X, if f ∣ n then F f else 0 := by
  rw [← Finset.sum_filter]
  apply Finset.sum_congr
  · ext f
    simp only [Finset.mem_filter, Finset.mem_Icc]
    constructor
    · intro hf
      have hd := Nat.dvd_of_mem_divisors hf
      have hfpos := Nat.pos_of_dvd_of_pos hd (Nat.pos_of_ne_zero hn0)
      have hfle := Nat.le_of_dvd (Nat.pos_of_ne_zero hn0) hd
      exact ⟨⟨hfpos, hfle.trans hnX⟩, hd⟩
    · rintro ⟨⟨hf1, hfX⟩, hd⟩
      exact Nat.mem_divisors.mpr ⟨hd, hn0⟩
  · intro f hf
    rfl

#print axioms source_sum_divisors_eq_Icc_indicator

lemma fixedProductBooleanAffineRootIntervalDiscrepancy_eq_centeredAverage
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S)) (r : ℕ) :
    fixedProductBooleanAffineRootIntervalDiscrepancy S hPrime u v r =
      calderBooleanRootAverageR S
        (fun x : ZMod (primeSetProduct S) =>
          h3HalfOpenIntervalCentered
            (primeSetProduct S) r
            ((u : ZMod (primeSetProduct S)) * x + v)) := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  rw [calder_affine_discrepancy_eq_rootAverage_indicator_sub]
  rw [show (r : ℝ) / (primeSetProduct S : ℝ) =
      calderBooleanRootAverageR S
        (fun _ : ZMod (primeSetProduct S) =>
          (r : ℝ) / (primeSetProduct S : ℝ)) by
    symm
    exact calderBooleanRootAverageR_const S _]
  rw [← calderBooleanRootAverageR_sub]
  apply congrArg (calderBooleanRootAverageR S)
  funext x
  exact (h3HalfOpenIntervalCentered_eq_indicator_sub
    (primeSetProduct S) r
    ((u : ZMod (primeSetProduct S)) * x + v)).symm

theorem fixedProductBooleanAffineRootInterval_vaaler_sandwich
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S)) (r J : ℕ)
    (hr : r < primeSetProduct S)
    (hGrid : @H3VaalerGridErrorSpec (primeSetProduct S) J
      ⟨(primeSetProduct_pos hPrime).ne'⟩) :
    sourceAffineVaalerMain S hPrime u v r J -
        sourceAffineVaalerError S hPrime u v r J ≤
      fixedProductBooleanAffineRootIntervalDiscrepancy
        S hPrime u v r ∧
      fixedProductBooleanAffineRootIntervalDiscrepancy
          S hPrime u v r ≤
        sourceAffineVaalerMain S hPrime u v r J +
          sourceAffineVaalerError S hPrime u v r J := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  have hpoint : ∀ x : ZMod (primeSetProduct S),
      h3IntervalLowerCentered (primeSetProduct S) r J
          ((u : ZMod (primeSetProduct S)) * x + v) ≤
        h3HalfOpenIntervalCentered (primeSetProduct S) r
          ((u : ZMod (primeSetProduct S)) * x + v) ∧
      h3HalfOpenIntervalCentered (primeSetProduct S) r
          ((u : ZMod (primeSetProduct S)) * x + v) ≤
        h3IntervalUpperCentered (primeSetProduct S) r J
          ((u : ZMod (primeSetProduct S)) * x + v) := by
    intro x
    exact h3IntervalCentered_sandwich_of_error hr hGrid
      ((u : ZMod (primeSetProduct S)) * x + v)
  have hlow := calderBooleanRootAverageR_mono S (fun x => (hpoint x).1)
  have hupp := calderBooleanRootAverageR_mono S (fun x => (hpoint x).2)
  rw [fixedProductBooleanAffineRootIntervalDiscrepancy_eq_centeredAverage]
  constructor
  · calc
      sourceAffineVaalerMain S hPrime u v r J -
          sourceAffineVaalerError S hPrime u v r J =
        calderBooleanRootAverageR S
          (fun x : ZMod (primeSetProduct S) =>
            (h3VaalerApprox (primeSetProduct S) J
                (((u : ZMod (primeSetProduct S)) * x + v) -
                  (r : ZMod (primeSetProduct S))) -
              h3VaalerApprox (primeSetProduct S) J
                ((u : ZMod (primeSetProduct S)) * x + v)) -
            (h3VaalerError (primeSetProduct S) J
                (((u : ZMod (primeSetProduct S)) * x + v) -
                  (r : ZMod (primeSetProduct S))) +
              h3VaalerError (primeSetProduct S) J
                ((u : ZMod (primeSetProduct S)) * x + v))) := by
          unfold sourceAffineVaalerMain sourceAffineVaalerError
          simp only [calderBooleanRootAverageR_sub]
      _ = calderBooleanRootAverageR S
          (fun x : ZMod (primeSetProduct S) =>
            h3IntervalLowerCentered (primeSetProduct S) r J
              ((u : ZMod (primeSetProduct S)) * x + v)) := by
          apply congrArg (calderBooleanRootAverageR S)
          funext x
          unfold h3IntervalLowerCentered
          ring
      _ ≤ calderBooleanRootAverageR S
          (fun x : ZMod (primeSetProduct S) =>
            h3HalfOpenIntervalCentered (primeSetProduct S) r
              ((u : ZMod (primeSetProduct S)) * x + v)) := hlow
  · calc
      calderBooleanRootAverageR S
          (fun x : ZMod (primeSetProduct S) =>
            h3HalfOpenIntervalCentered (primeSetProduct S) r
              ((u : ZMod (primeSetProduct S)) * x + v)) ≤
        calderBooleanRootAverageR S
          (fun x : ZMod (primeSetProduct S) =>
            h3IntervalUpperCentered (primeSetProduct S) r J
              ((u : ZMod (primeSetProduct S)) * x + v)) := hupp
      _ = sourceAffineVaalerMain S hPrime u v r J +
          sourceAffineVaalerError S hPrime u v r J := by
          unfold sourceAffineVaalerMain sourceAffineVaalerError
          unfold h3IntervalUpperCentered
          simp only [calderBooleanRootAverageR_add,
            calderBooleanRootAverageR_sub]
          abel

theorem sourceAffineVaalerMain_eq_frequency_sums
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S)) (r J : ℕ) :
    sourceAffineVaalerMain S hPrime u v r J =
      - ∑ j ∈ Finset.Icc 1 J,
          (h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
            (ZMod.stdAddChar
                ((j : ZMod (primeSetProduct S)) *
                  (v - (r : ZMod (primeSetProduct S)))) *
              fixedProductBooleanFourierCoeff S hPrime
                ((j : ZMod (primeSetProduct S)) *
                  (u : ZMod (primeSetProduct S)))).im +
        ∑ j ∈ Finset.Icc 1 J,
          (h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
            (ZMod.stdAddChar
                ((j : ZMod (primeSetProduct S)) * v) *
              fixedProductBooleanFourierCoeff S hPrime
                ((j : ZMod (primeSetProduct S)) *
                  (u : ZMod (primeSetProduct S)))).im := by
  unfold sourceAffineVaalerMain
  rw [calderBooleanRootAverageR_sub]
  have hrEq :=
    calder_booleanAverage_h3VaalerApprox_affine_translate_eq
      S hPrime u v J (r : ZMod (primeSetProduct S))
  have h0Eq :=
    calder_booleanAverage_h3VaalerApprox_affine_translate_eq
      S hPrime u v J (0 : ZMod (primeSetProduct S))
  rw [hrEq]
  have h0Eq' :
      calderBooleanRootAverageR S
        (fun x : ZMod (primeSetProduct S) =>
          h3VaalerApprox (primeSetProduct S) J
            ((u : ZMod (primeSetProduct S)) * x + v)) =
        - ∑ j ∈ Finset.Icc 1 J,
          (h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
            (ZMod.stdAddChar
                ((j : ZMod (primeSetProduct S)) * v) *
              fixedProductBooleanFourierCoeff S hPrime
                ((j : ZMod (primeSetProduct S)) *
                  (u : ZMod (primeSetProduct S)))).im := by
    simpa using h0Eq
  rw [h0Eq']
  abel

lemma abs_weighted_sum_of_sandwich
    {ι : Type*} (s : Finset ι)
    (w main err disc : ι → ℝ)
    (hw : ∀ i ∈ s, 0 ≤ w i)
    (herr : ∀ i ∈ s, 0 ≤ err i)
    (hsand : ∀ i ∈ s,
      main i - err i ≤ disc i ∧
        disc i ≤ main i + err i) :
    |∑ i ∈ s, w i * disc i| ≤
      |∑ i ∈ s, w i * main i| +
        ∑ i ∈ s, w i * err i := by
  have hlo :
      (∑ i ∈ s, w i * main i) -
          (∑ i ∈ s, w i * err i) ≤
        ∑ i ∈ s, w i * disc i := by
    rw [← Finset.sum_sub_distrib]
    apply Finset.sum_le_sum
    intro i hi
    have h := (hsand i hi).1
    have hw0 := hw i hi
    nlinarith
  have hup :
      (∑ i ∈ s, w i * disc i) ≤
        (∑ i ∈ s, w i * main i) +
          (∑ i ∈ s, w i * err i) := by
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_le_sum
    intro i hi
    simpa [mul_add] using
      (mul_le_mul_of_nonneg_left (hsand i hi).2 (hw i hi))
  have hE :
      0 ≤ ∑ i ∈ s, w i * err i := by
    apply Finset.sum_nonneg
    intro i hi
    exact mul_nonneg (hw i hi) (herr i hi)
  apply (abs_le).2
  constructor
  · have hA := neg_abs_le (∑ i ∈ s, w i * main i)
    linarith
  · have hA := le_abs_self (∑ i ∈ s, w i * main i)
    linarith

noncomputable def sourceForbiddenNaturalVaalerMain
    (q a H D m J : ℕ) : ℝ :=
  if hs : 1 < m ∧ Squarefree m ∧ m.Coprime (H * (6 * q) * D) then
    let hActive : ∀ p ∈ m.primeFactors, activeHighPrime q p :=
      (sourceForbiddenNatural_support_active hs.2.1 hs.2.2).1
    let hOrd : m.primeFactors ∈ ordinaryTwoDimensionalSet H :=
      (sourceForbiddenNatural_support_active hs.2.1 hs.2.2).2
    fixedQShiuWeight q m *
      ∑ c : Fin (fixedQPeriod q),
        occupiedFixedQLowWeight q a H (c.1 + 1) *
          sourceAffineVaalerMain
            m.primeFactors
            (fun p hp => (hActive p hp).1)
            (fixedProductBooleanPeriodicTwist
              (fixedQPeriod q) H m.primeFactors
              (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
              ((ordinary_primeSetProduct_coprime_height_iff
                (fun p hp => (hActive p hp).1)).mp hOrd).symm)
            (fixedProductBooleanPeriodicShift
              (fixedQPeriod q) m.primeFactors
              (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm c.1)
            (periodicResidueLength (fixedQPeriod q) H c.1 %
              primeSetProduct m.primeFactors)
            J
  else 0

noncomputable def sourceForbiddenNaturalVaalerError
    (q a H D m J : ℕ) : ℝ :=
  if hs : 1 < m ∧ Squarefree m ∧ m.Coprime (H * (6 * q) * D) then
    let hActive : ∀ p ∈ m.primeFactors, activeHighPrime q p :=
      (sourceForbiddenNatural_support_active hs.2.1 hs.2.2).1
    let hOrd : m.primeFactors ∈ ordinaryTwoDimensionalSet H :=
      (sourceForbiddenNatural_support_active hs.2.1 hs.2.2).2
    fixedQShiuWeight q m *
      ∑ c : Fin (fixedQPeriod q),
        |occupiedFixedQLowWeight q a H (c.1 + 1)| *
          sourceAffineVaalerError
            m.primeFactors
            (fun p hp => (hActive p hp).1)
            (fixedProductBooleanPeriodicTwist
              (fixedQPeriod q) H m.primeFactors
              (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
              ((ordinary_primeSetProduct_coprime_height_iff
                (fun p hp => (hActive p hp).1)).mp hOrd).symm)
            (fixedProductBooleanPeriodicShift
              (fixedQPeriod q) m.primeFactors
              (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm c.1)
            (periodicResidueLength (fixedQPeriod q) H c.1 %
              primeSetProduct m.primeFactors)
            J
  else 0

theorem sourceForbiddenBooleanNaturalTerm_sub_vaalerMain_abs_le_error
    {q a H D m J : ℕ}
    (hq : 0 < q)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H) :
    |sourceForbiddenBooleanNaturalTerm q a H D m -
        sourceForbiddenNaturalVaalerMain q a H D m J| ≤
      sourceForbiddenNaturalVaalerError q a H D m J := by
  classical
  by_cases hs : 1 < m ∧ Squarefree m ∧ m.Coprime (H * (6 * q) * D)
  · let hActive : ∀ p ∈ m.primeFactors, activeHighPrime q p :=
      (sourceForbiddenNatural_support_active hs.2.1 hs.2.2).1
    let hOrd : m.primeFactors ∈ ordinaryTwoDimensionalSet H :=
      (sourceForbiddenNatural_support_active hs.2.1 hs.2.2).2
    let hPrime : ∀ p ∈ m.primeFactors, p.Prime :=
      fun p hp => (hActive p hp).1
    let u :=
      fixedProductBooleanPeriodicTwist
        (fixedQPeriod q) H m.primeFactors
        (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
        ((ordinary_primeSetProduct_coprime_height_iff hPrime).mp hOrd).symm
    let v : Fin (fixedQPeriod q) → ZMod (primeSetProduct m.primeFactors) :=
      fun c =>
        fixedProductBooleanPeriodicShift
          (fixedQPeriod q) m.primeFactors
          (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm c.1
    let r : Fin (fixedQPeriod q) → ℕ :=
      fun c => periodicResidueLength (fixedQPeriod q) H c.1 %
        primeSetProduct m.primeFactors
    let w : Fin (fixedQPeriod q) → ℝ :=
      fun c => occupiedFixedQLowWeight q a H (c.1 + 1)
    let disc : Fin (fixedQPeriod q) → ℝ := fun c =>
      fixedProductBooleanAffineRootIntervalDiscrepancy
        m.primeFactors hPrime u (v c) (r c)
    let main : Fin (fixedQPeriod q) → ℝ := fun c =>
      sourceAffineVaalerMain m.primeFactors hPrime u (v c) (r c) J
    let err : Fin (fixedQPeriod q) → ℝ := fun c =>
      sourceAffineVaalerError m.primeFactors hPrime u (v c) (r c) J
    have hmpos : 0 < primeSetProduct m.primeFactors :=
      primeSetProduct_pos hPrime
    letI : NeZero (primeSetProduct m.primeFactors) := ⟨hmpos.ne'⟩
    have hsrc :
        sourceForbiddenBooleanNaturalTerm q a H D m =
          fixedQShiuWeight q m * ∑ c, w c * disc c := by
      rw [sourceForbiddenBooleanNaturalTerm_eq_periodic_affine_sum
        hq hs.1 hs.2.1 hs.2.2 h2admissible]
    have hmain :
        sourceForbiddenNaturalVaalerMain q a H D m J =
          fixedQShiuWeight q m * ∑ c, w c * main c := by
      rw [sourceForbiddenNaturalVaalerMain, dif_pos hs]
    have herrDef :
        sourceForbiddenNaturalVaalerError q a H D m J =
          fixedQShiuWeight q m * ∑ c, |w c| * err c := by
      rw [sourceForbiddenNaturalVaalerError, dif_pos hs]
    have hsand : ∀ c : Fin (fixedQPeriod q),
        main c - err c ≤ disc c ∧ disc c ≤ main c + err c := by
      intro c
      exact fixedProductBooleanAffineRootInterval_vaaler_sandwich
        m.primeFactors hPrime u (v c) (r c) J
        (Nat.mod_lt _ hmpos)
        (h3VaalerGridErrorSpec_holds (primeSetProduct m.primeFactors) J)
    have hpoint : ∀ c : Fin (fixedQPeriod q),
        |w c * (disc c - main c)| ≤ |w c| * err c := by
      intro c
      have hb := hsand c
      have hd : |disc c - main c| ≤ err c := by
        apply (abs_le).2
        constructor <;> linarith
      rw [abs_mul]
      exact mul_le_mul_of_nonneg_left hd (abs_nonneg _)
    rw [hsrc, hmain, herrDef]
    have hshiu0 : 0 ≤ fixedQShiuWeight q m :=
      fixedQShiuWeight_nonneg q m
    rw [← mul_sub]
    rw [abs_mul, abs_of_nonneg hshiu0]
    apply mul_le_mul_of_nonneg_left _ hshiu0
    calc
      |(∑ c, w c * disc c) - ∑ c, w c * main c|
          = |∑ c, w c * (disc c - main c)| := by
              rw [← Finset.sum_sub_distrib]
              apply congrArg abs
              apply Finset.sum_congr rfl
              intro c hc
              ring
      _ ≤ ∑ c, |w c * (disc c - main c)| :=
        Finset.abs_sum_le_sum_abs _ _
      _ ≤ ∑ c, |w c| * err c := by
        apply Finset.sum_le_sum
        intro c hc
        exact hpoint c
  · have hsrc : sourceForbiddenBooleanNaturalTerm q a H D m = 0 := by
      simp [sourceForbiddenBooleanNaturalTerm, hs]
    simp [sourceForbiddenNaturalVaalerMain,
      sourceForbiddenNaturalVaalerError, hs, hsrc]

#print axioms sourceAffineVaalerError_nonneg
#print axioms fixedProductBooleanAffineRootIntervalDiscrepancy_eq_centeredAverage
#print axioms fixedProductBooleanAffineRootInterval_vaaler_sandwich
#print axioms sourceAffineVaalerMain_eq_frequency_sums
#print axioms abs_weighted_sum_of_sandwich
theorem source_periodicFourierCoeff_block_factor
    {q H j : ℕ} {T R : Finset ℕ}
    (hdisj : Disjoint T R)
    (hActive : ∀ p ∈ T ∪ R, activeHighPrime q p)
    (hOrdU : T ∪ R ∈ ordinaryTwoDimensionalSet H)
    (hOrdR : R ∈ ordinaryTwoDimensionalSet H) :
    let hPrimeT : ∀ p ∈ T, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_left R hp)).1
    let hPrimeR : ∀ p ∈ R, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_right T hp)).1
    let hPrimeU : ∀ p ∈ T ∪ R, p.Prime :=
      fun p hp => (hActive p hp).1
    let hPcopU :
        (fixedQPeriod q).Coprime (primeSetProduct (T ∪ R)) :=
      (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
    let hHcopU :
        H.Coprime (primeSetProduct (T ∪ R)) :=
      ((ordinary_primeSetProduct_coprime_height_iff hPrimeU).mp hOrdU).symm
    let hPcopR :
        (fixedQPeriod q).Coprime (primeSetProduct R) :=
      (activePrimeSetProduct_coprime_fixedQPeriod
        (fun p hp => hActive p (Finset.mem_union_right T hp))).symm
    let hHcopR :
        H.Coprime (primeSetProduct R) :=
      ((ordinary_primeSetProduct_coprime_height_iff hPrimeR).mp hOrdR).symm
    fixedProductBooleanFourierCoeff (T ∪ R) hPrimeU
        ((j : ZMod (primeSetProduct (T ∪ R))) *
          (fixedProductBooleanPeriodicTwist
            (fixedQPeriod q) H (T ∪ R) hPcopU hHcopU :
              ZMod (primeSetProduct (T ∪ R)))) =
      fixedProductBooleanFourierCoeff T hPrimeT
        (h2BooleanBlockLeftFrequency T R hdisj hPrimeT hPrimeR
          ((j : ZMod (primeSetProduct (T ∪ R))) *
            (fixedQPeriodicTotalTwist q H (T ∪ R) :
              ZMod (primeSetProduct (T ∪ R))))) *
      fixedProductBooleanFourierCoeff R hPrimeR
        ((((j : ZMod (primeSetProduct R)) *
            (fixedProductBooleanPeriodicTwist
              (fixedQPeriod q) H R hPcopR hHcopR :
                ZMod (primeSetProduct R))) *
          (((ZMod.unitOfCoprime (primeSetProduct T)
            (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR))⁻¹ :
              (ZMod (primeSetProduct R))ˣ) :
                ZMod (primeSetProduct R)))) := by
  dsimp only
  let hPrimeT : ∀ p ∈ T, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_left R hp)).1
  let hPrimeR : ∀ p ∈ R, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_right T hp)).1
  let hPrimeU : ∀ p ∈ T ∪ R, p.Prime := fun p hp => (hActive p hp).1
  let hPcopU :=
    (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
  let hHcopU :=
    ((ordinary_primeSetProduct_coprime_height_iff hPrimeU).mp hOrdU).symm
  have htw :
      fixedQPeriodicTotalTwist q H (T ∪ R) =
        fixedProductBooleanPeriodicTwist
          (fixedQPeriod q) H (T ∪ R) hPcopU hHcopU :=
    fixedQPeriodicTotalTwist_eq_periodic hActive hOrdU
  rw [← htw]
  rw [fixedProductBooleanFourierCoeff_block_factor
    T R hdisj hPrimeT hPrimeR]
  rw [fixedQPeriodic_rightBlockFrequency_eq_source
    (q := q) (H := H) (j := j) hdisj hActive hOrdR]

theorem source_periodic_partition_phase_eq_rightBlock
    {q H j : ℕ} {T R : Finset ℕ}
    (hdisj : Disjoint T R)
    (hActive : ∀ p ∈ T ∪ R, activeHighPrime q p)
    (hOrdR : R ∈ ordinaryTwoDimensionalSet H)
    [NeZero (primeSetProduct T)]
    [NeZero (primeSetProduct R)]
    [NeZero (primeSetProduct (T ∪ R))] :
    let hPrimeT : ∀ p ∈ T, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_left R hp)).1
    let hPrimeR : ∀ p ∈ R, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_right T hp)).1
    let hPrimeU : ∀ p ∈ T ∪ R, p.Prime :=
      fun p hp => (hActive p hp).1
    let hPcopR :
        (fixedQPeriod q).Coprime (primeSetProduct R) :=
      (activePrimeSetProduct_coprime_fixedQPeriod
        (fun p hp => hActive p (Finset.mem_union_right T hp))).symm
    let hHcopR :
        H.Coprime (primeSetProduct R) :=
      ((ordinary_primeSetProduct_coprime_height_iff hPrimeR).mp hOrdR).symm
    ZMod.stdAddChar
        (((j : ZMod (primeSetProduct (T ∪ R))) *
          (fixedQPeriodicTotalTwist q H (T ∪ R) :
            ZMod (primeSetProduct (T ∪ R)))) *
          (fixedProductCRTIdempotentNat (T ∪ R) T :
            ZMod (primeSetProduct (T ∪ R)))) =
      ZMod.stdAddChar
        ((((j : ZMod (primeSetProduct R)) *
            (fixedProductBooleanPeriodicTwist
              (fixedQPeriod q) H R hPcopR hHcopR :
                ZMod (primeSetProduct R))) *
          (((ZMod.unitOfCoprime (primeSetProduct T)
            (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR))⁻¹ :
              (ZMod (primeSetProduct R))ˣ) :
                ZMod (primeSetProduct R)))) := by
  dsimp only
  let hPrimeT : ∀ p ∈ T, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_left R hp)).1
  let hPrimeR : ∀ p ∈ R, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_right T hp)).1
  let hPrimeU : ∀ p ∈ T ∪ R, p.Prime := fun p hp => (hActive p hp).1
  let t : ZMod (primeSetProduct (T ∪ R)) :=
    (j : ZMod (primeSetProduct (T ∪ R))) *
      (fixedQPeriodicTotalTwist q H (T ∪ R) :
        ZMod (primeSetProduct (T ∪ R)))
  let E : ZMod (primeSetProduct (T ∪ R)) :=
    (fixedProductCRTIdempotentNat (T ∪ R) T :
      ZMod (primeSetProduct (T ∪ R)))
  have hdiff : (T ∪ R) \ T = R := by
    ext p
    constructor
    · intro hp
      have hp' := Finset.mem_sdiff.mp hp
      rcases Finset.mem_union.mp hp'.1 with hpT | hpR
      · exact (hp'.2 hpT).elim
      · exact hpR
    · intro hpR
      apply Finset.mem_sdiff.mpr
      refine ⟨Finset.mem_union_right T hpR, ?_⟩
      intro hpT
      exact (Finset.disjoint_left.mp hdisj) hpT hpR
  have hE :
      h2BooleanBlockCRTEquiv T R hdisj hPrimeT hPrimeR E = (0, 1) := by
    rw [h2BooleanBlockCRTEquiv_apply_natCast]
    apply Prod.ext
    · have hs :=
        (fixedProductCRTIdempotentNat_specs
          (S := T ∪ R) (A := T) Finset.subset_union_left hPrimeU).1
      simpa [E] using
        ((ZMod.natCast_eq_natCast_iff
          (fixedProductCRTIdempotentNat (T ∪ R) T) 0
          (primeSetProduct T)).2 (by simpa using hs))
    · have hs :=
        (fixedProductCRTIdempotentNat_specs
          (S := T ∪ R) (A := T) Finset.subset_union_left hPrimeU).2
      simpa [E, hdiff] using
        ((ZMod.natCast_eq_natCast_iff
          (fixedProductCRTIdempotentNat (T ∪ R) T) 1
          (primeSetProduct R)).2 (by simpa [hdiff] using hs))
  have hmap :
      h2BooleanBlockCRTEquiv T R hdisj hPrimeT hPrimeR (t * E) =
        ((h2BooleanBlockCRTEquiv T R hdisj hPrimeT hPrimeR t).1 * 0,
         (h2BooleanBlockCRTEquiv T R hdisj hPrimeT hPrimeR t).2 * 1) := by
    rw [map_mul, hE]
    apply Prod.ext <;> simp
  have hchar :=
    h2_stdAddChar_eq_block_mul
      T R hdisj hPrimeT hPrimeR (t * E)
  rw [hmap] at hchar
  simp only [Prod.fst, Prod.snd, mul_zero, mul_one] at hchar
  have hzero :
      ZMod.stdAddChar (0 : ZMod (primeSetProduct T)) = 1 :=
    (ZMod.stdAddChar (N := primeSetProduct T)).map_zero_eq_one
  rw [hzero, one_mul] at hchar
  have hchar' :
      ZMod.stdAddChar (t * E) =
        ZMod.stdAddChar
          (h2BooleanBlockRightFrequency
            T R hdisj hPrimeT hPrimeR t) := by
    simpa [h2BooleanBlockRightFrequency] using hchar
  have hright :=
    fixedQPeriodic_rightBlockFrequency_eq_source
      (q := q) (H := H) (j := j) hdisj hActive hOrdR
  have ht :
      t = (j : ZMod (primeSetProduct (T ∪ R))) *
        (fixedQPeriodicTotalTwist q H (T ∪ R) :
          ZMod (primeSetProduct (T ∪ R))) := rfl
  rw [ht, hright] at hchar'
  simpa [t, E] using hchar'

#print axioms sourceForbiddenBooleanNaturalTerm_sub_vaalerMain_abs_le_error
#print axioms source_periodicFourierCoeff_block_factor
theorem source_weighted_fourier_mode_eq_powerset
    {q m : ℕ}
    (hm0 : m ≠ 0)
    (hsq : Squarefree m)
    (hcop6q : m.Coprime (6 * q))
    [NeZero (primeSetProduct m.primeFactors)]
    (z t : ZMod (primeSetProduct m.primeFactors)) :
    let hPrime : ∀ p ∈ m.primeFactors, p.Prime :=
      fun p hp => (Nat.mem_primeFactors.mp hp).1
    ((fixedQShiuWeight q m : ℝ) : ℂ) *
        (ZMod.stdAddChar z *
          fixedProductBooleanFourierCoeff m.primeFactors hPrime t) =
      (omegaCoeff q m : ℂ) *
        ∑ A ∈ m.primeFactors.powerset,
          ZMod.stdAddChar
            (z + t *
              (fixedProductCRTIdempotentNat m.primeFactors A :
                ZMod (primeSetProduct m.primeFactors))) := by
  dsimp only
  let hPrime : ∀ p ∈ m.primeFactors, p.Prime :=
    fun p hp => (Nat.mem_primeFactors.mp hp).1
  have hcoeff :=
    fixedQShiuWeight_mul_booleanFourierCoeff_eq_omega_phase_sum
      (q := q) (m := m) hm0 hsq hcop6q t
  calc
    ((fixedQShiuWeight q m : ℝ) : ℂ) *
        (ZMod.stdAddChar z *
          fixedProductBooleanFourierCoeff m.primeFactors hPrime t)
        =
      ZMod.stdAddChar z *
        (((fixedQShiuWeight q m : ℝ) : ℂ) *
          fixedProductBooleanFourierCoeff m.primeFactors hPrime t) := by
            ring
    _ =
      ZMod.stdAddChar z *
        ((omegaCoeff q m : ℂ) *
          ∑ A ∈ m.primeFactors.powerset,
            ZMod.stdAddChar
              (t * (fixedProductCRTIdempotentNat m.primeFactors A :
                ZMod (primeSetProduct m.primeFactors)))) := by
          rw [hcoeff]
    _ =
      (omegaCoeff q m : ℂ) *
        (ZMod.stdAddChar z *
          ∑ A ∈ m.primeFactors.powerset,
            ZMod.stdAddChar
              (t * (fixedProductCRTIdempotentNat m.primeFactors A :
                ZMod (primeSetProduct m.primeFactors)))) := by
          ring
    _ =
      (omegaCoeff q m : ℂ) *
        ∑ A ∈ m.primeFactors.powerset,
          (ZMod.stdAddChar z *
            ZMod.stdAddChar
              (t * (fixedProductCRTIdempotentNat m.primeFactors A :
                ZMod (primeSetProduct m.primeFactors)))) := by
          rw [Finset.mul_sum]
    _ =
      (omegaCoeff q m : ℂ) *
        ∑ A ∈ m.primeFactors.powerset,
          ZMod.stdAddChar
            (z + t *
              (fixedProductCRTIdempotentNat m.primeFactors A :
                ZMod (primeSetProduct m.primeFactors))) := by
          congr 1
          apply Finset.sum_congr rfl
          intro A hA
          rw [AddChar.map_add_eq_mul]

theorem source_weighted_fourier_mode_im_eq_powerset
    {q m : ℕ}
    (hm0 : m ≠ 0)
    (hsq : Squarefree m)
    (hcop6q : m.Coprime (6 * q))
    [NeZero (primeSetProduct m.primeFactors)]
    (z t : ZMod (primeSetProduct m.primeFactors)) :
    let hPrime : ∀ p ∈ m.primeFactors, p.Prime :=
      fun p hp => (Nat.mem_primeFactors.mp hp).1
    fixedQShiuWeight q m *
        (ZMod.stdAddChar z *
          fixedProductBooleanFourierCoeff m.primeFactors hPrime t).im =
      ((omegaCoeff q m : ℂ) *
        ∑ A ∈ m.primeFactors.powerset,
          ZMod.stdAddChar
            (z + t *
              (fixedProductCRTIdempotentNat m.primeFactors A :
                ZMod (primeSetProduct m.primeFactors)))).im := by
  dsimp only
  have h :=
    congrArg Complex.im
      (source_weighted_fourier_mode_eq_powerset
        (q := q) (m := m) hm0 hsq hcop6q z t)
  simpa using h

lemma omegaCoeff_eq_indicator_gamma_divisor_sum_div
    {q m : ℕ} (hm0 : m ≠ 0) :
    omegaCoeff q m =
      ((((intIndicator (Squarefree m) *
          intIndicator (m.Coprime (6 * q)) : ℤ) : ℝ) *
        (∑ d ∈ m.divisors, sourceGammaNatWeight d)) / (m : ℝ)) := by
  by_cases hs : Squarefree m ∧ m.Coprime (6 * q)
  · have hsq : Squarefree m := hs.1
    have hcop : m.Coprime (6 * q) := hs.2
    have h := omegaCoeff_mul_nat_eq_sourceGamma_divisor_sum
      (q := q) (m := m) hm0 hsq hcop
    have hmR : (m : ℝ) ≠ 0 := by exact_mod_cast hm0
    have hdiv :
        omegaCoeff q m =
          (∑ d ∈ m.divisors, sourceGammaNatWeight d) / (m : ℝ) := by
      apply (eq_div_iff hmR).2
      simpa [mul_comm] using h
    calc
      omegaCoeff q m =
          (∑ d ∈ m.divisors, sourceGammaNatWeight d) / (m : ℝ) := hdiv
      _ = ((((intIndicator (Squarefree m) *
          intIndicator (m.Coprime (6 * q)) : ℤ) : ℝ) *
        (∑ d ∈ m.divisors, sourceGammaNatWeight d)) / (m : ℝ)) := by
          unfold intIndicator
          rw [if_pos hsq, if_pos hcop]
          norm_num
  · have hz : omegaCoeff q m = 0 := by
      simp [omegaCoeff, hm0, hs]
    rw [hz]
    by_cases hsq : Squarefree m
    · have hcop : ¬ m.Coprime (6 * q) := by
        intro hc
        exact hs ⟨hsq, hc⟩
      simp [intIndicator, hsq, hcop]
    · simp [intIndicator, hsq]

#print axioms omegaCoeff_eq_indicator_gamma_divisor_sum_div

lemma source_sum_Icc_dvd_reindex_interval
    {M : Type*} [AddCommMonoid M]
    (F : ℕ → M) {d A B : ℕ} (hd : 0 < d) :
    (∑ n ∈ (Finset.Icc A B).filter (fun n => d ∣ n), F n) =
      ∑ ell ∈ Finset.Icc (A ⌈/⌉ d) (B / d), F (d * ell) := by
  classical
  apply Finset.sum_bij
    (fun n hn => n / d)
  · intro n hn
    have hnF := Finset.mem_filter.mp hn
    have hnI := Finset.mem_Icc.mp hnF.1
    have hdn := hnF.2
    apply Finset.mem_Icc.mpr
    constructor
    · apply (ceilDiv_le_iff_le_mul hd).2
      simpa [Nat.mul_div_cancel' hdn] using hnI.1
    · exact Nat.div_le_div_right hnI.2
  · intro n1 hn1 n2 hn2 heq
    have hd1 := (Finset.mem_filter.mp hn1).2
    have hd2 := (Finset.mem_filter.mp hn2).2
    calc
      n1 = d * (n1 / d) := (Nat.mul_div_cancel' hd1).symm
      _ = d * (n2 / d) := by rw [heq]
      _ = n2 := Nat.mul_div_cancel' hd2
  · intro ell hell
    have hellI := Finset.mem_Icc.mp hell
    refine ⟨d * ell, ?_, ?_⟩
    · apply Finset.mem_filter.mpr
      constructor
      · apply Finset.mem_Icc.mpr
        constructor
        · exact (ceilDiv_le_iff_le_mul hd).1 hellI.1
        · have hellB : ell * d ≤ B :=
            (Nat.le_div_iff_mul_le hd).mp hellI.2
          simpa [mul_comm] using hellB
      · exact dvd_mul_right d ell
    · exact Nat.mul_div_cancel_left ell hd
  · intro n hn
    have hdn := (Finset.mem_filter.mp hn).2
    exact congrArg F (Nat.mul_div_cancel' hdn).symm

#print axioms source_sum_Icc_dvd_reindex_interval

theorem source_sum_Icc_divisor_convolution_reindex
    {M : Type*} [AddCommMonoid M]
    (F : ℕ → ℕ → M) {A B : ℕ}
    (hA : 0 < A) :
    (∑ m ∈ Finset.Icc A B,
      ∑ d ∈ m.divisors, F d (m / d)) =
      ∑ d ∈ Finset.Icc 1 B,
        ∑ n ∈ Finset.Icc (A ⌈/⌉ d) (B / d), F d n := by
  classical
  calc
    (∑ m ∈ Finset.Icc A B,
      ∑ d ∈ m.divisors, F d (m / d))
      =
      ∑ m ∈ Finset.Icc A B,
        ∑ d ∈ Finset.Icc 1 B,
          if d ∣ m then F d (m / d) else 0 := by
            apply Finset.sum_congr rfl
            intro m hm
            have hmI := Finset.mem_Icc.mp hm
            have hm0 : m ≠ 0 := by omega
            exact source_sum_divisors_eq_Icc_indicator
              hm0 hmI.2 (fun d => F d (m / d))
    _ =
      ∑ d ∈ Finset.Icc 1 B,
        ∑ m ∈ Finset.Icc A B,
          if d ∣ m then F d (m / d) else 0 := by
            rw [Finset.sum_comm]
    _ =
      ∑ d ∈ Finset.Icc 1 B,
        ∑ n ∈ Finset.Icc (A ⌈/⌉ d) (B / d), F d n := by
            apply Finset.sum_congr rfl
            intro d hd
            have hdpos : 0 < d := (Finset.mem_Icc.mp hd).1
            rw [← Finset.sum_filter]
            rw [source_sum_Icc_dvd_reindex_interval
              (fun m => F d (m / d)) hdpos]
            apply Finset.sum_congr rfl
            intro n hn
            rw [Nat.mul_div_cancel_left n hdpos]

#print axioms source_sum_Icc_divisor_convolution_reindex

theorem source_sum_Icc_omegaCoeff_gamma_outer_reindex
    (F : ℕ → ℝ) {q A B : ℕ}
    (hA : 0 < A) :
    (∑ m ∈ Finset.Icc A B, omegaCoeff q m * F m) =
      ∑ d ∈ Finset.Icc 1 B,
        sourceGammaNatWeight d *
          ∑ n ∈ Finset.Icc (A ⌈/⌉ d) (B / d),
            (((intIndicator (Squarefree (d * n)) *
                intIndicator ((d * n).Coprime (6 * q)) : ℤ) : ℝ) /
              ((d * n : ℕ) : ℝ)) * F (d * n) := by
  classical
  let W : ℕ → ℝ := fun m =>
    (((intIndicator (Squarefree m) *
        intIndicator (m.Coprime (6 * q)) : ℤ) : ℝ) / (m : ℝ)) * F m
  have hpoint : ∀ m ∈ Finset.Icc A B,
      omegaCoeff q m * F m =
        (∑ d ∈ m.divisors, sourceGammaNatWeight d) * W m := by
    intro m hm
    have hm0 : m ≠ 0 := by
      have hmA := (Finset.mem_Icc.mp hm).1
      omega
    rw [omegaCoeff_eq_indicator_gamma_divisor_sum_div hm0]
    dsimp [W]
    ring
  calc
    (∑ m ∈ Finset.Icc A B, omegaCoeff q m * F m)
        = ∑ m ∈ Finset.Icc A B,
            (∑ d ∈ m.divisors, sourceGammaNatWeight d) * W m := by
              apply Finset.sum_congr rfl
              intro m hm
              exact hpoint m hm
    _ = ∑ m ∈ Finset.Icc A B,
          ∑ d ∈ m.divisors, sourceGammaNatWeight d * W m := by
            apply Finset.sum_congr rfl
            intro m hm
            rw [Finset.sum_mul]
    _ = ∑ m ∈ Finset.Icc A B,
          ∑ d ∈ m.divisors,
            sourceGammaNatWeight d * W (d * (m / d)) := by
              apply Finset.sum_congr rfl
              intro m hm
              apply Finset.sum_congr rfl
              intro d hd
              have hdm : d ∣ m := Nat.dvd_of_mem_divisors hd
              rw [Nat.mul_div_cancel' hdm]
    _ = ∑ d ∈ Finset.Icc 1 B,
          ∑ n ∈ Finset.Icc (A ⌈/⌉ d) (B / d),
            sourceGammaNatWeight d * W (d * n) := by
              exact source_sum_Icc_divisor_convolution_reindex
                (fun d n => sourceGammaNatWeight d * W (d * n)) hA
    _ = ∑ d ∈ Finset.Icc 1 B,
          sourceGammaNatWeight d *
            ∑ n ∈ Finset.Icc (A ⌈/⌉ d) (B / d), W (d * n) := by
              apply Finset.sum_congr rfl
              intro d hd
              rw [Finset.mul_sum]
    _ = ∑ d ∈ Finset.Icc 1 B,
          sourceGammaNatWeight d *
            ∑ n ∈ Finset.Icc (A ⌈/⌉ d) (B / d),
              (((intIndicator (Squarefree (d * n)) *
                  intIndicator ((d * n).Coprime (6 * q)) : ℤ) : ℝ) /
                ((d * n : ℕ) : ℝ)) * F (d * n) := by
              rfl

#print axioms source_sum_Icc_omegaCoeff_gamma_outer_reindex

lemma source_fixed_d_support_iff
    {q H D d n : ℕ}
    (hdsq : Squarefree d)
    (hdunit : d.Coprime (H * (6 * q) * D)) :
    (Squarefree (d * n) ∧
      (d * n).Coprime (H * (6 * q) * D)) ↔
    (n.Coprime H ∧
      n.Coprime (6 * q) ∧
      Squarefree n ∧
      n.Coprime (d * D)) := by
  have hdH : d.Coprime H := by
    exact (Nat.coprime_mul_iff_right.mp
      (Nat.coprime_mul_iff_right.mp hdunit).1).1
  have hd6q : d.Coprime (6 * q) := by
    exact (Nat.coprime_mul_iff_right.mp
      (Nat.coprime_mul_iff_right.mp hdunit).1).2
  have hdD : d.Coprime D := by
    exact (Nat.coprime_mul_iff_right.mp hdunit).2
  have hd6qD : d.Coprime (6 * q * D) :=
    Nat.Coprime.mul_right hd6q hdD
  constructor
  · rintro ⟨hdsn, hcop⟩
    have hH6q : (d * n).Coprime (H * (6 * q)) :=
      (Nat.coprime_mul_iff_right.mp hcop).1
    have hD : (d * n).Coprime D :=
      (Nat.coprime_mul_iff_right.mp hcop).2
    have hH : (d * n).Coprime H :=
      (Nat.coprime_mul_iff_right.mp hH6q).1
    have h6q : (d * n).Coprime (6 * q) :=
      (Nat.coprime_mul_iff_right.mp hH6q).2
    have hnH : n.Coprime H :=
      (Nat.coprime_mul_iff_left.mp hH).2
    have hdn6D : (d * n).Coprime (6 * D) := by
      have h6 : (d * n).Coprime 6 :=
        (Nat.coprime_mul_iff_right.mp h6q).1
      exact Nat.Coprime.mul_right h6 hD
    have hq : (d * n).Coprime q :=
      (Nat.coprime_mul_iff_right.mp h6q).2
    have hrem :=
      (fixedQ_squarefree_removal_support_iff
        (d := d) (n := n) (q := q) (R := D)
        hdsq hd6qD).mp ⟨hdsn, hdn6D, hq⟩
    exact ⟨hnH, hrem.1, hrem.2.1, hrem.2.2⟩
  · rintro ⟨hnH, hn6q, hnsq, hndD⟩
    have hrem :=
      (fixedQ_squarefree_removal_support_iff
        (d := d) (n := n) (q := q) (R := D)
        hdsq hd6qD).mpr ⟨hn6q, hnsq, hndD⟩
    have hdnH : (d * n).Coprime H :=
      Nat.Coprime.mul_left hdH hnH
    have hdn6q : (d * n).Coprime (6 * q) :=
      Nat.Coprime.mul_left hd6q hn6q
    have hdnD : (d * n).Coprime D :=
      (Nat.coprime_mul_iff_right.mp hrem.2.1).2
    have hdnH6q : (d * n).Coprime (H * (6 * q)) :=
      Nat.Coprime.mul_right hdnH hdn6q
    exact ⟨hrem.1, Nat.Coprime.mul_right hdnH6q hdnD⟩

#print axioms source_fixed_d_support_iff

lemma source_fixed_d_support_indicator
    {q H D d n : ℕ}
    (hdsq : Squarefree d)
    (hdunit : d.Coprime (H * (6 * q) * D)) :
    intIndicator (Squarefree (d * n)) *
        intIndicator ((d * n).Coprime (H * (6 * q) * D)) =
      intIndicator (n.Coprime H) *
        intIndicator (n.Coprime (6 * q)) *
        intIndicator (Squarefree n) *
        intIndicator (n.Coprime (d * D)) := by
  rw [intIndicator_mul]
  rw [show
      intIndicator (n.Coprime H) *
          intIndicator (n.Coprime (6 * q)) *
          intIndicator (Squarefree n) *
          intIndicator (n.Coprime (d * D)) =
        intIndicator
          (n.Coprime H ∧ n.Coprime (6 * q) ∧
            Squarefree n ∧ n.Coprime (d * D)) by
      rw [intIndicator_mul, intIndicator_mul, intIndicator_mul]
      simp [and_assoc]]
  exact intIndicator_congr (source_fixed_d_support_iff hdsq hdunit)

#print axioms source_fixed_d_support_indicator

lemma source_sum_Icc_cf2_reindex_interval
    {M : Type*} [AddCommMonoid M]
    (F : ℕ → M) {c f P A B : ℕ}
    (hcP : c ∣ P) (hfP : f.Coprime P)
    (hcpos : 0 < c) (hfpos : 0 < f) :
    (∑ n ∈ Finset.Icc A B,
      if c ∣ n ∧ f ^ 2 ∣ n then F n else 0) =
      ∑ ell ∈ Finset.Icc
        (A ⌈/⌉ (c * f ^ 2)) (B / (c * f ^ 2)),
        F ((c * f ^ 2) * ell) := by
  classical
  rw [← Finset.sum_filter]
  have hfilter :
      (Finset.Icc A B).filter (fun n => c ∣ n ∧ f ^ 2 ∣ n) =
        (Finset.Icc A B).filter (fun n => c * f ^ 2 ∣ n) := by
    ext n
    simp only [Finset.mem_filter, Finset.mem_Icc, and_congr_right_iff]
    intro hn
    exact source_c_mul_f_sq_dvd_iff hcP hfP
  rw [hfilter]
  exact source_sum_Icc_dvd_reindex_interval F
    (mul_pos hcpos (pow_pos hfpos 2))

#print axioms source_sum_Icc_cf2_reindex_interval

lemma source_squarefree_coprime_channel_expansion_real
    {n P : ℕ} (hn0 : n ≠ 0) (hP0 : P ≠ 0) :
    (((intIndicator (Squarefree n) * intIndicator (n.Coprime P) : ℤ) : ℝ)) =
      ∑ f ∈ n.divisors,
        if f ^ 2 ∣ n ∧ f.Coprime P then
          (ArithmeticFunction.moebius f : ℝ) *
            (∑ c ∈ P.divisors,
              if c ∣ n then (ArithmeticFunction.moebius c : ℝ) else 0)
        else 0 := by
  exact_mod_cast source_squarefree_coprime_channel_expansion hn0 hP0

theorem source_sum_Icc_squarefree_coprime_channel_reindex
    (F : ℕ → ℝ) {P A B : ℕ}
    (hP0 : P ≠ 0) (hA : 0 < A) :
    (∑ n ∈ Finset.Icc A B,
      (((intIndicator (Squarefree n) *
        intIndicator (n.Coprime P) : ℤ) : ℝ)) * F n) =
      ∑ f ∈ Finset.Icc 1 B,
        if f.Coprime P then
          (ArithmeticFunction.moebius f : ℝ) *
            ∑ c ∈ P.divisors,
              (ArithmeticFunction.moebius c : ℝ) *
                ∑ ell ∈ Finset.Icc
                  (A ⌈/⌉ (c * f ^ 2)) (B / (c * f ^ 2)),
                  F ((c * f ^ 2) * ell)
        else 0 := by
  classical
  calc
    (∑ n ∈ Finset.Icc A B,
      (((intIndicator (Squarefree n) *
        intIndicator (n.Coprime P) : ℤ) : ℝ)) * F n)
      =
      ∑ n ∈ Finset.Icc A B,
        (∑ f ∈ n.divisors,
          if f ^ 2 ∣ n ∧ f.Coprime P then
            (ArithmeticFunction.moebius f : ℝ) *
              (∑ c ∈ P.divisors,
                if c ∣ n then (ArithmeticFunction.moebius c : ℝ) else 0)
          else 0) * F n := by
            apply Finset.sum_congr rfl
            intro n hn
            have hn0 : n ≠ 0 := by
              have := (Finset.mem_Icc.mp hn).1
              omega
            rw [source_squarefree_coprime_channel_expansion_real hn0 hP0]
    _ =
      ∑ n ∈ Finset.Icc A B,
        ∑ f ∈ n.divisors,
          ((if f ^ 2 ∣ n ∧ f.Coprime P then
            (ArithmeticFunction.moebius f : ℝ) *
              (∑ c ∈ P.divisors,
                if c ∣ n then (ArithmeticFunction.moebius c : ℝ) else 0)
          else 0) * F n) := by
            apply Finset.sum_congr rfl
            intro n hn
            rw [Finset.sum_mul]
    _ =
      ∑ n ∈ Finset.Icc A B,
        ∑ f ∈ Finset.Icc 1 B,
          if f ∣ n then
            ((if f ^ 2 ∣ n ∧ f.Coprime P then
              (ArithmeticFunction.moebius f : ℝ) *
                (∑ c ∈ P.divisors,
                  if c ∣ n then (ArithmeticFunction.moebius c : ℝ) else 0)
            else 0) * F n)
          else 0 := by
            apply Finset.sum_congr rfl
            intro n hn
            have hnI := Finset.mem_Icc.mp hn
            have hn0 : n ≠ 0 := by omega
            exact source_sum_divisors_eq_Icc_indicator
              hn0 hnI.2
              (fun f =>
                ((if f ^ 2 ∣ n ∧ f.Coprime P then
                  (ArithmeticFunction.moebius f : ℝ) *
                    (∑ c ∈ P.divisors,
                      if c ∣ n then (ArithmeticFunction.moebius c : ℝ) else 0)
                else 0) * F n))
    _ =
      ∑ f ∈ Finset.Icc 1 B,
        ∑ n ∈ Finset.Icc A B,
          if f ∣ n then
            ((if f ^ 2 ∣ n ∧ f.Coprime P then
              (ArithmeticFunction.moebius f : ℝ) *
                (∑ c ∈ P.divisors,
                  if c ∣ n then (ArithmeticFunction.moebius c : ℝ) else 0)
            else 0) * F n)
          else 0 := by rw [Finset.sum_comm]
    _ =
      ∑ f ∈ Finset.Icc 1 B,
        if f.Coprime P then
          (ArithmeticFunction.moebius f : ℝ) *
            ∑ c ∈ P.divisors,
              (ArithmeticFunction.moebius c : ℝ) *
                ∑ ell ∈ Finset.Icc
                  (A ⌈/⌉ (c * f ^ 2)) (B / (c * f ^ 2)),
                  F ((c * f ^ 2) * ell)
        else 0 := by
      apply Finset.sum_congr rfl
      intro f hf
      have hfpos : 0 < f := (Finset.mem_Icc.mp hf).1
      by_cases hfP : f.Coprime P
      · rw [if_pos hfP]
        have hsimp :
            (∑ n ∈ Finset.Icc A B,
              if f ∣ n then
                ((if f ^ 2 ∣ n ∧ f.Coprime P then
                  (ArithmeticFunction.moebius f : ℝ) *
                    (∑ c ∈ P.divisors,
                      if c ∣ n then (ArithmeticFunction.moebius c : ℝ) else 0)
                else 0) * F n)
              else 0)
            =
            ∑ n ∈ Finset.Icc A B,
              if f ^ 2 ∣ n then
                (ArithmeticFunction.moebius f : ℝ) *
                  (∑ c ∈ P.divisors,
                    if c ∣ n then (ArithmeticFunction.moebius c : ℝ) else 0) *
                  F n
              else 0 := by
          apply Finset.sum_congr rfl
          intro n hn
          by_cases hf2 : f ^ 2 ∣ n
          · have hfd : f ∣ n :=
              (dvd_pow_self f (by norm_num : 2 ≠ 0)).trans hf2
            simp [hfP, hf2, hfd]
          · simp [hf2]
        rw [hsimp]
        have hfactor :
            (∑ n ∈ Finset.Icc A B,
              if f ^ 2 ∣ n then
                (ArithmeticFunction.moebius f : ℝ) *
                  (∑ c ∈ P.divisors,
                    if c ∣ n then (ArithmeticFunction.moebius c : ℝ) else 0) *
                  F n
              else 0)
            =
            (ArithmeticFunction.moebius f : ℝ) *
              ∑ n ∈ Finset.Icc A B,
                if f ^ 2 ∣ n then
                  (∑ c ∈ P.divisors,
                    if c ∣ n then (ArithmeticFunction.moebius c : ℝ) else 0) *
                    F n
                else 0 := by
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro n hn
          by_cases hf2 : f ^ 2 ∣ n <;> simp [hf2] <;> ring
        rw [hfactor]
        congr 1
        calc
          (∑ n ∈ Finset.Icc A B,
            if f ^ 2 ∣ n then
              (∑ c ∈ P.divisors,
                if c ∣ n then (ArithmeticFunction.moebius c : ℝ) else 0) *
                F n
            else 0)
            =
            ∑ n ∈ Finset.Icc A B,
              ∑ c ∈ P.divisors,
                if c ∣ n ∧ f ^ 2 ∣ n then
                  (ArithmeticFunction.moebius c : ℝ) * F n
                else 0 := by
              apply Finset.sum_congr rfl
              intro n hn
              by_cases hf2 : f ^ 2 ∣ n
              · simp [hf2, Finset.sum_mul]
              · simp [hf2]
          _ =
            ∑ c ∈ P.divisors,
              ∑ n ∈ Finset.Icc A B,
                if c ∣ n ∧ f ^ 2 ∣ n then
                  (ArithmeticFunction.moebius c : ℝ) * F n
                else 0 := by rw [Finset.sum_comm]
          _ =
            ∑ c ∈ P.divisors,
              (ArithmeticFunction.moebius c : ℝ) *
                ∑ ell ∈ Finset.Icc
                  (A ⌈/⌉ (c * f ^ 2)) (B / (c * f ^ 2)),
                  F ((c * f ^ 2) * ell) := by
              apply Finset.sum_congr rfl
              intro c hc
              have hcP : c ∣ P := Nat.dvd_of_mem_divisors hc
              have hcpos : 0 < c :=
                Nat.pos_of_dvd_of_pos hcP (Nat.pos_of_ne_zero hP0)
              have hre := source_sum_Icc_cf2_reindex_interval
                F hcP hfP hcpos hfpos
                (A := A) (B := B)
              have hre' := congrArg
                (fun x : ℝ => (ArithmeticFunction.moebius c : ℝ) * x) hre
              simpa [Finset.mul_sum, mul_ite] using hre'
      · rw [if_neg hfP]
        apply Finset.sum_eq_zero
        intro n hn
        by_cases hfd : f ∣ n
        · simp [hfd, hfP]
        · simp [hfd]

#print axioms source_sum_Icc_squarefree_coprime_channel_reindex

noncomputable def sourceFixedDUnitWeight
    (q H : ℕ) (F : ℕ → ℝ) (n : ℕ) : ℝ :=
  (((intIndicator (n.Coprime H) *
      intIndicator (n.Coprime (6 * q)) : ℤ) : ℝ) * F n)

theorem source_sum_Icc_fixed_d_cf2_channel_reindex
    (F : ℕ → ℝ) {q H D d A B : ℕ}
    (hdsq : Squarefree d)
    (hdunit : d.Coprime (H * (6 * q) * D))
    (hD0 : D ≠ 0)
    (hA : 0 < A) :
    (∑ n ∈ Finset.Icc A B,
      (((intIndicator (Squarefree (d * n)) *
          intIndicator ((d * n).Coprime (H * (6 * q) * D)) : ℤ) : ℝ) *
        F n)) =
      ∑ f ∈ Finset.Icc 1 B,
        if f.Coprime (d * D) then
          (ArithmeticFunction.moebius f : ℝ) *
            ∑ c ∈ (d * D).divisors,
              (ArithmeticFunction.moebius c : ℝ) *
                ∑ ell ∈ Finset.Icc
                  (A ⌈/⌉ (c * f ^ 2)) (B / (c * f ^ 2)),
                  sourceFixedDUnitWeight q H F ((c * f ^ 2) * ell)
        else 0 := by
  classical
  let G : ℕ → ℝ := fun n => sourceFixedDUnitWeight q H F n
  have hd0 : d ≠ 0 := hdsq.ne_zero
  have hP0 : d * D ≠ 0 := mul_ne_zero hd0 hD0
  have hleft :
      (∑ n ∈ Finset.Icc A B,
        (((intIndicator (Squarefree (d * n)) *
            intIndicator ((d * n).Coprime (H * (6 * q) * D)) : ℤ) : ℝ) *
          F n)) =
        ∑ n ∈ Finset.Icc A B,
          (((intIndicator (Squarefree n) *
              intIndicator (n.Coprime (d * D)) : ℤ) : ℝ) * G n) := by
    apply Finset.sum_congr rfl
    intro n hn
    have hs := source_fixed_d_support_indicator
      (q := q) (H := H) (D := D) (d := d) (n := n) hdsq hdunit
    dsimp [G, sourceFixedDUnitWeight]
    norm_cast at hs ⊢
    rw [hs]
    push_cast
    ring
  rw [hleft]
  simpa [G] using
    (source_sum_Icc_squarefree_coprime_channel_reindex
      G (P := d * D) (A := A) (B := B) hP0 hA)

#print axioms source_sum_Icc_fixed_d_cf2_channel_reindex

lemma source_stdAddChar_nat_gcd_reduce
    {A q t : ℕ} [NeZero q] [NeZero (reducedModulus A q)]
    (hq : 0 < q) :
    ZMod.stdAddChar (((A * t : ℕ) : ℤ) : ZMod q) =
      ZMod.stdAddChar
        ((((reducedNumerator A q) * t : ℕ) : ℤ) :
          ZMod (reducedModulus A q)) := by
  rw [ZMod.stdAddChar_coe, ZMod.stdAddChar_coe]
  congr 1
  unfold reducedNumerator reducedModulus reducedDivisor
  let g := Nat.gcd A q
  have hgpos : 0 < g := Nat.gcd_pos_of_pos_right A hq
  have hgA : g ∣ A := Nat.gcd_dvd_left A q
  have hgq : g ∣ q := Nat.gcd_dvd_right A q
  have hA : g * (A / g) = A := Nat.mul_div_cancel' hgA
  have hqeq : g * (q / g) = q := Nat.mul_div_cancel' hgq
  have hqred : 0 < q / g := Nat.div_pos (Nat.gcd_le_right A hq) hgpos
  have hqC : (q : ℂ) ≠ 0 := by exact_mod_cast hq.ne'
  have hgC : (g : ℂ) ≠ 0 := by exact_mod_cast hgpos.ne'
  have hqredC : ((q / g : ℕ) : ℂ) ≠ 0 := by exact_mod_cast hqred.ne'
  have hAc : (A : ℂ) = (g : ℂ) * ((A / g : ℕ) : ℂ) := by
    exact_mod_cast hA.symm
  have hqc : (q : ℂ) = (g : ℂ) * ((q / g : ℕ) : ℂ) := by
    exact_mod_cast hqeq.symm
  have hratio :
      (A : ℂ) / (q : ℂ) =
        ((A / g : ℕ) : ℂ) / ((q / g : ℕ) : ℂ) := by
    rw [hAc, hqc]
    field_simp [hgC, hqredC]
  calc
    2 * ↑Real.pi * Complex.I * ↑↑(A * t) / ↑q
        = (2 * ↑Real.pi * Complex.I * (t : ℂ)) *
            ((A : ℂ) / (q : ℂ)) := by
              push_cast
              ring
    _ = (2 * ↑Real.pi * Complex.I * (t : ℂ)) *
            (((A / g : ℕ) : ℂ) / ((q / g : ℕ) : ℂ)) := by
              rw [hratio]
    _ = 2 * ↑Real.pi * Complex.I * ↑↑(A / g * t) / ↑(q / g) := by
              push_cast
              ring

#print axioms source_stdAddChar_nat_gcd_reduce

lemma source_reciprocalPhase_neg_eq_star
    (N : ℕ) [NeZero N] (a x : ZMod N) :
    reciprocalPhase N (-a) x =
      (starRingEnd ℂ) (reciprocalPhase N a x) := by
  unfold reciprocalPhase
  by_cases hx : IsUnit x
  · rw [if_pos hx, if_pos hx]
    rw [show (-a) * x⁻¹ = -(a * x⁻¹) by ring]
    rw [AddChar.map_neg_eq_conj]
  · rw [if_neg hx, if_neg hx]
    simp

lemma source_reciprocalMean_neg_eq_star
    (N : ℕ) [NeZero N] (a : ZMod N) :
    reciprocalMean N (-a) =
      (starRingEnd ℂ) (reciprocalMean N a) := by
  unfold reciprocalMean
  rw [map_mul, map_sum]
  congr 1
  · simp
  · apply Finset.sum_congr rfl
    intro x hx
    exact source_reciprocalPhase_neg_eq_star N a x

lemma source_centeredReciprocalPhase_neg_eq_star
    (N : ℕ) [NeZero N] (a x : ZMod N) :
    centeredReciprocalPhase N (-a) x =
      (starRingEnd ℂ) (centeredReciprocalPhase N a x) := by
  unfold centeredReciprocalPhase
  rw [source_reciprocalPhase_neg_eq_star, source_reciprocalMean_neg_eq_star]
  exact ((starRingEnd ℂ).map_sub _ _).symm

lemma source_weightedCenteredIntervalSum_neg_eq_star
    (N : ℕ) [NeZero N] (a x : ZMod N) (Y L : ℕ) :
    weightedCenteredIntervalSum N (-a) x Y L =
      (starRingEnd ℂ) (weightedCenteredIntervalSum N a x Y L) := by
  unfold weightedCenteredIntervalSum
  rw [map_sum]
  apply Finset.sum_congr rfl
  intro j hj
  rw [map_mul]
  rw [source_centeredReciprocalPhase_neg_eq_star]
  congr 1
  simp [reciprocalNatWeight]

lemma source_norm_weightedCenteredIntervalSum_neg_eq
    (N : ℕ) [NeZero N] (a x : ZMod N) (Y L : ℕ) :
    ‖weightedCenteredIntervalSum N (-a) x Y L‖ =
      ‖weightedCenteredIntervalSum N a x Y L‖ := by
  rw [source_weightedCenteredIntervalSum_neg_eq_star]
  exact norm_star _

#print axioms source_norm_weightedCenteredIntervalSum_neg_eq

lemma source_norm_reciprocalPhase_le_one
    (N : ℕ) [NeZero N] (a x : ZMod N) :
    ‖reciprocalPhase N a x‖ ≤ 1 := by
  unfold reciprocalPhase
  by_cases hx : IsUnit x
  · rw [if_pos hx]
    rw [norm_stdAddChar_eq_one]
  · rw [if_neg hx, norm_zero]
    norm_num

lemma source_norm_reciprocalMean_le_one
    (N : ℕ) [NeZero N] (a : ZMod N) :
    ‖reciprocalMean N a‖ ≤ 1 := by
  unfold reciprocalMean
  rw [norm_mul]
  have hNpos : (0 : ℝ) < N := by
    exact_mod_cast (Nat.pos_of_ne_zero (NeZero.ne N))
  have hsum :
      ‖∑ x : ZMod N, reciprocalPhase N a x‖ ≤ (N : ℝ) := by
    calc
      ‖∑ x : ZMod N, reciprocalPhase N a x‖
          ≤ ∑ x : ZMod N, ‖reciprocalPhase N a x‖ := norm_sum_le _ _
      _ ≤ ∑ _x : ZMod N, (1 : ℝ) := by
        apply Finset.sum_le_sum
        intro x hx
        exact source_norm_reciprocalPhase_le_one N a x
      _ = (N : ℝ) := by
        simp [ZMod.card]
  have hinv : ‖(N : ℂ)⁻¹‖ = (N : ℝ)⁻¹ := by
    rw [norm_inv]
    norm_cast
  rw [hinv]
  calc
    (N : ℝ)⁻¹ * ‖∑ x : ZMod N, reciprocalPhase N a x‖
        ≤ (N : ℝ)⁻¹ * (N : ℝ) := by
          exact mul_le_mul_of_nonneg_left hsum (by positivity)
    _ = 1 := by field_simp [hNpos.ne']

lemma source_norm_centeredReciprocalPhase_le_two
    (N : ℕ) [NeZero N] (a x : ZMod N) :
    ‖centeredReciprocalPhase N a x‖ ≤ 2 := by
  unfold centeredReciprocalPhase
  calc
    ‖reciprocalPhase N a x - reciprocalMean N a‖
        ≤ ‖reciprocalPhase N a x‖ + ‖reciprocalMean N a‖ := norm_sub_le _ _
    _ ≤ 1 + 1 := add_le_add
      (source_norm_reciprocalPhase_le_one N a x)
      (source_norm_reciprocalMean_le_one N a)
    _ = 2 := by norm_num



lemma source_sum_Icc_eq_sum_range_shift
    {M : Type*} [AddCommMonoid M]
    (F : ℕ → M) {A B : ℕ} (hAB : A ≤ B) :
    (∑ n ∈ Finset.Icc A B, F n) =
      ∑ j ∈ Finset.range (B - A + 1), F (A + j) := by
  classical
  apply Finset.sum_bij
    (fun n hn => n - A)
  · intro n hn
    have hnI := Finset.mem_Icc.mp hn
    apply Finset.mem_range.mpr
    omega
  · intro n1 hn1 n2 hn2 heq
    have h1 := (Finset.mem_Icc.mp hn1).1
    have h2 := (Finset.mem_Icc.mp hn2).1
    omega
  · intro j hj
    have hjlt := Finset.mem_range.mp hj
    refine ⟨A + j, ?_, ?_⟩
    · apply Finset.mem_Icc.mpr
      constructor
      · omega
      · omega
    · simp
  · intro n hn
    have hA := (Finset.mem_Icc.mp hn).1
    exact congrArg F (Nat.add_sub_of_le hA).symm

#print axioms source_sum_Icc_eq_sum_range_shift

lemma source_sum_Icc_centered_reciprocal_weight_eq
    {N A B : ℕ} [NeZero N] (a : ZMod N) (hAB : A ≤ B) :
    (∑ ell ∈ Finset.Icc A B,
      centeredReciprocalPhase N a (ell : ZMod N) *
        ((((ell : ℕ) : ℝ)⁻¹ : ℝ) : ℂ)) =
      weightedCenteredIntervalSum N a (A : ZMod N) A (B - A + 1) := by
  rw [source_sum_Icc_eq_sum_range_shift
    (F := fun ell =>
      centeredReciprocalPhase N a (ell : ZMod N) *
        ((((ell : ℕ) : ℝ)⁻¹ : ℝ) : ℂ)) hAB]
  unfold weightedCenteredIntervalSum reciprocalNatWeight
  apply Finset.sum_congr rfl
  intro j hj
  congr 1
  push_cast
  rfl

#print axioms source_norm_centeredReciprocalPhase_le_two
#print axioms source_sum_Icc_centered_reciprocal_weight_eq

lemma source_norm_reciprocalNatWeight
    (Y j : ℕ) :
    ‖reciprocalNatWeight Y j‖ = (((Y + j : ℕ) : ℝ)⁻¹) := by
  unfold reciprocalNatWeight
  rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg]
  positivity

lemma source_norm_weightedCenteredIntervalSum_le
    (N : ℕ) [NeZero N] (a x : ZMod N)
    {Y L : ℕ} (hY : 0 < Y) :
    ‖weightedCenteredIntervalSum N a x Y L‖ ≤
      2 * (L : ℝ) / (Y : ℝ) := by
  unfold weightedCenteredIntervalSum
  calc
    ‖∑ j ∈ Finset.range L,
        centeredReciprocalPhase N a (x + (j : ZMod N)) *
          reciprocalNatWeight Y j‖
      ≤ ∑ j ∈ Finset.range L,
          ‖centeredReciprocalPhase N a (x + (j : ZMod N)) *
            reciprocalNatWeight Y j‖ := norm_sum_le _ _
    _ ≤ ∑ _j ∈ Finset.range L, (2 * (Y : ℝ)⁻¹) := by
      apply Finset.sum_le_sum
      intro j hj
      rw [norm_mul, source_norm_reciprocalNatWeight]
      have hcent :=
        source_norm_centeredReciprocalPhase_le_two
          N a (x + (j : ZMod N))
      have hYj : (Y : ℝ) ≤ (Y + j : ℕ) := by
        exact_mod_cast Nat.le_add_right Y j
      have hinv :
          (((Y + j : ℕ) : ℝ)⁻¹) ≤ (Y : ℝ)⁻¹ := by
        exact inv_anti₀ (by exact_mod_cast hY) hYj
      exact mul_le_mul hcent hinv (by positivity) (by norm_num)
    _ = (L : ℝ) * (2 * (Y : ℝ)⁻¹) := by simp
    _ = 2 * (L : ℝ) / (Y : ℝ) := by
      rw [div_eq_mul_inv]
      ring

lemma source_half_norm_weightedCenteredIntervalSum_le_one
    (N : ℕ) [NeZero N] (a x : ZMod N)
    {Y L : ℕ} (hY : 0 < Y) (hLY : L ≤ Y) :
    ‖weightedCenteredIntervalSum N a x Y L‖ / 2 ≤ 1 := by
  have h :=
    source_norm_weightedCenteredIntervalSum_le
      N a x (Y := Y) (L := L) hY
  have hYR : (0 : ℝ) < Y := by exact_mod_cast hY
  have hLR : (L : ℝ) ≤ Y := by exact_mod_cast hLY
  have hratio : (L : ℝ) / (Y : ℝ) ≤ 1 := by
    exact (div_le_one hYR).2 hLR
  apply (div_le_one (by norm_num : (0 : ℝ) < 2)).2
  calc
    ‖weightedCenteredIntervalSum N a x Y L‖
        ≤ 2 * (L : ℝ) / (Y : ℝ) := h
    _ = 2 * ((L : ℝ) / (Y : ℝ)) := by ring
    _ ≤ 2 * 1 := mul_le_mul_of_nonneg_left hratio (by norm_num)
    _ = 2 := by norm_num

#print axioms source_half_norm_weightedCenteredIntervalSum_le_one

theorem source_half_norm_weightedCenteredCombinedIntervalSum_le
    (hWeil : PrimeNondegenerateWeil)
    {A B : ℤ} {r L Y len : ℕ}
    (hr : 0 < r) (hL : 0 < L)
    (hrsq : Squarefree r) (hLsq : Squarefree L)
    (hcop : r.Coprime L)
    (hY : 0 < Y)
    [NeZero
      (reducedModulus
        (combinedNumeratorInt A B r L).natAbs
        (combinedModulus r L))]
    (x : ZMod
      (reducedModulus
        (combinedNumeratorInt A B r L).natAbs
        (combinedModulus r L))) :
    let Cnat := (combinedNumeratorInt A B r L).natAbs
    let Q := combinedModulus r L
    let rho := reducedModulus Cnat Q
    ‖weightedCenteredIntervalSum
        rho
        (reducedNumerator Cnat Q : ZMod rho)
        x Y len‖ / 2 ≤
      (((2 : ℝ) ^ rho.primeFactors.card * Real.sqrt rho) *
        (1 + Real.log rho)) / Y := by
  dsimp only
  have h :=
    source_weightedCenteredCombinedIntervalSum_le
      (Y := Y) (len := len)
      hWeil hr hL hrsq hLsq hcop hY x
  dsimp only at h
  have h' :
      ‖weightedCenteredIntervalSum
          (reducedModulus
            (combinedNumeratorInt A B r L).natAbs
            (combinedModulus r L))
          (reducedNumerator
            (combinedNumeratorInt A B r L).natAbs
            (combinedModulus r L) :
              ZMod
                (reducedModulus
                  (combinedNumeratorInt A B r L).natAbs
                  (combinedModulus r L)))
          x Y len‖ ≤
        2 * ((((2 : ℝ) ^
            (reducedModulus
              (combinedNumeratorInt A B r L).natAbs
              (combinedModulus r L)).primeFactors.card *
            Real.sqrt
              (reducedModulus
                (combinedNumeratorInt A B r L).natAbs
                (combinedModulus r L))) *
          (1 + Real.log
            (reducedModulus
              (combinedNumeratorInt A B r L).natAbs
              (combinedModulus r L)))) / Y) := by
    convert h using 1 <;> ring
  calc
    ‖weightedCenteredIntervalSum
        (reducedModulus
          (combinedNumeratorInt A B r L).natAbs
          (combinedModulus r L))
        (reducedNumerator
          (combinedNumeratorInt A B r L).natAbs
          (combinedModulus r L) :
            ZMod
              (reducedModulus
                (combinedNumeratorInt A B r L).natAbs
                (combinedModulus r L)))
        x Y len‖ / 2
      ≤ (2 * ((((2 : ℝ) ^
          (reducedModulus
            (combinedNumeratorInt A B r L).natAbs
            (combinedModulus r L)).primeFactors.card *
          Real.sqrt
            (reducedModulus
              (combinedNumeratorInt A B r L).natAbs
              (combinedModulus r L))) *
        (1 + Real.log
          (reducedModulus
            (combinedNumeratorInt A B r L).natAbs
            (combinedModulus r L)))) / Y)) / 2 := by
          exact div_le_div_of_nonneg_right h' (by norm_num)
    _ = (((2 : ℝ) ^
          (reducedModulus
            (combinedNumeratorInt A B r L).natAbs
            (combinedModulus r L)).primeFactors.card *
          Real.sqrt
            (reducedModulus
              (combinedNumeratorInt A B r L).natAbs
              (combinedModulus r L))) *
        (1 + Real.log
          (reducedModulus
            (combinedNumeratorInt A B r L).natAbs
            (combinedModulus r L)))) / Y := by ring

#print axioms source_half_norm_weightedCenteredCombinedIntervalSum_le

theorem source_fixed_dc_weightedCentered_channel_estimate
    (hWeil : PrimeNondegenerateWeil)
    (S : Finset ℕ) (h5 : ∀ p ∈ S, 5 ≤ p)
    {c F M r L : ℕ} {U s0 : ℝ}
    {A B : ℤ}
    (hcpos : 0 < c)
    (hr : 0 < r) (hL : 0 < L)
    (hrsq : Squarefree r) (hLsq : Squarefree L)
    (hcop : r.Coprime L)
    (hU : 0 < U) (hs0 : 0 < s0)
    (hsq :
      s0 ^ 2 =
        U / (((primeSetProduct S : ℕ) : ℝ) * (c : ℝ) *
          (((2 : ℝ) ^
              (reducedModulus
                (combinedNumeratorInt A B r L).natAbs
                (combinedModulus r L)).primeFactors.card *
            Real.sqrt
              (reducedModulus
                (combinedNumeratorInt A B r L).natAbs
                (combinedModulus r L))) *
            (1 + Real.log
              (reducedModulus
                (combinedNumeratorInt A B r L).natAbs
                (combinedModulus r L))))))
    (hsF : s0 ≤ (F : ℝ)) (hF2 : (F : ℝ) ≤ 2 * s0)
    [NeZero
      (reducedModulus
        (combinedNumeratorInt A B r L).natAbs
        (combinedModulus r L))]
    (Y len : ℕ → ℕ)
    (x : ℕ →
      ZMod
        (reducedModulus
          (combinedNumeratorInt A B r L).natAbs
          (combinedModulus r L)))
    (hYsmall : ∀ f ∈ Finset.Icc 1 F, 0 < Y f)
    (hYlarge : ∀ f ∈ Finset.Icc (F + 1) M, 0 < Y f)
    (hscale : ∀ f ∈ Finset.Icc 1 F,
      U ≤ (((primeSetProduct S : ℕ) : ℝ) * (c : ℝ)) *
        (f : ℝ) ^ 2 * (Y f : ℝ))
    (hlen : ∀ f ∈ Finset.Icc (F + 1) M, len f ≤ Y f) :
    (∑ f ∈ Finset.Icc 1 F,
        (sourceGammaFinsetWeight S /
          (((primeSetProduct S : ℕ) : ℝ) * (c : ℝ) * (f : ℝ)^2)) *
          (‖weightedCenteredIntervalSum
              (reducedModulus
                (combinedNumeratorInt A B r L).natAbs
                (combinedModulus r L))
              (reducedNumerator
                (combinedNumeratorInt A B r L).natAbs
                (combinedModulus r L) :
                  ZMod
                    (reducedModulus
                      (combinedNumeratorInt A B r L).natAbs
                      (combinedModulus r L)))
              (x f) (Y f) (len f)‖ / 2)) +
      (∑ f ∈ Finset.Icc (F + 1) M,
        (sourceGammaFinsetWeight S /
          (((primeSetProduct S : ℕ) : ℝ) * (c : ℝ) * (f : ℝ)^2)) *
          (‖weightedCenteredIntervalSum
              (reducedModulus
                (combinedNumeratorInt A B r L).natAbs
                (combinedModulus r L))
              (reducedNumerator
                (combinedNumeratorInt A B r L).natAbs
                (combinedModulus r L) :
                  ZMod
                    (reducedModulus
                      (combinedNumeratorInt A B r L).natAbs
                      (combinedModulus r L)))
              (x f) (Y f) (len f)‖ / 2)) ≤
      (3 *
        Real.sqrt
          ((((2 : ℝ) ^
              (reducedModulus
                (combinedNumeratorInt A B r L).natAbs
                (combinedModulus r L)).primeFactors.card *
            Real.sqrt
              (reducedModulus
                (combinedNumeratorInt A B r L).natAbs
                (combinedModulus r L))) *
            (1 + Real.log
              (reducedModulus
                (combinedNumeratorInt A B r L).natAbs
                (combinedModulus r L))))) *
        (Real.sqrt U)⁻¹) *
        (∏ p ∈ S, gammaPrimeTerm p) * invSqrtNat c := by
  let rho :=
    reducedModulus
      (combinedNumeratorInt A B r L).natAbs
      (combinedModulus r L)
  let C : ℝ :=
    (((2 : ℝ) ^ rho.primeFactors.card * Real.sqrt rho) *
      (1 + Real.log rho))
  let kernel : ℕ → ℝ := fun f =>
    ‖weightedCenteredIntervalSum
        rho
        (reducedNumerator
          (combinedNumeratorInt A B r L).natAbs
          (combinedModulus r L) : ZMod rho)
        (x f) (Y f) (len f)‖ / 2
  let Yr : ℕ → ℝ := fun f => (Y f : ℝ)
  have hrho : 0 < rho := by
    exact Nat.pos_of_ne_zero (NeZero.ne rho)
  have hlog : 0 ≤ Real.log rho := by
    apply Real.log_nonneg
    exact_mod_cast (Nat.one_le_iff_ne_zero.mpr (NeZero.ne rho))
  have hC : 0 < C := by
    dsimp [C]
    have hpow : 0 < (2 : ℝ) ^ rho.primeFactors.card := by positivity
    have hsqrt : 0 < Real.sqrt (rho : ℝ) := Real.sqrt_pos.2 (by exact_mod_cast hrho)
    positivity
  have hYrSmall : ∀ f ∈ Finset.Icc 1 F, 0 < Yr f := by
    intro f hf
    dsimp [Yr]
    exact_mod_cast hYsmall f hf
  have hscale' : ∀ f ∈ Finset.Icc 1 F,
      U ≤ (((primeSetProduct S : ℕ) : ℝ) * (c : ℝ)) *
        (f : ℝ) ^ 2 * Yr f := by
    intro f hf
    simpa [Yr] using hscale f hf
  have hcompletion : ∀ f ∈ Finset.Icc 1 F,
      kernel f ≤ C / Yr f := by
    intro f hf
    dsimp [kernel, C, Yr, rho]
    simpa using
      (source_half_norm_weightedCenteredCombinedIntervalSum_le
        hWeil hr hL hrsq hLsq hcop (hYsmall f hf) (x f))
  have hunit : ∀ f ∈ Finset.Icc (F + 1) M,
      kernel f ≤ 1 := by
    intro f hf
    dsimp [kernel, rho]
    exact source_half_norm_weightedCenteredIntervalSum_le_one
      _ _ (x f) (hYlarge f hf) (hlen f hf)
  have hbase :=
    source_fixed_dc_channel_estimate_from_kernel_bounds
      S h5 hcpos hU hC hs0
      (by simpa [C, rho] using hsq)
      hsF hF2 kernel Yr hYrSmall hscale' hcompletion hunit
  simpa [kernel, Yr, C, rho] using hbase

#print axioms source_fixed_dc_weightedCentered_channel_estimate

lemma source_completion_small_channel_rescale
    {G C U D Y F : ℝ}
    (hG : 0 ≤ G) (hC : 0 ≤ C)
    (hU : 0 < U) (hD : 0 < D) (hY : 0 < Y) (hF : 0 < F)
    (hscale : U ≤ D * F ^ 2 * Y)
    {Z : ℝ} (hZ : Z ≤ C / Y) :
    (G / (D * F ^ 2)) * Z ≤ G * C / U := by
  have hDF : 0 < D * F ^ 2 := by positivity
  have hleft :
      (G / (D * F ^ 2)) * Z ≤
        (G / (D * F ^ 2)) * (C / Y) := by
    exact mul_le_mul_of_nonneg_left hZ (by positivity)
  have hratio :
      (G / (D * F ^ 2)) * (C / Y) =
        G * C / (D * F ^ 2 * Y) := by
    field_simp [hDF.ne', hY.ne']
  have hinv :
      (D * F ^ 2 * Y)⁻¹ ≤ U⁻¹ := by
    simpa [one_div] using
      (one_div_le_one_div_of_le hU hscale)
  calc
    (G / (D * F ^ 2)) * Z
      ≤ (G / (D * F ^ 2)) * (C / Y) := hleft
    _ = G * C / (D * F ^ 2 * Y) := hratio
    _ ≤ G * C / U := by
      simp only [div_eq_mul_inv]
      exact mul_le_mul_of_nonneg_left hinv (mul_nonneg hG hC)

lemma source_completion_large_channel_rescale
    {G D F Z : ℝ}
    (hG : 0 ≤ G) (hD : 0 < D) (hF : 0 < F)
    (hZ : Z ≤ 1) :
    (G / (D * F ^ 2)) * Z ≤
      (G / D) * F⁻¹ ^ 2 := by
  have hcoef : 0 ≤ G / (D * F ^ 2) := by positivity
  calc
    (G / (D * F ^ 2)) * Z
      ≤ (G / (D * F ^ 2)) * 1 :=
        mul_le_mul_of_nonneg_left hZ hcoef
    _ = (G / D) * F⁻¹ ^ 2 := by
      field_simp [hD.ne', hF.ne']

#print axioms source_completion_small_channel_rescale
#print axioms source_completion_large_channel_rescale

lemma omegaCoeff_eq_sourceGamma_divisor_sum_div
    {q m : ℕ}
    (hm0 : m ≠ 0)
    (hsq : Squarefree m)
    (hcop : m.Coprime (6 * q)) :
    omegaCoeff q m =
      (∑ d ∈ m.divisors, sourceGammaNatWeight d) / (m : ℝ) := by
  have h :=
    omegaCoeff_mul_nat_eq_sourceGamma_divisor_sum
      (q := q) (m := m) hm0 hsq hcop
  have hmR : (m : ℝ) ≠ 0 := by exact_mod_cast hm0
  apply (eq_div_iff hmR).2
  simpa [mul_comm] using h

lemma omegaCoeff_complex_eq_sourceGamma_divisor_sum_div
    {q m : ℕ}
    (hm0 : m ≠ 0)
    (hsq : Squarefree m)
    (hcop : m.Coprime (6 * q)) :
    (omegaCoeff q m : ℂ) =
      ((∑ d ∈ m.divisors, sourceGammaNatWeight d) / (m : ℝ) : ℝ) := by
  exact_mod_cast
    omegaCoeff_eq_sourceGamma_divisor_sum_div
      (q := q) (m := m) hm0 hsq hcop

#print axioms omegaCoeff_eq_sourceGamma_divisor_sum_div
#print axioms omegaCoeff_complex_eq_sourceGamma_divisor_sum_div

lemma omegaCoeff_mul_im_eq_sourceGamma_divisor_sum
    {q m : ℕ}
    (hm0 : m ≠ 0)
    (hsq : Squarefree m)
    (hcop : m.Coprime (6 * q))
    (z : ℂ) :
    ((omegaCoeff q m : ℂ) * z).im =
      ∑ d ∈ m.divisors,
        (sourceGammaNatWeight d / (m : ℝ)) * z.im := by
  rw [omegaCoeff_complex_eq_sourceGamma_divisor_sum_div hm0 hsq hcop]
  rw [Complex.im_ofReal_mul]
  rw [Finset.sum_div]
  rw [Finset.sum_mul]

#print axioms omegaCoeff_mul_im_eq_sourceGamma_divisor_sum

lemma omegaCoeff_mul_finset_sum_im_eq_sourceGamma_divisor_sum
    {q m : ℕ}
    (hm0 : m ≠ 0)
    (hsq : Squarefree m)
    (hcop : m.Coprime (6 * q))
    {ι : Type*} (s : Finset ι) (φ : ι → ℂ) :
    ((omegaCoeff q m : ℂ) * ∑ i ∈ s, φ i).im =
      ∑ d ∈ m.divisors,
        ∑ i ∈ s,
          (sourceGammaNatWeight d / (m : ℝ)) * (φ i).im := by
  rw [omegaCoeff_mul_im_eq_sourceGamma_divisor_sum hm0 hsq hcop]
  apply Finset.sum_congr rfl
  intro d hd
  rw [show (∑ i ∈ s, φ i).im = ∑ i ∈ s, (φ i).im by simp]
  rw [Finset.mul_sum]

#print axioms omegaCoeff_mul_finset_sum_im_eq_sourceGamma_divisor_sum

theorem source_weighted_affineVaalerMain_eq_powerset_frequency_sums
    {q m : ℕ}
    (hm0 : m ≠ 0)
    (hsq : Squarefree m)
    (hcop6q : m.Coprime (6 * q))
    [NeZero (primeSetProduct m.primeFactors)]
    (u : (ZMod (primeSetProduct m.primeFactors))ˣ)
    (v : ZMod (primeSetProduct m.primeFactors))
    (r J : ℕ) :
    let hPrime : ∀ p ∈ m.primeFactors, p.Prime :=
      fun p hp => (Nat.mem_primeFactors.mp hp).1
    fixedQShiuWeight q m *
        sourceAffineVaalerMain m.primeFactors hPrime u v r J =
      - ∑ j ∈ Finset.Icc 1 J,
          (h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
            (((omegaCoeff q m : ℂ) *
              ∑ A ∈ m.primeFactors.powerset,
                ZMod.stdAddChar
                  (((j : ZMod (primeSetProduct m.primeFactors)) *
                      (v - (r : ZMod (primeSetProduct m.primeFactors)))) +
                    ((j : ZMod (primeSetProduct m.primeFactors)) *
                      (u : ZMod (primeSetProduct m.primeFactors))) *
                    (fixedProductCRTIdempotentNat m.primeFactors A :
                      ZMod (primeSetProduct m.primeFactors)))).im) +
        ∑ j ∈ Finset.Icc 1 J,
          (h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
            (((omegaCoeff q m : ℂ) *
              ∑ A ∈ m.primeFactors.powerset,
                ZMod.stdAddChar
                  (((j : ZMod (primeSetProduct m.primeFactors)) * v) +
                    ((j : ZMod (primeSetProduct m.primeFactors)) *
                      (u : ZMod (primeSetProduct m.primeFactors))) *
                    (fixedProductCRTIdempotentNat m.primeFactors A :
                      ZMod (primeSetProduct m.primeFactors)))).im) := by
  dsimp only
  let hPrime : ∀ p ∈ m.primeFactors, p.Prime :=
    fun p hp => (Nat.mem_primeFactors.mp hp).1
  rw [sourceAffineVaalerMain_eq_frequency_sums]
  rw [mul_add, mul_neg]
  have hleft :
      ∑ j ∈ Finset.Icc 1 J,
          fixedQShiuWeight q m *
            ((h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
              (ZMod.stdAddChar
                  ((j : ZMod (primeSetProduct m.primeFactors)) *
                    (v - (r : ZMod (primeSetProduct m.primeFactors)))) *
                fixedProductBooleanFourierCoeff m.primeFactors hPrime
                  ((j : ZMod (primeSetProduct m.primeFactors)) *
                    (u : ZMod (primeSetProduct m.primeFactors)))).im) =
        ∑ j ∈ Finset.Icc 1 J,
          (h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
            (((omegaCoeff q m : ℂ) *
              ∑ A ∈ m.primeFactors.powerset,
                ZMod.stdAddChar
                  (((j : ZMod (primeSetProduct m.primeFactors)) *
                      (v - (r : ZMod (primeSetProduct m.primeFactors)))) +
                    ((j : ZMod (primeSetProduct m.primeFactors)) *
                      (u : ZMod (primeSetProduct m.primeFactors))) *
                    (fixedProductCRTIdempotentNat m.primeFactors A :
                      ZMod (primeSetProduct m.primeFactors)))).im) := by
    apply Finset.sum_congr rfl
    intro j hj
    have hmode :=
      source_weighted_fourier_mode_im_eq_powerset
        (q := q) (m := m) hm0 hsq hcop6q
        ((j : ZMod (primeSetProduct m.primeFactors)) *
          (v - (r : ZMod (primeSetProduct m.primeFactors))))
        ((j : ZMod (primeSetProduct m.primeFactors)) *
          (u : ZMod (primeSetProduct m.primeFactors)))
    calc
      fixedQShiuWeight q m *
          ((h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
            (ZMod.stdAddChar
                ((j : ZMod (primeSetProduct m.primeFactors)) *
                  (v - (r : ZMod (primeSetProduct m.primeFactors)))) *
              fixedProductBooleanFourierCoeff m.primeFactors hPrime
                ((j : ZMod (primeSetProduct m.primeFactors)) *
                  (u : ZMod (primeSetProduct m.primeFactors)))).im)
          =
        (h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
          (fixedQShiuWeight q m *
            (ZMod.stdAddChar
                ((j : ZMod (primeSetProduct m.primeFactors)) *
                  (v - (r : ZMod (primeSetProduct m.primeFactors)))) *
              fixedProductBooleanFourierCoeff m.primeFactors hPrime
                ((j : ZMod (primeSetProduct m.primeFactors)) *
                  (u : ZMod (primeSetProduct m.primeFactors)))).im) := by
            ring
      _ = _ := by rw [hmode]
  have hright :
      ∑ j ∈ Finset.Icc 1 J,
          fixedQShiuWeight q m *
            ((h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
              (ZMod.stdAddChar
                  ((j : ZMod (primeSetProduct m.primeFactors)) * v) *
                fixedProductBooleanFourierCoeff m.primeFactors hPrime
                  ((j : ZMod (primeSetProduct m.primeFactors)) *
                    (u : ZMod (primeSetProduct m.primeFactors)))).im) =
        ∑ j ∈ Finset.Icc 1 J,
          (h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
            (((omegaCoeff q m : ℂ) *
              ∑ A ∈ m.primeFactors.powerset,
                ZMod.stdAddChar
                  (((j : ZMod (primeSetProduct m.primeFactors)) * v) +
                    ((j : ZMod (primeSetProduct m.primeFactors)) *
                      (u : ZMod (primeSetProduct m.primeFactors))) *
                    (fixedProductCRTIdempotentNat m.primeFactors A :
                      ZMod (primeSetProduct m.primeFactors)))).im) := by
    apply Finset.sum_congr rfl
    intro j hj
    have hmode :=
      source_weighted_fourier_mode_im_eq_powerset
        (q := q) (m := m) hm0 hsq hcop6q
        ((j : ZMod (primeSetProduct m.primeFactors)) * v)
        ((j : ZMod (primeSetProduct m.primeFactors)) *
          (u : ZMod (primeSetProduct m.primeFactors)))
    calc
      fixedQShiuWeight q m *
          ((h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
            (ZMod.stdAddChar
                ((j : ZMod (primeSetProduct m.primeFactors)) * v) *
              fixedProductBooleanFourierCoeff m.primeFactors hPrime
                ((j : ZMod (primeSetProduct m.primeFactors)) *
                  (u : ZMod (primeSetProduct m.primeFactors)))).im)
          =
        (h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
          (fixedQShiuWeight q m *
            (ZMod.stdAddChar
                ((j : ZMod (primeSetProduct m.primeFactors)) * v) *
              fixedProductBooleanFourierCoeff m.primeFactors hPrime
                ((j : ZMod (primeSetProduct m.primeFactors)) *
                  (u : ZMod (primeSetProduct m.primeFactors)))).im) := by
            ring
      _ = _ := by rw [hmode]
  rw [Finset.mul_sum, Finset.mul_sum]
  rw [hleft, hright]

#print axioms source_periodic_partition_phase_eq_rightBlock
#print axioms source_weighted_fourier_mode_eq_powerset
#print axioms source_weighted_fourier_mode_im_eq_powerset
theorem source_weighted_affineVaalerMain_eq_gamma_powerset_frequency_sums
    {q m : ℕ}
    (hm0 : m ≠ 0)
    (hsq : Squarefree m)
    (hcop6q : m.Coprime (6 * q))
    [NeZero (primeSetProduct m.primeFactors)]
    (u : (ZMod (primeSetProduct m.primeFactors))ˣ)
    (v : ZMod (primeSetProduct m.primeFactors))
    (r J : ℕ) :
    let hPrime : ∀ p ∈ m.primeFactors, p.Prime :=
      fun p hp => (Nat.mem_primeFactors.mp hp).1
    fixedQShiuWeight q m *
        sourceAffineVaalerMain m.primeFactors hPrime u v r J =
      - ∑ j ∈ Finset.Icc 1 J,
          (h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
            (∑ d ∈ m.divisors,
              ∑ A ∈ m.primeFactors.powerset,
                (sourceGammaNatWeight d / (m : ℝ)) *
                  (ZMod.stdAddChar
                    (((j : ZMod (primeSetProduct m.primeFactors)) *
                        (v - (r : ZMod (primeSetProduct m.primeFactors)))) +
                      ((j : ZMod (primeSetProduct m.primeFactors)) *
                        (u : ZMod (primeSetProduct m.primeFactors))) *
                      (fixedProductCRTIdempotentNat m.primeFactors A :
                        ZMod (primeSetProduct m.primeFactors)))).im) +
        ∑ j ∈ Finset.Icc 1 J,
          (h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
            (∑ d ∈ m.divisors,
              ∑ A ∈ m.primeFactors.powerset,
                (sourceGammaNatWeight d / (m : ℝ)) *
                  (ZMod.stdAddChar
                    (((j : ZMod (primeSetProduct m.primeFactors)) * v) +
                      ((j : ZMod (primeSetProduct m.primeFactors)) *
                        (u : ZMod (primeSetProduct m.primeFactors))) *
                      (fixedProductCRTIdempotentNat m.primeFactors A :
                        ZMod (primeSetProduct m.primeFactors)))).im) := by
  dsimp only
  rw [source_weighted_affineVaalerMain_eq_powerset_frequency_sums
    hm0 hsq hcop6q]
  congr 1
  · congr 1
    apply Finset.sum_congr rfl
    intro j hj
    congr 1
    let φ : Finset ℕ → ℂ := fun A =>
      ZMod.stdAddChar
        (((j : ZMod (primeSetProduct m.primeFactors)) *
            (v - (r : ZMod (primeSetProduct m.primeFactors)))) +
          ((j : ZMod (primeSetProduct m.primeFactors)) *
            (u : ZMod (primeSetProduct m.primeFactors))) *
          (fixedProductCRTIdempotentNat m.primeFactors A :
            ZMod (primeSetProduct m.primeFactors)))
    have hgamma :=
      omegaCoeff_mul_finset_sum_im_eq_sourceGamma_divisor_sum
        (q := q) (m := m) hm0 hsq hcop6q
        m.primeFactors.powerset φ
    simpa [φ] using hgamma
  · apply Finset.sum_congr rfl
    intro j hj
    congr 1
    let φ : Finset ℕ → ℂ := fun A =>
      ZMod.stdAddChar
        (((j : ZMod (primeSetProduct m.primeFactors)) * v) +
          ((j : ZMod (primeSetProduct m.primeFactors)) *
            (u : ZMod (primeSetProduct m.primeFactors))) *
          (fixedProductCRTIdempotentNat m.primeFactors A :
            ZMod (primeSetProduct m.primeFactors)))
    have hgamma :=
      omegaCoeff_mul_finset_sum_im_eq_sourceGamma_divisor_sum
        (q := q) (m := m) hm0 hsq hcop6q
        m.primeFactors.powerset φ
    simpa [φ] using hgamma

#print axioms source_weighted_affineVaalerMain_eq_gamma_powerset_frequency_sums

theorem source_periodic_partition_shifted_phase_eq_block_mul
    {q H j : ℕ} {T R : Finset ℕ}
    (hdisj : Disjoint T R)
    (hActive : ∀ p ∈ T ∪ R, activeHighPrime q p)
    (hOrdR : R ∈ ordinaryTwoDimensionalSet H)
    [NeZero (primeSetProduct T)]
    [NeZero (primeSetProduct R)]
    [NeZero (primeSetProduct (T ∪ R))]
    (z : ZMod (primeSetProduct (T ∪ R))) :
    let hPrimeT : ∀ p ∈ T, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_left R hp)).1
    let hPrimeR : ∀ p ∈ R, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_right T hp)).1
    let hPcopR :
        (fixedQPeriod q).Coprime (primeSetProduct R) :=
      (activePrimeSetProduct_coprime_fixedQPeriod
        (fun p hp => hActive p (Finset.mem_union_right T hp))).symm
    let hHcopR :
        H.Coprime (primeSetProduct R) :=
      ((ordinary_primeSetProduct_coprime_height_iff hPrimeR).mp hOrdR).symm
    ZMod.stdAddChar
        (z +
          ((j : ZMod (primeSetProduct (T ∪ R))) *
            (fixedQPeriodicTotalTwist q H (T ∪ R) :
              ZMod (primeSetProduct (T ∪ R)))) *
          (fixedProductCRTIdempotentNat (T ∪ R) T :
            ZMod (primeSetProduct (T ∪ R)))) =
      ZMod.stdAddChar
        (h2BooleanBlockLeftFrequency T R hdisj hPrimeT hPrimeR z) *
      ZMod.stdAddChar
        (h2BooleanBlockRightFrequency T R hdisj hPrimeT hPrimeR z +
          (((j : ZMod (primeSetProduct R)) *
              (fixedProductBooleanPeriodicTwist
                (fixedQPeriod q) H R hPcopR hHcopR :
                  ZMod (primeSetProduct R))) *
            (((ZMod.unitOfCoprime (primeSetProduct T)
              (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR))⁻¹ :
                (ZMod (primeSetProduct R))ˣ) :
                  ZMod (primeSetProduct R)))) := by
  dsimp only
  let hPrimeT : ∀ p ∈ T, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_left R hp)).1
  let hPrimeR : ∀ p ∈ R, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_right T hp)).1
  let hActiveR : ∀ p ∈ R, activeHighPrime q p :=
    fun p hp => hActive p (Finset.mem_union_right T hp)
  let hPcopR : (fixedQPeriod q).Coprime (primeSetProduct R) :=
    (activePrimeSetProduct_coprime_fixedQPeriod hActiveR).symm
  let hHcopR : H.Coprime (primeSetProduct R) :=
    ((ordinary_primeSetProduct_coprime_height_iff hPrimeR).mp hOrdR).symm
  let s : ZMod (primeSetProduct R) :=
    ((j : ZMod (primeSetProduct R)) *
        (fixedProductBooleanPeriodicTwist
          (fixedQPeriod q) H R hPcopR hHcopR :
            ZMod (primeSetProduct R))) *
      (((ZMod.unitOfCoprime (primeSetProduct T)
        (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR))⁻¹ :
          (ZMod (primeSetProduct R))ˣ) :
            ZMod (primeSetProduct R))
  let t : ZMod (primeSetProduct (T ∪ R)) :=
    (j : ZMod (primeSetProduct (T ∪ R))) *
      (fixedQPeriodicTotalTwist q H (T ∪ R) :
        ZMod (primeSetProduct (T ∪ R)))
  let E : ZMod (primeSetProduct (T ∪ R)) :=
    (fixedProductCRTIdempotentNat (T ∪ R) T :
      ZMod (primeSetProduct (T ∪ R)))
  have hzsplit :=
    h2_stdAddChar_eq_block_mul
      T R hdisj hPrimeT hPrimeR z
  have htesplit :
      ZMod.stdAddChar (t * E) = ZMod.stdAddChar s := by
    simpa [t, E, s, hActiveR, hPcopR, hHcopR] using
      (source_periodic_partition_phase_eq_rightBlock
        (q := q) (H := H) (j := j)
        hdisj hActive hOrdR)
  have hcombine :
      ZMod.stdAddChar
          (h2BooleanBlockRightFrequency
            T R hdisj hPrimeT hPrimeR z) *
        ZMod.stdAddChar s =
      ZMod.stdAddChar
        (h2BooleanBlockRightFrequency
            T R hdisj hPrimeT hPrimeR z + s) := by
    rw [AddChar.map_add_eq_mul]
  rw [AddChar.map_add_eq_mul]
  rw [show
      ((j : ZMod (primeSetProduct (T ∪ R))) *
          (fixedQPeriodicTotalTwist q H (T ∪ R) :
            ZMod (primeSetProduct (T ∪ R)))) *
        (fixedProductCRTIdempotentNat (T ∪ R) T :
          ZMod (primeSetProduct (T ∪ R))) = t * E by rfl]
  rw [hzsplit, htesplit]
  calc
    ZMod.stdAddChar
          (h2BooleanBlockLeftFrequency
            T R hdisj hPrimeT hPrimeR z) *
        ZMod.stdAddChar
          (h2BooleanBlockRightFrequency
            T R hdisj hPrimeT hPrimeR z) *
        ZMod.stdAddChar s
      =
        ZMod.stdAddChar
          (h2BooleanBlockLeftFrequency
            T R hdisj hPrimeT hPrimeR z) *
        (ZMod.stdAddChar
          (h2BooleanBlockRightFrequency
            T R hdisj hPrimeT hPrimeR z) *
          ZMod.stdAddChar s) := by ring
    _ =
        ZMod.stdAddChar
          (h2BooleanBlockLeftFrequency
            T R hdisj hPrimeT hPrimeR z) *
        ZMod.stdAddChar
          (h2BooleanBlockRightFrequency
            T R hdisj hPrimeT hPrimeR z + s) := by
          rw [hcombine]
    _ = _ := by rfl

lemma h2BooleanBlockCRTEquiv_snd_eq_castHom
    (T R : Finset ℕ) (hdisj : Disjoint T R)
    (hPrimeT : ∀ p ∈ T, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (z : ZMod (primeSetProduct (T ∪ R))) :
    (h2BooleanBlockCRTEquiv T R hdisj hPrimeT hPrimeR z).2 =
      ZMod.castHom
        (primeSetProduct_dvd_of_subset
          (Finset.subset_union_right : R ⊆ T ∪ R))
        (ZMod (primeSetProduct R)) z := by
  letI : NeZero (primeSetProduct (T ∪ R)) :=
    ⟨(primeSetProduct_pos (by
      intro p hp
      rcases Finset.mem_union.mp hp with hpT | hpR
      · exact hPrimeT p hpT
      · exact hPrimeR p hpR)).ne'⟩
  conv_lhs =>
    rw [← ZMod.natCast_zmod_val z]
  rw [h2BooleanBlockCRTEquiv_apply_natCast]
  change
    ((z.val : ℕ) : ZMod (primeSetProduct R)) =
      ZMod.castHom
        (primeSetProduct_dvd_of_subset
          (Finset.subset_union_right : R ⊆ T ∪ R))
        (ZMod (primeSetProduct R)) z
  rw [ZMod.castHom_apply, ZMod.cast_eq_val]

lemma fixedProductBooleanPeriodicShift_project
    {P : ℕ} {T S : Finset ℕ}
    (hTS : T ⊆ S)
    (hPS : P.Coprime (primeSetProduct S))
    (c : ℕ) :
    ZMod.castHom (primeSetProduct_dvd_of_subset hTS)
        (ZMod (primeSetProduct T))
        (fixedProductBooleanPeriodicShift P S hPS c) =
      fixedProductBooleanPeriodicShift P T
        (hPS.of_dvd_right (primeSetProduct_dvd_of_subset hTS)) c := by
  let hdiv := primeSetProduct_dvd_of_subset hTS
  let hproj :=
    zmodUnitProject_unitOfCoprime hdiv hPS
  unfold fixedProductBooleanPeriodicShift
  change
    ZMod.castHom hdiv (ZMod (primeSetProduct T))
      (-((((ZMod.unitOfCoprime P hPS)⁻¹ :
          (ZMod (primeSetProduct S))ˣ) :
            ZMod (primeSetProduct S))) *
        ((c + 1 : ℕ) : ZMod (primeSetProduct S))) =
      -((((ZMod.unitOfCoprime P
          (hPS.of_dvd_right hdiv))⁻¹ :
          (ZMod (primeSetProduct T))ˣ) :
            ZMod (primeSetProduct T))) *
        ((c + 1 : ℕ) : ZMod (primeSetProduct T))
  rw [map_mul, map_neg]
  have hunit :
      zmodUnitProject hdiv (ZMod.unitOfCoprime P hPS) =
        ZMod.unitOfCoprime P (hPS.of_dvd_right hdiv) :=
    zmodUnitProject_unitOfCoprime hdiv hPS
  have hinvVal :
      ZMod.castHom hdiv (ZMod (primeSetProduct T))
          (((ZMod.unitOfCoprime P hPS)⁻¹ :
            (ZMod (primeSetProduct S))ˣ) :
              ZMod (primeSetProduct S)) =
        ((ZMod.unitOfCoprime P (hPS.of_dvd_right hdiv))⁻¹ :
          (ZMod (primeSetProduct T))ˣ) := by
    change
      (((zmodUnitProject hdiv)
          ((ZMod.unitOfCoprime P hPS)⁻¹) :
            (ZMod (primeSetProduct T))ˣ) :
              ZMod (primeSetProduct T)) =
        (((ZMod.unitOfCoprime P (hPS.of_dvd_right hdiv))⁻¹ :
          (ZMod (primeSetProduct T))ˣ) :
            ZMod (primeSetProduct T))
    rw [map_inv, hunit]
  have hnat :
      ZMod.castHom hdiv (ZMod (primeSetProduct T))
          ((c + 1 : ℕ) : ZMod (primeSetProduct S)) =
        ((c + 1 : ℕ) : ZMod (primeSetProduct T)) := by
    exact map_natCast _ _
  rw [hinvVal, hnat]

lemma h2BooleanBlockRightFrequency_periodicShift
    {P c : ℕ} {T R : Finset ℕ}
    (hdisj : Disjoint T R)
    (hPrimeT : ∀ p ∈ T, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (hP : P.Coprime (primeSetProduct (T ∪ R))) :
    h2BooleanBlockRightFrequency T R hdisj hPrimeT hPrimeR
        (fixedProductBooleanPeriodicShift P (T ∪ R) hP c) =
      (((crtRightCoeff (primeSetProduct T) (primeSetProduct R) : ℤ) :
          ZMod (primeSetProduct R)) *
        fixedProductBooleanPeriodicShift P R
          (hP.of_dvd_right
            (primeSetProduct_dvd_of_subset
              (Finset.subset_union_right : R ⊆ T ∪ R))) c) := by
  unfold h2BooleanBlockRightFrequency
  rw [h2BooleanBlockCRTEquiv_snd_eq_castHom]
  rw [fixedProductBooleanPeriodicShift_project
    (hTS := (Finset.subset_union_right : R ⊆ T ∪ R))]

#print axioms source_weighted_affineVaalerMain_eq_powerset_frequency_sums
#print axioms source_periodic_partition_shifted_phase_eq_block_mul
#print axioms h2BooleanBlockCRTEquiv_snd_eq_castHom
#print axioms fixedProductBooleanPeriodicShift_project
lemma h2BooleanBlockRightFrequency_add
    {T R : Finset ℕ}
    (hdisj : Disjoint T R)
    (hPrimeT : ∀ p ∈ T, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (z w : ZMod (primeSetProduct (T ∪ R))) :
    h2BooleanBlockRightFrequency T R hdisj hPrimeT hPrimeR (z + w) =
      h2BooleanBlockRightFrequency T R hdisj hPrimeT hPrimeR z +
      h2BooleanBlockRightFrequency T R hdisj hPrimeT hPrimeR w := by
  unfold h2BooleanBlockRightFrequency
  rw [map_add]
  simp [mul_add]

lemma h2BooleanBlockRightFrequency_sub
    {T R : Finset ℕ}
    (hdisj : Disjoint T R)
    (hPrimeT : ∀ p ∈ T, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (z w : ZMod (primeSetProduct (T ∪ R))) :
    h2BooleanBlockRightFrequency T R hdisj hPrimeT hPrimeR (z - w) =
      h2BooleanBlockRightFrequency T R hdisj hPrimeT hPrimeR z -
      h2BooleanBlockRightFrequency T R hdisj hPrimeT hPrimeR w := by
  unfold h2BooleanBlockRightFrequency
  rw [map_sub]
  simp [mul_sub]

lemma h2BooleanBlockRightFrequency_natCast
    {T R : Finset ℕ}
    (hdisj : Disjoint T R)
    (hPrimeT : ∀ p ∈ T, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (n : ℕ) :
    h2BooleanBlockRightFrequency T R hdisj hPrimeT hPrimeR
        (n : ZMod (primeSetProduct (T ∪ R))) =
      ((crtRightCoeff (primeSetProduct T) (primeSetProduct R) : ℤ) :
          ZMod (primeSetProduct R)) *
        (n : ZMod (primeSetProduct R)) := by
  unfold h2BooleanBlockRightFrequency
  rw [h2BooleanBlockCRTEquiv_apply_natCast]

lemma h2BooleanBlockRightFrequency_natCast_mul
    {T R : Finset ℕ}
    (hdisj : Disjoint T R)
    (hPrimeT : ∀ p ∈ T, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (n : ℕ) (z : ZMod (primeSetProduct (T ∪ R))) :
    h2BooleanBlockRightFrequency T R hdisj hPrimeT hPrimeR
        ((n : ZMod (primeSetProduct (T ∪ R))) * z) =
      (n : ZMod (primeSetProduct R)) *
        h2BooleanBlockRightFrequency T R hdisj hPrimeT hPrimeR z := by
  unfold h2BooleanBlockRightFrequency
  rw [map_mul, h2BooleanBlockCRTEquiv_apply_natCast]
  simp
  ring

#print axioms h2BooleanBlockRightFrequency_periodicShift
#print axioms h2BooleanBlockRightFrequency_add
#print axioms h2BooleanBlockRightFrequency_sub
#print axioms h2BooleanBlockRightFrequency_natCast
theorem source_periodic_right_phase_shift_eq
    {q H j c : ℕ} {T R : Finset ℕ}
    (hdisj : Disjoint T R)
    (hActive : ∀ p ∈ T ∪ R, activeHighPrime q p)
    (hOrdR : R ∈ ordinaryTwoDimensionalSet H) :
    let hPrimeT : ∀ p ∈ T, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_left R hp)).1
    let hPrimeR : ∀ p ∈ R, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_right T hp)).1
    let hPcopU :
        (fixedQPeriod q).Coprime (primeSetProduct (T ∪ R)) :=
      (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
    let hPcopR :
        (fixedQPeriod q).Coprime (primeSetProduct R) :=
      (activePrimeSetProduct_coprime_fixedQPeriod
        (fun p hp => hActive p (Finset.mem_union_right T hp))).symm
    let hHcopR :
        H.Coprime (primeSetProduct R) :=
      ((ordinary_primeSetProduct_coprime_height_iff hPrimeR).mp hOrdR).symm
    h2BooleanBlockRightFrequency T R hdisj hPrimeT hPrimeR
        ((j : ZMod (primeSetProduct (T ∪ R))) *
          fixedProductBooleanPeriodicShift
            (fixedQPeriod q) (T ∪ R) hPcopU c) +
      (((j : ZMod (primeSetProduct R)) *
          (fixedProductBooleanPeriodicTwist
            (fixedQPeriod q) H R hPcopR hHcopR :
              ZMod (primeSetProduct R))) *
        (((ZMod.unitOfCoprime (primeSetProduct T)
          (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR))⁻¹ :
            (ZMod (primeSetProduct R))ˣ) :
              ZMod (primeSetProduct R))) =
      (j : ZMod (primeSetProduct R)) *
        (((ZMod.unitOfCoprime (fixedQPeriod q) hPcopR)⁻¹ :
          (ZMod (primeSetProduct R))ˣ) :
            ZMod (primeSetProduct R)) *
        (((ZMod.unitOfCoprime (primeSetProduct T)
          (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR))⁻¹ :
            (ZMod (primeSetProduct R))ˣ) :
              ZMod (primeSetProduct R)) *
        ((H : ZMod (primeSetProduct R)) -
          ((c + 1 : ℕ) : ZMod (primeSetProduct R))) := by
  dsimp only
  let hPrimeT : ∀ p ∈ T, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_left R hp)).1
  let hPrimeR : ∀ p ∈ R, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_right T hp)).1
  let hPcopU : (fixedQPeriod q).Coprime (primeSetProduct (T ∪ R)) :=
    (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
  let hActiveR : ∀ p ∈ R, activeHighPrime q p :=
    fun p hp => hActive p (Finset.mem_union_right T hp)
  let hPcopR : (fixedQPeriod q).Coprime (primeSetProduct R) :=
    (activePrimeSetProduct_coprime_fixedQPeriod hActiveR).symm
  let hHcopR : H.Coprime (primeSetProduct R) :=
    ((ordinary_primeSetProduct_coprime_height_iff hPrimeR).mp hOrdR).symm
  let hcopTR :=
    h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR
  letI : NeZero (primeSetProduct R) :=
    ⟨(primeSetProduct_pos hPrimeR).ne'⟩
  rw [h2BooleanBlockRightFrequency_natCast_mul]
  rw [h2BooleanBlockRightFrequency_periodicShift
    hdisj hPrimeT hPrimeR hPcopU]
  rw [h2_crtRightCoeff_eq_unit_inv hcopTR]
  unfold fixedProductBooleanPeriodicShift
  unfold fixedProductBooleanPeriodicTwist
  simp only [Units.val_mul]
  rw [ZMod.coe_unitOfCoprime H hHcopR]
  ring

#print axioms h2BooleanBlockRightFrequency_natCast_mul
theorem source_periodic_right_phase_shift_sub_nat_eq
    {q H j c n : ℕ} {T R : Finset ℕ}
    (hdisj : Disjoint T R)
    (hActive : ∀ p ∈ T ∪ R, activeHighPrime q p)
    (hOrdR : R ∈ ordinaryTwoDimensionalSet H) :
    let hPrimeT : ∀ p ∈ T, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_left R hp)).1
    let hPrimeR : ∀ p ∈ R, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_right T hp)).1
    let hPcopU :
        (fixedQPeriod q).Coprime (primeSetProduct (T ∪ R)) :=
      (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
    let hPcopR :
        (fixedQPeriod q).Coprime (primeSetProduct R) :=
      (activePrimeSetProduct_coprime_fixedQPeriod
        (fun p hp => hActive p (Finset.mem_union_right T hp))).symm
    let hHcopR :
        H.Coprime (primeSetProduct R) :=
      ((ordinary_primeSetProduct_coprime_height_iff hPrimeR).mp hOrdR).symm
    h2BooleanBlockRightFrequency T R hdisj hPrimeT hPrimeR
        ((j : ZMod (primeSetProduct (T ∪ R))) *
          (fixedProductBooleanPeriodicShift
              (fixedQPeriod q) (T ∪ R) hPcopU c -
            (n : ZMod (primeSetProduct (T ∪ R))))) +
      (((j : ZMod (primeSetProduct R)) *
          (fixedProductBooleanPeriodicTwist
            (fixedQPeriod q) H R hPcopR hHcopR :
              ZMod (primeSetProduct R))) *
        (((ZMod.unitOfCoprime (primeSetProduct T)
          (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR))⁻¹ :
            (ZMod (primeSetProduct R))ˣ) :
              ZMod (primeSetProduct R))) =
      (j : ZMod (primeSetProduct R)) *
        (((ZMod.unitOfCoprime (fixedQPeriod q) hPcopR)⁻¹ :
          (ZMod (primeSetProduct R))ˣ) :
            ZMod (primeSetProduct R)) *
        (((ZMod.unitOfCoprime (primeSetProduct T)
          (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR))⁻¹ :
            (ZMod (primeSetProduct R))ˣ) :
              ZMod (primeSetProduct R)) *
        ((H : ZMod (primeSetProduct R)) -
          ((c + 1 : ℕ) : ZMod (primeSetProduct R))) -
      (j : ZMod (primeSetProduct R)) *
        (((ZMod.unitOfCoprime (primeSetProduct T)
          (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR))⁻¹ :
            (ZMod (primeSetProduct R))ˣ) :
              ZMod (primeSetProduct R)) *
        (n : ZMod (primeSetProduct R)) := by
  dsimp only
  let hPrimeT : ∀ p ∈ T, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_left R hp)).1
  let hPrimeR : ∀ p ∈ R, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_right T hp)).1
  let hPcopU : (fixedQPeriod q).Coprime (primeSetProduct (T ∪ R)) :=
    (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
  let hActiveR : ∀ p ∈ R, activeHighPrime q p :=
    fun p hp => hActive p (Finset.mem_union_right T hp)
  let hPcopR : (fixedQPeriod q).Coprime (primeSetProduct R) :=
    (activePrimeSetProduct_coprime_fixedQPeriod hActiveR).symm
  let hHcopR : H.Coprime (primeSetProduct R) :=
    ((ordinary_primeSetProduct_coprime_height_iff hPrimeR).mp hOrdR).symm
  let hcopTR :=
    h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR
  letI : NeZero (primeSetProduct R) :=
    ⟨(primeSetProduct_pos hPrimeR).ne'⟩
  have hbase :=
    source_periodic_right_phase_shift_eq
      (q := q) (H := H) (j := j) (c := c)
      hdisj hActive hOrdR
  rw [h2BooleanBlockRightFrequency_natCast_mul]
  rw [h2BooleanBlockRightFrequency_sub]
  rw [h2BooleanBlockRightFrequency_natCast]
  rw [h2_crtRightCoeff_eq_unit_inv hcopTR]
  dsimp only at hbase
  rw [h2BooleanBlockRightFrequency_natCast_mul] at hbase
  linear_combination hbase

#print axioms source_periodic_right_phase_shift_eq
@[simp] lemma sourceAffineVaalerMain_zero_length
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S)) (J : ℕ) :
    sourceAffineVaalerMain S hPrime u v 0 J = 0 := by
  unfold sourceAffineVaalerMain
  simp only [Nat.cast_zero, sub_zero, sub_self]
  exact calderBooleanRootAverageR_const S 0

noncomputable def periodicResidueDefect (P H c : ℕ) : ℕ :=
  P * periodicResidueLength P H c - ((H - 1) - c)

lemma periodicResidueDefect_lt
    {P H c : ℕ} (hP : 0 < P) :
    periodicResidueDefect P H c < P := by
  let a := (H - 1) - c
  let L := periodicResidueLength P H c
  have hL : L = a ⌈/⌉ P := by rfl
  have hle : a ≤ P * L := by
    rw [hL]
    exact (ceilDiv_le_iff_le_mul hP).1 le_rfl
  by_cases hL0 : L = 0
  · have haLe0 : a ≤ 0 := by
      simpa [hL0] using hle
    have ha0 : a = 0 := Nat.eq_zero_of_le_zero haLe0
    simp [periodicResidueDefect, a, L, hL0, ha0, hP]
  · have hLpos : 0 < L := Nat.pos_of_ne_zero hL0
    have hprevLtL : L - 1 < L := by omega
    have hprevCeil : L - 1 < a ⌈/⌉ P := by simpa [hL] using hprevLtL
    have hprev : P * (L - 1) < a :=
      (nat_lt_ceilDiv_iff_mul_lt hP).1 hprevCeil
    have hLdecomp : L = (L - 1) + 1 := by omega
    have hmul : P * L = P * (L - 1) + P := by
      rw [hLdecomp, Nat.mul_add]
      simp
    unfold periodicResidueDefect
    change P * L - a < P
    omega

lemma zmod_natCast_mod_of_modulus_dvd
    {R M n : ℕ} [NeZero R]
    (hRM : R ∣ M) :
    ((n % M : ℕ) : ZMod R) = (n : ZMod R) := by
  apply (ZMod.natCast_eq_natCast_iff _ _ R).2
  exact (Nat.mod_modEq n M).of_dvd hRM

lemma periodicResidueLength_pos_implies_add_one_le
    {P H c : ℕ}
    (hL : 0 < periodicResidueLength P H c) :
    c + 1 ≤ H := by
  by_contra hnot
  have ha0 : (H - 1) - c = 0 := by omega
  unfold periodicResidueLength at hL
  rw [ha0, zero_ceilDiv] at hL
  omega

lemma periodicResidue_inverse_phase_eq_neg_defect
    {P H c R : ℕ} [NeZero R]
    (hP : 0 < P)
    (hPcop : P.Coprime R)
    (hL : 0 < periodicResidueLength P H c) :
    (((ZMod.unitOfCoprime P hPcop)⁻¹ : (ZMod R)ˣ) : ZMod R) *
          ((H : ZMod R) - ((c + 1 : ℕ) : ZMod R)) -
        (periodicResidueLength P H c : ZMod R) =
      -((((ZMod.unitOfCoprime P hPcop)⁻¹ : (ZMod R)ˣ) : ZMod R) *
        (periodicResidueDefect P H c : ZMod R)) := by
  let L := periodicResidueLength P H c
  let a := (H - 1) - c
  let d := periodicResidueDefect P H c
  have hcH : c + 1 ≤ H :=
    periodicResidueLength_pos_implies_add_one_le hL
  have haEq : H - (c + 1) = a := by
    dsimp [a]
    omega
  have hle : a ≤ P * L := by
    dsimp [a, L, periodicResidueLength]
    exact (ceilDiv_le_iff_le_mul hP).1 le_rfl
  have hdadd : d + a = P * L := by
    dsimp [d, periodicResidueDefect]
    exact Nat.sub_add_cancel hle
  have hdcast := congrArg (fun n : ℕ => (n : ZMod R)) hdadd
  have hPinv :
      ((((ZMod.unitOfCoprime P hPcop)⁻¹ : (ZMod R)ˣ) : ZMod R) *
        (P : ZMod R)) = 1 := by
    rw [← ZMod.coe_unitOfCoprime P hPcop]
    simp
  push_cast at hdcast
  rw [← haEq] at hdcast
  have hsubcast :
      ((H - (c + 1) : ℕ) : ZMod R) =
        (H : ZMod R) - ((c + 1 : ℕ) : ZMod R) := by
    exact Nat.cast_sub hcH
  rw [hsubcast] at hdcast
  have hPL :
      ((((ZMod.unitOfCoprime P hPcop)⁻¹ : (ZMod R)ˣ) : ZMod R) *
          ((P : ZMod R) * (L : ZMod R))) =
        (L : ZMod R) := by
    rw [← mul_assoc, hPinv, one_mul]
  calc
    (((ZMod.unitOfCoprime P hPcop)⁻¹ : (ZMod R)ˣ) : ZMod R) *
          ((H : ZMod R) - ((c + 1 : ℕ) : ZMod R)) -
        (periodicResidueLength P H c : ZMod R)
        =
      (((ZMod.unitOfCoprime P hPcop)⁻¹ : (ZMod R)ˣ) : ZMod R) *
          ((H : ZMod R) - ((c + 1 : ℕ) : ZMod R)) -
        (((ZMod.unitOfCoprime P hPcop)⁻¹ : (ZMod R)ˣ) : ZMod R) *
          ((P : ZMod R) * (L : ZMod R)) := by
            rw [hPL]
    _ =
      (((ZMod.unitOfCoprime P hPcop)⁻¹ : (ZMod R)ˣ) : ZMod R) *
          ((H : ZMod R) - ((c + 1 : ℕ) : ZMod R)) -
        (((ZMod.unitOfCoprime P hPcop)⁻¹ : (ZMod R)ˣ) : ZMod R) *
          ((d : ZMod R) +
            ((H : ZMod R) - ((c + 1 : ℕ) : ZMod R))) := by
              rw [hdcast]
    _ = -((((ZMod.unitOfCoprime P hPcop)⁻¹ : (ZMod R)ˣ) : ZMod R) *
        (periodicResidueDefect P H c : ZMod R)) := by
          dsimp [d]
          ring

#print axioms source_periodic_right_phase_shift_sub_nat_eq
#print axioms periodicResidueDefect_lt
#print axioms zmod_natCast_mod_of_modulus_dvd
#print axioms periodicResidueLength_pos_implies_add_one_le
theorem source_periodic_right_phase_actual_remainder_eq_neg_defect
    {q H j c : ℕ} {T R : Finset ℕ}
    (hq : 0 < q)
    (hdisj : Disjoint T R)
    (hActive : ∀ p ∈ T ∪ R, activeHighPrime q p)
    (hOrdR : R ∈ ordinaryTwoDimensionalSet H)
    (hL : 0 < periodicResidueLength (fixedQPeriod q) H c) :
    let hPrimeT : ∀ p ∈ T, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_left R hp)).1
    let hPrimeR : ∀ p ∈ R, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_right T hp)).1
    let hPcopU :
        (fixedQPeriod q).Coprime (primeSetProduct (T ∪ R)) :=
      (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
    let hPcopR :
        (fixedQPeriod q).Coprime (primeSetProduct R) :=
      (activePrimeSetProduct_coprime_fixedQPeriod
        (fun p hp => hActive p (Finset.mem_union_right T hp))).symm
    let hHcopR :
        H.Coprime (primeSetProduct R) :=
      ((ordinary_primeSetProduct_coprime_height_iff hPrimeR).mp hOrdR).symm
    h2BooleanBlockRightFrequency T R hdisj hPrimeT hPrimeR
        ((j : ZMod (primeSetProduct (T ∪ R))) *
          (fixedProductBooleanPeriodicShift
              (fixedQPeriod q) (T ∪ R) hPcopU c -
            ((periodicResidueLength (fixedQPeriod q) H c %
                primeSetProduct (T ∪ R)) :
              ZMod (primeSetProduct (T ∪ R))))) +
      (((j : ZMod (primeSetProduct R)) *
          (fixedProductBooleanPeriodicTwist
            (fixedQPeriod q) H R hPcopR hHcopR :
              ZMod (primeSetProduct R))) *
        (((ZMod.unitOfCoprime (primeSetProduct T)
          (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR))⁻¹ :
            (ZMod (primeSetProduct R))ˣ) :
              ZMod (primeSetProduct R))) =
      -((j : ZMod (primeSetProduct R)) *
        (((ZMod.unitOfCoprime (primeSetProduct T)
          (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR))⁻¹ :
            (ZMod (primeSetProduct R))ˣ) :
              ZMod (primeSetProduct R)) *
        (((ZMod.unitOfCoprime (fixedQPeriod q) hPcopR)⁻¹ :
            (ZMod (primeSetProduct R))ˣ) :
              ZMod (primeSetProduct R)) *
        (periodicResidueDefect (fixedQPeriod q) H c :
          ZMod (primeSetProduct R))) := by
  dsimp only
  let hPrimeT : ∀ p ∈ T, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_left R hp)).1
  let hPrimeR : ∀ p ∈ R, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_right T hp)).1
  let hPcopU : (fixedQPeriod q).Coprime (primeSetProduct (T ∪ R)) :=
    (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
  let hActiveR : ∀ p ∈ R, activeHighPrime q p :=
    fun p hp => hActive p (Finset.mem_union_right T hp)
  let hPcopR : (fixedQPeriod q).Coprime (primeSetProduct R) :=
    (activePrimeSetProduct_coprime_fixedQPeriod hActiveR).symm
  let hHcopR : H.Coprime (primeSetProduct R) :=
    ((ordinary_primeSetProduct_coprime_height_iff hPrimeR).mp hOrdR).symm
  let hcopTR :=
    h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR
  let L := periodicResidueLength (fixedQPeriod q) H c
  let M := primeSetProduct (T ∪ R)
  letI : NeZero (primeSetProduct R) :=
    ⟨(primeSetProduct_pos hPrimeR).ne'⟩
  have hraw :=
    source_periodic_right_phase_shift_sub_nat_eq
      (q := q) (H := H) (j := j) (c := c)
      (n := L % M) hdisj hActive hOrdR
  dsimp only at hraw
  have hRM : primeSetProduct R ∣ M := by
    dsimp [M]
    exact primeSetProduct_dvd_of_subset
      (Finset.subset_union_right : R ⊆ T ∪ R)
  have hmod :
      ((L % M : ℕ) : ZMod (primeSetProduct R)) =
        (L : ZMod (primeSetProduct R)) :=
    zmod_natCast_mod_of_modulus_dvd hRM
  rw [hmod] at hraw
  have hphase :=
    periodicResidue_inverse_phase_eq_neg_defect
      (P := fixedQPeriod q) (H := H) (c := c)
      (R := primeSetProduct R)
      (fixedQPeriod_pos q hq) hPcopR hL
  calc
    h2BooleanBlockRightFrequency T R hdisj hPrimeT hPrimeR
          ((j : ZMod (primeSetProduct (T ∪ R))) *
            (fixedProductBooleanPeriodicShift
                (fixedQPeriod q) (T ∪ R) hPcopU c -
              ((periodicResidueLength (fixedQPeriod q) H c %
                  primeSetProduct (T ∪ R)) :
                ZMod (primeSetProduct (T ∪ R))))) +
        (((j : ZMod (primeSetProduct R)) *
            (fixedProductBooleanPeriodicTwist
              (fixedQPeriod q) H R hPcopR hHcopR :
                ZMod (primeSetProduct R))) *
          (((ZMod.unitOfCoprime (primeSetProduct T) hcopTR)⁻¹ :
              (ZMod (primeSetProduct R))ˣ) :
                ZMod (primeSetProduct R)))
        =
      (j : ZMod (primeSetProduct R)) *
          (((ZMod.unitOfCoprime (fixedQPeriod q) hPcopR)⁻¹ :
              (ZMod (primeSetProduct R))ˣ) :
                ZMod (primeSetProduct R)) *
          (((ZMod.unitOfCoprime (primeSetProduct T) hcopTR)⁻¹ :
              (ZMod (primeSetProduct R))ˣ) :
                ZMod (primeSetProduct R)) *
          ((H : ZMod (primeSetProduct R)) -
            ((c + 1 : ℕ) : ZMod (primeSetProduct R))) -
        (j : ZMod (primeSetProduct R)) *
          (((ZMod.unitOfCoprime (primeSetProduct T) hcopTR)⁻¹ :
              (ZMod (primeSetProduct R))ˣ) :
                ZMod (primeSetProduct R)) *
          (L : ZMod (primeSetProduct R)) := by
            simpa [L, M] using hraw
    _ =
      (j : ZMod (primeSetProduct R)) *
        (((ZMod.unitOfCoprime (primeSetProduct T) hcopTR)⁻¹ :
            (ZMod (primeSetProduct R))ˣ) :
              ZMod (primeSetProduct R)) *
        ((((ZMod.unitOfCoprime (fixedQPeriod q) hPcopR)⁻¹ :
            (ZMod (primeSetProduct R))ˣ) :
              ZMod (primeSetProduct R)) *
            ((H : ZMod (primeSetProduct R)) -
              ((c + 1 : ℕ) : ZMod (primeSetProduct R))) -
          (L : ZMod (primeSetProduct R))) := by
            ring
    _ = _ := by
      rw [hphase]
      ring

lemma ordinaryTwoDimensionalSet_sdiff
    {H : ℕ} {S A : Finset ℕ}
    (hOrd : S ∈ ordinaryTwoDimensionalSet H)
    (hA : A ⊆ S)
    (hPrimeS : ∀ p ∈ S, p.Prime) :
    S \ A ∈ ordinaryTwoDimensionalSet H := by
  let R := S \ A
  have hPrimeR : ∀ p ∈ R, p.Prime := by
    intro p hp
    exact hPrimeS p (Finset.mem_sdiff.mp hp).1
  rw [ordinary_primeSetProduct_coprime_height_iff hPrimeR]
  have hcopS :=
    (ordinary_primeSetProduct_coprime_height_iff hPrimeS).mp hOrd
  exact Nat.Coprime.of_dvd_left
    (primeSetProduct_dvd_of_subset (Finset.sdiff_subset : R ⊆ S))
    hcopS

lemma h2BooleanBlockCRTEquiv_fst_eq_castHom
    (T R : Finset ℕ) (hdisj : Disjoint T R)
    (hPrimeT : ∀ p ∈ T, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (z : ZMod (primeSetProduct (T ∪ R))) :
    (h2BooleanBlockCRTEquiv T R hdisj hPrimeT hPrimeR z).1 =
      ZMod.castHom
        (primeSetProduct_dvd_of_subset
          (Finset.subset_union_left : T ⊆ T ∪ R))
        (ZMod (primeSetProduct T)) z := by
  letI : NeZero (primeSetProduct (T ∪ R)) :=
    ⟨(primeSetProduct_pos (by
      intro p hp
      rcases Finset.mem_union.mp hp with hpT | hpR
      · exact hPrimeT p hpT
      · exact hPrimeR p hpR)).ne'⟩
  conv_lhs =>
    rw [← ZMod.natCast_zmod_val z]
  rw [h2BooleanBlockCRTEquiv_apply_natCast]
  change
    ((z.val : ℕ) : ZMod (primeSetProduct T)) =
      ZMod.castHom
        (primeSetProduct_dvd_of_subset
          (Finset.subset_union_left : T ⊆ T ∪ R))
        (ZMod (primeSetProduct T)) z
  rw [ZMod.castHom_apply, ZMod.cast_eq_val]

lemma h2BooleanBlockLeftFrequency_natCast_mul
    {T R : Finset ℕ}
    (hdisj : Disjoint T R)
    (hPrimeT : ∀ p ∈ T, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (n : ℕ) (z : ZMod (primeSetProduct (T ∪ R))) :
    h2BooleanBlockLeftFrequency T R hdisj hPrimeT hPrimeR
        ((n : ZMod (primeSetProduct (T ∪ R))) * z) =
      (n : ZMod (primeSetProduct T)) *
        h2BooleanBlockLeftFrequency T R hdisj hPrimeT hPrimeR z := by
  unfold h2BooleanBlockLeftFrequency
  rw [map_mul, h2BooleanBlockCRTEquiv_apply_natCast]
  simp
  ring

lemma h2BooleanBlockLeftFrequency_periodicShift
    {P c : ℕ} {T R : Finset ℕ}
    (hdisj : Disjoint T R)
    (hPrimeT : ∀ p ∈ T, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (hP : P.Coprime (primeSetProduct (T ∪ R))) :
    h2BooleanBlockLeftFrequency T R hdisj hPrimeT hPrimeR
        (fixedProductBooleanPeriodicShift P (T ∪ R) hP c) =
      (((crtLeftCoeff (primeSetProduct T) (primeSetProduct R) : ℤ) :
          ZMod (primeSetProduct T)) *
        fixedProductBooleanPeriodicShift P T
          (hP.of_dvd_right
            (primeSetProduct_dvd_of_subset
              (Finset.subset_union_left : T ⊆ T ∪ R))) c) := by
  unfold h2BooleanBlockLeftFrequency
  rw [h2BooleanBlockCRTEquiv_fst_eq_castHom]
  rw [fixedProductBooleanPeriodicShift_project
    (hTS := (Finset.subset_union_left : T ⊆ T ∪ R))]

lemma h2BooleanBlockLeftFrequency_sub
    {T R : Finset ℕ}
    (hdisj : Disjoint T R)
    (hPrimeT : ∀ p ∈ T, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (z w : ZMod (primeSetProduct (T ∪ R))) :
    h2BooleanBlockLeftFrequency T R hdisj hPrimeT hPrimeR (z - w) =
      h2BooleanBlockLeftFrequency T R hdisj hPrimeT hPrimeR z -
      h2BooleanBlockLeftFrequency T R hdisj hPrimeT hPrimeR w := by
  unfold h2BooleanBlockLeftFrequency
  rw [map_sub]
  simp [mul_sub]

theorem source_periodic_left_phase_shift_eq
    {q j c : ℕ} {T R : Finset ℕ}
    (hdisj : Disjoint T R)
    (hActive : ∀ p ∈ T ∪ R, activeHighPrime q p) :
    let hPrimeT : ∀ p ∈ T, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_left R hp)).1
    let hPrimeR : ∀ p ∈ R, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_right T hp)).1
    let hPcopU :
        (fixedQPeriod q).Coprime (primeSetProduct (T ∪ R)) :=
      (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
    let hPcopT :
        (fixedQPeriod q).Coprime (primeSetProduct T) :=
      hPcopU.of_dvd_right
        (primeSetProduct_dvd_of_subset
          (Finset.subset_union_left : T ⊆ T ∪ R))
    h2BooleanBlockLeftFrequency T R hdisj hPrimeT hPrimeR
        ((j : ZMod (primeSetProduct (T ∪ R))) *
          fixedProductBooleanPeriodicShift
            (fixedQPeriod q) (T ∪ R) hPcopU c) =
      -((j : ZMod (primeSetProduct T)) *
        (((ZMod.unitOfCoprime (primeSetProduct R)
          (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR).symm)⁻¹ :
            (ZMod (primeSetProduct T))ˣ) :
              ZMod (primeSetProduct T)) *
        (((ZMod.unitOfCoprime (fixedQPeriod q) hPcopT)⁻¹ :
            (ZMod (primeSetProduct T))ˣ) :
              ZMod (primeSetProduct T)) *
        ((c + 1 : ℕ) : ZMod (primeSetProduct T))) := by
  dsimp only
  let hPrimeT : ∀ p ∈ T, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_left R hp)).1
  let hPrimeR : ∀ p ∈ R, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_right T hp)).1
  let hPcopU : (fixedQPeriod q).Coprime (primeSetProduct (T ∪ R)) :=
    (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
  let hPcopT : (fixedQPeriod q).Coprime (primeSetProduct T) :=
    hPcopU.of_dvd_right
      (primeSetProduct_dvd_of_subset
        (Finset.subset_union_left : T ⊆ T ∪ R))
  let hcopTR :=
    h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR
  letI : NeZero (primeSetProduct T) :=
    ⟨(primeSetProduct_pos hPrimeT).ne'⟩
  rw [h2BooleanBlockLeftFrequency_natCast_mul]
  rw [h2BooleanBlockLeftFrequency_periodicShift
    hdisj hPrimeT hPrimeR hPcopU]
  rw [h2_crtLeftCoeff_eq_unit_inv hcopTR]
  unfold fixedProductBooleanPeriodicShift
  ring

theorem source_periodic_left_phase_actual_remainder_eq
    {q H j c : ℕ} {T R : Finset ℕ}
    (hdisj : Disjoint T R)
    (hActive : ∀ p ∈ T ∪ R, activeHighPrime q p) :
    let hPrimeT : ∀ p ∈ T, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_left R hp)).1
    let hPrimeR : ∀ p ∈ R, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_right T hp)).1
    let hPcopU :
        (fixedQPeriod q).Coprime (primeSetProduct (T ∪ R)) :=
      (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
    let hPcopT :
        (fixedQPeriod q).Coprime (primeSetProduct T) :=
      hPcopU.of_dvd_right
        (primeSetProduct_dvd_of_subset
          (Finset.subset_union_left : T ⊆ T ∪ R))
    let L := periodicResidueLength (fixedQPeriod q) H c
    h2BooleanBlockLeftFrequency T R hdisj hPrimeT hPrimeR
        ((j : ZMod (primeSetProduct (T ∪ R))) *
          (fixedProductBooleanPeriodicShift
              (fixedQPeriod q) (T ∪ R) hPcopU c -
            ((L % primeSetProduct (T ∪ R)) :
              ZMod (primeSetProduct (T ∪ R))))) =
      -((j : ZMod (primeSetProduct T)) *
        (((ZMod.unitOfCoprime (primeSetProduct R)
          (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR).symm)⁻¹ :
            (ZMod (primeSetProduct T))ˣ) :
              ZMod (primeSetProduct T)) *
        ((((ZMod.unitOfCoprime (fixedQPeriod q) hPcopT)⁻¹ :
            (ZMod (primeSetProduct T))ˣ) :
              ZMod (primeSetProduct T)) *
            ((c + 1 : ℕ) : ZMod (primeSetProduct T)) +
          (L : ZMod (primeSetProduct T)))) := by
  dsimp only
  let hPrimeT : ∀ p ∈ T, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_left R hp)).1
  let hPrimeR : ∀ p ∈ R, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_right T hp)).1
  let hPcopU : (fixedQPeriod q).Coprime (primeSetProduct (T ∪ R)) :=
    (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
  let hPcopT : (fixedQPeriod q).Coprime (primeSetProduct T) :=
    hPcopU.of_dvd_right
      (primeSetProduct_dvd_of_subset
        (Finset.subset_union_left : T ⊆ T ∪ R))
  let hcopTR :=
    h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR
  let L := periodicResidueLength (fixedQPeriod q) H c
  let M := primeSetProduct (T ∪ R)
  letI : NeZero (primeSetProduct T) :=
    ⟨(primeSetProduct_pos hPrimeT).ne'⟩
  have hbase :=
    source_periodic_left_phase_shift_eq
      (q := q) (j := j) (c := c)
      (T := T) (R := R) hdisj hActive
  dsimp only at hbase
  rw [h2BooleanBlockLeftFrequency_natCast_mul] at hbase
  rw [h2BooleanBlockLeftFrequency_natCast_mul]
  rw [h2BooleanBlockLeftFrequency_sub]
  rw [h2BooleanBlockLeftFrequency_natCast]
  rw [h2_crtLeftCoeff_eq_unit_inv hcopTR]
  have hTM : primeSetProduct T ∣ M := by
    dsimp [M]
    exact primeSetProduct_dvd_of_subset
      (Finset.subset_union_left : T ⊆ T ∪ R)
  have hmod :
      ((L % M : ℕ) : ZMod (primeSetProduct T)) =
        (L : ZMod (primeSetProduct T)) :=
    zmod_natCast_mod_of_modulus_dvd hTM
  rw [hmod]
  linear_combination hbase

theorem source_periodic_partition_actual_remainder_phase_eq_left_mul_defect
    {q H j c : ℕ} {T R : Finset ℕ}
    [NeZero (primeSetProduct T)]
    [NeZero (primeSetProduct R)]
    [NeZero (primeSetProduct (T ∪ R))]
    (hq : 0 < q)
    (hdisj : Disjoint T R)
    (hActive : ∀ p ∈ T ∪ R, activeHighPrime q p)
    (hOrdU : T ∪ R ∈ ordinaryTwoDimensionalSet H)
    (hOrdR : R ∈ ordinaryTwoDimensionalSet H)
    (hL : 0 < periodicResidueLength (fixedQPeriod q) H c) :
    let hPrimeT : ∀ p ∈ T, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_left R hp)).1
    let hPrimeR : ∀ p ∈ R, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_right T hp)).1
    let hPcopU :
        (fixedQPeriod q).Coprime (primeSetProduct (T ∪ R)) :=
      (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
    let hPcopR :
        (fixedQPeriod q).Coprime (primeSetProduct R) :=
      (activePrimeSetProduct_coprime_fixedQPeriod
        (fun p hp => hActive p (Finset.mem_union_right T hp))).symm
    let hHcopU :
        H.Coprime (primeSetProduct (T ∪ R)) :=
      ((ordinary_primeSetProduct_coprime_height_iff
        (fun p hp => (hActive p hp).1)).mp hOrdU).symm
    let u :=
      fixedProductBooleanPeriodicTwist
        (fixedQPeriod q) H (T ∪ R) hPcopU hHcopU
    let v :=
      fixedProductBooleanPeriodicShift
        (fixedQPeriod q) (T ∪ R) hPcopU c
    let r :=
      periodicResidueLength (fixedQPeriod q) H c %
        primeSetProduct (T ∪ R)
    ZMod.stdAddChar
        (((j : ZMod (primeSetProduct (T ∪ R))) *
            (v - (r : ZMod (primeSetProduct (T ∪ R))))) +
          ((j : ZMod (primeSetProduct (T ∪ R))) *
            (u : ZMod (primeSetProduct (T ∪ R)))) *
          (fixedProductCRTIdempotentNat (T ∪ R) T :
            ZMod (primeSetProduct (T ∪ R)))) =
      ZMod.stdAddChar
        (h2BooleanBlockLeftFrequency
          T R hdisj hPrimeT hPrimeR
          ((j : ZMod (primeSetProduct (T ∪ R))) *
            (v - (r : ZMod (primeSetProduct (T ∪ R)))))) *
      ZMod.stdAddChar
        (-((j : ZMod (primeSetProduct R)) *
          (((ZMod.unitOfCoprime (primeSetProduct T)
            (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR))⁻¹ :
              (ZMod (primeSetProduct R))ˣ) :
                ZMod (primeSetProduct R)) *
          (((ZMod.unitOfCoprime (fixedQPeriod q) hPcopR)⁻¹ :
              (ZMod (primeSetProduct R))ˣ) :
                ZMod (primeSetProduct R)) *
          (periodicResidueDefect (fixedQPeriod q) H c :
            ZMod (primeSetProduct R)))) := by
  dsimp only
  let hPrimeT : ∀ p ∈ T, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_left R hp)).1
  let hPrimeR : ∀ p ∈ R, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_right T hp)).1
  let hPcopU : (fixedQPeriod q).Coprime (primeSetProduct (T ∪ R)) :=
    (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
  let hPcopR : (fixedQPeriod q).Coprime (primeSetProduct R) :=
    (activePrimeSetProduct_coprime_fixedQPeriod
      (fun p hp => hActive p (Finset.mem_union_right T hp))).symm
  let hHcopU : H.Coprime (primeSetProduct (T ∪ R)) :=
    ((ordinary_primeSetProduct_coprime_height_iff
      (fun p hp => (hActive p hp).1)).mp hOrdU).symm
  let u :=
    fixedProductBooleanPeriodicTwist
      (fixedQPeriod q) H (T ∪ R) hPcopU hHcopU
  let v :=
    fixedProductBooleanPeriodicShift
      (fixedQPeriod q) (T ∪ R) hPcopU c
  let r :=
    periodicResidueLength (fixedQPeriod q) H c %
      primeSetProduct (T ∪ R)
  have htwist :
      fixedQPeriodicTotalTwist q H (T ∪ R) =
        fixedProductBooleanPeriodicTwist
          (fixedQPeriod q) H (T ∪ R) hPcopU hHcopU := by
    exact fixedQPeriodicTotalTwist_eq_periodic hActive hOrdU
  have hsplit :=
    source_periodic_partition_shifted_phase_eq_block_mul
      (q := q) (H := H) (j := j)
      (T := T) (R := R)
      hdisj hActive hOrdR
      ((j : ZMod (primeSetProduct (T ∪ R))) *
        (v - (r : ZMod (primeSetProduct (T ∪ R)))))
  have hright :=
    source_periodic_right_phase_actual_remainder_eq_neg_defect
      (q := q) (H := H) (j := j) (c := c)
      (T := T) (R := R)
      hq hdisj hActive hOrdR hL
  dsimp only at hsplit hright
  rw [htwist] at hsplit
  rw [hright] at hsplit
  simpa [u, v, r] using hsplit

theorem source_periodic_partition_unshifted_phase_eq_left_mul_main
    {q H j c : ℕ} {T R : Finset ℕ}
    [NeZero (primeSetProduct T)]
    [NeZero (primeSetProduct R)]
    [NeZero (primeSetProduct (T ∪ R))]
    (hdisj : Disjoint T R)
    (hActive : ∀ p ∈ T ∪ R, activeHighPrime q p)
    (hOrdU : T ∪ R ∈ ordinaryTwoDimensionalSet H)
    (hOrdR : R ∈ ordinaryTwoDimensionalSet H) :
    let hPrimeT : ∀ p ∈ T, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_left R hp)).1
    let hPrimeR : ∀ p ∈ R, p.Prime :=
      fun p hp => (hActive p (Finset.mem_union_right T hp)).1
    let hPcopU :
        (fixedQPeriod q).Coprime (primeSetProduct (T ∪ R)) :=
      (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
    let hPcopR :
        (fixedQPeriod q).Coprime (primeSetProduct R) :=
      (activePrimeSetProduct_coprime_fixedQPeriod
        (fun p hp => hActive p (Finset.mem_union_right T hp))).symm
    let hHcopU :
        H.Coprime (primeSetProduct (T ∪ R)) :=
      ((ordinary_primeSetProduct_coprime_height_iff
        (fun p hp => (hActive p hp).1)).mp hOrdU).symm
    let u :=
      fixedProductBooleanPeriodicTwist
        (fixedQPeriod q) H (T ∪ R) hPcopU hHcopU
    let v :=
      fixedProductBooleanPeriodicShift
        (fixedQPeriod q) (T ∪ R) hPcopU c
    ZMod.stdAddChar
        (((j : ZMod (primeSetProduct (T ∪ R))) * v) +
          ((j : ZMod (primeSetProduct (T ∪ R))) *
            (u : ZMod (primeSetProduct (T ∪ R)))) *
          (fixedProductCRTIdempotentNat (T ∪ R) T :
            ZMod (primeSetProduct (T ∪ R)))) =
      ZMod.stdAddChar
        (h2BooleanBlockLeftFrequency
          T R hdisj hPrimeT hPrimeR
          ((j : ZMod (primeSetProduct (T ∪ R))) * v)) *
      ZMod.stdAddChar
        ((j : ZMod (primeSetProduct R)) *
          (((ZMod.unitOfCoprime (fixedQPeriod q) hPcopR)⁻¹ :
            (ZMod (primeSetProduct R))ˣ) :
              ZMod (primeSetProduct R)) *
          (((ZMod.unitOfCoprime (primeSetProduct T)
            (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR))⁻¹ :
              (ZMod (primeSetProduct R))ˣ) :
                ZMod (primeSetProduct R)) *
          ((H : ZMod (primeSetProduct R)) -
            ((c + 1 : ℕ) : ZMod (primeSetProduct R)))) := by
  dsimp only
  let hPrimeT : ∀ p ∈ T, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_left R hp)).1
  let hPrimeR : ∀ p ∈ R, p.Prime :=
    fun p hp => (hActive p (Finset.mem_union_right T hp)).1
  let hPcopU : (fixedQPeriod q).Coprime (primeSetProduct (T ∪ R)) :=
    (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
  let hPcopR : (fixedQPeriod q).Coprime (primeSetProduct R) :=
    (activePrimeSetProduct_coprime_fixedQPeriod
      (fun p hp => hActive p (Finset.mem_union_right T hp))).symm
  let hHcopU : H.Coprime (primeSetProduct (T ∪ R)) :=
    ((ordinary_primeSetProduct_coprime_height_iff
      (fun p hp => (hActive p hp).1)).mp hOrdU).symm
  let u :=
    fixedProductBooleanPeriodicTwist
      (fixedQPeriod q) H (T ∪ R) hPcopU hHcopU
  let v :=
    fixedProductBooleanPeriodicShift
      (fixedQPeriod q) (T ∪ R) hPcopU c
  have htwist :
      fixedQPeriodicTotalTwist q H (T ∪ R) =
        fixedProductBooleanPeriodicTwist
          (fixedQPeriod q) H (T ∪ R) hPcopU hHcopU := by
    exact fixedQPeriodicTotalTwist_eq_periodic hActive hOrdU
  have hsplit :=
    source_periodic_partition_shifted_phase_eq_block_mul
      (q := q) (H := H) (j := j)
      (T := T) (R := R)
      hdisj hActive hOrdR
      ((j : ZMod (primeSetProduct (T ∪ R))) * v)
  have hright :=
    source_periodic_right_phase_shift_eq
      (q := q) (H := H) (j := j) (c := c)
      (T := T) (R := R)
      hdisj hActive hOrdR
  dsimp only at hsplit hright
  rw [htwist] at hsplit
  rw [hright] at hsplit
  simpa [u, v] using hsplit

lemma reciprocalPhase_natCast_of_coprime
    {N n : ℕ} [NeZero N] (hcop : n.Coprime N)
    (a : ZMod N) :
    reciprocalPhase N a (n : ZMod N) =
      ZMod.stdAddChar
        (a * ((((ZMod.unitOfCoprime n hcop)⁻¹ : (ZMod N)ˣ) :
          ZMod N))) := by
  unfold reciprocalPhase
  have hu : IsUnit ((n : ℕ) : ZMod N) := by
    rw [ZMod.isUnit_iff_coprime]
    exact hcop
  rw [if_pos hu]
  rw [← ZMod.coe_unitOfCoprime n hcop]
  rw [ZMod.inv_coe_unit]

lemma centeredReciprocalPhase_natCast_of_coprime
    {N n : ℕ} [NeZero N] (hcop : n.Coprime N)
    (a : ZMod N) :
    centeredReciprocalPhase N a (n : ZMod N) =
      ZMod.stdAddChar
        (a * ((((ZMod.unitOfCoprime n hcop)⁻¹ : (ZMod N)ˣ) :
          ZMod N))) - reciprocalMean N a := by
  unfold centeredReciprocalPhase
  rw [reciprocalPhase_natCast_of_coprime hcop a]

theorem stdAddChar_reciprocity
    {m P : ℕ} [NeZero m] [NeZero P] [NeZero (m * P)]
    (hcop : m.Coprime P) (t : ℤ) :
    ZMod.stdAddChar
        ((t : ZMod m) *
          (((ZMod.unitOfCoprime P hcop.symm)⁻¹ : (ZMod m)ˣ) : ZMod m)) =
      ZMod.stdAddChar ((t : ℤ) : ZMod (m * P)) *
      ZMod.stdAddChar
        (-((t : ZMod P) *
          (((ZMod.unitOfCoprime m hcop)⁻¹ : (ZMod P)ˣ) : ZMod P))) := by
  have hcrt := stdAddChar_mul_eq_crt hcop t
  have hleftZ := h2_crtLeftCoeff_eq_unit_inv hcop
  have hrightZ := h2_crtRightCoeff_eq_unit_inv hcop
  push_cast at hcrt
  rw [hleftZ, hrightZ] at hcrt
  rw [AddChar.map_neg_eq_inv]
  let lchar :=
    ZMod.stdAddChar
      ((((ZMod.unitOfCoprime P hcop.symm)⁻¹ : (ZMod m)ˣ) : ZMod m) *
        (t : ZMod m))
  let rchar :=
    ZMod.stdAddChar
      ((((ZMod.unitOfCoprime m hcop)⁻¹ : (ZMod P)ˣ) : ZMod P) *
        (t : ZMod P))
  have hright0 : rchar ≠ 0 := by
    dsimp [rchar]
    intro hz
    have hn := norm_stdAddChar_eq_one P
      ((((ZMod.unitOfCoprime m hcop)⁻¹ : (ZMod P)ˣ) : ZMod P) *
        (t : ZMod P))
    rw [hz, norm_zero] at hn
    norm_num at hn
  have hcrt' :
      lchar * rchar = ZMod.stdAddChar ((t : ℤ) : ZMod (m * P)) := by
    simpa [lchar, rchar] using hcrt
  calc
    ZMod.stdAddChar
        ((t : ZMod m) *
          (((ZMod.unitOfCoprime P hcop.symm)⁻¹ : (ZMod m)ˣ) : ZMod m))
        = lchar := by
            dsimp [lchar]
            congr 1
            ring
    _ = (lchar * rchar) * rchar⁻¹ := by
          rw [mul_assoc, mul_inv_cancel₀ hright0, mul_one]
    _ = ZMod.stdAddChar ((t : ℤ) : ZMod (m * P)) * rchar⁻¹ := by
          rw [hcrt']
    _ = ZMod.stdAddChar ((t : ℤ) : ZMod (m * P)) *
        (ZMod.stdAddChar
          ((t : ZMod P) *
            (((ZMod.unitOfCoprime m hcop)⁻¹ : (ZMod P)ˣ) : ZMod P)))⁻¹ := by
          dsimp [rchar]
          congr 2
          congr 1
          ring

theorem reciprocalPhase_mul_eq_combined
    {r L ell : ℕ}
    [NeZero r] [NeZero L] [NeZero (r * L)]
    (hell : ell.Coprime (r * L))
    (A B : ℤ) :
    reciprocalPhase r (A : ZMod r) (ell : ZMod r) *
        reciprocalPhase L (B : ZMod L) (ell : ZMod L) =
      reciprocalPhase (r * L)
        (combinedNumeratorInt A B r L : ZMod (r * L))
        (ell : ZMod (r * L)) := by
  let Q := r * L
  let hR : r ∣ Q := dvd_mul_right r L
  let hL : L ∣ Q := dvd_mul_left L r
  let hEllR : ell.Coprime r := hell.of_dvd_right hR
  let hEllL : ell.Coprime L := hell.of_dvd_right hL
  let U : (ZMod Q)ˣ := ZMod.unitOfCoprime ell hell
  let z : ZMod Q := ((U⁻¹ : (ZMod Q)ˣ) : ZMod Q)
  let t : ℤ := (z.val : ℤ)
  have htQ : (t : ZMod Q) = z := by
    dsimp [t]
    simpa using (ZMod.natCast_zmod_val z).symm
  have hprojR :
      zmodUnitProject hR (U⁻¹) =
        (ZMod.unitOfCoprime ell hEllR)⁻¹ := by
    rw [map_inv]
    exact congrArg Inv.inv (zmodUnitProject_unitOfCoprime hR hell)
  have hprojL :
      zmodUnitProject hL (U⁻¹) =
        (ZMod.unitOfCoprime ell hEllL)⁻¹ := by
    rw [map_inv]
    exact congrArg Inv.inv (zmodUnitProject_unitOfCoprime hL hell)
  have htR :
      (t : ZMod r) =
        (((ZMod.unitOfCoprime ell hEllR)⁻¹ : (ZMod r)ˣ) : ZMod r) := by
    have hzcast :
        ZMod.castHom hR (ZMod r) z =
          (((ZMod.unitOfCoprime ell hEllR)⁻¹ : (ZMod r)ˣ) : ZMod r) := by
      change
        ((zmodUnitProject hR (U⁻¹) : (ZMod r)ˣ) : ZMod r) =
          (((ZMod.unitOfCoprime ell hEllR)⁻¹ : (ZMod r)ˣ) : ZMod r)
      rw [hprojR]
    rw [← htQ] at hzcast
    simpa [Q] using hzcast
  have htL :
      (t : ZMod L) =
        (((ZMod.unitOfCoprime ell hEllL)⁻¹ : (ZMod L)ˣ) : ZMod L) := by
    have hzcast :
        ZMod.castHom hL (ZMod L) z =
          (((ZMod.unitOfCoprime ell hEllL)⁻¹ : (ZMod L)ˣ) : ZMod L) := by
      change
        ((zmodUnitProject hL (U⁻¹) : (ZMod L)ˣ) : ZMod L) =
          (((ZMod.unitOfCoprime ell hEllL)⁻¹ : (ZMod L)ˣ) : ZMod L)
      rw [hprojL]
    rw [← htQ] at hzcast
    simpa [Q] using hzcast
  rw [reciprocalPhase_natCast_of_coprime hEllR]
  rw [reciprocalPhase_natCast_of_coprime hEllL]
  rw [reciprocalPhase_natCast_of_coprime hell]
  rw [← htR, ← htL]
  letI : NeZero (combinedModulus r L) :=
    inferInstanceAs (NeZero (r * L))
  have hcomb :=
    combined_reciprocal_phase_intCast (r := r) (L := L) A B t
  calc
    ZMod.stdAddChar ((A : ZMod r) * (t : ZMod r)) *
        ZMod.stdAddChar ((B : ZMod L) * (t : ZMod L))
        =
      ZMod.stdAddChar (((A * t : ℤ)) : ZMod r) *
        ZMod.stdAddChar (((B * t : ℤ)) : ZMod L) := by
          simp only [Int.cast_mul]
    _ = ZMod.stdAddChar
        ((((combinedNumeratorInt A B r L) * t : ℤ)) :
          ZMod (r * L)) := hcomb
    _ = ZMod.stdAddChar
        ((combinedNumeratorInt A B r L : ZMod (r * L)) *
          (((ZMod.unitOfCoprime ell hell)⁻¹ : (ZMod (r * L))ˣ) :
            ZMod (r * L))) := by
          congr 1
          rw [Int.cast_mul, htQ]

lemma reciprocalPhase_nat_mul_rescale
    {N k : ℕ} [NeZero N] (hk : k.Coprime N)
    (a x : ZMod N) :
    reciprocalPhase N a ((k : ZMod N) * x) =
      reciprocalPhase N
        (a * ((((ZMod.unitOfCoprime k hk)⁻¹ : (ZMod N)ˣ) : ZMod N)))
        x := by
  unfold reciprocalPhase
  have hku : IsUnit ((k : ℕ) : ZMod N) := by
    rw [ZMod.isUnit_iff_coprime]
    exact hk
  by_cases hx : IsUnit x
  · have hkx : IsUnit ((k : ZMod N) * x) := hku.mul hx
    rw [if_pos hkx, if_pos hx]
    rw [← ZMod.coe_unitOfCoprime k hk]
    rw [← hx.unit_spec]
    rw [← Units.val_mul]
    rw [ZMod.inv_coe_unit]
    rw [ZMod.inv_coe_unit]
    simp
    ring
  · have hkx : ¬ IsUnit ((k : ZMod N) * x) := by
      simpa [hku.mul_left_iff] using hx
    rw [if_neg hkx, if_neg hx]

#print axioms reciprocalPhase_nat_mul_rescale

#print axioms reciprocalPhase_natCast_of_coprime
#print axioms centeredReciprocalPhase_natCast_of_coprime
#print axioms stdAddChar_reciprocity
#print axioms reciprocalPhase_mul_eq_combined
#print axioms periodicResidue_inverse_phase_eq_neg_defect
#print axioms source_periodic_right_phase_actual_remainder_eq_neg_defect
#print axioms ordinaryTwoDimensionalSet_sdiff
#print axioms source_periodic_partition_actual_remainder_phase_eq_left_mul_defect
#print axioms source_periodic_partition_unshifted_phase_eq_left_mul_main

end PaperB.FixedQ
