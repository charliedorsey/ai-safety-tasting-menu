import PaperB.FixedQ.PetermannMovingTransfer
import Mathlib.Data.Int.CardIntervalMod
import Mathlib.NumberTheory.DirichletCharacter.Orthogonality
import Mathlib.RingTheory.RootsOfUnity.AlgebraicallyClosed
import Mathlib.Analysis.Complex.Polynomial.Basic

open scoped BigOperators

namespace PaperB.FixedQ

def positiveResidue (L n : ℕ) : ℕ :=
  if n % L = 0 then L else n % L

lemma positiveResidue_mem_Icc
    {L n : ℕ} (hL : 0 < L) :
    positiveResidue L n ∈ Finset.Icc 1 L := by
  by_cases hr : n % L = 0
  · rw [positiveResidue, if_pos hr]
    exact Finset.mem_Icc.mpr ⟨hL, le_rfl⟩
  · have hmodlt : n % L < L := Nat.mod_lt _ hL
    have hpos : 1 ≤ n % L := Nat.one_le_iff_ne_zero.mpr hr
    simp [positiveResidue, hr, hpos, Nat.le_of_lt hmodlt]

lemma positiveResidue_modEq
    {L n : ℕ} (hL : 0 < L) :
    n ≡ positiveResidue L n [MOD L] := by
  by_cases hr : n % L = 0
  · change n % L = (positiveResidue L n) % L
    simp [positiveResidue, hr, hL.ne']
  · change n % L = (positiveResidue L n) % L
    simp [positiveResidue, hr, Nat.mod_eq_of_lt (Nat.mod_lt _ hL)]

lemma periodic_eq_positiveResidue
    {f : ℕ → ℝ} {L n : ℕ}
    (hL : 0 < L) (hn : 1 ≤ n)
    (hper : Function.Periodic f L) :
    f n = f (positiveResidue L n) := by
  let k := n / L
  let rem := n % L
  have hdecomp : n = k * L + rem := by
    dsimp [k, rem]
    simpa [Nat.mul_comm, Nat.add_comm] using (Nat.mod_add_div n L).symm
  have hshift := (hper.nsmul k) rem
  have hmain : f n = f rem := by
    rw [hdecomp]
    simpa [nsmul_eq_mul, Nat.add_comm, Nat.mul_comm] using hshift
  unfold positiveResidue
  change f n = f (if rem = 0 then L else rem)
  by_cases hr : rem = 0
  · rw [if_pos hr, hmain, hr]
    have hp := hper 0
    simpa using hp.symm
  · rw [if_neg hr, hmain]

lemma residueFiber_eq_modEq
    {L Y a n : ℕ} (hL : 0 < L)
    (ha : a ∈ Finset.Icc 1 L)
    (hn : n ∈ Finset.Icc 1 Y) :
    positiveResidue L n = a ↔ n ≡ a [MOD L] := by
  have hn1 := (Finset.mem_Icc.mp hn).1
  have hpa := positiveResidue_modEq (L := L) (n := n) hL
  constructor
  · intro h
    simpa [h] using hpa
  · intro hna
    have hpos := positiveResidue_mem_Icc (n := n) hL
    have hmods : positiveResidue L n ≡ a [MOD L] :=
      hpa.symm.trans hna
    change positiveResidue L n % L = a % L at hmods
    have hprange := Finset.mem_Icc.mp hpos
    have harange := Finset.mem_Icc.mp ha
    by_cases hpL : positiveResidue L n = L
    · by_cases haL : a = L
      · exact hpL.trans haL.symm
      · have halt : a < L := lt_of_le_of_ne harange.2 haL
        rw [hpL, Nat.mod_eq_of_lt halt] at hmods
        simp [hL.ne'] at hmods
        omega
    · have hplt : positiveResidue L n < L :=
        lt_of_le_of_ne hprange.2 hpL
      by_cases haL : a = L
      · rw [haL, Nat.mod_eq_of_lt hplt] at hmods
        simp [hL.ne'] at hmods
        omega
      · have halt : a < L := lt_of_le_of_ne harange.2 haL
        rw [Nat.mod_eq_of_lt hplt, Nat.mod_eq_of_lt halt] at hmods
        exact hmods

lemma periodicPrefix_grouped
    {f : ℕ → ℝ} {L Y : ℕ}
    (hL : 0 < L) (hper : Function.Periodic f L) :
    (∑ n ∈ Finset.Icc 1 Y, f n) =
      ∑ a ∈ Finset.Icc 1 L,
        (((Finset.Icc 1 Y).filter
          (fun n => n ≡ a [MOD L])).card : ℝ) * f a := by
  classical
  have hmaps :
      ∀ n ∈ Finset.Icc 1 Y,
        positiveResidue L n ∈ Finset.Icc 1 L := by
    intro n hn
    exact positiveResidue_mem_Icc (n := n) hL
  have hfiber :=
    Finset.sum_fiberwise_of_maps_to hmaps f
  rw [← hfiber]
  apply Finset.sum_congr rfl
  intro a ha
  rw [Finset.sum_filter]
  calc
    (∑ n ∈ Finset.Icc 1 Y,
      if positiveResidue L n = a then f n else 0)
      = ∑ n ∈ Finset.Icc 1 Y,
          if n ≡ a [MOD L] then f a else 0 := by
          apply Finset.sum_congr rfl
          intro n hn
          have hiff := residueFiber_eq_modEq hL ha hn
          by_cases hp : positiveResidue L n = a
          · have hm : n ≡ a [MOD L] := hiff.mp hp
            simp [hp, hm,
              periodic_eq_positiveResidue hL
                (Finset.mem_Icc.mp hn).1 hper]
          · have hm : ¬ n ≡ a [MOD L] := by
              intro hma
              exact hp (hiff.mpr hma)
            simp [hp, hm]
    _ = (((Finset.Icc 1 Y).filter
          (fun n => n ≡ a [MOD L])).card : ℝ) * f a := by
          rw [← Finset.sum_filter]
          simp

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma residueFiber_card_eq_floor
    {L Y a : ℕ} (hL : 0 < L) (ha1 : 1 ≤ a) (haL : a ≤ L) :
    (((Finset.Icc 1 Y).filter (fun n => n ≡ a [MOD L])).card : ℤ) =
      ⌊(Y : ℝ) / L + 1 - (a : ℝ) / L⌋ := by
  have hset :
      (Finset.Icc 1 Y).filter (fun n => n ≡ a [MOD L]) =
        (Finset.Ioc 0 Y).filter (fun n => n ≡ a [MOD L]) := by
    ext n
    simp
    omega
  rw [hset]
  rw [Nat.Ioc_filter_modEq_card (a := 0) (b := Y) hL a]
  let k := Y / L
  let rem := Y % L
  have hrem : rem < L := by
    dsimp [rem]
    exact Nat.mod_lt _ hL
  have hdecomp : Y = k * L + rem := by
    dsimp [k, rem]
    simpa [Nat.mul_comm, Nat.add_comm] using (Nat.mod_add_div Y L).symm
  have hLQ : (0 : ℚ) < L := by exact_mod_cast hL
  have hLR : (0 : ℝ) < L := by exact_mod_cast hL
  have ha1Q : (1 : ℚ) ≤ a := by exact_mod_cast ha1
  have haLQ : (a : ℚ) ≤ L := by exact_mod_cast haL
  have ha1R : (1 : ℝ) ≤ a := by exact_mod_cast ha1
  have haLR : (a : ℝ) ≤ L := by exact_mod_cast haL
  have hfloor0 :
      ⌊(-(a : ℚ)) / (L : ℚ)⌋ = (-1 : ℤ) := by
    apply Int.floor_eq_iff.mpr
    constructor
    · have hdiv : (a : ℚ) / L ≤ 1 := (div_le_one hLQ).2 haLQ
      have hneg := neg_le_neg hdiv
      simpa [neg_div] using hneg
    · have haQpos : (0 : ℚ) < a := lt_of_lt_of_le zero_lt_one ha1Q
      have hnegnum : (-(a : ℚ)) < 0 := neg_neg_of_pos haQpos
      have : (-(a : ℚ)) / (L : ℚ) < 0 := div_neg_of_neg_of_pos hnegnum hLQ
      simpa using this
  have hxQ :
      ((Y : ℚ) - (a : ℚ)) / (L : ℚ) =
        (k : ℚ) + ((rem : ℚ) - (a : ℚ)) / (L : ℚ) := by
    rw [hdecomp]
    push_cast
    field_simp
    ring
  have hxR :
      (Y : ℝ) / L + 1 - (a : ℝ) / L =
        (k : ℝ) + (1 + ((rem : ℝ) - (a : ℝ)) / (L : ℝ)) := by
    rw [hdecomp]
    push_cast
    field_simp
    ring
  simp only [Nat.cast_zero, zero_sub]
  by_cases hcase : rem < a
  · have hcaseQ : (rem : ℚ) < a := by exact_mod_cast hcase
    have hcaseR : (rem : ℝ) < a := by exact_mod_cast hcase
    have hfracQ :
        ⌊((rem : ℚ) - (a : ℚ)) / (L : ℚ)⌋ = (-1 : ℤ) := by
      apply Int.floor_eq_iff.mpr
      constructor
      · norm_num
        apply (le_div_iff₀ hLQ).2
        linarith [haLQ]
      · have hneg : (rem : ℚ) - a < 0 := sub_neg.mpr hcaseQ
        have : ((rem : ℚ) - a) / L < 0 := div_neg_of_neg_of_pos hneg hLQ
        simpa using this
    have hfracR :
        ⌊1 + ((rem : ℝ) - (a : ℝ)) / (L : ℝ)⌋ = (0 : ℤ) := by
      apply Int.floor_eq_iff.mpr
      constructor
      · norm_num
        have hlow : -(L : ℝ) ≤ (rem : ℝ) - a := by
          have hrem0 : (0 : ℝ) ≤ rem := by positivity
          linarith [haLR]
        have hdiv : (-1 : ℝ) ≤ ((rem : ℝ) - a) / L := by
          apply (le_div_iff₀ hLR).2
          nlinarith
        linarith
      · norm_num
        have hneg : (rem : ℝ) - a < 0 := sub_neg.mpr hcaseR
        have hdiv : ((rem : ℝ) - a) / L < 0 := div_neg_of_neg_of_pos hneg hLR
        linarith
    have hfloorY :
        ⌊((Y : ℚ) - (a : ℚ)) / (L : ℚ)⌋ = (k : ℤ) - 1 := by
      rw [hxQ]
      rw [show (k : ℚ) = ((k : ℤ) : ℚ) by norm_num]
      rw [add_comm, Int.floor_add_intCast, hfracQ]
      ring
    have hfloorR :
        ⌊(Y : ℝ) / L + 1 - (a : ℝ) / L⌋ = (k : ℤ) := by
      rw [hxR]
      rw [show (k : ℝ) = ((k : ℤ) : ℝ) by norm_num]
      rw [add_comm, Int.floor_add_intCast, hfracR]
      simp
    rw [hfloor0, hfloorY, hfloorR]
    have hk0 : (0 : ℤ) ≤ (k : ℤ) := by positivity
    simp [hk0]
  · have hak : a ≤ rem := by omega
    have hakQ : (a : ℚ) ≤ rem := by exact_mod_cast hak
    have hakR : (a : ℝ) ≤ rem := by exact_mod_cast hak
    have hremQ : (rem : ℚ) < L := by exact_mod_cast hrem
    have hremR : (rem : ℝ) < L := by exact_mod_cast hrem
    have hfracQ :
        ⌊((rem : ℚ) - (a : ℚ)) / (L : ℚ)⌋ = (0 : ℤ) := by
      apply Int.floor_eq_iff.mpr
      constructor
      · norm_num
        exact div_nonneg (sub_nonneg.mpr hakQ) hLQ.le
      · norm_num
        apply (div_lt_one hLQ).2
        linarith [ha1Q, hremQ]
    have hfracR :
        ⌊1 + ((rem : ℝ) - (a : ℝ)) / (L : ℝ)⌋ = (1 : ℤ) := by
      apply Int.floor_eq_iff.mpr
      constructor
      · norm_num
        exact div_nonneg (sub_nonneg.mpr hakR) hLR.le
      · norm_num
        have hlt : (rem : ℝ) - a < L := by linarith [ha1R, hremR]
        have hdiv : ((rem : ℝ) - a) / L < 1 := (div_lt_one hLR).2 hlt
        linarith
    have hfloorY :
        ⌊((Y : ℚ) - (a : ℚ)) / (L : ℚ)⌋ = (k : ℤ) := by
      rw [hxQ]
      rw [show (k : ℚ) = ((k : ℤ) : ℚ) by norm_num]
      rw [add_comm, Int.floor_add_intCast, hfracQ]
      simp
    have hfloorR :
        ⌊(Y : ℝ) / L + 1 - (a : ℝ) / L⌋ = (k : ℤ) + 1 := by
      rw [hxR]
      rw [show (k : ℝ) = ((k : ℤ) : ℝ) by norm_num]
      rw [add_comm, Int.floor_add_intCast, hfracR]
      ring
    rw [hfloor0, hfloorY, hfloorR]
    have hk0 : (0 : ℤ) ≤ (k : ℤ) := by positivity
    have hk1 : (0 : ℤ) ≤ (k : ℤ) + 1 := by omega
    simp [hk0, hk1]

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def periodicWeightMass
    (L : ℕ) (f : ℕ → ℝ) : ℝ :=
  ∑ a ∈ Finset.Icc 1 L, f a

noncomputable def periodicBoundaryTerm
    (L : ℕ) (f : ℕ → ℝ) : ℝ :=
  ∑ a ∈ Finset.Icc 1 L,
    f a * (1 / 2 - (a : ℝ) / L)

noncomputable def periodicSawtoothTerm
    (L : ℕ) (f : ℕ → ℝ) (t : ℝ) : ℝ :=
  ∑ a ∈ Finset.Icc 1 L,
    f a *
      petermannSawtooth
        (t / L + 1 - (a : ℝ) / L)

theorem exactPeriodicFloorDecomposition
    {f : ℕ → ℝ} {L Y : ℕ}
    (hL : 0 < L)
    (hper : Function.Periodic f L) :
    (∑ n ∈ Finset.Icc 1 Y, f n) =
      periodicWeightMass L f / L * Y +
        periodicBoundaryTerm L f -
        periodicSawtoothTerm L f Y := by
  rw [periodicPrefix_grouped hL hper]
  unfold periodicWeightMass periodicBoundaryTerm periodicSawtoothTerm
  have hL0 : (L : ℝ) ≠ 0 := by exact_mod_cast hL.ne'
  calc
    (∑ a ∈ Finset.Icc 1 L,
        (((Finset.Icc 1 Y).filter
          (fun n => n ≡ a [MOD L])).card : ℝ) * f a)
      = ∑ a ∈ Finset.Icc 1 L,
          ((Y : ℝ) / L + 1 - (a : ℝ) / L -
            petermannSawtooth
              ((Y : ℝ) / L + 1 - (a : ℝ) / L) - 1 / 2) * f a := by
          apply Finset.sum_congr rfl
          intro a ha
          have hcard :=
            residueFiber_card_eq_floor hL
              (Finset.mem_Icc.mp ha).1
              (Finset.mem_Icc.mp ha).2
              (Y := Y)
          have hcardR :
              (((Finset.Icc 1 Y).filter
                (fun n => n ≡ a [MOD L])).card : ℝ) =
                (⌊(Y : ℝ) / L + 1 - (a : ℝ) / L⌋ : ℝ) := by
            exact_mod_cast hcard
          rw [hcardR]
          unfold petermannSawtooth
          ring
    _ = (∑ a ∈ Finset.Icc 1 L, f a) / L * Y +
          (∑ a ∈ Finset.Icc 1 L,
            f a * (1 / 2 - (a : ℝ) / L)) -
          (∑ a ∈ Finset.Icc 1 L,
            f a *
              petermannSawtooth
                ((Y : ℝ) / L + 1 - (a : ℝ) / L)) := by
          have hdensity :
              (∑ a ∈ Finset.Icc 1 L, f a) / L * Y =
                ∑ a ∈ Finset.Icc 1 L,
                  ((Y : ℝ) / L) * f a := by
            rw [div_eq_mul_inv]
            calc
              (∑ a ∈ Finset.Icc 1 L, f a) * (L : ℝ)⁻¹ * (Y : ℝ)
                = ((Y : ℝ) * (L : ℝ)⁻¹) *
                    (∑ a ∈ Finset.Icc 1 L, f a) := by ring
              _ = ∑ a ∈ Finset.Icc 1 L,
                    ((Y : ℝ) * (L : ℝ)⁻¹) * f a := by
                      rw [Finset.mul_sum]
              _ = ∑ a ∈ Finset.Icc 1 L,
                    ((Y : ℝ) / L) * f a := by
                      apply Finset.sum_congr rfl
                      intro a ha
                      simp [div_eq_mul_inv]
          rw [hdensity]
          rw [← Finset.sum_add_distrib]
          rw [← Finset.sum_sub_distrib]
          apply Finset.sum_congr rfl
          intro a ha
          ring

#print axioms residueFiber_card_eq_floor
#print axioms exactPeriodicFloorDecomposition

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def periodicUnitFourierCoeff
    (L : ℕ) [NeZero L]
    (g : (ZMod L)ˣ → ℂ)
    (chi : DirichletCharacter ℂ L) : ℂ :=
  (1 / (L.totient : ℂ)) *
    ∑ u : (ZMod L)ˣ, g u * chi ((u : ZMod L)⁻¹)

theorem periodicUnitFourierExpansion
    (L : ℕ) [NeZero L]
    (g : (ZMod L)ˣ → ℂ)
    (b : (ZMod L)ˣ) :
    g b =
      ∑ chi : DirichletCharacter ℂ L,
        periodicUnitFourierCoeff L g chi * chi (b : ZMod L) := by
  have hL : 0 < L := NeZero.pos L
  have hphi : (L.totient : ℂ) ≠ 0 := by
    exact_mod_cast (Nat.ne_of_gt (Nat.totient_pos.mpr hL))
  unfold periodicUnitFourierCoeff
  symm
  calc
    (∑ chi : DirichletCharacter ℂ L,
        ((1 / (L.totient : ℂ)) *
          ∑ u : (ZMod L)ˣ, g u * chi ((u : ZMod L)⁻¹)) *
          chi (b : ZMod L))
      =
        (1 / (L.totient : ℂ)) *
          ∑ chi : DirichletCharacter ℂ L,
            ((∑ u : (ZMod L)ˣ, g u * chi ((u : ZMod L)⁻¹)) *
              chi (b : ZMod L)) := by
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro chi hchi
          ring
    _ =
        (1 / (L.totient : ℂ)) *
          ∑ chi : DirichletCharacter ℂ L,
            ∑ u : (ZMod L)ˣ,
              (g u * chi ((u : ZMod L)⁻¹)) *
                chi (b : ZMod L) := by
          congr 1
          apply Finset.sum_congr rfl
          intro chi hchi
          rw [Finset.sum_mul]
    _ =
        (1 / (L.totient : ℂ)) *
          ∑ u : (ZMod L)ˣ,
            ∑ chi : DirichletCharacter ℂ L,
              (g u * chi ((u : ZMod L)⁻¹)) *
                chi (b : ZMod L) := by
          rw [Finset.sum_comm]
    _ =
        (1 / (L.totient : ℂ)) *
          ∑ u : (ZMod L)ˣ,
            g u *
              (∑ chi : DirichletCharacter ℂ L,
                chi ((u : ZMod L)⁻¹) * chi (b : ZMod L)) := by
          congr 1
          apply Finset.sum_congr rfl
          intro u hu
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro chi hchi
          ring
    _ =
        (1 / (L.totient : ℂ)) *
          ∑ u : (ZMod L)ˣ,
            g u *
              (if (u : ZMod L) = (b : ZMod L)
                then (L.totient : ℂ) else 0) := by
          congr 1
          apply Finset.sum_congr rfl
          intro u hu
          rw [DirichletCharacter.sum_char_inv_mul_char_eq
            ℂ (Units.isUnit u) (b : ZMod L)]
    _ = g b := by
          rw [Finset.sum_eq_single b]
          · simp [hphi, mul_comm]
          · intro u hu hub
            have hcoe : (u : ZMod L) ≠ (b : ZMod L) := by
              intro h
              exact hub (Units.ext h)
            simp [hcoe]
          · intro hb
            simp at hb

#print axioms periodicUnitFourierExpansion

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def periodicAlpha
    (L : ℕ) [NeZero L]
    (u : (ZMod L)ˣ) (c : ℕ) : ℕ :=
  positiveResidue L
    (((↑(u⁻¹) : ZMod L) * (c : ZMod L)).val)

lemma periodicAlpha_mem_Icc
    (L : ℕ) [NeZero L]
    (u : (ZMod L)ˣ) (c : ℕ) :
    periodicAlpha L u c ∈ Finset.Icc 1 L := by
  exact positiveResidue_mem_Icc (NeZero.pos L)

lemma periodicAlpha_cast_eq
    (L : ℕ) [NeZero L]
    (u : (ZMod L)ˣ) (c : ℕ) :
    (periodicAlpha L u c : ZMod L) =
      (↑(u⁻¹) : ZMod L) * (c : ZMod L) := by
  let x : ZMod L := (↑(u⁻¹) : ZMod L) * (c : ZMod L)
  have hmod :=
    positiveResidue_modEq
      (L := L) (n := x.val) (NeZero.pos L)
  have hcast :
      (x.val : ZMod L) =
        (positiveResidue L x.val : ZMod L) :=
    (ZMod.natCast_eq_natCast_iff _ _ L).2 hmod
  rw [ZMod.natCast_zmod_val] at hcast
  simpa [periodicAlpha, x] using hcast.symm

lemma mul_modEq_iff_modEq_periodicAlpha
    {L e n c : ℕ} [NeZero L]
    (he : e.Coprime L) :
    e * n ≡ c [MOD L] ↔
      n ≡ periodicAlpha L (ZMod.unitOfCoprime e he) c [MOD L] := by
  rw [← ZMod.natCast_eq_natCast_iff]
  rw [← ZMod.natCast_eq_natCast_iff]
  let u : (ZMod L)ˣ := ZMod.unitOfCoprime e he
  have heu : (u : ZMod L) = (e : ZMod L) := by
    simpa [u] using ZMod.coe_unitOfCoprime e he
  have halpha :
      (periodicAlpha L u c : ZMod L) =
        (↑(u⁻¹) : ZMod L) * (c : ZMod L) :=
    periodicAlpha_cast_eq L u c
  constructor
  · intro h
    have h' :
        (u : ZMod L) * (n : ZMod L) = (c : ZMod L) := by
      simpa [heu, Nat.cast_mul] using h
    have hm := congrArg
      (fun z : ZMod L => (↑(u⁻¹) : ZMod L) * z) h'
    have hunit :
        (↑(u⁻¹) : ZMod L) * (u : ZMod L) = 1 :=
      Units.inv_mul u
    simp [mul_assoc, hunit] at hm
    calc
      (n : ZMod L) =
          (↑(u⁻¹) : ZMod L) * (c : ZMod L) := hm
      _ = (periodicAlpha L u c : ZMod L) := halpha.symm
      _ = (periodicAlpha L (ZMod.unitOfCoprime e he) c : ZMod L) := by
        rfl
  · intro h
    have h' :
        (n : ZMod L) =
          (↑(u⁻¹) : ZMod L) * (c : ZMod L) := by
      calc
        (n : ZMod L) =
            (periodicAlpha L (ZMod.unitOfCoprime e he) c : ZMod L) := h
        _ = (periodicAlpha L u c : ZMod L) := by rfl
        _ = (↑(u⁻¹) : ZMod L) * (c : ZMod L) := halpha
    have hm := congrArg
      (fun z : ZMod L => (u : ZMod L) * z) h'
    have hunit :
        (u : ZMod L) * (↑(u⁻¹) : ZMod L) = 1 :=
      Units.mul_inv u
    simp [mul_assoc, hunit] at hm
    simpa [heu, Nat.cast_mul] using hm

#print axioms mul_modEq_iff_modEq_periodicAlpha

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def manuscriptBoundaryTerm
    (L : ℕ) [NeZero L]
    (w : ℕ → ℝ) (u : (ZMod L)ˣ) : ℝ :=
  ∑ c ∈ Finset.Icc 1 L,
    w c * (1 / 2 - (periodicAlpha L u c : ℝ) / L)

noncomputable def manuscriptSawtoothTerm
    (L : ℕ) [NeZero L]
    (w : ℕ → ℝ) (u : (ZMod L)ˣ) (t : ℝ) : ℝ :=
  ∑ c ∈ Finset.Icc 1 L,
    w c *
      petermannSawtooth
        (t / L + 1 - (periodicAlpha L u c : ℝ) / L)

lemma sourceResidueFiber_eq
    {L e n c : ℕ} [NeZero L]
    (he : e.Coprime L) (he1 : 1 ≤ e) (hn1 : 1 ≤ n)
    (hc : c ∈ Finset.Icc 1 L) :
    positiveResidue L (e * n) = c ↔
      n ≡ periodicAlpha L (ZMod.unitOfCoprime e he) c [MOD L] := by
  have he0 : e ≠ 0 := Nat.ne_of_gt (lt_of_lt_of_le Nat.zero_lt_one he1)
  have hn0 : n ≠ 0 := Nat.ne_of_gt (lt_of_lt_of_le Nat.zero_lt_one hn1)
  have hprod1 : 1 ≤ e * n :=
    Nat.one_le_iff_ne_zero.mpr (mul_ne_zero he0 hn0)
  have hmem : e * n ∈ Finset.Icc 1 (e * n) :=
    Finset.mem_Icc.mpr ⟨hprod1, le_rfl⟩
  exact
    (residueFiber_eq_modEq (NeZero.pos L) hc hmem).trans
      (mul_modEq_iff_modEq_periodicAlpha he)

theorem exactManuscriptPeriodicFloorDecomposition
    {w : ℕ → ℝ} {L e Y : ℕ} [NeZero L]
    (he : e.Coprime L) (he1 : 1 ≤ e)
    (hper : Function.Periodic w L) :
    (∑ n ∈ Finset.Icc 1 Y, w (e * n)) =
      periodicWeightMass L w / L * Y +
        manuscriptBoundaryTerm L w (ZMod.unitOfCoprime e he) -
        manuscriptSawtoothTerm L w (ZMod.unitOfCoprime e he) Y := by
  classical
  let u : (ZMod L)ˣ := ZMod.unitOfCoprime e he
  have hL : 0 < L := NeZero.pos L
  have hL0 : (L : ℝ) ≠ 0 := by exact_mod_cast (NeZero.ne L)
  have hmaps :
      ∀ n ∈ Finset.Icc 1 Y,
        positiveResidue L (e * n) ∈ Finset.Icc 1 L := by
    intro n hn
    exact positiveResidue_mem_Icc hL
  have hfiber :=
    Finset.sum_fiberwise_of_maps_to hmaps
      (fun n : ℕ => w (e * n))
  rw [← hfiber]
  unfold periodicWeightMass manuscriptBoundaryTerm manuscriptSawtoothTerm
  change
    (∑ c ∈ Finset.Icc 1 L,
      ∑ n ∈ Finset.Icc 1 Y with positiveResidue L (e * n) = c,
        w (e * n)) =
      (∑ c ∈ Finset.Icc 1 L, w c) / L * Y +
        (∑ c ∈ Finset.Icc 1 L,
          w c * (1 / 2 - (periodicAlpha L u c : ℝ) / L)) -
        (∑ c ∈ Finset.Icc 1 L,
          w c *
            petermannSawtooth
              ((Y : ℝ) / L + 1 -
                (periodicAlpha L u c : ℝ) / L))
  calc
    (∑ c ∈ Finset.Icc 1 L,
      ∑ n ∈ Finset.Icc 1 Y with positiveResidue L (e * n) = c,
        w (e * n))
      =
      ∑ c ∈ Finset.Icc 1 L,
        ((((Finset.Icc 1 Y).filter
          (fun n =>
            n ≡ periodicAlpha L u c [MOD L])).card : ℝ) * w c) := by
          apply Finset.sum_congr rfl
          intro c hc
          rw [Finset.sum_filter]
          calc
            (∑ n ∈ Finset.Icc 1 Y,
              if positiveResidue L (e * n) = c then w (e * n) else 0)
              =
              ∑ n ∈ Finset.Icc 1 Y,
                if n ≡ periodicAlpha L u c [MOD L]
                then w c else 0 := by
                  apply Finset.sum_congr rfl
                  intro n hn
                  have hn1 := (Finset.mem_Icc.mp hn).1
                  have hiff :
                      positiveResidue L (e * n) = c ↔
                        n ≡ periodicAlpha L u c [MOD L] := by
                    simpa [u] using sourceResidueFiber_eq he he1 hn1 hc
                  by_cases hp : positiveResidue L (e * n) = c
                  · have hm := hiff.mp hp
                    have hw :
                        w (e * n) = w c := by
                      calc
                        w (e * n) =
                            w (positiveResidue L (e * n)) :=
                          periodic_eq_positiveResidue hL
                            (Nat.one_le_iff_ne_zero.mpr
                              (mul_ne_zero
                                (Nat.ne_of_gt
                                  (lt_of_lt_of_le Nat.zero_lt_one he1))
                                (Nat.ne_of_gt
                                  (lt_of_lt_of_le Nat.zero_lt_one hn1)))) hper
                        _ = w c := by rw [hp]
                    simp [hp, hm, hw]
                  · have hm : ¬ n ≡ periodicAlpha L u c [MOD L] := by
                      intro hmod
                      exact hp (hiff.mpr hmod)
                    simp [hp, hm]
            _ =
              ((((Finset.Icc 1 Y).filter
                (fun n =>
                  n ≡ periodicAlpha L u c [MOD L])).card : ℝ) * w c) := by
                  rw [← Finset.sum_filter]
                  simp
    _ =
      ∑ c ∈ Finset.Icc 1 L,
        (((Y : ℝ) / L + 1 -
            (periodicAlpha L u c : ℝ) / L -
            petermannSawtooth
              ((Y : ℝ) / L + 1 -
                (periodicAlpha L u c : ℝ) / L) - 1 / 2) * w c) := by
          apply Finset.sum_congr rfl
          intro c hc
          have halpha := periodicAlpha_mem_Icc L u c
          have hcard :=
            residueFiber_card_eq_floor hL
              (Finset.mem_Icc.mp halpha).1
              (Finset.mem_Icc.mp halpha).2
              (Y := Y)
          have hcardR :
              ((((Finset.Icc 1 Y).filter
                (fun n =>
                  n ≡ periodicAlpha L u c [MOD L])).card : ℝ)) =
                (⌊(Y : ℝ) / L + 1 -
                  (periodicAlpha L u c : ℝ) / L⌋ : ℝ) := by
            exact_mod_cast hcard
          rw [hcardR]
          unfold petermannSawtooth
          ring
    _ =
      (∑ c ∈ Finset.Icc 1 L, w c) / L * Y +
        (∑ c ∈ Finset.Icc 1 L,
          w c * (1 / 2 - (periodicAlpha L u c : ℝ) / L)) -
        (∑ c ∈ Finset.Icc 1 L,
          w c *
            petermannSawtooth
              ((Y : ℝ) / L + 1 -
                (periodicAlpha L u c : ℝ) / L)) := by
          have hdensity :
              (∑ c ∈ Finset.Icc 1 L, w c) / L * Y =
                ∑ c ∈ Finset.Icc 1 L,
                  ((Y : ℝ) / L) * w c := by
            rw [div_eq_mul_inv]
            calc
              (∑ c ∈ Finset.Icc 1 L, w c) * (L : ℝ)⁻¹ * (Y : ℝ)
                = ((Y : ℝ) * (L : ℝ)⁻¹) *
                    (∑ c ∈ Finset.Icc 1 L, w c) := by ring
              _ = ∑ c ∈ Finset.Icc 1 L,
                    ((Y : ℝ) * (L : ℝ)⁻¹) * w c := by
                      rw [Finset.mul_sum]
              _ = ∑ c ∈ Finset.Icc 1 L,
                    ((Y : ℝ) / L) * w c := by
                      apply Finset.sum_congr rfl
                      intro c hc
                      simp [div_eq_mul_inv]
          rw [hdensity]
          rw [← Finset.sum_add_distrib]
          rw [← Finset.sum_sub_distrib]
          apply Finset.sum_congr rfl
          intro c hc
          ring

#print axioms exactManuscriptPeriodicFloorDecomposition

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma positiveRepresentative_eq_of_cast_eq
    {L a b : ℕ} [NeZero L]
    (ha : a ∈ Finset.Icc 1 L)
    (hb : b ∈ Finset.Icc 1 L)
    (hcast : (a : ZMod L) = (b : ZMod L)) :
    a = b := by
  have hmod : a ≡ b [MOD L] :=
    (ZMod.natCast_eq_natCast_iff a b L).1 hcast
  change a % L = b % L at hmod
  have haR := Finset.mem_Icc.mp ha
  have hbR := Finset.mem_Icc.mp hb
  by_cases haL : a = L
  · subst a
    by_cases hbL : b = L
    · exact hbL.symm
    · have hblt : b < L := lt_of_le_of_ne hbR.2 hbL
      rw [Nat.mod_eq_of_lt hblt] at hmod
      simp [NeZero.ne L] at hmod
      omega
  · have halt : a < L := lt_of_le_of_ne haR.2 haL
    rw [Nat.mod_eq_of_lt halt] at hmod
    by_cases hbL : b = L
    · subst b
      simp [NeZero.ne L] at hmod
      omega
    · have hblt : b < L := lt_of_le_of_ne hbR.2 hbL
      rw [Nat.mod_eq_of_lt hblt] at hmod
      exact hmod

lemma periodicAlpha_inv_left
    (L : ℕ) [NeZero L]
    (u : (ZMod L)ˣ) {a : ℕ}
    (ha : a ∈ Finset.Icc 1 L) :
    periodicAlpha L u (periodicAlpha L (u⁻¹) a) = a := by
  apply positiveRepresentative_eq_of_cast_eq (L := L)
  · exact periodicAlpha_mem_Icc L u _
  · exact ha
  rw [periodicAlpha_cast_eq L u, periodicAlpha_cast_eq L (u⁻¹)]
  simp [mul_assoc]

lemma periodicAlpha_inv_right
    (L : ℕ) [NeZero L]
    (u : (ZMod L)ˣ) {c : ℕ}
    (hc : c ∈ Finset.Icc 1 L) :
    periodicAlpha L (u⁻¹) (periodicAlpha L u c) = c := by
  simpa using periodicAlpha_inv_left L (u⁻¹) hc

#print axioms periodicAlpha_inv_left
#print axioms periodicAlpha_inv_right

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem sum_reindex_periodicAlpha
    {M : Type*} [AddCommMonoid M]
    (L : ℕ) [NeZero L]
    (u : (ZMod L)ˣ) (F : ℕ → ℕ → M) :
    (∑ c ∈ Finset.Icc 1 L,
      F c (periodicAlpha L u c)) =
      ∑ a ∈ Finset.Icc 1 L,
        F (periodicAlpha L (u⁻¹) a) a := by
  classical
  refine Finset.sum_bij'
    (fun c _ => periodicAlpha L u c)
    (fun a _ => periodicAlpha L (u⁻¹) a)
    ?_ ?_ ?_ ?_ ?_
  · intro c hc
    exact periodicAlpha_mem_Icc L u c
  · intro a ha
    exact periodicAlpha_mem_Icc L (u⁻¹) a
  · intro c hc
    exact periodicAlpha_inv_right L u hc
  · intro a ha
    exact periodicAlpha_inv_left L u ha
  · intro c hc
    rw [periodicAlpha_inv_right L u hc]

theorem manuscriptBoundaryTerm_reindex
    (L : ℕ) [NeZero L]
    (w : ℕ → ℝ) (u : (ZMod L)ˣ) :
    manuscriptBoundaryTerm L w u =
      ∑ a ∈ Finset.Icc 1 L,
        w (periodicAlpha L (u⁻¹) a) *
          (1 / 2 - (a : ℝ) / L) := by
  unfold manuscriptBoundaryTerm
  exact sum_reindex_periodicAlpha L u
    (fun c a =>
      w c * (1 / 2 - (a : ℝ) / L))

theorem manuscriptSawtoothTerm_reindex
    (L : ℕ) [NeZero L]
    (w : ℕ → ℝ) (u : (ZMod L)ˣ) (t : ℝ) :
    manuscriptSawtoothTerm L w u t =
      ∑ a ∈ Finset.Icc 1 L,
        w (periodicAlpha L (u⁻¹) a) *
          petermannSawtooth
            (t / L + 1 - (a : ℝ) / L) := by
  unfold manuscriptSawtoothTerm
  exact sum_reindex_periodicAlpha L u
    (fun c a =>
      w c *
        petermannSawtooth
          (t / L + 1 - (a : ℝ) / L))

#print axioms sum_reindex_periodicAlpha
#print axioms manuscriptBoundaryTerm_reindex
#print axioms manuscriptSawtoothTerm_reindex

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def boundaryCharacterCoeff
    (L : ℕ) [NeZero L]
    (w : ℕ → ℝ)
    (chi : DirichletCharacter ℂ L) : ℂ :=
  periodicUnitFourierCoeff L
    (fun u => (manuscriptBoundaryTerm L w u : ℂ)) chi

noncomputable def sawtoothCharacterCoeff
    (L : ℕ) [NeZero L]
    (w : ℕ → ℝ) (t : ℝ)
    (chi : DirichletCharacter ℂ L) : ℂ :=
  periodicUnitFourierCoeff L
    (fun u => (manuscriptSawtoothTerm L w u t : ℂ)) chi

theorem manuscriptBoundaryTerm_character_expansion
    (L : ℕ) [NeZero L]
    (w : ℕ → ℝ) (u : (ZMod L)ˣ) :
    (manuscriptBoundaryTerm L w u : ℂ) =
      ∑ chi : DirichletCharacter ℂ L,
        boundaryCharacterCoeff L w chi * chi (u : ZMod L) := by
  exact periodicUnitFourierExpansion L
    (fun v => (manuscriptBoundaryTerm L w v : ℂ)) u

theorem manuscriptSawtoothTerm_character_expansion
    (L : ℕ) [NeZero L]
    (w : ℕ → ℝ) (u : (ZMod L)ˣ) (t : ℝ) :
    (manuscriptSawtoothTerm L w u t : ℂ) =
      ∑ chi : DirichletCharacter ℂ L,
        sawtoothCharacterCoeff L w t chi * chi (u : ZMod L) := by
  exact periodicUnitFourierExpansion L
    (fun v => (manuscriptSawtoothTerm L w v t : ℂ)) u

theorem sawtoothCharacterCoeff_eq_fixed_shifts
    (L : ℕ) [NeZero L]
    (w : ℕ → ℝ) (t : ℝ)
    (chi : DirichletCharacter ℂ L) :
    sawtoothCharacterCoeff L w t chi =
      (1 / (L.totient : ℂ)) *
        ∑ u : (ZMod L)ˣ,
          ((∑ c ∈ Finset.Icc 1 L,
              w c *
                petermannSawtooth
                  (t / L + 1 -
                    (periodicAlpha L u c : ℝ) / L)) : ℂ) *
            chi ((u : ZMod L)⁻¹) := by
  unfold sawtoothCharacterCoeff periodicUnitFourierCoeff
  apply congrArg (fun z : ℂ => (1 / (L.totient : ℂ)) * z)
  apply Finset.sum_congr rfl
  intro u hu
  congr 1
  unfold manuscriptSawtoothTerm
  push_cast
  rfl

#print axioms manuscriptBoundaryTerm_character_expansion
#print axioms manuscriptSawtoothTerm_character_expansion
#print axioms sawtoothCharacterCoeff_eq_fixed_shifts

end PaperB.FixedQ
