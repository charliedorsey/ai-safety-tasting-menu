import PaperB.FixedQ.FixedProductAverage
import PaperB.FixedQ.FixedConductorCompletion
import PaperB.FixedQ.H3SelbergMajorant
import PaperB.FixedQ.H3SelbergCoeff
import PaperB.FixedQ.H3VaalerPeriodizationCloseout

open scoped BigOperators ComplexConjugate
namespace PaperB.FixedQ

/- inherited axiom-clean CRT bridge declarations, inlined for scratch court -/

lemma fixedProduct_complement_coprime
    {S A : Finset ℕ} (hA : A ⊆ S)
    (hPrime : ∀ p ∈ S, p.Prime) :
    (primeSetProduct A).Coprime (primeSetProduct (S \ A)) := by
  unfold primeSetProduct
  apply Nat.Coprime.prod_left
  intro p hpA
  apply Nat.Coprime.prod_right
  intro r hrD
  have hpS : p ∈ S := hA hpA
  have hrS : r ∈ S := (Finset.mem_sdiff.mp hrD).1
  have hpr : p ≠ r := by
    intro h
    subst r
    exact (Finset.mem_sdiff.mp hrD).2 hpA
  exact (Nat.coprime_primes (hPrime p hpS) (hPrime r hrS)).2 hpr

noncomputable def fixedProductCRTIdempotentNat
    (S A : Finset ℕ) : ℕ :=
  let e1 := primeSetProduct A
  let e2 := primeSetProduct (S \ A)
  if hc : e1.Coprime e2 then
    (Nat.chineseRemainder (m := e2) (n := e1) hc 0 1).1
  else 0

noncomputable def fixedProductCRTIdempotent
    (S A : Finset ℕ) (hA : A ⊆ S) : ZMod (primeSetProduct S) :=
  (fixedProductCRTIdempotentNat S A : ZMod (primeSetProduct S))

lemma fixedProductCRTIdempotentNat_specs
    {S A : Finset ℕ} (hA : A ⊆ S)
    (hPrime : ∀ p ∈ S, p.Prime) :
    fixedProductCRTIdempotentNat S A ≡ 0 [MOD primeSetProduct A] ∧
    fixedProductCRTIdempotentNat S A ≡ 1 [MOD primeSetProduct (S \ A)] := by
  have hc := fixedProduct_complement_coprime hA hPrime
  simp only [fixedProductCRTIdempotentNat, dif_pos hc]
  exact (Nat.chineseRemainder (m := primeSetProduct (S \ A))
    (n := primeSetProduct A) hc 0 1).2

lemma fixedProductPartition_dvd_iff_crt_modEq
    {S A : Finset ℕ} (hA : A ⊆ S)
    (hPrime : ∀ p ∈ S, p.Prime)
    {H y : ℕ} (hyH : y ≤ H) :
    (primeSetProduct A ∣ y ∧ primeSetProduct (S \ A) ∣ H - y) ↔
      y ≡ H * fixedProductCRTIdempotentNat S A [MOD primeSetProduct S] := by
  let e1 := primeSetProduct A
  let e2 := primeSetProduct (S \ A)
  have hc : e1.Coprime e2 := fixedProduct_complement_coprime hA hPrime
  have hm : e1 * e2 = primeSetProduct S :=
    pair_moduli_product_eq_fixedProduct hA hPrime
  have hu := fixedProductCRTIdempotentNat_specs hA hPrime
  constructor
  · rintro ⟨hy1, hy2⟩
    have hy1m : y ≡ 0 [MOD e1] := Nat.modEq_zero_iff_dvd.mpr hy1
    have hy2m : y ≡ H [MOD e2] := (Nat.modEq_iff_dvd' hyH).2 hy2
    have hH1 : H * fixedProductCRTIdempotentNat S A ≡ 0 [MOD e1] := by
      exact hu.1.mul_left H
    have hH2 : H * fixedProductCRTIdempotentNat S A ≡ H [MOD e2] := by
      simpa using hu.2.mul_left H
    have h1 : y ≡ H * fixedProductCRTIdempotentNat S A [MOD e1] :=
      hy1m.trans hH1.symm
    have h2 : y ≡ H * fixedProductCRTIdempotentNat S A [MOD e2] :=
      hy2m.trans hH2.symm
    have hp := (Nat.modEq_and_modEq_iff_modEq_mul hc).1 ⟨h1, h2⟩
    simpa [hm] using hp
  · intro hmod
    have hp : y ≡ H * fixedProductCRTIdempotentNat S A [MOD e1 * e2] := by
      simpa [hm] using hmod
    have hs := (Nat.modEq_and_modEq_iff_modEq_mul hc).2 hp
    have hy1m : y ≡ 0 [MOD e1] := hs.1.trans (hu.1.mul_left H)
    have hy2m : y ≡ H [MOD e2] := hs.2.trans (by simpa using hu.2.mul_left H)
    exact ⟨Nat.modEq_zero_iff_dvd.mp hy1m,
      (Nat.modEq_iff_dvd' hyH).1 hy2m⟩

#print axioms fixedProductPartition_dvd_iff_crt_modEq


theorem fixedProductCRTIdempotent_cast_eq
    {S A : Finset ℕ} (hA : A ⊆ S) :
    fixedProductCRTIdempotent S A hA =
      (fixedProductCRTIdempotentNat S A : ZMod (primeSetProduct S)) := rfl

theorem fixedProductPartition_rowConstrainedSet_eq_crtResidueFiber
    {S A : Finset ℕ} (hA : A ⊆ S)
    (hPrime : ∀ p ∈ S, p.Prime)
    {H y : ℕ} :
    y ∈ rowConstrainedSet H (primeSetProduct A) (primeSetProduct (S \ A)) ↔
      0 < y ∧ y < H ∧
        (y : ZMod (primeSetProduct S)) =
          (H : ZMod (primeSetProduct S)) * fixedProductCRTIdempotent S A hA := by
  rw [rowConstrainedSet, Finset.mem_filter, Finset.mem_Ioo]
  constructor
  · rintro ⟨⟨hy0, hyHlt⟩, hdiv⟩
    refine ⟨hy0, hyHlt, ?_⟩
    have hmod := fixedProductPartition_dvd_iff_crt_modEq hA hPrime
      (Nat.le_of_lt hyHlt) |>.mp hdiv
    rw [fixedProductCRTIdempotent_cast_eq]
    have hz :
        (y : ZMod (primeSetProduct S)) =
          (H * fixedProductCRTIdempotentNat S A : ℕ) :=
      (ZMod.natCast_eq_natCast_iff y
        (H * fixedProductCRTIdempotentNat S A) (primeSetProduct S)).2 hmod
    simpa using hz
  · rintro ⟨hy0, hyHlt, hz⟩
    refine ⟨⟨hy0, hyHlt⟩, ?_⟩
    have hz' :
        (y : ZMod (primeSetProduct S)) =
          (H * fixedProductCRTIdempotentNat S A : ℕ) := by
      simpa [fixedProductCRTIdempotent_cast_eq] using hz
    have hmod :
        y ≡ H * fixedProductCRTIdempotentNat S A [MOD primeSetProduct S] :=
      (ZMod.natCast_eq_natCast_iff y
        (H * fixedProductCRTIdempotentNat S A) (primeSetProduct S)).1 hz'
    exact (fixedProductPartition_dvd_iff_crt_modEq hA hPrime
      (Nat.le_of_lt hyHlt)).mpr hmod

#print axioms fixedProductPartition_rowConstrainedSet_eq_crtResidueFiber


noncomputable def fixedQBooleanResidueFiberMass
    (q a H : ℕ) (S A : Finset ℕ) : ℝ :=
  ∑ y ∈ Finset.Ioo 0 H,
    if y ≡ H * fixedProductCRTIdempotentNat S A [MOD primeSetProduct S]
    then fixedQLowWeight q a H y else 0

noncomputable def fixedQWeightedBooleanIntervalDiscrepancy
    (q a H : ℕ) (S : Finset ℕ) : ℝ :=
  ((2 : ℝ) ^ S.card)⁻¹ *
      ∑ A ∈ S.powerset, fixedQBooleanResidueFiberMass q a H S A -
    rowWeightMass (fixedQLowWeight q a H) H / (primeSetProduct S : ℝ)

lemma fixedProductPartition_constrainedMass_eq_crtResidueFiberMass
    {q a H : ℕ} {S A : Finset ℕ}
    (hA : A ⊆ S) (hPrime : ∀ p ∈ S, p.Prime) :
    rowConstrainedMass (fixedQLowWeight q a H) H
        (primeSetProduct A) (primeSetProduct (S \ A)) =
      fixedQBooleanResidueFiberMass q a H S A := by
  rw [rowConstrainedMass_eq_sum_set]
  unfold rowConstrainedSet fixedQBooleanResidueFiberMass
  rw [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro y hy
  have hyI := Finset.mem_Ioo.mp hy
  have hiff := fixedProductPartition_dvd_iff_crt_modEq hA hPrime
    (Nat.le_of_lt hyI.2)
  by_cases hd : primeSetProduct A ∣ y ∧ primeSetProduct (S \ A) ∣ H - y
  · have hm := hiff.mp hd
    simp [rowConstrainedSet, hd, hm]
  · have hm : ¬ y ≡ H * fixedProductCRTIdempotentNat S A [MOD primeSetProduct S] :=
      fun h => hd (hiff.mpr h)
    simp [rowConstrainedSet, hd, hm]

#print axioms fixedProductPartition_constrainedMass_eq_crtResidueFiberMass


theorem fixedProductBooleanDiscrepancy_eq_fixedQWeightedBooleanIntervalDiscrepancy
    {q a H : ℕ} {S : Finset ℕ}
    (hPrime : ∀ p ∈ S, p.Prime) :
    fixedProductBooleanDiscrepancy (fixedQLowWeight q a H) H S =
      fixedQWeightedBooleanIntervalDiscrepancy q a H S := by
  classical
  have hmpos : 0 < primeSetProduct S := primeSetProduct_pos hPrime
  have hm0 : (primeSetProduct S : ℝ) ≠ 0 := by exact_mod_cast hmpos.ne'
  have hpow0 : ((2 : ℝ) ^ S.card) ≠ 0 := by positivity
  have hrow : ∀ A ∈ S.powerset,
      fixedProductPartitionDiscrepancy (fixedQLowWeight q a H) H S A =
        fixedQBooleanResidueFiberMass q a H S A -
          rowWeightMass (fixedQLowWeight q a H) H / (primeSetProduct S : ℝ) := by
    intro A hApow
    have hA : A ⊆ S := Finset.mem_powerset.mp hApow
    unfold fixedProductPartitionDiscrepancy rowDiscrepancy
    rw [fixedProductPartition_constrainedMass_eq_crtResidueFiberMass hA hPrime]
    have hm := pair_moduli_product_eq_fixedProduct hA hPrime
    rw [show ((primeSetProduct A : ℝ) * (primeSetProduct (S \ A) : ℝ)) =
        (primeSetProduct S : ℝ) by exact_mod_cast hm]
  have hsum :
      (∑ A ∈ S.powerset,
        fixedProductPartitionDiscrepancy (fixedQLowWeight q a H) H S A) =
      ∑ A ∈ S.powerset,
        (fixedQBooleanResidueFiberMass q a H S A -
          rowWeightMass (fixedQLowWeight q a H) H / (primeSetProduct S : ℝ)) := by
    apply Finset.sum_congr rfl
    intro A hA
    exact hrow A hA
  unfold fixedProductBooleanDiscrepancy fixedQWeightedBooleanIntervalDiscrepancy
  rw [hsum, Finset.sum_sub_distrib]
  have hcard : S.powerset.card = 2 ^ S.card := Finset.card_powerset S
  rw [Finset.sum_const, hcard]
  simp only [nsmul_eq_mul, Nat.cast_pow, Nat.cast_ofNat]
  field_simp [hpow0, hm0]

#print axioms fixedProductBooleanDiscrepancy_eq_fixedQWeightedBooleanIntervalDiscrepancy


noncomputable def fixedProductBooleanFourierCoeff
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (t : ZMod (primeSetProduct S)) : ℂ := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  exact ((2 : ℂ) ^ S.card)⁻¹ *
    ∑ A ∈ S.powerset,
      ZMod.stdAddChar
        (t * (fixedProductCRTIdempotentNat S A : ZMod (primeSetProduct S)))


lemma calder_booleanFourierCoeff_neg
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (t : ZMod (primeSetProduct S)) :
    fixedProductBooleanFourierCoeff S hPrime (-t) =
      conj (fixedProductBooleanFourierCoeff S hPrime t) := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  unfold fixedProductBooleanFourierCoeff
  rw [map_mul]
  simp only [map_inv₀, map_pow, map_ofNat]
  congr 1
  rw [map_sum]
  apply Finset.sum_congr rfl
  intro A hA
  have harg :
      -t * (fixedProductCRTIdempotentNat S A : ZMod (primeSetProduct S)) =
        -(t * (fixedProductCRTIdempotentNat S A : ZMod (primeSetProduct S))) := by
    ring
  rw [harg, AddChar.map_neg_eq_inv]
  exact Complex.inv_eq_conj (norm_stdAddChar_eq_one (primeSetProduct S)
    (t * (fixedProductCRTIdempotentNat S A : ZMod (primeSetProduct S))))

lemma calder_booleanFrequencyMass_neg
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (t : ZMod (primeSetProduct S)) :
    ‖fixedProductBooleanFourierCoeff S hPrime (-t)‖ =
      ‖fixedProductBooleanFourierCoeff S hPrime t‖ := by
  rw [calder_booleanFourierCoeff_neg]
  simpa using norm_conj (fixedProductBooleanFourierCoeff S hPrime t)


#print axioms calder_booleanFourierCoeff_neg
#print axioms calder_booleanFrequencyMass_neg

noncomputable def calderBooleanRootAverageR
    (S : Finset ℕ) (f : ZMod (primeSetProduct S) → ℝ) : ℝ :=
  ((2 : ℝ) ^ S.card)⁻¹ *
    ∑ A ∈ S.powerset,
      f (fixedProductCRTIdempotentNat S A : ZMod (primeSetProduct S))

noncomputable def calderBooleanRootAverageC
    (S : Finset ℕ) (f : ZMod (primeSetProduct S) → ℂ) : ℂ :=
  (((2 : ℝ) ^ S.card)⁻¹ : ℝ) •
    ∑ A ∈ S.powerset,
      f (fixedProductCRTIdempotentNat S A : ZMod (primeSetProduct S))

lemma calderBooleanRootAverageR_const
    (S : Finset ℕ) (c : ℝ) :
    calderBooleanRootAverageR S (fun _ => c) = c := by
  unfold calderBooleanRootAverageR
  rw [Finset.sum_const, Finset.card_powerset]
  simp only [nsmul_eq_mul, Nat.cast_pow, Nat.cast_ofNat]
  have hpow : (2 : ℝ) ^ S.card ≠ 0 := by positivity
  field_simp [hpow]

lemma calderBooleanRootAverageC_const
    (S : Finset ℕ) (c : ℂ) :
    calderBooleanRootAverageC S (fun _ => c) = c := by
  unfold calderBooleanRootAverageC
  rw [Finset.sum_const, Finset.card_powerset]
  simp only [nsmul_eq_mul, Nat.cast_pow, Nat.cast_ofNat]
  rw [Algebra.smul_def]
  have hpowR : (2 : ℝ) ^ S.card ≠ 0 := by positivity
  have hpowC : (((2 : ℝ) ^ S.card : ℝ) : ℂ) ≠ 0 := by
    exact_mod_cast hpowR
  push_cast
  field_simp [hpowC]

lemma calderBooleanRootAverageR_add
    (S : Finset ℕ) (f g : ZMod (primeSetProduct S) → ℝ) :
    calderBooleanRootAverageR S (fun x => f x + g x) =
      calderBooleanRootAverageR S f + calderBooleanRootAverageR S g := by
  unfold calderBooleanRootAverageR
  simp_rw [Finset.sum_add_distrib]
  ring

lemma calderBooleanRootAverageR_sub
    (S : Finset ℕ) (f g : ZMod (primeSetProduct S) → ℝ) :
    calderBooleanRootAverageR S (fun x => f x - g x) =
      calderBooleanRootAverageR S f - calderBooleanRootAverageR S g := by
  unfold calderBooleanRootAverageR
  simp_rw [Finset.sum_sub_distrib]
  ring

lemma calderBooleanRootAverageR_im
    (S : Finset ℕ) (f : ZMod (primeSetProduct S) → ℂ) :
    calderBooleanRootAverageR S (fun x => (f x).im) =
      (calderBooleanRootAverageC S f).im := by
  unfold calderBooleanRootAverageR calderBooleanRootAverageC
  change
    ((2 : ℝ) ^ S.card)⁻¹ *
      (∑ A ∈ S.powerset,
        (f (fixedProductCRTIdempotentNat S A : ZMod (primeSetProduct S))).im) =
    Complex.imCLM
      ((((2 : ℝ) ^ S.card)⁻¹ : ℝ) •
        ∑ A ∈ S.powerset,
          f (fixedProductCRTIdempotentNat S A : ZMod (primeSetProduct S)))
  rw [map_smul]
  simp only [Complex.imCLM_apply, smul_eq_mul]
  have him :
      (∑ A ∈ S.powerset,
        f (fixedProductCRTIdempotentNat S A : ZMod (primeSetProduct S))).im =
      ∑ A ∈ S.powerset,
        (f (fixedProductCRTIdempotentNat S A : ZMod (primeSetProduct S))).im := by
    simp_rw [← Complex.imCLM_apply]
    rw [map_sum]
  rw [him]

lemma calderBooleanRootAverageC_stdAddChar
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (t : ZMod (primeSetProduct S)) :
    calderBooleanRootAverageC S
      (fun x => ZMod.stdAddChar (t * x)) =
      fixedProductBooleanFourierCoeff S hPrime t := by
  unfold calderBooleanRootAverageC fixedProductBooleanFourierCoeff
  rw [Algebra.smul_def]
  congr 1
  norm_num


lemma calder_conj_stdAddChar_eq_neg
    {N : ℕ} [NeZero N] (x : ZMod N) :
    conj (ZMod.stdAddChar x) = ZMod.stdAddChar (-x) := by
  rw [AddChar.map_neg_eq_inv]
  exact (Complex.inv_eq_conj (norm_stdAddChar_eq_one N x)).symm

lemma calder_conj_pow_stdAddChar
    {N : ℕ} [NeZero N] (x : ZMod N) (k : ℕ) :
    conj ((ZMod.stdAddChar x) ^ k) =
      ZMod.stdAddChar ((-(k : ZMod N)) * x) := by
  rw [map_pow, calder_conj_stdAddChar_eq_neg]
  rw [← AddChar.map_nsmul_eq_pow]
  congr 1
  simp [nsmul_eq_mul, mul_comm]

lemma calder_fejer_norm_sq_expand
    {N L : ℕ} [NeZero N] (x : ZMod N) :
    ((‖∑ k ∈ Finset.range L, (ZMod.stdAddChar x) ^ k‖ ^ 2 : ℝ) : ℂ) =
      ∑ b ∈ Finset.range L, ∑ a ∈ Finset.range L,
        ZMod.stdAddChar (((a : ZMod N) - (b : ZMod N)) * x) := by
  rw [← Complex.normSq_eq_norm_sq, Complex.normSq_eq_conj_mul_self]
  rw [map_sum, Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro b hb
  calc
    (starRingEnd ℂ) ((ZMod.stdAddChar x) ^ b) *
        (∑ k ∈ Finset.range L, (ZMod.stdAddChar x) ^ k) =
      ∑ a ∈ Finset.range L,
        (starRingEnd ℂ) ((ZMod.stdAddChar x) ^ b) *
          (ZMod.stdAddChar x) ^ a := by
        exact Finset.mul_sum (Finset.range L)
          (fun k => (ZMod.stdAddChar x) ^ k)
          ((starRingEnd ℂ) ((ZMod.stdAddChar x) ^ b))
    _ = ∑ a ∈ Finset.range L,
        ZMod.stdAddChar (((a : ZMod N) - (b : ZMod N)) * x) := by
      apply Finset.sum_congr rfl
      intro a ha
      rw [calder_conj_pow_stdAddChar]
      have haPow :
          (ZMod.stdAddChar x) ^ a =
            ZMod.stdAddChar ((a : ZMod N) * x) := by
        rw [← AddChar.map_nsmul_eq_pow]
        congr 1
        simp [nsmul_eq_mul, mul_comm]
      rw [haPow, ← AddChar.map_add_eq_mul]
      congr 1
      ring

lemma calderBooleanRootAverageC_add
    (S : Finset ℕ) (f g : ZMod (primeSetProduct S) → ℂ) :
    calderBooleanRootAverageC S (fun x => f x + g x) =
      calderBooleanRootAverageC S f + calderBooleanRootAverageC S g := by
  unfold calderBooleanRootAverageC
  simp_rw [Finset.sum_add_distrib, smul_add]

lemma calderBooleanRootAverageC_sum
    (S : Finset ℕ) {ι : Type} (T : Finset ι)
    (f : ι → ZMod (primeSetProduct S) → ℂ) :
    calderBooleanRootAverageC S (fun x => ∑ i ∈ T, f i x) =
      ∑ i ∈ T, calderBooleanRootAverageC S (f i) := by
  classical
  induction T using Finset.induction_on with
  | empty => simp [calderBooleanRootAverageC]
  | @insert i T hi ih =>
      simp only [Finset.sum_insert hi]
      rw [calderBooleanRootAverageC_add, ih]


lemma calderBooleanRootAverageC_ofReal
    (S : Finset ℕ) (f : ZMod (primeSetProduct S) → ℝ) :
    calderBooleanRootAverageC S (fun x => (f x : ℂ)) =
      (calderBooleanRootAverageR S f : ℂ) := by
  unfold calderBooleanRootAverageC calderBooleanRootAverageR
  rw [Algebra.smul_def]
  push_cast
  congr 1

lemma calder_booleanAverage_fejer_normsq_eq_double
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (L : ℕ) :
    let N := primeSetProduct S
    ((calderBooleanRootAverageR S
      (fun x : ZMod N =>
        ‖∑ k ∈ Finset.range L, (ZMod.stdAddChar x) ^ k‖ ^ 2) : ℝ) : ℂ) =
      ∑ b ∈ Finset.range L, ∑ a ∈ Finset.range L,
        fixedProductBooleanFourierCoeff S hPrime
          ((a : ZMod N) - (b : ZMod N)) := by
  dsimp
  rw [← calderBooleanRootAverageC_ofReal]
  have hpoint :
      (fun x : ZMod (primeSetProduct S) =>
        ((‖∑ k ∈ Finset.range L, (ZMod.stdAddChar x) ^ k‖ ^ 2 : ℝ) : ℂ)) =
      (fun x =>
        ∑ b ∈ Finset.range L, ∑ a ∈ Finset.range L,
          ZMod.stdAddChar
            ((((a : ZMod (primeSetProduct S)) - (b : ZMod (primeSetProduct S)))) * x)) := by
    funext x
    exact calder_fejer_norm_sq_expand x
  rw [hpoint]
  rw [calderBooleanRootAverageC_sum]
  apply Finset.sum_congr rfl
  intro b hb
  rw [calderBooleanRootAverageC_sum]
  apply Finset.sum_congr rfl
  intro a ha
  exact calderBooleanRootAverageC_stdAddChar S hPrime
    ((a : ZMod (primeSetProduct S)) - (b : ZMod (primeSetProduct S)))


noncomputable def fixedProductBooleanRootIntervalDiscrepancy
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (r : ℕ) : ℝ :=
  ((2 : ℝ) ^ S.card)⁻¹ *
      ∑ A ∈ S.powerset,
        (if (fixedProductCRTIdempotentNat S A) % (primeSetProduct S) < r then 1 else 0)
    - (r : ℝ) / (primeSetProduct S : ℝ)

noncomputable def fixedProductBooleanFrequencyMass
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (j : ℕ) : ℝ :=
  ‖fixedProductBooleanFourierCoeff S hPrime
      (j : ZMod (primeSetProduct S))‖

lemma calder_booleanFourierCoeff_zero
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime) :
    fixedProductBooleanFourierCoeff S hPrime
      (0 : ZMod (primeSetProduct S)) = 1 := by
  letI : NeZero (primeSetProduct S) := ⟨(primeSetProduct_pos hPrime).ne'⟩
  unfold fixedProductBooleanFourierCoeff
  simp only [zero_mul, AddChar.map_zero_eq_one, Finset.sum_const, Finset.card_powerset,
    nsmul_eq_mul, Nat.cast_pow, Nat.cast_ofNat]
  have hpow : (2 : ℂ) ^ S.card ≠ 0 := pow_ne_zero _ (by norm_num)
  field_simp [hpow]

lemma calder_sum_range_succ_shift_eq_Icc
    (f : ℕ → ℝ) (n : ℕ) :
    (∑ k ∈ Finset.range n, f (k + 1)) =
      ∑ j ∈ Finset.Icc 1 n, f j := by
  induction n with
  | zero => simp
  | succ n ih =>
      rw [Finset.sum_range_succ, Finset.sum_Icc_succ_top (by omega)]
      rw [ih]

lemma calder_sum_Icc_mono_of_nonneg
    (f : ℕ → ℝ) {b J : ℕ} (hbJ : b ≤ J)
    (hf : ∀ j ∈ Finset.Icc 1 J, 0 ≤ f j) :
    (∑ j ∈ Finset.Icc 1 b, f j) ≤
      ∑ j ∈ Finset.Icc 1 J, f j := by
  apply Finset.sum_le_sum_of_subset_of_nonneg
  · intro j hj
    exact Finset.mem_Icc.mpr
      ⟨(Finset.mem_Icc.mp hj).1, (Finset.mem_Icc.mp hj).2.trans hbJ⟩
  · intro j hjJ hjnot
    exact hf j hjJ

lemma calder_booleanCoeff_row_norm_le
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (J b : ℕ) (hb : b < J + 1) :
    let N := primeSetProduct S
    (∑ a ∈ Finset.range (J + 1),
      ‖fixedProductBooleanFourierCoeff S hPrime
        ((a : ZMod N) - (b : ZMod N))‖) ≤
      1 + 2 * ∑ j ∈ Finset.Icc 1 J,
        fixedProductBooleanFrequencyMass S hPrime j := by
  dsimp
  letI : NeZero (primeSetProduct S) := ⟨(primeSetProduct_pos hPrime).ne'⟩
  let F : ℕ → ℝ := fun j => fixedProductBooleanFrequencyMass S hPrime j
  let g : ℕ → ℝ := fun a =>
    ‖fixedProductBooleanFourierCoeff S hPrime
      ((a : ZMod (primeSetProduct S)) - (b : ZMod (primeSetProduct S)))‖
  have hbJ : b ≤ J := by omega
  have hF0 : ∀ j ∈ Finset.Icc 1 J, 0 ≤ F j := by
    intro j hj
    exact norm_nonneg _
  have hdiag : g b = 1 := by
    dsimp [g]
    rw [sub_self, calder_booleanFourierCoeff_zero]
    norm_num
  have hleft :
      (∑ a ∈ Finset.range b, g a) ≤
        ∑ j ∈ Finset.Icc 1 J, F j := by
    calc
      (∑ a ∈ Finset.range b, g a) =
          ∑ a ∈ Finset.range b, F (b - a) := by
            apply Finset.sum_congr rfl
            intro a ha
            have hab : a < b := Finset.mem_range.mp ha
            dsimp [g, F, fixedProductBooleanFrequencyMass]
            have hcast :
                ((b - a : ℕ) : ZMod (primeSetProduct S)) =
                  (b : ZMod (primeSetProduct S)) -
                    (a : ZMod (primeSetProduct S)) := by
              rw [Nat.cast_sub (Nat.le_of_lt hab)]
            have hneg :
                (a : ZMod (primeSetProduct S)) -
                    (b : ZMod (primeSetProduct S)) =
                  -((b - a : ℕ) : ZMod (primeSetProduct S)) := by
              rw [hcast]
              ring
            rw [hneg, calder_booleanFrequencyMass_neg]
      _ = ∑ k ∈ Finset.range b, F (k + 1) := by
            rw [← Finset.sum_range_reflect (fun k => F (k + 1)) b]
            apply Finset.sum_congr rfl
            intro a ha
            congr 1
            have hab : a < b := Finset.mem_range.mp ha
            omega
      _ = ∑ j ∈ Finset.Icc 1 b, F j :=
            calder_sum_range_succ_shift_eq_Icc F b
      _ ≤ ∑ j ∈ Finset.Icc 1 J, F j :=
            calder_sum_Icc_mono_of_nonneg F hbJ hF0
  have hright :
      (∑ k ∈ Finset.range (J - b), g (b + (1 + k))) ≤
        ∑ j ∈ Finset.Icc 1 J, F j := by
    calc
      (∑ k ∈ Finset.range (J - b), g (b + (1 + k))) =
          ∑ k ∈ Finset.range (J - b), F (k + 1) := by
            apply Finset.sum_congr rfl
            intro k hk
            have hklt : k < J - b := Finset.mem_range.mp hk
            dsimp [g, F, fixedProductBooleanFrequencyMass]
            simp only [Nat.cast_add, Nat.cast_one]
            congr 2
            ring
      _ = ∑ j ∈ Finset.Icc 1 (J - b), F j :=
            calder_sum_range_succ_shift_eq_Icc F (J - b)
      _ ≤ ∑ j ∈ Finset.Icc 1 J, F j := by
            exact calder_sum_Icc_mono_of_nonneg F (Nat.sub_le J b) hF0
  have hsplit :
      (∑ a ∈ Finset.range (J + 1), g a) =
        (∑ a ∈ Finset.range b, g a) + g b +
          ∑ k ∈ Finset.range (J - b), g (b + (1 + k)) := by
    rw [show J + 1 = b + (1 + (J - b)) by omega]
    rw [Finset.sum_range_add, Finset.sum_range_add]
    simp
    ring
  rw [show (∑ a ∈ Finset.range (J + 1),
      ‖fixedProductBooleanFourierCoeff S hPrime
        ((a : ZMod (primeSetProduct S)) - (b : ZMod (primeSetProduct S)))‖) =
      ∑ a ∈ Finset.range (J + 1), g a by rfl]
  rw [hsplit, hdiag]
  dsimp [F] at hleft hright ⊢
  linarith


lemma calderBooleanRootAverageC_const_mul
    (S : Finset ℕ) (c : ℂ)
    (f : ZMod (primeSetProduct S) → ℂ) :
    calderBooleanRootAverageC S (fun x => c * f x) =
      c * calderBooleanRootAverageC S f := by
  unfold calderBooleanRootAverageC
  rw [← Finset.mul_sum]
  rw [Algebra.smul_def, Algebra.smul_def]
  ring

lemma calderBooleanRootAverageC_stdAddChar_translate
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (t c : ZMod (primeSetProduct S)) :
    calderBooleanRootAverageC S
      (fun x => ZMod.stdAddChar (t * (x - c))) =
      ZMod.stdAddChar (-(t * c)) *
        fixedProductBooleanFourierCoeff S hPrime t := by
  have hfun :
      (fun x : ZMod (primeSetProduct S) =>
        ZMod.stdAddChar (t * (x - c))) =
      (fun x =>
        ZMod.stdAddChar (-(t * c)) *
          ZMod.stdAddChar (t * x)) := by
    funext x
    rw [← AddChar.map_add_eq_mul]
    congr 1
    ring
  rw [hfun, calderBooleanRootAverageC_const_mul,
    calderBooleanRootAverageC_stdAddChar]

lemma calder_booleanAverage_fejer_normsq_translate_eq_double
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (L : ℕ) (c : ZMod (primeSetProduct S)) :
    ((calderBooleanRootAverageR S
      (fun x : ZMod (primeSetProduct S) =>
        ‖∑ k ∈ Finset.range L, (ZMod.stdAddChar (x - c)) ^ k‖ ^ 2) : ℝ) : ℂ) =
      ∑ b ∈ Finset.range L, ∑ a ∈ Finset.range L,
        ZMod.stdAddChar
          (-(((a : ZMod (primeSetProduct S)) -
              (b : ZMod (primeSetProduct S))) * c)) *
        fixedProductBooleanFourierCoeff S hPrime
          ((a : ZMod (primeSetProduct S)) - (b : ZMod (primeSetProduct S))) := by
  rw [← calderBooleanRootAverageC_ofReal]
  have hpoint :
      (fun x : ZMod (primeSetProduct S) =>
        ((‖∑ k ∈ Finset.range L, (ZMod.stdAddChar (x - c)) ^ k‖ ^ 2 : ℝ) : ℂ)) =
      (fun x =>
        ∑ b ∈ Finset.range L, ∑ a ∈ Finset.range L,
          ZMod.stdAddChar
            ((((a : ZMod (primeSetProduct S)) -
              (b : ZMod (primeSetProduct S)))) * (x - c))) := by
    funext x
    exact calder_fejer_norm_sq_expand (x - c)
  rw [hpoint, calderBooleanRootAverageC_sum]
  apply Finset.sum_congr rfl
  intro b hb
  rw [calderBooleanRootAverageC_sum]
  apply Finset.sum_congr rfl
  intro a ha
  exact calderBooleanRootAverageC_stdAddChar_translate S hPrime
    ((a : ZMod (primeSetProduct S)) - (b : ZMod (primeSetProduct S))) c

lemma calder_booleanAverage_fejer_normsq_translate_le
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (J : ℕ) (c : ZMod (primeSetProduct S)) :
    calderBooleanRootAverageR S
      (fun x : ZMod (primeSetProduct S) =>
        ‖∑ k ∈ Finset.range (J + 1), (ZMod.stdAddChar (x - c)) ^ k‖ ^ 2) ≤
      (J + 1 : ℝ) *
        (1 + 2 * ∑ j ∈ Finset.Icc 1 J,
          fixedProductBooleanFrequencyMass S hPrime j) := by
  let A : ℝ :=
    calderBooleanRootAverageR S
      (fun x : ZMod (primeSetProduct S) =>
        ‖∑ k ∈ Finset.range (J + 1), (ZMod.stdAddChar (x - c)) ^ k‖ ^ 2)
  let H : ℝ := ∑ j ∈ Finset.Icc 1 J,
    fixedProductBooleanFrequencyMass S hPrime j
  have hA0 : 0 ≤ A := by
    dsimp [A, calderBooleanRootAverageR]
    positivity
  have heq := calder_booleanAverage_fejer_normsq_translate_eq_double
    S hPrime (J + 1) c
  have hnorm :
      A = ‖(A : ℂ)‖ := by
    rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg hA0]
  change A ≤ ((J : ℝ) + 1) * (1 + 2 * H)
  rw [hnorm]
  rw [show (A : ℂ) =
      ∑ b ∈ Finset.range (J + 1), ∑ a ∈ Finset.range (J + 1),
        ZMod.stdAddChar
          (-(((a : ZMod (primeSetProduct S)) -
              (b : ZMod (primeSetProduct S))) * c)) *
        fixedProductBooleanFourierCoeff S hPrime
          ((a : ZMod (primeSetProduct S)) - (b : ZMod (primeSetProduct S))) by
      simpa [A] using heq]
  calc
    ‖∑ b ∈ Finset.range (J + 1), ∑ a ∈ Finset.range (J + 1),
        ZMod.stdAddChar
          (-(((a : ZMod (primeSetProduct S)) -
              (b : ZMod (primeSetProduct S))) * c)) *
        fixedProductBooleanFourierCoeff S hPrime
          ((a : ZMod (primeSetProduct S)) - (b : ZMod (primeSetProduct S)))‖
      ≤ ∑ b ∈ Finset.range (J + 1),
          ‖∑ a ∈ Finset.range (J + 1),
            ZMod.stdAddChar
              (-(((a : ZMod (primeSetProduct S)) -
                  (b : ZMod (primeSetProduct S))) * c)) *
            fixedProductBooleanFourierCoeff S hPrime
              ((a : ZMod (primeSetProduct S)) - (b : ZMod (primeSetProduct S)))‖ := by
        exact norm_sum_le _ _
    _ ≤ ∑ b ∈ Finset.range (J + 1),
          ∑ a ∈ Finset.range (J + 1),
            ‖fixedProductBooleanFourierCoeff S hPrime
              ((a : ZMod (primeSetProduct S)) - (b : ZMod (primeSetProduct S)))‖ := by
        apply Finset.sum_le_sum
        intro b hb
        calc
          ‖∑ a ∈ Finset.range (J + 1),
              ZMod.stdAddChar
                (-(((a : ZMod (primeSetProduct S)) -
                    (b : ZMod (primeSetProduct S))) * c)) *
              fixedProductBooleanFourierCoeff S hPrime
                ((a : ZMod (primeSetProduct S)) - (b : ZMod (primeSetProduct S)))‖
            ≤ ∑ a ∈ Finset.range (J + 1),
                ‖ZMod.stdAddChar
                    (-(((a : ZMod (primeSetProduct S)) -
                        (b : ZMod (primeSetProduct S))) * c)) *
                  fixedProductBooleanFourierCoeff S hPrime
                    ((a : ZMod (primeSetProduct S)) -
                      (b : ZMod (primeSetProduct S)))‖ := norm_sum_le _ _
          _ = ∑ a ∈ Finset.range (J + 1),
                ‖fixedProductBooleanFourierCoeff S hPrime
                  ((a : ZMod (primeSetProduct S)) -
                    (b : ZMod (primeSetProduct S)))‖ := by
              apply Finset.sum_congr rfl
              intro a ha
              rw [norm_mul, norm_stdAddChar_eq_one, one_mul]
    _ ≤ ∑ b ∈ Finset.range (J + 1), (1 + 2 * H) := by
        apply Finset.sum_le_sum
        intro b hb
        have hb' : b < J + 1 := Finset.mem_range.mp hb
        simpa [H] using calder_booleanCoeff_row_norm_le S hPrime J b hb'
    _ = (J + 1 : ℝ) * (1 + 2 * H) := by
        simp [nsmul_eq_mul]
        ring
    _ = _ := by ring


lemma calderBooleanRootAverageR_const_mul
    (S : Finset ℕ) (c : ℝ)
    (f : ZMod (primeSetProduct S) → ℝ) :
    calderBooleanRootAverageR S (fun x => c * f x) =
      c * calderBooleanRootAverageR S f := by
  unfold calderBooleanRootAverageR
  rw [← Finset.mul_sum]
  ring

lemma calderBooleanRootAverageR_neg
    (S : Finset ℕ) (f : ZMod (primeSetProduct S) → ℝ) :
    calderBooleanRootAverageR S (fun x => - f x) =
      - calderBooleanRootAverageR S f := by
  simpa using calderBooleanRootAverageR_const_mul S (-1) f

lemma calderBooleanRootAverageR_sum
    (S : Finset ℕ) {ι : Type} (T : Finset ι)
    (f : ι → ZMod (primeSetProduct S) → ℝ) :
    calderBooleanRootAverageR S (fun x => ∑ i ∈ T, f i x) =
      ∑ i ∈ T, calderBooleanRootAverageR S (f i) := by
  classical
  induction T using Finset.induction_on with
  | empty => simp [calderBooleanRootAverageR]
  | @insert i T hi ih =>
      simp only [Finset.sum_insert hi]
      rw [calderBooleanRootAverageR_add, ih]

lemma calderBooleanRootAverageR_stdAddChar_translate_im
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (t c : ZMod (primeSetProduct S)) :
    calderBooleanRootAverageR S
      (fun x => (ZMod.stdAddChar (t * (x - c))).im) =
      (ZMod.stdAddChar (-(t * c)) *
        fixedProductBooleanFourierCoeff S hPrime t).im := by
  rw [calderBooleanRootAverageR_im]
  rw [calderBooleanRootAverageC_stdAddChar_translate]

lemma calder_booleanAverage_h3VaalerApprox_translate_eq
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (J : ℕ) (c : ZMod (primeSetProduct S)) :
    calderBooleanRootAverageR S
      (fun x : ZMod (primeSetProduct S) =>
        h3VaalerApprox (primeSetProduct S) J (x - c)) =
      - ∑ j ∈ Finset.Icc 1 J,
        (h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
          (ZMod.stdAddChar (-((j : ZMod (primeSetProduct S)) * c)) *
            fixedProductBooleanFourierCoeff S hPrime
              (j : ZMod (primeSetProduct S))).im := by
  unfold h3VaalerApprox
  rw [calderBooleanRootAverageR_neg]
  rw [calderBooleanRootAverageR_sum]
  congr 1
  apply Finset.sum_congr rfl
  intro j hj
  rw [calderBooleanRootAverageR_const_mul]
  rw [calderBooleanRootAverageR_stdAddChar_translate_im]

lemma calder_vaaler_weight_le_one_div
    {J j : ℕ} (hj : j ∈ Finset.Icc 1 J) :
    0 ≤ h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ)) ∧
    h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ)) ≤ 1 / (j : ℝ) := by
  have hj1 : 1 ≤ j := (Finset.mem_Icc.mp hj).1
  have hjpos : (0 : ℝ) < (j : ℝ) := by positivity
  have hhat0 := h3VaalerJHat_nonneg J (j : ℤ)
  have hhat1 := h3VaalerJHat_le_one J (j : ℤ)
  have hpi1 : (1 : ℝ) ≤ Real.pi := by linarith [Real.pi_gt_three]
  constructor
  · exact div_nonneg hhat0 (by positivity)
  · have hden : (j : ℝ) ≤ Real.pi * (j : ℝ) := by
      nlinarith
    have hinv : 1 / (Real.pi * (j : ℝ)) ≤ 1 / (j : ℝ) :=
      one_div_le_one_div_of_le hjpos hden
    calc
      h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))
          ≤ 1 / (Real.pi * (j : ℝ)) := by
            rw [div_eq_mul_inv, div_eq_mul_inv]
            gcongr
      _ ≤ 1 / (j : ℝ) := hinv

lemma calder_abs_booleanAverage_h3VaalerApprox_translate_le
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (J : ℕ) (c : ZMod (primeSetProduct S)) :
    |calderBooleanRootAverageR S
      (fun x : ZMod (primeSetProduct S) =>
        h3VaalerApprox (primeSetProduct S) J (x - c))| ≤
      ∑ j ∈ Finset.Icc 1 J,
        ‖fixedProductBooleanFourierCoeff S hPrime
          (j : ZMod (primeSetProduct S))‖ / (j : ℝ) := by
  rw [calder_booleanAverage_h3VaalerApprox_translate_eq S hPrime J c]
  rw [abs_neg]
  calc
    |∑ j ∈ Finset.Icc 1 J,
        (h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
          (ZMod.stdAddChar (-((j : ZMod (primeSetProduct S)) * c)) *
            fixedProductBooleanFourierCoeff S hPrime
              (j : ZMod (primeSetProduct S))).im|
      ≤ ∑ j ∈ Finset.Icc 1 J,
          |(h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
            (ZMod.stdAddChar (-((j : ZMod (primeSetProduct S)) * c)) *
              fixedProductBooleanFourierCoeff S hPrime
                (j : ZMod (primeSetProduct S))).im| := by
        exact Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ j ∈ Finset.Icc 1 J,
          ‖fixedProductBooleanFourierCoeff S hPrime
                (j : ZMod (primeSetProduct S))‖ / (j : ℝ) := by
        apply Finset.sum_le_sum
        intro j hj
        have hw := calder_vaaler_weight_le_one_div hj
        have hj1 : 1 ≤ j := (Finset.mem_Icc.mp hj).1
        have hjpos : (0 : ℝ) < (j : ℝ) := by positivity
        have him :
            |(ZMod.stdAddChar (-((j : ZMod (primeSetProduct S)) * c)) *
              fixedProductBooleanFourierCoeff S hPrime
                (j : ZMod (primeSetProduct S))).im| ≤
              ‖fixedProductBooleanFourierCoeff S hPrime
                (j : ZMod (primeSetProduct S))‖ := by
          calc
            |(ZMod.stdAddChar (-((j : ZMod (primeSetProduct S)) * c)) *
                fixedProductBooleanFourierCoeff S hPrime
                  (j : ZMod (primeSetProduct S))).im|
              ≤ ‖ZMod.stdAddChar (-((j : ZMod (primeSetProduct S)) * c)) *
                fixedProductBooleanFourierCoeff S hPrime
                  (j : ZMod (primeSetProduct S))‖ :=
                Complex.abs_im_le_norm _
            _ = ‖fixedProductBooleanFourierCoeff S hPrime
                (j : ZMod (primeSetProduct S))‖ := by
                rw [norm_mul, norm_stdAddChar_eq_one, one_mul]
        rw [abs_mul, abs_of_nonneg hw.1]
        calc
          (h3VaalerJHat J (j : ℤ) / (Real.pi * (j : ℝ))) *
              |(ZMod.stdAddChar (-((j : ZMod (primeSetProduct S)) * c)) *
                fixedProductBooleanFourierCoeff S hPrime
                  (j : ZMod (primeSetProduct S))).im|
            ≤ (1 / (j : ℝ)) *
                ‖fixedProductBooleanFourierCoeff S hPrime
                (j : ZMod (primeSetProduct S))‖ := by
              exact mul_le_mul hw.2 him (abs_nonneg _) (by positivity)
          _ = ‖fixedProductBooleanFourierCoeff S hPrime
                (j : ZMod (primeSetProduct S))‖ / (j : ℝ) := by
              ring


lemma calderBooleanRootAverageR_mono
    (S : Finset ℕ)
    {f g : ZMod (primeSetProduct S) → ℝ}
    (hfg : ∀ x, f x ≤ g x) :
    calderBooleanRootAverageR S f ≤ calderBooleanRootAverageR S g := by
  unfold calderBooleanRootAverageR
  have hscale : 0 ≤ ((2 : ℝ) ^ S.card)⁻¹ := by positivity
  gcongr with A hA
  exact hfg _

lemma calder_booleanAverage_h3VaalerError_translate_le
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (J : ℕ) (c : ZMod (primeSetProduct S)) :
    calderBooleanRootAverageR S
      (fun x : ZMod (primeSetProduct S) =>
        h3VaalerError (primeSetProduct S) J (x - c)) ≤
      (1 + 2 * ∑ j ∈ Finset.Icc 1 J,
        fixedProductBooleanFrequencyMass S hPrime j) /
        (2 * ((J + 1 : ℕ) : ℝ)) := by
  let M : ℝ := ∑ j ∈ Finset.Icc 1 J,
    fixedProductBooleanFrequencyMass S hPrime j
  have hN :=
    calder_booleanAverage_fejer_normsq_translate_le S hPrime J c
  have hJpos : (0 : ℝ) < ((J + 1 : ℕ) : ℝ) := by positivity
  unfold h3VaalerError h3FejerKernel
  rw [calderBooleanRootAverageR_const_mul]
  rw [calderBooleanRootAverageR_const_mul]
  calc
    (1 / (2 * ((J + 1 : ℕ) : ℝ))) *
        ((((J + 1 : ℕ) : ℝ))⁻¹ *
          calderBooleanRootAverageR S
            (fun x : ZMod (primeSetProduct S) =>
              ‖∑ k ∈ Finset.range (J + 1),
                (ZMod.stdAddChar (x - c)) ^ k‖ ^ 2))
      ≤ (1 / (2 * ((J + 1 : ℕ) : ℝ))) *
          ((((J + 1 : ℕ) : ℝ))⁻¹ *
            (((J + 1 : ℕ) : ℝ) * (1 + 2 * M))) := by
              gcongr
              simpa [M] using hN
    _ = (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) := by
          field_simp [hJpos.ne']
    _ = (1 + 2 * ∑ j ∈ Finset.Icc 1 J,
        fixedProductBooleanFrequencyMass S hPrime j) /
        (2 * ((J + 1 : ℕ) : ℝ)) := by rfl

lemma calder_discrepancy_eq_rootAverage_indicator_sub
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (r : ℕ) :
    fixedProductBooleanRootIntervalDiscrepancy S hPrime r =
      calderBooleanRootAverageR S
        (fun x : ZMod (primeSetProduct S) =>
          h3HalfOpenIntervalIndicator r x) -
        (r : ℝ) / (primeSetProduct S : ℝ) := by
  unfold fixedProductBooleanRootIntervalDiscrepancy
  unfold calderBooleanRootAverageR h3HalfOpenIntervalIndicator
  simp only [ZMod.val_natCast]

lemma fixedProductBooleanRootInterval_erdosTuran_of_grid_error
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (r J : ℕ)
    (hr : r < primeSetProduct S)
    (hJ : 1 ≤ J)
    (hGrid : @H3VaalerGridErrorSpec (primeSetProduct S) J
      ⟨(primeSetProduct_pos hPrime).ne'⟩) :
    |fixedProductBooleanRootIntervalDiscrepancy S hPrime r| ≤
      4 / (J : ℝ) +
        4 * ∑ j ∈ Finset.Icc 1 J,
          fixedProductBooleanFrequencyMass S hPrime j / (j : ℝ) := by
  let N := primeSetProduct S
  letI : NeZero N := ⟨(primeSetProduct_pos hPrime).ne'⟩
  let R : ZMod N := (r : ZMod N)
  let H : ℝ := ∑ j ∈ Finset.Icc 1 J,
    fixedProductBooleanFrequencyMass S hPrime j / (j : ℝ)
  let M : ℝ := ∑ j ∈ Finset.Icc 1 J,
    fixedProductBooleanFrequencyMass S hPrime j
  have hH0 : 0 ≤ H := by
    dsimp [H]
    apply Finset.sum_nonneg
    intro j hj
    exact div_nonneg (norm_nonneg _) (by positivity)
  have hM0 : 0 ≤ M := by
    dsimp [M]
    apply Finset.sum_nonneg
    intro j hj
    exact norm_nonneg _
  have hJpos : (0 : ℝ) < (J : ℝ) := by
    exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hJ)
  have hJ1pos : (0 : ℝ) < ((J + 1 : ℕ) : ℝ) := by positivity
  have hInd :
      fixedProductBooleanRootIntervalDiscrepancy S hPrime r =
        calderBooleanRootAverageR S
          (fun x : ZMod N => h3HalfOpenIntervalIndicator r x) -
          (r : ℝ) / (N : ℝ) := by
    simpa [N] using calder_discrepancy_eq_rootAverage_indicator_sub S hPrime r
  have hSand : ∀ x : ZMod N,
      h3IntervalLowerMinorant N r J x ≤ h3HalfOpenIntervalIndicator r x ∧
      h3HalfOpenIntervalIndicator r x ≤ h3IntervalUpperMajorant N r J x := by
    intro x
    exact fixedProductBooleanRootInterval_selberg_majorant_of_grid_error
      (N := N) (r := r) (J := J) (by simpa [N] using hr) hGrid x
  have hLow := calderBooleanRootAverageR_mono S (fun x => (hSand x).1)
  have hUp := calderBooleanRootAverageR_mono S (fun x => (hSand x).2)
  have hSawR :=
    calder_abs_booleanAverage_h3VaalerApprox_translate_le
      S hPrime J R
  have hSaw0 :=
    calder_abs_booleanAverage_h3VaalerApprox_translate_le
      S hPrime J (0 : ZMod N)
  have hErrR :=
    calder_booleanAverage_h3VaalerError_translate_le
      S hPrime J R
  have hErr0 :=
    calder_booleanAverage_h3VaalerError_translate_le
      S hPrime J (0 : ZMod N)
  have hA0 :
      calderBooleanRootAverageR S
        (fun x : ZMod N => h3VaalerApprox N J x) =
      calderBooleanRootAverageR S
        (fun x : ZMod N => h3VaalerApprox N J (x - (0 : ZMod N))) := by
    congr 1
    funext x
    simp
  rw [← hA0] at hSaw0
  have hE0 :
      calderBooleanRootAverageR S
        (fun x : ZMod N => h3VaalerError N J x) =
      calderBooleanRootAverageR S
        (fun x : ZMod N => h3VaalerError N J (x - (0 : ZMod N))) := by
    congr 1
    funext x
    simp
  rw [← hE0] at hErr0
  have hM_to_H :
      M / ((J + 1 : ℕ) : ℝ) ≤ H := by
    have hrewrite :
        M / ((J + 1 : ℕ) : ℝ) =
          ∑ j ∈ Finset.Icc 1 J,
            fixedProductBooleanFrequencyMass S hPrime j /
              ((J + 1 : ℕ) : ℝ) := by
      dsimp [M]
      rw [Finset.sum_div]
    rw [hrewrite]
    dsimp [H]
    apply Finset.sum_le_sum
    intro j hj
    have hjJ : j ≤ J := (Finset.mem_Icc.mp hj).2
    have hjpos : (0 : ℝ) < (j : ℝ) := by
      have hj1 : 1 ≤ j := (Finset.mem_Icc.mp hj).1
      exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hj1)
    have hm0 : 0 ≤ fixedProductBooleanFrequencyMass S hPrime j := norm_nonneg _
    have hden : (j : ℝ) ≤ ((J + 1 : ℕ) : ℝ) := by
      exact_mod_cast Nat.le_succ_of_le hjJ
    have hinv :
        1 / ((J + 1 : ℕ) : ℝ) ≤ 1 / (j : ℝ) :=
      one_div_le_one_div_of_le hjpos hden
    calc
      fixedProductBooleanFrequencyMass S hPrime j /
          ((J + 1 : ℕ) : ℝ)
        = fixedProductBooleanFrequencyMass S hPrime j *
            (1 / ((J + 1 : ℕ) : ℝ)) := by ring
      _ ≤ fixedProductBooleanFrequencyMass S hPrime j *
            (1 / (j : ℝ)) := mul_le_mul_of_nonneg_left hinv hm0
      _ = fixedProductBooleanFrequencyMass S hPrime j / (j : ℝ) := by ring
  have hErrSum :
      calderBooleanRootAverageR S
          (fun x : ZMod N => h3VaalerError N J (x - R)) +
        calderBooleanRootAverageR S
          (fun x : ZMod N => h3VaalerError N J x) ≤
        1 / ((J + 1 : ℕ) : ℝ) + 2 * H := by
    have hs := add_le_add hErrR hErr0
    have hs' :
        calderBooleanRootAverageR S
            (fun x : ZMod N => h3VaalerError N J (x - R)) +
          calderBooleanRootAverageR S
            (fun x : ZMod N => h3VaalerError N J x) ≤
          (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) +
          (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) := by
      simpa [N, M] using hs
    have hcalc :
        (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) +
          (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) =
          1 / ((J + 1 : ℕ) : ℝ) +
            2 * (M / ((J + 1 : ℕ) : ℝ)) := by
      field_simp [hJ1pos.ne']
      ring
    calc
      calderBooleanRootAverageR S
          (fun x : ZMod N => h3VaalerError N J (x - R)) +
        calderBooleanRootAverageR S
          (fun x : ZMod N => h3VaalerError N J x)
        ≤ (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) +
          (1 + 2 * M) / (2 * ((J + 1 : ℕ) : ℝ)) := hs'
      _ = 1 / ((J + 1 : ℕ) : ℝ) +
            2 * (M / ((J + 1 : ℕ) : ℝ)) := hcalc
      _ ≤ 1 / ((J + 1 : ℕ) : ℝ) + 2 * H := by
            gcongr

  have hSawDiff :
      |calderBooleanRootAverageR S
          (fun x : ZMod N => h3VaalerApprox N J (x - R)) -
        calderBooleanRootAverageR S
          (fun x : ZMod N => h3VaalerApprox N J x)| ≤ 2 * H := by
    calc
      |calderBooleanRootAverageR S
          (fun x : ZMod N => h3VaalerApprox N J (x - R)) -
        calderBooleanRootAverageR S
          (fun x : ZMod N => h3VaalerApprox N J x)|
        ≤ |calderBooleanRootAverageR S
            (fun x : ZMod N => h3VaalerApprox N J (x - R))| +
          |calderBooleanRootAverageR S
            (fun x : ZMod N => h3VaalerApprox N J x)| := abs_sub _ _
      _ ≤ H + H := by
        exact add_le_add (by simpa [N, H, fixedProductBooleanFrequencyMass] using hSawR)
          (by simpa [N, H, fixedProductBooleanFrequencyMass] using hSaw0)
      _ = 2 * H := by ring
  have hCenteredUp :
      fixedProductBooleanRootIntervalDiscrepancy S hPrime r ≤
        (calderBooleanRootAverageR S
            (fun x : ZMod N => h3VaalerApprox N J (x - R)) -
          calderBooleanRootAverageR S
            (fun x : ZMod N => h3VaalerApprox N J x)) +
        calderBooleanRootAverageR S
            (fun x : ZMod N => h3VaalerError N J (x - R)) +
        calderBooleanRootAverageR S
            (fun x : ZMod N => h3VaalerError N J x) := by
    rw [hInd]
    have hUp' := hUp
    unfold h3IntervalUpperMajorant h3IntervalUpperCentered at hUp'
    rw [calderBooleanRootAverageR_add] at hUp'
    rw [calderBooleanRootAverageR_add] at hUp'
    rw [calderBooleanRootAverageR_add] at hUp'
    rw [calderBooleanRootAverageR_sub] at hUp'
    rw [calderBooleanRootAverageR_const] at hUp'
    dsimp [R] at hUp' ⊢
    linarith
  have hCenteredLow :
      - fixedProductBooleanRootIntervalDiscrepancy S hPrime r ≤
        -(calderBooleanRootAverageR S
            (fun x : ZMod N => h3VaalerApprox N J (x - R)) -
          calderBooleanRootAverageR S
            (fun x : ZMod N => h3VaalerApprox N J x)) +
        calderBooleanRootAverageR S
            (fun x : ZMod N => h3VaalerError N J (x - R)) +
        calderBooleanRootAverageR S
            (fun x : ZMod N => h3VaalerError N J x) := by
    rw [hInd]
    have hLow' := hLow
    unfold h3IntervalLowerMinorant h3IntervalLowerCentered at hLow'
    rw [calderBooleanRootAverageR_add] at hLow'
    rw [calderBooleanRootAverageR_sub] at hLow'
    rw [calderBooleanRootAverageR_sub] at hLow'
    rw [calderBooleanRootAverageR_sub] at hLow'
    rw [calderBooleanRootAverageR_const] at hLow'
    dsimp [R] at hLow' ⊢
    linarith
  have hCore :
      |fixedProductBooleanRootIntervalDiscrepancy S hPrime r| ≤
        1 / ((J + 1 : ℕ) : ℝ) + 4 * H := by
    rw [abs_le]
    have hSawLower := (abs_le.mp hSawDiff).1
    have hSawUpper := (abs_le.mp hSawDiff).2
    constructor <;> linarith [hCenteredLow, hCenteredUp, hErrSum]

  calc
    |fixedProductBooleanRootIntervalDiscrepancy S hPrime r|
      ≤ 1 / ((J + 1 : ℕ) : ℝ) + 4 * H := hCore
    _ ≤ 4 / (J : ℝ) + 4 * H := by
      have hden : (J : ℝ) ≤ ((J + 1 : ℕ) : ℝ) := by
        exact_mod_cast Nat.le_succ J
      have hinv :
          1 / ((J + 1 : ℕ) : ℝ) ≤ 1 / (J : ℝ) :=
        one_div_le_one_div_of_le hJpos hden
      have hposinv : 0 < 1 / (J : ℝ) := one_div_pos.mpr hJpos
      have h1to4 : 1 / (J : ℝ) ≤ 4 / (J : ℝ) := by
        calc
          1 / (J : ℝ) = 1 * (1 / (J : ℝ)) := by ring
          _ ≤ 4 * (1 / (J : ℝ)) :=
            mul_le_mul_of_nonneg_right (by norm_num) hposinv.le
          _ = 4 / (J : ℝ) := by ring
      exact add_le_add (hinv.trans h1to4) (le_refl (4 * H))
    _ = _ := by rfl

theorem fixedProductBooleanRootInterval_erdosTuran
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (r J : ℕ)
    (hr : r < primeSetProduct S)
    (hJ : 1 ≤ J) :
    |fixedProductBooleanRootIntervalDiscrepancy S hPrime r| ≤
      4 / (J : ℝ) +
        4 * ∑ j ∈ Finset.Icc 1 J,
          fixedProductBooleanFrequencyMass S hPrime j / (j : ℝ) := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  exact fixedProductBooleanRootInterval_erdosTuran_of_grid_error
    S hPrime r J hr hJ
    (h3VaalerGridErrorSpec_holds (primeSetProduct S) J)

#print axioms fixedProductBooleanRootInterval_erdosTuran

#print axioms calder_booleanAverage_h3VaalerError_translate_le
#print axioms fixedProductBooleanRootInterval_erdosTuran_of_grid_error

#print axioms calder_booleanAverage_h3VaalerApprox_translate_eq
#print axioms calder_abs_booleanAverage_h3VaalerApprox_translate_le

#print axioms calderBooleanRootAverageC_stdAddChar_translate
#print axioms calder_booleanAverage_fejer_normsq_translate_le

#print axioms calder_booleanFourierCoeff_zero
#print axioms calder_booleanCoeff_row_norm_le

#print axioms calderBooleanRootAverageC_ofReal
#print axioms calder_booleanAverage_fejer_normsq_eq_double

#print axioms calder_fejer_norm_sq_expand
#print axioms calderBooleanRootAverageC_sum

#print axioms calderBooleanRootAverageR_const
#print axioms calderBooleanRootAverageR_im
#print axioms calderBooleanRootAverageC_stdAddChar

end PaperB.FixedQ
