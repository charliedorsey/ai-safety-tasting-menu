import PaperB.FixedQ.H2EndpointRowBound
import PaperB.FixedQ.H2BooleanDyadicMoments

open scoped BigOperators

namespace PaperB.FixedQ

lemma h2BooleanX0_one_le : 1 ≤ h2BooleanX0 := by
  unfold h2BooleanX0 h2BooleanA0
  have hs0 : 0 ≤ Real.sqrt (101 / 200 : ℝ) := Real.sqrt_nonneg _
  have hs2 : (Real.sqrt (101 / 200 : ℝ)) ^ 2 = (101 / 200 : ℝ) := by
    rw [Real.sq_sqrt]
    norm_num
  nlinarith

noncomputable def h2EndpointDyadicConst (q : ℕ) : ℝ :=
  2 * h2EndpointRowConst q

noncomputable def h2EndpointDyadicShell
    (q A H M : ℕ) : ℝ :=
  ∑ S ∈ h2BooleanDyadicSets q M,
    (ordinaryBooleanFullEndpointAbsTerm q A H S +
      ordinaryBooleanEmptyEndpointAbsTerm q A H S)

lemma h2EndpointRowConst_nonneg (q : ℕ) :
    0 ≤ h2EndpointRowConst q := by
  unfold h2EndpointRowConst fixedQDensityMean fixedQPeriod
  positivity

lemma h2EndpointDyadicConst_nonneg (q : ℕ) :
    0 ≤ h2EndpointDyadicConst q := by
  unfold h2EndpointDyadicConst
  exact mul_nonneg (by norm_num) (h2EndpointRowConst_nonneg q)

lemma ordinaryBooleanFullEndpointAbsTerm_le_rowConst
    {q A H : ℕ} {S : Finset ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H)
    (hActive : ∀ p ∈ S, activeHighPrime q p) :
    ordinaryBooleanFullEndpointAbsTerm q A H S ≤
      finiteOmegaWeightReal S * h2EndpointRowConst q := by
  by_cases hmem : S ∈ activeOrdinaryTwoDimensionalSet q H
  · rw [ordinaryBooleanFullEndpointAbsTerm, Set.indicator_of_mem hmem]
    have hw0 := finiteOmegaWeightReal_nonneg_of_active hActive
    exact mul_le_mul_of_nonneg_left
      (abs_rowDiscrepancy_fixedQLowWeight_full_endpoint_le
        hq hH h2admissible hActive) hw0
  · rw [ordinaryBooleanFullEndpointAbsTerm]
    simp [Set.indicator, hmem]
    exact mul_nonneg
      (finiteOmegaWeightReal_nonneg_of_active hActive)
      (h2EndpointRowConst_nonneg q)

lemma ordinaryBooleanEmptyEndpointAbsTerm_le_rowConst
    {q A H : ℕ} {S : Finset ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H)
    (hActive : ∀ p ∈ S, activeHighPrime q p) :
    ordinaryBooleanEmptyEndpointAbsTerm q A H S ≤
      finiteOmegaWeightReal S * h2EndpointRowConst q := by
  by_cases hmem : S ∈ activeOrdinaryTwoDimensionalSet q H
  · rw [ordinaryBooleanEmptyEndpointAbsTerm, Set.indicator_of_mem hmem]
    have hw0 := finiteOmegaWeightReal_nonneg_of_active hActive
    exact mul_le_mul_of_nonneg_left
      (abs_rowDiscrepancy_fixedQLowWeight_empty_endpoint_le
        hq hH h2admissible hActive) hw0
  · rw [ordinaryBooleanEmptyEndpointAbsTerm]
    simp [Set.indicator, hmem]
    exact mul_nonneg
      (finiteOmegaWeightReal_nonneg_of_active hActive)
      (h2EndpointRowConst_nonneg q)

theorem h2EndpointDyadicShell_le_firstMoment
    {q A H M : ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H) :
    h2EndpointDyadicShell q A H M ≤
      h2EndpointDyadicConst q *
        (∑ S ∈ h2BooleanDyadicSets q M,
          finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) := by
  unfold h2EndpointDyadicShell
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro S hS
  have hActive := h2BooleanDyadicSets_active (q := q) (M := M) hS
  have hF := ordinaryBooleanFullEndpointAbsTerm_le_rowConst
    (q := q) (A := A) (H := H) (S := S)
    hq hH h2admissible hActive
  have hE := ordinaryBooleanEmptyEndpointAbsTerm_le_rowConst
    (q := q) (A := A) (H := H) (S := S)
    hq hH h2admissible hActive
  have hw0 : 0 ≤ finiteOmegaWeightReal S :=
    finiteOmegaWeightReal_nonneg_of_active hActive
  have hpow : (1 : ℝ) ≤ h2BooleanX0 ^ S.card := by
    exact one_le_pow₀ h2BooleanX0_one_le
  unfold h2EndpointDyadicConst
  calc
    ordinaryBooleanFullEndpointAbsTerm q A H S +
        ordinaryBooleanEmptyEndpointAbsTerm q A H S
      ≤ finiteOmegaWeightReal S * h2EndpointRowConst q +
          finiteOmegaWeightReal S * h2EndpointRowConst q :=
        add_le_add hF hE
    _ = (2 * h2EndpointRowConst q) * finiteOmegaWeightReal S := by ring
    _ ≤ (2 * h2EndpointRowConst q) *
          (finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) := by
        have hc0 : 0 ≤ 2 * h2EndpointRowConst q :=
          mul_nonneg (by norm_num) (h2EndpointRowConst_nonneg q)
        apply mul_le_mul_of_nonneg_left _ hc0
        calc
          finiteOmegaWeightReal S = finiteOmegaWeightReal S * 1 := by ring
          _ ≤ finiteOmegaWeightReal S * h2BooleanX0 ^ S.card :=
            mul_le_mul_of_nonneg_left hpow hw0

theorem h2EndpointDyadicShell_log_power
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ M0 : ℕ, ∀ A H M : ℕ,
      0 < H →
      (¬ 2 ∣ q → 2 ∣ H) →
      M0 ≤ M →
      ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
      ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
      h2EndpointDyadicShell q A H M ≤
        C * (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) := by
  rcases h2BooleanFirstTilt_interval_log_power q hq with
    ⟨C1, M0, hfirst⟩
  refine ⟨h2EndpointDyadicConst q * |C1|, max M0 1, ?_⟩
  intro A H M hH h2admissible hM hquarter hqM
  have hM0 : M0 ≤ M := (le_max_left M0 1).trans hM
  have hMpos : 0 < M := by
    have : 1 ≤ M := (le_max_right M0 1).trans hM
    omega
  have hshell := h2EndpointDyadicShell_le_firstMoment
    (q := q) (A := A) (H := H) (M := M) hq hH h2admissible
  have hdy := h2BooleanDyadicFirstMoment_le_interval (q := q) (M := M) hMpos
  have hfirstM := hfirst M hM0 hquarter hqM
  have hC1non : 0 ≤ |C1| := abs_nonneg _
  have htilt0 :
      0 ≤ ∑ n ∈ Finset.Ioc M (2 * M),
        h2BooleanTiltLift q h2BooleanFirstTilt n := by
    apply Finset.sum_nonneg
    intro n hn
    exact h2BooleanTiltLift_nonneg q _ h2BooleanFirstTilt_nonneg
  have hC1 :
      (∑ n ∈ Finset.Ioc M (2 * M),
        h2BooleanTiltLift q h2BooleanFirstTilt n) ≤
      |C1| * (M : ℝ) *
        (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) := by
    exact hfirstM.trans (by
      gcongr
      exact le_abs_self C1)
  have hMcast : (0 : ℝ) < M := by exact_mod_cast hMpos
  have hmoment :
      (∑ S ∈ h2BooleanDyadicSets q M,
        finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) ≤
      |C1| *
        (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) := by
    calc
      _ ≤ (M : ℝ)⁻¹ *
          (∑ n ∈ Finset.Ioc M (2 * M),
            h2BooleanTiltLift q h2BooleanFirstTilt n) := hdy
      _ ≤ (M : ℝ)⁻¹ *
          (|C1| * (M : ℝ) *
            (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1)) := by
          gcongr
      _ = |C1| *
          (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) := by
          field_simp [hMcast.ne']
  calc
    h2EndpointDyadicShell q A H M
      ≤ h2EndpointDyadicConst q *
          (∑ S ∈ h2BooleanDyadicSets q M,
            finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) := hshell
    _ ≤ h2EndpointDyadicConst q *
          (|C1| *
            (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1)) := by
          exact mul_le_mul_of_nonneg_left hmoment
            (h2EndpointDyadicConst_nonneg q)
    _ = (h2EndpointDyadicConst q * |C1|) *
          (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) := by ring

#print axioms h2BooleanX0_one_le
#print axioms h2EndpointDyadicShell_le_firstMoment
#print axioms h2EndpointDyadicShell_log_power

end PaperB.FixedQ
