import PaperB.FixedQ.SignedForbiddenExactNaturalDecomposition
import PaperB.FixedQ.SignedForbiddenCompletedMainPrincipalBridge

namespace PaperB.FixedQ

/-- Exact terminal-facing bookkeeping once the moderate Vaaler-main aggregate
has been identified with its centered reciprocal-pair part plus signed mean.
No estimate occurs here. -/
theorem signedForbiddenCompletedMainAggregate_exact_decomposition_of_vaalerMain_split
    {q a h : ℕ}
    (hq : 0 < q) (ha : q.Coprime a) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h)
    (centered signedMean : ℝ)
    (hMainSplit :
      cStarReal q h *
          signedForbiddenCompletedModerateVaalerMainAggregate q a h =
        centered + signedMean) :
    cStarReal q h * signedForbiddenCompletedMainAggregate q a h -
        signedMainB1Principal q (h / 2) =
      centered +
        (signedMean - signedMainB1Principal q (h / 2)) +
        (cStarReal q h *
          signedForbiddenCompletedVaalerResidualAggregate q a h) +
        (cStarReal q h *
          signedForbiddenCompletedNaturalFarTailAggregate q a h) := by
  rw [signedForbiddenCompletedMainAggregate_eq_vaalerMain_add_residual_add_farTail
    hq ha hh h2]
  rw [mul_add, mul_add]
  rw [hMainSplit]
  ring

#print axioms signedForbiddenCompletedMainAggregate_exact_decomposition_of_vaalerMain_split

/-- Pointwise signed Vaaler residual is controlled by the existing unsigned
Vaaler error majorant; this records the exact signed object used by the
aggregate decomposition without identifying it with the majorant. -/
theorem abs_sourceForbiddenNaturalVaalerResidual_le_error
    {q a H D m J : ℕ}
    (hq : 0 < q)
    (h2 : ¬ 2 ∣ q → 2 ∣ H) :
    |sourceForbiddenNaturalVaalerResidual q a H D m J| ≤
      sourceForbiddenNaturalVaalerError q a H D m J := by
  unfold sourceForbiddenNaturalVaalerResidual
  exact sourceForbiddenBooleanNaturalTerm_sub_vaalerMain_abs_le_error
    hq h2

#print axioms abs_sourceForbiddenNaturalVaalerResidual_le_error

end PaperB.FixedQ
