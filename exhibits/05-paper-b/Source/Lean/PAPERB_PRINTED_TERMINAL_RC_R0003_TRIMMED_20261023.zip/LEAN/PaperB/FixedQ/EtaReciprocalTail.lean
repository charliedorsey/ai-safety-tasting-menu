import PaperB.FixedQ.EtaLinearMean
import PaperB.FixedQ.OneDimensionalFamilyPartition
import Mathlib.Algebra.BigOperators.Module

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def etaReciprocalTerm (q n : ℕ) : ℝ :=
  etaArithmetic q n / (n : ℝ)

@[simp] theorem etaReciprocalTerm_zero (q : ℕ) :
    etaReciprocalTerm q 0 = 0 := by
  simp [etaReciprocalTerm, etaArithmetic]

@[simp] theorem etaReciprocalTerm_one (q : ℕ) :
    etaReciprocalTerm q 1 = 1 := by
  simp [etaReciprocalTerm, etaArithmetic,
    petermannSupportedArithmetic, petermannSupportedCoeff]

theorem etaReciprocalTerm_eq_etaCoeff_div
    (q n : ℕ) :
    etaReciprocalTerm q n = etaCoeff q n / (n : ℝ) := by
  simp [etaReciprocalTerm, etaArithmetic_apply]

theorem etaReciprocalTerm_mul_of_coprime
    (q : ℕ) {m n : ℕ} (hcop : m.Coprime n) :
    etaReciprocalTerm q (m * n) =
      etaReciprocalTerm q m * etaReciprocalTerm q n := by
  by_cases hm0 : m = 0
  · subst m
    have hn1 : n = 1 := by simpa using hcop
    subst n
    simp
  · by_cases hn0 : n = 0
    · subst n
      have hm1 : m = 1 := by simpa using hcop
      subst m
      simp
    · unfold etaReciprocalTerm
      rw [(etaArithmetic_multiplicative q).map_mul_of_coprime hcop]
      push_cast
      have hmR : (m : ℝ) ≠ 0 := by exact_mod_cast hm0
      have hnR : (n : ℝ) ≠ 0 := by exact_mod_cast hn0
      field_simp [hmR, hnR]

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem etaReciprocalTerm_prime_active
    (q : ℕ) {p : ℕ} (hp : p.Prime) (hcop : p.Coprime (6 * q)) :
    etaReciprocalTerm q p =
      1 / ((p : ℝ) * ((p : ℝ) - 2)) := by
  unfold etaReciprocalTerm
  have hlocal :=
    petermannSupportedArithmetic_prime_pow q petermannB
      (p := p) (i := 1) hp
  have hcoeff : etaArithmetic q p = petermannB p := by
    change petermannSupportedArithmetic q petermannB p = petermannB p
    have h := hlocal
    simp at h
    rw [if_pos hcop] at h
    exact h
  rw [hcoeff]
  unfold petermannB
  have hpR : (p : ℝ) ≠ 0 := by exact_mod_cast hp.ne_zero
  field_simp [hpR]

theorem etaReciprocalTerm_prime_inactive
    (q : ℕ) {p : ℕ} (hp : p.Prime) (hcop : ¬ p.Coprime (6 * q)) :
    etaReciprocalTerm q p = 0 := by
  unfold etaReciprocalTerm
  have hlocal :=
    petermannSupportedArithmetic_prime_pow q petermannB
      (p := p) (i := 1) hp
  have hcoeff : etaArithmetic q p = 0 := by
    change petermannSupportedArithmetic q petermannB p = 0
    have h := hlocal
    simp at h
    rw [if_neg hcop] at h
    exact h
  rw [hcoeff]
  simp

theorem etaReciprocalTerm_prime_pow_zero_of_two_le
    (q : ℕ) {p nu : ℕ} (hp : p.Prime) (hnu : 2 ≤ nu) :
    etaReciprocalTerm q (p ^ nu) = 0 := by
  unfold etaReciprocalTerm
  have hlocal :=
    petermannSupportedArithmetic_prime_pow q petermannB
      (p := p) (i := nu) hp
  have h0 : nu ≠ 0 := by omega
  have h1 : nu ≠ 1 := by omega
  have hcoeff : etaArithmetic q (p ^ nu) = 0 := by
    change petermannSupportedArithmetic q petermannB (p ^ nu) = 0
    rw [hlocal]
    simp [h0, h1]
  rw [hcoeff]
  simp

theorem tsum_etaReciprocalTerm_prime_pow
    (q : ℕ) {p : ℕ} (hp : p.Prime) :
    (∑' nu : ℕ, etaReciprocalTerm q (p ^ nu)) =
      1 + normalizationCorrection q 0 p := by
  rw [tsum_eq_sum (s := ({0, 1} : Finset ℕ))]
  · by_cases hactive : p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q
    · have hcop : p.Coprime (6 * q) := by
        apply hp.coprime_iff_not_dvd.mpr
        intro hd
        rcases hp.dvd_mul.mp hd with h6 | hq
        · have hp6 : p ∣ 2 * 3 := by simpa using h6
          rcases hp.dvd_mul.mp hp6 with h2 | h3
          · have : p ≤ 2 := Nat.le_of_dvd (by norm_num) h2
            omega
          · have : p ≤ 3 := Nat.le_of_dvd (by norm_num) h3
            omega
        · exact hactive.2.2 hq
      rw [show normalizationCorrection q 0 p =
          1 / ((p : ℝ) * ((p : ℝ) - 2)) by
        simp [normalizationCorrection, hactive]]
      simp [etaReciprocalTerm_one,
        etaReciprocalTerm_prime_active q hp hcop]
    · have hnotcop : ¬ p.Coprime (6 * q) := by
        intro hcop
        have hp5 : 5 ≤ p := eta_rankin_five_le_of_prime_coprime_six hp hcop
        have hpq : ¬ p ∣ q := by
          intro hd
          exact (hp.coprime_iff_not_dvd.mp hcop)
            (dvd_mul_of_dvd_right hd 6)
        exact hactive ⟨hp, hp5, hpq⟩
      rw [show normalizationCorrection q 0 p = 0 by
        simp [normalizationCorrection, hactive]]
      simp [etaReciprocalTerm_one,
        etaReciprocalTerm_prime_inactive q hp hnotcop]
  · intro nu hnu
    have hnot : nu ∉ ({0, 1} : Finset ℕ) := hnu
    have hge : 2 ≤ nu := by
      simp at hnot
      omega
    exact etaReciprocalTerm_prime_pow_zero_of_two_le q hp hge

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem coprimePrefixCount_le
    (L Y : ℕ) :
    coprimePrefixCount L Y ≤ Y := by
  unfold coprimePrefixCount
  calc
    ((Finset.Icc 1 Y).filter fun n => L.Coprime n).card
        ≤ (Finset.Icc 1 Y).card := Finset.card_filter_le _ _
    _ = Y := by simp

theorem abs_etaLinearPartialSum_le
    (q X : ℕ) :
    |etaLinearPartialSum q X| ≤
      (X : ℝ) * etaRankinBound := by
  rw [etaLinearPartialSum_eq_correction_coprime]
  have hR0 : 0 ≤ etaRankinBound := by
    unfold etaRankinBound
    positivity
  calc
    |∑ d ∈ Finset.Icc 1 X,
        etaLinearCorrectionArithmetic q d *
          (coprimePrefixCount (6 * q) (X / d) : ℝ)|
      ≤ ∑ d ∈ Finset.Icc 1 X,
          |etaLinearCorrectionArithmetic q d *
            (coprimePrefixCount (6 * q) (X / d) : ℝ)| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ d ∈ Finset.Icc 1 X,
          (X : ℝ) * |etaCorrectionInvTerm q d| := by
        apply Finset.sum_le_sum
        intro d hd
        have hdI := Finset.mem_Icc.mp hd
        have hd0 : d ≠ 0 := by omega
        have hcountN :
            coprimePrefixCount (6 * q) (X / d) ≤ X / d :=
          coprimePrefixCount_le (6 * q) (X / d)
        have hcountR :
            (coprimePrefixCount (6 * q) (X / d) : ℝ) ≤
              (X : ℝ) / (d : ℝ) := by
          calc
            (coprimePrefixCount (6 * q) (X / d) : ℝ)
                ≤ ((X / d : ℕ) : ℝ) := by exact_mod_cast hcountN
            _ ≤ (X : ℝ) / (d : ℝ) := Nat.cast_div_le
        have hcount0 :
            0 ≤ (coprimePrefixCount (6 * q) (X / d) : ℝ) := by positivity
        rw [abs_mul, abs_of_nonneg hcount0]
        have hc0 : 0 ≤ |etaLinearCorrectionArithmetic q d| := abs_nonneg _
        calc
          |etaLinearCorrectionArithmetic q d| *
              (coprimePrefixCount (6 * q) (X / d) : ℝ)
            ≤ |etaLinearCorrectionArithmetic q d| *
                ((X : ℝ) / (d : ℝ)) :=
              mul_le_mul_of_nonneg_left hcountR hc0
          _ = (X : ℝ) * |etaCorrectionInvTerm q d| := by
              unfold etaCorrectionInvTerm
              rw [abs_div, abs_of_pos (by positivity : (0 : ℝ) < d)]
              ring
    _ = (X : ℝ) *
          ∑ d ∈ Finset.Icc 1 X, |etaCorrectionInvTerm q d| := by
        rw [Finset.mul_sum]
    _ ≤ (X : ℝ) * etaRankinBound := by
        apply mul_le_mul_of_nonneg_left _ (by positivity)
        calc
          (∑ d ∈ Finset.Icc 1 X, |etaCorrectionInvTerm q d|)
              ≤ ∑' d : ℕ, |etaCorrectionInvTerm q d| := by
                exact (summable_etaCorrectionInvTerm q).abs.sum_le_tsum
                  (Finset.Icc 1 X) (fun d hd => abs_nonneg _)
          _ ≤ etaRankinBound :=
            tsum_abs_etaCorrectionInvTerm_le_bound q

#print axioms abs_etaLinearPartialSum_le

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem etaLinearPartialSum_eq_shifted_range
    (q X : ℕ) :
    etaLinearPartialSum q X =
      ∑ j ∈ Finset.range X, etaLinearArithmetic q (j + 1) := by
  unfold etaLinearPartialSum
  refine Finset.sum_bij
    (fun n hn => n - 1)
    ?_ ?_ ?_ ?_
  · intro n hn
    rw [Finset.mem_Icc] at hn
    rw [Finset.mem_range]
    omega
  · intro n1 hn1 n2 hn2 h
    rw [Finset.mem_Icc] at hn1 hn2
    omega
  · intro j hj
    rw [Finset.mem_range] at hj
    refine ⟨j + 1, ?_, ?_⟩
    · rw [Finset.mem_Icc]
      omega
    · omega
  · intro n hn
    rw [Finset.mem_Icc] at hn
    have hpos : 1 ≤ n := hn.1
    rw [Nat.sub_add_cancel hpos]

theorem etaReciprocalTerm_succ_eq_linear_sq
    (q j : ℕ) :
    etaReciprocalTerm q (j + 1) =
      (((j + 1 : ℕ) : ℝ)⁻¹ ^ 2) *
        etaLinearArithmetic q (j + 1) := by
  rw [etaReciprocalTerm_eq_etaCoeff_div]
  change etaCoeff q (j + 1) / (((j + 1 : ℕ) : ℝ)) =
    (((j + 1 : ℕ) : ℝ)⁻¹ ^ 2) *
      ((((j + 1 : ℕ) : ℝ) * etaCoeff q (j + 1)))
  have hj : (0 : ℝ) < j + 1 := by positivity
  field_simp [ne_of_gt hj]


#print axioms etaLinearPartialSum_eq_shifted_range
#print axioms etaReciprocalTerm_succ_eq_linear_sq

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem etaReciprocalFiniteTail_by_parts
    (q X M : ℕ) (hXM : X < M) :
    (∑ j ∈ Finset.Ico X M, etaReciprocalTerm q (j + 1)) =
      ((M : ℝ)⁻¹ ^ 2) * etaLinearPartialSum q M -
      (((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) * etaLinearPartialSum q X -
      ∑ i ∈ Finset.Ico X (M - 1),
        (((((i + 2 : ℕ) : ℝ)⁻¹ ^ 2) -
          (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2)) *
          etaLinearPartialSum q (i + 1)) := by
  have h := Finset.sum_Ico_by_parts
    (f := fun j : ℕ => (((j + 1 : ℕ) : ℝ)⁻¹ ^ 2))
    (g := fun j : ℕ => etaLinearArithmetic q (j + 1))
    hXM
  simp only [smul_eq_mul] at h
  have hL :
      (∑ i ∈ Finset.Ico X M,
        (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2) *
          etaLinearArithmetic q (i + 1)) =
      ∑ i ∈ Finset.Ico X M, etaReciprocalTerm q (i + 1) := by
    apply Finset.sum_congr rfl
    intro i hi
    rw [etaReciprocalTerm_succ_eq_linear_sq]
  rw [hL] at h
  simp_rw [← etaLinearPartialSum_eq_shifted_range] at h
  have hM : M - 1 + 1 = M := Nat.sub_add_cancel (Nat.one_le_of_lt hXM)
  simpa [hM, Nat.add_assoc] using h

#print axioms etaReciprocalFiniteTail_by_parts

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma reciprocal_sq_succ_le
    {m : ℕ} (hm : 0 < m) :
    (((m + 1 : ℕ) : ℝ)⁻¹ ^ 2) ≤ ((m : ℝ)⁻¹ ^ 2) := by
  have hmR : (0 : ℝ) < m := by exact_mod_cast hm
  have hmsR : (0 : ℝ) < m + 1 := by positivity
  have hinv :
      (((m + 1 : ℕ) : ℝ)⁻¹) ≤ (m : ℝ)⁻¹ := by
    simpa [Nat.cast_add, Nat.cast_one] using
      (inv_le_inv₀ hmsR hmR).2 (by exact_mod_cast Nat.le_succ m)
  exact (sq_le_sq₀ (by positivity) (by positivity)).2 hinv

lemma nat_mul_reciprocal_sq_diff_le
    {m : ℕ} (hm : 0 < m) :
    (m : ℝ) *
        (((m : ℝ)⁻¹ ^ 2) - (((m + 1 : ℕ) : ℝ)⁻¹ ^ 2))
      ≤ 2 * ((m : ℝ)⁻¹ ^ 2) := by
  have hmR : (0 : ℝ) < m := by exact_mod_cast hm
  have hmsR : (0 : ℝ) < m + 1 := by positivity
  field_simp [hmR.ne', hmsR.ne']
  norm_num [Nat.cast_add, Nat.cast_one] at *
  ring_nf at *
  nlinarith

theorem abs_inv_sq_mul_etaLinearPartialSum_le
    (q N : ℕ) (hN : 0 < N) :
    |((N : ℝ)⁻¹ ^ 2) * etaLinearPartialSum q N| ≤
      etaRankinBound / (N : ℝ) := by
  have hA := abs_etaLinearPartialSum_le q N
  have hsq0 : 0 ≤ ((N : ℝ)⁻¹ ^ 2) := sq_nonneg _
  rw [abs_mul, abs_of_nonneg hsq0]
  calc
    ((N : ℝ)⁻¹ ^ 2) * |etaLinearPartialSum q N|
      ≤ ((N : ℝ)⁻¹ ^ 2) * ((N : ℝ) * etaRankinBound) :=
        mul_le_mul_of_nonneg_left hA hsq0
    _ = etaRankinBound / (N : ℝ) := by
      have hNR : (N : ℝ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hN)
      field_simp [hNR]

theorem abs_etaAbelDifferenceTerm_le
    (q i : ℕ) (hi : 0 < i + 1) :
    |(((((i + 2 : ℕ) : ℝ)⁻¹ ^ 2) -
        (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2)) *
        etaLinearPartialSum q (i + 1))| ≤
      2 * etaRankinBound * (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2) := by
  let m := i + 1
  have hm : 0 < m := by
    dsimp [m]
    omega
  have hdec :
      (((m + 1 : ℕ) : ℝ)⁻¹ ^ 2) ≤ ((m : ℝ)⁻¹ ^ 2) :=
    reciprocal_sq_succ_le hm
  have hA := abs_etaLinearPartialSum_le q m
  have hdiff0 :
      0 ≤ ((m : ℝ)⁻¹ ^ 2) - (((m + 1 : ℕ) : ℝ)⁻¹ ^ 2) :=
    sub_nonneg.mpr hdec
  have hR0 : 0 ≤ etaRankinBound := by
    unfold etaRankinBound
    positivity
  change
    |(((((m + 1 : ℕ) : ℝ)⁻¹ ^ 2) - ((m : ℝ)⁻¹ ^ 2)) *
        etaLinearPartialSum q m)| ≤
      2 * etaRankinBound * ((m : ℝ)⁻¹ ^ 2)
  rw [abs_mul, abs_of_nonpos (sub_nonpos.mpr hdec), neg_sub]
  calc
    (((m : ℝ)⁻¹ ^ 2) - (((m + 1 : ℕ) : ℝ)⁻¹ ^ 2)) *
        |etaLinearPartialSum q m|
      ≤ (((m : ℝ)⁻¹ ^ 2) - (((m + 1 : ℕ) : ℝ)⁻¹ ^ 2)) *
          ((m : ℝ) * etaRankinBound) :=
        mul_le_mul_of_nonneg_left hA hdiff0
    _ = etaRankinBound *
        ((m : ℝ) *
          (((m : ℝ)⁻¹ ^ 2) - (((m + 1 : ℕ) : ℝ)⁻¹ ^ 2))) := by ring
    _ ≤ etaRankinBound * (2 * ((m : ℝ)⁻¹ ^ 2)) :=
      mul_le_mul_of_nonneg_left
        (nat_mul_reciprocal_sq_diff_le hm) hR0
    _ = 2 * etaRankinBound * ((m : ℝ)⁻¹ ^ 2) := by ring

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem abs_etaAbelInteriorSum_le
    (q X M : ℕ) (hX : 0 < X) :
    |∑ i ∈ Finset.Ico X (M - 1),
        (((((i + 2 : ℕ) : ℝ)⁻¹ ^ 2) -
          (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2)) *
          etaLinearPartialSum q (i + 1))| ≤
      2 * etaRankinBound * (X : ℝ)⁻¹ := by
  have hR0 : 0 ≤ etaRankinBound := by
    unfold etaRankinBound
    positivity
  have hshift :
      (∑ i ∈ Finset.Ico X (M - 1),
        (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2)) =
      ∑ m ∈ Finset.Icc (X + 1) (M - 1),
        ((m : ℝ)⁻¹ ^ 2) := by
    refine Finset.sum_bij
      (fun i hi => i + 1)
      ?_ ?_ ?_ ?_
    · intro i hi
      rw [Finset.mem_Ico] at hi
      rw [Finset.mem_Icc]
      omega
    · intro i1 hi1 i2 hi2 heq
      omega
    · intro m hm
      rw [Finset.mem_Icc] at hm
      refine ⟨m - 1, ?_, ?_⟩
      · rw [Finset.mem_Ico]
        omega
      · omega
    · intro i hi
      rfl
  calc
    |∑ i ∈ Finset.Ico X (M - 1),
        (((((i + 2 : ℕ) : ℝ)⁻¹ ^ 2) -
          (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2)) *
          etaLinearPartialSum q (i + 1))|
      ≤ ∑ i ∈ Finset.Ico X (M - 1),
          |(((((i + 2 : ℕ) : ℝ)⁻¹ ^ 2) -
            (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2)) *
            etaLinearPartialSum q (i + 1))| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ i ∈ Finset.Ico X (M - 1),
          2 * etaRankinBound *
            (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2) := by
        apply Finset.sum_le_sum
        intro i hi
        exact abs_etaAbelDifferenceTerm_le q i (by omega)
    _ = 2 * etaRankinBound *
          (∑ i ∈ Finset.Ico X (M - 1),
            (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2)) := by
        rw [Finset.mul_sum]
    _ = 2 * etaRankinBound *
          (∑ m ∈ Finset.Icc (X + 1) (M - 1),
            ((m : ℝ)⁻¹ ^ 2)) := by rw [hshift]
    _ ≤ 2 * etaRankinBound * (X : ℝ)⁻¹ := by
        apply mul_le_mul_of_nonneg_left
          (finite_square_tail_le_inv (F := X) (M := M - 1) hX)
        positivity

theorem abs_etaReciprocalFiniteTail_le
    (q X M : ℕ) (hX : 0 < X) (hXM : X < M) :
    |∑ j ∈ Finset.Ico X M, etaReciprocalTerm q (j + 1)| ≤
      4 * etaRankinBound * (X : ℝ)⁻¹ := by
  rw [etaReciprocalFiniteTail_by_parts q X M hXM]
  have hU :=
    abs_inv_sq_mul_etaLinearPartialSum_le q M
      (lt_of_lt_of_le hX (Nat.le_of_lt hXM))
  have hL :=
    abs_inv_sq_mul_etaLinearPartialSum_le q X hX
  have hI := abs_etaAbelInteriorSum_le q X M hX
  have hR0 : 0 ≤ etaRankinBound := by
    unfold etaRankinBound
    positivity
  have hXR : (0 : ℝ) < X := by exact_mod_cast hX
  have hM : 0 < M := lt_trans hX hXM
  have hMR : (0 : ℝ) < M := by exact_mod_cast hM
  have hXMreal : (X : ℝ) ≤ (M : ℝ) := by
    exact_mod_cast (Nat.le_of_lt hXM)
  have hInvM :
      (M : ℝ)⁻¹ ≤ (X : ℝ)⁻¹ :=
    (inv_le_inv₀ hMR hXR).2 hXMreal
  have hInvSucc :
      (((X + 1 : ℕ) : ℝ)⁻¹) ≤ (X : ℝ)⁻¹ := by
    have hXsR : (0 : ℝ) < ((X + 1 : ℕ) : ℝ) := by
      exact_mod_cast Nat.zero_lt_succ X
    exact (inv_le_inv₀ hXsR hXR).2 (by exact_mod_cast Nat.le_succ X)
  have hUb :
      |((M : ℝ)⁻¹ ^ 2) * etaLinearPartialSum q M| ≤
        etaRankinBound * (X : ℝ)⁻¹ := by
    calc
      |((M : ℝ)⁻¹ ^ 2) * etaLinearPartialSum q M|
          ≤ etaRankinBound / (M : ℝ) := hU
      _ = etaRankinBound * (M : ℝ)⁻¹ := by rw [div_eq_mul_inv]
      _ ≤ etaRankinBound * (X : ℝ)⁻¹ :=
        mul_le_mul_of_nonneg_left hInvM hR0
  have hLb :
      |(((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) *
          etaLinearPartialSum q X| ≤
        etaRankinBound * (X : ℝ)⁻¹ := by
    have hA := abs_etaLinearPartialSum_le q X
    have hsq0 : 0 ≤ (((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) := sq_nonneg _
    rw [abs_mul, abs_of_nonneg hsq0]
    calc
      (((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) *
          |etaLinearPartialSum q X|
        ≤ (((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) *
            ((X : ℝ) * etaRankinBound) :=
          mul_le_mul_of_nonneg_left hA hsq0
      _ ≤ etaRankinBound * (X : ℝ)⁻¹ := by
        have hsqInv :
            (((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) ≤ ((X : ℝ)⁻¹ ^ 2) :=
          (sq_le_sq₀ (by positivity) (by positivity)).2 hInvSucc
        calc
          (((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) *
              ((X : ℝ) * etaRankinBound)
            ≤ ((X : ℝ)⁻¹ ^ 2) *
                ((X : ℝ) * etaRankinBound) :=
              mul_le_mul_of_nonneg_right hsqInv
                (mul_nonneg (le_of_lt hXR) hR0)
          _ = etaRankinBound * (X : ℝ)⁻¹ := by
              have hXne : (X : ℝ) ≠ 0 := ne_of_gt hXR
              field_simp [hXne]
  calc
    |((M : ℝ)⁻¹ ^ 2) * etaLinearPartialSum q M -
      (((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) * etaLinearPartialSum q X -
      ∑ i ∈ Finset.Ico X (M - 1),
        (((((i + 2 : ℕ) : ℝ)⁻¹ ^ 2) -
          (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2)) *
          etaLinearPartialSum q (i + 1))|
      ≤ |((M : ℝ)⁻¹ ^ 2) * etaLinearPartialSum q M| +
        |(((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) * etaLinearPartialSum q X| +
        |∑ i ∈ Finset.Ico X (M - 1),
          (((((i + 2 : ℕ) : ℝ)⁻¹ ^ 2) -
            (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2)) *
            etaLinearPartialSum q (i + 1))| := by
          have h1 := abs_sub
            (((M : ℝ)⁻¹ ^ 2) * etaLinearPartialSum q M -
              (((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) * etaLinearPartialSum q X)
            (∑ i ∈ Finset.Ico X (M - 1),
              (((((i + 2 : ℕ) : ℝ)⁻¹ ^ 2) -
                (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2)) *
                etaLinearPartialSum q (i + 1)))
          have h2 := abs_sub
            (((M : ℝ)⁻¹ ^ 2) * etaLinearPartialSum q M)
            ((((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) * etaLinearPartialSum q X)
          linarith
    _ ≤ 4 * etaRankinBound * (X : ℝ)⁻¹ := by
      have hInvX0 : 0 ≤ (X : ℝ)⁻¹ := le_of_lt (inv_pos.mpr hXR)
      nlinarith [hUb, hLb, hI, mul_nonneg hR0 hInvX0]

#print axioms abs_etaReciprocalFiniteTail_le

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem etaCoeff_nonneg
    (q n : ℕ) :
    0 ≤ etaCoeff q n := by
  unfold etaCoeff
  by_cases hn0 : n = 0
  · simp [hn0]
  · rw [if_neg hn0]
    by_cases hs : Squarefree n ∧ n.Coprime (6 * q)
    · rw [if_pos hs]
      apply Finset.prod_nonneg
      intro p hp
      have hpPrime := (Nat.mem_primeFactors.mp hp).1
      have hpDvd := (Nat.mem_primeFactors.mp hp).2.1
      have hpcop : p.Coprime (6 * q) :=
        hs.2.coprime_dvd_left hpDvd
      have hp5 : 5 ≤ p :=
        eta_rankin_five_le_of_prime_coprime_six hpPrime hpcop
      have hpR : (5 : ℝ) ≤ (p : ℝ) := by exact_mod_cast hp5
      have hden : 0 < (p : ℝ) - 2 := by linarith
      positivity
    · rw [if_neg hs]

theorem etaReciprocalTerm_nonneg
    (q n : ℕ) :
    0 ≤ etaReciprocalTerm q n := by
  rw [etaReciprocalTerm_eq_etaCoeff_div]
  exact div_nonneg (etaCoeff_nonneg q n) (by positivity)

theorem shifted_etaReciprocal_sum_range_le
    (q M : ℕ) :
    (∑ j ∈ Finset.range M, etaReciprocalTerm q (j + 1)) ≤
      1 + 4 * etaRankinBound := by
  have hR0 : 0 ≤ etaRankinBound := by
    unfold etaRankinBound
    positivity
  cases M with
  | zero =>
      simp
      nlinarith
  | succ k =>
      by_cases hk0 : k = 0
      · subst k
        have h4 : 0 ≤ 4 * etaRankinBound :=
          mul_nonneg (by norm_num) hR0
        simpa [etaReciprocalTerm_one] using h4
      · have hk : 0 < k := Nat.pos_of_ne_zero hk0
        have htail :=
          abs_etaReciprocalFiniteTail_le q 1 (k + 1)
            (by norm_num) (by omega)
        have htail0 :
            0 ≤ ∑ j ∈ Finset.Ico 1 (k + 1),
              etaReciprocalTerm q (j + 1) := by
          exact Finset.sum_nonneg fun j hj =>
            etaReciprocalTerm_nonneg q (j + 1)
        have htailLe :
            (∑ j ∈ Finset.Ico 1 (k + 1),
              etaReciprocalTerm q (j + 1)) ≤
              4 * etaRankinBound := by
          simpa [abs_of_nonneg htail0] using htail
        rw [show Finset.range (k + 1) =
            insert 0 (Finset.Ico 1 (k + 1)) by
          ext j
          simp
          omega]
        simp [etaReciprocalTerm_one, htailLe]

theorem summable_shifted_etaReciprocalTerm
    (q : ℕ) :
    Summable (fun j : ℕ => etaReciprocalTerm q (j + 1)) := by
  exact summable_of_sum_range_le
    (fun j => etaReciprocalTerm_nonneg q (j + 1))
    (shifted_etaReciprocal_sum_range_le q)

theorem summable_etaReciprocalTerm
    (q : ℕ) :
    Summable (etaReciprocalTerm q) := by
  exact (summable_nat_add_iff (f := etaReciprocalTerm q) 1).1
    (by simpa using summable_shifted_etaReciprocalTerm q)

#print axioms summable_etaReciprocalTerm

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def etaReciprocalTail
    (q X : ℕ) : ℝ :=
  ∑' j : ℕ, etaReciprocalTerm q (X + 1 + j)

theorem summable_etaReciprocalTail
    (q X : ℕ) :
    Summable (fun j : ℕ => etaReciprocalTerm q (X + 1 + j)) := by
  have hs :
      Summable (fun j : ℕ => etaReciprocalTerm q (j + (X + 1))) :=
    (summable_nat_add_iff (f := etaReciprocalTerm q) (X + 1)).2
      (summable_etaReciprocalTerm q)
  simpa [Nat.add_comm, Nat.add_left_comm, Nat.add_assoc] using hs

theorem etaReciprocalTail_nonneg
    (q X : ℕ) :
    0 ≤ etaReciprocalTail q X := by
  unfold etaReciprocalTail
  exact tsum_nonneg fun j => etaReciprocalTerm_nonneg q (X + 1 + j)

theorem etaReciprocalTail_eq_etaCoeff_div
    (q X : ℕ) :
    etaReciprocalTail q X =
      ∑' j : ℕ, etaCoeff q (X + 1 + j) / ((X + 1 + j : ℕ) : ℝ) := by
  unfold etaReciprocalTail
  apply tsum_congr
  intro j
  exact etaReciprocalTerm_eq_etaCoeff_div q (X + 1 + j)

theorem etaReciprocalTail_le
    (q X : ℕ) (hX : 0 < X) :
    etaReciprocalTail q X ≤
      4 * etaRankinBound * (X : ℝ)⁻¹ := by
  have hR0 : 0 ≤ etaRankinBound := by
    unfold etaRankinBound
    positivity
  have hXR : (0 : ℝ) < X := by exact_mod_cast hX
  have hInvX0 : 0 ≤ (X : ℝ)⁻¹ := le_of_lt (inv_pos.mpr hXR)
  unfold etaReciprocalTail
  apply Real.tsum_le_of_sum_range_le
    (fun j => etaReciprocalTerm_nonneg q (X + 1 + j))
  intro K
  cases K with
  | zero =>
      simp
      exact mul_nonneg (mul_nonneg (by norm_num) hR0) hInvX0
  | succ k =>
      have hXM : X < X + (k + 1) := by omega
      have hfinite :=
        abs_etaReciprocalFiniteTail_le q X (X + (k + 1)) hX hXM
      have hEq :
          (∑ j ∈ Finset.range (k + 1),
            etaReciprocalTerm q (X + 1 + j)) =
          ∑ j ∈ Finset.Ico X (X + (k + 1)),
            etaReciprocalTerm q (j + 1) := by
        refine Finset.sum_bij
          (fun j hj => X + j)
          ?_ ?_ ?_ ?_
        · intro j hj
          rw [Finset.mem_range] at hj
          rw [Finset.mem_Ico]
          omega
        · intro j1 hj1 j2 hj2 h
          omega
        · intro i hi
          rw [Finset.mem_Ico] at hi
          refine ⟨i - X, ?_, ?_⟩
          · rw [Finset.mem_range]
            omega
          · omega
        · intro j hj
          congr 1
          omega
      rw [hEq]
      have hnonneg :
          0 ≤ ∑ j ∈ Finset.Ico X (X + (k + 1)),
            etaReciprocalTerm q (j + 1) := by
        exact Finset.sum_nonneg fun j hj =>
          etaReciprocalTerm_nonneg q (j + 1)
      simpa [abs_of_nonneg hnonneg] using hfinite

theorem abs_etaReciprocalTail_le
    (q X : ℕ) (hX : 0 < X) :
    |etaReciprocalTail q X| ≤
      4 * etaRankinBound * (X : ℝ)⁻¹ := by
  rw [abs_of_nonneg (etaReciprocalTail_nonneg q X)]
  exact etaReciprocalTail_le q X hX

#print axioms etaReciprocalTail_le
#print axioms abs_etaReciprocalTail_le

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem etaReciprocalTail_manuscript
    (q H : ℕ) (hH : 2 ≤ H) :
    |((H - 1 : ℕ) : ℝ) * etaReciprocalTail q (H - 1)| ≤
      4 * etaRankinBound := by
  have hX : 0 < H - 1 := by omega
  have hXR : (0 : ℝ) < (H - 1 : ℕ) := by exact_mod_cast hX
  have htail := etaReciprocalTail_le q (H - 1) hX
  have htail0 := etaReciprocalTail_nonneg q (H - 1)
  have hR0 : 0 ≤ etaRankinBound := by
    unfold etaRankinBound
    positivity
  rw [abs_mul, abs_of_nonneg (le_of_lt hXR), abs_of_nonneg htail0]
  calc
    ((H - 1 : ℕ) : ℝ) * etaReciprocalTail q (H - 1)
      ≤ ((H - 1 : ℕ) : ℝ) *
          (4 * etaRankinBound * (((H - 1 : ℕ) : ℝ)⁻¹)) :=
        mul_le_mul_of_nonneg_left htail (le_of_lt hXR)
    _ = 4 * etaRankinBound := by
      have hXne : (((H - 1 : ℕ) : ℝ)) ≠ 0 := ne_of_gt hXR
      field_simp [hXne]

#print axioms etaReciprocalTail_manuscript

end PaperB.FixedQ
