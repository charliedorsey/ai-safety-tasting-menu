import OrielLR.ReduceLR

/-!
# Oriel L/R — one short variable, the long variable summed

Generic bound for `∑_{a < n ≤ b} b_{F m}(n) (ψ_m(n; (H-1)/n) + c₀/(m n))`, used with
`m = r` (Left, orientation `α = H, β = -1`) and `m = s` (Right, `α = 0, β = 1`).
-/

open Finset

namespace OrielUpper

variable {P : ℕ} [NeZero P]

lemma sum_bW_div_le {F N : ℕ} {Cτ : ℝ}
    (hτ : ∀ N, ∑ r ∈ Icc 1 N, bW F r * ((r.divisors.card : ℝ) / r) ≤ Cτ) {a : ℕ} :
    ∑ n ∈ Ioc a N, bW F n / n ≤ Cτ := by
  refine le_trans ?_ (hτ N)
  calc ∑ n ∈ Ioc a N, bW F n / n ≤ ∑ n ∈ Icc 1 N, bW F n / n := by
        apply sum_le_sum_of_subset_of_nonneg
        · intro n hn; simp only [mem_Ioc, mem_Icc] at hn ⊢; omega
        · intro n _ _; exact div_nonneg (bW_nonneg _ _) (Nat.cast_nonneg _)
    _ ≤ _ := by
        apply sum_le_sum; intro n hn
        have hn1 : 1 ≤ n := (mem_Icc.mp hn).1
        have hτ1 : (1 : ℝ) ≤ n.divisors.card := by
          have : 1 ≤ n.divisors.card := Finset.card_pos.mpr ⟨1, Nat.one_mem_divisors.mpr (by omega)⟩
          exact_mod_cast this
        rw [div_eq_mul_one_div]
        apply mul_le_mul_of_nonneg_left _ (bW_nonneg _ _)
        apply div_le_div_of_nonneg_right hτ1 (Nat.cast_nonneg _)

theorem short_long_bound {F H : ℕ} {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {B : ℝ}
    (hR : RowHyp P F H w Λ B) {m : ℕ} (hm1 : 1 < m) (hmW : bW F m ≠ 0)
    {α β : ZMod P} (hβ : IsUnit β)
    {cK Ck : ℝ} (hcK : 0 < cK) (hCk : 0 ≤ Ck) (hK : KarBound cK Ck)
    {a b D N0 Lb : ℕ} (ha : 1 ≤ a) (hab : a ≤ b) (hD : 1 ≤ D) (hN0 : 1 ≤ N0)
    (hA : (N0 + 1) * (P * m) * D ≤ a)
    (hX : 2 * (D : ℝ) * ((P * m : ℕ) : ℝ) ^ 2 ≤ ((H - 1 : ℕ) : ℝ))
    (hLb : b ≤ 2 ^ Lb) {E1 E34 Cτ : ℝ}
    (hE1 : Asig (F * m) b 1 ≤ E1) (hE34 : Asig (F * m) b (3 / 4) ≤ E34)
    (hτ : ∀ N, ∑ r ∈ Icc 1 N, bW F r * ((r.divisors.card : ℝ) / r) ≤ Cτ) :
    |∑ n ∈ Ioc a b, bW (F * m) n *
        (psiR m H Λ α β (n : ZMod P) (n : ZMod m) (((H - 1 : ℕ) : ℝ) / n) +
          cZero H w Λ / ((m : ℝ) * n))| ≤
      E34 * ((D : ℝ) ^ (3 / 4 : ℝ) * (2 * ((P * m : ℕ) : ℝ) * ((P : ℝ) + 1) * B / a) +
          (D : ℝ) ^ (-(1 / 4 : ℝ)) * ((2 * P + 2) * B * (1 + Real.log ((b : ℝ) / a)))) +
        E1 * (((P : ℝ) + 1) * B * Lb * Ck *
          (karE cK N0 ((H - 1 : ℕ) : ℝ) + b * ((P * m : ℕ) : ℝ) / ((H - 1 : ℕ) : ℝ))) +
        (2 * P + 1) * B * Cτ / m := by
  haveI : NeZero m := ⟨by omega⟩
  have hB0 := hR.B_nonneg
  have hmP : Nat.Coprime m P := hR.coprime_P hmW
  have hHm : IsUnit (H : ZMod m) := (ZMod.isUnit_iff_coprime H m).mpr (hR.coprime_H hmW)
  have hmr : (0 : ℝ) < m := by exact_mod_cast (show 0 < m by omega)
  rw [show ∑ n ∈ Ioc a b, bW (F * m) n *
        (psiR m H Λ α β (n : ZMod P) (n : ZMod m) (((H - 1 : ℕ) : ℝ) / n) +
          cZero H w Λ / ((m : ℝ) * n)) =
      ∑ n ∈ Ioc a b, bW (F * m) n *
        psiR m H Λ α β (n : ZMod P) (n : ZMod m) (((H - 1 : ℕ) : ℝ) / n) +
      ∑ n ∈ Ioc a b, bW (F * m) n * (cZero H w Λ / ((m : ℝ) * n)) by
    rw [← sum_add_distrib]; apply sum_congr rfl; intro n _; ring]
  refine (abs_add_le _ _).trans (add_le_add ?_ ?_)
  · have hlv := long_vk (H := H) (F := F * m) (α := α) hR.hB hβ hmP hHm hm1 hcK hCk hK
      (hR.hcop m) ha hab hD hN0 hA hX hLb
    refine hlv.trans ?_
    have hT1 : 0 ≤ (D : ℝ) ^ (3 / 4 : ℝ) * (2 * ((P * m : ℕ) : ℝ) * ((P : ℝ) + 1) * B / a) +
        (D : ℝ) ^ (-(1 / 4 : ℝ)) * ((2 * P + 2) * B * (1 + Real.log ((b : ℝ) / a))) := by
      have := log_ratio_nonneg ha hab
      positivity
    have hT2 : 0 ≤ ((P : ℝ) + 1) * B * Lb * Ck *
        (karE cK N0 ((H - 1 : ℕ) : ℝ) + b * ((P * m : ℕ) : ℝ) / ((H - 1 : ℕ) : ℝ)) := by
      unfold karE; positivity
    exact add_le_add (mul_le_mul_of_nonneg_right hE34 hT1) (mul_le_mul_of_nonneg_right hE1 hT2)
  · have hc0 : |cZero H w Λ| ≤ (2 * P + 1) * B := oriel_centering hR.hw hR.hB
    refine (abs_sum_le_sum_abs _ _).trans ?_
    calc ∑ n ∈ Ioc a b, |bW (F * m) n * (cZero H w Λ / ((m : ℝ) * n))|
        ≤ ∑ n ∈ Ioc a b, (2 * P + 1) * B / m * (bW F n / n) := by
          apply sum_le_sum; intro n hn
          have hn0 : (0 : ℝ) < n := by
            have := (mem_Ioc.mp hn).1; exact_mod_cast (show 0 < n by omega)
          rw [abs_mul, abs_of_nonneg (bW_nonneg _ _), abs_div,
            abs_of_pos (mul_pos hmr hn0)]
          have h1 := bW_mul_le F m n
          have h2 : |cZero H w Λ| / ((m : ℝ) * n) ≤ (2 * P + 1) * B / ((m : ℝ) * n) :=
            div_le_div_of_nonneg_right hc0 (by positivity)
          calc bW (F * m) n * (|cZero H w Λ| / ((m : ℝ) * n))
              ≤ bW F n * ((2 * P + 1) * B / ((m : ℝ) * n)) :=
                mul_le_mul h1 h2 (by positivity) (bW_nonneg _ _)
            _ = (2 * P + 1) * B / m * (bW F n / n) := by field_simp
      _ = (2 * P + 1) * B / m * ∑ n ∈ Ioc a b, bW F n / n := by rw [mul_sum]
      _ ≤ (2 * P + 1) * B / m * Cτ :=
          mul_le_mul_of_nonneg_left (sum_bW_div_le (N := b) hτ) (by positivity)
      _ = (2 * P + 1) * B * Cτ / m := by ring

end OrielUpper
