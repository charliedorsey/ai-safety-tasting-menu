import GoldC.QuillonRowModes
import GoldC.QuillonReciprocity
import GoldC.QuillonWBilinear
import GoldC.QuillonRBilinear

/-!
# Quillon CSC3 F7.6a: the row normal forms (fixed `s` → `rowW`, fixed `r` → `rowR`)

The abstract folded row (class form, after `classPart_normal_form`) is

    rowAbs(r,s) = −2μ·saw(H·r̄/s) + Σ_{b<M} Γ(b, rs mod M)·(saw(x_b − 1/M) − saw(x_b)),

where `x_b = classPhase H r s M b`. For the source, `M = 6q`, `μ = meanWeight`, `Γ = gammaClass`.

This file contains the phase toolkit:
* `eR_int`, `eR_add_int`, `zeta_zpow_eR`, `stdAddChar_eq_eR`, `kphase_intCast_eq`;
* `eR_modEq`: congruent numerators give equal phases;
* `classPhase_eq`: `x_b = N_b/(Ms)` with `N_b = t·M̄·M + β_b·s̄·s`;
* `classN_not_dvd`: `Ms ∤ N_b` and `Ms ∤ N_b + (M−1)s` (from `(H,s)=1`).

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonRowNF

open GoldC.QuillonR GoldC.QuillonCot GoldC.QuillonSawDFT GoldC.QuillonRowModes GoldC.QuillonVW
  GoldC.QuillonWBilinear GoldC.QuillonRBilinear

local notation "invM" => GoldC.QuillonCopyC.invMod
local notation "sawC" => GoldC.QuillonCopyC.saw

/-! ## Phases -/

lemma eR_int (n : ℤ) : eR (n : ℝ) = 1 := by
  unfold eR
  rw [show 2 * (Real.pi : ℂ) * Complex.I * (((n : ℝ)) : ℂ) = (n : ℂ) * (2 * Real.pi * Complex.I) by
    push_cast; ring]
  exact Complex.exp_int_mul_two_pi_mul_I n

lemma eR_add_int (x : ℝ) (n : ℤ) : eR (x + n) = eR x := by
  rw [eR_add, eR_int, mul_one]

lemma zeta_zpow_eR (m : ℕ) (e : ℤ) : zeta m ^ e = eR ((e : ℝ) / m) := by
  unfold zeta eR
  rw [← Complex.exp_int_mul]
  congr 1; push_cast; ring

lemma stdAddChar_eq_eR {s : ℕ} [NeZero s] (x : ZMod s) :
    ZMod.stdAddChar x = eR ((x.val : ℝ) / s) := by
  rw [ZMod.stdAddChar_apply, ZMod.toCircle_apply]; unfold eR; congr 1; push_cast; ring

lemma kphase_intCast_eq {s : ℕ} [NeZero s] (A : ℤ) (r : ℕ) (hr : r.Coprime s) :
    kphase ((A : ZMod s)) r = eR ((A : ℝ) * (invM r s : ℝ) / s) := by
  unfold kphase
  rw [if_pos ((ZMod.isUnit_iff_coprime r s).2 hr)]
  have : (A : ZMod s) * (r : ZMod s)⁻¹ = (((A * (invM r s : ℤ)) : ℤ) : ZMod s) := by
    push_cast; unfold GoldC.QuillonCopyC.invMod; rw [ZMod.natCast_zmod_val]
  rw [this, ZMod.stdAddChar_coe]; unfold eR; congr 1; push_cast; ring

/-- Congruent numerators give equal phases. -/
lemma eR_modEq (s : ℕ) (hs : 0 < s) (a b : ℕ) (h : a ≡ b [MOD s]) (k : ℤ) :
    eR ((k : ℝ) * a / s) = eR ((k : ℝ) * b / s) := by
  obtain ⟨z, hz⟩ := (Nat.ModEq.dvd h)
  have hsR : (s : ℝ) ≠ 0 := by positivity
  have hzR : (b : ℝ) - a = s * z := by exact_mod_cast hz
  have : (k : ℝ) * b / s = (k : ℝ) * a / s + ((k * z : ℤ) : ℝ) := by
    push_cast; field_simp; linear_combination (k : ℝ) * hzR
  rw [this, eR_add_int]

/-! ## The class numerator -/

/-- `N_b = t·M̄·M + β_b·s̄·s`, with `t = (H r̄) mod s` and `β_b = (b r̄_M) mod M`. -/
noncomputable def classN (H r s M b : ℕ) : ℕ :=
  (H * invM r s) % s * invM M s * M + (b * invM r M) % M * invM s M * s

lemma classPhase_eq (H r s M b : ℕ) (hM : 1 ≤ M) (hs : 1 ≤ s) :
    GoldC.QuillonCopyC.classPhase H r s M b = (classN H r s M b : ℝ) / ((M * s : ℕ) : ℝ) := by
  unfold GoldC.QuillonCopyC.classPhase classN
  have hMR : (M : ℝ) ≠ 0 := by
    have : (0 : ℝ) < M := by exact_mod_cast hM
    exact this.ne'
  have hsR : (s : ℝ) ≠ 0 := by
    have : (0 : ℝ) < s := by exact_mod_cast hs
    exact this.ne'
  push_cast; field_simp

lemma classN_modEq (H r s M b : ℕ) (hs : 2 ≤ s) (hMs : M.Coprime s) :
    classN H r s M b ≡ (H * invM r s) % s [MOD s] := by
  unfold classN
  have h1 : M * invM M s ≡ 1 [MOD s] := GoldC.QuillonCopyC.mul_invMod_modEq hs hMs
  have h2 : (b * invM r M) % M * invM s M * s ≡ 0 [MOD s] := by
    rw [Nat.modEq_zero_iff_dvd]; exact Dvd.intro_left _ rfl
  calc (H * invM r s) % s * invM M s * M + (b * invM r M) % M * invM s M * s
      ≡ (H * invM r s) % s * (M * invM M s) + 0 [MOD s] := by
        refine Nat.ModEq.add ?_ h2
        rw [show (H * invM r s) % s * invM M s * M = (H * invM r s) % s * (M * invM M s) by ring]
    _ ≡ (H * invM r s) % s * 1 + 0 [MOD s] := Nat.ModEq.add_right _ (Nat.ModEq.mul_left _ h1)
    _ = (H * invM r s) % s := by ring

lemma t_mod_ne_zero (H r s : ℕ) (hs : 2 ≤ s) (hr : r.Coprime s) (hH : H.Coprime s) :
    (H * invM r s) % s ≠ 0 := by
  intro h0
  have : NeZero s := ⟨by omega⟩
  have hdvd : s ∣ H * invM r s := Nat.dvd_of_mod_eq_zero h0
  have hz : ((H * invM r s : ℕ) : ZMod s) = 0 := (ZMod.natCast_eq_zero_iff _ _).2 hdvd
  have hu := ZMod.coe_mul_inv_eq_one r hr
  have hH0 : (H : ZMod s) = 0 := by
    push_cast at hz
    unfold GoldC.QuillonCopyC.invMod at hz
    rw [ZMod.natCast_zmod_val] at hz
    calc (H : ZMod s) = H * ((r : ZMod s) * (r : ZMod s)⁻¹) := by rw [hu, mul_one]
      _ = (H * (r : ZMod s)⁻¹) * r := by ring
      _ = 0 := by rw [hz, zero_mul]
  have hsH : s ∣ H := (ZMod.natCast_eq_zero_iff _ _).1 hH0
  have := Nat.Coprime.eq_one_of_dvd (Nat.Coprime.symm hH) hsH
  omega

lemma classN_not_dvd (H r s M b : ℕ) (hs : 2 ≤ s) (hr : r.Coprime s) (hH : H.Coprime s)
    (hMs : M.Coprime s) : ¬ (M * s) ∣ classN H r s M b := by
  intro hd
  have hsd : s ∣ classN H r s M b := Dvd.dvd.trans (Dvd.intro_left _ rfl) hd
  have h1 := classN_modEq H r s M b hs hMs
  have h2 : (H * invM r s) % s % s = 0 := by
    exact (h1.symm.trans (Nat.modEq_zero_iff_dvd.2 hsd))
  rw [Nat.mod_mod] at h2
  exact t_mod_ne_zero H r s hs hr hH h2

lemma classN_shift_not_dvd (H r s M b : ℕ) (hs : 2 ≤ s) (hr : r.Coprime s) (hH : H.Coprime s)
    (hMs : M.Coprime s) : ¬ (M * s) ∣ classN H r s M b + (M - 1) * s := by
  intro hd
  have hsd : s ∣ classN H r s M b + (M - 1) * s := Dvd.dvd.trans (Dvd.intro_left _ rfl) hd
  have hsd' : s ∣ classN H r s M b := (Nat.dvd_add_right (Dvd.intro_left _ rfl)).1
    (by rwa [add_comm] at hsd)
  have h1 := classN_modEq H r s M b hs hMs
  have h2 : (H * invM r s) % s % s = 0 := by
    exact (h1.symm.trans (Nat.modEq_zero_iff_dvd.2 hsd'))
  rw [Nat.mod_mod] at h2
  exact t_mod_ne_zero H r s hs hr hH h2


/-! ## Saw expansions in `eR` form -/

/-- The mode coefficient `i·ampC(k,m)/(2πk)`. -/
noncomputable def αm (k m : ℕ) : ℂ := Complex.I * ((ampC k m : ℝ) : ℂ) / (2 * Real.pi * k)

lemma norm_αm_le (k m : ℕ) (hk : 1 ≤ k) (hm : 1 ≤ m) : ‖αm k m‖ ≤ 1 / (2 * Real.pi * k) := by
  unfold αm
  have hA := ampC_bounds k m hk hm
  have hkR : (1 : ℝ) ≤ k := by exact_mod_cast hk
  rw [norm_div, norm_mul, Complex.norm_I, one_mul, Complex.norm_real, Real.norm_eq_abs,
    abs_of_nonneg hA.1]
  have h2 : ‖(2 * (Real.pi : ℂ) * (k : ℂ))‖ = 2 * Real.pi * k := by
    rw [show (2 * (Real.pi : ℂ) * (k : ℂ)) = ((2 * Real.pi * k : ℝ) : ℂ) by push_cast; ring,
      Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (by positivity)]
  rw [h2]
  exact div_le_div_of_nonneg_right hA.2 (by positivity)

lemma saw_eR (N m J : ℕ) (hm : 2 ≤ m) (hN : ¬ m ∣ N) (hJ : m ≤ 2 * J) :
    ((sawC ((N : ℝ) / m) : ℝ) : ℂ) = ∑ k ∈ Icc 1 J, αm k m *
      (eR ((((k : ℤ) * N : ℤ) : ℝ) / m) - eR ((((-(k : ℤ)) * N : ℤ) : ℝ) / m)) := by
  rw [saw_modes N m J hm hN hJ]
  refine sum_congr rfl fun k _ => ?_
  rw [zeta_zpow_eR, zeta_zpow_eR, neg_mul]
  rfl

/-! ## The abstract folded row -/

/-- The folded row in class form (after `classPart_normal_form`). -/
noncomputable def rowAbs (M H : ℕ) (μ : ℝ) (Γ : ℕ → ℕ → ℝ) (r s : ℕ) : ℝ :=
  -(2 * μ) * sawC ((H : ℝ) * invM r s / s) +
    ∑ b ∈ range M, Γ b ((r * s) % M) *
      (sawC (GoldC.QuillonCopyC.classPhase H r s M b - 1 / M) -
        sawC (GoldC.QuillonCopyC.classPhase H r s M b))

lemma class_saw_eR (H r s M b J : ℕ) (hM : 2 ≤ M) (hs : 2 ≤ s) (hr : r.Coprime s)
    (hH : H.Coprime s) (hMs : M.Coprime s) (hJ : M * s ≤ 2 * J) :
    ((sawC (GoldC.QuillonCopyC.classPhase H r s M b - 1 / M) : ℝ) : ℂ) -
        ((sawC (GoldC.QuillonCopyC.classPhase H r s M b) : ℝ) : ℂ) =
      ∑ k ∈ Icc 1 J, αm k (M * s) *
        ((eR ((((k : ℤ) * (classN H r s M b + (M - 1) * s : ℕ) : ℤ) : ℝ) / ((M * s : ℕ) : ℝ)) -
          eR ((((-(k : ℤ)) * (classN H r s M b + (M - 1) * s : ℕ) : ℤ) : ℝ) / ((M * s : ℕ) : ℝ))) -
        (eR ((((k : ℤ) * (classN H r s M b : ℕ) : ℤ) : ℝ) / ((M * s : ℕ) : ℝ)) -
          eR ((((-(k : ℤ)) * (classN H r s M b : ℕ) : ℤ) : ℝ) / ((M * s : ℕ) : ℝ)))) := by
  have hMs2 : 2 ≤ M * s := by nlinarith
  rw [classPhase_eq H r s M b (by omega) (by omega),
    saw_shift_eq _ M s (by omega) (by omega),
    saw_eR _ (M * s) J hMs2 (classN_shift_not_dvd H r s M b hs hr hH hMs) hJ,
    saw_eR _ (M * s) J hMs2 (classN_not_dvd H r s M b hs hr hH hMs) hJ, ← sum_sub_distrib]
  refine sum_congr rfl fun k _ => ?_
  ring

/-! ## Phase identities -/

lemma main_phase_S {s : ℕ} [NeZero s] (H r : ℕ) (hr : r.Coprime s) (z : ℤ) :
    eR (((z * ((H * invM r s : ℕ) : ℤ) : ℤ) : ℝ) / s) = kphase (((z * H : ℤ)) : ZMod s) r := by
  rw [kphase_intCast_eq _ r hr]; congr 1; push_cast; ring

lemma class_phase_S {s : ℕ} [NeZero s] (H r M b : ℕ) (hM : 1 ≤ M) (hs : 1 ≤ s) (hr : r.Coprime s)
    (z : ℤ) :
    eR (((z * (classN H r s M b : ℕ) : ℤ) : ℝ) / ((M * s : ℕ) : ℝ)) =
      kphase (((z * H * invM M s : ℤ)) : ZMod s) r *
        eR ((z : ℝ) * (((b * invM r M) % M * invM s M : ℕ) : ℝ) / M) := by
  have hMR : (M : ℝ) ≠ 0 := by
    have : (0 : ℝ) < M := by exact_mod_cast hM
    exact this.ne'
  have hsR : (s : ℝ) ≠ 0 := by
    have : (0 : ℝ) < s := by exact_mod_cast hs
    exact this.ne'
  have e : (((z * (classN H r s M b : ℕ) : ℤ) : ℝ) / ((M * s : ℕ) : ℝ)) =
      (z : ℝ) * (((H * invM r s) % s * invM M s : ℕ) : ℝ) / s +
        (z : ℝ) * (((b * invM r M) % M * invM s M : ℕ) : ℝ) / M := by
    rw [Int.cast_mul, Int.cast_natCast]
    unfold classN; push_cast; field_simp
  rw [e, eR_add]
  congr 1
  rw [eR_modEq s (by omega) _ (H * invM r s * invM M s)
    (Nat.ModEq.mul_right _ (Nat.mod_modEq _ _)) z, kphase_intCast_eq _ r hr]
  congr 1; push_cast; ring

lemma shift_phase (N M s : ℕ) (hM : 1 ≤ M) (hs : 1 ≤ s) (z : ℤ) :
    eR (((z * (N + (M - 1) * s : ℕ) : ℤ) : ℝ) / ((M * s : ℕ) : ℝ)) =
      eR (((z * (N : ℕ) : ℤ) : ℝ) / ((M * s : ℕ) : ℝ)) * eR ((z : ℝ) * ((M - 1 : ℕ) : ℝ) / M) := by
  have hMR : (M : ℝ) ≠ 0 := by
    have : (0 : ℝ) < M := by exact_mod_cast hM
    exact this.ne'
  have hsR : (s : ℝ) ≠ 0 := by
    have : (0 : ℝ) < s := by exact_mod_cast hs
    exact this.ne'
  rw [← eR_add]; congr 1
  rw [show ((N + (M - 1) * s : ℕ) : ℤ) = (N : ℤ) + ((M - 1 : ℕ) : ℤ) * s by push_cast; ring]
  push_cast; field_simp

/-! ## Fixed `s`: the `rowW` normal form -/

lemma rowW_eval {s M : ℕ} [NeZero s] [NeZero M] (𝒥 : Finset ℕ) (A : ZMod M → ℕ → ℂ)
    (c : ℕ → ZMod s) (r : ℕ) :
    rowW 𝒥 A c r = ∑ j ∈ 𝒥, A (r : ZMod M) j * kphase (c j) r := by
  unfold rowW; rw [Finset.sum_ite_eq]; simp

/-- One digit's fixed-`s` class amplitude for frequency `z = ±k`. -/
noncomputable def bS (M : ℕ) (Γ : ℕ → ℕ → ℝ) (s b : ℕ) (z : ℤ) (ρ : ZMod M) : ℂ :=
  (Γ b ((ρ.val * s) % M) : ℂ) *
    (eR ((z : ℝ) * (((b * (ρ⁻¹).val) % M * invM s M : ℕ) : ℝ) / M) *
      (eR ((z : ℝ) * ((M - 1 : ℕ) : ℝ) / M) - 1))

/-- The fixed-`s` class amplitude for frequency `z = ±k`. -/
noncomputable def BclS (M : ℕ) (Γ : ℕ → ℕ → ℝ) (s : ℕ) (z : ℤ) (ρ : ZMod M) : ℂ :=
  ∑ b ∈ range M, bS M Γ s b z ρ

/-- **Fixed `s` normal form**: the folded row is a sum of four `rowW` rows. -/
theorem rowAbs_eq_rowW {s M : ℕ} [NeZero s] [NeZero M] (hM : 2 ≤ M) (hs : 2 ≤ s) (H : ℕ) (μ : ℝ)
    (Γ : ℕ → ℕ → ℝ) (r : ℕ) (hrs : r.Coprime s) (hsM : s.Coprime M) (hHs : H.Coprime s)
    (J : ℕ) (hJ : M * s ≤ 2 * J) :
    ((rowAbs M H μ Γ r s : ℝ) : ℂ) =
      rowW (Icc 1 J) (fun (_ : ZMod M) k => ((-(2 * μ) : ℝ) : ℂ) * αm k s)
          (fun k => ((((k : ℤ) * H : ℤ)) : ZMod s)) r +
        rowW (Icc 1 J) (fun (_ : ZMod M) k => -(((-(2 * μ) : ℝ) : ℂ) * αm k s))
          (fun k => ((((-(k : ℤ)) * H : ℤ)) : ZMod s)) r +
        rowW (Icc 1 J) (fun (ρ : ZMod M) k => αm k (M * s) * BclS M Γ s (k : ℤ) ρ)
          (fun k => ((((k : ℤ) * H * invM M s : ℤ)) : ZMod s)) r +
        rowW (Icc 1 J) (fun (ρ : ZMod M) k => -(αm k (M * s) * BclS M Γ s (-(k : ℤ)) ρ))
          (fun k => ((((-(k : ℤ)) * H * invM M s : ℤ)) : ZMod s)) r := by
  classical
  have hM1 : 1 ≤ M := by omega
  have hMs : M.Coprime s := hsM.symm
  have hsMs : s ≤ M * s := Nat.le_mul_of_pos_left s (by omega)
  have hJs : s ≤ 2 * J := le_trans hsMs hJ
  have hNs : ¬ s ∣ H * invM r s := fun h =>
    t_mod_ne_zero H r s hs hrs hHs (Nat.mod_eq_zero_of_dvd h)
  -- class saws, digit by digit
  have hcls : ∀ b ∈ range M, (Γ b ((r * s) % M) : ℂ) *
      (((sawC (GoldC.QuillonCopyC.classPhase H r s M b - 1 / M) : ℝ) : ℂ) -
        ((sawC (GoldC.QuillonCopyC.classPhase H r s M b) : ℝ) : ℂ)) =
      ∑ k ∈ Icc 1 J, ((αm k (M * s) * bS M Γ s b (k : ℤ) (r : ZMod M)) *
          kphase ((((k : ℤ) * H * invM M s : ℤ)) : ZMod s) r +
        (-(αm k (M * s) * bS M Γ s b (-(k : ℤ)) (r : ZMod M))) *
          kphase ((((-(k : ℤ)) * H * invM M s : ℤ)) : ZMod s) r) := by
    intro b _
    rw [class_saw_eR H r s M b J hM hs hrs hHs hMs hJ, mul_sum]
    refine sum_congr rfl fun k _ => ?_
    rw [shift_phase _ M s hM1 (by omega), shift_phase _ M s hM1 (by omega),
      class_phase_S H r M b hM1 (by omega) hrs, class_phase_S H r M b hM1 (by omega) hrs]
    unfold bS
    rw [ZMod.val_natCast, Nat.mod_mul_mod]
    unfold GoldC.QuillonCopyC.invMod
    ring
  simp only [rowW_eval]
  unfold rowAbs
  simp only [Complex.ofReal_add, Complex.ofReal_mul, Complex.ofReal_sum, Complex.ofReal_sub]
  have e0 : (H : ℝ) * invM r s / s = ((H * invM r s : ℕ) : ℝ) / s := by push_cast; ring
  rw [e0, saw_eR _ s J hs hNs hJs, sum_congr rfl hcls, sum_comm, mul_sum, ← sum_add_distrib,
    ← sum_add_distrib, ← sum_add_distrib, ← sum_add_distrib]
  refine sum_congr rfl fun k _ => ?_
  rw [main_phase_S H r hrs, main_phase_S H r hrs, sum_add_distrib, ← sum_mul, ← sum_mul]
  unfold BclS
  rw [mul_sum, mul_sum, sum_neg_distrib]
  ring


/-! ## Fixed `r`: the `rowR` normal form -/

local notation "invR" => GoldC.QuillonCopyRec.invMod

lemma invM_mod (a n m : ℕ) (h : m ∣ n) : invM (a % n) m = invM a m := by
  have : ((a % n : ℕ) : ZMod m) = (a : ZMod m) :=
    (ZMod.natCast_eq_natCast_iff' _ _ _).2 (Nat.mod_mod_of_dvd a h)
  unfold GoldC.QuillonCopyC.invMod; rw [this]

lemma main_phase_R (H r s : ℕ) (hr : 2 ≤ r) (hs : 2 ≤ s) (hrs : r.Coprime s) (z : ℤ) :
    eR (((z * ((H * invM r s : ℕ) : ℤ) : ℤ) : ℝ) / s) =
      eR ((((z * H : ℤ) : ℝ) / r) / s) * eR (-(((z * H : ℤ) : ℝ) * invM s r / r)) := by
  have h := GoldC.QuillonCopyRec.eR_reciprocity hr hs hrs (z * H)
  have hrR : (r : ℝ) ≠ 0 := by positivity
  have hsR : (s : ℝ) ≠ 0 := by positivity
  have e1 : (((z * ((H * invM r s : ℕ) : ℤ) : ℤ) : ℝ) / s) =
      ((z * H : ℤ) : ℝ) * (invR r s : ℝ) / s := by
    push_cast; unfold GoldC.QuillonCopyRec.invMod GoldC.QuillonCopyC.invMod; ring
  have e2 : (((z * H : ℤ) : ℝ) / r) / s = ((z * H : ℤ) : ℝ) / ((r : ℝ) * s) := by
    field_simp
  rw [e1, h, e2]
  rfl

lemma class_phase_R (H r s M b : ℕ) (hM : 2 ≤ M) (hr : 1 ≤ r) (hs : 2 ≤ s) (hrs : r.Coprime s)
    (hMs : M.Coprime s) (z : ℤ) :
    eR (((z * (classN H r s M b : ℕ) : ℤ) : ℝ) / ((M * s : ℕ) : ℝ)) =
      eR ((((z * H : ℤ) : ℝ) / ((M * r : ℕ) : ℝ)) / s) *
        eR (-(((z * H : ℤ) : ℝ) * invM s (M * r) / ((M * r : ℕ) : ℝ))) *
        eR ((z : ℝ) * (((b * invM r M) % M * invM s M : ℕ) : ℝ) / M) := by
  have hMR : (M : ℝ) ≠ 0 := by
    have : (0 : ℝ) < M := by exact_mod_cast (show 0 < M by omega)
    exact this.ne'
  have hsR : (s : ℝ) ≠ 0 := by
    have : (0 : ℝ) < s := by exact_mod_cast (show 0 < s by omega)
    exact this.ne'
  have e : (((z * (classN H r s M b : ℕ) : ℤ) : ℝ) / ((M * s : ℕ) : ℝ)) =
      (z : ℝ) * (((H * invM r s) % s * invM M s : ℕ) : ℝ) / s +
        (z : ℝ) * (((b * invM r M) % M * invM s M : ℕ) : ℝ) / M := by
    rw [Int.cast_mul, Int.cast_natCast]
    unfold classN; push_cast; field_simp
  rw [e, eR_add]
  congr 1
  have hk : (H * invM r s) % s * invM M s ≡ H * invM (M * r) s [MOD s] :=
    GoldC.QuillonCopyC.phase_kloosterman hs hrs hMs
  rw [eR_modEq s (by omega) _ _ hk z]
  have hMr : 2 ≤ M * r := by nlinarith
  have hMrs : (M * r).Coprime s := Nat.coprime_mul_iff_left.2 ⟨hMs, hrs⟩
  have h := GoldC.QuillonCopyRec.eR_reciprocity hMr hs hMrs (z * H)
  have e1 : (z : ℝ) * ((H * invM (M * r) s : ℕ) : ℝ) / s =
      ((z * H : ℤ) : ℝ) * (invR (M * r) s : ℝ) / s := by
    push_cast; unfold GoldC.QuillonCopyRec.invMod GoldC.QuillonCopyC.invMod; ring
  have hMrR : ((M * r : ℕ) : ℝ) ≠ 0 := by positivity
  have e2 : (((z * H : ℤ) : ℝ) / ((M * r : ℕ) : ℝ)) / s = ((z * H : ℤ) : ℝ) / (((M * r : ℕ) : ℝ) * s) := by
    field_simp
  rw [e1, h, e2]
  rfl

/-- The `I/(2πk)` factor. -/
noncomputable def βk (k : ℕ) : ℂ := Complex.I / (2 * Real.pi * k)

lemma αm_eq (k m : ℕ) : αm k m = βk k * ((ampC k m : ℝ) : ℂ) := by
  unfold αm βk; ring

/-- The main-saw class phase for fixed `r`: `e(−zH·σ̄/r)`. -/
noncomputable def ΓmR (r H : ℕ) (z : ℤ) (σ : ℕ) : ℂ :=
  eR (-(((z * H : ℤ) : ℝ) * invM σ r / r))

/-- One digit's class phase for fixed `r` (unnormalized). -/
noncomputable def cbR (M H : ℕ) (Γ : ℕ → ℕ → ℝ) (r b : ℕ) (z : ℤ) (σ : ℕ) : ℂ :=
  (Γ b ((r * σ) % M) : ℂ) *
    (eR (-(((z * H : ℤ) : ℝ) * invM σ (M * r) / ((M * r : ℕ) : ℝ))) *
      (eR ((z : ℝ) * (((b * invM r M) % M * invM σ M : ℕ) : ℝ) / M) *
        (eR ((z : ℝ) * ((M - 1 : ℕ) : ℝ) / M) - 1)))

/-- The class phase for fixed `r` (unnormalized). -/
noncomputable def ΓcR (M H : ℕ) (Γ : ℕ → ℕ → ℝ) (r : ℕ) (z : ℤ) (σ : ℕ) : ℂ :=
  ∑ b ∈ range M, cbR M H Γ r b z σ

lemma ΓmR_mod (r H M : ℕ) (z : ℤ) (s : ℕ) : ΓmR r H z (s % (M * r)) = ΓmR r H z s := by
  unfold ΓmR; rw [invM_mod s (M * r) r (Dvd.intro_left _ rfl)]

lemma cbR_mod (M H : ℕ) (Γ : ℕ → ℕ → ℝ) (r b : ℕ) (z : ℤ) (s : ℕ) :
    cbR M H Γ r b z (s % (M * r)) = cbR M H Γ r b z s := by
  unfold cbR
  rw [invM_mod s (M * r) (M * r) dvd_rfl, invM_mod s (M * r) M (Dvd.intro _ rfl)]
  have : (r * (s % (M * r))) % M = (r * s) % M := by
    rw [Nat.mul_mod, Nat.mod_mod_of_dvd s (Dvd.intro _ rfl), ← Nat.mul_mod]
  rw [this]

lemma ΓcR_mod (M H : ℕ) (Γ : ℕ → ℕ → ℝ) (r : ℕ) (z : ℤ) (s : ℕ) :
    ΓcR M H Γ r z (s % (M * r)) = ΓcR M H Γ r z s := by
  unfold ΓcR; exact sum_congr rfl fun b _ => cbR_mod M H Γ r b z s

/-- **Fixed `r` normal form**: the folded row is a sum of four `rowR` rows (modulus `Q = Mr`). -/
theorem rowAbs_eq_rowR (M H : ℕ) (μ : ℝ) (Γ : ℕ → ℕ → ℝ) (r s : ℕ) (hM : 2 ≤ M) (hr : 2 ≤ r)
    (hs : 2 ≤ s) (hrs : r.Coprime s) (hsM : s.Coprime M) (hHs : H.Coprime s)
    (J : ℕ) (hJ : M * s ≤ 2 * J) :
    ((rowAbs M H μ Γ r s : ℝ) : ℂ) =
      rowR (Icc 1 J) (fun k => ((-(2 * μ) : ℝ) : ℂ) * βk k) (fun k => k) (fun _ => 1)
          (fun k => (((k : ℤ) * H : ℤ) : ℝ) / r) (fun k σ => ΓmR r H k σ) (M * r) s +
        rowR (Icc 1 J) (fun k => -(((-(2 * μ) : ℝ) : ℂ) * βk k)) (fun k => k) (fun _ => 1)
          (fun k => (((-(k : ℤ)) * H : ℤ) : ℝ) / r) (fun k σ => ΓmR r H (-(k : ℤ)) σ) (M * r) s +
        rowR (Icc 1 J) (fun k => βk k) (fun k => k) (fun _ => M)
          (fun k => (((k : ℤ) * H : ℤ) : ℝ) / ((M * r : ℕ) : ℝ)) (fun k σ => ΓcR M H Γ r k σ)
          (M * r) s +
        rowR (Icc 1 J) (fun k => -βk k) (fun k => k) (fun _ => M)
          (fun k => (((-(k : ℤ)) * H : ℤ) : ℝ) / ((M * r : ℕ) : ℝ))
          (fun k σ => ΓcR M H Γ r (-(k : ℤ)) σ) (M * r) s := by
  classical
  have hM1 : 1 ≤ M := by omega
  have hMs : M.Coprime s := hsM.symm
  have hsMs : s ≤ M * s := Nat.le_mul_of_pos_left s (by omega)
  have hJs : s ≤ 2 * J := le_trans hsMs hJ
  have hNs : ¬ s ∣ H * invM r s := fun h =>
    t_mod_ne_zero H r s hs hrs hHs (Nat.mod_eq_zero_of_dvd h)
  have hcls : ∀ b ∈ range M, (Γ b ((r * s) % M) : ℂ) *
      (((sawC (GoldC.QuillonCopyC.classPhase H r s M b - 1 / M) : ℝ) : ℂ) -
        ((sawC (GoldC.QuillonCopyC.classPhase H r s M b) : ℝ) : ℂ)) =
      ∑ k ∈ Icc 1 J, (βk k * (((ampC k (M * s) : ℝ) : ℂ) *
          (eR ((((k : ℤ) * H : ℤ) : ℝ) / ((M * r : ℕ) : ℝ) / s) * cbR M H Γ r b k s)) +
        -βk k * (((ampC k (M * s) : ℝ) : ℂ) *
          (eR ((((-(k : ℤ)) * H : ℤ) : ℝ) / ((M * r : ℕ) : ℝ) / s) *
            cbR M H Γ r b (-(k : ℤ)) s))) := by
    intro b _
    rw [class_saw_eR H r s M b J hM hs hrs hHs hMs hJ, mul_sum]
    refine sum_congr rfl fun k _ => ?_
    rw [shift_phase _ M s hM1 (by omega), shift_phase _ M s hM1 (by omega),
      class_phase_R H r s M b hM (by omega) hs hrs hMs, class_phase_R H r s M b hM (by omega) hs hrs hMs]
    unfold cbR
    rw [αm_eq]
    ring
  unfold rowR
  simp only [ΓmR_mod, ΓcR_mod, one_mul]
  unfold rowAbs
  simp only [Complex.ofReal_add, Complex.ofReal_mul, Complex.ofReal_sum, Complex.ofReal_sub]
  have e0 : (H : ℝ) * invM r s / s = ((H * invM r s : ℕ) : ℝ) / s := by push_cast; ring
  rw [e0, saw_eR _ s J hs hNs hJs, sum_congr rfl hcls, sum_comm, mul_sum, ← sum_add_distrib,
    ← sum_add_distrib, ← sum_add_distrib, ← sum_add_distrib]
  refine sum_congr rfl fun k _ => ?_
  rw [main_phase_R H r s hr hs hrs, main_phase_R H r s hr hs hrs, sum_add_distrib]
  unfold ΓcR ΓmR
  rw [αm_eq, mul_sum, mul_sum, mul_sum, mul_sum, mul_sum, mul_sum]
  ring

/-- Rescaling a `rowR` row (used to normalize `‖Γ‖ ≤ 1`). -/
lemma rowR_rescale (𝒦 : Finset ℕ) (coef : ℕ → ℂ) (jm Lm : ℕ → ℕ) (Ym : ℕ → ℝ)
    (Γ : ℕ → ℕ → ℂ) (Q s : ℕ) (G : ℂ) (hG : G ≠ 0) :
    rowR 𝒦 coef jm Lm Ym Γ Q s = rowR 𝒦 (fun m => G * coef m) jm Lm Ym (fun m σ => G⁻¹ * Γ m σ) Q s := by
  unfold rowR
  refine sum_congr rfl fun m _ => ?_
  field_simp

end GoldC.QuillonRowNF

#print axioms GoldC.QuillonRowNF.kphase_intCast_eq
#print axioms GoldC.QuillonRowNF.classN_not_dvd
#print axioms GoldC.QuillonRowNF.class_saw_eR
#print axioms GoldC.QuillonRowNF.rowAbs_eq_rowW
#print axioms GoldC.QuillonRowNF.rowAbs_eq_rowR
#print axioms GoldC.QuillonRowNF.rowR_rescale
