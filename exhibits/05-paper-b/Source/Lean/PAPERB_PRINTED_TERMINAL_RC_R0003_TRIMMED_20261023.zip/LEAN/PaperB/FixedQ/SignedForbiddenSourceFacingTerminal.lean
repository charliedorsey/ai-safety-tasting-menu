import PaperB.Admission.H1
import PaperB.FixedQ.H2GlobalReaggregation
import PaperB.FixedQ.PureHeightTerminal
import PaperB.ExactAccounting.H1Reassignment

open scoped BigOperators

namespace PaperB.FixedQ

def SourceFacingMainContract : Prop :=
  ∀ q : ℕ, 0 < q → Squarefree q →
    ∀ ε : ℝ, 0 < ε →
      ∃ h0 : ℕ,
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          h0 ≤ h →
          |cStarReal q h * completedBooleanMain q a h -
            PaperB.Closure.manuscriptB1Kernel q a b h| ≤
              ε * Real.log (h : ℝ)

theorem paid_centering_residual_plus_B1_sublog
    (q : ℕ) (hq : 0 < q) (hsq : Squarefree q) :
    ∀ ε : ℝ, 0 < ε →
      ∃ h0 : ℕ,
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          h0 ≤ h →
          |cStarReal q h *
                (completedBooleanDensity q a h -
                  pureLeftFamily q a h -
                  heightBoundaryFamily q a h) +
              PaperB.Closure.manuscriptB1Kernel q a b h| ≤
            ε * Real.log (h : ℝ) := by
  intro ε hε
  let δ : ℝ := ε / 4
  have hδ : 0 < δ := by
    dsimp [δ]
    positivity
  obtain ⟨hH1, hH1spec⟩ :=
    PaperB.Admission.sourceNativeH1Control_fixedQ q hq hsq δ hδ
  obtain ⟨hD, hDspec⟩ :=
    completedBooleanDensity_sublog q hq δ hδ
  obtain ⟨hP, hPspec⟩ :=
    pureHeight_terminal_sublog q hq δ hδ
  refine ⟨max hH1 (max hD hP), ?_⟩
  intro a b h ha hb hcompat h2 hh hlarge
  have hH1h : hH1 ≤ h := (le_max_left hH1 (max hD hP)).trans hlarge
  have hDh : hD ≤ h :=
    (le_max_left hD hP).trans ((le_max_right hH1 (max hD hP)).trans hlarge)
  have hPh : hP ≤ h :=
    (le_max_right hD hP).trans ((le_max_right hH1 (max hD hP)).trans hlarge)
  obtain ⟨hleft, hright⟩ :=
    hH1spec a b h ha hb hcompat h2 hh hH1h
  have hdens := hDspec a h h2 hh hDh
  have hpure := hPspec a h h2 hh hPh
  have hreflect :=
    PaperB.Closure.reflected_coprime_equiv hq hcompat
  have hboundary :=
    heightBoundaryFamily_add_pureHeight_eq_reflectedPureLeft hreflect
  unfold PaperB.Closure.manuscriptB1Kernel
  have hdecomp :
      cStarReal q h *
            (completedBooleanDensity q a h -
              pureLeftFamily q a h -
              heightBoundaryFamily q a h) +
          (PaperB.Closure.manuscriptS1Kernel q a h +
            PaperB.Closure.manuscriptS1Kernel q
              (PaperB.Closure.reflectedResidue q b) h)
      =
        cStarReal q h * completedBooleanDensity q a h -
        (cStarReal q h * pureLeftFamily q a h -
          PaperB.Closure.manuscriptS1Kernel q a h) -
        (cStarReal q h *
            pureLeftFamily q (PaperB.Closure.reflectedResidue q b) h -
          PaperB.Closure.manuscriptS1Kernel q
            (PaperB.Closure.reflectedResidue q b) h) +
        cStarReal q h *
          (∑' e : Finset ℕ, pureHeightSupportTerm q a h e) := by
    rw [← hboundary]
    ring
  rw [hdecomp]
  calc
    |cStarReal q h * completedBooleanDensity q a h -
        (cStarReal q h * pureLeftFamily q a h -
          PaperB.Closure.manuscriptS1Kernel q a h) -
        (cStarReal q h *
            pureLeftFamily q (PaperB.Closure.reflectedResidue q b) h -
          PaperB.Closure.manuscriptS1Kernel q
            (PaperB.Closure.reflectedResidue q b) h) +
        cStarReal q h *
          (∑' e : Finset ℕ, pureHeightSupportTerm q a h e)|
      ≤ |cStarReal q h * completedBooleanDensity q a h| +
        |cStarReal q h * pureLeftFamily q a h -
          PaperB.Closure.manuscriptS1Kernel q a h| +
        |cStarReal q h *
            pureLeftFamily q (PaperB.Closure.reflectedResidue q b) h -
          PaperB.Closure.manuscriptS1Kernel q
            (PaperB.Closure.reflectedResidue q b) h| +
        |cStarReal q h *
          (∑' e : Finset ℕ, pureHeightSupportTerm q a h e)| := by
        calc
          |_|
            ≤ |cStarReal q h * completedBooleanDensity q a h -
                (cStarReal q h * pureLeftFamily q a h -
                  PaperB.Closure.manuscriptS1Kernel q a h) -
                (cStarReal q h *
                    pureLeftFamily q (PaperB.Closure.reflectedResidue q b) h -
                  PaperB.Closure.manuscriptS1Kernel q
                    (PaperB.Closure.reflectedResidue q b) h)| +
              |cStarReal q h *
                (∑' e : Finset ℕ, pureHeightSupportTerm q a h e)| :=
            abs_add_le _ _
          _ ≤
              (|cStarReal q h * completedBooleanDensity q a h| +
                |cStarReal q h * pureLeftFamily q a h -
                  PaperB.Closure.manuscriptS1Kernel q a h| +
                |cStarReal q h *
                    pureLeftFamily q (PaperB.Closure.reflectedResidue q b) h -
                  PaperB.Closure.manuscriptS1Kernel q
                    (PaperB.Closure.reflectedResidue q b) h|) +
              |cStarReal q h *
                (∑' e : Finset ℕ, pureHeightSupportTerm q a h e)| := by
            gcongr
            exact (abs_sub _ _).trans
              (add_le_add
                (abs_sub _ _)
                (le_refl _))
          _ = _ := by ring
    _ ≤ δ * Real.log (h : ℝ) +
        δ * Real.log (h : ℝ) +
        δ * Real.log (h : ℝ) +
        δ * Real.log (h : ℝ) := by
      exact add_le_add
        (add_le_add (add_le_add hdens hleft) hright) hpure
    _ = ε * Real.log (h : ℝ) := by
      dsimp [δ]
      ring

theorem paperBTerminal_of_sourceFacingMain
    (hMain : SourceFacingMainContract) :
    PaperB.Closure.PaperBTerminalStatement := by
  intro q hq hsq ε hε
  let δ : ℝ := ε / 3
  have hδ : 0 < δ := by
    dsimp [δ]
    positivity
  obtain ⟨hM, hMspec⟩ := hMain q hq hsq δ hδ
  obtain ⟨hD, hDspec⟩ :=
    completedBooleanDensity_sublog q hq δ hδ
  obtain ⟨hP, hPspec⟩ :=
    pureHeight_terminal_sublog q hq δ hδ
  refine ⟨max hM (max hD hP), ?_⟩
  intro a b h ha hb hcompat h2 hh hlarge
  have hMh : hM ≤ h := (le_max_left hM (max hD hP)).trans hlarge
  have hDh : hD ≤ h :=
    (le_max_left hD hP).trans ((le_max_right hM (max hD hP)).trans hlarge)
  have hPh : hP ≤ h :=
    (le_max_right hD hP).trans ((le_max_right hM (max hD hP)).trans hlarge)
  have hm := hMspec a b h ha hb hcompat h2 hh hMh
  have hd := hDspec a h h2 hh hDh
  have hp := hPspec a h h2 hh hPh
  have hreflect :=
    PaperB.Closure.reflected_coprime_equiv hq hcompat
  have hfull := fullPairFamily_eq_completedBoolean_visible
    (q := q) (a := a)
    (r := PaperB.Closure.reflectedResidue q b) (h := h)
    hq hh h2 hreflect
  have hA := manuscriptA1Kernel_eq_boundary_families_add_twoDimensional
    (q := q) (a := a) (h := h) h2
  have hold := fullPairFamily_eq_boundary_families_add_twoDimensional q a h
  rw [hfull] at hold
  have hvisible :
      manuscriptA1Kernel q a h =
        cStarReal q h *
          (completedBooleanMain q a h +
            completedBooleanDensity q a h +
            (∑' e : Finset ℕ, pureHeightSupportTerm q a h e)) := by
    rw [hA]
    rw [← hold]
  rw [hvisible]
  have hdecomp :
      cStarReal q h *
          (completedBooleanMain q a h +
            completedBooleanDensity q a h +
            (∑' e : Finset ℕ, pureHeightSupportTerm q a h e)) -
        PaperB.Closure.manuscriptB1Kernel q a b h
      =
        (cStarReal q h * completedBooleanMain q a h -
          PaperB.Closure.manuscriptB1Kernel q a b h) +
        cStarReal q h * completedBooleanDensity q a h +
        cStarReal q h *
          (∑' e : Finset ℕ, pureHeightSupportTerm q a h e) := by
    ring
  rw [hdecomp]
  calc
    |(cStarReal q h * completedBooleanMain q a h -
          PaperB.Closure.manuscriptB1Kernel q a b h) +
        cStarReal q h * completedBooleanDensity q a h +
        cStarReal q h *
          (∑' e : Finset ℕ, pureHeightSupportTerm q a h e)|
      ≤ |cStarReal q h * completedBooleanMain q a h -
          PaperB.Closure.manuscriptB1Kernel q a b h| +
        |cStarReal q h * completedBooleanDensity q a h| +
        |cStarReal q h *
          (∑' e : Finset ℕ, pureHeightSupportTerm q a h e)| := by
        exact (abs_add_le _ _).trans
          (add_le_add (abs_add_le _ _) (le_refl _))
    _ ≤ δ * Real.log (h : ℝ) +
          δ * Real.log (h : ℝ) +
          δ * Real.log (h : ℝ) := by
        exact add_le_add (add_le_add hm hd) hp
    _ = ε * Real.log (h : ℝ) := by
      dsimp [δ]
      ring

end PaperB.FixedQ

#print axioms PaperB.FixedQ.paid_centering_residual_plus_B1_sublog
#print axioms PaperB.FixedQ.paperBTerminal_of_sourceFacingMain
