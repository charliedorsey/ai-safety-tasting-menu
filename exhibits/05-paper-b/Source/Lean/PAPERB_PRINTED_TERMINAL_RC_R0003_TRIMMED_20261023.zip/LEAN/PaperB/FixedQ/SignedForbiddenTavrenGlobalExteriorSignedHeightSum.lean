import PaperB.FixedQ.SignedForbiddenTavrenGlobalExteriorSignedTsum

open scoped BigOperators Classical

namespace PaperB.FixedQ

/-- Full SIGNED reduced ordinary exterior beyond the original
height cutoff Z(h), keeping the forbidden height-divisor block d.
Do not change Z(h) into a different reduced-height cutoff. -/
noncomputable def tavrenReducedExteriorSignedCore
    (q A H Z : ℕ) (d : Finset ℕ) : ℝ :=
  ∑' n : Finset ℕ,
    if Z < primeSetProduct n then
      dForbiddenReducedBooleanCoreTerm q A H d n
    else 0

theorem tavren_summable_reducedExteriorSignedCore
    {q A H Z : ℕ} (hq : 0 < q) (hH : 0 < H)
    (h2 : ¬ 2 ∣ q → 2 ∣ H) (d : Finset ℕ) :
    Summable (fun n : Finset ℕ =>
      if Z < primeSetProduct n then
        dForbiddenReducedBooleanCoreTerm q A H d n
      else 0) := by
  have hs := summable_abs_ordinaryBooleanCoreTerm
    (q := q) (a := A) (h := H) hq hH h2
  apply Summable.of_norm_bounded hs
  intro n
  rw [Real.norm_eq_abs]
  by_cases hgt : Z < primeSetProduct n
  · simpa [hgt] using
      abs_dForbiddenReducedBooleanCoreTerm_le q A H d n
  · simp [hgt]

/-- Finite over ALL height-prime subsets, signed in the inner
nonheight family AND signed across height subsets. Not an L1 majorant. -/
theorem tavren_tsum_signedReindex_eq_signedHeightSum
    {q a h Z : ℕ}
    (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    (∑' x : (Finset ℕ × Finset ℕ) ⊕ Finset ℕ,
      tavrenGlobalExteriorSignedReindexTerm q a h Z x) =
      ∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
        finiteVWeightReal h d *
          tavrenReducedExteriorSignedCore q
            (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d) Z d := by
  have hPair := tavren_summable_globalExteriorSignedPair
    (q := q) (a := a) (h := h) (Z := Z) hq hh h2
  have hInl : Summable
      (tavrenGlobalExteriorSignedReindexTerm q a h Z ∘ Sum.inl) := by
    simpa [Function.comp_def, tavrenGlobalExteriorSignedReindexTerm]
      using hPair
  have hInr : Summable
      (tavrenGlobalExteriorSignedReindexTerm q a h Z ∘ Sum.inr) := by
    simp [Function.comp_def, tavrenGlobalExteriorSignedReindexTerm]
  rw [Summable.tsum_sum hInl hInr]
  simp only [tavrenGlobalExteriorSignedReindexTerm, tsum_zero, add_zero]
  rw [hPair.tsum_prod]
  rw [tsum_eq_sum (s := (decoratedHeightPrimeSet q h).powerset)]
  · apply Finset.sum_congr rfl
    intro d hd
    have hHpos := decoratedReducedHeight_pos_of_mem hh hd
    have hHpar := decoratedReducedHeight_parity_of_mem h2 hd
    have hrow := tavren_summable_reducedExteriorSignedCore
      (q := q)
      (A := decoratedReducedAnchor q a (primeSetProduct d))
      (H := h / primeSetProduct d) (Z := Z)
      hq (by simpa [decoratedReducedHeight, decoratedHeightProduct] using hHpos)
      (by simpa [decoratedReducedHeight, decoratedHeightProduct] using hHpar)
      d
    unfold tavrenReducedExteriorSignedCore
    calc
      (∑' n : Finset ℕ,
        tavrenGlobalExteriorSignedPairTerm q a h Z (d, n))
        = ∑' n : Finset ℕ,
          finiteVWeightReal h d *
            (if Z < primeSetProduct n then
              dForbiddenReducedBooleanCoreTerm q
                (decoratedReducedAnchor q a (primeSetProduct d))
                (h / primeSetProduct d) d n
            else 0) := by
              apply tsum_congr
              intro n
              unfold tavrenGlobalExteriorSignedPairTerm
              dsimp
              rw [if_pos hd]
              split_ifs <;> ring
      _ = finiteVWeightReal h d *
          (∑' n : Finset ℕ,
            if Z < primeSetProduct n then
              dForbiddenReducedBooleanCoreTerm q
                (decoratedReducedAnchor q a (primeSetProduct d))
                (h / primeSetProduct d) d n
            else 0) := by
          exact hrow.tsum_mul_left (finiteVWeightReal h d)
  · intro d hd
    have hnot : d ∉ (decoratedHeightPrimeSet q h).powerset := hd
    simp [tavrenGlobalExteriorSignedPairTerm, hnot]

/-- SOURCE EXACT actual exterior, without ANY absolute value before
summing d and n. This is the algebraic interface a genuine global
signed o(log h) estimate must feed. -/
theorem tavren_globalProperExterior_eq_signedHeightSum
    {q a h Z : ℕ}
    (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    globalProperExteriorAnalytic q a h Z =
      ∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
        finiteVWeightReal h d *
          tavrenReducedExteriorSignedCore q
            (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d) Z d := by
  rw [tavren_globalProperExteriorAnalytic_eq_signedReindex_tsum hh]
  exact tavren_tsum_signedReindex_eq_signedHeightSum hq hh h2

#print axioms tavren_globalProperExterior_eq_signedHeightSum

end PaperB.FixedQ
