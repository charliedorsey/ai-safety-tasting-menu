import GoldC.QuillonPContext

/-!
# Quillon CSC3 F7.5h: explicit, `B`-monotone majorant of the Type II closed form

`TIIb P c U V T B ≤ TIIx P c U V T B`, where `TIIx` replaces `Jstop` by `T(log₂B+1)` and `t_J` by
`U + 2B/(V+1)`. Every factor of `TIIx` is nondecreasing in `B` (`TIIx_mono`).

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonExplicit

open GoldC.QuillonPContext GoldC.QuillonPartition

variable {s : ℕ} [NeZero s]

/-- Explicit Type II majorant. -/
noncomputable def TIIx (P : Finset ℕ) (c : ZMod s) (U V T B : ℕ) : ℝ :=
  Real.sqrt (2 * (1 + Real.log ((U : ℝ) + 2 * B)) ^ 4) *
    Real.sqrt (Real.log B ^ 2 * B * ((T : ℝ) * (Nat.log 2 B + 1)) *
      (2 * B / ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ) +
        2 * ((U : ℝ) + 2 * B / ((V : ℝ) + 1)) +
        s * B / (U * ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ)) +
        s)) +
  Real.log B * (1 + Real.log ((U : ℝ) + 2 * B)) ^ 4 *
    (2 * B / T + 2 * B / U + 2 * ((U : ℝ) + 2 * B / ((V : ℝ) + 1)))

lemma TIIb_le_TIIx (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (c : ZMod s) (U V T B : ℕ)
    (hU : 2 ≤ U) (hT : 2 ≤ T) (hB : 1 ≤ B) :
    TIIb P c U V T B ≤ TIIx P c U V T B := by
  unfold TIIb TIIx
  have hU' : max U 2 = U := max_eq_left hU
  have hT' : max T 2 = T := max_eq_left hT
  simp only [hU', hT']
  set J := Jstop U T V B (by omega) (by omega) with hJ
  set tJ := tseq U T J with htJ
  have hJle : (J : ℝ) ≤ (T : ℝ) * (Nat.log 2 B + 1) := by
    have := Jstop_le V B (U := U) (T := T) (by omega) (by omega)
    rw [← hJ] at this
    have : (J : ℝ) ≤ ((Nat.log 2 B + 1) * T : ℕ) := by exact_mod_cast this
    push_cast at this; linarith
  have htJ1 : ((V : ℝ) + 1) * tJ ≤ ((V : ℝ) + 1) * U + 2 * B := by
    have := tJstop_le V B (U := U) (T := T) hT hU
    have h' : (V + 1) * tseq U T (Jstop U T V B (by omega) (by omega)) ≤ (V + 1) * U + 2 * B := this
    rw [← hJ, ← htJ] at h'
    exact_mod_cast h'
  have hV1 : (0 : ℝ) < (V : ℝ) + 1 := by positivity
  have htJle : (tJ : ℝ) ≤ (U : ℝ) + 2 * B / ((V : ℝ) + 1) := by
    rw [← sub_nonneg]
    have e : (U : ℝ) + 2 * B / ((V : ℝ) + 1) - tJ =
        (((V : ℝ) + 1) * U + 2 * B - ((V : ℝ) + 1) * tJ) / ((V : ℝ) + 1) := by
      field_simp
    rw [e]; exact div_nonneg (by linarith) hV1.le
  have htJpos : (1 : ℝ) ≤ tJ := by
    have := tseq_ge (U := U) (T := T) J
    exact_mod_cast (show 1 ≤ tJ by omega)
  have hBR : (1 : ℝ) ≤ B := by exact_mod_cast hB
  have htJle2 : (tJ : ℝ) ≤ (U : ℝ) + 2 * B := by
    have : 2 * (B : ℝ) / ((V : ℝ) + 1) ≤ 2 * B := div_le_self (by positivity) (by linarith)
    linarith
  have hlog : Real.log tJ ≤ Real.log ((U : ℝ) + 2 * B) := Real.log_le_log (by linarith) htJle2
  have hlog0 : 0 ≤ Real.log tJ := Real.log_nonneg htJpos
  have hlogB : 0 ≤ Real.log B := Real.log_natCast_nonneg B
  have hg : (0 : ℝ) < ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ) := by
    have : 0 < ∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p :=
      Finset.prod_pos fun p hp => (hP p (filter_subset _ _ hp)).pos
    exact_mod_cast this
  have hUR : (0 : ℝ) < U := by exact_mod_cast (show 0 < U by omega)
  have hTR : (0 : ℝ) < T := by exact_mod_cast (show 0 < T by omega)
  gcongr

end GoldC.QuillonExplicit

#print axioms GoldC.QuillonExplicit.TIIb_le_TIIx
