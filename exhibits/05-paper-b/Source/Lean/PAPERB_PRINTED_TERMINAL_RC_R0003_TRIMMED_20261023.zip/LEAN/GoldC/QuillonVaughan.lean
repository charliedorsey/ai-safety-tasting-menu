import Mathlib.NumberTheory.ArithmeticFunction.VonMangoldt
import Mathlib.Tactic

/-!
# Quillon CSC3 F4: Vaughan's identity (exact, as an identity of arithmetic functions)

With truncations `f_{≤U}(n) = 1[n ≤ U] f(n)` and `f_{>U} = f − f_{≤U}`:

    Λ_{>V} = μ_{≤U} * log − μ_{≤U} * Λ_{≤V} * ζ + μ_{>U} * Λ_{>V} * ζ.

So for `n > V`, `Λ(n)` equals the Type I₁ minus Type I₂ plus Type II convolutions evaluated at `n`.
The proof is ring algebra from `μ * ζ = 1` and `Λ * ζ = log`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open ArithmeticFunction

namespace GoldC.QuillonVaughan

/-- Truncation `f_{≤U}`. -/
noncomputable def trunc (U : ℕ) (f : ArithmeticFunction ℝ) : ArithmeticFunction ℝ :=
  ⟨fun n => if n ≤ U then f n else 0, by simp⟩

/-- Upper part `f_{>U}`. -/
noncomputable def upper (U : ℕ) (f : ArithmeticFunction ℝ) : ArithmeticFunction ℝ :=
  ⟨fun n => if n ≤ U then 0 else f n, by simp⟩

lemma trunc_add_upper (U : ℕ) (f : ArithmeticFunction ℝ) : trunc U f + upper U f = f := by
  ext n
  rw [ArithmeticFunction.add_apply]
  show (if n ≤ U then f n else 0) + (if n ≤ U then 0 else f n) = f n
  split_ifs <;> simp

lemma trunc_apply (U : ℕ) (f : ArithmeticFunction ℝ) (n : ℕ) :
    trunc U f n = if n ≤ U then f n else 0 := rfl

lemma upper_apply (U : ℕ) (f : ArithmeticFunction ℝ) (n : ℕ) :
    upper U f n = if n ≤ U then 0 else f n := rfl

/-- **Vaughan's identity.** -/
theorem vaughan (U V : ℕ) :
    upper V (vonMangoldt : ArithmeticFunction ℝ) =
      trunc U ((moebius : ArithmeticFunction ℤ) : ArithmeticFunction ℝ) * log -
        trunc U ((moebius : ArithmeticFunction ℤ) : ArithmeticFunction ℝ) * trunc V vonMangoldt * ((zeta : ArithmeticFunction ℕ) : ArithmeticFunction ℝ) +
        upper U ((moebius : ArithmeticFunction ℤ) : ArithmeticFunction ℝ) * upper V vonMangoldt * ((zeta : ArithmeticFunction ℕ) : ArithmeticFunction ℝ) := by
  set a := trunc U ((moebius : ArithmeticFunction ℤ) : ArithmeticFunction ℝ)
  set b := upper U ((moebius : ArithmeticFunction ℤ) : ArithmeticFunction ℝ)
  set c := trunc V (vonMangoldt : ArithmeticFunction ℝ)
  set d := upper V (vonMangoldt : ArithmeticFunction ℝ)
  have h1 : (a + b) * ((zeta : ArithmeticFunction ℕ) : ArithmeticFunction ℝ) = 1 := by
    rw [trunc_add_upper]; exact coe_moebius_mul_coe_zeta
  have h2 : (c + d) * ((zeta : ArithmeticFunction ℕ) : ArithmeticFunction ℝ) = log := by
    rw [trunc_add_upper]; exact vonMangoldt_mul_zeta
  linear_combination (-d) * h1 + a * h2

/-- Pointwise form for `n > V`. -/
theorem vaughan_apply (U V n : ℕ) (hn : V < n) :
    (vonMangoldt n : ℝ) =
      (trunc U ((moebius : ArithmeticFunction ℤ) : ArithmeticFunction ℝ) * log) n -
        (trunc U ((moebius : ArithmeticFunction ℤ) : ArithmeticFunction ℝ) * trunc V vonMangoldt * ((zeta : ArithmeticFunction ℕ) : ArithmeticFunction ℝ)) n +
        (upper U ((moebius : ArithmeticFunction ℤ) : ArithmeticFunction ℝ) * upper V vonMangoldt * ((zeta : ArithmeticFunction ℕ) : ArithmeticFunction ℝ)) n := by
  have := congrArg (fun f : ArithmeticFunction ℝ => f n) (vaughan U V)
  simp only [upper_apply, if_neg (show ¬ n ≤ V by omega), sub_eq_add_neg,
    ArithmeticFunction.add_apply, ArithmeticFunction.neg_apply] at this ⊢
  exact this

end GoldC.QuillonVaughan

#print axioms GoldC.QuillonVaughan.vaughan
#print axioms GoldC.QuillonVaughan.vaughan_apply
