import PaperB.FixedQ.GlobalProperExteriorBridge
import PaperB.FixedQ.SignedForbiddenBridge

open scoped BigOperators Classical

namespace PaperB.FixedQ

/-- Signed, source-exact exterior row, without taking absolute values
inside the non-height-prime family. Both d=empty and d nonempty are kept. -/
noncomputable def tavrenGlobalExteriorSignedPairTerm
    (q a h Z : ℕ) (dn : Finset ℕ × Finset ℕ) : ℝ :=
  let d := dn.1
  let n := dn.2
  if hd : d ∈ (decoratedHeightPrimeSet q h).powerset then
    if Z < primeSetProduct n then
      finiteVWeightReal h d *
        dForbiddenReducedBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) d n
    else 0
  else 0

noncomputable def tavrenGlobalExteriorSignedReindexTerm
    (q a h Z : ℕ)
    (x : (Finset ℕ × Finset ℕ) ⊕ Finset ℕ) : ℝ :=
  match x with
  | Sum.inl dn => tavrenGlobalExteriorSignedPairTerm q a h Z dn
  | Sum.inr _ => 0

/-- The native global exterior summand is identical to a signed
height/nonheight pair summand under the existing injective CRT key.
No absolute value, no free D, and no invented endpoint correction. -/
theorem tavren_globalExterior_indicator_eq_signedReindex
    {q a h Z : ℕ} (hh : 0 < h) (e : Finset ℕ) :
    (globalProperSmallSet h Z)ᶜ.indicator
      (decoratedAnalyticPerE q a h) e =
    tavrenGlobalExteriorSignedReindexTerm q a h Z
      (decoratedAnalyticSignedReindexKey q h e) := by
  classical
  by_cases hA : ∀ p ∈ e, activeHighPrime q p
  · let d := heightPrimePart h e
    let n := e \ d
    have hdsub : d ⊆ decoratedHeightPrimeSet q h := by
      dsimp [d]
      exact heightPrimePart_subset_decoratedHeightPrimeSet_of_active hh hA
    have hdmem : d ∈ (decoratedHeightPrimeSet q h).powerset :=
      Finset.mem_powerset.mpr hdsub
    rw [decoratedAnalyticSignedReindexKey, if_pos hA]
    simp only [tavrenGlobalExteriorSignedReindexTerm]
    by_cases hext : e ∈ (globalProperSmallSet h Z)ᶜ
    · rw [Set.indicator_of_mem hext]
      have hnotSmall : e ∉ globalProperSmallSet h Z := by
        simpa using hext
      have hgt : Z < primeSetProduct n := by
        have hnotLe : ¬ primeSetProduct n ≤ Z := by
          intro hle
          apply hnotSmall
          simpa [globalProperSmallSet, d, n] using hle
        omega
      have hdis : Disjoint d n := by
        dsimp [n]
        exact Finset.disjoint_sdiff
      have hn : n ∈ activeOrdinaryTwoDimensionalSet q
          (h / primeSetProduct d) := by
        have h0 := decorated_nonheight_activeOrdinary
          (q := q) (h := h) (e := e) hA
        simpa [d, n, decoratedReducedHeight, decoratedHeightProduct] using h0
      have hmain :=
        decoratedAnalyticPerE_eq_height_weight_mul_boolean
          (q := q) (a := a) (h := h) (e := e) hA
      have hmain' :
          decoratedAnalyticPerE q a h e =
            finiteVWeightReal h d * finiteOmegaWeightReal n *
              ordinaryBooleanInteriorDiscrepancy
                (fixedQLowWeight q
                  (decoratedReducedAnchor q a (primeSetProduct d))
                  (h / primeSetProduct d))
                (h / primeSetProduct d) n := by
        simpa [d, n, decoratedHeightProduct, decoratedReducedHeight] using hmain
      have hcore :
          ordinaryBooleanCoreTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) n =
            finiteOmegaWeightReal n *
              ordinaryBooleanInteriorDiscrepancy
                (fixedQLowWeight q
                  (decoratedReducedAnchor q a (primeSetProduct d))
                  (h / primeSetProduct d))
                (h / primeSetProduct d) n := by
        rw [ordinaryBooleanCoreTerm, Set.indicator_of_mem hn]
      have hforbid :
          dForbiddenReducedBooleanCoreTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) d n =
            ordinaryBooleanCoreTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) n := by
        simp [dForbiddenReducedBooleanCoreTerm, hdis]
      simp only [tavrenGlobalExteriorSignedPairTerm]
      dsimp
      rw [if_pos hdmem, if_pos hgt]
      rw [hmain', hforbid, hcore]
      ring
    · have hleft :
          (globalProperSmallSet h Z)ᶜ.indicator
            (decoratedAnalyticPerE q a h) e = 0 := by
          simp [Set.indicator, hext]
      rw [hleft]
      have hsmall : e ∈ globalProperSmallSet h Z := by
        simpa using hext
      have hnotGt : ¬ Z < primeSetProduct n := by
        have hle : primeSetProduct n ≤ Z := by
          simpa [globalProperSmallSet, d, n] using hsmall
        omega
      change (0 : ℝ) = tavrenGlobalExteriorSignedPairTerm q a h Z (d,n)
      unfold tavrenGlobalExteriorSignedPairTerm
      dsimp
      rw [if_pos hdmem, if_neg hnotGt]
  · rw [decoratedAnalyticSignedReindexKey, if_neg hA]
    have hz := decoratedAnalyticPerE_eq_zero_of_not_all_active
      (q := q) (a := a) (h := h) (e := e) hA
    simp [tavrenGlobalExteriorSignedReindexTerm, hz]

#print axioms tavren_globalExterior_indicator_eq_signedReindex

end PaperB.FixedQ
