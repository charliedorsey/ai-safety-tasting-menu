import PaperB.FixedQ.SignedForbiddenShiuQuarterMoment

open scoped BigOperators

namespace PaperB.FixedQ

lemma fixedQShiuWeight_div_le_quarter_rankin
    (q : ℕ) {H m : ℕ} (hH : 0 < H) (hgt : H ^ 2 < m) :
    fixedQShiuWeight q m / (m : ℝ) ≤
      (H : ℝ) ^ (-3 / 2 : ℝ) *
        (fixedQShiuWeight q m * (m : ℝ) ^ (-1 / 4 : ℝ)) := by
  have hmpos : 0 < m := by
    have : 0 < H ^ 2 := pow_pos hH _
    omega
  have hHR : (0 : ℝ) < H := by exact_mod_cast hH
  have hmR : (0 : ℝ) < m := by exact_mod_cast hmpos
  have hbase : (H : ℝ) ^ (2 : ℕ) ≤ (m : ℝ) := by
    exact_mod_cast (Nat.le_of_lt hgt)
  have hpow0 : (0 : ℝ) < (H : ℝ) ^ (2 : ℕ) := pow_pos hHR _
  have hpow :
      (m : ℝ) ^ (-3 / 4 : ℝ) ≤
        ((H : ℝ) ^ (2 : ℕ)) ^ (-3 / 4 : ℝ) :=
    Real.rpow_le_rpow_of_nonpos hpow0 hbase (by norm_num)
  have hHid :
      ((H : ℝ) ^ (2 : ℕ)) ^ (-3 / 4 : ℝ) =
        (H : ℝ) ^ (-3 / 2 : ℝ) := by
    have hm := (Real.rpow_mul hHR.le (2 : ℝ) (-3 / 4 : ℝ)).symm
    convert hm using 1 <;> norm_num [Real.rpow_natCast]
  have hpow' :
      (m : ℝ) ^ (-3 / 4 : ℝ) ≤
        (H : ℝ) ^ (-3 / 2 : ℝ) := by
    rw [← hHid]
    exact hpow
  have hsplit :
      ((m : ℝ)⁻¹) =
        (m : ℝ) ^ (-1 / 4 : ℝ) *
          (m : ℝ) ^ (-3 / 4 : ℝ) := by
    calc
      ((m : ℝ)⁻¹) = (m : ℝ) ^ (-1 : ℝ) := by
        symm
        exact Real.rpow_neg_one (m : ℝ)
      _ = (m : ℝ) ^ ((-1 / 4 : ℝ) + (-3 / 4 : ℝ)) := by norm_num
      _ = (m : ℝ) ^ (-1 / 4 : ℝ) *
          (m : ℝ) ^ (-3 / 4 : ℝ) :=
        Real.rpow_add hmR (-1 / 4) (-3 / 4)
  have hw0 : 0 ≤ fixedQShiuWeight q m :=
    fixedQShiuWeight_nonneg q m
  have hq0 : 0 ≤ (m : ℝ) ^ (-1 / 4 : ℝ) :=
    Real.rpow_nonneg hmR.le _
  calc
    fixedQShiuWeight q m / (m : ℝ)
        = fixedQShiuWeight q m * ((m : ℝ)⁻¹) := by
            rw [div_eq_mul_inv]
    _ = (fixedQShiuWeight q m * (m : ℝ) ^ (-1 / 4 : ℝ)) *
          (m : ℝ) ^ (-3 / 4 : ℝ) := by
            rw [hsplit]
            ring
    _ ≤ (fixedQShiuWeight q m * (m : ℝ) ^ (-1 / 4 : ℝ)) *
          (H : ℝ) ^ (-3 / 2 : ℝ) :=
        mul_le_mul_of_nonneg_left hpow' (mul_nonneg hw0 hq0)
    _ = (H : ℝ) ^ (-3 / 2 : ℝ) *
        (fixedQShiuWeight q m * (m : ℝ) ^ (-1 / 4 : ℝ)) := by ring

noncomputable def fixedQShiuReciprocalFarTail
    (q H : ℕ) : ℝ :=
  ∑' m : ℕ,
    if H ^ 2 < m then fixedQShiuWeight q m / (m : ℝ) else 0

theorem fixedQShiuReciprocalFarTail_le_quarter
    (q : ℕ) {H : ℕ} (hH : 0 < H) :
    fixedQShiuReciprocalFarTail q H ≤
      (H : ℝ) ^ (-3 / 2 : ℝ) * fixedQShiuQuarterMoment q := by
  let f : ℕ → ℝ := fun m =>
    if H ^ 2 < m then fixedQShiuWeight q m / (m : ℝ) else 0
  let g : ℕ → ℝ := fun m =>
    (H : ℝ) ^ (-3 / 2 : ℝ) *
      (fixedQShiuWeight q m * (m : ℝ) ^ (-1 / 4 : ℝ))
  have hf0 : ∀ m, 0 ≤ f m := by
    intro m
    dsimp [f]
    split_ifs
    · exact div_nonneg (fixedQShiuWeight_nonneg q m) (by positivity)
    · exact le_rfl
  have hfg : ∀ m, f m ≤ g m := by
    intro m
    dsimp [f, g]
    by_cases hm : H ^ 2 < m
    · rw [if_pos hm]
      exact fixedQShiuWeight_div_le_quarter_rankin q hH hm
    · rw [if_neg hm]
      exact mul_nonneg
        (Real.rpow_nonneg (by positivity) _)
        (mul_nonneg (fixedQShiuWeight_nonneg q m)
          (Real.rpow_nonneg (by positivity) _))
  have hg : Summable g := by
    dsimp [g]
    exact (summable_fixedQShiuWeight_mul_quarter q).mul_left
      ((H : ℝ) ^ (-3 / 2 : ℝ))
  have hf : Summable f :=
    Summable.of_nonneg_of_le hf0 hfg hg
  have hsum := hf.tsum_le_tsum hfg hg
  simpa [fixedQShiuReciprocalFarTail, f, g,
    fixedQShiuQuarterMoment, tsum_mul_left] using hsum

#print axioms fixedQShiuReciprocalFarTail_le_quarter

end PaperB.FixedQ
