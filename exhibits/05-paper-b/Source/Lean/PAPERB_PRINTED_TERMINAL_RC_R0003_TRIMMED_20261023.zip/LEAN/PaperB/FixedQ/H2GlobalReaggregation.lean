import PaperB.FixedQ.DecoratedTerminalSpine
import PaperB.Closure

open scoped BigOperators

namespace PaperB.FixedQ

def completedBooleanSupport (q h : ℕ) : Set (Finset ℕ) :=
  {e | (∀ p ∈ e, activeHighPrime q p) ∧ heightPrimePart h e ≠ e}

noncomputable def completedBooleanMainTerm
    (q a h : ℕ) (e : Finset ℕ) : ℝ :=
  (completedBooleanSupport q h).indicator
    (fun e =>
      let d := heightPrimePart h e
      let n := e \ d
      let D := decoratedHeightProduct h e
      let H := decoratedReducedHeight h e
      let aD := decoratedReducedAnchor q a D
      finiteVWeightReal h d * finiteOmegaWeightReal n *
        ((2 : ℝ) ^ n.card *
          fixedProductBooleanDiscrepancy
            (fixedQLowWeight q aD H) H n)) e

noncomputable def completedBooleanDensityTerm
    (q a h : ℕ) (e : Finset ℕ) : ℝ :=
  (completedBooleanSupport q h).indicator
    (fun e =>
      decoratedDensityPerE q a h e +
        decoratedDensityPairTerm q a h e e +
        decoratedDensityPairTerm q a h e (heightPrimePart h e)) e

noncomputable def completedBooleanMain (q a h : ℕ) : ℝ :=
  ∑' e : Finset ℕ, completedBooleanMainTerm q a h e

noncomputable def completedBooleanDensity (q a h : ℕ) : ℝ :=
  ∑' e : Finset ℕ, completedBooleanDensityTerm q a h e

theorem twoDimensionalPerE_eq_completedBoolean_global
    {q a h : ℕ} (hq : 0 < q) (e : Finset ℕ) :
    twoDimensionalPerE q a h e =
      completedBooleanMainTerm q a h e +
      completedBooleanDensityTerm q a h e -
      combinedBooleanFullEndpointTerm q a h e -
      combinedBooleanEmptyEndpointTerm q a h e := by
  by_cases hA : ∀ p ∈ e, activeHighPrime q p
  · by_cases hall : heightPrimePart h e = e
    · have hzero := twoDimensionalPerE_eq_zero_of_all_height
        (q := q) (a := a) (h := h) (e := e) hA hall
      rw [hzero]
      have hnot : e ∉ completedBooleanSupport q h := by
        intro he
        exact he.2 hall
      simp [completedBooleanMainTerm, completedBooleanDensityTerm,
        Set.indicator, hnot, combinedBooleanFullEndpointTerm,
        combinedBooleanEmptyEndpointTerm, hall]
    · have hmem : e ∈ completedBooleanSupport q h := ⟨hA, hall⟩
      rw [completedBooleanMainTerm, Set.indicator_of_mem hmem]
      rw [completedBooleanDensityTerm, Set.indicator_of_mem hmem]
      exact twoDimensionalPerE_eq_completed_boolean_residual
        (q := q) (a := a) (h := h) hq hA hall
  · have hzero := twoDimensionalPerE_eq_zero_of_not_all_active
      (q := q) (a := a) (h := h) (e := e) hA
    rw [hzero]
    have hnot : e ∉ completedBooleanSupport q h := by
      intro he
      exact hA he.1
    simp only [completedBooleanMainTerm, completedBooleanDensityTerm]
    simp [Set.indicator, hnot]
    by_cases hall : heightPrimePart h e = e
    · simp [combinedBooleanFullEndpointTerm,
        combinedBooleanEmptyEndpointTerm, hall]
    · have hzFull := pairCoefficient_eq_zero_of_not_all_active
        (q := q) (h := h) (e := e) (e1 := e) hA
      have hzEmpty := pairCoefficient_eq_zero_of_not_all_active
        (q := q) (h := h) (e := e)
        (e1 := heightPrimePart h e) hA
      simp [combinedBooleanFullEndpointTerm,
        combinedBooleanEmptyEndpointTerm, hall,
        decoratedAnalyticPairTerm, decoratedDensityPairTerm,
        hzFull, hzEmpty]

theorem pairBaseline_le_normalizationWeightMass
    (q h : ℕ) {e e1 : Finset ℕ} (he1 : e1 ⊆ e) :
    pairCoefficient q h e e1 / pairDenominator e e1 ≤
      normalizationWeightMass q h e := by
  rw [normalizationWeightMass_eq_pairBaselineSum]
  have hmem : e1 ∈ e.powerset := Finset.mem_powerset.mpr he1
  exact Finset.single_le_sum
    (fun x hx => pairBaseline_nonneg q h e x) hmem

theorem summable_completedBooleanDensityInteriorTerm
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    Summable (fun e : Finset ℕ =>
      (completedBooleanSupport q h).indicator
        (decoratedDensityPerE q a h) e) := by
  let C : ℝ := genericFixedQPeriodicDensityBound q * (h : ℝ)
  have hmajor :
      Summable (fun e : Finset ℕ => C * normalizationWeightMass q h e) :=
    (summable_normalizationWeightMass q h).mul_left C
  apply hmajor.of_norm_bounded
  intro e
  by_cases he : e ∈ completedBooleanSupport q h
  · rw [Set.indicator_of_mem he, Real.norm_eq_abs]
    exact abs_decoratedDensityPerE_le_normalization
      (q := q) (a := a) (h := h) hq hh h2admissible e
  · simp [Set.indicator, he]
    exact mul_nonneg
      (by
        dsimp [C]
        apply mul_nonneg
        · unfold genericFixedQPeriodicDensityBound
            fixedQDensityDefectUniformBound admissibleCountMeanErrorBound
          positivity
        · positivity)
      (normalizationWeightMass_nonneg q h e)

theorem summable_completedBooleanFullDensityTerm
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    Summable (fun e : Finset ℕ =>
      (completedBooleanSupport q h).indicator
        (fun e => decoratedDensityPairTerm q a h e e) e) := by
  let C : ℝ := genericFixedQPeriodicDensityBound q * (h : ℝ)
  have hC0 : 0 ≤ C := by
    dsimp [C]
    apply mul_nonneg
    · unfold genericFixedQPeriodicDensityBound
        fixedQDensityDefectUniformBound admissibleCountMeanErrorBound
      positivity
    · positivity
  have hmajor :
      Summable (fun e : Finset ℕ => C * normalizationWeightMass q h e) :=
    (summable_normalizationWeightMass q h).mul_left C
  apply hmajor.of_norm_bounded
  intro e
  by_cases he : e ∈ completedBooleanSupport q h
  · rw [Set.indicator_of_mem he, Real.norm_eq_abs]
    have h0 := abs_decoratedDensityPairTerm_le_h_mul_baseline
      (q := q) (a := a) (h := h) hq hh h2admissible
      (e := e) (e1 := e) (fun _ hp => hp)
    have hb := pairBaseline_le_normalizationWeightMass q h
      (e := e) (e1 := e) (fun _ hp => hp)
    exact h0.trans (mul_le_mul_of_nonneg_left hb hC0)
  · simp [Set.indicator, he]
    exact mul_nonneg hC0 (normalizationWeightMass_nonneg q h e)

theorem summable_completedBooleanEmptyDensityTerm
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    Summable (fun e : Finset ℕ =>
      (completedBooleanSupport q h).indicator
        (fun e => decoratedDensityPairTerm q a h e (heightPrimePart h e)) e) := by
  let C : ℝ := genericFixedQPeriodicDensityBound q * (h : ℝ)
  have hC0 : 0 ≤ C := by
    dsimp [C]
    apply mul_nonneg
    · unfold genericFixedQPeriodicDensityBound
        fixedQDensityDefectUniformBound admissibleCountMeanErrorBound
      positivity
    · positivity
  have hmajor :
      Summable (fun e : Finset ℕ => C * normalizationWeightMass q h e) :=
    (summable_normalizationWeightMass q h).mul_left C
  apply hmajor.of_norm_bounded
  intro e
  by_cases he : e ∈ completedBooleanSupport q h
  · rw [Set.indicator_of_mem he, Real.norm_eq_abs]
    have hdsub : heightPrimePart h e ⊆ e := Finset.filter_subset _ _
    have h0 := abs_decoratedDensityPairTerm_le_h_mul_baseline
      (q := q) (a := a) (h := h) hq hh h2admissible
      (e := e) (e1 := heightPrimePart h e) hdsub
    have hb := pairBaseline_le_normalizationWeightMass q h
      (e := e) (e1 := heightPrimePart h e) hdsub
    exact h0.trans (mul_le_mul_of_nonneg_left hb hC0)
  · simp [Set.indicator, he]
    exact mul_nonneg hC0 (normalizationWeightMass_nonneg q h e)

theorem summable_completedBooleanDensityTerm
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    Summable (completedBooleanDensityTerm q a h) := by
  have hI := summable_completedBooleanDensityInteriorTerm
    (q := q) (a := a) hq hh h2admissible
  have hF := summable_completedBooleanFullDensityTerm
    (q := q) (a := a) hq hh h2admissible
  have hE := summable_completedBooleanEmptyDensityTerm
    (q := q) (a := a) hq hh h2admissible
  have hs := (hI.add hF).add hE
  apply hs.congr
  intro e
  by_cases he : e ∈ completedBooleanSupport q h
  · simp [completedBooleanDensityTerm, Set.indicator, he]
  · simp [completedBooleanDensityTerm, Set.indicator, he]

theorem summable_combinedBooleanEmptyEndpointTerm
    {q a r h : ℕ} (hq : 0 < q)
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    Summable (combinedBooleanEmptyEndpointTerm q a h) := by
  exact (summable_heightBoundaryPairTerm hreflect).congr
    (fun e => (combinedBooleanEmptyEndpoint_eq_heightBoundary hq e).symm)

theorem tsum_combinedBooleanEmptyEndpoint_eq_heightBoundary
    {q a h : ℕ} (hq : 0 < q) :
    (∑' e : Finset ℕ, combinedBooleanEmptyEndpointTerm q a h e) =
      heightBoundaryFamily q a h := by
  unfold heightBoundaryFamily
  apply tsum_congr
  intro e
  exact combinedBooleanEmptyEndpoint_eq_heightBoundary hq e

theorem summable_completedBooleanMainTerm
    {q a r h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h)
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    Summable (completedBooleanMainTerm q a h) := by
  have hsT := summable_twoDimensionalPerE hreflect
  have hsD := summable_completedBooleanDensityTerm
    (q := q) (a := a) hq hh h2admissible
  have hsF := summable_combinedBooleanFullEndpointTerm
    (q := q) (a := a) (h := h) hq
  have hsE := summable_combinedBooleanEmptyEndpointTerm
    (q := q) (a := a) (r := r) (h := h) hq hreflect
  have hs := (((hsT.sub hsD).add hsF).add hsE)
  apply hs.congr
  intro e
  have hp := twoDimensionalPerE_eq_completedBoolean_global
    (q := q) (a := a) (h := h) hq e
  linarith

theorem twoDimensionalFamilyRemainder_eq_completedBoolean_raw
    {q a r h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h)
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    twoDimensionalFamilyRemainder q a h =
      completedBooleanMain q a h +
      completedBooleanDensity q a h -
      (∑' e : Finset ℕ, combinedBooleanFullEndpointTerm q a h e) -
      (∑' e : Finset ℕ, combinedBooleanEmptyEndpointTerm q a h e) := by
  have hsM := summable_completedBooleanMainTerm
    (q := q) (a := a) (r := r) hq hh h2admissible hreflect
  have hsD := summable_completedBooleanDensityTerm
    (q := q) (a := a) hq hh h2admissible
  have hsF := summable_combinedBooleanFullEndpointTerm
    (q := q) (a := a) (h := h) hq
  have hsE := summable_combinedBooleanEmptyEndpointTerm
    (q := q) (a := a) (r := r) (h := h) hq hreflect
  rw [twoDimensionalFamilyRemainder_eq_tsum hreflect]
  calc
    (∑' e : Finset ℕ, twoDimensionalPerE q a h e) =
      ∑' e : Finset ℕ,
        (completedBooleanMainTerm q a h e +
          completedBooleanDensityTerm q a h e -
          combinedBooleanFullEndpointTerm q a h e -
          combinedBooleanEmptyEndpointTerm q a h e) := by
            apply tsum_congr
            intro e
            exact twoDimensionalPerE_eq_completedBoolean_global hq e
    _ = ((∑' e : Finset ℕ, completedBooleanMainTerm q a h e) +
          (∑' e : Finset ℕ, completedBooleanDensityTerm q a h e)) -
          (∑' e : Finset ℕ, combinedBooleanFullEndpointTerm q a h e) -
          (∑' e : Finset ℕ, combinedBooleanEmptyEndpointTerm q a h e) := by
            rw [((hsM.add hsD).sub hsF).tsum_sub hsE]
            rw [(hsM.add hsD).tsum_sub hsF]
            rw [hsM.tsum_add hsD]
    _ = completedBooleanMain q a h +
        completedBooleanDensity q a h -
        (∑' e : Finset ℕ, combinedBooleanFullEndpointTerm q a h e) -
        (∑' e : Finset ℕ, combinedBooleanEmptyEndpointTerm q a h e) := by
          rfl

theorem twoDimensionalFamilyRemainder_eq_completedBoolean_visible
    {q a r h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h)
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    twoDimensionalFamilyRemainder q a h =
      completedBooleanMain q a h +
      completedBooleanDensity q a h -
      pureLeftFamily q a h +
      (∑' e : Finset ℕ, pureHeightSupportTerm q a h e) -
      heightBoundaryFamily q a h := by
  rw [twoDimensionalFamilyRemainder_eq_completedBoolean_raw
    hq hh h2admissible hreflect]
  rw [tsum_combinedBooleanFullEndpoint_eq_pureLeft_sub_pureHeight hq]
  rw [tsum_combinedBooleanEmptyEndpoint_eq_heightBoundary hq]
  ring

theorem fullPairFamily_eq_completedBoolean_visible
    {q a r h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h)
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    fullPairFamily q a h =
      completedBooleanMain q a h +
      completedBooleanDensity q a h +
      (∑' e : Finset ℕ, pureHeightSupportTerm q a h e) := by
  rw [fullPairFamily_eq_boundary_families_add_twoDimensional]
  rw [twoDimensionalFamilyRemainder_eq_completedBoolean_visible
    hq hh h2admissible hreflect]
  ring

#print axioms twoDimensionalPerE_eq_completedBoolean_global
#print axioms summable_completedBooleanDensityTerm
#print axioms twoDimensionalFamilyRemainder_eq_completedBoolean_raw
#print axioms twoDimensionalFamilyRemainder_eq_completedBoolean_visible
#print axioms fullPairFamily_eq_completedBoolean_visible

theorem abs_completedBooleanDensityTerm_le_three_productMajorant
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h)
    (e : Finset ℕ) :
    |completedBooleanDensityTerm q a h e| ≤
      3 * decoratedDensityReindexMajorant q h
        (decoratedDensityReindexKey q h e) := by
  by_cases he : e ∈ completedBooleanSupport q h
  · have hA : ∀ p ∈ e, activeHighPrime q p := he.1
    have hI :=
      abs_decoratedDensityPerE_le_shiu_harmonic
        (q := q) (a := a) (h := h) hq hh h2admissible hA
    have hF :=
      abs_decoratedDensityPairTerm_le_forbidden_harmonic
        (q := q) (a := a) (h := h) hq hh h2admissible
        (e := e) (e1 := e) (fun _ hp => hp) hA (Finset.filter_subset _ _)
    have hdsub : heightPrimePart h e ⊆ e := Finset.filter_subset _ _
    have hE :=
      abs_decoratedDensityPairTerm_le_forbidden_harmonic
        (q := q) (a := a) (h := h) hq hh h2admissible
        (e := e) (e1 := heightPrimePart h e) hdsub hA (fun _ hp => hp)
    let d := heightPrimePart h e
    let n := e \ d
    let m := primeSetProduct n
    have hdset : d ⊆ decoratedHeightPrimeSet q h := by
      simpa [d] using
        heightPrimePart_subset_decoratedHeightPrimeSet_of_active hh hA
    have hH :
        decoratedHeightDensityMassTerm q h d =
          finiteVWeightReal h d := by
      simp [decoratedHeightDensityMassTerm,
        Finset.mem_powerset.mpr hdset]
    have hcop : m.Coprime h := by
      simpa [m, n, d] using primeSetProduct_nonheight_coprime_height hA
    have hM :
        fixedQShiuCoprimeHarmonicTerm q h m =
          fixedQShiuWeight q m / (m : ℝ) := by
      simp [fixedQShiuCoprimeHarmonicTerm, hcop]
    have hmaj :
        decoratedDensityReindexMajorant q h
            (decoratedDensityReindexKey q h e) =
          genericFixedQPeriodicDensityBound q *
            finiteVWeightReal h d *
            (fixedQShiuWeight q m / (m : ℝ)) := by
      rw [decoratedDensityReindexKey, if_pos hA]
      simp only [decoratedDensityReindexMajorant]
      unfold decoratedDensityProductMajorant
      rw [hH, hM]
    rw [completedBooleanDensityTerm, Set.indicator_of_mem he]
    rw [hmaj]
    have hI' :
        |decoratedDensityPerE q a h e| ≤
          genericFixedQPeriodicDensityBound q *
            finiteVWeightReal h d *
            (fixedQShiuWeight q m / (m : ℝ)) := by
      simpa [d, n, m] using hI
    have hnActive : ∀ p ∈ n, activeHighPrime q p := by
      intro p hp
      exact hA p (Finset.mem_sdiff.mp hp).1
    have hShiu :=
      fixedQShiuWeight_primeSetProduct_eq_card_mul_finiteOmegaWeightReal
        hnActive
    have hnPrime : ∀ p ∈ n, p.Prime := fun p hp => (hnActive p hp).1
    have hmpos : 0 < m := by
      dsimp [m]
      exact primeSetProduct_pos hnPrime
    have hw0 : 0 ≤ finiteOmegaWeightReal n :=
      finiteOmegaWeightReal_nonneg_of_active hnActive
    have hpow1 : (1 : ℝ) ≤ (2 : ℝ) ^ n.card := by
      exact one_le_pow₀ (by norm_num)
    have hOmegaToShiu :
        finiteOmegaWeightReal n / (m : ℝ) ≤
          fixedQShiuWeight q m / (m : ℝ) := by
      rw [hShiu]
      have hmR : (0 : ℝ) < m := by exact_mod_cast hmpos
      apply div_le_div_of_nonneg_right _ hmR.le
      calc
        finiteOmegaWeightReal n
          = 1 * finiteOmegaWeightReal n := by ring
        _ ≤ (2 : ℝ) ^ n.card * finiteOmegaWeightReal n :=
          mul_le_mul_of_nonneg_right hpow1 hw0
    have hB0 : 0 ≤ genericFixedQPeriodicDensityBound q := by
      unfold genericFixedQPeriodicDensityBound fixedQDensityDefectUniformBound
        admissibleCountMeanErrorBound
      positivity
    have hv0 : 0 ≤ finiteVWeightReal h d := by
      apply finiteVWeightReal_nonneg_of_active
      intro p hp
      exact hA p ((Finset.filter_subset _ _) hp)
    have hscale :
        genericFixedQPeriodicDensityBound q *
              finiteVWeightReal h d *
              (finiteOmegaWeightReal n / (m : ℝ)) ≤
          genericFixedQPeriodicDensityBound q *
              finiteVWeightReal h d *
              (fixedQShiuWeight q m / (m : ℝ)) := by
      gcongr
    have hF' :
        |decoratedDensityPairTerm q a h e e| ≤
          genericFixedQPeriodicDensityBound q *
            finiteVWeightReal h d *
            (fixedQShiuWeight q m / (m : ℝ)) := by
      have hraw :
          |decoratedDensityPairTerm q a h e e| ≤
            genericFixedQPeriodicDensityBound q *
              finiteVWeightReal h d *
              (finiteOmegaWeightReal n / (m : ℝ)) := by
        simpa [d, n, m] using hF
      exact hraw.trans hscale
    have hE' :
        |decoratedDensityPairTerm q a h e (heightPrimePart h e)| ≤
          genericFixedQPeriodicDensityBound q *
            finiteVWeightReal h d *
            (fixedQShiuWeight q m / (m : ℝ)) := by
      have hraw :
          |decoratedDensityPairTerm q a h e (heightPrimePart h e)| ≤
            genericFixedQPeriodicDensityBound q *
              finiteVWeightReal h d *
              (finiteOmegaWeightReal n / (m : ℝ)) := by
        simpa [d, n, m] using hE
      exact hraw.trans hscale
    calc
      |decoratedDensityPerE q a h e +
          decoratedDensityPairTerm q a h e e +
          decoratedDensityPairTerm q a h e (heightPrimePart h e)|
        ≤ |decoratedDensityPerE q a h e +
            decoratedDensityPairTerm q a h e e| +
            |decoratedDensityPairTerm q a h e (heightPrimePart h e)| :=
              abs_add_le _ _
      _ ≤ |decoratedDensityPerE q a h e| +
            |decoratedDensityPairTerm q a h e e| +
            |decoratedDensityPairTerm q a h e (heightPrimePart h e)| := by
              gcongr
              exact abs_add_le _ _
      _ ≤ 3 * (genericFixedQPeriodicDensityBound q *
            finiteVWeightReal h d *
            (fixedQShiuWeight q m / (m : ℝ))) := by
          linarith
  · have hmaj0 :
        0 ≤ decoratedDensityReindexMajorant q h
          (decoratedDensityReindexKey q h e) := by
      rw [decoratedDensityReindexKey]
      split_ifs with hA
      · simp only [decoratedDensityReindexMajorant]
        exact decoratedDensityProductMajorant_nonneg q h _
      · simp only [decoratedDensityReindexMajorant]
        exact le_rfl
    change |(completedBooleanSupport q h).indicator
      (fun e =>
        decoratedDensityPerE q a h e +
          decoratedDensityPairTerm q a h e e +
          decoratedDensityPairTerm q a h e (heightPrimePart h e)) e| ≤ _
    simp only [Set.indicator, he, if_false, abs_zero]
    exact mul_nonneg (by norm_num) hmaj0


theorem abs_completedBooleanDensity_le_three_productMajorant
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    |completedBooleanDensity q a h| ≤
      3 * (∑' dm : Finset ℕ × ℕ,
        decoratedDensityProductMajorant q h dm) := by
  have hsD :=
    summable_completedBooleanDensityTerm
      (q := q) (a := a) hq hh h2admissible
  have hsAbs : Summable
      (fun e : Finset ℕ => |completedBooleanDensityTerm q a h e|) := by
    simpa [Real.norm_eq_abs] using hsD.norm
  have hsG := summable_decoratedDensityReindexMajorant q h
  have hs3G :
      Summable (fun x => 3 * decoratedDensityReindexMajorant q h x) :=
    hsG.mul_left 3
  have hle :
      (∑' e : Finset ℕ, |completedBooleanDensityTerm q a h e|) ≤
        ∑' x, 3 * decoratedDensityReindexMajorant q h x := by
    apply hsAbs.tsum_le_tsum_of_inj
      (decoratedDensityReindexKey q h)
      (decoratedDensityReindexKey_injective q h)
    · intro x hx
      exact mul_nonneg (by norm_num)
        (by
          cases x with
          | inl dm =>
              exact decoratedDensityProductMajorant_nonneg q h dm
          | inr e =>
              simp [decoratedDensityReindexMajorant])
    · intro e
      exact abs_completedBooleanDensityTerm_le_three_productMajorant
        hq hh h2admissible e
    · exact hs3G
  unfold completedBooleanDensity
  calc
    |∑' e : Finset ℕ, completedBooleanDensityTerm q a h e|
      ≤ ∑' e : Finset ℕ, |completedBooleanDensityTerm q a h e| := by
        simpa [Real.norm_eq_abs] using norm_tsum_le_tsum_norm hsD.norm
    _ ≤ ∑' x, 3 * decoratedDensityReindexMajorant q h x := hle
    _ = 3 * (∑' x, decoratedDensityReindexMajorant q h x) := by
      rw [tsum_mul_left]
    _ = 3 * (∑' dm : Finset ℕ × ℕ,
        decoratedDensityProductMajorant q h dm) := by
      rw [tsum_decoratedDensityReindexMajorant]

noncomputable def completedBooleanDensityLogLogConstant (q : ℕ) : ℝ :=
  3 * decoratedDensityLogLogConstant q

lemma completedBooleanDensityLogLogConstant_nonneg (q : ℕ) :
    0 ≤ completedBooleanDensityLogLogConstant q := by
  unfold completedBooleanDensityLogLogConstant
  exact mul_nonneg (by norm_num) (decoratedDensityLogLogConstant_nonneg q)

theorem abs_completedBooleanDensity_le_loglog
    {q a h : ℕ} (hq : 0 < q) (hh : 16 ≤ h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    |completedBooleanDensity q a h| ≤
      completedBooleanDensityLogLogConstant q *
        Real.log (Real.log (h : ℝ)) := by
  have hhpos : 0 < h := by omega
  have hbase :=
    abs_completedBooleanDensity_le_three_productMajorant
      (q := q) (a := a) hq hhpos h2admissible
  rw [tsum_decoratedDensityProductMajorant,
    tsum_decoratedHeightDensityMassTerm] at hbase
  have hHle :
      (∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
        finiteVWeightReal h d) ≤
        weakDecoratedMertensC * Real.log (Real.log (h : ℝ)) :=
    (sum_decorated_finiteVWeightReal_lt_weakMertens
      (q := q) hh).le
  have hMle :=
    tsum_fixedQShiuWeight_div_coprime_le_exp_five q h
  have hB0 : 0 ≤ genericFixedQPeriodicDensityBound q := by
    unfold genericFixedQPeriodicDensityBound fixedQDensityDefectUniformBound
      admissibleCountMeanErrorBound
    positivity
  have hH0 :
      0 ≤ ∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
        finiteVWeightReal h d := by
    apply Finset.sum_nonneg
    intro d hd
    apply finiteVWeightReal_nonneg_of_active
    intro p hp
    have hsub := Finset.mem_powerset.mp hd
    have hpSet := Finset.mem_filter.mp (hsub hp)
    exact ⟨Nat.prime_of_mem_primeFactors hpSet.1, hpSet.2.1, hpSet.2.2⟩
  have hM0 :
      0 ≤ ∑' m : ℕ, fixedQShiuCoprimeHarmonicTerm q h m :=
    tsum_nonneg (fixedQShiuCoprimeHarmonicTerm_nonneg q h)
  have hloglog0 : 0 ≤ Real.log (Real.log (h : ℝ)) := by
    have h1 := one_le_log_log_nat_of_sixteen_le hh
    linarith
  have hW0 : 0 ≤ weakDecoratedMertensC := by
    unfold weakDecoratedMertensC weakMertensC
    positivity
  calc
    |completedBooleanDensity q a h|
      ≤ 3 * (genericFixedQPeriodicDensityBound q *
          (∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
            finiteVWeightReal h d) *
          (∑' m : ℕ, fixedQShiuCoprimeHarmonicTerm q h m)) := hbase
    _ ≤ 3 * (genericFixedQPeriodicDensityBound q *
          (weakDecoratedMertensC * Real.log (Real.log (h : ℝ))) *
          (∑' m : ℕ, fixedQShiuCoprimeHarmonicTerm q h m)) := by
            gcongr
    _ ≤ 3 * (genericFixedQPeriodicDensityBound q *
          (weakDecoratedMertensC * Real.log (Real.log (h : ℝ))) *
          Real.exp 5) := by
            gcongr
    _ = completedBooleanDensityLogLogConstant q *
        Real.log (Real.log (h : ℝ)) := by
          unfold completedBooleanDensityLogLogConstant
            decoratedDensityLogLogConstant
          ring

theorem completedBooleanDensity_sublog
    (q : ℕ) (hq : 0 < q) :
    ∀ eps : ℝ, 0 < eps →
      ∃ h0 : ℕ,
        ∀ a h : ℕ,
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          h0 ≤ h →
          |cStarReal q h * completedBooleanDensity q a h| ≤
            eps * Real.log (h : ℝ) := by
  intro eps hε
  let C : ℝ := completedBooleanDensityLogLogConstant q
  have hlo0 :
      (fun x : ℝ => Real.log (Real.log x)) =o[Filter.atTop]
        Real.log := by
    simpa [Function.comp_def] using
      Real.isLittleO_log_id_atTop.comp_tendsto Real.tendsto_log_atTop
  have hlo :
      (fun x : ℝ => C * Real.log (Real.log x)) =o[Filter.atTop]
        Real.log :=
    hlo0.const_mul_left C
  have hev := hlo.bound hε
  rw [Filter.eventually_atTop] at hev
  obtain ⟨T, hT⟩ := hev
  obtain ⟨N, hN⟩ := exists_nat_ge T
  refine ⟨max 16 N, ?_⟩
  intro a h h2admissible hh hlarge
  have hh16 : 16 ≤ h :=
    (le_max_left 16 N).trans hlarge
  have hNh : N ≤ h :=
    (le_max_right 16 N).trans hlarge
  have hTR : T ≤ (h : ℝ) := by
    exact hN.trans (by exact_mod_cast hNh)
  have hasym := hT (h : ℝ) hTR
  have hloglog0 : 0 ≤ Real.log (Real.log (h : ℝ)) := by
    have h1 := one_le_log_log_nat_of_sixteen_le hh16
    linarith
  have hlog0 : 0 ≤ Real.log (h : ℝ) := by
    exact Real.log_nonneg (by exact_mod_cast (show 1 ≤ h by omega))
  have hC0 : 0 ≤ C := by
    dsimp [C]
    exact completedBooleanDensityLogLogConstant_nonneg q
  rw [Real.norm_eq_abs,
    abs_of_nonneg (mul_nonneg hC0 hloglog0),
    Real.norm_eq_abs, abs_of_nonneg hlog0] at hasym
  have hrem :=
    abs_completedBooleanDensity_le_loglog
      (q := q) (a := a) hq hh16 h2admissible
  have hc := abs_cStarReal_le_one q h
  rw [abs_mul]
  calc
    |cStarReal q h| * |completedBooleanDensity q a h|
      ≤ 1 * (C * Real.log (Real.log (h : ℝ))) := by
          gcongr
    _ = C * Real.log (Real.log (h : ℝ)) := by ring
    _ ≤ eps * Real.log (h : ℝ) := hasym

theorem postReaggregationTerminalCore_eq_old_obligation_ledger
    {q a b h : ℕ}
    (hq : 0 < q)
    (hh : 0 < h)
    (hcompat : Nat.ModEq q (a + h) b)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    cStarReal q h *
        (completedBooleanMain q a h +
          ∑' e : Finset ℕ, pureHeightSupportTerm q a h e)
      - PaperB.Closure.manuscriptB1Kernel q a b h
    =
      (cStarReal q h * pureLeftFamily q a h -
        PaperB.Closure.manuscriptS1Kernel q a h)
      +
      (cStarReal q h * heightBoundaryFamily q a h -
        PaperB.Closure.manuscriptS1Kernel q
          (PaperB.Closure.reflectedResidue q b) h)
      +
      cStarReal q h * twoDimensionalFamilyRemainder q a h
      -
      cStarReal q h * completedBooleanDensity q a h := by
  have hreflect :
      ∀ z ∈ Finset.Ioo 0 h,
        q.Coprime (a + (h - z)) ↔
          q.Coprime (PaperB.Closure.reflectedResidue q b + z) :=
    PaperB.Closure.reflected_coprime_equiv hq hcompat
  have hnew := fullPairFamily_eq_completedBoolean_visible
    (q := q) (a := a) (r := PaperB.Closure.reflectedResidue q b) (h := h)
    hq hh h2admissible hreflect
  have hold := fullPairFamily_eq_boundary_families_add_twoDimensional q a h
  unfold PaperB.Closure.manuscriptB1Kernel
  rw [hnew] at hold
  have hmul := congrArg (fun x : ℝ => cStarReal q h * x) hold
  linear_combination hmul