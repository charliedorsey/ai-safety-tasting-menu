import PaperB.FixedQ.EtaReciprocalTail
import PaperB.FixedQ.OmegaLinearMean

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def omegaReciprocalTerm (q n : ℕ) : ℝ :=
  omegaArithmetic q n / (n : ℝ)

@[simp] theorem omegaReciprocalTerm_zero (q : ℕ) :
    omegaReciprocalTerm q 0 = 0 := by
  simp [omegaReciprocalTerm, omegaArithmetic]

@[simp] theorem omegaReciprocalTerm_one (q : ℕ) :
    omegaReciprocalTerm q 1 = 1 := by
  simp [omegaReciprocalTerm, omegaArithmetic,
    petermannSupportedArithmetic, petermannSupportedCoeff]

theorem omegaReciprocalTerm_eq_omegaCoeff_div
    (q n : ℕ) :
    omegaReciprocalTerm q n = omegaCoeff q n / (n : ℝ) := by
  simp [omegaReciprocalTerm, omegaArithmetic_apply]

theorem omegaReciprocalTerm_mul_of_coprime
    (q : ℕ) {m n : ℕ} (hcop : m.Coprime n) :
    omegaReciprocalTerm q (m * n) =
      omegaReciprocalTerm q m * omegaReciprocalTerm q n := by
  by_cases hm0 : m = 0
  · subst m
    have hn1 : n = 1 := by simpa using hcop
    subst n
    simp
  · by_cases hn0 : n = 0
    · subst n
      have hm1 : m = 1 := by simpa using hcop
      subst m
      simp
    · unfold omegaReciprocalTerm
      rw [(omegaArithmetic_multiplicative q).map_mul_of_coprime hcop]
      push_cast
      have hmR : (m : ℝ) ≠ 0 := by exact_mod_cast hm0
      have hnR : (n : ℝ) ≠ 0 := by exact_mod_cast hn0
      field_simp [hmR, hnR]

end PaperB.FixedQ
namespace PaperB.FixedQ

theorem abs_omegaLinearPartialSum_le
    (q X : ℕ) :
    |omegaLinearPartialSum q X| ≤
      (X : ℝ) * omegaRankinBound := by
  rw [omegaLinearPartialSum_eq_correction_coprime]
  have hR0 : 0 ≤ omegaRankinBound := by
    unfold omegaRankinBound
    positivity
  calc
    |∑ d ∈ Finset.Icc 1 X,
        omegaLinearCorrectionArithmetic q d *
          (coprimePrefixCount (6 * q) (X / d) : ℝ)|
      ≤ ∑ d ∈ Finset.Icc 1 X,
          |omegaLinearCorrectionArithmetic q d *
            (coprimePrefixCount (6 * q) (X / d) : ℝ)| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ d ∈ Finset.Icc 1 X,
          (X : ℝ) * |omegaCorrectionInvTerm q d| := by
        apply Finset.sum_le_sum
        intro d hd
        have hdI := Finset.mem_Icc.mp hd
        have hd0 : d ≠ 0 := by omega
        have hcountN :
            coprimePrefixCount (6 * q) (X / d) ≤ X / d :=
          coprimePrefixCount_le (6 * q) (X / d)
        have hcountR :
            (coprimePrefixCount (6 * q) (X / d) : ℝ) ≤
              (X : ℝ) / (d : ℝ) := by
          calc
            (coprimePrefixCount (6 * q) (X / d) : ℝ)
                ≤ ((X / d : ℕ) : ℝ) := by exact_mod_cast hcountN
            _ ≤ (X : ℝ) / (d : ℝ) := Nat.cast_div_le
        have hcount0 :
            0 ≤ (coprimePrefixCount (6 * q) (X / d) : ℝ) := by positivity
        rw [abs_mul, abs_of_nonneg hcount0]
        have hc0 : 0 ≤ |omegaLinearCorrectionArithmetic q d| := abs_nonneg _
        calc
          |omegaLinearCorrectionArithmetic q d| *
              (coprimePrefixCount (6 * q) (X / d) : ℝ)
            ≤ |omegaLinearCorrectionArithmetic q d| *
                ((X : ℝ) / (d : ℝ)) :=
              mul_le_mul_of_nonneg_left hcountR hc0
          _ = (X : ℝ) * |omegaCorrectionInvTerm q d| := by
              unfold omegaCorrectionInvTerm
              rw [abs_div, abs_of_pos (by positivity : (0 : ℝ) < d)]
              ring
    _ = (X : ℝ) *
          ∑ d ∈ Finset.Icc 1 X, |omegaCorrectionInvTerm q d| := by
        rw [Finset.mul_sum]
    _ ≤ (X : ℝ) * omegaRankinBound := by
        apply mul_le_mul_of_nonneg_left _ (by positivity)
        calc
          (∑ d ∈ Finset.Icc 1 X, |omegaCorrectionInvTerm q d|)
              ≤ ∑' d : ℕ, |omegaCorrectionInvTerm q d| := by
                exact (summable_omegaCorrectionInvTerm q).abs.sum_le_tsum
                  (Finset.Icc 1 X) (fun d hd => abs_nonneg _)
          _ ≤ omegaRankinBound :=
            tsum_abs_omegaCorrectionInvTerm_le_bound q

#print axioms abs_omegaLinearPartialSum_le

end PaperB.FixedQ
namespace PaperB.FixedQ

theorem omegaLinearPartialSum_eq_shifted_range
    (q X : ℕ) :
    omegaLinearPartialSum q X =
      ∑ j ∈ Finset.range X, omegaLinearArithmetic q (j + 1) := by
  unfold omegaLinearPartialSum
  refine Finset.sum_bij
    (fun n hn => n - 1)
    ?_ ?_ ?_ ?_
  · intro n hn
    rw [Finset.mem_Icc] at hn
    rw [Finset.mem_range]
    omega
  · intro n1 hn1 n2 hn2 h
    rw [Finset.mem_Icc] at hn1 hn2
    omega
  · intro j hj
    rw [Finset.mem_range] at hj
    refine ⟨j + 1, ?_, ?_⟩
    · rw [Finset.mem_Icc]
      omega
    · omega
  · intro n hn
    rw [Finset.mem_Icc] at hn
    have hpos : 1 ≤ n := hn.1
    rw [Nat.sub_add_cancel hpos]

theorem omegaReciprocalTerm_succ_eq_linear_sq
    (q j : ℕ) :
    omegaReciprocalTerm q (j + 1) =
      (((j + 1 : ℕ) : ℝ)⁻¹ ^ 2) *
        omegaLinearArithmetic q (j + 1) := by
  rw [omegaReciprocalTerm_eq_omegaCoeff_div]
  change omegaCoeff q (j + 1) / (((j + 1 : ℕ) : ℝ)) =
    (((j + 1 : ℕ) : ℝ)⁻¹ ^ 2) *
      ((((j + 1 : ℕ) : ℝ) * omegaCoeff q (j + 1)))
  have hj : (0 : ℝ) < j + 1 := by positivity
  field_simp [ne_of_gt hj]


#print axioms omegaLinearPartialSum_eq_shifted_range
#print axioms omegaReciprocalTerm_succ_eq_linear_sq

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem omegaReciprocalFiniteTail_by_parts
    (q X M : ℕ) (hXM : X < M) :
    (∑ j ∈ Finset.Ico X M, omegaReciprocalTerm q (j + 1)) =
      ((M : ℝ)⁻¹ ^ 2) * omegaLinearPartialSum q M -
      (((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) * omegaLinearPartialSum q X -
      ∑ i ∈ Finset.Ico X (M - 1),
        (((((i + 2 : ℕ) : ℝ)⁻¹ ^ 2) -
          (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2)) *
          omegaLinearPartialSum q (i + 1)) := by
  have h := Finset.sum_Ico_by_parts
    (f := fun j : ℕ => (((j + 1 : ℕ) : ℝ)⁻¹ ^ 2))
    (g := fun j : ℕ => omegaLinearArithmetic q (j + 1))
    hXM
  simp only [smul_eq_mul] at h
  have hL :
      (∑ i ∈ Finset.Ico X M,
        (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2) *
          omegaLinearArithmetic q (i + 1)) =
      ∑ i ∈ Finset.Ico X M, omegaReciprocalTerm q (i + 1) := by
    apply Finset.sum_congr rfl
    intro i hi
    rw [omegaReciprocalTerm_succ_eq_linear_sq]
  rw [hL] at h
  simp_rw [← omegaLinearPartialSum_eq_shifted_range] at h
  have hM : M - 1 + 1 = M := Nat.sub_add_cancel (Nat.one_le_of_lt hXM)
  simpa [hM, Nat.add_assoc] using h

#print axioms omegaReciprocalFiniteTail_by_parts

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem abs_inv_sq_mul_omegaLinearPartialSum_le
    (q N : ℕ) (hN : 0 < N) :
    |((N : ℝ)⁻¹ ^ 2) * omegaLinearPartialSum q N| ≤
      omegaRankinBound / (N : ℝ) := by
  have hA := abs_omegaLinearPartialSum_le q N
  have hsq0 : 0 ≤ ((N : ℝ)⁻¹ ^ 2) := sq_nonneg _
  rw [abs_mul, abs_of_nonneg hsq0]
  calc
    ((N : ℝ)⁻¹ ^ 2) * |omegaLinearPartialSum q N|
      ≤ ((N : ℝ)⁻¹ ^ 2) * ((N : ℝ) * omegaRankinBound) :=
        mul_le_mul_of_nonneg_left hA hsq0
    _ = omegaRankinBound / (N : ℝ) := by
      have hNR : (N : ℝ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hN)
      field_simp [hNR]

theorem abs_omegaAbelDifferenceTerm_le
    (q i : ℕ) (hi : 0 < i + 1) :
    |(((((i + 2 : ℕ) : ℝ)⁻¹ ^ 2) -
        (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2)) *
        omegaLinearPartialSum q (i + 1))| ≤
      2 * omegaRankinBound * (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2) := by
  let m := i + 1
  have hm : 0 < m := by
    dsimp [m]
    omega
  have hdec :
      (((m + 1 : ℕ) : ℝ)⁻¹ ^ 2) ≤ ((m : ℝ)⁻¹ ^ 2) :=
    reciprocal_sq_succ_le hm
  have hA := abs_omegaLinearPartialSum_le q m
  have hdiff0 :
      0 ≤ ((m : ℝ)⁻¹ ^ 2) - (((m + 1 : ℕ) : ℝ)⁻¹ ^ 2) :=
    sub_nonneg.mpr hdec
  have hR0 : 0 ≤ omegaRankinBound := by
    unfold omegaRankinBound
    positivity
  change
    |(((((m + 1 : ℕ) : ℝ)⁻¹ ^ 2) - ((m : ℝ)⁻¹ ^ 2)) *
        omegaLinearPartialSum q m)| ≤
      2 * omegaRankinBound * ((m : ℝ)⁻¹ ^ 2)
  rw [abs_mul, abs_of_nonpos (sub_nonpos.mpr hdec), neg_sub]
  calc
    (((m : ℝ)⁻¹ ^ 2) - (((m + 1 : ℕ) : ℝ)⁻¹ ^ 2)) *
        |omegaLinearPartialSum q m|
      ≤ (((m : ℝ)⁻¹ ^ 2) - (((m + 1 : ℕ) : ℝ)⁻¹ ^ 2)) *
          ((m : ℝ) * omegaRankinBound) :=
        mul_le_mul_of_nonneg_left hA hdiff0
    _ = omegaRankinBound *
        ((m : ℝ) *
          (((m : ℝ)⁻¹ ^ 2) - (((m + 1 : ℕ) : ℝ)⁻¹ ^ 2))) := by ring
    _ ≤ omegaRankinBound * (2 * ((m : ℝ)⁻¹ ^ 2)) :=
      mul_le_mul_of_nonneg_left
        (nat_mul_reciprocal_sq_diff_le hm) hR0
    _ = 2 * omegaRankinBound * ((m : ℝ)⁻¹ ^ 2) := by ring

end PaperB.FixedQ
namespace PaperB.FixedQ

theorem abs_omegaAbelInteriorSum_le
    (q X M : ℕ) (hX : 0 < X) :
    |∑ i ∈ Finset.Ico X (M - 1),
        (((((i + 2 : ℕ) : ℝ)⁻¹ ^ 2) -
          (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2)) *
          omegaLinearPartialSum q (i + 1))| ≤
      2 * omegaRankinBound * (X : ℝ)⁻¹ := by
  have hR0 : 0 ≤ omegaRankinBound := by
    unfold omegaRankinBound
    positivity
  have hshift :
      (∑ i ∈ Finset.Ico X (M - 1),
        (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2)) =
      ∑ m ∈ Finset.Icc (X + 1) (M - 1),
        ((m : ℝ)⁻¹ ^ 2) := by
    refine Finset.sum_bij
      (fun i hi => i + 1)
      ?_ ?_ ?_ ?_
    · intro i hi
      rw [Finset.mem_Ico] at hi
      rw [Finset.mem_Icc]
      omega
    · intro i1 hi1 i2 hi2 heq
      omega
    · intro m hm
      rw [Finset.mem_Icc] at hm
      refine ⟨m - 1, ?_, ?_⟩
      · rw [Finset.mem_Ico]
        omega
      · omega
    · intro i hi
      rfl
  calc
    |∑ i ∈ Finset.Ico X (M - 1),
        (((((i + 2 : ℕ) : ℝ)⁻¹ ^ 2) -
          (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2)) *
          omegaLinearPartialSum q (i + 1))|
      ≤ ∑ i ∈ Finset.Ico X (M - 1),
          |(((((i + 2 : ℕ) : ℝ)⁻¹ ^ 2) -
            (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2)) *
            omegaLinearPartialSum q (i + 1))| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ i ∈ Finset.Ico X (M - 1),
          2 * omegaRankinBound *
            (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2) := by
        apply Finset.sum_le_sum
        intro i hi
        exact abs_omegaAbelDifferenceTerm_le q i (by omega)
    _ = 2 * omegaRankinBound *
          (∑ i ∈ Finset.Ico X (M - 1),
            (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2)) := by
        rw [Finset.mul_sum]
    _ = 2 * omegaRankinBound *
          (∑ m ∈ Finset.Icc (X + 1) (M - 1),
            ((m : ℝ)⁻¹ ^ 2)) := by rw [hshift]
    _ ≤ 2 * omegaRankinBound * (X : ℝ)⁻¹ := by
        apply mul_le_mul_of_nonneg_left
          (finite_square_tail_le_inv (F := X) (M := M - 1) hX)
        positivity

theorem abs_omegaReciprocalFiniteTail_le
    (q X M : ℕ) (hX : 0 < X) (hXM : X < M) :
    |∑ j ∈ Finset.Ico X M, omegaReciprocalTerm q (j + 1)| ≤
      4 * omegaRankinBound * (X : ℝ)⁻¹ := by
  rw [omegaReciprocalFiniteTail_by_parts q X M hXM]
  have hU :=
    abs_inv_sq_mul_omegaLinearPartialSum_le q M
      (lt_of_lt_of_le hX (Nat.le_of_lt hXM))
  have hL :=
    abs_inv_sq_mul_omegaLinearPartialSum_le q X hX
  have hI := abs_omegaAbelInteriorSum_le q X M hX
  have hR0 : 0 ≤ omegaRankinBound := by
    unfold omegaRankinBound
    positivity
  have hXR : (0 : ℝ) < X := by exact_mod_cast hX
  have hM : 0 < M := lt_trans hX hXM
  have hMR : (0 : ℝ) < M := by exact_mod_cast hM
  have hXMreal : (X : ℝ) ≤ (M : ℝ) := by
    exact_mod_cast (Nat.le_of_lt hXM)
  have hInvM :
      (M : ℝ)⁻¹ ≤ (X : ℝ)⁻¹ :=
    (inv_le_inv₀ hMR hXR).2 hXMreal
  have hInvSucc :
      (((X + 1 : ℕ) : ℝ)⁻¹) ≤ (X : ℝ)⁻¹ := by
    have hXsR : (0 : ℝ) < ((X + 1 : ℕ) : ℝ) := by
      exact_mod_cast Nat.zero_lt_succ X
    exact (inv_le_inv₀ hXsR hXR).2 (by exact_mod_cast Nat.le_succ X)
  have hUb :
      |((M : ℝ)⁻¹ ^ 2) * omegaLinearPartialSum q M| ≤
        omegaRankinBound * (X : ℝ)⁻¹ := by
    calc
      |((M : ℝ)⁻¹ ^ 2) * omegaLinearPartialSum q M|
          ≤ omegaRankinBound / (M : ℝ) := hU
      _ = omegaRankinBound * (M : ℝ)⁻¹ := by rw [div_eq_mul_inv]
      _ ≤ omegaRankinBound * (X : ℝ)⁻¹ :=
        mul_le_mul_of_nonneg_left hInvM hR0
  have hLb :
      |(((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) *
          omegaLinearPartialSum q X| ≤
        omegaRankinBound * (X : ℝ)⁻¹ := by
    have hA := abs_omegaLinearPartialSum_le q X
    have hsq0 : 0 ≤ (((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) := sq_nonneg _
    rw [abs_mul, abs_of_nonneg hsq0]
    calc
      (((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) *
          |omegaLinearPartialSum q X|
        ≤ (((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) *
            ((X : ℝ) * omegaRankinBound) :=
          mul_le_mul_of_nonneg_left hA hsq0
      _ ≤ omegaRankinBound * (X : ℝ)⁻¹ := by
        have hsqInv :
            (((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) ≤ ((X : ℝ)⁻¹ ^ 2) :=
          (sq_le_sq₀ (by positivity) (by positivity)).2 hInvSucc
        calc
          (((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) *
              ((X : ℝ) * omegaRankinBound)
            ≤ ((X : ℝ)⁻¹ ^ 2) *
                ((X : ℝ) * omegaRankinBound) :=
              mul_le_mul_of_nonneg_right hsqInv
                (mul_nonneg (le_of_lt hXR) hR0)
          _ = omegaRankinBound * (X : ℝ)⁻¹ := by
              have hXne : (X : ℝ) ≠ 0 := ne_of_gt hXR
              field_simp [hXne]
  calc
    |((M : ℝ)⁻¹ ^ 2) * omegaLinearPartialSum q M -
      (((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) * omegaLinearPartialSum q X -
      ∑ i ∈ Finset.Ico X (M - 1),
        (((((i + 2 : ℕ) : ℝ)⁻¹ ^ 2) -
          (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2)) *
          omegaLinearPartialSum q (i + 1))|
      ≤ |((M : ℝ)⁻¹ ^ 2) * omegaLinearPartialSum q M| +
        |(((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) * omegaLinearPartialSum q X| +
        |∑ i ∈ Finset.Ico X (M - 1),
          (((((i + 2 : ℕ) : ℝ)⁻¹ ^ 2) -
            (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2)) *
            omegaLinearPartialSum q (i + 1))| := by
          have h1 := abs_sub
            (((M : ℝ)⁻¹ ^ 2) * omegaLinearPartialSum q M -
              (((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) * omegaLinearPartialSum q X)
            (∑ i ∈ Finset.Ico X (M - 1),
              (((((i + 2 : ℕ) : ℝ)⁻¹ ^ 2) -
                (((i + 1 : ℕ) : ℝ)⁻¹ ^ 2)) *
                omegaLinearPartialSum q (i + 1)))
          have h2 := abs_sub
            (((M : ℝ)⁻¹ ^ 2) * omegaLinearPartialSum q M)
            ((((X + 1 : ℕ) : ℝ)⁻¹ ^ 2) * omegaLinearPartialSum q X)
          linarith
    _ ≤ 4 * omegaRankinBound * (X : ℝ)⁻¹ := by
      have hInvX0 : 0 ≤ (X : ℝ)⁻¹ := le_of_lt (inv_pos.mpr hXR)
      nlinarith [hUb, hLb, hI, mul_nonneg hR0 hInvX0]

#print axioms abs_omegaReciprocalFiniteTail_le

end PaperB.FixedQ
namespace PaperB.FixedQ

theorem omegaCoeff_nonneg
    (q n : ℕ) :
    0 ≤ omegaCoeff q n := by
  unfold omegaCoeff
  by_cases hn0 : n = 0
  · simp [hn0]
  · rw [if_neg hn0]
    by_cases hs : Squarefree n ∧ n.Coprime (6 * q)
    · rw [if_pos hs]
      apply Finset.prod_nonneg
      intro p hp
      have hpPrime := (Nat.mem_primeFactors.mp hp).1
      have hpDvd := (Nat.mem_primeFactors.mp hp).2.1
      have hpcop : p.Coprime (6 * q) :=
        hs.2.coprime_dvd_left hpDvd
      have hp5 : 5 ≤ p :=
        omega_rankin_five_le_of_prime_coprime_six hpPrime hpcop
      have hpR : (5 : ℝ) ≤ (p : ℝ) := by exact_mod_cast hp5
      have hden : 0 < (p : ℝ) - 3 := by linarith
      positivity
    · rw [if_neg hs]

theorem omegaReciprocalTerm_nonneg
    (q n : ℕ) :
    0 ≤ omegaReciprocalTerm q n := by
  rw [omegaReciprocalTerm_eq_omegaCoeff_div]
  exact div_nonneg (omegaCoeff_nonneg q n) (by positivity)

theorem shifted_omegaReciprocal_sum_range_le
    (q M : ℕ) :
    (∑ j ∈ Finset.range M, omegaReciprocalTerm q (j + 1)) ≤
      1 + 4 * omegaRankinBound := by
  have hR0 : 0 ≤ omegaRankinBound := by
    unfold omegaRankinBound
    positivity
  cases M with
  | zero =>
      simp
      nlinarith
  | succ k =>
      by_cases hk0 : k = 0
      · subst k
        have h4 : 0 ≤ 4 * omegaRankinBound :=
          mul_nonneg (by norm_num) hR0
        simpa [omegaReciprocalTerm_one] using h4
      · have hk : 0 < k := Nat.pos_of_ne_zero hk0
        have htail :=
          abs_omegaReciprocalFiniteTail_le q 1 (k + 1)
            (by norm_num) (by omega)
        have htail0 :
            0 ≤ ∑ j ∈ Finset.Ico 1 (k + 1),
              omegaReciprocalTerm q (j + 1) := by
          exact Finset.sum_nonneg fun j hj =>
            omegaReciprocalTerm_nonneg q (j + 1)
        have htailLe :
            (∑ j ∈ Finset.Ico 1 (k + 1),
              omegaReciprocalTerm q (j + 1)) ≤
              4 * omegaRankinBound := by
          simpa [abs_of_nonneg htail0] using htail
        rw [show Finset.range (k + 1) =
            insert 0 (Finset.Ico 1 (k + 1)) by
          ext j
          simp
          omega]
        simp [omegaReciprocalTerm_one, htailLe]

theorem summable_shifted_omegaReciprocalTerm
    (q : ℕ) :
    Summable (fun j : ℕ => omegaReciprocalTerm q (j + 1)) := by
  exact summable_of_sum_range_le
    (fun j => omegaReciprocalTerm_nonneg q (j + 1))
    (shifted_omegaReciprocal_sum_range_le q)

theorem summable_omegaReciprocalTerm
    (q : ℕ) :
    Summable (omegaReciprocalTerm q) := by
  exact (summable_nat_add_iff (f := omegaReciprocalTerm q) 1).1
    (by simpa using summable_shifted_omegaReciprocalTerm q)

#print axioms summable_omegaReciprocalTerm

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def omegaReciprocalTail
    (q X : ℕ) : ℝ :=
  ∑' j : ℕ, omegaReciprocalTerm q (X + 1 + j)

theorem summable_omegaReciprocalTail
    (q X : ℕ) :
    Summable (fun j : ℕ => omegaReciprocalTerm q (X + 1 + j)) := by
  have hs :
      Summable (fun j : ℕ => omegaReciprocalTerm q (j + (X + 1))) :=
    (summable_nat_add_iff (f := omegaReciprocalTerm q) (X + 1)).2
      (summable_omegaReciprocalTerm q)
  simpa [Nat.add_comm, Nat.add_left_comm, Nat.add_assoc] using hs

theorem omegaReciprocalTail_nonneg
    (q X : ℕ) :
    0 ≤ omegaReciprocalTail q X := by
  unfold omegaReciprocalTail
  exact tsum_nonneg fun j => omegaReciprocalTerm_nonneg q (X + 1 + j)

theorem omegaReciprocalTail_eq_omegaCoeff_div
    (q X : ℕ) :
    omegaReciprocalTail q X =
      ∑' j : ℕ, omegaCoeff q (X + 1 + j) / ((X + 1 + j : ℕ) : ℝ) := by
  unfold omegaReciprocalTail
  apply tsum_congr
  intro j
  exact omegaReciprocalTerm_eq_omegaCoeff_div q (X + 1 + j)

theorem omegaReciprocalTail_le
    (q X : ℕ) (hX : 0 < X) :
    omegaReciprocalTail q X ≤
      4 * omegaRankinBound * (X : ℝ)⁻¹ := by
  have hR0 : 0 ≤ omegaRankinBound := by
    unfold omegaRankinBound
    positivity
  have hXR : (0 : ℝ) < X := by exact_mod_cast hX
  have hInvX0 : 0 ≤ (X : ℝ)⁻¹ := le_of_lt (inv_pos.mpr hXR)
  unfold omegaReciprocalTail
  apply Real.tsum_le_of_sum_range_le
    (fun j => omegaReciprocalTerm_nonneg q (X + 1 + j))
  intro K
  cases K with
  | zero =>
      simp
      exact mul_nonneg (mul_nonneg (by norm_num) hR0) hInvX0
  | succ k =>
      have hXM : X < X + (k + 1) := by omega
      have hfinite :=
        abs_omegaReciprocalFiniteTail_le q X (X + (k + 1)) hX hXM
      have hEq :
          (∑ j ∈ Finset.range (k + 1),
            omegaReciprocalTerm q (X + 1 + j)) =
          ∑ j ∈ Finset.Ico X (X + (k + 1)),
            omegaReciprocalTerm q (j + 1) := by
        refine Finset.sum_bij
          (fun j hj => X + j)
          ?_ ?_ ?_ ?_
        · intro j hj
          rw [Finset.mem_range] at hj
          rw [Finset.mem_Ico]
          omega
        · intro j1 hj1 j2 hj2 h
          omega
        · intro i hi
          rw [Finset.mem_Ico] at hi
          refine ⟨i - X, ?_, ?_⟩
          · rw [Finset.mem_range]
            omega
          · omega
        · intro j hj
          congr 1
          omega
      rw [hEq]
      have hnonneg :
          0 ≤ ∑ j ∈ Finset.Ico X (X + (k + 1)),
            omegaReciprocalTerm q (j + 1) := by
        exact Finset.sum_nonneg fun j hj =>
          omegaReciprocalTerm_nonneg q (j + 1)
      simpa [abs_of_nonneg hnonneg] using hfinite

theorem abs_omegaReciprocalTail_le
    (q X : ℕ) (hX : 0 < X) :
    |omegaReciprocalTail q X| ≤
      4 * omegaRankinBound * (X : ℝ)⁻¹ := by
  rw [abs_of_nonneg (omegaReciprocalTail_nonneg q X)]
  exact omegaReciprocalTail_le q X hX

#print axioms omegaReciprocalTail_le
#print axioms abs_omegaReciprocalTail_le

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem omegaReciprocalTail_manuscript
    (q H : ℕ) (hH : 2 ≤ H) :
    |((H - 1 : ℕ) : ℝ) * omegaReciprocalTail q (H - 1)| ≤
      4 * omegaRankinBound := by
  have hX : 0 < H - 1 := by omega
  have hXR : (0 : ℝ) < (H - 1 : ℕ) := by exact_mod_cast hX
  have htail := omegaReciprocalTail_le q (H - 1) hX
  have htail0 := omegaReciprocalTail_nonneg q (H - 1)
  have hR0 : 0 ≤ omegaRankinBound := by
    unfold omegaRankinBound
    positivity
  rw [abs_mul, abs_of_nonneg (le_of_lt hXR), abs_of_nonneg htail0]
  calc
    ((H - 1 : ℕ) : ℝ) * omegaReciprocalTail q (H - 1)
      ≤ ((H - 1 : ℕ) : ℝ) *
          (4 * omegaRankinBound * (((H - 1 : ℕ) : ℝ)⁻¹)) :=
        mul_le_mul_of_nonneg_left htail (le_of_lt hXR)
    _ = 4 * omegaRankinBound := by
      have hXne : (((H - 1 : ℕ) : ℝ)) ≠ 0 := ne_of_gt hXR
      field_simp [hXne]

#print axioms omegaReciprocalTail_manuscript

end PaperB.FixedQ
