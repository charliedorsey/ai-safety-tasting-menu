import GoldC.QuillonVaughan
import GoldC.QuillonWCell
import GoldC.QuillonAbel
import Mathlib.NumberTheory.ArithmeticFunction.Misc

/-!
# Quillon CSC3 F7.4c: VW (Vaughan) machinery for prime sums with Kloosterman phases mod `s`

* `sum_Ioc_conv_twist`: `Σ_{n≤N}(f*g)(n)F(n) = Σ_{d≤N} f(d) Σ_{m≤N/d} g(m)F(dm)`.
* `sum_Ioc_conv_twist_AB`: the same over `(A, B]`, with `m ∈ (A/d, B/d]`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset ArithmeticFunction

namespace GoldC.QuillonVW

theorem sum_Ioc_conv_twist (f g : ArithmeticFunction ℝ) (F : ℕ → ℂ) (N : ℕ) :
    ∑ n ∈ Ioc 0 N, (((f * g) n : ℝ) : ℂ) * F n =
      ∑ d ∈ Ioc 0 N, (f d : ℂ) * ∑ m ∈ Ioc 0 (N / d), (g m : ℂ) * F (d * m) := by
  simp only [mul_apply, Complex.ofReal_sum, Complex.ofReal_mul, sum_mul]
  trans ∑ n ∈ Ioc 0 N, ∑ x ∈ Ioc 0 N ×ˢ Ioc 0 N with x.1 * x.2 = n,
      (f x.1 : ℂ) * (g x.2 : ℂ) * F (x.1 * x.2)
  · refine sum_congr rfl fun n hn => ?_
    simp only [mem_Ioc] at hn
    rw [Nat.divisorsAntidiagonal_eq_prod_filter_of_le hn.1.ne' hn.2]
    refine sum_congr rfl fun x hx => ?_
    rw [(mem_filter.1 hx).2]
  · simp_rw [sum_filter]
    rw [sum_comm]
    trans ∑ x ∈ Ioc 0 N ×ˢ Ioc 0 N, if x.1 * x.2 ≤ N then
        (f x.1 : ℂ) * (g x.2 : ℂ) * F (x.1 * x.2) else 0
    · refine sum_congr rfl fun x hx => ?_
      rw [sum_ite_eq]
      simp only [mem_product, mem_Ioc] at hx
      by_cases h : x.1 * x.2 ≤ N
      · rw [if_pos (mem_Ioc.2 ⟨Nat.mul_pos hx.1.1 hx.2.1, h⟩), if_pos h]
      · rw [if_neg (fun h' => h (mem_Ioc.1 h').2), if_neg h]
    rw [sum_product]
    refine sum_congr rfl fun d hd => ?_
    rw [mul_sum, ← sum_filter]
    simp only [mem_Ioc] at hd
    dsimp only
    apply sum_congr
    · ext m
      simp only [mem_filter, mem_Ioc]
      constructor
      · rintro ⟨⟨hm0, _⟩, hm⟩
        exact ⟨hm0, (Nat.le_div_iff_mul_le hd.1).2 (by linarith [mul_comm d m])⟩
      · rintro ⟨hm0, hm⟩
        have := (Nat.le_div_iff_mul_le hd.1).1 hm
        refine ⟨⟨hm0, ?_⟩, by linarith [mul_comm d m]⟩
        calc m ≤ m * d := Nat.le_mul_of_pos_right m hd.1
          _ ≤ N := this
    · intro m _; ring

theorem sum_Ioc_conv_twist_AB (f g : ArithmeticFunction ℝ) (F : ℕ → ℂ) (A B : ℕ) (hAB : A ≤ B) :
    ∑ n ∈ Ioc A B, (((f * g) n : ℝ) : ℂ) * F n =
      ∑ d ∈ Ioc 0 B, (f d : ℂ) * ∑ m ∈ Ioc (A / d) (B / d), (g m : ℂ) * F (d * m) := by
  have hB := sum_Ioc_conv_twist f g F B
  have hA := sum_Ioc_conv_twist f g F A
  rw [← sum_Ioc_consecutive _ (Nat.zero_le A) hAB] at hB
  have hA' : ∑ d ∈ Ioc 0 A, (f d : ℂ) * ∑ m ∈ Ioc 0 (A / d), (g m : ℂ) * F (d * m) =
      ∑ d ∈ Ioc 0 B, (f d : ℂ) * ∑ m ∈ Ioc 0 (A / d), (g m : ℂ) * F (d * m) := by
    apply sum_subset (Ioc_subset_Ioc_right hAB)
    intro d hd hdA
    simp only [mem_Ioc, not_and, not_le] at hd hdA
    rw [Nat.div_eq_of_lt (hdA hd.1), Ioc_self, sum_empty, mul_zero]
  have key : ∑ n ∈ Ioc A B, (((f * g) n : ℝ) : ℂ) * F n =
      ∑ d ∈ Ioc 0 B, (f d : ℂ) * ∑ m ∈ Ioc 0 (B / d), (g m : ℂ) * F (d * m) -
      ∑ d ∈ Ioc 0 B, (f d : ℂ) * ∑ m ∈ Ioc 0 (A / d), (g m : ℂ) * F (d * m) := by
    rw [← hA', ← hA, ← hB]; ring
  rw [key, ← sum_sub_distrib]
  refine sum_congr rfl fun d _ => ?_
  rw [← mul_sub, ← sum_Ioc_consecutive _ (Nat.zero_le (A / d)) (Nat.div_le_div_right hAB)]
  ring

/-! ## Abel summation with monotone real weights -/

open GoldC.QuillonAbel in
lemma abel_inc (w : ℕ → ℝ) (hw : ∀ n, 0 ≤ w n) (hmono : Monotone w) (b : ℕ → ℂ) (N M : ℕ)
    (hNM : N ≤ M) (β : ℝ) (hB : ∀ j, N ≤ j → j ≤ M → ‖psum b N j‖ ≤ β) :
    ‖∑ n ∈ Ioc N M, (w n : ℂ) * b n‖ ≤ 2 * w M * β := by
  have hβ : 0 ≤ β := (norm_nonneg _).trans (hB N le_rfl hNM)
  refine (abel_bound (fun n => (w n : ℂ)) b N M hNM β hB).trans ?_
  apply mul_le_mul_of_nonneg_right _ hβ
  rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (hw M)]
  rcases Nat.lt_or_ge N M with h | h
  · rw [variation_monotone w N M h (fun n _ _ => hmono (Nat.le_succ n))]
    linarith [hw (N + 1)]
  · have : Ico (N + 1) M = ∅ := Finset.Ico_eq_empty (by omega)
    rw [this, sum_empty]; linarith [hw M]

open GoldC.QuillonAbel in
lemma abel_dec (w : ℕ → ℝ) (hw : ∀ n, 0 ≤ w n) (hanti : Antitone w) (b : ℕ → ℂ) (N M : ℕ)
    (hNM : N ≤ M) (β : ℝ) (hB : ∀ j, N ≤ j → j ≤ M → ‖psum b N j‖ ≤ β) :
    ‖∑ n ∈ Ioc N M, (w n : ℂ) * b n‖ ≤ w (N + 1) * β := by
  have hβ : 0 ≤ β := (norm_nonneg _).trans (hB N le_rfl hNM)
  rcases Nat.lt_or_ge N M with h | h
  · refine (abel_bound (fun n => (w n : ℂ)) b N M hNM β hB).trans ?_
    apply mul_le_mul_of_nonneg_right _ hβ
    rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (hw M),
      variation_antitone w N M h (fun n _ _ => hanti (Nat.le_succ n))]
    linarith
  · have : Ioc N M = ∅ := Finset.Ioc_eq_empty (by omega)
    rw [this, sum_empty, norm_zero]; exact mul_nonneg (hw _) hβ

/-! ## The Kloosterman phase `1_unit(n)·e(c n̄/s)` -/

section phase
variable {s : ℕ} [NeZero s]

/-- `kphase c n = 1_{unit}(n)·e(c n̄/s)`. -/
noncomputable def kphase (c : ZMod s) (n : ℕ) : ℂ :=
  if IsUnit (n : ZMod s) then ZMod.stdAddChar (c * (n : ZMod s)⁻¹) else 0

lemma norm_kphase_le (c : ZMod s) (n : ℕ) : ‖kphase c n‖ ≤ 1 := by
  unfold kphase; split_ifs
  · exact (AddChar.norm_apply _ _).le
  · simp

lemma kphase_mul (c : ZMod s) (d m : ℕ) :
    kphase c (d * m) = if IsUnit (d : ZMod s) then kphase (c * (d : ZMod s)⁻¹) m else 0 := by
  unfold kphase
  push_cast
  by_cases hd : IsUnit (d : ZMod s)
  · rw [if_pos hd]
    by_cases hm : IsUnit (m : ZMod s)
    · rw [if_pos (hd.mul hm), if_pos hm, GoldC.QuillonW.unit_mul_inv hd hm, mul_assoc]
    · rw [if_neg (fun h => hm (isUnit_of_mul_isUnit_right h)), if_neg hm]
  · rw [if_neg (fun h => hd (isUnit_of_mul_isUnit_left h)), if_neg hd]

omit [NeZero s] in
lemma unit_inv_isUnit {d : ZMod s} (hd : IsUnit d) : IsUnit d⁻¹ := by
  rw [← hd.unit_spec, ZMod.inv_coe_unit]; exact Units.isUnit _

/-- Incomplete sum of the shifted phase. -/
lemma kphase_shift_bound (hs : 2 ≤ s) (c : ZMod s) (d N M : ℕ) (hNM : N ≤ M) (Kmax : ℝ)
    (hK : ∀ u : ZMod s, IsUnit u → ∀ b : ZMod s, ‖GoldC.QuillonKl.K s b (c * u)‖ ≤ Kmax)
    (hK0 : 0 ≤ Kmax) :
    ‖∑ m ∈ Ioc N M, kphase c (d * m)‖ ≤ Kmax * (((M - N : ℕ) : ℝ) / s + 1 + Real.log s) := by
  simp_rw [kphase_mul]
  by_cases hd : IsUnit (d : ZMod s)
  · simp_rw [if_pos hd]
    exact GoldC.QuillonCompletion.incomplete_bound hs _ N M hNM Kmax
      (hK _ (unit_inv_isUnit hd))
  · simp_rw [if_neg hd, sum_const_zero, norm_zero]
    have : (0 : ℝ) ≤ Real.log s := Real.log_nonneg (by exact_mod_cast (show 1 ≤ s by omega))
    positivity

end phase

/-! ## Type I sums -/

/-- `μ` as a real arithmetic function. -/
noncomputable abbrev μR : ArithmeticFunction ℝ := ((moebius : ArithmeticFunction ℤ) : ArithmeticFunction ℝ)
/-- `ζ` as a real arithmetic function. -/
noncomputable abbrev ζR : ArithmeticFunction ℝ := ((zeta : ArithmeticFunction ℕ) : ArithmeticFunction ℝ)

lemma harm_Ioc_le (U : ℕ) : ∑ d ∈ Ioc 0 U, (1 / (d : ℝ)) ≤ 1 + Real.log U := by
  have := harmonic_le_one_add_log U
  rw [harmonic_eq_sum_Icc] at this; push_cast at this
  have e : Ioc 0 U = Icc 1 U := by ext d; simp only [mem_Ioc, mem_Icc]; omega
  rw [e]; simpa [one_div] using this

lemma log_nat_div_le (B d : ℕ) : Real.log ((B / d : ℕ) : ℝ) ≤ Real.log B := by
  rcases Nat.eq_zero_or_pos (B / d) with h | h
  · rw [h, Nat.cast_zero, Real.log_zero]
    exact Real.log_natCast_nonneg B
  · exact Real.log_le_log (by exact_mod_cast h) (by exact_mod_cast Nat.div_le_self B d)

/-- Inner bound shared by both Type I sums: `Σ_{d ≤ D₀} (⌊B/d⌋/s + 1 + log s) ≤ B(1+log D₀)/s + D₀(1+log s)`. -/
lemma typeI_outer (s B D₀ : ℕ) (hs : 1 ≤ s) :
    ∑ d ∈ Ioc 0 D₀, (((B / d : ℕ) : ℝ) / s + 1 + Real.log s) ≤
      B * (1 + Real.log D₀) / s + D₀ * (1 + Real.log s) := by
  have hsR : (0 : ℝ) < s := by exact_mod_cast hs
  calc _ ≤ ∑ d ∈ Ioc 0 D₀, ((B : ℝ) / s * (1 / (d : ℝ)) + (1 + Real.log s)) := by
        refine sum_le_sum fun d hd => ?_
        have h1 : ((B / d : ℕ) : ℝ) ≤ (B : ℝ) / d := Nat.cast_div_le
        have : ((B / d : ℕ) : ℝ) / s ≤ (B : ℝ) / s * (1 / (d : ℝ)) := by
          rw [div_mul_div_comm, mul_one, mul_comm (s : ℝ)]
          rw [div_le_div_iff₀ hsR (by have := (mem_Ioc.1 hd).1; positivity)]
          have hdR : (0 : ℝ) < d := by exact_mod_cast (mem_Ioc.1 hd).1
          calc ((B / d : ℕ) : ℝ) * (d * s) = (((B / d : ℕ) : ℝ) * d) * s := by ring
            _ ≤ B * s := by
                apply mul_le_mul_of_nonneg_right _ hsR.le
                exact_mod_cast Nat.div_mul_le_self B d
        linarith
    _ = (B : ℝ) / s * ∑ d ∈ Ioc 0 D₀, (1 / (d : ℝ)) + D₀ * (1 + Real.log s) := by
        rw [sum_add_distrib, ← mul_sum, sum_const, Nat.card_Ioc, nsmul_eq_mul]; simp only [Nat.sub_zero]
    _ ≤ (B : ℝ) / s * (1 + Real.log D₀) + D₀ * (1 + Real.log s) := by
        gcongr; exact harm_Ioc_le D₀
    _ = _ := by ring

section typeI
variable {s : ℕ} [NeZero s]

/-- **Type I₁** (`μ_{≤U} * log`). -/
theorem typeI1 (hs : 2 ≤ s) (c : ZMod s) (U A B : ℕ) (hAB : A ≤ B) (Kmax : ℝ)
    (hK : ∀ u : ZMod s, IsUnit u → ∀ b : ZMod s, ‖GoldC.QuillonKl.K s b (c * u)‖ ≤ Kmax)
    (hK0 : 0 ≤ Kmax) :
    ‖∑ n ∈ Ioc A B, ((((GoldC.QuillonVaughan.trunc U μR) * log) n : ℝ) : ℂ) * kphase c n‖ ≤
      2 * Real.log B * Kmax * (B * (1 + Real.log U) / s + U * (1 + Real.log s)) := by
  rw [sum_Ioc_conv_twist_AB _ _ _ A B hAB]
  have hlogs : 0 ≤ Real.log s := Real.log_nonneg (by exact_mod_cast (show 1 ≤ s by omega))
  have hlogB : 0 ≤ Real.log B := Real.log_natCast_nonneg B
  have hpt : ∀ d ∈ Ioc 0 B,
      ‖((GoldC.QuillonVaughan.trunc U μR d : ℝ) : ℂ) *
          ∑ m ∈ Ioc (A / d) (B / d), ((log m : ℝ) : ℂ) * kphase c (d * m)‖ ≤
        (if d ≤ U then 1 else 0) *
          (2 * Real.log B * Kmax * (((B / d : ℕ) : ℝ) / s + 1 + Real.log s)) := by
    intro d hd
    rw [GoldC.QuillonVaughan.trunc_apply]
    split_ifs with hdU
    · rw [norm_mul, one_mul]
      have hμ : ‖((μR d : ℝ) : ℂ)‖ ≤ 1 := by
        rw [Complex.norm_real, Real.norm_eq_abs]
        simp only [μR, intCoe_apply]
        exact_mod_cast abs_moebius_le_one
      have hAB' : A / d ≤ B / d := Nat.div_le_div_right hAB
      have hβ : ∀ j, A / d ≤ j → j ≤ B / d →
          ‖GoldC.QuillonAbel.psum (fun m => kphase c (d * m)) (A / d) j‖ ≤
            Kmax * (((B / d - A / d : ℕ) : ℝ) / s + 1 + Real.log s) := by
        intro j hj1 hj2
        refine (kphase_shift_bound hs c d (A / d) j hj1 Kmax hK hK0).trans ?_
        gcongr
      have hinner := abel_inc (fun m => Real.log m) (fun m => Real.log_natCast_nonneg m)
        (fun a b hab => by
          rcases Nat.eq_zero_or_pos a with h | h
          · simp [h, Real.log_natCast_nonneg]
          · exact Real.log_le_log (by exact_mod_cast h) (by exact_mod_cast hab))
        (fun m => kphase c (d * m)) (A / d) (B / d) hAB' _ hβ
      simp only [log_apply] at hinner ⊢
      calc ‖((μR d : ℝ) : ℂ)‖ * ‖∑ m ∈ Ioc (A / d) (B / d), ((Real.log m : ℝ) : ℂ) * kphase c (d * m)‖
          ≤ 1 * (2 * Real.log ((B / d : ℕ) : ℝ) *
              (Kmax * (((B / d - A / d : ℕ) : ℝ) / s + 1 + Real.log s))) :=
            mul_le_mul hμ hinner (norm_nonneg _) zero_le_one
        _ ≤ _ := by
            rw [one_mul, ← mul_assoc]
            have h1 := log_nat_div_le B d
            have h2 : ((B / d - A / d : ℕ) : ℝ) ≤ ((B / d : ℕ) : ℝ) := by exact_mod_cast Nat.sub_le _ _
            have hsR : (0 : ℝ) < s := by exact_mod_cast (show 0 < s by omega)
            have h3 : ((B / d - A / d : ℕ) : ℝ) / s ≤ ((B / d : ℕ) : ℝ) / s :=
              div_le_div_of_nonneg_right h2 hsR.le
            have hlogd : 0 ≤ Real.log ((B / d : ℕ) : ℝ) := Real.log_natCast_nonneg _
            have hpos : 0 ≤ ((B / d - A / d : ℕ) : ℝ) / s + 1 + Real.log s := by positivity
            calc 2 * Real.log ((B / d : ℕ) : ℝ) * Kmax * (((B / d - A / d : ℕ) : ℝ) / s + 1 + Real.log s)
                ≤ 2 * Real.log B * Kmax * (((B / d - A / d : ℕ) : ℝ) / s + 1 + Real.log s) := by
                  gcongr
              _ ≤ _ := by gcongr
    · rw [Complex.ofReal_zero, zero_mul, norm_zero, zero_mul]
  refine (norm_sum_le _ _).trans ((sum_le_sum hpt).trans ?_)
  have hC : 0 ≤ 2 * Real.log B * Kmax := by positivity
  calc ∑ d ∈ Ioc 0 B, (if d ≤ U then (1 : ℝ) else 0) *
        (2 * Real.log B * Kmax * (((B / d : ℕ) : ℝ) / s + 1 + Real.log s))
      ≤ ∑ d ∈ Ioc 0 U, 2 * Real.log B * Kmax * (((B / d : ℕ) : ℝ) / s + 1 + Real.log s) := by
        simp only [ite_mul, one_mul, zero_mul]
        rw [← sum_filter]
        apply sum_le_sum_of_subset_of_nonneg
        · intro d hd; simp only [mem_filter, mem_Ioc] at hd ⊢; omega
        · intro d _ _; positivity
    _ = 2 * Real.log B * Kmax * ∑ d ∈ Ioc 0 U, (((B / d : ℕ) : ℝ) / s + 1 + Real.log s) := by
        rw [mul_sum]
    _ ≤ _ := mul_le_mul_of_nonneg_left (typeI_outer s B U (by omega)) hC

/-- `|(μ_{≤U} * Λ_{≤V})(d)| ≤ log d`. -/
lemma lam_bound (U V d : ℕ) :
    |((GoldC.QuillonVaughan.trunc U μR) * (GoldC.QuillonVaughan.trunc V vonMangoldt)) d| ≤
      Real.log d := by
  rw [mul_apply]
  refine (abs_sum_le_sum_abs _ _).trans ?_
  calc ∑ x ∈ d.divisorsAntidiagonal, |GoldC.QuillonVaughan.trunc U μR x.1 *
        GoldC.QuillonVaughan.trunc V vonMangoldt x.2|
      ≤ ∑ x ∈ d.divisorsAntidiagonal, vonMangoldt x.2 := by
        refine sum_le_sum fun x _ => ?_
        rw [abs_mul, GoldC.QuillonVaughan.trunc_apply, GoldC.QuillonVaughan.trunc_apply]
        have hμ : |(if x.1 ≤ U then μR x.1 else 0)| ≤ 1 := by
          split_ifs
          · simp only [μR, intCoe_apply]; exact_mod_cast abs_moebius_le_one
          · simp
        have hΛ : |(if x.2 ≤ V then (vonMangoldt x.2 : ℝ) else 0)| ≤ vonMangoldt x.2 := by
          split_ifs
          · rw [abs_of_nonneg vonMangoldt_nonneg]
          · simp [vonMangoldt_nonneg]
        calc _ ≤ 1 * (vonMangoldt x.2 : ℝ) := mul_le_mul hμ hΛ (abs_nonneg _) zero_le_one
          _ = _ := one_mul _
    _ = ∑ i ∈ d.divisors, vonMangoldt i := Nat.sum_divisorsAntidiagonal' (fun _ b => vonMangoldt b)
    _ = Real.log d := vonMangoldt_sum

lemma lam_support (U V d : ℕ) (hd : U * V < d) :
    ((GoldC.QuillonVaughan.trunc U μR) * (GoldC.QuillonVaughan.trunc V vonMangoldt)) d = 0 := by
  rw [mul_apply]
  refine sum_eq_zero fun x hx => ?_
  rw [Nat.mem_divisorsAntidiagonal] at hx
  rw [GoldC.QuillonVaughan.trunc_apply, GoldC.QuillonVaughan.trunc_apply]
  by_cases h1 : x.1 ≤ U
  · by_cases h2 : x.2 ≤ V
    · exfalso; have := Nat.mul_le_mul h1 h2; omega
    · rw [if_neg h2, mul_zero]
  · rw [if_neg h1, zero_mul]

/-- **Type I₂** (`μ_{≤U} * Λ_{≤V} * ζ`). -/
theorem typeI2 (hs : 2 ≤ s) (c : ZMod s) (U V A B : ℕ) (hAB : A ≤ B) (Kmax : ℝ)
    (hK : ∀ u : ZMod s, IsUnit u → ∀ b : ZMod s, ‖GoldC.QuillonKl.K s b (c * u)‖ ≤ Kmax)
    (hK0 : 0 ≤ Kmax) :
    ‖∑ n ∈ Ioc A B, ((((GoldC.QuillonVaughan.trunc U μR) *
        (GoldC.QuillonVaughan.trunc V vonMangoldt) * ζR) n : ℝ) : ℂ) * kphase c n‖ ≤
      Real.log B * Kmax * (B * (1 + Real.log (U * V : ℕ)) / s + (U * V : ℕ) * (1 + Real.log s)) := by
  rw [sum_Ioc_conv_twist_AB _ _ _ A B hAB]
  have hlogs : 0 ≤ Real.log s := Real.log_nonneg (by exact_mod_cast (show 1 ≤ s by omega))
  have hlogB : 0 ≤ Real.log B := Real.log_natCast_nonneg B
  set lam := (GoldC.QuillonVaughan.trunc U μR) * (GoldC.QuillonVaughan.trunc V vonMangoldt)
  have hpt : ∀ d ∈ Ioc 0 B,
      ‖((lam d : ℝ) : ℂ) * ∑ m ∈ Ioc (A / d) (B / d), ((ζR m : ℝ) : ℂ) * kphase c (d * m)‖ ≤
        (if d ≤ U * V then 1 else 0) *
          (Real.log B * Kmax * (((B / d : ℕ) : ℝ) / s + 1 + Real.log s)) := by
    intro d hd
    have hd1 := (mem_Ioc.1 hd)
    split_ifs with hdUV
    · rw [norm_mul, one_mul]
      have hζ : ∑ m ∈ Ioc (A / d) (B / d), ((ζR m : ℝ) : ℂ) * kphase c (d * m) =
          ∑ m ∈ Ioc (A / d) (B / d), kphase c (d * m) := by
        refine sum_congr rfl fun m hm => ?_
        have hm0 : m ≠ 0 := Nat.pos_iff_ne_zero.1 (lt_of_le_of_lt (Nat.zero_le _) (mem_Ioc.1 hm).1)
        simp only [ζR, natCoe_apply, zeta_apply, if_neg hm0, Nat.cast_one, Complex.ofReal_one,
          one_mul]
      rw [hζ]
      have hl : ‖((lam d : ℝ) : ℂ)‖ ≤ Real.log B := by
        rw [Complex.norm_real, Real.norm_eq_abs]
        exact (lam_bound U V d).trans (Real.log_le_log (by exact_mod_cast hd1.1)
          (by exact_mod_cast hd1.2))
      have hin := kphase_shift_bound hs c d (A / d) (B / d) (Nat.div_le_div_right hAB) Kmax hK hK0
      have hsR : (0 : ℝ) < s := by exact_mod_cast (show 0 < s by omega)
      have h2 : ((B / d - A / d : ℕ) : ℝ) / s ≤ ((B / d : ℕ) : ℝ) / s :=
        div_le_div_of_nonneg_right (by exact_mod_cast Nat.sub_le _ _) hsR.le
      calc ‖((lam d : ℝ) : ℂ)‖ * ‖∑ m ∈ Ioc (A / d) (B / d), kphase c (d * m)‖
          ≤ Real.log B * (Kmax * (((B / d - A / d : ℕ) : ℝ) / s + 1 + Real.log s)) :=
            mul_le_mul hl hin (norm_nonneg _) hlogB
        _ ≤ Real.log B * (Kmax * (((B / d : ℕ) : ℝ) / s + 1 + Real.log s)) := by gcongr
        _ = _ := by ring
    · rw [lam_support U V d (lt_of_not_ge hdUV), Complex.ofReal_zero, zero_mul, norm_zero, zero_mul]
  refine (norm_sum_le _ _).trans ((sum_le_sum hpt).trans ?_)
  have hC : 0 ≤ Real.log B * Kmax := by positivity
  calc ∑ d ∈ Ioc 0 B, (if d ≤ U * V then (1 : ℝ) else 0) *
        (Real.log B * Kmax * (((B / d : ℕ) : ℝ) / s + 1 + Real.log s))
      ≤ ∑ d ∈ Ioc 0 (U * V), Real.log B * Kmax * (((B / d : ℕ) : ℝ) / s + 1 + Real.log s) := by
        simp only [ite_mul, one_mul, zero_mul]
        rw [← sum_filter]
        apply sum_le_sum_of_subset_of_nonneg
        · intro d hd; simp only [mem_filter, mem_Ioc] at hd ⊢; omega
        · intro d _ _; positivity
    _ = Real.log B * Kmax * ∑ d ∈ Ioc 0 (U * V), (((B / d : ℕ) : ℝ) / s + 1 + Real.log s) := by
        rw [mul_sum]
    _ ≤ _ := by
        have := typeI_outer s B (U * V) (by omega)
        push_cast at this ⊢
        exact mul_le_mul_of_nonneg_left this hC

end typeI

end GoldC.QuillonVW

#print axioms GoldC.QuillonVW.sum_Ioc_conv_twist
#print axioms GoldC.QuillonVW.sum_Ioc_conv_twist_AB
#print axioms GoldC.QuillonVW.kphase_shift_bound
#print axioms GoldC.QuillonVW.abel_inc
#print axioms GoldC.QuillonVW.abel_dec
#print axioms GoldC.QuillonVW.typeI1
#print axioms GoldC.QuillonVW.typeI2
