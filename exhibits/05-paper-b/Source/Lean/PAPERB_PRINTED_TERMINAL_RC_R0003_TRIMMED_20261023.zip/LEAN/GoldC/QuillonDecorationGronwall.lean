import Mathlib.NumberTheory.Primorial
import Mathlib.NumberTheory.Harmonic.Bounds
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Tactic

/-!
# Quillon CSC3 — decoration-mass Gronwall-type bound (Lemma G)

The decoration definitions below are **verbatim copies** of the curated
`GoldC/SourceCore.lean` (SHA-256 `0888e660…0362`, byte-identical in the curated
supplement and in this workspace). The full `import Mathlib` that SourceCore uses is not
built here, so the copies live in `GoldC.QuillonCopyG`. Replaying against production
means deleting the copies and importing `GoldC.SourceCore`. Every proof below uses only
the definitions' bodies.

Main results:
* `decoration_mass_eq_prod`: Σ_{d ⊆ P} decorationWeight h d = ∏_{p∈P} (1 + 1/(p-2)) (exact).
* `sum_inv_primes_below_two_pow`: Σ_{p<2^(K+1)} 1/p ≤ 4·H_K (Chebyshev via `primorial_le_four_pow`).
* `decoration_mass_le_exp_loglog`: for 16 ≤ h, the mass is
  ≤ exp (10 + 8·log (Nat.log 2 ⌊log h⌋₊)), i.e. `≪ (log log h)^8`.
No axioms beyond Lean/Mathlib standard ones.
-/

open scoped BigOperators Classical
open Finset Real

namespace GoldC.QuillonCopyG

/-- Verbatim copy of `GoldC.decoratedHeightPrimeSet`. -/
def decoratedHeightPrimeSet (q h : ℕ) : Finset ℕ :=
  h.primeFactors.filter (fun p => 5 ≤ p ∧ ¬ p ∣ q)

/-- Verbatim copy of `GoldC.decorationWeight`. -/
noncomputable def decorationWeight (h : ℕ) (s : Finset ℕ) : ℝ :=
  ∏ p ∈ s, if p ∣ h then 1 / ((p : ℝ) - 2) else 1 / ((p : ℝ) - 3)

lemma mem_P {q h p : ℕ} (hp : p ∈ decoratedHeightPrimeSet q h) :
    p.Prime ∧ p ∣ h ∧ 5 ≤ p ∧ h ≠ 0 := by
  unfold decoratedHeightPrimeSet at hp
  rw [Finset.mem_filter, Nat.mem_primeFactors] at hp
  exact ⟨hp.1.1, hp.1.2.1, hp.2.1, hp.1.2.2⟩

/-- **Exact identity**: the decoration mass is an Euler product. -/
theorem decoration_mass_eq_prod (q h : ℕ) :
    ∑ d ∈ (decoratedHeightPrimeSet q h).powerset, decorationWeight h d =
      ∏ p ∈ decoratedHeightPrimeSet q h, (1 + 1 / ((p : ℝ) - 2)) := by
  rw [Finset.prod_one_add]
  refine Finset.sum_congr rfl fun d hd => ?_
  unfold decorationWeight
  refine Finset.prod_congr rfl fun p hp => ?_
  have := (mem_P (Finset.mem_powerset.1 hd hp)).2.1
  simp [this]

/-- `∏ (1 + x) ≤ exp (Σ x)` for nonnegative `x`. -/
lemma prod_one_add_le_exp_sum {ι : Type*} (s : Finset ι) (x : ι → ℝ)
    (hx : ∀ i ∈ s, 0 ≤ x i) : ∏ i ∈ s, (1 + x i) ≤ Real.exp (∑ i ∈ s, x i) := by
  rw [Real.exp_sum]
  refine Finset.prod_le_prod₀ (fun i hi => by linarith [hx i hi]) fun i _ => ?_
  linarith [Real.add_one_le_exp (x i)]

/-! ## Chebyshev-type dyadic block bound -/

/-- Primes in the dyadic block `[2^k, 2^(k+1))`. -/
def block (k : ℕ) : Finset ℕ := (Finset.Ico (2 ^ k) (2 ^ (k + 1))).filter Nat.Prime

lemma block_card_mul_le (k : ℕ) : k * (block k).card ≤ 2 ^ (k + 2) := by
  -- (2^k)^card ≤ ∏ block ≤ primorial (2^(k+1)) ≤ 4^(2^(k+1)) = 2^(2^(k+2))
  have h1 : (2 ^ k) ^ (block k).card ≤ ∏ p ∈ block k, p :=
    Finset.pow_card_le_prod _ _ _ fun p hp => (Finset.mem_Ico.1 (Finset.mem_filter.1 hp).1).1
  have hsub : block k ⊆ (Finset.range (2 ^ (k + 1) + 1)).filter Nat.Prime := by
    intro p hp
    rw [block, Finset.mem_filter, Finset.mem_Ico] at hp
    rw [Finset.mem_filter, Finset.mem_range]
    exact ⟨by omega, hp.2⟩
  have h2 : ∏ p ∈ block k, p ≤ primorial (2 ^ (k + 1)) := by
    unfold primorial
    apply Nat.le_of_dvd
    · exact Finset.prod_pos fun p hp => (Finset.mem_filter.1 hp).2.pos
    · exact Finset.prod_dvd_prod_of_subset _ _ _ hsub
  have h3 := primorial_le_four_pow (2 ^ (k + 1))
  have h4 : (4 : ℕ) ^ (2 ^ (k + 1)) = 2 ^ (2 ^ (k + 2)) := by
    rw [show (4 : ℕ) = 2 ^ 2 by norm_num, ← pow_mul]; congr 1; ring
  have h5 : 2 ^ (k * (block k).card) ≤ 2 ^ (2 ^ (k + 2)) := by
    rw [pow_mul]; calc _ ≤ _ := h1
      _ ≤ _ := h2
      _ ≤ _ := h3
      _ = _ := h4
  exact (Nat.pow_le_pow_iff_right (by norm_num)).1 h5

lemma block_sum_le (k : ℕ) (hk : 1 ≤ k) :
    ∑ p ∈ block k, (1 / (p : ℝ)) ≤ 4 / k := by
  have hk' : (0 : ℝ) < k := by exact_mod_cast hk
  have hpos : (0 : ℝ) < 2 ^ k := by positivity
  calc ∑ p ∈ block k, (1 / (p : ℝ)) ≤ ∑ _p ∈ block k, (1 / (2 : ℝ) ^ k) := by
        refine Finset.sum_le_sum fun p hp => ?_
        have : 2 ^ k ≤ p := (Finset.mem_Ico.1 (Finset.mem_filter.1 hp).1).1
        have : (2 : ℝ) ^ k ≤ p := by exact_mod_cast this
        exact one_div_le_one_div_of_le hpos this
    _ = (block k).card / (2 : ℝ) ^ k := by rw [Finset.sum_const, nsmul_eq_mul]; ring
    _ ≤ 4 / k := by
        rw [div_le_div_iff₀ hpos hk']
        have h := block_card_mul_le k
        have h' : (k : ℝ) * (block k).card ≤ 2 ^ (k + 2) := by exact_mod_cast h
        rw [pow_add] at h'; nlinarith

/-- Primes below `2^K`. -/
def primesBelowPow (K : ℕ) : Finset ℕ := (Finset.range (2 ^ K)).filter Nat.Prime

lemma primesBelowPow_succ (K : ℕ) :
    primesBelowPow (K + 1) = primesBelowPow K ∪ block K := by
  ext p
  simp only [primesBelowPow, block, Finset.mem_union, Finset.mem_filter, Finset.mem_range,
    Finset.mem_Ico]
  have : 2 ^ K ≤ 2 ^ (K + 1) := Nat.pow_le_pow_right (by norm_num) (by omega)
  constructor
  · rintro ⟨h1, h2⟩; by_cases h : p < 2 ^ K
    · exact Or.inl ⟨h, h2⟩
    · exact Or.inr ⟨⟨by omega, h1⟩, h2⟩
  · rintro (⟨h1, h2⟩ | ⟨⟨h1, h1'⟩, h2⟩)
    · exact ⟨by omega, h2⟩
    · exact ⟨h1', h2⟩

lemma disjoint_block (K : ℕ) : Disjoint (primesBelowPow K) (block K) := by
  rw [Finset.disjoint_left]
  intro p h1 h2
  simp only [primesBelowPow, block, Finset.mem_filter, Finset.mem_range, Finset.mem_Ico] at h1 h2
  omega

/-- **Dyadic Mertens-type bound**: `Σ_{p < 2^(K+1)} 1/p ≤ 4·H_K`. -/
theorem sum_inv_primes_below_two_pow (K : ℕ) :
    ∑ p ∈ primesBelowPow (K + 1), (1 / (p : ℝ)) ≤ 4 * (harmonic K : ℝ) := by
  induction K with
  | zero =>
    have : primesBelowPow 1 = ∅ := by
      ext p; simp only [primesBelowPow, Finset.mem_filter, Finset.mem_range,
        Finset.notMem_empty, iff_false, not_and]
      intro hp hpr; have := hpr.two_le; norm_num at hp; omega
    simp [this]
  | succ K ih =>
    rw [primesBelowPow_succ, Finset.sum_union (disjoint_block _), harmonic_succ]
    have hb := block_sum_le (K + 1) (by omega)
    push_cast at hb ⊢
    have : (4 : ℝ) / (K + 1) = 4 * (K + 1 : ℝ)⁻¹ := by ring
    linarith

/-! ## Assembly -/

lemma inv_sub_two_le (p : ℕ) (hp : 5 ≤ p) : 1 / ((p : ℝ) - 2) ≤ 2 * (1 / (p : ℝ)) := by
  have : (5 : ℝ) ≤ p := by exact_mod_cast hp
  rw [div_le_iff₀ (by linarith)]
  field_simp
  linarith

/-- Large decorated primes: at most `log h / log (Y+1)` of them exceed `Y`. -/
lemma large_part_le (q h Y : ℕ) (hh : 0 < h) :
    ∑ p ∈ (decoratedHeightPrimeSet q h).filter (fun p => Y < p), (1 / (p : ℝ)) ≤
      Real.log h / (((Y : ℝ) + 1) * Real.log ((Y : ℝ) + 1)) ∨ Y = 0 := by
  rcases Nat.eq_zero_or_pos Y with hY | hY
  · exact Or.inr hY
  left
  set S := (decoratedHeightPrimeSet q h).filter (fun p => Y < p)
  have hY0 : (0:ℝ) < Y := by exact_mod_cast hY
  have hY1 : (1 : ℝ) < (Y : ℝ) + 1 := by linarith
  have hlogY : 0 < Real.log ((Y : ℝ) + 1) := Real.log_pos hY1
  -- (Y+1)^card ≤ ∏ S ≤ h
  have hprod : ((Y + 1) ^ S.card : ℕ) ≤ h := by
    have h1 : (Y + 1) ^ S.card ≤ ∏ p ∈ S, p :=
      Finset.pow_card_le_prod _ _ _ fun p hp => (Finset.mem_filter.1 hp).2
    have h2 : ∏ p ∈ S, p ∣ h := by
      calc ∏ p ∈ S, p ∣ ∏ p ∈ h.primeFactors, p := by
            refine Finset.prod_dvd_prod_of_subset S h.primeFactors id fun p hp => ?_
            have := mem_P (Finset.mem_filter.1 hp).1
            exact Nat.mem_primeFactors.2 ⟨this.1, this.2.1, hh.ne'⟩
        _ ∣ h := Nat.prod_primeFactors_dvd h
    exact h1.trans (Nat.le_of_dvd hh h2)
  have hcard : (S.card : ℝ) * Real.log ((Y : ℝ) + 1) ≤ Real.log h := by
    have : (((Y + 1) ^ S.card : ℕ) : ℝ) ≤ h := by exact_mod_cast hprod
    have hpos : (0 : ℝ) < (((Y + 1) ^ S.card : ℕ) : ℝ) := by positivity
    have := Real.log_le_log hpos this
    push_cast at this
    rwa [Real.log_pow] at this
  calc ∑ p ∈ S, (1 / (p : ℝ)) ≤ ∑ _p ∈ S, (1 / ((Y : ℝ) + 1)) := by
        refine Finset.sum_le_sum fun p hp => ?_
        have : Y + 1 ≤ p := (Finset.mem_filter.1 hp).2
        have : (Y : ℝ) + 1 ≤ p := by exact_mod_cast this
        exact one_div_le_one_div_of_le (by linarith) this
    _ = S.card / ((Y : ℝ) + 1) := by rw [Finset.sum_const, nsmul_eq_mul]; ring
    _ ≤ Real.log h / (((Y : ℝ) + 1) * Real.log ((Y : ℝ) + 1)) := by
        rw [div_le_div_iff₀ (by linarith) (by positivity)]
        nlinarith

/-- Small decorated primes `≤ Y` lie below `2^(Nat.log 2 Y + 1)`. -/
lemma small_part_le (q h Y : ℕ) :
    ∑ p ∈ (decoratedHeightPrimeSet q h).filter (fun p => ¬ Y < p), (1 / (p : ℝ)) ≤
      4 * (harmonic (Nat.log 2 Y) : ℝ) := by
  refine le_trans ?_ (sum_inv_primes_below_two_pow (Nat.log 2 Y))
  apply Finset.sum_le_sum_of_subset_of_nonneg
  · intro p hp
    rw [Finset.mem_filter] at hp
    have hP := mem_P hp.1
    simp only [primesBelowPow, Finset.mem_filter, Finset.mem_range]
    exact ⟨lt_of_le_of_lt (not_lt.1 hp.2) (Nat.lt_pow_succ_log_self (by norm_num) Y), hP.1⟩
  · intro p _ _; positivity

/-- **Lemma G (decoration Gronwall, crude scale)**: for `16 ≤ h`,
`Σ_{d ⊆ P} decorationWeight h d ≤ exp (10 + 8 · log (Nat.log 2 ⌊log h⌋₊))`. -/
theorem decoration_mass_le_exp_loglog (q h : ℕ) (hh : 16 ≤ h) :
    ∑ d ∈ (decoratedHeightPrimeSet q h).powerset, decorationWeight h d ≤
      Real.exp (10 + 8 * Real.log (Nat.log 2 ⌊Real.log h⌋₊)) := by
  set P := decoratedHeightPrimeSet q h
  set Y := ⌊Real.log h⌋₊
  have hh0 : 0 < h := by omega
  have hlogh : Real.log 16 ≤ Real.log h :=
    Real.log_le_log (by norm_num) (by exact_mod_cast hh)
  have hlog16 : (2.7 : ℝ) < Real.log 16 := by
    rw [show (16 : ℝ) = 2 ^ 4 by norm_num, Real.log_pow]
    have := Real.log_two_gt_d9; push_cast; linarith
  have hY2 : 2 ≤ Y := by
    apply Nat.le_floor; push_cast; linarith
  have hYlt : Real.log h < (Y : ℝ) + 1 := Nat.lt_floor_add_one _
  -- large part ≤ 1
  have hlarge : ∑ p ∈ P.filter (fun p => Y < p), (1 / (p : ℝ)) ≤ 1 := by
    rcases large_part_le q h Y hh0 with h1 | h1
    · refine h1.trans ?_
      have hY3 : (3 : ℝ) ≤ (Y : ℝ) + 1 := by
        have : (2 : ℝ) ≤ Y := by exact_mod_cast hY2
        linarith
      have hl3 : 1 < Real.log ((Y : ℝ) + 1) := by
        have : Real.log 3 ≤ Real.log ((Y : ℝ) + 1) := Real.log_le_log (by norm_num) hY3
        have h3 : (1 : ℝ) < Real.log 3 := by
          have := Real.exp_one_lt_d9
          rw [Real.lt_log_iff_exp_lt (by norm_num)]; linarith
        linarith
      rw [div_le_one (by nlinarith)]
      nlinarith
    · omega
  have hsmall := small_part_le q h Y
  have hharm := harmonic_le_one_add_log (Nat.log 2 Y)
  -- Σ 1/(p-2) ≤ 2 Σ 1/p ≤ 2 (4(1+log m) + 1)
  have hsplit : ∑ p ∈ P, (1 / (p : ℝ)) =
      ∑ p ∈ P.filter (fun p => ¬ Y < p), (1 / (p : ℝ)) +
      ∑ p ∈ P.filter (fun p => Y < p), (1 / (p : ℝ)) := by
    rw [add_comm]; exact (Finset.sum_filter_add_sum_filter_not P _ _).symm
  have hsum : ∑ p ∈ P, (1 / ((p : ℝ) - 2)) ≤ 10 + 8 * Real.log (Nat.log 2 Y) := by
    calc ∑ p ∈ P, (1 / ((p : ℝ) - 2)) ≤ ∑ p ∈ P, 2 * (1 / (p : ℝ)) :=
          Finset.sum_le_sum fun p hp => inv_sub_two_le p (mem_P hp).2.2.1
      _ = 2 * ∑ p ∈ P, (1 / (p : ℝ)) := by rw [Finset.mul_sum]
      _ ≤ 10 + 8 * Real.log (Nat.log 2 Y) := by
          rw [hsplit]; nlinarith
  rw [decoration_mass_eq_prod]
  refine (prod_one_add_le_exp_sum P _ fun p hp => ?_).trans (Real.exp_le_exp.2 hsum)
  have : (5 : ℝ) ≤ p := by exact_mod_cast (mem_P hp).2.2.1
  exact div_nonneg zero_le_one (by linarith)

/-- **Lemma G, `(log log h)^8` form**: for `16 ≤ h`,
`Σ_{d ⊆ P} decorationWeight h d ≤ e^10 · (log log h / log 2 + 1)^8`. -/
theorem decoration_mass_le_loglog_pow (q h : ℕ) (hh : 16 ≤ h) :
    ∑ d ∈ (decoratedHeightPrimeSet q h).powerset, decorationWeight h d ≤
      Real.exp 10 * (Real.log (Real.log h) / Real.log 2 + 1) ^ 8 := by
  refine (decoration_mass_le_exp_loglog q h hh).trans ?_
  set Y := ⌊Real.log h⌋₊
  set m := Nat.log 2 Y
  have hlogh : Real.log 16 ≤ Real.log h :=
    Real.log_le_log (by norm_num) (by exact_mod_cast hh)
  have hlog16 : (2.7 : ℝ) < Real.log 16 := by
    rw [show (16 : ℝ) = 2 ^ 4 by norm_num, Real.log_pow]
    have := Real.log_two_gt_d9; push_cast; linarith
  have hl2 : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hll : 0 ≤ Real.log (Real.log h) := Real.log_nonneg (by linarith)
  have hbase : 0 ≤ Real.log (Real.log h) / Real.log 2 := div_nonneg hll hl2.le
  rcases Nat.eq_zero_or_pos m with hm | hm
  · rw [hm]; simp only [Nat.cast_zero, Real.log_zero, mul_zero, add_zero]
    have : (1 : ℝ) ≤ (Real.log (Real.log h) / Real.log 2 + 1) ^ 8 :=
      one_le_pow₀ (by linarith)
    nlinarith [Real.exp_pos 10]
  · have hmpos : (0 : ℝ) < m := by exact_mod_cast hm
    rw [Real.exp_add, show 8 * Real.log m = Real.log ((m : ℝ) ^ 8) by
      rw [Real.log_pow]; push_cast; ring, Real.exp_log (by positivity)]
    refine mul_le_mul_of_nonneg_left ?_ (Real.exp_pos 10).le
    apply pow_le_pow_left₀ hmpos.le
    -- 2^m ≤ Y ≤ log h, so m·log 2 ≤ log log h
    have hY0 : Y ≠ 0 := by
      intro h0; simp [m, h0] at hm
    have h2m : 2 ^ m ≤ Y := Nat.pow_log_le_self 2 hY0
    have h2mR : (2 : ℝ) ^ m ≤ Real.log h := by
      have : ((2 ^ m : ℕ) : ℝ) ≤ (Y : ℝ) := by exact_mod_cast h2m
      push_cast at this
      exact this.trans (Nat.floor_le (by linarith))
    have := Real.log_le_log (by positivity) h2mR
    rw [Real.log_pow] at this
    have : (m : ℝ) ≤ Real.log (Real.log h) / Real.log 2 := by
      rw [le_div_iff₀ hl2]; linarith
    linarith

/-! ## Sign-safe exact decomposition (replaces any "sandwich" of a signed sum)

If a coupled mask is written exactly as `G = A + E` with `E ≥ 0`, then for any signed
summand `F` with `|F| ≤ C` and nonnegative weights `w`, the error made by replacing `G`
by `A` is at most `C · Σ w E`. No upper/lower sandwich of a signed sum is used. -/
theorem signed_mask_replace {ι : Type*} (S : Finset ι) (w F G A E : ι → ℝ) (C : ℝ)
    (hw : ∀ i ∈ S, 0 ≤ w i) (hF : ∀ i ∈ S, |F i| ≤ C)
    (hdec : ∀ i ∈ S, G i = A i + E i) (hE : ∀ i ∈ S, 0 ≤ E i) :
    |∑ i ∈ S, w i * F i * G i - ∑ i ∈ S, w i * F i * A i| ≤ C * ∑ i ∈ S, w i * E i := by
  rw [← Finset.sum_sub_distrib, Finset.mul_sum]
  refine (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun i hi => ?_)
  rw [hdec i hi, show w i * F i * (A i + E i) - w i * F i * A i = F i * (w i * E i) by ring,
    abs_mul, abs_of_nonneg (mul_nonneg (hw i hi) (hE i hi))]
  exact mul_le_mul_of_nonneg_right (hF i hi) (mul_nonneg (hw i hi) (hE i hi))

/-! ## Corrected W-diagonal gcd count (checkpoint §4)

The naive count `max_y Σ_{y'≡y (g)} α_{y'} ≤ C/Y₀` loses a fatal `Y^{1/2}/Y₀`. The symmetric
double count below is the correct one: `Σ_{y<y', g | y'-y} 1/(y y') ≤ (1+log Y)²/g`. The
full off-diagonal (`y ≠ y'`) is twice this, by symmetry. -/
theorem gcd_pair_sum_le (g Y : ℕ) (hg : 1 ≤ g) :
    ∑ y ∈ Finset.Icc 1 Y, ∑ y' ∈ (Finset.Icc 1 Y).filter (fun y' => y < y' ∧ g ∣ y' - y),
      (1 / ((y : ℝ) * y')) ≤ (1 + Real.log Y) ^ 2 / g := by
  have hgR : (0 : ℝ) < g := by exact_mod_cast hg
  set H : ℝ := ∑ k ∈ Finset.Icc 1 Y, (1 / (k : ℝ)) with hH
  have hHle : H ≤ 1 + Real.log Y := by
    have := harmonic_le_one_add_log Y
    rw [harmonic_eq_sum_Icc] at this; push_cast at this
    simpa [hH, one_div] using this
  have hH0 : 0 ≤ H := Finset.sum_nonneg fun k _ => by positivity
  have inner : ∀ y ∈ Finset.Icc 1 Y,
      ∑ y' ∈ (Finset.Icc 1 Y).filter (fun y' => y < y' ∧ g ∣ y' - y), (1 / ((y : ℝ) * y'))
        ≤ (1 / (y : ℝ)) * (1 / (g : ℝ)) * H := by
    intro y hy
    have hy1 : 1 ≤ y := (Finset.mem_Icc.1 hy).1
    have hyR : (0 : ℝ) < y := by exact_mod_cast hy1
    have hinj : Set.InjOn (fun k => y + k * g) (Finset.Icc 1 Y : Set ℕ) := by
      intro a _ b _ hab
      exact Nat.eq_of_mul_eq_mul_right (show 0 < g by omega) (Nat.add_left_cancel hab)
    have hsub : (Finset.Icc 1 Y).filter (fun y' => y < y' ∧ g ∣ y' - y) ⊆
        (Finset.Icc 1 Y).image (fun k => y + k * g) := by
      intro y' hy'
      rw [Finset.mem_filter, Finset.mem_Icc] at hy'
      obtain ⟨⟨_, hy'Y⟩, hlt, k, hk⟩ := hy'
      rw [Finset.mem_image]
      refine ⟨k, Finset.mem_Icc.2 ⟨?_, ?_⟩, by rw [mul_comm]; omega⟩
      · rcases Nat.eq_zero_or_pos k with h0 | h0
        · rw [h0, mul_zero] at hk; omega
        · exact h0
      · have : k ≤ g * k := Nat.le_mul_of_pos_left k (by omega)
        omega
    calc ∑ y' ∈ (Finset.Icc 1 Y).filter (fun y' => y < y' ∧ g ∣ y' - y), (1 / ((y : ℝ) * y'))
        ≤ ∑ y' ∈ (Finset.Icc 1 Y).image (fun k => y + k * g), (1 / ((y : ℝ) * y')) :=
          Finset.sum_le_sum_of_subset_of_nonneg hsub fun _ _ _ => by positivity
      _ = ∑ k ∈ Finset.Icc 1 Y, (1 / ((y : ℝ) * ((y + k * g : ℕ) : ℝ))) :=
          Finset.sum_image hinj
      _ ≤ ∑ k ∈ Finset.Icc 1 Y, (1 / (y : ℝ)) * (1 / (g : ℝ)) * (1 / (k : ℝ)) := by
          refine Finset.sum_le_sum fun k hk => ?_
          have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast (Finset.mem_Icc.1 hk).1
          have hle : (k : ℝ) * g ≤ ((y + k * g : ℕ) : ℝ) := by push_cast; linarith
          rw [show (1 / (y : ℝ)) * (1 / (g : ℝ)) * (1 / (k : ℝ)) = 1 / ((y : ℝ) * (k * g)) by
            field_simp]
          apply one_div_le_one_div_of_le (by positivity)
          exact mul_le_mul_of_nonneg_left hle hyR.le
      _ = (1 / (y : ℝ)) * (1 / (g : ℝ)) * H := by rw [← Finset.mul_sum]
  calc _ ≤ ∑ y ∈ Finset.Icc 1 Y, (1 / (y : ℝ)) * (1 / (g : ℝ)) * H := Finset.sum_le_sum inner
    _ = H * H / g := by
        rw [← Finset.sum_mul, ← Finset.sum_mul, ← hH]; field_simp
    _ ≤ (1 + Real.log Y) ^ 2 / g := by
        apply div_le_div_of_nonneg_right _ hgR.le
        nlinarith

end GoldC.QuillonCopyG

#print axioms GoldC.QuillonCopyG.decoration_mass_eq_prod
#print axioms GoldC.QuillonCopyG.sum_inv_primes_below_two_pow
#print axioms GoldC.QuillonCopyG.decoration_mass_le_exp_loglog
#print axioms GoldC.QuillonCopyG.decoration_mass_le_loglog_pow
#print axioms GoldC.QuillonCopyG.signed_mask_replace
#print axioms GoldC.QuillonCopyG.gcd_pair_sum_le
