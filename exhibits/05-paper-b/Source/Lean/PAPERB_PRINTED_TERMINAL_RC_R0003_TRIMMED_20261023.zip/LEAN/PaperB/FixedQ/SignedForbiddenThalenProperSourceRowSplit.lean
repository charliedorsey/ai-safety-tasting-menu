import PaperB.FixedQ.SignedForbiddenThalenFiniteDensityCorrection

open scoped BigOperators

namespace PaperB.FixedQ

/-- The literal source proper Boolean discrepancy, separated without
replacing the source row mass by admissibleInteriorCount.  The proper
partition range and the source's original oriented moduli are untouched. -/
theorem thalen_ordinaryBooleanInteriorDiscrepancy_eq_direct_sub_actualDensity
    (lambda : ℕ → ℝ) (H : ℕ) (S : Finset ℕ) :
    ordinaryBooleanInteriorDiscrepancy lambda H S =
      (∑ A ∈ ((S.powerset.erase S).erase ∅),
        rowConstrainedMass lambda H
          (primeSetProduct A) (primeSetProduct (S \ A))) -
      rowWeightMass lambda H *
        (∑ A ∈ ((S.powerset.erase S).erase ∅),
          1 / ((primeSetProduct A : ℝ) * (primeSetProduct (S \ A) : ℝ))) := by
  unfold ordinaryBooleanInteriorDiscrepancy
    fixedProductPartitionDiscrepancy rowDiscrepancy
  rw [Finset.mul_sum, ← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro A hA
  ring

#print axioms thalen_ordinaryBooleanInteriorDiscrepancy_eq_direct_sub_actualDensity

end PaperB.FixedQ
