import PaperB.Analytic.FixedBetaActualTerms

open scoped BigOperators

namespace PaperB.Analytic

open Real Finset Nat

noncomputable def fixedBetaModelConst (k : ℕ) : ℝ :=
  fixedBetaUpperConst k ^ fixedBetaA k +
    fixedBetaLowerConst k ^ (-(fixedBetaA k))

lemma fixedBetaModelConst_pos (k : ℕ) :
    0 < fixedBetaModelConst k := by
  unfold fixedBetaModelConst
  have hu : 0 < fixedBetaUpperConst k ^ fixedBetaA k :=
    Real.rpow_pos_of_pos (fixedBetaUpperConst_pos k) _
  have hl : 0 < fixedBetaLowerConst k ^ (-(fixedBetaA k)) :=
    Real.rpow_pos_of_pos (fixedBetaLowerConst_pos k) _
  positivity

noncomputable def fixedBetaModelEnvelope (K : ℕ) : ℝ :=
  1 + ∑ k ∈ Finset.Icc 2 K, fixedBetaModelConst k

lemma fixedBetaModelEnvelope_ge_one (K : ℕ) :
    1 ≤ fixedBetaModelEnvelope K := by
  unfold fixedBetaModelEnvelope
  have hsum : 0 ≤ ∑ k ∈ Finset.Icc 2 K, fixedBetaModelConst k :=
    Finset.sum_nonneg (fun k hk => (fixedBetaModelConst_pos k).le)
  linarith

lemma fixedBetaModelConst_le_envelope
    {k K : ℕ} (hk : 2 ≤ k) (hkK : k ≤ K) :
    fixedBetaModelConst k ≤ fixedBetaModelEnvelope K := by
  unfold fixedBetaModelEnvelope
  have hmem : k ∈ Finset.Icc 2 K := Finset.mem_Icc.mpr ⟨hk, hkK⟩
  have hrest :
      0 ≤ ∑ j ∈ (Finset.Icc 2 K).erase k, fixedBetaModelConst j :=
    Finset.sum_nonneg (fun j hj => (fixedBetaModelConst_pos j).le)
  rw [← Finset.sum_erase_add _ _ hmem]
  linarith

#print axioms fixedBetaModelConst_pos
#print axioms fixedBetaModelEnvelope_ge_one
#print axioms fixedBetaModelConst_le_envelope

end PaperB.Analytic
