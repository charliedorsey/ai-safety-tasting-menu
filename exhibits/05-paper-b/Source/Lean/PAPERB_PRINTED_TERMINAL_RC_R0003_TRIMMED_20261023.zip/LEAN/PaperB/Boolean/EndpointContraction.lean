import Mathlib.Algebra.BigOperators.Group.Finset.Powerset
import Mathlib.Algebra.BigOperators.Pi
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Data.Finset.SDiff
import Mathlib.Tactic.Abel

/-!
# Paper B: endpoint Boolean contraction

Frozen paper source:
* `manuscript/paper_b_frozen.tex`
* SHA-256: `9004c20d63218b529ea392d13914c17a347c485fd43814eb88bf8612a8512070`
* labels: `prop:endpoint-contraction`, `eq:commuting-identity`

Mathematical role: exact finite Boolean incidence algebra only.
This file intentionally contains no singular-series, CRT, arithmetic, or asymptotic definitions.
-/

open scoped BigOperators

namespace PaperB
namespace Boolean

variable {ι A : Type*}

/-- Boolean Möbius transform on the interval below `s`.

The exponent is written as `card (s \ t)` because this is convenient for the
finite-set recursion. `mobius_eq_paper_formula` below proves that on the
powerset summation range this is exactly the frozen paper exponent
`|s| - |t|`.
-/
def mobius [DecidableEq ι] [AddCommGroup A]
    (f : Finset ι → A) (s : Finset ι) : A :=
  ∑ t ∈ s.powerset, ((-1 : ℤ) ^ (s \ t).card) • f t

/-- The implementation of `mobius` is literally the frozen paper formula
`∑_{t ⊆ s} (-1)^(|s|-|t|) f(t)` after the finite-cardinality identity
`|s \ t| = |s| - |t|` on `t ⊆ s`.
-/
theorem mobius_eq_paper_formula [DecidableEq ι] [AddCommGroup A]
    (f : Finset ι → A) (s : Finset ι) :
    mobius f s =
      ∑ t ∈ s.powerset, ((-1 : ℤ) ^ (s.card - t.card)) • f t := by
  apply Finset.sum_congr rfl
  intro t ht
  have hts : t ⊆ s := Finset.mem_powerset.mp ht
  rw [Finset.card_sdiff_of_subset hts]

/-- Möbius transform as an operator on Boolean-fiber functions. -/
def mobiusOp [DecidableEq ι] [AddCommGroup A]
    (f : Finset ι → A) : Finset ι → A :=
  fun s => mobius f s

/-- Evaluation of a function-valued Boolean Möbius transform is pointwise. -/
theorem mobius_apply [DecidableEq ι] [AddCommGroup A]
    {X : Type*} (f : Finset ι → X → A) (s : Finset ι) (x : X) :
    mobius f s x = mobius (fun t => f t x) s := by
  simp [mobius, Finset.sum_apply]

/-- Zeta contraction to the top of a finite Boolean fiber. -/
def zetaTop [Fintype ι] [DecidableEq ι] [AddCommMonoid A]
    (f : Finset ι → A) : A :=
  ∑ s ∈ (Finset.univ : Finset ι).powerset, f s

private theorem mobius_insert [DecidableEq ι] [AddCommGroup A]
    (f : Finset ι → A) (a : ι) (s : Finset ι) (ha : a ∉ s) :
    mobius f (insert a s) =
      mobius (fun t => f (insert a t) - f t) s := by
  rw [mobius, Finset.sum_powerset_insert ha, mobius]
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro t ht
  have ht_sub : t ⊆ s := Finset.mem_powerset.mp ht
  have hat : a ∉ t := fun h => ha (ht_sub h)
  have ha_diff : a ∉ s \ t := fun h => ha (Finset.sdiff_subset h)
  have hleft : insert a s \ t = insert a (s \ t) :=
    Finset.insert_sdiff_of_notMem s hat
  have hright : insert a s \ insert a t = s \ t := by
    rw [Finset.insert_sdiff_insert, Finset.sdiff_insert_of_notMem ha]
  rw [hleft, Finset.card_insert_of_notMem ha_diff, hright, pow_succ]
  simp only [mul_neg, mul_one, neg_zsmul, zsmul_sub]
  abel

/-- Finite Boolean zeta followed by Möbius, evaluated at an arbitrary top `s`. -/
theorem zeta_mobius_on [DecidableEq ι] [AddCommGroup A]
    (f : Finset ι → A) (s : Finset ι) :
    ∑ t ∈ s.powerset, mobius f t = f s := by
  induction s using Finset.induction_on generalizing f with
  | empty => simp [mobius]
  | @insert a s ha ih =>
      rw [Finset.sum_powerset_insert ha]
      rw [ih f]
      have hsecond :
          (∑ t ∈ s.powerset, mobius f (insert a t)) = f (insert a s) - f s := by
        calc
          (∑ t ∈ s.powerset, mobius f (insert a t)) =
              ∑ t ∈ s.powerset, mobius (fun u => f (insert a u) - f u) t := by
                apply Finset.sum_congr rfl
                intro t ht
                have ht_sub : t ⊆ s := Finset.mem_powerset.mp ht
                exact mobius_insert f a t (fun hat => ha (ht_sub hat))
          _ = f (insert a s) - f s := ih (fun u => f (insert a u) - f u)
      rw [hsecond]
      abel

/-- Global Boolean zeta–Möbius identity at the full finite endpoint fiber. -/
theorem zeta_mobius [Fintype ι] [DecidableEq ι] [AddCommGroup A]
    (f : Finset ι → A) :
    zetaTop (mobiusOp f) = f Finset.univ := by
  simpa [zetaTop, mobiusOp] using zeta_mobius_on f (Finset.univ : Finset ι)

end Boolean

section EndpointContraction

variable {E T A : Type*}
variable [Fintype E] [DecidableEq E]
variable [Fintype T] [DecidableEq T]
variable [AddCommGroup A]

/-- Free-fiber Möbius transform `M_T`.

It is polymorphic in its codomain. In the left side of the paper identity the
codomain is the endpoint-fiber function space `Finset E → A`; after `ev_E` it
is simply `A`. This makes the same Lean operator represent both typed uses of
paper notation `M_T`.
-/
def mobiusT {X : Type*} [AddCommGroup X]
    (f : Finset T → X) : Finset T → X :=
  Boolean.mobiusOp f

/-- Endpoint-fiber Möbius transform `M_E`, acting pointwise in the free fiber. -/
def mobiusE (f : Finset T → Finset E → A) : Finset T → Finset E → A :=
  fun t => Boolean.mobiusOp (f t)

/-- Endpoint zeta/contraction `Z_E`, acting pointwise in the free fiber. -/
def zetaE (g : Finset T → Finset E → A) : Finset T → A :=
  fun t => Boolean.zetaTop (g t)

/-- Evaluation at the full endpoint set, `ev_E`. -/
def evE (f : Finset T → Finset E → A) : Finset T → A :=
  fun t => f t Finset.univ

/-- Pointwise form of the frozen endpoint-contraction identity.

For every free Boolean choice `t`, this states
`(Z_E M_E M_T f)(t) = (M_T ev_E f)(t)`.
-/
theorem endpointContractionPointwise
    (f : Finset T → Finset E → A) (t : Finset T) :
    zetaE (mobiusE (mobiusT f)) t = mobiusT (evE f) t := by
  calc
    zetaE (mobiusE (mobiusT f)) t = (mobiusT f t) Finset.univ := by
      exact Boolean.zeta_mobius (mobiusT f t)
    _ = mobiusT (evE f) t := by
      change Boolean.mobius f t (Finset.univ : Finset E) =
        Boolean.mobius (fun u => f u (Finset.univ : Finset E)) t
      exact Boolean.mobius_apply f t (Finset.univ : Finset E)

/-- Operator-form correspondence with the frozen paper display
`Z_E M_E M_T = M_T ev_E`.

This is an equality of the resulting functions on the free Boolean fiber.
-/
theorem endpointContraction
    (f : Finset T → Finset E → A) :
    zetaE (mobiusE (mobiusT f)) = mobiusT (evE f) := by
  funext t
  exact endpointContractionPointwise f t

end EndpointContraction
end PaperB
