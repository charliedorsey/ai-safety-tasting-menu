import GoldC.QuillonWFinal
import GoldC.QuillonCEst

/-!
# Quillon CSC3 F8.8: parameters and eventual bounds for the region-C cell (Parseval-W + VW + Rankin)

**Parameters**, with `Λ = log h` and `ε = Λ^{−1/200}`:
* `Tp = ⌈Λ^{100}⌉`;
* `Lw_C(s) = ⌊s^{1+ε}⌋ − 1`;
* `Uv = Vv = ⌊s^{1/16}⌋`;
* `Tv = X³`;
* Rankin exponent `σ_R = Λ^{−1/10}`.

**Lemmas.**
* `edecay`: `s^{−ε} ≤ Λ^{−K}` eventually, uniformly in `log s ≥ 5Λ^σ`.
* `Pα_le` and `Pβ_le`: the Parseval-W majorants are `≤ C·Λ^{−45}`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonCEv

open GoldC.QuillonEv GoldC.QuillonSetup GoldC.QuillonLam GoldC.QuillonCEst

noncomputable def εp (h : ℕ) : ℝ := (Real.log h) ^ (-(1 / 200 : ℝ))
noncomputable def Tpp (h : ℕ) : ℕ := ⌈(Real.log h) ^ (100 : ℝ)⌉₊
noncomputable def LwC (h s : ℕ) : ℕ := ⌊(s : ℝ) ^ (1 + εp h)⌋₊ - 1
noncomputable def Uvp (s : ℕ) : ℕ := ⌊(s : ℝ) ^ (1 / 16 : ℝ)⌋₊
noncomputable def Tvp (h : ℕ) : ℕ := Xp h ^ 3
noncomputable def σRk (h : ℕ) : ℝ := (Real.log h) ^ (-(1 / 10 : ℝ))

lemma rp {Λ : ℝ} (hΛ : 0 < Λ) (a b : ℝ) : Λ ^ a * Λ ^ b = Λ ^ (a + b) := (Real.rpow_add hΛ a b).symm

lemma sqrt_le_of {x y : ℝ} (hy : 0 ≤ y) (h : x ≤ y ^ 2) : Real.sqrt x ≤ y :=
  Real.sqrt_le_iff.2 ⟨hy, h⟩

/-- `s^{−ε} ≤ Λ^{−K}` eventually (`ε = Λ^{−1/200}`, `log s ≥ 5Λ^σ`). -/
theorem edecay (K : ℝ) (hK : 0 ≤ K) :
    ∃ Λ₀ : ℝ, 1 ≤ Λ₀ ∧ ∀ Λ : ℝ, Λ₀ ≤ Λ → ∀ x : ℝ, 0 < x → 5 * Λ ^ σ₀ ≤ Real.log x →
      x ^ (-(Λ ^ (-(1 / 200 : ℝ)))) ≤ Λ ^ (-K) := by
  have hτ : 0 < σ₀ - 1 / 200 := by unfold σ₀; norm_num
  obtain ⟨Λ₀, hΛ₀, h⟩ := decay 0 K 5 (σ₀ - 1 / 200) (by linarith) (by norm_num) hτ
  refine ⟨Λ₀, hΛ₀, fun Λ hΛ x hx hlog => ?_⟩
  have hΛ0 : 0 < Λ := by linarith
  have h1 := h Λ hΛ
  rw [Real.rpow_zero, one_mul] at h1
  have he : Λ ^ (-(1 / 200 : ℝ)) * (5 * Λ ^ σ₀) = 5 * Λ ^ (σ₀ - 1 / 200) := by
    rw [mul_left_comm, rp hΛ0]; ring_nf
  have hpos : 0 ≤ Λ ^ (-(1 / 200 : ℝ)) := by positivity
  calc x ^ (-(Λ ^ (-(1 / 200 : ℝ)))) = Real.exp (-(Λ ^ (-(1 / 200 : ℝ))) * Real.log x) := by
        rw [Real.rpow_def_of_pos hx]; ring_nf
    _ ≤ Real.exp (-(5 * Λ ^ (σ₀ - 1 / 200))) := by
        apply Real.exp_le_exp.2
        rw [← he]; nlinarith [mul_le_mul_of_nonneg_left hlog hpos]
    _ ≤ Λ ^ (-K) := h1

/-- The real core of the `Pα` bound. -/
lemma Pα_real (Λ Aw L S1 S2 S3 : ℝ) (hΛ : 1 ≤ Λ) (hAw0 : 0 ≤ Aw) (hAw : Aw ≤ Λ) (hL0 : 0 ≤ L)
    (hL : L ≤ 4 * Λ) (hS10 : 0 ≤ S1) (hS1 : S1 ≤ 4 * Λ ^ (51 : ℝ)) (hS20 : 0 ≤ S2)
    (hS2 : S2 ≤ 3 * Λ ^ (-(100 : ℝ))) (hS30 : 0 ≤ S3) (hS3 : S3 ≤ 9 * Λ ^ (-(100 : ℝ))) :
    4 * Aw * (Real.sqrt 2 * L ^ 3 * S1 * S2 + L ^ 5 * S3) ≤ 41472 * Λ ^ (-(45 : ℝ)) := by
  have hΛ0 : 0 < Λ := by linarith
  have hs2 : Real.sqrt 2 ≤ 1.5 := sqrt_le_of (by norm_num) (by norm_num)
  have hL3 : L ^ 3 ≤ 64 * Λ ^ (3 : ℝ) := by
    calc L ^ 3 ≤ (4 * Λ) ^ 3 := pow_le_pow_left₀ hL0 hL 3
      _ = 64 * Λ ^ (3 : ℝ) := by rw [mul_pow, ← Real.rpow_natCast]; norm_num
  have hL5 : L ^ 5 ≤ 1024 * Λ ^ (5 : ℝ) := by
    calc L ^ 5 ≤ (4 * Λ) ^ 5 := pow_le_pow_left₀ hL0 hL 5
      _ = 1024 * Λ ^ (5 : ℝ) := by rw [mul_pow, ← Real.rpow_natCast]; norm_num
  have t1 : Real.sqrt 2 * L ^ 3 * S1 * S2 ≤ 1152 * Λ ^ (-(46 : ℝ)) := by
    calc Real.sqrt 2 * L ^ 3 * S1 * S2 ≤ 1.5 * (64 * Λ ^ (3 : ℝ)) * (4 * Λ ^ (51 : ℝ)) * (3 * Λ ^ (-(100 : ℝ))) := by
          gcongr
      _ = 1152 * (Λ ^ (3 : ℝ) * Λ ^ (51 : ℝ) * Λ ^ (-(100 : ℝ))) := by ring
      _ = 1152 * Λ ^ (-(46 : ℝ)) := by rw [rp hΛ0, rp hΛ0]; norm_num
  have t2 : L ^ 5 * S3 ≤ 9216 * Λ ^ (-(46 : ℝ)) := by
    calc L ^ 5 * S3 ≤ (1024 * Λ ^ (5 : ℝ)) * (9 * Λ ^ (-(100 : ℝ))) := by gcongr
      _ = 9216 * (Λ ^ (5 : ℝ) * Λ ^ (-(100 : ℝ))) := by ring
      _ = 9216 * Λ ^ (-(95 : ℝ)) := by rw [rp hΛ0]; norm_num
      _ ≤ 9216 * Λ ^ (-(46 : ℝ)) := mul_le_mul_of_nonneg_left
          (Real.rpow_le_rpow_of_exponent_le hΛ (by norm_num : (-(95 : ℝ)) ≤ -(46 : ℝ))) (by norm_num)
  have hin0 : 0 ≤ Real.sqrt 2 * L ^ 3 * S1 * S2 + L ^ 5 * S3 := by positivity
  calc 4 * Aw * (Real.sqrt 2 * L ^ 3 * S1 * S2 + L ^ 5 * S3) ≤ 4 * Λ * (10368 * Λ ^ (-(46 : ℝ))) := by
        apply mul_le_mul (by linarith) (by linarith) hin0 (by positivity)
    _ = 41472 * (Λ ^ (1 : ℝ) * Λ ^ (-(46 : ℝ))) := by rw [Real.rpow_one]; ring
    _ = 41472 * Λ ^ (-(45 : ℝ)) := by rw [rp hΛ0]; norm_num


/-! ### Small-quantity calculus

`τ := (1 + log s)²·s^{−c₀}` with `c₀ ≤ 1/32`. Every fixed-power decay used below is `≤ C·τ`. -/

lemma rpow_le_tau {s c₀ e : ℝ} (hs : 1 ≤ s) (he : c₀ ≤ e) : s ^ (-e) ≤ s ^ (-c₀) :=
  Real.rpow_le_rpow_of_exponent_le hs (by linarith)

lemma t_le_tau {s c₀ : ℝ} (hs : 1 ≤ s) :
    s ^ (-c₀) ≤ (1 + Real.log s) ^ 2 * s ^ (-c₀) := by
  have h1 : 1 ≤ (1 + Real.log s) ^ 2 := one_le_pow₀ (by have := Real.log_nonneg hs; linarith)
  have h2 : 0 ≤ s ^ (-c₀) := by positivity
  nlinarith

lemma lt_le_tau {s c₀ : ℝ} (hs : 1 ≤ s) :
    (1 + Real.log s) * s ^ (-c₀) ≤ (1 + Real.log s) ^ 2 * s ^ (-c₀) := by
  have h0 : 1 ≤ 1 + Real.log s := by have := Real.log_nonneg hs; linarith
  have h2 : 0 ≤ s ^ (-c₀) := by positivity
  have : (1 + Real.log s) ≤ (1 + Real.log s) ^ 2 := by nlinarith
  exact mul_le_mul_of_nonneg_right this h2

/-- `v₁ = 4X·log b·Uv²/b ≤ 32Λ^{201}·τ`. -/
lemma v1_le (Λ s b Xr Uv lb : ℝ) (c₀ : ℝ) (hΛ : 1 ≤ Λ) (hc₀ : c₀ ≤ 1 / 32) (hs : 1 ≤ s)
    (hX0 : 0 ≤ Xr) (hX : Xr ≤ 2 * Λ ^ (200 : ℝ)) (hb : s / 2 ≤ b) (hlb0 : 0 ≤ lb) (hlb : lb ≤ 2 * Λ)
    (hUv0 : 0 ≤ Uv) (hUv : Uv ≤ s ^ (1 / 16 : ℝ)) :
    4 * Xr * lb * (Uv * Uv) / b ≤ 32 * Λ ^ (201 : ℝ) * ((1 + Real.log s) ^ 2 * s ^ (-c₀)) := by
  have hs0 : 0 < s := by linarith
  have hb0 : 0 < b := by linarith
  have hΛ0 : 0 < Λ := by linarith
  have hU2 : Uv * Uv ≤ s ^ (1 / 8 : ℝ) := by
    calc Uv * Uv ≤ s ^ (1 / 16 : ℝ) * s ^ (1 / 16 : ℝ) := mul_le_mul hUv hUv hUv0 (by positivity)
      _ = s ^ (1 / 8 : ℝ) := by rw [rp hs0]; norm_num
  have hkey : s ^ (1 / 8 : ℝ) / b ≤ 2 * s ^ (-(7 / 8 : ℝ)) := by
    rw [div_le_iff₀ hb0]
    have e : s ^ (1 / 8 : ℝ) = s ^ (-(7 / 8 : ℝ)) * s := by
      rw [show s ^ (-(7 / 8 : ℝ)) * s = s ^ (-(7 / 8 : ℝ)) * s ^ (1 : ℝ) by rw [Real.rpow_one], rp hs0]
      norm_num
    rw [e]
    have : 0 ≤ s ^ (-(7 / 8 : ℝ)) := by positivity
    nlinarith
  have h78 : s ^ (-(7 / 8 : ℝ)) ≤ (1 + Real.log s) ^ 2 * s ^ (-c₀) :=
    le_trans (rpow_le_tau hs (by linarith)) (t_le_tau hs)
  calc 4 * Xr * lb * (Uv * Uv) / b = 4 * Xr * lb * ((Uv * Uv) / b) := by ring
    _ ≤ 4 * (2 * Λ ^ (200 : ℝ)) * (2 * Λ) * (s ^ (1 / 8 : ℝ) / b) := by
        gcongr
    _ ≤ 4 * (2 * Λ ^ (200 : ℝ)) * (2 * Λ) * (2 * ((1 + Real.log s) ^ 2 * s ^ (-c₀))) := by
        gcongr; linarith
    _ = 32 * (Λ ^ (200 : ℝ) * Λ ^ (1 : ℝ)) * ((1 + Real.log s) ^ 2 * s ^ (-c₀)) := by
        rw [Real.rpow_one]; ring
    _ = 32 * Λ ^ (201 : ℝ) * ((1 + Real.log s) ^ 2 * s ^ (-c₀)) := by rw [rp hΛ0]; norm_num


/-- facts about `Uv = ⌊s^{1/16}⌋`. -/
lemma uv_facts (s b c₀ : ℝ) (Uv : ℕ) (hc₀ : c₀ ≤ 1 / 32) (hs : 65536 ≤ s) (hb : s / 2 ≤ b)
    (hUv : Uv = ⌊s ^ (1 / 16 : ℝ)⌋₊) :
    1 ≤ (Uv : ℝ) ∧ (Uv : ℝ) ≤ s ^ (1 / 16 : ℝ) ∧
      2 * (Uv : ℝ) / b ≤ 4 * ((1 + Real.log s) ^ 2 * s ^ (-c₀)) ∧
      4 / ((Uv : ℝ) + 1) ≤ 4 * ((1 + Real.log s) ^ 2 * s ^ (-c₀)) ∧
      2 / (Uv : ℝ) ≤ 4 * ((1 + Real.log s) ^ 2 * s ^ (-c₀)) := by
  have hs1 : 1 ≤ s := by linarith
  have hs0 : 0 < s := by linarith
  have hb0 : 0 < b := by linarith
  set y := s ^ (1 / 16 : ℝ) with hy
  have hy2 : 2 ≤ y := by
    calc (2 : ℝ) = (65536 : ℝ) ^ (1 / 16 : ℝ) := by
          rw [show (65536 : ℝ) = 2 ^ (16 : ℝ) by norm_num, ← Real.rpow_mul (by norm_num)]; norm_num
      _ ≤ y := Real.rpow_le_rpow (by norm_num) hs (by norm_num)
  have hfl := Nat.floor_le (show 0 ≤ y by linarith)
  have hfl2 := Nat.lt_floor_add_one y
  rw [← hUv] at hfl hfl2
  have hU1 : (1 : ℝ) ≤ Uv := by
    have : 1 ≤ Uv := by rw [hUv]; exact Nat.le_floor (by push_cast; linarith)
    exact_mod_cast this
  have hUy : y / 2 ≤ (Uv : ℝ) := by linarith
  have hτ : y⁻¹ ≤ (1 + Real.log s) ^ 2 * s ^ (-c₀) := by
    have : y⁻¹ = s ^ (-(1 / 16 : ℝ)) := by rw [hy, Real.rpow_neg hs0.le]
    rw [this]; exact le_trans (rpow_le_tau hs1 (by linarith)) (t_le_tau hs1)
  have hy0 : 0 < y := by linarith
  refine ⟨hU1, hfl, ?_, ?_, ?_⟩
  · -- `2Uv/b ≤ 4y/s ≤ 4/y`
    have h1 : 2 * (Uv : ℝ) / b ≤ 4 * y / s := by
      rw [div_le_div_iff₀ hb0 hs0]; nlinarith
    have h2 : 4 * y / s ≤ 4 * y⁻¹ := by
      have hys : y * y ≤ s := by
        calc y * y ≤ s ^ (1 / 2 : ℝ) := by
              rw [hy, rp hs0]; exact Real.rpow_le_rpow_of_exponent_le hs1 (by norm_num)
          _ ≤ s := by
              calc s ^ (1 / 2 : ℝ) ≤ s ^ (1 : ℝ) := Real.rpow_le_rpow_of_exponent_le hs1 (by norm_num)
                _ = s := Real.rpow_one s
      rw [div_le_iff₀ hs0]
      have : y⁻¹ * y = 1 := inv_mul_cancel₀ hy0.ne'
      nlinarith [inv_pos.2 hy0]
    linarith
  · have h1 : 4 / ((Uv : ℝ) + 1) ≤ 4 * y⁻¹ := by
      rw [div_le_iff₀ (by linarith)]
      have : y⁻¹ * y = 1 := inv_mul_cancel₀ hy0.ne'
      nlinarith [inv_pos.2 hy0]
    linarith
  · have h1 : 2 / (Uv : ℝ) ≤ 4 * y⁻¹ := by
      rw [div_le_iff₀ (by linarith)]
      have : y⁻¹ * y = 1 := inv_mul_cancel₀ hy0.ne'
      nlinarith [inv_pos.2 hy0]
    linarith

/-- The real core of the second `Vα` term. -/
lemma v2_real (Λ Xr Mr L S1 S2 S3 : ℝ) (hΛ : 1 ≤ Λ) (hX0 : 0 ≤ Xr) (hX : Xr ≤ 2 * Λ ^ (200 : ℝ))
    (hM0 : 0 ≤ Mr) (hM : Mr ≤ Λ) (hL0 : 0 ≤ L) (hL : L ≤ 4 * Λ) (hS10 : 0 ≤ S1)
    (hS1 : S1 ≤ 7 * Λ ^ (301 : ℝ)) (hS20 : 0 ≤ S2) (hS2 : S2 ≤ 3 * Λ ^ (-(1500 : ℝ)))
    (hS30 : 0 ≤ S3) (hS3 : S3 ≤ 14 * Λ ^ (-(600 : ℝ))) :
    2 * Xr * Mr * (Real.sqrt 2 * L ^ 3 * S1 * S2 + L ^ 5 * S3) ≤ 70000 * Λ ^ (-(394 : ℝ)) := by
  have hΛ0 : 0 < Λ := by linarith
  have hs2 : Real.sqrt 2 ≤ 1.5 := sqrt_le_of (by norm_num) (by norm_num)
  have hL3 : L ^ 3 ≤ 64 * Λ ^ (3 : ℝ) := by
    calc L ^ 3 ≤ (4 * Λ) ^ 3 := pow_le_pow_left₀ hL0 hL 3
      _ = 64 * Λ ^ (3 : ℝ) := by rw [mul_pow, ← Real.rpow_natCast]; norm_num
  have hL5 : L ^ 5 ≤ 1024 * Λ ^ (5 : ℝ) := by
    calc L ^ 5 ≤ (4 * Λ) ^ 5 := pow_le_pow_left₀ hL0 hL 5
      _ = 1024 * Λ ^ (5 : ℝ) := by rw [mul_pow, ← Real.rpow_natCast]; norm_num
  have t1 : Real.sqrt 2 * L ^ 3 * S1 * S2 ≤ 2016 * Λ ^ (-(595 : ℝ)) := by
    calc Real.sqrt 2 * L ^ 3 * S1 * S2 ≤ 1.5 * (64 * Λ ^ (3 : ℝ)) * (7 * Λ ^ (301 : ℝ)) *
          (3 * Λ ^ (-(1500 : ℝ))) := by gcongr
      _ = 2016 * (Λ ^ (3 : ℝ) * Λ ^ (301 : ℝ) * Λ ^ (-(1500 : ℝ))) := by ring
      _ = 2016 * Λ ^ (-(1196 : ℝ)) := by rw [rp hΛ0, rp hΛ0]; norm_num
      _ ≤ 2016 * Λ ^ (-(595 : ℝ)) := mul_le_mul_of_nonneg_left
          (Real.rpow_le_rpow_of_exponent_le hΛ (by norm_num : (-(1196 : ℝ)) ≤ -(595 : ℝ))) (by norm_num)
  have t2 : L ^ 5 * S3 ≤ 14336 * Λ ^ (-(595 : ℝ)) := by
    calc L ^ 5 * S3 ≤ (1024 * Λ ^ (5 : ℝ)) * (14 * Λ ^ (-(600 : ℝ))) := by gcongr
      _ = 14336 * (Λ ^ (5 : ℝ) * Λ ^ (-(600 : ℝ))) := by ring
      _ = 14336 * Λ ^ (-(595 : ℝ)) := by rw [rp hΛ0]; norm_num
  have hin0 : 0 ≤ Real.sqrt 2 * L ^ 3 * S1 * S2 + L ^ 5 * S3 := by positivity
  calc 2 * Xr * Mr * (Real.sqrt 2 * L ^ 3 * S1 * S2 + L ^ 5 * S3)
      ≤ 2 * (2 * Λ ^ (200 : ℝ)) * Λ * (16352 * Λ ^ (-(595 : ℝ))) := by
        apply mul_le_mul _ (by linarith) hin0 (by positivity)
        exact mul_le_mul (by linarith) hM hM0 (by positivity)
    _ = 65408 * (Λ ^ (200 : ℝ) * Λ ^ (1 : ℝ) * Λ ^ (-(595 : ℝ))) := by rw [Real.rpow_one]; ring
    _ = 65408 * Λ ^ (-(394 : ℝ)) := by rw [rp hΛ0, rp hΛ0]; norm_num
    _ ≤ 70000 * Λ ^ (-(394 : ℝ)) := by
        have : 0 ≤ Λ ^ (-(394 : ℝ)) := by positivity
        nlinarith


lemma L3b_le (Λ : ℝ) (hΛ : 2 ≤ Λ) (b : ℕ) (hb : 1 ≤ b) (hbh : Real.log b ≤ 2 * Λ) :
    0 ≤ 1 + Real.log (3 * b) ∧ 1 + Real.log (3 * b) ≤ 4 * Λ := by
  have hb1 : (1 : ℝ) ≤ b := by exact_mod_cast hb
  rw [Real.log_mul (by norm_num) (by positivity)]
  have h3 : Real.log 3 ≤ 2 := by
    have := Real.log_le_sub_one_of_pos (show (0 : ℝ) < 3 by norm_num); linarith
  have h3' : 0 ≤ Real.log 3 := Real.log_nonneg (by norm_num)
  have := Real.log_nonneg hb1
  constructor <;> linarith

set_option maxHeartbeats 1000000 in
/-- **`Vα ≤ Λ^{−60}`** on an admissible region-C piece. -/
theorem Vα_le (Λ : ℝ) (hΛ : 2 ≤ Λ) (hΛK : 200000 ≤ Λ) (s X Lw b Uv Tv Ec M : ℕ) (c₀ : ℝ) (hc₀ : c₀ ≤ 1 / 32)
    (hsR : 65536 ≤ (s : ℝ)) (hτ : (1 + Real.log s) ^ 2 * (s : ℝ) ^ (-c₀) ≤ Λ ^ (-(3000 : ℝ)))
    (hsb : (s : ℝ) / b ≤ Λ ^ (-(3000 : ℝ)))
    (hX0 : 1 ≤ X) (hX : (X : ℝ) ≤ 2 * Λ ^ (200 : ℝ)) (hb : (s : ℝ) / 2 ≤ b) (hb1 : 1 ≤ b)
    (hbh : Real.log b ≤ 2 * Λ) (hUv : Uv = ⌊(s : ℝ) ^ (1 / 16 : ℝ)⌋₊) (hTv1 : Λ ^ (600 : ℝ) ≤ Tv)
    (hTv : (Tv : ℝ) ≤ 8 * Λ ^ (600 : ℝ)) (hEc : (Ec : ℝ) ≤ Λ ^ 2)
    (hLwX : (s : ℝ) / (8 * Λ ^ (200 : ℝ)) ≤ ((Lw / X : ℕ) : ℝ)) (hM1 : 1 ≤ M) (hM : (M : ℝ) ≤ Λ)
    (hlb : (Nat.log 2 b : ℝ) + 1 ≤ 5 * Λ) :
    Vα s X Lw b Uv Uv Tv Ec M ≤ Λ ^ (-(60 : ℝ)) := by
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  have hs1 : (1 : ℝ) ≤ s := by linarith
  have hs0 : (0 : ℝ) < s := by linarith
  have hb0 : (0 : ℝ) < b := by exact_mod_cast hb1
  set τ := (1 + Real.log (s : ℝ)) ^ 2 * (s : ℝ) ^ (-c₀) with hτdef
  have hτ0 : 0 ≤ τ := by
    have : 0 ≤ (s : ℝ) ^ (-c₀) := by positivity
    positivity
  obtain ⟨hU1, hUs, hU2b, hU4, hU2⟩ := uv_facts (s : ℝ) b c₀ Uv hc₀ hsR hb hUv
  obtain ⟨hL0, hL⟩ := L3b_le Λ hΛ b hb1 hbh
  have hp3000 : 0 ≤ Λ ^ (-(3000 : ℝ)) := by positivity
  have hlogb0 : 0 ≤ Real.log b := Real.log_nonneg (by exact_mod_cast hb1)
  have hX0R : (0 : ℝ) ≤ X := by positivity
  -- small facts in `Λ`
  have hmono : ∀ a : ℝ, a ≤ -394 → Λ ^ a ≤ Λ ^ (-(394 : ℝ)) := fun a ha =>
    Real.rpow_le_rpow_of_exponent_le hΛ1 (by linarith)
  -- v1
  have v1 : 4 * (X : ℝ) * Real.log b * ((Uv * Uv : ℕ) : ℝ) / b ≤ 32 * Λ ^ (-(394 : ℝ)) := by
    have h := v1_le Λ s b X Uv (Real.log b) c₀ hΛ1 hc₀ hs1 hX0R hX hb hlogb0 hbh (by positivity) hUs
    push_cast
    calc 4 * (X : ℝ) * Real.log b * ((Uv : ℝ) * Uv) / b ≤ 32 * Λ ^ (201 : ℝ) * τ := h
      _ ≤ 32 * Λ ^ (201 : ℝ) * Λ ^ (-(3000 : ℝ)) := by gcongr
      _ = 32 * Λ ^ (-(2799 : ℝ)) := by rw [mul_assoc, rp hΛ0]; norm_num
      _ ≤ 32 * Λ ^ (-(394 : ℝ)) :=
          mul_le_mul_of_nonneg_left (hmono (-(2799 : ℝ)) (by norm_num)) (by norm_num)
  -- v2
  have S1 : Real.sqrt ((Tv : ℝ) * (Nat.log 2 b + 1)) ≤ 7 * Λ ^ (301 : ℝ) := by
    apply sqrt_le_of (by positivity)
    calc (Tv : ℝ) * (Nat.log 2 b + 1) ≤ (8 * Λ ^ (600 : ℝ)) * (5 * Λ) := by
          apply mul_le_mul hTv hlb (by positivity) (by positivity)
      _ = 40 * (Λ ^ (600 : ℝ) * Λ ^ (1 : ℝ)) := by rw [Real.rpow_one]; ring
      _ = 40 * Λ ^ (601 : ℝ) := by rw [rp hΛ0]; norm_num
      _ ≤ 49 * Λ ^ (602 : ℝ) := by
          have : Λ ^ (601 : ℝ) ≤ Λ ^ (602 : ℝ) := Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)
          have : 0 ≤ Λ ^ (601 : ℝ) := by positivity
          nlinarith
      _ = (7 * Λ ^ (301 : ℝ)) ^ 2 := by
          rw [mul_pow, ← Real.rpow_natCast (Λ ^ (301 : ℝ)) 2, ← Real.rpow_mul hΛ0.le]; norm_num
  have S2 : Real.sqrt (2 * (Uv : ℝ) / b + 4 / ((Uv : ℝ) + 1) + s / b) ≤ 3 * Λ ^ (-(1500 : ℝ)) := by
    apply sqrt_le_of (by positivity)
    have e : (3 * Λ ^ (-(1500 : ℝ))) ^ 2 = 9 * Λ ^ (-(3000 : ℝ)) := by
      rw [mul_pow, ← Real.rpow_natCast (Λ ^ (-(1500 : ℝ))) 2, ← Real.rpow_mul hΛ0.le]; norm_num
    rw [e]; linarith
  have S3 : 2 / (Tv : ℝ) + 2 / (Uv : ℝ) + 2 * (Uv : ℝ) / b + 4 / ((Uv : ℝ) + 1) ≤
      14 * Λ ^ (-(600 : ℝ)) := by
    have hTv0 : 0 < (Tv : ℝ) := lt_of_lt_of_le (by positivity) hTv1
    have h1 : 2 / (Tv : ℝ) ≤ 2 * Λ ^ (-(600 : ℝ)) := by
      rw [div_le_iff₀ hTv0]
      have e : Λ ^ (-(600 : ℝ)) * Λ ^ (600 : ℝ) = 1 := by rw [rp hΛ0]; norm_num
      have : 0 ≤ Λ ^ (-(600 : ℝ)) := by positivity
      nlinarith
    have h2 : Λ ^ (-(3000 : ℝ)) ≤ Λ ^ (-(600 : ℝ)) :=
      Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)
    linarith
  have v2 := v2_real Λ X M (1 + Real.log (3 * b)) _ _ _ hΛ1 hX0R hX (by positivity) hM hL0 hL
    (by positivity) S1 (by positivity) S2 (by positivity) S3
  -- v3
  have v3 : 2 * (X : ℝ) * Real.log b * (Nat.log 2 b : ℝ) / Real.sqrt b ≤ 90 * Λ ^ (-(394 : ℝ)) := by
    have hsq : Real.sqrt ((s : ℝ) / 2) ≤ Real.sqrt b := Real.sqrt_le_sqrt hb
    have hsqpos : 0 < Real.sqrt ((s : ℝ) / 2) := Real.sqrt_pos.2 (by positivity)
    have hinv : 1 / Real.sqrt b ≤ 1.5 * τ := by
      have h1 : 1 / Real.sqrt b ≤ 1 / Real.sqrt ((s : ℝ) / 2) :=
        one_div_le_one_div_of_le hsqpos hsq
      have h2 : 1 / Real.sqrt ((s : ℝ) / 2) = Real.sqrt 2 * (s : ℝ) ^ (-(1 / 2 : ℝ)) := by
        rw [Real.sqrt_div' _ (by norm_num : (0:ℝ) ≤ 2), Real.sqrt_eq_rpow, Real.rpow_neg hs0.le]
        field_simp
      have h3 : (s : ℝ) ^ (-(1 / 2 : ℝ)) ≤ τ :=
        le_trans (rpow_le_tau hs1 (by linarith)) (t_le_tau hs1)
      have hs2 : Real.sqrt 2 ≤ 1.5 := sqrt_le_of (by norm_num) (by norm_num)
      have : 0 ≤ (s : ℝ) ^ (-(1 / 2 : ℝ)) := by positivity
      rw [h2] at h1; nlinarith
    have hlb' : (Nat.log 2 b : ℝ) ≤ 5 * Λ := by linarith
    calc 2 * (X : ℝ) * Real.log b * (Nat.log 2 b : ℝ) / Real.sqrt b
        = 2 * (X : ℝ) * Real.log b * (Nat.log 2 b : ℝ) * (1 / Real.sqrt b) := by ring
      _ ≤ 2 * (2 * Λ ^ (200 : ℝ)) * (2 * Λ) * (5 * Λ) * (1.5 * Λ ^ (-(3000 : ℝ))) := by
          gcongr; linarith
      _ = 60 * (Λ ^ (200 : ℝ) * Λ ^ (1 : ℝ) * Λ ^ (1 : ℝ) * Λ ^ (-(3000 : ℝ))) := by
          rw [Real.rpow_one]; ring
      _ = 60 * Λ ^ (-(2798 : ℝ)) := by rw [rp hΛ0, rp hΛ0, rp hΛ0]; norm_num
      _ ≤ 90 * Λ ^ (-(394 : ℝ)) := by
          have := hmono (-(2798 : ℝ)) (by norm_num)
          have : 0 ≤ Λ ^ (-(2798 : ℝ)) := by positivity
          linarith
  -- v4
  have v4 : (6 + 2.5 * (Ec : ℝ)) / ((Lw / X : ℕ) : ℝ) ≤ 100 * Λ ^ (-(394 : ℝ)) := by
    have hd0 : 0 < (s : ℝ) / (8 * Λ ^ (200 : ℝ)) := by positivity
    have hd : 0 < ((Lw / X : ℕ) : ℝ) := lt_of_lt_of_le hd0 hLwX
    have hsinv : (s : ℝ)⁻¹ ≤ Λ ^ (-(3000 : ℝ)) := by
      have : (s : ℝ)⁻¹ = (s : ℝ) ^ (-(1 : ℝ)) := by rw [Real.rpow_neg_one]
      rw [this]; exact le_trans (le_trans (rpow_le_tau hs1 (by linarith)) (t_le_tau hs1)) hτ
    calc (6 + 2.5 * (Ec : ℝ)) / ((Lw / X : ℕ) : ℝ) ≤ (6 + 2.5 * Λ ^ 2) / ((s : ℝ) / (8 * Λ ^ (200 : ℝ))) := by
          apply div_le_div₀ (by positivity) (by linarith) hd0 hLwX
      _ = (6 + 2.5 * Λ ^ 2) * (8 * Λ ^ (200 : ℝ)) * (s : ℝ)⁻¹ := by field_simp
      _ ≤ (8.5 * Λ ^ (2 : ℝ)) * (8 * Λ ^ (200 : ℝ)) * Λ ^ (-(3000 : ℝ)) := by
          gcongr
          rw [← Real.rpow_natCast]; push_cast
          have : (1 : ℝ) ≤ Λ ^ (2 : ℝ) := Real.one_le_rpow hΛ1 (by norm_num)
          linarith
      _ = 68 * (Λ ^ (2 : ℝ) * Λ ^ (200 : ℝ) * Λ ^ (-(3000 : ℝ))) := by ring
      _ = 68 * Λ ^ (-(2798 : ℝ)) := by rw [rp hΛ0, rp hΛ0]; norm_num
      _ ≤ 100 * Λ ^ (-(394 : ℝ)) := by
          have := hmono (-(2798 : ℝ)) (by norm_num)
          have : 0 ≤ Λ ^ (-(2798 : ℝ)) := by positivity
          linarith
  unfold Vα
  have hfin : (32 + 70000 + 90 + 100) * Λ ^ (-(394 : ℝ)) ≤ Λ ^ (-(60 : ℝ)) := by
    have e : Λ ^ (-(60 : ℝ)) = Λ ^ (-(394 : ℝ)) * Λ ^ (334 : ℝ) := by rw [rp hΛ0]; norm_num
    rw [e]
    have h1 : Λ ^ (1 : ℝ) ≤ Λ ^ (334 : ℝ) := Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)
    rw [Real.rpow_one] at h1
    have : 0 ≤ Λ ^ (-(394 : ℝ)) := by positivity
    nlinarith
  linarith


lemma three_quarter_le (n : ℕ) : (3 : ℝ) ^ ((n : ℝ) / 4) * (2 : ℝ) ^ n ≤ (4 : ℝ) ^ n := by
  have h1 : (3 : ℝ) ^ ((n : ℝ) / 4) ≤ (2 : ℝ) ^ n := by
    rw [show ((n : ℝ) / 4) = (1 / 4 : ℝ) * n by ring, Real.rpow_mul (by norm_num), Real.rpow_natCast]
    apply pow_le_pow_left₀ (by positivity)
    rw [show (2 : ℝ) = (16 : ℝ) ^ (1 / 4 : ℝ) by
      rw [show (16 : ℝ) = 2 ^ (4 : ℝ) by norm_num, ← Real.rpow_mul (by norm_num)]; norm_num]
    exact Real.rpow_le_rpow (by norm_num) (by norm_num) (by norm_num)
  calc (3 : ℝ) ^ ((n : ℝ) / 4) * (2 : ℝ) ^ n ≤ (2 : ℝ) ^ n * (2 : ℝ) ^ n := by gcongr
    _ = (4 : ℝ) ^ n := by rw [← mul_pow]; norm_num

set_option maxHeartbeats 1000000 in
/-- **`Vβ·2^{|C|} ≤ Λ^{−60}`** on an admissible region-C piece. -/
theorem Vβ_le (Λ : ℝ) (hΛ : 2 ≤ Λ) (hΛK : 100000 ≤ Λ) (s X b Uv Tv M n : ℕ) (c₀ : ℝ) (hc₀0 : 0 < c₀)
    (hc₀ : c₀ ≤ 1 / 64)
    (hsR : 65536 ≤ (s : ℝ)) (hτ : (1 + Real.log s) ^ 2 * (s : ℝ) ^ (-c₀) ≤ Λ ^ (-(3000 : ℝ)))
    (h4n : (4 : ℝ) ^ n ≤ (s : ℝ) ^ (c₀ / 2))
    (hX0 : 1 ≤ X) (hX : (X : ℝ) ≤ 2 * Λ ^ (200 : ℝ)) (hb : (s : ℝ) / 2 ≤ b) (hb1 : 1 ≤ b)
    (hbh : Real.log b ≤ 2 * Λ) (hUv : Uv = ⌊(s : ℝ) ^ (1 / 16 : ℝ)⌋₊)
    (hTv : (Tv : ℝ) ≤ 8 * Λ ^ (600 : ℝ)) (hM1 : 1 ≤ M) (hM : (M : ℝ) ≤ Λ)
    (hlb : (Nat.log 2 b : ℝ) + 1 ≤ 5 * Λ) :
    Vβ s X b Uv Uv Tv M n * 2 ^ n ≤ Λ ^ (-(60 : ℝ)) := by
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  have hs1 : (1 : ℝ) ≤ s := by linarith
  have hs0 : (0 : ℝ) < s := by linarith
  have hb0 : (0 : ℝ) < b := by exact_mod_cast hb1
  set τ := (1 + Real.log (s : ℝ)) ^ 2 * (s : ℝ) ^ (-c₀) with hτdef
  have hls0 : 0 ≤ Real.log (s : ℝ) := Real.log_nonneg hs1
  obtain ⟨hU1, hUs, -, -, -⟩ := uv_facts (s : ℝ) b c₀ Uv (by linarith) hsR hb hUv
  obtain ⟨hL0, hL⟩ := L3b_le Λ hΛ b hb1 hbh
  have hlogb0 : 0 ≤ Real.log b := Real.log_nonneg (by exact_mod_cast hb1)
  have hX0R : (0 : ℝ) ≤ X := by positivity
  have hM0 : (0 : ℝ) < M := by exact_mod_cast hM1
  have h2n : (2 : ℝ) ^ n ≤ (s : ℝ) ^ (c₀ / 2) :=
    le_trans (pow_le_pow_left₀ (by norm_num) (by norm_num) n) h4n
  have h32 := three_quarter_le n
  -- first bracket
  set A := (s : ℝ) ^ ((3 : ℝ) / 4) / s * (1 + Real.log ((Uv * Uv : ℕ) : ℝ)) / M +
      (s : ℝ) ^ ((3 : ℝ) / 4) * ((Uv * Uv : ℕ) : ℝ) * (1 + Real.log s) / b with hA
  have hUU : ((Uv * Uv : ℕ) : ℝ) ≤ (s : ℝ) ^ (1 / 8 : ℝ) := by
    push_cast
    calc (Uv : ℝ) * Uv ≤ (s : ℝ) ^ (1 / 16 : ℝ) * (s : ℝ) ^ (1 / 16 : ℝ) :=
          mul_le_mul hUs hUs (by positivity) (by positivity)
      _ = (s : ℝ) ^ (1 / 8 : ℝ) := by rw [rp hs0]; norm_num
  have hUU1 : (1 : ℝ) ≤ ((Uv * Uv : ℕ) : ℝ) := by push_cast; nlinarith
  have hs18 : (s : ℝ) ^ (1 / 8 : ℝ) ≤ s := by
    calc (s : ℝ) ^ (1 / 8 : ℝ) ≤ (s : ℝ) ^ (1 : ℝ) := Real.rpow_le_rpow_of_exponent_le hs1 (by norm_num)
      _ = s := Real.rpow_one _
  have hA0 : 0 ≤ A := by
    have : 0 ≤ Real.log ((Uv * Uv : ℕ) : ℝ) := Real.log_nonneg hUU1
    positivity
  have hAle : A ≤ 3 * (1 + Real.log s) * (s : ℝ) ^ (-(1 / 8 : ℝ)) := by
    have a1 : (s : ℝ) ^ ((3 : ℝ) / 4) / s * (1 + Real.log ((Uv * Uv : ℕ) : ℝ)) / M ≤
        (1 + Real.log s) * (s : ℝ) ^ (-(1 / 8 : ℝ)) := by
      have e : (s : ℝ) ^ ((3 : ℝ) / 4) / s = (s : ℝ) ^ (-(1 / 4 : ℝ)) := by
        rw [div_eq_iff hs0.ne', show (s : ℝ) ^ (-(1 / 4 : ℝ)) * s = (s : ℝ) ^ (-(1 / 4 : ℝ)) * (s : ℝ) ^ (1 : ℝ)
          by rw [Real.rpow_one], rp hs0]; norm_num
      have hlog : Real.log ((Uv * Uv : ℕ) : ℝ) ≤ Real.log s :=
        Real.log_le_log (by linarith) (le_trans hUU hs18)
      have hq : (s : ℝ) ^ (-(1 / 4 : ℝ)) ≤ (s : ℝ) ^ (-(1 / 8 : ℝ)) :=
        Real.rpow_le_rpow_of_exponent_le hs1 (by norm_num)
      rw [e, div_le_iff₀ hM0]
      have hMR : (1 : ℝ) ≤ M := by exact_mod_cast hM1
      have h0 : 0 ≤ (s : ℝ) ^ (-(1 / 4 : ℝ)) := by positivity
      have h0' : 0 ≤ (s : ℝ) ^ (-(1 / 8 : ℝ)) := by positivity
      have h1 : (s : ℝ) ^ (-(1 / 4 : ℝ)) * (1 + Real.log ((Uv * Uv : ℕ) : ℝ)) ≤
          (s : ℝ) ^ (-(1 / 8 : ℝ)) * (1 + Real.log s) :=
        mul_le_mul hq (by linarith) (by have := Real.log_nonneg hUU1; linarith) h0'
      have hk : 0 ≤ (1 + Real.log s) * (s : ℝ) ^ (-(1 / 8 : ℝ)) := by positivity
      calc (s : ℝ) ^ (-(1 / 4 : ℝ)) * (1 + Real.log ((Uv * Uv : ℕ) : ℝ))
          ≤ (s : ℝ) ^ (-(1 / 8 : ℝ)) * (1 + Real.log s) := h1
        _ = (1 + Real.log s) * (s : ℝ) ^ (-(1 / 8 : ℝ)) * 1 := by ring
        _ ≤ (1 + Real.log s) * (s : ℝ) ^ (-(1 / 8 : ℝ)) * M := mul_le_mul_of_nonneg_left hMR hk
    have a2 : (s : ℝ) ^ ((3 : ℝ) / 4) * ((Uv * Uv : ℕ) : ℝ) * (1 + Real.log s) / b ≤
        2 * (1 + Real.log s) * (s : ℝ) ^ (-(1 / 8 : ℝ)) := by
      rw [div_le_iff₀ hb0]
      have e : (s : ℝ) ^ ((3 : ℝ) / 4) * (s : ℝ) ^ (1 / 8 : ℝ) = (s : ℝ) ^ (-(1 / 8 : ℝ)) * s := by
        rw [rp hs0, show (s : ℝ) ^ (-(1 / 8 : ℝ)) * s = (s : ℝ) ^ (-(1 / 8 : ℝ)) * (s : ℝ) ^ (1 : ℝ)
          by rw [Real.rpow_one], rp hs0]; norm_num
      have h0' : 0 ≤ (s : ℝ) ^ (-(1 / 8 : ℝ)) := by positivity
      calc (s : ℝ) ^ ((3 : ℝ) / 4) * ((Uv * Uv : ℕ) : ℝ) * (1 + Real.log s)
          ≤ (s : ℝ) ^ ((3 : ℝ) / 4) * (s : ℝ) ^ (1 / 8 : ℝ) * (1 + Real.log s) := by gcongr
        _ = (s : ℝ) ^ (-(1 / 8 : ℝ)) * s * (1 + Real.log s) := by rw [e]
        _ ≤ 2 * (1 + Real.log s) * (s : ℝ) ^ (-(1 / 8 : ℝ)) * b := by
            have hk : 0 ≤ (1 + Real.log s) * (s : ℝ) ^ (-(1 / 8 : ℝ)) := by positivity
            have : (s : ℝ) ≤ 2 * b := by linarith
            calc (s : ℝ) ^ (-(1 / 8 : ℝ)) * s * (1 + Real.log s)
                = ((1 + Real.log s) * (s : ℝ) ^ (-(1 / 8 : ℝ))) * s := by ring
              _ ≤ ((1 + Real.log s) * (s : ℝ) ^ (-(1 / 8 : ℝ))) * (2 * b) :=
                  mul_le_mul_of_nonneg_left this hk
              _ = 2 * (1 + Real.log s) * (s : ℝ) ^ (-(1 / 8 : ℝ)) * b := by ring
    rw [hA]; linarith
  have hAs : A * (s : ℝ) ^ (c₀ / 2) ≤ 3 * τ := by
    calc A * (s : ℝ) ^ (c₀ / 2) ≤ 3 * (1 + Real.log s) * (s : ℝ) ^ (-(1 / 8 : ℝ)) * (s : ℝ) ^ (c₀ / 2) := by
          gcongr
      _ = 3 * ((1 + Real.log s) * (s : ℝ) ^ (-(1 / 8 : ℝ) + c₀ / 2)) := by rw [← rp hs0]; ring
      _ ≤ 3 * ((1 + Real.log s) * (s : ℝ) ^ (-c₀)) :=
          mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left
            (Real.rpow_le_rpow_of_exponent_le hs1 (by linarith)) (by positivity)) (by norm_num)
      _ ≤ 3 * τ := by gcongr; exact lt_le_tau hs1
  -- second bracket
  have hsqU : 1 / Real.sqrt (Uv : ℝ) ≤ 1.5 * (s : ℝ) ^ (-(1 / 32 : ℝ)) := by
    have hy2 : (s : ℝ) ^ (1 / 16 : ℝ) / 2 ≤ Uv := by
      have := Nat.lt_floor_add_one ((s : ℝ) ^ (1 / 16 : ℝ))
      rw [← hUv] at this
      have h2 : (2 : ℝ) ≤ (s : ℝ) ^ (1 / 16 : ℝ) := by
        calc (2 : ℝ) = (65536 : ℝ) ^ (1 / 16 : ℝ) := by
              rw [show (65536 : ℝ) = 2 ^ (16 : ℝ) by norm_num, ← Real.rpow_mul (by norm_num)]; norm_num
          _ ≤ (s : ℝ) ^ (1 / 16 : ℝ) := Real.rpow_le_rpow (by norm_num) hsR (by norm_num)
      linarith
    have hq : Real.sqrt ((s : ℝ) ^ (1 / 16 : ℝ) / 2) = (s : ℝ) ^ (1 / 32 : ℝ) / Real.sqrt 2 := by
      rw [Real.sqrt_div' _ (by norm_num), Real.sqrt_eq_rpow, ← Real.rpow_mul hs0.le]; norm_num
    have hpos : 0 < Real.sqrt ((s : ℝ) ^ (1 / 16 : ℝ) / 2) := Real.sqrt_pos.2 (by positivity)
    have h1 : 1 / Real.sqrt (Uv : ℝ) ≤ 1 / Real.sqrt ((s : ℝ) ^ (1 / 16 : ℝ) / 2) :=
      one_div_le_one_div_of_le hpos (Real.sqrt_le_sqrt hy2)
    rw [hq] at h1
    have hs2 : Real.sqrt 2 ≤ 1.5 := sqrt_le_of (by norm_num) (by norm_num)
    have e : 1 / ((s : ℝ) ^ (1 / 32 : ℝ) / Real.sqrt 2) = Real.sqrt 2 * (s : ℝ) ^ (-(1 / 32 : ℝ)) := by
      rw [Real.rpow_neg hs0.le]; field_simp
    rw [e] at h1
    have : 0 ≤ (s : ℝ) ^ (-(1 / 32 : ℝ)) := by positivity
    nlinarith
  have hsqs : Real.sqrt (2 / (s : ℝ)) ≤ 1.5 * (s : ℝ) ^ (-(1 / 32 : ℝ)) := by
    have e : Real.sqrt (2 / (s : ℝ)) = Real.sqrt 2 * (s : ℝ) ^ (-(1 / 2 : ℝ)) := by
      rw [Real.sqrt_div' _ hs0.le, Real.sqrt_eq_rpow (s : ℝ), Real.rpow_neg hs0.le]; field_simp
    have hs2 : Real.sqrt 2 ≤ 1.5 := sqrt_le_of (by norm_num) (by norm_num)
    have hq : (s : ℝ) ^ (-(1 / 2 : ℝ)) ≤ (s : ℝ) ^ (-(1 / 32 : ℝ)) :=
      Real.rpow_le_rpow_of_exponent_le hs1 (by norm_num)
    have : 0 ≤ (s : ℝ) ^ (-(1 / 2 : ℝ)) := by positivity
    rw [e]; nlinarith
  have hB : (Real.sqrt (2 / (s : ℝ)) + 1 / Real.sqrt (Uv : ℝ)) * (s : ℝ) ^ (c₀ / 2) ≤ 3 * τ := by
    calc (Real.sqrt (2 / (s : ℝ)) + 1 / Real.sqrt (Uv : ℝ)) * (s : ℝ) ^ (c₀ / 2)
        ≤ (3 * (s : ℝ) ^ (-(1 / 32 : ℝ))) * (s : ℝ) ^ (c₀ / 2) := by gcongr; linarith
      _ = 3 * (s : ℝ) ^ (-(1 / 32 : ℝ) + c₀ / 2) := by rw [← rp hs0]; ring
      _ ≤ 3 * (s : ℝ) ^ (-c₀) :=
          mul_le_mul_of_nonneg_left (Real.rpow_le_rpow_of_exponent_le hs1 (by linarith)) (by norm_num)
      _ ≤ 3 * τ := by gcongr; exact t_le_tau hs1
  have S1 : Real.sqrt ((Tv : ℝ) * (Nat.log 2 b + 1)) ≤ 7 * Λ ^ (301 : ℝ) := by
    apply sqrt_le_of (by positivity)
    calc (Tv : ℝ) * (Nat.log 2 b + 1) ≤ (8 * Λ ^ (600 : ℝ)) * (5 * Λ) := by
          apply mul_le_mul hTv hlb (by positivity) (by positivity)
      _ = 40 * (Λ ^ (600 : ℝ) * Λ ^ (1 : ℝ)) := by rw [Real.rpow_one]; ring
      _ = 40 * Λ ^ (601 : ℝ) := by rw [rp hΛ0]; norm_num
      _ ≤ 49 * Λ ^ (602 : ℝ) := by
          have : Λ ^ (601 : ℝ) ≤ Λ ^ (602 : ℝ) := Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)
          have : 0 ≤ Λ ^ (601 : ℝ) := by positivity
          nlinarith
      _ = (7 * Λ ^ (301 : ℝ)) ^ 2 := by
          rw [mul_pow, ← Real.rpow_natCast (Λ ^ (301 : ℝ)) 2, ← Real.rpow_mul hΛ0.le]; norm_num
  have hL3 : (1 + Real.log (3 * b)) ^ 3 ≤ 64 * Λ ^ (3 : ℝ) := by
    calc (1 + Real.log (3 * b)) ^ 3 ≤ (4 * Λ) ^ 3 := pow_le_pow_left₀ hL0 hL 3
      _ = 64 * Λ ^ (3 : ℝ) := by rw [mul_pow, ← Real.rpow_natCast]; norm_num
  have hs2 : Real.sqrt 2 ≤ 1.5 := sqrt_le_of (by norm_num) (by norm_num)
  have hτ0 : 0 ≤ τ := by positivity
  unfold Vβ
  have hsc0 : 0 ≤ (s : ℝ) ^ (c₀ / 2) := by positivity
  have hp : ∀ a : ℝ, 0 ≤ Λ ^ a := fun a => by positivity
  -- combine
  have T1 : 8 * (X : ℝ) * Real.log b * (3 : ℝ) ^ ((n : ℝ) / 4) * A * 2 ^ n ≤
      96 * Λ ^ (201 : ℝ) * τ := by
    calc 8 * (X : ℝ) * Real.log b * (3 : ℝ) ^ ((n : ℝ) / 4) * A * 2 ^ n
        = 8 * (X : ℝ) * Real.log b * A * ((3 : ℝ) ^ ((n : ℝ) / 4) * 2 ^ n) := by ring
      _ ≤ 8 * (2 * Λ ^ (200 : ℝ)) * (2 * Λ) * A * (s : ℝ) ^ (c₀ / 2) := by
          gcongr; exact le_trans h32 h4n
      _ = 32 * (Λ ^ (200 : ℝ) * Λ) * (A * (s : ℝ) ^ (c₀ / 2)) := by ring
      _ ≤ 32 * (Λ ^ (200 : ℝ) * Λ) * (3 * τ) := by gcongr
      _ = 96 * Λ ^ (201 : ℝ) * τ := by
          rw [show Λ ^ (200 : ℝ) * Λ = Λ ^ (200 : ℝ) * Λ ^ (1 : ℝ) by rw [Real.rpow_one], rp hΛ0]
          ring_nf
  have T2 : 2 * (X : ℝ) * M * (Real.sqrt 2 * (1 + Real.log (3 * b)) ^ 3 *
      Real.sqrt ((Tv : ℝ) * (Nat.log 2 b + 1)) * (Real.sqrt (2 / s) + 1 / Real.sqrt Uv)) * 2 ^ n ≤
      8064 * Λ ^ (505 : ℝ) * τ := by
    calc 2 * (X : ℝ) * M * (Real.sqrt 2 * (1 + Real.log (3 * b)) ^ 3 *
          Real.sqrt ((Tv : ℝ) * (Nat.log 2 b + 1)) * (Real.sqrt (2 / s) + 1 / Real.sqrt Uv)) * 2 ^ n
        = 2 * (X : ℝ) * M * (Real.sqrt 2 * (1 + Real.log (3 * b)) ^ 3 *
          Real.sqrt ((Tv : ℝ) * (Nat.log 2 b + 1))) *
            ((Real.sqrt (2 / s) + 1 / Real.sqrt Uv) * 2 ^ n) := by ring
      _ ≤ 2 * (2 * Λ ^ (200 : ℝ)) * Λ * (1.5 * (64 * Λ ^ (3 : ℝ)) * (7 * Λ ^ (301 : ℝ))) *
            ((Real.sqrt (2 / s) + 1 / Real.sqrt Uv) * (s : ℝ) ^ (c₀ / 2)) := by
          gcongr
      _ ≤ 2 * (2 * Λ ^ (200 : ℝ)) * Λ * (1.5 * (64 * Λ ^ (3 : ℝ)) * (7 * Λ ^ (301 : ℝ))) * (3 * τ) := by
          gcongr
      _ = 8064 * (Λ ^ (200 : ℝ) * Λ ^ (1 : ℝ) * Λ ^ (3 : ℝ) * Λ ^ (301 : ℝ)) * τ := by
          rw [Real.rpow_one]; ring
      _ = 8064 * Λ ^ (505 : ℝ) * τ := by rw [rp hΛ0, rp hΛ0, rp hΛ0]; norm_num
  have e1 : (96 * Λ ^ (201 : ℝ) + 8064 * Λ ^ (505 : ℝ)) * τ ≤ Λ ^ (-(60 : ℝ)) := by
    have h1 : Λ ^ (201 : ℝ) ≤ Λ ^ (505 : ℝ) := Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)
    calc (96 * Λ ^ (201 : ℝ) + 8064 * Λ ^ (505 : ℝ)) * τ ≤ (8160 * Λ ^ (505 : ℝ)) * Λ ^ (-(3000 : ℝ)) := by
          gcongr; linarith
      _ = 8160 * Λ ^ (-(2495 : ℝ)) := by rw [mul_assoc, rp hΛ0]; norm_num
      _ ≤ Λ ^ (1 : ℝ) * Λ ^ (-(2495 : ℝ)) := by
          gcongr; rw [Real.rpow_one]; linarith
      _ = Λ ^ (-(2494 : ℝ)) := by rw [rp hΛ0]; norm_num
      _ ≤ Λ ^ (-(60 : ℝ)) := Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)
  have hsplit : (8 * (X : ℝ) * Real.log b * (3 : ℝ) ^ ((n : ℝ) / 4) * A +
      2 * (X : ℝ) * M * (Real.sqrt 2 * (1 + Real.log (3 * b)) ^ 3 *
        Real.sqrt ((Tv : ℝ) * (Nat.log 2 b + 1)) * (Real.sqrt (2 / s) + 1 / Real.sqrt Uv))) * 2 ^ n =
      8 * (X : ℝ) * Real.log b * (3 : ℝ) ^ ((n : ℝ) / 4) * A * 2 ^ n +
      2 * (X : ℝ) * M * (Real.sqrt 2 * (1 + Real.log (3 * b)) ^ 3 *
        Real.sqrt ((Tv : ℝ) * (Nat.log 2 b + 1)) * (Real.sqrt (2 / s) + 1 / Real.sqrt Uv)) * 2 ^ n := by
    ring
  rw [hA] at hsplit T1
  rw [hsplit]
  linarith


lemma S1_le (Λ : ℝ) (hΛ : 1 ≤ Λ) (Tp b : ℕ) (hTp : (Tp : ℝ) ≤ 2 * Λ ^ (100 : ℝ))
    (hlb : (Nat.log 2 b : ℝ) + 1 ≤ 5 * Λ) :
    Real.sqrt ((Tp : ℝ) * (Nat.log 2 b + 1)) ≤ 4 * Λ ^ (51 : ℝ) := by
  have hΛ0 : 0 < Λ := by linarith
  apply sqrt_le_of (by positivity)
  calc (Tp : ℝ) * (Nat.log 2 b + 1) ≤ (2 * Λ ^ (100 : ℝ)) * (5 * Λ) :=
        mul_le_mul hTp hlb (by positivity) (by positivity)
    _ = 10 * (Λ ^ (100 : ℝ) * Λ ^ (1 : ℝ)) := by rw [Real.rpow_one]; ring
    _ = 10 * Λ ^ (101 : ℝ) := by rw [rp hΛ0]; norm_num
    _ ≤ 16 * Λ ^ (102 : ℝ) := by
        have : Λ ^ (101 : ℝ) ≤ Λ ^ (102 : ℝ) := Real.rpow_le_rpow_of_exponent_le hΛ (by norm_num)
        have : 0 ≤ Λ ^ (101 : ℝ) := by positivity
        nlinarith
    _ = (4 * Λ ^ (51 : ℝ)) ^ 2 := by
        rw [mul_pow, ← Real.rpow_natCast (Λ ^ (51 : ℝ)) 2, ← Real.rpow_mul hΛ0.le]; norm_num

lemma inv_rpow_le {Λ x : ℝ} (hΛ : 0 < Λ) (k c : ℝ) (hx : Λ ^ k ≤ x) (hc : 0 ≤ c) :
    c / x ≤ c * Λ ^ (-k) := by
  have hx0 : 0 < x := lt_of_lt_of_le (by positivity) hx
  rw [div_le_iff₀ hx0]
  have e : Λ ^ (-k) * Λ ^ k = 1 := by rw [rp hΛ]; norm_num
  have : 0 ≤ c * Λ ^ (-k) := by positivity
  calc c = c * (Λ ^ (-k) * Λ ^ k) := by rw [e, mul_one]
    _ = (c * Λ ^ (-k)) * Λ ^ k := by ring
    _ ≤ (c * Λ ^ (-k)) * x := mul_le_mul_of_nonneg_left hx this

/-- `Pα ≤ 41472Λ^{−45}`. -/
theorem Pα_le (Λ : ℝ) (hΛ : 2 ≤ Λ) (s X Y Tp b : ℕ) (Aw : ℝ) (hAw0 : 0 ≤ Aw) (hAw : Aw ≤ Λ)
    (hb1 : 1 ≤ b) (hbh : Real.log b ≤ 2 * Λ) (hlb : (Nat.log 2 b : ℝ) + 1 ≤ 5 * Λ)
    (hTp1 : Λ ^ (100 : ℝ) ≤ Tp) (hTp : (Tp : ℝ) ≤ 2 * Λ ^ (100 : ℝ)) (hX : Λ ^ (200 : ℝ) ≤ X)
    (hsb : (s : ℝ) / b ≤ Λ ^ (-(200 : ℝ))) (hY : 2 / (Y : ℝ) ≤ Λ ^ (-(100 : ℝ))) :
    Pα s X Y Tp b Aw ≤ 41472 * Λ ^ (-(45 : ℝ)) := by
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  obtain ⟨hL0, hL⟩ := L3b_le Λ hΛ b hb1 hbh
  have h6X : 6 / (X : ℝ) ≤ 6 * Λ ^ (-(200 : ℝ)) := inv_rpow_le hΛ0 200 6 hX (by norm_num)
  have h2T : 2 / (Tp : ℝ) ≤ 2 * Λ ^ (-(100 : ℝ)) := inv_rpow_le hΛ0 100 2 hTp1 (by norm_num)
  have h200 : Λ ^ (-(200 : ℝ)) ≤ Λ ^ (-(100 : ℝ)) := Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)
  have hsb0 : 0 ≤ (s : ℝ) / b := by positivity
  have S2 : Real.sqrt (6 / (X : ℝ) + s / b) ≤ 3 * Λ ^ (-(100 : ℝ)) := by
    apply sqrt_le_of (by positivity)
    have e : (3 * Λ ^ (-(100 : ℝ))) ^ 2 = 9 * Λ ^ (-(200 : ℝ)) := by
      rw [mul_pow, ← Real.rpow_natCast (Λ ^ (-(100 : ℝ))) 2, ← Real.rpow_mul hΛ0.le]; norm_num
    rw [e]; linarith
  unfold Pα
  exact Pα_real Λ Aw _ _ _ _ hΛ1 hAw0 hAw hL0 hL (by positivity) (S1_le Λ hΛ1 Tp b hTp hlb)
    (by positivity) S2 (by positivity) (by linarith)

/-- `Pβ·2^n ≤ 41472Λ^{−45}`. -/
theorem Pβ_le (Λ : ℝ) (hΛ : 2 ≤ Λ) (s Y Tp b n : ℕ) (Aw : ℝ) (hAw0 : 0 ≤ Aw) (hAw : Aw ≤ Λ)
    (hb1 : 1 ≤ b) (hbh : Real.log b ≤ 2 * Λ) (hlb : (Nat.log 2 b : ℝ) + 1 ≤ 5 * Λ)
    (hTp : (Tp : ℝ) ≤ 2 * Λ ^ (100 : ℝ))
    (hsY : (Real.sqrt (2 / (s : ℝ)) + 1 / Real.sqrt (Y : ℝ)) * 2 ^ n ≤ 3 * Λ ^ (-(100 : ℝ))) :
    Pβ s Y Tp b Aw * 2 ^ n ≤ 41472 * Λ ^ (-(45 : ℝ)) := by
  have hΛ1 : 1 ≤ Λ := by linarith
  obtain ⟨hL0, hL⟩ := L3b_le Λ hΛ b hb1 hbh
  have h := Pα_real Λ Aw (1 + Real.log (3 * b)) (Real.sqrt ((Tp : ℝ) * (Nat.log 2 b + 1)))
    ((Real.sqrt (2 / (s : ℝ)) + 1 / Real.sqrt (Y : ℝ)) * 2 ^ n) 0 hΛ1 hAw0 hAw hL0 hL (by positivity)
    (S1_le Λ hΛ1 Tp b hTp hlb) (by positivity) hsY le_rfl (by positivity)
  unfold Pβ
  calc 4 * Aw * (Real.sqrt 2 * (1 + Real.log (3 * b)) ^ 3 * Real.sqrt ((Tp : ℝ) * (Nat.log 2 b + 1)) *
        (Real.sqrt (2 / s) + 1 / Real.sqrt Y)) * 2 ^ n =
      4 * Aw * (Real.sqrt 2 * (1 + Real.log (3 * b)) ^ 3 * Real.sqrt ((Tp : ℝ) * (Nat.log 2 b + 1)) *
        ((Real.sqrt (2 / (s : ℝ)) + 1 / Real.sqrt (Y : ℝ)) * 2 ^ n) + (1 + Real.log (3 * b)) ^ 5 * 0) := by
        ring
    _ ≤ 41472 * Λ ^ (-(45 : ℝ)) := h

/-- the final real combination for one `CTerm`. -/
lemma C_combine (Λ K1 Mr Ab F4 P V Sm WU Yi E : ℝ) (hΛ2 : 2 ≤ Λ) (hM : 0 ≤ Mr) (hAb : 0 ≤ Ab)
    (hK10 : 0 ≤ K1) (hK1 : K1 ≤ 5 * Λ) (hF40 : 0 ≤ F4) (hF4 : F4 ≤ 2 * Λ)
    (hP0 : 0 ≤ P) (hP : P ≤ 82944 * Λ ^ (-(45 : ℝ))) (hV0 : 0 ≤ V) (hV : V ≤ 2 * Λ ^ (-(60 : ℝ)))
    (hSm0 : 0 ≤ Sm) (hSm : Sm ≤ E * Λ ^ (10 : ℝ)) (hWU0 : 0 ≤ WU) (hWU : WU ≤ E * Λ ^ (10 : ℝ))
    (hYi0 : 0 ≤ Yi) (hYi : Yi ≤ Λ ^ (-(100 : ℝ))) (hE : 0 ≤ E)
    (hK : 5 * Mr * (Mr * Ab * 2) * 82944 + E * (Mr * Ab * 2) * 2 + Mr * Ab * 2 * E ≤ Λ ^ (1 : ℝ)) :
    K1 * Mr * (Mr * Ab * F4 * P) + Sm * (Mr * Ab * F4 * V) + Mr * Ab * F4 * WU * Yi ≤
      Λ ^ (-(40 : ℝ)) := by
  have hΛ1 : 1 ≤ Λ := by linarith
  have hΛ0 : 0 < Λ := by linarith
  have p45 : 0 ≤ Λ ^ (-(45 : ℝ)) := by positivity
  have hmono : ∀ a : ℝ, a ≤ -43 → Λ ^ a ≤ Λ ^ (-(43 : ℝ)) := fun a ha =>
    Real.rpow_le_rpow_of_exponent_le hΛ1 (by linarith)
  have t1 : K1 * Mr * (Mr * Ab * F4 * P) ≤ (5 * Mr * (Mr * Ab * 2) * 82944) * Λ ^ (-(43 : ℝ)) := by
    calc K1 * Mr * (Mr * Ab * F4 * P) ≤ (5 * Λ) * Mr * (Mr * Ab * (2 * Λ) * (82944 * Λ ^ (-(45 : ℝ)))) := by
          gcongr
      _ = (5 * Mr * (Mr * Ab * 2) * 82944) * (Λ ^ (1 : ℝ) * Λ ^ (1 : ℝ) * Λ ^ (-(45 : ℝ))) := by
          rw [Real.rpow_one]; ring
      _ = (5 * Mr * (Mr * Ab * 2) * 82944) * Λ ^ (-(43 : ℝ)) := by rw [rp hΛ0, rp hΛ0]; norm_num
  have t2 : Sm * (Mr * Ab * F4 * V) ≤ (E * (Mr * Ab * 2) * 2) * Λ ^ (-(43 : ℝ)) := by
    calc Sm * (Mr * Ab * F4 * V) ≤ (E * Λ ^ (10 : ℝ)) * (Mr * Ab * (2 * Λ) * (2 * Λ ^ (-(60 : ℝ)))) := by
          gcongr
      _ = (E * (Mr * Ab * 2) * 2) * (Λ ^ (10 : ℝ) * Λ ^ (1 : ℝ) * Λ ^ (-(60 : ℝ))) := by
          rw [Real.rpow_one]; ring
      _ = (E * (Mr * Ab * 2) * 2) * Λ ^ (-(49 : ℝ)) := by rw [rp hΛ0, rp hΛ0]; norm_num
      _ ≤ (E * (Mr * Ab * 2) * 2) * Λ ^ (-(43 : ℝ)) :=
          mul_le_mul_of_nonneg_left (hmono (-(49 : ℝ)) (by norm_num)) (by positivity)
  have t3 : Mr * Ab * F4 * WU * Yi ≤ (Mr * Ab * 2 * E) * Λ ^ (-(43 : ℝ)) := by
    calc Mr * Ab * F4 * WU * Yi ≤ Mr * Ab * (2 * Λ) * (E * Λ ^ (10 : ℝ)) * Λ ^ (-(100 : ℝ)) := by
          gcongr
      _ = (Mr * Ab * 2 * E) * (Λ ^ (1 : ℝ) * Λ ^ (10 : ℝ) * Λ ^ (-(100 : ℝ))) := by
          rw [Real.rpow_one]; ring
      _ = (Mr * Ab * 2 * E) * Λ ^ (-(89 : ℝ)) := by rw [rp hΛ0, rp hΛ0]; norm_num
      _ ≤ (Mr * Ab * 2 * E) * Λ ^ (-(43 : ℝ)) :=
          mul_le_mul_of_nonneg_left (hmono (-(89 : ℝ)) (by norm_num)) (by positivity)
  have p43 : 0 ≤ Λ ^ (-(43 : ℝ)) := by positivity
  calc K1 * Mr * (Mr * Ab * F4 * P) + Sm * (Mr * Ab * F4 * V) + Mr * Ab * F4 * WU * Yi
      ≤ (5 * Mr * (Mr * Ab * 2) * 82944 + E * (Mr * Ab * 2) * 2 + Mr * Ab * 2 * E) * Λ ^ (-(43 : ℝ)) := by
        linarith
    _ ≤ Λ ^ (1 : ℝ) * Λ ^ (-(43 : ℝ)) := mul_le_mul_of_nonneg_right hK p43
    _ = Λ ^ (-(42 : ℝ)) := by rw [rp hΛ0]; norm_num
    _ ≤ Λ ^ (-(40 : ℝ)) := Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)

end GoldC.QuillonCEv

#print axioms GoldC.QuillonCEv.edecay
#print axioms GoldC.QuillonCEv.Pα_real
#print axioms GoldC.QuillonCEv.v1_le
#print axioms GoldC.QuillonCEv.uv_facts
#print axioms GoldC.QuillonCEv.v2_real
#print axioms GoldC.QuillonCEv.Vα_le
#print axioms GoldC.QuillonCEv.Vβ_le
#print axioms GoldC.QuillonCEv.Pα_le
#print axioms GoldC.QuillonCEv.Pβ_le
#print axioms GoldC.QuillonCEv.C_combine
