import PaperB.Analytic.PetermannEtaThresholdTransport
import PaperB.Analytic.PetermannEtaHarmonicExpansion

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

lemma eta_correction_inner_eq_harmonicSawtooth
    (q d X : ℕ) (hd : 1 ≤ d)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (T : ℝ) :
    (∑ m ∈ Finset.Icc 1 (X / d),
      ((chi m) / (m : ℂ)) *
        (petermannSawtooth
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) /
              ((d * m : ℕ) : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ)) =
      etaHarmonicSawtoothSum q chi r
        (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (d : ℝ)) (X / d) := by
  unfold etaHarmonicSawtoothSum
  apply Finset.sum_congr rfl
  intro m hm
  congr 2
  simp only [Nat.cast_mul, div_eq_mul_inv, mul_inv_rev]
  ring

lemma norm_etaHarmonicSawtoothSum_le_half_harmonic
    (q : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (A : ℝ) (Y : ℕ) :
    ‖etaHarmonicSawtoothSum q chi r A Y‖
      ≤ (1 / 2 : ℝ) * (harmonic Y : ℝ) := by
  unfold etaHarmonicSawtoothSum
  have h :=
    norm_etaHarmonicSawtooth_Icc_le_half_harmonic
      q chi r A (M := 1) (Y := Y) (by omega)
  have hsum :
      (∑ m ∈ Finset.Icc 1 Y, (1 : ℝ) / (m : ℝ)) =
        (harmonic Y : ℝ) := by
    rw [harmonic_eq_sum_Icc]
    push_cast
    apply Finset.sum_congr rfl
    intro m hm
    norm_num [div_eq_mul_inv]
  rw [← hsum]
  exact h

lemma etaCorrectionInvTerm_small_off_finset
    (q : ℕ) {delta : ℝ} (hdelta : 0 < delta) :
    ∃ s : Finset ℕ,
      ∀ t : Finset ℕ, Disjoint t s →
        (∑ d ∈ t, |etaCorrectionInvTerm q d|) < delta := by
  have hsumm : Summable (fun d : ℕ => |etaCorrectionInvTerm q d|) :=
    (summable_etaCorrectionInvTerm q).abs
  obtain ⟨s, hs⟩ :=
    (summable_iff_vanishing_norm.mp hsumm) delta hdelta
  refine ⟨s, ?_⟩
  intro t hts
  have h := hs t hts
  rw [Real.norm_eq_abs, abs_of_nonneg] at h
  · exact h
  · exact Finset.sum_nonneg (fun d hd => abs_nonneg _)

set_option maxHeartbeats 1000000 in
theorem petermannEtaR0002_of_sawtooth
    (q : ℕ) (hq : 0 < q)
    (hspec : EtaHarmonicSawtoothSpec q) :
    PetermannMinimalConsumerR0002Spec q PetermannBase.eta := by
  intro eps heps
  let L : ℕ := Nat.lcm 6 q
  have hLpos : 0 < L := Nat.lcm_pos (by norm_num) hq
  have hL1 : 1 ≤ L := by omega
  have hLR : (0 : ℝ) < L := by exact_mod_cast hLpos
  let R : ℝ := etaRankinBound
  have hR0 : 0 ≤ R := by
    dsimp [R]
    unfold etaRankinBound
    positivity
  let delta : ℝ := eps / 4
  have hdelta : 0 < delta := by dsimp [delta]; positivity
  obtain ⟨s, hsTail⟩ :=
    etaCorrectionInvTerm_small_off_finset q hdelta
  let D : ℕ := (∑ d ∈ s, d) + 1
  have hDpos : 0 < D := by dsimp [D]; omega
  have hD1 : 1 ≤ D := by omega
  let epsH : ℝ := eps / (4 * (R + 1))
  have hepsH : 0 < epsH := by
    dsimp [epsH]
    positivity
  obtain ⟨A0, hA00, C, hC0, hstretch⟩ :=
    etaHarmonicSawtooth_fixed_stretch q hq hspec epsH hepsH
  let Tth : ℝ := A0 * (L : ℝ) * (D : ℝ)
  let Kc : ℝ := 4 * R * C / eps
  let T0 : ℝ := max (Real.exp 1) (max Tth (Real.exp Kc))
  refine ⟨T0, ?_⟩
  intro chi r T X hT0 h2L hX1 hXT
  have hExp1 : Real.exp 1 ≤ T :=
    (le_max_left (Real.exp 1) (max Tth (Real.exp Kc))).trans hT0
  have hTpos : 0 < T := (Real.exp_pos 1).trans_le hExp1
  have hT1 : 1 ≤ T := by
    have : (1 : ℝ) ≤ Real.exp 1 := by
      rw [← Real.exp_zero]
      exact Real.exp_le_exp.mpr (by norm_num)
    exact this.trans hExp1
  have hlog1 : 1 ≤ Real.log T := by
    have h := Real.log_le_log (Real.exp_pos 1) hExp1
    simpa using h
  have hlog0 : 0 ≤ Real.log T := by linarith
  have hTth : Tth ≤ T := by
    exact (le_max_left Tth (Real.exp Kc)).trans
      ((le_max_right (Real.exp 1) (max Tth (Real.exp Kc))).trans hT0)
  have hExpK : Real.exp Kc ≤ T := by
    exact (le_max_right Tth (Real.exp Kc)).trans
      ((le_max_right (Real.exp 1) (max Tth (Real.exp Kc))).trans hT0)
  have hlogK : Kc ≤ Real.log T := by
    have h := Real.log_le_log (Real.exp_pos Kc) hExpK
    simpa using h
  have hheadCoef : R * epsH ≤ eps / 4 := by
    dsimp [epsH]
    have hden : 0 < 4 * (R + 1) := by positivity
    rw [show R * (eps / (4 * (R + 1))) =
        (R * eps) / (4 * (R + 1)) by ring]
    apply (div_le_iff₀ hden).2
    ring_nf
    nlinarith
  have hheadConst : R * C ≤ (eps / 4) * Real.log T := by
    have hm := mul_le_mul_of_nonneg_left hlogK
      (show 0 ≤ eps / 4 by positivity)
    calc
      R * C = (eps / 4) * Kc := by
        dsimp [Kc]
        field_simp [ne_of_gt heps]
      _ ≤ (eps / 4) * Real.log T := hm
  rw [petermannBaseKernelSum_eta_eq_correction_harmonic]
  have hexpand :
      (∑ d ∈ Finset.Icc 1 X,
        (chi d) * (etaCorrectionInvTerm q d : ℂ) *
          ∑ m ∈ Finset.Icc 1 (X / d),
            ((chi m) / (m : ℂ)) *
              (petermannSawtooth
                (T / ((Nat.lcm 6 q : ℕ) : ℝ) /
                    ((d * m : ℕ) : ℝ) +
                  (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ)) =
      ∑ d ∈ Finset.Icc 1 X,
        (chi d) * (etaCorrectionInvTerm q d : ℂ) *
          etaHarmonicSawtoothSum q chi r
            (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (d : ℝ)) (X / d) := by
    apply Finset.sum_congr rfl
    intro d hd
    rw [eta_correction_inner_eq_harmonicSawtooth
      q d X (Finset.mem_Icc.mp hd).1 chi r T]
  rw [hexpand]
  let E := Finset.Icc 1 X
  let p : ℕ → Prop := fun d => d ∈ s
  let F : ℕ → ℂ := fun d =>
    (chi d) * (etaCorrectionInvTerm q d : ℂ) *
      etaHarmonicSawtoothSum q chi r
        (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (d : ℝ)) (X / d)
  change ‖∑ d ∈ E, F d‖ ≤ _
  rw [← Finset.sum_filter_add_sum_filter_not E p F]
  calc
    ‖(∑ d ∈ E.filter p, F d) +
        (∑ d ∈ E.filter (fun d => ¬ p d), F d)‖
      ≤ ‖∑ d ∈ E.filter p, F d‖ +
          ‖∑ d ∈ E.filter (fun d => ¬ p d), F d‖ :=
        norm_add_le _ _
    _ ≤ (eps / 2) * Real.log T + (eps / 4) * Real.log T := by
      apply _root_.add_le_add
      · calc
          ‖∑ d ∈ E.filter p, F d‖
            ≤ ∑ d ∈ E.filter p, ‖F d‖ := norm_sum_le _ _
          _ ≤ ∑ d ∈ E.filter p,
              |etaCorrectionInvTerm q d| *
                (epsH * Real.log T + C) := by
              apply Finset.sum_le_sum
              intro d hd
              have hdE := (Finset.mem_filter.mp hd).1
              have hds := (Finset.mem_filter.mp hd).2
              have hdI := Finset.mem_Icc.mp hdE
              have hd1 : 1 ≤ d := hdI.1
              have hdposR : (0 : ℝ) < d := by positivity
              have hdSum : d ≤ ∑ x ∈ s, x := by
                exact Finset.single_le_sum
                  (fun i hi => Nat.zero_le i) hds
              have hdD : d ≤ D := by
                dsimp [D]
                omega
              have hA0scaled :
                  A0 ≤ T / (L : ℝ) / (d : ℝ) := by
                have hLDpos : 0 < (L : ℝ) * (d : ℝ) := mul_pos hLR hdposR
                rw [div_div]
                apply (le_div_iff₀ hLDpos).2
                have hDdR : (d : ℝ) ≤ (D : ℝ) := by exact_mod_cast hdD
                have hA0nonneg : 0 ≤ A0 := hA00.le
                have hmulD :
                    A0 * (L : ℝ) * (d : ℝ) ≤
                      A0 * (L : ℝ) * (D : ℝ) := by
                  exact mul_le_mul_of_nonneg_left hDdR
                    (mul_nonneg hA0nonneg hLR.le)
                exact (by
                  simpa [mul_assoc] using hmulD.trans (by simpa [Tth] using hTth))
              have hY1 : 1 ≤ X / d :=
                one_le_scaled_cutoff hdE
              have hYstretch :
                  ((X / d : ℕ) : ℝ) ≤
                    (L : ℝ) *
                      (T / (L : ℝ) / (d : ℝ)) := by
                have hcast :
                    ((X / d : ℕ) : ℝ) ≤ (X : ℝ) / (d : ℝ) :=
                  Nat.cast_div_le
                have hXTd :
                    (X : ℝ) / (d : ℝ) ≤ T / (d : ℝ) :=
                  div_le_div_of_nonneg_right hXT hdposR.le
                have hEq :
                    (L : ℝ) * (T / (L : ℝ) / (d : ℝ)) =
                      T / (d : ℝ) := by
                  field_simp [hLR.ne']
                rw [hEq]
                exact hcast.trans hXTd
              have hin :=
                hstretch chi r
                  (T / (L : ℝ) / (d : ℝ)) (X / d)
                  hA0scaled hY1 hYstretch
              have hscaledPos :
                  0 < T / (L : ℝ) / (d : ℝ) := by positivity
              have hscaledLeT :
                  T / (L : ℝ) / (d : ℝ) ≤ T := by
                have hLd1 : (1 : ℝ) ≤ (L : ℝ) * (d : ℝ) := by
                  have hLR1 : (1 : ℝ) ≤ L := by exact_mod_cast hL1
                  have hdR1 : (1 : ℝ) ≤ d := by exact_mod_cast hd1
                  nlinarith
                rw [div_div]
                exact div_le_self hTpos.le hLd1
              have hlog :
                  Real.log (T / (L : ℝ) / (d : ℝ)) ≤ Real.log T :=
                Real.log_le_log hscaledPos hscaledLeT
              have hinT :
                  ‖etaHarmonicSawtoothSum q chi r
                      (T / (L : ℝ) / (d : ℝ)) (X / d)‖
                    ≤ epsH * Real.log T + C := by
                exact hin.trans (_root_.add_le_add
                  (mul_le_mul_of_nonneg_left hlog hepsH.le) le_rfl)
              have hchi :=
                norm_dirichletCharacter_nat_le_one
                  (q := q) (e := d) chi
              have hB0 : 0 ≤ epsH * Real.log T + C :=
                add_nonneg (mul_nonneg hepsH.le hlog0) hC0
              dsimp [F]
              simp only [norm_mul, Complex.norm_real, Real.norm_eq_abs]
              calc
                ‖chi d‖ * |etaCorrectionInvTerm q d| *
                    ‖etaHarmonicSawtoothSum q chi r
                      (T / ↑(Nat.lcm 6 q) / ↑d) (X / d)‖
                  ≤ 1 * |etaCorrectionInvTerm q d| *
                      (epsH * Real.log T + C) := by gcongr
                _ = |etaCorrectionInvTerm q d| *
                      (epsH * Real.log T + C) := by ring
          _ = (epsH * Real.log T + C) *
              (∑ d ∈ E.filter p, |etaCorrectionInvTerm q d|) := by
                rw [Finset.mul_sum]
                apply Finset.sum_congr rfl
                intro d hd
                ring
          _ ≤ (epsH * Real.log T + C) * R := by
                apply mul_le_mul_of_nonneg_left
                · have hsub : E.filter p ⊆ Finset.Icc 1 X :=
                    (Finset.filter_subset p E)
                  have hsumsub :=
                    Finset.sum_le_sum_of_subset_of_nonneg hsub
                      (fun d hd hnot => abs_nonneg (etaCorrectionInvTerm q d))
                  exact hsumsub.trans
                    (by simpa [R] using sum_Icc_abs_etaCorrectionInvTerm_le_bound q X)
                · exact add_nonneg (mul_nonneg hepsH.le hlog0) hC0
          _ = R * (epsH * Real.log T + C) := by ring
          _ ≤ (eps / 2) * Real.log T := by
                calc
                  R * (epsH * Real.log T + C)
                    = (R * epsH) * Real.log T + R * C := by ring
                  _ ≤ (eps / 4) * Real.log T +
                      (eps / 4) * Real.log T :=
                    add_le_add
                      (mul_le_mul_of_nonneg_right hheadCoef hlog0)
                      hheadConst
                  _ = (eps / 2) * Real.log T := by ring
      · have htailDisjoint :
            Disjoint (E.filter (fun d => ¬ p d)) s := by
          rw [Finset.disjoint_left]
          intro d hd hds
          have hnp := (Finset.mem_filter.mp hd).2
          exact hnp hds
        have hmassLt :=
          hsTail (E.filter (fun d => ¬ p d)) htailDisjoint
        have hmass :
            (∑ d ∈ E.filter (fun d => ¬ p d),
              |etaCorrectionInvTerm q d|) ≤ delta :=
          le_of_lt hmassLt
        calc
          ‖∑ d ∈ E.filter (fun d => ¬ p d), F d‖
            ≤ ∑ d ∈ E.filter (fun d => ¬ p d), ‖F d‖ :=
              norm_sum_le _ _
          _ ≤ ∑ d ∈ E.filter (fun d => ¬ p d),
              |etaCorrectionInvTerm q d| * Real.log T := by
                apply Finset.sum_le_sum
                intro d hd
                have hdE := (Finset.mem_filter.mp hd).1
                have hdI := Finset.mem_Icc.mp hdE
                have hd1 : 1 ≤ d := hdI.1
                have hY1 : 1 ≤ X / d := one_le_scaled_cutoff hdE
                have hYXT :
                    ((X / d : ℕ) : ℝ) ≤ T := by
                  have hcast :
                      ((X / d : ℕ) : ℝ) ≤ (X : ℝ) / (d : ℝ) :=
                    Nat.cast_div_le
                  have hdR1 : (1 : ℝ) ≤ d := by exact_mod_cast hd1
                  have hXdX : (X : ℝ) / (d : ℝ) ≤ (X : ℝ) := by
                    exact div_le_self (by positivity) hdR1
                  exact hcast.trans (hXdX.trans hXT)
                have hYpos : (0 : ℝ) < (X / d : ℕ) := by
                  exact_mod_cast (show 0 < X / d by omega)
                have hlogY :
                    Real.log ((X / d : ℕ) : ℝ) ≤ Real.log T :=
                  Real.log_le_log hYpos hYXT
                have hharm :=
                  harmonic_le_one_add_log (X / d)
                have hharm2 :
                    (harmonic (X / d) : ℝ) ≤ 2 * Real.log T := by
                  linarith
                have hin :=
                  norm_etaHarmonicSawtoothSum_le_half_harmonic
                    q chi r
                      (T / (L : ℝ) / (d : ℝ)) (X / d)
                have hinLog :
                    ‖etaHarmonicSawtoothSum q chi r
                        (T / (L : ℝ) / (d : ℝ)) (X / d)‖
                      ≤ Real.log T := by
                  calc
                    _ ≤ (1 / 2 : ℝ) * (harmonic (X / d) : ℝ) := hin
                    _ ≤ (1 / 2 : ℝ) * (2 * Real.log T) :=
                      mul_le_mul_of_nonneg_left hharm2 (by norm_num)
                    _ = Real.log T := by ring
                have hchi :=
                  norm_dirichletCharacter_nat_le_one
                    (q := q) (e := d) chi
                dsimp [F]
                simp only [norm_mul, Complex.norm_real, Real.norm_eq_abs]
                calc
                  ‖chi d‖ * |etaCorrectionInvTerm q d| *
                      ‖etaHarmonicSawtoothSum q chi r
                        (T / ↑(Nat.lcm 6 q) / ↑d) (X / d)‖
                    ≤ 1 * |etaCorrectionInvTerm q d| * Real.log T := by
                      gcongr
                  _ = |etaCorrectionInvTerm q d| * Real.log T := by ring
          _ = Real.log T *
              (∑ d ∈ E.filter (fun d => ¬ p d),
                |etaCorrectionInvTerm q d|) := by
                rw [Finset.mul_sum]
                apply Finset.sum_congr rfl
                intro d hd
                ring
          _ ≤ Real.log T * delta :=
                mul_le_mul_of_nonneg_left hmass hlog0
          _ = (eps / 4) * Real.log T := by
                dsimp [delta]
                ring
    _ ≤ eps * Real.log T := by
      have h : (eps / 2 + eps / 4) ≤ eps := by linarith
      nlinarith [mul_nonneg heps.le hlog0]

theorem petermannEtaR0002
    (q : ℕ) (hq : 0 < q) :
    PetermannMinimalConsumerR0002Spec q PetermannBase.eta := by
  exact petermannEtaR0002_of_sawtooth q hq
    (etaHarmonicSawtoothSpec_of_pos q hq)

#print axioms petermannEtaR0002_of_sawtooth
#print axioms petermannEtaR0002

end PaperB.Analytic
