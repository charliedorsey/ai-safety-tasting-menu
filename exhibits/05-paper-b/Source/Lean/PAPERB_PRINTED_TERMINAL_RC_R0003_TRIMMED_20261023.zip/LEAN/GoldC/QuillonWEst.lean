import GoldC.QuillonWCellApp
import GoldC.QuillonAsymp

/-!
# Quillon CSC3 F7.9b: the W′ term in closed form

`WTerm_le`: with `‖A ρ j‖ ≤ Ab/j` and `G₀(c_j) = ∏_{p∈C, p|j} p`:

    WTerm ≤ (log₂ max(Nb,Lw) + 1)·M²·Ab·Aω*²·(1 + log Jm)·
              (2/√X + 2(1+log Y)/√s + 2(1+log Y)·8^{|C|}·√(s^{−1/4} + s^{3/4}(1+log s)/(Lw/Y)))
            + M·Ab·(1 + log Jm)·∏_U(1 + 1/(p−3))·12.5/X.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonWEst

open GoldC.QuillonWCellApp GoldC.QuillonWBilinear GoldC.QuillonAsymp

lemma sqrt_add3_le (a b c : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) :
    Real.sqrt (a + b + c) ≤ Real.sqrt a + Real.sqrt b + Real.sqrt c := by
  rw [Real.sqrt_le_left (by positivity)]
  have h1 := Real.sq_sqrt ha; have h2 := Real.sq_sqrt hb; have h3 := Real.sq_sqrt hc
  have := Real.sqrt_nonneg a; have := Real.sqrt_nonneg b; have := Real.sqrt_nonneg c
  nlinarith [mul_nonneg (Real.sqrt_nonneg a) (Real.sqrt_nonneg b),
    mul_nonneg (Real.sqrt_nonneg b) (Real.sqrt_nonneg c), mul_nonneg (Real.sqrt_nonneg a) (Real.sqrt_nonneg c)]

lemma harm_Icc_le (J : ℕ) : ∑ j ∈ Icc 1 J, (1 / (j : ℝ)) ≤ 1 + Real.log J := by
  have h := GoldC.QuillonDivisorMoment.harm_Ioc_le' J
  have e : Icc 1 J = Ioc 0 J := by ext j; simp only [mem_Icc, mem_Ioc]; omega
  rw [e]; exact h

lemma prod_one_add_rpow_le (C : Finset ℕ) (hC : ∀ p ∈ C, p.Prime) (b : ℝ) (hb : b ≤ 0) :
    ∏ p ∈ C, (1 + (p : ℝ) ^ b) ≤ 2 ^ C.card := by
  rw [← prod_const]
  refine prod_le_prod₀ (fun p hp => by positivity) fun p hp => ?_
  have : (p : ℝ) ^ b ≤ 1 := Real.rpow_le_one_of_one_le_of_nonpos (by exact_mod_cast (hC p hp).one_le) hb
  linarith

section W
variable {s : ℕ} [NeZero s] {M : ℕ} [NeZero M]

/-- The W′ saving factor for one mode, with the gcd made explicit. -/
lemma sqrt_WPsi_le (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (c₀ : ZMod s) (X Y N : ℕ) (hX : 1 ≤ X) (hN : 1 ≤ N)
    (G : ℕ) (hG : P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0) = P.filter (fun p => p ∣ G)) :
    Real.sqrt (2 * WPsi P c₀ X Y N) ≤
      2 / Real.sqrt X + 2 * (1 + Real.log Y) / Real.sqrt s +
        2 * (1 + Real.log Y) * Real.sqrt (∏ p ∈ P, (1 + (p : ℝ) ^ (-(3 : ℝ) / 4))) *
          (3 : ℝ) ^ ((P.card : ℝ) / 8) *
          (((∏ p ∈ P.filter (fun p => p ∣ G), p : ℕ) : ℝ) ^ ((1 : ℝ) / 8)) *
          Real.sqrt ((s : ℝ) ^ ((3 : ℝ) / 4) / s + (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + Real.log s) / N) := by
  unfold WPsi
  rw [hG]
  have hXR : (0 : ℝ) < X := by exact_mod_cast hX
  have hsR : (0 : ℝ) < s := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne s)
  have hlY : 0 ≤ 1 + Real.log Y := by
    have := Real.log_natCast_nonneg Y; linarith
  have hls : 0 ≤ 1 + Real.log s := by
    have := Real.log_natCast_nonneg s; linarith
  set Pi34 := ∏ p ∈ P, (1 + (p : ℝ) ^ (-(3 : ℝ) / 4)) with hPi
  have hPi0 : 0 ≤ Pi34 := prod_nonneg fun _ _ => by positivity
  set Gp := ∏ p ∈ P.filter (fun p => p ∣ G), (p : ℝ) with hGp
  have hGp0 : 0 ≤ Gp := prod_nonneg fun _ _ => Nat.cast_nonneg _
  have hGpN : Gp = ((∏ p ∈ P.filter (fun p => p ∣ G), p : ℕ) : ℝ) := by rw [Nat.cast_prod]
  set Q := (s : ℝ) ^ ((3 : ℝ) / 4) / s + (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + Real.log s) / N with hQ
  have hQ0 : 0 ≤ Q := by positivity
  have h3 : (0 : ℝ) ≤ (3 : ℝ) ^ ((P.card : ℝ) / 4) := by positivity
  have hG4 : (0 : ℝ) ≤ Gp ^ ((1 : ℝ) / 4) := by positivity
  rw [show 2 * (2 / (X : ℝ) + 2 * (1 + Real.log Y) ^ 2 / s +
      2 * (1 + Real.log Y) ^ 2 * Pi34 * ((3 : ℝ) ^ ((P.card : ℝ) / 4) * Gp ^ ((1 : ℝ) / 4)) * Q) =
      4 / (X : ℝ) + 4 * (1 + Real.log Y) ^ 2 / s +
      4 * (1 + Real.log Y) ^ 2 * Pi34 * ((3 : ℝ) ^ ((P.card : ℝ) / 4) * Gp ^ ((1 : ℝ) / 4)) * Q by ring]
  refine (sqrt_add3_le _ _ _ (by positivity) (by positivity) (by positivity)).trans ?_
  apply add_le_add (add_le_add ?_ ?_) ?_
  · rw [Real.sqrt_div' _ hXR.le, show (4 : ℝ) = 2 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
  · rw [Real.sqrt_div' _ hsR.le, show 4 * (1 + Real.log Y) ^ 2 = (2 * (1 + Real.log Y)) ^ 2 by ring,
      Real.sqrt_sq (by positivity)]
  · have e3 : Real.sqrt ((3 : ℝ) ^ ((P.card : ℝ) / 4)) = (3 : ℝ) ^ ((P.card : ℝ) / 8) := by
      rw [Real.sqrt_eq_rpow, ← Real.rpow_mul (by norm_num)]; congr 1; ring
    have eG : Real.sqrt (Gp ^ ((1 : ℝ) / 4)) = Gp ^ ((1 : ℝ) / 8) := by
      rw [Real.sqrt_eq_rpow, ← Real.rpow_mul hGp0]; congr 1; ring
    rw [show 4 * (1 + Real.log Y) ^ 2 * Pi34 * ((3 : ℝ) ^ ((P.card : ℝ) / 4) * Gp ^ ((1 : ℝ) / 4)) * Q =
        (2 * (1 + Real.log Y)) ^ 2 * Pi34 * (3 : ℝ) ^ ((P.card : ℝ) / 4) * Gp ^ ((1 : ℝ) / 4) * Q by ring]
    rw [Real.sqrt_mul (by positivity), Real.sqrt_mul (by positivity), Real.sqrt_mul (by positivity),
      Real.sqrt_mul (by positivity), Real.sqrt_sq (by positivity), e3, eG, ← hGpN]

/-- **The W′ term in closed form.** -/
theorem WTerm_le (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (U : Finset ℕ) (hU : ∀ p ∈ U, 5 ≤ p)
    (Jm : ℕ) (A : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s) (Ab : ℝ) (hAb : 0 ≤ Ab)
    (hA : ∀ ρ j, 1 ≤ j → ‖A ρ j‖ ≤ Ab / j)
    (hc : ∀ j, 1 ≤ j → P.filter (fun p => (ZMod.cast (c j) : ZMod p) = 0) = P.filter (fun p => p ∣ j))
    (X Y Nb Lw : ℕ) (hX : 1 ≤ X) (hN : 1 ≤ Lw / Y) :
    WTerm P U (Icc 1 Jm) A c X Y Nb Lw ≤
      ((Nat.log 2 (max Nb Lw) + 1 : ℕ) : ℝ) * M * (M * Ab) *
        (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 * (max Nb Lw) ^ 2)) : ℝ) ^ 30) ^ 2 *
        (1 + Real.log Jm) *
        (2 / Real.sqrt X + 2 * (1 + Real.log Y) / Real.sqrt s +
          2 * (1 + Real.log Y) * (8 : ℝ) ^ P.card *
            Real.sqrt ((s : ℝ) ^ ((3 : ℝ) / 4) / s + (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + Real.log s) / (Lw / Y : ℕ))) +
      M * Ab * (1 + Real.log Jm) * (∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3))) * ((12.5 : ℝ) / X) := by
  unfold WTerm
  set K₁ : ℝ := ((Nat.log 2 (max Nb Lw) + 1 : ℕ) : ℝ) with hK₁
  set Aω : ℝ := (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 (2 * (max Nb Lw) ^ 2)) : ℝ) ^ 30) ^ 2 with hAω
  set WU : ℝ := ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) with hWU
  have hWU0 : 0 ≤ WU := prod_nonneg fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast hU p hp
    have : 0 ≤ 1 / ((p : ℝ) - 3) := by apply div_nonneg zero_le_one; linarith
    linarith
  have hlJ : 0 ≤ 1 + Real.log Jm := GoldC.QuillonDivisorMoment.one_add_log_nonneg Jm
  have hsR : (0 : ℝ) < s := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne s)
  have hlY : 0 ≤ 1 + Real.log Y := by have := Real.log_natCast_nonneg Y; linarith
  set Q := (s : ℝ) ^ ((3 : ℝ) / 4) / s + (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + Real.log s) / (Lw / Y : ℕ) with hQ
  have hQ0 : 0 ≤ Q := by
    have : 0 ≤ 1 + Real.log s := by have := Real.log_natCast_nonneg s; linarith
    positivity
  set Pi34 := ∏ p ∈ P, (1 + (p : ℝ) ^ (-(3 : ℝ) / 4)) with hPi34
  have hPi34 : Real.sqrt Pi34 ≤ 2 ^ P.card := by
    have h := prod_one_add_rpow_le P hP (-(3 : ℝ) / 4) (by norm_num)
    have h1 : (1 : ℝ) ≤ 2 ^ P.card := one_le_pow₀ (by norm_num)
    calc Real.sqrt Pi34 ≤ Real.sqrt (2 ^ P.card) := Real.sqrt_le_sqrt h
      _ ≤ 2 ^ P.card := by
          rw [Real.sqrt_le_left (by positivity)]; nlinarith
  have h3 : (3 : ℝ) ^ ((P.card : ℝ) / 8) ≤ 2 ^ P.card := by
    rw [show (2 : ℝ) ^ P.card = (2 : ℝ) ^ (P.card : ℝ) by rw [Real.rpow_natCast]]
    calc (3 : ℝ) ^ ((P.card : ℝ) / 8) ≤ (3 : ℝ) ^ ((P.card : ℝ) / 2) :=
          Real.rpow_le_rpow_of_exponent_le (by norm_num) (by
            have : (0 : ℝ) ≤ P.card := Nat.cast_nonneg _; linarith)
      _ = (Real.sqrt 3) ^ (P.card : ℝ) := by
          rw [Real.sqrt_eq_rpow, ← Real.rpow_mul (by norm_num)]; congr 1; ring
      _ ≤ (2 : ℝ) ^ (P.card : ℝ) := by
          apply Real.rpow_le_rpow (Real.sqrt_nonneg _) _ (Nat.cast_nonneg _)
          rw [Real.sqrt_le_left (by norm_num)]; norm_num
  -- per-mode bound
  have hmode : ∀ j ∈ Icc 1 Jm, Real.sqrt (2 * WPsi P (c j) X Y (Lw / Y)) ≤
      2 / Real.sqrt X + 2 * (1 + Real.log Y) / Real.sqrt s +
        2 * (1 + Real.log Y) * (4 : ℝ) ^ P.card *
          (((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 8)) * Real.sqrt Q := by
    intro j hj
    have hj1 : 1 ≤ j := (mem_Icc.1 hj).1
    refine (sqrt_WPsi_le P hP (c j) X Y (Lw / Y) hX hN j (hc j hj1)).trans ?_
    have hG0 : (0 : ℝ) ≤ ((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 8) := by positivity
    have h4 : Real.sqrt Pi34 * (3 : ℝ) ^ ((P.card : ℝ) / 8) ≤ (4 : ℝ) ^ P.card := by
      rw [show (4 : ℝ) ^ P.card = 2 ^ P.card * 2 ^ P.card by rw [← mul_pow]; norm_num]
      exact mul_le_mul hPi34 h3 (by positivity) (by positivity)
    have := Real.sqrt_nonneg Q
    have hsPi : 0 ≤ Real.sqrt Pi34 := Real.sqrt_nonneg _
    have h3' : (0 : ℝ) ≤ (3 : ℝ) ^ ((P.card : ℝ) / 8) := by positivity
    have hsQ := Real.sqrt_nonneg Q
    have hk : 2 * (1 + Real.log Y) * (Real.sqrt Pi34 * (3 : ℝ) ^ ((P.card : ℝ) / 8)) *
        ((((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 8)) * Real.sqrt Q) ≤
        2 * (1 + Real.log Y) * (4 : ℝ) ^ P.card *
        ((((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 8)) * Real.sqrt Q) :=
      mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left h4 (by positivity)) (by positivity)
    have e1 : 2 * (1 + Real.log Y) * Real.sqrt Pi34 * (3 : ℝ) ^ ((P.card : ℝ) / 8) *
        (((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 8)) * Real.sqrt Q =
        2 * (1 + Real.log Y) * (Real.sqrt Pi34 * (3 : ℝ) ^ ((P.card : ℝ) / 8)) *
        ((((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 8)) * Real.sqrt Q) := by ring
    have e2 : 2 * (1 + Real.log Y) * (4 : ℝ) ^ P.card *
        (((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 8)) * Real.sqrt Q =
        2 * (1 + Real.log Y) * (4 : ℝ) ^ P.card *
        ((((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 8)) * Real.sqrt Q) := by ring
    rw [e1, e2]
    linarith
  -- mode sums
  have hsum1 : ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) ≤ 1 + Real.log Jm := harm_Icc_le Jm
  have hsum2 := gcd_mode_sum P hP Jm (1 / 8) (by norm_num) (by norm_num)
  have hPi78 : ∏ p ∈ P, (1 + (p : ℝ) ^ ((1 : ℝ) / 8 - 1)) ≤ 2 ^ P.card :=
    prod_one_add_rpow_le P hP _ (by norm_num)
  have hS : ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * Real.sqrt (2 * WPsi P (c j) X Y (Lw / Y)) ≤
      (1 + Real.log Jm) *
        (2 / Real.sqrt X + 2 * (1 + Real.log Y) / Real.sqrt s +
          2 * (1 + Real.log Y) * (8 : ℝ) ^ P.card * Real.sqrt Q) := by
    calc ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * Real.sqrt (2 * WPsi P (c j) X Y (Lw / Y))
        ≤ ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * (2 / Real.sqrt X + 2 * (1 + Real.log Y) / Real.sqrt s +
            2 * (1 + Real.log Y) * (4 : ℝ) ^ P.card *
              (((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 8)) * Real.sqrt Q) :=
          sum_le_sum fun j hj => mul_le_mul_of_nonneg_left (hmode j hj) (by positivity)
      _ = (∑ j ∈ Icc 1 Jm, (1 / (j : ℝ))) * (2 / Real.sqrt X + 2 * (1 + Real.log Y) / Real.sqrt s) +
          2 * (1 + Real.log Y) * (4 : ℝ) ^ P.card * Real.sqrt Q *
            ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * (((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 8)) := by
          rw [sum_mul, mul_sum, ← sum_add_distrib]
          refine sum_congr rfl fun j _ => by ring
      _ ≤ (1 + Real.log Jm) * (2 / Real.sqrt X + 2 * (1 + Real.log Y) / Real.sqrt s) +
          2 * (1 + Real.log Y) * (4 : ℝ) ^ P.card * Real.sqrt Q * ((1 + Real.log Jm) * 2 ^ P.card) := by
          have h0 : 0 ≤ 2 / Real.sqrt X + 2 * (1 + Real.log Y) / Real.sqrt s := by positivity
          have hb : 0 ≤ 2 * (1 + Real.log Y) * (4 : ℝ) ^ P.card * Real.sqrt Q := by positivity
          exact add_le_add (mul_le_mul_of_nonneg_right hsum1 h0)
            (mul_le_mul_of_nonneg_left (hsum2.trans (mul_le_mul_of_nonneg_left hPi78 hlJ)) hb)
      _ = _ := by
          rw [show (8 : ℝ) ^ P.card = 4 ^ P.card * 2 ^ P.card by rw [← mul_pow]; norm_num]; ring
  -- assemble
  have hρ : ∀ (f : ℕ → ℝ), (∀ j, 0 ≤ f j) → ∑ ρ : ZMod M, ∑ j ∈ Icc 1 Jm, ‖A ρ j‖ * f j ≤
      M * (Ab * ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * f j) := by
    intro f hf
    calc ∑ ρ : ZMod M, ∑ j ∈ Icc 1 Jm, ‖A ρ j‖ * f j ≤ ∑ _ρ : ZMod M, Ab * ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * f j := by
          refine sum_le_sum fun ρ _ => ?_
          rw [mul_sum]
          refine sum_le_sum fun j hj => ?_
          have hj1 : 1 ≤ j := (mem_Icc.1 hj).1
          calc ‖A ρ j‖ * f j ≤ Ab / j * f j := mul_le_mul_of_nonneg_right (hA ρ j hj1) (hf j)
            _ = Ab * (1 / (j : ℝ) * f j) := by ring
      _ = M * (Ab * ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * f j) := by
          rw [sum_const, card_univ, ZMod.card, nsmul_eq_mul]
  have hfirst := hρ (fun j => Aω * Real.sqrt (2 * WPsi P (c j) X Y (Lw / Y))) (fun j => by positivity)
  have hsecond := hρ (fun _ => 1) (fun _ => by norm_num)
  simp only [mul_one] at hsecond
  have hM0 : (0 : ℝ) ≤ M := Nat.cast_nonneg _
  have hK0 : (0 : ℝ) ≤ K₁ := Nat.cast_nonneg _
  have e1 : ∑ ρ : ZMod M, ∑ j ∈ Icc 1 Jm, ‖A ρ j‖ * (Aω * Real.sqrt (2 * WPsi P (c j) X Y (Lw / Y))) =
      ∑ ρ : ZMod M, ∑ j ∈ Icc 1 Jm, ‖A ρ j‖ * (Real.exp 37.5 *
        (1 + Nat.log 2 (Nat.log 2 (2 * (max Nb Lw) ^ 2)) : ℝ) ^ 30) ^ 2 *
        Real.sqrt (2 * WPsi P (c j) X Y (Lw / Y)) := by
    refine sum_congr rfl fun ρ _ => sum_congr rfl fun j _ => by rw [hAω]; ring
  have hfirst' : ∑ ρ : ZMod M, ∑ j ∈ Icc 1 Jm, ‖A ρ j‖ * ((Real.exp 37.5 *
        (1 + Nat.log 2 (Nat.log 2 (2 * (max Nb Lw) ^ 2)) : ℝ) ^ 30) ^ 2 *
        Real.sqrt (2 * WPsi P (c j) X Y (Lw / Y))) ≤
      M * (Ab * (Aω * ((1 + Real.log Jm) *
        (2 / Real.sqrt X + 2 * (1 + Real.log Y) / Real.sqrt s +
          2 * (1 + Real.log Y) * (8 : ℝ) ^ P.card * Real.sqrt Q)))) := by
    refine hfirst.trans ?_
    apply mul_le_mul_of_nonneg_left _ hM0
    apply mul_le_mul_of_nonneg_left _ hAb
    rw [show ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * (Aω * Real.sqrt (2 * WPsi P (c j) X Y (Lw / Y))) =
        Aω * ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * Real.sqrt (2 * WPsi P (c j) X Y (Lw / Y)) by
      rw [mul_sum]; exact sum_congr rfl fun j _ => by ring]
    exact mul_le_mul_of_nonneg_left hS (by positivity)
  have hsecond' : ∑ ρ : ZMod M, ∑ j ∈ Icc 1 Jm, ‖A ρ j‖ ≤ M * (Ab * (1 + Real.log Jm)) :=
    hsecond.trans (mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left hsum1 hAb) hM0)
  have h12 : (0 : ℝ) ≤ 12.5 / X := by positivity
  calc K₁ * M * _ + _ * WU * (12.5 / X)
      ≤ K₁ * M * (M * (Ab * (Aω * ((1 + Real.log Jm) *
          (2 / Real.sqrt X + 2 * (1 + Real.log Y) / Real.sqrt s +
            2 * (1 + Real.log Y) * (8 : ℝ) ^ P.card * Real.sqrt Q))))) +
        M * (Ab * (1 + Real.log Jm)) * WU * (12.5 / X) := by
        gcongr
    _ = _ := by ring

end W

end GoldC.QuillonWEst

#print axioms GoldC.QuillonWEst.sqrt_WPsi_le
#print axioms GoldC.QuillonWEst.WTerm_le
