import PaperB.FixedQ.OneDimensionalFamilyPartition

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def pureLeftMovingTerm
    (q a h n : ℕ) : ℝ :=
  movingVCoeff q h n * fixedQRowDelta q a h n 1

theorem tsum_primeFinset_pureLeft_eq_moving
    (q a h : ℕ) :
    (∑' s : PrimeFinset, pureLeftPairTerm q a h s.1) =
      ∑' s : PrimeFinset,
        pureLeftMovingTerm q a h (primeSetProduct s.1) := by
  apply tsum_congr
  intro s
  exact pureLeftPairTerm_eq_moving_nat q a h s

theorem tsum_squarefree_pureLeftMoving_eq_primeFinset
    (q a h : ℕ) :
    (∑' n : SquarefreeNat, pureLeftMovingTerm q a h n.1) =
      ∑' s : PrimeFinset,
        pureLeftMovingTerm q a h (primeSetProduct s.1) := by
  have ht :=
    (Equiv.tsum_eq primeFinsetEquivSquarefreeNat
      (fun n : SquarefreeNat => pureLeftMovingTerm q a h n.1)).symm
  calc
    (∑' n : SquarefreeNat, pureLeftMovingTerm q a h n.1) =
        ∑' s : PrimeFinset,
          pureLeftMovingTerm q a h (primeFinsetEquivSquarefreeNat s).1 := ht
    _ = ∑' s : PrimeFinset,
          pureLeftMovingTerm q a h (primeSetProduct s.1) := by
      apply tsum_congr
      intro s
      rfl

theorem tsum_primeFinset_pureLeft_eq_squarefree_moving
    (q a h : ℕ) :
    (∑' s : PrimeFinset, pureLeftPairTerm q a h s.1) =
      ∑' n : SquarefreeNat, pureLeftMovingTerm q a h n.1 := by
  rw [tsum_primeFinset_pureLeft_eq_moving]
  exact (tsum_squarefree_pureLeftMoving_eq_primeFinset q a h).symm

#print axioms tsum_primeFinset_pureLeft_eq_moving
#print axioms tsum_squarefree_pureLeftMoving_eq_primeFinset
#print axioms tsum_primeFinset_pureLeft_eq_squarefree_moving

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma pureLeftPairTerm_eq_zero_of_not_primeFinset
    {q a h : ℕ} {e : Finset ℕ}
    (he : ¬ ∀ p ∈ e, p.Prime) :
    pureLeftPairTerm q a h e = 0 := by
  unfold pureLeftPairTerm pairCoefficient
  rw [if_neg]
  · simp
  · intro hA
    apply he
    intro p hp
    exact (hA p hp).1

theorem tsum_pureLeftPairTerm_eq_primeFinset
    (q a h : ℕ) :
    (∑' e : Finset ℕ, pureLeftPairTerm q a h e) =
      ∑' s : PrimeFinset, pureLeftPairTerm q a h s.1 := by
  let P : Set (Finset ℕ) := {e | ∀ p ∈ e, p.Prime}
  have hind :
      (∑' e : Finset ℕ, pureLeftPairTerm q a h e) =
        ∑' e : Finset ℕ, P.indicator (pureLeftPairTerm q a h) e := by
    apply tsum_congr
    intro e
    by_cases he : e ∈ P
    · simp [Set.indicator, he]
    · have hz : pureLeftPairTerm q a h e = 0 := by
        apply pureLeftPairTerm_eq_zero_of_not_primeFinset
        simpa [P] using he
      simp [Set.indicator, he, hz]
  rw [hind]
  rw [← tsum_subtype]
  rfl

lemma pureLeftMovingTerm_eq_zero_of_not_squarefree
    {q a h n : ℕ} (hn : ¬ Squarefree n) :
    pureLeftMovingTerm q a h n = 0 := by
  unfold pureLeftMovingTerm movingVCoeff
  by_cases hn0 : n = 0
  · simp [hn0]
  · rw [if_neg hn0]
    rw [if_neg]
    · simp
    · intro hs
      exact hn hs.1

theorem tsum_squarefree_moving_eq_nat
    (q a h : ℕ) :
    (∑' n : SquarefreeNat, pureLeftMovingTerm q a h n.1) =
      ∑' n : ℕ, pureLeftMovingTerm q a h n := by
  let S : Set ℕ := {n | Squarefree n}
  have hind :
      (∑' n : ℕ, S.indicator (pureLeftMovingTerm q a h) n) =
        ∑' n : ℕ, pureLeftMovingTerm q a h n := by
    apply tsum_congr
    intro n
    by_cases hn : n ∈ S
    · simp [Set.indicator, hn]
    · have hz : pureLeftMovingTerm q a h n = 0 := by
        apply pureLeftMovingTerm_eq_zero_of_not_squarefree
        simpa [S] using hn
      simp [Set.indicator, hn, hz]
  rw [← hind]
  rw [← tsum_subtype]
  rfl

theorem tsum_pureLeftPairTerm_eq_movingNat
    (q a h : ℕ) :
    (∑' e : Finset ℕ, pureLeftPairTerm q a h e) =
      ∑' n : ℕ,
        movingVCoeff q h n * fixedQRowDelta q a h n 1 := by
  rw [tsum_pureLeftPairTerm_eq_primeFinset]
  rw [tsum_primeFinset_pureLeft_eq_squarefree_moving]
  rw [tsum_squarefree_moving_eq_nat]
  rfl

#print axioms pureLeftPairTerm_eq_zero_of_not_primeFinset
#print axioms tsum_pureLeftPairTerm_eq_primeFinset
#print axioms pureLeftMovingTerm_eq_zero_of_not_squarefree
#print axioms tsum_squarefree_moving_eq_nat
#print axioms tsum_pureLeftPairTerm_eq_movingNat

end PaperB.FixedQ
