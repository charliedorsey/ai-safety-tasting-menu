import PaperB.FixedQ.H2BooleanETBridge

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def fixedProductBooleanSignFourierCoeff
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (t : ZMod (primeSetProduct S)) : ℂ := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  exact ((2 : ℂ) ^ S.card)⁻¹ *
    ∑ A ∈ S.powerset,
      ZMod.stdAddChar
        (t * (2 * (fixedProductCRTIdempotentNat S A :
          ZMod (primeSetProduct S)) - 1))

lemma fixedProductBooleanSignFourierCoeff_eq_char_mul_W
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)]
    (t : ZMod (primeSetProduct S)) :
    fixedProductBooleanSignFourierCoeff S hPrime t =
      ZMod.stdAddChar (-t) *
        fixedProductBooleanFourierCoeff S hPrime (2 * t) := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  unfold fixedProductBooleanSignFourierCoeff
  unfold fixedProductBooleanFourierCoeff
  have hpoint :
      ∀ A ∈ S.powerset,
        ZMod.stdAddChar
            (t * (2 * (fixedProductCRTIdempotentNat S A :
              ZMod (primeSetProduct S)) - 1)) =
          ZMod.stdAddChar (-t) *
            ZMod.stdAddChar
              ((2 * t) *
                (fixedProductCRTIdempotentNat S A :
                  ZMod (primeSetProduct S))) := by
    intro A hA
    rw [← AddChar.map_add_eq_mul]
    congr 1
    ring
  rw [show
    (∑ A ∈ S.powerset,
      ZMod.stdAddChar
        (t * (2 * (fixedProductCRTIdempotentNat S A :
          ZMod (primeSetProduct S)) - 1))) =
      ∑ A ∈ S.powerset,
        (ZMod.stdAddChar (-t) *
          ZMod.stdAddChar
            ((2 * t) *
              (fixedProductCRTIdempotentNat S A :
                ZMod (primeSetProduct S)))) by
        apply Finset.sum_congr rfl
        intro A hA
        exact hpoint A hA]
  rw [← Finset.mul_sum]
  ring

lemma norm_fixedProductBooleanSignFourierCoeff_eq_norm_W_two_mul
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (t : ZMod (primeSetProduct S)) :
    ‖fixedProductBooleanSignFourierCoeff S hPrime t‖ =
      ‖fixedProductBooleanFourierCoeff S hPrime (2 * t)‖ := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  rw [fixedProductBooleanSignFourierCoeff_eq_char_mul_W]
  rw [norm_mul, norm_stdAddChar_eq_one, one_mul]

#print axioms fixedProductBooleanSignFourierCoeff_eq_char_mul_W
#print axioms norm_fixedProductBooleanSignFourierCoeff_eq_norm_W_two_mul

end PaperB.FixedQ
