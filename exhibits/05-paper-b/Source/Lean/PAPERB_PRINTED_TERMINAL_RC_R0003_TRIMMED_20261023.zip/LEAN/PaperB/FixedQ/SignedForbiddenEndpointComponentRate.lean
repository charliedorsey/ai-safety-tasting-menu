import PaperB.FixedQ.PetermannMovingTransfer
import PaperB.FixedQ.FixedQReflection
import PaperB.FixedQ.SignedForbiddenEndpointAdapters
import PaperB.FixedQ.PureLeftTsumBridge
import PaperB.FixedQ.PetermannCorrectionL1

open Filter Real Asymptotics
open scoped BigOperators

namespace PaperB.FixedQ

/-- Vela socket: the ordinary omega Pétermann kernel has the frozen Walfisz
majorant, uniformly in character, shift, and partial upper limit. -/
def EndpointPetermannFixedPowerSpec (q : ℕ) : Prop :=
  ∃ C : ℝ, 0 ≤ C ∧
    ∀ (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
      (r : ℤ) (T : ℝ) (X : ℕ),
      (2 * (Nat.lcm 6 q) : ℝ) ≤ T →
      1 ≤ X →
      (X : ℝ) ≤ T →
      ‖petermannBaseKernelSum q PetermannBase.omega chi r T X‖ ≤
        C * petermannMajorant T

def signedForbiddenEndpointSupport
    (q H : ℕ) (d : Finset ℕ) : Set (Finset ℕ) :=
  {n | n ∈ activeOrdinaryTwoDimensionalSet q H ∧
    Disjoint d n ∧ n.Nonempty}

noncomputable def signedForbiddenMaskedPureLeft
    (q a H : ℕ) (d n : Finset ℕ) : ℝ :=
  (signedForbiddenEndpointSupport q H d).indicator
    (pureLeftPairTerm q a H) n

noncomputable def signedForbiddenMaskedDensity
    (q a H : ℕ) (d n : Finset ℕ) : ℝ :=
  (signedForbiddenEndpointSupport q H d).indicator
    (ordinaryEndpointDensityCorrection q a H) n

theorem dForbiddenBooleanLeftEndpointTerm_eq_masked_split
    (q a H : ℕ) (d n : Finset ℕ) :
    dForbiddenBooleanLeftEndpointTerm q a H d n =
      signedForbiddenMaskedPureLeft q a H d n -
        signedForbiddenMaskedDensity q a H d n := by
  classical
  by_cases hs : n ∈ signedForbiddenEndpointSupport q H d
  · have hs' :
        (n ∈ activeOrdinaryTwoDimensionalSet q H ∧ Disjoint d n) ∧
          n ∈ activeOrdinaryTwoDimensionalSet q H ∧ n.Nonempty := by
      simpa [signedForbiddenEndpointSupport] using hs
    have hbase :=
      dForbiddenBooleanLeftEndpointTerm_eq_masked_pureLeft_sub_density
        (q := q) (a := a) (H := H) (d := d) (n := n) hs'.1.1
    rw [signedForbiddenMaskedPureLeft, Set.indicator_of_mem hs,
      signedForbiddenMaskedDensity, Set.indicator_of_mem hs]
    simpa [hs'.1.2] using hbase
  · simp [signedForbiddenMaskedPureLeft, signedForbiddenMaskedDensity,
      Set.indicator, hs]
    have hs' :
        ¬ ((n ∈ activeOrdinaryTwoDimensionalSet q H ∧ Disjoint d n) ∧
          n ∈ activeOrdinaryTwoDimensionalSet q H ∧ n.Nonempty) := by
      simpa [signedForbiddenEndpointSupport] using hs
    simp [dForbiddenBooleanLeftEndpointTerm]
    aesop

theorem summable_signedForbiddenMaskedPureLeft
    (q a H : ℕ) (d : Finset ℕ) :
    Summable (signedForbiddenMaskedPureLeft q a H d) := by
  change Summable
    ((signedForbiddenEndpointSupport q H d).indicator
      (pureLeftPairTerm q a H))
  exact (summable_pureLeftPairTerm q a H).indicator
    (signedForbiddenEndpointSupport q H d)

lemma abs_signedForbiddenMaskedDensity_le_normalization
    {q a H : ℕ} (hq : 0 < q) (hH : 0 < H)
    (h2 : ¬ 2 ∣ q → 2 ∣ H)
    (d n : Finset ℕ) :
    |signedForbiddenMaskedDensity q a H d n| ≤
      fixedQDensityDefectUniformBound q *
        normalizationWeightMass q 1 n := by
  classical
  have hB0 : 0 ≤ fixedQDensityDefectUniformBound q := by
    unfold fixedQDensityDefectUniformBound
    positivity
  by_cases hs : n ∈ signedForbiddenEndpointSupport q H d
  · rw [signedForbiddenMaskedDensity, Set.indicator_of_mem hs]
    have hs' :
        (n ∈ activeOrdinaryTwoDimensionalSet q H ∧ Disjoint d n) ∧
          n ∈ activeOrdinaryTwoDimensionalSet q H ∧ n.Nonempty := by
      simpa [signedForbiddenEndpointSupport] using hs
    have hact := hs'.1.1
    have hA : ∀ p ∈ n, activeHighPrime q p := hact.2
    have hOrd : n ∈ ordinaryTwoDimensionalSet H := hact.1
    have hnoH : ∀ p ∈ n, ¬ p ∣ H :=
      ordinaryTwoDimensionalSet_iff.mp hOrd
    have hdef := abs_fixedQLowWeight_density_defect_le_uniform
      (q := q) (a := a) (h := H) hq hH h2
    have hw0 : 0 ≤ finiteOmegaWeightReal n :=
      finiteOmegaWeightReal_nonneg_of_active hA
    have hp0 : 0 < primeSetProduct n :=
      primeSetProduct_pos (fun p hp => (hA p hp).1)
    have hpR : 0 < (primeSetProduct n : ℝ) := by exact_mod_cast hp0
    have hnormH := normalizationWeightMass_eq_ordinary_boolean_weight
      (q := q) (h := H) (e := n) hA hnoH
    have hno1 : ∀ p ∈ n, ¬ p ∣ 1 := by
      intro p hp hpd
      have hp5 := (hA p hp).2.1
      have : p ≤ 1 := Nat.le_of_dvd (by norm_num) hpd
      omega
    have hnorm1 := normalizationWeightMass_eq_ordinary_boolean_weight
      (q := q) (h := 1) (e := n) hA hno1
    have hnormeq :
        normalizationWeightMass q H n =
          normalizationWeightMass q 1 n := by
      rw [hnormH, hnorm1]
    unfold ordinaryEndpointDensityCorrection
    rw [abs_mul, abs_div, abs_of_nonneg hw0, abs_of_pos hpR]
    change
      finiteOmegaWeightReal n *
          (|rowWeightMass (fixedQLowWeight q a H) H -
            (admissibleInteriorCount q a H : ℝ)| /
            (primeSetProduct n : ℝ)) ≤ _
    have hpow : (1 : ℝ) ≤ (2 : ℝ) ^ n.card := by
      exact one_le_pow₀ (by norm_num)
    calc
      finiteOmegaWeightReal n *
          (|rowWeightMass (fixedQLowWeight q a H) H -
            (admissibleInteriorCount q a H : ℝ)| /
          (primeSetProduct n : ℝ))
        ≤ finiteOmegaWeightReal n *
            fixedQDensityDefectUniformBound q /
            (primeSetProduct n : ℝ) := by
          have hdiv :
              |rowWeightMass (fixedQLowWeight q a H) H -
                  (admissibleInteriorCount q a H : ℝ)| /
                  (primeSetProduct n : ℝ) ≤
                fixedQDensityDefectUniformBound q /
                  (primeSetProduct n : ℝ) :=
            div_le_div_of_nonneg_right hdef hpR.le
          simpa [mul_div_assoc] using
            mul_le_mul_of_nonneg_left hdiv hw0
      _ ≤ fixedQDensityDefectUniformBound q *
            (((2 : ℝ) ^ n.card * finiteOmegaWeightReal n) /
              (primeSetProduct n : ℝ)) := by
          have hB0 : 0 ≤ fixedQDensityDefectUniformBound q := by
            unfold fixedQDensityDefectUniformBound
            positivity
          have hfrac0 :
              0 ≤ finiteOmegaWeightReal n / (primeSetProduct n : ℝ) :=
            div_nonneg hw0 hpR.le
          calc
            finiteOmegaWeightReal n *
                fixedQDensityDefectUniformBound q /
                (primeSetProduct n : ℝ)
              = fixedQDensityDefectUniformBound q *
                  (finiteOmegaWeightReal n /
                    (primeSetProduct n : ℝ)) := by ring
            _ ≤ fixedQDensityDefectUniformBound q *
                  ((2 : ℝ) ^ n.card *
                    (finiteOmegaWeightReal n /
                      (primeSetProduct n : ℝ))) := by
                apply mul_le_mul_of_nonneg_left _ hB0
                calc
                  finiteOmegaWeightReal n /
                      (primeSetProduct n : ℝ)
                    = 1 * (finiteOmegaWeightReal n /
                      (primeSetProduct n : ℝ)) := by ring
                  _ ≤ (2 : ℝ) ^ n.card *
                      (finiteOmegaWeightReal n /
                        (primeSetProduct n : ℝ)) :=
                    mul_le_mul_of_nonneg_right hpow hfrac0
            _ = fixedQDensityDefectUniformBound q *
                (((2 : ℝ) ^ n.card * finiteOmegaWeightReal n) /
                  (primeSetProduct n : ℝ)) := by ring
      _ = fixedQDensityDefectUniformBound q *
            normalizationWeightMass q 1 n := by
          rw [hnorm1]
          simp [primeSetProduct]
  · simp [signedForbiddenMaskedDensity, Set.indicator, hs]
    exact mul_nonneg hB0 (normalizationWeightMass_nonneg q 1 n)

theorem summable_signedForbiddenMaskedDensity
    {q a H : ℕ} (hq : 0 < q) (hH : 0 < H)
    (h2 : ¬ 2 ∣ q → 2 ∣ H) (d : Finset ℕ) :
    Summable (signedForbiddenMaskedDensity q a H d) := by
  apply summable_of_abs_le_normalizationWeightMass
    q 1 (fixedQDensityDefectUniformBound q)
  · unfold fixedQDensityDefectUniformBound
    positivity
  · intro n
    exact abs_signedForbiddenMaskedDensity_le_normalization
      hq hH h2 d n

theorem abs_tsum_signedForbiddenMaskedDensity_le
    {q a H : ℕ} (hq : 0 < q) (hH : 0 < H)
    (h2 : ¬ 2 ∣ q → 2 ∣ H) (d : Finset ℕ) :
    |∑' n : Finset ℕ, signedForbiddenMaskedDensity q a H d n| ≤
      fixedQDensityDefectUniformBound q * petermannCorrectionL1Bound q := by
  let B : ℝ := fixedQDensityDefectUniformBound q
  have hB0 : 0 ≤ B := by
    dsimp [B]
    unfold fixedQDensityDefectUniformBound
    positivity
  have hs := summable_signedForbiddenMaskedDensity
    (q := q) (a := a) (H := H) hq hH h2 d
  have hmajor :
      Summable (fun n : Finset ℕ =>
        B * normalizationWeightMass q 1 n) :=
    (summable_normalizationWeightMass q 1).mul_left B
  have hpoint : ∀ n : Finset ℕ,
      ‖signedForbiddenMaskedDensity q a H d n‖ ≤
        B * normalizationWeightMass q 1 n := by
    intro n
    simpa [B, Real.norm_eq_abs] using
      abs_signedForbiddenMaskedDensity_le_normalization
        (q := q) (a := a) (H := H) hq hH h2 d n
  rw [← Real.norm_eq_abs]
  calc
    ‖∑' n : Finset ℕ, signedForbiddenMaskedDensity q a H d n‖
      ≤ ∑' n : Finset ℕ,
          ‖signedForbiddenMaskedDensity q a H d n‖ :=
        norm_tsum_le_tsum_norm hs.norm
    _ ≤ ∑' n : Finset ℕ,
          B * normalizationWeightMass q 1 n :=
        hs.norm.tsum_le_tsum hpoint hmajor
    _ = B * (∑' n : Finset ℕ, normalizationWeightMass q 1 n) := by
        rw [tsum_mul_left]
    _ = fixedQDensityDefectUniformBound q *
          petermannCorrectionL1Bound q := by
        rfl

#print axioms abs_tsum_signedForbiddenMaskedDensity_le

theorem summable_dForbiddenBooleanLeftEndpointTerm
    {q a H : ℕ} (hq : 0 < q) (hH : 0 < H)
    (h2 : ¬ 2 ∣ q → 2 ∣ H) (d : Finset ℕ) :
    Summable (dForbiddenBooleanLeftEndpointTerm q a H d) := by
  have hp := summable_signedForbiddenMaskedPureLeft q a H d
  have hd := summable_signedForbiddenMaskedDensity
    (q := q) (a := a) (H := H) hq hH h2 d
  exact (hp.sub hd).congr (fun n =>
    (dForbiddenBooleanLeftEndpointTerm_eq_masked_split q a H d n).symm)



theorem endpoint_finiteOmega_mul_empty_partition_eq_reflected_pureLeft_sub_density
    {q a r H : ℕ} {n : Finset ℕ}
    (hact : n ∈ activeOrdinaryTwoDimensionalSet q H)
    (hreflect : ∀ z ∈ Finset.Ioo 0 H,
      q.Coprime (a + (H - z)) ↔ q.Coprime (r + z)) :
    finiteOmegaWeightReal n *
        fixedProductPartitionDiscrepancy
          (fixedQLowWeight q a H) H n ∅ =
      pureLeftPairTerm q r H n -
        ordinaryEndpointDensityCorrection q r H n := by
  have hrefW :
      ∀ z ∈ Finset.Ioo 0 H,
        fixedQLowWeight q a H (H - z) =
          fixedQLowWeight q r H z := by
    intro z hz
    exact fixedQLowWeight_reflect_of_coprime
      (Nat.le_of_lt (Finset.mem_Ioo.mp hz).2)
      (hreflect z hz)
  rw [fixedProductPartitionDiscrepancy_empty_left]
  rw [rowDiscrepancy_reflect
    (fixedQLowWeight q a H) (fixedQLowWeight q r H)
    H 1 (primeSetProduct n) hrefW]
  have hleft :=
    finiteOmega_mul_full_partition_eq_pureLeft_sub_density
      (q := q) (a := r) (H := H) (n := n) hact
  rw [fixedProductPartitionDiscrepancy_full_left] at hleft
  exact hleft

theorem endpoint_right_eq_masked_reflected_pureLeft_sub_density
    {q a r H : ℕ} {d n : Finset ℕ}
    (hact : n ∈ activeOrdinaryTwoDimensionalSet q H)
    (hreflect : ∀ z ∈ Finset.Ioo 0 H,
      q.Coprime (a + (H - z)) ↔ q.Coprime (r + z)) :
    dForbiddenBooleanRightEndpointTerm q a H d n =
      if Disjoint d n then
        pureLeftPairTerm q r H n -
          ordinaryEndpointDensityCorrection q r H n
      else 0 := by
  classical
  by_cases hdis : Disjoint d n
  · by_cases hne : n.Nonempty
    · rw [dForbiddenBooleanRightEndpointTerm, if_pos ⟨hdis, hne⟩]
      rw [Set.indicator_of_mem hact]
      rw [if_pos hdis]
      exact endpoint_finiteOmega_mul_empty_partition_eq_reflected_pureLeft_sub_density
        hact hreflect
    · have hn0 : n = ∅ := Finset.not_nonempty_iff_eq_empty.mp hne
      subst n
      have hzero :
          pureLeftPairTerm q r H ∅ -
              ordinaryEndpointDensityCorrection q r H ∅ = 0 := by
        have hmain :=
          endpoint_finiteOmega_mul_empty_partition_eq_reflected_pureLeft_sub_density
            (q := q) (a := a) (r := r) (H := H) (n := ∅)
            hact hreflect
        rw [fixedProductPartitionDiscrepancy_empty_left] at hmain
        have hp0 : primeSetProduct (∅ : Finset ℕ) = 1 := by
          simp [primeSetProduct]
        rw [hp0, rowDiscrepancy_one_one_zero] at hmain
        simpa using hmain.symm
      rw [dForbiddenBooleanRightEndpointTerm]
      simp [hdis, hzero]
  · simp [dForbiddenBooleanRightEndpointTerm, hdis]


theorem dForbiddenBooleanRightEndpointTerm_eq_reflected_left
    {q a H : ℕ} (hq : 0 < q) (d n : Finset ℕ) :
    let r := PaperB.Closure.reflectedResidue q (a + H)
    dForbiddenBooleanRightEndpointTerm q a H d n =
      dForbiddenBooleanLeftEndpointTerm q r H d n := by
  classical
  dsimp
  let r := PaperB.Closure.reflectedResidue q (a + H)
  have hreflect :
      ∀ z ∈ Finset.Ioo 0 H,
        q.Coprime (a + (H - z)) ↔ q.Coprime (r + z) := by
    dsimp [r]
    exact PaperB.Closure.reflected_coprime_equiv hq
      (Nat.ModEq.refl (a + H))
  by_cases hact : n ∈ activeOrdinaryTwoDimensionalSet q H
  · have hr :=
      endpoint_right_eq_masked_reflected_pureLeft_sub_density
        (q := q) (a := a) (r := r) (H := H) (d := d) (n := n)
        hact hreflect
    have hl :=
      dForbiddenBooleanLeftEndpointTerm_eq_masked_pureLeft_sub_density
        (q := q) (a := r) (H := H) (d := d) (n := n) hact
    exact hr.trans hl.symm
  · simp [dForbiddenBooleanRightEndpointTerm,
      dForbiddenBooleanLeftEndpointTerm, Set.indicator, hact]

theorem summable_dForbiddenBooleanRightEndpointTerm
    {q a H : ℕ} (hq : 0 < q) (hH : 0 < H)
    (h2 : ¬ 2 ∣ q → 2 ∣ H) (d : Finset ℕ) :
    Summable (dForbiddenBooleanRightEndpointTerm q a H d) := by
  let r := PaperB.Closure.reflectedResidue q (a + H)
  have hl :=
    summable_dForbiddenBooleanLeftEndpointTerm
      (q := q) (a := r) (H := H) hq hH h2 d
  exact hl.congr (fun n => by
    simpa [r] using
      (dForbiddenBooleanRightEndpointTerm_eq_reflected_left
        (q := q) (a := a) (H := H) hq d n).symm)

#print axioms dForbiddenBooleanLeftEndpointTerm_eq_masked_split
#print axioms summable_signedForbiddenMaskedPureLeft
#print axioms abs_signedForbiddenMaskedDensity_le_normalization
#print axioms summable_signedForbiddenMaskedDensity
#print axioms summable_dForbiddenBooleanLeftEndpointTerm
#print axioms dForbiddenBooleanRightEndpointTerm_eq_reflected_left
#print axioms summable_dForbiddenBooleanRightEndpointTerm


end PaperB.FixedQ
