import OrielUpper.Row

/-!
# Oriel Upper — variation of `k ↦ ψ(X/(e k))/(e k)`

With `g k = ψ_{v,t}(X/(e k))/(e k)` (`v, t` units, `m` coprime to `P`):

`|g b| + ∑_{a<k<b} |g(k+1) - g k| ≤ B/(e(a+1)) · (2 X/(e(a+1) m) + 4P + 5)`.

The counting function `N(x) = #{u ≤ x : H ≡ t u (m)}` telescopes, so no
per-step `+1` loss occurs.
-/

open Finset

namespace OrielUpper

variable {P : ℕ} [NeZero P]

/-- Residue reformulation of the row condition. -/
lemma row_cond_iff {m H : ℕ} [NeZero m] (tu : (ZMod m)ˣ) (u : ℕ) :
    ((H : ZMod m) = (tu : ZMod m) * (u : ZMod m)) ↔
      u % m = (((tu⁻¹ : (ZMod m)ˣ) : ZMod m) * (H : ZMod m)).val := by
  constructor
  · intro h
    have : (u : ZMod m) = ((tu⁻¹ : (ZMod m)ˣ) : ZMod m) * (H : ZMod m) := by
      rw [h, ← mul_assoc, ← Units.val_mul, inv_mul_cancel, Units.val_one, one_mul]
    rw [← ZMod.val_natCast, this]
  · intro h
    have : (u : ZMod m) = ((tu⁻¹ : (ZMod m)ˣ) : ZMod m) * (H : ZMod m) := by
      rw [← ZMod.natCast_zmod_val (((tu⁻¹ : (ZMod m)ˣ) : ZMod m) * (H : ZMod m)), ← h,
        ZMod.natCast_mod]
    rw [this, ← mul_assoc, ← Units.val_mul, mul_inv_cancel, Units.val_one, one_mul]

/-- Counting function of the row support up to `x`. -/
noncomputable def rowN (m H : ℕ) (t : ZMod m) (x : ℝ) : ℕ :=
  ((Icc 1 ⌊x⌋₊).filter (fun u : ℕ => (H : ZMod m) = t * (u : ZMod m))).card

lemma rowN_mono {m H : ℕ} {t : ZMod m} {x x' : ℝ} (h : x' ≤ x) :
    rowN m H t x' ≤ rowN m H t x := by
  unfold rowN
  apply card_le_card
  intro u hu
  simp only [mem_filter, mem_Icc] at hu ⊢
  exact ⟨⟨hu.1.1, hu.1.2.trans (Nat.floor_le_floor h)⟩, hu.2⟩

lemma rowN_le {m H : ℕ} [NeZero m] {t : ZMod m} (ht : IsUnit t) {x : ℝ} (hx : 0 ≤ x) :
    (rowN m H t x : ℝ) ≤ x / m + 1 := by
  have hm : 0 < m := NeZero.pos m
  have hmr : (0 : ℝ) < m := by exact_mod_cast hm
  obtain ⟨tu, rfl⟩ := ht
  set u0 := (((tu⁻¹ : (ZMod m)ˣ) : ZMod m) * (H : ZMod m)).val
  have hu0 : u0 < m := ZMod.val_lt _
  have hfilt : (Icc 1 ⌊x⌋₊).filter (fun u : ℕ => (H : ZMod m) = (tu : ZMod m) * (u : ZMod m)) =
      (Icc 1 ⌊x⌋₊).filter (fun u => u % m = u0) := by
    apply filter_congr; intro u _; exact row_cond_iff tu u
  have hcard : (rowN m H (tu : ZMod m) x : ℝ) = ((kHi ⌊x⌋₊ m u0 - kLo u0 : ℕ) : ℝ) := by
    unfold rowN
    rw [hfilt]
    have := oriel_sum_filter_mod hm hu0 ⌊x⌋₊ (fun _ => (1 : ℝ))
    simp only [sum_const, nsmul_eq_mul, mul_one, Nat.card_Ico] at this
    exact_mod_cast this
  have hc := oriel_count_mod_close hm hu0 ⌊x⌋₊
  rw [hcard]
  have : (⌊x⌋₊ : ℝ) / m ≤ x / m := div_le_div_of_nonneg_right (Nat.floor_le hx) hmr.le
  rw [abs_le] at hc
  linarith [hc.2]

/-- Increment bound for the uncentered row sum. -/
lemma row_increment {m H : ℕ} {Λ : ZMod P → ℝ} {B : ℝ} (hB : ∀ z, |Λ z| ≤ B)
    {α β v : ZMod P} {t : ZMod m} {x x' : ℝ} (h : x' ≤ x) :
    |∑ u ∈ Icc 1 ⌊x⌋₊, rowF m H Λ α β v t u - ∑ u ∈ Icc 1 ⌊x'⌋₊, rowF m H Λ α β v t u| ≤
      B * ((rowN m H t x : ℝ) - rowN m H t x') := by
  have hfl : ⌊x'⌋₊ ≤ ⌊x⌋₊ := Nat.floor_le_floor h
  have hsplit : ∑ u ∈ Icc 1 ⌊x⌋₊, rowF m H Λ α β v t u =
      ∑ u ∈ Icc 1 ⌊x'⌋₊, rowF m H Λ α β v t u + ∑ u ∈ Ioc ⌊x'⌋₊ ⌊x⌋₊, rowF m H Λ α β v t u := by
    rw [← sum_union]
    · congr 1; ext u; simp only [mem_union, mem_Icc, mem_Ioc]; omega
    · rw [disjoint_left]; intro u h1 h2; simp only [mem_Icc, mem_Ioc] at h1 h2; omega
  have hU : Icc 1 ⌊x⌋₊ = Icc 1 ⌊x'⌋₊ ∪ Ioc ⌊x'⌋₊ ⌊x⌋₊ := by
    ext u; simp only [mem_union, mem_Icc, mem_Ioc]; omega
  have hD : Disjoint (Icc 1 ⌊x'⌋₊) (Ioc ⌊x'⌋₊ ⌊x⌋₊) := by
    rw [disjoint_left]; intro u h1 h2; simp only [mem_Icc, mem_Ioc] at h1 h2; omega
  have hN : (rowN m H t x : ℝ) - rowN m H t x' =
      ((Ioc ⌊x'⌋₊ ⌊x⌋₊).filter (fun u : ℕ => (H : ZMod m) = t * (u : ZMod m))).card := by
    unfold rowN
    rw [hU, filter_union, card_union_of_disjoint (disjoint_filter_filter hD)]
    push_cast; ring
  rw [hsplit, add_sub_cancel_left, hN]
  calc |∑ u ∈ Ioc ⌊x'⌋₊ ⌊x⌋₊, rowF m H Λ α β v t u|
      ≤ ∑ u ∈ Ioc ⌊x'⌋₊ ⌊x⌋₊, |rowF m H Λ α β v t u| := abs_sum_le_sum_abs _ _
    _ ≤ ∑ u ∈ Ioc ⌊x'⌋₊ ⌊x⌋₊, (if (H : ZMod m) = t * u then B else 0) := by
        apply sum_le_sum; intro u _
        unfold rowF
        split_ifs
        · rw [mul_one]; exact hB _
        · simp
    _ = B * ((Ioc ⌊x'⌋₊ ⌊x⌋₊).filter (fun u : ℕ => (H : ZMod m) = t * (u : ZMod m))).card := by
        rw [← sum_filter, sum_const, nsmul_eq_mul, mul_comm]

end OrielUpper
