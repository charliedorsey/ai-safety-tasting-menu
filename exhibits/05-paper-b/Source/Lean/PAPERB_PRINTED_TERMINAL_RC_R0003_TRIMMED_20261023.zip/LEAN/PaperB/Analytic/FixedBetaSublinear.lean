import PaperB.Analytic.FixedBetaScaling
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics

namespace PaperB.Analytic

open Real Filter

theorem rpow_lt_one_is_sublinear
    {theta eps : ℝ}
    (htheta : theta < 1) (heps : 0 < eps) :
    ∃ W0 : ℝ, ∀ W : ℝ, W0 ≤ W → 1 ≤ W →
      W ^ theta ≤ eps * W := by
  have hdelta : 0 < 1 - theta := sub_pos.mpr htheta
  have htend := tendsto_rpow_neg_atTop hdelta
  have hev :
      ∀ᶠ W : ℝ in Filter.atTop,
        W ^ (-(1 - theta)) < eps :=
    (tendsto_order.mp htend).2 eps heps
  rw [Filter.eventually_atTop] at hev
  rcases hev with ⟨W0, hW0⟩
  refine ⟨W0, ?_⟩
  intro W hWW0 hW1
  have hdecay : W ^ (theta - 1) < eps := by
    have h := hW0 W hWW0
    convert h using 1 <;> ring_nf
  have hWpos : 0 < W := lt_of_lt_of_le zero_lt_one hW1
  have hid : W ^ theta = W * W ^ (theta - 1) := by
    calc
      W ^ theta = W ^ ((theta - 1) + 1) := by congr 1 <;> ring
      _ = W ^ (theta - 1) * W ^ (1 : ℝ) := by
        rw [Real.rpow_add hWpos]
      _ = W * W ^ (theta - 1) := by
        rw [Real.rpow_one]
        ring
  rw [hid]
  simpa [mul_comm] using
    (mul_le_mul_of_nonneg_left hdecay.le hWpos.le)

theorem fixedBeta_two_powers_sublinear
    {beta : ℝ} (hb0 : 0 < beta) (hb1 : beta < 1)
    {eps : ℝ} (heps : 0 < eps) :
    ∃ k : ℕ, 2 ≤ k ∧
      ∃ W0 : ℝ, ∀ W : ℝ, W0 ≤ W → 1 ≤ W →
        W ^ fixedBetaFirstExponent beta k ≤ eps * W ∧
        W ^ fixedBetaSecondExponent beta k ≤ eps * W := by
  obtain ⟨k, hk, hfirst, hsecond⟩ :=
    exists_fixedBeta_exponent_ledger hb0 hb1
  obtain ⟨W01, hW01⟩ :=
    rpow_lt_one_is_sublinear hfirst heps
  obtain ⟨W02, hW02⟩ :=
    rpow_lt_one_is_sublinear hsecond heps
  refine ⟨k, hk, max W01 W02, ?_⟩
  intro W hW hW1
  constructor
  · exact hW01 W (le_trans (le_max_left _ _) hW) hW1
  · exact hW02 W (le_trans (le_max_right _ _) hW) hW1

#print axioms rpow_lt_one_is_sublinear
#print axioms fixedBeta_two_powers_sublinear

end PaperB.Analytic
