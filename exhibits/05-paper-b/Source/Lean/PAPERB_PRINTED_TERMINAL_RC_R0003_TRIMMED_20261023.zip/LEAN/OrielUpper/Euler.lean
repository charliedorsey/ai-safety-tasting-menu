import OrielUpper.Weights
import OrielUpper.Mertens
import Mathlib.NumberTheory.EulerProduct.Basic
import Mathlib.NumberTheory.SmoothNumbers
import Mathlib.NumberTheory.PrimeCounting
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.SpecialFunctions.Pow.Real

/-!
# Oriel Upper — Euler inequality and the A_σ envelopes

* `oriel_euler_le`: for multiplicative nonnegative `f` vanishing on cubes of primes,
  `∑_{1 ≤ n ≤ N} f n ≤ ∏_{p ≤ N} (1 + f p + f p²)`.
* `oriel_Asigma_le`: for `σ ∈ [3/4,1]`,
  `∑_{1≤e≤N} |κ_F(e)| e^{-σ} ≤ 4 exp(10 Z₃₂) ∏_{p ∣ F} (1 + p^{-σ})`.
* `oriel_sum_rpow_neg_three_quarters`: `∑_{p∈S} p^{-3/4} ≤ 4 |S|^{1/4}`.
-/

open Finset Real ArithmeticFunction

namespace OrielUpper

/-! ### Euler inequality -/

theorem oriel_euler_le (f : ℕ → ℝ) (hf0 : ∀ n, 0 ≤ f n) (hf1 : f 1 = 1)
    (hmul : ∀ {m n : ℕ}, Nat.Coprime m n → f (m * n) = f m * f n)
    (hcube : ∀ {p k : ℕ}, p.Prime → 3 ≤ k → f (p ^ k) = 0) (N : ℕ) :
    ∑ n ∈ Icc 1 N, f n ≤ ∏ p ∈ (N + 1).primesBelow, (1 + f p + f (p ^ 2)) := by
  have hloc : ∀ {p : ℕ}, p.Prime → ∀ k ∉ range 3, f (p ^ k) = 0 := by
    intro p hp k hk
    exact hcube hp (by simpa using hk)
  have hsum : ∀ {p : ℕ}, p.Prime → Summable (fun n : ℕ ↦ ‖f (p ^ n)‖) := by
    intro p hp
    apply summable_of_ne_finset_zero (s := range 3)
    intro k hk; simp [hloc hp k hk]
  obtain ⟨hS, hH⟩ :=
    EulerProduct.summable_and_hasSum_smoothNumbers_prod_primesBelow_tsum hf1 hmul hsum (N + 1)
  have hlocal : ∀ p ∈ (N + 1).primesBelow, ∑' n : ℕ, f (p ^ n) = 1 + f p + f (p ^ 2) := by
    intro p hp
    have hpp : p.Prime := (Nat.mem_primesBelow.mp hp).2
    rw [tsum_eq_sum (s := range 3) (fun k hk => hloc hpp k hk)]
    simp [sum_range_succ, hf1]
  rw [prod_congr rfl hlocal] at hH
  have hS' : Summable (fun m : (N + 1).smoothNumbers ↦ f m) := by
    refine Summable.of_norm ?_
    simpa using hS
  -- embed `Icc 1 N` into the smooth numbers
  let emb : {n // n ∈ Icc 1 N} ↪ (N + 1).smoothNumbers :=
    ⟨fun n => ⟨n.1, Nat.mem_smoothNumbers_of_lt (by have := (mem_Icc.mp n.2).1; omega)
        (by have := (mem_Icc.mp n.2).2; omega)⟩,
     fun a b h => Subtype.ext (by simpa using congrArg Subtype.val h)⟩
  calc ∑ n ∈ Icc 1 N, f n = ∑ n ∈ (Icc 1 N).attach, f n.1 := (sum_attach _ _).symm
    _ = ∑ m ∈ (Icc 1 N).attach.map emb, f m.1 := by rw [sum_map]; rfl
    _ ≤ ∑' m : (N + 1).smoothNumbers, f m :=
        Summable.sum_le_tsum _ (fun i _ => hf0 _) hS'
    _ = _ := hH.tsum_eq

/-! ### Local factor bounds -/

lemma oriel_allowed_local_le {p : ℕ} (hp5 : 5 ≤ p) {σ : ℝ} (hσ1 : 3 / 4 ≤ σ) (hσ2 : σ ≤ 1) :
    (3 / ((p : ℝ) - 3)) * (p : ℝ) ^ (-σ) + ((p : ℝ) / ((p : ℝ) - 3)) * ((p : ℝ) ^ 2) ^ (-σ) ≤
      10 * (p : ℝ) ^ (-(3 / 2 : ℝ)) := by
  have hp : (5 : ℝ) ≤ p := by exact_mod_cast hp5
  have hp0 : (0 : ℝ) < p := by linarith
  have hp1 : (1 : ℝ) ≤ p := by linarith
  have hd : (0 : ℝ) < (p : ℝ) - 3 := by linarith
  -- 1/(p-3) ≤ 5/(2p)
  have hinv : 1 / ((p : ℝ) - 3) ≤ 5 / (2 * p) := by
    rw [div_le_div_iff₀ hd (by positivity)]; linarith
  have hsq : ((p : ℝ) ^ 2) ^ (-σ) = (p : ℝ) ^ (-(2 * σ)) := by
    rw [← Real.rpow_natCast, ← Real.rpow_mul hp0.le]; ring_nf
  rw [hsq]
  -- p^(-σ) / p ≤ p^(-3/2) and p^(-2σ) ≤ p^(-3/2)
  have e1 : (p : ℝ) ^ (-σ) * (1 / p) ≤ (p : ℝ) ^ (-(3 / 2 : ℝ)) := by
    have : (p : ℝ) ^ (-σ) * (1 / p) = (p : ℝ) ^ (-σ - 1) := by
      rw [Real.rpow_sub hp0, Real.rpow_one]; ring
    rw [this]; apply Real.rpow_le_rpow_of_exponent_le hp1; linarith
  have e2 : (p : ℝ) ^ (-(2 * σ)) ≤ (p : ℝ) ^ (-(3 / 2 : ℝ)) := by
    apply Real.rpow_le_rpow_of_exponent_le hp1; linarith
  have hpos1 : 0 ≤ (p : ℝ) ^ (-σ) := by positivity
  have hpos2 : 0 ≤ (p : ℝ) ^ (-(2 * σ)) := by positivity
  have t1 : (3 / ((p : ℝ) - 3)) * (p : ℝ) ^ (-σ) ≤ (15 / 2) * ((p : ℝ) ^ (-σ) * (1 / p)) := by
    have : 3 / ((p : ℝ) - 3) ≤ 3 * (5 / (2 * p)) := by
      rw [show 3 / ((p : ℝ) - 3) = 3 * (1 / ((p : ℝ) - 3)) by ring]; gcongr
    calc (3 / ((p : ℝ) - 3)) * (p : ℝ) ^ (-σ) ≤ (3 * (5 / (2 * p))) * (p : ℝ) ^ (-σ) := by gcongr
      _ = _ := by field_simp; norm_num
  have t2 : ((p : ℝ) / ((p : ℝ) - 3)) * (p : ℝ) ^ (-(2 * σ)) ≤ (5 / 2) * (p : ℝ) ^ (-(2 * σ)) := by
    have : (p : ℝ) / ((p : ℝ) - 3) ≤ 5 / 2 := by
      rw [div_le_iff₀ hd]; linarith
    gcongr
  nlinarith

/-- The convergent constant `Z₃₂ = ∑ n^{-3/2}`. -/
noncomputable def Z32 : ℝ := ∑' n : ℕ, ((n : ℝ) ^ (3 / 2 : ℝ))⁻¹

lemma summable_Z32 : Summable (fun n : ℕ => ((n : ℝ) ^ (3 / 2 : ℝ))⁻¹) :=
  Real.summable_nat_rpow_inv.mpr (by norm_num)

lemma sum_rpow_neg_three_halves_le (s : Finset ℕ) :
    ∑ p ∈ s, (p : ℝ) ^ (-(3 / 2 : ℝ)) ≤ Z32 := by
  have : ∀ p : ℕ, (p : ℝ) ^ (-(3 / 2 : ℝ)) = ((p : ℝ) ^ (3 / 2 : ℝ))⁻¹ := by
    intro p; rw [Real.rpow_neg (Nat.cast_nonneg p)]
  simp_rw [this]
  exact Summable.sum_le_tsum s (fun i _ => by positivity) summable_Z32

/-- Product of `1 + 10 p^{-3/2}` is bounded by `exp(10 Z₃₂)`. -/
lemma prod_allowed_le (s : Finset ℕ) :
    ∏ p ∈ s, (1 + 10 * (p : ℝ) ^ (-(3 / 2 : ℝ))) ≤ Real.exp (10 * Z32) := by
  calc ∏ p ∈ s, (1 + 10 * (p : ℝ) ^ (-(3 / 2 : ℝ)))
      ≤ Real.exp (∑ p ∈ s, 10 * (p : ℝ) ^ (-(3 / 2 : ℝ))) :=
        Real.prod_one_add_le_exp_sum s (fun p => by positivity)
    _ ≤ Real.exp (10 * Z32) := by
        apply Real.exp_le_exp.mpr
        rw [← mul_sum]
        gcongr
        exact sum_rpow_neg_three_halves_le s

/-- `∏_{A∪B} f ≤ ∏_A f ∏_B f` when `f ≥ 1`. -/
lemma prod_union_le_mul_prod_of_one_le' {A B : Finset ℕ} {f : ℕ → ℝ} (hf : ∀ p, 1 ≤ f p) :
    ∏ p ∈ A ∪ B, f p ≤ (∏ p ∈ A, f p) * ∏ p ∈ B, f p := by
  rw [← union_sdiff_self_eq_union, prod_union disjoint_sdiff]
  have h0 : 0 ≤ ∏ p ∈ A, f p := prod_nonneg (fun p _ => le_trans zero_le_one (hf p))
  apply mul_le_mul_of_nonneg_left _ h0
  exact prod_le_prod_of_subset_of_one_le₀ sdiff_subset (fun p _ => le_trans zero_le_one (hf p))
    (fun p _ _ => hf p)

/-! ### The A_σ envelope -/

/-- `A_σ(F,N) = ∑_{1 ≤ e ≤ N} |κ_F(e)| e^{-σ}`. -/
noncomputable def Asig (F N : ℕ) (σ : ℝ) : ℝ :=
  ∑ e ∈ Icc 1 N, |KW F e| * (e : ℝ) ^ (-σ)

lemma Asig_nonneg (F N : ℕ) (σ : ℝ) : 0 ≤ Asig F N σ :=
  sum_nonneg (fun e _ => mul_nonneg (abs_nonneg _) (by positivity))

theorem oriel_Asig_le_prod (F N : ℕ) {σ : ℝ} (hσ1 : 3 / 4 ≤ σ) (hσ2 : σ ≤ 1) :
    Asig F N σ ≤ ∏ p ∈ (N + 1).primesBelow,
      (1 + |KW F p| * (p : ℝ) ^ (-σ) + |KW F (p ^ 2)| * ((p ^ 2 : ℕ) : ℝ) ^ (-σ)) := by
  have hKm := KW_isMultiplicative F
  apply oriel_euler_le (fun n => |KW F n| * (n : ℝ) ^ (-σ))
  · intro n; exact mul_nonneg (abs_nonneg _) (by positivity)
  · simp only [KW_one, abs_one, Nat.cast_one, Real.one_rpow, mul_one]
  · intro m n hmn
    rw [hKm.map_mul_of_coprime hmn, abs_mul, Nat.cast_mul,
      Real.mul_rpow (Nat.cast_nonneg _) (Nat.cast_nonneg _)]
    ring
  · intro p k hp hk
    simp [KW_prime_pow_ge_three F hp hk]

/-- Explicit envelope: `A_σ(F,N) ≤ 4 exp(10 Z₃₂) ∏_{p∣F} (1 + p^{-σ})` for `F ≠ 0`. -/
theorem oriel_Asig_le (F N : ℕ) (hF : F ≠ 0) {σ : ℝ} (hσ1 : 3 / 4 ≤ σ) (hσ2 : σ ≤ 1) :
    Asig F N σ ≤ 4 * Real.exp (10 * Z32) *
      ∏ p ∈ F.primeFactors, (1 + (p : ℝ) ^ (-σ)) := by
  refine (oriel_Asig_le_prod F N hσ1 hσ2).trans ?_
  set P := (N + 1).primesBelow
  set φ : ℕ → ℝ := fun p =>
    1 + |KW F p| * (p : ℝ) ^ (-σ) + |KW F (p ^ 2)| * ((p ^ 2 : ℕ) : ℝ) ^ (-σ)
  have hσ0 : 0 < σ := by linarith
  -- factor values
  have hforb : ∀ p ∈ P, ¬ allowedP F p → φ p = 1 + (p : ℝ) ^ (-σ) := by
    intro p hp hna
    have hpp : p.Prime := (Nat.mem_primesBelow.mp hp).2
    simp only [φ, KW_prime F hpp, KW_prime_sq F hpp, if_neg hna]
    simp
  have hall : ∀ p ∈ P, allowedP F p → φ p ≤ 1 + 10 * (p : ℝ) ^ (-(3 / 2 : ℝ)) := by
    intro p hp ha
    have hpp : p.Prime := (Nat.mem_primesBelow.mp hp).2
    have h5 : (5 : ℝ) ≤ p := by exact_mod_cast ha.1
    have hd : (0 : ℝ) < (p : ℝ) - 3 := by linarith
    simp only [φ, KW_prime F hpp, KW_prime_sq F hpp, if_pos ha]
    have e1 : |(p : ℝ) / ((p : ℝ) - 3) - 1| = 3 / ((p : ℝ) - 3) := by
      rw [show (p : ℝ) / ((p : ℝ) - 3) - 1 = 3 / ((p : ℝ) - 3) by field_simp; ring]
      exact abs_of_pos (by positivity)
    have e2 : |-((p : ℝ) / ((p : ℝ) - 3))| = (p : ℝ) / ((p : ℝ) - 3) := by
      rw [abs_neg]; exact abs_of_pos (by positivity)
    rw [e1, e2]
    push_cast
    linarith [oriel_allowed_local_le ha.1 hσ1 hσ2]
  have hφ1 : ∀ p ∈ P, 1 ≤ φ p := by
    intro p _
    simp only [φ]
    have : 0 ≤ |KW F p| * (p : ℝ) ^ (-σ) := mul_nonneg (abs_nonneg _) (by positivity)
    have : 0 ≤ |KW F (p ^ 2)| * ((p ^ 2 : ℕ) : ℝ) ^ (-σ) :=
      mul_nonneg (abs_nonneg _) (by positivity)
    linarith
  -- split the product
  rw [← prod_filter_mul_prod_filter_not P (fun p => allowedP F p)]
  have hA : ∏ p ∈ P with allowedP F p, φ p ≤ Real.exp (10 * Z32) := by
    calc ∏ p ∈ P with allowedP F p, φ p
        ≤ ∏ p ∈ P with allowedP F p, (1 + 10 * (p : ℝ) ^ (-(3 / 2 : ℝ))) := by
          apply prod_le_prod₀
          · intro p hp; exact le_trans zero_le_one (hφ1 p (mem_filter.mp hp).1)
          · intro p hp; exact hall p (mem_filter.mp hp).1 (mem_filter.mp hp).2
      _ ≤ _ := prod_allowed_le _
  have hB : ∏ p ∈ P with ¬ allowedP F p, φ p ≤
      4 * ∏ p ∈ F.primeFactors, (1 + (p : ℝ) ^ (-σ)) := by
    have hsub : (P.filter (fun p => ¬ allowedP F p)) ⊆ ({2, 3} : Finset ℕ) ∪ F.primeFactors := by
      intro p hp
      have hpP := (mem_filter.mp hp).1
      have hna := (mem_filter.mp hp).2
      have hpp : p.Prime := (Nat.mem_primesBelow.mp hpP).2
      simp only [allowedP, not_and_or, not_le, not_not] at hna
      rcases hna with h | h
      · have := hpp.two_le
        have : p = 2 ∨ p = 3 ∨ p = 4 := by omega
        rcases this with rfl | rfl | rfl
        · simp
        · simp
        · exact absurd hpp (by decide)
      · exact mem_union_right _ (Nat.mem_primeFactors.mpr ⟨hpp, h, hF⟩)
    have hg1 : ∀ p : ℕ, 1 ≤ 1 + (p : ℝ) ^ (-σ) := fun p => by
      have : 0 ≤ (p : ℝ) ^ (-σ) := by positivity
      linarith
    calc ∏ p ∈ P with ¬ allowedP F p, φ p
        = ∏ p ∈ P with ¬ allowedP F p, (1 + (p : ℝ) ^ (-σ)) :=
          prod_congr rfl (fun p hp => hforb p (mem_filter.mp hp).1 (mem_filter.mp hp).2)
      _ ≤ ∏ p ∈ ({2, 3} : Finset ℕ) ∪ F.primeFactors, (1 + (p : ℝ) ^ (-σ)) :=
          prod_le_prod_of_subset_of_one_le₀ hsub (fun p _ => le_trans zero_le_one (hg1 p))
            (fun p _ _ => hg1 p)
      _ ≤ (∏ p ∈ ({2, 3} : Finset ℕ), (1 + (p : ℝ) ^ (-σ))) *
            ∏ p ∈ F.primeFactors, (1 + (p : ℝ) ^ (-σ)) :=
          prod_union_le_mul_prod_of_one_le' (fun p => hg1 p)
      _ ≤ 4 * ∏ p ∈ F.primeFactors, (1 + (p : ℝ) ^ (-σ)) := by
          gcongr
          · have h2 : (2 : ℝ) ^ (-σ) ≤ 1 := Real.rpow_le_one_of_one_le_of_nonpos (by norm_num)
              (by linarith)
            have h3 : (3 : ℝ) ^ (-σ) ≤ 1 := Real.rpow_le_one_of_one_le_of_nonpos (by norm_num)
              (by linarith)
            rw [prod_pair (by norm_num)]
            push_cast
            have : 0 ≤ (2 : ℝ) ^ (-σ) := by positivity
            have : 0 ≤ (3 : ℝ) ^ (-σ) := by positivity
            nlinarith
  calc (∏ p ∈ P with allowedP F p, φ p) * ∏ p ∈ P with ¬ allowedP F p, φ p
      ≤ Real.exp (10 * Z32) * (4 * ∏ p ∈ F.primeFactors, (1 + (p : ℝ) ^ (-σ))) := by
        gcongr
    _ = _ := by ring

end OrielUpper
