import PaperB.FixedQ.SignedForbiddenConditionalAggregateJoin
import PaperB.FixedQ.SignedForbiddenExactAggregateDecomposition

namespace PaperB.FixedQ

/--
Mechanical adapter from the exact moderate-Vaaler-main split to the existing
four-component aggregate-rate consumer.  No estimate is proved here.
-/
theorem signedForbiddenAggregateRate_of_vaalerMain_split_component_rates
    {q : ℕ} (hq : 0 < q) (hsq : Squarefree q)
    (centered signedMean : ℕ → ℕ → ℝ)
    (hMainSplit :
      ∀ a b h : ℕ,
        q.Coprime a →
        q.Coprime b →
        Nat.ModEq q (a + h) b →
        (¬ 2 ∣ q → 2 ∣ h) →
        0 < h →
        cStarReal q h *
            signedForbiddenCompletedModerateVaalerMainAggregate q a h =
          centered a h + signedMean a h)
    (hCentered :
      ∃ C : ℝ, ∃ H0 : ℕ,
        0 ≤ C ∧
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          H0 ≤ h →
          |centered a h| ≤
            C * (Real.log (h : ℝ)) ^
                (h2BooleanSigma * h2BooleanX0) *
              (Real.log (Real.log (h : ℝ))) ^ 2)
    (hMean :
      ∃ C : ℝ, ∃ H0 : ℕ,
        0 ≤ C ∧
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          H0 ≤ h →
          |signedMean a h - signedMainB1Principal q (h / 2)| ≤
            C * (Real.log (h : ℝ)) ^
                (h2BooleanSigma * h2BooleanX0) *
              (Real.log (Real.log (h : ℝ))) ^ 2)
    (hVaaler :
      ∃ C : ℝ, ∃ H0 : ℕ,
        0 ≤ C ∧
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          H0 ≤ h →
          |cStarReal q h *
              signedForbiddenCompletedVaalerResidualAggregate q a h| ≤
            C * (Real.log (h : ℝ)) ^
                (h2BooleanSigma * h2BooleanX0) *
              (Real.log (Real.log (h : ℝ))) ^ 2)
    (hFar :
      ∃ C : ℝ, ∃ H0 : ℕ,
        0 ≤ C ∧
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          H0 ≤ h →
          |cStarReal q h *
              signedForbiddenCompletedNaturalFarTailAggregate q a h| ≤
            C * (Real.log (h : ℝ)) ^
                (h2BooleanSigma * h2BooleanX0) *
              (Real.log (Real.log (h : ℝ))) ^ 2) :
    ∃ C rho : ℝ, ∃ k H0 : ℕ,
      0 ≤ C ∧ rho < 1 ∧
      ∀ a b h : ℕ,
        q.Coprime a →
        q.Coprime b →
        Nat.ModEq q (a + h) b →
        (¬ 2 ∣ q → 2 ∣ h) →
        0 < h →
        H0 ≤ h →
        |cStarReal q h * signedForbiddenCompletedMainAggregate q a h -
            signedMainB1Principal q (h / 2)| ≤
          C * (Real.log (h : ℝ)) ^ rho *
            (Real.log (Real.log (h : ℝ))) ^ k := by
  apply signedForbiddenAggregateRate_of_component_rates
    hq hsq
    centered
    (fun a h => signedMean a h - signedMainB1Principal q (h / 2))
    (fun a h =>
      cStarReal q h *
        signedForbiddenCompletedVaalerResidualAggregate q a h)
    (fun a h =>
      cStarReal q h *
        signedForbiddenCompletedNaturalFarTailAggregate q a h)
  · intro a b h ha hb hcompat h2 hh
    exact
      signedForbiddenCompletedMainAggregate_exact_decomposition_of_vaalerMain_split
        hq ha hh h2
        (centered a h) (signedMean a h)
        (hMainSplit a b h ha hb hcompat h2 hh)
  · exact hCentered
  · exact hMean
  · exact hVaaler
  · exact hFar

#print axioms signedForbiddenAggregateRate_of_vaalerMain_split_component_rates

end PaperB.FixedQ
