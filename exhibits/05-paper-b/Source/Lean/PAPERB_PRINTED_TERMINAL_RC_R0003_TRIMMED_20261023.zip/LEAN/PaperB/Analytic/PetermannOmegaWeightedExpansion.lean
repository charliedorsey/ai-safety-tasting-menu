import PaperB.FixedQ.OmegaLinearMean

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ

theorem omega_weighted_sum_eq_correction_coprime
    (q X : ℕ) (F : ℕ → ℂ) :
    (∑ n ∈ Finset.Icc 1 X, (omegaCoeff q n : ℂ) * F n) =
      ∑ d ∈ Finset.Icc 1 X,
        (omegaCorrectionInvTerm q d : ℂ) *
          ∑ m ∈ Finset.Icc 1 (X / d),
            ((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
              F (d * m) := by
  classical
  calc
    (∑ n ∈ Finset.Icc 1 X, (omegaCoeff q n : ℂ) * F n)
      =
    ∑ n ∈ Finset.Icc 1 X,
      ∑ ds ∈ n.divisorsAntidiagonal,
        ((omegaCorrectionInvTerm q ds.2 *
          (coprimeIndicatorArithmetic q ds.1 / (ds.1 : ℝ)) : ℝ) : ℂ) *
          F n := by
        apply Finset.sum_congr rfl
        intro n hn
        have hn0 : n ≠ 0 := by
          rw [Finset.mem_Icc] at hn
          omega
        rw [omegaCoeff_eq_correction_divisor_sum q n hn0]
        push_cast
        rw [Finset.sum_mul]
    _ =
      ∑ x ∈ petermannDivisorSigma X,
        ((omegaCorrectionInvTerm q x.2.2 *
          (coprimeIndicatorArithmetic q x.2.1 / (x.2.1 : ℝ)) : ℝ) : ℂ) *
          F x.1 := by
        rw [petermannDivisorSigma, Finset.sum_sigma']
    _ =
      ∑ x ∈ petermannDivisorSigma X,
        ((omegaCorrectionInvTerm q x.2.2 *
          (coprimeIndicatorArithmetic q x.2.1 / (x.2.1 : ℝ)) : ℝ) : ℂ) *
          F (x.2.2 * x.2.1) := by
        apply Finset.sum_congr rfl
        intro x hx
        rw [petermannDivisorSigma, Finset.mem_sigma] at hx
        have hmul : x.2.1 * x.2.2 = x.1 :=
          (Nat.prodMk_mem_divisorsAntidiag
            (by
              rw [Finset.mem_Icc] at hx
              omega)).mp hx.2
        have hmul' : x.2.2 * x.2.1 = x.1 := by
          simpa [mul_comm] using hmul
        rw [hmul']
    _ =
      ∑ d ∈ Finset.Icc 1 X,
        ∑ m ∈ Finset.Icc 1 (X / d),
          ((omegaCorrectionInvTerm q d *
            (coprimeIndicatorArithmetic q m / (m : ℝ)) : ℝ) : ℂ) *
            F (d * m) := by
        exact sum_petermannDivisorSigma_eq_nested X
          (fun d m =>
            ((omegaCorrectionInvTerm q d *
              (coprimeIndicatorArithmetic q m / (m : ℝ)) : ℝ) : ℂ) *
              F (d * m))
    _ =
      ∑ d ∈ Finset.Icc 1 X,
        (omegaCorrectionInvTerm q d : ℂ) *
          ∑ m ∈ Finset.Icc 1 (X / d),
            ((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
              F (d * m) := by
        apply Finset.sum_congr rfl
        intro d hd
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro m hm
        push_cast
        ring

#print axioms omega_weighted_sum_eq_correction_coprime

end PaperB.Analytic
