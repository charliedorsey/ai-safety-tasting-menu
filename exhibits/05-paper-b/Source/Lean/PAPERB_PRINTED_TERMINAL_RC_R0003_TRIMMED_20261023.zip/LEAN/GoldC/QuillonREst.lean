import GoldC.QuillonRCellApp
import GoldC.QuillonWEst

/-!
# Quillon CSC3 F7.9c: the R term in closed form

`RTerm_le`: with `‖coef_m‖ ≤ Cb/m` on `𝒦 = [1, Jm]` and `Ymin ≤ |Y_m| ≤ Ymax`:

    RTerm ≤ Ku·Kv·Cb(1 + log Jm)·Aω(Sb)²·(2/√X + √(8C)·e^{−cL³/(2Lmax²)} + √(128C·Sb(1+log Sb)/Ymin))
          + Cb(1 + log Jm)·∏_U(1+1/(p−3))·12.5/X,

where `L = log((Ulo−Q)/Q)` and `Lmax = log(Ymax/Q)`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonREst

open GoldC.QuillonRCellApp GoldC.QuillonRBilinear GoldC.QuillonWEst

lemma sqrt_RPsi_le (c C : ℝ) (hc : 0 < c) (hC : 0 ≤ C) (Q V₀ Ulo S₁ : ℕ) (Y Ymin Ymax : ℝ)
    (hV₀ : 1 ≤ V₀) (hQ : 1 ≤ Q) (hYmin : 0 < Ymin) (hY1 : Ymin ≤ |Y|) (hY2 : |Y| ≤ Ymax)
    (hYQ : (Q : ℝ) < |Y|) :
    Real.sqrt (2 * RPsi c C Q V₀ Ulo S₁ Y) ≤
      2 / Real.sqrt V₀ +
        Real.sqrt (8 * C) * Real.exp (-(c * Real.log (((Ulo - Q) / Q : ℕ) : ℝ) ^ 3 /
          Real.log (Ymax / Q) ^ 2) / 2) +
        Real.sqrt (128 * C * S₁ * (1 + Real.log S₁) / Ymin) := by
  unfold RPsi
  have hV₀R : (0 : ℝ) < V₀ := by exact_mod_cast hV₀
  have hQR : (0 : ℝ) < Q := by exact_mod_cast hQ
  have hYpos : 0 < |Y| := lt_of_lt_of_le hYmin hY1
  have hlS : 0 ≤ 1 + Real.log S₁ := by have := Real.log_natCast_nonneg S₁; linarith
  set L := Real.log (((Ulo - Q) / Q : ℕ) : ℝ) with hL
  set ℓ := Real.log (|Y| / Q) with hℓ
  have hℓpos : 0 < ℓ := Real.log_pos (by rw [one_lt_div hQR]; exact hYQ)
  have hℓle : ℓ ≤ Real.log (Ymax / Q) :=
    Real.log_le_log (div_pos hYpos hQR) (div_le_div_of_nonneg_right hY2 hQR.le)
  have hexp : Real.exp (-(c * L ^ 3 / ℓ ^ 2)) ≤ Real.exp (-(c * L ^ 3 / Real.log (Ymax / Q) ^ 2)) := by
    apply Real.exp_le_exp.2
    apply neg_le_neg
    have hL0 : 0 ≤ L := Real.log_natCast_nonneg _
    exact div_le_div_of_nonneg_left (by positivity) (by positivity) (pow_le_pow_left₀ hℓpos.le hℓle 2)
  have hthird : 64 * C * S₁ * (1 + Real.log S₁) / |Y| ≤ 64 * C * S₁ * (1 + Real.log S₁) / Ymin :=
    div_le_div_of_nonneg_left (by positivity) hYmin hY1
  have hsum : 2 * (2 / (V₀ : ℝ) + 4 * C * Real.exp (-(c * L ^ 3 / ℓ ^ 2)) +
      64 * C * S₁ * (1 + Real.log S₁) / |Y|) ≤
      4 / (V₀ : ℝ) + 8 * C * Real.exp (-(c * L ^ 3 / Real.log (Ymax / Q) ^ 2)) +
      128 * C * S₁ * (1 + Real.log S₁) / Ymin := by
    have h1 := mul_le_mul_of_nonneg_left hexp (show 0 ≤ 8 * C by positivity)
    have h2 : 2 * (64 * C * S₁ * (1 + Real.log S₁) / |Y|) ≤ 128 * C * S₁ * (1 + Real.log S₁) / Ymin := by
      have := mul_le_mul_of_nonneg_left hthird (show (0 : ℝ) ≤ 2 by norm_num)
      rw [show 2 * (64 * C * S₁ * (1 + Real.log S₁) / Ymin) = 128 * C * S₁ * (1 + Real.log S₁) / Ymin by ring]
        at this
      exact this
    have e1 : 2 * (2 / (V₀ : ℝ) + 4 * C * Real.exp (-(c * L ^ 3 / ℓ ^ 2)) +
        64 * C * S₁ * (1 + Real.log S₁) / |Y|) =
        4 / (V₀ : ℝ) + 8 * C * Real.exp (-(c * L ^ 3 / ℓ ^ 2)) +
        2 * (64 * C * S₁ * (1 + Real.log S₁) / |Y|) := by ring
    rw [e1]
    linarith
  refine (Real.sqrt_le_sqrt hsum).trans ((sqrt_add3_le _ _ _ (by positivity) (by positivity)
    (by positivity)).trans ?_)
  apply add_le_add (add_le_add ?_ ?_) le_rfl
  · rw [Real.sqrt_div' _ hV₀R.le, show (4 : ℝ) = 2 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
  · rw [Real.sqrt_mul (by positivity), Real.sqrt_eq_rpow (Real.exp _), ← Real.exp_mul]
    apply le_of_eq; congr 1; ring

/-- **The R term in closed form.** -/
theorem RTerm_le (c C : ℝ) (hc : 0 < c) (hC : 0 ≤ C) (Jm : ℕ) (coef : ℕ → ℂ) (Cb : ℝ) (hCb : 0 ≤ Cb)
    (hcoef : ∀ m, 1 ≤ m → ‖coef m‖ ≤ Cb / m) (Ym : ℕ → ℝ) (Q : ℕ) (hQ : 1 ≤ Q) (U : Finset ℕ)
    (hU : ∀ p ∈ U, 5 ≤ p) (X Kv Lw Sb : ℕ) (hX : 1 ≤ X) (Ymin Ymax : ℝ) (hYmin : 0 < Ymin)
    (hY : ∀ m ∈ Icc 1 Jm, Ymin ≤ |Ym m| ∧ |Ym m| ≤ Ymax ∧ (Q : ℝ) < |Ym m|) :
    RTerm c C (Icc 1 Jm) coef Ym Q U X Kv Lw Sb ≤
      ((((Nat.log 2 Sb + 1) * 2) * Kv : ℕ) : ℝ) * (Cb * (1 + Real.log Jm)) *
        (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 Sb) : ℝ) ^ 30) ^ 2 *
        (2 / Real.sqrt X +
          Real.sqrt (8 * C) * Real.exp (-(c * Real.log (((Lw / (2 ^ Kv * X) - Q) / Q : ℕ) : ℝ) ^ 3 /
            Real.log (Ymax / Q) ^ 2) / 2) +
          Real.sqrt (128 * C * Sb * (1 + Real.log Sb) / Ymin)) +
      Cb * (1 + Real.log Jm) * (∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3))) * ((12.5 : ℝ) / X) := by
  unfold RTerm
  set Aω := (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 Sb) : ℝ) ^ 30) ^ 2 with hAω
  set B := 2 / Real.sqrt X +
          Real.sqrt (8 * C) * Real.exp (-(c * Real.log (((Lw / (2 ^ Kv * X) - Q) / Q : ℕ) : ℝ) ^ 3 /
            Real.log (Ymax / Q) ^ 2) / 2) +
          Real.sqrt (128 * C * Sb * (1 + Real.log Sb) / Ymin) with hB
  have hlJ : 0 ≤ 1 + Real.log Jm := GoldC.QuillonDivisorMoment.one_add_log_nonneg Jm
  have hsum : ∑ m ∈ Icc 1 Jm, ‖coef m‖ ≤ Cb * (1 + Real.log Jm) := by
    calc ∑ m ∈ Icc 1 Jm, ‖coef m‖ ≤ ∑ m ∈ Icc 1 Jm, Cb * (1 / (m : ℝ)) :=
          sum_le_sum fun m hm => (hcoef m (mem_Icc.1 hm).1).trans (le_of_eq (by ring))
      _ = Cb * ∑ m ∈ Icc 1 Jm, (1 / (m : ℝ)) := by rw [mul_sum]
      _ ≤ Cb * (1 + Real.log Jm) := mul_le_mul_of_nonneg_left (harm_Icc_le Jm) hCb
  have hmode : ∀ m ∈ Icc 1 Jm, Real.sqrt (2 * RPsi c C Q X (Lw / (2 ^ Kv * X)) Sb (Ym m)) ≤ B := by
    intro m hm
    obtain ⟨h1, h2, h3⟩ := hY m hm
    exact sqrt_RPsi_le c C hc hC Q X (Lw / (2 ^ Kv * X)) Sb (Ym m) Ymin Ymax hX hQ hYmin h1 h2 h3
  have hB0 : 0 ≤ B := by
    have := Real.sqrt_nonneg (2 * RPsi c C Q X (Lw / (2 ^ Kv * X)) Sb 0)
    rw [hB]; positivity
  have hfirst : ∑ m ∈ Icc 1 Jm, ‖coef m‖ * (Aω * Real.sqrt (2 * RPsi c C Q X (Lw / (2 ^ Kv * X)) Sb (Ym m))) ≤
      Cb * (1 + Real.log Jm) * Aω * B := by
    calc _ ≤ ∑ m ∈ Icc 1 Jm, ‖coef m‖ * (Aω * B) :=
          sum_le_sum fun m hm => mul_le_mul_of_nonneg_left
            (mul_le_mul_of_nonneg_left (hmode m hm) (by positivity)) (norm_nonneg _)
      _ = (∑ m ∈ Icc 1 Jm, ‖coef m‖) * (Aω * B) := by rw [sum_mul]
      _ ≤ Cb * (1 + Real.log Jm) * (Aω * B) := mul_le_mul_of_nonneg_right hsum (by positivity)
      _ = _ := by ring
  have hWU0 : 0 ≤ ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) := prod_nonneg fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast hU p hp
    have : 0 ≤ 1 / ((p : ℝ) - 3) := by apply div_nonneg zero_le_one; linarith
    linarith
  have hK0 : (0 : ℝ) ≤ ((((Nat.log 2 Sb + 1) * 2) * Kv : ℕ) : ℝ) := Nat.cast_nonneg _
  have e : ∑ m ∈ Icc 1 Jm, ‖coef m‖ * ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 Sb) : ℝ) ^ 30) ^ 2 *
      Real.sqrt (2 * RPsi c C Q X (Lw / (2 ^ Kv * X)) Sb (Ym m))) =
      ∑ m ∈ Icc 1 Jm, ‖coef m‖ * (Aω * Real.sqrt (2 * RPsi c C Q X (Lw / (2 ^ Kv * X)) Sb (Ym m))) := rfl
  rw [e]
  calc ((((Nat.log 2 Sb + 1) * 2) * Kv : ℕ) : ℝ) * _ + (∑ m ∈ Icc 1 Jm, ‖coef m‖) *
        (∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3))) * ((12.5 : ℝ) / X)
      ≤ ((((Nat.log 2 Sb + 1) * 2) * Kv : ℕ) : ℝ) * (Cb * (1 + Real.log Jm) * Aω * B) +
        Cb * (1 + Real.log Jm) * (∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3))) * ((12.5 : ℝ) / X) := by
        gcongr
    _ = _ := by ring

end GoldC.QuillonREst

#print axioms GoldC.QuillonREst.sqrt_RPsi_le
#print axioms GoldC.QuillonREst.RTerm_le
