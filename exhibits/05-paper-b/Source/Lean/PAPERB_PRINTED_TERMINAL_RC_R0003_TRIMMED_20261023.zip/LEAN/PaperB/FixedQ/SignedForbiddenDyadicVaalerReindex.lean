import PaperB.FixedQ.SignedForbiddenDyadicVaalerSplit

namespace PaperB.FixedQ

lemma neris_sourceForbiddenNaturalVaalerError_nonzero_mem_ordinaryDyadic
    {q a H D M m J : ℕ}
    (hm : m ∈ Finset.Ioc M (2 * M))
    (hnz : sourceForbiddenNaturalVaalerError q a H D m J ≠ 0) :
    m.primeFactors ∈ h2BooleanOrdinaryDyadicSets q H M := by
  classical
  have hs :
      1 < m ∧ Squarefree m ∧ m.Coprime (H * (6 * q) * D) := by
    by_contra h
    have hz : sourceForbiddenNaturalVaalerError q a H D m J = 0 := by
      simp [sourceForbiddenNaturalVaalerError, h]
    exact hnz hz
  have hsupport :=
    sourceForbiddenNatural_support_active
      (q := q) (H := H) (D := D) (m := m) hs.2.1 hs.2.2
  have hmI := Finset.mem_Ioc.mp hm
  unfold h2BooleanOrdinaryDyadicSets
  apply Finset.mem_filter.mpr
  constructor
  · unfold h2BooleanDyadicSets
    apply Finset.mem_filter.mpr
    constructor
    · apply Finset.mem_powerset.mpr
      intro p hp
      unfold h2BooleanActivePrimesLE
      apply Finset.mem_filter.mpr
      constructor
      · apply Nat.mem_primesLE.mpr
        constructor
        · have hpdiv : p ∣ m := (Nat.mem_primeFactors.mp hp).2.1
          have hmpos : 0 < m := by omega
          exact (Nat.le_of_dvd hmpos hpdiv).trans hmI.2
        · exact (Nat.mem_primeFactors.mp hp).1
      · exact hsupport.1 p hp
    · unfold primeSetProduct
      rw [Nat.prod_primeFactors_of_squarefree hs.2.1]
      exact hmI
  · exact hsupport.2

theorem neris_sourceForbiddenNaturalVaalerErrorDyadicBlock_eq_ordinaryDyadic
    (q a H D M J : ℕ) :
    sourceForbiddenNaturalVaalerErrorDyadicBlock q a H D M J =
      ∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
        sourceForbiddenNaturalVaalerError q a H D
          (primeSetProduct S) J := by
  classical
  let G := h2BooleanOrdinaryDyadicSets q H M
  let P := G.image primeSetProduct
  let f : ℕ → ℝ := fun m =>
    sourceForbiddenNaturalVaalerError q a H D m J
  have hPsub : P ⊆ Finset.Ioc M (2 * M) := by
    intro m hm
    rcases Finset.mem_image.mp hm with ⟨S, hS, rfl⟩
    exact Finset.mem_Ioc.mpr
      (h2BooleanDyadicSets_range
        (h2BooleanOrdinaryDyadicSets_mem hS).1)
  have hzero :
      ∀ m ∈ Finset.Ioc M (2 * M), m ∉ P → f m = 0 := by
    intro m hm hmP
    by_contra hnz
    have hS :=
      neris_sourceForbiddenNaturalVaalerError_nonzero_mem_ordinaryDyadic
        (q := q) (a := a) (H := H) (D := D)
        (M := M) (J := J) hm hnz
    have hsq : Squarefree m := by
      by_contra hnsq
      exact hnz (by
        simp [f, sourceForbiddenNaturalVaalerError, hnsq])
    apply hmP
    apply Finset.mem_image.mpr
    refine ⟨m.primeFactors, hS, ?_⟩
    unfold primeSetProduct
    exact Nat.prod_primeFactors_of_squarefree hsq
  have hinj : Set.InjOn primeSetProduct (↑G : Set (Finset ℕ)) := by
    intro S hS T hT hEq
    apply h2BooleanDyadicSets_product_injective (q := q) (M := M)
    · exact (h2BooleanOrdinaryDyadicSets_mem hS).1
    · exact (h2BooleanOrdinaryDyadicSets_mem hT).1
    · exact hEq
  unfold sourceForbiddenNaturalVaalerErrorDyadicBlock
  change (∑ m ∈ Finset.Ioc M (2 * M), f m) = _
  calc
    (∑ m ∈ Finset.Ioc M (2 * M), f m) =
        ∑ m ∈ P, f m := (Finset.sum_subset hPsub hzero).symm
    _ = ∑ S ∈ G, f (primeSetProduct S) := Finset.sum_image hinj
    _ = _ := by rfl

lemma neris_sourceForbiddenNaturalVaalerMain_nonzero_mem_ordinaryDyadic
    {q a H D M m J : ℕ}
    (hm : m ∈ Finset.Ioc M (2 * M))
    (hnz : sourceForbiddenNaturalVaalerMain q a H D m J ≠ 0) :
    m.primeFactors ∈ h2BooleanOrdinaryDyadicSets q H M := by
  classical
  have hs :
      1 < m ∧ Squarefree m ∧ m.Coprime (H * (6 * q) * D) := by
    by_contra h
    have hz : sourceForbiddenNaturalVaalerMain q a H D m J = 0 := by
      simp [sourceForbiddenNaturalVaalerMain, h]
    exact hnz hz
  have hsupport :=
    sourceForbiddenNatural_support_active
      (q := q) (H := H) (D := D) (m := m) hs.2.1 hs.2.2
  have hmI := Finset.mem_Ioc.mp hm
  unfold h2BooleanOrdinaryDyadicSets
  apply Finset.mem_filter.mpr
  constructor
  · unfold h2BooleanDyadicSets
    apply Finset.mem_filter.mpr
    constructor
    · apply Finset.mem_powerset.mpr
      intro p hp
      unfold h2BooleanActivePrimesLE
      apply Finset.mem_filter.mpr
      constructor
      · apply Nat.mem_primesLE.mpr
        constructor
        · have hpdiv : p ∣ m := (Nat.mem_primeFactors.mp hp).2.1
          have hmpos : 0 < m := by omega
          exact (Nat.le_of_dvd hmpos hpdiv).trans hmI.2
        · exact (Nat.mem_primeFactors.mp hp).1
      · exact hsupport.1 p hp
    · unfold primeSetProduct
      rw [Nat.prod_primeFactors_of_squarefree hs.2.1]
      exact hmI
  · exact hsupport.2

theorem neris_sourceForbiddenNaturalVaalerMainDyadicBlock_eq_ordinaryDyadic
    (q a H D M J : ℕ) :
    sourceForbiddenNaturalVaalerMainDyadicBlock q a H D M J =
      ∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
        sourceForbiddenNaturalVaalerMain q a H D
          (primeSetProduct S) J := by
  classical
  let G := h2BooleanOrdinaryDyadicSets q H M
  let P := G.image primeSetProduct
  let f : ℕ → ℝ := fun m =>
    sourceForbiddenNaturalVaalerMain q a H D m J
  have hPsub : P ⊆ Finset.Ioc M (2 * M) := by
    intro m hm
    rcases Finset.mem_image.mp hm with ⟨S, hS, rfl⟩
    exact Finset.mem_Ioc.mpr
      (h2BooleanDyadicSets_range
        (h2BooleanOrdinaryDyadicSets_mem hS).1)
  have hzero :
      ∀ m ∈ Finset.Ioc M (2 * M), m ∉ P → f m = 0 := by
    intro m hm hmP
    by_contra hnz
    have hS :=
      neris_sourceForbiddenNaturalVaalerMain_nonzero_mem_ordinaryDyadic
        (q := q) (a := a) (H := H) (D := D)
        (M := M) (J := J) hm hnz
    have hsq : Squarefree m := by
      by_contra hnsq
      exact hnz (by
        simp [f, sourceForbiddenNaturalVaalerMain, hnsq])
    apply hmP
    apply Finset.mem_image.mpr
    refine ⟨m.primeFactors, hS, ?_⟩
    unfold primeSetProduct
    exact Nat.prod_primeFactors_of_squarefree hsq
  have hinj : Set.InjOn primeSetProduct (↑G : Set (Finset ℕ)) := by
    intro S hS T hT hEq
    apply h2BooleanDyadicSets_product_injective (q := q) (M := M)
    · exact (h2BooleanOrdinaryDyadicSets_mem hS).1
    · exact (h2BooleanOrdinaryDyadicSets_mem hT).1
    · exact hEq
  unfold sourceForbiddenNaturalVaalerMainDyadicBlock
  change (∑ m ∈ Finset.Ioc M (2 * M), f m) = _
  calc
    (∑ m ∈ Finset.Ioc M (2 * M), f m) =
        ∑ m ∈ P, f m := (Finset.sum_subset hPsub hzero).symm
    _ = ∑ S ∈ G, f (primeSetProduct S) := Finset.sum_image hinj
    _ = _ := by rfl

#print axioms neris_sourceForbiddenNaturalVaalerErrorDyadicBlock_eq_ordinaryDyadic
#print axioms neris_sourceForbiddenNaturalVaalerMainDyadicBlock_eq_ordinaryDyadic

end PaperB.FixedQ
