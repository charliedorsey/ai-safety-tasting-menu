import PaperB.Analytic.FixedBetaNaturalOrder
import PaperB.Analytic.FixedBetaConstantEnvelope
import PaperB.Analytic.FixedBetaCanonicalMajorant
import PaperB.Analytic.ReciprocalFiniteOrderEnvelope

namespace PaperB.Analytic

open Real Finset Nat

noncomputable def fixedBetaUniformMajorantConst (beta0 : ℝ) : ℝ :=
  reciprocalFiniteOrderEnvelope (fixedBetaNaturalOrder beta0) *
    fixedBetaModelEnvelope (fixedBetaNaturalOrder beta0)

lemma fixedBetaUniformMajorantConst_nonneg (beta0 : ℝ) :
    0 ≤ fixedBetaUniformMajorantConst beta0 := by
  unfold fixedBetaUniformMajorantConst
  exact mul_nonneg
    (le_trans (by norm_num) (reciprocalFiniteOrderEnvelope_ge_one _))
    (le_trans (by norm_num) (fixedBetaModelEnvelope_ge_one _))

theorem fixedBeta_sourceScale_interval_uniform_majorant
    {beta0 beta : ℝ}
    (hb00 : 0 < beta0) (hb01 : beta0 < 1)
    (hbb : beta0 ≤ beta) (hb34 : beta ≤ 3 / 4) :
    ∀ (xi : ℝ) (W B : ℕ),
      fixedBetaNaturalOrder beta0 ≤ W →
      0 < W → W ≤ B → B ≤ 2 * W →
      ‖∑ n ∈ Finset.Icc W B,
          eR (((W : ℝ) ^ beta⁻¹) / (n : ℝ) + xi * (n : ℝ))‖
        ≤
      1 + fixedBetaUniformMajorantConst beta0 *
        (W : ℝ) ^ fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) := by
  intro xi W B hKW hW hWB hB2
  let k := fixedBetaNaturalOrder beta
  let K := fixedBetaNaturalOrder beta0
  let theta := fixedBetaUniformExponent K
  have hb0 : 0 < beta := lt_of_lt_of_le hb00 hbb
  have hb1 : beta < 1 := lt_of_le_of_lt hb34 (by norm_num)
  have hu := fixedBetaNaturalOrder_uniform_exponents hb00 hb01 hbb hb34
  dsimp at hu
  rcases hu with ⟨hk2, hkK, he1, he2, htheta⟩
  have hkW : k ≤ W := hkK.trans hKW
  have hraw := fixedBeta_sourceScale_interval_majorant_canonical
    beta k hk2 xi W B hW hkW hWB hB2
  have hW1 : (1 : ℝ) ≤ (W : ℝ) := by
    exact_mod_cast (Nat.one_le_iff_ne_zero.mpr (Nat.ne_of_gt hW))
  have hp1 :
      (W : ℝ) ^ fixedBetaFirstExponent beta k ≤
        (W : ℝ) ^ theta := by
    exact Real.rpow_le_rpow_of_exponent_le hW1 (by simpa [k, K, theta] using he1)
  have hp2 :
      (W : ℝ) ^ fixedBetaSecondExponent beta k ≤
        (W : ℝ) ^ theta := by
    exact Real.rpow_le_rpow_of_exponent_le hW1 (by simpa [k, K, theta] using he2)
  let c1 : ℝ := fixedBetaUpperConst k ^ fixedBetaA k
  let c2 : ℝ := fixedBetaLowerConst k ^ (-(fixedBetaA k))
  have hc1 : 0 ≤ c1 := by
    dsimp [c1]
    exact (Real.rpow_pos_of_pos (fixedBetaUpperConst_pos k) _).le
  have hc2 : 0 ≤ c2 := by
    dsimp [c2]
    exact (Real.rpow_pos_of_pos (fixedBetaLowerConst_pos k) _).le
  have hpow0 : 0 ≤ (W : ℝ) ^ theta :=
    Real.rpow_nonneg (by positivity) _
  have hmodel :
      c1 * (W : ℝ) ^ fixedBetaFirstExponent beta k +
          c2 * (W : ℝ) ^ fixedBetaSecondExponent beta k
        ≤ fixedBetaModelEnvelope K * (W : ℝ) ^ theta := by
    calc
      c1 * (W : ℝ) ^ fixedBetaFirstExponent beta k +
          c2 * (W : ℝ) ^ fixedBetaSecondExponent beta k
        ≤ c1 * (W : ℝ) ^ theta + c2 * (W : ℝ) ^ theta :=
          add_le_add
            (mul_le_mul_of_nonneg_left hp1 hc1)
            (mul_le_mul_of_nonneg_left hp2 hc2)
      _ = fixedBetaModelConst k * (W : ℝ) ^ theta := by
          dsimp [c1, c2]
          rw [fixedBetaModelConst]
          ring
      _ ≤ fixedBetaModelEnvelope K * (W : ℝ) ^ theta :=
          mul_le_mul_of_nonneg_right
            (fixedBetaModelConst_le_envelope hk2 hkK) hpow0
  have hC :
      reciprocalFiniteOrderConst k ≤ reciprocalFiniteOrderEnvelope K :=
    reciprocalFiniteOrderConst_le_envelope hk2 hkK
  have hC0 : 0 ≤ reciprocalFiniteOrderConst k :=
    le_trans (by norm_num) (reciprocalFiniteOrderConst_ge_one k)
  have hCE0 : 0 ≤ reciprocalFiniteOrderEnvelope K :=
    le_trans (by norm_num) (reciprocalFiniteOrderEnvelope_ge_one K)
  have hactual0 :
      0 ≤
        c1 * (W : ℝ) ^ fixedBetaFirstExponent beta k +
          c2 * (W : ℝ) ^ fixedBetaSecondExponent beta k := by
    positivity
  have hmul :
      reciprocalFiniteOrderConst k *
        (c1 * (W : ℝ) ^ fixedBetaFirstExponent beta k +
          c2 * (W : ℝ) ^ fixedBetaSecondExponent beta k)
      ≤
      reciprocalFiniteOrderEnvelope K *
        (fixedBetaModelEnvelope K * (W : ℝ) ^ theta) := by
    calc
      reciprocalFiniteOrderConst k *
          (c1 * (W : ℝ) ^ fixedBetaFirstExponent beta k +
            c2 * (W : ℝ) ^ fixedBetaSecondExponent beta k)
        ≤ reciprocalFiniteOrderEnvelope K *
          (c1 * (W : ℝ) ^ fixedBetaFirstExponent beta k +
            c2 * (W : ℝ) ^ fixedBetaSecondExponent beta k) :=
          mul_le_mul_of_nonneg_right hC hactual0
      _ ≤ reciprocalFiniteOrderEnvelope K *
          (fixedBetaModelEnvelope K * (W : ℝ) ^ theta) :=
          mul_le_mul_of_nonneg_left hmodel hCE0
  have hraw' :
      ‖∑ n ∈ Finset.Icc W B,
          eR (((W : ℝ) ^ beta⁻¹) / (n : ℝ) + xi * (n : ℝ))‖
        ≤
      1 + reciprocalFiniteOrderConst k *
        (c1 * (W : ℝ) ^ fixedBetaFirstExponent beta k +
          c2 * (W : ℝ) ^ fixedBetaSecondExponent beta k) := by
    simpa [c1, c2, k] using hraw
  calc
    ‖∑ n ∈ Finset.Icc W B,
        eR (((W : ℝ) ^ beta⁻¹) / (n : ℝ) + xi * (n : ℝ))‖
      ≤ 1 + reciprocalFiniteOrderConst k *
          (c1 * (W : ℝ) ^ fixedBetaFirstExponent beta k +
            c2 * (W : ℝ) ^ fixedBetaSecondExponent beta k) := hraw'
    _ ≤ 1 + reciprocalFiniteOrderEnvelope K *
          (fixedBetaModelEnvelope K * (W : ℝ) ^ theta) :=
      by simpa [add_comm] using add_le_add_right hmul 1
    _ = 1 + fixedBetaUniformMajorantConst beta0 *
          (W : ℝ) ^ fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) := by
      dsimp [K, theta]
      unfold fixedBetaUniformMajorantConst
      ring

#print axioms fixedBeta_sourceScale_interval_uniform_majorant

end PaperB.Analytic
