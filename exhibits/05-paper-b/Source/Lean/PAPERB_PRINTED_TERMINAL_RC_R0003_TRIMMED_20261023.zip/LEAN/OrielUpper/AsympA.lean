import OrielUpper.Master
import Mathlib.Analysis.MeanInequalitiesPow
import Mathlib.Analysis.Complex.ExponentialBounds

/-!
# Oriel Upper — asymptotic toolkit in the scale `θ = (log h + 2)^{1/64}`
-/

open Finset

namespace OrielUpper

/-- The master scale. -/
noncomputable def thH (h : ℕ) : ℝ := (Real.log (h : ℝ) + 2) ^ (1 / 64 : ℝ)

/-- `t = (log h)^{1/4}`. -/
noncomputable def tH (h : ℕ) : ℝ := (Real.log (h : ℝ)) ^ (1 / 4 : ℝ)

lemma logh_nonneg {h : ℕ} (hh : 1 ≤ h) : 0 ≤ Real.log (h : ℝ) :=
  Real.log_nonneg (by exact_mod_cast hh)

lemma thH_ge_one {h : ℕ} (hh : 1 ≤ h) : 1 ≤ thH h := by
  unfold thH
  apply Real.one_le_rpow _ (by norm_num)
  linarith [logh_nonneg hh]

lemma thH_pow64 {h : ℕ} (hh : 1 ≤ h) : thH h ^ 64 = Real.log (h : ℝ) + 2 := by
  unfold thH
  rw [← Real.rpow_natCast, ← Real.rpow_mul (by linarith [logh_nonneg hh])]
  norm_num

lemma tH_nonneg (h : ℕ) : 0 ≤ tH h := by
  unfold tH
  rcases Nat.eq_zero_or_pos h with h0 | hpos
  · subst h0; simp
  · have := logh_nonneg (show 1 ≤ h by omega); positivity

lemma tH_pow4 {h : ℕ} (hh : 1 ≤ h) : tH h ^ 4 = Real.log (h : ℝ) := by
  unfold tH
  rw [← Real.rpow_natCast, ← Real.rpow_mul (logh_nonneg hh)]
  norm_num

lemma tH_le {h : ℕ} (hh : 1 ≤ h) : tH h ≤ thH h ^ 16 := by
  unfold tH thH
  rw [← Real.rpow_natCast, ← Real.rpow_mul (by linarith [logh_nonneg hh])]
  norm_num
  exact Real.rpow_le_rpow (logh_nonneg hh) (by linarith) (by norm_num)

lemma kappa_le {h : ℕ} (hh : 1 ≤ h) : Real.log (Real.log (h : ℝ) + 2) ≤ 64 * thH h := by
  rw [← thH_pow64 hh, Real.log_pow]
  have h1 := thH_ge_one hh
  have := Real.log_le_sub_one_of_pos (show 0 < thH h by linarith)
  push_cast
  linarith

lemma natlog2_le_two_log (n : ℕ) : ((Nat.log 2 n : ℕ) : ℝ) ≤ 2 * Real.log n := by
  rcases Nat.eq_zero_or_pos n with h0 | hpos
  · subst h0; simp
  have h1 : 2 ^ Nat.log 2 n ≤ n := Nat.pow_log_le_self 2 hpos.ne'
  have h2 : ((Nat.log 2 n : ℕ) : ℝ) * Real.log 2 ≤ Real.log n := by
    rw [← Real.log_pow]
    exact Real.log_le_log (by positivity) (by exact_mod_cast h1)
  have hl2 := Real.log_two_gt_d9
  have : (0 : ℝ) ≤ ((Nat.log 2 n : ℕ) : ℝ) := Nat.cast_nonneg _
  nlinarith

/-- `q`-dependent constant for the iterated logarithm. -/
noncomputable def cq (q : ℕ) : ℝ := 130 + 2 * Real.log (2 * (Real.log (q : ℝ) + 3))

lemma logq_nonneg {q : ℕ} (hq : 1 ≤ q) : 0 ≤ Real.log (q : ℝ) :=
  Real.log_nonneg (by exact_mod_cast hq)

lemma cq_pos {q : ℕ} (hq : 1 ≤ q) : 130 ≤ cq q := by
  unfold cq
  have := logq_nonneg hq
  have : 0 ≤ Real.log (2 * (Real.log (q : ℝ) + 3)) := Real.log_nonneg (by linarith)
  linarith

lemma log_qh3 {q h : ℕ} (hq : 1 ≤ q) (hh : 1 ≤ h) :
    Real.log ((q * h ^ 3 : ℕ) : ℝ) = Real.log q + 3 * Real.log h := by
  have hq0 : (q : ℝ) ≠ 0 := by
    have : (1 : ℝ) ≤ q := by exact_mod_cast hq
    linarith
  have hh0 : (h : ℝ) ^ 3 ≠ 0 := by
    have : (1 : ℝ) ≤ h := by exact_mod_cast hh
    positivity
  push_cast
  rw [Real.log_mul hq0 hh0, Real.log_pow]
  push_cast; ring

/-- The iterated-log scale is `O(θ)`. -/
lemma lamX_le {q h : ℕ} (hq : 1 ≤ q) (hh : 1 ≤ h) :
    ((Nat.log 2 (Nat.log 2 (q * h ^ 3)) : ℕ) : ℝ) + 2 ≤ cq q * thH h := by
  have hθ := thH_ge_one hh
  have hc := cq_pos hq
  set n := Nat.log 2 (q * h ^ 3)
  have hL := logh_nonneg hh
  have hlq := logq_nonneg hq
  rcases Nat.eq_zero_or_pos n with h0 | hpos
  · rw [h0]; simp only [Nat.log_zero_right, Nat.cast_zero, zero_add]; nlinarith
  have h1 := natlog2_le_two_log n
  have h2 : (n : ℝ) ≤ 2 * (Real.log q + 3 * Real.log h) := by
    have := natlog2_le_two_log (q * h ^ 3)
    rwa [log_qh3 hq hh] at this
  have h3 : (n : ℝ) ≤ 2 * (Real.log q + 3) * (Real.log h + 2) := by nlinarith
  have hn : (0 : ℝ) < n := by exact_mod_cast hpos
  have h4 : Real.log n ≤ Real.log (2 * (Real.log q + 3)) + Real.log (Real.log h + 2) := by
    rw [← Real.log_mul (by positivity) (by positivity)]
    exact Real.log_le_log hn (by linarith)
  have h5 := kappa_le hh
  have h6 : 0 ≤ Real.log (2 * (Real.log (q : ℝ) + 3)) := Real.log_nonneg (by linarith)
  unfold cq
  nlinarith

lemma lamh_le_lamX {q h : ℕ} (hq : 1 ≤ q) :
    ((Nat.log 2 (Nat.log 2 h) : ℕ) : ℝ) + 2 ≤ ((Nat.log 2 (Nat.log 2 (q * h ^ 3)) : ℕ) : ℝ) + 2 := by
  have : h ≤ q * h ^ 3 := by
    rcases Nat.eq_zero_or_pos h with h0 | hpos
    · subst h0; simp
    calc h = 1 * h ^ 1 := by ring
      _ ≤ q * h ^ 3 := Nat.mul_le_mul hq (Nat.pow_le_pow_right hpos (by norm_num))
  have := Nat.log_mono_right (b := 2) (Nat.log_mono_right (b := 2) this)
  exact_mod_cast Nat.add_le_add_right this 2

/-- `exp(c + k log y) = e^c y^k`. -/
lemma exp_add_mul_log {c y : ℝ} (hy : 0 < y) (k : ℕ) :
    Real.exp (c + k * Real.log y) = Real.exp c * y ^ k := by
  rw [Real.exp_add, Real.exp_nat_mul, Real.exp_log hy]

/-- Envelope constants. -/
noncomputable def kE1 (q : ℕ) : ℝ := 4 * Real.exp (10 * Z32) * Real.exp 6 * cq q ^ 4

lemma envA1_le {q h : ℕ} (hq : 1 ≤ q) (hh : 1 ≤ h) :
    envA1 (q * h ^ 3) ≤ kE1 q * thH h ^ 4 := by
  unfold envA1 kE1
  set y := ((Nat.log 2 (Nat.log 2 (q * h ^ 3)) : ℕ) : ℝ) + 2
  have hy : 0 < y := by positivity
  have e : Real.exp (6 + 4 * Real.log y) = Real.exp 6 * y ^ 4 := by
    have := exp_add_mul_log (c := 6) hy 4; push_cast at this; exact this
  rw [e]
  have hyl := lamX_le hq hh
  have : y ^ 4 ≤ (cq q * thH h) ^ 4 := pow_le_pow_left₀ hy.le hyl 4
  have hpos : 0 ≤ 4 * Real.exp (10 * Z32) * Real.exp 6 := by positivity
  calc 4 * Real.exp (10 * Z32) * (Real.exp 6 * y ^ 4)
      = (4 * Real.exp (10 * Z32) * Real.exp 6) * y ^ 4 := by ring
    _ ≤ (4 * Real.exp (10 * Z32) * Real.exp 6) * (cq q * thH h) ^ 4 :=
        mul_le_mul_of_nonneg_left this hpos
    _ = _ := by ring

lemma envA1_ge_one (X : ℕ) : 1 ≤ envA1 X := by
  unfold envA1
  have h1 : 1 ≤ Real.exp (10 * Z32) := by
    apply Real.one_le_exp
    have : 0 ≤ Z32 := tsum_nonneg (fun n => by positivity)
    positivity
  have h2 : 1 ≤ Real.exp (6 + 4 * Real.log (Nat.log 2 (Nat.log 2 X) + 2)) := by
    apply Real.one_le_exp
    have : 0 ≤ Real.log (((Nat.log 2 (Nat.log 2 X) : ℕ) : ℝ) + 2) := Real.log_nonneg (by
      have : (0 : ℝ) ≤ ((Nat.log 2 (Nat.log 2 X) : ℕ) : ℝ) := Nat.cast_nonneg _
      linarith)
    positivity
  nlinarith

noncomputable def kV (q : ℕ) : ℝ := Real.exp 10 * cq q ^ 7

lemma Vb_le {q h : ℕ} (hq : 1 ≤ q) (hh : 1 ≤ h) : Vb h ≤ kV q * thH h ^ 7 := by
  unfold Vb kV
  set y := ((Nat.log 2 (Nat.log 2 h) : ℕ) : ℝ) + 2
  have hy : 2 ≤ y := by have : (0 : ℝ) ≤ ((Nat.log 2 (Nat.log 2 h) : ℕ) : ℝ) := Nat.cast_nonneg _
                        linarith
  have hly : 0 ≤ Real.log y := Real.log_nonneg (by linarith)
  have h1 : Real.exp (5 / 3 * (6 + 4 * Real.log y)) ≤ Real.exp (10 + (7 : ℕ) * Real.log y) := by
    apply Real.exp_le_exp.mpr; push_cast; nlinarith
  rw [exp_add_mul_log (by linarith) 7] at h1
  refine h1.trans ?_
  have hyl := (lamh_le_lamX (h := h) hq).trans (lamX_le hq hh)
  have : y ^ 7 ≤ (cq q * thH h) ^ 7 := pow_le_pow_left₀ (by linarith) hyl 7
  calc Real.exp 10 * y ^ 7 ≤ Real.exp 10 * (cq q * thH h) ^ 7 :=
        mul_le_mul_of_nonneg_left this (by positivity)
    _ = _ := by ring

end OrielUpper
