import PaperB.Analytic.FixedBetaIntervalSublinear

namespace PaperB.Analytic

open Real Finset Nat

lemma reciprocal_phase_mul_branch_identity
    {A xi : ℝ} {d m : ℕ} (hd : d ≠ 0) :
    eR (A / ((d * m : ℕ) : ℝ) + xi * ((d * m : ℕ) : ℝ)) =
      eR ((A / (d : ℝ)) / (m : ℝ) + (xi * (d : ℝ)) * (m : ℝ)) := by
  congr 1
  have hdR : (d : ℝ) ≠ 0 := by exact_mod_cast hd
  push_cast
  field_simp [hdR]

theorem fixedBeta_divisor_branch_interval_sublinear
    {beta eps A xi : ℝ} {d W B : ℕ}
    (hb0 : 0 < beta) (hb1 : beta < 1) (heps : 0 < eps)
    (hd : d ≠ 0)
    (hscale : A / (d : ℝ) = (W : ℝ) ^ beta⁻¹) :
    ∃ k : ℕ, 2 ≤ k ∧
      ∃ W0 : ℝ,
        W0 ≤ (W : ℝ) →
        k ≤ W → W ≤ B → B ≤ 2 * W →
        ‖∑ m ∈ Finset.Icc W B,
            eR (A / (((d * m : ℕ) : ℝ)) +
              xi * ((d * m : ℕ) : ℝ))‖
          ≤ eps * (W : ℝ) := by
  obtain ⟨k, hk, W0, hmain⟩ :=
    fixedBeta_sourceScale_interval_sublinear hb0 hb1 heps
  refine ⟨k, hk, W0, ?_⟩
  intro hW0 hkW hWB hB2
  have hbound := hmain (xi * (d : ℝ)) W B hW0 hkW hWB hB2
  rw [← hscale] at hbound
  calc
    ‖∑ m ∈ Finset.Icc W B,
        eR (A / (((d * m : ℕ) : ℝ)) +
          xi * ((d * m : ℕ) : ℝ))‖
      =
    ‖∑ m ∈ Finset.Icc W B,
        eR ((A / (d : ℝ)) / (m : ℝ) +
          (xi * (d : ℝ)) * (m : ℝ))‖ := by
        congr 1
        apply Finset.sum_congr rfl
        intro m hm
        exact reciprocal_phase_mul_branch_identity hd
    _ ≤ eps * (W : ℝ) := hbound

lemma source_scale_rpow_inversion
    {A W beta : ℝ}
    (hA : 0 < A) (hb : beta ≠ 0)
    (hscale : W = A ^ beta) :
    A = W ^ beta⁻¹ := by
  rw [hscale]
  rw [← Real.rpow_mul hA.le]
  rw [mul_inv_cancel₀ hb, Real.rpow_one]

theorem fixedBeta_divisor_branch_interval_sublinear_of_source_relation
    {beta eps A xi : ℝ} {d W B : ℕ}
    (hb0 : 0 < beta) (hb1 : beta < 1) (heps : 0 < eps)
    (hA : 0 < A) (hd : d ≠ 0)
    (hsource : (W : ℝ) = (A / (d : ℝ)) ^ beta) :
    ∃ k : ℕ, 2 ≤ k ∧
      ∃ W0 : ℝ,
        W0 ≤ (W : ℝ) →
        k ≤ W → W ≤ B → B ≤ 2 * W →
        ‖∑ m ∈ Finset.Icc W B,
            eR (A / (((d * m : ℕ) : ℝ)) +
              xi * ((d * m : ℕ) : ℝ))‖
          ≤ eps * (W : ℝ) := by
  have hdR : (0 : ℝ) < d := by
    exact_mod_cast Nat.pos_of_ne_zero hd
  have hAd : 0 < A / (d : ℝ) := div_pos hA hdR
  have hscale :
      A / (d : ℝ) = (W : ℝ) ^ beta⁻¹ :=
    source_scale_rpow_inversion hAd hb0.ne' hsource
  exact fixedBeta_divisor_branch_interval_sublinear
    hb0 hb1 heps hd hscale

#print axioms reciprocal_phase_mul_branch_identity
#print axioms fixedBeta_divisor_branch_interval_sublinear
#print axioms source_scale_rpow_inversion
#print axioms fixedBeta_divisor_branch_interval_sublinear_of_source_relation

end PaperB.Analytic
