import GoldB.QuillonSelectedOrders

/-!
# Interface reconstruction (Quillon, Hunt B R0001) for the missing module
# `GoldB.QuillonDerivativeWindow`

**Provenance.** This is a from-scratch reconstruction by Quillon. It is not the original scratch
source; see `GoldB.QuillonSelectedOrders` for the construction. No axiom, no
`sorry`.

`veylan_suzuki_literal_selected_derivative_window` states that, for every selected order `j`
and every `x ∈ [P, 2P]` and `ϑ ∈ [0,1]`, Suzuki's window holds:
`P^{-(599/624) j} ≤ |f^{(j)}(x)|/j! ≤ P^{-j/4}` for `f(z) = Y/(z+ϑ)`, with `P ≥ 4096`, in the
regime `log Y ≥ (3/2)(log P + log 2)`.
-/

namespace OrielUpper

/-- `log(2P+1) ≤ (157/144) log P` for `P ≥ 4096`. -/
lemma quillon_log_two_P_add_one (P : ℝ) (hP : 4096 ≤ P) :
    Real.log (2 * P + 1) ≤ (157 / 144) * Real.log P := by
  have hP0 : 0 < P := by linarith
  have h1 : Real.log (2 * P + 1) - Real.log (2 * P) ≤ 1 / (2 * P) := by
    rw [← Real.log_div (by positivity) (by positivity)]
    have := Real.log_le_sub_one_of_pos (by positivity : (0 : ℝ) < (2 * P + 1) / (2 * P))
    have e : (2 * P + 1) / (2 * P) - 1 = 1 / (2 * P) := by field_simp; ring
    linarith
  have h2 : Real.log (2 * P) = Real.log 2 + Real.log P := Real.log_mul (by norm_num) hP0.ne'
  have h3 : 12 * Real.log 2 ≤ Real.log P := by
    have : Real.log ((2 : ℝ) ^ 12) = 12 * Real.log 2 := by rw [Real.log_pow]; norm_num
    rw [← this]; exact Real.log_le_log (by norm_num) (by norm_num; linarith)
  have h4 : 1 / (2 * P) ≤ 1 / 8192 := by
    rw [div_le_div_iff₀ (by positivity) (by norm_num)]; linarith
  have h5 : 1 - (2 : ℝ)⁻¹ ≤ Real.log 2 := Real.one_sub_inv_le_log_of_pos (by norm_num)
  norm_num at h5
  linarith

theorem veylan_suzuki_literal_selected_derivative_window (P x ϑ Y : ℝ) (j : ℕ)
    (hP : 4096 ≤ P) (hx : P ≤ x) (hx2 : x ≤ 2 * P) (hϑ0 : 0 ≤ ϑ) (hϑ1 : ϑ ≤ 1) (hY : 0 < Y)
    (hreg : (3 / 2) * (Real.log P + Real.log 2) ≤ Real.log Y)
    (hj : j ∈ veylanSuzukiSelected (Real.log Y / Real.log P)) :
    P ^ (-(599 / 624 : ℝ) * (j : ℝ)) ≤
        ‖iteratedDeriv j (fun z : ℝ => Y / (z + ϑ)) x / (j.factorial : ℝ)‖ ∧
      ‖iteratedDeriv j (fun z : ℝ => Y / (z + ϑ)) x / (j.factorial : ℝ)‖ ≤
        P ^ (-((1 / 4 : ℝ) * j)) := by
  have hP0 : 0 < P := by linarith
  have hL : 0 < Real.log P := Real.log_pos (by linarith)
  have hu0 : 0 < x + ϑ := by linarith
  rw [veylan_suzuki_normalized_derivative Y ϑ x j hY.le hu0]
  set L := Real.log P
  set t := Real.log Y / L
  have hl2 : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have ht : (3 / 2 : ℝ) ≤ t := by
    simp only [t]; rw [le_div_iff₀ hL]; nlinarith
  have hY' : Real.log Y = t * L := by simp only [t]; field_simp
  obtain ⟨_, hlo, hhi, _⟩ := veylan_suzuki_selected_order t ht j hj
  set u := x + ϑ
  have hV : Y / u ^ (j + 1) = Real.exp (Real.log Y - ((j : ℝ) + 1) * Real.log u) := by
    rw [Real.exp_sub, Real.exp_log hY, show ((j : ℝ) + 1) * Real.log u = Real.log (u ^ (j + 1)) by
      rw [Real.log_pow]; push_cast; ring, Real.exp_log (by positivity)]
  have hlogu_lo : L ≤ Real.log u := Real.log_le_log hP0 (by simp only [u]; linarith)
  have hlogu_hi : Real.log u ≤ (157 / 144) * L :=
    (Real.log_le_log hu0 (by simp only [u]; linarith)).trans (quillon_log_two_P_add_one P hP)
  rw [hV, Real.rpow_def_of_pos hP0, Real.rpow_def_of_pos hP0]
  constructor
  · apply Real.exp_le_exp.mpr
    rw [hY']
    have hj0 : (0 : ℝ) ≤ (j : ℝ) + 1 := by positivity
    have a1 := mul_le_mul_of_nonneg_left hlogu_hi hj0
    have a2 : (j : ℝ) * (61 / 468) ≤ t - 157 / 144 := by nlinarith
    have a3 := mul_le_mul_of_nonneg_left a2 hL.le
    nlinarith
  · apply Real.exp_le_exp.mpr
    rw [hY']
    have hj0 : (0 : ℝ) ≤ (j : ℝ) + 1 := by positivity
    have a1 := mul_le_mul_of_nonneg_left hlogu_lo hj0
    have a2 : t - 1 ≤ (3 / 4) * (j : ℝ) := by linarith
    have a3 := mul_le_mul_of_nonneg_left a2 hL.le
    nlinarith

end OrielUpper

#print axioms OrielUpper.quillon_log_two_P_add_one
#print axioms OrielUpper.veylan_suzuki_literal_selected_derivative_window
