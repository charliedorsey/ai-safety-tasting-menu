import PaperB.FixedQ.SignedForbiddenThalenFiniteSpectral

open scoped BigOperators

namespace PaperB.FixedQ

/-- The finite spectral diagonal's signed mean is exactly the disjoint
Boolean density after removal of the two pure one-sided packets.
This identity is finite and retains A_S, rather than replacing it by
the unrestricted Euler constant. -/
theorem thalen_finite_density_correction
    (S : Finset ℕ) (h5 : ∀ p ∈ S, 5 ≤ p) :
    (thalenFiniteA S - 1) ^ 2 +
        (thalenFiniteA S) ^ 2 *
          ((∏ p ∈ S, (1 - (thalenPrimeDelta p) ^ 2)) - 1) =
      (∏ p ∈ S,
        (1 + 2 / ((p : ℝ) * ((p : ℝ) - 3)))) -
        2 * thalenFiniteA S + 1 := by
  have hlocal : ∀ p ∈ S,
      (1 + 1 / ((p : ℝ) * ((p : ℝ) - 3))) ^ 2 *
          (1 - thalenPrimeDelta p ^ 2) =
        1 + 2 / ((p : ℝ) * ((p : ℝ) - 3)) := by
    intro p hp
    have hpr : (5 : ℝ) ≤ (p : ℝ) := by exact_mod_cast h5 p hp
    have hz : (p : ℝ) * ((p : ℝ) - 3) ≠ 0 := by
      apply mul_ne_zero
      · linarith
      · linarith
    have hz1 : (p : ℝ) * ((p : ℝ) - 3) + 1 ≠ 0 := by
      nlinarith
    let t : ℝ := (p : ℝ) * ((p : ℝ) - 3)
    have ht : t ≠ 0 := hz
    have ht1 : t + 1 ≠ 0 := hz1
    change (1 + 1 / t) ^ 2 * (1 - (1 / (t + 1)) ^ 2) =
      1 + 2 / t
    field_simp
    ring
  have hprod :
      (thalenFiniteA S) ^ 2 *
        (∏ p ∈ S, (1 - thalenPrimeDelta p ^ 2)) =
      ∏ p ∈ S, (1 + 2 / ((p : ℝ) * ((p : ℝ) - 3))) := by
    unfold thalenFiniteA
    rw [← Finset.prod_pow, ← Finset.prod_mul_distrib]
    exact Finset.prod_congr rfl hlocal
  nlinarith [hprod]

#print axioms thalen_finite_density_correction

end PaperB.FixedQ
