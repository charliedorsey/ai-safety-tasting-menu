import PaperB.FixedQ.H2BooleanDyadicMoments
import PaperB.FixedQ.H2BooleanETConsumer

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def h2BooleanDyadicSmoothFiber
    (q Y M : ℕ) (T : Finset ℕ) : Finset (Finset ℕ) :=
  (h2BooleanDyadicSets q M).filter
    (fun S => S.filter (fun p => p ≤ Y) = T)

lemma h2BooleanDyadicSmoothFiber_mem
    {q Y M : ℕ} {T S : Finset ℕ}
    (hS : S ∈ h2BooleanDyadicSmoothFiber q Y M T) :
    S ∈ h2BooleanDyadicSets q M ∧
      S.filter (fun p => p ≤ Y) = T :=
  Finset.mem_filter.mp hS

lemma h2BooleanDyadicSmoothFiber_active
    {q Y M : ℕ} {T S : Finset ℕ}
    (hS : S ∈ h2BooleanDyadicSmoothFiber q Y M T) :
    ∀ p ∈ S, activeHighPrime q p :=
  h2BooleanDyadicSets_active (h2BooleanDyadicSmoothFiber_mem hS).1

lemma h2BooleanDyadicSmoothFiber_smooth_active
    {q Y M : ℕ} {T S : Finset ℕ}
    (hS : S ∈ h2BooleanDyadicSmoothFiber q Y M T) :
    ∀ p ∈ T, activeHighPrime q p := by
  intro p hp
  have hT := (h2BooleanDyadicSmoothFiber_mem hS).2
  rw [← hT] at hp
  exact h2BooleanDyadicSmoothFiber_active hS p (Finset.mem_filter.mp hp).1

lemma h2BooleanDyadicSmoothFiber_rough_active
    {q Y M : ℕ} {T S : Finset ℕ}
    (hS : S ∈ h2BooleanDyadicSmoothFiber q Y M T) :
    ∀ p ∈ S.filter (fun p => Y < p), activeHighPrime q p := by
  intro p hp
  exact h2BooleanDyadicSmoothFiber_active hS p (Finset.mem_filter.mp hp).1

lemma h2BooleanDyadicSmoothFiber_partition
    {q Y M : ℕ} {T S : Finset ℕ}
    (hS : S ∈ h2BooleanDyadicSmoothFiber q Y M T) :
    S = T ∪ S.filter (fun p => Y < p) := by
  have hT := (h2BooleanDyadicSmoothFiber_mem hS).2
  calc
    S = S.filter (fun p => p ≤ Y) ∪ S.filter (fun p => Y < p) :=
      h2Boolean_filtered_partition Y S
    _ = T ∪ S.filter (fun p => Y < p) := by rw [hT]

lemma h2BooleanDyadicSmoothFiber_disjoint
    {q Y M : ℕ} {T S : Finset ℕ}
    (hS : S ∈ h2BooleanDyadicSmoothFiber q Y M T) :
    Disjoint T (S.filter (fun p => Y < p)) := by
  have hT := (h2BooleanDyadicSmoothFiber_mem hS).2
  rw [← hT]
  exact h2Boolean_filtered_disjoint Y S

lemma h2BooleanDyadicSmoothFiber_product_split
    {q Y M : ℕ} {T S : Finset ℕ}
    (hS : S ∈ h2BooleanDyadicSmoothFiber q Y M T) :
    primeSetProduct S =
      primeSetProduct T * primeSetProduct (S.filter (fun p => Y < p)) := by
  let R := S.filter (fun p => Y < p)
  have hdisj : Disjoint T R := h2BooleanDyadicSmoothFiber_disjoint hS
  have hPrimeT : ∀ p ∈ T, p.Prime :=
    fun p hp => (h2BooleanDyadicSmoothFiber_smooth_active hS p hp).1
  have hPrimeR : ∀ p ∈ R, p.Prime :=
    fun p hp => (h2BooleanDyadicSmoothFiber_rough_active hS p hp).1
  have hpart := h2BooleanDyadicSmoothFiber_partition hS
  calc
    primeSetProduct S = primeSetProduct (T ∪ R) := by rw [hpart]
    _ = primeSetProduct T * primeSetProduct R :=
      h2_primeSetProduct_union hdisj

lemma h2BooleanDyadicSmoothFiber_rough_product_injective
    {q Y M : ℕ} {T : Finset ℕ} :
    Set.InjOn
      (fun S : Finset ℕ => primeSetProduct (S.filter (fun p => Y < p)))
      {S | S ∈ h2BooleanDyadicSmoothFiber q Y M T} := by
  intro S hS U hU hprod
  change S ∈ h2BooleanDyadicSmoothFiber q Y M T at hS
  change U ∈ h2BooleanDyadicSmoothFiber q Y M T at hU
  let RS := S.filter (fun p => Y < p)
  let RU := U.filter (fun p => Y < p)
  have hPrimeRS : ∀ p ∈ RS, p.Prime :=
    fun p hp => (h2BooleanDyadicSmoothFiber_rough_active hS p hp).1
  have hPrimeRU : ∀ p ∈ RU, p.Prime :=
    fun p hp => (h2BooleanDyadicSmoothFiber_rough_active hU p hp).1
  have hpfRS : (primeSetProduct RS).primeFactors = RS := by
    unfold primeSetProduct
    exact Nat.primeFactors_prod hPrimeRS
  have hpfRU : (primeSetProduct RU).primeFactors = RU := by
    unfold primeSetProduct
    exact Nat.primeFactors_prod hPrimeRU
  have hRUeq : RS = RU := by
    rw [← hpfRS, ← hpfRU]
    exact congrArg Nat.primeFactors hprod
  calc
    S = T ∪ RS := h2BooleanDyadicSmoothFiber_partition hS
    _ = T ∪ RU := by rw [hRUeq]
    _ = U := (h2BooleanDyadicSmoothFiber_partition hU).symm

#print axioms h2BooleanDyadicSmoothFiber_product_split
#print axioms h2BooleanDyadicSmoothFiber_rough_product_injective

noncomputable def h2BooleanFourierNormSq
    (q : ℕ) (S : Finset ℕ) (j : ℕ) : ℝ :=
  if hA : ∀ p ∈ S, activeHighPrime q p then
    ‖fixedProductBooleanFourierCoeff S
      (fun p hp => (hA p hp).1)
      (j : ZMod (primeSetProduct S))‖ ^ 2
  else 0

lemma h2BooleanFourierNormSq_nonneg
    (q : ℕ) (S : Finset ℕ) (j : ℕ) :
    0 ≤ h2BooleanFourierNormSq q S j := by
  unfold h2BooleanFourierNormSq
  split_ifs
  · positivity
  · exact le_rfl

lemma h2BooleanFourierNormSq_eq_of_active
    {q : ℕ} {S : Finset ℕ} (j : ℕ)
    (hA : ∀ p ∈ S, activeHighPrime q p) :
    h2BooleanFourierNormSq q S j =
      ‖fixedProductBooleanFourierCoeff S
        (fun p hp => (hA p hp).1)
        (j : ZMod (primeSetProduct S))‖ ^ 2 := by
  unfold h2BooleanFourierNormSq
  rw [dif_pos hA]

noncomputable def h2BooleanDyadicFrequencySecondMoment
    (q M j : ℕ) : ℝ :=
  ∑ S ∈ h2BooleanDyadicSets q M,
    finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
      h2BooleanFourierNormSq q S j

noncomputable def h2BooleanDyadicFrequencyFiberMoment
    (q Y M : ℕ) (T : Finset ℕ) (j : ℕ) : ℝ :=
  ∑ S ∈ h2BooleanDyadicSmoothFiber q Y M T,
    finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
      h2BooleanFourierNormSq q S j

lemma h2BooleanDyadicSmoothFiber_fourier_block_le
    {q Y M : ℕ} {T S : Finset ℕ} {j : ℕ}
    (hS : S ∈ h2BooleanDyadicSmoothFiber q Y M T) :
    h2BooleanFourierNormSq q S j ≤
      ‖fixedProductBooleanFourierCoeff T
        (fun p hp => (h2BooleanDyadicSmoothFiber_smooth_active hS p hp).1)
        ((j : ZMod (primeSetProduct T)) *
          (((ZMod.unitOfCoprime
            (primeSetProduct (S.filter (fun p => Y < p)))
            (h2_primeSetProduct_coprime
              (h2BooleanDyadicSmoothFiber_disjoint hS)
              (fun p hp => (h2BooleanDyadicSmoothFiber_smooth_active hS p hp).1)
              (fun p hp => (h2BooleanDyadicSmoothFiber_rough_active hS p hp).1)).symm)⁻¹ :
              (ZMod (primeSetProduct T))ˣ) : ZMod (primeSetProduct T)))‖ ^ 2 := by
  let R := S.filter (fun p => Y < p)
  have hA := h2BooleanDyadicSmoothFiber_active hS
  have hT := h2BooleanDyadicSmoothFiber_smooth_active hS
  have hR := h2BooleanDyadicSmoothFiber_rough_active hS
  have hdisj : Disjoint T R := h2BooleanDyadicSmoothFiber_disjoint hS
  have hPrimeT : ∀ p ∈ T, p.Prime := fun p hp => (hT p hp).1
  have hPrimeR : ∀ p ∈ R, p.Prime := fun p hp => (hR p hp).1
  have hpart : S = T ∪ R := h2BooleanDyadicSmoothFiber_partition hS
  change h2BooleanFourierNormSq q S j ≤
    ‖fixedProductBooleanFourierCoeff T hPrimeT
      ((j : ZMod (primeSetProduct T)) *
        (((ZMod.unitOfCoprime (primeSetProduct R)
          (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR).symm)⁻¹ :
            (ZMod (primeSetProduct T))ˣ) : ZMod (primeSetProduct T)))‖ ^ 2
  rw [h2BooleanFourierNormSq_eq_of_active j hA]
  have hblock := norm_sq_fixedProductBooleanFourierCoeff_block_le_left
    T R hdisj hPrimeT hPrimeR
    (j : ZMod (primeSetProduct (T ∪ R)))
  have hfreq := h2BooleanBlockLeftFrequency_natCast_eq_mul_inv_unit
    T R hdisj hPrimeT hPrimeR j
  rw [hfreq] at hblock
  clear_value R
  subst S
  exact hblock

#print axioms h2BooleanDyadicSmoothFiber_fourier_block_le

lemma h2BooleanRoughTiltLift_primeSetProduct
    {q Y : ℕ} {R : Finset ℕ} {c : ℝ}
    (hPrime : ∀ p ∈ R, p.Prime)
    (hRough : ∀ p ∈ R, Y < p) :
    h2BooleanRoughTiltLift q Y c (primeSetProduct R) =
      h2BooleanTiltLift q c (primeSetProduct R) := by
  rw [h2BooleanRoughTiltLift_apply]
  unfold h2BooleanRoughTiltLiftNat
  rw [if_pos]
  intro p hp
  have hpf : (primeSetProduct R).primeFactors = R := by
    unfold primeSetProduct
    exact Nat.primeFactors_prod hPrime
  rw [hpf] at hp
  exact hRough p hp

lemma h2BooleanDyadicSmoothFiber_weight_fourier_le
    {q Y M : ℕ} {T S : Finset ℕ} {j : ℕ}
    (hS : S ∈ h2BooleanDyadicSmoothFiber q Y M T) :
    finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
        h2BooleanFourierNormSq q S j ≤
      (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
      (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt
          (primeSetProduct (S.filter (fun p => Y < p))) /
        (primeSetProduct (S.filter (fun p => Y < p)) : ℝ)) *
      ‖fixedProductBooleanFourierCoeff T
        (fun p hp => (h2BooleanDyadicSmoothFiber_smooth_active hS p hp).1)
        ((j : ZMod (primeSetProduct T)) *
          (((ZMod.unitOfCoprime
            (primeSetProduct (S.filter (fun p => Y < p)))
            (h2_primeSetProduct_coprime
              (h2BooleanDyadicSmoothFiber_disjoint hS)
              (fun p hp => (h2BooleanDyadicSmoothFiber_smooth_active hS p hp).1)
              (fun p hp => (h2BooleanDyadicSmoothFiber_rough_active hS p hp).1)).symm)⁻¹ :
              (ZMod (primeSetProduct T))ˣ) : ZMod (primeSetProduct T)))‖ ^ 2 := by
  let R := S.filter (fun p => Y < p)
  have hT := h2BooleanDyadicSmoothFiber_smooth_active hS
  have hR := h2BooleanDyadicSmoothFiber_rough_active hS
  have hdisj : Disjoint T R := h2BooleanDyadicSmoothFiber_disjoint hS
  have hPrimeR : ∀ p ∈ R, p.Prime := fun p hp => (hR p hp).1
  have hRough : ∀ p ∈ R, Y < p := fun p hp => (Finset.mem_filter.mp hp).2
  have hpart : S = T ∪ R := h2BooleanDyadicSmoothFiber_partition hS
  have hweight :
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card =
        (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
        (finiteOmegaWeightReal R * h2BooleanV0 ^ R.card) := by
    rw [hpart]
    exact h2BooleanSecondWeight_union T R hdisj
  have hRweight := h2BooleanSecondTiltLift_primeSetProduct_div
    (q := q) (S := R) hR
  have hroughEq := h2BooleanRoughTiltLift_primeSetProduct
    (q := q) (Y := Y) (R := R) (c := h2BooleanSecondTilt)
    hPrimeR hRough
  have hcoeff := h2BooleanDyadicSmoothFiber_fourier_block_le
    (q := q) (Y := Y) (M := M) (T := T) (S := S) (j := j) hS
  have hTweight0 : 0 ≤ finiteOmegaWeightReal T * h2BooleanV0 ^ T.card :=
    mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hT)
      (pow_nonneg h2BooleanV0_nonneg _)
  have hRweight0 : 0 ≤ finiteOmegaWeightReal R * h2BooleanV0 ^ R.card :=
    mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hR)
      (pow_nonneg h2BooleanV0_nonneg _)
  rw [hweight]
  change
    (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
      (finiteOmegaWeightReal R * h2BooleanV0 ^ R.card) *
      h2BooleanFourierNormSq q S j ≤ _
  calc
    (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
        (finiteOmegaWeightReal R * h2BooleanV0 ^ R.card) *
        h2BooleanFourierNormSq q S j
      ≤ (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
        (finiteOmegaWeightReal R * h2BooleanV0 ^ R.card) *
        ‖fixedProductBooleanFourierCoeff T
          (fun p hp => (hT p hp).1)
          ((j : ZMod (primeSetProduct T)) *
            (((ZMod.unitOfCoprime (primeSetProduct R)
              (h2_primeSetProduct_coprime hdisj
                (fun p hp => (hT p hp).1) hPrimeR).symm)⁻¹ :
                (ZMod (primeSetProduct T))ˣ) : ZMod (primeSetProduct T)))‖ ^ 2 := by
          gcongr
    _ = (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
        (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt
          (primeSetProduct R) / (primeSetProduct R : ℝ)) *
        ‖fixedProductBooleanFourierCoeff T
          (fun p hp => (hT p hp).1)
          ((j : ZMod (primeSetProduct T)) *
            (((ZMod.unitOfCoprime (primeSetProduct R)
              (h2_primeSetProduct_coprime hdisj
                (fun p hp => (hT p hp).1) hPrimeR).symm)⁻¹ :
                (ZMod (primeSetProduct T))ˣ) : ZMod (primeSetProduct T)))‖ ^ 2 := by
          rw [hroughEq, hRweight]

#print axioms h2BooleanRoughTiltLift_primeSetProduct
#print axioms h2BooleanDyadicSmoothFiber_weight_fourier_le

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def h2BooleanDyadicRoughProducts
    (q Y M : ℕ) (T : Finset ℕ) : Finset ℕ :=
  (h2BooleanDyadicSmoothFiber q Y M T).image
    (fun S => primeSetProduct (S.filter (fun p => Y < p)))

lemma h2BooleanDyadicRoughProducts_mem
    {q Y M : ℕ} {T : Finset ℕ} {r : ℕ}
    (hr : r ∈ h2BooleanDyadicRoughProducts q Y M T) :
    ∃ S ∈ h2BooleanDyadicSmoothFiber q Y M T,
      primeSetProduct (S.filter (fun p => Y < p)) = r := by
  exact Finset.mem_image.mp hr

lemma h2BooleanDyadicRoughProducts_unique_set
    {q Y M : ℕ} {T : Finset ℕ} {r : ℕ}
    (hr : r ∈ h2BooleanDyadicRoughProducts q Y M T) :
    ∃! S, S ∈ h2BooleanDyadicSmoothFiber q Y M T ∧
      primeSetProduct (S.filter (fun p => Y < p)) = r := by
  rcases h2BooleanDyadicRoughProducts_mem hr with ⟨S, hS, hSr⟩
  refine ⟨S, ⟨hS, hSr⟩, ?_⟩
  intro U hU
  exact h2BooleanDyadicSmoothFiber_rough_product_injective
    (q := q) (Y := Y) (M := M) (T := T)
    hU.1 hS (hU.2.trans hSr.symm)

lemma h2BooleanDyadicRoughProducts_range
    {q Y M : ℕ} {T : Finset ℕ} {r : ℕ}
    (hr : r ∈ h2BooleanDyadicRoughProducts q Y M T) :
    M < primeSetProduct T * r ∧
      primeSetProduct T * r ≤ 2 * M := by
  rcases h2BooleanDyadicRoughProducts_mem hr with ⟨S, hS, hSr⟩
  have hsplit := h2BooleanDyadicSmoothFiber_product_split hS
  have hrange := h2BooleanDyadicSets_range
    (h2BooleanDyadicSmoothFiber_mem hS).1
  rw [hsplit, hSr] at hrange
  exact hrange

lemma h2BooleanDyadicRoughProducts_coprime_smooth
    {q Y M : ℕ} {T : Finset ℕ} {r : ℕ}
    (hr : r ∈ h2BooleanDyadicRoughProducts q Y M T) :
    r.Coprime (primeSetProduct T) := by
  rcases h2BooleanDyadicRoughProducts_mem hr with ⟨S, hS, hSr⟩
  let R := S.filter (fun p => Y < p)
  have hdisj := h2BooleanDyadicSmoothFiber_disjoint hS
  have hPrimeT : ∀ p ∈ T, p.Prime :=
    fun p hp => (h2BooleanDyadicSmoothFiber_smooth_active hS p hp).1
  have hPrimeR : ∀ p ∈ R, p.Prime :=
    fun p hp => (h2BooleanDyadicSmoothFiber_rough_active hS p hp).1
  have hc := h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR
  rw [hSr] at hc
  exact hc.symm

lemma h2BooleanDyadicRoughProducts_pos
    {q Y M : ℕ} {T : Finset ℕ} {r : ℕ}
    (hr : r ∈ h2BooleanDyadicRoughProducts q Y M T) : 0 < r := by
  rcases h2BooleanDyadicRoughProducts_mem hr with ⟨S, hS, hSr⟩
  have hPrimeR : ∀ p ∈ S.filter (fun p => Y < p), p.Prime :=
    fun p hp => (h2BooleanDyadicSmoothFiber_rough_active hS p hp).1
  rw [← hSr]
  exact primeSetProduct_pos hPrimeR

lemma h2BooleanDyadicRoughProducts_roughLift_eq
    {q Y M : ℕ} {T : Finset ℕ} {r : ℕ}
    (hr : r ∈ h2BooleanDyadicRoughProducts q Y M T) :
    h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r =
      h2BooleanTiltLift q h2BooleanSecondTilt r := by
  rcases h2BooleanDyadicRoughProducts_mem hr with ⟨S, hS, hSr⟩
  have hPrimeR : ∀ p ∈ S.filter (fun p => Y < p), p.Prime :=
    fun p hp => (h2BooleanDyadicSmoothFiber_rough_active hS p hp).1
  have hRough : ∀ p ∈ S.filter (fun p => Y < p), Y < p :=
    fun p hp => (Finset.mem_filter.mp hp).2
  rw [← hSr]
  exact h2BooleanRoughTiltLift_primeSetProduct hPrimeR hRough

#print axioms h2BooleanDyadicRoughProducts_range
#print axioms h2BooleanDyadicRoughProducts_coprime_smooth

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def h2BooleanRoughFiberTerm
    (q Y : ℕ) (T : Finset ℕ)
    (hT : ∀ p ∈ T, activeHighPrime q p)
    (j r : ℕ) : ℝ :=
  if hr : r.Coprime (primeSetProduct T) then
    (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r / (r : ℝ)) *
      ‖fixedProductBooleanFourierCoeff T
        (fun p hp => (hT p hp).1)
        ((j : ZMod (primeSetProduct T)) *
          (((ZMod.unitOfCoprime r hr)⁻¹ :
            (ZMod (primeSetProduct T))ˣ) : ZMod (primeSetProduct T)))‖ ^ 2
  else 0

lemma h2BooleanRoughFiberTerm_nonneg
    (q Y : ℕ) (T : Finset ℕ)
    (hT : ∀ p ∈ T, activeHighPrime q p)
    (j r : ℕ) :
    0 ≤ h2BooleanRoughFiberTerm q Y T hT j r := by
  unfold h2BooleanRoughFiberTerm
  split_ifs
  · exact mul_nonneg
      (div_nonneg
        (h2BooleanRoughTiltLift_nonneg q Y r h2BooleanSecondTilt_nonneg)
        (by positivity))
      (sq_nonneg _)
  · exact le_rfl

lemma h2BooleanRoughFiberTerm_eq_of_coprime
    {q Y : ℕ} {T : Finset ℕ}
    (hT : ∀ p ∈ T, activeHighPrime q p)
    (j r : ℕ) (hr : r.Coprime (primeSetProduct T)) :
    h2BooleanRoughFiberTerm q Y T hT j r =
      (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r / (r : ℝ)) *
      ‖fixedProductBooleanFourierCoeff T
        (fun p hp => (hT p hp).1)
        ((j : ZMod (primeSetProduct T)) *
          (((ZMod.unitOfCoprime r hr)⁻¹ :
            (ZMod (primeSetProduct T))ˣ) : ZMod (primeSetProduct T)))‖ ^ 2 := by
  unfold h2BooleanRoughFiberTerm
  rw [dif_pos hr]

lemma h2BooleanDyadicSmoothFiber_point_le_roughTerm
    {q Y M : ℕ} {T S : Finset ℕ} {j : ℕ}
    (hS : S ∈ h2BooleanDyadicSmoothFiber q Y M T) :
    finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
        h2BooleanFourierNormSq q S j ≤
      (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
        h2BooleanRoughFiberTerm q Y T
          (h2BooleanDyadicSmoothFiber_smooth_active hS) j
          (primeSetProduct (S.filter (fun p => Y < p))) := by
  have hc := h2BooleanDyadicRoughProducts_coprime_smooth
    (q := q) (Y := Y) (M := M) (T := T)
    (show primeSetProduct (S.filter (fun p => Y < p)) ∈
      h2BooleanDyadicRoughProducts q Y M T by
        exact Finset.mem_image.mpr ⟨S, hS, rfl⟩)
  rw [h2BooleanRoughFiberTerm_eq_of_coprime
    (h2BooleanDyadicSmoothFiber_smooth_active hS) j _ hc]
  simpa [mul_assoc] using h2BooleanDyadicSmoothFiber_weight_fourier_le
    (q := q) (Y := Y) (M := M) (T := T) (S := S) (j := j) hS

#print axioms h2BooleanDyadicSmoothFiber_point_le_roughTerm

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma h2BooleanDyadicSmoothFiber_point_le_roughTerm_with
    {q Y M : ℕ} {T S : Finset ℕ} {j : ℕ}
    (hT : ∀ p ∈ T, activeHighPrime q p)
    (hS : S ∈ h2BooleanDyadicSmoothFiber q Y M T) :
    finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
        h2BooleanFourierNormSq q S j ≤
      (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
        h2BooleanRoughFiberTerm q Y T hT j
          (primeSetProduct (S.filter (fun p => Y < p))) := by
  simpa only using
    h2BooleanDyadicSmoothFiber_point_le_roughTerm
      (q := q) (Y := Y) (M := M) (T := T) (S := S) (j := j) hS

lemma h2BooleanDyadicFrequencyFiberMoment_le_roughProducts
    {q Y M : ℕ} {T : Finset ℕ} {j : ℕ}
    (hT : ∀ p ∈ T, activeHighPrime q p) :
    h2BooleanDyadicFrequencyFiberMoment q Y M T j ≤
      (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
        ∑ r ∈ h2BooleanDyadicRoughProducts q Y M T,
          h2BooleanRoughFiberTerm q Y T hT j r := by
  unfold h2BooleanDyadicFrequencyFiberMoment
  calc
    (∑ S ∈ h2BooleanDyadicSmoothFiber q Y M T,
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
        h2BooleanFourierNormSq q S j)
      ≤ ∑ S ∈ h2BooleanDyadicSmoothFiber q Y M T,
        (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
          h2BooleanRoughFiberTerm q Y T hT j
            (primeSetProduct (S.filter (fun p => Y < p))) := by
          apply Finset.sum_le_sum
          intro S hS
          exact h2BooleanDyadicSmoothFiber_point_le_roughTerm_with hT hS
    _ = (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
        ∑ S ∈ h2BooleanDyadicSmoothFiber q Y M T,
          h2BooleanRoughFiberTerm q Y T hT j
            (primeSetProduct (S.filter (fun p => Y < p))) := by
          rw [Finset.mul_sum]
    _ = (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
        ∑ r ∈ h2BooleanDyadicRoughProducts q Y M T,
          h2BooleanRoughFiberTerm q Y T hT j r := by
          congr 1
          unfold h2BooleanDyadicRoughProducts
          rw [Finset.sum_image
            (h2BooleanDyadicSmoothFiber_rough_product_injective
              (q := q) (Y := Y) (M := M) (T := T))]

#print axioms h2BooleanDyadicFrequencyFiberMoment_le_roughProducts

end PaperB.FixedQ
namespace PaperB.FixedQ

lemma h2_unit_progression_sum
    {m x y : ℕ} [NeZero m]
    (f : ArithmeticFunction ℝ) (G : (ZMod m)ˣ → ℝ) :
    (∑ u : (ZMod m)ˣ,
      G u * PaperB.M4B.progressionSum f x y m (u : ZMod m).val) =
    ∑ n ∈ Finset.Ioc (x - y) x,
      if hn : n.Coprime m then f n * G (ZMod.unitOfCoprime n hn) else 0 := by
  unfold PaperB.M4B.progressionSum
  simp_rw [Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro n hnI
  by_cases hcop : n.Coprime m
  · rw [dif_pos hcop]
    let u0 : (ZMod m)ˣ := ZMod.unitOfCoprime n hcop
    rw [Fintype.sum_eq_single u0]
    · have hmod : n ≡ (u0 : ZMod m).val [MOD m] := by
        rw [← ZMod.natCast_eq_natCast_iff]
        rw [ZMod.natCast_zmod_val]
        exact (ZMod.coe_unitOfCoprime n hcop).symm
      rw [if_pos hmod]
      ring
    · intro u hune
      have hnmod : ¬ n ≡ (u : ZMod m).val [MOD m] := by
        intro hmod
        apply hune
        apply Units.ext
        change (u : ZMod m) = (u0 : ZMod m)
        have hcast : (n : ZMod m) = ((u : ZMod m).val : ZMod m) :=
          (ZMod.natCast_eq_natCast_iff n (u : ZMod m).val m).2 hmod
        calc
          (u : ZMod m) = ((u : ZMod m).val : ZMod m) :=
            (ZMod.natCast_zmod_val (u : ZMod m)).symm
          _ = (n : ZMod m) := hcast.symm
          _ = (u0 : ZMod m) := (ZMod.coe_unitOfCoprime n hcop).symm
      rw [if_neg hnmod]
      ring
  · rw [dif_neg hcop]
    apply Fintype.sum_eq_zero
    intro u
    have hnmod : ¬ n ≡ (u : ZMod m).val [MOD m] := by
      intro hmod
      apply hcop
      have hu : ((u : ZMod m).val).Coprime m :=
        (ZMod.unitsEquivCoprime u).property
      exact PaperB.M4B.coprime_of_modEq_reduced hu hmod
    rw [if_neg hnmod]
    ring

end PaperB.FixedQ

#print axioms PaperB.FixedQ.h2_unit_progression_sum

namespace PaperB.FixedQ

lemma h2_unit_progression_sum_le
    {m x y : ℕ} [NeZero m]
    (f : ArithmeticFunction ℝ) (G : (ZMod m)ˣ → ℝ)
    (B : ℝ)
    (hG : ∀ u, 0 ≤ G u)
    (hprog : ∀ u : (ZMod m)ˣ,
      PaperB.M4B.progressionSum f x y m (u : ZMod m).val ≤ B) :
    (∑ n ∈ Finset.Ioc (x - y) x,
      if hn : n.Coprime m then f n * G (ZMod.unitOfCoprime n hn) else 0) ≤
      B * ∑ u : (ZMod m)ˣ, G u := by
  rw [← h2_unit_progression_sum f G]
  calc
    (∑ u : (ZMod m)ˣ,
      G u * PaperB.M4B.progressionSum f x y m (u : ZMod m).val)
      ≤ ∑ u : (ZMod m)ˣ, G u * B := by
        apply Finset.sum_le_sum
        intro u hu
        exact mul_le_mul_of_nonneg_left (hprog u) (hG u)
    _ = B * ∑ u : (ZMod m)ˣ, G u := by
      rw [← Finset.sum_mul]
      ring

lemma h2_zmod_unit_val_pos
    {m : ℕ} [NeZero m] (hm1 : 1 < m) (u : (ZMod m)ˣ) :
    0 < (u : ZMod m).val := by
  have hc : (u : ZMod m).val.Coprime m :=
    (ZMod.unitsEquivCoprime u).property
  apply Nat.pos_of_ne_zero
  intro h0
  rw [h0] at hc
  have hmone : m = 1 := by simpa using hc
  omega

lemma h2_zmod_unit_val_coprime
    {m : ℕ} [NeZero m] (u : (ZMod m)ˣ) :
    (u : ZMod m).val.Coprime m :=
  (ZMod.unitsEquivCoprime u).property

theorem h2BooleanRoughUnitWeighted_progression
    (q Y : ℕ) :
    ∃ C : ℝ, ∃ X0 : ℕ, ∀
      (T : Finset ℕ) [NeZero (primeSetProduct T)]
      (hT : ∀ p ∈ T, activeHighPrime q p)
      (j x y : ℕ),
      1 < primeSetProduct T →
      X0 ≤ x →
      (x : ℝ) ^ (1 / 4 : ℝ) < (y : ℝ) →
      y ≤ x →
      (primeSetProduct T : ℝ) < (y : ℝ) ^ (3 / 4 : ℝ) →
      (∑ n ∈ Finset.Ioc (x - y) x,
        if hn : n.Coprime (primeSetProduct T) then
          h2BooleanRoughTiltLift q Y h2BooleanSecondTilt n *
            ‖fixedProductBooleanFourierCoeff T
              (fun p hp => (hT p hp).1)
              ((j : ZMod (primeSetProduct T)) *
                (((ZMod.unitOfCoprime n hn)⁻¹ :
                  (ZMod (primeSetProduct T))ˣ) :
                    ZMod (primeSetProduct T)))‖ ^ 2
        else 0) ≤
      C * ((y : ℝ) /
        (((primeSetProduct T).totient : ℝ) * Real.log (x : ℝ))) *
        Real.exp (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
          x (primeSetProduct T)) *
        (∑ u : (ZMod (primeSetProduct T))ˣ,
          ‖fixedProductBooleanFourierCoeff T
            (fun p hp => (hT p hp).1)
            ((j : ZMod (primeSetProduct T)) *
              (u : ZMod (primeSetProduct T)))‖ ^ 2) := by
  rcases h2BooleanRoughTiltLift_progression
      q Y h2BooleanSecondTilt_nonneg
        h2BooleanSecondTilt_le_three_halves with ⟨C, X0, hShiu⟩
  refine ⟨C, X0, ?_⟩
  intro T _ hT j x y hm1 hX hquarter hyx hmod
  let G : (ZMod (primeSetProduct T))ˣ → ℝ := fun u =>
    ‖fixedProductBooleanFourierCoeff T
      (fun p hp => (hT p hp).1)
      ((j : ZMod (primeSetProduct T)) *
        ((u⁻¹ : (ZMod (primeSetProduct T))ˣ) :
          ZMod (primeSetProduct T)))‖ ^ 2
  let B : ℝ :=
    C * ((y : ℝ) /
      (((primeSetProduct T).totient : ℝ) * Real.log (x : ℝ))) *
      Real.exp (PaperB.M4B.primeMass
        (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
        x (primeSetProduct T))
  have hG : ∀ u, 0 ≤ G u := fun u => sq_nonneg _
  have hprog : ∀ u : (ZMod (primeSetProduct T))ˣ,
      PaperB.M4B.progressionSum
        (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
        x y (primeSetProduct T) (u : ZMod (primeSetProduct T)).val ≤ B := by
    intro u
    have ha0 : 0 < (u : ZMod (primeSetProduct T)).val :=
      h2_zmod_unit_val_pos hm1 u
    have halt : (u : ZMod (primeSetProduct T)).val < primeSetProduct T :=
      ZMod.val_lt _
    have hacop : (u : ZMod (primeSetProduct T)).val.Coprime
        (primeSetProduct T) := h2_zmod_unit_val_coprime u
    exact hShiu x y (primeSetProduct T)
      (u : ZMod (primeSetProduct T)).val
      hX hquarter hyx hmod ha0 halt hacop
  have hsum := h2_unit_progression_sum_le
    (f := h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
    (G := G) B hG hprog
  dsimp [G, B] at hsum ⊢
  have hinv := h2_sum_units_inv
    (m := primeSetProduct T)
    (fun u : (ZMod (primeSetProduct T))ˣ =>
      ‖fixedProductBooleanFourierCoeff T
        (fun p hp => (hT p hp).1)
        ((j : ZMod (primeSetProduct T)) *
          (u : ZMod (primeSetProduct T)))‖ ^ 2)
  have hinv' :
      (∑ u : (ZMod (primeSetProduct T))ˣ,
        ‖fixedProductBooleanFourierCoeff T
          (fun p hp => (hT p hp).1)
          ((j : ZMod (primeSetProduct T)) *
            ((u⁻¹ : (ZMod (primeSetProduct T))ˣ) :
              ZMod (primeSetProduct T)))‖ ^ 2) =
      ∑ u : (ZMod (primeSetProduct T))ˣ,
        ‖fixedProductBooleanFourierCoeff T
          (fun p hp => (hT p hp).1)
          ((j : ZMod (primeSetProduct T)) *
            (u : ZMod (primeSetProduct T)))‖ ^ 2 := by
    simpa using hinv
  rw [hinv'] at hsum
  exact hsum

#print axioms h2BooleanRoughUnitWeighted_progression

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma h2_inv_le_modulus_div_of_product_gt
    {M m r : ℕ} (hM : 0 < M) (hmr : M < m * r) :
    (r : ℝ)⁻¹ ≤ (m : ℝ) / (M : ℝ) := by
  have hr : 0 < r := by
    by_contra h
    have : r = 0 := Nat.eq_zero_of_not_pos h
    subst r
    simp at hmr
  have hMR : (0 : ℝ) < M := by exact_mod_cast hM
  have hrR : (0 : ℝ) < r := by exact_mod_cast hr
  rw [inv_eq_one_div]
  apply (div_le_div_iff₀ hrR hMR).2
  simpa using (show (M : ℝ) ≤ (m * r : ℕ) by exact_mod_cast (Nat.le_of_lt hmr))

lemma h2BooleanDyadicRoughProducts_mem_cover
    {q Y M : ℕ} {T : Finset ℕ} {r : ℕ}
    (hr : r ∈ h2BooleanDyadicRoughProducts q Y M T) :
    r ∈ Finset.Ioc
      (PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T) -
        PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T))
      (PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)) := by
  have hTactive : ∀ p ∈ T, activeHighPrime q p := by
    rcases h2BooleanDyadicRoughProducts_mem hr with ⟨S, hS, hSr⟩
    exact h2BooleanDyadicSmoothFiber_smooth_active hS
  have hmpos : 0 < primeSetProduct T :=
    primeSetProduct_pos (fun p hp => (hTactive p hp).1)
  have hrange := h2BooleanDyadicRoughProducts_range hr
  apply PaperB.M4B.scaledCover_mem hmpos
  · have hsub : 2 * M - M = M := by omega
    rw [hsub]
    exact hrange.1
  · exact hrange.2

lemma h2BooleanDyadicRoughProducts_sum_le_cover
    {q Y M : ℕ} {T : Finset ℕ} {j : ℕ}
    (hM : 0 < M)
    (hT : ∀ p ∈ T, activeHighPrime q p) :
    (∑ r ∈ h2BooleanDyadicRoughProducts q Y M T,
      h2BooleanRoughFiberTerm q Y T hT j r) ≤
      ((primeSetProduct T : ℝ) / (M : ℝ)) *
      (∑ n ∈ Finset.Ioc
        (PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T) -
          PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T))
        (PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)),
        if hn : n.Coprime (primeSetProduct T) then
          h2BooleanRoughTiltLift q Y h2BooleanSecondTilt n *
            ‖fixedProductBooleanFourierCoeff T
              (fun p hp => (hT p hp).1)
              ((j : ZMod (primeSetProduct T)) *
                (((ZMod.unitOfCoprime n hn)⁻¹ :
                  (ZMod (primeSetProduct T))ˣ) :
                    ZMod (primeSetProduct T)))‖ ^ 2
        else 0) := by
  let I := Finset.Ioc
    (PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T) -
      PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T))
    (PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T))
  let H : ℕ → ℝ := fun n =>
    if hn : n.Coprime (primeSetProduct T) then
      h2BooleanRoughTiltLift q Y h2BooleanSecondTilt n *
        ‖fixedProductBooleanFourierCoeff T
          (fun p hp => (hT p hp).1)
          ((j : ZMod (primeSetProduct T)) *
            (((ZMod.unitOfCoprime n hn)⁻¹ :
              (ZMod (primeSetProduct T))ˣ) :
                ZMod (primeSetProduct T)))‖ ^ 2
    else 0
  have hscale0 : 0 ≤ (primeSetProduct T : ℝ) / (M : ℝ) := by positivity
  calc
    (∑ r ∈ h2BooleanDyadicRoughProducts q Y M T,
      h2BooleanRoughFiberTerm q Y T hT j r)
      ≤ ∑ r ∈ h2BooleanDyadicRoughProducts q Y M T,
          ((primeSetProduct T : ℝ) / (M : ℝ)) * H r := by
        apply Finset.sum_le_sum
        intro r hr
        have hcop := h2BooleanDyadicRoughProducts_coprime_smooth hr
        have hrange := h2BooleanDyadicRoughProducts_range hr
        have hinv := h2_inv_le_modulus_div_of_product_gt hM hrange.1
        rw [h2BooleanRoughFiberTerm_eq_of_coprime hT j r hcop]
        dsimp [H]
        rw [dif_pos hcop]
        have hf0 : 0 ≤ h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r :=
          h2BooleanRoughTiltLift_nonneg q Y r h2BooleanSecondTilt_nonneg
        have hW0 :
            0 ≤ ‖fixedProductBooleanFourierCoeff T
              (fun p hp => (hT p hp).1)
              ((j : ZMod (primeSetProduct T)) *
                (((ZMod.unitOfCoprime r hcop)⁻¹ :
                  (ZMod (primeSetProduct T))ˣ) :
                    ZMod (primeSetProduct T)))‖ ^ 2 := sq_nonneg _
        rw [div_eq_mul_inv]
        calc
          h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r * (r : ℝ)⁻¹ * _
            ≤ h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r *
                ((primeSetProduct T : ℝ) / (M : ℝ)) * _ := by
              gcongr
          _ = ((primeSetProduct T : ℝ) / (M : ℝ)) *
              (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt r *
                ‖fixedProductBooleanFourierCoeff T
                  (fun p hp => (hT p hp).1)
                  ((j : ZMod (primeSetProduct T)) *
                    (((ZMod.unitOfCoprime r hcop)⁻¹ :
                      (ZMod (primeSetProduct T))ˣ) :
                        ZMod (primeSetProduct T)))‖ ^ 2) := by ring
    _ ≤ ∑ n ∈ I, ((primeSetProduct T : ℝ) / (M : ℝ)) * H n := by
        apply Finset.sum_le_sum_of_subset_of_nonneg
        · intro r hr
          dsimp [I]
          exact h2BooleanDyadicRoughProducts_mem_cover hr
        · intro n hnI hnnot
          exact mul_nonneg hscale0 (by
            dsimp [H]
            split_ifs
            · exact mul_nonneg
                (h2BooleanRoughTiltLift_nonneg q Y n h2BooleanSecondTilt_nonneg)
                (sq_nonneg _)
            · exact le_rfl)
    _ = ((primeSetProduct T : ℝ) / (M : ℝ)) * ∑ n ∈ I, H n := by
        rw [Finset.mul_sum]
    _ = _ := by rfl

#print axioms h2BooleanDyadicRoughProducts_sum_le_cover

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem h2BooleanDyadicFrequencyFiberMoment_le_m3_cover
    (q Y : ℕ) :
    ∃ C : ℝ, ∃ X0 : ℕ, ∀
      (T : Finset ℕ) [NeZero (primeSetProduct T)]
      (hT : ∀ p ∈ T, activeHighPrime q p)
      (j M : ℕ),
      0 < M →
      1 < primeSetProduct T →
      let x := PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)
      let y := PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T)
      X0 ≤ x →
      (x : ℝ) ^ (1 / 4 : ℝ) < (y : ℝ) →
      y ≤ x →
      (primeSetProduct T : ℝ) < (y : ℝ) ^ (3 / 4 : ℝ) →
      h2BooleanDyadicFrequencyFiberMoment q Y M T j ≤
        ((primeSetProduct T : ℝ) / (M : ℝ)) * C *
          ((y : ℝ) / Real.log (x : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
            x (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
  rcases h2BooleanRoughUnitWeighted_progression q Y with ⟨C, X0, hunit⟩
  refine ⟨C, X0, ?_⟩
  intro T _ hT j M hM hm1
  dsimp
  intro hX hquarter hyx hmod
  let x := PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)
  let y := PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T)
  have hfiber := h2BooleanDyadicFrequencyFiberMoment_le_roughProducts
    (q := q) (Y := Y) (M := M) (T := T) (j := j) hT
  have hcover := h2BooleanDyadicRoughProducts_sum_le_cover
    (q := q) (Y := Y) (M := M) (T := T) (j := j) hM hT
  have hunit' := hunit T hT j x y hm1 hX hquarter hyx hmod
  have hTweight0 : 0 ≤ finiteOmegaWeightReal T * h2BooleanV0 ^ T.card :=
    mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hT)
      (pow_nonneg h2BooleanV0_nonneg _)
  have hscale0 : 0 ≤ (primeSetProduct T : ℝ) / (M : ℝ) := by positivity
  have hinterval0 :
      0 ≤ ∑ n ∈ Finset.Ioc (x - y) x,
        if hn : n.Coprime (primeSetProduct T) then
          h2BooleanRoughTiltLift q Y h2BooleanSecondTilt n *
            ‖fixedProductBooleanFourierCoeff T
              (fun p hp => (hT p hp).1)
              ((j : ZMod (primeSetProduct T)) *
                (((ZMod.unitOfCoprime n hn)⁻¹ :
                  (ZMod (primeSetProduct T))ˣ) :
                    ZMod (primeSetProduct T)))‖ ^ 2
        else 0 := by
    apply Finset.sum_nonneg
    intro n hn
    split_ifs
    · exact mul_nonneg
        (h2BooleanRoughTiltLift_nonneg q Y n h2BooleanSecondTilt_nonneg)
        (sq_nonneg _)
    · exact le_rfl
  have hrough :
      (∑ r ∈ h2BooleanDyadicRoughProducts q Y M T,
        h2BooleanRoughFiberTerm q Y T hT j r) ≤
      ((primeSetProduct T : ℝ) / (M : ℝ)) *
        (C * ((y : ℝ) /
          (((primeSetProduct T).totient : ℝ) * Real.log (x : ℝ))) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
            x (primeSetProduct T)) *
          (∑ u : (ZMod (primeSetProduct T))ˣ,
            ‖fixedProductBooleanFourierCoeff T
              (fun p hp => (hT p hp).1)
              ((j : ZMod (primeSetProduct T)) *
                (u : ZMod (primeSetProduct T)))‖ ^ 2)) := by
    calc
      (∑ r ∈ h2BooleanDyadicRoughProducts q Y M T,
        h2BooleanRoughFiberTerm q Y T hT j r)
        ≤ ((primeSetProduct T : ℝ) / (M : ℝ)) *
          (∑ n ∈ Finset.Ioc (x - y) x,
            if hn : n.Coprime (primeSetProduct T) then
              h2BooleanRoughTiltLift q Y h2BooleanSecondTilt n *
                ‖fixedProductBooleanFourierCoeff T
                  (fun p hp => (hT p hp).1)
                  ((j : ZMod (primeSetProduct T)) *
                    (((ZMod.unitOfCoprime n hn)⁻¹ :
                      (ZMod (primeSetProduct T))ˣ) :
                        ZMod (primeSetProduct T)))‖ ^ 2
            else 0) := by
              simpa [x, y] using hcover
      _ ≤ ((primeSetProduct T : ℝ) / (M : ℝ)) *
          (C * ((y : ℝ) /
            (((primeSetProduct T).totient : ℝ) * Real.log (x : ℝ))) *
            Real.exp (PaperB.M4B.primeMass
              (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
              x (primeSetProduct T)) *
            (∑ u : (ZMod (primeSetProduct T))ˣ,
              ‖fixedProductBooleanFourierCoeff T
                (fun p hp => (hT p hp).1)
                ((j : ZMod (primeSetProduct T)) *
                  (u : ZMod (primeSetProduct T)))‖ ^ 2)) :=
            mul_le_mul_of_nonneg_left hunit' hscale0
  have hmain := hfiber.trans (mul_le_mul_of_nonneg_left hrough hTweight0)
  have hcard :
      (Fintype.card (ZMod (primeSetProduct T))ˣ : ℝ) =
        ((primeSetProduct T).totient : ℝ) := by
    exact_mod_cast ZMod.card_units_eq_totient (primeSetProduct T)
  have hm3 := h2_weightedCompleteUnitFourierSecondMoment_eq_m3
    (q := q) (S := T) hT (j : ℤ)
  have hm3nat :
      finiteOmegaWeightReal T * h2BooleanV0 ^ T.card *
        (((Fintype.card (ZMod (primeSetProduct T))ˣ : ℝ)⁻¹) *
          (∑ u : (ZMod (primeSetProduct T))ˣ,
            ‖fixedProductBooleanFourierCoeff T
              (fun p hp => (hT p hp).1)
              ((j : ZMod (primeSetProduct T)) *
                (u : ZMod (primeSetProduct T)))‖ ^ 2)) =
        ∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ) := by
    simpa using hm3
  calc
    h2BooleanDyadicFrequencyFiberMoment q Y M T j
      ≤ (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
        (((primeSetProduct T : ℝ) / (M : ℝ)) *
          (C * ((y : ℝ) /
            (((primeSetProduct T).totient : ℝ) * Real.log (x : ℝ))) *
            Real.exp (PaperB.M4B.primeMass
              (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
              x (primeSetProduct T)) *
            (∑ u : (ZMod (primeSetProduct T))ˣ,
              ‖fixedProductBooleanFourierCoeff T
                (fun p hp => (hT p hp).1)
                ((j : ZMod (primeSetProduct T)) *
                  (u : ZMod (primeSetProduct T)))‖ ^ 2))) := hmain
    _ = ((primeSetProduct T : ℝ) / (M : ℝ)) * C *
        ((y : ℝ) / Real.log (x : ℝ)) *
        Real.exp (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
          x (primeSetProduct T)) *
        (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card *
          (((Fintype.card (ZMod (primeSetProduct T))ˣ : ℝ)⁻¹) *
            (∑ u : (ZMod (primeSetProduct T))ˣ,
              ‖fixedProductBooleanFourierCoeff T
                (fun p hp => (hT p hp).1)
                ((j : ZMod (primeSetProduct T)) *
                  (u : ZMod (primeSetProduct T)))‖ ^ 2))) := by
          rw [hcard]
          ring
    _ = ((primeSetProduct T : ℝ) / (M : ℝ)) * C *
        ((y : ℝ) / Real.log (x : ℝ)) *
        Real.exp (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
          x (primeSetProduct T)) *
        (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
          rw [hm3nat]
    _ = ((primeSetProduct T : ℝ) / (M : ℝ)) * C *
        ((PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T) : ℝ) /
          Real.log (PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T) : ℝ)) *
        Real.exp (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
          (PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T))
          (primeSetProduct T)) *
        (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
          rfl

#print axioms h2BooleanDyadicFrequencyFiberMoment_le_m3_cover

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma h2BooleanDyadic_smooth_filter_mem
    {q Y M : ℕ} {S : Finset ℕ}
    (hS : S ∈ h2BooleanDyadicSets q M) :
    S.filter (fun p => p ≤ Y) ∈
      (h2BooleanSmoothActivePrimeSet q Y).powerset := by
  rw [Finset.mem_powerset]
  intro p hp
  have hpF := Finset.mem_filter.mp hp
  have hpA := h2BooleanDyadicSets_active hS p hpF.1
  rw [h2BooleanSmoothActivePrimeSet, Finset.mem_filter]
  exact ⟨Nat.mem_primesLE.mpr ⟨hpF.2, hpA.1⟩, hpA⟩

lemma h2BooleanDyadicFrequencySecondMoment_eq_sum_fibers
    (q Y M j : ℕ) :
    h2BooleanDyadicFrequencySecondMoment q M j =
      ∑ T ∈ (h2BooleanSmoothActivePrimeSet q Y).powerset,
        h2BooleanDyadicFrequencyFiberMoment q Y M T j := by
  let F := h2BooleanDyadicSets q M
  let P := (h2BooleanSmoothActivePrimeSet q Y).powerset
  let phi : Finset ℕ → Finset ℕ := fun S => S.filter (fun p => p ≤ Y)
  let w : Finset ℕ → ℝ := fun S =>
    finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
      h2BooleanFourierNormSq q S j
  have hmaps : ∀ S ∈ F, phi S ∈ P := by
    intro S hS
    dsimp [F, P, phi] at hS ⊢
    exact h2BooleanDyadic_smooth_filter_mem hS
  have hfiber := Finset.sum_fiberwise_of_maps_to hmaps w
  unfold h2BooleanDyadicFrequencySecondMoment
  symm
  calc
    (∑ T ∈ (h2BooleanSmoothActivePrimeSet q Y).powerset,
      h2BooleanDyadicFrequencyFiberMoment q Y M T j)
      = ∑ T ∈ P, ∑ S ∈ F with phi S = T, w S := by
          apply Finset.sum_congr rfl
          intro T hT
          unfold h2BooleanDyadicFrequencyFiberMoment
          dsimp [h2BooleanDyadicSmoothFiber, F, phi, w]
    _ = ∑ S ∈ F, w S := hfiber
    _ = ∑ S ∈ h2BooleanDyadicSets q M,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
          h2BooleanFourierNormSq q S j := by rfl

#print axioms h2BooleanDyadicFrequencySecondMoment_eq_sum_fibers

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma h2BooleanM3LocalWeight_prod_nonneg
    {q : ℕ} {T : Finset ℕ} (j : ℤ)
    (hT : ∀ p ∈ T, activeHighPrime q p) :
    0 ≤ ∏ p ∈ T, h2BooleanM3LocalWeight q p j := by
  apply Finset.prod_nonneg
  intro p hp
  exact h2BooleanM3LocalWeight_nonneg j (hT p hp).1

lemma h2BooleanM3_sum_family_le_euler
    {q Y : ℕ} (j : ℤ) (F : Finset (Finset ℕ))
    (hF : F ⊆ (h2BooleanSmoothActivePrimeSet q Y).powerset) :
    (∑ T ∈ F, ∏ p ∈ T, h2BooleanM3LocalWeight q p j) ≤
      h2BooleanSmoothM3EulerMass q Y j := by
  unfold h2BooleanSmoothM3EulerMass
  apply Finset.sum_le_sum_of_subset_of_nonneg hF
  intro T hTP hnot
  have hTsub := Finset.mem_powerset.mp hTP
  apply h2BooleanM3LocalWeight_prod_nonneg
  intro p hp
  exact h2BooleanSmoothActivePrimeSet_active p (hTsub hp)

lemma h2BooleanM3_sum_family_le_log_powers
    {q Y j : ℕ} (hY : 4 ≤ Y) (hj : 4 ≤ j)
    (F : Finset (Finset ℕ))
    (hF : F ⊆ (h2BooleanSmoothActivePrimeSet q Y).powerset) :
    (∑ T ∈ F, ∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) ≤
      Real.exp (5 * h2BooleanV0 + 24) *
        (Real.log (Y : ℝ)) ^ (h2BooleanV0 / 2) *
        (Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by
  exact (h2BooleanM3_sum_family_le_euler (j : ℤ) F hF).trans
    (h2BooleanSmoothM3EulerMass_le_log_powers
      (q := q) (Y := Y) (j := j) hY hj)

#print axioms h2BooleanM3_sum_family_le_log_powers

end PaperB.FixedQ


namespace PaperB.FixedQ

/-- Uniform-in-the-moving-rough-cutoff version of the unit-weighted Shiu
consumer.  The paid fixed-quarter Shiu threshold is chosen before `Y`. -/
theorem h2BooleanRoughUnitWeighted_progression_uniform
    (q : ℕ) :
    ∃ X0 : ℕ, ∀
      (Y : ℕ)
      (T : Finset ℕ) [NeZero (primeSetProduct T)]
      (hT : ∀ p ∈ T, activeHighPrime q p)
      (j x y : ℕ),
      1 < primeSetProduct T →
      X0 ≤ x →
      (x : ℝ) ^ (1 / 4 : ℝ) < (y : ℝ) →
      y ≤ x →
      (primeSetProduct T : ℝ) < (y : ℝ) ^ (3 / 4 : ℝ) →
      (∑ n ∈ Finset.Ioc (x - y) x,
        if hn : n.Coprime (primeSetProduct T) then
          h2BooleanRoughTiltLift q Y h2BooleanSecondTilt n *
            ‖fixedProductBooleanFourierCoeff T
              (fun p hp => (hT p hp).1)
              ((j : ZMod (primeSetProduct T)) *
                (((ZMod.unitOfCoprime n hn)⁻¹ :
                  (ZMod (primeSetProduct T))ˣ) :
                    ZMod (primeSetProduct T)))‖ ^ 2
        else 0) ≤
      PaperB.M4B.shiuFixedQuarterAssembleConstant
          8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
        ((y : ℝ) /
          (((primeSetProduct T).totient : ℝ) * Real.log (x : ℝ))) *
        Real.exp (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
          x (primeSetProduct T)) *
        (∑ u : (ZMod (primeSetProduct T))ˣ,
          ‖fixedProductBooleanFourierCoeff T
            (fun p hp => (hT p hp).1)
            ((j : ZMod (primeSetProduct T)) *
              (u : ZMod (primeSetProduct T)))‖ ^ 2) := by
  rcases PaperB.M4B.shiuFixedQuarter_progression_uniform
      8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) with ⟨X0, hShiu⟩
  refine ⟨X0, ?_⟩
  intro Y T _ hT j x y hm1 hX hquarter hyx hmod
  let C : ℝ :=
    PaperB.M4B.shiuFixedQuarterAssembleConstant
      8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold)
  let G : (ZMod (primeSetProduct T))ˣ → ℝ := fun u =>
    ‖fixedProductBooleanFourierCoeff T
      (fun p hp => (hT p hp).1)
      ((j : ZMod (primeSetProduct T)) *
        ((u⁻¹ : (ZMod (primeSetProduct T))ˣ) :
          ZMod (primeSetProduct T)))‖ ^ 2
  let B : ℝ :=
    C * ((y : ℝ) /
      (((primeSetProduct T).totient : ℝ) * Real.log (x : ℝ))) *
      Real.exp (PaperB.M4B.primeMass
        (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
        x (primeSetProduct T))
  have hG : ∀ u, 0 ≤ G u := fun u => sq_nonneg _
  have henv :=
    h2BooleanRoughTiltLift_envelope q Y
      h2BooleanSecondTilt_nonneg h2BooleanSecondTilt_le_three_halves
  have hprog : ∀ u : (ZMod (primeSetProduct T))ˣ,
      PaperB.M4B.progressionSum
        (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
        x y (primeSetProduct T) (u : ZMod (primeSetProduct T)).val ≤ B := by
    intro u
    have ha0 : 0 < (u : ZMod (primeSetProduct T)).val :=
      h2_zmod_unit_val_pos hm1 u
    have halt : (u : ZMod (primeSetProduct T)).val < primeSetProduct T :=
      ZMod.val_lt _
    have hacop : (u : ZMod (primeSetProduct T)).val.Coprime
        (primeSetProduct T) := h2_zmod_unit_val_coprime u
    exact hShiu
      (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt) henv
      x y (primeSetProduct T) (u : ZMod (primeSetProduct T)).val
      hX hquarter hyx hmod ha0 halt hacop
  have hsum := h2_unit_progression_sum_le
    (f := h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
    (G := G) B hG hprog
  dsimp [G, B, C] at hsum ⊢
  have hinv := h2_sum_units_inv
    (m := primeSetProduct T)
    (fun u : (ZMod (primeSetProduct T))ˣ =>
      ‖fixedProductBooleanFourierCoeff T
        (fun p hp => (hT p hp).1)
        ((j : ZMod (primeSetProduct T)) *
          (u : ZMod (primeSetProduct T)))‖ ^ 2)
  have hinv' :
      (∑ u : (ZMod (primeSetProduct T))ˣ,
        ‖fixedProductBooleanFourierCoeff T
          (fun p hp => (hT p hp).1)
          ((j : ZMod (primeSetProduct T)) *
            ((u⁻¹ : (ZMod (primeSetProduct T))ˣ) :
              ZMod (primeSetProduct T)))‖ ^ 2) =
      ∑ u : (ZMod (primeSetProduct T))ˣ,
        ‖fixedProductBooleanFourierCoeff T
          (fun p hp => (hT p hp).1)
          ((j : ZMod (primeSetProduct T)) *
            (u : ZMod (primeSetProduct T)))‖ ^ 2 := by
    simpa using hinv
  rw [hinv'] at hsum
  exact hsum

#print axioms h2BooleanRoughUnitWeighted_progression_uniform

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem h2BooleanDyadicFrequencyFiberMoment_le_m3_cover_uniform
    (q : ℕ) :
    ∃ X0 : ℕ, ∀
      (Y : ℕ)
      (T : Finset ℕ) [NeZero (primeSetProduct T)]
      (hT : ∀ p ∈ T, activeHighPrime q p)
      (j M : ℕ),
      0 < M →
      1 < primeSetProduct T →
      let x := PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)
      let y := PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T)
      X0 ≤ x →
      (x : ℝ) ^ (1 / 4 : ℝ) < (y : ℝ) →
      y ≤ x →
      (primeSetProduct T : ℝ) < (y : ℝ) ^ (3 / 4 : ℝ) →
      h2BooleanDyadicFrequencyFiberMoment q Y M T j ≤
        ((primeSetProduct T : ℝ) / (M : ℝ)) *
          PaperB.M4B.shiuFixedQuarterAssembleConstant
            8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold) *
          ((y : ℝ) / Real.log (x : ℝ)) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
            x (primeSetProduct T)) *
          (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
  rcases h2BooleanRoughUnitWeighted_progression_uniform q with ⟨X0, hunit⟩
  refine ⟨X0, ?_⟩
  intro Y T _ hT j M hM hm1
  let C : ℝ := PaperB.M4B.shiuFixedQuarterAssembleConstant
    8 ((8 : ℝ)^h2BooleanShiuGrowthThreshold)
  dsimp
  intro hX hquarter hyx hmod
  change h2BooleanDyadicFrequencyFiberMoment q Y M T j ≤
    ((primeSetProduct T : ℝ) / (M : ℝ)) * C *
      ((PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T) : ℝ) /
        Real.log (PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T) : ℝ)) *
      Real.exp (PaperB.M4B.primeMass
        (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
        (PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T))
        (primeSetProduct T)) *
      (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ))
  let x := PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)
  let y := PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T)
  have hfiber := h2BooleanDyadicFrequencyFiberMoment_le_roughProducts
    (q := q) (Y := Y) (M := M) (T := T) (j := j) hT
  have hcover := h2BooleanDyadicRoughProducts_sum_le_cover
    (q := q) (Y := Y) (M := M) (T := T) (j := j) hM hT
  have hunit' := hunit Y T hT j x y hm1 hX hquarter hyx hmod
  have hTweight0 : 0 ≤ finiteOmegaWeightReal T * h2BooleanV0 ^ T.card :=
    mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hT)
      (pow_nonneg h2BooleanV0_nonneg _)
  have hscale0 : 0 ≤ (primeSetProduct T : ℝ) / (M : ℝ) := by positivity
  have hinterval0 :
      0 ≤ ∑ n ∈ Finset.Ioc (x - y) x,
        if hn : n.Coprime (primeSetProduct T) then
          h2BooleanRoughTiltLift q Y h2BooleanSecondTilt n *
            ‖fixedProductBooleanFourierCoeff T
              (fun p hp => (hT p hp).1)
              ((j : ZMod (primeSetProduct T)) *
                (((ZMod.unitOfCoprime n hn)⁻¹ :
                  (ZMod (primeSetProduct T))ˣ) :
                    ZMod (primeSetProduct T)))‖ ^ 2
        else 0 := by
    apply Finset.sum_nonneg
    intro n hn
    split_ifs
    · exact mul_nonneg
        (h2BooleanRoughTiltLift_nonneg q Y n h2BooleanSecondTilt_nonneg)
        (sq_nonneg _)
    · exact le_rfl
  have hrough :
      (∑ r ∈ h2BooleanDyadicRoughProducts q Y M T,
        h2BooleanRoughFiberTerm q Y T hT j r) ≤
      ((primeSetProduct T : ℝ) / (M : ℝ)) *
        (C * ((y : ℝ) /
          (((primeSetProduct T).totient : ℝ) * Real.log (x : ℝ))) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
            x (primeSetProduct T)) *
          (∑ u : (ZMod (primeSetProduct T))ˣ,
            ‖fixedProductBooleanFourierCoeff T
              (fun p hp => (hT p hp).1)
              ((j : ZMod (primeSetProduct T)) *
                (u : ZMod (primeSetProduct T)))‖ ^ 2)) := by
    calc
      (∑ r ∈ h2BooleanDyadicRoughProducts q Y M T,
        h2BooleanRoughFiberTerm q Y T hT j r)
        ≤ ((primeSetProduct T : ℝ) / (M : ℝ)) *
          (∑ n ∈ Finset.Ioc (x - y) x,
            if hn : n.Coprime (primeSetProduct T) then
              h2BooleanRoughTiltLift q Y h2BooleanSecondTilt n *
                ‖fixedProductBooleanFourierCoeff T
                  (fun p hp => (hT p hp).1)
                  ((j : ZMod (primeSetProduct T)) *
                    (((ZMod.unitOfCoprime n hn)⁻¹ :
                      (ZMod (primeSetProduct T))ˣ) :
                        ZMod (primeSetProduct T)))‖ ^ 2
            else 0) := by
              simpa [x, y] using hcover
      _ ≤ ((primeSetProduct T : ℝ) / (M : ℝ)) *
          (C * ((y : ℝ) /
            (((primeSetProduct T).totient : ℝ) * Real.log (x : ℝ))) *
            Real.exp (PaperB.M4B.primeMass
              (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
              x (primeSetProduct T)) *
            (∑ u : (ZMod (primeSetProduct T))ˣ,
              ‖fixedProductBooleanFourierCoeff T
                (fun p hp => (hT p hp).1)
                ((j : ZMod (primeSetProduct T)) *
                  (u : ZMod (primeSetProduct T)))‖ ^ 2)) :=
            mul_le_mul_of_nonneg_left hunit' hscale0
  have hmain := hfiber.trans (mul_le_mul_of_nonneg_left hrough hTweight0)
  have hcard :
      (Fintype.card (ZMod (primeSetProduct T))ˣ : ℝ) =
        ((primeSetProduct T).totient : ℝ) := by
    exact_mod_cast ZMod.card_units_eq_totient (primeSetProduct T)
  have hm3 := h2_weightedCompleteUnitFourierSecondMoment_eq_m3
    (q := q) (S := T) hT (j : ℤ)
  have hm3nat :
      finiteOmegaWeightReal T * h2BooleanV0 ^ T.card *
        (((Fintype.card (ZMod (primeSetProduct T))ˣ : ℝ)⁻¹) *
          (∑ u : (ZMod (primeSetProduct T))ˣ,
            ‖fixedProductBooleanFourierCoeff T
              (fun p hp => (hT p hp).1)
              ((j : ZMod (primeSetProduct T)) *
                (u : ZMod (primeSetProduct T)))‖ ^ 2)) =
        ∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ) := by
    simpa using hm3
  calc
    h2BooleanDyadicFrequencyFiberMoment q Y M T j
      ≤ (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
        (((primeSetProduct T : ℝ) / (M : ℝ)) *
          (C * ((y : ℝ) /
            (((primeSetProduct T).totient : ℝ) * Real.log (x : ℝ))) *
            Real.exp (PaperB.M4B.primeMass
              (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
              x (primeSetProduct T)) *
            (∑ u : (ZMod (primeSetProduct T))ˣ,
              ‖fixedProductBooleanFourierCoeff T
                (fun p hp => (hT p hp).1)
                ((j : ZMod (primeSetProduct T)) *
                  (u : ZMod (primeSetProduct T)))‖ ^ 2))) := hmain
    _ = ((primeSetProduct T : ℝ) / (M : ℝ)) * C *
        ((y : ℝ) / Real.log (x : ℝ)) *
        Real.exp (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
          x (primeSetProduct T)) *
        (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card *
          (((Fintype.card (ZMod (primeSetProduct T))ˣ : ℝ)⁻¹) *
            (∑ u : (ZMod (primeSetProduct T))ˣ,
              ‖fixedProductBooleanFourierCoeff T
                (fun p hp => (hT p hp).1)
                ((j : ZMod (primeSetProduct T)) *
                  (u : ZMod (primeSetProduct T)))‖ ^ 2))) := by
          rw [hcard]
          ring
    _ = ((primeSetProduct T : ℝ) / (M : ℝ)) * C *
        ((y : ℝ) / Real.log (x : ℝ)) *
        Real.exp (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
          x (primeSetProduct T)) *
        (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
          rw [hm3nat]
    _ = ((primeSetProduct T : ℝ) / (M : ℝ)) * C *
        ((PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T) : ℝ) /
          Real.log (PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T) : ℝ)) *
        Real.exp (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
          (PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T))
          (primeSetProduct T)) *
        (∏ p ∈ T, h2BooleanM3LocalWeight q p (j : ℤ)) := by
          rfl


#print axioms h2BooleanDyadicFrequencyFiberMoment_le_m3_cover_uniform

end PaperB.FixedQ


namespace PaperB.FixedQ

/-- Crude fiber bound used only for the Rankin-bad smooth family.  The
Fourier factor is discarded, and the remaining rough harmonic mass is paid
by the squarefree Euler-product bound. -/
theorem h2BooleanDyadicFrequencyFiberMoment_le_exp_rough_mass
    {q Y M : ℕ} {T : Finset ℕ} {j : ℕ}
    (hT : ∀ p ∈ T, activeHighPrime q p) :
    h2BooleanDyadicFrequencyFiberMoment q Y M T j ≤
      (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
        Real.exp (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt)
          (2 * M) (primeSetProduct T)) := by
  have hfiber := h2BooleanDyadicFrequencyFiberMoment_le_roughProducts
    (q := q) (Y := Y) (M := M) (T := T) (j := j) hT
  let f := h2BooleanRoughTiltLift q Y h2BooleanSecondTilt
  let R := h2BooleanDyadicRoughProducts q Y M T
  have hPrimeT : ∀ p ∈ T, p.Prime := fun p hp => (hT p hp).1
  have hmpos : 0 < primeSetProduct T := primeSetProduct_pos hPrimeT
  have hpoint : ∀ r ∈ R,
      h2BooleanRoughFiberTerm q Y T hT j r ≤ f r / (r : ℝ) := by
    intro r hr
    have hcop := h2BooleanDyadicRoughProducts_coprime_smooth
      (q := q) (Y := Y) (M := M) (T := T) hr
    rw [h2BooleanRoughFiberTerm_eq_of_coprime hT j r hcop]
    have hcoeff := norm_fixedProductBooleanFourierCoeff_le_one
      T hPrimeT
      ((j : ZMod (primeSetProduct T)) *
        (((ZMod.unitOfCoprime r hcop)⁻¹ :
          (ZMod (primeSetProduct T))ˣ) : ZMod (primeSetProduct T)))
    have hcoeff0 : 0 ≤
        ‖fixedProductBooleanFourierCoeff T hPrimeT
          ((j : ZMod (primeSetProduct T)) *
            (((ZMod.unitOfCoprime r hcop)⁻¹ :
              (ZMod (primeSetProduct T))ˣ) : ZMod (primeSetProduct T)))‖ := norm_nonneg _
    have hsqle :
        ‖fixedProductBooleanFourierCoeff T hPrimeT
          ((j : ZMod (primeSetProduct T)) *
            (((ZMod.unitOfCoprime r hcop)⁻¹ :
              (ZMod (primeSetProduct T))ˣ) : ZMod (primeSetProduct T)))‖ ^ 2 ≤ 1 := by
      nlinarith
    have hf0 : 0 ≤ f r := by
      dsimp [f]
      exact h2BooleanRoughTiltLift_nonneg q Y r h2BooleanSecondTilt_nonneg
    have hr0 : 0 ≤ (r : ℝ) := by positivity
    have hfr0 : 0 ≤ f r / (r : ℝ) := div_nonneg hf0 hr0
    exact mul_le_of_le_one_right hfr0 hsqle
  have hsubset : R ⊆
      (Finset.Icc 1 (2 * M)).filter
        (fun r => r.Coprime (primeSetProduct T)) := by
    intro r hr
    rw [Finset.mem_filter]
    have hrpos := h2BooleanDyadicRoughProducts_pos
      (q := q) (Y := Y) (M := M) (T := T) hr
    have hrange := h2BooleanDyadicRoughProducts_range
      (q := q) (Y := Y) (M := M) (T := T) hr
    have hrle : r ≤ 2 * M := by
      have hm1 : 1 ≤ primeSetProduct T := hmpos
      nlinarith
    exact ⟨Finset.mem_Icc.mpr ⟨hrpos, hrle⟩,
      h2BooleanDyadicRoughProducts_coprime_smooth
        (q := q) (Y := Y) (M := M) (T := T) hr⟩
  have hsum :
      (∑ r ∈ R, h2BooleanRoughFiberTerm q Y T hT j r) ≤
        PaperB.M4B.coprimeHarmonicMass f (2 * M) (primeSetProduct T) := by
    calc
      (∑ r ∈ R, h2BooleanRoughFiberTerm q Y T hT j r)
          ≤ ∑ r ∈ R, f r / (r : ℝ) := by
            apply Finset.sum_le_sum
            intro r hr
            exact hpoint r hr
      _ ≤ ∑ r ∈ (Finset.Icc 1 (2 * M)).filter
            (fun r => r.Coprime (primeSetProduct T)),
            f r / (r : ℝ) := by
          apply Finset.sum_le_sum_of_subset_of_nonneg hsubset
          intro r hr hnot
          exact div_nonneg
            (by
              dsimp [f]
              exact h2BooleanRoughTiltLift_nonneg
                q Y r h2BooleanSecondTilt_nonneg)
            (by positivity)
      _ = PaperB.M4B.coprimeHarmonicMass f (2 * M)
          (primeSetProduct T) := by
            rfl
  have heuler :
      PaperB.M4B.coprimeHarmonicMass f (2 * M) (primeSetProduct T) ≤
        Real.exp (PaperB.M4B.primeMass f (2 * M) (primeSetProduct T)) := by
    exact PaperB.M4B.squarefree_coprime_harmonic_upper
      (h2BooleanRoughTiltLift_envelope q Y
        h2BooleanSecondTilt_nonneg h2BooleanSecondTilt_le_three_halves)
      (2 * M) (primeSetProduct T)
  have hweight0 : 0 ≤ finiteOmegaWeightReal T * h2BooleanV0 ^ T.card :=
    mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hT)
      (pow_nonneg h2BooleanV0_nonneg _)
  calc
    h2BooleanDyadicFrequencyFiberMoment q Y M T j
      ≤ (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
          ∑ r ∈ R, h2BooleanRoughFiberTerm q Y T hT j r := by
            simpa [R] using hfiber
    _ ≤ (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
          PaperB.M4B.coprimeHarmonicMass f (2 * M)
            (primeSetProduct T) :=
      mul_le_mul_of_nonneg_left hsum hweight0
    _ ≤ (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
          Real.exp (PaperB.M4B.primeMass f (2 * M) (primeSetProduct T)) :=
      mul_le_mul_of_nonneg_left heuler hweight0
    _ = _ := by rfl

#print axioms h2BooleanDyadicFrequencyFiberMoment_le_exp_rough_mass

end PaperB.FixedQ
