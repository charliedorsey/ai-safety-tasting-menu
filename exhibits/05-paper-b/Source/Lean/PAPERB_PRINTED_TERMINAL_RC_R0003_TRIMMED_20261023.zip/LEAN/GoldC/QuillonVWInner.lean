import GoldC.QuillonCContext
import GoldC.QuillonPrimeSum

/-!
# Quillon CSC3 F7.5k: the VW inner prime sum (discharges `hVW` of `C_context`)

For `m₀` (a unit mod `s` and mod `M`) and the big-prime set `J = {p prime ∈ (P₀,P₁]} ∖ E` with `P₀ > M`:

    ‖Σ_{p∈J} ω(p)·1[pm₀∈(I₀,I₁]]·rowW(pm₀)‖
      ≤ Σ_ρ Σ_j ‖A_{ρj}‖·(wt(P₀+1)(β_j + log P₁·√P₁·log₂P₁) + 6/P₀ + |E|·2.5/P₀),

where `β_j` bounds all `Λ`-sums `Σ_{n∈(X₁,X']} Λ(n)·cphase(ρ', c_j m̄₀, n)` with `P₀ ≤ X₁ ≤ X' ≤ P₁`.
These are supplied by `vw_lambda_class`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset ArithmeticFunction

namespace GoldC.QuillonVWInner

open GoldC.QuillonVW GoldC.QuillonVWClass GoldC.QuillonPrimeSum GoldC.QuillonWBilinear
  GoldC.QuillonPContext

variable {s : ℕ} [NeZero s] {M : ℕ} [NeZero M]

lemma prime_unit_of_gt (p : ℕ) (hp : p.Prime) (hpM : M < p) : IsUnit (p : ZMod M) := by
  rw [ZMod.isUnit_iff_coprime]
  exact (Nat.Prime.coprime_iff_not_dvd hp).2 fun h =>
    absurd (Nat.le_of_dvd (Nat.pos_of_ne_zero (NeZero.ne M)) h) (by omega)

theorem VW_inner (𝒥 : Finset ℕ) (Acoef : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s) (m₀ : ℕ)
    (hm₀s : IsUnit (m₀ : ZMod s)) (hm₀M : IsUnit (m₀ : ZMod M)) (hm₀ : 1 ≤ m₀)
    (J E : Finset ℕ) (P₀ P₁ I₀ I₁ : ℕ)
    (hJ : ∀ p, p ∈ J ↔ (p.Prime ∧ p ∈ Ioc P₀ P₁ ∧ p ∉ E)) (hP₀M : M < P₀) (hP₀6 : 6 ≤ P₀)
    (βΛ : ℕ → ℝ) (hβ0 : ∀ j, 0 ≤ βΛ j)
    (hΛ : ∀ j ∈ 𝒥, ∀ ρ' : ZMod M, IsUnit ρ' → ∀ X₁ X', P₀ ≤ X₁ → X₁ ≤ X' → X' ≤ P₁ →
      ‖∑ n ∈ Ioc X₁ X', ((vonMangoldt n : ℝ) : ℂ) * cphase ρ' (c j * (m₀ : ZMod s)⁻¹) n‖ ≤ βΛ j) :
    ‖∑ p ∈ J, ((1 / ((p : ℝ) - 3) : ℝ) : ℂ) *
        (if p * m₀ ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (p * m₀) else 0)‖ ≤
      ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ *
        (wt (P₀ + 1) * (βΛ j + Real.log P₁ * (Nat.sqrt P₁ * Nat.log 2 P₁)) + 6 / P₀ +
          E.card * (2.5 / P₀)) := by
  classical
  set α : ℕ → ℂ := fun p => ((1 / ((p : ℝ) - 3) : ℝ) : ℂ) with hα
  -- the per-(ρ,j) inner sums
  set S : ZMod M → ℕ → ℂ := fun ρ j => ∑ p ∈ J, α p *
    (if p * m₀ ∈ Ioc I₀ I₁ then (if ((p * m₀ : ℕ) : ZMod M) = ρ then kphase (c j) (p * m₀) else 0)
      else 0) with hS
  have hexp : ∑ p ∈ J, α p * (if p * m₀ ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (p * m₀) else 0) =
      ∑ ρ : ZMod M, ∑ j ∈ 𝒥, Acoef ρ j * S ρ j := by
    symm
    calc ∑ ρ : ZMod M, ∑ j ∈ 𝒥, Acoef ρ j * S ρ j
        = ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ∑ p ∈ J, Acoef ρ j * (α p *
            (if p * m₀ ∈ Ioc I₀ I₁ then
              (if ((p * m₀ : ℕ) : ZMod M) = ρ then kphase (c j) (p * m₀) else 0) else 0)) := by
          simp only [hS, mul_sum]
      _ = ∑ ρ : ZMod M, ∑ p ∈ J, ∑ j ∈ 𝒥, Acoef ρ j * (α p *
            (if p * m₀ ∈ Ioc I₀ I₁ then
              (if ((p * m₀ : ℕ) : ZMod M) = ρ then kphase (c j) (p * m₀) else 0) else 0)) :=
          sum_congr rfl fun ρ _ => sum_comm
      _ = ∑ p ∈ J, ∑ ρ : ZMod M, ∑ j ∈ 𝒥, Acoef ρ j * (α p *
            (if p * m₀ ∈ Ioc I₀ I₁ then
              (if ((p * m₀ : ℕ) : ZMod M) = ρ then kphase (c j) (p * m₀) else 0) else 0)) := sum_comm
      _ = _ := by
          refine sum_congr rfl fun p _ => ?_
          unfold rowW
          by_cases hI : p * m₀ ∈ Ioc I₀ I₁
          · simp only [if_pos hI]
            rw [mul_sum]
            refine sum_congr rfl fun ρ _ => ?_
            by_cases hρ : ((p * m₀ : ℕ) : ZMod M) = ρ
            · simp only [if_pos hρ]
              rw [mul_sum]; exact sum_congr rfl fun j _ => by ring
            · simp only [if_neg hρ, mul_zero, sum_const_zero]
          · simp only [if_neg hI, mul_zero, sum_const_zero]
  rw [hexp]
  have hRHS0 : ∀ j, 0 ≤ wt (P₀ + 1) * (βΛ j + Real.log P₁ * (Nat.sqrt P₁ * Nat.log 2 P₁)) +
      6 / P₀ + E.card * (2.5 / P₀) := by
    intro j
    have := wt_nonneg (P₀ + 1)
    have := hβ0 j
    have : 0 ≤ Real.log P₁ := Real.log_natCast_nonneg P₁
    positivity
  have hP₀R : (6 : ℝ) ≤ P₀ := by exact_mod_cast hP₀6
  -- per-(ρ, j) bound
  have hSle : ∀ ρ, ∀ j ∈ 𝒥, ‖S ρ j‖ ≤ wt (P₀ + 1) * (βΛ j + Real.log P₁ * (Nat.sqrt P₁ * Nat.log 2 P₁)) +
      6 / P₀ + E.card * (2.5 / P₀) := by
    intro ρ j hj
    set ρ' := ρ * (m₀ : ZMod M)⁻¹ with hρ'
    set c' := c j * (m₀ : ZMod s)⁻¹ with hc'
    have hm1 : (m₀ : ZMod M) * (m₀ : ZMod M)⁻¹ = 1 := ZMod.mul_inv_of_unit _ hm₀M
    -- rewrite each summand via `cphase`
    have hterm : ∀ p ∈ J, (if p * m₀ ∈ Ioc I₀ I₁ then
        (if ((p * m₀ : ℕ) : ZMod M) = ρ then kphase (c j) (p * m₀) else 0) else 0) =
        (if p ∈ Ioc (I₀ / m₀) (I₁ / m₀) then cphase ρ' c' p else 0) := by
      intro p _
      have hiff := mem_Ioc_div_iff I₀ I₁ m₀ p hm₀
      by_cases hI : p * m₀ ∈ Ioc I₀ I₁
      · rw [if_pos hI, if_pos (hiff.2 (by rwa [mul_comm]))]
        unfold cphase
        have hcl : ((p * m₀ : ℕ) : ZMod M) = ρ ↔ (p : ZMod M) = ρ' := by
          push_cast
          constructor
          · intro h; rw [hρ', ← h, mul_assoc, hm1, mul_one]
          · intro h; rw [h, hρ', mul_assoc, mul_comm _ (m₀ : ZMod M), hm1, mul_one]
        by_cases h : (p : ZMod M) = ρ'
        · rw [if_pos (hcl.2 h), if_pos h, mul_comm p m₀, kphase_mul, if_pos hm₀s]
        · rw [if_neg (fun h' => h (hcl.1 h')), if_neg h]
      · rw [if_neg hI, if_neg (fun h => hI (by rw [mul_comm]; exact hiff.1 h))]
    have hS' : S ρ j = ∑ p ∈ J.filter (fun p => p ∈ Ioc (I₀ / m₀) (I₁ / m₀)), α p * cphase ρ' c' p := by
      simp only [hS]
      rw [sum_filter]
      refine sum_congr rfl fun p hp => ?_
      rw [hterm p hp]; split_ifs <;> simp
    rw [hS']
    by_cases hρu : IsUnit ρ'
    · set X₁ := max P₀ (I₀ / m₀)
      set X₂ := min P₁ (I₁ / m₀)
      have hset : J.filter (fun p => p ∈ Ioc (I₀ / m₀) (I₁ / m₀)) =
          ((Ioc X₁ X₂).filter Nat.Prime).filter (fun p => p ∉ E) := by
        ext p
        simp only [mem_filter, hJ, mem_Ioc, X₁, X₂, max_lt_iff, le_min_iff]
        tauto
      rw [hset]
      have hsplit := sum_filter_add_sum_filter_not ((Ioc X₁ X₂).filter Nat.Prime) (fun p => p ∉ E)
        (fun p => α p * cphase ρ' c' p)
      rw [eq_sub_of_add_eq hsplit]
      refine (norm_sub_le _ _).trans ?_
      apply add_le_add
      · -- the full prime sum
        rcases le_or_gt X₁ X₂ with hX12 | hX12
        · have hX16 : 6 ≤ X₁ := le_trans hP₀6 (le_max_left _ _)
          have hps := prime_sum_omega (cphase ρ' c') (norm_cphase_le ρ' c') X₁ X₂ hX16 hX12 (βΛ j)
            (fun j' hj1 hj2 => hΛ j hj ρ' hρu X₁ j' (le_max_left _ _) hj1
              (hj2.trans (min_le_left _ _)))
          refine hps.trans ?_
          have hw : wt (X₁ + 1) ≤ wt (P₀ + 1) := wt_antitone (by have := le_max_left P₀ (I₀ / m₀); omega)
          have hX₂P₁ : X₂ ≤ P₁ := min_le_left _ _
          have hlog : Real.log X₂ ≤ Real.log P₁ := by
            rcases Nat.eq_zero_or_pos X₂ with h | h
            · simp [h, Real.log_natCast_nonneg]
            · exact Real.log_le_log (by exact_mod_cast h) (by exact_mod_cast hX₂P₁)
          have hsq : (Nat.sqrt X₂ : ℝ) ≤ Nat.sqrt P₁ := by exact_mod_cast Nat.sqrt_le_sqrt hX₂P₁
          have hl2 : (Nat.log 2 X₂ : ℝ) ≤ Nat.log 2 P₁ := by exact_mod_cast Nat.log_mono_right hX₂P₁
          have h6 : (6 : ℝ) / X₁ ≤ 6 / P₀ := by
            apply div_le_div_of_nonneg_left (by norm_num) (by positivity)
            exact_mod_cast le_max_left _ _
          have : 0 ≤ Real.log X₂ := Real.log_natCast_nonneg _
          have := wt_nonneg (X₁ + 1)
          have := hβ0 j
          have : 0 ≤ (E.card : ℝ) * (2.5 / P₀) := by positivity
          have := wt_nonneg (P₀ + 1)
          gcongr
        · rw [Ioc_eq_empty (by omega), filter_empty, sum_empty, norm_zero]
          have := wt_nonneg (P₀ + 1)
          have := hβ0 j
          have : 0 ≤ Real.log P₁ := Real.log_natCast_nonneg P₁
          positivity
      · -- the excluded primes
        calc _ ≤ ∑ p ∈ ((Ioc X₁ X₂).filter Nat.Prime).filter (fun p => ¬ p ∉ E), ‖α p * cphase ρ' c' p‖ :=
              norm_sum_le _ _
          _ ≤ ∑ _p ∈ E, (2.5 / P₀ : ℝ) := by
              refine (sum_le_sum fun p hp => ?_).trans (sum_le_sum_of_subset_of_nonneg ?_ fun _ _ _ => by positivity)
              · have hp' := mem_filter.1 hp
                have hpX := (mem_Ioc.1 (mem_filter.1 hp'.1).1).1
                have hpP : (P₀ : ℝ) < p := by exact_mod_cast lt_of_le_of_lt (le_max_left _ _) hpX
                rw [norm_mul]
                calc ‖α p‖ * ‖cphase ρ' c' p‖ ≤ ‖α p‖ * 1 :=
                      mul_le_mul_of_nonneg_left (norm_cphase_le _ _ _) (norm_nonneg _)
                  _ ≤ 2.5 / P₀ := by
                      rw [mul_one]; simp only [hα]
                      rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (by apply div_nonneg zero_le_one; linarith)]
                      rw [div_le_div_iff₀ (by linarith) (by linarith)]
                      linarith
              · intro p hp; have := (mem_filter.1 hp).2; push Not at this; exact this
          _ = E.card * (2.5 / P₀) := by rw [sum_const, nsmul_eq_mul]
    · -- non-unit class: every summand vanishes
      have hz : ∑ p ∈ J.filter (fun p => p ∈ Ioc (I₀ / m₀) (I₁ / m₀)), α p * cphase ρ' c' p = 0 := by
        refine sum_eq_zero fun p hp => ?_
        have hpJ := (hJ p).1 (mem_filter.1 hp).1
        have hpu : IsUnit (p : ZMod M) := prime_unit_of_gt p hpJ.1
          (lt_of_lt_of_le hP₀M (le_of_lt (mem_Ioc.1 hpJ.2.1).1))
        unfold cphase
        rw [if_neg (fun h => hρu (by rw [← h]; exact hpu)), mul_zero]
      rw [hz, norm_zero]; exact hRHS0 j
  calc _ ≤ ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j * S ρ j‖ :=
        (norm_sum_le _ _).trans (sum_le_sum fun ρ _ => norm_sum_le _ _)
    _ ≤ _ := by
        refine sum_le_sum fun ρ _ => sum_le_sum fun j hj => ?_
        rw [norm_mul]
        exact mul_le_mul_of_nonneg_left (hSle ρ j hj) (norm_nonneg _)

end GoldC.QuillonVWInner
#print axioms GoldC.QuillonVWInner.VW_inner
