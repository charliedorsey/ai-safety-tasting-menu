import GoldC.QuillonVW
import GoldC.QuillonParsevalCell
import Mathlib.Data.Int.ModEq
import GoldC.QuillonDivisorMoment

/-!
# Quillon CSC3 F7.4d: VW Type II (Parseval + interval decoupling)

* `class_count`: `#{m' ∈ (a,b] : g ∣ m − m'} ≤ (b−a)/g + 1`.
* `parseval_block`: for a block `𝒟 ⊆ [1,Y]` and a fixed range `m ∈ (a,b]` with `‖b_m‖ ≤ β`,
  `‖Σ_{d∈𝒟} α_d Σ_m b_m kphase c (dm)‖² ≤ (Σ‖α‖²)(Y/s+1)s·β²(b−a)((b−a)/g'+1)`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset ArithmeticFunction

namespace GoldC.QuillonTypeII

open GoldC.QuillonVW GoldC.QuillonWCell GoldC.QuillonParsevalCell

lemma class_count (g a b m : ℕ) (hg : 1 ≤ g) :
    (((Ioc a b).filter (fun m' : ℕ => (g : ℤ) ∣ (m : ℤ) - m')).card : ℝ) ≤
      ((b - a : ℕ) : ℝ) / g + 1 := by
  set S := (Ioc a b).filter (fun m' : ℕ => (g : ℤ) ∣ (m : ℤ) - m')
  have hinj : Set.InjOn (fun m' => (m' - (a + 1)) / g) (S : Set ℕ) := by
    intro x hx y hy hxy
    simp only [S, coe_filter, mem_Ioc, Set.mem_ofPred_eq] at hx hy
    simp only at hxy
    have hd : (g : ℤ) ∣ (y : ℤ) - x := by
      have := dvd_sub hx.2 hy.2; convert this using 1; ring
    have hmod : x ≡ y [MOD g] := Int.natCast_modEq_iff.1 (Int.modEq_of_dvd hd)
    have hmod' : x - (a + 1) ≡ y - (a + 1) [MOD g] := by
      have e1 : x = (x - (a + 1)) + (a + 1) := by omega
      have e2 : y = (y - (a + 1)) + (a + 1) := by omega
      rw [e1, e2] at hmod
      exact Nat.ModEq.add_right_cancel' (a + 1) hmod
    have h1 := Nat.div_add_mod (x - (a + 1)) g
    have h2 := Nat.div_add_mod (y - (a + 1)) g
    rw [hxy, hmod'] at h1
    omega
  have hmaps : ∀ x ∈ S, (x - (a + 1)) / g ∈ range ((b - (a + 1)) / g + 1) := by
    intro x hx
    simp only [S, mem_filter, mem_Ioc] at hx
    rw [mem_range]
    exact Nat.lt_succ_of_le (Nat.div_le_div_right (by omega))
  have hc := card_le_card_of_injOn _ hmaps hinj
  rw [card_range] at hc
  have hgR : (0 : ℝ) < g := by exact_mod_cast hg
  calc (S.card : ℝ) ≤ (((b - (a + 1)) / g + 1 : ℕ) : ℝ) := by exact_mod_cast hc
    _ ≤ ((b - (a + 1) : ℕ) : ℝ) / g + 1 := by push_cast; linarith [Nat.cast_div_le (α := ℝ) (m := b - (a + 1)) (n := g)]
    _ ≤ _ := by
        have h : ((b - (a + 1) : ℕ) : ℝ) ≤ ((b - a : ℕ) : ℝ) := by
          exact_mod_cast (show b - (a + 1) ≤ b - a by omega)
        linarith [div_le_div_of_nonneg_right h hgR.le]

section block
variable {s : ℕ} [NeZero s]

theorem parseval_block (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p)
    (c : ZMod s) (Y : ℕ) (𝒟 : Finset ℕ) (h𝒟 : 𝒟 ⊆ Icc 1 Y) (a b : ℕ) (α bc : ℕ → ℂ) (β : ℝ)
    (hb : ∀ m ∈ Ioc a b, ‖bc m‖ ≤ β) :
    ‖∑ d ∈ 𝒟, α d * ∑ m ∈ Ioc a b, bc m * kphase c (d * m)‖ ^ 2 ≤
      (∑ d ∈ 𝒟, ‖α d‖ ^ 2) * ((Y : ℝ) / s + 1) * s *
        (β ^ 2 * (((b - a : ℕ) : ℝ) * (((b - a : ℕ) : ℝ) /
          ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ) + 1))) := by
  classical
  set g : ℕ := ∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p with hg
  have hg1 : 1 ≤ g := Nat.one_le_iff_ne_zero.2 (Finset.prod_ne_zero_iff.2 fun p hp =>
    (hP p (filter_subset _ _ hp)).ne_zero)
  have hβ : ∀ m ∈ Ioc a b, 0 ≤ β := fun m hm => (norm_nonneg _).trans (hb m hm)
  set 𝒟' := 𝒟.filter (fun d => Nat.Coprime d s)
  set bc' : ℕ → ℂ := fun m => if IsUnit (m : ZMod s) then bc m else 0
  have hrew : ∑ d ∈ 𝒟, α d * ∑ m ∈ Ioc a b, bc m * kphase c (d * m) =
      ∑ d ∈ 𝒟', ∑ m ∈ Ioc a b, α d * bc' m *
        ZMod.stdAddChar (c * (d : ZMod s)⁻¹ * (fun m : ℕ => (m : ZMod s)⁻¹) m) := by
    rw [sum_filter]
    refine sum_congr rfl fun d _ => ?_
    split_ifs with hd
    · rw [mul_sum]
      refine sum_congr rfl fun m _ => ?_
      have hdu : IsUnit (d : ZMod s) := (ZMod.isUnit_iff_coprime d s).2 hd
      rw [kphase_mul, if_pos hdu]
      simp only [bc', kphase]
      split_ifs with hm
      · rw [mul_assoc c]; ring
      · ring
    · have hdu : ¬ IsUnit (d : ZMod s) := fun h => hd ((ZMod.isUnit_iff_coprime d s).1 h)
      simp only [kphase_mul, if_neg hdu, mul_zero, sum_const_zero]
  rw [hrew]
  refine (GoldC.QuillonParseval.parseval_bilinear c (fun m : ℕ => (m : ZMod s)⁻¹) Y 𝒟' (Ioc a b)
    ((filter_subset _ _).trans h𝒟) (fun d hd => (mem_filter.1 hd).2) α bc').trans ?_
  have hYs : (0 : ℝ) ≤ ((Y : ℝ) / s + 1) * s := by positivity
  have hA : ∑ d ∈ 𝒟', ‖α d‖ ^ 2 ≤ ∑ d ∈ 𝒟, ‖α d‖ ^ 2 :=
    sum_le_sum_of_subset_of_nonneg (filter_subset _ _) fun _ _ _ => by positivity
  have hpair : ∑ m ∈ Ioc a b, ∑ m' ∈ Ioc a b,
      (if c * ((fun m : ℕ => (m : ZMod s)⁻¹) m - (fun m : ℕ => (m : ZMod s)⁻¹) m') = 0 then
        ‖bc' m‖ * ‖bc' m'‖ else 0) ≤
      β ^ 2 * (((b - a : ℕ) : ℝ) * (((b - a : ℕ) : ℝ) / (g : ℝ) + 1)) := by
    have hpt : ∀ m ∈ Ioc a b, ∀ m' ∈ Ioc a b,
        (if c * ((fun m : ℕ => (m : ZMod s)⁻¹) m - (fun m : ℕ => (m : ZMod s)⁻¹) m') = 0 then
          ‖bc' m‖ * ‖bc' m'‖ else 0) ≤
        β ^ 2 * (if (g : ℤ) ∣ (m : ℤ) - m' then 1 else 0) := by
      intro m hm m' hm'
      simp only [bc']
      by_cases hmu : IsUnit (m : ZMod s)
      · by_cases hmu' : IsUnit (m' : ZMod s)
        · split_ifs with h0 hdvd hdvd
          · rw [mul_one, sq]; exact mul_le_mul (hb m hm) (hb m' hm') (norm_nonneg _) (hβ m hm)
          · exact absurd (freq_zero_dvd P hP hsP c m m' hmu hmu' h0) hdvd
          · rw [mul_one]; positivity
          · rw [mul_zero]
        · simp only [if_neg hmu', norm_zero, mul_zero, ite_self]
          positivity
      · simp only [if_neg hmu, norm_zero, zero_mul, ite_self]
        positivity
    calc _ ≤ ∑ m ∈ Ioc a b, ∑ m' ∈ Ioc a b, β ^ 2 * (if (g : ℤ) ∣ (m : ℤ) - m' then (1 : ℝ) else 0) :=
          sum_le_sum fun m hm => sum_le_sum fun m' hm' => hpt m hm m' hm'
      _ = β ^ 2 * ∑ m ∈ Ioc a b, ((((Ioc a b).filter
            (fun m' : ℕ => (g : ℤ) ∣ (m : ℤ) - m')).card : ℕ) : ℝ) := by
          rw [mul_sum]; refine sum_congr rfl fun m _ => ?_
          rw [← mul_sum, sum_ite, sum_const_zero, add_zero, sum_const, nsmul_eq_mul, mul_one]
      _ ≤ β ^ 2 * ∑ _m ∈ Ioc a b, (((b - a : ℕ) : ℝ) / g + 1) := by
          gcongr with m _; exact class_count g a b m hg1
      _ = _ := by rw [sum_const, Nat.card_Ioc, nsmul_eq_mul]
  calc (∑ d ∈ 𝒟', ‖α d‖ ^ 2) * ((Y : ℝ) / s + 1) * s * _
      ≤ (∑ d ∈ 𝒟, ‖α d‖ ^ 2) * ((Y : ℝ) / s + 1) * s *
          (β ^ 2 * (((b - a : ℕ) : ℝ) * (((b - a : ℕ) : ℝ) / (g : ℝ) + 1))) := by
        rw [mul_assoc _ _ (s : ℝ), mul_assoc _ _ (s : ℝ)]
        apply mul_le_mul (mul_le_mul_of_nonneg_right hA hYs) hpair
        · exact sum_nonneg fun m _ => sum_nonneg fun m' _ => by split_ifs <;> positivity
        · positivity

end block

/-! ## Interval decoupling -/

lemma sum_Ioc_sub_eq (f : ℕ → ℂ) (x y : ℕ) (hxy : x ≤ y) :
    ∑ m ∈ Ioc x y, f m = ∑ m ∈ Ioc 0 y, f m - ∑ m ∈ Ioc 0 x, f m := by
  rw [← sum_Ioc_consecutive f (Nat.zero_le x) hxy]; ring

lemma Ioc_shift_bound (f : ℕ → ℂ) (a₁ a a₂ b₁ b b₂ : ℕ) (h1 : a₁ ≤ a) (h2 : a ≤ a₂)
    (h3 : b₁ ≤ b) (h4 : b ≤ b₂) (hab : a ≤ b) (hab2 : a₂ ≤ b₂) :
    ‖∑ m ∈ Ioc a b, f m - ∑ m ∈ Ioc a₂ b₂, f m‖ ≤
      ∑ m ∈ Ioc a₁ a₂, ‖f m‖ + ∑ m ∈ Ioc b₁ b₂, ‖f m‖ := by
  rw [sum_Ioc_sub_eq f a b hab, sum_Ioc_sub_eq f a₂ b₂ hab2]
  have e : ∑ m ∈ Ioc 0 b, f m - ∑ m ∈ Ioc 0 a, f m - (∑ m ∈ Ioc 0 b₂, f m - ∑ m ∈ Ioc 0 a₂, f m)
      = ∑ m ∈ Ioc a a₂, f m - ∑ m ∈ Ioc b b₂, f m := by
    rw [sum_Ioc_sub_eq f a a₂ h2, sum_Ioc_sub_eq f b b₂ h4]; ring
  rw [e]
  refine (norm_sub_le _ _).trans (add_le_add ?_ ?_)
  · exact (norm_sum_le _ _).trans (sum_le_sum_of_subset_of_nonneg (Ioc_subset_Ioc_left h1)
      fun _ _ _ => norm_nonneg _)
  · exact (norm_sum_le _ _).trans (sum_le_sum_of_subset_of_nonneg (Ioc_subset_Ioc_left h3)
      fun _ _ _ => norm_nonneg _)

lemma sum_Ioc_telescope (g : ℕ → ℂ) (t : ℕ → ℕ) (htm : Monotone t) (J : ℕ) :
    ∑ d ∈ Ioc (t 0) (t J), g d = ∑ j ∈ range J, ∑ d ∈ Ioc (t j) (t (j + 1)), g d := by
  induction J with
  | zero => simp
  | succ J ih =>
    rw [sum_range_succ, ← ih, sum_Ioc_consecutive _ (htm (Nat.zero_le J)) (htm (Nat.le_succ J))]

/-- **Decoupling.** Replacing the coupled range `m ∈ (A/d, B/d]` by `(A/t_j, B/t_j]` on each
block `d ∈ (t_j, t_{j+1}]` costs at most the boundary masses. -/
theorem decouple (α : ℕ → ℂ) (f : ℕ → ℕ → ℂ) (A B : ℕ) (hAB : A ≤ B) (t : ℕ → ℕ) (J : ℕ)
    (ht1 : 1 ≤ t 0) (htm : Monotone t) :
    ‖∑ d ∈ Ioc (t 0) (t J), α d * ∑ m ∈ Ioc (A / d) (B / d), f d m‖ ≤
      ∑ j ∈ range J, ‖∑ d ∈ Ioc (t j) (t (j + 1)), α d *
          ∑ m ∈ Ioc (A / t j) (B / t j), f d m‖ +
        ∑ j ∈ range J, ∑ d ∈ Ioc (t j) (t (j + 1)), ‖α d‖ *
          (∑ m ∈ Ioc (A / t (j + 1)) (A / t j), ‖f d m‖ +
            ∑ m ∈ Ioc (B / t (j + 1)) (B / t j), ‖f d m‖) := by
  rw [sum_Ioc_telescope _ t htm J, ← sum_add_distrib]
  refine (norm_sum_le _ _).trans (sum_le_sum fun j _ => ?_)
  have htj : 1 ≤ t j := ht1.trans (htm (Nat.zero_le j))
  have hsplit : ∑ d ∈ Ioc (t j) (t (j + 1)), α d * ∑ m ∈ Ioc (A / d) (B / d), f d m =
      ∑ d ∈ Ioc (t j) (t (j + 1)), α d * ∑ m ∈ Ioc (A / t j) (B / t j), f d m +
      ∑ d ∈ Ioc (t j) (t (j + 1)), α d * (∑ m ∈ Ioc (A / d) (B / d), f d m -
        ∑ m ∈ Ioc (A / t j) (B / t j), f d m) := by
    rw [← sum_add_distrib]; refine sum_congr rfl fun d _ => by ring
  rw [hsplit]
  refine (norm_add_le _ _).trans (add_le_add le_rfl ?_)
  refine (norm_sum_le _ _).trans (sum_le_sum fun d hd => ?_)
  rw [norm_mul]
  apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
  have hd' := mem_Ioc.1 hd
  have hd0 : 0 < d := by omega
  exact Ioc_shift_bound (f d) _ _ _ _ _ _ (Nat.div_le_div_left hd'.2 hd0)
    (Nat.div_le_div_left hd'.1.le (by omega)) (Nat.div_le_div_left hd'.2 hd0)
    (Nat.div_le_div_left hd'.1.le (by omega)) (Nat.div_le_div_right hAB)
    (Nat.div_le_div_right hAB)

/-! ## Type II coefficients -/

lemma coefII_support (U d : ℕ) (hd : d ≤ U) :
    ((GoldC.QuillonVaughan.upper U μR) * ζR) d = 0 := by
  rw [mul_apply]
  refine sum_eq_zero fun x hx => ?_
  have hx' := Nat.mem_divisorsAntidiagonal.1 hx
  have hd0 : d ≠ 0 := hx'.2
  have h1 : x.1 ≤ U := (Nat.le_of_dvd (Nat.pos_of_ne_zero hd0) ⟨x.2, hx'.1.symm⟩).trans hd
  rw [GoldC.QuillonVaughan.upper_apply, if_pos h1, zero_mul]

lemma coefII_bound (U d : ℕ) :
    |((GoldC.QuillonVaughan.upper U μR) * ζR) d| ≤ (d.divisors.card : ℝ) := by
  rw [mul_apply]
  refine (abs_sum_le_sum_abs _ _).trans ?_
  calc _ ≤ ∑ x ∈ d.divisorsAntidiagonal, (1 : ℝ) := by
        refine sum_le_sum fun x _ => ?_
        rw [abs_mul, GoldC.QuillonVaughan.upper_apply]
        have h1 : |(if x.1 ≤ U then (0 : ℝ) else μR x.1)| ≤ 1 := by
          split_ifs
          · simp
          · simp only [μR, intCoe_apply]; exact_mod_cast abs_moebius_le_one
        have h2 : |ζR x.2| ≤ 1 := by
          simp only [ζR, natCoe_apply, zeta_apply]; split_ifs <;> simp
        calc _ ≤ (1 : ℝ) * 1 := mul_le_mul h1 h2 (abs_nonneg _) zero_le_one
          _ = 1 := one_mul 1
    _ = ∑ x ∈ d.divisors, (1 : ℝ) := Nat.sum_divisorsAntidiagonal (fun _ _ => (1 : ℝ))
    _ = _ := by rw [sum_const, nsmul_eq_mul, mul_one]

lemma convII_eq (U V : ℕ) :
    (GoldC.QuillonVaughan.upper U μR) * (GoldC.QuillonVaughan.upper V vonMangoldt) * ζR =
      ((GoldC.QuillonVaughan.upper U μR) * ζR) * (GoldC.QuillonVaughan.upper V vonMangoldt) :=
  mul_right_comm _ _ _

lemma upperΛ_le (V m B : ℕ) (hmB : m ≤ B) :
    ‖(((GoldC.QuillonVaughan.upper V vonMangoldt) m : ℝ) : ℂ)‖ ≤ Real.log B := by
  rw [Complex.norm_real, Real.norm_eq_abs, GoldC.QuillonVaughan.upper_apply]
  split_ifs
  · simp [Real.log_natCast_nonneg]
  · rw [abs_of_nonneg vonMangoldt_nonneg]
    refine vonMangoldt_le_log.trans ?_
    rcases Nat.eq_zero_or_pos m with h | h
    · rw [h, Nat.cast_zero, Real.log_zero]; exact Real.log_natCast_nonneg B
    · exact Real.log_le_log (by exact_mod_cast h) (by exact_mod_cast hmB)

section typeII
variable {s : ℕ} [NeZero s]

/-- **Type II, explicit form** for an arbitrary monotone partition `U = t₀ ≤ t₁ ≤ … ≤ t_J`
with `(V+1)·t_J > B`. Here `L_j = ⌊B/t_j⌋ − ⌊A/t_j⌋` and `g' = ∏_{p∈P, p∤c} p`. -/
theorem typeII_abstract (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p)
    (c : ZMod s) (U V A B : ℕ) (hAB : A ≤ B) (t : ℕ → ℕ) (J : ℕ) (ht0 : t 0 = U) (hU : 1 ≤ U)
    (htm : Monotone t) (htJ : B < (V + 1) * t J) :
    ‖∑ n ∈ Ioc A B, ((((GoldC.QuillonVaughan.upper U μR) *
        (GoldC.QuillonVaughan.upper V vonMangoldt) * ζR) n : ℝ) : ℂ) * kphase c n‖ ≤
      ∑ j ∈ range J, Real.sqrt ((∑ d ∈ Ioc (t j) (t (j + 1)), ((d.divisors.card : ℝ)) ^ 2) *
          (((t (j + 1) : ℕ) : ℝ) / s + 1) * s *
          (Real.log B ^ 2 * (((B / t j - A / t j : ℕ) : ℝ) * (((B / t j - A / t j : ℕ) : ℝ) /
            ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ) + 1)))) +
        ∑ j ∈ range J, ∑ d ∈ Ioc (t j) (t (j + 1)), (d.divisors.card : ℝ) *
          (Real.log B * (((A / t j - A / t (j + 1) : ℕ) : ℝ) + ((B / t j - B / t (j + 1) : ℕ) : ℝ))) := by
  classical
  set a := (GoldC.QuillonVaughan.upper U μR) * ζR with ha
  set bΛ := GoldC.QuillonVaughan.upper V vonMangoldt with hbΛ
  rw [convII_eq, sum_Ioc_conv_twist_AB _ _ _ A B hAB]
  set F : ℕ → ℂ := fun d => (a d : ℂ) * ∑ m ∈ Ioc (A / d) (B / d), (bΛ m : ℂ) * kphase c (d * m)
    with hF
  have hext : ∑ d ∈ Ioc 0 B, F d = ∑ d ∈ Ioc (t 0) (t J), F d := by
    have hFB : ∀ d, B < d → F d = 0 := by
      intro d hd
      simp only [hF, Nat.div_eq_of_lt hd, Nat.div_eq_of_lt (lt_of_le_of_lt hAB hd), Ioc_self,
        sum_empty, mul_zero]
    have hFJ : ∀ d, t J < d → F d = 0 := by
      intro d hd
      simp only [hF]
      rw [sum_eq_zero, mul_zero]
      intro m hm
      have hm2 := (mem_Ioc.1 hm).2
      have hmV : m ≤ V := by
        have h1 : B / d ≤ B / t J := Nat.div_le_div_left hd.le (by
          rcases Nat.eq_zero_or_pos (t J) with h | h
          · rw [h, mul_zero] at htJ; omega
          · exact h)
        have h2 : B / t J < V + 1 := by
          rw [Nat.div_lt_iff_lt_mul (by
            rcases Nat.eq_zero_or_pos (t J) with h | h
            · rw [h, mul_zero] at htJ; omega
            · exact h)]
          linarith [mul_comm (V + 1) (t J)]
        omega
      simp only [hbΛ, GoldC.QuillonVaughan.upper_apply, if_pos hmV, Complex.ofReal_zero, zero_mul]
    have h1 : ∑ d ∈ Ioc 0 B, F d = ∑ d ∈ Ioc 0 (t J), F d := by
      have hm1 : ∑ d ∈ Ioc 0 (min B (t J)), F d = ∑ d ∈ Ioc 0 B, F d := by
        apply sum_subset (Ioc_subset_Ioc_right (min_le_left _ _))
        intro d hd hdn
        simp only [mem_Ioc, not_and, not_le] at hd hdn
        have hlt := hdn hd.1
        apply hFJ
        rcases le_total B (t J) with h | h
        · rw [min_eq_left h] at hlt; omega
        · rw [min_eq_right h] at hlt; exact hlt
      have hm2 : ∑ d ∈ Ioc 0 (min B (t J)), F d = ∑ d ∈ Ioc 0 (t J), F d := by
        apply sum_subset (Ioc_subset_Ioc_right (min_le_right _ _))
        intro d hd hdn
        simp only [mem_Ioc, not_and, not_le] at hd hdn
        have hlt := hdn hd.1
        apply hFB
        rcases le_total B (t J) with h | h
        · rw [min_eq_left h] at hlt; exact hlt
        · rw [min_eq_right h] at hlt; omega
      rw [← hm1, hm2]
    have h2 : ∑ d ∈ Ioc (t 0) (t J), F d = ∑ d ∈ Ioc 0 (t J), F d := by
      apply sum_subset (Ioc_subset_Ioc_left (Nat.zero_le _))
      intro d hd hdU
      simp only [mem_Ioc, not_and, not_lt] at hd hdU
      have : d ≤ U := by rw [← ht0]; by_contra h; exact absurd (hdU (lt_of_not_ge h)) (by omega)
      simp only [hF, ha, coefII_support U d this, Complex.ofReal_zero, zero_mul]
    rw [h1, h2]
  rw [hext]
  have ht1 : 1 ≤ t 0 := by rw [ht0]; exact hU
  refine (decouple (fun d => (a d : ℂ)) (fun d m => (bΛ m : ℂ) * kphase c (d * m)) A B hAB t J
    ht1 htm).trans (add_le_add ?_ ?_)
  · -- main terms via `parseval_block`
    refine sum_le_sum fun j _ => ?_
    have htj : 1 ≤ t j := ht1.trans (htm (Nat.zero_le j))
    have hsub : Ioc (t j) (t (j + 1)) ⊆ Icc 1 (t (j + 1)) := by
      intro d hd; simp only [mem_Ioc, mem_Icc] at hd ⊢; omega
    have hpb := parseval_block P hP hsP c (t (j + 1)) (Ioc (t j) (t (j + 1))) hsub (A / t j) (B / t j)
      (fun d => (a d : ℂ)) (fun m => (bΛ m : ℂ)) (Real.log B)
      (fun m hm => upperΛ_le V m B ((mem_Ioc.1 hm).2.trans (Nat.div_le_self _ _)))
    rw [← Real.sqrt_sq (norm_nonneg _)]
    apply Real.sqrt_le_sqrt
    refine (le_of_eq_of_le ?_ hpb).trans ?_
    · simp only [mul_sum]
    · have hsq : ∑ d ∈ Ioc (t j) (t (j + 1)), ‖((a d : ℝ) : ℂ)‖ ^ 2 ≤
          ∑ d ∈ Ioc (t j) (t (j + 1)), ((d.divisors.card : ℝ)) ^ 2 := by
        refine sum_le_sum fun d _ => ?_
        rw [Complex.norm_real, Real.norm_eq_abs]
        exact pow_le_pow_left₀ (abs_nonneg _) (coefII_bound U d) 2
      have h0 : (0 : ℝ) ≤ (((t (j + 1) : ℕ) : ℝ) / s + 1) * s := by positivity
      have h0' : (0 : ℝ) ≤ Real.log B ^ 2 * (((B / t j - A / t j : ℕ) : ℝ) *
          (((B / t j - A / t j : ℕ) : ℝ) /
            ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ) + 1)) := by
        positivity
      rw [mul_assoc _ _ (s : ℝ), mul_assoc _ _ (s : ℝ)]
      exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hsq h0) h0'
  · -- boundary terms
    refine sum_le_sum fun j _ => sum_le_sum fun d _ => ?_
    have htj : 1 ≤ t j := ht1.trans (htm (Nat.zero_le j))
    have hα : ‖((a d : ℝ) : ℂ)‖ ≤ (d.divisors.card : ℝ) := by
      rw [Complex.norm_real, Real.norm_eq_abs]; exact coefII_bound U d
    have hbd : ∀ x y : ℕ, y ≤ B → ∑ m ∈ Ioc x y, ‖(bΛ m : ℂ) * kphase c (d * m)‖ ≤
        Real.log B * ((y - x : ℕ) : ℝ) := by
      intro x y hy
      calc _ ≤ ∑ _m ∈ Ioc x y, Real.log B := by
            refine sum_le_sum fun m hm => ?_
            rw [norm_mul]
            calc _ ≤ Real.log B * 1 := mul_le_mul (upperΛ_le V m B ((mem_Ioc.1 hm).2.trans hy))
                  (norm_kphase_le c _) (norm_nonneg _) (Real.log_natCast_nonneg B)
              _ = _ := mul_one _
        _ = _ := by rw [sum_const, Nat.card_Ioc, nsmul_eq_mul, mul_comm]
    have hA' : A / t j ≤ B := (Nat.div_le_self _ _).trans hAB
    have hB' : B / t j ≤ B := Nat.div_le_self _ _
    refine mul_le_mul hα ?_ (by positivity) (by positivity)
    rw [mul_add]
    exact add_le_add (hbd _ _ hA') (hbd _ _ hB')

end typeII

end GoldC.QuillonTypeII

#print axioms GoldC.QuillonTypeII.class_count
#print axioms GoldC.QuillonTypeII.parseval_block
#print axioms GoldC.QuillonTypeII.decouple
#print axioms GoldC.QuillonTypeII.typeII_abstract
