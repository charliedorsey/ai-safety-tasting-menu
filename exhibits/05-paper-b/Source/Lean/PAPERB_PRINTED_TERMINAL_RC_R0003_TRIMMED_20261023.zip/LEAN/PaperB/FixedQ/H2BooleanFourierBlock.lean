import PaperB.FixedQ.H2BooleanFourierCRT
import PaperB.FixedQ.FixedConductorCompletion

open scoped BigOperators

namespace PaperB.FixedQ

lemma h2_primeSetProduct_union
    {S R : Finset ℕ} (hdisj : Disjoint S R) :
    primeSetProduct (S ∪ R) =
      primeSetProduct S * primeSetProduct R := by
  unfold primeSetProduct
  rw [Finset.prod_union hdisj]

lemma h2_primeSetProduct_coprime
    {S R : Finset ℕ}
    (hdisj : Disjoint S R)
    (hPrimeS : ∀ p ∈ S, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime) :
    (primeSetProduct S).Coprime (primeSetProduct R) := by
  unfold primeSetProduct
  apply Nat.Coprime.prod_left
  intro p hp
  apply Nat.Coprime.prod_right
  intro r hr
  exact (Nat.coprime_primes (hPrimeS p hp) (hPrimeR r hr)).2 (by
    intro h
    apply (Finset.disjoint_left.mp hdisj) hp
    simpa [h] using hr)

lemma h2BooleanPrimeBasis_cast_subset
    {S U : Finset ℕ} (hSU : S ⊆ U)
    (hPrimeU : ∀ p ∈ U, p.Prime)
    {p : ℕ} (hpS : p ∈ S) :
    ((h2BooleanPrimeBasis U p : ℕ) : ZMod (primeSetProduct S)) =
      (h2BooleanPrimeBasis S p : ZMod (primeSetProduct S)) := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos (fun q hq => hPrimeU q (hSU hq))).ne'⟩
  apply (ZMod.natCast_eq_natCast_iff
    (h2BooleanPrimeBasis U p) (h2BooleanPrimeBasis S p)
    (primeSetProduct S)).2
  apply h2_modEq_primeSetProduct_of_modEq_primes
    (fun q hq => hPrimeU q (hSU hq))
  intro q hqS
  apply (ZMod.natCast_eq_natCast_iff
    (h2BooleanPrimeBasis U p) (h2BooleanPrimeBasis S p) q).1
  unfold h2BooleanPrimeBasis
  rw [fixedProductCRTIdempotentNat_mod_prime_eq_bit
    Finset.sdiff_subset hPrimeU (hSU hqS)]
  rw [fixedProductCRTIdempotentNat_mod_prime_eq_bit
    Finset.sdiff_subset (fun x hx => hPrimeU x (hSU hx)) hqS]
  simp [hqS, hSU hqS]

lemma h2BooleanPrimeBasis_cast_disjoint_zero
    {S R : Finset ℕ} (hdisj : Disjoint S R)
    (hPrimeU : ∀ p ∈ S ∪ R, p.Prime)
    {p : ℕ} (hpS : p ∈ S) :
    ((h2BooleanPrimeBasis (S ∪ R) p : ℕ) :
      ZMod (primeSetProduct R)) = 0 := by
  letI : NeZero (primeSetProduct R) :=
    ⟨(primeSetProduct_pos
      (fun q hq => hPrimeU q (Finset.mem_union_right S hq))).ne'⟩
  have hmod :
      h2BooleanPrimeBasis (S ∪ R) p ≡ 0 [MOD primeSetProduct R] := by
    apply h2_modEq_primeSetProduct_of_modEq_primes
      (fun q hq => hPrimeU q (Finset.mem_union_right S hq))
    intro q hqR
    apply (ZMod.natCast_eq_natCast_iff
      (h2BooleanPrimeBasis (S ∪ R) p) 0 q).1
    unfold h2BooleanPrimeBasis
    rw [fixedProductCRTIdempotentNat_mod_prime_eq_bit
      Finset.sdiff_subset hPrimeU
      (Finset.mem_union_right S hqR)]
    have hqp : q ≠ p := by
      intro h
      subst q
      exact (Finset.disjoint_left.mp hdisj) hpS hqR
    simp [hpS, hqR, hqp]
  simpa using
    (ZMod.natCast_eq_natCast_iff
      (h2BooleanPrimeBasis (S ∪ R) p) 0
      (primeSetProduct R)).2 hmod

#print axioms h2BooleanPrimeBasis_cast_subset
#print axioms h2BooleanPrimeBasis_cast_disjoint_zero


noncomputable def h2BooleanBlockCRTEquiv
    (S R : Finset ℕ) (hdisj : Disjoint S R)
    (hPrimeS : ∀ p ∈ S, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime) :
    ZMod (primeSetProduct (S ∪ R)) ≃+*
      ZMod (primeSetProduct S) × ZMod (primeSetProduct R) := by
  have hprod := h2_primeSetProduct_union hdisj
  have hcop := h2_primeSetProduct_coprime hdisj hPrimeS hPrimeR
  exact (ZMod.ringEquivCongr hprod).trans (ZMod.chineseRemainder hcop)

lemma h2BooleanBlockCRTEquiv_apply_natCast
    (S R : Finset ℕ) (hdisj : Disjoint S R)
    (hPrimeS : ∀ p ∈ S, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (n : ℕ) :
    h2BooleanBlockCRTEquiv S R hdisj hPrimeS hPrimeR
      (n : ZMod (primeSetProduct (S ∪ R))) =
      ((n : ZMod (primeSetProduct S)),
        (n : ZMod (primeSetProduct R))) := by
  calc
    h2BooleanBlockCRTEquiv S R hdisj hPrimeS hPrimeR
        (n : ZMod (primeSetProduct (S ∪ R))) =
        (n : ZMod (primeSetProduct S) ×
          ZMod (primeSetProduct R)) :=
      map_natCast
        (h2BooleanBlockCRTEquiv S R hdisj hPrimeS hPrimeR) n
    _ = ((n : ZMod (primeSetProduct S)),
          (n : ZMod (primeSetProduct R))) := rfl

lemma h2BooleanBlockCRTEquiv_primeBasis_left
    (S R : Finset ℕ) (hdisj : Disjoint S R)
    (hPrimeS : ∀ p ∈ S, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    {p : ℕ} (hpS : p ∈ S) :
    h2BooleanBlockCRTEquiv S R hdisj hPrimeS hPrimeR
      (h2BooleanPrimeBasis (S ∪ R) p :
        ZMod (primeSetProduct (S ∪ R))) =
      ((h2BooleanPrimeBasis S p : ZMod (primeSetProduct S)), 0) := by
  rw [h2BooleanBlockCRTEquiv_apply_natCast]
  apply Prod.ext
  · exact h2BooleanPrimeBasis_cast_subset
      (Finset.subset_union_left) (by
        intro q hq
        rcases Finset.mem_union.mp hq with hqS | hqR
        · exact hPrimeS q hqS
        · exact hPrimeR q hqR) hpS
  · exact h2BooleanPrimeBasis_cast_disjoint_zero hdisj
      (by
        intro q hq
        rcases Finset.mem_union.mp hq with hqS | hqR
        · exact hPrimeS q hqS
        · exact hPrimeR q hqR) hpS

lemma h2BooleanBlockCRTEquiv_primeBasis_right
    (S R : Finset ℕ) (hdisj : Disjoint S R)
    (hPrimeS : ∀ p ∈ S, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    {p : ℕ} (hpR : p ∈ R) :
    h2BooleanBlockCRTEquiv S R hdisj hPrimeS hPrimeR
      (h2BooleanPrimeBasis (S ∪ R) p :
        ZMod (primeSetProduct (S ∪ R))) =
      (0, (h2BooleanPrimeBasis R p : ZMod (primeSetProduct R))) := by
  rw [h2BooleanBlockCRTEquiv_apply_natCast]
  apply Prod.ext
  · have hdisj' : Disjoint R S := hdisj.symm
    have hz := h2BooleanPrimeBasis_cast_disjoint_zero hdisj'
      (by
        intro q hq
        rcases Finset.mem_union.mp hq with hqR | hqS
        · exact hPrimeR q hqR
        · exact hPrimeS q hqS) hpR
    simpa [Finset.union_comm] using hz
  · exact h2BooleanPrimeBasis_cast_subset
      (Finset.subset_union_right) (by
        intro q hq
        rcases Finset.mem_union.mp hq with hqS | hqR
        · exact hPrimeS q hqS
        · exact hPrimeR q hqR) hpR

#print axioms h2BooleanBlockCRTEquiv_primeBasis_left
#print axioms h2BooleanBlockCRTEquiv_primeBasis_right


lemma h2_stdAddChar_ringEquivCongr
    {m n : ℕ} [NeZero m] [NeZero n]
    (h : m = n) (x : ZMod m) :
    ZMod.stdAddChar (ZMod.ringEquivCongr h x) =
      ZMod.stdAddChar x := by
  subst n
  have hx : ZMod.ringEquivCongr (Eq.refl m) x = x := by
    apply ZMod.val_injective
    simpa using ZMod.ringEquivCongr_val (Eq.refl m) x
  rw [hx]

#print axioms h2_stdAddChar_ringEquivCongr


lemma h2BooleanBlockCRTEquiv_apply
    (S R : Finset ℕ) (hdisj : Disjoint S R)
    (hPrimeS : ∀ p ∈ S, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (z : ZMod (primeSetProduct (S ∪ R))) :
    h2BooleanBlockCRTEquiv S R hdisj hPrimeS hPrimeR z =
      ZMod.chineseRemainder
        (h2_primeSetProduct_coprime hdisj hPrimeS hPrimeR)
        (ZMod.ringEquivCongr (h2_primeSetProduct_union hdisj) z) := by
  let hprod : primeSetProduct (S ∪ R) =
      primeSetProduct S * primeSetProduct R :=
    h2_primeSetProduct_union hdisj
  let hcop : (primeSetProduct S).Coprime (primeSetProduct R) :=
    h2_primeSetProduct_coprime hdisj hPrimeS hPrimeR
  change
    ((ZMod.ringEquivCongr hprod).trans
      (ZMod.chineseRemainder hcop)) z =
      ZMod.chineseRemainder hcop (ZMod.ringEquivCongr hprod z)
  rfl

lemma h2_stdAddChar_eq_block_mul
    (S R : Finset ℕ) (hdisj : Disjoint S R)
    (hPrimeS : ∀ p ∈ S, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    [NeZero (primeSetProduct S)]
    [NeZero (primeSetProduct R)]
    [NeZero (primeSetProduct (S ∪ R))]
    (z : ZMod (primeSetProduct (S ∪ R))) :
    ZMod.stdAddChar z =
      ZMod.stdAddChar
        (((crtLeftCoeff (primeSetProduct S) (primeSetProduct R) : ℤ) :
            ZMod (primeSetProduct S)) *
          (h2BooleanBlockCRTEquiv S R hdisj hPrimeS hPrimeR z).1) *
      ZMod.stdAddChar
        (((crtRightCoeff (primeSetProduct S) (primeSetProduct R) : ℤ) :
            ZMod (primeSetProduct R)) *
          (h2BooleanBlockCRTEquiv S R hdisj hPrimeS hPrimeR z).2) := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrimeS).ne'⟩
  letI : NeZero (primeSetProduct R) :=
    ⟨(primeSetProduct_pos hPrimeR).ne'⟩
  letI : NeZero (primeSetProduct S * primeSetProduct R) :=
    ⟨mul_ne_zero (NeZero.ne _) (NeZero.ne _)⟩
  letI : NeZero (primeSetProduct (S ∪ R)) :=
    ⟨(primeSetProduct_pos (by
      intro p hp
      rcases Finset.mem_union.mp hp with hpS | hpR
      · exact hPrimeS p hpS
      · exact hPrimeR p hpR)).ne'⟩
  have hprod := h2_primeSetProduct_union hdisj
  have hcop := h2_primeSetProduct_coprime hdisj hPrimeS hPrimeR
  have hcrt := stdAddChar_mul_eq_crt_zmod hcop
    (ZMod.ringEquivCongr hprod z)
  have hcongr := h2_stdAddChar_ringEquivCongr hprod z
  rw [h2BooleanBlockCRTEquiv_apply] 
  calc
    ZMod.stdAddChar z =
        ZMod.stdAddChar (ZMod.ringEquivCongr hprod z) := hcongr.symm
    _ = _ := hcrt.symm

#print axioms h2BooleanBlockCRTEquiv_apply
#print axioms h2_stdAddChar_eq_block_mul


noncomputable def h2BooleanBlockLeftFrequency
    (S R : Finset ℕ) (hdisj : Disjoint S R)
    (hPrimeS : ∀ p ∈ S, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (z : ZMod (primeSetProduct (S ∪ R))) :
    ZMod (primeSetProduct S) :=
  ((crtLeftCoeff (primeSetProduct S) (primeSetProduct R) : ℤ) :
      ZMod (primeSetProduct S)) *
    (h2BooleanBlockCRTEquiv S R hdisj hPrimeS hPrimeR z).1

noncomputable def h2BooleanBlockRightFrequency
    (S R : Finset ℕ) (hdisj : Disjoint S R)
    (hPrimeS : ∀ p ∈ S, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (z : ZMod (primeSetProduct (S ∪ R))) :
    ZMod (primeSetProduct R) :=
  ((crtRightCoeff (primeSetProduct S) (primeSetProduct R) : ℤ) :
      ZMod (primeSetProduct R)) *
    (h2BooleanBlockCRTEquiv S R hdisj hPrimeS hPrimeR z).2

lemma h2BooleanLocalFourierFactor_block_left
    (S R : Finset ℕ) (hdisj : Disjoint S R)
    (hPrimeS : ∀ p ∈ S, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (z : ZMod (primeSetProduct (S ∪ R)))
    {p : ℕ} (hpS : p ∈ S) :
    h2BooleanLocalFourierFactor (S ∪ R)
      (fun q hq => by
        rcases Finset.mem_union.mp hq with hqS | hqR
        · exact hPrimeS q hqS
        · exact hPrimeR q hqR)
      z p =
    h2BooleanLocalFourierFactor S hPrimeS
      (h2BooleanBlockLeftFrequency S R hdisj hPrimeS hPrimeR z) p := by
  let hPrimeU : ∀ q ∈ S ∪ R, q.Prime := by
    intro q hq
    rcases Finset.mem_union.mp hq with hqS | hqR
    · exact hPrimeS q hqS
    · exact hPrimeR q hqR
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrimeS).ne'⟩
  letI : NeZero (primeSetProduct R) :=
    ⟨(primeSetProduct_pos hPrimeR).ne'⟩
  letI : NeZero (primeSetProduct (S ∪ R)) :=
    ⟨(primeSetProduct_pos hPrimeU).ne'⟩
  unfold h2BooleanLocalFourierFactor
  unfold h2BooleanBlockLeftFrequency
  congr 2
  have hchar := h2_stdAddChar_eq_block_mul
    S R hdisj hPrimeS hPrimeR
    (z * (h2BooleanPrimeBasis (S ∪ R) p :
      ZMod (primeSetProduct (S ∪ R))))
  have hbasis := h2BooleanBlockCRTEquiv_primeBasis_left
    S R hdisj hPrimeS hPrimeR hpS
  have hmap :
      h2BooleanBlockCRTEquiv S R hdisj hPrimeS hPrimeR
        (z * (h2BooleanPrimeBasis (S ∪ R) p :
          ZMod (primeSetProduct (S ∪ R)))) =
      ((h2BooleanBlockCRTEquiv S R hdisj hPrimeS hPrimeR z).1 *
          (h2BooleanPrimeBasis S p : ZMod (primeSetProduct S)),
        0) := by
    rw [map_mul, hbasis]
    apply Prod.ext <;> simp
  rw [hmap] at hchar
  simp only [Prod.fst, Prod.snd, mul_zero] at hchar
  have hzeroR :
      ZMod.stdAddChar (0 : ZMod (primeSetProduct R)) = 1 :=
    (ZMod.stdAddChar (N := primeSetProduct R)).map_zero_eq_one
  rw [hzeroR, mul_one] at hchar
  rw [hchar]
  congr 1
  ring

lemma h2BooleanLocalFourierFactor_block_right
    (S R : Finset ℕ) (hdisj : Disjoint S R)
    (hPrimeS : ∀ p ∈ S, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (z : ZMod (primeSetProduct (S ∪ R)))
    {p : ℕ} (hpR : p ∈ R) :
    h2BooleanLocalFourierFactor (S ∪ R)
      (fun q hq => by
        rcases Finset.mem_union.mp hq with hqS | hqR
        · exact hPrimeS q hqS
        · exact hPrimeR q hqR)
      z p =
    h2BooleanLocalFourierFactor R hPrimeR
      (h2BooleanBlockRightFrequency S R hdisj hPrimeS hPrimeR z) p := by
  let hPrimeU : ∀ q ∈ S ∪ R, q.Prime := by
    intro q hq
    rcases Finset.mem_union.mp hq with hqS | hqR
    · exact hPrimeS q hqS
    · exact hPrimeR q hqR
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrimeS).ne'⟩
  letI : NeZero (primeSetProduct R) :=
    ⟨(primeSetProduct_pos hPrimeR).ne'⟩
  letI : NeZero (primeSetProduct (S ∪ R)) :=
    ⟨(primeSetProduct_pos hPrimeU).ne'⟩
  unfold h2BooleanLocalFourierFactor
  unfold h2BooleanBlockRightFrequency
  congr 2
  have hchar := h2_stdAddChar_eq_block_mul
    S R hdisj hPrimeS hPrimeR
    (z * (h2BooleanPrimeBasis (S ∪ R) p :
      ZMod (primeSetProduct (S ∪ R))))
  have hbasis := h2BooleanBlockCRTEquiv_primeBasis_right
    S R hdisj hPrimeS hPrimeR hpR
  have hmap :
      h2BooleanBlockCRTEquiv S R hdisj hPrimeS hPrimeR
        (z * (h2BooleanPrimeBasis (S ∪ R) p :
          ZMod (primeSetProduct (S ∪ R)))) =
      (0,
        (h2BooleanBlockCRTEquiv S R hdisj hPrimeS hPrimeR z).2 *
          (h2BooleanPrimeBasis R p : ZMod (primeSetProduct R))) := by
    rw [map_mul, hbasis]
    apply Prod.ext <;> simp
  rw [hmap] at hchar
  simp only [Prod.fst, Prod.snd, mul_zero] at hchar
  have hzeroS :
      ZMod.stdAddChar (0 : ZMod (primeSetProduct S)) = 1 :=
    (ZMod.stdAddChar (N := primeSetProduct S)).map_zero_eq_one
  rw [hzeroS, one_mul] at hchar
  rw [hchar]
  congr 1
  ring

#print axioms h2BooleanLocalFourierFactor_block_left
#print axioms h2BooleanLocalFourierFactor_block_right


theorem fixedProductBooleanFourierCoeff_block_factor
    (S R : Finset ℕ) (hdisj : Disjoint S R)
    (hPrimeS : ∀ p ∈ S, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (z : ZMod (primeSetProduct (S ∪ R))) :
    fixedProductBooleanFourierCoeff (S ∪ R)
      (fun q hq => by
        rcases Finset.mem_union.mp hq with hqS | hqR
        · exact hPrimeS q hqS
        · exact hPrimeR q hqR)
      z =
      fixedProductBooleanFourierCoeff S hPrimeS
        (h2BooleanBlockLeftFrequency S R hdisj hPrimeS hPrimeR z) *
      fixedProductBooleanFourierCoeff R hPrimeR
        (h2BooleanBlockRightFrequency S R hdisj hPrimeS hPrimeR z) := by
  let hPrimeU : ∀ q ∈ S ∪ R, q.Prime := by
    intro q hq
    rcases Finset.mem_union.mp hq with hqS | hqR
    · exact hPrimeS q hqS
    · exact hPrimeR q hqR
  rw [fixedProductBooleanFourierCoeff_eq_prod_local]
  rw [Finset.prod_union hdisj]
  rw [fixedProductBooleanFourierCoeff_eq_prod_local]
  rw [fixedProductBooleanFourierCoeff_eq_prod_local]
  congr 1
  · apply Finset.prod_congr rfl
    intro p hp
    exact h2BooleanLocalFourierFactor_block_left
      S R hdisj hPrimeS hPrimeR z hp
  · apply Finset.prod_congr rfl
    intro p hp
    exact h2BooleanLocalFourierFactor_block_right
      S R hdisj hPrimeS hPrimeR z hp

lemma norm_h2BooleanLocalFourierFactor_le_one
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (t : ZMod (primeSetProduct S)) (p : ℕ) :
    ‖h2BooleanLocalFourierFactor S hPrime t p‖ ≤ 1 := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrime).ne'⟩
  unfold h2BooleanLocalFourierFactor
  rw [norm_mul]
  have htwo : ‖((2 : ℂ)⁻¹)‖ = (1 / 2 : ℝ) := by norm_num
  rw [htwo]
  calc
    (1 / 2 : ℝ) *
        ‖1 + ZMod.stdAddChar
          (t * (h2BooleanPrimeBasis S p :
            ZMod (primeSetProduct S)))‖
        ≤ (1 / 2 : ℝ) *
            (‖(1 : ℂ)‖ +
              ‖ZMod.stdAddChar
                (t * (h2BooleanPrimeBasis S p :
                  ZMod (primeSetProduct S)))‖) := by
          gcongr
          exact norm_add_le _ _
    _ = 1 := by
      rw [norm_one, norm_stdAddChar_eq_one]
      norm_num

theorem norm_fixedProductBooleanFourierCoeff_le_one
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (t : ZMod (primeSetProduct S)) :
    ‖fixedProductBooleanFourierCoeff S hPrime t‖ ≤ 1 := by
  rw [fixedProductBooleanFourierCoeff_eq_prod_local]
  rw [norm_prod]
  calc
    (∏ p ∈ S, ‖h2BooleanLocalFourierFactor S hPrime t p‖)
        ≤ ∏ _p ∈ S, (1 : ℝ) := by
          apply Finset.prod_le_prod₀
          · intro p hp
            positivity
          · intro p hp
            exact norm_h2BooleanLocalFourierFactor_le_one S hPrime t p
    _ = 1 := by simp

theorem norm_sq_fixedProductBooleanFourierCoeff_block_le_left
    (S R : Finset ℕ) (hdisj : Disjoint S R)
    (hPrimeS : ∀ p ∈ S, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (z : ZMod (primeSetProduct (S ∪ R))) :
    ‖fixedProductBooleanFourierCoeff (S ∪ R)
      (fun q hq => by
        rcases Finset.mem_union.mp hq with hqS | hqR
        · exact hPrimeS q hqS
        · exact hPrimeR q hqR)
      z‖ ^ 2 ≤
      ‖fixedProductBooleanFourierCoeff S hPrimeS
        (h2BooleanBlockLeftFrequency S R hdisj hPrimeS hPrimeR z)‖ ^ 2 := by
  rw [fixedProductBooleanFourierCoeff_block_factor
    S R hdisj hPrimeS hPrimeR z]
  rw [norm_mul, mul_pow]
  have hr := norm_fixedProductBooleanFourierCoeff_le_one R hPrimeR
    (h2BooleanBlockRightFrequency S R hdisj hPrimeS hPrimeR z)
  have hr0 :
      0 ≤ ‖fixedProductBooleanFourierCoeff R hPrimeR
        (h2BooleanBlockRightFrequency S R hdisj hPrimeS hPrimeR z)‖ ^ 2 := by
    positivity
  have hr2 :
      ‖fixedProductBooleanFourierCoeff R hPrimeR
        (h2BooleanBlockRightFrequency S R hdisj hPrimeS hPrimeR z)‖ ^ 2 ≤ 1 := by
    have hnorm0 :
        0 ≤ ‖fixedProductBooleanFourierCoeff R hPrimeR
          (h2BooleanBlockRightFrequency S R hdisj hPrimeS hPrimeR z)‖ :=
      norm_nonneg _
    nlinarith
  exact mul_le_of_le_one_right (sq_nonneg _) hr2

#print axioms fixedProductBooleanFourierCoeff_block_factor
#print axioms norm_fixedProductBooleanFourierCoeff_le_one
#print axioms norm_sq_fixedProductBooleanFourierCoeff_block_le_left

end PaperB.FixedQ
