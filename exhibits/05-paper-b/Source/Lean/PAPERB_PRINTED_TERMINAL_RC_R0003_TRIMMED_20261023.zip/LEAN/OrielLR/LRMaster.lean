import OrielLR.SliceLR

/-!
# Oriel L/R — the master per-height bound for Left and Right
-/

open Finset
open OrielUpper.Mirror

namespace OrielUpper

section
open scoped Classical

theorem quarter_eq_region (Z : ℕ → ℕ) (R : ℕ → ℕ → ℕ → ℕ → Prop) {q a h : ℕ} (hq : 0 < q)
    (hh : 0 < h) :
    auvrenR0056CompleteQuarter Z q a h R =
      ∑ d ∈ (decoratedHeightPrimeSet q h).powerset, finiteVWeightReal h d *
        regWin (q * (h / primeSetProduct d) * primeSetProduct d) (h / primeSetProduct d)
          (fixedQLowWeight q (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d)) Z R h ((h / primeSetProduct d) ^ 2 / 4) := by
  unfold auvrenR0056CompleteQuarter
  apply sum_congr rfl
  intro d hd
  congr 1
  exact slice_eq_region Z R hq hh (mem_powerset.mp hd)

end

/-- Slice hypotheses hold for every decoration of the actual source. -/
theorem sliceHyp_source {Z : ℕ → ℕ} {q a h : ℕ} (hq : 0 < q) (hh : 1 ≤ h) {d : Finset ℕ}
    (hd : d ⊆ decoratedHeightPrimeSet q h) {Y D N0 Lb : ℕ} (hY : Y ^ 3 ≤ Z h)
    (hYN : (N0 + 1) * (6 * q) * D ≤ Y) (hYD : 2 * D * (6 * q) ^ 2 + 1 ≤ Y) (hD : 1 ≤ D)
    (hN0 : 1 ≤ N0) (hLb : h ≤ 2 ^ Lb) :
    haveI : NeZero (6 * q) := ⟨by omega⟩
    SliceHyp (6 * q) (q * (h / primeSetProduct d) * primeSetProduct d) (h / primeSetProduct d)
      (fixedQLowWeight q (decoratedReducedAnchor q a (primeSetProduct d)) (h / primeSetProduct d))
      (lamZ q (decoratedReducedAnchor q a (primeSetProduct d)) (h / primeSetProduct d)) 3
      Z h Y D N0 Lb (envA1 (q * h ^ 3)) (envA34 (q * h ^ 3)) (Real.exp (10 * Z32)) := by
  haveI : NeZero (6 * q) := ⟨by omega⟩
  set H := h / primeSetProduct d with hHdef
  set A := decoratedReducedAnchor q a (primeSetProduct d)
  set F := q * H * primeSetProduct d with hFdef
  have hdP : ∀ p ∈ d, p.Prime := fun p hp => (mem_decorated (hd hp)).1
  have hdpos : 0 < primeSetProduct d := primeSetProduct_pos' hdP
  have hHh : H ≤ h := Nat.div_le_self _ _
  have hHd : H * primeSetProduct d ≤ h := Nat.div_mul_le_self _ _
  have hd_dvd : primeSetProduct d ∣ h := by
    unfold primeSetProduct
    apply Finset.prod_primes_dvd
    · intro p hp; exact (hdP p hp).prime
    · intro p hp; exact (mem_decorated (hd hp)).2.1
  have hH : 0 < H := Nat.div_pos (Nat.le_of_dvd (by omega) hd_dvd) hdpos
  have hF0 : F ≠ 0 := by positivity
  have hFm : ∀ m, m ≤ h ^ 2 → F * m ≤ q * h ^ 3 := by
    intro m hm
    have h2 : F ≤ q * h := by rw [hFdef, mul_assoc]; exact Nat.mul_le_mul_left q hHd
    calc F * m ≤ (q * h) * h ^ 2 := Nat.mul_le_mul h2 hm
      _ = q * h ^ 3 := by ring
  refine ⟨rowHyp_source hq (show q ∣ F from ⟨H * primeSetProduct d, by rw [hFdef]; ring⟩)
      (show H ∣ F from ⟨q * primeSetProduct d, by rw [hFdef]; ring⟩), hHh, hh, hY, ?_, ?_, hD, hN0,
      hLb, ?_, ?_, tau_sum_le F⟩
  · simpa [mul_assoc] using hYN
  · simpa using hYD
  · intro m N hm1 hm2
    exact Asig_one_env (mul_ne_zero hF0 (by omega)) (hFm m hm2) N
  · intro m N hm1 hm2
    exact Asig_34_env (mul_ne_zero hF0 (by omega)) (hFm m hm2) N

/-- Generic assembly over decorations. -/
theorem quarter_le_slice (Z : ℕ → ℕ) (R : ℕ → ℕ → ℕ → ℕ → Prop) {q a h : ℕ} (hq : 0 < q)
    (hh : 1 ≤ h) {S : ℝ} (hS0 : 0 ≤ S)
    (hslice : ∀ d, d ⊆ decoratedHeightPrimeSet q h →
      |regWin (q * (h / primeSetProduct d) * primeSetProduct d) (h / primeSetProduct d)
          (fixedQLowWeight q (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d)) Z R h ((h / primeSetProduct d) ^ 2 / 4)| ≤ S) :
    |auvrenR0056CompleteQuarter Z q a h R| ≤ Vb h * S := by
  rw [quarter_eq_region Z R hq (by omega)]
  refine (abs_sum_le_sum_abs _ _).trans ?_
  calc _ ≤ ∑ d ∈ (decoratedHeightPrimeSet q h).powerset, finiteVWeightReal h d * S := by
        apply sum_le_sum
        intro d hd
        rw [abs_mul, abs_of_nonneg (finiteVWeightReal_nonneg hd)]
        exact mul_le_mul_of_nonneg_left (hslice d (mem_powerset.mp hd))
          (finiteVWeightReal_nonneg hd)
    _ = (∑ d ∈ (decoratedHeightPrimeSet q h).powerset, finiteVWeightReal h d) * S := by
        rw [sum_mul]
    _ ≤ Vb h * S := mul_le_mul_of_nonneg_right (decor_sum_le q h) hS0

theorem left_master {cK Ck : ℝ} (hcK : 0 < cK) (hCk : 0 ≤ Ck) (hK : KarBound cK Ck)
    (Z : ℕ → ℕ) {q a h : ℕ} (hq : 0 < q) (hh : 1 ≤ h) {Y D N0 Lb : ℕ} (hY : Y ^ 3 ≤ Z h)
    (hYN : (N0 + 1) * (6 * q) * D ≤ Y) (hYD : 2 * D * (6 * q) ^ 2 + 1 ≤ Y) (hD : 1 ≤ D)
    (hN0 : 1 ≤ N0) (hLb : h ≤ 2 ^ Lb) :
    |auvrenR0056CompleteQuarter Z q a h virelleR0037Left| ≤
      Vb h * sliceLR (6 * q) 3 (envA1 (q * h ^ 3)) (envA34 (q * h ^ 3)) Ck cK
        (Real.exp (10 * Z32)) D N0 Lb h := by
  haveI : NeZero (6 * q) := ⟨by omega⟩
  have hS0 := sliceLR_nonneg (sliceHyp_source (Z := Z) (a := a) hq hh (empty_subset _) hY hYN hYD
    hD hN0 hLb) hCk (cK := cK)
  exact quarter_le_slice Z _ hq hh hS0 (fun d hd =>
    left_slice (sliceHyp_source hq hh hd hY hYN hYD hD hN0 hLb) hcK hCk hK)

theorem right_master {cK Ck : ℝ} (hcK : 0 < cK) (hCk : 0 ≤ Ck) (hK : KarBound cK Ck)
    (Z : ℕ → ℕ) {q a h : ℕ} (hq : 0 < q) (hh : 1 ≤ h) {Y D N0 Lb : ℕ} (hY : Y ^ 3 ≤ Z h)
    (hYN : (N0 + 1) * (6 * q) * D ≤ Y) (hYD : 2 * D * (6 * q) ^ 2 + 1 ≤ Y) (hD : 1 ≤ D)
    (hN0 : 1 ≤ N0) (hLb : h ≤ 2 ^ Lb) :
    |auvrenR0056CompleteQuarter Z q a h virelleR0037Right| ≤
      Vb h * sliceLR (6 * q) 3 (envA1 (q * h ^ 3)) (envA34 (q * h ^ 3)) Ck cK
        (Real.exp (10 * Z32)) D N0 Lb h := by
  haveI : NeZero (6 * q) := ⟨by omega⟩
  have hS0 := sliceLR_nonneg (sliceHyp_source (Z := Z) (a := a) hq hh (empty_subset _) hY hYN hYD
    hD hN0 hLb) hCk (cK := cK)
  exact quarter_le_slice Z _ hq hh hS0 (fun d hd =>
    right_slice (sliceHyp_source hq hh hd hY hYN hYD hD hN0 hLb) hcK hCk hK)

end OrielUpper
