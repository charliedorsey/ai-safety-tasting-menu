import PaperB.FixedQ.PetermannInterface

namespace PaperB.FixedQ

noncomputable def petermannA (p : ℕ) : ℝ :=
  1 / ((p : ℝ) - 3)

noncomputable def petermannB (p : ℕ) : ℝ :=
  1 / ((p : ℝ) - 2)

noncomputable def petermannCorrectionPrimePower
    (p nu : ℕ) : ℝ :=
  if nu = 0 then 1
  else (petermannB p - petermannA p) *
    (- petermannA p) ^ (nu - 1)

theorem petermannCorrectionPrimePower_zero
    (p : ℕ) :
    petermannCorrectionPrimePower p 0 = 1 := by
  simp [petermannCorrectionPrimePower]

theorem petermannCorrectionPrimePower_one
    (p : ℕ) :
    petermannCorrectionPrimePower p 1 =
      petermannB p - petermannA p := by
  simp [petermannCorrectionPrimePower]

theorem petermannCorrectionPrimePower_succ
    (p nu : ℕ) :
    petermannCorrectionPrimePower p (nu + 1) =
      (petermannB p - petermannA p) *
        (- petermannA p) ^ nu := by
  simp [petermannCorrectionPrimePower, Nat.add_eq_zero_iff]

/-- Coefficient identity at degree one in
    (1 + a z) * (1 + sum c_n z^n) = 1 + b z. -/
theorem petermannLocalConvolution_degree_one
    (p : ℕ) :
    petermannCorrectionPrimePower p 1 + petermannA p =
      petermannB p := by
  rw [petermannCorrectionPrimePower_one]
  ring

/-- All higher coefficients vanish in the same local generating identity. -/
theorem petermannLocalConvolution_higher
    (p nu : ℕ) (hnu : 1 ≤ nu) :
    petermannCorrectionPrimePower p (nu + 1) +
      petermannA p * petermannCorrectionPrimePower p nu = 0 := by
  rw [petermannCorrectionPrimePower_succ]
  have hnu0 : nu ≠ 0 := by omega
  rw [petermannCorrectionPrimePower]
  rw [if_neg hnu0]
  have hpow :
      (-petermannA p) ^ nu =
        (-petermannA p) ^ (nu - 1) * (-petermannA p) := by
    conv_lhs =>
      rw [show nu = (nu - 1) + 1 by omega]
    rw [pow_succ]
  calc
    (petermannB p - petermannA p) * (-petermannA p) ^ nu +
        petermannA p *
          ((petermannB p - petermannA p) *
            (-petermannA p) ^ (nu - 1))
      =
        (petermannB p - petermannA p) *
          ((-petermannA p) ^ nu +
            petermannA p * (-petermannA p) ^ (nu - 1)) := by
              ring
    _ = 0 := by
      rw [hpow]
      ring

/-- Source local identity at a height prime: the moving local factor
    1 + b z is exactly the squarefree omega factor 1 + a z convolved
    with the correction Euler series. -/
theorem petermannLocalConvolution_coeff
    (p nu : ℕ) :
    (if nu = 0 then
        petermannCorrectionPrimePower p 0
      else if nu = 1 then
        petermannCorrectionPrimePower p 1 + petermannA p
      else
        petermannCorrectionPrimePower p nu +
          petermannA p * petermannCorrectionPrimePower p (nu - 1))
      =
      if nu = 0 then 1 else if nu = 1 then petermannB p else 0 := by
  by_cases h0 : nu = 0
  · subst nu
    simp [petermannCorrectionPrimePower_zero]
  · by_cases h1 : nu = 1
    · subst nu
      simp [petermannLocalConvolution_degree_one]
    · have hnu : 2 ≤ nu := by omega
      have hnupred : 1 ≤ nu - 1 := by omega
      have hrewrite : (nu - 1) + 1 = nu := by omega
      simp only [h0, h1, if_false]
      have hh := petermannLocalConvolution_higher p (nu - 1) hnupred
      simpa [hrewrite] using hh

#print axioms petermannLocalConvolution_degree_one
#print axioms petermannLocalConvolution_higher
#print axioms petermannLocalConvolution_coeff

end PaperB.FixedQ
