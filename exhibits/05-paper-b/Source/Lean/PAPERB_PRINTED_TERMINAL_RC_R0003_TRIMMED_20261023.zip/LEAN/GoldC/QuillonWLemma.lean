import GoldC.QuillonCompletion

/-!
# Quillon CSC3 F5b: the W′ Cauchy lemma (fixed modulus `s`, bilinear `r = y·n`)

For `s ≥ 2`, frequency `c₀ : ZMod s`, a finite set `𝒴` and `𝒩 ⊆ (N, M]`, coefficients `α, β`, and any
`KB` with `‖K_s(b, c)‖ ≤ KB c` for all `b, c`:

    ‖Σ_{n∈𝒩} β_n Σ_{y∈𝒴} α_y · 1_{unit}(yn) · e(c₀ (yn)⁻¹/s)‖²
      ≤ (Σ‖β‖²) · Σ_{y,y'} ‖α_y‖‖α_y'‖ · W(y,y'),

where `W(y,y') = (M−N)` if `y ≡ y' (mod s)` (the diagonal, including congruent pairs), and
`KB(c₀(ȳ − ȳ'))·((M−N)/s + 1 + log s)` otherwise.

Then `K_squarefree_bound` supplies `KB(c) = (∏_{p|s} 3p³·(p if p|c else 1))^{1/4}`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonW

open GoldC.QuillonKl GoldC.QuillonCompletion

variable {s : ℕ} [NeZero s]

local notation "ψ" => (ZMod.stdAddChar : AddChar (ZMod s) ℂ)

/-- The W′ summand. -/
noncomputable def g (c₀ : ZMod s) (y n : ℕ) : ℂ :=
  if IsUnit ((y : ZMod s) * n) then ψ (c₀ * ((y : ZMod s) * n)⁻¹) else 0

lemma conj_psi (t : ZMod s) : (starRingEnd ℂ) (ψ t) = ψ (-t) := by
  have hR : 0 < ringChar (ZMod s) := by
    rw [ZMod.ringChar_zmod_n]; exact Nat.pos_of_ne_zero (NeZero.ne s)
  rw [AddChar.starComp_apply hR, AddChar.map_neg_eq_inv, AddChar.inv_apply']

omit [NeZero s] in
lemma unit_mul_inv {a b : ZMod s} (ha : IsUnit a) (hb : IsUnit b) : (a * b)⁻¹ = a⁻¹ * b⁻¹ := by
  rw [← ha.unit_spec, ← hb.unit_spec, ← Units.val_mul, ZMod.inv_coe_unit, ZMod.inv_coe_unit,
    ZMod.inv_coe_unit, mul_inv, Units.val_mul, mul_comm]

/-- Pair product `g(y,n)·conj g(y',n)` is the incomplete-sum summand at `c = c₀(ȳ − ȳ')`. -/
lemma pair_term (c₀ : ZMod s) (y y' n : ℕ) (hy : IsUnit (y : ZMod s)) (hy' : IsUnit (y' : ZMod s)) :
    g c₀ y n * (starRingEnd ℂ) (g c₀ y' n) =
      if IsUnit (n : ZMod s) then ψ ((c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹)) * (n : ZMod s)⁻¹)
      else 0 := by
  unfold g
  by_cases hn : IsUnit (n : ZMod s)
  · have h1 : IsUnit ((y : ZMod s) * n) := hy.mul hn
    have h2 : IsUnit ((y' : ZMod s) * n) := hy'.mul hn
    rw [if_pos h1, if_pos h2, if_pos hn, conj_psi, ← AddChar.map_add_eq_mul,
      unit_mul_inv hy hn, unit_mul_inv hy' hn]
    congr 1; ring
  · have h1 : ¬ IsUnit ((y : ZMod s) * n) := fun h => hn (isUnit_of_mul_isUnit_right h)
    rw [if_neg h1, if_neg hn, zero_mul]

theorem W_cauchy (hs : 2 ≤ s) (c₀ : ZMod s) (𝒴 𝒩 : Finset ℕ) {N M : ℕ} (hNM : N ≤ M)
    (h𝒩 : 𝒩 ⊆ Ioc N M) (hunit : ∀ y ∈ 𝒴, IsUnit (y : ZMod s)) (α β : ℕ → ℂ)
    (KB : ZMod s → ℝ) (hKB : ∀ c b : ZMod s, ‖K s b c‖ ≤ KB c) :
    ‖∑ n ∈ 𝒩, β n * ∑ y ∈ 𝒴, α y * g c₀ y n‖ ^ 2 ≤
      (∑ n ∈ 𝒩, ‖β n‖ ^ 2) * ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴, ‖α y‖ * ‖α y'‖ *
        (if (y : ZMod s) = y' then ((M - N : ℕ) : ℝ) else
          KB (c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹)) *
            (((M - N : ℕ) : ℝ) / s + 1 + Real.log s)) := by
  set F : ℕ → ℂ := fun n => ∑ y ∈ 𝒴, α y * g c₀ y n with hF
  -- Cauchy–Schwarz in n, then extend to (N, M]
  have hCS : ‖∑ n ∈ 𝒩, β n * F n‖ ^ 2 ≤ (∑ n ∈ 𝒩, ‖β n‖ ^ 2) * ∑ n ∈ Ioc N M, ‖F n‖ ^ 2 := by
    calc ‖∑ n ∈ 𝒩, β n * F n‖ ^ 2 ≤ (∑ n ∈ 𝒩, ‖β n‖ * ‖F n‖) ^ 2 := by
          refine pow_le_pow_left₀ (norm_nonneg _) ?_ 2
          exact (norm_sum_le _ _).trans (le_of_eq (Finset.sum_congr rfl fun n _ => norm_mul _ _))
      _ ≤ (∑ n ∈ 𝒩, ‖β n‖ ^ 2) * ∑ n ∈ 𝒩, ‖F n‖ ^ 2 := Finset.sum_mul_sq_le_sq_mul_sq _ _ _
      _ ≤ _ := mul_le_mul_of_nonneg_left
          (Finset.sum_le_sum_of_subset_of_nonneg h𝒩 fun n _ _ => by positivity)
          (Finset.sum_nonneg fun n _ => by positivity)
  refine hCS.trans (mul_le_mul_of_nonneg_left ?_ (Finset.sum_nonneg fun n _ => by positivity))
  -- expand Σ_n ‖F n‖²
  have hexp : ((∑ n ∈ Ioc N M, ‖F n‖ ^ 2 : ℝ) : ℂ) = ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴,
      α y * (starRingEnd ℂ) (α y') * ∑ n ∈ Ioc N M, g c₀ y n * (starRingEnd ℂ) (g c₀ y' n) := by
    rw [Complex.ofReal_sum]
    have : ∀ n, ((‖F n‖ ^ 2 : ℝ) : ℂ) = ∑ y ∈ 𝒴, ∑ y' ∈ 𝒴,
        α y * (starRingEnd ℂ) (α y') * (g c₀ y n * (starRingEnd ℂ) (g c₀ y' n)) := by
      intro n
      rw [Complex.ofReal_pow, ← Complex.mul_conj']
      simp only [hF, map_sum, map_mul]
      rw [Finset.sum_mul_sum]
      refine Finset.sum_congr rfl fun y _ => Finset.sum_congr rfl fun y' _ => by ring
    simp_rw [this]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun y _ => ?_
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun y' _ => ?_
    rw [Finset.mul_sum]
  have hreal : ∑ n ∈ Ioc N M, ‖F n‖ ^ 2 = ‖((∑ n ∈ Ioc N M, ‖F n‖ ^ 2 : ℝ) : ℂ)‖ := by
    rw [Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (Finset.sum_nonneg fun n _ => by positivity)]
  rw [hreal, hexp]
  refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun y hy => ?_)
  refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun y' hy' => ?_)
  rw [norm_mul, norm_mul, Complex.norm_conj]
  refine mul_le_mul_of_nonneg_left ?_ (by positivity)
  simp_rw [pair_term c₀ y y' _ (hunit y hy) (hunit y' hy')]
  split_ifs with hyy
  · -- diagonal: phase 0, count ≤ M − N
    have hc : c₀ * ((y : ZMod s)⁻¹ - (y' : ZMod s)⁻¹) = 0 := by rw [hyy, sub_self, mul_zero]
    simp_rw [hc, zero_mul, AddChar.map_zero_eq_one]
    refine (norm_sum_le _ _).trans ?_
    calc ∑ n ∈ Ioc N M, ‖(if IsUnit (n : ZMod s) then (1 : ℂ) else 0)‖
        ≤ ∑ _n ∈ Ioc N M, (1 : ℝ) := Finset.sum_le_sum fun n _ => by split_ifs <;> simp
      _ = ((M - N : ℕ) : ℝ) := by simp
  · exact incomplete_bound hs _ N M hNM _ fun b => hKB _ b

end GoldC.QuillonW

#print axioms GoldC.QuillonW.W_cauchy
