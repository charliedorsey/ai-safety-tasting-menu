import PaperB.FixedQ.H2BooleanRoughShiu
import PaperB.M3.BooleanCRTSecondMoment
import PaperB.FixedQ.HarmonicLogTail
import PaperB.FixedQ.FixedConductorCompletion

open scoped BigOperators

namespace PaperB.FixedQ

lemma h2_activeHighPrime_coprime_six_mul
    {q p : ℕ} (hp : activeHighPrime q p) :
    p.Coprime (6 * q) := by
  rcases hp with ⟨hpPrime, hp5, hpq⟩
  rw [hpPrime.coprime_iff_not_dvd]
  intro hdiv
  rcases hpPrime.dvd_mul.mp hdiv with h6 | hq
  · have hpLe : p ≤ 6 := Nat.le_of_dvd (by norm_num : 0 < 6) h6
    have hp56 : p = 5 ∨ p = 6 := by omega
    rcases hp56 with rfl | rfl
    · norm_num at h6
    · have h := hpPrime.eq_two_or_odd
      norm_num at h
  · exact hpq hq

lemma h2BooleanSecondTiltLift_prime_eq
    {q p : ℕ} (hp : activeHighPrime q p) :
    h2BooleanTiltLift q h2BooleanSecondTilt p =
      (p : ℝ) * h2BooleanV0 / ((p : ℝ) - 3) := by
  have hpPrime : p.Prime := hp.1
  have hp5 : 5 ≤ p := hp.2.1
  have hcop : p.Coprime (6 * q) :=
    h2_activeHighPrime_coprime_six_mul hp
  rw [h2BooleanTiltLift_apply]
  unfold h2BooleanTiltLiftNat
  rw [fixedQShiuWeight_prime_eq hpPrime hcop]
  have hcard : p.primeFactors.card = 1 := by simp [hpPrime]
  rw [hcard, pow_one]
  unfold fixedQShiuPrimeFactor
  rw [if_pos hp5]
  rw [h2BooleanSecondTilt_eq]
  unfold h2BooleanV0
  ring

noncomputable def h2BooleanM3LocalReal (p : ℕ) (j : ℤ) : ℝ :=
  (PaperB.Boolean.booleanLocalSecondMoment p j : ℚ)

lemma h2BooleanM3LocalReal_eq
    {p : ℕ} (j : ℤ) (hp : p.Prime) :
    h2BooleanM3LocalReal p j =
      if (p : ℤ) ∣ j then 1
      else (((p : ℝ) - 2) / (2 * ((p : ℝ) - 1))) := by
  unfold h2BooleanM3LocalReal
  rw [PaperB.Boolean.booleanLocalSecondMoment_eq p j hp]
  split_ifs with h
  · norm_num
  · push_cast
    rfl

lemma h2BooleanM3LocalReal_nonneg
    {p : ℕ} (j : ℤ) (hp : p.Prime) :
    0 ≤ h2BooleanM3LocalReal p j := by
  rw [h2BooleanM3LocalReal_eq j hp]
  split_ifs
  · norm_num
  · have hp2 : (2 : ℝ) ≤ p := by exact_mod_cast hp.two_le
    have hp1 : (1 : ℝ) < p := by exact_mod_cast hp.one_lt
    positivity
noncomputable def h2BooleanM3LocalWeight
    (q p : ℕ) (j : ℤ) : ℝ :=
  (h2BooleanTiltLift q h2BooleanSecondTilt p / (p : ℝ)) *
    h2BooleanM3LocalReal p j

lemma h2BooleanM3LocalWeight_active_eq
    {q p : ℕ} (j : ℤ) (hp : activeHighPrime q p) :
    h2BooleanM3LocalWeight q p j =
      (h2BooleanV0 / ((p : ℝ) - 3)) *
        h2BooleanM3LocalReal p j := by
  have hp0 : (0 : ℝ) < (p : ℝ) := by
    exact_mod_cast hp.1.pos
  rw [h2BooleanM3LocalWeight, h2BooleanSecondTiltLift_prime_eq hp]
  field_simp [hp0.ne']

lemma h2BooleanV0_le_three :
    h2BooleanV0 ≤ (3 : ℝ) := by
  rw [← two_mul_h2BooleanSecondTilt]
  nlinarith [h2BooleanSecondTilt_le_three_halves]

lemma h2BooleanM3LocalWeight_nonneg
    {q p : ℕ} (j : ℤ) (hp : p.Prime) :
    0 ≤ h2BooleanM3LocalWeight q p j := by
  unfold h2BooleanM3LocalWeight
  exact mul_nonneg
    (div_nonneg
      (h2BooleanTiltLift_nonneg q p h2BooleanSecondTilt_nonneg)
      (by positivity))
    (h2BooleanM3LocalReal_nonneg j hp)

lemma h2BooleanM3LocalReal_nonres_le_half
    {p : ℕ} {j : ℤ} (hp : p.Prime)
    (hn : ¬ (p : ℤ) ∣ j) :
    h2BooleanM3LocalReal p j ≤ (1 / 2 : ℝ) := by
  rw [h2BooleanM3LocalReal_eq j hp, if_neg hn]
  have hp1 : (1 : ℝ) < p := by exact_mod_cast hp.one_lt
  have hden : 0 < 2 * ((p : ℝ) - 1) := by positivity
  apply (div_le_iff₀ hden).2
  nlinarith

lemma h2BooleanM3LocalWeight_nonres_le
    {q p : ℕ} {j : ℤ}
    (hp : activeHighPrime q p)
    (hn : ¬ (p : ℤ) ∣ j) :
    h2BooleanM3LocalWeight q p j ≤
      (h2BooleanV0 / 2) * ((p : ℝ)⁻¹) +
        12 * ((p : ℝ)⁻¹ ^ 2) := by
  have hpPrime : p.Prime := hp.1
  have hp5 : 5 ≤ p := hp.2.1
  have hpR : (5 : ℝ) ≤ p := by exact_mod_cast hp5
  have hp0 : (0 : ℝ) < (p : ℝ) := by positivity
  have hpm3 : (0 : ℝ) < (p : ℝ) - 3 := by linarith
  rw [h2BooleanM3LocalWeight_active_eq j hp]
  have hm := h2BooleanM3LocalReal_nonres_le_half hpPrime hn
  have hbase0 : 0 ≤ h2BooleanV0 / ((p : ℝ) - 3) := by
    exact div_nonneg h2BooleanV0_nonneg hpm3.le
  calc
    (h2BooleanV0 / ((p : ℝ) - 3)) *
        h2BooleanM3LocalReal p j
        ≤ (h2BooleanV0 / ((p : ℝ) - 3)) * (1/2 : ℝ) :=
      mul_le_mul_of_nonneg_left hm hbase0
    _ ≤ (h2BooleanV0 / 2) * ((p : ℝ)⁻¹) +
          12 * ((p : ℝ)⁻¹ ^ 2) := by
      have hv := h2BooleanV0_le_three
      have hv0 := h2BooleanV0_nonneg
      field_simp [hp0.ne', hpm3.ne']
      nlinarith

lemma h2BooleanM3LocalWeight_res_le
    {q p : ℕ} {j : ℤ}
    (hp : activeHighPrime q p)
    (hr : (p : ℤ) ∣ j) :
    h2BooleanM3LocalWeight q p j ≤
      h2BooleanV0 * ((p : ℝ)⁻¹) +
        24 * ((p : ℝ)⁻¹ ^ 2) := by
  have hpPrime : p.Prime := hp.1
  have hp5 : 5 ≤ p := hp.2.1
  have hpR : (5 : ℝ) ≤ p := by exact_mod_cast hp5
  have hp0 : (0 : ℝ) < (p : ℝ) := by positivity
  have hpm3 : (0 : ℝ) < (p : ℝ) - 3 := by linarith
  rw [h2BooleanM3LocalWeight_active_eq j hp]
  rw [h2BooleanM3LocalReal_eq j hpPrime, if_pos hr, mul_one]
  have hv := h2BooleanV0_le_three
  have hv0 := h2BooleanV0_nonneg
  field_simp [hp0.ne', hpm3.ne']
  nlinarith
noncomputable def h2BooleanSmoothActivePrimeSet
    (q Y : ℕ) : Finset ℕ :=
  Y.primesLE.filter (fun p => activeHighPrime q p)

lemma h2BooleanSmoothActivePrimeSet_active
    {q Y : ℕ} :
    ∀ p ∈ h2BooleanSmoothActivePrimeSet q Y,
      activeHighPrime q p := by
  intro p hp
  exact (Finset.mem_filter.mp hp).2

lemma h2BooleanSmoothActivePrimeSet_prime
    {q Y : ℕ} :
    ∀ p ∈ h2BooleanSmoothActivePrimeSet q Y, p.Prime := by
  intro p hp
  exact (h2BooleanSmoothActivePrimeSet_active p hp).1

lemma h2BooleanSmoothActivePrimeSet_high
    {q Y : ℕ} :
    ∀ p ∈ h2BooleanSmoothActivePrimeSet q Y, 5 ≤ p := by
  intro p hp
  exact (h2BooleanSmoothActivePrimeSet_active p hp).2.1

lemma h2BooleanSecondTiltLift_prime_div_eq
    {q p : ℕ} (hp : activeHighPrime q p) :
    h2BooleanTiltLift q h2BooleanSecondTilt p / (p : ℝ) =
      h2BooleanV0 / ((p : ℝ) - 3) := by
  have hp0 : (0 : ℝ) < (p : ℝ) := by exact_mod_cast hp.1.pos
  rw [h2BooleanSecondTiltLift_prime_eq hp]
  field_simp [hp0.ne']

lemma h2BooleanSecondTiltWeight_prod_eq
    {q : ℕ} {S : Finset ℕ}
    (hA : ∀ p ∈ S, activeHighPrime q p) :
    (∏ p ∈ S,
        h2BooleanTiltLift q h2BooleanSecondTilt p / (p : ℝ)) =
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card := by
  have hpoint :
      ∀ p ∈ S,
        h2BooleanTiltLift q h2BooleanSecondTilt p / (p : ℝ) =
          (1 / ((p : ℝ) - 3)) * h2BooleanV0 := by
    intro p hp
    rw [h2BooleanSecondTiltLift_prime_div_eq (hA p hp)]
    ring
  calc
    (∏ p ∈ S,
        h2BooleanTiltLift q h2BooleanSecondTilt p / (p : ℝ))
        = ∏ p ∈ S, ((1 / ((p : ℝ) - 3)) * h2BooleanV0) := by
          apply Finset.prod_congr rfl
          intro p hp
          exact hpoint p hp
    _ = (∏ p ∈ S, 1 / ((p : ℝ) - 3)) *
          (∏ _p ∈ S, h2BooleanV0) := by
          rw [Finset.prod_mul_distrib]
    _ = finiteOmegaWeightReal S * h2BooleanV0 ^ S.card := by
          simp [finiteOmegaWeightReal]
lemma h2BooleanCRTSecondMoment_real_eq_prod
    (S : Finset ℕ) (j : ℤ) :
    ((PaperB.Boolean.booleanCRTSecondMoment S j : ℚ) : ℝ) =
      ∏ p ∈ S, h2BooleanM3LocalReal p j := by
  unfold PaperB.Boolean.booleanCRTSecondMoment h2BooleanM3LocalReal
  push_cast
  rfl

lemma h2BooleanM3LocalWeight_prod_eq
    {q : ℕ} {S : Finset ℕ} (j : ℤ)
    (hA : ∀ p ∈ S, activeHighPrime q p) :
    (∏ p ∈ S, h2BooleanM3LocalWeight q p j) =
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
        (((PaperB.Boolean.booleanCRTSecondMoment S j : ℚ) : ℝ)) := by
  unfold h2BooleanM3LocalWeight
  rw [Finset.prod_mul_distrib]
  rw [h2BooleanSecondTiltWeight_prod_eq hA]
  rw [h2BooleanCRTSecondMoment_real_eq_prod]

lemma h2Boolean_completeUnitSecondMoment_real
    {S : Finset ℕ} (j : ℤ)
    (hPrime : ∀ p ∈ S, p.Prime)
    (hHigh : ∀ p ∈ S, 5 ≤ p) :
    (((PaperB.Boolean.booleanCRTSecondMoment S j : ℚ) : ℝ)) =
      ∏ p ∈ (S.filter (fun p : ℕ => ¬ ((p : ℤ) ∣ j))),
        (((p : ℝ) - 2) / (2 * ((p : ℝ) - 1))) := by
  have h :=
    PaperB.Boolean.completeUnitBooleanSecondMoment S j hPrime hHigh
  exact_mod_cast h

lemma h2BooleanM3LocalWeight_prod_eq_complete_unit
    {q : ℕ} {S : Finset ℕ} (j : ℤ)
    (hA : ∀ p ∈ S, activeHighPrime q p) :
    (∏ p ∈ S, h2BooleanM3LocalWeight q p j) =
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
        (∏ p ∈ (S.filter (fun p : ℕ => ¬ ((p : ℤ) ∣ j))),
          (((p : ℝ) - 2) / (2 * ((p : ℝ) - 1)))) := by
  rw [h2BooleanM3LocalWeight_prod_eq j hA]
  rw [h2Boolean_completeUnitSecondMoment_real j
    (fun p hp => (hA p hp).1)
    (fun p hp => (hA p hp).2.1)]
noncomputable def h2BooleanM3BaselinePrimeTerm (p : ℕ) : ℝ :=
  (h2BooleanV0 / 2) * ((p : ℝ)⁻¹) +
    12 * ((p : ℝ)⁻¹ ^ 2)

lemma h2BooleanM3BaselinePrimeTerm_nonneg (p : ℕ) :
    0 ≤ h2BooleanM3BaselinePrimeTerm p := by
  unfold h2BooleanM3BaselinePrimeTerm
  exact add_nonneg
    (mul_nonneg (div_nonneg h2BooleanV0_nonneg (by norm_num))
      (inv_nonneg.mpr (by positivity)))
    (mul_nonneg (by norm_num) (sq_nonneg ((p : ℝ)⁻¹)))

lemma h2BooleanM3LocalWeight_le_baseline_plus_resonance
    {q p j : ℕ} (hp : activeHighPrime q p) :
    h2BooleanM3LocalWeight q p (j : ℤ) ≤
      h2BooleanM3BaselinePrimeTerm p +
        (if p ∣ j then h2BooleanM3BaselinePrimeTerm p else 0) := by
  by_cases hdiv : p ∣ j
  · have hdivZ : (p : ℤ) ∣ (j : ℤ) := by exact_mod_cast hdiv
    have hres := h2BooleanM3LocalWeight_res_le hp hdivZ
    rw [if_pos hdiv]
    unfold h2BooleanM3BaselinePrimeTerm
    nlinarith
  · have hdivZ : ¬ (p : ℤ) ∣ (j : ℤ) := by
      intro hz
      exact hdiv (by exact_mod_cast hz)
    have hnr := h2BooleanM3LocalWeight_nonres_le hp hdivZ
    rw [if_neg hdiv]
    simpa [h2BooleanM3BaselinePrimeTerm] using hnr

lemma h2BooleanSmoothActivePrimeSet_subset_primesLE
    (q Y : ℕ) :
    h2BooleanSmoothActivePrimeSet q Y ⊆ Y.primesLE := by
  intro p hp
  exact (Finset.mem_filter.mp hp).1

lemma sum_h2BooleanM3BaselinePrimeTerm_primesLE_le
    {Y : ℕ} (hY : 4 ≤ Y) :
    (∑ p ∈ Y.primesLE, h2BooleanM3BaselinePrimeTerm p) ≤
      (h2BooleanV0 / 2) *
        (Real.log (Real.log (Y : ℝ)) + 5) + 12 := by
  have hrecip := sum_prime_recip_le_loglog_add_five hY
  have hsub : Y.primesLE ⊆ Finset.Icc 2 Y := by
    intro p hp
    have hp' := Nat.mem_primesLE.mp hp
    exact Finset.mem_Icc.mpr ⟨hp'.2.two_le, hp'.1⟩
  have hsq :
      (∑ p ∈ Y.primesLE, ((p : ℝ)⁻¹ ^ 2)) ≤ 1 := by
    calc
      (∑ p ∈ Y.primesLE, ((p : ℝ)⁻¹ ^ 2)) ≤
          ∑ n ∈ Finset.Icc 2 Y, ((n : ℝ)⁻¹ ^ 2) := by
            exact Finset.sum_le_sum_of_subset_of_nonneg hsub
              (fun n hn hnot => by positivity)
      _ ≤ 1 := by
        simpa using
          (finite_square_tail_le_inv (F := 1) (M := Y) (by norm_num))
  unfold h2BooleanM3BaselinePrimeTerm
  calc
    (∑ p ∈ Y.primesLE,
        ((h2BooleanV0 / 2) * ((p : ℝ)⁻¹) +
          12 * ((p : ℝ)⁻¹ ^ 2))) =
      (h2BooleanV0 / 2) *
          (∑ p ∈ Y.primesLE, (1 : ℝ) / p) +
        12 * (∑ p ∈ Y.primesLE, ((p : ℝ)⁻¹ ^ 2)) := by
          simp_rw [one_div]
          rw [Finset.sum_add_distrib, Finset.mul_sum, Finset.mul_sum]
    _ ≤ (h2BooleanV0 / 2) *
          (Real.log (Real.log (Y : ℝ)) + 5) + 12 * 1 := by
          exact add_le_add
            (mul_le_mul_of_nonneg_left hrecip
              (div_nonneg h2BooleanV0_nonneg (by norm_num)))
            (mul_le_mul_of_nonneg_left hsq (by norm_num))
    _ = _ := by ring
lemma h2BooleanResonancePrimeSet_subset_primesLE
    {q Y j : ℕ} (hj : 4 ≤ j) :
    (h2BooleanSmoothActivePrimeSet q Y).filter (fun p => p ∣ j) ⊆
      j.primesLE := by
  intro p hp
  have hpF := Finset.mem_filter.mp hp
  have hpA := h2BooleanSmoothActivePrimeSet_active p hpF.1
  have hpPrime := hpA.1
  have hjpos : 0 < j := by omega
  have hpLe : p ≤ j := Nat.le_of_dvd hjpos hpF.2
  exact Nat.mem_primesLE.mpr ⟨hpLe, hpPrime⟩

lemma sum_h2BooleanM3BaselinePrimeTerm_resonance_le
    {q Y j : ℕ} (hj : 4 ≤ j) :
    (∑ p ∈ (h2BooleanSmoothActivePrimeSet q Y).filter
        (fun p => p ∣ j),
      h2BooleanM3BaselinePrimeTerm p) ≤
      (h2BooleanV0 / 2) *
        (Real.log (Real.log (j : ℝ)) + 5) + 12 := by
  have hsub :=
    h2BooleanResonancePrimeSet_subset_primesLE
      (q := q) (Y := Y) hj
  calc
    (∑ p ∈ (h2BooleanSmoothActivePrimeSet q Y).filter
        (fun p => p ∣ j),
      h2BooleanM3BaselinePrimeTerm p)
        ≤ ∑ p ∈ j.primesLE,
            h2BooleanM3BaselinePrimeTerm p := by
          exact Finset.sum_le_sum_of_subset_of_nonneg hsub
            (fun p hp hnot =>
              h2BooleanM3BaselinePrimeTerm_nonneg p)
    _ ≤ (h2BooleanV0 / 2) *
          (Real.log (Real.log (j : ℝ)) + 5) + 12 :=
      sum_h2BooleanM3BaselinePrimeTerm_primesLE_le hj

lemma sum_h2BooleanM3LocalWeight_le
    {q Y j : ℕ} (hY : 4 ≤ Y) (hj : 4 ≤ j) :
    (∑ p ∈ h2BooleanSmoothActivePrimeSet q Y,
      h2BooleanM3LocalWeight q p (j : ℤ)) ≤
      ((h2BooleanV0 / 2) *
          (Real.log (Real.log (Y : ℝ)) + 5) + 12) +
      ((h2BooleanV0 / 2) *
          (Real.log (Real.log (j : ℝ)) + 5) + 12) := by
  have hpoint :
      ∀ p ∈ h2BooleanSmoothActivePrimeSet q Y,
        h2BooleanM3LocalWeight q p (j : ℤ) ≤
          h2BooleanM3BaselinePrimeTerm p +
            (if p ∣ j then h2BooleanM3BaselinePrimeTerm p else 0) := by
    intro p hp
    exact h2BooleanM3LocalWeight_le_baseline_plus_resonance
      (h2BooleanSmoothActivePrimeSet_active p hp)
  have hsum := Finset.sum_le_sum hpoint
  have hbaseSubset :=
    h2BooleanSmoothActivePrimeSet_subset_primesLE q Y
  have hbase :
      (∑ p ∈ h2BooleanSmoothActivePrimeSet q Y,
        h2BooleanM3BaselinePrimeTerm p) ≤
        (h2BooleanV0 / 2) *
          (Real.log (Real.log (Y : ℝ)) + 5) + 12 := by
    calc
      (∑ p ∈ h2BooleanSmoothActivePrimeSet q Y,
        h2BooleanM3BaselinePrimeTerm p)
          ≤ ∑ p ∈ Y.primesLE,
              h2BooleanM3BaselinePrimeTerm p := by
            exact Finset.sum_le_sum_of_subset_of_nonneg hbaseSubset
              (fun p hp hnot =>
                h2BooleanM3BaselinePrimeTerm_nonneg p)
      _ ≤ _ := sum_h2BooleanM3BaselinePrimeTerm_primesLE_le hY
  have hresEq :
      (∑ p ∈ h2BooleanSmoothActivePrimeSet q Y,
        (if p ∣ j then h2BooleanM3BaselinePrimeTerm p else 0)) =
      ∑ p ∈ (h2BooleanSmoothActivePrimeSet q Y).filter
          (fun p => p ∣ j),
        h2BooleanM3BaselinePrimeTerm p := by
    rw [Finset.sum_filter]
  have hres :
      (∑ p ∈ h2BooleanSmoothActivePrimeSet q Y,
        (if p ∣ j then h2BooleanM3BaselinePrimeTerm p else 0)) ≤
        (h2BooleanV0 / 2) *
          (Real.log (Real.log (j : ℝ)) + 5) + 12 := by
    rw [hresEq]
    exact sum_h2BooleanM3BaselinePrimeTerm_resonance_le hj
  rw [Finset.sum_add_distrib] at hsum
  exact hsum.trans (add_le_add hbase hres)
noncomputable def h2BooleanSmoothM3EulerMass
    (q Y : ℕ) (j : ℤ) : ℝ :=
  ∑ S ∈ (h2BooleanSmoothActivePrimeSet q Y).powerset,
    ∏ p ∈ S, h2BooleanM3LocalWeight q p j

theorem h2BooleanSmoothM3EulerMass_eq_prod
    (q Y : ℕ) (j : ℤ) :
    h2BooleanSmoothM3EulerMass q Y j =
      ∏ p ∈ h2BooleanSmoothActivePrimeSet q Y,
        (1 + h2BooleanM3LocalWeight q p j) := by
  unfold h2BooleanSmoothM3EulerMass
  exact (Finset.prod_one_add
    (s := h2BooleanSmoothActivePrimeSet q Y)
    (f := fun p => h2BooleanM3LocalWeight q p j)).symm

theorem h2BooleanSmoothM3EulerMass_le_exp
    {q Y j : ℕ} (hY : 4 ≤ Y) (hj : 4 ≤ j) :
    h2BooleanSmoothM3EulerMass q Y (j : ℤ) ≤
      Real.exp
        (((h2BooleanV0 / 2) *
            (Real.log (Real.log (Y : ℝ)) + 5) + 12) +
         ((h2BooleanV0 / 2) *
            (Real.log (Real.log (j : ℝ)) + 5) + 12)) := by
  rw [h2BooleanSmoothM3EulerMass_eq_prod]
  let g : ℕ → ℝ := fun p =>
    if hp : p ∈ h2BooleanSmoothActivePrimeSet q Y then
      h2BooleanM3LocalWeight q p (j : ℤ) else 0
  have hg : ∀ p : ℕ, 0 ≤ g p := by
    intro p
    dsimp [g]
    split_ifs with hp
    · exact h2BooleanM3LocalWeight_nonneg (j : ℤ)
        (h2BooleanSmoothActivePrimeSet_prime p hp)
    · exact le_rfl
  have hprod :
      (∏ p ∈ h2BooleanSmoothActivePrimeSet q Y,
        (1 + h2BooleanM3LocalWeight q p (j : ℤ))) =
      ∏ p ∈ h2BooleanSmoothActivePrimeSet q Y, (1 + g p) := by
    apply Finset.prod_congr rfl
    intro p hp
    simp [g, hp]
  have hsum :
      (∑ p ∈ h2BooleanSmoothActivePrimeSet q Y, g p) =
      ∑ p ∈ h2BooleanSmoothActivePrimeSet q Y,
        h2BooleanM3LocalWeight q p (j : ℤ) := by
    apply Finset.sum_congr rfl
    intro p hp
    simp [g, hp]
  rw [hprod]
  have hpe :
      (∏ p ∈ h2BooleanSmoothActivePrimeSet q Y, (1 + g p)) ≤
        Real.exp
          (∑ p ∈ h2BooleanSmoothActivePrimeSet q Y, g p) :=
    Real.prod_one_add_le_exp_sum
      (h2BooleanSmoothActivePrimeSet q Y) hg
  rw [hsum] at hpe
  exact hpe.trans
    (Real.exp_le_exp.mpr (sum_h2BooleanM3LocalWeight_le hY hj))

#print axioms h2BooleanM3LocalWeight_prod_eq_complete_unit
#print axioms h2BooleanSmoothM3EulerMass_le_exp

theorem h2BooleanSmoothM3EulerMass_le_log_powers
    {q Y j : ℕ} (hY : 4 ≤ Y) (hj : 4 ≤ j) :
    h2BooleanSmoothM3EulerMass q Y (j : ℤ) ≤
      Real.exp (5 * h2BooleanV0 + 24) *
        (Real.log (Y : ℝ)) ^ (h2BooleanV0 / 2) *
        (Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by
  have hbase := h2BooleanSmoothM3EulerMass_le_exp
    (q := q) (Y := Y) (j := j) hY hj
  have hY1 : (1 : ℝ) < (Y : ℝ) := by
    exact_mod_cast (show 1 < Y by omega)
  have hj1 : (1 : ℝ) < (j : ℝ) := by
    exact_mod_cast (show 1 < j by omega)
  have hlogY : 0 < Real.log (Y : ℝ) := Real.log_pos hY1
  have hlogj : 0 < Real.log (j : ℝ) := Real.log_pos hj1
  calc
    h2BooleanSmoothM3EulerMass q Y (j : ℤ)
        ≤ Real.exp
          (((h2BooleanV0 / 2) *
              (Real.log (Real.log (Y : ℝ)) + 5) + 12) +
           ((h2BooleanV0 / 2) *
              (Real.log (Real.log (j : ℝ)) + 5) + 12)) := hbase
    _ = Real.exp (5 * h2BooleanV0 + 24) *
        Real.exp
          (Real.log (Real.log (Y : ℝ)) *
            (h2BooleanV0 / 2)) *
        Real.exp
          (Real.log (Real.log (j : ℝ)) *
            (h2BooleanV0 / 2)) := by
      rw [show
        ((h2BooleanV0 / 2) *
              (Real.log (Real.log (Y : ℝ)) + 5) + 12) +
           ((h2BooleanV0 / 2) *
              (Real.log (Real.log (j : ℝ)) + 5) + 12) =
          (5 * h2BooleanV0 + 24) +
            Real.log (Real.log (Y : ℝ)) * (h2BooleanV0 / 2) +
            Real.log (Real.log (j : ℝ)) * (h2BooleanV0 / 2) by ring]
      rw [Real.exp_add, Real.exp_add]
    _ = Real.exp (5 * h2BooleanV0 + 24) *
        (Real.log (Y : ℝ)) ^ (h2BooleanV0 / 2) *
        (Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by
      rw [Real.rpow_def_of_pos hlogY, Real.rpow_def_of_pos hlogj]

#print axioms h2BooleanSmoothM3EulerMass_le_log_powers

end PaperB.FixedQ
