import PaperB.FixedQ.SignedForbiddenThalenFiniteMassPacket

open scoped BigOperators

namespace PaperB.FixedQ

/-- The literal outer proper Boolean source over finite active primes
is exactly its centered finite spectral correlation, with the true
signed diagonal/density correction. No cutoff is removed. -/
theorem thalen_finite_full_source_eq_spectral
    (q A H : ℕ) (S : Finset ℕ)
    (hp : ∀ p ∈ S, p.Prime)
    (h5 : ∀ p ∈ S, 5 ≤ p)
    (hH : ∀ p ∈ S, ¬ p ∣ H) :
    (∑ e ∈ S.powerset, thalenFiniteOuterSourceTerm q A H e) =
      (∑ y ∈ Finset.Ioo 0 H,
        fixedQLowWeight q A H y *
          (thalenFiniteCenteredPacket S (thalenFiniteA S) y *
           thalenFiniteCenteredPacket S (thalenFiniteA S) (H-y))) -
        rowWeightMass (fixedQLowWeight q A H) H *
          ((thalenFiniteA S - 1) ^ 2 +
           (thalenFiniteA S) ^ 2 *
             ((∏ p ∈ S, (1 - thalenPrimeDelta p ^ 2)) - 1)) := by
  calc
    _ = (∑ e ∈ S.powerset,
          finiteOmegaWeightReal e *
            (∑ B ∈ ((e.powerset.erase e).erase ∅),
              rowConstrainedMass (fixedQLowWeight q A H) H
                (primeSetProduct B) (primeSetProduct (e \ B)))) -
        rowWeightMass (fixedQLowWeight q A H) H *
          (∑ e ∈ S.powerset,
            finiteOmegaWeightReal e *
              (∑ B ∈ ((e.powerset.erase e).erase ∅),
                1 / ((primeSetProduct B : ℝ) *
                  (primeSetProduct (e \ B) : ℝ)))) :=
        thalen_finite_outer_eq_constrained_sub_density q A H S
    _ = (∑ y ∈ Finset.Ioo 0 H,
         fixedQLowWeight q A H y *
           thalenFiniteProperSourcePacket S H y) -
        rowWeightMass (fixedQLowWeight q A H) H *
          thalenFiniteProperSourceDensity S := by
          rw [thalen_finite_rowMass_eq_weighted_sourcePacket
            S H (fixedQLowWeight q A H) hp,
            thalen_finite_source_density_eq_rows]
    _ = _ := thalen_weighted_finite_proper_source_eq_spectral S H
      (fixedQLowWeight q A H) h5 hH

/-- Cairn's precise finite decorated source/cutoff commission:
actual dForbidden source equals the complete centered source-spectral
packet MINUS the signed low-support source term at the ORIGINAL Z.
Both endpoints and the density overlap remain in the centered packet. -/
theorem thalen_decorated_finite_exterior_eq_spectral_sub_small
    (q A H Z : ℕ) (d S : Finset ℕ)
    (hact : ∀ n ∈ S.powerset,
      n ∈ activeOrdinaryTwoDimensionalSet q H)
    (hdis : Disjoint d S) :
    (∑ n ∈ S.powerset.filter (fun n => Z < primeSetProduct n),
      dForbiddenReducedBooleanCoreTerm q A H d n) =
      (∑ y ∈ Finset.Ioo 0 H,
        fixedQLowWeight q A H y *
          (thalenFiniteCenteredPacket S (thalenFiniteA S) y *
           thalenFiniteCenteredPacket S (thalenFiniteA S) (H-y))) -
        rowWeightMass (fixedQLowWeight q A H) H *
          ((thalenFiniteA S - 1) ^ 2 +
           (thalenFiniteA S) ^ 2 *
             ((∏ p ∈ S, (1 - thalenPrimeDelta p ^ 2)) - 1)) -
        (∑ n ∈ S.powerset.filter (fun n => primeSetProduct n ≤ Z),
          thalenFiniteOuterSourceTerm q A H n) := by
  have hp : ∀ p ∈ S, p.Prime := by
    intro p hpS
    have hs : S ∈ S.powerset := Finset.mem_powerset.mpr (Finset.Subset.rfl)
    exact ((hact S hs).2 p hpS).1
  have h5 : ∀ p ∈ S, 5 ≤ p := by
    intro p hpS
    exact ((hact S (Finset.mem_powerset.mpr (Finset.Subset.rfl))).2 p hpS).2.1
  have hH : ∀ p ∈ S, ¬ p ∣ H := by
    intro p hpS
    exact ordinaryTwoDimensionalSet_iff.mp
      (hact S (Finset.mem_powerset.mpr (Finset.Subset.rfl))).1 p hpS
  rw [thalen_decorated_finite_exterior_eq_full_sub_small
    q A H Z d S hact hdis]
  rw [thalen_finite_full_source_eq_spectral q A H S hp h5 hH]

#print axioms thalen_finite_full_source_eq_spectral
#print axioms thalen_decorated_finite_exterior_eq_spectral_sub_small

end PaperB.FixedQ
