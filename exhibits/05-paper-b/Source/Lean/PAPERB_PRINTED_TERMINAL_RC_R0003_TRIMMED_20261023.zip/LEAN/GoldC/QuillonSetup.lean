import GoldC.QuillonBridge
import GoldC.QuillonLam
import GoldC.QuillonPairParam
import GoldC.QuillonDecorationGronwall
import GoldC.QuillonCells

/-!
# Quillon CSC3 F8.3: CORE source copies, parameters, admissibility, mask convexity

**Verbatim copies** (namespace `GoldC.QuillonCopyM`) of:
* `Merivelle.Central.regionDecorations` (from `GoldC/QuarterFold.lean`);
* `regionSumMiddleWhere`, `longInverseLeft`, `longInverseRight` (from `MiddleDirectionalPartition.lean`);
* `longEither`, `signedCoreMiddle` (from `MiddleLongCoreConsumer.lean`);
* `SourceUniformSublog` (from `ThreeSectorConsumer.lean`).

The names they use resolve to the existing verbatim copies: `QuillonCopyS` (SourceCore,
`regionPairSumMiddleWhere`), `QuillonCopyG` (`decoratedHeightPrimeSet`, `decorationWeight`) and
`QuillonCopyF` (`centralGate`, `foldRow`).

**Admissibility** (`adm`). On the source mask (`Z < rs`, `¬long`, `centralGate`, `H ≤ h`):
* `log r, log s ≥ 5Λ^σ`, with `σ = 2/3 + 1/100` and `Λ = log h`;
* `r, s ≤ h`;
* `rs·e^{Λ^{1/4}} ≤ H`.

**Convexity** (`geo0_convex_r`, `geo0_convex_s`): the source mask is convex in each variable.

No axiom, no `sorry`.
-/

open scoped BigOperators Classical
open Finset

namespace GoldC.QuillonCopyM

open GoldC.QuillonCopyS GoldC.QuillonCopyG GoldC.QuillonCopyF

noncomputable def regionDecorations (q h : ℕ) : Finset (Finset ℕ) :=
  (decoratedHeightPrimeSet q h).powerset

noncomputable def regionSumMiddleWhere
    (Jlow Jhigh q h : ℕ)
    (gate : ℕ → ℕ → ℕ → Prop)
    (P : ℕ → ℕ → Prop)
    (F : ℕ → ℕ → ℕ → ℕ → ℝ) : ℝ :=
  ∑ d ∈ regionDecorations q h,
    decorationWeight h d *
      regionPairSumMiddleWhere Jlow Jhigh q h gate P d
        (F (primeSetProduct d))

noncomputable def longInverseLeft (δ : ℝ) (r s : ℕ) : Prop :=
  (s : ℝ) ^ (1 + δ) < (r : ℝ)

noncomputable def longInverseRight (δ : ℝ) (r s : ℕ) : Prop :=
  (r : ℝ) ^ (1 + δ) < (s : ℝ)

noncomputable def longEither (δ : ℝ) (r s : ℕ) : Prop :=
  longInverseLeft δ r s ∨ longInverseRight δ r s

noncomputable def signedCoreMiddle (Jlow Jhigh : ℕ → ℕ)
    (δ : ℝ) (q a h : ℕ) : ℝ :=
  regionSumMiddleWhere (Jlow h) (Jhigh h) q h
    (centralGate h) (fun r s => ¬ longEither δ r s) (foldRow q a)

def SourceUniformSublog (S : ℕ → ℕ → ℕ → ℝ) : Prop :=
  ∀ q : ℕ, 0 < q → Squarefree q →
    ∀ eps : ℝ, 0 < eps →
      ∃ H0 : ℕ, ∀ a h : ℕ,
        q.Coprime a → 0 < h → (¬ 2 ∣ q → 2 ∣ h) →
        H0 ≤ h →
        |S q a h| ≤ eps * Real.log (h : ℝ)

end GoldC.QuillonCopyM

namespace GoldC.QuillonSetup

open GoldC.QuillonCopyS GoldC.QuillonCopyG GoldC.QuillonCopyF GoldC.QuillonCopyM

/-- The base geometric source mask for the oriented pair `(r, s)`. -/
def Geo0 (h H : ℕ) (δ : ℝ) (r s : ℕ) : Prop :=
  originalZ h < r * s ∧ 4 * (r * s) ≤ H ^ 2 ∧ ¬ longEither δ r s ∧ centralGate h H r s

noncomputable def σ₀ : ℝ := 2 / 3 + 1 / 100

lemma originalZ_ge (h : ℕ) :
    20 * Real.log 2 * (Real.log h) ^ σ₀ ≤ Real.log (originalZ h : ℝ) := by
  unfold originalZ booleanSourceCutoff
  rw [show σ₀ = booleanSigma from rfl]
  push_cast
  rw [Real.log_pow]
  have hl2 : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have h1 : (Real.log h) ^ booleanSigma ≤ (⌊(Real.log h) ^ booleanSigma⌋₊ : ℝ) + 1 :=
    (Nat.lt_floor_add_one _).le
  push_cast
  nlinarith

/-- Admissibility of both factors on the source mask. -/
theorem adm (h H r s : ℕ) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) (hh : 2 ≤ h) (hHh : H ≤ h)
    (hG : Geo0 h H δ r s) :
    5 * (Real.log h) ^ σ₀ ≤ Real.log s ∧ 5 * (Real.log h) ^ σ₀ ≤ Real.log r ∧
      1 ≤ r ∧ 1 ≤ s ∧ (r : ℝ) ≤ h ∧ (s : ℝ) ≤ h ∧
      (r : ℝ) ≤ (s : ℝ) ^ (1 + δ) ∧ (s : ℝ) ≤ (r : ℝ) ^ (1 + δ) ∧
      ((r : ℝ) * s) * Real.exp ((Real.log h) ^ (1 / 4 : ℝ)) ≤ H := by
  obtain ⟨hZ, -, hlong, hgate1, -, -⟩ := hG
  unfold longEither longInverseLeft longInverseRight at hlong
  push_neg at hlong
  obtain ⟨hL, hR⟩ := hlong
  have hrs0 : 0 < r * s := lt_of_le_of_lt (Nat.zero_le _) hZ
  have hr1 : 1 ≤ r := Nat.pos_of_ne_zero (by rintro rfl; simp at hrs0)
  have hs1 : 1 ≤ s := Nat.pos_of_ne_zero (by rintro rfl; simp at hrs0)
  have hrR : (1 : ℝ) ≤ r := by exact_mod_cast hr1
  have hsR : (1 : ℝ) ≤ s := by exact_mod_cast hs1
  have hE : 1 ≤ Real.exp ((Real.log h) ^ (1 / 4 : ℝ)) := Real.one_le_exp (by positivity)
  have hHR : (H : ℝ) ≤ h := by exact_mod_cast hHh
  have hrsH : ((r : ℝ) * s) * Real.exp ((Real.log h) ^ (1 / 4 : ℝ)) ≤ H := by
    have := hgate1
    rw [le_div_iff₀ (Real.exp_pos _)] at this
    exact_mod_cast this
  have hrs_le : (r : ℝ) * s ≤ h :=
    calc (r : ℝ) * s ≤ ((r : ℝ) * s) * Real.exp ((Real.log h) ^ (1 / 4 : ℝ)) :=
          le_mul_of_one_le_right (by positivity) hE
      _ ≤ H := hrsH
      _ ≤ h := hHR
  have hrh : (r : ℝ) ≤ h := le_trans (le_mul_of_one_le_right (by positivity) hsR) hrs_le
  have hsh : (s : ℝ) ≤ h := le_trans (le_mul_of_one_le_left (by positivity) hrR) hrs_le
  -- logs
  have hZl := originalZ_ge h
  have hZlt : Real.log (originalZ h : ℝ) < Real.log ((r : ℝ) * s) := by
    apply Real.log_lt_log
    · have : 0 < originalZ h := by unfold originalZ; exact Nat.pow_pos (by norm_num)
      exact_mod_cast this
    · exact_mod_cast hZ
  rw [Real.log_mul (by positivity) (by positivity)] at hZlt
  clear hZ hgate1
  have hlr : Real.log r ≤ (1 + δ) * Real.log s := by
    have := Real.log_le_log (by positivity) hL
    rwa [Real.log_rpow (by positivity)] at this
  have hls : Real.log s ≤ (1 + δ) * Real.log r := by
    have := Real.log_le_log (by positivity) hR
    rwa [Real.log_rpow (by positivity)] at this
  have hl2 : (0.69 : ℝ) < Real.log 2 := by have := Real.log_two_gt_d9; linarith
  have hσpos : 0 ≤ (Real.log h) ^ σ₀ := by
    have h1 : (1 : ℝ) ≤ h := by exact_mod_cast (by omega : 1 ≤ h)
    exact Real.rpow_nonneg (Real.log_nonneg h1) _
  have hlogs0 : 0 ≤ Real.log s := Real.log_nonneg hsR
  have hlogr0 : 0 ≤ Real.log r := Real.log_nonneg hrR
  generalize Real.log (originalZ h : ℝ) = Lz at hZl hZlt
  generalize (Real.log h) ^ σ₀ = Lσ at hZl hσpos ⊢
  have k1 : 20 * 0.69 * Lσ ≤ 20 * Real.log 2 * Lσ := by
    apply mul_le_mul_of_nonneg_right _ hσpos; linarith
  have k2 : (1 + δ) * Real.log s ≤ (4 / 3) * Real.log s :=
    mul_le_mul_of_nonneg_right (by linarith) hlogs0
  have k3 : (1 + δ) * Real.log r ≤ (4 / 3) * Real.log r :=
    mul_le_mul_of_nonneg_right (by linarith) hlogr0
  refine ⟨?_, ?_, hr1, hs1, hrh, hsh, hL, hR, hrsH⟩
  · linarith
  · linarith

/-- convexity of the base mask in `r` (fixed `s`). -/
theorem geo0_convex_r (h H : ℕ) (δ : ℝ) (hδ : 0 ≤ δ) (s : ℕ) :
    ∀ a b c, a ≤ b → b ≤ c → Geo0 h H δ a s → Geo0 h H δ c s → Geo0 h H δ b s := by
  intro a b c hab hbc ha hc
  obtain ⟨ha1, ha2, ha3, ha4, ha5, ha6⟩ := ha
  obtain ⟨hc1, hc2, hc3, hc4, hc5, hc6⟩ := hc
  unfold longEither longInverseLeft longInverseRight at ha3 hc3
  push_neg at ha3 hc3
  have habR : (a : ℝ) ≤ b := by exact_mod_cast hab
  have hbcR : (b : ℝ) ≤ c := by exact_mod_cast hbc
  have ha0 : (0 : ℝ) ≤ a := by positivity
  refine ⟨lt_of_lt_of_le ha1 (Nat.mul_le_mul_right _ hab), le_trans (by
    have := Nat.mul_le_mul_right s hbc; omega) hc2, ?_, ?_, ?_, ?_⟩
  · unfold longEither longInverseLeft longInverseRight; push_neg
    exact ⟨le_trans hbcR hc3.1, le_trans ha3.2 (Real.rpow_le_rpow ha0 habR (by linarith))⟩
  · have : (b : ℝ) * s ≤ c * s := by gcongr
    exact le_trans (by exact_mod_cast Nat.mul_le_mul_right s hbc) hc4
  · exact le_trans ha5 (Nat.pow_le_pow_left hab 2)
  · exact le_trans hbc hc6

/-- convexity of the base mask in `s` (fixed `r`). -/
theorem geo0_convex_s (h H : ℕ) (δ : ℝ) (hδ : 0 ≤ δ) (r : ℕ) :
    ∀ a b c, a ≤ b → b ≤ c → Geo0 h H δ r a → Geo0 h H δ r c → Geo0 h H δ r b := by
  intro a b c hab hbc ha hc
  obtain ⟨ha1, ha2, ha3, ha4, ha5, ha6⟩ := ha
  obtain ⟨hc1, hc2, hc3, hc4, hc5, hc6⟩ := hc
  unfold longEither longInverseLeft longInverseRight at ha3 hc3
  push_neg at ha3 hc3
  have habR : (a : ℝ) ≤ b := by exact_mod_cast hab
  have hbcR : (b : ℝ) ≤ c := by exact_mod_cast hbc
  have ha0 : (0 : ℝ) ≤ a := by positivity
  refine ⟨lt_of_lt_of_le ha1 (Nat.mul_le_mul_left _ hab), le_trans (by
    have := Nat.mul_le_mul_left r hbc; omega) hc2, ?_, ?_, ?_, ?_⟩
  · unfold longEither longInverseLeft longInverseRight; push_neg
    exact ⟨le_trans ha3.1 (Real.rpow_le_rpow ha0 habR (by linarith)), le_trans hbcR hc3.2⟩
  · exact le_trans (by exact_mod_cast Nat.mul_le_mul_left r hbc) hc4
  · exact le_trans hbc hc5
  · exact le_trans ha6 (Nat.pow_le_pow_left hab 2)

end GoldC.QuillonSetup

#print axioms GoldC.QuillonSetup.adm
#print axioms GoldC.QuillonSetup.geo0_convex_r
#print axioms GoldC.QuillonSetup.geo0_convex_s
