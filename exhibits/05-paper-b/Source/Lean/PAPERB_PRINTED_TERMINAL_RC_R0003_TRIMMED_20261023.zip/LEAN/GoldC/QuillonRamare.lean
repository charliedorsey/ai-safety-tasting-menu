import Mathlib.Algebra.BigOperators.Field
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Tactic

/-!
# Quillon CSC3 F7.5c: Ramaré's identity (exact, coupling-free factorization)

For finite sets `J ⊆ T` and any `f : Finset ℕ → 𝕜` (`𝕜` a field of characteristic 0):

    Σ_{B ⊆ T, B∩J ≠ ∅} f(B) = Σ_{p∈J} Σ_{B' ⊆ T∖{p}} f(B' ∪ {p}) / (1 + |B'∩J|).

The weight `1/(1+|B'∩J|)` depends on `B'` only. With `r = ∏B = p·∏B'`, this writes every `r` that
has a prime in `J` as a bilinear form in `(p, ∏B')` with **no** coupling between `p` and `B'` beyond
`p ∉ B'`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonRamare

variable {𝕜 : Type*} [Field 𝕜] [CharZero 𝕜]

lemma powerset_filter_mem_eq_image (T : Finset ℕ) (p : ℕ) (hp : p ∈ T) :
    T.powerset.filter (fun B => p ∈ B) = (T.erase p).powerset.image (insert p) := by
  ext B
  simp only [mem_filter, mem_powerset, mem_image]
  constructor
  · rintro ⟨hBT, hpB⟩
    refine ⟨B.erase p, ?_, insert_erase hpB⟩
    intro x hx
    simp only [mem_erase] at hx ⊢
    exact ⟨hx.1, hBT hx.2⟩
  · rintro ⟨B', hB', rfl⟩
    refine ⟨?_, mem_insert_self _ _⟩
    intro x hx
    rcases mem_insert.1 hx with rfl | hx
    · exact hp
    · exact (mem_erase.1 (hB' hx)).2

theorem ramare (T J : Finset ℕ) (hJ : J ⊆ T) (f : Finset ℕ → 𝕜) :
    ∑ B ∈ T.powerset.filter (fun B => (B ∩ J).Nonempty), f B =
      ∑ p ∈ J, ∑ B' ∈ (T.erase p).powerset,
        f (insert p B') / (1 + ((B' ∩ J).card : 𝕜)) := by
  classical
  -- step 1: spread `f B` over the primes of `B ∩ J`
  have h1 : ∑ B ∈ T.powerset.filter (fun B => (B ∩ J).Nonempty), f B =
      ∑ B ∈ T.powerset, ∑ p ∈ B ∩ J, f B / ((B ∩ J).card : 𝕜) := by
    rw [sum_filter]
    refine sum_congr rfl fun B _ => ?_
    split_ifs with hne
    · rw [sum_const, nsmul_eq_mul]
      have : ((B ∩ J).card : 𝕜) ≠ 0 := by exact_mod_cast (card_pos.2 hne).ne'
      field_simp
    · rw [not_nonempty_iff_eq_empty.1 hne, sum_empty]
  rw [h1]
  -- step 2: swap the order
  rw [sum_comm' (t' := J) (s' := fun p => T.powerset.filter (fun B => p ∈ B))]
  swap
  · intro B p
    simp only [mem_powerset, mem_inter, mem_filter]
    constructor
    · rintro ⟨hBT, hpB, hpJ⟩; exact ⟨⟨hBT, hpB⟩, hpJ⟩
    · rintro ⟨⟨hBT, hpB⟩, hpJ⟩; exact ⟨hBT, hpB, hpJ⟩
  -- step 3: reindex `B = insert p B'`
  refine sum_congr rfl fun p hp => ?_
  rw [powerset_filter_mem_eq_image T p (hJ hp), sum_image]
  · refine sum_congr rfl fun B' hB' => ?_
    have hpB' : p ∉ B' := fun h => by
      have := (mem_powerset.1 hB') h; simp at this
    rw [insert_inter_of_mem hp, card_insert_of_notMem (fun h => hpB' (mem_inter.1 h).1)]
    push_cast; ring
  · intro B₁ h₁ B₂ h₂ heq
    have hp₁ : p ∉ B₁ := fun h => by have := (mem_powerset.1 h₁) h; simp at this
    have hp₂ : p ∉ B₂ := fun h => by have := (mem_powerset.1 h₂) h; simp at this
    have := congrArg (fun B => B.erase p) heq
    simpa [erase_insert hp₁, erase_insert hp₂] using this

end GoldC.QuillonRamare

#print axioms GoldC.QuillonRamare.ramare
