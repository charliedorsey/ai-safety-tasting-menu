import PaperB.Closure
import PaperB.ExactAccounting.H1FloorFamilyBridge
import PaperB.Analytic.PetermannEtaR0002
import PaperB.Analytic.PetermannOmegaR0002

open scoped BigOperators

namespace PaperB.Admission

open PaperB.FixedQ
open PaperB.Closure
open PaperB.ExactAccounting
open PaperB.Analytic

private lemma h1_positiveGapRepresentative_compat
    {q a b : ℕ} (hq : 0 < q) :
    Nat.ModEq q (a + positiveGapRepresentative q a b) b := by
  let A := a % q
  let B := b % q
  have hA : A < q := by dsimp [A]; exact Nat.mod_lt _ hq
  have hB : B < q := by dsimp [B]; exact Nat.mod_lt _ hq
  by_cases hEq : A = B
  · have hraw0 : (B + q - A) % q = 0 := by
      rw [hEq]
      simp
    unfold positiveGapRepresentative
    change (a + (if (B + q - A) % q = 0 then q else (B + q - A) % q)) % q = b % q
    rw [if_pos hraw0]
    simp [Nat.add_mod, A, B, hEq]
  · by_cases hAB : A < B
    · have hBA : B - A < q := by omega
      have hraw : (B + q - A) % q = B - A := by
        have heq : B + q - A = q + (B - A) := by omega
        rw [heq]
        simp [Nat.add_mod, Nat.mod_eq_of_lt hBA]
      have hpos : B - A ≠ 0 := by omega
      unfold positiveGapRepresentative
      change (a + (if (B + q - A) % q = 0 then q else (B + q - A) % q)) % q = b % q
      rw [hraw, if_neg hpos, Nat.add_mod]
      rw [Nat.mod_eq_of_lt hBA]
      have hsum : A + (B - A) = B := by omega
      rw [show a % q = A by rfl, hsum, Nat.mod_eq_of_lt hB]
    · have hBA : B < A := by omega
      have hraw_lt : B + q - A < q := by omega
      have hraw_pos : 0 < B + q - A := by omega
      have hraw : (B + q - A) % q = B + q - A :=
        Nat.mod_eq_of_lt hraw_lt
      have hne : B + q - A ≠ 0 := Nat.ne_of_gt hraw_pos
      unfold positiveGapRepresentative
      change (a + (if (B + q - A) % q = 0 then q else (B + q - A) % q)) % q = b % q
      rw [hraw, if_neg hne, Nat.add_mod]
      rw [Nat.mod_eq_of_lt hraw_lt]
      have hsum : A + (B + q - A) = B + q := by omega
      rw [show a % q = A by rfl, hsum, Nat.add_mod, Nat.mod_self, add_zero]
      simp [B, Nat.mod_eq_of_lt (Nat.mod_lt b hq)]

private lemma h1_positiveGapRepresentative_le_modulus
    {q a b : ℕ} (hq : 0 < q) :
    positiveGapRepresentative q a b ≤ q := by
  let r := (b % q + q - a % q) % q
  change (if r = 0 then q else r) ≤ q
  by_cases hr : r = 0
  · simp [hr]
  · rw [if_neg hr]
    exact Nat.le_of_lt (by
      dsimp [r]
      exact Nat.mod_lt _ hq)

private lemma h1_compatible_height_even
    {q a b h : ℕ}
    (ha : q.Coprime a) (hb : q.Coprime b)
    (hcompat : Nat.ModEq q (a + h) b)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    2 ∣ h := by
  by_cases h2q : 2 ∣ q
  · have h2a : Nat.Coprime 2 a := Nat.Coprime.of_dvd_left h2q ha
    have h2b : Nat.Coprime 2 b := Nat.Coprime.of_dvd_left h2q hb
    have haodd : Odd a := h2a.odd_of_left
    have hbodd : Odd b := h2b.odd_of_left
    obtain ⟨ka, hka⟩ := haodd
    obtain ⟨kb, hkb⟩ := hbodd
    have hmod2 : Nat.ModEq 2 (a + h) b := hcompat.of_dvd h2q
    unfold Nat.ModEq at hmod2
    rw [hka, hkb] at hmod2
    have : h % 2 = 0 := by omega
    exact Nat.dvd_iff_mod_eq_zero.mpr this
  · exact h2admissible h2q

private lemma h1_compatible_height_progression
    {q a b h : ℕ}
    (hq : 0 < q) (hh : 0 < h)
    (hcompat : Nat.ModEq q (a + h) b) :
    ∃ n : ℕ, h = positiveGapRepresentative q a b + n * q := by
  let g := positiveGapRepresentative q a b
  have hgpos : 0 < g := by
    dsimp [g]
    exact positiveGapRepresentative_pos hq
  have hgle : g ≤ q := by
    dsimp [g]
    exact h1_positiveGapRepresentative_le_modulus hq
  have hgap : Nat.ModEq q (a + g) b := by
    dsimp [g]
    exact h1_positiveGapRepresentative_compat hq
  have hhg : Nat.ModEq q h g :=
    Nat.ModEq.add_left_cancel' a (hcompat.trans hgap.symm)
  have hgh : g ≤ h := by
    by_cases hqh : q ≤ h
    · exact hgle.trans hqh
    · have hhq : h < q := by omega
      have hgq : g < q := by
        by_contra hng
        have hgeq : g = q := by omega
        unfold Nat.ModEq at hhg
        rw [Nat.mod_eq_of_lt hhq] at hhg
        rw [hgeq, Nat.mod_self] at hhg
        omega
      unfold Nat.ModEq at hhg
      rw [Nat.mod_eq_of_lt hhq, Nat.mod_eq_of_lt hgq] at hhg
      omega
  have hdvd : q ∣ h - g := hhg.symm.dvd'
  obtain ⟨n, hn⟩ := hdvd
  refine ⟨n, ?_⟩
  calc
    h = (h - g) + g := (Nat.sub_add_cancel hgh).symm
    _ = q * n + g := by rw [hn]
    _ = g + n * q := by ac_rfl

private lemma h1_dvd_add_reflectedResidue
    {q b : ℕ} (hq : 0 < q) :
    q ∣ b + reflectedResidue q b := by
  rw [Nat.dvd_iff_mod_eq_zero]
  unfold reflectedResidue
  rw [Nat.add_mod]
  by_cases hs : b % q = 0
  · simp [hs]
  · have hslt : b % q < q := Nat.mod_lt b hq
    have hsub_lt : q - b % q < q := by omega
    simp only [Nat.mod_eq_of_lt hsub_lt]
    have hsum : b % q + (q - b % q) = q := by omega
    rw [hsum, Nat.mod_self]

private lemma h1_reflected_compatibility
    {q a b h : ℕ} (hq : 0 < q)
    (hcompat : Nat.ModEq q (a + h) b) :
    Nat.ModEq q
      (reflectedResidue q b + h)
      (reflectedResidue q a) := by
  have hdbr : q ∣ b + reflectedResidue q b :=
    h1_dvd_add_reflectedResidue hq
  have hdar : q ∣ a + reflectedResidue q a :=
    h1_dvd_add_reflectedResidue hq
  have hbr0 : Nat.ModEq q (b + reflectedResidue q b) 0 :=
    Nat.modEq_zero_iff_dvd.mpr hdbr
  have har0 : Nat.ModEq q ((a + h) + reflectedResidue q b) 0 :=
    (hcompat.add_right (reflectedResidue q b)).trans hbr0
  have haa0 : Nat.ModEq q (a + reflectedResidue q a) 0 :=
    Nat.modEq_zero_iff_dvd.mpr hdar
  have hsum :
      Nat.ModEq q
        (a + (reflectedResidue q b + h))
        (a + reflectedResidue q a) := by
    have hraw := har0.trans haa0.symm
    simpa [Nat.add_assoc, Nat.add_comm, Nat.add_left_comm] using hraw
  exact Nat.ModEq.add_left_cancel' a hsum

def SourceNativeH1ControlAt (q : ℕ) : Prop :=
  0 < q →
  Squarefree q →
  ∀ ε : ℝ, 0 < ε →
    ∃ h0 : ℕ,
      ∀ a b h : ℕ,
        q.Coprime a →
        q.Coprime b →
        Nat.ModEq q (a + h) b →
        (¬ 2 ∣ q → 2 ∣ h) →
        0 < h →
        h0 ≤ h →
        |cStarReal q h * pureLeftFamily q a h -
            manuscriptS1Kernel q a h| ≤
          ε * Real.log (h : ℝ) ∧
        |cStarReal q h *
              pureLeftFamily q (reflectedResidue q b) h -
            manuscriptS1Kernel q (reflectedResidue q b) h| ≤
          ε * Real.log (h : ℝ)

theorem sourceNativeH1Control_fixedQ
    (q : ℕ) :
    SourceNativeH1ControlAt q := by
  intro hq hsq ε hε
  have homega := petermannOmegaR0002 q hq
  have hP : 0 < fixedQPeriod q := by
    unfold fixedQPeriod
    exact Nat.lcm_pos (by norm_num) hq
  letI : NeZero (fixedQPeriod q) := ⟨Nat.ne_of_gt hP⟩
  obtain ⟨H0, hbracket⟩ :=
    oneDimensionalBracket_sublog_of_r0002 q hq
      homega (petermannEtaR0002 q hq) ε hε
  refine ⟨2 * H0 + 4, ?_⟩
  intro a b h ha hb hcompat h2admissible hh hlarge
  have heven : 2 ∣ h :=
    h1_compatible_height_even ha hb hcompat h2admissible
  let H := h / 2
  have h2H : 2 * H = h := by
    dsimp [H]
    simpa [Nat.mul_comm] using Nat.div_mul_cancel heven
  have hH2 : 2 ≤ H := by
    omega
  have hH0 : H0 ≤ H := by
    omega
  obtain ⟨n, hn⟩ :=
    h1_compatible_height_progression hq hh hcompat
  have hgap :
      2 * H = positiveGapRepresentative q a b + n * q :=
    h2H.trans hn
  have hleftRaw :=
    hbracket a b H n ha hb hH0 hgap
  have hleftBridge :=
    source_family_floor_sub_bridge
      (q := q) (r := a) (H := H) hq ha hH2
  have hlog2 :
      Real.log (((H - 1 : ℕ) : ℝ)) ≤
        Real.log (((2 * H : ℕ) : ℝ)) := by
    apply Real.log_le_log
    · exact_mod_cast (show 0 < H - 1 by omega)
    · exact_mod_cast (show H - 1 ≤ 2 * H by omega)
  have hleft2 :
      |cStarReal q (2 * H) * pureLeftFamily q a (2 * H) -
          manuscriptS1Kernel q a (2 * H)| ≤
        ε * Real.log (((2 * H : ℕ) : ℝ)) := by
    rw [hleftBridge]
    exact hleftRaw.trans
      (mul_le_mul_of_nonneg_left hlog2 (le_of_lt hε))
  have hleft :
      |cStarReal q h * pureLeftFamily q a h -
          manuscriptS1Kernel q a h| ≤
        ε * Real.log (h : ℝ) := by
    simpa [h2H] using hleft2
  have hra : q.Coprime (reflectedResidue q a) :=
    coprime_reflectedResidue hq ha
  have hrb : q.Coprime (reflectedResidue q b) :=
    coprime_reflectedResidue hq hb
  have href :
      Nat.ModEq q
        (reflectedResidue q b + h)
        (reflectedResidue q a) :=
    h1_reflected_compatibility hq hcompat
  obtain ⟨nr, hnr⟩ :=
    h1_compatible_height_progression hq hh href
  have hgapr :
      2 * H =
        positiveGapRepresentative q
          (reflectedResidue q b) (reflectedResidue q a) +
          nr * q :=
    h2H.trans hnr
  have hrightRaw :=
    hbracket (reflectedResidue q b) (reflectedResidue q a)
      H nr hrb hra hH0 hgapr
  have hrightBridge :=
    source_family_floor_sub_bridge
      (q := q) (r := reflectedResidue q b) (H := H)
      hq hrb hH2
  have hright2 :
      |cStarReal q (2 * H) *
            pureLeftFamily q (reflectedResidue q b) (2 * H) -
          manuscriptS1Kernel q (reflectedResidue q b) (2 * H)| ≤
        ε * Real.log (((2 * H : ℕ) : ℝ)) := by
    rw [hrightBridge]
    exact hrightRaw.trans
      (mul_le_mul_of_nonneg_left hlog2 (le_of_lt hε))
  have hright :
      |cStarReal q h *
            pureLeftFamily q (reflectedResidue q b) h -
          manuscriptS1Kernel q (reflectedResidue q b) h| ≤
        ε * Real.log (h : ℝ) := by
    simpa [h2H] using hright2
  exact ⟨hleft, hright⟩

#print axioms sourceNativeH1Control_fixedQ

end PaperB.Admission
