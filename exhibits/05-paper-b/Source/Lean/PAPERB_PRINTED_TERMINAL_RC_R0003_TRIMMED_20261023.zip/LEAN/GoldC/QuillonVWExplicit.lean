import GoldC.QuillonVWInner
import GoldC.QuillonExplicit

/-!
# Quillon CSC3 F7.7d: explicit, `B`-monotone form of the class-restricted Vaughan bound

* `TIIx_mono`: `TIIx` is nondecreasing in `B` (for `1 ≤ B ≤ B'`).
* `castZero_mul_unit`: for `p | s` and a unit `u`, `cast(c·u) = 0 ↔ cast c = 0` in `ZMod p`.
  So `Kmax` and the Type II moduli are unchanged when `c` is multiplied by a unit.
* `vw_lambda_explicit`: for `V ≤ A ≤ B ≤ B'`,
  `‖Σ_{n∈(A,B]} Λ(n)·cphase ρ c n‖ ≤ VWB P c U V T Q B'`, an explicit majorant that is monotone in `B'`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset ArithmeticFunction

namespace GoldC.QuillonVWExplicit

open GoldC.QuillonVW GoldC.QuillonVWClass GoldC.QuillonVWSum GoldC.QuillonExplicit
  GoldC.QuillonPContext GoldC.QuillonPartition

variable {s : ℕ} [NeZero s]

lemma TIIx_mono (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (c : ZMod s) (U V T B B' : ℕ)
    (hU : 1 ≤ U) (hT : 1 ≤ T) (hB : 1 ≤ B) (hBB : B ≤ B') :
    TIIx P c U V T B ≤ TIIx P c U V T B' := by
  unfold TIIx
  have hBR : (1 : ℝ) ≤ B := by exact_mod_cast hB
  have hBBR : (B : ℝ) ≤ B' := by exact_mod_cast hBB
  have hg : (0 : ℝ) < ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ) := by
    have : 0 < ∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p :=
      Finset.prod_pos fun p hp => (hP p (filter_subset _ _ hp)).pos
    exact_mod_cast this
  have hUR : (0 : ℝ) < U := by exact_mod_cast (show 0 < U by omega)
  have hTR : (0 : ℝ) < T := by exact_mod_cast (show 0 < T by omega)
  have hlogB : 0 ≤ Real.log B := Real.log_natCast_nonneg B
  have hlogBB : Real.log B ≤ Real.log B' := Real.log_le_log (by linarith) hBBR
  have hl1 : 0 ≤ Real.log ((U : ℝ) + 2 * B) := Real.log_nonneg (by linarith)
  have hl2 : Real.log ((U : ℝ) + 2 * B) ≤ Real.log ((U : ℝ) + 2 * B') :=
    Real.log_le_log (by linarith) (by linarith)
  have hNl : ((Nat.log 2 B : ℕ) : ℝ) ≤ Nat.log 2 B' := by exact_mod_cast Nat.log_mono_right hBB
  gcongr

/-- In `ZMod p` with `p ∣ s`, multiplying by a unit of `ZMod s` does not change being zero. -/
lemma castZero_mul_unit (p : ℕ) (hps : p ∣ s) (c u : ZMod s) (hu : IsUnit u) :
    ((ZMod.cast (c * u) : ZMod p) = 0 ↔ (ZMod.cast c : ZMod p) = 0) := by
  have hcast : (ZMod.cast (c * u) : ZMod p) = (ZMod.cast c : ZMod p) * (ZMod.cast u : ZMod p) :=
    ZMod.cast_mul hps c u
  have hu' : IsUnit (ZMod.cast u : ZMod p) := by
    obtain ⟨v, hv⟩ := hu
    refine ⟨⟨ZMod.cast (v : ZMod s), ZMod.cast ((v⁻¹ : (ZMod s)ˣ) : ZMod s), ?_, ?_⟩, ?_⟩
    · rw [← ZMod.cast_mul hps, Units.mul_inv, ZMod.cast_one hps]
    · rw [← ZMod.cast_mul hps, Units.inv_mul, ZMod.cast_one hps]
    · simp [hv]
  rw [hcast]
  constructor
  · intro h; exact (hu'.mul_left_eq_zero).1 h
  · intro h; rw [h, zero_mul]

lemma filter_cast_mul_unit (P : Finset ℕ) (hsP : s = ∏ p ∈ P, p) (c u : ZMod s) (hu : IsUnit u) :
    P.filter (fun p => (ZMod.cast (c * u) : ZMod p) = 0) = P.filter (fun p => (ZMod.cast c : ZMod p) = 0) := by
  ext p
  simp only [mem_filter]
  constructor
  · rintro ⟨hp, h⟩
    exact ⟨hp, (castZero_mul_unit p (hsP ▸ dvd_prod_of_mem _ hp) c u hu).1 h⟩
  · rintro ⟨hp, h⟩
    exact ⟨hp, (castZero_mul_unit p (hsP ▸ dvd_prod_of_mem _ hp) c u hu).2 h⟩

lemma filter_cast_ne_mul_unit (P : Finset ℕ) (hsP : s = ∏ p ∈ P, p) (c u : ZMod s) (hu : IsUnit u) :
    P.filter (fun p => (ZMod.cast (c * u) : ZMod p) ≠ 0) = P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0) := by
  ext p
  simp only [mem_filter]
  constructor
  · rintro ⟨hp, h⟩
    exact ⟨hp, fun h' => h ((castZero_mul_unit p (hsP ▸ dvd_prod_of_mem _ hp) c u hu).2 h')⟩
  · rintro ⟨hp, h⟩
    exact ⟨hp, fun h' => h ((castZero_mul_unit p (hsP ▸ dvd_prod_of_mem _ hp) c u hu).1 h')⟩

lemma Kmax_mul_unit (P : Finset ℕ) (hsP : s = ∏ p ∈ P, p) (c u : ZMod s) (hu : IsUnit u) :
    Kmax P (c * u) = Kmax P c := by
  unfold Kmax; rw [filter_cast_mul_unit P hsP c u hu]

lemma TIIx_mul_unit (P : Finset ℕ) (hsP : s = ∏ p ∈ P, p) (c u : ZMod s) (hu : IsUnit u)
    (U V T B : ℕ) : TIIx P (c * u) U V T B = TIIx P c U V T B := by
  unfold TIIx; rw [filter_cast_ne_mul_unit P hsP c u hu]

/-- The explicit Vaughan majorant. -/
noncomputable def VWB (P : Finset ℕ) (c : ZMod s) (U V T Q B : ℕ) : ℝ :=
  Real.log B * (U + 2 * Kmax P c * (B * (1 + Real.log U) / (Q * s) + U * (1 + Real.log s))) +
    Real.log B * ((U * V : ℕ) + 2 * Kmax P c * (B * (1 + Real.log (U * V : ℕ)) / (Q * s) +
      (U * V : ℕ) * (1 + Real.log s))) +
    Q * TIIx P c U V T B

lemma VWB_mul_unit (P : Finset ℕ) (hsP : s = ∏ p ∈ P, p) (c u : ZMod s) (hu : IsUnit u)
    (U V T Q B : ℕ) : VWB P (c * u) U V T Q B = VWB P c U V T Q B := by
  unfold VWB; rw [Kmax_mul_unit P hsP c u hu, TIIx_mul_unit P hsP c u hu]

lemma VWB_nonneg (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (c : ZMod s) (U V T Q B : ℕ) (hU : 1 ≤ U)
    (hT : 1 ≤ T) : 0 ≤ VWB P c U V T Q B := by
  unfold VWB TIIx
  have hK := Kmax_nonneg P c
  have hg : (0 : ℝ) < ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ) := by
    have : 0 < ∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p :=
      Finset.prod_pos fun p hp => (hP p (filter_subset _ _ hp)).pos
    exact_mod_cast this
  have hUR : (1 : ℝ) ≤ U := by exact_mod_cast hU
  have h1 := Real.log_natCast_nonneg B
  have h2 := Real.log_natCast_nonneg U
  have h3 := Real.log_natCast_nonneg s
  have h4 := Real.log_natCast_nonneg (U * V)
  have h5 : 0 ≤ Real.log ((U : ℝ) + 2 * B) := Real.log_nonneg (by
    have : (0 : ℝ) ≤ B := Nat.cast_nonneg _
    linarith)
  positivity

section Q
variable {Q : ℕ} [NeZero Q]

theorem vw_lambda_explicit (hs2 : 2 ≤ s) (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime)
    (hsP : s = ∏ p ∈ P, p) (c : ZMod s) (ρ : ZMod Q) (hρ : IsUnit ρ) (hcop : Nat.Coprime Q s)
    (U V T A B B' : ℕ) (hVA : V ≤ A) (hAB : A ≤ B) (hBB : B ≤ B') (hB1 : 1 ≤ B) (hU : 2 ≤ U)
    (hT : 2 ≤ T) :
    ‖∑ n ∈ Ioc A B, ((vonMangoldt n : ℝ) : ℂ) * cphase ρ c n‖ ≤ VWB P c U V T Q B' := by
  have h := vw_lambda_class hs2 P hP hsP c ρ hρ hcop U V T A B hVA hAB hU hT
  have hTIIb : TIIb P c U V T B ≤ TIIx P c U V T B := TIIb_le_TIIx P hP c U V T B hU hT hB1
  have hU' : max U 2 = U := max_eq_left hU
  have hT' : max T 2 = T := max_eq_left hT
  have hTb : (Real.sqrt (2 * (1 + Real.log (tseq U T (Jstop U T V B (by omega) (by omega)))) ^ 4) *
        Real.sqrt (Real.log B ^ 2 * B * (Jstop U T V B (by omega) (by omega) : ℝ) *
          (2 * B / ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ) +
            2 * (tseq U T (Jstop U T V B (by omega) (by omega)) : ℝ) +
            s * B / (U * ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ)) +
            s)) +
      Real.log B * (1 + Real.log (tseq U T (Jstop U T V B (by omega) (by omega)))) ^ 4 *
        (2 * B / T + 2 * B / U + 2 * (tseq U T (Jstop U T V B (by omega) (by omega)) : ℝ))) =
      TIIb P c U V T B := by
    unfold TIIb
    congr 1 <;> simp only [hU', hT']
  rw [hTb] at h
  refine h.trans ?_
  unfold VWB
  have hBR : (B : ℝ) ≤ B' := by exact_mod_cast hBB
  have hB1R : (1 : ℝ) ≤ B := by exact_mod_cast hB1
  have hlog : Real.log B ≤ Real.log B' := Real.log_le_log (by linarith) hBR
  have hlog0 : 0 ≤ Real.log B := Real.log_natCast_nonneg B
  have hK := Kmax_nonneg P c
  have hQs : (0 : ℝ) < Q * s := by
    have : (0 : ℝ) < Q := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne Q)
    have : (0 : ℝ) < s := by exact_mod_cast (show 0 < s by omega)
    positivity
  have hlU := Real.log_natCast_nonneg U
  have hls := Real.log_natCast_nonneg s
  have hlUV := Real.log_natCast_nonneg (U * V)
  have hTx := TIIx_mono P hP c U V T B B' (by omega) (by omega) hB1 hBB
  have hQ0 : (0 : ℝ) ≤ Q := Nat.cast_nonneg _
  gcongr
  exact hTIIb.trans hTx

end Q

end GoldC.QuillonVWExplicit

#print axioms GoldC.QuillonVWExplicit.TIIx_mono
#print axioms GoldC.QuillonVWExplicit.VWB_mul_unit
#print axioms GoldC.QuillonVWExplicit.vw_lambda_explicit
