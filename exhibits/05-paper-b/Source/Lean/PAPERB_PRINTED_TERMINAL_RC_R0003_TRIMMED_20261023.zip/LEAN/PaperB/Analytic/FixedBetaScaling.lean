import PaperB.Analytic.FixedBetaOrder

namespace PaperB.Analytic

open Real

noncomputable def fixedBetaLambdaExponent (beta : ℝ) (k : ℕ) : ℝ :=
  beta⁻¹ - (k + 1 : ℝ)

lemma fixedBeta_first_scale_identity
    {W beta : ℝ} {k : ℕ}
    (hW : 0 < W) :
    W *
        (W ^ fixedBetaLambdaExponent beta k) ^
          (1 / ((2 : ℝ)^k - 2))
      =
    W ^ fixedBetaFirstExponent beta k := by
  rw [fixedBetaLambdaExponent, fixedBetaFirstExponent]
  have hinner :
      (W ^ (beta⁻¹ - (k + 1 : ℝ))) ^
          (1 / ((2 : ℝ)^k - 2))
        =
      W ^ ((beta⁻¹ - (k + 1 : ℝ)) *
          (1 / ((2 : ℝ)^k - 2))) := by
    rw [← Real.rpow_mul hW.le]
  rw [hinner]
  calc
    W * W ^ ((beta⁻¹ - (k + 1 : ℝ)) *
        (1 / ((2 : ℝ)^k - 2)))
      = W ^ (1 : ℝ) * W ^ ((beta⁻¹ - (k + 1 : ℝ)) *
          (1 / ((2 : ℝ)^k - 2))) := by
        rw [Real.rpow_one]
    _ = W ^ ((1 : ℝ) + ((beta⁻¹ - (k + 1 : ℝ)) *
          (1 / ((2 : ℝ)^k - 2)))) := by
      rw [Real.rpow_add hW]
    _ = W ^ (1 + (beta⁻¹ - (k + 1 : ℝ)) /
          ((2 : ℝ)^k - 2)) := by
      congr 1
      ring

lemma fixedBeta_second_scale_identity
    {W beta : ℝ} {k : ℕ}
    (hW : 0 < W) :
    W ^ (1 - 4 / (2 : ℝ)^k) *
        (W ^ fixedBetaLambdaExponent beta k) ^
          (-(1 / ((2 : ℝ)^k - 2)))
      =
    W ^ fixedBetaSecondExponent beta k := by
  rw [fixedBetaLambdaExponent, fixedBetaSecondExponent]
  rw [← Real.rpow_mul hW.le]
  rw [← Real.rpow_add hW]
  congr 1
  ring

theorem fixedBeta_source_scale_pair
    {W beta : ℝ} {k : ℕ}
    (hW : 0 < W) :
    W *
        (W ^ fixedBetaLambdaExponent beta k) ^
          (1 / ((2 : ℝ)^k - 2))
        =
        W ^ fixedBetaFirstExponent beta k
    ∧
    W ^ (1 - 4 / (2 : ℝ)^k) *
        (W ^ fixedBetaLambdaExponent beta k) ^
          (-(1 / ((2 : ℝ)^k - 2)))
        =
        W ^ fixedBetaSecondExponent beta k :=
  ⟨fixedBeta_first_scale_identity hW,
    fixedBeta_second_scale_identity hW⟩

#print axioms fixedBeta_first_scale_identity
#print axioms fixedBeta_second_scale_identity
#print axioms fixedBeta_source_scale_pair

end PaperB.Analytic
