import PaperB.Analytic.SawtoothBridge
import PaperB.FixedQ.OmegaLinearMean
import PaperB.FixedQ.OmegaReciprocalTail

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset

theorem omega_sawtooth_smoothing_away_error_le
    {S : ℝ} (hS : 1 < S) {H : ℕ} (hH : 1 ≤ H)
    (q X : ℕ) (xi T : ℝ) (r : ℤ)
    (haway : ∀ e ∈ Finset.Icc 1 X,
      sawSmoothHalfWidth S <
        Int.fract
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) ∧
      Int.fract
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) ≤
        1 - sawSmoothHalfWidth S) :
    ‖∑ e ∈ Finset.Icc 1 X,
        (omegaCoeff q e : ℂ) * eR (xi * (e : ℝ)) *
          ((petermannSawtooth
              (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
                (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
            sawSmoothPartial S H
              ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
                (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
                AddCircle (1 : ℝ)))‖
      ≤ (S / (Real.pi ^ 2 * H)) * omegaPartialSum q X := by
  calc
    ‖∑ e ∈ Finset.Icc 1 X,
        (omegaCoeff q e : ℂ) * eR (xi * (e : ℝ)) *
          ((petermannSawtooth
              (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
                (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
            sawSmoothPartial S H
              ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
                (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
                AddCircle (1 : ℝ)))‖
      ≤ ∑ e ∈ Finset.Icc 1 X,
          ‖(omegaCoeff q e : ℂ) * eR (xi * (e : ℝ)) *
            ((petermannSawtooth
                (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
                  (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
              sawSmoothPartial S H
                ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
                  (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
                  AddCircle (1 : ℝ)))‖ := norm_sum_le _ _
    _ ≤ ∑ e ∈ Finset.Icc 1 X,
          omegaCoeff q e * (S / (Real.pi ^ 2 * H)) := by
      apply Finset.sum_le_sum
      intro e he
      have herr := petermannSawtooth_partial_error_le hS hH
        (haway e he).1 (haway e he).2
      rw [norm_mul, norm_mul, norm_eR, mul_one, Complex.norm_real,
        Real.norm_eq_abs, abs_of_nonneg (omegaCoeff_nonneg q e)]
      exact mul_le_mul_of_nonneg_left herr (omegaCoeff_nonneg q e)
    _ = (S / (Real.pi ^ 2 * H)) * omegaPartialSum q X := by
      unfold omegaPartialSum
      rw [← Finset.sum_mul]
      ring

#print axioms omega_sawtooth_smoothing_away_error_le

end PaperB.Analytic
