import PaperB.Analytic.PetermannOmegaKernelSplit
import PaperB.Analytic.PetermannOmegaAwayError
import PaperB.Analytic.SawtoothTruncation
import PaperB.FixedQ.OmegaReciprocalTail

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset

noncomputable def petermannOmegaAwayFromJump
    (q : ℕ) (T : ℝ) (r : ℤ) (S : ℝ) (e : ℕ) : Prop :=
  sawSmoothHalfWidth S <
      Int.fract
        (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
          (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) ∧
    Int.fract
        (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
          (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) ≤
      1 - sawSmoothHalfWidth S

noncomputable def petermannOmegaNearJumpMass
    (q : ℕ) (T : ℝ) (r : ℤ) (X : ℕ) (S : ℝ) : ℝ := by
  classical
  exact
    ∑ e ∈ (Finset.Icc 1 X).filter
        (fun e => ¬ petermannOmegaAwayFromJump q T r S e),
      omegaCoeff q e

noncomputable def sawSmoothPartialNormBound
    (S : ℝ) (H : ℕ) : ℝ :=
  ‖sawSmoothCoeff S 0‖ +
    ∑ k ∈ Finset.range H,
      (‖sawSmoothCoeff S (k + 1 : ℕ)‖ +
        ‖sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ))‖)

lemma sawSmoothPartialNormBound_nonneg
    (S : ℝ) (H : ℕ) :
    0 ≤ sawSmoothPartialNormBound S H := by
  unfold sawSmoothPartialNormBound
  positivity

lemma norm_sawSmoothPair_le_coeffs
    (S : ℝ) (k : ℕ) (x : AddCircle (1 : ℝ)) :
    ‖sawSmoothPair S k x‖ ≤
      ‖sawSmoothCoeff S (k + 1 : ℕ)‖ +
        ‖sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ))‖ := by
  unfold sawSmoothPair
  calc
    ‖sawSmoothMode S (k + 1 : ℕ) x +
        sawSmoothMode S (-((k + 1 : ℕ) : ℤ)) x‖
      ≤ ‖sawSmoothMode S (k + 1 : ℕ) x‖ +
          ‖sawSmoothMode S (-((k + 1 : ℕ) : ℤ)) x‖ := norm_add_le _ _
    _ = ‖sawSmoothCoeff S (k + 1 : ℕ)‖ +
        ‖sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ))‖ := by
      rw [norm_sawSmoothMode, norm_sawSmoothMode]

lemma norm_sawSmoothPartial_le
    (S : ℝ) (H : ℕ) (x : AddCircle (1 : ℝ)) :
    ‖sawSmoothPartial S H x‖ ≤ sawSmoothPartialNormBound S H := by
  unfold sawSmoothPartial sawSmoothPartialNormBound
  calc
    ‖sawSmoothMode S 0 x +
        ∑ k ∈ Finset.range H, sawSmoothPair S k x‖
      ≤ ‖sawSmoothMode S 0 x‖ +
          ‖∑ k ∈ Finset.range H, sawSmoothPair S k x‖ := norm_add_le _ _
    _ ≤ ‖sawSmoothCoeff S 0‖ +
          ∑ k ∈ Finset.range H, ‖sawSmoothPair S k x‖ := by
      rw [norm_sawSmoothMode]
      gcongr
      exact norm_sum_le _ _
    _ ≤ ‖sawSmoothCoeff S 0‖ +
          ∑ k ∈ Finset.range H,
            (‖sawSmoothCoeff S (k + 1 : ℕ)‖ +
              ‖sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ))‖) := by
      gcongr with k hk
      exact norm_sawSmoothPair_le_coeffs S k x

lemma omega_smoothing_point_norm_le_near_const
    (q : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (T S : ℝ) (r : ℤ) (H e : ℕ) :
    ‖(chi e) * (omegaCoeff q e : ℂ) *
      ((petermannSawtooth
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
        sawSmoothPartial S H
          ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
            AddCircle (1 : ℝ)))‖
      ≤ omegaCoeff q e * (1 / 2 + sawSmoothPartialNormBound S H) := by
  have hchi := norm_dirichletCharacter_nat_le_one (q := q) (e := e) chi
  have homega := omegaCoeff_nonneg q e
  have hsaw := abs_petermannSawtooth_le_half
    (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
      (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))
  have hsmooth := norm_sawSmoothPartial_le S H
    ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
      (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
      AddCircle (1 : ℝ))
  rw [norm_mul, norm_mul, Complex.norm_real,
    Real.norm_eq_abs, abs_of_nonneg homega]
  have hdiff :
      ‖((petermannSawtooth
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
        sawSmoothPartial S H
          ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
            AddCircle (1 : ℝ)))‖
        ≤ 1 / 2 + sawSmoothPartialNormBound S H := by
    calc
      ‖((petermannSawtooth
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
        sawSmoothPartial S H
          ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
            AddCircle (1 : ℝ)))‖
        ≤ ‖(petermannSawtooth
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ)‖ +
          ‖sawSmoothPartial S H
            ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
              (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
              AddCircle (1 : ℝ))‖ := norm_sub_le _ _
      _ ≤ 1 / 2 + sawSmoothPartialNormBound S H := by
        rw [Complex.norm_real, Real.norm_eq_abs]
        exact add_le_add hsaw hsmooth
  have hnonneg : 0 ≤ 1 / 2 + sawSmoothPartialNormBound S H := by
    have := sawSmoothPartialNormBound_nonneg S H
    positivity
  calc
    ‖chi (e : ZMod (Nat.lcm 6 q))‖ * omegaCoeff q e *
        ‖((petermannSawtooth
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
          sawSmoothPartial S H
            ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
              (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
              AddCircle (1 : ℝ)))‖
      ≤ 1 * omegaCoeff q e *
          (1 / 2 + sawSmoothPartialNormBound S H) := by
        gcongr
    _ = omegaCoeff q e *
          (1 / 2 + sawSmoothPartialNormBound S H) := by ring

theorem petermannOmegaSmoothingRemainder_le_away_add_near
    {S : ℝ} (hS : 1 < S) {H : ℕ} (hH : 1 ≤ H)
    (q X : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (T : ℝ) :
    ‖petermannOmegaSmoothingRemainder q chi r T X H S‖
      ≤
    (S / (Real.pi ^ 2 * H)) * omegaPartialSum q X +
      (1 / 2 + sawSmoothPartialNormBound S H) *
        petermannOmegaNearJumpMass q T r X S := by
  classical
  let E := Finset.Icc 1 X
  let away : ℕ → Prop := fun e => petermannOmegaAwayFromJump q T r S e
  let f : ℕ → ℂ := fun e =>
    (chi e) * (omegaCoeff q e : ℂ) *
      ((petermannSawtooth
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
        sawSmoothPartial S H
          ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
            AddCircle (1 : ℝ)))
  unfold petermannOmegaSmoothingRemainder
  change ‖∑ e ∈ E, f e‖ ≤ _
  rw [← Finset.sum_filter_add_sum_filter_not E away f]
  calc
    ‖(∑ e ∈ E.filter away, f e) +
        (∑ e ∈ E.filter (fun e => ¬ away e), f e)‖
      ≤ ‖∑ e ∈ E.filter away, f e‖ +
          ‖∑ e ∈ E.filter (fun e => ¬ away e), f e‖ := norm_add_le _ _
    _ ≤
      (S / (Real.pi ^ 2 * H)) *
          (∑ e ∈ E.filter away, omegaCoeff q e) +
        (1 / 2 + sawSmoothPartialNormBound S H) *
          (∑ e ∈ E.filter (fun e => ¬ away e), omegaCoeff q e) := by
      apply add_le_add
      · calc
          ‖∑ e ∈ E.filter away, f e‖
            ≤ ∑ e ∈ E.filter away, ‖f e‖ := norm_sum_le _ _
          _ ≤ ∑ e ∈ E.filter away,
              omegaCoeff q e * (S / (Real.pi ^ 2 * H)) := by
            apply Finset.sum_le_sum
            intro e he
            have heAway : away e := (Finset.mem_filter.mp he).2
            have herr := petermannSawtooth_partial_error_le hS hH
              heAway.1 heAway.2
            dsimp [f]
            rw [norm_mul, norm_mul, Complex.norm_real,
              Real.norm_eq_abs, abs_of_nonneg (omegaCoeff_nonneg q e)]
            have hchi := norm_dirichletCharacter_nat_le_one (q := q) (e := e) chi
            have homega : 0 ≤ omegaCoeff q e := omegaCoeff_nonneg q e
            have hR : 0 ≤ S / (Real.pi ^ 2 * H) := by positivity
            calc
              ‖chi (e : ZMod (Nat.lcm 6 q))‖ * omegaCoeff q e *
                  ‖((petermannSawtooth
                    (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
                      (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
                    sawSmoothPartial S H
                      ((T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
                        (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
                        AddCircle (1 : ℝ)))‖
                ≤ 1 * omegaCoeff q e * (S / (Real.pi ^ 2 * H)) := by
                  gcongr
              _ = omegaCoeff q e * (S / (Real.pi ^ 2 * H)) := by ring
          _ = (S / (Real.pi ^ 2 * H)) *
              (∑ e ∈ E.filter away, omegaCoeff q e) := by
            rw [Finset.mul_sum]
            apply Finset.sum_congr rfl
            intro e he
            ring
      · calc
          ‖∑ e ∈ E.filter (fun e => ¬ away e), f e‖
            ≤ ∑ e ∈ E.filter (fun e => ¬ away e), ‖f e‖ := norm_sum_le _ _
          _ ≤ ∑ e ∈ E.filter (fun e => ¬ away e),
              omegaCoeff q e *
                (1 / 2 + sawSmoothPartialNormBound S H) := by
            apply Finset.sum_le_sum
            intro e he
            exact omega_smoothing_point_norm_le_near_const q chi T S r H e
          _ = (1 / 2 + sawSmoothPartialNormBound S H) *
              (∑ e ∈ E.filter (fun e => ¬ away e), omegaCoeff q e) := by
            rw [Finset.mul_sum]
            apply Finset.sum_congr rfl
            intro e he
            ring
    _ ≤
      (S / (Real.pi ^ 2 * H)) * omegaPartialSum q X +
        (1 / 2 + sawSmoothPartialNormBound S H) *
          petermannOmegaNearJumpMass q T r X S := by
      have hAwaySum :
          (∑ e ∈ E.filter away, omegaCoeff q e) ≤ omegaPartialSum q X := by
        unfold omegaPartialSum E
        exact Finset.sum_le_sum_of_subset_of_nonneg
          (Finset.filter_subset _ _)
          (fun e he hnot => omegaCoeff_nonneg q e)
      have hfac : 0 ≤ S / (Real.pi ^ 2 * H) := by positivity
      have hnearEq :
          (∑ e ∈ E.filter (fun e => ¬ away e), omegaCoeff q e) =
            petermannOmegaNearJumpMass q T r X S := by
        rfl
      rw [hnearEq]
      gcongr

#print axioms petermannOmegaSmoothingRemainder_le_away_add_near

end PaperB.Analytic
