import PaperB.FixedQ.PetermannCorrectionMoment
import Mathlib.NumberTheory.DirichletCharacter.Bounds

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def petermannBaseKernelSum
    (q : ℕ) (base : PetermannBase)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (T : ℝ) (X : ℕ) : ℂ :=
  ∑ e ∈ Finset.Icc 1 X,
    (chi e) *
    (petermannBaseCoeff q base e : ℂ) *
    (petermannSawtooth
      (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ)
        + (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ)

def PetermannMinimalConsumerR0002Spec
    (q : ℕ) (base : PetermannBase) : Prop :=
  ∀ ε : ℝ, 0 < ε →
    ∃ T0 : ℝ, ∀
      (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
      (r : ℤ) (T : ℝ) (X : ℕ),
      T0 ≤ T →
      (2 * (Nat.lcm 6 q) : ℝ) ≤ T →
      1 ≤ X →
      (X : ℝ) ≤ T →
      ‖petermannBaseKernelSum q base chi r T X‖
        ≤ ε * Real.log T

noncomputable def petermannMovingKernelSum
    (q h : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (T : ℝ) (X : ℕ) : ℂ :=
  ∑ e ∈ Finset.Icc 1 X,
    (chi e) *
    (movingVCoeff q h e : ℂ) *
    (petermannSawtooth
      (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ)
        + (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ)

lemma abs_petermannSawtooth_le_half (x : ℝ) :
    |petermannSawtooth x| ≤ 1 / 2 := by
  unfold petermannSawtooth
  rw [abs_le]
  constructor
  · have hf := Int.floor_le x
    linarith
  · have hf := Int.lt_floor_add_one x
    linarith

lemma norm_dirichletCharacter_nat_le_one
    {q e : ℕ}
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q)) :
    ‖chi e‖ ≤ 1 := by
  simpa using chi.norm_le_one (e : ZMod (Nat.lcm 6 q))

#print axioms abs_petermannSawtooth_le_half
#print axioms norm_dirichletCharacter_nat_le_one

end PaperB.FixedQ

namespace PaperB.FixedQ

def petermannTriPairs (X : ℕ) : Finset (ℕ × ℕ) :=
  ((Finset.Icc 1 X).product (Finset.Icc 1 X)).filter
    (fun sd => sd.1 * sd.2 ≤ X)

def petermannDivisorSigma (X : ℕ) :
    Finset (Σ _n : ℕ, ℕ × ℕ) :=
  (Finset.Icc 1 X).sigma (fun n => n.divisorsAntidiagonal)

theorem sum_petermannDivisorSigma_eq_triPairs
    {M : Type*} [AddCommMonoid M]
    (X : ℕ) (F : ℕ → ℕ → M) :
    (∑ x ∈ petermannDivisorSigma X, F x.2.2 x.2.1) =
      ∑ sd ∈ petermannTriPairs X, F sd.1 sd.2 := by
  classical
  refine Finset.sum_bij'
    (fun x _ => (x.2.2, x.2.1))
    (fun sd _ => ⟨sd.1 * sd.2, (sd.2, sd.1)⟩)
    ?_ ?_ ?_ ?_ ?_
  · intro x hx
    rw [petermannDivisorSigma, Finset.mem_sigma] at hx
    rcases hx with ⟨hn, hp⟩
    rw [Finset.mem_Icc] at hn
    have hmul : x.2.1 * x.2.2 = x.1 :=
      (Nat.prodMk_mem_divisorsAntidiag (by omega)).mp hp
    have hd0 : x.2.1 ≠ 0 := by
      intro hd
      rw [hd, zero_mul] at hmul
      omega
    have hs0 : x.2.2 ≠ 0 := by
      intro hs
      rw [hs, mul_zero] at hmul
      omega
    have hd1 : 1 ≤ x.2.1 := Nat.one_le_iff_ne_zero.mpr hd0
    have hs1 : 1 ≤ x.2.2 := Nat.one_le_iff_ne_zero.mpr hs0
    have hdX : x.2.1 ≤ X := by
      calc
        x.2.1 ≤ x.2.1 * x.2.2 := Nat.le_mul_of_pos_right _ hs1
        _ = x.1 := hmul
        _ ≤ X := hn.2
    have hsX : x.2.2 ≤ X := by
      calc
        x.2.2 ≤ x.2.2 * x.2.1 := Nat.le_mul_of_pos_right _ hd1
        _ = x.2.1 * x.2.2 := by ac_rfl
        _ = x.1 := hmul
        _ ≤ X := hn.2
    rw [petermannTriPairs, Finset.mem_filter]
    constructor
    · exact Finset.mem_product.mpr
        ⟨Finset.mem_Icc.mpr ⟨hs1, hsX⟩,
          Finset.mem_Icc.mpr ⟨hd1, hdX⟩⟩
    · simpa [mul_comm] using hmul.le.trans hn.2
  · intro sd hsd
    rw [petermannTriPairs, Finset.mem_filter] at hsd
    rcases hsd with ⟨hprod, hmul⟩
    have hparts := Finset.mem_product.mp hprod
    have hs := Finset.mem_Icc.mp hparts.1
    have hd := Finset.mem_Icc.mp hparts.2
    rw [petermannDivisorSigma, Finset.mem_sigma]
    refine ⟨?_, ?_⟩
    · rw [Finset.mem_Icc]
      exact ⟨Nat.one_le_iff_ne_zero.mpr
        (mul_ne_zero (by omega) (by omega)), hmul⟩
    · apply (Nat.prodMk_mem_divisorsAntidiag
        (mul_ne_zero (by omega) (by omega))).mpr
      simp [mul_comm]
  · intro x hx
    rw [petermannDivisorSigma, Finset.mem_sigma] at hx
    have hmul : x.2.1 * x.2.2 = x.1 :=
      (Nat.prodMk_mem_divisorsAntidiag
        (by
          rw [Finset.mem_Icc] at hx
          omega)).mp hx.2
    apply Sigma.ext
    · simpa [mul_comm] using hmul
    · simp
  · intro sd hsd
    rfl
  · intro x hx
    rfl

#print axioms sum_petermannDivisorSigma_eq_triPairs

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma filter_Icc_mul_le_eq_Icc_div
    (X s : ℕ) (hs : s ∈ Finset.Icc 1 X) :
    (Finset.Icc 1 X).filter (fun d => s * d ≤ X) =
      Finset.Icc 1 (X / s) := by
  ext d
  rw [Finset.mem_filter]
  rw [Finset.mem_Icc, Finset.mem_Icc]
  have hs1 : 0 < s := by
    exact lt_of_lt_of_le Nat.zero_lt_one (Finset.mem_Icc.mp hs).1
  constructor
  · rintro ⟨⟨hd1, hdX⟩, hmul⟩
    exact ⟨hd1, (Nat.le_div_iff_mul_le hs1).2
      (by simpa [mul_comm] using hmul)⟩
  · rintro ⟨hd1, hddiv⟩
    have hmul' := (Nat.le_div_iff_mul_le hs1).1 hddiv
    have hmul : s * d ≤ X := by simpa [mul_comm] using hmul'
    have hspos : 1 ≤ s := (Finset.mem_Icc.mp hs).1
    have hdX : d ≤ X := by
      calc
        d ≤ s * d := Nat.le_mul_of_pos_left d hspos
        _ ≤ X := hmul
    exact ⟨⟨hd1, hdX⟩, hmul⟩

theorem sum_petermannTriPairs_eq_nested
    {M : Type*} [AddCommMonoid M]
    (X : ℕ) (F : ℕ → ℕ → M) :
    (∑ sd ∈ petermannTriPairs X, F sd.1 sd.2) =
      ∑ s ∈ Finset.Icc 1 X,
        ∑ d ∈ Finset.Icc 1 (X / s), F s d := by
  classical
  rw [petermannTriPairs, Finset.sum_filter]
  calc
    (∑ a ∈ (Finset.Icc 1 X).product (Finset.Icc 1 X),
        if a.1 * a.2 ≤ X then F a.1 a.2 else 0)
      = ∑ s ∈ Finset.Icc 1 X,
          ∑ d ∈ Finset.Icc 1 X,
            if s * d ≤ X then F s d else 0 := by
        simpa using
          (Finset.sum_product' (Finset.Icc 1 X) (Finset.Icc 1 X)
            (fun s d => if s * d ≤ X then F s d else 0))
    _ = ∑ s ∈ Finset.Icc 1 X,
          ∑ d ∈ Finset.Icc 1 (X / s), F s d := by
        apply Finset.sum_congr rfl
        intro s hs
        rw [← Finset.sum_filter]
        rw [filter_Icc_mul_le_eq_Icc_div X s hs]

theorem sum_petermannDivisorSigma_eq_nested
    {M : Type*} [AddCommMonoid M]
    (X : ℕ) (F : ℕ → ℕ → M) :
    (∑ x ∈ petermannDivisorSigma X, F x.2.2 x.2.1) =
      ∑ s ∈ Finset.Icc 1 X,
        ∑ d ∈ Finset.Icc 1 (X / s), F s d := by
  rw [sum_petermannDivisorSigma_eq_triPairs,
    sum_petermannTriPairs_eq_nested]

#print axioms filter_Icc_mul_le_eq_Icc_div
#print axioms sum_petermannTriPairs_eq_nested
#print axioms sum_petermannDivisorSigma_eq_nested

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem petermannMovingKernelSum_eq_correction_sum
    (q h : ℕ) (hq : 0 < q)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (T : ℝ) (X : ℕ) :
    petermannMovingKernelSum q h chi r T X =
      ∑ s ∈ Finset.Icc 1 X,
        (chi s) *
        (petermannCorrectionArithmetic q h s : ℂ) *
        petermannBaseKernelSum q PetermannBase.omega chi r
          (T / s) (X / s) := by
  classical
  unfold petermannMovingKernelSum
  have hperiod : (Nat.lcm 6 q : ℝ) ≠ 0 := by
    have hq0 : q ≠ 0 := Nat.ne_of_gt hq
    have hlcm : Nat.lcm 6 q ≠ 0 := by
      simp [Nat.lcm_eq_zero_iff, hq0]
    exact_mod_cast hlcm
  calc
    (∑ e ∈ Finset.Icc 1 X,
      (chi e) * (movingVCoeff q h e : ℂ) *
        (petermannSawtooth
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ)
            + (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ))
      = ∑ e ∈ Finset.Icc 1 X,
          (chi e) *
          ((movingVArithmetic q h e : ℝ) : ℂ) *
          (petermannSawtooth
            (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ)
              + (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) := by
          apply Finset.sum_congr rfl
          intro e he
          rw [movingVArithmetic_apply]
    _ = ∑ e ∈ Finset.Icc 1 X,
          ∑ ds ∈ e.divisorsAntidiagonal,
            (chi e) *
            (((omegaArithmetic q ds.1 : ℝ) *
              petermannCorrectionArithmetic q h ds.2 : ℝ) : ℂ) *
            (petermannSawtooth
              (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ)
                + (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) := by
          apply Finset.sum_congr rfl
          intro e he
          rw [movingVArithmetic_eq_omega_mul_petermannCorrection]
          rw [ArithmeticFunction.mul_apply]
          push_cast
          rw [Finset.mul_sum, Finset.sum_mul]
    _ = ∑ x ∈ petermannDivisorSigma X,
          (chi x.1) *
          (((omegaArithmetic q x.2.1 : ℝ) *
            petermannCorrectionArithmetic q h x.2.2 : ℝ) : ℂ) *
          (petermannSawtooth
            (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (x.1 : ℝ)
              + (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) := by
          rw [petermannDivisorSigma, Finset.sum_sigma']
    _ = ∑ x ∈ petermannDivisorSigma X,
          ((chi (x.2.2 * x.2.1)) *
          (((omegaArithmetic q x.2.1 : ℝ) *
            petermannCorrectionArithmetic q h x.2.2 : ℝ) : ℂ) *
          (petermannSawtooth
            (T / ((Nat.lcm 6 q : ℕ) : ℝ) /
                ((x.2.2 * x.2.1 : ℕ) : ℝ)
              + (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ)) := by
          apply Finset.sum_congr rfl
          intro x hx
          rw [petermannDivisorSigma, Finset.mem_sigma] at hx
          have hmul : x.2.1 * x.2.2 = x.1 :=
            (Nat.prodMk_mem_divisorsAntidiag
              (by
                rw [Finset.mem_Icc] at hx
                omega)).mp hx.2
          have hmul' : x.2.2 * x.2.1 = x.1 := by
            simpa [mul_comm] using hmul
          rw [← hmul']
          simp [Nat.cast_mul]
    _ = ∑ s ∈ Finset.Icc 1 X,
          ∑ d ∈ Finset.Icc 1 (X / s),
            (chi (s * d)) *
            (((omegaArithmetic q d : ℝ) *
              petermannCorrectionArithmetic q h s : ℝ) : ℂ) *
            (petermannSawtooth
              (T / ((Nat.lcm 6 q : ℕ) : ℝ) /
                  ((s * d : ℕ) : ℝ)
                + (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) := by
          exact sum_petermannDivisorSigma_eq_nested X
            (fun s d =>
              (chi (s * d)) *
              (((omegaArithmetic q d : ℝ) *
                petermannCorrectionArithmetic q h s : ℝ) : ℂ) *
              (petermannSawtooth
                (T / ((Nat.lcm 6 q : ℕ) : ℝ) /
                    ((s * d : ℕ) : ℝ)
                  + (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ))
    _ = ∑ s ∈ Finset.Icc 1 X,
          (chi s) *
          (petermannCorrectionArithmetic q h s : ℂ) *
          petermannBaseKernelSum q PetermannBase.omega chi r
            (T / s) (X / s) := by
          apply Finset.sum_congr rfl
          intro s hs
          unfold petermannBaseKernelSum
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro d hd
          rw [map_mul]
          rw [omegaArithmetic_apply]
          simp only [petermannBaseCoeff]
          have hs0 : (s : ℝ) ≠ 0 := by
            have : 1 ≤ s := (Finset.mem_Icc.mp hs).1
            positivity
          have hd0 : (d : ℝ) ≠ 0 := by
            have : 1 ≤ d := (Finset.mem_Icc.mp hd).1
            positivity
          have hsaw :
              petermannSawtooth
                (T / ((Nat.lcm 6 q : ℕ) : ℝ) /
                    ((s * d : ℕ) : ℝ)
                  + (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) =
              petermannSawtooth
                ((T / (s : ℝ)) / ((Nat.lcm 6 q : ℕ) : ℝ) / (d : ℝ)
                  + (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) := by
            congr 1
            push_cast
            field_simp [hs0, hd0, hperiod]
          rw [hsaw]
          push_cast
          ring

#print axioms petermannMovingKernelSum_eq_correction_sum

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def petermannOmegaFiniteMass
    (q N : ℕ) : ℝ :=
  ∑ e ∈ Finset.Icc 1 N, |omegaCoeff q e|

lemma petermannOmegaFiniteMass_nonneg (q N : ℕ) :
    0 ≤ petermannOmegaFiniteMass q N := by
  unfold petermannOmegaFiniteMass
  exact Finset.sum_nonneg (fun _ _ => abs_nonneg _)

lemma norm_petermannOmegaKernel_term_le_abs
    (q : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (T : ℝ) (e : ℕ) :
    ‖(chi e) * (omegaCoeff q e : ℂ) *
        (petermannSawtooth
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ)
            + (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ)‖
      ≤ |omegaCoeff q e| := by
  have hchi := norm_dirichletCharacter_nat_le_one (q := q) (e := e) chi
  have hsaw := abs_petermannSawtooth_le_half
    (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ)
      + (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))
  have hsaw1 :
      |petermannSawtooth
        (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ)
          + (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))| ≤ 1 := by
    linarith
  simp only [norm_mul, Complex.norm_real, Real.norm_eq_abs]
  calc
    ‖chi e‖ * |omegaCoeff q e| *
        |petermannSawtooth
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ)
            + (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))|
      ≤ 1 * |omegaCoeff q e| * 1 := by
        gcongr
    _ = |omegaCoeff q e| := by ring

theorem norm_petermannBaseKernelSum_omega_le_finiteMass
    (q N : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (T : ℝ) (Y : ℕ)
    (hYN : Y ≤ N) :
    ‖petermannBaseKernelSum q PetermannBase.omega chi r T Y‖
      ≤ petermannOmegaFiniteMass q N := by
  unfold petermannBaseKernelSum
  calc
    ‖∑ e ∈ Finset.Icc 1 Y,
        (chi e) *
        (petermannBaseCoeff q PetermannBase.omega e : ℂ) *
        (petermannSawtooth
          (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ)
            + (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ)‖
      ≤ ∑ e ∈ Finset.Icc 1 Y,
          ‖(chi e) * (omegaCoeff q e : ℂ) *
            (petermannSawtooth
              (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ)
                + (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ)‖ := by
          simpa only [petermannBaseCoeff] using
            norm_sum_le (Finset.Icc 1 Y)
              (fun e =>
                (chi e) * (omegaCoeff q e : ℂ) *
                  (petermannSawtooth
                    (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ)
                      + (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ))
    _ ≤ ∑ e ∈ Finset.Icc 1 Y, |omegaCoeff q e| := by
          exact Finset.sum_le_sum (fun e he =>
            norm_petermannOmegaKernel_term_le_abs q chi r T e)
    _ ≤ ∑ e ∈ Finset.Icc 1 N, |omegaCoeff q e| := by
          apply Finset.sum_le_sum_of_subset_of_nonneg
          · intro e he
            rw [Finset.mem_Icc] at he ⊢
            exact ⟨he.1, he.2.trans hYN⟩
          · intro e heN heY
            exact abs_nonneg _
    _ = petermannOmegaFiniteMass q N := rfl

#print axioms norm_petermannOmegaKernel_term_le_abs
#print axioms norm_petermannBaseKernelSum_omega_le_finiteMass

end PaperB.FixedQ

namespace PaperB.FixedQ

def PetermannMovingSublogSpec (q : ℕ) : Prop :=
  ∀ ε : ℝ, 0 < ε →
    ∃ T0 : ℝ, ∀
      (h : ℕ), h ≠ 0 →
      ∀ (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
      (r : ℤ) (T : ℝ) (X : ℕ),
      T0 ≤ T →
      (2 * (Nat.lcm 6 q) : ℝ) ≤ T →
      1 ≤ X →
      (X : ℝ) ≤ T →
      ‖petermannMovingKernelSum q h chi r T X‖
        ≤ ε * Real.log T

lemma petermannCorrectionL1Finite_le
    (q h X : ℕ) (hh : h ≠ 0) :
    (∑ s ∈ Finset.Icc 1 X,
      |petermannCorrectionArithmetic q h s|) ≤
      petermannCorrectionL1UniformBound := by
  calc
    (∑ s ∈ Finset.Icc 1 X,
      |petermannCorrectionArithmetic q h s|)
      ≤ ∑' s : ℕ, |petermannCorrectionArithmetic q h s| := by
        exact (summable_abs_petermannCorrectionArithmetic q h hh).sum_le_tsum
          (Finset.Icc 1 X) (fun s hs => abs_nonneg _)
    _ ≤ petermannCorrectionL1UniformBound :=
      petermannCorrectionL1_uniform_le q h hh

lemma petermannCorrectionL1UniformBound_nonneg :
    0 ≤ petermannCorrectionL1UniformBound := by
  unfold petermannCorrectionL1UniformBound
  exact tsum_nonneg (fun s =>
    Finset.prod_nonneg (fun p hp => by positivity))
lemma scaled_cutoff_le_scaled_T
    {T : ℝ} {X s : ℕ}
    (hs : s ∈ Finset.Icc 1 X)
    (hXT : (X : ℝ) ≤ T) :
    ((X / s : ℕ) : ℝ) ≤ T / (s : ℝ) := by
  have hs1 : 1 ≤ s := (Finset.mem_Icc.mp hs).1
  have hspos : (0 : ℝ) < s := by positivity
  calc
    ((X / s : ℕ) : ℝ) ≤ (X : ℝ) / (s : ℝ) :=
      Nat.cast_div_le
    _ ≤ T / (s : ℝ) := by
      exact div_le_div_of_nonneg_right hXT hspos.le

lemma one_le_scaled_cutoff
    {X s : ℕ} (hs : s ∈ Finset.Icc 1 X) :
    1 ≤ X / s := by
  have hspos : 0 < s := by
    exact lt_of_lt_of_le Nat.zero_lt_one (Finset.mem_Icc.mp hs).1
  exact (Nat.one_le_div_iff hspos).2 (Finset.mem_Icc.mp hs).2

lemma scaled_T_le_T
    {T : ℝ} {s : ℕ}
    (hT0 : 0 ≤ T) (hs1 : 1 ≤ s) :
    T / (s : ℝ) ≤ T := by
  have hsR : (1 : ℝ) ≤ s := by exact_mod_cast hs1
  have hspos : (0 : ℝ) < s := by positivity
  rw [div_le_iff₀ hspos]
  nlinarith

theorem petermannMovingSublog_of_r0002
    (q : ℕ) (hq : 0 < q)
    (hbase :
      PetermannMinimalConsumerR0002Spec q PetermannBase.omega) :
    PetermannMovingSublogSpec q := by
  intro ε hε
  let D : ℝ := petermannCorrectionL1UniformBound
  have hD0 : 0 ≤ D := by
    exact petermannCorrectionL1UniformBound_nonneg
  let ε' : ℝ := ε / (2 * (D + 1))
  have hε' : 0 < ε' := by
    dsimp [ε']
    positivity
  obtain ⟨Tbase, hTbase⟩ := hbase ε' hε'
  let L : ℝ := (Nat.lcm 6 q : ℕ)
  have hlcm : 0 < Nat.lcm 6 q :=
    Nat.lcm_pos (by norm_num) hq
  have hL : 0 < L := by
    change (0 : ℝ) < (Nat.lcm 6 q : ℝ)
    exact_mod_cast hlcm
  have hL1 : 1 ≤ L := by
    change (1 : ℝ) ≤ (Nat.lcm 6 q : ℝ)
    exact_mod_cast hlcm
  let A : ℝ := max Tbase (2 * L)
  let N : ℕ := ⌈A⌉₊
  let C : ℝ := petermannOmegaFiniteMass q N
  have hC0 : 0 ≤ C :=
    petermannOmegaFiniteMass_nonneg q N
  let K : ℝ := 2 * D * C / ε
  let Tfinal : ℝ := max A (Real.exp K)
  refine ⟨Tfinal, ?_⟩
  intro h hh chi r T X hTf h2 hX1 hXT
  have h2L : 2 * L ≤ T := by simpa [L] using h2
  have hTpos : 0 < T := by linarith
  have hT1 : 1 ≤ T := by linarith [hL1]
  have hlogT0 : 0 ≤ Real.log T := Real.log_nonneg hT1
  have hA_T : A ≤ T :=
    (le_max_left A (Real.exp K)).trans hTf
  have hExp_T : Real.exp K ≤ T :=
    (le_max_right A (Real.exp K)).trans hTf
  have hN_A : A ≤ (N : ℝ) := by
    simpa [N] using (Nat.le_ceil A)
  have hheadcoef : D * ε' ≤ ε / 2 := by
    dsimp [ε']
    have hden : 0 < 2 * (D + 1) := by positivity
    rw [show D * (ε / (2 * (D + 1))) =
        (D * ε) / (2 * (D + 1)) by ring]
    apply (div_le_iff₀ hden).2
    ring_nf
    nlinarith
  have hloglower : K ≤ Real.log T := by
    have hlogmono :=
      Real.log_le_log (Real.exp_pos K) hExp_T
    simpa [K] using hlogmono
  have hconst :
      D * C ≤ (ε / 2) * Real.log T := by
    have hm := mul_le_mul_of_nonneg_left hloglower
      (show 0 ≤ ε / 2 by positivity)
    calc
      D * C = (ε / 2) * K := by
        dsimp [K]
        field_simp [ne_of_gt hε]
      _ ≤ (ε / 2) * Real.log T := hm
  rw [petermannMovingKernelSum_eq_correction_sum q h hq]
  calc
    ‖∑ s ∈ Finset.Icc 1 X,
        (chi s) *
        (petermannCorrectionArithmetic q h s : ℂ) *
        petermannBaseKernelSum q PetermannBase.omega chi r
          (T / s) (X / s)‖
      ≤ ∑ s ∈ Finset.Icc 1 X,
          ‖(chi s) *
            (petermannCorrectionArithmetic q h s : ℂ) *
            petermannBaseKernelSum q PetermannBase.omega chi r
              (T / s) (X / s)‖ := by
          exact norm_sum_le _ _
    _ ≤ ∑ s ∈ Finset.Icc 1 X,
          |petermannCorrectionArithmetic q h s| *
            (ε' * Real.log T + C) := by
          apply Finset.sum_le_sum
          intro s hs
          have hs1 : 1 ≤ s := (Finset.mem_Icc.mp hs).1
          have hsposR : (0 : ℝ) < s := by positivity
          have hscaledPos : 0 < T / (s : ℝ) := div_pos hTpos hsposR
          have hscaledLeT :
              T / (s : ℝ) ≤ T :=
            scaled_T_le_T hTpos.le hs1
          have hcut1 : 1 ≤ X / s :=
            one_le_scaled_cutoff hs
          have hcutT :
              ((X / s : ℕ) : ℝ) ≤ T / (s : ℝ) :=
            scaled_cutoff_le_scaled_T hs hXT
          have hkernel :
              ‖petermannBaseKernelSum q PetermannBase.omega chi r
                  (T / s) (X / s)‖
                ≤ ε' * Real.log T + C := by
            by_cases hlarge : A ≤ T / (s : ℝ)
            · have hb0 : Tbase ≤ T / (s : ℝ) :=
                (le_max_left Tbase (2 * L)).trans hlarge
              have hb2 : 2 * L ≤ T / (s : ℝ) :=
                (le_max_right Tbase (2 * L)).trans hlarge
              have hraw :=
                hTbase chi r (T / s) (X / s)
                  hb0 (by simpa [L] using hb2) hcut1 hcutT
              have hlog :
                  Real.log (T / (s : ℝ)) ≤ Real.log T :=
                Real.log_le_log hscaledPos hscaledLeT
              have hmain :
                  ‖petermannBaseKernelSum q PetermannBase.omega chi r
                      (T / s) (X / s)‖
                    ≤ ε' * Real.log T := by
                exact hraw.trans
                  (mul_le_mul_of_nonneg_left hlog hε'.le)
              linarith
            · have hsmall : T / (s : ℝ) < A := lt_of_not_ge hlarge
              have hYNreal :
                  ((X / s : ℕ) : ℝ) ≤ (N : ℝ) :=
                hcutT.trans (hsmall.le.trans hN_A)
              have hYN : X / s ≤ N := by
                exact_mod_cast hYNreal
              have hfinite :=
                norm_petermannBaseKernelSum_omega_le_finiteMass
                  q N chi r (T / s) (X / s) hYN
              have hεlog : 0 ≤ ε' * Real.log T :=
                mul_nonneg hε'.le hlogT0
              exact hfinite.trans (by linarith)
          have hchi :=
            norm_dirichletCharacter_nat_le_one
              (q := q) (e := s) chi
          have hB0 : 0 ≤ ε' * Real.log T + C :=
            add_nonneg (mul_nonneg hε'.le hlogT0) hC0
          simp only [norm_mul, Complex.norm_real, Real.norm_eq_abs]
          calc
            ‖chi s‖ *
                  |petermannCorrectionArithmetic q h s| *
                  ‖petermannBaseKernelSum q PetermannBase.omega chi r
                    (T / s) (X / s)‖
              ≤ 1 * |petermannCorrectionArithmetic q h s| *
                  (ε' * Real.log T + C) := by
                    gcongr
            _ = |petermannCorrectionArithmetic q h s| *
                  (ε' * Real.log T + C) := by ring
    _ = (ε' * Real.log T + C) *
          (∑ s ∈ Finset.Icc 1 X,
            |petermannCorrectionArithmetic q h s|) := by
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro s hs
          ring
    _ ≤ (ε' * Real.log T + C) * D := by
          exact mul_le_mul_of_nonneg_left
            (petermannCorrectionL1Finite_le q h X hh)
            (add_nonneg (mul_nonneg hε'.le hlogT0) hC0)
    _ = D * (ε' * Real.log T + C) := by ring
    _ ≤ ε * Real.log T := by
          calc
            D * (ε' * Real.log T + C)
              = (D * ε') * Real.log T + D * C := by ring
            _ ≤ (ε / 2) * Real.log T +
                (ε / 2) * Real.log T := by
                  exact add_le_add
                    (mul_le_mul_of_nonneg_right hheadcoef hlogT0)
                    hconst
            _ = ε * Real.log T := by ring

#print axioms petermannMovingSublog_of_r0002

end PaperB.FixedQ
