import PaperB.FixedQ.H2ProperWeightedEventual

open scoped BigOperators
namespace PaperB.FixedQ

lemma h3HalfOpenIntervalIndicator_bounds {N r : ℕ} [NeZero N] (x : ZMod N) :
    0 ≤ h3HalfOpenIntervalIndicator r x ∧
      h3HalfOpenIntervalIndicator r x ≤ 1 := by
  unfold h3HalfOpenIntervalIndicator
  split <;> norm_num

theorem fixedProductProperAffineRootIntervalDiscrepancy_abs_le_two
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime)
    (u : (ZMod (primeSetProduct S))ˣ)
    (v : ZMod (primeSetProduct S)) (r : ℕ)
    (hr : r < primeSetProduct S) :
    |fixedProductProperAffineRootIntervalDiscrepancy S hPrime u v r| ≤ 2 := by
  letI : NeZero (primeSetProduct S) := ⟨(primeSetProduct_pos hPrime).ne'⟩
  rw [calder_proper_affine_discrepancy_eq_rootAverage_indicator_sub]
  have havg0 : 0 ≤ calderProperRootAverageR S
      (fun x : ZMod (primeSetProduct S) =>
        h3HalfOpenIntervalIndicator r ((u : ZMod (primeSetProduct S)) * x + v)) := by
    calc
      0 = calderProperRootAverageR S (fun _ => (0 : ℝ)) := by
        rw [calderProperRootAverageR_const]
        ring
      _ ≤ _ := calderProperRootAverageR_mono S (fun x => (h3HalfOpenIntervalIndicator_bounds _).1)
  have havg1 : calderProperRootAverageR S
      (fun x : ZMod (primeSetProduct S) =>
        h3HalfOpenIntervalIndicator r ((u : ZMod (primeSetProduct S)) * x + v)) ≤ 1 := by
    calc
      _ ≤ calderProperRootAverageR S (fun _ => (1 : ℝ)) :=
        calderProperRootAverageR_mono S (fun x => (h3HalfOpenIntervalIndicator_bounds _).2)
      _ = fixedProductProperMass S := by rw [calderProperRootAverageR_const]; ring
      _ ≤ 1 := fixedProductProperMass_le_one S
  have hmpos : 0 < (primeSetProduct S : ℝ) := by
    exact_mod_cast primeSetProduct_pos hPrime
  have hrdiv0 : 0 ≤ (r : ℝ) / (primeSetProduct S : ℝ) := by
    exact div_nonneg (by positivity) hmpos.le
  have hrexp0 : 0 ≤ fixedProductProperMass S *
      ((r : ℝ) / (primeSetProduct S : ℝ)) :=
    mul_nonneg (fixedProductProperMass_nonneg S) hrdiv0
  have hrle : (r : ℝ) / (primeSetProduct S : ℝ) ≤ 1 := by
    apply (div_le_iff₀ hmpos).2
    simpa using (show (r : ℝ) ≤ (primeSetProduct S : ℝ) by
      exact_mod_cast (Nat.le_of_lt hr))
  have hrexp1 : fixedProductProperMass S *
      ((r : ℝ) / (primeSetProduct S : ℝ)) ≤ 1 := by
    calc
      _ ≤ 1 * 1 := mul_le_mul
        (fixedProductProperMass_le_one S) hrle hrdiv0 (by norm_num)
      _ = 1 := by norm_num
  rw [abs_sub_le_iff]
  constructor <;> linarith

theorem fixedQProperWeightedDiscrepancy_abs_le_uniform
    {q A H : ℕ} {S : Finset ℕ}
    (hq : 0 < q)
    (hActive : ∀ p ∈ S, activeHighPrime q p)
    (hOrd : S ∈ ordinaryTwoDimensionalSet H)
    (h2 : ¬ 2 ∣ q → 2 ∣ H) :
    |fixedQProperWeightedDiscrepancy q A H S| ≤
      12 * (fixedQPeriod q : ℝ) := by
  rw [fixedQProperWeightedDiscrepancy_eq_periodic_affine_sum hq hActive hOrd h2]
  calc
    |∑ c : Fin (fixedQPeriod q),
        occupiedFixedQLowWeight q A H (c.1 + 1) *
          fixedProductProperAffineRootIntervalDiscrepancy S
            (fun p hp => (hActive p hp).1)
            _ _ _|
      ≤ ∑ c : Fin (fixedQPeriod q),
          |occupiedFixedQLowWeight q A H (c.1 + 1) *
            fixedProductProperAffineRootIntervalDiscrepancy S
              (fun p hp => (hActive p hp).1) _ _ _| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _c : Fin (fixedQPeriod q), (12 : ℝ) := by
      apply Finset.sum_le_sum
      intro c hc
      rw [abs_mul]
      have hw := abs_occupiedFixedQLowWeight_le_six q A H (c.1 + 1) h2
      have hr : periodicResidueLength (fixedQPeriod q) H c.1 % primeSetProduct S < primeSetProduct S :=
        Nat.mod_lt _ (primeSetProduct_pos (fun p hp => (hActive p hp).1))
      let u := fixedProductBooleanPeriodicTwist
        (fixedQPeriod q) H S
        (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
        ((ordinary_primeSetProduct_coprime_height_iff
          (fun p hp => (hActive p hp).1)).mp hOrd).symm
      let v := fixedProductBooleanPeriodicShift
        (fixedQPeriod q) S
        (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm c.1
      let rr := periodicResidueLength (fixedQPeriod q) H c.1 % primeSetProduct S
      have hd := fixedProductProperAffineRootIntervalDiscrepancy_abs_le_two
        S (fun p hp => (hActive p hp).1) u v rr (by simpa [rr] using hr)
      dsimp [u, v, rr] at hd
      calc
        |occupiedFixedQLowWeight q A H (c.1 + 1)| *
            |fixedProductProperAffineRootIntervalDiscrepancy S
              (fun p hp => (hActive p hp).1)
              (fixedProductBooleanPeriodicTwist
                (fixedQPeriod q) H S
                (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
                ((ordinary_primeSetProduct_coprime_height_iff
                  (fun p hp => (hActive p hp).1)).mp hOrd).symm)
              (fixedProductBooleanPeriodicShift
                (fixedQPeriod q) S
                (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm c.1)
              (periodicResidueLength (fixedQPeriod q) H c.1 % primeSetProduct S)|
          ≤ 6 *
            |fixedProductProperAffineRootIntervalDiscrepancy S
              (fun p hp => (hActive p hp).1)
              (fixedProductBooleanPeriodicTwist
                (fixedQPeriod q) H S
                (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
                ((ordinary_primeSetProduct_coprime_height_iff
                  (fun p hp => (hActive p hp).1)).mp hOrd).symm)
              (fixedProductBooleanPeriodicShift
                (fixedQPeriod q) S
                (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm c.1)
              (periodicResidueLength (fixedQPeriod q) H c.1 % primeSetProduct S)| :=
            mul_le_mul_of_nonneg_right hw (abs_nonneg _)
        _ ≤ 6 * 2 := mul_le_mul_of_nonneg_left hd (by norm_num)
        _ = 12 := by norm_num

    _ = 12 * (fixedQPeriod q : ℝ) := by
      simp
      ring

#print axioms fixedProductProperAffineRootIntervalDiscrepancy_abs_le_two
#print axioms fixedQProperWeightedDiscrepancy_abs_le_uniform

end PaperB.FixedQ
