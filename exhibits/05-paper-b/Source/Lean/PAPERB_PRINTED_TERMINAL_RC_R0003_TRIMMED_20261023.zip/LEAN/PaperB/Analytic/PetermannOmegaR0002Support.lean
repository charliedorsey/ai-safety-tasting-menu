import PaperB.Analytic.PetermannOmegaHighCoprimeDFT
import PaperB.Analytic.PetermannOmegaLowMovingCutoff
import PaperB.Analytic.PetermannFixedBetaMiddleWindow
import PaperB.Analytic.PetermannOmegaWeightedExpansion
import PaperB.Analytic.PetermannOmegaSmoothedDFT
import PaperB.Analytic.PetermannOmegaKernelSplit
import PaperB.Analytic.PetermannOmegaRemainderSublog
import PaperB.Analytic.PetermannOmegaPartialSumLogBound
import PaperB.FixedQ.HarmonicLogTail

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

theorem fixedBeta_middle_coprime_reciprocal_weight_tail_bound
    (q : ℕ) [NeZero (6 * q)] (g : ZMod (6 * q))
    {beta0 A : ℝ} {M N : ℕ}
    (hb00 : 0 < beta0) (hb01 : beta0 < 1)
    (hA1 : 1 < A)
    (hM1 : 1 < M)
    (hlow : A ^ beta0 ≤ (M : ℝ))
    (hhigh : (N : ℝ) ≤ A ^ (3 / 4 : ℝ))
    (hKM : fixedBetaNaturalOrder beta0 ≤ M)
    (hMN : M ≤ N) :
    ‖∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR (A / (m : ℝ) +
            ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖
      ≤ ((6 * q : ℕ) : ℝ) *
          (4 / (M : ℝ) +
            ((2 * fixedBetaUniformMajorantConst beta0) /
              (1 - (2 : ℝ) ^
                (fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) - 1))) *
              (M : ℝ) ^
                (fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) - 1)) := by
  have hM : 0 < M := by omega
  have hexp := coprime_weighted_high_shell_dft_expansion
    q g (A := A) (W := M) (B := N) hM
  have hrewrite :
      (∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR (A / (m : ℝ) +
            ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))) =
      (∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m : ℝ) : ℂ) *
          (m : ℂ)⁻¹ *
          eR (A / (m : ℝ) +
            ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))) := by
    apply Finset.sum_congr rfl
    intro m hm
    have hm0 : (m : ℝ) ≠ 0 := by
      have hmM := (Finset.mem_Icc.mp hm).1
      have hmNat0 : m ≠ 0 := by omega
      exact_mod_cast hmNat0
    push_cast
    rw [div_eq_mul_inv]
  have hmode : ∀ a : ZMod (6 * q),
      ‖∑ m ∈ Finset.Icc M N,
          (m : ℂ)⁻¹ *
            eR (A / (m : ℝ) +
              (((g + a).val : ℝ) /
                ((6 * q : ℕ) : ℝ)) * (m : ℝ))‖
        ≤
          4 / (M : ℝ) +
            ((2 * fixedBetaUniformMajorantConst beta0) /
              (1 - (2 : ℝ) ^
                (fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) - 1))) *
              (M : ℝ) ^
                (fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) - 1) := by
    intro a
    exact fixedBeta_middle_reciprocal_weight_tail_bound
      hb00 hb01 hA1 hM1 hlow hhigh hKM hMN
  rw [hrewrite, hexp]
  rw [norm_mul, norm_inv, Complex.norm_natCast]
  have hPnat : 0 < 6 * q := NeZero.pos _
  have hPreal : (0 : ℝ) < ((6 * q : ℕ) : ℝ) := by exact_mod_cast hPnat
  let C : ℝ :=
    4 / (M : ℝ) +
      ((2 * fixedBetaUniformMajorantConst beta0) /
        (1 - (2 : ℝ) ^
          (fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) - 1))) *
        (M : ℝ) ^
          (fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) - 1)
  have hC0 : 0 ≤ C := by
    dsimp [C]
    have htheta := fixedBetaUniformExponent_lt_one (fixedBetaNaturalOrder beta0)
    have hpowlt :
        (2 : ℝ) ^
          (fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) - 1) < 1 :=
      Real.rpow_lt_one_of_one_lt_of_neg (by norm_num) (by linarith)
    have hden :
        0 < 1 - (2 : ℝ) ^
          (fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) - 1) := by
      linarith
    have hconst : 0 ≤ fixedBetaUniformMajorantConst beta0 :=
      fixedBetaUniformMajorantConst_nonneg beta0
    have hMr : (0 : ℝ) < M := by exact_mod_cast hM
    have hp : 0 ≤ (M : ℝ) ^
        (fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) - 1) :=
      Real.rpow_nonneg hMr.le _
    positivity
  calc
    (((6 * q : ℕ) : ℝ))⁻¹ *
        ‖∑ a : ZMod (6 * q),
          ZMod.dft
              (fun x : ZMod (6 * q) =>
                (1 : DirichletCharacter ℂ (6 * q)) x) a *
            (∑ m ∈ Finset.Icc M N,
              (m : ℂ)⁻¹ *
                eR (A / (m : ℝ) +
                  (((g + a).val : ℝ) /
                    ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖
      ≤ (((6 * q : ℕ) : ℝ))⁻¹ *
          ∑ a : ZMod (6 * q),
            ‖ZMod.dft
                (fun x : ZMod (6 * q) =>
                  (1 : DirichletCharacter ℂ (6 * q)) x) a *
              (∑ m ∈ Finset.Icc M N,
                (m : ℂ)⁻¹ *
                  eR (A / (m : ℝ) +
                    (((g + a).val : ℝ) /
                      ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖ := by
        gcongr
        exact norm_sum_le _ _
    _ ≤ (((6 * q : ℕ) : ℝ))⁻¹ *
          ∑ _a : ZMod (6 * q),
            (((6 * q : ℕ) : ℝ) * C) := by
        gcongr with a
        rw [norm_mul]
        calc
          ‖ZMod.dft
              (fun x : ZMod (6 * q) =>
                (1 : DirichletCharacter ℂ (6 * q)) x) a‖ *
              ‖∑ m ∈ Finset.Icc M N,
                (m : ℂ)⁻¹ *
                  eR (A / (m : ℝ) +
                    (((g + a).val : ℝ) /
                      ((6 * q : ℕ) : ℝ)) * (m : ℝ))‖
            ≤ ((6 * q : ℕ) : ℝ) *
              ‖∑ m ∈ Finset.Icc M N,
                (m : ℂ)⁻¹ *
                  eR (A / (m : ℝ) +
                    (((g + a).val : ℝ) /
                      ((6 * q : ℕ) : ℝ)) * (m : ℝ))‖ :=
                mul_le_mul_of_nonneg_right
                  (principalCharacter_dft_norm_le q a) (norm_nonneg _)
          _ ≤ ((6 * q : ℕ) : ℝ) * C :=
                mul_le_mul_of_nonneg_left
                  (by simpa [C] using hmode a) (by positivity)
    _ = (((6 * q : ℕ) : ℝ)) * C := by
        simp
        field_simp [hPreal.ne']
    _ = ((6 * q : ℕ) : ℝ) *
          (4 / (M : ℝ) +
            ((2 * fixedBetaUniformMajorantConst beta0) /
              (1 - (2 : ℝ) ^
                (fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) - 1))) *
              (M : ℝ) ^
                (fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) - 1)) := rfl

#print axioms fixedBeta_middle_coprime_reciprocal_weight_tail_bound

end PaperB.Analytic

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat
open scoped ComplexConjugate

lemma norm_coprime_reciprocal_phase_negA
    (q : ℕ) {A xi : ℝ} {M N : ℕ} :
    ‖∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR (-A / (m : ℝ) + xi * (m : ℝ)))‖ =
      ‖∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR (A / (m : ℝ) + (-xi) * (m : ℝ)))‖ := by
  have hconj :
      conj
        (∑ m ∈ Finset.Icc M N,
          (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
            eR (A / (m : ℝ) + (-xi) * (m : ℝ)))) =
        ∑ m ∈ Finset.Icc M N,
          (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
            eR (-A / (m : ℝ) + xi * (m : ℝ))) := by
    rw [map_sum]
    apply Finset.sum_congr rfl
    intro m hm
    rw [map_mul, conj_eR]
    have hreal :
        conj (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ)) =
          ((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) := by
      simp
    rw [hreal]
    congr 1
    ring
  rw [← hconj, RCLike.norm_conj]

#print axioms norm_coprime_reciprocal_phase_negA

end PaperB.Analytic


namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

private lemma omega_sum_Icc_split
    {M0 : Type} [AddCommMonoid M0] (f : ℕ → M0)
    {a b c : ℕ} (hab : a ≤ b) (hbc : b ≤ c) :
    (∑ n ∈ Finset.Icc a c, f n) =
      (∑ n ∈ Finset.Icc a b, f n) +
      (∑ n ∈ Finset.Icc (b + 1) c, f n) := by
  have hdis : Disjoint (Finset.Icc a b) (Finset.Icc (b + 1) c) := by
    rw [Finset.disjoint_left]
    intro x hx1 hx2
    simp only [Finset.mem_Icc] at hx1 hx2
    omega
  have hunion :
      Finset.Icc a b ∪ Finset.Icc (b + 1) c = Finset.Icc a c := by
    ext x
    simp only [Finset.mem_union, Finset.mem_Icc]
    constructor
    · intro hx
      rcases hx with hx | hx
      · exact ⟨hx.1, hx.2.trans hbc⟩
      · exact ⟨hab.trans (by omega), hx.2⟩
    · intro hx
      by_cases hxb : x ≤ b
      · exact Or.inl ⟨hx.1, hxb⟩
      · exact Or.inr ⟨by omega, hx.2⟩
  rw [← hunion, Finset.sum_union hdis]

noncomputable def omegaMiddleTailBound
    (q : ℕ) (beta0 : ℝ) (M : ℕ) : ℝ :=
  ((6 * q : ℕ) : ℝ) *
    (4 / (M : ℝ) +
      ((2 * fixedBetaUniformMajorantConst beta0) /
        (1 - (2 : ℝ) ^
          (fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) - 1))) *
        (M : ℝ) ^
          (fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) - 1))

lemma omegaMiddleTailBound_nonneg
    (q : ℕ) {beta0 : ℝ} (hb0 : 0 < beta0) (M : ℕ) (hM : 0 < M) :
    0 ≤ omegaMiddleTailBound q beta0 M := by
  unfold omegaMiddleTailBound
  have htheta := fixedBetaUniformExponent_lt_one (fixedBetaNaturalOrder beta0)
  have hpowlt :
      (2 : ℝ) ^
        (fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) - 1) < 1 :=
    Real.rpow_lt_one_of_one_lt_of_neg (by norm_num) (by linarith)
  have hden :
      0 < 1 - (2 : ℝ) ^
        (fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) - 1) := by
    linarith
  have hconst : 0 ≤ fixedBetaUniformMajorantConst beta0 :=
    fixedBetaUniformMajorantConst_nonneg beta0
  have hMr : (0 : ℝ) < M := by exact_mod_cast hM
  have hp : 0 ≤ (M : ℝ) ^
      (fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) - 1) :=
    Real.rpow_nonneg hMr.le _
  positivity

theorem omega_middle_high_coprime_reciprocal_weight_tail_sublog
    (q : ℕ) [NeZero (6 * q)]
    {beta0 A : ℝ} (g : ZMod (6 * q)) {M N : ℕ}
    (hb00 : 0 < beta0) (hb01 : beta0 < 1)
    (hA1 : 1 < A)
    (hM1 : 1 < M)
    (hlow : A ^ beta0 ≤ (M : ℝ))
    (hKM : fixedBetaNaturalOrder beta0 ≤ M)
    (hMN : M ≤ N)
    (hAthresh : (2 * ((6 * q : ℕ) : ℝ)) ^ 2 ≤ A)
    (hscale : (N : ℝ) ≤ ((6 * q : ℕ) : ℝ) * A) :
    ∀ eps : ℝ, 0 < eps →
      ∃ T0 : ℝ, ∀ T : ℝ,
        T0 ≤ T → Real.exp 1 ≤ T →
        ‖∑ m ∈ Finset.Icc M N,
            (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
              eR (A / (m : ℝ) +
                ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖
          ≤ omegaMiddleTailBound q beta0 M + eps * Real.log T := by
  intro eps heps
  obtain ⟨T0, hhighSub⟩ :=
    omega_high_coprime_dft_reciprocal_weight_tail_sublog q eps heps
  refine ⟨T0, ?_⟩
  intro T hT0 hT1
  let K : ℕ := Nat.floor (A ^ (3 / 4 : ℝ))
  have hApow0 : 0 ≤ A ^ (3 / 4 : ℝ) :=
    Real.rpow_nonneg (le_of_lt (lt_trans zero_lt_one hA1)) _
  have hKle : (K : ℝ) ≤ A ^ (3 / 4 : ℝ) := by
    dsimp [K]
    exact Nat.floor_le hApow0
  have hAltK1 : A ^ (3 / 4 : ℝ) < (K : ℝ) + 1 := by
    dsimp [K]
    exact Nat.lt_floor_add_one _
  have hlog0 : 0 ≤ Real.log T := by
    have hTone : (1 : ℝ) ≤ T := by
      have he1 : (1 : ℝ) ≤ Real.exp 1 := by
        rw [← Real.exp_zero]
        exact Real.exp_le_exp.mpr (by norm_num)
      exact he1.trans hT1
    exact Real.log_nonneg hTone
  have hmid0 : 0 ≤ omegaMiddleTailBound q beta0 M :=
    omegaMiddleTailBound_nonneg q hb00 M (by omega)
  by_cases hNK : N ≤ K
  · have hNhigh : (N : ℝ) ≤ A ^ (3 / 4 : ℝ) := by
      exact (by exact_mod_cast hNK : (N : ℝ) ≤ K).trans hKle
    have hm :=
      fixedBeta_middle_coprime_reciprocal_weight_tail_bound
        q g hb00 hb01 hA1 hM1 hlow hNhigh hKM hMN
    calc
      ‖∑ m ∈ Finset.Icc M N,
          (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
            eR (A / (m : ℝ) +
              ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖
        ≤ omegaMiddleTailBound q beta0 M := by
          simpa [omegaMiddleTailBound] using hm
      _ ≤ omegaMiddleTailBound q beta0 M + eps * Real.log T := by
          exact le_add_of_nonneg_right (mul_nonneg heps.le hlog0)
  · have hKN : K < N := Nat.lt_of_not_ge hNK
    by_cases hKMcut : K < M
    · have hhighM : A ^ (3 / 4 : ℝ) < (M : ℝ) := by
        have hK1M : K + 1 ≤ M := by omega
        have hcast : (K : ℝ) + 1 ≤ (M : ℝ) := by exact_mod_cast hK1M
        exact hAltK1.trans_le hcast
      have hh := hhighSub g A M N T hAthresh (by omega)
        hhighM hMN hscale hT0 hT1
      calc
        ‖∑ m ∈ Finset.Icc M N,
            (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
              eR (A / (m : ℝ) +
                ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖
          ≤ eps * Real.log T := hh
        _ ≤ omegaMiddleTailBound q beta0 M + eps * Real.log T := by
          exact le_add_of_nonneg_left hmid0
    · have hMK : M ≤ K := Nat.le_of_not_gt hKMcut
      have hK1N : K + 1 ≤ N := by omega
      let f : ℕ → ℂ := fun m =>
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR (A / (m : ℝ) +
            ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))
      have hsplit := omega_sum_Icc_split f hMK (Nat.le_of_lt hKN)
      have hmiddle :=
        fixedBeta_middle_coprime_reciprocal_weight_tail_bound
          q g hb00 hb01 hA1 hM1 hlow hKle hKM hMK
      have hhighK : A ^ (3 / 4 : ℝ) < ((K + 1 : ℕ) : ℝ) := by
        norm_num only [Nat.cast_add, Nat.cast_one]
        exact hAltK1
      have hhigh :=
        hhighSub g A (K + 1) N T hAthresh (by omega)
          hhighK hK1N hscale hT0 hT1
      rw [show (∑ m ∈ Finset.Icc M N, f m) =
          (∑ m ∈ Finset.Icc M K, f m) +
          (∑ m ∈ Finset.Icc (K + 1) N, f m) by exact hsplit]
      calc
        ‖(∑ m ∈ Finset.Icc M K, f m) +
            (∑ m ∈ Finset.Icc (K + 1) N, f m)‖
          ≤ ‖∑ m ∈ Finset.Icc M K, f m‖ +
              ‖∑ m ∈ Finset.Icc (K + 1) N, f m‖ := norm_add_le _ _
        _ ≤ omegaMiddleTailBound q beta0 M + eps * Real.log T := by
          exact add_le_add
            (by simpa [f, omegaMiddleTailBound] using hmiddle)
            (by simpa [f] using hhigh)

#print axioms omega_middle_high_coprime_reciprocal_weight_tail_sublog

end PaperB.Analytic


namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

lemma eR_neg_zmod_frequency
    {P : ℕ} [NeZero P] (g : ZMod P) (m : ℕ) :
    eR (-(((g.val : ℝ) / (P : ℝ)) * (m : ℝ))) =
      eR ((((-g).val : ℝ) / (P : ℝ)) * (m : ℝ)) := by
  have hadd := eR_zmod_frequency_add g (-g) m
  have hzero :
      eR ((((g + (-g)).val : ℝ) / (P : ℝ)) * (m : ℝ)) = 1 := by
    simp [eR]
  rw [hzero] at hadd
  have hx0 :
      eR (((g.val : ℝ) / (P : ℝ)) * (m : ℝ)) ≠ 0 := by
    intro hz
    have hn := norm_eR (((g.val : ℝ) / (P : ℝ)) * (m : ℝ))
    rw [hz, norm_zero] at hn
    norm_num at hn
  have hinv :
      eR ((((-g).val : ℝ) / (P : ℝ)) * (m : ℝ)) =
        (eR (((g.val : ℝ) / (P : ℝ)) * (m : ℝ)))⁻¹ := by
    calc
      eR ((((-g).val : ℝ) / (P : ℝ)) * (m : ℝ))
          = 1 * eR ((((-g).val : ℝ) / (P : ℝ)) * (m : ℝ)) := by simp
      _ = ((eR (((g.val : ℝ) / (P : ℝ)) * (m : ℝ)))⁻¹ *
            eR (((g.val : ℝ) / (P : ℝ)) * (m : ℝ))) *
          eR ((((-g).val : ℝ) / (P : ℝ)) * (m : ℝ)) := by
            rw [inv_mul_cancel₀ hx0]
      _ = (eR (((g.val : ℝ) / (P : ℝ)) * (m : ℝ)))⁻¹ *
          (eR (((g.val : ℝ) / (P : ℝ)) * (m : ℝ)) *
            eR ((((-g).val : ℝ) / (P : ℝ)) * (m : ℝ))) := by ring
      _ = (eR (((g.val : ℝ) / (P : ℝ)) * (m : ℝ)))⁻¹ := by
            rw [hadd]
            simp
  rw [eR_neg]
  exact hinv.symm

lemma norm_coprime_reciprocal_phase_negA_zmod
    (q : ℕ) [NeZero (6 * q)] (g : ZMod (6 * q))
    {A : ℝ} {M N : ℕ} :
    ‖∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR (-A / (m : ℝ) +
            ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖ =
      ‖∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR (A / (m : ℝ) +
            (((-g).val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖ := by
  rw [norm_coprime_reciprocal_phase_negA
    (q := q) (A := A)
    (xi := (g.val : ℝ) / ((6 * q : ℕ) : ℝ))
    (M := M) (N := N)]
  congr 1
  apply Finset.sum_congr rfl
  intro m hm
  congr 1
  rw [eR_add, eR_add]
  congr 1
  have hneg := eR_neg_zmod_frequency (P := 6 * q) g m
  simpa [neg_mul] using hneg

#print axioms eR_neg_zmod_frequency
#print axioms norm_coprime_reciprocal_phase_negA_zmod

end PaperB.Analytic


namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

noncomputable def omegaHighTailSimpleBound
    (q : ℕ) (A : ℝ) (N : ℕ) : ℝ :=
  24 * ((6 * q : ℕ) : ℝ) * (N : ℝ) / A +
    4 * ((6 * q : ℕ) : ℝ) * (1 + 2 * ((6 * q : ℕ) : ℝ)) /
      (A ^ (3 / 4 : ℝ))

theorem omega_high_coprime_dft_reciprocal_weight_tail_simple_bound
    (q : ℕ) [NeZero (6 * q)] (g : ZMod (6 * q))
    {A : ℝ} {M N : ℕ}
    (hAthresh : (2 * ((6 * q : ℕ) : ℝ)) ^ 2 ≤ A)
    (hM : 0 < M)
    (hhigh : A ^ (3 / 4 : ℝ) < (M : ℝ))
    (hMN : M ≤ N) :
    ‖∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR (A / (m : ℝ) +
            ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖
      ≤ omegaHighTailSimpleBound q A N := by
  have hPnat : 0 < 6 * q := NeZero.pos _
  have hPr : (0 : ℝ) < ((6 * q : ℕ) : ℝ) := by exact_mod_cast hPnat
  have hApos : 0 < A := by
    have hsquare : 0 < (2 * ((6 * q : ℕ) : ℝ)) ^ 2 := by positivity
    exact lt_of_lt_of_le hsquare hAthresh
  have hpowpos : 0 < A ^ (3 / 4 : ℝ) :=
    Real.rpow_pos_of_pos hApos _
  have hMr : (0 : ℝ) < M := by exact_mod_cast hM
  have hinv :
      1 / (M : ℝ) ≤ 1 / (A ^ (3 / 4 : ℝ)) := by
    exact one_div_le_one_div_of_le hpowpos hhigh.le
  have htail :=
    omega_high_coprime_dft_reciprocal_weight_tail_bound
      q g hAthresh hM hhigh hMN
  have halpha :
      0 ≤ (((6 * q : ℕ) : ℝ) * 12 / A) * (M : ℝ) := by positivity
  have hbeta :
      0 ≤ 4 * ((6 * q : ℕ) : ℝ) *
        (1 + 2 * ((6 * q : ℕ) : ℝ)) := by positivity
  unfold omegaHighTailSimpleBound
  calc
    ‖∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR (A / (m : ℝ) +
            ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖
      ≤ 2 * (((6 * q : ℕ) : ℝ) * 12 / A) * (N : ℝ) -
          (((6 * q : ℕ) : ℝ) * 12 / A) * (M : ℝ) +
          2 * (((6 * q : ℕ) : ℝ) *
            (2 * (1 + 2 * ((6 * q : ℕ) : ℝ)))) / (M : ℝ) := htail
    _ ≤ 2 * (((6 * q : ℕ) : ℝ) * 12 / A) * (N : ℝ) +
          2 * (((6 * q : ℕ) : ℝ) *
            (2 * (1 + 2 * ((6 * q : ℕ) : ℝ)))) / (M : ℝ) := by
          linarith
    _ ≤ 24 * ((6 * q : ℕ) : ℝ) * (N : ℝ) / A +
          4 * ((6 * q : ℕ) : ℝ) *
            (1 + 2 * ((6 * q : ℕ) : ℝ)) /
              (A ^ (3 / 4 : ℝ)) := by
        have hmul := mul_le_mul_of_nonneg_left hinv hbeta
        calc
          2 * (((6 * q : ℕ) : ℝ) * 12 / A) * (N : ℝ) +
              2 * (((6 * q : ℕ) : ℝ) *
                (2 * (1 + 2 * ((6 * q : ℕ) : ℝ)))) / (M : ℝ)
            =
              24 * ((6 * q : ℕ) : ℝ) * (N : ℝ) / A +
              (4 * ((6 * q : ℕ) : ℝ) *
                (1 + 2 * ((6 * q : ℕ) : ℝ))) * (1 / (M : ℝ)) := by ring
          _ ≤
              24 * ((6 * q : ℕ) : ℝ) * (N : ℝ) / A +
              (4 * ((6 * q : ℕ) : ℝ) *
                (1 + 2 * ((6 * q : ℕ) : ℝ))) *
                  (1 / (A ^ (3 / 4 : ℝ))) := by
                exact add_le_add le_rfl hmul
          _ =
              24 * ((6 * q : ℕ) : ℝ) * (N : ℝ) / A +
              4 * ((6 * q : ℕ) : ℝ) *
                (1 + 2 * ((6 * q : ℕ) : ℝ)) /
                  (A ^ (3 / 4 : ℝ)) := by ring

theorem omega_middle_high_coprime_reciprocal_weight_tail_bound
    (q : ℕ) [NeZero (6 * q)]
    {beta0 A : ℝ} (g : ZMod (6 * q)) {M N : ℕ}
    (hb00 : 0 < beta0) (hb01 : beta0 < 1)
    (hA1 : 1 < A)
    (hM1 : 1 < M)
    (hlow : A ^ beta0 ≤ (M : ℝ))
    (hKM : fixedBetaNaturalOrder beta0 ≤ M)
    (hMN : M ≤ N)
    (hAthresh : (2 * ((6 * q : ℕ) : ℝ)) ^ 2 ≤ A) :
    ‖∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR (A / (m : ℝ) +
            ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖
      ≤ omegaMiddleTailBound q beta0 M +
          omegaHighTailSimpleBound q A N := by
  let K : ℕ := Nat.floor (A ^ (3 / 4 : ℝ))
  have hApow0 : 0 ≤ A ^ (3 / 4 : ℝ) :=
    Real.rpow_nonneg (le_of_lt (lt_trans zero_lt_one hA1)) _
  have hKle : (K : ℝ) ≤ A ^ (3 / 4 : ℝ) := by
    dsimp [K]
    exact Nat.floor_le hApow0
  have hAltK1 : A ^ (3 / 4 : ℝ) < (K : ℝ) + 1 := by
    dsimp [K]
    exact Nat.lt_floor_add_one _
  have hmid0 : 0 ≤ omegaMiddleTailBound q beta0 M :=
    omegaMiddleTailBound_nonneg q hb00 M (by omega)
  have hhigh0 : 0 ≤ omegaHighTailSimpleBound q A N := by
    unfold omegaHighTailSimpleBound
    have hPnat : 0 < 6 * q := NeZero.pos _
    have hApos : 0 < A := lt_trans zero_lt_one hA1
    have hp : 0 < A ^ (3 / 4 : ℝ) := Real.rpow_pos_of_pos hApos _
    positivity
  by_cases hNK : N ≤ K
  · have hNhigh : (N : ℝ) ≤ A ^ (3 / 4 : ℝ) := by
      exact (by exact_mod_cast hNK : (N : ℝ) ≤ K).trans hKle
    have hm :=
      fixedBeta_middle_coprime_reciprocal_weight_tail_bound
        q g hb00 hb01 hA1 hM1 hlow hNhigh hKM hMN
    calc
      ‖∑ m ∈ Finset.Icc M N,
          (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
            eR (A / (m : ℝ) +
              ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖
        ≤ omegaMiddleTailBound q beta0 M := by
          simpa [omegaMiddleTailBound] using hm
      _ ≤ omegaMiddleTailBound q beta0 M +
          omegaHighTailSimpleBound q A N :=
        le_add_of_nonneg_right hhigh0
  · have hKN : K < N := Nat.lt_of_not_ge hNK
    by_cases hKMcut : K < M
    · have hhighM : A ^ (3 / 4 : ℝ) < (M : ℝ) := by
        have hK1M : K + 1 ≤ M := by omega
        have hcast : (K : ℝ) + 1 ≤ (M : ℝ) := by exact_mod_cast hK1M
        exact hAltK1.trans_le hcast
      have hh :=
        omega_high_coprime_dft_reciprocal_weight_tail_simple_bound
          q g hAthresh (by omega) hhighM hMN
      calc
        ‖∑ m ∈ Finset.Icc M N,
            (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
              eR (A / (m : ℝ) +
                ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖
          ≤ omegaHighTailSimpleBound q A N := hh
        _ ≤ omegaMiddleTailBound q beta0 M +
            omegaHighTailSimpleBound q A N :=
          le_add_of_nonneg_left hmid0
    · have hMK : M ≤ K := Nat.le_of_not_gt hKMcut
      have hK1N : K + 1 ≤ N := by omega
      let f : ℕ → ℂ := fun m =>
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR (A / (m : ℝ) +
            ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))
      have hsplit := omega_sum_Icc_split f hMK (Nat.le_of_lt hKN)
      have hmiddle :=
        fixedBeta_middle_coprime_reciprocal_weight_tail_bound
          q g hb00 hb01 hA1 hM1 hlow hKle hKM hMK
      have hhighK : A ^ (3 / 4 : ℝ) < ((K + 1 : ℕ) : ℝ) := by
        norm_num only [Nat.cast_add, Nat.cast_one]
        exact hAltK1
      have hhigh :=
        omega_high_coprime_dft_reciprocal_weight_tail_simple_bound
          q g hAthresh (by omega) hhighK hK1N
      rw [show (∑ m ∈ Finset.Icc M N, f m) =
          (∑ m ∈ Finset.Icc M K, f m) +
          (∑ m ∈ Finset.Icc (K + 1) N, f m) by exact hsplit]
      calc
        ‖(∑ m ∈ Finset.Icc M K, f m) +
            (∑ m ∈ Finset.Icc (K + 1) N, f m)‖
          ≤ ‖∑ m ∈ Finset.Icc M K, f m‖ +
              ‖∑ m ∈ Finset.Icc (K + 1) N, f m‖ := norm_add_le _ _
        _ ≤ omegaMiddleTailBound q beta0 M +
            omegaHighTailSimpleBound q A N := by
          exact add_le_add
            (by simpa [f, omegaMiddleTailBound] using hmiddle)
            (by simpa [f] using hhigh)

#print axioms omega_high_coprime_dft_reciprocal_weight_tail_simple_bound
#print axioms omega_middle_high_coprime_reciprocal_weight_tail_bound

end PaperB.Analytic


namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

lemma omega_eR_int (z : ℤ) : eR (z : ℝ) = 1 := by
  rw [eR]
  have h := Complex.exp_int_mul_two_pi_mul_I z
  convert h using 1 <;> push_cast <;> ring

lemma omega_eR_nat (n : ℕ) : eR (n : ℝ) = 1 := by
  simpa using omega_eR_int (n : ℤ)

lemma omega_eR_nat_fraction_mod
    (P a m : ℕ) [NeZero P] :
    eR (((a : ℝ) / (P : ℝ)) * (m : ℝ)) =
      eR ((((a : ZMod P).val : ℝ) / (P : ℝ)) * (m : ℝ)) := by
  have hP : 0 < P := NeZero.pos P
  have hval : (a : ZMod P).val = a % P := ZMod.val_natCast P a
  rw [hval]
  have hPr : (P : ℝ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hP)
  have hdecomp : a % P + P * (a / P) = a := Nat.mod_add_div a P
  have hcast :
      (((a % P : ℕ) : ℝ) + (P : ℝ) * ((a / P : ℕ) : ℝ)) = (a : ℝ) := by
    exact_mod_cast hdecomp
  have hratio :
      (a : ℝ) / (P : ℝ) =
        ((a % P : ℕ) : ℝ) / (P : ℝ) + ((a / P : ℕ) : ℝ) := by
    calc
      (a : ℝ) / (P : ℝ)
        = ((((a % P : ℕ) : ℝ) + (P : ℝ) * ((a / P : ℕ) : ℝ))) /
            (P : ℝ) := by rw [hcast]
      _ = ((a % P : ℕ) : ℝ) / (P : ℝ) + ((a / P : ℕ) : ℝ) := by
        field_simp [hPr]
  rw [hratio, add_mul, eR_add]
  have hint :
      eR (((a / P : ℕ) : ℝ) * (m : ℝ)) = 1 := by
    have hn := omega_eR_nat ((a / P) * m)
    rw [Nat.cast_mul] at hn
    exact hn
  rw [hint, mul_one]

lemma lcm_frequency_mul_eq_sixq_frequency
    (q : ℕ) (hq : 0 < q)
    (h : ZMod (Nat.lcm 6 q)) (d m : ℕ) :
    let L := Nat.lcm 6 q
    let P := 6 * q
    let C := P / L
    let g : ZMod P := (h.val * C * d : ℕ)
    eR ((((h.val : ℝ) / (L : ℝ)) * (d : ℝ)) * (m : ℝ)) =
      eR (((g.val : ℝ) / (P : ℝ)) * (m : ℝ)) := by
  let L := Nat.lcm 6 q
  let P := 6 * q
  let C := P / L
  have hL : 0 < L := by
    dsimp [L]
    exact Nat.lcm_pos (by norm_num) hq
  have hP : 0 < P := by dsimp [P]; omega
  letI : NeZero P := ⟨Nat.ne_of_gt hP⟩
  have hLP : L ∣ P := by
    dsimp [L, P]
    exact Nat.lcm_dvd_mul 6 q
  have hmul : L * C = P := by
    dsimp [C]
    exact Nat.mul_div_cancel' hLP
  have hmulR : (L : ℝ) * (C : ℝ) = (P : ℝ) := by exact_mod_cast hmul
  have hC : 0 < C := by
    dsimp [C]
    exact Nat.div_pos (Nat.le_of_dvd hP hLP) hL
  have hLr : (L : ℝ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hL)
  have hCr : (C : ℝ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hC)
  dsimp only
  change
    eR ((((h.val : ℝ) / (L : ℝ)) * (d : ℝ)) * (m : ℝ)) =
      eR (((((h.val * C * d : ℕ) : ZMod P).val : ℝ) /
        (P : ℝ)) * (m : ℝ))
  have halg :
      (((h.val : ℝ) / (L : ℝ)) * (d : ℝ)) * (m : ℝ) =
        (((h.val * C * d : ℕ) : ℝ) / (P : ℝ)) * (m : ℝ) := by
    push_cast
    rw [← hmulR]
    field_simp [hLr, hCr]
  rw [halg]
  exact omega_eR_nat_fraction_mod P (h.val * C * d) m

#print axioms omega_eR_nat_fraction_mod
#print axioms lcm_frequency_mul_eq_sixq_frequency

end PaperB.Analytic


namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

lemma sawSmoothPartial_norm_le_pair_uniform_r0002
    {S : ℝ} (hS : 1 < S) (H : ℕ) (y : ℝ) :
    ‖sawSmoothPartial S H (y : AddCircle (1 : ℝ))‖ ≤ 12 / Real.pi := by
  rw [sawSmoothPartial_eq_pair_sum hS]
  simpa using
    (omega_low_transition_moving_fourier_band_uniform
      hS y 0 H (Nat.zero_le H))

theorem coprime_smoothed_partial_Icc_norm_le
    {S : ℝ} (hS : 1 < S)
    (q H : ℕ) {M N : ℕ}
    (hM : 1 ≤ M) (hMN : M ≤ N)
    (phase : ℕ → ℂ) (hphase : ∀ m, ‖phase m‖ ≤ 1)
    (y : ℕ → ℝ) :
    ‖∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          phase m * sawSmoothPartial S H (y m : AddCircle (1 : ℝ)))‖
      ≤ (12 / Real.pi) *
          ((1 : ℝ) / (M : ℝ) +
            (Real.log ((N + 1 : ℕ) : ℝ) - Real.log (M : ℝ))) := by
  have hharm := harmonic_Icc_le_one_div_add_log_ratio hM hMN
  have hC0 : 0 ≤ 12 / Real.pi := by positivity
  calc
    ‖∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          phase m * sawSmoothPartial S H (y m : AddCircle (1 : ℝ)))‖
      ≤ ∑ m ∈ Finset.Icc M N,
          ‖(((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
            phase m * sawSmoothPartial S H
              (y m : AddCircle (1 : ℝ)))‖ := norm_sum_le _ _
    _ ≤ ∑ m ∈ Finset.Icc M N,
          (12 / Real.pi) * ((1 : ℝ) / (m : ℝ)) := by
      apply Finset.sum_le_sum
      intro m hm
      have hmM : M ≤ m := (Finset.mem_Icc.mp hm).1
      have hm1 : 1 ≤ m := hM.trans hmM
      have hmr : (0 : ℝ) < m := by positivity
      have hcop := abs_coprimeIndicatorArithmetic_le_one q m
      have hsaw := sawSmoothPartial_norm_le_pair_uniform_r0002 hS H (y m)
      rw [norm_mul, norm_mul, Complex.norm_real, Real.norm_eq_abs]
      have hdiv :
          |coprimeIndicatorArithmetic q m / (m : ℝ)|
            ≤ (1 : ℝ) / (m : ℝ) := by
        rw [abs_div, abs_of_pos hmr]
        exact div_le_div_of_nonneg_right hcop hmr.le
      calc
        |coprimeIndicatorArithmetic q m / (m : ℝ)| *
            ‖phase m‖ *
            ‖sawSmoothPartial S H (y m : AddCircle (1 : ℝ))‖
          ≤ ((1 : ℝ) / (m : ℝ)) * 1 * (12 / Real.pi) := by
            exact mul_le_mul
              (mul_le_mul hdiv (hphase m) (norm_nonneg _) (by positivity))
              hsaw (by positivity) (by positivity)
        _ = (12 / Real.pi) * ((1 : ℝ) / (m : ℝ)) := by ring
    _ = (12 / Real.pi) *
          ∑ m ∈ Finset.Icc M N, (1 : ℝ) / (m : ℝ) := by
      rw [Finset.mul_sum]
    _ ≤ (12 / Real.pi) *
          ((1 : ℝ) / (M : ℝ) +
            (Real.log ((N + 1 : ℕ) : ℝ) - Real.log (M : ℝ))) :=
      mul_le_mul_of_nonneg_left hharm hC0

#print axioms sawSmoothPartial_norm_le_pair_uniform_r0002
#print axioms coprime_smoothed_partial_Icc_norm_le

end PaperB.Analytic


namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

lemma sawSmoothCoeff_pair_norm_le_reciprocal
    {S : ℝ} (hS : 1 < S) (k : ℕ) :
    ‖sawSmoothCoeff S (k + 1 : ℕ)‖ +
        ‖sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ))‖
      ≤ (1 / Real.pi) * (1 / ((k + 1 : ℕ) : ℝ)) := by
  have hk0p : ((k + 1 : ℕ) : ℤ) ≠ 0 := by omega
  have hp := sawSmoothCoeff_le_linear hS hk0p
  have hn := sawSmoothCoeff_le_linear hS (neg_ne_zero.mpr hk0p)
  have hkR : (0 : ℝ) < (k + 1 : ℕ) := by positivity
  norm_num only [Int.cast_natCast, Int.cast_neg] at hp hn
  rw [abs_of_pos hkR] at hp
  rw [abs_neg, abs_of_pos hkR] at hn
  calc
    ‖sawSmoothCoeff S (k + 1 : ℕ)‖ +
        ‖sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ))‖
      ≤ 1 / (2 * Real.pi * ((k + 1 : ℕ) : ℝ)) +
          1 / (2 * Real.pi * ((k + 1 : ℕ) : ℝ)) :=
        add_le_add hp hn
    _ = (1 / Real.pi) * (1 / ((k + 1 : ℕ) : ℝ)) := by
      field_simp [Real.pi_ne_zero, ne_of_gt hkR]
      ring

theorem sum_range_sawSmoothCoeff_pair_norm_le_log
    {S : ℝ} (hS : 1 < S) (H : ℕ) :
    (∑ k ∈ Finset.range H,
      (‖sawSmoothCoeff S (k + 1 : ℕ)‖ +
        ‖sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ))‖))
      ≤ (1 / Real.pi) *
          (1 + (Real.log ((1 + H : ℕ) : ℝ) - Real.log (1 : ℝ))) := by
  have hh := PaperB.FixedQ.shifted_harmonic_range_le
    (K := 1) (N := H) (by norm_num)
  have hpi : 0 ≤ 1 / Real.pi := by positivity
  calc
    (∑ k ∈ Finset.range H,
      (‖sawSmoothCoeff S (k + 1 : ℕ)‖ +
        ‖sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ))‖))
      ≤ ∑ k ∈ Finset.range H,
          (1 / Real.pi) * (1 / ((k + 1 : ℕ) : ℝ)) := by
        apply Finset.sum_le_sum
        intro k hk
        exact sawSmoothCoeff_pair_norm_le_reciprocal hS k
    _ = (1 / Real.pi) *
          ∑ k ∈ Finset.range H, (1 / ((k + 1 : ℕ) : ℝ)) := by
        rw [Finset.mul_sum]
    _ ≤ (1 / Real.pi) *
          (1 + (Real.log ((1 + H : ℕ) : ℝ) - Real.log (1 : ℝ))) := by
        apply mul_le_mul_of_nonneg_left _ hpi
        simpa [Nat.add_comm] using hh

#print axioms sawSmoothCoeff_pair_norm_le_reciprocal
#print axioms sum_range_sawSmoothCoeff_pair_norm_le_log

end PaperB.Analytic


namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

noncomputable def omegaPSeriesTwo : ℝ :=
  ∑' k : ℕ, 1 / (((k + 1 : ℕ) : ℝ) ^ (2 : ℝ))

noncomputable def omegaPSeriesSevenFourths : ℝ :=
  ∑' k : ℕ, 1 / (((k + 1 : ℕ) : ℝ) ^ (7 / 4 : ℝ))

lemma summable_omegaPSeriesTwo :
    Summable (fun k : ℕ => 1 / (((k + 1 : ℕ) : ℝ) ^ (2 : ℝ))) := by
  have hbase :
      Summable (fun n : ℕ => 1 / ((n : ℝ) ^ (2 : ℝ))) :=
    Real.summable_one_div_nat_rpow.mpr (by norm_num)
  have hs := (_root_.summable_nat_add_iff (f := fun n : ℕ =>
    1 / ((n : ℝ) ^ (2 : ℝ))) 1).2 hbase
  simpa [Nat.add_comm] using hs

lemma summable_omegaPSeriesSevenFourths :
    Summable (fun k : ℕ => 1 / (((k + 1 : ℕ) : ℝ) ^ (7 / 4 : ℝ))) := by
  have hbase :
      Summable (fun n : ℕ => 1 / ((n : ℝ) ^ (7 / 4 : ℝ))) :=
    Real.summable_one_div_nat_rpow.mpr (by norm_num)
  have hs := (_root_.summable_nat_add_iff (f := fun n : ℕ =>
    1 / ((n : ℝ) ^ (7 / 4 : ℝ))) 1).2 hbase
  simpa [Nat.add_comm] using hs

lemma sum_range_one_div_rpow_two_le (H : ℕ) :
    (∑ k ∈ Finset.range H,
      1 / (((k + 1 : ℕ) : ℝ) ^ (2 : ℝ))) ≤ omegaPSeriesTwo := by
  unfold omegaPSeriesTwo
  exact summable_omegaPSeriesTwo.sum_le_tsum
    (Finset.range H) (fun k hk => by positivity)

lemma sum_range_one_div_rpow_seven_fourths_le (H : ℕ) :
    (∑ k ∈ Finset.range H,
      1 / (((k + 1 : ℕ) : ℝ) ^ (7 / 4 : ℝ))) ≤
        omegaPSeriesSevenFourths := by
  unfold omegaPSeriesSevenFourths
  exact summable_omegaPSeriesSevenFourths.sum_le_tsum
    (Finset.range H) (fun k hk => by positivity)

lemma omegaPSeriesTwo_nonneg : 0 ≤ omegaPSeriesTwo :=
  tsum_nonneg (fun _ => by positivity)

lemma omegaPSeriesSevenFourths_nonneg : 0 ≤ omegaPSeriesSevenFourths :=
  tsum_nonneg (fun _ => by positivity)

#print axioms sum_range_one_div_rpow_two_le
#print axioms sum_range_one_div_rpow_seven_fourths_le

end PaperB.Analytic


namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

theorem omegaHighTailSimpleBound_scaled_le
    (q : ℕ) (hq : 0 < q)
    {T : ℝ} (hT : 0 < T)
    {X d k D : ℕ}
    (hd : 1 ≤ d) (hdD : d ≤ D) (hD : 1 ≤ D)
    (hXT : (X : ℝ) ≤ T) :
    omegaHighTailSimpleBound q
        (((k + 1 : ℕ) : ℝ) * T /
          ((Nat.lcm 6 q : ℕ) : ℝ) / (d : ℝ))
        (X / d)
      ≤
      24 * ((6 * q : ℕ) : ℝ) *
          ((Nat.lcm 6 q : ℕ) : ℝ) / ((k + 1 : ℕ) : ℝ) +
        4 * ((6 * q : ℕ) : ℝ) *
          (1 + 2 * ((6 * q : ℕ) : ℝ)) /
          ((T / (((Nat.lcm 6 q : ℕ) : ℝ) * (D : ℝ))) ^
            (3 / 4 : ℝ)) := by
  let L : ℝ := ((Nat.lcm 6 q : ℕ) : ℝ)
  let P : ℝ := ((6 * q : ℕ) : ℝ)
  let A : ℝ := (((k + 1 : ℕ) : ℝ) * T / L / (d : ℝ))
  have hLnat : 0 < Nat.lcm 6 q := Nat.lcm_pos (by norm_num) hq
  have hL : 0 < L := by
    dsimp [L]
    exact_mod_cast hLnat
  have hdR : (0 : ℝ) < d := by positivity
  have hDR : (0 : ℝ) < D := by positivity
  have hkR : (0 : ℝ) < (k + 1 : ℕ) := by positivity
  have hA : 0 < A := by
    dsimp [A]
    positivity
  have hNcast :
      ((X / d : ℕ) : ℝ) ≤ (X : ℝ) / (d : ℝ) := Nat.cast_div_le
  have hXTd :
      (X : ℝ) / (d : ℝ) ≤ T / (d : ℝ) :=
    div_le_div_of_nonneg_right hXT hdR.le
  have hNA :
      ((X / d : ℕ) : ℝ) / A ≤ L / ((k + 1 : ℕ) : ℝ) := by
    have hpre :
        ((X / d : ℕ) : ℝ) / A ≤ (T / (d : ℝ)) / A :=
      div_le_div_of_nonneg_right (hNcast.trans hXTd) hA.le
    calc
      ((X / d : ℕ) : ℝ) / A
        ≤ (T / (d : ℝ)) / A := hpre
      _ = L / ((k + 1 : ℕ) : ℝ) := by
        dsimp [A]
        field_simp [hL.ne', hdR.ne', hT.ne']
  have hbase :
      T / (L * (D : ℝ)) ≤ A := by
    have hdDreal : (d : ℝ) ≤ (D : ℝ) := by exact_mod_cast hdD
    have hk1 : (1 : ℝ) ≤ ((k + 1 : ℕ) : ℝ) := by
      exact_mod_cast (show 1 ≤ k + 1 by omega)
    dsimp [A]
    rw [div_le_div_iff₀ (mul_pos hL hDR) hdR]
    field_simp [hL.ne']
    nlinarith
  have hbasepos : 0 < T / (L * (D : ℝ)) := by positivity
  have hrpow :
      (T / (L * (D : ℝ))) ^ (3 / 4 : ℝ) ≤
        A ^ (3 / 4 : ℝ) :=
    Real.rpow_le_rpow hbasepos.le hbase (by norm_num)
  have hinv :
      1 / (A ^ (3 / 4 : ℝ)) ≤
        1 / ((T / (L * (D : ℝ))) ^ (3 / 4 : ℝ)) := by
    have hbp :
        0 < (T / (L * (D : ℝ))) ^ (3 / 4 : ℝ) :=
      Real.rpow_pos_of_pos hbasepos _
    exact one_div_le_one_div_of_le hbp hrpow
  unfold omegaHighTailSimpleBound
  change
    24 * P * ((X / d : ℕ) : ℝ) / A +
        4 * P * (1 + 2 * P) / (A ^ (3 / 4 : ℝ))
      ≤ 24 * P * L / ((k + 1 : ℕ) : ℝ) +
        4 * P * (1 + 2 * P) /
          ((T / (L * (D : ℝ))) ^ (3 / 4 : ℝ))
  have hC0 : 0 ≤ 4 * P * (1 + 2 * P) := by
    dsimp [P]
    positivity
  calc
    24 * P * ((X / d : ℕ) : ℝ) / A +
        4 * P * (1 + 2 * P) / (A ^ (3 / 4 : ℝ))
      =
        (24 * P) * (((X / d : ℕ) : ℝ) / A) +
          (4 * P * (1 + 2 * P)) *
            (1 / (A ^ (3 / 4 : ℝ))) := by ring
    _ ≤
        (24 * P) * (L / ((k + 1 : ℕ) : ℝ)) +
          (4 * P * (1 + 2 * P)) *
            (1 / ((T / (L * (D : ℝ))) ^ (3 / 4 : ℝ))) := by
      exact add_le_add
        (mul_le_mul_of_nonneg_left hNA (by
          dsimp [P]
          positivity))
        (mul_le_mul_of_nonneg_left hinv hC0)
    _ =
        24 * P * L / ((k + 1 : ℕ) : ℝ) +
          4 * P * (1 + 2 * P) /
            ((T / (L * (D : ℝ))) ^ (3 / 4 : ℝ)) := by ring

#print axioms omegaHighTailSimpleBound_scaled_le

end PaperB.Analytic

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

lemma abs_omegaCorrectionInvTerm_eq_rankin_mul_rpow_neg_quarter
    (q d : ℕ) (hd : d ≠ 0) :
    |omegaCorrectionInvTerm q d| =
      omegaCorrectionRankin q d * (d : ℝ) ^ (-1 / 4 : ℝ) := by
  rw [omegaCorrectionInvTerm, omegaCorrectionRankin, if_neg hd]
  have hdR : (0 : ℝ) < d := by positivity
  rw [abs_div, abs_of_pos hdR]
  rw [div_eq_mul_inv, ← Real.rpow_neg_one]
  have hp :
      (d : ℝ) ^ (-3 / 4 : ℝ) * (d : ℝ) ^ (-1 / 4 : ℝ) =
        (d : ℝ) ^ (-1 : ℝ) := by
    rw [← Real.rpow_add hdR]
    norm_num
  calc
    |omegaLinearCorrectionArithmetic q d| * (d : ℝ) ^ (-1 : ℝ)
      = |omegaLinearCorrectionArithmetic q d| *
          ((d : ℝ) ^ (-3 / 4 : ℝ) * (d : ℝ) ^ (-1 / 4 : ℝ)) := by rw [hp]
    _ = |omegaLinearCorrectionArithmetic q d| *
          (d : ℝ) ^ (-3 / 4 : ℝ) * (d : ℝ) ^ (-1 / 4 : ℝ) := by ring

lemma sum_Icc_abs_omegaCorrectionInvTerm_tail_le
    (q D X : ℕ) (hD : 1 ≤ D) :
    (∑ d ∈ Finset.Icc D X, |omegaCorrectionInvTerm q d|)
      ≤ (D : ℝ) ^ (-1 / 4 : ℝ) * omegaRankinBound := by
  have hDr : (0 : ℝ) < D := by exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hD)
  calc
    (∑ d ∈ Finset.Icc D X, |omegaCorrectionInvTerm q d|)
      = ∑ d ∈ Finset.Icc D X,
          omegaCorrectionRankin q d * (d : ℝ) ^ (-1 / 4 : ℝ) := by
        apply Finset.sum_congr rfl
        intro d hdmem
        have hd0 : d ≠ 0 := by
          have := (Finset.mem_Icc.mp hdmem).1
          omega
        exact abs_omegaCorrectionInvTerm_eq_rankin_mul_rpow_neg_quarter q d hd0
    _ ≤ ∑ d ∈ Finset.Icc D X,
          omegaCorrectionRankin q d * (D : ℝ) ^ (-1 / 4 : ℝ) := by
        apply Finset.sum_le_sum
        intro d hdmem
        have hDd : D ≤ d := (Finset.mem_Icc.mp hdmem).1
        have hdR : (0 : ℝ) < d := by
          have hdNat : 0 < d := lt_of_lt_of_le (lt_of_lt_of_le Nat.zero_lt_one hD) hDd
          exact_mod_cast hdNat
        have hp :
            (d : ℝ) ^ (-1 / 4 : ℝ) ≤ (D : ℝ) ^ (-1 / 4 : ℝ) := by
          exact Real.rpow_le_rpow_of_nonpos hDr
            (by exact_mod_cast hDd) (by norm_num)
        exact mul_le_mul_of_nonneg_left hp
          (omegaCorrectionRankin_nonneg q d)
    _ = (D : ℝ) ^ (-1 / 4 : ℝ) *
          ∑ d ∈ Finset.Icc D X, omegaCorrectionRankin q d := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro d hd
        ring
    _ ≤ (D : ℝ) ^ (-1 / 4 : ℝ) * omegaRankinBound := by
        apply mul_le_mul_of_nonneg_left
        · calc
            (∑ d ∈ Finset.Icc D X, omegaCorrectionRankin q d)
              ≤ ∑' d : ℕ, omegaCorrectionRankin q d := by
                exact (summable_omegaCorrectionRankin q).sum_le_tsum
                  (Finset.Icc D X)
                  (fun d hd => omegaCorrectionRankin_nonneg q d)
            _ ≤ omegaRankinBound := tsum_omegaCorrectionRankin_le_bound q
        · exact Real.rpow_nonneg (by positivity) _

#print axioms abs_omegaCorrectionInvTerm_eq_rankin_mul_rpow_neg_quarter
#print axioms sum_Icc_abs_omegaCorrectionInvTerm_tail_le

end PaperB.Analytic


