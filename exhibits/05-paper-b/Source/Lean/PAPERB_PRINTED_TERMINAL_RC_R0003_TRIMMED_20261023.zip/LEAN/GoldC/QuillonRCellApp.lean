import GoldC.QuillonRContext
import GoldC.QuillonRowNF
import GoldC.QuillonWCellApp

/-!
# Quillon CSC3 F7.7c: the R cell for a fixed `r` (from the source mask to an explicit bound)

For fixed `B` (`r = ∏B`), universe `U = T∖B`, Ramaré set `J ⊆ U ∩ (X, 2^{Kv}X]` and an `s`-mask `Geo`
(convex, `≤ Nb`, `> Lw`), with the row equal to `rowAbs` on masked `s`:

    |Σ_{C⊆U, C≠∅} 1[Kc(|C|) ∧ Geo(∏C) ∧ C∩J≠∅]·ω(C)·F(∏C)| ≤ Σ_{4 types} RTerm,

where `RTerm` is the `R_context` bound with `(S₀, S₁)` replaced by explicit monotone majorants.
The class types are rescaled by `G = 2M·Gb + 1` so that `‖Γ‖ ≤ 1` (`rowR_rescale`).

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonRCellApp

open GoldC.QuillonRContext GoldC.QuillonRBilinear GoldC.QuillonRowNF GoldC.QuillonCells
  GoldC.QuillonWContext GoldC.QuillonWCellApp GoldC.QuillonR GoldC.QuillonCot

/-- `RPsi` is antitone in `Ulo` and monotone in `S₁`. -/
lemma RPsi_mono (c C : ℝ) (hc : 0 < c) (hC : 0 ≤ C) (Q V₀ Ulo Ulo' S₁ S₁' : ℕ) (Y : ℝ)
    (hQ : 1 ≤ Q) (hUlo' : 4 * Q + 2 ≤ Ulo') (hU : Ulo' ≤ Ulo) (hS : S₁ ≤ S₁') (hY : 0 < |Y|) :
    RPsi c C Q V₀ Ulo S₁ Y ≤ RPsi c C Q V₀ Ulo' S₁' Y := by
  unfold RPsi
  have hnlo : 1 ≤ (Ulo' - Q) / Q := by rw [Nat.le_div_iff_mul_le (by omega)]; omega
  have hn : (Ulo' - Q) / Q ≤ (Ulo - Q) / Q := Nat.div_le_div_right (by omega)
  have hlog : Real.log (((Ulo' - Q) / Q : ℕ) : ℝ) ≤ Real.log (((Ulo - Q) / Q : ℕ) : ℝ) :=
    Real.log_le_log (by exact_mod_cast (show 0 < (Ulo' - Q) / Q by omega)) (by exact_mod_cast hn)
  have hlog0 : 0 ≤ Real.log (((Ulo' - Q) / Q : ℕ) : ℝ) := Real.log_nonneg (by exact_mod_cast hnlo)
  have h2 : Real.exp (-(c * Real.log (((Ulo - Q) / Q : ℕ) : ℝ) ^ 3 / Real.log (|Y| / Q) ^ 2)) ≤
      Real.exp (-(c * Real.log (((Ulo' - Q) / Q : ℕ) : ℝ) ^ 3 / Real.log (|Y| / Q) ^ 2)) := by
    apply Real.exp_le_exp.2
    apply neg_le_neg
    apply div_le_div_of_nonneg_right _ (sq_nonneg _)
    exact mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hlog0 hlog 3) hc.le
  have h3 : (S₁ : ℝ) * (1 + Real.log S₁) ≤ S₁' * (1 + Real.log S₁') := by
    rcases Nat.eq_zero_or_pos S₁ with h0 | hpos
    · rw [h0]; simp only [Nat.cast_zero, zero_mul]
      have := Real.log_natCast_nonneg S₁'; positivity
    · have hSR : (S₁ : ℝ) ≤ S₁' := by exact_mod_cast hS
      have hl : Real.log S₁ ≤ Real.log S₁' :=
        Real.log_le_log (by exact_mod_cast hpos) hSR
      have := Real.log_natCast_nonneg S₁
      exact mul_le_mul hSR (by linarith) (by linarith) (by positivity)
  have h3' : 64 * C * S₁ * (1 + Real.log S₁) / |Y| ≤ 64 * C * S₁' * (1 + Real.log S₁') / |Y| := by
    apply div_le_div_of_nonneg_right _ hY.le
    calc 64 * C * S₁ * (1 + Real.log S₁) = 64 * C * ((S₁ : ℝ) * (1 + Real.log S₁)) := by ring
      _ ≤ 64 * C * (S₁' * (1 + Real.log S₁')) := mul_le_mul_of_nonneg_left h3 (by positivity)
      _ = 64 * C * S₁' * (1 + Real.log S₁') := by ring
  exact add_le_add (add_le_add le_rfl (mul_le_mul_of_nonneg_left h2 (by positivity))) h3'

/-- The R bound for one row type. -/
noncomputable def RTerm (c C : ℝ) (𝒦 : Finset ℕ) (coef : ℕ → ℂ) (Ym : ℕ → ℝ) (Q : ℕ)
    (U : Finset ℕ) (X Kv Lw Sb : ℕ) : ℝ :=
  ((((Nat.log 2 Sb + 1) * 2) * Kv : ℕ) : ℝ) * ∑ m ∈ 𝒦, ‖coef m‖ *
      ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 Sb) : ℝ) ^ 30) ^ 2 *
        Real.sqrt (2 * RPsi c C Q X (Lw / (2 ^ Kv * X)) Sb (Ym m))) +
    (∑ m ∈ 𝒦, ‖coef m‖) * (∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3))) * ((12.5 : ℝ) / X)

lemma RTerm_nonneg (c C : ℝ) (𝒦 : Finset ℕ) (coef : ℕ → ℂ) (Ym : ℕ → ℝ) (Q : ℕ)
    (U : Finset ℕ) (X Kv Lw Sb : ℕ) (hU : ∀ p ∈ U, 5 ≤ p) : 0 ≤ RTerm c C 𝒦 coef Ym Q U X Kv Lw Sb := by
  unfold RTerm
  have h1 : 0 ≤ ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) := prod_nonneg fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast hU p hp
    have : 0 ≤ 1 / ((p : ℝ) - 3) := by apply div_nonneg zero_le_one; linarith
    linarith
  have h2 : 0 ≤ ∑ m ∈ 𝒦, ‖coef m‖ * ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 Sb) : ℝ) ^ 30) ^ 2 *
        Real.sqrt (2 * RPsi c C Q X (Lw / (2 ^ Kv * X)) Sb (Ym m))) :=
    sum_nonneg fun _ _ => by positivity
  have h3 : 0 ≤ ∑ m ∈ 𝒦, ‖coef m‖ := sum_nonneg fun _ _ => norm_nonneg _
  positivity

/-- `R_context` with explicit majorants for `(S₀, S₁)`. -/
lemma R_context_explicit (c C : ℝ) (hc : 0 < c) (hC : 0 ≤ C)
    (hcab : ∀ (Q ρ N M : ℕ) (Y : ℝ) (A : ℕ → ℂ), 1 ≤ Q → ρ < Q → 1 ≤ N → N ≤ M → M ≤ 2 * N →
        2 * (Q : ℝ) ≤ |Y| →
        ‖∑ t ∈ Ioc N M, A t * eR (Y / ((ρ : ℝ) + Q * t))‖ ≤
          (‖A M‖ + ∑ n ∈ Ico (N + 1) M, ‖A (n + 1) - A n‖) *
            (C * ((N : ℝ) * Real.exp (-(c * Real.log (N : ℝ) ^ 3 / Real.log (|Y| / Q) ^ 2)) +
              (N : ℝ) ^ 2 / (|Y| / Q))))
    (𝒦 : Finset ℕ) (coef : ℕ → ℂ) (jm Lm : ℕ → ℕ) (Ym : ℕ → ℝ) (Γ : ℕ → ℕ → ℂ)
    (hjm : ∀ m ∈ 𝒦, 1 ≤ jm m) (hLm : ∀ m ∈ 𝒦, 1 ≤ Lm m) (hΓ : ∀ m ∈ 𝒦, ∀ x, ‖Γ m x‖ ≤ 1)
    (Q : ℕ) (hQ : 1 ≤ Q) (U J : Finset ℕ) (hJU : J ⊆ U) (hU : ∀ p ∈ U, p.Prime ∧ 5 ≤ p)
    (X Kv S₀ S₁ Lw Sb : ℕ) (hX : 2 ≤ X) (hJ : ∀ p ∈ J, X < p ∧ p ≤ 2 ^ Kv * X)
    (hUlo : 4 * Q + 2 ≤ Lw / (2 ^ Kv * X)) (hLS : Lw ≤ S₀) (hSb : S₁ ≤ Sb)
    (hY : ∀ m ∈ 𝒦, 8 * (Q : ℝ) * ((2 ^ Kv * X : ℕ) : ℝ) ^ 2 ≤ |Ym m|) (Kset : Finset ℕ) :
    ‖∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty), (ωR B : ℂ) *
        (if (∏ p ∈ B, p) ∈ Ioc S₀ S₁ ∧ B.card ∈ Kset then
          rowR 𝒦 coef jm Lm Ym Γ Q (∏ p ∈ B, p) else 0)‖ ≤
      RTerm c C 𝒦 coef Ym Q U X Kv Lw Sb := by
  have hdiv : Lw / (2 ^ Kv * X) ≤ S₀ / (2 ^ Kv * X) := Nat.div_le_div_right hLS
  refine (R_context c C hc hC hcab 𝒦 coef jm Lm Ym Γ hjm hLm hΓ Q hQ U J hJU hU X Kv S₀ S₁ hX hJ
    (hUlo.trans hdiv) hY Kset).trans ?_
  unfold RTerm
  have hlog : Nat.log 2 S₁ ≤ Nat.log 2 Sb := Nat.log_mono_right hSb
  have hKu : ((((Nat.log 2 S₁ + 1) * 2) * Kv : ℕ) : ℝ) ≤ ((((Nat.log 2 Sb + 1) * 2) * Kv : ℕ) : ℝ) := by
    exact_mod_cast Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (Nat.add_le_add_right hlog 1))
  have hAω : (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 S₁) : ℝ) ^ 30) ^ 2 ≤
      (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 Sb) : ℝ) ^ 30) ^ 2 := by
    have hm : (Nat.log 2 (Nat.log 2 S₁) : ℝ) ≤ Nat.log 2 (Nat.log 2 Sb) := by
      exact_mod_cast Nat.log_mono_right hlog
    gcongr
  have hQR : (0 : ℝ) < Q := by exact_mod_cast hQ
  have hVt : (0 : ℝ) < ((2 ^ Kv * X : ℕ) : ℝ) := by
    have : 0 < 2 ^ Kv * X := by positivity
    exact_mod_cast this
  have hS : ∑ m ∈ 𝒦, ‖coef m‖ * ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 S₁) : ℝ) ^ 30) ^ 2 *
        Real.sqrt (2 * RPsi c C Q X (S₀ / (2 ^ Kv * X)) S₁ (Ym m))) ≤
      ∑ m ∈ 𝒦, ‖coef m‖ * ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 Sb) : ℝ) ^ 30) ^ 2 *
        Real.sqrt (2 * RPsi c C Q X (Lw / (2 ^ Kv * X)) Sb (Ym m))) := by
    refine sum_le_sum fun m hm => ?_
    apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
    apply mul_le_mul hAω _ (Real.sqrt_nonneg _) (by positivity)
    have hYm : 0 < |Ym m| := lt_of_lt_of_le (by positivity) (hY m hm)
    have := RPsi_mono c C hc hC Q X (S₀ / (2 ^ Kv * X)) (Lw / (2 ^ Kv * X)) S₁ Sb (Ym m) hQ hUlo hdiv
      hSb hYm
    exact Real.sqrt_le_sqrt (by linarith)
  have hS0 : 0 ≤ ∑ m ∈ 𝒦, ‖coef m‖ * ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 S₁) : ℝ) ^ 30) ^ 2 *
        Real.sqrt (2 * RPsi c C Q X (S₀ / (2 ^ Kv * X)) S₁ (Ym m))) :=
    sum_nonneg fun _ _ => by positivity
  refine add_le_add ?_ le_rfl
  exact mul_le_mul hKu hS hS0 (by positivity)

lemma norm_ΓmR (r H : ℕ) (z : ℤ) (σ : ℕ) : ‖ΓmR r H z σ‖ = 1 := by
  unfold ΓmR; exact norm_eR _

lemma norm_cbR_le (M H : ℕ) (Γ : ℕ → ℕ → ℝ) (Gb : ℝ) (hGb : ∀ b ν, |Γ b ν| ≤ Gb)
    (r b : ℕ) (z : ℤ) (σ : ℕ) : ‖cbR M H Γ r b z σ‖ ≤ 2 * Gb := by
  unfold cbR
  rw [norm_mul, norm_mul, norm_mul, norm_eR, norm_eR, Complex.norm_real, Real.norm_eq_abs]
  have h1 : ‖eR ((z : ℝ) * ((M - 1 : ℕ) : ℝ) / M) - 1‖ ≤ 2 := by
    calc _ ≤ ‖eR ((z : ℝ) * ((M - 1 : ℕ) : ℝ) / M)‖ + ‖(1 : ℂ)‖ := norm_sub_le _ _
      _ = 2 := by rw [norm_eR, norm_one]; norm_num
  have h0 : 0 ≤ Gb := (abs_nonneg _).trans (hGb b 0)
  calc |Γ b ((r * σ) % M)| * (1 * (1 * ‖eR ((z : ℝ) * ((M - 1 : ℕ) : ℝ) / M) - 1‖)) ≤ Gb * (1 * (1 * 2)) := by
        gcongr
        exact hGb _ _
    _ = 2 * Gb := by ring

lemma norm_ΓcR_le (M H : ℕ) (Γ : ℕ → ℕ → ℝ) (Gb : ℝ) (hGb : ∀ b ν, |Γ b ν| ≤ Gb)
    (r : ℕ) (z : ℤ) (σ : ℕ) : ‖ΓcR M H Γ r z σ‖ ≤ 2 * M * Gb := by
  unfold ΓcR
  refine (norm_sum_le _ _).trans ?_
  calc ∑ b ∈ range M, ‖cbR M H Γ r b z σ‖ ≤ ∑ _b ∈ range M, 2 * Gb :=
        sum_le_sum fun b _ => norm_cbR_le M H Γ Gb hGb r b z σ
    _ = 2 * M * Gb := by rw [sum_const, card_range, nsmul_eq_mul]; ring

/-- **The R cell for a fixed `r`.** -/
theorem R_cell (c C : ℝ) (hc : 0 < c) (hC : 0 ≤ C)
    (hcab : ∀ (Q ρ N M : ℕ) (Y : ℝ) (A : ℕ → ℂ), 1 ≤ Q → ρ < Q → 1 ≤ N → N ≤ M → M ≤ 2 * N →
        2 * (Q : ℝ) ≤ |Y| →
        ‖∑ t ∈ Ioc N M, A t * eR (Y / ((ρ : ℝ) + Q * t))‖ ≤
          (‖A M‖ + ∑ n ∈ Ico (N + 1) M, ‖A (n + 1) - A n‖) *
            (C * ((N : ℝ) * Real.exp (-(c * Real.log (N : ℝ) ^ 3 / Real.log (|Y| / Q) ^ 2)) +
              (N : ℝ) ^ 2 / (|Y| / Q))))
    (M H : ℕ) (μ : ℝ) (Γ : ℕ → ℕ → ℝ) (hM : 2 ≤ M) (Gb : ℝ) (hGb : ∀ b ν, |Γ b ν| ≤ Gb)
    (T B : Finset ℕ) (hT : ∀ p ∈ T, p.Prime ∧ 5 ≤ p ∧ p.Coprime M ∧ p.Coprime H) (hBT : B ⊆ T)
    (r : ℕ) (hrB : r = ∏ p ∈ B, p) (hr2 : 2 ≤ r)
    (J : Finset ℕ) (hJU : J ⊆ T \ B) (X Kv : ℕ) (hX : 2 ≤ X) (hJ : ∀ p ∈ J, X < p ∧ p ≤ 2 ^ Kv * X)
    (Kc : ℕ → Prop) [DecidablePred Kc] (Geo : ℕ → Prop) [DecidablePred Geo] (Nb Lw : ℕ)
    (hbdd : ∀ s, Geo s → s ≤ Nb) (hlow : ∀ s, Geo s → Lw < s)
    (hconv : ∀ a b c, a ≤ b → b ≤ c → Geo a → Geo c → Geo b)
    (hUlo : 4 * (M * r) + 2 ≤ Lw / (2 ^ Kv * X))
    (hHY : 8 * ((M * r : ℕ) : ℝ) * ((2 ^ Kv * X : ℕ) : ℝ) ^ 2 ≤ (H : ℝ) / ((M * r : ℕ) : ℝ))
    (F : ℕ → ℝ) (hF : ∀ C ⊆ T \ B, C ≠ ∅ → Geo (∏ p ∈ C, p) → F (∏ p ∈ C, p) = rowAbs M H μ Γ r (∏ p ∈ C, p))
    (Jm : ℕ) (hJm : M * max Nb Lw ≤ 2 * Jm) :
    |∑ C ∈ (T \ B).powerset.filter (fun C => C ≠ ∅),
        (if (Kc C.card ∧ Geo (∏ p ∈ C, p)) ∧ (C ∩ J).Nonempty then ωR C * F (∏ p ∈ C, p) else 0)| ≤
      RTerm c C (Icc 1 Jm) (fun k => ((-(2 * μ) : ℝ) : ℂ) * βk k) (fun k => (((k : ℤ) * H : ℤ) : ℝ) / r)
          (M * r) (T \ B) X Kv Lw (max Nb Lw) +
        RTerm c C (Icc 1 Jm) (fun k => -(((-(2 * μ) : ℝ) : ℂ) * βk k))
          (fun k => (((-(k : ℤ)) * H : ℤ) : ℝ) / r) (M * r) (T \ B) X Kv Lw (max Nb Lw) +
        RTerm c C (Icc 1 Jm) (fun k => (((2 * M * Gb + 1 : ℝ)) : ℂ) * βk k)
          (fun k => (((k : ℤ) * H : ℤ) : ℝ) / ((M * r : ℕ) : ℝ)) (M * r) (T \ B) X Kv Lw (max Nb Lw) +
        RTerm c C (Icc 1 Jm) (fun k => (((2 * M * Gb + 1 : ℝ)) : ℂ) * -βk k)
          (fun k => (((-(k : ℤ)) * H : ℤ) : ℝ) / ((M * r : ℕ) : ℝ)) (M * r) (T \ B) X Kv Lw (max Nb Lw) := by
  classical
  set U := T \ B with hUdef
  set Sb := max Nb Lw with hSb
  have hU5 : ∀ p ∈ U, 5 ≤ p := fun p hp => (hT p (sdiff_subset hp)).2.1
  have hGb0 : 0 ≤ Gb := (abs_nonneg _).trans (hGb 0 0)
  set G : ℝ := 2 * M * Gb + 1 with hG
  have hGpos : 0 < G := by positivity
  have hGC : ((G : ℝ) : ℂ) ≠ 0 := by exact_mod_cast hGpos.ne'
  have hRHS0 := add_nonneg (add_nonneg (add_nonneg
    (RTerm_nonneg c C (Icc 1 Jm) (fun k => ((-(2 * μ) : ℝ) : ℂ) * βk k)
      (fun k => (((k : ℤ) * H : ℤ) : ℝ) / r) (M * r) U X Kv Lw Sb hU5)
    (RTerm_nonneg c C (Icc 1 Jm) (fun k => -(((-(2 * μ) : ℝ) : ℂ) * βk k))
      (fun k => (((-(k : ℤ)) * H : ℤ) : ℝ) / r) (M * r) U X Kv Lw Sb hU5))
    (RTerm_nonneg c C (Icc 1 Jm) (fun k => ((G : ℝ) : ℂ) * βk k)
      (fun k => (((k : ℤ) * H : ℤ) : ℝ) / ((M * r : ℕ) : ℝ)) (M * r) U X Kv Lw Sb hU5))
    (RTerm_nonneg c C (Icc 1 Jm) (fun k => ((G : ℝ) : ℂ) * -βk k)
      (fun k => (((-(k : ℤ)) * H : ℤ) : ℝ) / ((M * r : ℕ) : ℝ)) (M * r) U X Kv Lw Sb hU5)
  obtain ⟨S₀, S₁, hLS, hS₁, hGeo⟩ := exists_Ioc_of_convex Geo Nb Lw hbdd hlow hconv
  rw [cell_sum_Ioc U J Kc Geo S₀ S₁ hGeo (fun C => ωR C * F (∏ p ∈ C, p))]
  rcases le_or_gt S₁ S₀ with hS | hS
  · rw [sum_eq_zero fun C _ => by
      rw [if_neg]; rintro ⟨h1, _⟩; have := mem_Ioc.1 h1; omega]
    rw [abs_zero]; exact hRHS0
  have hTp : ∀ p ∈ T, p.Prime := fun p hp => (hT p hp).1
  have hBp : ∀ p ∈ B, p.Prime := fun p hp => hTp p (hBT hp)
  have hUP : ∀ p ∈ U, p.Prime ∧ 5 ≤ p := fun p hp => ⟨(hT p (sdiff_subset hp)).1, hU5 p hp⟩
  have hMr : 1 ≤ M * r := by nlinarith
  have hHMr : ∀ k : ℕ, 1 ≤ k → (H : ℝ) / ((M * r : ℕ) : ℝ) ≤ |(((k : ℤ) * H : ℤ) : ℝ) / ((M * r : ℕ) : ℝ)| ∧
      (H : ℝ) / ((M * r : ℕ) : ℝ) ≤ |(((-(k : ℤ)) * H : ℤ) : ℝ) / ((M * r : ℕ) : ℝ)| ∧
      (H : ℝ) / ((M * r : ℕ) : ℝ) ≤ |(((k : ℤ) * H : ℤ) : ℝ) / r| ∧
      (H : ℝ) / ((M * r : ℕ) : ℝ) ≤ |(((-(k : ℤ)) * H : ℤ) : ℝ) / r| := by
    intro k hk
    have hkR : (1 : ℝ) ≤ k := by exact_mod_cast hk
    have hMrR : (0 : ℝ) < ((M * r : ℕ) : ℝ) := by exact_mod_cast hMr
    have hrR : (0 : ℝ) < r := by exact_mod_cast (show 0 < r by omega)
    have hH0 : (0 : ℝ) ≤ H := Nat.cast_nonneg _
    have hrMr : (r : ℝ) ≤ ((M * r : ℕ) : ℝ) := by
      exact_mod_cast Nat.le_mul_of_pos_left r (by omega)
    have e1 : |(((k : ℤ) * H : ℤ) : ℝ)| = k * H := by
      push_cast; rw [abs_of_nonneg (by positivity)]
    have e2 : |(((-(k : ℤ)) * H : ℤ) : ℝ)| = k * H := by
      push_cast; rw [neg_mul, abs_neg, abs_of_nonneg (by positivity)]
    have hkH : (H : ℝ) ≤ k * H := by nlinarith
    refine ⟨?_, ?_, ?_, ?_⟩
    · rw [abs_div, e1, abs_of_pos hMrR]; exact div_le_div_of_nonneg_right hkH hMrR.le
    · rw [abs_div, e2, abs_of_pos hMrR]; exact div_le_div_of_nonneg_right hkH hMrR.le
    · rw [abs_div, e1, abs_of_pos hrR]
      calc (H : ℝ) / ((M * r : ℕ) : ℝ) ≤ H / r := div_le_div_of_nonneg_left hH0 hrR hrMr
        _ ≤ k * H / r := div_le_div_of_nonneg_right hkH hrR.le
    · rw [abs_div, e2, abs_of_pos hrR]
      calc (H : ℝ) / ((M * r : ℕ) : ℝ) ≤ H / r := div_le_div_of_nonneg_left hH0 hrR hrMr
        _ ≤ k * H / r := div_le_div_of_nonneg_right hkH hrR.le
  have hK1 : ∀ k ∈ Icc 1 Jm, 1 ≤ k := fun k hk => (mem_Icc.1 hk).1
  have hJ' : ∀ p ∈ J, X < p ∧ p ≤ 2 ^ Kv * X := hJ
  -- expansion
  set Rτ : (ℕ → ℂ) → (ℕ → ℕ) → (ℕ → ℝ) → (ℕ → ℕ → ℂ) → ℂ := fun coef Lm Ym Γm =>
    ∑ C ∈ U.powerset.filter (fun C => (C ∩ J).Nonempty), (ωR C : ℂ) *
      (if (∏ p ∈ C, p) ∈ Ioc S₀ S₁ ∧ C.card ∈ (range (U.card + 1)).filter Kc then
        rowR (Icc 1 Jm) coef (fun k => k) Lm Ym Γm (M * r) (∏ p ∈ C, p) else 0) with hRτ
  have hexp : ((∑ C ∈ U.powerset.filter (fun C => (C ∩ J).Nonempty),
      (if (∏ p ∈ C, p) ∈ Ioc S₀ S₁ ∧ C.card ∈ (range (U.card + 1)).filter Kc then
        ωR C * F (∏ p ∈ C, p) else 0) : ℝ) : ℂ) =
      Rτ (fun k => ((-(2 * μ) : ℝ) : ℂ) * βk k) (fun _ => 1) (fun k => (((k : ℤ) * H : ℤ) : ℝ) / r)
          (fun k σ => ΓmR r H k σ) +
        Rτ (fun k => -(((-(2 * μ) : ℝ) : ℂ) * βk k)) (fun _ => 1)
          (fun k => (((-(k : ℤ)) * H : ℤ) : ℝ) / r) (fun k σ => ΓmR r H (-(k : ℤ)) σ) +
        Rτ (fun k => ((G : ℝ) : ℂ) * βk k) (fun _ => M)
          (fun k => (((k : ℤ) * H : ℤ) : ℝ) / ((M * r : ℕ) : ℝ))
          (fun k σ => ((G : ℝ) : ℂ)⁻¹ * ΓcR M H Γ r k σ) +
        Rτ (fun k => ((G : ℝ) : ℂ) * -βk k) (fun _ => M)
          (fun k => (((-(k : ℤ)) * H : ℤ) : ℝ) / ((M * r : ℕ) : ℝ))
          (fun k σ => ((G : ℝ) : ℂ)⁻¹ * ΓcR M H Γ r (-(k : ℤ)) σ) := by
    simp only [hRτ, ← sum_add_distrib]
    rw [Complex.ofReal_sum]
    refine sum_congr rfl fun C hC => ?_
    have hCU := mem_powerset.1 (mem_filter.1 hC).1
    have hCne : C ≠ ∅ := by
      rintro rfl; have := (mem_filter.1 hC).2; simp at this
    by_cases hmC : (∏ p ∈ C, p) ∈ Ioc S₀ S₁ ∧ C.card ∈ (range (U.card + 1)).filter Kc
    · simp only [if_pos hmC]
      have hgeo : Geo (∏ p ∈ C, p) := (hGeo _).2 hmC.1
      have hCp : ∀ p ∈ C, p.Prime := fun p hp => hTp p (sdiff_subset (hCU hp))
      have hs2 : 2 ≤ ∏ p ∈ C, p := by
        obtain ⟨p, hp⟩ := nonempty_iff_ne_empty.2 hCne
        have h1 : p ∣ ∏ p ∈ C, p := dvd_prod_of_mem _ hp
        have h2 : 0 < ∏ p ∈ C, p := prod_pos fun q hq => (hCp q hq).pos
        exact le_trans (hCp p hp).two_le (Nat.le_of_dvd h2 h1)
      have hrs : r.Coprime (∏ p ∈ C, p) := by
        rw [hrB]; exact coprime_prod_primes B C hBp hCp
          (by rw [disjoint_left]; intro p hp hpC; exact (mem_sdiff.1 (hCU hpC)).2 hp)
      have hsM : (∏ p ∈ C, p).Coprime M :=
        Nat.Coprime.prod_left fun q hq => (hT q (sdiff_subset (hCU hq))).2.2.1
      have hHs : H.Coprime (∏ p ∈ C, p) :=
        Nat.Coprime.prod_right fun q hq => ((hT q (sdiff_subset (hCU hq))).2.2.2).symm
      have hsS : ∏ p ∈ C, p ≤ Sb := (mem_Ioc.1 hmC.1).2.trans hS₁
      have hJm' : M * (∏ p ∈ C, p) ≤ 2 * Jm := le_trans (Nat.mul_le_mul_left M hsS) hJm
      rw [Complex.ofReal_mul, hF C hCU hCne hgeo,
        rowAbs_eq_rowR M H μ Γ r _ hM hr2 hs2 hrs hsM hHs Jm hJm',
        rowR_rescale (Icc 1 Jm) (fun k => βk k) (fun k => k) (fun _ => M) _ _ (M * r) _ _ hGC,
        rowR_rescale (Icc 1 Jm) (fun k => -βk k) (fun k => k) (fun _ => M) _ _ (M * r) _ _ hGC]
      ring
    · simp only [if_neg hmC, Complex.ofReal_zero]; ring
  rw [← Real.norm_eq_abs, ← Complex.norm_real, hexp]
  have hΓc : ∀ (z : ℤ) σ, ‖((G : ℝ) : ℂ)⁻¹ * ΓcR M H Γ r z σ‖ ≤ 1 := by
    intro z σ
    rw [norm_mul, norm_inv, Complex.norm_real, Real.norm_eq_abs, abs_of_pos hGpos]
    rw [inv_mul_le_iff₀ hGpos, mul_one]
    have := norm_ΓcR_le M H Γ Gb hGb r z σ
    linarith
  refine (norm_add_le _ _).trans (add_le_add ((norm_add_le _ _).trans (add_le_add
    ((norm_add_le _ _).trans (add_le_add ?_ ?_)) ?_)) ?_)
  · exact R_context_explicit c C hc hC hcab (Icc 1 Jm) _ (fun k => k) (fun _ => 1) _ _ hK1
      (fun _ _ => le_rfl) (fun k _ σ => (norm_ΓmR r H k σ).le) (M * r) hMr U J hJU hUP X Kv S₀ S₁ Lw Sb hX hJ'
      hUlo hLS hS₁ (fun k hk => hHY.trans (hHMr k (hK1 k hk)).2.2.1) _
  · exact R_context_explicit c C hc hC hcab (Icc 1 Jm) _ (fun k => k) (fun _ => 1) _ _ hK1
      (fun _ _ => le_rfl) (fun k _ σ => (norm_ΓmR r H _ σ).le) (M * r) hMr U J hJU hUP X Kv S₀ S₁ Lw Sb hX hJ'
      hUlo hLS hS₁ (fun k hk => hHY.trans (hHMr k (hK1 k hk)).2.2.2) _
  · exact R_context_explicit c C hc hC hcab (Icc 1 Jm) _ (fun k => k) (fun _ => M) _ _ hK1
      (fun _ _ => by omega) (fun k _ σ => hΓc _ σ) (M * r) hMr U J hJU hUP X Kv S₀ S₁ Lw Sb hX hJ'
      hUlo hLS hS₁ (fun k hk => hHY.trans (hHMr k (hK1 k hk)).1) _
  · exact R_context_explicit c C hc hC hcab (Icc 1 Jm) _ (fun k => k) (fun _ => M) _ _ hK1
      (fun _ _ => by omega) (fun k _ σ => hΓc _ σ) (M * r) hMr U J hJU hUP X Kv S₀ S₁ Lw Sb hX hJ'
      hUlo hLS hS₁ (fun k hk => hHY.trans (hHMr k (hK1 k hk)).2.1) _

end GoldC.QuillonRCellApp

#print axioms GoldC.QuillonRCellApp.RPsi_mono
#print axioms GoldC.QuillonRCellApp.R_context_explicit
#print axioms GoldC.QuillonRCellApp.R_cell
