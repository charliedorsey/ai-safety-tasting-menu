import PaperB.FixedQ.H2BooleanDyadicSecondMoment
import Mathlib.Analysis.Complex.ExponentialBounds

namespace PaperB.FixedQ

noncomputable def h2BooleanRoughCutoff (M : ℕ) : ℕ :=
  ⌊Real.exp ((Real.log (M : ℝ)) ^ h2BooleanTheta)⌋₊

lemma h2BooleanTheta_pos : 0 < h2BooleanTheta := by
  norm_num [h2BooleanTheta]

lemma h2BooleanRoughCutoff_log_base_nonneg
    {M : ℕ} (hM : 1 ≤ M) :
    0 ≤ (Real.log (M : ℝ)) ^ h2BooleanTheta := by
  have hlog : 0 ≤ Real.log (M : ℝ) :=
    Real.log_nonneg (by exact_mod_cast hM)
  exact Real.rpow_nonneg hlog _

lemma h2BooleanRoughCutoff_one_le
    {M : ℕ} (hM : 1 ≤ M) :
    1 ≤ h2BooleanRoughCutoff M := by
  unfold h2BooleanRoughCutoff
  apply (Nat.one_le_floor_iff _).2
  have hA0 := h2BooleanRoughCutoff_log_base_nonneg hM
  rw [← Real.exp_zero]
  exact Real.exp_monotone hA0

lemma h2BooleanRoughCutoff_cast_le_exp
    (M : ℕ) :
    (h2BooleanRoughCutoff M : ℝ) ≤
      Real.exp ((Real.log (M : ℝ)) ^ h2BooleanTheta) := by
  unfold h2BooleanRoughCutoff
  exact Nat.floor_le (Real.exp_pos _).le

lemma h2BooleanRoughCutoff_exp_lt_succ
    (M : ℕ) :
    Real.exp ((Real.log (M : ℝ)) ^ h2BooleanTheta) <
      (h2BooleanRoughCutoff M + 1 : ℕ) := by
  unfold h2BooleanRoughCutoff
  simpa using
    (Nat.lt_floor_add_one
      (Real.exp ((Real.log (M : ℝ)) ^ h2BooleanTheta) : ℝ))

lemma h2BooleanRoughCutoff_log_le
    {M : ℕ} (hM : 1 ≤ M) :
    Real.log (h2BooleanRoughCutoff M : ℝ) ≤
      (Real.log (M : ℝ)) ^ h2BooleanTheta := by
  have hY1 := h2BooleanRoughCutoff_one_le hM
  have hYpos : (0 : ℝ) < h2BooleanRoughCutoff M := by
    exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hY1)
  have hexppos : 0 < Real.exp ((Real.log (M : ℝ)) ^ h2BooleanTheta) :=
    Real.exp_pos _
  have hle := h2BooleanRoughCutoff_cast_le_exp M
  have hlogle := Real.strictMonoOn_log.monotoneOn hYpos hexppos hle
  simpa using hlogle

lemma h2BooleanRoughCutoff_log_succ_ge
    (M : ℕ) :
    (Real.log (M : ℝ)) ^ h2BooleanTheta ≤
      Real.log ((h2BooleanRoughCutoff M + 1 : ℕ) : ℝ) := by
  have hexppos : 0 < Real.exp ((Real.log (M : ℝ)) ^ h2BooleanTheta) :=
    Real.exp_pos _
  have hlt := h2BooleanRoughCutoff_exp_lt_succ M
  have hsuccpos : (0 : ℝ) < ((h2BooleanRoughCutoff M + 1 : ℕ) : ℝ) := by
    positivity
  have hloglt := Real.strictMonoOn_log hexppos hsuccpos hlt
  rw [Real.log_exp] at hloglt
  exact hloglt.le

#print axioms h2BooleanRoughCutoff_log_le
#print axioms h2BooleanRoughCutoff_log_succ_ge

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma h2BooleanRoughCutoff_loglog_succ_ge
    {M : ℕ} (hM : 2 ≤ M) :
    h2BooleanTheta * Real.log (Real.log (M : ℝ)) ≤
      Real.log (Real.log ((h2BooleanRoughCutoff M + 1 : ℕ) : ℝ)) := by
  have hM1 : (1 : ℝ) < (M : ℝ) := by exact_mod_cast (show 1 < M by omega)
  have hLpos : 0 < Real.log (M : ℝ) := Real.log_pos hM1
  have hApos : 0 < (Real.log (M : ℝ)) ^ h2BooleanTheta :=
    Real.rpow_pos_of_pos hLpos _
  have hbase := h2BooleanRoughCutoff_log_succ_ge M
  have hYspos : 0 < Real.log ((h2BooleanRoughCutoff M + 1 : ℕ) : ℝ) :=
    hApos.trans_le hbase
  have hlog := Real.strictMonoOn_log.monotoneOn hApos hYspos hbase
  rw [Real.log_rpow hLpos h2BooleanTheta] at hlog
  exact hlog

lemma h2BooleanRoughCutoff_smooth_rpow_le
    {M : ℕ} (hM : 2 ≤ M) :
    (Real.log (h2BooleanRoughCutoff M : ℝ)) ^ (h2BooleanV0 / 2) ≤
      (Real.log (M : ℝ)) ^ (h2BooleanTheta * (h2BooleanV0 / 2)) := by
  have hMone : 1 ≤ M := by omega
  have hY1 := h2BooleanRoughCutoff_one_le hMone
  have hlogY0 : 0 ≤ Real.log (h2BooleanRoughCutoff M : ℝ) :=
    Real.log_nonneg (by exact_mod_cast hY1)
  have hlogM0 : 0 ≤ Real.log (M : ℝ) :=
    Real.log_nonneg (by exact_mod_cast hMone)
  have hcut := h2BooleanRoughCutoff_log_le hMone
  have hvhalf0 : 0 ≤ h2BooleanV0 / 2 :=
    div_nonneg h2BooleanV0_nonneg (by norm_num)
  have hp := Real.rpow_le_rpow hlogY0 hcut hvhalf0
  calc
    (Real.log (h2BooleanRoughCutoff M : ℝ)) ^ (h2BooleanV0 / 2)
      ≤ ((Real.log (M : ℝ)) ^ h2BooleanTheta) ^ (h2BooleanV0 / 2) := hp
    _ = (Real.log (M : ℝ)) ^
        (h2BooleanTheta * (h2BooleanV0 / 2)) := by
          symm
          exact Real.rpow_mul hlogM0 h2BooleanTheta (h2BooleanV0 / 2)

lemma h2Boolean_source_exponent_identity :
    (h2BooleanV0 * (1 - h2BooleanTheta) - 1) +
        h2BooleanTheta * (h2BooleanV0 / 2) =
      h2BooleanX0 - 1 := by
  rw [← h2BooleanL2Exponent_eq_firstExponent]
  rw [← h2Boolean_exponent_split]
  ring

#print axioms h2BooleanRoughCutoff_loglog_succ_ge
#print axioms h2BooleanRoughCutoff_smooth_rpow_le
#print axioms h2Boolean_source_exponent_identity

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma h2BooleanSecondRough_primeMass_cutoff_le
    {q M X k : ℕ}
    (hM : 2 ≤ M)
    (hY2 : 2 ≤ h2BooleanRoughCutoff M)
    (hYX : h2BooleanRoughCutoff M ≤ X)
    (hX : 4 ≤ X) :
    PaperB.M4B.primeMass
        (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
          h2BooleanSecondTilt) X k ≤
      h2BooleanV0 *
        (Real.log (Real.log (X : ℝ)) -
          h2BooleanTheta * Real.log (Real.log (M : ℝ)) + 6) + 24 := by
  have hraw := h2BooleanSecondRoughTiltLift_primeMass_le
    q (h2BooleanRoughCutoff M) X k hY2 hYX hX
  have hlower := h2BooleanRoughCutoff_loglog_succ_ge hM
  have hinside :
      Real.log (Real.log (X : ℝ)) + 5 -
          (Real.log (Real.log ((h2BooleanRoughCutoff M + 1 : ℕ) : ℝ)) - 1) ≤
        Real.log (Real.log (X : ℝ)) -
          h2BooleanTheta * Real.log (Real.log (M : ℝ)) + 6 := by
    linarith
  exact hraw.trans (add_le_add
    (mul_le_mul_of_nonneg_left hinside h2BooleanV0_nonneg) (le_refl 24))

lemma h2BooleanSecondRough_exp_primeMass_cutoff_le
    {q M X k : ℕ}
    (hM : 2 ≤ M)
    (hY2 : 2 ≤ h2BooleanRoughCutoff M)
    (hYX : h2BooleanRoughCutoff M ≤ X)
    (hX : 4 ≤ X) :
    Real.exp
      (PaperB.M4B.primeMass
        (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
          h2BooleanSecondTilt) X k) ≤
      Real.exp (6 * h2BooleanV0 + 24) *
        (Real.log (X : ℝ)) ^ h2BooleanV0 *
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) := by
  have hpm := h2BooleanSecondRough_primeMass_cutoff_le
    (q := q) (M := M) (X := X) (k := k) hM hY2 hYX hX
  have hM1 : (1 : ℝ) < (M : ℝ) := by exact_mod_cast (show 1 < M by omega)
  have hX1 : (1 : ℝ) < (X : ℝ) := by exact_mod_cast (show 1 < X by omega)
  have hlogM : 0 < Real.log (M : ℝ) := Real.log_pos hM1
  have hlogX : 0 < Real.log (X : ℝ) := Real.log_pos hX1
  have hexp := Real.exp_le_exp.mpr hpm
  calc
    Real.exp
      (PaperB.M4B.primeMass
        (h2BooleanRoughTiltLift q (h2BooleanRoughCutoff M)
          h2BooleanSecondTilt) X k)
      ≤ Real.exp
        (h2BooleanV0 *
          (Real.log (Real.log (X : ℝ)) -
            h2BooleanTheta * Real.log (Real.log (M : ℝ)) + 6) + 24) := hexp
    _ = Real.exp (6 * h2BooleanV0 + 24) *
        Real.exp (h2BooleanV0 * Real.log (Real.log (X : ℝ))) *
        Real.exp ((-h2BooleanTheta * h2BooleanV0) *
          Real.log (Real.log (M : ℝ))) := by
          rw [show
            h2BooleanV0 *
                (Real.log (Real.log (X : ℝ)) -
                  h2BooleanTheta * Real.log (Real.log (M : ℝ)) + 6) + 24 =
              (6 * h2BooleanV0 + 24) +
                h2BooleanV0 * Real.log (Real.log (X : ℝ)) +
                ((-h2BooleanTheta * h2BooleanV0) *
                  Real.log (Real.log (M : ℝ))) by ring]
          rw [Real.exp_add, Real.exp_add]
    _ = Real.exp (6 * h2BooleanV0 + 24) *
        (Real.log (X : ℝ)) ^ h2BooleanV0 *
        (Real.log (M : ℝ)) ^ (-h2BooleanTheta * h2BooleanV0) := by
          rw [Real.rpow_def_of_pos hlogX, Real.rpow_def_of_pos hlogM]
          congr 2 <;> ring

#print axioms h2BooleanSecondRough_exp_primeMass_cutoff_le

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def h2BooleanTailEpsilon (M : ℕ) : ℝ :=
  (Real.log (M : ℝ)) ^ (-h2BooleanTheta)

lemma h2BooleanTailEpsilon_pos
    {M : ℕ} (hM : 2 ≤ M) : 0 < h2BooleanTailEpsilon M := by
  unfold h2BooleanTailEpsilon
  have hM1 : (1 : ℝ) < (M : ℝ) := by exact_mod_cast (show 1 < M by omega)
  exact Real.rpow_pos_of_pos (Real.log_pos hM1) _

lemma h2BooleanTailEpsilon_le_one
    {M : ℕ} (hlog : 1 ≤ Real.log (M : ℝ)) :
    h2BooleanTailEpsilon M ≤ 1 := by
  unfold h2BooleanTailEpsilon
  have hpos : 0 < Real.log (M : ℝ) := lt_of_lt_of_le zero_lt_one hlog
  rw [Real.rpow_neg hpos.le]
  apply inv_le_one_of_one_le₀
  exact Real.one_le_rpow hlog h2BooleanTheta_pos.le

lemma h2BooleanRoughCutoff_two_le
    {M : ℕ} (hlog : 1 ≤ Real.log (M : ℝ)) :
    2 ≤ h2BooleanRoughCutoff M := by
  unfold h2BooleanRoughCutoff
  apply Nat.le_floor
  have hpow1 : 1 ≤ (Real.log (M : ℝ)) ^ h2BooleanTheta :=
    Real.one_le_rpow hlog h2BooleanTheta_pos.le
  calc
    (2 : ℝ) ≤ Real.exp 1 := Real.exp_one_gt_two.le
    _ ≤ Real.exp ((Real.log (M : ℝ)) ^ h2BooleanTheta) :=
      Real.exp_monotone hpow1

lemma h2BooleanTailEpsilon_mul_cutoffLog_le_one
    {M : ℕ} (hM : 2 ≤ M) :
    h2BooleanTailEpsilon M *
      Real.log (h2BooleanRoughCutoff M : ℝ) ≤ 1 := by
  have hM1 : 1 ≤ M := by omega
  have hM1R : (1 : ℝ) < (M : ℝ) := by exact_mod_cast (show 1 < M by omega)
  have hlogM : 0 < Real.log (M : ℝ) := Real.log_pos hM1R
  have hcut := h2BooleanRoughCutoff_log_le hM1
  have heps0 := (h2BooleanTailEpsilon_pos hM).le
  calc
    h2BooleanTailEpsilon M * Real.log (h2BooleanRoughCutoff M : ℝ)
      ≤ h2BooleanTailEpsilon M *
          ((Real.log (M : ℝ)) ^ h2BooleanTheta) :=
        mul_le_mul_of_nonneg_left hcut heps0
    _ = 1 := by
      unfold h2BooleanTailEpsilon
      rw [← Real.rpow_add hlogM]
      norm_num

lemma h2Boolean_shell_geometric_rankin_bound
    {P : ℕ} {ε : ℝ}
    (hP : 2 ≤ P) (hε0 : 0 < ε) (hε1 : ε ≤ 1) :
    ε * (∑ j ∈ Finset.range (Nat.log 2 P + 1),
      (((2 ^ j : ℕ) : ℝ)) ^ ε) ≤
      (2 / Real.log 2) * (P : ℝ) ^ ε := by
  let q : ℝ := (2 : ℝ) ^ ε
  let M : ℕ := Nat.log 2 P
  have hq1 : 1 < q := by
    dsimp [q]
    exact Real.one_lt_rpow (by norm_num) hε0
  have hq0 : 0 ≤ q := by linarith
  have hq2 : q ≤ 2 := by
    dsimp [q]
    calc
      (2 : ℝ) ^ ε ≤ (2 : ℝ) ^ (1 : ℝ) :=
        Real.rpow_le_rpow_of_exponent_le (by norm_num) hε1
      _ = 2 := by simp
  have hlog2 : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hterm : ∀ j : ℕ,
      (((2 ^ j : ℕ) : ℝ)) ^ ε = q ^ j := by
    intro j
    dsimp [q]
    rw [Nat.cast_pow, Nat.cast_ofNat]
    rw [← Real.rpow_natCast]
    rw [← Real.rpow_mul (by norm_num : (0 : ℝ) ≤ 2)]
    rw [mul_comm]
    rw [Real.rpow_mul (by norm_num : (0 : ℝ) ≤ 2)]
    rw [Real.rpow_natCast]
  have hden : ε * Real.log 2 ≤ q - 1 := by
    have h := Real.add_one_le_exp (ε * Real.log 2)
    have hqexp : q = Real.exp (ε * Real.log 2) := by
      dsimp [q]
      rw [Real.rpow_def_of_pos (by norm_num : (0 : ℝ) < 2)]
      congr 1
      ring
    rw [← hqexp] at h
    linarith
  have hden0 : 0 < q - 1 := sub_pos.mpr hq1
  have hfrac : ε / (q - 1) ≤ 1 / Real.log 2 := by
    apply (div_le_iff₀ hden0).2
    rw [one_div, inv_mul_eq_div, le_div_iff₀ hlog2]
    simpa [mul_comm] using hden
  have hMpowNat : 2 ^ M ≤ P := by
    dsimp [M]
    exact Nat.pow_log_le_self 2 (by omega)
  have hMpowReal : (((2 ^ M : ℕ) : ℝ)) ≤ (P : ℝ) := by
    exact_mod_cast hMpowNat
  have hqM : q ^ M ≤ (P : ℝ) ^ ε := by
    rw [← hterm M]
    exact Real.rpow_le_rpow (by positivity) hMpowReal hε0.le
  have hgeom :
      (∑ j ∈ Finset.range (M + 1), q ^ j) =
        (q ^ (M + 1) - 1) / (q - 1) :=
    geom_sum_eq hq1.ne' (M + 1)
  have hnum0 : 0 ≤ q ^ (M + 1) - 1 :=
    sub_nonneg.mpr (one_le_pow₀ hq1.le)
  have hnumle : q ^ (M + 1) - 1 ≤ q ^ (M + 1) := by linarith
  have hpowSucc : q ^ (M + 1) ≤ 2 * q ^ M := by
    rw [pow_succ]
    nlinarith [pow_nonneg hq0 M]
  change ε * (∑ j ∈ Finset.range (M + 1),
      (((2 ^ j : ℕ) : ℝ)) ^ ε) ≤ _
  calc
    ε * (∑ j ∈ Finset.range (M + 1), (((2 ^ j : ℕ) : ℝ)) ^ ε)
        = ε * (∑ j ∈ Finset.range (M + 1), q ^ j) := by
          congr 1
          apply Finset.sum_congr rfl
          intro j hj
          exact hterm j
    _ = ε * ((q ^ (M + 1) - 1) / (q - 1)) := by rw [hgeom]
    _ = (ε / (q - 1)) * (q ^ (M + 1) - 1) := by ring
    _ ≤ (1 / Real.log 2) * (q ^ (M + 1) - 1) :=
      mul_le_mul_of_nonneg_right hfrac hnum0
    _ ≤ (1 / Real.log 2) * q ^ (M + 1) :=
      mul_le_mul_of_nonneg_left hnumle (by positivity)
    _ ≤ (1 / Real.log 2) * (2 * q ^ M) :=
      mul_le_mul_of_nonneg_left hpowSucc (by positivity)
    _ = (2 / Real.log 2) * q ^ M := by ring
    _ ≤ (2 / Real.log 2) * (P : ℝ) ^ ε :=
      mul_le_mul_of_nonneg_left hqM (by positivity)

lemma h2BooleanTailCorrection_le_const
    {q M k : ℕ} (hM : 2 ≤ M) (hlog : 1 ≤ Real.log (M : ℝ)) :
    PaperB.M4B.primeRankinCorrection
        (h2BooleanTiltLift q h2BooleanSecondTilt)
        (h2BooleanRoughCutoff M) k (h2BooleanTailEpsilon M) ≤
      ((32 * Real.log 4) / Real.log 2) * Real.exp 1 := by
  let Y := h2BooleanRoughCutoff M
  let ε := h2BooleanTailEpsilon M
  have henv := h2BooleanTiltLift_envelope q
    h2BooleanSecondTilt_nonneg h2BooleanSecondTilt_le_three_halves
  have hY2 : 2 ≤ Y := by simpa [Y] using h2BooleanRoughCutoff_two_le hlog
  have hε0 : 0 < ε := by simpa [ε] using h2BooleanTailEpsilon_pos hM
  have hε1 : ε ≤ 1 := by simpa [ε] using h2BooleanTailEpsilon_le_one hlog
  have hdy := PaperB.M4B.primeRankinCorrection_le_dyadic
    henv Y k hε0.le hε1
  have hgeom := h2Boolean_shell_geometric_rankin_bound hY2 hε0 hε1
  have hYpos : (0 : ℝ) < (Y : ℝ) := by exact_mod_cast (show 0 < Y by omega)
  have hYeps : (Y : ℝ) ^ ε ≤ Real.exp 1 := by
    rw [Real.rpow_def_of_pos hYpos]
    apply Real.exp_monotone
    have hmul := h2BooleanTailEpsilon_mul_cutoffLog_le_one hM
    simpa [Y, ε, mul_comm] using hmul
  have hA : 0 ≤ 16 * Real.log 4 := by positivity
  calc
    PaperB.M4B.primeRankinCorrection
        (h2BooleanTiltLift q h2BooleanSecondTilt) Y k ε
      ≤ (8 * ε) *
          (2 * Real.log 4 *
            ∑ j ∈ Finset.range (Nat.log 2 Y + 1),
              (((2 ^ j : ℕ) : ℝ)) ^ ε) := hdy
    _ = (16 * Real.log 4) *
          (ε * ∑ j ∈ Finset.range (Nat.log 2 Y + 1),
            (((2 ^ j : ℕ) : ℝ)) ^ ε) := by ring
    _ ≤ (16 * Real.log 4) * ((2 / Real.log 2) * (Y : ℝ) ^ ε) :=
      mul_le_mul_of_nonneg_left hgeom hA
    _ = ((32 * Real.log 4) / Real.log 2) * (Y : ℝ) ^ ε := by ring
    _ ≤ ((32 * Real.log 4) / Real.log 2) * Real.exp 1 := by
      have hcoef : 0 ≤ (32 * Real.log 4) / Real.log 2 := by positivity
      exact mul_le_mul_of_nonneg_left hYeps hcoef

#print axioms h2BooleanTailCorrection_le_const

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def h2BooleanSmoothProductCutoff (M : ℕ) : ℕ :=
  Nat.nthRoot 4 M + 1

lemma h2BooleanSmoothProductCutoff_one_le (M : ℕ) :
    1 ≤ h2BooleanSmoothProductCutoff M := by
  unfold h2BooleanSmoothProductCutoff
  omega

lemma h2BooleanSmoothProductCutoff_pow_four_gt (M : ℕ) :
    M < (h2BooleanSmoothProductCutoff M) ^ 4 := by
  unfold h2BooleanSmoothProductCutoff
  exact Nat.lt_pow_nthRoot_add_one (by norm_num) M

lemma h2BooleanSmoothProductCutoff_log_lower
    {M : ℕ} (hM : 1 ≤ M) :
    (1 / 4 : ℝ) * Real.log (M : ℝ) <
      Real.log (h2BooleanSmoothProductCutoff M : ℝ) := by
  have hMR : (0 : ℝ) < (M : ℝ) := by
    exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hM)
  have hXnat : 0 < h2BooleanSmoothProductCutoff M := by
    unfold h2BooleanSmoothProductCutoff
    omega
  have hXR : (0 : ℝ) < (h2BooleanSmoothProductCutoff M : ℝ) := by
    exact_mod_cast hXnat
  have hpow := h2BooleanSmoothProductCutoff_pow_four_gt M
  have hpowR :
      (M : ℝ) < (h2BooleanSmoothProductCutoff M : ℝ) ^ (4 : ℕ) := by
    exact_mod_cast hpow
  have hlog := Real.log_lt_log hMR hpowR
  rw [Real.log_pow] at hlog
  have hscaled := mul_lt_mul_of_pos_left hlog (show (0 : ℝ) < 1 / 4 by norm_num)
  norm_num at hscaled ⊢
  nlinarith

lemma h2BooleanTailEpsilon_mul_smoothCutoffLog_lower
    {M : ℕ} (hM : 2 ≤ M) :
    (1 / 4 : ℝ) *
        (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) <
      h2BooleanTailEpsilon M *
        Real.log (h2BooleanSmoothProductCutoff M : ℝ) := by
  have hM1 : 1 ≤ M := by omega
  have hloglow := h2BooleanSmoothProductCutoff_log_lower hM1
  have heps := h2BooleanTailEpsilon_pos hM
  have hmul := mul_lt_mul_of_pos_left hloglow heps
  have hM1R : (1 : ℝ) < (M : ℝ) := by exact_mod_cast (show 1 < M by omega)
  have hlogM : 0 < Real.log (M : ℝ) := Real.log_pos hM1R
  have hrpow :
      (Real.log (M : ℝ)) ^ (-h2BooleanTheta) *
          Real.log (M : ℝ) =
        (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) := by
    rw [Real.rpow_def_of_pos hlogM, Real.rpow_def_of_pos hlogM]
    rw [← Real.exp_log hlogM]
    rw [← Real.exp_add]
    congr 1
    simp only [Real.log_exp]
    ring
  have hid :
      h2BooleanTailEpsilon M * ((1 / 4 : ℝ) * Real.log (M : ℝ)) =
        (1 / 4 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) := by
    unfold h2BooleanTailEpsilon
    calc
      (Real.log (M : ℝ)) ^ (-h2BooleanTheta) *
          ((1 / 4 : ℝ) * Real.log (M : ℝ))
        = (1 / 4 : ℝ) *
            ((Real.log (M : ℝ)) ^ (-h2BooleanTheta) *
              Real.log (M : ℝ)) := by ring
      _ = (1 / 4 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) := by rw [hrpow]
  rw [hid] at hmul
  simpa [mul_comm, mul_left_comm, mul_assoc] using hmul

lemma h2Boolean_one_sub_theta_pos :
    0 < 1 - h2BooleanTheta := by
  norm_num [h2BooleanTheta]

noncomputable def h2BooleanTailCorrectionConst : ℝ :=
  ((32 * Real.log 4) / Real.log 2) * Real.exp 1

lemma h2BooleanTailCorrectionConst_nonneg :
    0 ≤ h2BooleanTailCorrectionConst := by
  unfold h2BooleanTailCorrectionConst
  positivity

lemma h2BooleanTailCorrection_le_const'
    {q M k : ℕ} (hM : 2 ≤ M) (hlog : 1 ≤ Real.log (M : ℝ)) :
    PaperB.M4B.primeRankinCorrection
        (h2BooleanTiltLift q h2BooleanSecondTilt)
        (h2BooleanRoughCutoff M) k (h2BooleanTailEpsilon M) ≤
      h2BooleanTailCorrectionConst := by
  simpa [h2BooleanTailCorrectionConst] using
    h2BooleanTailCorrection_le_const (q := q) (M := M) (k := k) hM hlog

lemma eventually_h2BooleanTailCorrection_budget :
    ∀ᶠ M : ℕ in Filter.atTop,
      2 ≤ M ∧
      1 ≤ Real.log (M : ℝ) ∧
      h2BooleanTailCorrectionConst ≤
        (1 / 8 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) := by
  have hpow :
      ∀ᶠ t : ℝ in Filter.atTop,
        8 * h2BooleanTailCorrectionConst ≤
          t ^ (1 - h2BooleanTheta) :=
    (tendsto_rpow_atTop h2Boolean_one_sub_theta_pos).eventually
      (Filter.eventually_ge_atTop (8 * h2BooleanTailCorrectionConst))
  have hlogNat :
      Filter.Tendsto (fun M : ℕ => Real.log (M : ℝ))
        Filter.atTop Filter.atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hpowNat := hlogNat.eventually hpow
  have hM2 : ∀ᶠ M : ℕ in Filter.atTop, 2 ≤ M :=
    Filter.eventually_ge_atTop 2
  have hlog1Real : ∀ᶠ t : ℝ in Filter.atTop, 1 ≤ t :=
    Filter.eventually_ge_atTop 1
  have hlog1 := hlogNat.eventually hlog1Real
  filter_upwards [hM2, hlog1, hpowNat] with M hM hL hp
  refine ⟨hM, hL, ?_⟩
  nlinarith

lemma exists_h2BooleanTailCorrection_budget :
    ∃ M0 : ℕ, ∀ M : ℕ, M0 ≤ M →
      2 ≤ M ∧
      1 ≤ Real.log (M : ℝ) ∧
      h2BooleanTailCorrectionConst ≤
        (1 / 8 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) := by
  simpa only [Filter.eventually_atTop] using
    eventually_h2BooleanTailCorrection_budget

#print axioms h2BooleanTailEpsilon_mul_smoothCutoffLog_lower
#print axioms exists_h2BooleanTailCorrection_budget

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def h2BooleanBadSmoothSets (q M : ℕ) : Finset (Finset ℕ) :=
  ((h2BooleanSmoothActivePrimeSet q (h2BooleanRoughCutoff M)).powerset).filter
    (fun T => h2BooleanSmoothProductCutoff M ≤ primeSetProduct T)

lemma h2BooleanBadSmoothSets_subset_powerset
    (q M : ℕ) :
    h2BooleanBadSmoothSets q M ⊆
      (h2BooleanSmoothActivePrimeSet q (h2BooleanRoughCutoff M)).powerset :=
  Finset.filter_subset _ _

lemma h2BooleanBadSmoothSets_product_ge
    {q M : ℕ} {T : Finset ℕ}
    (hT : T ∈ h2BooleanBadSmoothSets q M) :
    h2BooleanSmoothProductCutoff M ≤ primeSetProduct T :=
  (Finset.mem_filter.mp hT).2

lemma h2BooleanBadSmoothSets_active
    {q M : ℕ} {T : Finset ℕ}
    (hT : T ∈ h2BooleanBadSmoothSets q M) :
    ∀ p ∈ T, activeHighPrime q p := by
  intro p hp
  have hsub := Finset.mem_powerset.mp (Finset.mem_filter.mp hT).1
  exact h2BooleanSmoothActivePrimeSet_active p (hsub hp)

lemma h2BooleanBadSmoothSets_subset_rankin_powerset
    {q M : ℕ} :
    h2BooleanBadSmoothSets q M ⊆
      (((Nat.primesLE (h2BooleanRoughCutoff M)).filter
        (fun p => ¬ p ∣ q)).powerset).filter
          (fun T => h2BooleanSmoothProductCutoff M ≤ T.prod id) := by
  intro T hT
  rw [Finset.mem_filter]
  constructor
  · rw [Finset.mem_powerset]
    intro p hp
    have hA := h2BooleanBadSmoothSets_active hT p hp
    have hpSmooth :=
      (Finset.mem_powerset.mp (Finset.mem_filter.mp hT).1) hp
    have hpF := Finset.mem_filter.mp hpSmooth
    rw [Finset.mem_filter]
    exact ⟨hpF.1, hA.2.2⟩
  · simpa [primeSetProduct] using h2BooleanBadSmoothSets_product_ge hT

lemma h2BooleanBadSmoothWeightSum_le_tail
    (q M : ℕ) :
    (∑ T ∈ h2BooleanBadSmoothSets q M,
      finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) ≤
      PaperB.M4B.squarefreeSmoothTailMass
        (h2BooleanTiltLift q h2BooleanSecondTilt)
        (h2BooleanSmoothProductCutoff M)
        (h2BooleanRoughCutoff M) q := by
  unfold PaperB.M4B.squarefreeSmoothTailMass
  let P := (Nat.primesLE (h2BooleanRoughCutoff M)).filter (fun p => ¬ p ∣ q)
  let F := (P.powerset).filter
    (fun T => h2BooleanSmoothProductCutoff M ≤ T.prod id)
  have hsub : h2BooleanBadSmoothSets q M ⊆ F := by
    simpa [P, F] using
      (h2BooleanBadSmoothSets_subset_rankin_powerset (q := q) (M := M))
  calc
    (∑ T ∈ h2BooleanBadSmoothSets q M,
      finiteOmegaWeightReal T * h2BooleanV0 ^ T.card)
      = ∑ T ∈ h2BooleanBadSmoothSets q M,
          ∏ p ∈ T,
            h2BooleanTiltLift q h2BooleanSecondTilt p / (p : ℝ) := by
          apply Finset.sum_congr rfl
          intro T hT
          exact (h2BooleanSecondTiltWeight_prod_eq
            (h2BooleanBadSmoothSets_active hT)).symm
    _ ≤ ∑ T ∈ F,
          ∏ p ∈ T,
            h2BooleanTiltLift q h2BooleanSecondTilt p / (p : ℝ) := by
          apply Finset.sum_le_sum_of_subset_of_nonneg hsub
          intro T hTF hnot
          apply Finset.prod_nonneg
          intro p hp
          exact div_nonneg
            (h2BooleanTiltLift_nonneg q p h2BooleanSecondTilt_nonneg)
            (by positivity)
    _ = _ := by rfl

#print axioms h2BooleanBadSmoothWeightSum_le_tail

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma h2BooleanBadSmoothTail_rankin
    {q M : ℕ}
    (hM : 2 ≤ M)
    (hlog : 1 ≤ Real.log (M : ℝ))
    (hC : h2BooleanTailCorrectionConst ≤
      (1 / 8 : ℝ) * (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) :
    PaperB.M4B.squarefreeSmoothTailMass
        (h2BooleanTiltLift q h2BooleanSecondTilt)
        (h2BooleanSmoothProductCutoff M)
        (h2BooleanRoughCutoff M) q ≤
      Real.exp
        (PaperB.M4B.primeMass
          (h2BooleanTiltLift q h2BooleanSecondTilt)
          (h2BooleanRoughCutoff M) q -
        (1 / 8 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) := by
  let f := h2BooleanTiltLift q h2BooleanSecondTilt
  let eps := h2BooleanTailEpsilon M
  let R := (1 / 8 : ℝ) *
    (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)
  have henv := h2BooleanTiltLift_envelope q
    h2BooleanSecondTilt_nonneg h2BooleanSecondTilt_le_three_halves
  have heps0 : 0 ≤ eps := by
    dsimp [eps]
    exact (h2BooleanTailEpsilon_pos hM).le
  have heps1 : eps ≤ 1 := by
    dsimp [eps]
    exact h2BooleanTailEpsilon_le_one hlog
  have hX1 : 1 ≤ h2BooleanSmoothProductCutoff M :=
    h2BooleanSmoothProductCutoff_one_le M
  have hcorr :
      PaperB.M4B.primeRankinCorrection f
          (h2BooleanRoughCutoff M) q eps ≤
        h2BooleanTailCorrectionConst := by
    dsimp [f, eps]
    exact h2BooleanTailCorrection_le_const' hM hlog
  have hscale :
      (1 / 4 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) <
        eps * Real.log (h2BooleanSmoothProductCutoff M : ℝ) := by
    dsimp [eps]
    exact h2BooleanTailEpsilon_mul_smoothCutoffLog_lower hM
  have hbudget :
      PaperB.M4B.primeRankinCorrection f
          (h2BooleanRoughCutoff M) q eps -
        eps * Real.log (h2BooleanSmoothProductCutoff M : ℝ) ≤ -R := by
    dsimp [R]
    linarith
  simpa [f, eps, R] using
    PaperB.M4B.squarefree_smoothTail_rankin_of_budget
      henv (h2BooleanSmoothProductCutoff M)
      (h2BooleanRoughCutoff M) q hX1 heps0 heps1 hbudget

lemma h2BooleanBadSmoothWeightSum_rankin
    {q M : ℕ}
    (hM : 2 ≤ M)
    (hlog : 1 ≤ Real.log (M : ℝ))
    (hC : h2BooleanTailCorrectionConst ≤
      (1 / 8 : ℝ) * (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) :
    (∑ T ∈ h2BooleanBadSmoothSets q M,
      finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) ≤
      Real.exp
        (PaperB.M4B.primeMass
          (h2BooleanTiltLift q h2BooleanSecondTilt)
          (h2BooleanRoughCutoff M) q -
        (1 / 8 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) :=
  (h2BooleanBadSmoothWeightSum_le_tail q M).trans
    (h2BooleanBadSmoothTail_rankin hM hlog hC)

#print axioms h2BooleanBadSmoothWeightSum_rankin

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def h2BooleanGoodSmoothSets (q M : ℕ) : Finset (Finset ℕ) :=
  ((h2BooleanSmoothActivePrimeSet q (h2BooleanRoughCutoff M)).powerset).filter
    (fun T => primeSetProduct T < h2BooleanSmoothProductCutoff M)

lemma h2BooleanGoodSmoothSets_active
    {q M : ℕ} {T : Finset ℕ}
    (hT : T ∈ h2BooleanGoodSmoothSets q M) :
    ∀ p ∈ T, activeHighPrime q p := by
  intro p hp
  have hsub := Finset.mem_powerset.mp (Finset.mem_filter.mp hT).1
  exact h2BooleanSmoothActivePrimeSet_active p (hsub hp)

lemma h2BooleanGoodSmoothSets_product_pow_four_le
    {q M : ℕ} {T : Finset ℕ}
    (hT : T ∈ h2BooleanGoodSmoothSets q M) :
    (primeSetProduct T) ^ 4 ≤ M := by
  have hlt := (Finset.mem_filter.mp hT).2
  unfold h2BooleanSmoothProductCutoff at hlt
  have hle : primeSetProduct T ≤ Nat.nthRoot 4 M := by omega
  exact (Nat.le_nthRoot_iff (by norm_num)).1 hle

lemma h2BooleanGoodSmoothSets_partition
    (q M : ℕ) :
    (h2BooleanSmoothActivePrimeSet q (h2BooleanRoughCutoff M)).powerset =
      h2BooleanGoodSmoothSets q M ∪ h2BooleanBadSmoothSets q M := by
  ext T
  simp only [h2BooleanGoodSmoothSets, h2BooleanBadSmoothSets,
    Finset.mem_union, Finset.mem_filter]
  constructor
  · intro hT
    by_cases h : primeSetProduct T < h2BooleanSmoothProductCutoff M
    · exact Or.inl ⟨hT, h⟩
    · exact Or.inr ⟨hT, Nat.le_of_not_gt h⟩
  · rintro (⟨hT, _⟩ | ⟨hT, _⟩) <;> exact hT

lemma h2BooleanGoodBad_disjoint (q M : ℕ) :
    Disjoint (h2BooleanGoodSmoothSets q M) (h2BooleanBadSmoothSets q M) := by
  rw [Finset.disjoint_left]
  intro T hG hB
  have hlt := (Finset.mem_filter.mp hG).2
  have hle := (Finset.mem_filter.mp hB).2
  omega

lemma h2Boolean_good_scaled_div_ge_cube
    {q M : ℕ} {T : Finset ℕ}
    (hT : T ∈ h2BooleanGoodSmoothSets q M) :
    (primeSetProduct T) ^ 3 ≤ M / primeSetProduct T := by
  have hA := h2BooleanGoodSmoothSets_active hT
  have hmpos : 0 < primeSetProduct T :=
    primeSetProduct_pos (fun p hp => (hA p hp).1)
  apply (Nat.le_div_iff_mul_le hmpos).2
  have hpow := h2BooleanGoodSmoothSets_product_pow_four_le hT
  simpa [pow_succ, mul_comm, mul_left_comm, mul_assoc] using hpow

lemma h2Boolean_scaledCoverLength_ge_div
    {M m : ℕ} :
    M / m + 1 ≤ PaperB.M4B.scaledCoverLength (2 * M) M m := by
  have h := PaperB.M4B.div_le_scaledLength
    (x := 2 * M) (y := M) (b := m) (by omega)
  unfold PaperB.M4B.scaledCoverLength
  omega

lemma h2Boolean_scaledCoverUpper_le_twice_div_add_two
    {M m : ℕ} :
    PaperB.M4B.scaledCoverUpper (2 * M) m ≤ 2 * (M / m) + 2 := by
  have h := Nat.add_div_le_div_add_div_add_one M M m
  unfold PaperB.M4B.scaledCoverUpper PaperB.M4B.scaledUpper
  have htwo : M + M = 2 * M := by omega
  rw [htwo] at h
  omega

lemma h2Boolean_good_scaled_quarter_nat
    {q M : ℕ} {T : Finset ℕ}
    (hT : T ∈ h2BooleanGoodSmoothSets q M)
    (hM : 1 ≤ M) :
    PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T) <
      (PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T)) ^ 4 := by
  let d := M / primeSetProduct T
  have hd1 : 1 ≤ d := by
    have hm4 := h2BooleanGoodSmoothSets_product_pow_four_le hT
    have hA := h2BooleanGoodSmoothSets_active hT
    have hmpos : 0 < primeSetProduct T :=
      primeSetProduct_pos (fun p hp => (hA p hp).1)
    have hmle : primeSetProduct T ≤ M := by
      have hmself : primeSetProduct T ≤ (primeSetProduct T)^4 :=
        Nat.le_pow (by norm_num)
      exact hmself.trans hm4
    exact (Nat.le_div_iff_mul_le hmpos).2 (by simpa using hmle)
  have hx := h2Boolean_scaledCoverUpper_le_twice_div_add_two
    (M := M) (m := primeSetProduct T)
  have hy := h2Boolean_scaledCoverLength_ge_div
    (M := M) (m := primeSetProduct T)
  dsimp [d] at hd1
  have hbase : 1 < d + 1 := by omega
  have htwo : 2 * (d + 1) ≤ (d + 1) * (d + 1) := by
    exact Nat.mul_le_mul_right (d + 1) (by omega)
  have hsqpow : (d + 1) * (d + 1) = (d + 1)^2 := by ring
  have hp24 : (d + 1)^2 < (d + 1)^4 :=
    Nat.pow_lt_pow_right hbase (by norm_num)
  have hpoly : 2 * d + 2 < (d + 1)^4 := by
    have : 2 * (d + 1) < (d + 1)^4 := by
      rw [hsqpow] at htwo
      exact htwo.trans_lt hp24
    omega
  calc
    PaperB.M4B.scaledCoverUpper (2 * M) (primeSetProduct T)
      ≤ 2 * d + 2 := by simpa [d] using hx
    _ < (d + 1)^4 := hpoly
    _ ≤ (PaperB.M4B.scaledCoverLength (2 * M) M (primeSetProduct T))^4 := by
      exact Nat.pow_le_pow_left (by simpa [d] using hy) 4

#print axioms h2BooleanGoodSmoothSets_product_pow_four_le
#print axioms h2Boolean_good_scaled_quarter_nat

end PaperB.FixedQ
