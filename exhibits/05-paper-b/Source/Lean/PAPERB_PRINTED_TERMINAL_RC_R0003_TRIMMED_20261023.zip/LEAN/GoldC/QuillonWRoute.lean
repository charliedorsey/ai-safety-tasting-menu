import GoldC.QuillonWCoupled
import GoldC.QuillonOmega
import GoldC.QuillonVW

/-!
# Quillon CSC3 F7.5d: one W′ piece in closed form

For `s = ∏P` (distinct primes), a set `𝒫` of `y`'s with `X ≤ y ≤ Y`, units mod `s`
(the Ramaré primes); a set `𝒩 ⊆ (N, 2N]`; `‖α_y‖ ≤ A/y`, `‖β_n‖ ≤ A/n`; and an interval `(I₀, I₁]`:

    ‖Σ_n β_n Σ_y α_y 1[yn ∈ (I₀,I₁]] kphase(c₀, yn)‖² ≤ 2A⁴·Ψ,

where
`Ψ = 2/X + 2(1+log Y)²/s + 2(1+log Y)²·Π·3^{|P|/4}G₀^{1/4}·(s^{3/4}/s + s^{3/4}(1+log s)/N)`
and `Π = ∏_P(1+p^{−3/4})`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonWRoute

open GoldC.QuillonWCoupled GoldC.QuillonWCell GoldC.QuillonVW GoldC.QuillonOmega

variable {s : ℕ} [NeZero s]

lemma gI_eq_kphase (c₀ : ZMod s) (I₀ I₁ y n : ℕ) (hy : 1 ≤ y) :
    gI c₀ (fun y => I₀ / y) (fun y => I₁ / y) y n =
      if y * n ∈ Ioc I₀ I₁ then kphase c₀ (y * n) else 0 := by
  unfold gI
  have hiff : n ∈ Ioc (I₀ / y) (I₁ / y) ↔ y * n ∈ Ioc I₀ I₁ := by
    simp only [mem_Ioc]
    constructor
    · rintro ⟨h1, h2⟩
      refine ⟨?_, ?_⟩
      · rw [Nat.div_lt_iff_lt_mul (by omega)] at h1; linarith [mul_comm n y]
      · rw [Nat.le_div_iff_mul_le (by omega)] at h2; linarith [mul_comm n y]
    · rintro ⟨h1, h2⟩
      refine ⟨?_, ?_⟩
      · rw [Nat.div_lt_iff_lt_mul (by omega)]; linarith [mul_comm n y]
      · rw [Nat.le_div_iff_mul_le (by omega)]; linarith [mul_comm n y]
  by_cases h : n ∈ Ioc (I₀ / y) (I₁ / y)
  · rw [if_pos h, if_pos (hiff.1 h)]
    unfold GoldC.QuillonW.g kphase
    push_cast; rfl
  · rw [if_neg h, if_neg (fun h' => h (hiff.2 h'))]

theorem W_piece (hs2 : 2 ≤ s) (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p)
    (c₀ : ZMod s) (𝒴 𝒩 : Finset ℕ) (X Y N I₀ I₁ : ℕ) (hX : 2 ≤ X) (hN : 1 ≤ N)
    (h𝒴 : ∀ y ∈ 𝒴, X ≤ y ∧ y ≤ Y) (h𝒩 : 𝒩 ⊆ Ioc N (2 * N))
    (hunit : ∀ y ∈ 𝒴, IsUnit (y : ZMod s)) (α β : ℕ → ℂ) (A : ℝ)
    (hA : 0 ≤ A) (hα : ∀ y ∈ 𝒴, ‖α y‖ ≤ A / y) (hβ : ∀ n ∈ 𝒩, ‖β n‖ ≤ A / n) :
    ‖∑ n ∈ 𝒩, β n * ∑ y ∈ 𝒴, α y *
        (if y * n ∈ Ioc I₀ I₁ then kphase c₀ (y * n) else 0)‖ ^ 2 ≤
      2 * A ^ 4 * (2 / X + 2 * (1 + Real.log Y) ^ 2 / s +
        2 * (1 + Real.log Y) ^ 2 * (∏ p ∈ P, (1 + (p : ℝ) ^ (-(3 : ℝ) / 4))) *
          ((3 : ℝ) ^ ((P.card : ℝ) / 4) *
            (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 4)) *
          ((s : ℝ) ^ ((3 : ℝ) / 4) / s + (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + Real.log s) / N)) := by
  classical
  have hy1 : ∀ y ∈ 𝒴, 1 ≤ y := fun y hy => le_trans (by omega) (h𝒴 y hy).1
  have hrw : ∑ n ∈ 𝒩, β n * ∑ y ∈ 𝒴, α y *
        (if y * n ∈ Ioc I₀ I₁ then kphase c₀ (y * n) else 0) =
      ∑ n ∈ 𝒩, β n * ∑ y ∈ 𝒴, α y * gI c₀ (fun y => I₀ / y) (fun y => I₁ / y) y n := by
    refine sum_congr rfl fun n _ => ?_
    congr 1
    refine sum_congr rfl fun y hy => ?_
    rw [gI_eq_kphase c₀ I₀ I₁ y n (hy1 y hy)]
  rw [hrw]
  have h𝒴' : 𝒴 ⊆ Icc 1 Y := fun y hy => mem_Icc.2 ⟨hy1 y hy, (h𝒴 y hy).2⟩
  have hW := W_cell_coupled hs2 P hP hsP c₀ 𝒴 𝒩 Y N (2 * N) (by omega) h𝒩 h𝒴' hunit α β A hα
    (fun y => I₀ / y) (fun y => I₁ / y)
  refine hW.trans ?_
  set L := (1 + Real.log Y) ^ 2 with hL
  set Pf := ∏ p ∈ P, (1 + (p : ℝ) ^ (-(3 : ℝ) / 4)) with hPf
  set KF := (3 : ℝ) ^ ((P.card : ℝ) / 4) *
    (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 4) with hKF
  have hsR : (0 : ℝ) < s := by exact_mod_cast (show 0 < s by omega)
  have hNR : (0 : ℝ) < N := by exact_mod_cast hN
  have hXR : (0 : ℝ) < X := by exact_mod_cast (show 0 < X by omega)
  have hlogs : 0 ≤ Real.log s := Real.log_nonneg (by exact_mod_cast (show 1 ≤ s by omega))
  have hL0 : 0 ≤ L := by positivity
  have hPf0 : 0 ≤ Pf := prod_nonneg fun p _ => by positivity
  have hKF0 : 0 ≤ KF := by positivity
  have hMN : ((2 * N - N : ℕ) : ℝ) = N := by rw [show 2 * N - N = N by omega]
  rw [hMN]
  -- Σβ² ≤ 2A²/N
  have hSβ : ∑ n ∈ 𝒩, ‖β n‖ ^ 2 ≤ 2 * A ^ 2 / N := by
    calc ∑ n ∈ 𝒩, ‖β n‖ ^ 2 ≤ ∑ n ∈ 𝒩, A ^ 2 * (1 / ((n : ℝ) ^ 2)) := by
          refine sum_le_sum fun n hn => ?_
          have hnR : (0 : ℝ) < n := by
            have := (mem_Ioc.1 (h𝒩 hn)).1; exact_mod_cast (show 0 < n by omega)
          calc ‖β n‖ ^ 2 ≤ (A / n) ^ 2 := pow_le_pow_left₀ (norm_nonneg _) (hβ n hn) 2
            _ = _ := by field_simp
      _ = A ^ 2 * ∑ n ∈ 𝒩.filter (fun n => N + 1 ≤ n), (1 / ((n : ℝ) ^ 2)) := by
          rw [← mul_sum]; congr 1
          rw [filter_true_of_mem (p := fun n => N + 1 ≤ n) fun n hn => (mem_Ioc.1 (h𝒩 hn)).1]
      _ ≤ A ^ 2 * (2 / ((N + 1 : ℕ) : ℝ)) :=
          mul_le_mul_of_nonneg_left (sum_inv_sq_tail 𝒩 (N + 1) (by omega)) (sq_nonneg A)
      _ ≤ 2 * A ^ 2 / N := by
          rw [mul_div_assoc', mul_comm (A ^ 2) 2]
          apply div_le_div_of_nonneg_left (by positivity) hNR
          push_cast; linarith
  -- Σα² ≤ 2A²/X
  have hSα : ∑ y ∈ 𝒴, ‖α y‖ ^ 2 ≤ 2 * A ^ 2 / X := by
    calc ∑ y ∈ 𝒴, ‖α y‖ ^ 2 ≤ ∑ y ∈ 𝒴, A ^ 2 * (1 / ((y : ℝ) ^ 2)) := by
          refine sum_le_sum fun y hy => ?_
          have hyR : (0 : ℝ) < y := by exact_mod_cast hy1 y hy
          calc ‖α y‖ ^ 2 ≤ (A / y) ^ 2 := pow_le_pow_left₀ (norm_nonneg _) (hα y hy) 2
            _ = _ := by field_simp
      _ = A ^ 2 * ∑ y ∈ 𝒴.filter (fun y => X ≤ y), (1 / ((y : ℝ) ^ 2)) := by
          rw [← mul_sum]; congr 1
          rw [filter_true_of_mem fun y hy => (h𝒴 y hy).1]
      _ ≤ A ^ 2 * (2 / (X : ℝ)) :=
          mul_le_mul_of_nonneg_left (sum_inv_sq_tail 𝒴 X hX) (sq_nonneg A)
      _ = 2 * A ^ 2 / X := by ring
  have hsq34 : (s : ℝ) ^ ((3 : ℝ) / 4) * (((N : ℝ) / s + 1 + Real.log s)) / N =
      (s : ℝ) ^ ((3 : ℝ) / 4) / s + (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + Real.log s) / N := by
    field_simp; ring
  have hinner : (N : ℝ) * ∑ y ∈ 𝒴, ‖α y‖ ^ 2 +
      A ^ 2 * ((N : ℝ) * (2 * (1 + Real.log Y) ^ 2 / s) +
        (3 : ℝ) ^ ((P.card : ℝ) / 4) * (s : ℝ) ^ ((3 : ℝ) / 4) *
          (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 4) *
          ((N : ℝ) / s + 1 + Real.log s) *
          (2 * (1 + Real.log Y) ^ 2 * ∏ p ∈ P, (1 + (p : ℝ) ^ (-(3 : ℝ) / 4)))) ≤
      N * A ^ 2 * (2 / X + 2 * L / s + 2 * L * Pf * KF *
        ((s : ℝ) ^ ((3 : ℝ) / 4) / s + (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + Real.log s) / N)) := by
    rw [← hsq34]
    have e : (N : ℝ) * A ^ 2 * (2 / X + 2 * L / s + 2 * L * Pf * KF *
        ((s : ℝ) ^ ((3 : ℝ) / 4) * (((N : ℝ) / s + 1 + Real.log s)) / N)) =
        (N : ℝ) * (2 * A ^ 2 / X) + A ^ 2 * ((N : ℝ) * (2 * L / s) +
          KF * (s : ℝ) ^ ((3 : ℝ) / 4) * ((N : ℝ) / s + 1 + Real.log s) * (2 * L * Pf)) := by
      field_simp; ring
    rw [e, hKF, hL, hPf]
    have := mul_le_mul_of_nonneg_left hSα hNR.le
    have hrest : (3 : ℝ) ^ ((P.card : ℝ) / 4) * (s : ℝ) ^ ((3 : ℝ) / 4) *
          (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 4) =
        (3 : ℝ) ^ ((P.card : ℝ) / 4) *
          (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 4) *
          (s : ℝ) ^ ((3 : ℝ) / 4) := by ring
    rw [hrest]
    linarith
  have hin0 : 0 ≤ (N : ℝ) * ∑ y ∈ 𝒴, ‖α y‖ ^ 2 +
      A ^ 2 * ((N : ℝ) * (2 * (1 + Real.log Y) ^ 2 / s) +
        (3 : ℝ) ^ ((P.card : ℝ) / 4) * (s : ℝ) ^ ((3 : ℝ) / 4) *
          (∏ p ∈ P.filter (fun p => (ZMod.cast c₀ : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 4) *
          ((N : ℝ) / s + 1 + Real.log s) *
          (2 * (1 + Real.log Y) ^ 2 * ∏ p ∈ P, (1 + (p : ℝ) ^ (-(3 : ℝ) / 4)))) := by
    have : (0 : ℝ) ≤ ∑ y ∈ 𝒴, ‖α y‖ ^ 2 := sum_nonneg fun _ _ => by positivity
    positivity
  calc _ ≤ (2 * A ^ 2 / N) * (N * A ^ 2 * (2 / X + 2 * L / s + 2 * L * Pf * KF *
        ((s : ℝ) ^ ((3 : ℝ) / 4) / s + (s : ℝ) ^ ((3 : ℝ) / 4) * (1 + Real.log s) / N))) :=
        mul_le_mul hSβ hinner hin0 (by positivity)
    _ = _ := by rw [hL, hPf, hKF]; field_simp

end GoldC.QuillonWRoute
#print axioms GoldC.QuillonWRoute.W_piece
