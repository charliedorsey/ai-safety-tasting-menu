import Mathlib.NumberTheory.ArithmeticFunction.Moebius
import Mathlib.NumberTheory.ArithmeticFunction.Zeta
import Mathlib.Data.Nat.Squarefree
import Mathlib.Analysis.SpecialFunctions.Pow.Real

/-!
# Oriel Upper — source weights and the signed κ expansion

`gW F n = ∏_{p ∣ n} p/(p-3)` on squarefree `n` whose primes are all `≥ 5` and
coprime to `F`, else `0`.  The Paper B pair weight is `b(n) = gW F n / n`
(`= ∏_{p∣n} 1/(p-3)`).

`KW F = gW F * μ` is the signed convolution; `∑_{e ∣ n} KW F e = gW F n` for all
`n` (exact Möbius inversion).  On prime powers:
`KW(p) = gW(p) - 1`, `KW(p^2) = -gW(p)`, `KW(p^k) = 0` (`k ≥ 3`).
So forbidden primes carry `κ(p) = -1` and allowed primes the negative
`κ(p²) = -p/(p-3)`; nothing is dropped.
-/

open Finset ArithmeticFunction
open scoped ArithmeticFunction.Moebius ArithmeticFunction.zeta

namespace OrielUpper

/-- Allowed primes for the weight with forbidden modulus `F`. -/
def allowedP (F p : ℕ) : Prop := 5 ≤ p ∧ ¬ p ∣ F

instance (F p : ℕ) : Decidable (allowedP F p) := by unfold allowedP; infer_instance

/-- Numerator weight `g_F(n) = n b_F(n)`. -/
noncomputable def gW (F n : ℕ) : ℝ :=
  if Squarefree n ∧ ∀ p ∈ n.primeFactors, allowedP F p then
    ∏ p ∈ n.primeFactors, (p : ℝ) / ((p : ℝ) - 3)
  else 0

/-- Pair weight `b_F(n) = g_F(n)/n`. -/
noncomputable def bW (F n : ℕ) : ℝ := gW F n / n

lemma gW_zero (F : ℕ) : gW F 0 = 0 := by simp [gW]

lemma gW_one (F : ℕ) : gW F 1 = 1 := by simp [gW]

lemma gW_nonneg (F n : ℕ) : 0 ≤ gW F n := by
  unfold gW
  split_ifs with h
  · apply prod_nonneg
    intro p hp
    have h5 := (h.2 p hp).1
    have : (5 : ℝ) ≤ p := by exact_mod_cast h5
    apply div_nonneg <;> linarith
  · exact le_refl 0

lemma bW_nonneg (F n : ℕ) : 0 ≤ bW F n :=
  div_nonneg (gW_nonneg F n) (Nat.cast_nonneg n)

/-- The weight as an arithmetic function. -/
noncomputable def GW (F : ℕ) : ArithmeticFunction ℝ := ⟨gW F, gW_zero F⟩

@[simp] lemma GW_apply (F n : ℕ) : GW F n = gW F n := rfl

theorem GW_isMultiplicative (F : ℕ) : (GW F).IsMultiplicative := by
  refine ⟨by simp [gW_one], ?_⟩
  intro m n hmn
  simp only [GW_apply]
  rcases Nat.eq_zero_or_pos m with hm | hm
  · subst hm; simp [gW_zero]
  rcases Nat.eq_zero_or_pos n with hn | hn
  · subst hn; simp [gW_zero]
  have hpf : (m * n).primeFactors = m.primeFactors ∪ n.primeFactors :=
    Nat.primeFactors_mul hm.ne' hn.ne'
  have hdisj : Disjoint m.primeFactors n.primeFactors := hmn.disjoint_primeFactors
  have key : (Squarefree (m * n) ∧ ∀ p ∈ (m * n).primeFactors, allowedP F p) ↔
      ((Squarefree m ∧ ∀ p ∈ m.primeFactors, allowedP F p) ∧
        (Squarefree n ∧ ∀ p ∈ n.primeFactors, allowedP F p)) := by
    rw [hpf, Nat.squarefree_mul_iff]
    constructor
    · rintro ⟨⟨_, hsm, hsn⟩, hall⟩
      exact ⟨⟨hsm, fun p hp => hall p (mem_union_left _ hp)⟩,
        ⟨hsn, fun p hp => hall p (mem_union_right _ hp)⟩⟩
    · rintro ⟨⟨hsm, h1⟩, ⟨hsn, h2⟩⟩
      refine ⟨⟨hmn, hsm, hsn⟩, ?_⟩
      intro p hp
      rcases mem_union.mp hp with hp | hp
      · exact h1 p hp
      · exact h2 p hp
  unfold gW
  by_cases h1 : Squarefree m ∧ ∀ p ∈ m.primeFactors, allowedP F p
  · by_cases h2 : Squarefree n ∧ ∀ p ∈ n.primeFactors, allowedP F p
    · rw [if_pos (key.mpr ⟨h1, h2⟩), if_pos h1, if_pos h2, hpf, prod_union hdisj]
    · rw [if_neg (fun h => h2 (key.mp h).2), if_neg h2, mul_zero]
  · rw [if_neg (fun h => h1 (key.mp h).1), if_neg h1, zero_mul]

/-- Signed convolution `κ_F = g_F * μ`. -/
noncomputable def KW (F : ℕ) : ArithmeticFunction ℝ := GW F * (μ : ArithmeticFunction ℝ)

theorem KW_isMultiplicative (F : ℕ) : (KW F).IsMultiplicative :=
  (GW_isMultiplicative F).mul isMultiplicative_moebius.intCast

/-- Exact Möbius inversion: `∑_{e ∣ n} κ_F(e) = g_F(n)`. -/
theorem sum_divisors_KW (F n : ℕ) : ∑ e ∈ n.divisors, KW F e = gW F n := by
  have h : (KW F * (ζ : ArithmeticFunction ℝ)) = GW F := by
    rw [KW, mul_assoc, coe_moebius_mul_coe_zeta, mul_one]
  have := congrArg (fun f : ArithmeticFunction ℝ => f n) h
  simp only [coe_mul_zeta_apply, GW_apply] at this
  exact this

/-- Values of `g_F` at a prime. -/
lemma gW_prime (F : ℕ) {p : ℕ} (hp : p.Prime) :
    gW F p = if allowedP F p then (p : ℝ) / ((p : ℝ) - 3) else 0 := by
  unfold gW
  rw [hp.primeFactors]
  simp only [mem_singleton, forall_eq, prod_singleton]
  by_cases h : allowedP F p
  · rw [if_pos ⟨hp.squarefree, h⟩, if_pos h]
  · rw [if_neg (fun h' => h h'.2), if_neg h]

/-- `g_F` vanishes on higher prime powers (not squarefree). -/
lemma gW_prime_pow {F p k : ℕ} (hp : p.Prime) (hk : 2 ≤ k) : gW F (p ^ k) = 0 := by
  unfold gW
  rw [if_neg]
  rintro ⟨hsq, _⟩
  have : p * p ∣ p ^ k := by
    rw [← pow_two]; exact Nat.pow_dvd_pow p hk
  have := hsq p this
  exact hp.not_isUnit this

/-- Partial sums of `κ` over divisors of a prime power. -/
lemma sum_KW_prime_pow (F : ℕ) {p : ℕ} (hp : p.Prime) (k : ℕ) :
    ∑ i ∈ range (k + 1), KW F (p ^ i) = gW F (p ^ k) := by
  rw [← sum_divisors_KW F (p ^ k), Nat.divisors_prime_pow hp k, sum_map]
  rfl

lemma KW_prime_pow_succ (F : ℕ) {p : ℕ} (hp : p.Prime) (k : ℕ) :
    KW F (p ^ (k + 1)) = gW F (p ^ (k + 1)) - gW F (p ^ k) := by
  have h1 := sum_KW_prime_pow F hp (k + 1)
  have h2 := sum_KW_prime_pow F hp k
  rw [sum_range_succ] at h1
  linarith

lemma KW_one (F : ℕ) : KW F 1 = 1 := (KW_isMultiplicative F).map_one

lemma KW_prime (F : ℕ) {p : ℕ} (hp : p.Prime) :
    KW F p = (if allowedP F p then (p : ℝ) / ((p : ℝ) - 3) else 0) - 1 := by
  have := KW_prime_pow_succ F hp 0
  simp only [zero_add, pow_one, pow_zero, gW_one] at this
  rw [this, gW_prime F hp]

lemma KW_prime_sq (F : ℕ) {p : ℕ} (hp : p.Prime) :
    KW F (p ^ 2) = -(if allowedP F p then (p : ℝ) / ((p : ℝ) - 3) else 0) := by
  have := KW_prime_pow_succ F hp 1
  simp only [pow_one] at this
  rw [this, gW_prime_pow hp le_rfl, gW_prime F hp]
  ring

lemma KW_prime_pow_ge_three (F : ℕ) {p k : ℕ} (hp : p.Prime) (hk : 3 ≤ k) :
    KW F (p ^ k) = 0 := by
  obtain ⟨j, rfl⟩ : ∃ j, k = j + 1 := ⟨k - 1, by omega⟩
  rw [KW_prime_pow_succ F hp j, gW_prime_pow hp (by omega), gW_prime_pow hp (by omega)]
  simp

end OrielUpper
