import PaperB.Analytic.SawtoothTruncation
import PaperB.Analytic.Basic

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Set

lemma smoothedSawCircle_coe_eq_smoothedSawtooth
    {T : ℝ} (hT : 1 < T) (y : ℝ) :
    smoothedSawCircle T hT (y : AddCircle (1 : ℝ)) =
      (smoothedSawtooth T y : ℂ) := by
  by_cases hy : Int.fract y = 0
  · have hycircle : (y : AddCircle (1 : ℝ)) = 0 := by
      rw [← AddCircle.coe_fract y, hy]
      rfl
    have h10 : ((1 : ℝ) : AddCircle (1 : ℝ)) = 0 := by simp
    rw [hycircle, ← h10]
    change AddCircle.liftIoc (1 : ℝ) 0
        (fun x : ℝ => (smoothedSawCell T x : ℂ)) ((1 : ℝ) : AddCircle (1 : ℝ)) =
      (smoothedSawtooth T y : ℂ)
    rw [AddCircle.liftIoc_coe_apply (show (1 : ℝ) ∈ Set.Ioc 0 (0 + 1) by simp)]
    rw [smoothedSawtooth, hy, smoothedSawCell_one hT,
      smoothedSawCell_zero (lt_trans zero_lt_one hT)]
  · have hpos : 0 < Int.fract y :=
      lt_of_le_of_ne (Int.fract_nonneg y) (Ne.symm hy)
    rw [← AddCircle.coe_fract y]
    change AddCircle.liftIoc (1 : ℝ) 0
        (fun x : ℝ => (smoothedSawCell T x : ℂ))
          ((Int.fract y : ℝ) : AddCircle (1 : ℝ)) =
      (smoothedSawtooth T y : ℂ)
    rw [AddCircle.liftIoc_coe_apply
      (show Int.fract y ∈ Set.Ioc 0 (0 + 1) by
        refine ⟨hpos, ?_⟩
        simpa using (Int.fract_lt_one y).le)]
    rfl

theorem petermannSawtooth_partial_error_le
    {T : ℝ} (hT : 1 < T) {H : ℕ} (hH : 1 ≤ H)
    {y : ℝ}
    (hlo : sawSmoothHalfWidth T < Int.fract y)
    (hhi : Int.fract y ≤ 1 - sawSmoothHalfWidth T) :
    ‖(petermannSawtooth y : ℂ) -
        sawSmoothPartial T H (y : AddCircle (1 : ℝ))‖
      ≤ T / (Real.pi ^ 2 * H) := by
  rw [← smoothedSawtooth_eq_petermannSawtooth hT hlo hhi,
    ← smoothedSawCircle_coe_eq_smoothedSawtooth hT y]
  exact sawSmoothPartial_error_le hT hH (y : AddCircle (1 : ℝ))

theorem smoothedSawtooth_ne_petermannSawtooth_only_near_jump
    {T y : ℝ} (hT : 1 < T)
    (hne : smoothedSawtooth T y ≠ petermannSawtooth y) :
    Int.fract y ≤ sawSmoothHalfWidth T ∨
      1 - sawSmoothHalfWidth T < Int.fract y := by
  by_contra h
  push_neg at h
  exact hne (smoothedSawtooth_eq_petermannSawtooth hT h.1 h.2)

lemma integral_smoothedSawCell_zero
    {T : ℝ} (hT : 1 < T) :
    (∫ x : ℝ in 0..1, smoothedSawCell T x) = 0 := by
  let a : ℝ := sawSmoothHalfWidth T
  let b : ℝ := 1 - sawSmoothHalfWidth T
  have hT0 : 0 < T := lt_trans zero_lt_one hT
  have ha0 : 0 ≤ a := (sawSmoothHalfWidth_pos hT0).le
  have hab : a ≤ b := sawSmoothHalfWidth_le_one_sub hT.le
  have hb1 : b ≤ 1 := by
    dsimp [b]
    linarith [sawSmoothHalfWidth_pos hT0]
  have hcont : Continuous (smoothedSawCell T) :=
    continuous_smoothedSawCell hT
  have hint : ∀ u v : ℝ,
      IntervalIntegrable (smoothedSawCell T) MeasureTheory.volume u v :=
    fun u v => hcont.intervalIntegrable u v
  have hsplit1 :=
    intervalIntegral.integral_add_adjacent_intervals
      (hint 0 a) (hint a b)
  have h0b : IntervalIntegrable (smoothedSawCell T)
      MeasureTheory.volume 0 b :=
    (hint 0 a).trans (hint a b)
  have hsplit2 :=
    intervalIntegral.integral_add_adjacent_intervals
      h0b (hint b 1)
  have hsplit :
      (∫ x : ℝ in 0..1, smoothedSawCell T x) =
        (∫ x : ℝ in 0..a, smoothedSawCell T x) +
        (∫ x : ℝ in a..b, smoothedSawCell T x) +
        (∫ x : ℝ in b..1, smoothedSawCell T x) := by
    rw [← hsplit2, ← hsplit1]
  have hleft :
      (∫ x : ℝ in 0..a, smoothedSawCell T x) =
        ∫ x : ℝ in 0..a, (1 - T) * x := by
    apply intervalIntegral.integral_congr
    intro x hx
    rw [Set.uIcc_of_le ha0] at hx
    rw [smoothedSawCell_left_eq hx.2]
  have hmid :
      (∫ x : ℝ in a..b, smoothedSawCell T x) =
        ∫ x : ℝ in a..b, x - 1 / 2 := by
    apply intervalIntegral.integral_congr
    intro x hx
    rw [Set.uIcc_of_le hab] at hx
    rw [smoothedSawCell_middle_eq hT hx.1 hx.2]
  have hright :
      (∫ x : ℝ in b..1, smoothedSawCell T x) =
        ∫ x : ℝ in b..1, (1 - T) * (x - 1) := by
    apply intervalIntegral.integral_congr
    intro x hx
    rw [Set.uIcc_of_le hb1] at hx
    rw [smoothedSawCell_right_eq hT hx.1]

  have hmidEval :
      (∫ x : ℝ in a..b, x - 1 / 2) =
        (b ^ 2 - a ^ 2) / 2 - (b - a) * (1 / 2) := by
    rw [intervalIntegral.integral_sub
      (f := fun x : ℝ => x)
      (g := fun _ : ℝ => (1 / 2 : ℝ))
      (continuous_id.intervalIntegrable _ _)
      (continuous_const.intervalIntegrable _ _)]
    rw [integral_id, intervalIntegral.integral_const]
    rfl
  have hrightCoreEval :
      (∫ x : ℝ in b..1, x - 1) =
        (1 ^ 2 - b ^ 2) / 2 - (1 - b) := by
    rw [intervalIntegral.integral_sub
      (f := fun x : ℝ => x)
      (g := fun _ : ℝ => (1 : ℝ))
      (continuous_id.intervalIntegrable _ _)
      (continuous_const.intervalIntegrable _ _)]
    rw [integral_id, intervalIntegral.integral_const]
    norm_num
  rw [hsplit, hleft, hmid, hright]
  rw [intervalIntegral.integral_const_mul, integral_id]
  rw [hmidEval]
  rw [intervalIntegral.integral_const_mul, hrightCoreEval]
  dsimp [a, b]
  rw [sawSmoothHalfWidth]
  field_simp [ne_of_gt hT0]
  ring

lemma sawSmoothCoeff_zero
    {T : ℝ} (hT : 1 < T) :
    sawSmoothCoeff T 0 = 0 := by
  rw [sawSmoothCoeff]
  simp [sawSmoothFreq]
  rw [intervalIntegral.integral_ofReal]
  rw [integral_smoothedSawCell_zero hT]
  norm_num

lemma sawSmoothMode_coe_eq_coeff_mul_eR
    (T : ℝ) (n : ℤ) (y : ℝ) :
    sawSmoothMode T n (y : AddCircle (1 : ℝ)) =
      sawSmoothCoeff T n * eR ((n : ℝ) * y) := by
  unfold sawSmoothMode eR
  rw [smul_eq_mul, fourier_coe_apply]
  apply congrArg (fun z : ℂ => sawSmoothCoeff T n * z)
  congr 1
  push_cast
  norm_num
  ring

lemma eR_mul_sawSmoothMode_coe
    (T xi : ℝ) (n : ℤ) (e : ℕ) (y : ℝ) :
    eR (xi * (e : ℝ)) * sawSmoothMode T n (y : AddCircle (1 : ℝ)) =
      sawSmoothCoeff T n *
        eR ((n : ℝ) * y + xi * (e : ℝ)) := by
  rw [sawSmoothMode_coe_eq_coeff_mul_eR, eR_add]
  ring

lemma eR_mul_sawSmoothMode_petermann_phase
    (S xi T : ℝ) (L : ℕ) (n : ℤ) (e : ℕ) (r : ℤ) :
    eR (xi * (e : ℝ)) *
        sawSmoothMode S n
          ((T / (L : ℝ) / (e : ℝ) + (r : ℝ) / (L : ℝ) :
            ℝ) : AddCircle (1 : ℝ)) =
      sawSmoothCoeff S n *
        eR ((n : ℝ) * (r : ℝ) / (L : ℝ)) *
        eR ((((n : ℝ) * T) / (L : ℝ)) / (e : ℝ) +
          xi * (e : ℝ)) := by
  rw [eR_mul_sawSmoothMode_coe]
  have hphase :
      (n : ℝ) *
          (T / (L : ℝ) / (e : ℝ) + (r : ℝ) / (L : ℝ)) +
          xi * (e : ℝ) =
        (n : ℝ) * (r : ℝ) / (L : ℝ) +
          ((((n : ℝ) * T) / (L : ℝ)) / (e : ℝ) +
            xi * (e : ℝ)) := by
    ring
  rw [hphase, eR_add]
  ring

#print axioms integral_smoothedSawCell_zero
#print axioms sawSmoothCoeff_zero
#print axioms eR_mul_sawSmoothMode_petermann_phase
#print axioms sawSmoothMode_coe_eq_coeff_mul_eR
#print axioms eR_mul_sawSmoothMode_coe
#print axioms smoothedSawCircle_coe_eq_smoothedSawtooth
#print axioms petermannSawtooth_partial_error_le
#print axioms smoothedSawtooth_ne_petermannSawtooth_only_near_jump

end PaperB.Analytic
