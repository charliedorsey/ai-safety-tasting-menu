import GoldB.KaratsubaMain

/-!
# GoldB.Final — Karatsuba's lemma (Suzuki, arXiv:1811.02556v2, §3, Lemma 1)

`karatsuba_lemma`: constants `γ, C` depending only on `c0, c1, c2, c3`, valid for every
order `k ≥ 1`, every length `P ≥ 1`, every real `X`, every phase `f`, and every sharp
clip `P1 ≤ P` of the sum over integers `X < n ≤ X + P1`.
-/

open Finset Set

namespace GoldB

lemma sum_reflect (g : ℤ → ℂ) (u v : ℤ) :
    ∑ a ∈ Finset.Icc u v, g a = ∑ m ∈ Finset.Icc (-v) (-u), g (-m) := by
  apply Finset.sum_nbij' (fun a => -a) (fun m => -m)
  · intro a ha; simp only [Finset.mem_coe, Finset.mem_Icc] at ha ⊢; omega
  · intro m hm; simp only [Finset.mem_coe, Finset.mem_Icc] at hm ⊢; omega
  · intro a _; simp
  · intro m _; simp
  · intro a _; simp

theorem karatsuba_lemma (c0 c1 c2 c3 : ℝ) (h0 : 0 < c0) (h0' : c0 < 1) (h3 : 0 < c3)
    (h32 : c3 ≤ c2) (h21 : c2 < c1) (h1 : c1 < 1) :
    ∃ γ C : ℝ, 0 < γ ∧ γ ≤ 1 ∧ 0 ≤ C ∧
      ∀ k : ℕ, 1 ≤ k → ∀ X P : ℝ, 1 ≤ P → ∀ f : ℝ → ℝ,
        (∀ x ∈ Set.Icc X (X + P), ContDiffAt ℝ (k + 1) f x) →
        (∀ x ∈ Set.Icc X (X + P),
          |iteratedDeriv (k + 1) f x| / (k + 1).factorial ≤ P ^ (-(c1 * (k + 1)))) →
        ∀ Js : Finset ℕ, Js ⊆ Finset.Icc 1 k → c0 * k ≤ Js.card →
        (∀ j ∈ Js, ∀ x ∈ Set.Icc X (X + P),
          P ^ (-(c2 * j)) ≤ |iteratedDeriv j f x| / j.factorial ∧
            |iteratedDeriv j f x| / j.factorial ≤ P ^ (-(c3 * j))) →
        ∀ P1 : ℝ, P1 ≤ P →
          ‖∑ n ∈ Finset.Ioc ⌊X⌋ ⌊X + P1⌋, ee (f n)‖ ≤ C * P ^ (1 - γ / (k : ℝ) ^ 2) := by
  classical
  let K : KParams := ⟨c0, c1, c2, c3, h0, h0', h3, h32, h21, h1⟩
  set P0 : ℝ := max ((2 : ℝ) ^ (1 / c3)) ((2 : ℝ) ^ (1 / (1 - c1)))
  set C : ℝ := max (2 * P0) (2 * (K.Kc + 2 * Real.pi + 2))
  have hKc := K.Kc_pos
  have hP0pos : 0 < P0 := lt_max_of_lt_left (by positivity)
  refine ⟨K.γ, C, K.γ_pos, K.γ_le_one, le_max_of_le_left (by positivity), ?_⟩
  intro k hk X P hP f hf hA Js hJs hJc hB P1 hP1
  have hP0 : 0 < P := by linarith
  have hkr : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hγk : K.γ / (k : ℝ) ^ 2 ≤ 1 :=
    (div_le_self K.γ_pos.le (by nlinarith)).trans K.γ_le_one
  have hCpos : 0 ≤ P ^ (1 - K.γ / (k : ℝ) ^ 2) := by positivity
  -- the selected orders as `Fin k`
  set S : Finset (Fin k) := univ.filter fun j : Fin k => (j : ℕ) + 1 ∈ Js
  have hSc : S.card = Js.card := by
    have himg : S.image (fun j : Fin k => (j : ℕ) + 1) = Js := by
      ext n
      simp only [S, Finset.mem_image, Finset.mem_filter, Finset.mem_univ, true_and]
      constructor
      · rintro ⟨j, hj, rfl⟩; exact hj
      · intro hn
        have := Finset.mem_Icc.mp (hJs hn)
        exact ⟨⟨n - 1, by omega⟩, by simp; rwa [show n - 1 + 1 = n by omega], by simp; omega⟩
    rw [← himg, Finset.card_image_of_injective _ (fun a b h => Fin.ext (by simpa using h))]
  have hS : K.c0 * k ≤ S.card := by rw [hSc]; exact hJc
  by_cases hbig : 2 ≤ P ^ c3 ∧ 2 ≤ P ^ (1 - c1)
  · obtain ⟨hPc3, hPc1⟩ := hbig
    have hP1' : 1 < P := by
      by_contra hle; push_neg at hle
      have : P ^ c3 ≤ 1 := Real.rpow_le_one hP0.le hle h3.le
      linarith
    -- hypotheses (B) in `Fin k` form
    have hBf : ∀ (g : ℝ → ℝ) (Y : ℝ),
        (∀ j ∈ Js, ∀ x ∈ Set.Icc Y (Y + P), P ^ (-(c2 * j)) ≤ |iteratedDeriv j g x| / j.factorial ∧
          |iteratedDeriv j g x| / j.factorial ≤ P ^ (-(c3 * j))) →
        ∀ j ∈ S, ∀ x ∈ Set.Icc Y (Y + P),
          P ^ (-(K.c2 * ((j : ℕ) + 1))) ≤ |iteratedDeriv ((j : ℕ) + 1) g x| / ((j : ℕ) + 1).factorial ∧
          |iteratedDeriv ((j : ℕ) + 1) g x| / ((j : ℕ) + 1).factorial ≤ P ^ (-(K.c3 * ((j : ℕ) + 1))) := by
      intro g Y hg j hj x hx
      have := hg ((j : ℕ) + 1) (mem_filter.mp hj).2 x hx
      simpa using this
    set M := ⌊X + P / 2⌋
    set lo := ⌊X⌋ + 1
    set hi := ⌊X + P1⌋
    have hsplit : ∑ n ∈ Finset.Ioc ⌊X⌋ hi, ee (f n) =
        ∑ n ∈ Finset.Icc lo (min hi M), ee (f n) + ∑ n ∈ Finset.Icc (max lo (M + 1)) hi, ee (f n) := by
      rw [← sum_filter_add_sum_filter_not (Finset.Ioc ⌊X⌋ hi) (fun n => n ≤ M)]
      congr 1
      · apply sum_congr _ (fun _ _ => rfl); ext n
        simp only [mem_filter, Finset.mem_Ioc, Finset.mem_Icc, lo]; omega
      · apply sum_congr _ (fun _ _ => rfl); ext n
        simp only [mem_filter, Finset.mem_Ioc, Finset.mem_Icc, lo]; omega
    -- left half
    have hL := K.left_bound k hk X P hP1' hPc3 hPc1 f hf hA S hS (hBf f X hB) lo (min hi M) (by
      intro a ha
      rw [Finset.mem_Icc] at ha
      constructor
      · have := Int.lt_floor_add_one X
        have : (lo : ℝ) ≤ a := by exact_mod_cast ha.1
        simp only [lo] at this; push_cast at this; linarith
      · have h1 : a ≤ M := ha.2.trans (min_le_right _ _)
        have h2 : (M : ℝ) ≤ X + P / 2 := Int.floor_le _
        have : (a : ℝ) ≤ M := by exact_mod_cast h1
        linarith)
    -- right half, by reflection
    set g : ℝ → ℝ := fun y => f (-y)
    have hR0 : ∑ n ∈ Finset.Icc (max lo (M + 1)) hi, ee (f n) =
        ∑ m ∈ Finset.Icc (-hi) (-(max lo (M + 1))), ee (g m) := by
      rw [sum_reflect]; apply sum_congr rfl; intro m _; simp [g]
    have hgI : ∀ x ∈ Set.Icc (-X - P) (-X - P + P), -x ∈ Set.Icc X (X + P) := by
      intro x hx; exact ⟨by linarith [hx.2], by linarith [hx.1]⟩
    have hR := K.left_bound k hk (-X - P) P hP1' hPc3 hPc1 g
      (fun x hx => contDiffAt_reflect f _ x (hf _ (hgI x hx)))
      (fun x hx => by rw [iteratedDeriv_reflect]; exact hA _ (hgI x hx))
      S hS
      (hBf g (-X - P) (by
        intro j hj x hx
        rw [iteratedDeriv_reflect]; exact hB j hj _ (hgI x hx)))
      (-hi) (-(max lo (M + 1))) (by
        intro m hm
        rw [Finset.mem_Icc] at hm
        constructor
        · have h1 : (hi : ℝ) ≤ X + P1 := Int.floor_le _
          have : ((-hi : ℤ) : ℝ) ≤ m := by exact_mod_cast hm.1
          push_cast at this; linarith
        · have h1 : X + P / 2 < (M : ℝ) + 1 := Int.lt_floor_add_one _
          have h2 : m ≤ -(M + 1) := hm.2.trans (neg_le_neg (le_max_right _ _))
          have : (m : ℝ) ≤ -((M : ℝ) + 1) := by exact_mod_cast h2
          linarith)
    rw [hsplit]
    calc ‖∑ n ∈ Finset.Icc lo (min hi M), ee (f n) + ∑ n ∈ Finset.Icc (max lo (M + 1)) hi, ee (f n)‖
        ≤ ‖∑ n ∈ Finset.Icc lo (min hi M), ee (f n)‖ +
            ‖∑ n ∈ Finset.Icc (max lo (M + 1)) hi, ee (f n)‖ := norm_add_le _ _
      _ ≤ (K.Kc + 2 * Real.pi + 2) * P ^ (1 - K.γ / (k : ℝ) ^ 2) +
            (K.Kc + 2 * Real.pi + 2) * P ^ (1 - K.γ / (k : ℝ) ^ 2) := by
          rw [hR0]; exact add_le_add hL hR
      _ = 2 * (K.Kc + 2 * Real.pi + 2) * P ^ (1 - K.γ / (k : ℝ) ^ 2) := by ring
      _ ≤ C * P ^ (1 - K.γ / (k : ℝ) ^ 2) :=
          mul_le_mul_of_nonneg_right (le_max_right _ _) hCpos
  · -- small `P`: the trivial bound
    have hPle : P ≤ P0 := by
      rw [not_and_or] at hbig
      push_neg at hbig
      rcases hbig with h | h
      · have : P ≤ (2 : ℝ) ^ (1 / c3) := by
          have e : P = (P ^ c3) ^ (1 / c3) := by
            rw [← Real.rpow_mul hP0.le, mul_one_div_cancel h3.ne', Real.rpow_one]
          rw [e]
          exact Real.rpow_le_rpow (by positivity) h.le (by positivity)
        exact this.trans (le_max_left _ _)
      · have hc : 0 < 1 - c1 := by linarith
        have : P ≤ (2 : ℝ) ^ (1 / (1 - c1)) := by
          have e : P = (P ^ (1 - c1)) ^ (1 / (1 - c1)) := by
            rw [← Real.rpow_mul hP0.le, mul_one_div_cancel hc.ne', Real.rpow_one]
          rw [e]
          exact Real.rpow_le_rpow (by positivity) h.le (by positivity)
        exact this.trans (le_max_right _ _)
    have hcard : ((Finset.Ioc ⌊X⌋ ⌊X + P1⌋).card : ℝ) ≤ 2 * P := by
      rw [Int.card_Ioc]
      have h1 : (⌊X + P1⌋ : ℝ) ≤ X + P1 := Int.floor_le _
      have h2 : X < (⌊X⌋ : ℝ) + 1 := Int.lt_floor_add_one _
      rcases le_or_gt ⌊X + P1⌋ ⌊X⌋ with hle | hlt
      · rw [Int.toNat_of_nonpos (by omega)]; simp; linarith
      · have : (((⌊X + P1⌋ - ⌊X⌋).toNat : ℤ) : ℝ) = (⌊X + P1⌋ : ℝ) - ⌊X⌋ := by
          rw [Int.toNat_of_nonneg (by omega)]; push_cast; ring
        have e : (((⌊X + P1⌋ - ⌊X⌋).toNat : ℕ) : ℝ) = (⌊X + P1⌋ : ℝ) - ⌊X⌋ := by exact_mod_cast this
        rw [e]; linarith
    have htriv : ‖∑ n ∈ Finset.Ioc ⌊X⌋ ⌊X + P1⌋, ee (f n)‖ ≤ 2 * P := by
      calc ‖∑ n ∈ Finset.Ioc ⌊X⌋ ⌊X + P1⌋, ee (f n)‖ ≤ ∑ n ∈ Finset.Ioc ⌊X⌋ ⌊X + P1⌋, ‖ee (f n)‖ :=
            norm_sum_le _ _
        _ = ((Finset.Ioc ⌊X⌋ ⌊X + P1⌋).card : ℝ) := by simp
        _ ≤ 2 * P := hcard
    have hPsplit : P = P ^ (K.γ / (k : ℝ) ^ 2) * P ^ (1 - K.γ / (k : ℝ) ^ 2) := by
      rw [← Real.rpow_add hP0]; simp
    have hsmall : P ^ (K.γ / (k : ℝ) ^ 2) ≤ P0 := by
      calc P ^ (K.γ / (k : ℝ) ^ 2) ≤ P ^ (1 : ℝ) := Real.rpow_le_rpow_of_exponent_le hP hγk
        _ = P := Real.rpow_one P
        _ ≤ P0 := hPle
    calc ‖∑ n ∈ Finset.Ioc ⌊X⌋ ⌊X + P1⌋, ee (f n)‖ ≤ 2 * P := htriv
      _ = 2 * (P ^ (K.γ / (k : ℝ) ^ 2) * P ^ (1 - K.γ / (k : ℝ) ^ 2)) := by rw [← hPsplit]
      _ ≤ 2 * (P0 * P ^ (1 - K.γ / (k : ℝ) ^ 2)) := by gcongr
      _ = (2 * P0) * P ^ (1 - K.γ / (k : ℝ) ^ 2) := by ring
      _ ≤ C * P ^ (1 - K.γ / (k : ℝ) ^ 2) :=
          mul_le_mul_of_nonneg_right (le_max_left _ _) hCpos

end GoldB
