import PaperB.Analytic.Kusmin
import PaperB.Analytic.DerivTest
import PaperB.Analytic.Basic
import PaperB.FixedQ.FixedConductorCompletion

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset

private lemma sum_range_shift_eq_Icc_zero
    (f : ℕ → ℂ) (W D : ℕ) (hWD : W ≤ D) :
    (∑ j ∈ Finset.range (D - W + 1), f (W + j)) =
      ∑ n ∈ Finset.Icc W D, f n := by
  apply Finset.sum_bij (fun j _ => W + j)
  · intro j hj
    rw [Finset.mem_range] at hj
    rw [Finset.mem_Icc]
    omega
  · intro j1 hj1 j2 hj2 h
    omega
  · intro n hn
    rw [Finset.mem_Icc] at hn
    refine ⟨n - W, ?_, ?_⟩
    · rw [Finset.mem_range]
      omega
    · omega
  · intro j hj
    rfl

lemma negative_reciprocal_phase_diff
    {A : ℝ} {m : ℕ} (hm : 0 < m) :
    (-A / ((m + 1 : ℕ) : ℝ)) - (-A / (m : ℝ))
      = A / ((m : ℝ) * ((m + 1 : ℕ) : ℝ)) := by
  have hmR : (0 : ℝ) < m := by exact_mod_cast hm
  have hm1R : (0 : ℝ) < (m + 1 : ℕ) := by positivity
  push_cast
  field_simp [hmR.ne', hm1R.ne']
  ring
lemma reciprocal_step_antitone
    {A : ℝ} (hA : 0 ≤ A) {m n : ℕ}
    (hm : 0 < m) (hmn : m ≤ n) :
    A / ((n : ℝ) * ((n + 1 : ℕ) : ℝ)) ≤
      A / ((m : ℝ) * ((m + 1 : ℕ) : ℝ)) := by
  have hmR : (0 : ℝ) < m := by exact_mod_cast hm
  have hnR : (0 : ℝ) < n := by
    exact_mod_cast lt_of_lt_of_le hm hmn
  have hden :
      (m : ℝ) * ((m + 1 : ℕ) : ℝ) ≤
        (n : ℝ) * ((n + 1 : ℕ) : ℝ) := by
    exact mul_le_mul
      (by exact_mod_cast hmn)
      (by exact_mod_cast Nat.add_le_add_right hmn 1)
      (by positivity) (by positivity)
  exact div_le_div_of_nonneg_left hA (by positivity) hden

lemma high_window_reciprocal_step_le_half
    {A : ℝ} {W : ℕ}
    (hA4 : 4 ≤ A)
    (hhigh : A ^ (3 / 4 : ℝ) < (W : ℝ)) :
    A / ((W : ℝ) * ((W + 1 : ℕ) : ℝ)) ≤ 1 / 2 := by
  have hA0 : 0 < A := lt_of_lt_of_le (by norm_num) hA4
  have hA : 0 ≤ A := hA0.le
  have hW0 : (0 : ℝ) < W := by
    have hr : 0 ≤ A ^ (3 / 4 : ℝ) := Real.rpow_nonneg hA _
    linarith
  have hsqrt : 2 ≤ Real.sqrt A := by
    apply (Real.le_sqrt (by norm_num) hA).2
    norm_num
    exact hA4
  have hrpow_sq :
      (A ^ (3 / 4 : ℝ)) ^ 2 = A * Real.sqrt A := by
    calc
      (A ^ (3 / 4 : ℝ)) ^ 2
          = (A ^ (3 / 4 : ℝ)) ^ (2 : ℝ) := by
              exact (Real.rpow_two (A ^ (3 / 4 : ℝ))).symm
      _ = A ^ ((3 / 4 : ℝ) * 2) := by
              rw [← Real.rpow_mul hA]
      _ = A ^ (1 + 1 / 2 : ℝ) := by norm_num
      _ = A ^ (1 : ℝ) * A ^ (1 / 2 : ℝ) := by
              rw [Real.rpow_add hA0]
      _ = A * Real.sqrt A := by
              rw [Real.rpow_one, Real.sqrt_eq_rpow]
  have hr0 : 0 ≤ A ^ (3 / 4 : ℝ) := Real.rpow_nonneg hA _
  have hWsq : (A ^ (3 / 4 : ℝ)) ^ 2 < (W : ℝ) ^ 2 := by
    nlinarith
  rw [hrpow_sq] at hWsq
  have h2A : 2 * A ≤ A * Real.sqrt A := by
    nlinarith
  have hden :
      2 * A ≤ (W : ℝ) * ((W + 1 : ℕ) : ℝ) := by
    have hWW :
        (W : ℝ) ^ 2 ≤ (W : ℝ) * ((W + 1 : ℕ) : ℝ) := by
      push_cast
      nlinarith
    nlinarith
  have hdenpos :
      0 < (W : ℝ) * ((W + 1 : ℕ) : ℝ) := by positivity
  rw [div_le_iff₀ hdenpos]
  nlinarith

lemma reciprocal_phase_diff_zero
    {A : ℝ} {m : ℕ} (hm : 0 < m) :
    (A / ((m + 1 : ℕ) : ℝ)) - (A / (m : ℝ))
      = -(A / ((m : ℝ) * ((m + 1 : ℕ) : ℝ))) := by
  have hmR : (0 : ℝ) < m := by exact_mod_cast hm
  have hm1R : (0 : ℝ) < (m + 1 : ℕ) := by positivity
  push_cast
  field_simp [hmR.ne', hm1R.ne']
  ring

theorem omega_high_zero_mode_prefix_bound
    {A : ℝ} {W B : ℕ}
    (hA4 : 4 ≤ A)
    (hW : 0 < W) (hWB : W ≤ B)
    (hhigh : A ^ (3 / 4 : ℝ) < (W : ℝ)) :
    ∀ k ≤ B - W + 1,
      ‖∑ j ∈ Finset.range k,
          eR (A / ((W + j : ℕ) : ℝ))‖
        ≤ ((B : ℝ) * ((B + 1 : ℕ) : ℝ)) / A := by
  intro k hk
  by_cases hk0 : k = 0
  · subst k
    simp
    have hA0 : 0 < A := lt_of_lt_of_le (by norm_num) hA4
    positivity
  · have hk1 : 1 ≤ k := Nat.one_le_iff_ne_zero.mpr hk0
    let D : ℕ := W + k - 1
    let delta : ℝ := A / ((B : ℝ) * ((B + 1 : ℕ) : ℝ))
    have hA0 : 0 < A := lt_of_lt_of_le (by norm_num) hA4
    have hA : 0 ≤ A := hA0.le
    have hB : 0 < B := lt_of_lt_of_le hW hWB
    have hWD : W ≤ D := by dsimp [D]; omega
    have hDB : D ≤ B := by dsimp [D]; omega
    have hdelta0 : 0 < delta := by
      dsimp [delta]
      positivity
    have hstepW :=
      high_window_reciprocal_step_le_half hA4 hhigh
    have hdelta_le_stepW :
        delta ≤ A / ((W : ℝ) * ((W + 1 : ℕ) : ℝ)) := by
      dsimp [delta]
      exact reciprocal_step_antitone hA hW hWB
    have hdeltahalf : delta ≤ 1 / 2 :=
      hdelta_le_stepW.trans hstepW
    let f : ℕ → ℝ := fun n => A / (n : ℝ)
    have hdiff : ∀ n : ℕ, 0 < n →
        f (n + 1) - f n =
          -(A / ((n : ℝ) * ((n + 1 : ℕ) : ℝ))) := by
      intro n hn
      simpa [f] using reciprocal_phase_diff_zero (A := A) hn
    have hgap_lb : ∀ n, W - 1 < n → n ≤ D →
        ((-1 : ℤ) : ℝ) + delta ≤ f (n + 1) - f n := by
      intro n hnW hnD
      have hnpos : 0 < n := by omega
      have hWn : W ≤ n := by omega
      have hnB : n ≤ B := le_trans hnD hDB
      rw [hdiff n hnpos]
      have hpW :
          A / ((n : ℝ) * ((n + 1 : ℕ) : ℝ)) ≤
            A / ((W : ℝ) * ((W + 1 : ℕ) : ℝ)) :=
        reciprocal_step_antitone hA hW hWn
      have hpHalf := hpW.trans hstepW
      have hp_one_minus :
          A / ((n : ℝ) * ((n + 1 : ℕ) : ℝ)) ≤ 1 - delta := by
        linarith [hpHalf, hdeltahalf]
      norm_num
      norm_num only [Nat.cast_add, Nat.cast_one] at hp_one_minus ⊢
      linarith [hp_one_minus]
    have hgap_ub : ∀ n, W - 1 < n → n ≤ D →
        f (n + 1) - f n ≤ ((-1 : ℤ) : ℝ) + 1 - delta := by
      intro n hnW hnD
      have hnpos : 0 < n := by omega
      have hnB : n ≤ B := le_trans hnD hDB
      rw [hdiff n hnpos]
      have hpB :
          delta ≤ A / ((n : ℝ) * ((n + 1 : ℕ) : ℝ)) := by
        dsimp [delta]
        exact reciprocal_step_antitone hA hnpos hnB
      norm_num
      norm_num only [Nat.cast_add, Nat.cast_one] at hpB ⊢
      exact hpB
    have hmono : ∀ n, W - 1 < n → n < D →
        f (n + 1) - f n ≤ f (n + 2) - f (n + 1) := by
      intro n hnW hnD
      have hnpos : 0 < n := by omega
      rw [hdiff n hnpos, hdiff (n + 1) (by omega)]
      have hp :=
        reciprocal_step_antitone hA hnpos
          (show n ≤ n + 1 by omega)
      have hp' :
          A / (((n + 1 : ℕ) : ℝ) * ((n + 2 : ℕ) : ℝ)) ≤
            A / ((n : ℝ) * ((n + 1 : ℕ) : ℝ)) := by
        simpa [Nat.add_assoc] using hp
      change
        -(A / ((n : ℝ) * ((n + 1 : ℕ) : ℝ))) ≤
          -(A / (((n + 1 : ℕ) : ℝ) * ((n + 2 : ℕ) : ℝ)))
      exact neg_le_neg hp'
    have hKL := kusmin_landau
      (f := f) (a := W - 1) (b := D)
      (δ := delta) (m := (-1 : ℤ))
      hdelta0 hdeltahalf hgap_lb hgap_ub hmono
    have hIcc :
        Finset.Ioc (W - 1) D = Finset.Icc W D := by
      ext n
      simp
      omega
    have hrange :
        (∑ j ∈ Finset.range k, eR (A / ((W + j : ℕ) : ℝ))) =
          ∑ n ∈ Finset.Icc W D, eR (A / (n : ℝ)) := by
      have hlen : D - W + 1 = k := by
        dsimp [D]
        omega
      rw [← hlen]
      exact sum_range_shift_eq_Icc_zero
        (fun n => eR (A / (n : ℝ))) W D hWD
    rw [hrange, ← hIcc]
    have hKLR :
        ‖∑ n ∈ Finset.Ioc (W - 1) D, eR (f n)‖ ≤ 1 / delta := by
      simpa only [eR_eq_eK] using hKL
    have hdelta_inv :
        1 / delta = ((B : ℝ) * ((B + 1 : ℕ) : ℝ)) / A := by
      dsimp [delta]
      field_simp [hA0.ne']
    simpa [f, hdelta_inv] using hKLR



theorem omega_high_zero_mode_reciprocal_weight_tail_raw
    {A : ℝ} {W B : ℕ}
    (hA4 : 4 ≤ A)
    (hW : 0 < W) (hWB : W ≤ B)
    (hhigh : A ^ (3 / 4 : ℝ) < (W : ℝ)) :
    ‖∑ m ∈ Finset.Icc W B,
        ((m : ℂ)⁻¹ * eR (A / (m : ℝ)))‖
      ≤ 2 * (((B : ℝ) * ((B + 1 : ℕ) : ℝ)) / A) / W := by
  let C : ℝ := ((B : ℝ) * ((B + 1 : ℕ) : ℝ)) / A
  let L : ℕ := B - W + 1
  let c : ℕ → ℂ := fun j => eR (A / ((W + j : ℕ) : ℝ))
  have hA0 : 0 < A := lt_of_lt_of_le (by norm_num) hA4
  have hB : 0 < B := lt_of_lt_of_le hW hWB
  have hC0 : 0 ≤ C := by
    dsimp [C]
    positivity
  have hprefix : ∀ k ≤ L,
      ‖∑ j ∈ Finset.range k, c j‖ ≤ C := by
    intro k hk
    simpa [C, L, c] using
      omega_high_zero_mode_prefix_bound hA4 hW hWB hhigh k hk
  have hps := partialSummation_reciprocal_weight_le
    W L hW c hC0 hprefix
  have hweighted :
      (∑ j ∈ Finset.range L, c j * reciprocalNatWeight W j) =
        ∑ m ∈ Finset.Icc W B,
          ((m : ℂ)⁻¹ * eR (A / (m : ℝ))) := by
    calc
      (∑ j ∈ Finset.range L, c j * reciprocalNatWeight W j)
          = ∑ j ∈ Finset.range L,
              ((W + j : ℂ)⁻¹ *
                eR (A / ((W + j : ℕ) : ℝ))) := by
              apply Finset.sum_congr rfl
              intro j hj
              dsimp [c, reciprocalNatWeight]
              simp [mul_comm]
      _ = ∑ m ∈ Finset.Icc W B,
              ((m : ℂ)⁻¹ * eR (A / (m : ℝ))) := by
              dsimp [L]
              simpa only [Nat.cast_add] using
                (sum_range_shift_eq_Icc_zero
                  (fun m => ((m : ℂ)⁻¹ * eR (A / (m : ℝ)))) W B hWB)
  rw [← hweighted]
  simpa [C] using hps

theorem omega_high_zero_mode_reciprocal_weight_tail
    {A : ℝ} {W B : ℕ}
    (hA4 : 4 ≤ A)
    (hW : 0 < W) (hWB : W ≤ B) (hB2 : B ≤ 2 * W)
    (hhigh : A ^ (3 / 4 : ℝ) < (W : ℝ)) :
    ‖∑ m ∈ Finset.Icc W B,
        ((m : ℂ)⁻¹ * eR (A / (m : ℝ)))‖
      ≤ 12 * (W : ℝ) / A := by
  have hraw :=
    omega_high_zero_mode_reciprocal_weight_tail_raw
      hA4 hW hWB hhigh
  have hA0 : 0 < A := lt_of_lt_of_le (by norm_num) hA4
  have hWreal : (0 : ℝ) < W := by exact_mod_cast hW
  have hBreal : (B : ℝ) ≤ 2 * (W : ℝ) := by exact_mod_cast hB2
  have hWp1 : ((B + 1 : ℕ) : ℝ) ≤ 3 * (W : ℝ) := by
    push_cast
    have hWone : (1 : ℝ) ≤ W := by exact_mod_cast hW
    linarith
  have hBB :
      (B : ℝ) * ((B + 1 : ℕ) : ℝ) ≤
        6 * (W : ℝ) ^ 2 := by
    nlinarith
  calc
    ‖∑ m ∈ Finset.Icc W B,
        ((m : ℂ)⁻¹ * eR (A / (m : ℝ)))‖
      ≤ 2 * (((B : ℝ) * ((B + 1 : ℕ) : ℝ)) / A) / W := hraw
    _ ≤ 12 * (W : ℝ) / A := by
      have hfac : 0 ≤ (2 : ℝ) / (A * (W : ℝ)) := by positivity
      have hm :=
        mul_le_mul_of_nonneg_right hBB hfac
      calc
        2 * (((B : ℝ) * ((B + 1 : ℕ) : ℝ)) / A) / (W : ℝ)
            = ((B : ℝ) * ((B + 1 : ℕ) : ℝ)) *
                (2 / (A * (W : ℝ))) := by
                  field_simp [hA0.ne', hWreal.ne']
        _ ≤ (6 * (W : ℝ) ^ 2) * (2 / (A * (W : ℝ))) := hm
        _ = 12 * (W : ℝ) / A := by
              field_simp [hA0.ne', hWreal.ne']
              ring

#print axioms omega_high_zero_mode_prefix_bound
#print axioms omega_high_zero_mode_reciprocal_weight_tail_raw
#print axioms omega_high_zero_mode_reciprocal_weight_tail

end PaperB.Analytic
