import PaperB.Analytic.PetermannOmegaR0002Tail

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

private lemma omega_r0002_sum_Icc_split
    {M0 : Type} [AddCommMonoid M0] (f : ℕ → M0)
    {a b c : ℕ} (hab : a ≤ b) (hbc : b ≤ c) :
    (∑ n ∈ Finset.Icc a c, f n) =
      (∑ n ∈ Finset.Icc a b, f n) +
      (∑ n ∈ Finset.Icc (b + 1) c, f n) := by
  have hdis : Disjoint (Finset.Icc a b) (Finset.Icc (b + 1) c) := by
    rw [Finset.disjoint_left]
    intro x hx1 hx2
    simp only [Finset.mem_Icc] at hx1 hx2
    omega
  have hunion :
      Finset.Icc a b ∪ Finset.Icc (b + 1) c = Finset.Icc a c := by
    ext x
    simp only [Finset.mem_union, Finset.mem_Icc]
    omega
  rw [← hunion, Finset.sum_union hdis]

noncomputable def omegaR0002LowBlockBound (M : ℕ) : ℝ :=
  (12 / Real.pi) * (1 + Real.log (M : ℝ))

noncomputable def omegaR0002LargeDivisorBranchBound (X : ℕ) : ℝ :=
  (12 / Real.pi) * (1 + Real.log ((X + 1 : ℕ) : ℝ))

noncomputable def omegaR0002AdditiveMajorant
    (q : ℕ) (beta : ℝ) (M H : ℕ) (T : ℝ) (D X : ℕ) : ℝ :=
  omegaRankinBound *
      (omegaR0002LowBlockBound M +
        omegaSmallDivisorTailBound q beta M H T D) +
    ((D + 1 : ℕ) : ℝ) ^ (-1 / 4 : ℝ) * omegaRankinBound *
      omegaR0002LargeDivisorBranchBound X

lemma omegaR0002LowBlockBound_nonneg (M : ℕ) (hM : 1 ≤ M) :
    0 ≤ omegaR0002LowBlockBound M := by
  unfold omegaR0002LowBlockBound
  have hlog : 0 ≤ Real.log (M : ℝ) :=
    Real.log_nonneg (by exact_mod_cast hM)
  positivity

lemma omegaR0002LargeDivisorBranchBound_nonneg (X : ℕ) :
    0 ≤ omegaR0002LargeDivisorBranchBound X := by
  unfold omegaR0002LargeDivisorBranchBound
  have hlog : 0 ≤ Real.log ((X + 1 : ℕ) : ℝ) :=
    Real.log_nonneg (by
      exact_mod_cast (show 1 ≤ X + 1 by omega))
  positivity

lemma omega_smoothed_branch_rewrite
    (q H X d : ℕ) (xi T : ℝ) (r : ℤ) (S : ℝ)
    (hd : 1 ≤ d) :
    let L := Nat.lcm 6 q
    (∑ m ∈ Finset.Icc 1 (X / d),
      (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
        (eR (xi * ((d * m : ℕ) : ℝ)) *
          sawSmoothPartial S H
            ((T / (L : ℝ) / ((d * m : ℕ) : ℝ) +
              (r : ℝ) / (L : ℝ) : ℝ) : AddCircle (1 : ℝ))))) =
    ∑ m ∈ Finset.Icc 1 (X / d),
      (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
        eR ((xi * (d : ℝ)) * (m : ℝ)) *
          sawSmoothPartial S H
            (((T / (L : ℝ) / (d : ℝ)) / (m : ℝ) +
              (r : ℝ) / (L : ℝ) : ℝ) : AddCircle (1 : ℝ))) := by
  dsimp only
  apply Finset.sum_congr rfl
  intro m hm
  have hm1 : 1 ≤ m := (Finset.mem_Icc.mp hm).1
  have hdR : (0 : ℝ) < d := by positivity
  have hmR : (0 : ℝ) < m := by positivity
  have hphase :
      eR (xi * ((d * m : ℕ) : ℝ)) =
        eR ((xi * (d : ℝ)) * (m : ℝ)) := by
    congr 1
    push_cast
    ring
  have hy :
      T / (Nat.lcm 6 q : ℝ) / ((d * m : ℕ) : ℝ) +
          (r : ℝ) / (Nat.lcm 6 q : ℝ) =
        (T / (Nat.lcm 6 q : ℝ) / (d : ℝ)) / (m : ℝ) +
          (r : ℝ) / (Nat.lcm 6 q : ℝ) := by
    push_cast
    field_simp [hdR.ne', hmR.ne']
  rw [hphase, hy]
  ring

theorem omega_small_divisor_branch_norm_le
    {S : ℝ} (hS : 1 < S)
    (q : ℕ) (hq : 0 < q)
    (h : ZMod (Nat.lcm 6 q))
    {beta T : ℝ} (hb0 : 0 < beta) (hb1 : beta < 1)
    (r : ℤ) {H d D M X : ℕ}
    (hH : 1 ≤ H)
    (hd : 1 ≤ d) (hdD : d ≤ D) (hD : 1 ≤ D)
    (hM : 1 < M) (hKM : fixedBetaNaturalOrder beta ≤ M)
    (hMXd : M ≤ X / d)
    (hT : 0 < T) (hXT : (X : ℝ) ≤ T)
    (hsource : (((H : ℝ) * T) ^ beta) ≤ (M : ℝ))
    (hbase :
      (2 * ((6 * q : ℕ) : ℝ)) ^ 2 ≤
        T / (((Nat.lcm 6 q : ℕ) : ℝ) * (D : ℝ))) :
    let L := Nat.lcm 6 q
    let xi := (h.val : ℝ) / (L : ℝ)
    ‖∑ m ∈ Finset.Icc 1 (X / d),
      (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
        (eR (xi * ((d * m : ℕ) : ℝ)) *
          sawSmoothPartial S H
            ((T / (L : ℝ) / ((d * m : ℕ) : ℝ) +
              (r : ℝ) / (L : ℝ) : ℝ) : AddCircle (1 : ℝ))))‖
      ≤ omegaR0002LowBlockBound M +
          omegaSmallDivisorTailBound q beta M H T D := by
  dsimp only
  let L := Nat.lcm 6 q
  let xi := (h.val : ℝ) / (L : ℝ)
  rw [omega_smoothed_branch_rewrite q H X d xi T r S hd]
  let f : ℕ → ℂ := fun m =>
    (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
      eR ((xi * (d : ℝ)) * (m : ℝ)) *
        sawSmoothPartial S H
          (((T / (L : ℝ) / (d : ℝ)) / (m : ℝ) +
            (r : ℝ) / (L : ℝ) : ℝ) : AddCircle (1 : ℝ)))
  have hM1 : 1 ≤ M - 1 := by omega
  have hMm1 : M - 1 ≤ X / d := by omega
  have hsplit := omega_r0002_sum_Icc_split f hM1 hMm1
  have hsucc : M - 1 + 1 = M := by omega
  rw [hsucc] at hsplit
  rw [hsplit]
  have hlow :
      ‖∑ m ∈ Finset.Icc 1 (M - 1), f m‖ ≤
        omegaR0002LowBlockBound M := by
    have hb := coprime_smoothed_partial_Icc_norm_le
      hS q H (M := 1) (N := M - 1) (by norm_num) hM1
      (fun m => eR ((xi * (d : ℝ)) * (m : ℝ)))
      (fun m => by simp)
      (fun m => (T / (L : ℝ) / (d : ℝ)) / (m : ℝ) +
        (r : ℝ) / (L : ℝ))
    have hcast : ((M - 1 + 1 : ℕ) : ℝ) = (M : ℝ) := by
      exact_mod_cast (show M - 1 + 1 = M by omega)
    simpa [f, omegaR0002LowBlockBound, hcast] using hb
  have htail :
      ‖∑ m ∈ Finset.Icc M (X / d), f m‖ ≤
        omegaSmallDivisorTailBound q beta M H T D := by
    simpa [f, xi, L] using
      (omega_coprime_smoothed_tail_norm_le hS q hq h
        hb0 hb1 r hH hd hdD hD hM hKM hMXd hT hXT hsource hbase)
  exact le_trans (norm_add_le _ _) (_root_.add_le_add hlow htail)

theorem omega_large_divisor_branch_norm_le
    {S : ℝ} (hS : 1 < S)
    (q H X d : ℕ) (xi T : ℝ) (r : ℤ)
    (hd : 1 ≤ d) (hdX : d ≤ X) :
    let L := Nat.lcm 6 q
    ‖∑ m ∈ Finset.Icc 1 (X / d),
      (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
        (eR (xi * ((d * m : ℕ) : ℝ)) *
          sawSmoothPartial S H
            ((T / (L : ℝ) / ((d * m : ℕ) : ℝ) +
              (r : ℝ) / (L : ℝ) : ℝ) : AddCircle (1 : ℝ))))‖
      ≤ omegaR0002LargeDivisorBranchBound X := by
  dsimp only
  let L := Nat.lcm 6 q
  rw [omega_smoothed_branch_rewrite q H X d xi T r S hd]
  have hXd : 1 ≤ X / d := by
    exact Nat.le_div_iff_mul_le (by omega) |>.2 (by simpa using hdX)
  have hb := coprime_smoothed_partial_Icc_norm_le
    hS q H (M := 1) (N := X / d) (by norm_num) hXd
    (fun m => eR ((xi * (d : ℝ)) * (m : ℝ)))
    (fun m => by simp)
    (fun m => (T / (L : ℝ) / (d : ℝ)) / (m : ℝ) +
      (r : ℝ) / (L : ℝ))
  have hNX : X / d + 1 ≤ X + 1 := by
    have := Nat.div_le_self X d
    omega
  have hlog :
      Real.log (((X / d + 1 : ℕ) : ℝ)) ≤
        Real.log (((X + 1 : ℕ) : ℝ)) := by
    apply Real.log_le_log (by positivity)
    exact_mod_cast hNX
  unfold omegaR0002LargeDivisorBranchBound
  calc
    _ ≤ (12 / Real.pi) *
      ((1 : ℝ) / (1 : ℝ) +
        (Real.log (((X / d + 1 : ℕ) : ℝ)) - Real.log (1 : ℝ))) := by
          simpa using hb
    _ ≤ (12 / Real.pi) * (1 + Real.log (((X + 1 : ℕ) : ℝ))) := by
      have hp : 0 ≤ 12 / Real.pi := by positivity
      apply mul_le_mul_of_nonneg_left _ hp
      norm_num at *
      linarith

theorem petermannOmegaSmoothedAdditiveKernel_norm_le_majorant
    {S : ℝ} (hS : 1 < S)
    (q : ℕ) (hq : 0 < q)
    (h : ZMod (Nat.lcm 6 q))
    {beta T : ℝ} (hb0 : 0 < beta) (hb1 : beta < 1)
    (r : ℤ) {H D M X : ℕ}
    (hH : 1 ≤ H) (hD : 1 ≤ D) (hDX : D ≤ X)
    (hM : 1 < M) (hKM : fixedBetaNaturalOrder beta ≤ M)
    (hMDX : M * D ≤ X)
    (hT : 0 < T) (hXT : (X : ℝ) ≤ T)
    (hsource : (((H : ℝ) * T) ^ beta) ≤ (M : ℝ))
    (hbase :
      (2 * ((6 * q : ℕ) : ℝ)) ^ 2 ≤
        T / (((Nat.lcm 6 q : ℕ) : ℝ) * (D : ℝ))) :
    ‖petermannOmegaSmoothedAdditiveKernel q H X S
        ((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) T r‖
      ≤ omegaR0002AdditiveMajorant q beta M H T D X := by
  let L := Nat.lcm 6 q
  let xi := (h.val : ℝ) / (L : ℝ)
  unfold petermannOmegaSmoothedAdditiveKernel
  rw [omega_weighted_sum_eq_correction_coprime]
  let branch : ℕ → ℂ := fun d =>
    ∑ m ∈ Finset.Icc 1 (X / d),
      (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
        (eR (xi * ((d * m : ℕ) : ℝ)) *
          sawSmoothPartial S H
            ((T / (L : ℝ) / ((d * m : ℕ) : ℝ) +
              (r : ℝ) / (L : ℝ) : ℝ) : AddCircle (1 : ℝ))))
  have hsplit := omega_r0002_sum_Icc_split
    (fun d => (omegaCorrectionInvTerm q d : ℂ) * branch d)
    (show 1 ≤ D by exact hD) hDX
  rw [hsplit]
  have hsmall :
      ‖∑ d ∈ Finset.Icc 1 D,
          (omegaCorrectionInvTerm q d : ℂ) * branch d‖
        ≤ omegaRankinBound *
            (omegaR0002LowBlockBound M +
              omegaSmallDivisorTailBound q beta M H T D) := by
    calc
      _ ≤ ∑ d ∈ Finset.Icc 1 D,
          ‖(omegaCorrectionInvTerm q d : ℂ) * branch d‖ :=
            norm_sum_le _ _
      _ ≤ ∑ d ∈ Finset.Icc 1 D,
          |omegaCorrectionInvTerm q d| *
            (omegaR0002LowBlockBound M +
              omegaSmallDivisorTailBound q beta M H T D) := by
        apply Finset.sum_le_sum
        intro d hdmem
        have hd1 : 1 ≤ d := (Finset.mem_Icc.mp hdmem).1
        have hdD : d ≤ D := (Finset.mem_Icc.mp hdmem).2
        have hMd : M * d ≤ X := by
          exact (Nat.mul_le_mul_left M hdD).trans hMDX
        have hMXd : M ≤ X / d := by
          exact (Nat.le_div_iff_mul_le (by omega)).2 hMd
        have hb := omega_small_divisor_branch_norm_le
          hS q hq h hb0 hb1 r hH hd1 hdD hD hM hKM hMXd
          hT hXT hsource hbase
        rw [norm_mul, Complex.norm_real, Real.norm_eq_abs]
        exact mul_le_mul_of_nonneg_left (by simpa [branch, xi, L] using hb)
          (abs_nonneg _)
      _ = (∑ d ∈ Finset.Icc 1 D, |omegaCorrectionInvTerm q d|) *
            (omegaR0002LowBlockBound M +
              omegaSmallDivisorTailBound q beta M H T D) := by
        rw [Finset.sum_mul]
      _ ≤ omegaRankinBound *
            (omegaR0002LowBlockBound M +
              omegaSmallDivisorTailBound q beta M H T D) := by
        apply mul_le_mul_of_nonneg_right
        · exact sum_Icc_abs_omegaCorrectionInvTerm_le_bound q D
        · apply add_nonneg
          · exact omegaR0002LowBlockBound_nonneg M (by omega)
          · unfold omegaSmallDivisorTailBound
            have hfour : 0 ≤ omegaFourierCoeffPairMassBound H :=
              omegaFourierCoeffPairMassBound_nonneg H
            have hmid : 0 ≤ omegaMiddleTailBound q beta M :=
              omegaMiddleTailBound_nonneg q hb0 M (by omega)
            have hP : 0 < (6 * q : ℕ) := by omega
            have hLnat : 0 < Nat.lcm 6 q :=
              Nat.lcm_pos (by norm_num) hq
            have hbasepos :
                0 < T / (((Nat.lcm 6 q : ℕ) : ℝ) * (D : ℝ)) := by
              have hs : 0 < (2 * ((6 * q : ℕ) : ℝ)) ^ 2 := by
                have hPr : (0 : ℝ) < (6 * q : ℕ) := by exact_mod_cast hP
                positivity
              exact lt_of_lt_of_le hs hbase
            have hpser : 0 ≤ omegaPSeriesTwo := omegaPSeriesTwo_nonneg
            positivity
  have hlarge :
      ‖∑ d ∈ Finset.Icc (D + 1) X,
          (omegaCorrectionInvTerm q d : ℂ) * branch d‖
        ≤ ((D + 1 : ℕ) : ℝ) ^ (-1 / 4 : ℝ) * omegaRankinBound *
            omegaR0002LargeDivisorBranchBound X := by
    calc
      _ ≤ ∑ d ∈ Finset.Icc (D + 1) X,
          ‖(omegaCorrectionInvTerm q d : ℂ) * branch d‖ :=
            norm_sum_le _ _
      _ ≤ ∑ d ∈ Finset.Icc (D + 1) X,
          |omegaCorrectionInvTerm q d| *
            omegaR0002LargeDivisorBranchBound X := by
        apply Finset.sum_le_sum
        intro d hdmem
        have hd1 : 1 ≤ d := by
          have := (Finset.mem_Icc.mp hdmem).1
          omega
        have hdX : d ≤ X := (Finset.mem_Icc.mp hdmem).2
        have hb := omega_large_divisor_branch_norm_le
          hS q H X d xi T r hd1 hdX
        rw [norm_mul, Complex.norm_real, Real.norm_eq_abs]
        exact mul_le_mul_of_nonneg_left (by simpa [branch, xi, L] using hb)
          (abs_nonneg _)
      _ = (∑ d ∈ Finset.Icc (D + 1) X,
              |omegaCorrectionInvTerm q d|) *
            omegaR0002LargeDivisorBranchBound X := by
        rw [Finset.sum_mul]
      _ ≤ ((D + 1 : ℕ) : ℝ) ^ (-1 / 4 : ℝ) * omegaRankinBound *
            omegaR0002LargeDivisorBranchBound X := by
        apply mul_le_mul_of_nonneg_right
        · exact sum_Icc_abs_omegaCorrectionInvTerm_tail_le
            q (D + 1) X (by omega)
        · exact omegaR0002LargeDivisorBranchBound_nonneg X
  exact le_trans (norm_add_le _ _) (by
    unfold omegaR0002AdditiveMajorant
    exact _root_.add_le_add hsmall hlarge)

#print axioms omega_small_divisor_branch_norm_le
#print axioms omega_large_divisor_branch_norm_le
#print axioms petermannOmegaSmoothedAdditiveKernel_norm_le_majorant

end PaperB.Analytic
