import PaperB.FixedQ.H2EndpointSmallProduct
import PaperB.FixedQ.H2BooleanInteriorEndpointBridge
import PaperB.FixedQ.H2BooleanFinalAssembly

open scoped BigOperators
open Filter Real Asymptotics

namespace PaperB.FixedQ

noncomputable def h2BooleanSourceCutoff (H : ℕ) : ℕ :=
  ⌊(Real.log (H : ℝ)) ^ h2BooleanSigma⌋₊

lemma h2BooleanSourceCutoff_cast_le
    {H : ℕ} (hH : 0 < H) :
    (h2BooleanSourceCutoff H : ℝ) ≤
      (Real.log (H : ℝ)) ^ h2BooleanSigma := by
  unfold h2BooleanSourceCutoff
  apply Nat.floor_le
  exact Real.rpow_nonneg (Real.log_nonneg (by exact_mod_cast hH)) _

lemma ordinaryBooleanCoreTerm_empty
    (q A H : ℕ) :
    ordinaryBooleanCoreTerm q A H ∅ = 0 := by
  simp [ordinaryBooleanCoreTerm, ordinaryBooleanInteriorDiscrepancy]

noncomputable def h2BooleanOrdinaryDyadicFullShell
    (q A H M : ℕ) : ℝ :=
  ∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
    finiteOmegaWeightReal S * (2 : ℝ) ^ S.card *
      |fixedProductBooleanDiscrepancy (fixedQLowWeight q A H) H S|

noncomputable def h2BooleanCombinedDyadicShell
    (q A H M : ℕ) : ℝ :=
  h2BooleanOrdinaryDyadicFullShell q A H M +
    h2EndpointDyadicShell q A H M

noncomputable def h2BooleanExteriorTerm
    (q A H N : ℕ) (S : Finset ℕ) : ℝ :=
  if S.Nonempty ∧ N < primeSetProduct S then
    ordinaryBooleanFullAbsTerm q A H S +
      ordinaryBooleanFullEndpointAbsTerm q A H S +
      ordinaryBooleanEmptyEndpointAbsTerm q A H S
  else 0

noncomputable def h2BooleanExteriorMajorant
    (q A H N : ℕ) : ℝ :=
  ∑' S : Finset ℕ, h2BooleanExteriorTerm q A H N S

noncomputable def h2BooleanGlobalSmallSets
    (q H N : ℕ) : Finset (Finset ℕ) := by
  classical
  exact (h2EndpointSmallProductSets q N).filter
    (fun S => S ∈ ordinaryTwoDimensionalSet H)

noncomputable def h2BooleanGlobalSmallMajorant
    (q A H N : ℕ) : ℝ :=
  ∑ S ∈ h2BooleanGlobalSmallSets q H N,
    (ordinaryBooleanFullAbsTerm q A H S +
      ordinaryBooleanFullEndpointAbsTerm q A H S +
      ordinaryBooleanEmptyEndpointAbsTerm q A H S)

lemma h2BooleanGlobalSmallSets_mem_endpoint
    {q H N : ℕ} {S : Finset ℕ}
    (hS : S ∈ h2BooleanGlobalSmallSets q H N) :
    S ∈ h2EndpointSmallProductSets q N := by
  classical
  exact (Finset.mem_filter.mp hS).1

lemma h2BooleanGlobalSmallSets_ordinary
    {q H N : ℕ} {S : Finset ℕ}
    (hS : S ∈ h2BooleanGlobalSmallSets q H N) :
    S ∈ ordinaryTwoDimensionalSet H := by
  classical
  exact (Finset.mem_filter.mp hS).2

lemma h2BooleanGlobalSmallSets_mem_ordinaryDyadic
    {q H N : ℕ} {S : Finset ℕ}
    (hS : S ∈ h2BooleanGlobalSmallSets q H N) :
    S ∈ h2BooleanOrdinaryDyadicSets q H (primeSetProduct S - 1) := by
  classical
  unfold h2BooleanOrdinaryDyadicSets
  apply Finset.mem_filter.mpr
  exact ⟨h2EndpointSmallProductSets_mem_dyadic
    (h2BooleanGlobalSmallSets_mem_endpoint hS),
    h2BooleanGlobalSmallSets_ordinary hS⟩

lemma ordinaryBooleanFullAbsTerm_eq_shellTerm_of_small
    {q A H N : ℕ} {S : Finset ℕ}
    (hS : S ∈ h2BooleanGlobalSmallSets q H N) :
    ordinaryBooleanFullAbsTerm q A H S =
      finiteOmegaWeightReal S * (2 : ℝ) ^ S.card *
        |fixedProductBooleanDiscrepancy (fixedQLowWeight q A H) H S| := by
  have hE := h2BooleanGlobalSmallSets_mem_endpoint hS
  have hAct : S ∈ activeOrdinaryTwoDimensionalSet q H :=
    ⟨h2BooleanGlobalSmallSets_ordinary hS,
      h2EndpointSmallProductSets_active hE⟩
  rw [ordinaryBooleanFullAbsTerm, Set.indicator_of_mem hAct]
  ring

lemma h2BooleanCombinedDyadicShell_nonneg
    (q A H M : ℕ) :
    0 ≤ h2BooleanCombinedDyadicShell q A H M := by
  unfold h2BooleanCombinedDyadicShell h2BooleanOrdinaryDyadicFullShell
  apply add_nonneg
  · apply Finset.sum_nonneg
    intro S hS
    have hA := h2BooleanDyadicSets_active
      (h2BooleanOrdinaryDyadicSets_mem hS).1
    exact mul_nonneg
      (mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hA)
        (pow_nonneg (by norm_num) _))
      (abs_nonneg _)
  · exact h2EndpointDyadicShell_nonneg q A H M

theorem h2BooleanGlobalSmallMajorant_le_dyadic_sum
    {q A H N : ℕ} :
    h2BooleanGlobalSmallMajorant q A H N ≤
      ∑ i ∈ Finset.range N, h2BooleanCombinedDyadicShell q A H i := by
  classical
  unfold h2BooleanGlobalSmallMajorant
  let F := h2BooleanGlobalSmallSets q H N
  let key : Finset ℕ → ℕ := fun S => primeSetProduct S - 1
  let f : Finset ℕ → ℝ := fun S =>
    ordinaryBooleanFullAbsTerm q A H S +
      ordinaryBooleanFullEndpointAbsTerm q A H S +
      ordinaryBooleanEmptyEndpointAbsTerm q A H S
  let g : ℕ → ℝ := fun i => h2BooleanCombinedDyadicShell q A H i
  change (∑ S ∈ F, f S) ≤ ∑ i ∈ Finset.range N, g i
  apply Finset.sum_le_sum_of_injOn key
  · intro S hSF T hTF hkey
    have hS : S ∈ h2BooleanGlobalSmallSets q H N := by
      simpa [F] using hSF
    have hT : T ∈ h2BooleanGlobalSmallSets q H N := by
      simpa [F] using hTF
    have hSs :
        S ∈ {U : Finset ℕ | U ∈ h2EndpointSmallProductSets q N} :=
      h2BooleanGlobalSmallSets_mem_endpoint hS
    have hTs :
        T ∈ {U : Finset ℕ | U ∈ h2EndpointSmallProductSets q N} :=
      h2BooleanGlobalSmallSets_mem_endpoint hT
    exact (h2EndpointSmallProductSets_key_injective (q := q) (N := N))
      hSs hTs hkey
  · intro i hi
    rcases Finset.mem_image.mp hi with ⟨S, hSF, rfl⟩
    have hS : S ∈ h2BooleanGlobalSmallSets q H N := by
      simpa [F] using hSF
    have hE := h2BooleanGlobalSmallSets_mem_endpoint hS
    apply Finset.mem_range.mpr
    have hmle := h2EndpointSmallProductSets_product_le hE
    have hm5 := h2EndpointSmallProductSets_product_ge_five hE
    dsimp [key]
    omega
  · intro S hSF
    have hS : S ∈ h2BooleanGlobalSmallSets q H N := by
      simpa [F] using hSF
    have hE := h2BooleanGlobalSmallSets_mem_endpoint hS
    have hdyFull := h2BooleanGlobalSmallSets_mem_ordinaryDyadic hS
    have hdyEnd := h2EndpointSmallProductSets_mem_dyadic hE
    have hFull :
        ordinaryBooleanFullAbsTerm q A H S ≤
          h2BooleanOrdinaryDyadicFullShell q A H (primeSetProduct S - 1) := by
      rw [ordinaryBooleanFullAbsTerm_eq_shellTerm_of_small hS]
      unfold h2BooleanOrdinaryDyadicFullShell
      exact Finset.single_le_sum
        (s := h2BooleanOrdinaryDyadicSets q H (primeSetProduct S - 1))
        (f := fun T =>
          finiteOmegaWeightReal T * (2 : ℝ) ^ T.card *
            |fixedProductBooleanDiscrepancy (fixedQLowWeight q A H) H T|)
        (fun T hT => by
          have hA := h2BooleanDyadicSets_active
            (h2BooleanOrdinaryDyadicSets_mem hT).1
          exact mul_nonneg
            (mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hA)
              (pow_nonneg (by norm_num) _))
            (abs_nonneg _))
        hdyFull
    have hEnd :
        ordinaryBooleanFullEndpointAbsTerm q A H S +
            ordinaryBooleanEmptyEndpointAbsTerm q A H S ≤
          h2EndpointDyadicShell q A H (primeSetProduct S - 1) := by
      unfold h2EndpointDyadicShell
      exact Finset.single_le_sum
        (s := h2BooleanDyadicSets q (primeSetProduct S - 1))
        (f := fun T =>
          ordinaryBooleanFullEndpointAbsTerm q A H T +
            ordinaryBooleanEmptyEndpointAbsTerm q A H T)
        (fun T hT =>
          h2EndpointCombinedTerm_nonneg_of_active
            (h2BooleanDyadicSets_active hT))
        hdyEnd
    dsimp [f, g, key]
    unfold h2BooleanCombinedDyadicShell
    linarith
  · intro i hi hnot
    dsimp [g]
    exact h2BooleanCombinedDyadicShell_nonneg q A H i

lemma h2BooleanCombinedAbsTerm_nonneg
    (q A H : ℕ) (S : Finset ℕ) :
    0 ≤ ordinaryBooleanFullAbsTerm q A H S +
      ordinaryBooleanFullEndpointAbsTerm q A H S +
      ordinaryBooleanEmptyEndpointAbsTerm q A H S := by
  by_cases hAct : S ∈ activeOrdinaryTwoDimensionalSet q H
  · rw [ordinaryBooleanFullAbsTerm, Set.indicator_of_mem hAct]
    rw [ordinaryBooleanFullEndpointAbsTerm, Set.indicator_of_mem hAct]
    rw [ordinaryBooleanEmptyEndpointAbsTerm, Set.indicator_of_mem hAct]
    have hw0 : 0 ≤ finiteOmegaWeightReal S :=
      finiteOmegaWeightReal_nonneg_of_active hAct.2
    positivity
  · simp [ordinaryBooleanFullAbsTerm,
      ordinaryBooleanFullEndpointAbsTerm,
      ordinaryBooleanEmptyEndpointAbsTerm, Set.indicator, hAct]

lemma h2BooleanGlobalSmallSets_of_active_le
    {q H N : ℕ} {S : Finset ℕ}
    (hAct : S ∈ activeOrdinaryTwoDimensionalSet q H)
    (hne : S.Nonempty)
    (hle : primeSetProduct S ≤ N) :
    S ∈ h2BooleanGlobalSmallSets q H N := by
  classical
  unfold h2BooleanGlobalSmallSets
  apply Finset.mem_filter.mpr
  constructor
  · unfold h2EndpointSmallProductSets
    apply Finset.mem_filter.mpr
    constructor
    · apply Finset.mem_powerset.mpr
      intro p hp
      unfold h2BooleanActivePrimesLE
      apply Finset.mem_filter.mpr
      constructor
      · apply Nat.mem_primesLE.mpr
        constructor
        · have hPrime : ∀ r ∈ S, r.Prime := fun r hr => (hAct.2 r hr).1
          have hprodPos : 0 < primeSetProduct S :=
            primeSetProduct_pos hPrime
          have hpdiv : p ∣ primeSetProduct S := by
            unfold primeSetProduct
            exact Finset.dvd_prod_of_mem (fun x : ℕ => x) hp
          exact (Nat.le_of_dvd hprodPos hpdiv).trans hle
        · exact (hAct.2 p hp).1
      · exact hAct.2 p hp
    · exact ⟨hne, hle⟩
  · exact hAct.1

lemma abs_ordinaryBooleanCoreTerm_le_small_or_exterior
    {q A H N : ℕ} (S : Finset ℕ) :
    |ordinaryBooleanCoreTerm q A H S| ≤
      (if S ∈ h2BooleanGlobalSmallSets q H N then
        ordinaryBooleanFullAbsTerm q A H S +
          ordinaryBooleanFullEndpointAbsTerm q A H S +
          ordinaryBooleanEmptyEndpointAbsTerm q A H S
      else 0) +
      h2BooleanExteriorTerm q A H N S := by
  classical
  by_cases hne : S.Nonempty
  · by_cases hAct : S ∈ activeOrdinaryTwoDimensionalSet q H
    · by_cases hle : primeSetProduct S ≤ N
      · have hsmall := h2BooleanGlobalSmallSets_of_active_le hAct hne hle
        rw [if_pos hsmall]
        have hnot : ¬ N < primeSetProduct S := by omega
        simp [h2BooleanExteriorTerm, hne, hnot]
        exact abs_ordinaryBooleanCoreTerm_le_full_add_endpoints q A H S
      · have hgt : N < primeSetProduct S := by omega
        simp [h2BooleanExteriorTerm, hne, hgt]
        exact (abs_ordinaryBooleanCoreTerm_le_full_add_endpoints q A H S).trans
          (by
            have hs0 := h2BooleanCombinedAbsTerm_nonneg q A H S
            by_cases hs : S ∈ h2BooleanGlobalSmallSets q H N
            · simp [hs]
              exact hs0
            · simp [hs, hs0])
    · have hz : ordinaryBooleanCoreTerm q A H S = 0 := by
        simp [ordinaryBooleanCoreTerm, Set.indicator, hAct]
      rw [hz, abs_zero]
      exact add_nonneg
        (by
          split_ifs
          · exact h2BooleanCombinedAbsTerm_nonneg q A H S
          · exact le_rfl)
        (by
          unfold h2BooleanExteriorTerm
          split_ifs
          · exact h2BooleanCombinedAbsTerm_nonneg q A H S
          · exact le_rfl)
  · have hS0 : S = ∅ := Finset.not_nonempty_iff_eq_empty.mp hne
    subst S
    rw [ordinaryBooleanCoreTerm_empty, abs_zero]
    have hEmpty0 : 0 ≤
        ordinaryBooleanFullAbsTerm q A H ∅ +
          ordinaryBooleanFullEndpointAbsTerm q A H ∅ +
          ordinaryBooleanEmptyEndpointAbsTerm q A H ∅ :=
      h2BooleanCombinedAbsTerm_nonneg q A H ∅
    have hExt0 : h2BooleanExteriorTerm q A H N ∅ = 0 := by
      simp [h2BooleanExteriorTerm]
    rw [hExt0, add_zero]
    split_ifs
    · exact hEmpty0
    · exact le_rfl

theorem ordinaryBooleanAbsFamily_le_small_plus_exterior
    {q A H N : ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H)
    (hExt : Summable (h2BooleanExteriorTerm q A H N)) :
    ordinaryBooleanAbsFamily q A H ≤
      h2BooleanGlobalSmallMajorant q A H N +
        h2BooleanExteriorMajorant q A H N := by
  classical
  let F := h2BooleanGlobalSmallSets q H N
  let small : Finset ℕ → ℝ := fun S =>
    if S ∈ F then
      ordinaryBooleanFullAbsTerm q A H S +
        ordinaryBooleanFullEndpointAbsTerm q A H S +
        ordinaryBooleanEmptyEndpointAbsTerm q A H S
    else 0
  have hSmall : Summable small := by
    apply summable_of_hasFiniteSupport
    refine F.finite_toSet.subset ?_
    intro S hSupp
    by_contra hmem
    change S ∉ F at hmem
    have hz : small S = 0 := by simp [small, hmem]
    exact hSupp hz
  have hAbs := summable_abs_ordinaryBooleanCoreTerm
    (q := q) (a := A) (h := H) hq hH h2admissible
  have hsum : Summable (fun S => small S +
      h2BooleanExteriorTerm q A H N S) :=
    hSmall.add hExt
  unfold ordinaryBooleanAbsFamily
  calc
    (∑' S : Finset ℕ, |ordinaryBooleanCoreTerm q A H S|)
      ≤ ∑' S : Finset ℕ,
          (small S + h2BooleanExteriorTerm q A H N S) := by
        exact hAbs.tsum_le_tsum
          (fun S => by
            simpa [small, F] using
              abs_ordinaryBooleanCoreTerm_le_small_or_exterior
                (q := q) (A := A) (H := H) (N := N) S)
          hsum
    _ = (∑' S : Finset ℕ, small S) +
        h2BooleanExteriorMajorant q A H N := by
          rw [hSmall.tsum_add hExt]
          rfl
    _ = h2BooleanGlobalSmallMajorant q A H N +
        h2BooleanExteriorMajorant q A H N := by
          congr 1
          rw [tsum_eq_sum (s := F)]
          · unfold h2BooleanGlobalSmallMajorant
            apply Finset.sum_congr
            · rfl
            · intro S hS
              have hSF : S ∈ F := by simpa [F] using hS
              simp [small, hSF]
          · intro S hS
            simp [small, hS]

theorem ordinaryBooleanAbsFamily_le_finite_shells_plus_exterior
    {q A H N : ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H)
    (hExt : Summable (h2BooleanExteriorTerm q A H N)) :
    ordinaryBooleanAbsFamily q A H ≤
      (∑ i ∈ Finset.range N,
        h2BooleanCombinedDyadicShell q A H i) +
      h2BooleanExteriorMajorant q A H N := by
  exact (ordinaryBooleanAbsFamily_le_small_plus_exterior
    hq hH h2admissible hExt).trans
      (add_le_add h2BooleanGlobalSmallMajorant_le_dyadic_sum
        (le_refl (h2BooleanExteriorMajorant q A H N)))

def H2BooleanExteriorReceipt
    (q A H N : ℕ) (Cext : ℝ) : Prop :=
  Summable (h2BooleanExteriorTerm q A H N) ∧
    h2BooleanExteriorMajorant q A H N ≤
      Cext *
        (Real.log (H : ℝ)) ^
          (h2BooleanSigma * h2BooleanX0) *
        (Real.log (Real.log (H : ℝ))) ^ 2

def H2BooleanExteriorGlobalBound (q : ℕ) : Prop :=
  ∃ Cext : ℝ, ∃ H0 : ℕ,
    0 ≤ Cext ∧
    ∀ A H : ℕ,
      q.Coprime A →
      0 < H →
      (¬ 2 ∣ q → 2 ∣ H) →
      H0 ≤ H →
      H2BooleanExteriorReceipt q A H (h2BooleanSourceCutoff H) Cext

theorem ordinaryBooleanAbsFamily_source_split_of_exterior_receipt
    {q A H : ℕ} (hq : 0 < q)
    (hA : q.Coprime A)
    (hH : 0 < H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H)
    {Cext : ℝ}
    (hExt : H2BooleanExteriorReceipt
      q A H (h2BooleanSourceCutoff H) Cext) :
    (h2BooleanSourceCutoff H : ℝ) ≤
        (Real.log (H : ℝ)) ^ h2BooleanSigma
    ∧
    ordinaryBooleanAbsFamily q A H ≤
      (∑ i ∈ Finset.range (h2BooleanSourceCutoff H),
        h2BooleanCombinedDyadicShell q A H i) +
      h2BooleanExteriorMajorant q A H (h2BooleanSourceCutoff H)
    ∧
    h2BooleanExteriorMajorant q A H (h2BooleanSourceCutoff H) ≤
      Cext *
        (Real.log (H : ℝ)) ^
          (h2BooleanSigma * h2BooleanX0) *
        (Real.log (Real.log (H : ℝ))) ^ 2 := by
  refine ⟨h2BooleanSourceCutoff_cast_le hH, ?_, hExt.2⟩
  exact ordinaryBooleanAbsFamily_le_finite_shells_plus_exterior
    hq hH h2admissible hExt.1

theorem ordinaryBooleanAbsFamily_le_source_shells_plus_exterior_rate_of_auren
    (q : ℕ) (hq : 0 < q)
    (hAuren : H2BooleanExteriorGlobalBound q) :
    ∃ Cext : ℝ, ∃ H0 : ℕ,
      0 ≤ Cext ∧
      ∀ A H : ℕ,
        q.Coprime A →
        0 < H →
        (¬ 2 ∣ q → 2 ∣ H) →
        H0 ≤ H →
        let N := h2BooleanSourceCutoff H
        (N : ℝ) ≤ (Real.log (H : ℝ)) ^ h2BooleanSigma
        ∧
        ordinaryBooleanAbsFamily q A H ≤
          (∑ i ∈ Finset.range N,
            h2BooleanCombinedDyadicShell q A H i) +
          h2BooleanExteriorMajorant q A H N
        ∧
        h2BooleanExteriorMajorant q A H N ≤
          Cext *
            (Real.log (H : ℝ)) ^
              (h2BooleanSigma * h2BooleanX0) *
            (Real.log (Real.log (H : ℝ))) ^ 2 := by
  rcases hAuren with ⟨Cext, H0, hCext, hExt⟩
  refine ⟨Cext, H0, hCext, ?_⟩
  intro A H hA hH h2 hH0
  dsimp
  exact ordinaryBooleanAbsFamily_source_split_of_exterior_receipt
    hq hA hH h2 (hExt A H hA hH h2 hH0)

#print axioms ordinaryBooleanAbsFamily_source_split_of_exterior_receipt
#print axioms ordinaryBooleanAbsFamily_le_source_shells_plus_exterior_rate_of_auren

#print axioms h2BooleanSourceCutoff_cast_le
#print axioms ordinaryBooleanCoreTerm_empty
#print axioms h2BooleanGlobalSmallSets_mem_ordinaryDyadic
#print axioms h2BooleanGlobalSmallMajorant_le_dyadic_sum
#print axioms ordinaryBooleanAbsFamily_le_finite_shells_plus_exterior

end PaperB.FixedQ
