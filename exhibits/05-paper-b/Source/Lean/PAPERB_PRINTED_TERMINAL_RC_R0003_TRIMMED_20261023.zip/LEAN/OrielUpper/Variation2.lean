import OrielUpper.Variation
import Mathlib.Algebra.BigOperators.Field

/-!
# Oriel Upper — the variation bound
-/

open Finset

namespace OrielUpper

variable {P : ℕ} [NeZero P]

theorem oriel_variation {m H : ℕ} [NeZero m] {Λ : ZMod P → ℝ} {B : ℝ}
    (hB : ∀ z, |Λ z| ≤ B) {α β v : ZMod P} {t : ZMod m}
    (hmP : IsUnit (m : ZMod P)) (hβ : IsUnit β) (hv : IsUnit v) (ht : IsUnit t)
    {X0 : ℝ} (hX0 : 0 ≤ X0) {e a b : ℕ} (he : 1 ≤ e) (hab : a < b) :
    |psiR m H Λ α β v t (X0 / (e * b)) / (e * b)| +
      ∑ i ∈ range (b - a - 1),
        |psiR m H Λ α β v t (X0 / (e * (a + 1 + (i + 1) : ℕ))) / (e * (a + 1 + (i + 1) : ℕ)) -
          psiR m H Λ α β v t (X0 / (e * (a + 1 + i : ℕ))) / (e * (a + 1 + i : ℕ))| ≤
      B / (e * (a + 1)) * (2 * (X0 / (e * (a + 1))) / m + 4 * P + 5) := by
  have hm : 0 < m := NeZero.pos m
  have hmr : (0 : ℝ) < m := by exact_mod_cast hm
  have her : (1 : ℝ) ≤ e := by exact_mod_cast he
  have hB0 : 0 ≤ B := le_trans (abs_nonneg _) (hB 0)
  have hmu := abs_muL_le hB
  set x : ℕ → ℝ := fun k => X0 / (e * k) with hx
  set ψ : ℕ → ℝ := fun k => psiR m H Λ α β v t (x k) with hψ
  set N : ℕ → ℝ := fun k => (rowN m H t (x k) : ℝ) with hN
  set E : ℝ := e * (a + 1) with hE
  have hEpos : 0 < E := by positivity
  have hkpos : ∀ k : ℕ, a + 1 ≤ k → (0 : ℝ) < e * k := by
    intro k hk
    have : (1 : ℝ) ≤ k := by exact_mod_cast (show 1 ≤ k by omega)
    positivity
  have hEle : ∀ k : ℕ, a + 1 ≤ k → E ≤ e * k := by
    intro k hk; rw [hE]; gcongr; exact_mod_cast hk
  have hxnn : ∀ k, 0 ≤ x k := fun k => by simp only [hx]; positivity
  have hxanti : ∀ k : ℕ, a + 1 ≤ k → x (k + 1) ≤ x k := by
    intro k hk
    simp only [hx]
    apply div_le_div_of_nonneg_left hX0 (hkpos k hk)
    push_cast; nlinarith
  have hψb : ∀ k, |ψ k| ≤ (2 * P + 2) * B := fun k =>
    oriel_psi_bound hm hB hmP hβ hv ht (hxnn k)
  -- increment of ψ
  have hinc : ∀ k : ℕ, a + 1 ≤ k →
      |ψ (k + 1) - ψ k| ≤ B * (N k - N (k + 1)) + B * (x k - x (k + 1)) / m := by
    intro k hk
    have hr := row_increment (m := m) (H := H) hB (α := α) (β := β) (v := v) (t := t)
      (hxanti k hk)
    simp only [hψ, psiR, hN]
    have e1 : (∑ u ∈ Icc 1 ⌊x (k + 1)⌋₊, rowF m H Λ α β v t u - muL Λ * x (k + 1) / m) -
        (∑ u ∈ Icc 1 ⌊x k⌋₊, rowF m H Λ α β v t u - muL Λ * x k / m) =
        -(∑ u ∈ Icc 1 ⌊x k⌋₊, rowF m H Λ α β v t u -
          ∑ u ∈ Icc 1 ⌊x (k + 1)⌋₊, rowF m H Λ α β v t u) +
        muL Λ * (x k - x (k + 1)) / m := by ring
    rw [e1]
    calc |-(∑ u ∈ Icc 1 ⌊x k⌋₊, rowF m H Λ α β v t u -
            ∑ u ∈ Icc 1 ⌊x (k + 1)⌋₊, rowF m H Λ α β v t u) + muL Λ * (x k - x (k + 1)) / m|
        ≤ |∑ u ∈ Icc 1 ⌊x k⌋₊, rowF m H Λ α β v t u -
            ∑ u ∈ Icc 1 ⌊x (k + 1)⌋₊, rowF m H Λ α β v t u| +
          |muL Λ * (x k - x (k + 1)) / m| := by
          refine (abs_add_le _ _).trans ?_; rw [abs_neg]
      _ ≤ B * ((rowN m H t (x k) : ℝ) - rowN m H t (x (k + 1))) +
          B * (x k - x (k + 1)) / m := by
          apply add_le_add hr
          rw [abs_div, abs_mul, abs_of_pos hmr, abs_of_nonneg (sub_nonneg.mpr (hxanti k hk))]
          apply div_le_div_of_nonneg_right _ hmr.le
          exact mul_le_mul_of_nonneg_right hmu (sub_nonneg.mpr (hxanti k hk))
  -- increment of g
  have hginc : ∀ k : ℕ, a + 1 ≤ k →
      |ψ (k + 1) / (e * (k + 1 : ℕ)) - ψ k / (e * k)| ≤
        (B * (N k - N (k + 1)) + B * (x k - x (k + 1)) / m) / E +
        (2 * P + 2) * B * (1 / (e * k) - 1 / (e * (k + 1 : ℕ))) := by
    intro k hk
    have hk1 := hkpos k hk
    have hk2 := hkpos (k + 1) (by omega)
    have e1 : ψ (k + 1) / (e * (k + 1 : ℕ)) - ψ k / (e * k) =
        (ψ (k + 1) - ψ k) / (e * (k + 1 : ℕ)) +
          ψ k * (1 / (e * (k + 1 : ℕ)) - 1 / (e * k)) := by field_simp; ring
    rw [e1]
    have hdiff : 0 ≤ 1 / ((e : ℝ) * k) - 1 / (e * (k + 1 : ℕ)) := by
      rw [sub_nonneg]; apply one_div_le_one_div_of_le hk1; push_cast; nlinarith
    refine (abs_add_le _ _).trans (add_le_add ?_ ?_)
    · rw [abs_div, abs_of_pos hk2]
      calc |ψ (k + 1) - ψ k| / (e * (k + 1 : ℕ))
          ≤ (B * (N k - N (k + 1)) + B * (x k - x (k + 1)) / m) / (e * (k + 1 : ℕ)) := by
            gcongr; exact hinc k hk
        _ ≤ (B * (N k - N (k + 1)) + B * (x k - x (k + 1)) / m) / E := by
            apply div_le_div_of_nonneg_left _ hEpos (hEle (k + 1) (by omega))
            have hNm : N (k + 1) ≤ N k := by
              simp only [hN]; exact_mod_cast rowN_mono (hxanti k hk)
            have : 0 ≤ x k - x (k + 1) := sub_nonneg.mpr (hxanti k hk)
            positivity
    · rw [abs_mul, show 1 / ((e : ℝ) * (k + 1 : ℕ)) - 1 / (e * k) =
          -(1 / ((e : ℝ) * k) - 1 / (e * (k + 1 : ℕ))) by ring, abs_neg, abs_of_nonneg hdiff]
      exact mul_le_mul_of_nonneg_right (hψb k) hdiff
  -- assemble
  set n := b - a - 1 with hn
  have hsum : ∑ i ∈ range n, |ψ (a + 1 + (i + 1)) / (e * (a + 1 + (i + 1) : ℕ)) -
      ψ (a + 1 + i) / (e * (a + 1 + i : ℕ))| ≤
      (B * (N (a + 1) - N (a + 1 + n)) + B * (x (a + 1) - x (a + 1 + n)) / m) / E +
        (2 * P + 2) * B * (1 / (e * (a + 1 : ℕ)) - 1 / (e * (a + 1 + n : ℕ))) := by
    have hT1 : ∑ i ∈ range n, (N (a + 1 + i) - N (a + 1 + (i + 1))) =
        N (a + 1) - N (a + 1 + n) := by
      rw [sum_range_sub' (fun i => N (a + 1 + i))]
    have hT2 : ∑ i ∈ range n, (x (a + 1 + i) - x (a + 1 + (i + 1))) =
        x (a + 1) - x (a + 1 + n) := by
      rw [sum_range_sub' (fun i => x (a + 1 + i))]
    have hT3 : ∑ i ∈ range n, (1 / ((e : ℝ) * (a + 1 + i : ℕ)) - 1 / (e * (a + 1 + (i + 1) : ℕ))) =
        1 / (e * (a + 1 : ℕ)) - 1 / (e * (a + 1 + n : ℕ)) := by
      rw [sum_range_sub' (fun i => 1 / ((e : ℝ) * (a + 1 + i : ℕ)))]
    calc ∑ i ∈ range n, |ψ (a + 1 + (i + 1)) / (e * (a + 1 + (i + 1) : ℕ)) -
          ψ (a + 1 + i) / (e * (a + 1 + i : ℕ))|
        ≤ ∑ i ∈ range n, ((B * (N (a + 1 + i) - N (a + 1 + (i + 1))) +
            B * (x (a + 1 + i) - x (a + 1 + (i + 1))) / m) / E +
            (2 * P + 2) * B * (1 / (e * (a + 1 + i : ℕ)) - 1 / (e * (a + 1 + (i + 1) : ℕ)))) := by
          apply sum_le_sum; intro i _
          have := hginc (a + 1 + i) (by omega)
          simpa [add_assoc] using this
      _ = _ := by
          rw [sum_add_distrib, ← Finset.sum_div, sum_add_distrib, ← mul_sum, ← Finset.sum_div,
            ← mul_sum, ← mul_sum, hT1, hT2, hT3]
  have hab' : a + 1 + n = b := by omega
  rw [hab'] at hsum
  -- final bounds
  have hNa : N (a + 1) ≤ x (a + 1) / m + 1 := rowN_le ht (hxnn _)
  have hNb : 0 ≤ N b := Nat.cast_nonneg _
  have hxb : 0 ≤ x b := hxnn b
  have hgb : |ψ b / (e * b)| ≤ (2 * P + 2) * B / E := by
    rw [abs_div, abs_of_pos (hkpos b (by omega))]
    calc |ψ b| / (e * b) ≤ (2 * P + 2) * B / (e * b) := by gcongr; exact hψb b
      _ ≤ (2 * P + 2) * B / E := by
        apply div_le_div_of_nonneg_left (by positivity) hEpos (hEle b (by omega))
  have hrec : 1 / ((e : ℝ) * (a + 1 : ℕ)) - 1 / (e * b) ≤ 1 / E := by
    have : 0 ≤ 1 / ((e : ℝ) * b) := by positivity
    rw [hE]; push_cast; linarith
  have hxa : x (a + 1) = X0 / E := by simp only [hx, hE]; push_cast; ring
  show |ψ b / (e * b)| + _ ≤ _
  have hsum' : ∑ i ∈ range (b - a - 1), |ψ (a + 1 + (i + 1)) / (e * (a + 1 + (i + 1) : ℕ)) -
      ψ (a + 1 + i) / (e * (a + 1 + i : ℕ))| ≤
      (B * (x (a + 1) / m + 1) + B * x (a + 1) / m) / E + (2 * P + 2) * B * (1 / E) := by
    refine hsum.trans (add_le_add ?_ ?_)
    · apply div_le_div_of_nonneg_right _ hEpos.le
      have h1 : B * (N (a + 1) - N b) ≤ B * (x (a + 1) / m + 1) := by
        apply mul_le_mul_of_nonneg_left _ hB0; linarith
      have h2 : B * (x (a + 1) - x b) / m ≤ B * x (a + 1) / m := by
        apply div_le_div_of_nonneg_right _ hmr.le; nlinarith
      linarith
    · apply mul_le_mul_of_nonneg_left hrec; positivity
  calc |ψ b / (e * b)| + ∑ i ∈ range (b - a - 1), |ψ (a + 1 + (i + 1)) /
          (e * (a + 1 + (i + 1) : ℕ)) - ψ (a + 1 + i) / (e * (a + 1 + i : ℕ))|
      ≤ (2 * P + 2) * B / E +
          ((B * (x (a + 1) / m + 1) + B * x (a + 1) / m) / E + (2 * P + 2) * B * (1 / E)) :=
        add_le_add hgb hsum'
    _ = B / E * (2 * (X0 / E) / m + 4 * P + 5) := by
        rw [hxa]; field_simp; ring

end OrielUpper
