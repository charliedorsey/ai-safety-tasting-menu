import PaperB.FixedQ.H2ProperSmallProductCover

open scoped BigOperators

set_option maxHeartbeats 800000

namespace PaperB.FixedQ

theorem h2BooleanProperCoreSmallMajorant_le_geometric_rate
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ N0 : ℕ,
      0 ≤ C ∧ 0 < N0 ∧
      ∀ A H Z : ℕ,
        (¬ 2 ∣ q → 2 ∣ H) →
        h2BooleanProperCoreSmallMajorant q A H Z ≤
          (12 * (fixedQPeriod q : ℝ)) *
              h2BooleanInitialProperWeightMass q N0 +
            ((Nat.log 2 Z + 1 : ℕ) : ℝ) * C *
              (Real.log ((N0 * 2 ^ (Nat.log 2 Z + 1) : ℕ) : ℝ)) ^
                (h2BooleanX0 - 1) *
              (Real.log
                (Real.log ((N0 * 2 ^ (Nat.log 2 Z + 1) : ℕ) : ℝ))) ^ 2 := by
  rcases h2BooleanProperGeometricPrefix_le_rate q hq with
    ⟨C, Nbase, hC, hprefix⟩
  let N0 := max Nbase 1
  have hN0 : 0 < N0 := by
    dsimp [N0]
    omega
  refine ⟨C, N0, hC, hN0, ?_⟩
  intro A H Z h2
  have hsplit :=
    h2BooleanProperCoreSmallMajorant_le_initial_add_middle
      (q := q) (A := A) (H := H) (N := N0) (Z := Z) hq h2
  have hmid :=
    h2BooleanProperCoreMiddleMajorant_le_geometricPrefix
      (q := q) (A := A) (H := H) (N := N0) (Z := Z) hN0
  have hNbase : Nbase ≤ N0 := by
    dsimp [N0]
    omega
  have hrate :=
    hprefix A H N0 (Nat.log 2 Z + 1) h2 hNbase
  calc
    h2BooleanProperCoreSmallMajorant q A H Z
      ≤ (12 * (fixedQPeriod q : ℝ)) *
          h2BooleanInitialProperWeightMass q N0 +
        h2BooleanProperCoreMiddleMajorant q A H N0 Z := hsplit
    _ ≤ (12 * (fixedQPeriod q : ℝ)) *
          h2BooleanInitialProperWeightMass q N0 +
        h2BooleanProperGeometricPrefix q A H N0 (Nat.log 2 Z + 1) :=
          add_le_add (le_refl _) hmid
    _ ≤ (12 * (fixedQPeriod q : ℝ)) *
          h2BooleanInitialProperWeightMass q N0 +
        ((Nat.log 2 Z + 1 : ℕ) : ℝ) * C *
          (Real.log ((N0 * 2 ^ (Nat.log 2 Z + 1) : ℕ) : ℝ)) ^
            (h2BooleanX0 - 1) *
          (Real.log
            (Real.log ((N0 * 2 ^ (Nat.log 2 Z + 1) : ℕ) : ℝ))) ^ 2 :=
          add_le_add (le_refl _) hrate

#print axioms h2BooleanProperCoreSmallMajorant_le_geometric_rate

end PaperB.FixedQ
