import PaperB.FixedQ.EtaLinearConvolution

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def omegaLinearArithmetic (q : ℕ) : ArithmeticFunction ℝ :=
  ⟨fun n => (n : ℝ) * omegaCoeff q n, by simp⟩

theorem omegaLinearArithmetic_multiplicative (q : ℕ) :
    (omegaLinearArithmetic q).IsMultiplicative := by
  constructor
  · simp [omegaLinearArithmetic, omegaCoeff]
  · intro m n hcop
    change (((m * n : ℕ) : ℝ) * omegaCoeff q (m * n)) =
      ((m : ℝ) * omegaCoeff q m) * ((n : ℝ) * omegaCoeff q n)
    have homega :=
      (omegaArithmetic_multiplicative q).map_mul_of_coprime hcop
    simp only [omegaArithmetic_apply] at homega
    rw [Nat.cast_mul, homega]
    ring

noncomputable def omegaLinearCorrectionLocal
    (q p nu : ℕ) : ℝ :=
  if nu = 0 then 1
  else if p.Prime ∧ p.Coprime (6 * q) then
    if nu = 1 then 3 / ((p : ℝ) - 3)
    else if nu = 2 then -(p : ℝ) / ((p : ℝ) - 3)
    else 0
  else 0

noncomputable def omegaLinearCorrectionCoeff
    (q n : ℕ) : ℝ :=
  if n = 0 then 0
  else ∏ p ∈ n.primeFactors,
    omegaLinearCorrectionLocal q p (n.factorization p)

noncomputable def omegaLinearCorrectionArithmetic
    (q : ℕ) : ArithmeticFunction ℝ :=
  ⟨omegaLinearCorrectionCoeff q, by simp [omegaLinearCorrectionCoeff]⟩

@[simp] theorem omegaLinearCorrectionArithmetic_apply (q n : ℕ) :
    omegaLinearCorrectionArithmetic q n = omegaLinearCorrectionCoeff q n := rfl

theorem omegaLinearCorrectionArithmetic_multiplicative (q : ℕ) :
    (omegaLinearCorrectionArithmetic q).IsMultiplicative := by
  constructor
  · change omegaLinearCorrectionCoeff q 1 = 1
    simp [omegaLinearCorrectionCoeff]
  · intro m n hcop
    change omegaLinearCorrectionCoeff q (m * n) =
      omegaLinearCorrectionCoeff q m * omegaLinearCorrectionCoeff q n
    by_cases hm0 : m = 0
    · subst m
      have hn1 : n = 1 := by simpa using hcop
      subst n
      simp [omegaLinearCorrectionCoeff]
    · by_cases hn0 : n = 0
      · subst n
        have hm1 : m = 1 := by simpa using hcop
        subst m
        simp [omegaLinearCorrectionCoeff]
      · have hmn0 : m * n ≠ 0 := mul_ne_zero hm0 hn0
        have hpf : (m * n).primeFactors =
            m.primeFactors ∪ n.primeFactors :=
          Nat.primeFactors_mul hm0 hn0
        have hdisj : Disjoint m.primeFactors n.primeFactors := by
          rw [Finset.disjoint_left]
          intro p hpm hpn
          have hpd : p ∣ m.gcd n :=
            Nat.dvd_gcd (Nat.dvd_of_mem_primeFactors hpm)
              (Nat.dvd_of_mem_primeFactors hpn)
          rw [hcop.gcd_eq_one] at hpd
          exact (Nat.prime_of_mem_primeFactors hpm).not_dvd_one hpd
        rw [omegaLinearCorrectionCoeff, if_neg hmn0,
          omegaLinearCorrectionCoeff, if_neg hm0,
          omegaLinearCorrectionCoeff, if_neg hn0, hpf,
          Finset.prod_union hdisj]
        congr 1
        · apply Finset.prod_congr rfl
          intro p hp
          have hpL : p ∈ m.primeFactorsList :=
            Nat.mem_primeFactors_iff_mem_primeFactorsList.mp hp
          rw [Nat.factorization_eq_of_coprime_left hcop hpL]
        · apply Finset.prod_congr rfl
          intro p hp
          have hpL : p ∈ n.primeFactorsList :=
            Nat.mem_primeFactors_iff_mem_primeFactorsList.mp hp
          rw [Nat.factorization_eq_of_coprime_right hcop hpL]

theorem omegaLinearArithmetic_prime_pow
    (q : ℕ) {p i : ℕ} (hp : p.Prime) :
    omegaLinearArithmetic q (p ^ i) =
      if i = 0 then 1
      else if i = 1 ∧ p.Coprime (6 * q) then
        (p : ℝ) / ((p : ℝ) - 3)
      else 0 := by
  by_cases hi0 : i = 0
  · subst i
    simp [omegaLinearArithmetic, omegaCoeff]
  · by_cases hi1 : i = 1
    · subst i
      by_cases hcop : p.Coprime (6 * q)
      · simp [omegaLinearArithmetic, omegaCoeff, hp, hp.ne_zero,
          hp.squarefree, hcop, div_eq_mul_inv]
      · simp [omegaLinearArithmetic, omegaCoeff, hp, hp.ne_zero,
          hp.squarefree, hcop]
    · have hsq : ¬ Squarefree (p ^ i) := by
        rw [Nat.squarefree_pow_iff hp.ne_one hi0]
        simp [hi1]
      have hp0 : p ^ i ≠ 0 := pow_ne_zero _ hp.ne_zero
      simp [omegaLinearArithmetic, omegaCoeff, hi0, hi1, hsq, hp0]

theorem omegaLinearCorrectionArithmetic_prime_pow
    (q : ℕ) {p i : ℕ} (hp : p.Prime) :
    omegaLinearCorrectionArithmetic q (p ^ i) =
      omegaLinearCorrectionLocal q p i := by
  by_cases hi0 : i = 0
  · subst i
    simp [omegaLinearCorrectionArithmetic, omegaLinearCorrectionCoeff,
      omegaLinearCorrectionLocal]
  · have hp0 : p ^ i ≠ 0 := pow_ne_zero _ hp.ne_zero
    rw [omegaLinearCorrectionArithmetic_apply,
      omegaLinearCorrectionCoeff, if_neg hp0,
      Nat.primeFactors_prime_pow hi0 hp]
    simp [omegaLinearCorrectionLocal, hp, hi0]

private lemma omega_sum_range_zero_two
    (a b : ℝ) (f : ℕ → ℝ) :
    ∀ i : ℕ,
      (∑ j ∈ Finset.range (i + 1),
        (if j = 0 then 1
         else if j = 1 then a
         else if j = 2 then b
         else 0) * f j) =
      if i = 0 then f 0
      else if i = 1 then f 0 + a * f 1
      else f 0 + a * f 1 + b * f 2 := by
  intro i
  induction i with
  | zero => simp
  | succ i ih =>
      rw [Finset.sum_range_succ, ih]
      cases i with
      | zero => simp
      | succ k =>
          cases k with
          | zero => simp
          | succ t =>
              have h0 : Nat.succ (Nat.succ (Nat.succ t)) ≠ 0 := by omega
              have h1 : Nat.succ (Nat.succ (Nat.succ t)) ≠ 1 := by omega
              have h2 : Nat.succ (Nat.succ (Nat.succ t)) ≠ 2 := by omega
              simp [h0, h1, h2]

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem omegaLinearCorrection_mul_coprime_prime_pow
    (q : ℕ) {p i : ℕ} (hp : p.Prime) :
    (omegaLinearCorrectionArithmetic q * coprimeIndicatorArithmetic q) (p ^ i) =
      omegaLinearArithmetic q (p ^ i) := by
  rw [ArithmeticFunction.mul_apply,
    Nat.sum_divisorsAntidiagonal
      (fun a b =>
        omegaLinearCorrectionArithmetic q a *
          coprimeIndicatorArithmetic q b),
    Nat.sum_divisors_prime_pow hp]
  have hdiv :
      ∀ j ∈ Finset.range (i + 1), p ^ i / p ^ j = p ^ (i - j) := by
    intro j hj
    have hji : j ≤ i := by
      simpa [Finset.mem_range] using hj
    have hpow : p ^ j * p ^ (i - j) = p ^ i :=
      pow_mul_pow_sub p hji
    rw [← hpow]
    exact Nat.mul_div_cancel_left _ (pow_pos hp.pos _)
  have hsum :
      (∑ j ∈ Finset.range (i + 1),
        omegaLinearCorrectionArithmetic q (p ^ j) *
          coprimeIndicatorArithmetic q (p ^ i / p ^ j)) =
      ∑ j ∈ Finset.range (i + 1),
        omegaLinearCorrectionLocal q p j *
          coprimeIndicatorArithmetic q (p ^ (i - j)) := by
    apply Finset.sum_congr rfl
    intro j hj
    rw [omegaLinearCorrectionArithmetic_prime_pow q hp, hdiv j hj]
  rw [hsum]
  by_cases hcop : p.Coprime (6 * q)
  · have hcorr : ∀ j : ℕ,
        omegaLinearCorrectionLocal q p j =
          if j = 0 then 1
          else if j = 1 then 3 / ((p : ℝ) - 3)
          else if j = 2 then -(p : ℝ) / ((p : ℝ) - 3)
          else 0 := by
      intro j
      by_cases hj0 : j = 0
      · simp [omegaLinearCorrectionLocal, hj0]
      · rw [omegaLinearCorrectionLocal, if_neg hj0]
        rw [if_pos ⟨hp, hcop⟩]
        simp [hj0]
    have hbase : ∀ j : ℕ,
        coprimeIndicatorArithmetic q (p ^ (i - j)) = 1 := by
      intro j
      rw [coprimeIndicatorArithmetic_prime_pow q hp]
      by_cases hz : i - j = 0
      · simp [hz]
      · simp [hz, hcop]
    simp_rw [hcorr, hbase]
    rw [omega_sum_range_zero_two
      (3 / ((p : ℝ) - 3))
      (-(p : ℝ) / ((p : ℝ) - 3))
      (fun _ => (1 : ℝ)) i]
    rw [omegaLinearArithmetic_prime_pow q hp]
    have hp3 : p ≠ 3 := by
      intro heq
      subst p
      have hd : 3 ∣ Nat.gcd 3 (6 * q) :=
        Nat.dvd_gcd (by norm_num)
          (dvd_mul_of_dvd_left (by norm_num : 3 ∣ 6) q)
      rw [hcop.gcd_eq_one] at hd
      norm_num at hd
    have hp3R : (p : ℝ) - 3 ≠ 0 := by
      exact sub_ne_zero.mpr (by exact_mod_cast hp3)
    by_cases hi0 : i = 0
    · subst i
      simp
    · by_cases hi1 : i = 1
      · have hcond : i = 1 ∧ p.Coprime (6 * q) := ⟨hi1, hcop⟩
        rw [if_neg hi0, if_pos hi1, if_neg hi0, if_pos hcond]
        field_simp [hp3R]
        ring
      · have hcond : ¬ (i = 1 ∧ p.Coprime (6 * q)) := by
          intro h
          exact hi1 h.1
        rw [if_neg hi0, if_neg hi1, if_neg hi0, if_neg hcond]
        field_simp [hp3R]
        ring
  · have hcorr : ∀ j : ℕ,
        omegaLinearCorrectionLocal q p j =
          if j = 0 then 1 else 0 := by
      intro j
      simp [omegaLinearCorrectionLocal, hp, hcop]
    simp_rw [hcorr]
    have hzero :
        (∑ j ∈ Finset.range (i + 1),
          (if j = 0 then 1 else 0) *
            coprimeIndicatorArithmetic q (p ^ (i - j))) =
          coprimeIndicatorArithmetic q (p ^ i) := by
      calc
        (∑ j ∈ Finset.range (i + 1),
          (if j = 0 then 1 else 0) *
            coprimeIndicatorArithmetic q (p ^ (i - j))) =
            (if 0 = 0 then 1 else 0) *
              coprimeIndicatorArithmetic q (p ^ (i - 0)) := by
                apply Finset.sum_eq_single 0
                · intro b hb hb0
                  simp [hb0]
                · simp
        _ = coprimeIndicatorArithmetic q (p ^ i) := by simp
    rw [hzero, coprimeIndicatorArithmetic_prime_pow q hp,
      omegaLinearArithmetic_prime_pow q hp]
    by_cases hi0 : i = 0
    · simp [hi0]
    · simp [hi0, hcop]

theorem omegaLinearArithmetic_eq_correction_mul_coprime (q : ℕ) :
    omegaLinearArithmetic q =
      omegaLinearCorrectionArithmetic q * coprimeIndicatorArithmetic q := by
  apply (ArithmeticFunction.IsMultiplicative.eq_iff_eq_on_prime_powers
    (omegaLinearArithmetic q)
    (omegaLinearArithmetic_multiplicative q)
    (omegaLinearCorrectionArithmetic q * coprimeIndicatorArithmetic q)
    ((omegaLinearCorrectionArithmetic_multiplicative q).mul
      (coprimeIndicatorArithmetic_multiplicative q))).2
  intro p i hp
  exact (omegaLinearCorrection_mul_coprime_prime_pow q hp).symm

#print axioms omegaLinearCorrection_mul_coprime_prime_pow
#print axioms omegaLinearArithmetic_eq_correction_mul_coprime

end PaperB.FixedQ
