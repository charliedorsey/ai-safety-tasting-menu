import PaperB.FixedQ.SignedForbiddenActiveSourceBridge

open scoped BigOperators

namespace PaperB.FixedQ

theorem tsum_dForbiddenBooleanMainTerm_eq_source_of_active
    {q a H : ℕ} {d : Finset ℕ}
    (hdActive : ∀ p ∈ d, activeHighPrime q p) :
    (∑' n : Finset ℕ, dForbiddenBooleanMainTerm q a H d n) =
      ∑' n : Finset ℕ, sourceForbiddenBooleanMainTerm q a H d n := by
  apply tsum_congr
  intro n
  exact dForbiddenBooleanMainTerm_eq_source_signed_of_active hdActive

theorem tsum_dForbiddenBooleanMainTerm_eq_naturalNat_of_active
    {q a H : ℕ} {d : Finset ℕ}
    (hdActive : ∀ p ∈ d, activeHighPrime q p) :
    (∑' n : Finset ℕ, dForbiddenBooleanMainTerm q a H d n) =
      ∑' m : ℕ,
        sourceForbiddenBooleanNaturalTerm q a H (primeSetProduct d) m := by
  rw [tsum_dForbiddenBooleanMainTerm_eq_source_of_active hdActive]
  exact tsum_sourceForbiddenBooleanMainTerm_eq_naturalNat q a H d

#print axioms tsum_dForbiddenBooleanMainTerm_eq_source_of_active
#print axioms tsum_dForbiddenBooleanMainTerm_eq_naturalNat_of_active

end PaperB.FixedQ
