import OrielLR.ZeroSum

/-!
# Oriel L/R — the single classical input and its use on progressions

`ShiftedKaratsuba` is the ONE external analytic premise of the Left/Right suppliers:
a uniform bound for sharp partial sums of the sawtooth along a shifted reciprocal
phase,

`|∑_{N < m ≤ U} ψ(X/(m+ϑ) + γ)| ≤ C (N exp(-c (log N)^3/(log X)^2) + N²/X)`

for all `X ≥ 2`, `N ≥ 1`, `N ≤ U ≤ 2N`, `0 ≤ ϑ ≤ 1`, `γ ∈ ℝ`.

It is the sawtooth form of the shifted Karatsuba reciprocal-sum estimate
(Elarin R0110 / Suzuki): the exponential form
`|∑_{N<m≤U} e(Y/(m+ϑ))| ≤ C (N exp(-c log³N/log²Y) + N²/Y)` gives this one by
Vaaler's trigonometric approximation of `ψ` (with a smaller `c`).
-/

open Finset

namespace OrielUpper

/-- **The single classical hypothesis** (shifted Karatsuba reciprocal sum, sawtooth form). -/
def ShiftedKaratsuba : Prop :=
  ∃ c Ck : ℝ, 0 < c ∧ 0 ≤ Ck ∧
    ∀ X : ℝ, 2 ≤ X → ∀ N : ℕ, 1 ≤ N → ∀ ϑ : ℝ, 0 ≤ ϑ → ϑ ≤ 1 → ∀ γ : ℝ,
      ∀ U : ℕ, U ≤ 2 * N →
        |∑ m ∈ Ioc N U, saw (X / ((m : ℝ) + ϑ) + γ)| ≤
          Ck * ((N : ℝ) * Real.exp (-(c * Real.log N ^ 3 / Real.log X ^ 2)) + (N : ℝ) ^ 2 / X)

/-- Abel summation against a nonnegative non-increasing weight. -/
lemma abel_bound {a w : ℕ → ℝ} {N U0 : ℕ} {E : ℝ} (hE : 0 ≤ E) (hw0 : ∀ m, 0 ≤ w m)
    (hwm : ∀ m, N < m → w (m + 1) ≤ w m)
    (hS : ∀ U, N ≤ U → U ≤ U0 → |∑ m ∈ Ioc N U, a m| ≤ E) :
    |∑ m ∈ Ioc N U0, a m * w m| ≤ E * w (N + 1) := by
  rcases Nat.lt_or_ge N U0 with hNU | hNU
  swap
  · rw [Ioc_eq_empty (by omega), sum_empty, abs_zero]
    exact mul_nonneg hE (hw0 _)
  -- claim
  have claim : ∀ U, N + 1 ≤ U → U ≤ U0 →
      |∑ m ∈ Ioc N U, a m * w m - (∑ m ∈ Ioc N U, a m) * w U| ≤ E * (w (N + 1) - w U) := by
    intro U hU
    induction U, hU using Nat.le_induction with
    | base =>
      intro _
      rw [Nat.Ioc_succ_singleton, sum_singleton, sum_singleton]; simp
    | succ U hU ih =>
      intro hU0
      have ih' := ih (by omega)
      rw [sum_Ioc_succ_top (by omega), sum_Ioc_succ_top (by omega)]
      have e : ∑ m ∈ Ioc N U, a m * w m + a (U + 1) * w (U + 1) -
          (∑ m ∈ Ioc N U, a m + a (U + 1)) * w (U + 1) =
          (∑ m ∈ Ioc N U, a m * w m - (∑ m ∈ Ioc N U, a m) * w U) +
            (∑ m ∈ Ioc N U, a m) * (w U - w (U + 1)) := by ring
      rw [e]
      have hd : 0 ≤ w U - w (U + 1) := by have := hwm U (by omega); linarith
      have hS' := hS U (by omega) (by omega)
      calc _ ≤ |∑ m ∈ Ioc N U, a m * w m - (∑ m ∈ Ioc N U, a m) * w U| +
            |(∑ m ∈ Ioc N U, a m) * (w U - w (U + 1))| := abs_add_le _ _
        _ ≤ E * (w (N + 1) - w U) + E * (w U - w (U + 1)) := by
            apply add_le_add ih'
            rw [abs_mul, abs_of_nonneg hd]
            exact mul_le_mul_of_nonneg_right hS' hd
        _ = E * (w (N + 1) - w (U + 1)) := by ring
  have h := claim U0 hNU le_rfl
  have hS0 := hS U0 hNU.le le_rfl
  have hw := hw0 U0
  calc |∑ m ∈ Ioc N U0, a m * w m|
      = |(∑ m ∈ Ioc N U0, a m * w m - (∑ m ∈ Ioc N U0, a m) * w U0) +
          (∑ m ∈ Ioc N U0, a m) * w U0| := by ring_nf
    _ ≤ E * (w (N + 1) - w U0) + E * w U0 := by
        refine (abs_add_le _ _).trans (add_le_add h ?_)
        rw [abs_mul, abs_of_nonneg hw]
        exact mul_le_mul_of_nonneg_right hS0 hw
    _ = E * w (N + 1) := by ring

/-- Splitting off one sharp clip. -/
lemma sum_Ioc_split_min (F : ℕ → ℝ) {a b c : ℕ} (hab : a ≤ b) :
    ∑ i ∈ Ioc a c, F i = ∑ i ∈ Ioc a (min b c), F i + ∑ i ∈ Ioc b c, F i := by
  rcases le_total b c with hbc | hbc
  · rw [min_eq_left hbc, sum_Ioc_consecutive _ hab hbc]
  · rw [min_eq_right hbc, Finset.Ioc_eq_empty_of_le hbc, sum_empty, add_zero]

/-- Geometric blocks `(i₁ 2^l, i₁ 2^{l+1}]`. -/
lemma sum_Ioc_blocks (F : ℕ → ℝ) (i1 i2 : ℕ) (Lb : ℕ) :
    ∑ i ∈ Ioc i1 i2, F i =
      ∑ l ∈ range Lb, ∑ i ∈ Ioc (i1 * 2 ^ l) (min (i1 * 2 ^ (l + 1)) i2), F i +
        ∑ i ∈ Ioc (i1 * 2 ^ Lb) i2, F i := by
  induction Lb with
  | zero => simp
  | succ L ih =>
    rw [ih, sum_range_succ, add_assoc]
    congr 1
    apply sum_Ioc_split_min
    exact Nat.mul_le_mul_left _ (Nat.pow_le_pow_right (by norm_num) (by omega))

/-- The classical input applied along a progression with harmonic weights. -/
theorem prog_vk {c Ck : ℝ} (hc : 0 < c) (hCk : 0 ≤ Ck)
    (hK : ∀ X : ℝ, 2 ≤ X → ∀ N : ℕ, 1 ≤ N → ∀ ϑ : ℝ, 0 ≤ ϑ → ϑ ≤ 1 → ∀ γ : ℝ,
      ∀ U : ℕ, U ≤ 2 * N →
        |∑ m ∈ Ioc N U, saw (X / ((m : ℝ) + ϑ) + γ)| ≤
          Ck * ((N : ℝ) * Real.exp (-(c * Real.log N ^ 3 / Real.log X ^ 2)) + (N : ℝ) ^ 2 / X))
    {X : ℝ} (hX : 2 ≤ X) {Q c0 : ℕ} (hQ : 0 < Q) (hc0 : c0 < Q) {e : ℝ} (he : 0 < e)
    {i1 i2 Lb : ℕ} (hi1 : 1 ≤ i1) (hLb : i2 ≤ i1 * 2 ^ Lb) (γ : ℝ) :
    |∑ i ∈ Ioc i1 i2, saw (X / ((i : ℝ) + (c0 : ℝ) / Q) + γ) / (e * ((c0 : ℝ) + Q * i))| ≤
      Lb * (Ck / (e * Q) *
        (Real.exp (-(c * Real.log i1 ^ 3 / Real.log X ^ 2)) + (i2 : ℝ) / X)) := by
  have hQr : (0 : ℝ) < Q := by exact_mod_cast hQ
  have hX0 : 0 < X := by linarith
  have hlX : 0 < Real.log X := Real.log_pos (by linarith)
  set F : ℕ → ℝ := fun i => saw (X / ((i : ℝ) + (c0 : ℝ) / Q) + γ) / (e * ((c0 : ℝ) + Q * i))
  rw [sum_Ioc_blocks F i1 i2 Lb, Ioc_eq_empty (by omega), sum_empty, add_zero]
  refine ((abs_sum_le_sum_abs _ _).trans (sum_le_sum (fun l _ => ?_))).trans
    (le_of_eq (by rw [sum_const, card_range, nsmul_eq_mul]))
  set N := i1 * 2 ^ l
  set U0 := min (i1 * 2 ^ (l + 1)) i2
  have hN1 : 1 ≤ N := Nat.one_le_iff_ne_zero.mpr (by positivity)
  have hNi1 : i1 ≤ N := Nat.le_mul_of_pos_right _ (by positivity)
  have hRHS0 : 0 ≤ Ck / (e * Q) *
      (Real.exp (-(c * Real.log i1 ^ 3 / Real.log X ^ 2)) + (i2 : ℝ) / X) := by positivity
  rcases Nat.lt_or_ge N U0 with hNU | hNU
  swap
  · rw [Ioc_eq_empty (by omega), sum_empty, abs_zero]; exact hRHS0
  have hU0N : U0 ≤ 2 * N := by
    have : i1 * 2 ^ (l + 1) = 2 * N := by simp only [N]; rw [pow_succ]; ring
    omega
  have hNi2 : N < i2 := lt_of_lt_of_le hNU (min_le_right _ _)
  set w : ℕ → ℝ := fun i => 1 / (e * ((c0 : ℝ) + Q * i))
  have hw0 : ∀ i, 0 ≤ w i := fun i => by simp only [w]; positivity
  have hwm : ∀ i, N < i → w (i + 1) ≤ w i := by
    intro i hi
    simp only [w]
    have hi1 : (1 : ℝ) ≤ i := by exact_mod_cast (show 1 ≤ i by omega)
    have hpos : (0 : ℝ) < (c0 : ℝ) + Q * i := by
      have : (0 : ℝ) ≤ c0 := Nat.cast_nonneg _
      nlinarith
    apply one_div_le_one_div_of_le (mul_pos he hpos)
    apply mul_le_mul_of_nonneg_left _ he.le
    push_cast; nlinarith
  set E := Ck * ((N : ℝ) * Real.exp (-(c * Real.log N ^ 3 / Real.log X ^ 2)) + (N : ℝ) ^ 2 / X)
  have hab := abel_bound (a := fun i => saw (X / ((i : ℝ) + (c0 : ℝ) / Q) + γ)) (w := w)
    (N := N) (U0 := U0) (E := E) (by simp only [E]; positivity) hw0 hwm (by
      intro U _ hU
      exact hK X hX N hN1 (c0 / Q) (by positivity)
        (by rw [div_le_one hQr]; exact_mod_cast hc0.le) γ U (hU.trans hU0N))
  have eF : ∑ i ∈ Ioc N U0, F i = ∑ i ∈ Ioc N U0,
      saw (X / ((i : ℝ) + (c0 : ℝ) / Q) + γ) * w i := by
    apply sum_congr rfl; intro i _; simp only [F, w]; ring
  rw [eF]
  refine hab.trans ?_
  have hNr : (1 : ℝ) ≤ N := by exact_mod_cast hN1
  have hlN : Real.log i1 ≤ Real.log N := Real.log_le_log (by exact_mod_cast hi1)
    (by exact_mod_cast hNi1)
  have hli1 : 0 ≤ Real.log i1 := Real.log_nonneg (by exact_mod_cast hi1)
  have hexp : Real.exp (-(c * Real.log N ^ 3 / Real.log X ^ 2)) ≤
      Real.exp (-(c * Real.log i1 ^ 3 / Real.log X ^ 2)) := by
    apply Real.exp_le_exp.mpr
    apply neg_le_neg
    apply div_le_div_of_nonneg_right _ (by positivity)
    apply mul_le_mul_of_nonneg_left _ hc.le
    exact pow_le_pow_left₀ hli1 hlN 3
  have hNX : (N : ℝ) / X ≤ (i2 : ℝ) / X :=
    div_le_div_of_nonneg_right (by exact_mod_cast hNi2.le) hX0.le
  have hw1 : w (N + 1) ≤ 1 / (e * Q * N) := by
    simp only [w]
    apply one_div_le_one_div_of_le (by positivity)
    push_cast; nlinarith
  have hE0 : 0 ≤ E := by simp only [E]; positivity
  calc E * w (N + 1) ≤ E * (1 / (e * Q * N)) := mul_le_mul_of_nonneg_left hw1 hE0
    _ = Ck / (e * Q) * (Real.exp (-(c * Real.log N ^ 3 / Real.log X ^ 2)) + (N : ℝ) / X) := by
        simp only [E]; field_simp
    _ ≤ _ := by
        apply mul_le_mul_of_nonneg_left _ (by positivity)
        linarith

end OrielUpper
