import Mathlib.Analysis.MeanInequalities
import Mathlib.Algebra.Order.Chebyshev
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic

/-!
# GoldB.RealAux

Small real-analysis helpers: power-mean, Hölder in the form used for the
ill-conditioned part, and the "absorb" lemma closing the p-adic step.
-/

open Finset

namespace GoldB

/-- `(∑_{h<p} u_h)^n ≤ (p^n / p) ∑ u_h^n` (power mean; also valid for `n = 0`). -/
lemma pow_sum_le_card_pow_div {ι : Type*} (s : Finset ι) (u : ι → ℝ) (hu : ∀ i ∈ s, 0 ≤ u i)
    (hs : s.Nonempty) (n : ℕ) :
    (∑ i ∈ s, u i) ^ n ≤ ((s.card : ℝ) ^ n / s.card) * ∑ i ∈ s, u i ^ n := by
  have hc : (0 : ℝ) < s.card := by exact_mod_cast hs.card_pos
  rcases Nat.eq_zero_or_pos n with h0 | hpos
  · subst h0; simp [ne_of_gt hc]
  · obtain ⟨m, rfl⟩ : ∃ m, n = m + 1 := ⟨n - 1, by omega⟩
    have := pow_sum_le_card_mul_sum_pow hu m
    calc (∑ i ∈ s, u i) ^ (m + 1) ≤ (s.card : ℝ) ^ m * ∑ i ∈ s, u i ^ (m + 1) := by
          exact_mod_cast this
      _ = ((s.card : ℝ) ^ (m + 1) / s.card) * ∑ i ∈ s, u i ^ (m + 1) := by
          rw [pow_succ, mul_div_assoc, div_self hc.ne', mul_one]

/-- Hölder for the ill-conditioned part: `∑ u^4 v^{2T-4} ≤ (∑ u^{2T})^{2/T} (∑ v^{2T})^{1-2/T}`. -/
lemma holder_four {ι : Type*} (s : Finset ι) (u v : ι → ℝ) (hu : ∀ i, 0 ≤ u i)
    (hv : ∀ i, 0 ≤ v i) (T : ℕ) (hT : 2 ≤ T) :
    ∑ i ∈ s, u i ^ 4 * v i ^ (2 * T - 4) ≤
      (∑ i ∈ s, u i ^ (2 * T)) ^ ((2 : ℝ) / T) *
        (∑ i ∈ s, v i ^ (2 * T)) ^ (1 - (2 : ℝ) / T) := by
  rcases eq_or_lt_of_le hT with h2 | hlt
  · subst h2
    norm_num
  · have hTr : (2 : ℝ) < T := by exact_mod_cast hlt
    have hT0 : (0 : ℝ) < T := by linarith
    set P : ℝ := (T : ℝ) / 2
    set Q : ℝ := (T : ℝ) / (T - 2)
    have hPQ : P.HolderConjugate Q := by
      rw [Real.holderConjugate_iff]
      refine ⟨by simp only [P]; linarith, ?_⟩
      simp only [P, Q]
      field_simp
      ring
    have h := Real.inner_le_Lp_mul_Lq s (fun i => u i ^ 4) (fun i => v i ^ (2 * T - 4)) hPQ
    have e1 : ∀ i, |u i ^ 4| ^ P = u i ^ (2 * T) := by
      intro i
      rw [abs_of_nonneg (by positivity), ← Real.rpow_natCast (u i) 4, ← Real.rpow_mul (hu i)]
      rw [← Real.rpow_natCast]
      congr 1; simp only [P]; push_cast; ring
    have e2 : ∀ i, |v i ^ (2 * T - 4)| ^ Q = v i ^ (2 * T) := by
      intro i
      rw [abs_of_nonneg (pow_nonneg (hv i) _), ← Real.rpow_natCast (v i), ← Real.rpow_mul (hv i)]
      rw [← Real.rpow_natCast]
      congr 1; simp only [Q]
      have : ((2 * T - 4 : ℕ) : ℝ) = 2 * T - 4 := by
        rw [Nat.cast_sub (by omega)]; push_cast; ring
      rw [this]
      have : (T : ℝ) - 2 ≠ 0 := by linarith
      field_simp
      push_cast; ring
    simp_rw [e1, e2] at h
    convert h using 2
    · simp only [P]; field_simp
    · simp only [Q]; field_simp

/-- the absorption step: `J ≤ 2X + 2c Y^{2/T} J^{1-2/T}` implies
`J ≤ max (4X) ((4c)^{T/2} Y)`. -/
lemma absorb (J X Y c : ℝ) (T : ℕ) (hT : 2 ≤ T) (hJ : 0 ≤ J) (hX : 0 ≤ X) (hY : 0 ≤ Y)
    (hc : 0 ≤ c)
    (h : J ≤ 2 * X + 2 * c * (Y ^ ((2 : ℝ) / T) * J ^ (1 - (2 : ℝ) / T))) :
    J ≤ max (4 * X) ((4 * c) ^ ((T : ℝ) / 2) * Y) := by
  by_cases h4 : J ≤ 4 * X
  · exact le_max_of_le_left h4
  push_neg at h4
  apply le_max_of_le_right
  have hJpos : 0 < J := lt_of_le_of_lt (by positivity) h4
  have hT0 : (0 : ℝ) < T := by
    have : (2 : ℝ) ≤ T := by exact_mod_cast hT
    linarith
  have h1 : J / 2 < 2 * c * (Y ^ ((2 : ℝ) / T) * J ^ (1 - (2 : ℝ) / T)) := by linarith
  -- divide by J^{1-2/T}
  have hJp : 0 < J ^ (1 - (2 : ℝ) / T) := Real.rpow_pos_of_pos hJpos _
  have h2 : J ^ ((2 : ℝ) / T) < 4 * c * Y ^ ((2 : ℝ) / T) := by
    have e : J = J ^ ((2 : ℝ) / T) * J ^ (1 - (2 : ℝ) / T) := by
      rw [← Real.rpow_add hJpos]; simp
    have : J ^ ((2 : ℝ) / T) * J ^ (1 - (2 : ℝ) / T) <
        (4 * c * Y ^ ((2 : ℝ) / T)) * J ^ (1 - (2 : ℝ) / T) := by
      rw [← e]; nlinarith
    exact lt_of_mul_lt_mul_right this hJp.le
  have h3 : (J ^ ((2 : ℝ) / T)) ^ ((T : ℝ) / 2) ≤
      (4 * c * Y ^ ((2 : ℝ) / T)) ^ ((T : ℝ) / 2) :=
    Real.rpow_le_rpow (by positivity) h2.le (by positivity)
  rw [← Real.rpow_mul hJ, Real.mul_rpow (by positivity) (by positivity),
    ← Real.rpow_mul hY] at h3
  have e2 : (2 : ℝ) / T * (T / 2) = 1 := by field_simp
  rw [e2, Real.rpow_one, Real.rpow_one] at h3
  exact h3

end GoldB
