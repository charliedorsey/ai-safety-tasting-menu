import Orienne.Central.HighCardGrowingR0001
import PaperB.Gate3.CentralTransfer.ThreeSectorConsumer

/-!
# Physical HIGH-cardinality source supplier — uniform sublog rate

The uniform-in-(a,h) numerical bound for the growing cardinality cutoff
is upgraded to the literal Merivelle.Central.SourceUniformSublog contract.
No artificial signed estimate or alternative source is introduced.
-/

open scoped BigOperators
open Filter Real

namespace Merivelle.Central

/-- Physical folded HIGH-card source is o(log h), at the growing
    cutoff `ceil(40 * log(log(h^2)))`, for every original central gate.
    The proof is uniform in the anchor a. -/
theorem orienne_highSector_sublog :
    SourceUniformSublog (highSector GoldC.orienneCentralHighCut) := by
  intro q hq hsq eps heps
  let C : ℝ := (4 + 48 * (q : ℝ)) * (8 * Real.exp 75)
  have hEventually : ∀ᶠ h : ℕ in atTop,
      C / eps ≤ Real.log (h : ℝ) :=
    (Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop).eventually
      (eventually_ge_atTop (C / eps))
  obtain ⟨H0, hH0⟩ := eventually_atTop.1 hEventually
  refine ⟨max 3 H0, ?_⟩
  intro a h hqa hh hpar hlarge
  have hh3 : 3 ≤ h := (le_max_left 3 H0).trans hlarge
  have hlog : C / eps ≤ Real.log (h : ℝ) :=
    hH0 h ((le_max_right 3 H0).trans hlarge)
  change |GoldC.regionSumCard
      (GoldC.orienneCentralHighCut h) true q h
      (GoldC.centralGate h) (GoldC.foldRow q a)| ≤
    eps * Real.log (h : ℝ)
  calc
    _ ≤ C := GoldC.orienne_physical_highCard_uniform q a h hq hh3
      (GoldC.centralGate h)
    _ = eps * (C / eps) := by
      field_simp
    _ ≤ eps * Real.log (h : ℝ) :=
      mul_le_mul_of_nonneg_left hlog heps.le

#print axioms orienne_highSector_sublog
end Merivelle.Central
