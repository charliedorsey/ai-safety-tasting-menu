import PaperB.Analytic.PetermannOmegaNearJumpSplit
import PaperB.Analytic.PetermannOmegaPartialSumLogBound

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset

theorem petermannOmegaSmoothingRemainder_le_eps_log_of_near_mass
    {S delta eps : ℝ} (hS : 1 < S) (hdelta : 0 ≤ delta) (heps : 0 < eps)
    {H : ℕ} (hH : 1 ≤ H)
    (q X : ℕ) (hq : 0 < q) (hX : 1 ≤ X)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (T : ℝ)
    (hXT : (X : ℝ) ≤ T)
    (hT : Real.exp 1 ≤ T)
    (hawaySmall :
      (S / (Real.pi ^ 2 * H)) *
        (((2 * (6 * q) + 10 : ℕ) : ℝ) * omegaRankinBound) ≤ eps / 2)
    (hnearSmall :
      (1 / 2 + sawSmoothPartialNormBound S H) * delta ≤ eps / 2)
    (hnear :
      petermannOmegaNearJumpMass q T r X S ≤ delta * Real.log T) :
    ‖petermannOmegaSmoothingRemainder q chi r T X H S‖
      ≤ eps * Real.log T := by
  have hsplit :=
    petermannOmegaSmoothingRemainder_le_away_add_near
      hS hH q X chi r T
  have hmass := omegaPartialSum_le_const_mul_log q X hq hX T hXT hT
  have hlog0 : 0 ≤ Real.log T := by
    have hTpos : 0 < T := (Real.exp_pos 1).trans_le hT
    exact Real.log_nonneg (by
      have : (1 : ℝ) ≤ Real.exp 1 := by
        rw [← Real.exp_zero]
        exact Real.exp_le_exp.mpr (by norm_num)
      exact this.trans hT)
  have hawayFac : 0 ≤ S / (Real.pi ^ 2 * H) := by positivity
  have hnearFac : 0 ≤ 1 / 2 + sawSmoothPartialNormBound S H := by
    have hb := sawSmoothPartialNormBound_nonneg S H
    positivity
  calc
    ‖petermannOmegaSmoothingRemainder q chi r T X H S‖
      ≤ (S / (Real.pi ^ 2 * H)) * omegaPartialSum q X +
          (1 / 2 + sawSmoothPartialNormBound S H) *
            petermannOmegaNearJumpMass q T r X S := hsplit
    _ ≤ (S / (Real.pi ^ 2 * H)) *
            ((((2 * (6 * q) + 10 : ℕ) : ℝ) * omegaRankinBound) *
              Real.log T) +
          (1 / 2 + sawSmoothPartialNormBound S H) *
            (delta * Real.log T) := by
      exact add_le_add
        (mul_le_mul_of_nonneg_left hmass hawayFac)
        (mul_le_mul_of_nonneg_left hnear hnearFac)
    _ = ((S / (Real.pi ^ 2 * H)) *
            (((2 * (6 * q) + 10 : ℕ) : ℝ) * omegaRankinBound) +
          (1 / 2 + sawSmoothPartialNormBound S H) * delta) *
            Real.log T := by ring
    _ ≤ (eps / 2 + eps / 2) * Real.log T := by
      exact mul_le_mul_of_nonneg_right
        (add_le_add hawaySmall hnearSmall) hlog0
    _ = eps * Real.log T := by ring

#print axioms petermannOmegaSmoothingRemainder_le_eps_log_of_near_mass

end PaperB.Analytic
