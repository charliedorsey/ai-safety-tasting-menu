import GoldC.QuillonSawDFT
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Deriv
import Mathlib.Analysis.Calculus.MeanValue
import GoldC.QuillonAbel

/-!
# Quillon CSC3: the cotangent form of the saw DFT coefficients, and monotonicity

* `phi_strictAnti`: `φ(y) = y·cos y/sin y` is strictly decreasing on `(0, π/2]`.
* `sawCoeff_cot`: for `0 < k < m`, `a_m(k) = (i/(2m))·cot(πk/m)`, i.e. `(i/2k)·φ(πk/m)/π`.

For a fixed frequency `j`, the R-route amplitude `a_{vu}(j)·conj(a_{v'u}(j))` is therefore a product of
two positive increasing functions of `u` (when `j ≤ vu/2`, `j ≤ v'u/2`). Its variation telescopes.

No axiom, no `sorry`.
-/

open Real

namespace GoldC.QuillonCot

noncomputable def phi (y : ℝ) : ℝ := y * Real.cos y / Real.sin y

lemma hasDerivAt_phi {y : ℝ} (hy : Real.sin y ≠ 0) :
    HasDerivAt phi ((Real.cos y * Real.sin y - y) / Real.sin y ^ 2) y := by
  have h1 : HasDerivAt (fun y => y * Real.cos y) (Real.cos y - y * Real.sin y) y := by
    have := (hasDerivAt_id' y).mul (Real.hasDerivAt_cos y)
    convert this using 1; ring
  have h2 := h1.div (Real.hasDerivAt_sin y) hy
  convert h2 using 1
  · ext x; simp [phi, Pi.div_apply]
  · have := Real.sin_sq_add_cos_sq y
    rw [show (Real.cos y - y * Real.sin y) * Real.sin y - y * Real.cos y * Real.cos y =
      Real.cos y * Real.sin y - y by linear_combination (-y) * this]

lemma phi_strictAnti : StrictAntiOn phi (Set.Ioc 0 (π / 2)) := by
  have hconv : Convex ℝ (Set.Ioc 0 (π / 2)) := convex_Ioc 0 (π / 2)
  have hsin : ∀ y ∈ Set.Ioc 0 (π / 2), Real.sin y ≠ 0 := by
    intro y hy
    exact (Real.sin_pos_of_pos_of_lt_pi hy.1 (by linarith [hy.2, Real.pi_pos])).ne'
  refine strictAntiOn_of_deriv_neg hconv ?_ ?_
  · intro y hy
    exact (hasDerivAt_phi (hsin y hy)).continuousAt.continuousWithinAt
  · intro y hy
    rw [interior_Ioc] at hy
    have hs := hsin y ⟨hy.1, hy.2.le⟩
    rw [(hasDerivAt_phi hs).deriv]
    apply div_neg_of_neg_of_pos
    · -- cos y sin y = sin(2y)/2 < y
      have h2 : Real.cos y * Real.sin y = Real.sin (2 * y) / 2 := by
        rw [Real.sin_two_mul]; ring
      have h3 := Real.sin_lt (show 0 < 2 * y by linarith [hy.1])
      rw [h2]; linarith
    · positivity

/-- `a_m(k) = (i/(2m))·cot(πk/m)`. -/
theorem sawCoeff_cot (m k : ℕ) (hm : 2 ≤ m) (hk : k ∈ Finset.Ioo 0 m) :
    GoldC.QuillonSawDFT.sawCoeff m k =
      Complex.I * ((Real.cos (π * k / m) / Real.sin (π * k / m) : ℝ) : ℂ) / (2 * m) := by
  rw [GoldC.QuillonSawDFT.sawCoeff_closed m k hm hk]
  have hk1 := Finset.mem_Ioo.1 hk
  have hmR : (0 : ℝ) < m := by exact_mod_cast (show 0 < m by omega)
  set θ : ℝ := π * k / m with hθ
  have hθ0 : 0 < θ := by rw [hθ]; have : (0:ℝ) < k := by exact_mod_cast hk1.1
                         positivity
  have hθπ : θ < π := by
    rw [hθ, div_lt_iff₀ hmR]
    have : (k : ℝ) < m := by exact_mod_cast hk1.2
    nlinarith [Real.pi_pos]
  have hsθ : Real.sin θ ≠ 0 := (Real.sin_pos_of_pos_of_lt_pi hθ0 hθπ).ne'
  -- ζ^{-k} = exp(-2iθ) = (cos θ − i sin θ)²
  have hz : GoldC.QuillonSawDFT.zeta m ^ (-(k : ℤ)) =
      (Complex.cos (θ : ℂ) - Complex.sin (θ : ℂ) * Complex.I) ^ 2 := by
    unfold GoldC.QuillonSawDFT.zeta
    rw [← Complex.exp_int_mul]
    have e1 : ((-(k : ℤ) : ℤ) : ℂ) * (2 * (π : ℂ) * Complex.I / (m : ℂ)) =
        2 * ((-(θ : ℂ)) * Complex.I) := by
      rw [hθ]; push_cast; field_simp
    rw [e1, show (2 : ℂ) * (-(θ : ℂ) * Complex.I) = (-(θ : ℂ) * Complex.I) + (-(θ : ℂ) * Complex.I) by ring,
      Complex.exp_add, Complex.exp_mul_I, Complex.cos_neg, Complex.sin_neg]
    ring
  rw [hz]
  have hmC : (m : ℂ) ≠ 0 := by exact_mod_cast (show m ≠ 0 by omega)
  have hsC : Complex.sin (θ : ℂ) ≠ 0 := by
    rw [← Complex.ofReal_sin]; exact_mod_cast hsθ
  have hC := Complex.sin_sq_add_cos_sq (θ : ℂ)
  set c := Complex.cos (θ : ℂ)
  set sn := Complex.sin (θ : ℂ)
  have hD : (c - sn * Complex.I) ^ 2 - 1 = -2 * sn * (sn + c * Complex.I) := by
    linear_combination hC + sn ^ 2 * Complex.I_sq
  have hprod : (sn - c * Complex.I) * (sn + c * Complex.I) = 1 := by
    linear_combination hC - c ^ 2 * Complex.I_sq
  have hne : sn + c * Complex.I ≠ 0 := by
    intro h; rw [h, mul_zero] at hprod; exact zero_ne_one hprod
  have hinv : (sn + c * Complex.I)⁻¹ = sn - c * Complex.I :=
    (eq_inv_of_mul_eq_one_left hprod).symm
  have hR : (((Real.cos (π * k / m) / Real.sin (π * k / m) : ℝ)) : ℂ) = c / sn := by
    rw [← hθ]; push_cast; rfl
  rw [hR, hD]
  have h2 : (1 : ℂ) / ((m : ℂ) * (-2 * sn * (sn + c * Complex.I))) =
      -(1 / (2 * (m : ℂ) * sn)) * (sn + c * Complex.I)⁻¹ := by
    field_simp
  rw [h2, hinv]
  field_simp
  ring

/-! ## Bounds on `φ` and the R-route amplitude variation -/

lemma phi_nonneg {y : ℝ} (h0 : 0 < y) (h1 : y ≤ π / 2) : 0 ≤ phi y := by
  unfold phi
  have hs : 0 < Real.sin y := Real.sin_pos_of_pos_of_lt_pi h0 (by linarith [Real.pi_pos])
  have hc : 0 ≤ Real.cos y := Real.cos_nonneg_of_neg_pi_div_two_le_of_le (by linarith) h1
  positivity

lemma phi_le_one {y : ℝ} (h0 : 0 < y) (h1 : y ≤ π / 2) : phi y ≤ 1 := by
  unfold phi
  have hs : 0 < Real.sin y := Real.sin_pos_of_pos_of_lt_pi h0 (by linarith [Real.pi_pos])
  rw [div_le_one hs]
  rcases lt_or_eq_of_le h1 with h | h
  · have hc : 0 < Real.cos y := Real.cos_pos_of_mem_Ioo ⟨by linarith, h⟩
    have := Real.le_tan h0.le h
    rw [Real.tan_eq_sin_div_cos, le_div_iff₀ hc] at this
    linarith
  · rw [h, Real.cos_pi_div_two, mul_zero]; rw [h] at hs; exact hs.le

/-- Real amplitude for frequency `j` at modulus `m`: `φ(πj/m)` (with `0 < πj/m ≤ π/2`). -/
noncomputable def amp (j m : ℕ) : ℝ := phi (π * j / m)

lemma amp_mono {j m m' : ℕ} (hj : 1 ≤ j) (hm : 2 * j ≤ m) (hmm : m ≤ m') :
    amp j m ≤ amp j m' := by
  unfold amp
  have hmR : (0 : ℝ) < m := by exact_mod_cast (show 0 < m by omega)
  have hm'R : (0 : ℝ) < m' := by exact_mod_cast (show 0 < m' by omega)
  have hjR : (0 : ℝ) < j := by exact_mod_cast hj
  have hle : π * j / m' ≤ π * j / m := by
    apply div_le_div_of_nonneg_left (by positivity) hmR (by exact_mod_cast hmm)
  have hin : ∀ x : ℕ, 2 * j ≤ x → π * j / x ∈ Set.Ioc 0 (π / 2) := by
    intro x hx
    have hxR : (0 : ℝ) < x := by exact_mod_cast (show 0 < x by omega)
    refine ⟨by positivity, ?_⟩
    rw [div_le_div_iff₀ hxR (by norm_num)]
    have : (2 * j : ℝ) ≤ x := by exact_mod_cast hx
    nlinarith [Real.pi_pos]
  exact phi_strictAnti.antitoneOn (hin m' (le_trans hm hmm)) (hin m hm) hle

/-- **Amplitude variation along an increasing progression.** If `x_t` is increasing with
`2j ≤ v·x_t` and `2j ≤ v'·x_t`, then the real amplitude `amp j (v x_t) · amp j (v' x_t)` is
increasing, nonnegative and `≤ 1`. Its Abel factor is `≤ 2`. -/
theorem amp_abel_factor (j v v' : ℕ) (hj : 1 ≤ j) (x : ℕ → ℕ) (N M : ℕ) (hNM : N + 1 ≤ M)
    (hx : ∀ t, N + 1 ≤ t → t < M → x t ≤ x (t + 1))
    (hpos : ∀ t, N + 1 ≤ t → t ≤ M → 2 * j ≤ v * x t ∧ 2 * j ≤ v' * x t) :
    ‖((amp j (v * x M) * amp j (v' * x M) : ℝ) : ℂ)‖ +
      ∑ t ∈ Finset.Ico (N + 1) M, ‖((amp j (v * x (t + 1)) * amp j (v' * x (t + 1)) : ℝ) : ℂ) -
        ((amp j (v * x t) * amp j (v' * x t) : ℝ) : ℂ)‖ ≤ 2 := by
  set f : ℕ → ℝ := fun t => amp j (v * x t) * amp j (v' * x t) with hf
  have hbounds : ∀ t, N + 1 ≤ t → t ≤ M → 0 ≤ f t ∧ f t ≤ 1 := by
    intro t h1 h2
    obtain ⟨ha, hb⟩ := hpos t h1 h2
    have hin : ∀ m : ℕ, 2 * j ≤ m → 0 < π * j / m ∧ π * j / m ≤ π / 2 := by
      intro m hm
      have hmR : (0 : ℝ) < m := by exact_mod_cast (show 0 < m by omega)
      have hjR : (0 : ℝ) < j := by exact_mod_cast hj
      refine ⟨by positivity, ?_⟩
      rw [div_le_div_iff₀ hmR (by norm_num)]
      have : (2 * j : ℝ) ≤ m := by exact_mod_cast hm
      nlinarith [Real.pi_pos]
    have e1 := hin _ ha; have e2 := hin _ hb
    have p1 := phi_nonneg e1.1 e1.2; have p2 := phi_nonneg e2.1 e2.2
    have q1 := phi_le_one e1.1 e1.2; have q2 := phi_le_one e2.1 e2.2
    simp only [hf, amp]
    exact ⟨mul_nonneg p1 p2, by nlinarith⟩
  have hmono : ∀ t, N + 1 ≤ t → t < M → f t ≤ f (t + 1) := by
    intro t h1 h2
    obtain ⟨ha, hb⟩ := hpos t h1 h2.le
    obtain ⟨ha', hb'⟩ := hpos (t + 1) (by omega) (by omega)
    have hxt := hx t h1 h2
    have m1 := amp_mono hj ha (Nat.mul_le_mul_left v hxt)
    have m2 := amp_mono hj hb (Nat.mul_le_mul_left v' hxt)
    have n1 := (hbounds t h1 h2.le)
    -- both factors nonnegative
    have hin : ∀ m : ℕ, 2 * j ≤ m → 0 ≤ amp j m := by
      intro m hm
      have hmR : (0 : ℝ) < m := by exact_mod_cast (show 0 < m by omega)
      have hjR : (0 : ℝ) < j := by exact_mod_cast hj
      refine phi_nonneg (by positivity) ?_
      rw [div_le_div_iff₀ hmR (by norm_num)]
      have : (2 * j : ℝ) ≤ m := by exact_mod_cast hm
      nlinarith [Real.pi_pos]
    simp only [hf]
    exact mul_le_mul m1 m2 (hin _ hb) (le_trans (hin _ ha) m1)
  have hvar := GoldC.QuillonAbel.variation_monotone f N M hNM hmono
  have hM := hbounds M (by omega) le_rfl
  have hN := hbounds (N + 1) le_rfl hNM
  rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg hM.1]
  have : ∑ t ∈ Finset.Ico (N + 1) M, ‖((f (t + 1) : ℝ) : ℂ) - ((f t : ℝ) : ℂ)‖ = f M - f (N + 1) :=
    hvar
  simp only [hf] at this ⊢
  rw [this]
  linarith [hM.2, hN.1]

/-! ## Clipped amplitude: one formula for all moduli -/

/-- `ampC j m = φ(min(πj/m, π/2))`. It vanishes once `2j ≥ m`, and is increasing in `m`. -/
noncomputable def ampC (j m : ℕ) : ℝ := phi (min (π * j / m) (π / 2))

lemma ampC_mem (j m : ℕ) (hj : 1 ≤ j) (hm : 1 ≤ m) :
    0 < min (π * j / m) (π / 2) ∧ min (π * j / m) (π / 2) ≤ π / 2 := by
  have hmR : (0 : ℝ) < m := by exact_mod_cast hm
  have hjR : (0 : ℝ) < j := by exact_mod_cast hj
  exact ⟨lt_min (by positivity) (by linarith [Real.pi_pos]), min_le_right _ _⟩

lemma ampC_bounds (j m : ℕ) (hj : 1 ≤ j) (hm : 1 ≤ m) : 0 ≤ ampC j m ∧ ampC j m ≤ 1 := by
  obtain ⟨h0, h1⟩ := ampC_mem j m hj hm
  exact ⟨phi_nonneg h0 h1, phi_le_one h0 h1⟩

lemma ampC_mono {j m m' : ℕ} (hj : 1 ≤ j) (hm : 1 ≤ m) (hmm : m ≤ m') : ampC j m ≤ ampC j m' := by
  unfold ampC
  have hmR : (0 : ℝ) < m := by exact_mod_cast hm
  have hle : min (π * j / m') (π / 2) ≤ min (π * j / m) (π / 2) := by
    apply min_le_min_right
    have hjR : (0 : ℝ) ≤ j := by positivity
    exact div_le_div_of_nonneg_left (by positivity) hmR (by exact_mod_cast hmm)
  exact phi_strictAnti.antitoneOn (ampC_mem j m' hj (le_trans hm hmm))
    (ampC_mem j m hj hm) hle

/-- Abel factor of the clipped R amplitude along an increasing progression (no range hypothesis). -/
theorem ampC_abel_factor (j v v' : ℕ) (hj : 1 ≤ j) (x : ℕ → ℕ) (N M : ℕ) (hNM : N + 1 ≤ M)
    (hx : ∀ t, N + 1 ≤ t → t < M → x t ≤ x (t + 1))
    (hpos : ∀ t, N + 1 ≤ t → t ≤ M → 1 ≤ v * x t ∧ 1 ≤ v' * x t) :
    ‖((ampC j (v * x M) * ampC j (v' * x M) : ℝ) : ℂ)‖ +
      ∑ t ∈ Finset.Ico (N + 1) M, ‖((ampC j (v * x (t + 1)) * ampC j (v' * x (t + 1)) : ℝ) : ℂ) -
        ((ampC j (v * x t) * ampC j (v' * x t) : ℝ) : ℂ)‖ ≤ 2 := by
  set f : ℕ → ℝ := fun t => ampC j (v * x t) * ampC j (v' * x t) with hf
  have hbounds : ∀ t, N + 1 ≤ t → t ≤ M → 0 ≤ f t ∧ f t ≤ 1 := by
    intro t h1 h2
    obtain ⟨ha, hb⟩ := hpos t h1 h2
    have p1 := ampC_bounds j _ hj ha; have p2 := ampC_bounds j _ hj hb
    simp only [hf]; exact ⟨mul_nonneg p1.1 p2.1, by nlinarith [p1.1, p1.2, p2.1, p2.2]⟩
  have hmono : ∀ t, N + 1 ≤ t → t < M → f t ≤ f (t + 1) := by
    intro t h1 h2
    obtain ⟨ha, hb⟩ := hpos t h1 h2.le
    have hxt := hx t h1 h2
    have m1 := ampC_mono hj ha (Nat.mul_le_mul_left v hxt)
    have m2 := ampC_mono hj hb (Nat.mul_le_mul_left v' hxt)
    simp only [hf]
    exact mul_le_mul m1 m2 (ampC_bounds j _ hj hb).1 (le_trans (ampC_bounds j _ hj ha).1 m1)
  have hvar := GoldC.QuillonAbel.variation_monotone f N M hNM hmono
  have hM := hbounds M (by omega) le_rfl
  have hN := hbounds (N + 1) le_rfl hNM
  rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg hM.1]
  have : ∑ t ∈ Finset.Ico (N + 1) M, ‖((f (t + 1) : ℝ) : ℂ) - ((f t : ℝ) : ℂ)‖ = f M - f (N + 1) :=
    hvar
  simp only [hf] at this ⊢
  rw [this]
  linarith [hM.2, hN.1]

/-- For `0 < k < m`: `a_m(k) = i·ampC(k,m)/(2πk)` when `2k < m`, and `a_m(k) = −a_m(m−k)`. -/
lemma sawCoeff_eq_ampC (m k : ℕ) (hm : 2 ≤ m) (hk : 0 < k) (h2k : 2 * k < m) :
    GoldC.QuillonSawDFT.sawCoeff m k =
      Complex.I * ((ampC k m : ℝ) : ℂ) / (2 * π * k) := by
  rw [sawCoeff_cot m k hm (Finset.mem_Ioo.2 ⟨hk, by omega⟩)]
  have hmR : (0 : ℝ) < m := by exact_mod_cast (show 0 < m by omega)
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hlt : π * k / m < π / 2 := by
    rw [div_lt_div_iff₀ hmR (by norm_num)]
    have : (2 * k : ℝ) < m := by exact_mod_cast h2k
    nlinarith [Real.pi_pos]
  unfold ampC phi
  rw [min_eq_left hlt.le]
  have hs : Real.sin (π * k / m) ≠ 0 :=
    (Real.sin_pos_of_pos_of_lt_pi (by positivity) (by linarith [Real.pi_pos])).ne'
  have hpiC : (π : ℂ) ≠ 0 := by exact_mod_cast Real.pi_ne_zero
  have hkC : (k : ℂ) ≠ 0 := by exact_mod_cast hk.ne'
  have hmC : (m : ℂ) ≠ 0 := by exact_mod_cast (show m ≠ 0 by omega)
  have hsC : ((Real.sin (π * k / m) : ℝ) : ℂ) ≠ 0 := by exact_mod_cast hs
  push_cast
  field_simp

lemma ampC_eq_zero (k m : ℕ) (hm : 1 ≤ m) (h2k : m ≤ 2 * k) : ampC k m = 0 := by
  unfold ampC phi
  have hmR : (0 : ℝ) < m := by exact_mod_cast hm
  have hge : π / 2 ≤ π * k / m := by
    rw [div_le_div_iff₀ (by norm_num) hmR]
    have : (m : ℝ) ≤ 2 * k := by exact_mod_cast h2k
    nlinarith [Real.pi_pos]
  rw [min_eq_right hge, Real.cos_pi_div_two]; simp

lemma sawCoeff_reflect (m k : ℕ) (hm : 2 ≤ m) (hk : k ∈ Finset.Ioo 0 m) :
    GoldC.QuillonSawDFT.sawCoeff m (m - k) = -GoldC.QuillonSawDFT.sawCoeff m k := by
  have hk1 := Finset.mem_Ioo.1 hk
  rw [sawCoeff_cot m (m - k) hm (Finset.mem_Ioo.2 ⟨by omega, by omega⟩), sawCoeff_cot m k hm hk]
  have hmR : (0 : ℝ) < m := by exact_mod_cast (show 0 < m by omega)
  have : π * ((m - k : ℕ) : ℝ) / m = π - π * k / m := by
    rw [Nat.cast_sub hk1.2.le]; field_simp
  rw [this, Real.cos_pi_sub, Real.sin_pi_sub]
  push_cast; ring

/-- **Signed expansion with uniform clipped coefficients.** For `2 ≤ m`, `0 < c < m` and any
`J` with `m ≤ 2J`:
`c/m − 1/2 = Σ_{k=1}^{J} (i·ampC(k,m)/(2πk))·(ζ^{kc} − ζ^{−kc})`.
The coefficients depend on `m` only through `ampC(k,m)`, which is monotone and in `[0,1]`. -/
theorem prof_signed (m c J : ℕ) (hm : 2 ≤ m) (hc : c ∈ Finset.Ioo 0 m) (hJ : m ≤ 2 * J) :
    GoldC.QuillonSawDFT.prof m c =
      ∑ k ∈ Finset.Icc 1 J, (Complex.I * ((ampC k m : ℝ) : ℂ) / (2 * π * k)) *
        (GoldC.QuillonSawDFT.zeta m ^ ((k : ℤ) * c) - GoldC.QuillonSawDFT.zeta m ^ (-((k : ℤ) * c))) := by
  rw [GoldC.QuillonSawDFT.prof_expansion m c hm hc]
  set a := GoldC.QuillonSawDFT.sawCoeff m
  set ζ := GoldC.QuillonSawDFT.zeta m
  have hζ := GoldC.QuillonSawDFT.zeta_prim m (by omega)
  have hζ0 := GoldC.QuillonSawDFT.zeta_ne_zero m
  -- a 0 = 0
  have ha0 : a 0 = 0 := by
    simp only [a, GoldC.QuillonSawDFT.sawCoeff, Nat.cast_zero, zero_mul, neg_zero, zpow_zero,
      mul_one, GoldC.QuillonSawDFT.prof]
    rw [← Complex.ofReal_sum, Finset.sum_sub_distrib]
    have hs : ∑ x ∈ Finset.Ioo 0 m, ((x : ℝ) / m) = ((m : ℝ) - 1) / 2 := by
      rw [← Finset.sum_div]
      have h := Finset.sum_range_id_mul_two m
      have hsplit : ∑ x ∈ Finset.Ioo 0 m, (x : ℝ) = ∑ x ∈ Finset.range m, (x : ℝ) := by
        rw [Finset.range_eq_Ico, ← Finset.sum_Ioo_add_eq_sum_Ico (by omega)]; simp
      rw [hsplit]
      have : (∑ x ∈ Finset.range m, (x : ℝ)) * 2 = (m : ℝ) * ((m : ℝ) - 1) := by
        have h' : ((∑ i ∈ Finset.range m, i : ℕ) : ℝ) * 2 = ((m * (m - 1) : ℕ) : ℝ) := by
          exact_mod_cast h
        push_cast [Nat.cast_sub (show 1 ≤ m by omega)] at h'
        exact h'
      have hmR : (m : ℝ) ≠ 0 := by exact_mod_cast (show m ≠ 0 by omega)
      field_simp; linarith
    rw [hs, Finset.sum_const, Nat.card_Ioo, nsmul_eq_mul, Nat.sub_zero]
    have hmR : (m : ℝ) ≠ 0 := by exact_mod_cast (show m ≠ 0 by omega)
    push_cast [Nat.cast_sub (show 1 ≤ m by omega)]
    field_simp
    ring
  -- reindex the full sum
  have hsum : ∑ k ∈ Finset.range m, a k * ζ ^ ((k : ℤ) * c) =
      ∑ k ∈ Finset.Ioo 0 m, a k * ζ ^ ((k : ℤ) * c) := by
    rw [Finset.range_eq_Ico, ← Finset.sum_Ioo_add_eq_sum_Ico (by omega), ha0, zero_mul, add_zero]
  rw [hsum]
  -- split Ioo 0 m by 2k < m, 2k = m, 2k > m
  have hpart : ∑ k ∈ Finset.Ioo 0 m, a k * ζ ^ ((k : ℤ) * c) =
      ∑ k ∈ (Finset.Ioo 0 m).filter (fun k => 2 * k < m), a k * ζ ^ ((k : ℤ) * c) +
      ∑ k ∈ (Finset.Ioo 0 m).filter (fun k => ¬ 2 * k < m), a k * ζ ^ ((k : ℤ) * c) :=
    (Finset.sum_filter_add_sum_filter_not _ _ _).symm
  rw [hpart]
  -- the upper half reflects onto the lower half (the middle term has a = 0)
  have hupper : ∑ k ∈ (Finset.Ioo 0 m).filter (fun k => ¬ 2 * k < m), a k * ζ ^ ((k : ℤ) * c) =
      ∑ k ∈ (Finset.Ioo 0 m).filter (fun k => 2 * k < m), (-a k) * ζ ^ (-((k : ℤ) * c)) := by
    -- drop the possible middle term k = m/2 (a = 0 there)
    have hmid : ∀ k ∈ (Finset.Ioo 0 m).filter (fun k => ¬ 2 * k < m), 2 * k = m →
        a k * ζ ^ ((k : ℤ) * c) = 0 := by
      intro k hk h2
      have hk' := Finset.mem_filter.1 hk
      have hkI := Finset.mem_Ioo.1 hk'.1
      have : a k = 0 := by
        simp only [a]
        rw [sawCoeff_cot m k hm hk'.1]
        have hmR : (m : ℝ) ≠ 0 := by exact_mod_cast (show m ≠ 0 by omega)
        have : π * (k : ℝ) / m = π / 2 := by
          have : (m : ℝ) = 2 * k := by exact_mod_cast h2.symm
          have hkR : (k : ℝ) ≠ 0 := by exact_mod_cast (show k ≠ 0 by omega)
          rw [this]; field_simp
        rw [this, Real.cos_pi_div_two]; simp
      rw [this, zero_mul]
    rw [← Finset.sum_filter_add_sum_filter_not _ (fun k => 2 * k = m)]
    rw [Finset.sum_eq_zero (fun k hk => hmid k (Finset.mem_filter.1 hk).1 (Finset.mem_filter.1 hk).2),
      zero_add]
    rw [Finset.filter_filter]
    refine Finset.sum_nbij' (fun k => m - k) (fun k => m - k) ?_ ?_ ?_ ?_ ?_
    · intro k hk
      simp only [Finset.mem_filter, Finset.mem_Ioo] at hk ⊢
      omega
    · intro k hk
      simp only [Finset.mem_filter, Finset.mem_Ioo] at hk ⊢
      omega
    · intro k hk
      simp only [Finset.mem_filter, Finset.mem_Ioo] at hk
      omega
    · intro k hk
      simp only [Finset.mem_filter, Finset.mem_Ioo] at hk
      omega
    · intro k hk
      rw [Finset.mem_filter, Finset.mem_Ioo] at hk
      have hkI : k ∈ Finset.Ioo 0 m := Finset.mem_Ioo.2 ⟨hk.1.1, hk.1.2⟩
      have hrefl := sawCoeff_reflect m k hm hkI
      show a k * ζ ^ ((k : ℤ) * c) = (-a (m - k)) * ζ ^ (-(((m - k : ℕ) : ℤ) * c))
      rw [show a (m - k) = -a k from hrefl, neg_neg]
      congr 1
      rw [show -(((m - k : ℕ) : ℤ) * c) = (k : ℤ) * c + (m : ℤ) * (-(c : ℤ)) by
        push_cast [Nat.cast_sub hk.1.2.le]; ring]
      have h1 : ζ ^ ((m : ℤ) * (-(c : ℤ))) = 1 := by
        rw [zpow_mul, zpow_natCast, hζ.pow_eq_one, one_zpow]
      rw [zpow_add₀ hζ0, h1, mul_one]
  rw [hupper, ← Finset.sum_add_distrib]
  -- extend from {2k < m} to Icc 1 J using ampC = 0 for 2k ≥ m
  have hlow : ∀ k ∈ (Finset.Ioo 0 m).filter (fun k => 2 * k < m),
      a k * ζ ^ ((k : ℤ) * c) + (-a k) * ζ ^ (-((k : ℤ) * c)) =
        (Complex.I * ((ampC k m : ℝ) : ℂ) / (2 * π * k)) *
          (ζ ^ ((k : ℤ) * c) - ζ ^ (-((k : ℤ) * c))) := by
    intro k hk
    have hk' := Finset.mem_filter.1 hk
    rw [show a k = _ from sawCoeff_eq_ampC m k hm (Finset.mem_Ioo.1 hk'.1).1 hk'.2]
    ring
  rw [Finset.sum_congr rfl hlow]
  apply Finset.sum_subset
  · intro k hk
    rw [Finset.mem_filter, Finset.mem_Ioo] at hk
    rw [Finset.mem_Icc]; omega
  · intro k hk hnot
    rw [Finset.mem_filter, Finset.mem_Ioo] at hnot
    rw [Finset.mem_Icc] at hk
    have h2k : m ≤ 2 * k := by
      by_contra hc'
      exact hnot ⟨⟨by omega, by omega⟩, by omega⟩
    rw [ampC_eq_zero k m (by omega) h2k]
    simp

end GoldC.QuillonCot

#print axioms GoldC.QuillonCot.phi_strictAnti
#print axioms GoldC.QuillonCot.sawCoeff_cot
#print axioms GoldC.QuillonCot.amp_abel_factor
#print axioms GoldC.QuillonCot.ampC_abel_factor
#print axioms GoldC.QuillonCot.sawCoeff_eq_ampC
#print axioms GoldC.QuillonCot.prof_signed
