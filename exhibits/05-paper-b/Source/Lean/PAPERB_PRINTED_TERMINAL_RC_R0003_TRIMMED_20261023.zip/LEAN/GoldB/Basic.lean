import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.SpecialFunctions.Complex.Circle
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Tactic

/-!
# GoldB.Basic

The additive character `ee t = exp(2πi t)` and the elementary estimates used
throughout: unit modulus, Lipschitz bound, and the geometric-sum bound
`|∑_{|m| ≤ L} e(θ m)| ≤ min(2L+1, 1/(2‖θ‖))` with `‖θ‖ = |θ - round θ|`.
-/

open Complex Finset

namespace GoldB

noncomputable def ee (t : ℝ) : ℂ := Complex.exp (2 * Real.pi * Complex.I * t)

lemma ee_eq (t : ℝ) : ee t = Complex.exp (((2 * Real.pi * t : ℝ) : ℂ) * Complex.I) := by
  unfold ee; congr 1; push_cast; ring

@[simp] lemma norm_ee (t : ℝ) : ‖ee t‖ = 1 := by
  rw [ee_eq]; exact Complex.norm_exp_ofReal_mul_I _

lemma ee_add (s t : ℝ) : ee (s + t) = ee s * ee t := by
  unfold ee; rw [← Complex.exp_add]; congr 1; push_cast; ring

lemma ee_neg (t : ℝ) : ee (-t) = (starRingEnd ℂ) (ee t) := by
  unfold ee
  rw [← Complex.exp_conj]
  congr 1
  simp only [map_mul, map_ofNat, Complex.conj_ofReal, Complex.conj_I, map_neg]
  push_cast
  ring

lemma ee_sub (s t : ℝ) : ee (s - t) = ee s * (starRingEnd ℂ) (ee t) := by
  rw [sub_eq_add_neg, ee_add, ee_neg]

@[simp] lemma ee_zero : ee 0 = 1 := by simp [ee]

lemma ee_int (n : ℤ) : ee n = 1 := by
  unfold ee
  rw [Complex.exp_eq_one_iff]
  exact ⟨n, by push_cast; ring⟩

lemma ee_add_int (t : ℝ) (n : ℤ) : ee (t + n) = ee t := by
  rw [ee_add, ee_int, mul_one]

lemma ee_sum {ι : Type*} (s : Finset ι) (f : ι → ℝ) :
    ee (∑ i ∈ s, f i) = ∏ i ∈ s, ee (f i) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | insert a s ha ih => rw [sum_insert ha, prod_insert ha, ee_add, ih]

lemma ee_mul_conj (t : ℝ) : ee t * (starRingEnd ℂ) (ee t) = 1 := by
  rw [Complex.mul_conj, Complex.normSq_eq_norm_sq, norm_ee]; simp

/-- Lipschitz bound for the character. -/
lemma norm_ee_sub_ee_le (s t : ℝ) : ‖ee s - ee t‖ ≤ 2 * Real.pi * |s - t| := by
  have h1 : ee s - ee t = ee t * (ee (s - t) - 1) := by
    rw [mul_sub, ← ee_add]; ring_nf
  rw [h1, norm_mul, norm_ee, one_mul, ee_eq]
  have := Real.norm_exp_I_mul_ofReal_sub_one_le (x := 2 * Real.pi * (s - t))
  calc ‖Complex.exp (((2 * Real.pi * (s - t) : ℝ) : ℂ) * Complex.I) - 1‖
      = ‖Complex.exp (Complex.I * ((2 * Real.pi * (s - t) : ℝ) : ℂ)) - 1‖ := by rw [mul_comm]
    _ ≤ ‖(2 * Real.pi * (s - t) : ℝ)‖ := this
    _ = 2 * Real.pi * |s - t| := by
      rw [Real.norm_eq_abs, abs_mul, abs_of_pos (by positivity : (0:ℝ) < 2 * Real.pi)]

/-- distance to the nearest integer -/
noncomputable def dz (θ : ℝ) : ℝ := |θ - round θ|

lemma dz_nonneg (θ : ℝ) : 0 ≤ dz θ := abs_nonneg _

lemma dz_le_half (θ : ℝ) : dz θ ≤ 1 / 2 := abs_sub_round θ

lemma dz_neg (θ : ℝ) : dz (-θ) = dz θ := by
  unfold dz
  rcases eq_or_ne (round (-θ)) (-round θ) with h | h
  · rw [h]; push_cast; rw [← abs_neg]; ring_nf
  · -- use the characterization dz θ = min over integers
    have h1 : |(-θ) - round (-θ)| ≤ |(-θ) - ((-round θ : ℤ) : ℝ)| := round_le (-θ) _
    have h2 : |θ - round θ| ≤ |θ - ((-round (-θ) : ℤ) : ℝ)| := round_le θ _
    apply le_antisymm
    · calc |(-θ) - round (-θ)| ≤ |(-θ) - ((-round θ : ℤ) : ℝ)| := h1
        _ = |θ - round θ| := by push_cast; rw [← abs_neg]; ring_nf
    · calc |θ - round θ| ≤ |θ - ((-round (-θ) : ℤ) : ℝ)| := h2
        _ = |(-θ) - round (-θ)| := by push_cast; rw [← abs_neg]; ring_nf

lemma dz_le_abs (θ : ℝ) : dz θ ≤ |θ| := by
  have := round_le θ 0
  simpa [dz] using this

lemma dz_add_int (θ : ℝ) (n : ℤ) : dz (θ + n) = dz θ := by
  unfold dz; rw [round_add_intCast]; push_cast; ring_nf

/-- `|sin (π θ)| ≥ 2 dz θ` (Jordan). -/
lemma two_dz_le_abs_sin (θ : ℝ) : 2 * dz θ ≤ |Real.sin (Real.pi * θ)| := by
  set n := round θ
  set d := θ - n
  have hd : |d| ≤ 1 / 2 := abs_sub_round θ
  have hsin : |Real.sin (Real.pi * θ)| = |Real.sin (Real.pi * d)| := by
    have : Real.pi * θ = Real.pi * d + (n : ℤ) * Real.pi := by simp [d]; ring
    rw [this, Real.sin_add_int_mul_pi]
    rw [abs_mul]
    have : |((-1 : ℝ) ^ n)| = 1 := by
      rcases Int.even_or_odd n with h | h
      · rw [h.neg_one_zpow]; simp
      · rw [h.neg_one_zpow]; simp
    simp [this]
  rw [hsin]
  unfold dz
  change 2 * |d| ≤ _
  have key : ∀ e : ℝ, 0 ≤ e → e ≤ 1 / 2 → 2 * e ≤ Real.sin (Real.pi * e) := by
    intro e he0 he1
    have h1 := Real.mul_le_sin (x := Real.pi * e) (by positivity) (by nlinarith [Real.pi_pos])
    have : 2 / Real.pi * (Real.pi * e) = 2 * e := by field_simp
    linarith
  rcases lt_or_ge 0 d with h | h
  · rw [abs_of_nonneg h.le]
    have hd' : d ≤ 1 / 2 := by rw [abs_of_nonneg h.le] at hd; exact hd
    have := key d h.le hd'
    exact this.trans (le_abs_self _)
  · rw [abs_of_nonpos h]
    have hd' : -d ≤ 1 / 2 := by rw [abs_of_nonpos h] at hd; exact hd
    have := key (-d) (by linarith) hd'
    rw [show Real.pi * -d = -(Real.pi * d) by ring, Real.sin_neg] at this
    calc 2 * -d ≤ -Real.sin (Real.pi * d) := this
      _ ≤ |Real.sin (Real.pi * d)| := neg_le_abs _

/-- `|e(θ) - 1| ≥ 4 dz θ`. -/
lemma four_dz_le_norm_ee_sub_one (θ : ℝ) : 4 * dz θ ≤ ‖ee θ - 1‖ := by
  have h : ‖ee θ - 1‖ = 2 * |Real.sin (Real.pi * θ)| := by
    rw [ee_eq, mul_comm, Complex.norm_exp_I_mul_ofReal_sub_one]
    rw [Real.norm_eq_abs, abs_mul]
    norm_num
    ring_nf
  rw [h]
  have := two_dz_le_abs_sin θ
  linarith

/-- Finite geometric sum `∑_{m < n} e(θ m)`: bound `1/(2 dz θ)`. -/
lemma norm_geom_ee_le (θ : ℝ) (n : ℕ) (hθ : dz θ ≠ 0) :
    ‖∑ m ∈ range n, ee (θ * m)‖ ≤ 1 / (2 * dz θ) := by
  have hpos : 0 < dz θ := lt_of_le_of_ne (dz_nonneg θ) (Ne.symm hθ)
  have hr : ee θ ≠ 1 := by
    intro h
    have := four_dz_le_norm_ee_sub_one θ
    rw [h, sub_self, norm_zero] at this
    linarith
  have hm : ∀ m : ℕ, ee (θ * m) = (ee θ) ^ m := by
    intro m
    induction m with
    | zero => simp
    | succ m ih =>
      rw [pow_succ, ← ih, ← ee_add]
      congr 1
      push_cast
      ring
  have hsum : ∑ m ∈ range n, ee (θ * m) = ∑ m ∈ range n, (ee θ) ^ m := by
    apply sum_congr rfl
    intro m _
    exact hm m
  rw [hsum, geom_sum_eq hr]
  rw [norm_div]
  have hnum : ‖ee θ ^ n - 1‖ ≤ 2 := by
    calc ‖ee θ ^ n - 1‖ ≤ ‖ee θ ^ n‖ + ‖(1 : ℂ)‖ := norm_sub_le _ _
      _ = 2 := by rw [norm_pow, norm_ee]; norm_num
  have hden := four_dz_le_norm_ee_sub_one θ
  have hden_pos : 0 < ‖ee θ - 1‖ := by linarith
  rw [div_le_div_iff₀ hden_pos (by positivity)]
  nlinarith

/-- Symmetric geometric sum over `[-L, L]`. -/
lemma norm_sym_geom_le (θ : ℝ) (L : ℕ) :
    ‖∑ m ∈ Icc (-(L : ℤ)) L, ee (θ * m)‖ ≤ 2 * L + 1 := by
  calc ‖∑ m ∈ Icc (-(L : ℤ)) L, ee (θ * m)‖ ≤ ∑ m ∈ Icc (-(L : ℤ)) L, ‖ee (θ * m)‖ :=
        norm_sum_le _ _
    _ = ((Icc (-(L : ℤ)) L).card : ℝ) := by simp
    _ = 2 * L + 1 := by
      rw [Int.card_Icc]; push_cast
      have : ((L : ℤ) + 1 - -(L : ℤ)).toNat = 2 * L + 1 := by omega
      rw [this]; push_cast; ring

lemma sym_geom_shift (θ : ℝ) (L : ℕ) :
    ∑ m ∈ Icc (-(L : ℤ)) L, ee (θ * m) =
      ee (-(θ * L)) * ∑ m ∈ range (2 * L + 1), ee (θ * m) := by
  rw [mul_sum]
  let emb : ℕ ↪ ℤ :=
    ⟨fun m : ℕ => (m : ℤ) - L, by
      intro a b h
      change (a : ℤ) - L = (b : ℤ) - L at h
      have hh : (a : ℤ) = (b : ℤ) := by omega
      exact_mod_cast hh⟩
  have hfin : Icc (-(L : ℤ)) L = (range (2 * L + 1)).map emb := by
    ext x
    constructor
    · intro hx
      have hlo : -(L : ℤ) ≤ x := (Finset.mem_Icc.mp hx).1
      have hhi : x ≤ (L : ℤ) := (Finset.mem_Icc.mp hx).2
      let m : ℕ := (x + (L : ℤ)).toNat
      have hm_cast : (m : ℤ) = x + L := Int.toNat_of_nonneg (by omega)
      apply Finset.mem_map.mpr
      refine ⟨m, Finset.mem_range.mpr ?_, ?_⟩
      · have hm_bound : (m : ℤ) < ((2 * L + 1 : ℕ) : ℤ) := by
          rw [hm_cast]
          push_cast
          omega
        exact_mod_cast hm_bound
      · change (m : ℤ) - L = x
        omega
    · intro hx
      obtain ⟨m, hm, hmx⟩ := Finset.mem_map.mp hx
      have hm_bound : m < 2 * L + 1 := Finset.mem_range.mp hm
      change (m : ℤ) - L = x at hmx
      apply Finset.mem_Icc.mpr
      constructor <;> omega
  rw [hfin, sum_map]
  apply sum_congr rfl; intro m _
  dsimp [emb]
  change ee (θ * (((m : ℤ) - L : ℤ) : ℝ)) = ee (-(θ * L)) * ee (θ * m)
  rw [← ee_add]; congr 1; push_cast; ring

lemma norm_sym_geom_le_dz (θ : ℝ) (L : ℕ) (hθ : dz θ ≠ 0) :
    ‖∑ m ∈ Icc (-(L : ℤ)) L, ee (θ * m)‖ ≤ 1 / (2 * dz θ) := by
  rw [sym_geom_shift, norm_mul, norm_ee, one_mul]
  exact norm_geom_ee_le θ _ hθ

/-- The min-type bound `G U θ`: `U` if `θ ∈ ℤ`, else `min U (1/(2 dz θ))`. -/
noncomputable def gmin (U θ : ℝ) : ℝ := if dz θ = 0 then U else min U (1 / (2 * dz θ))

lemma gmin_le_U (U θ : ℝ) : gmin U θ ≤ U := by
  unfold gmin; split_ifs <;> simp

lemma gmin_nonneg {U : ℝ} (hU : 0 ≤ U) (θ : ℝ) : 0 ≤ gmin U θ := by
  unfold gmin; split_ifs
  · exact hU
  · exact le_min hU (by have := dz_nonneg θ; positivity)

lemma norm_sym_geom_le_gmin (θ : ℝ) (L : ℕ) :
    ‖∑ m ∈ Icc (-(L : ℤ)) L, ee (θ * m)‖ ≤ gmin (2 * L + 1) θ := by
  unfold gmin; split_ifs with h
  · exact norm_sym_geom_le θ L
  · exact le_min (norm_sym_geom_le θ L) (norm_sym_geom_le_dz θ L h)

lemma gmin_neg (U θ : ℝ) : gmin U (-θ) = gmin U θ := by
  unfold gmin; rw [dz_neg]

end GoldB
