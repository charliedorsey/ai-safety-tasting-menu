import PaperB.FixedQ.TwoDimensionalClosure

open scoped BigOperators

namespace PaperB.FixedQ

lemma decoratedAnalyticPairTerm_eq_partition
    {q a h : ℕ} {e e1 : Finset ℕ}
    (he1 : e1 ⊆ e)
    (hAall : ∀ p ∈ e, activeHighPrime q p)
    (hheight : heightPrimePart h e ⊆ e1) :
    let d := heightPrimePart h e
    let n := e \ d
    let A := e1 \ d
    let D := decoratedHeightProduct h e
    let H := decoratedReducedHeight h e
    decoratedAnalyticPairTerm q a h e e1 =
      finiteVWeightReal h d * finiteOmegaWeightReal n *
        fixedProductPartitionDiscrepancy
          (fixedQLowWeight q (decoratedReducedAnchor q a D) H)
          H n A := by
  dsimp
  unfold decoratedAnalyticPairTerm
  rw [pairCoefficient_eq_heightPart_mul_nonheightOmega he1 hAall hheight]
  unfold fixedProductPartitionDiscrepancy
  rfl

#print axioms decoratedAnalyticPairTerm_eq_partition

end PaperB.FixedQ
