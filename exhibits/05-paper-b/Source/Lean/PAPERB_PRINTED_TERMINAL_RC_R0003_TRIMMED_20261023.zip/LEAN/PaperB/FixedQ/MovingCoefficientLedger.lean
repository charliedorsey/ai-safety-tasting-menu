import PaperB.FixedQ.OneDimensionalCoefficientLedger
import PaperB.FixedQ.OmegaLinearMean
import PaperB.FixedQ.OmegaCharacterBound
import PaperB.FixedQ.OmegaReciprocalTail
import PaperB.FixedQ.MovingCorrectionMass

open scoped BigOperators

namespace PaperB.FixedQ

theorem movingVNonprincipalCharacterBoundSpec
    (q h : ℕ) (hq : 0 < q) (hh : h ≠ 0) :
    CharacterBoundSpec q (movingVCoeff q h)
      ((2 * ((Nat.lcm 6 q : ℕ) + 1) * omegaRankinBound) *
        petermannCorrectionL1UniformBound) := by
  constructor
  · have hR0 : 0 ≤ omegaRankinBound := by
      unfold omegaRankinBound
      positivity
    have hL10 : 0 ≤ petermannCorrectionL1UniformBound := by
      unfold petermannCorrectionL1UniformBound
      exact tsum_nonneg (fun s =>
        Finset.prod_nonneg (fun p hp => by positivity))
    positivity
  · intro chi hchi X hX
    rw [characterCoefficientPartialSum_moving_eq_correction]
    let Cω : ℝ :=
      2 * ((Nat.lcm 6 q : ℕ) + 1) * omegaRankinBound
    have hCω :
        ∀ Y : ℕ,
          ‖characterCoefficientPartialSum chi (omegaCoeff q) Y‖ ≤ Cω := by
      intro Y
      unfold Cω
      simpa [characterCoefficientPartialSum, omegaCharacterPartialSum] using
        norm_omegaCharacterPartialSum_le q Y hq chi hchi
    calc
      ‖∑ s ∈ Finset.Icc 1 X,
          (chi s) * (petermannCorrectionArithmetic q h s : ℂ) *
            characterCoefficientPartialSum chi (omegaCoeff q) (X / s)‖
        ≤ ∑ s ∈ Finset.Icc 1 X,
            ‖(chi s) * (petermannCorrectionArithmetic q h s : ℂ) *
              characterCoefficientPartialSum chi (omegaCoeff q) (X / s)‖ := by
              exact norm_sum_le _ _
      _ ≤ ∑ s ∈ Finset.Icc 1 X,
            |petermannCorrectionArithmetic q h s| * Cω := by
              apply Finset.sum_le_sum
              intro s hs
              have hchi1 :=
                chi.norm_le_one (s : ZMod (Nat.lcm 6 q))
              have hω := hCω (X / s)
              rw [norm_mul, norm_mul, Complex.norm_real]
              have hc0 : 0 ≤ |petermannCorrectionArithmetic q h s| :=
                abs_nonneg _
              have hω0 :
                  0 ≤ ‖characterCoefficientPartialSum chi (omegaCoeff q) (X / s)‖ :=
                norm_nonneg _
              calc
                ‖chi (s : ZMod (Nat.lcm 6 q))‖ *
                    |petermannCorrectionArithmetic q h s| *
                    ‖characterCoefficientPartialSum chi (omegaCoeff q) (X / s)‖
                    ≤ |petermannCorrectionArithmetic q h s| *
                        ‖characterCoefficientPartialSum chi (omegaCoeff q) (X / s)‖ := by
                      apply mul_le_mul_of_nonneg_right _ hω0
                      simpa using
                        mul_le_mul_of_nonneg_right hchi1 hc0
                _ ≤ |petermannCorrectionArithmetic q h s| * Cω :=
                      mul_le_mul_of_nonneg_left hω hc0
      _ = Cω * ∑ s ∈ Finset.Icc 1 X,
            |petermannCorrectionArithmetic q h s| := by
              rw [Finset.mul_sum]
              apply Finset.sum_congr rfl
              intro s hs
              ring
      _ ≤ Cω * petermannCorrectionL1UniformBound := by
              have hC0 : 0 ≤ Cω := by
                dsimp [Cω]
                have hR0 : 0 ≤ omegaRankinBound := by
                  unfold omegaRankinBound
                  positivity
                positivity
              apply mul_le_mul_of_nonneg_left _ hC0
              calc
                (∑ s ∈ Finset.Icc 1 X,
                    |petermannCorrectionArithmetic q h s|)
                    ≤ ∑' s : ℕ,
                        |petermannCorrectionArithmetic q h s| := by
                      exact (summable_abs_petermannCorrectionArithmetic q h hh).sum_le_tsum
                        (Finset.Icc 1 X) (fun s hs => abs_nonneg _)
                _ ≤ petermannCorrectionL1UniformBound :=
                      petermannCorrectionL1_uniform_le q h hh
      _ = (2 * ((Nat.lcm 6 q : ℕ) + 1) * omegaRankinBound) *
            petermannCorrectionL1UniformBound := by rfl

#print axioms movingVNonprincipalCharacterBoundSpec

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma abs_log_natDiv_sub_log_le
    (X s : ℕ) (hs1 : 1 ≤ s) (hsX : s ≤ X) :
    |Real.log (((X / s : ℕ) : ℝ)) - Real.log (X : ℝ)| ≤
      1 + Real.log (s : ℝ) := by
  have hX1 : 1 ≤ X := hs1.trans hsX
  have hYpos : 0 < X / s := Nat.div_pos hsX (by omega)
  have hY1 : 1 ≤ X / s := hYpos
  have hYleX : X / s ≤ X := Nat.div_le_self X s
  have hlogYX :
      Real.log ((X / s : ℕ) : ℝ) ≤ Real.log (X : ℝ) := by
    exact Real.log_le_log (by positivity) (by exact_mod_cast hYleX)
  rw [abs_of_nonpos (sub_nonpos.mpr hlogYX), neg_sub]
  have hltNat : X < s * (X / s + 1) :=
    Nat.lt_mul_div_succ X (by omega)
  have hplus : X / s + 1 ≤ 2 * (X / s) := by omega
  have hXleNat : X ≤ 2 * s * (X / s) := by
    calc
      X ≤ s * (X / s + 1) := Nat.le_of_lt hltNat
      _ ≤ s * (2 * (X / s)) := Nat.mul_le_mul_left s hplus
      _ = 2 * s * (X / s) := by ring
  have hYR : (0 : ℝ) < ((X / s : ℕ) : ℝ) := by exact_mod_cast hYpos
  have hratio :
      (X : ℝ) / ((X / s : ℕ) : ℝ) ≤ 2 * (s : ℝ) := by
    rw [div_le_iff₀ hYR]
    exact_mod_cast hXleNat
  have hratioPos : 0 < (X : ℝ) / ((X / s : ℕ) : ℝ) := by positivity
  have h2sPos : 0 < (2 : ℝ) * (s : ℝ) := by positivity
  have hlogratio :
      Real.log ((X : ℝ) / ((X / s : ℕ) : ℝ)) ≤
        Real.log ((2 : ℝ) * (s : ℝ)) :=
    Real.log_le_log hratioPos hratio
  rw [Real.log_div (by positivity) (by positivity)] at hlogratio
  rw [Real.log_mul (by norm_num : (2 : ℝ) ≠ 0) (by positivity)] at hlogratio
  have hlog2raw := Real.log_lt_sub_one_of_pos
      (show (0 : ℝ) < 2 by norm_num) (by norm_num : (2 : ℝ) ≠ 1)
  have hlog2 : Real.log (2 : ℝ) < 1 := by
    norm_num at hlog2raw ⊢
    exact hlog2raw
  linarith

lemma abs_logarithmicEulerResidue_omega_le_rankin
    (q : ℕ) (hq : 0 < q) :
    |logarithmicEulerResidue (omegaCoeff q)| ≤ omegaRankinBound := by
  rw [← six_mul_density_mul_omegaCorrectionInvMass_eq_residue q hq]
  have hD0 :
      0 ≤ (Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ) := by
    positivity
  have hD1 :
      (Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ) ≤ 1 := by
    rw [div_le_one (by positivity : (0 : ℝ) < (6 * q : ℕ))]
    exact_mod_cast Nat.totient_le (6 * q)
  rw [abs_mul, abs_of_nonneg hD0]
  have hmass :
      |omegaCorrectionInvMass q| ≤ omegaRankinBound := by
    unfold omegaCorrectionInvMass
    calc
      |∑' n : ℕ, omegaCorrectionInvTerm q n|
          ≤ ∑' n : ℕ, |omegaCorrectionInvTerm q n| := by
            simpa [Real.norm_eq_abs] using
              norm_tsum_le_tsum_norm (summable_omegaCorrectionInvTerm q).norm
      _ ≤ omegaRankinBound := tsum_abs_omegaCorrectionInvTerm_le_bound q
  have hR0 : 0 ≤ omegaRankinBound := by
    unfold omegaRankinBound
    positivity
  nlinarith [abs_nonneg (omegaCorrectionInvMass q)]

#print axioms abs_log_natDiv_sub_log_le
#print axioms abs_logarithmicEulerResidue_omega_le_rankin

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem movingResidue_eq_correctionMass_mul_omegaResidue
    (q h : ℕ) (hq : 0 < q) (hh : h ≠ 0) :
    logarithmicEulerResidue (movingVCoeff q h) =
      petermannCorrectionMass q h *
        logarithmicEulerResidue (omegaCoeff q) := by
  have hmove := principalHighCoefficient_moving q h hq
  have hone := principalHighCoefficient_moving q 1 hq
  rw [movingVCoeff_one_eq_omegaCoeff q] at hone
  have hmass := cStar_mul_petermannCorrectionMass_eq_cStar_one q h hh
  have hc0 : cStarReal q h ≠ 0 := by
    unfold cStarReal
    exact tprod_normalizationBaseline_ne_zero q h
  apply (mul_left_cancel₀ hc0)
  calc
    cStarReal q h * logarithmicEulerResidue (movingVCoeff q h)
        = (Nat.totient (fixedQPeriod q) : ℝ) /
            (fixedQPeriod q : ℝ) := hmove
    _ = cStarReal q 1 * logarithmicEulerResidue (omegaCoeff q) := hone.symm
    _ = (cStarReal q h * petermannCorrectionMass q h) *
          logarithmicEulerResidue (omegaCoeff q) := by rw [hmass]
    _ = cStarReal q h *
          (petermannCorrectionMass q h *
            logarithmicEulerResidue (omegaCoeff q)) := by ring

#print axioms movingResidue_eq_correctionMass_mul_omegaResidue

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma abs_moving_log_distortion_sum_le
    (q h X : ℕ) (hh : h ≠ 0) (hX : 1 ≤ X) :
    |∑ s ∈ Finset.Icc 1 X,
        petermannCorrectionArithmetic q h s *
          (Real.log (((X / s : ℕ) : ℝ)) - Real.log (X : ℝ))| ≤
      petermannCorrectionConvolutionMomentBound := by
  calc
    |∑ s ∈ Finset.Icc 1 X,
        petermannCorrectionArithmetic q h s *
          (Real.log (((X / s : ℕ) : ℝ)) - Real.log (X : ℝ))|
      ≤ ∑ s ∈ Finset.Icc 1 X,
          |petermannCorrectionArithmetic q h s *
            (Real.log (((X / s : ℕ) : ℝ)) - Real.log (X : ℝ))| := by
            exact Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ s ∈ Finset.Icc 1 X,
          |petermannCorrectionArithmetic q h s| *
            (1 + Real.log (s : ℝ)) := by
            apply Finset.sum_le_sum
            intro s hs
            rw [abs_mul]
            have hsI := Finset.mem_Icc.mp hs
            exact mul_le_mul_of_nonneg_left
              (abs_log_natDiv_sub_log_le X s hsI.1 hsI.2)
              (abs_nonneg _)
    _ ≤ ∑' s : ℕ,
          |petermannCorrectionArithmetic q h s| *
            (1 + Real.log (s : ℝ)) := by
            exact (summable_petermannCorrectionConvolutionMoment q h hh).sum_le_tsum
              (Finset.Icc 1 X) (fun s hs => by
                by_cases hs0 : s = 0
                · subst s
                  simp
                · have hs1 : 1 ≤ s := Nat.one_le_iff_ne_zero.mpr hs0
                  have hlog0 : 0 ≤ Real.log (s : ℝ) :=
                    Real.log_nonneg (by exact_mod_cast hs1)
                  positivity)
    _ ≤ petermannCorrectionConvolutionMomentBound :=
      petermannCorrectionConvolutionMoment_uniform_le q h hh

#print axioms abs_moving_log_distortion_sum_le

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma abs_log_mul_petermannCorrection_tail_le
    (q h X : ℕ) (hh : h ≠ 0) (hX : 1 ≤ X) :
    |Real.log (X : ℝ) *
      ((∑ s ∈ Finset.Icc 1 X, petermannCorrectionArithmetic q h s) -
        petermannCorrectionMass q h)| ≤
      petermannCorrectionLogUniformBound := by
  let S : Finset ℕ := Finset.Icc 1 X
  have hsum := summable_petermannCorrectionArithmetic_signed q h hh
  have hdecomp := hsum.sum_add_tsum_subtype_compl S
  unfold petermannCorrectionMass at hdecomp
  have htail :
      (∑ s ∈ S, petermannCorrectionArithmetic q h s) -
          (∑' s : ℕ, petermannCorrectionArithmetic q h s) =
        -(∑' s : {s // s ∉ S}, petermannCorrectionArithmetic q h s) := by
    linarith
  rw [show (∑ s ∈ Finset.Icc 1 X, petermannCorrectionArithmetic q h s) =
      ∑ s ∈ S, petermannCorrectionArithmetic q h s by rfl]
  unfold petermannCorrectionMass
  rw [htail, mul_neg, abs_neg]
  have hlog0 : 0 ≤ Real.log (X : ℝ) :=
    Real.log_nonneg (by exact_mod_cast hX)
  have hpoint :
      ∀ s : {s // s ∉ S},
        ‖Real.log (X : ℝ) * petermannCorrectionArithmetic q h s.1‖ ≤
          |petermannCorrectionArithmetic q h s.1| * Real.log (s.1 : ℝ) := by
    intro s
    by_cases hs0 : s.1 = 0
    · rw [hs0]
      simp [petermannCorrectionArithmetic, petermannCorrectionCoeff]
    · have hs1 : 1 ≤ s.1 := Nat.one_le_iff_ne_zero.mpr hs0
      have hsnot : s.1 ∉ Finset.Icc 1 X := s.2
      have hXs : X < s.1 := by
        rw [Finset.mem_Icc] at hsnot
        push_neg at hsnot
        exact hsnot hs1
      have hlogle : Real.log (X : ℝ) ≤ Real.log (s.1 : ℝ) :=
        Real.log_le_log (by positivity) (by exact_mod_cast hXs.le)
      have hlogs0 : 0 ≤ Real.log (s.1 : ℝ) :=
        Real.log_nonneg (by exact_mod_cast hs1)
      rw [Real.norm_eq_abs, abs_mul, abs_of_nonneg hlog0]
      simpa [mul_comm] using
        mul_le_mul_of_nonneg_right hlogle
          (abs_nonneg (petermannCorrectionArithmetic q h s.1))
  have hsubsum :
      Summable (fun s : {s // s ∉ S} =>
        Real.log (X : ℝ) * petermannCorrectionArithmetic q h s.1) := by
    exact (hsum.subtype _).mul_left _
  have hnorm0 :
      ‖∑' s : {s // s ∉ S},
          Real.log (X : ℝ) * petermannCorrectionArithmetic q h s.1‖ ≤
        ∑' s : {s // s ∉ S},
          ‖Real.log (X : ℝ) * petermannCorrectionArithmetic q h s.1‖ :=
    norm_tsum_le_tsum_norm hsubsum.norm
  have hlogsum :=
    summable_abs_petermannCorrectionArithmetic_log q h hh
  have hnorm1 :
      (∑' s : {s // s ∉ S},
          ‖Real.log (X : ℝ) * petermannCorrectionArithmetic q h s.1‖) ≤
        ∑' s : {s // s ∉ S},
          |petermannCorrectionArithmetic q h s.1| * Real.log (s.1 : ℝ) := by
    exact hsubsum.norm.tsum_le_tsum hpoint (hlogsum.subtype _)
  have hsuble :
      (∑' s : {s // s ∉ S},
          |petermannCorrectionArithmetic q h s.1| * Real.log (s.1 : ℝ)) ≤
        ∑' s : ℕ,
          |petermannCorrectionArithmetic q h s| * Real.log (s : ℝ) := by
    have hdecompLog := hlogsum.sum_add_tsum_subtype_compl S
    have hfin0 :
        0 ≤ ∑ s ∈ S,
          |petermannCorrectionArithmetic q h s| * Real.log (s : ℝ) := by
      apply Finset.sum_nonneg
      intro s hs
      have hs1 := (Finset.mem_Icc.mp hs).1
      have hlogs0 : 0 ≤ Real.log (s : ℝ) :=
        Real.log_nonneg (by exact_mod_cast hs1)
      positivity
    linarith
  have htotal :=
    hnorm0.trans (hnorm1.trans
      (hsuble.trans (petermannCorrectionLog_uniform_le q h hh)))
  rw [← tsum_mul_left]
  simpa [Real.norm_eq_abs] using htotal

#print axioms abs_log_mul_petermannCorrection_tail_le

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem movingVPrincipalLogMeanSpec
    (q h : ℕ) (hq : 0 < q) (hh : h ≠ 0) :
    PrincipalLogMeanSpec
      (movingVCoeff q h)
      (logarithmicEulerResidue (movingVCoeff q h))
      (((2 * (6 * q) + 9) * omegaRankinBound) *
          petermannCorrectionL1UniformBound +
        omegaRankinBound *
          (petermannCorrectionConvolutionMomentBound +
            petermannCorrectionLogUniformBound)) := by
  let Cω : ℝ := (2 * (6 * q) + 9) * omegaRankinBound
  let Rω : ℝ := logarithmicEulerResidue (omegaCoeff q)
  let B1 : ℝ := petermannCorrectionL1UniformBound
  let BM : ℝ := petermannCorrectionConvolutionMomentBound
  let BL : ℝ := petermannCorrectionLogUniformBound
  have hR0 : 0 ≤ omegaRankinBound := by
    unfold omegaRankinBound
    positivity
  have hB10 : 0 ≤ B1 := by
    dsimp [B1]
    unfold petermannCorrectionL1UniformBound
    exact tsum_nonneg (fun s =>
      Finset.prod_nonneg (fun p hp => by positivity))
  have hBM0 : 0 ≤ BM := by
    dsimp [BM]
    unfold petermannCorrectionConvolutionMomentBound
    have hL0 : 0 ≤ petermannCorrectionLogUniformBound := by
      unfold petermannCorrectionLogUniformBound
      positivity
    positivity
  have hBL0 : 0 ≤ BL := by
    dsimp [BL]
    unfold petermannCorrectionLogUniformBound
    positivity
  constructor
  · positivity
  · intro X hX
    rw [coefficientPartialSum_moving_eq_correction]
    rw [movingResidue_eq_correctionMass_mul_omegaResidue q h hq hh]
    let E : ℝ :=
      ∑ s ∈ Finset.Icc 1 X,
        petermannCorrectionArithmetic q h s *
          (coefficientPartialSum (omegaCoeff q) (X / s) -
            Rω * Real.log (((X / s : ℕ) : ℝ)))
    let D : ℝ :=
      Rω * ∑ s ∈ Finset.Icc 1 X,
        petermannCorrectionArithmetic q h s *
          (Real.log (((X / s : ℕ) : ℝ)) - Real.log (X : ℝ))
    let T : ℝ :=
      Rω * Real.log (X : ℝ) *
        ((∑ s ∈ Finset.Icc 1 X,
            petermannCorrectionArithmetic q h s) -
          petermannCorrectionMass q h)
    have hErr : |E| ≤ Cω * B1 := by
      unfold E
      calc
        |∑ s ∈ Finset.Icc 1 X,
            petermannCorrectionArithmetic q h s *
              (coefficientPartialSum (omegaCoeff q) (X / s) -
                Rω * Real.log (((X / s : ℕ) : ℝ)))|
          ≤ ∑ s ∈ Finset.Icc 1 X,
              |petermannCorrectionArithmetic q h s *
                (coefficientPartialSum (omegaCoeff q) (X / s) -
                  Rω * Real.log (((X / s : ℕ) : ℝ)))| :=
                Finset.abs_sum_le_sum_abs _ _
        _ ≤ ∑ s ∈ Finset.Icc 1 X,
              |petermannCorrectionArithmetic q h s| * Cω := by
                apply Finset.sum_le_sum
                intro s hs
                rw [abs_mul]
                have hsI := Finset.mem_Icc.mp hs
                have hY : 1 ≤ X / s := Nat.div_pos hsI.2 (by omega)
                have hω := omegaPrincipalLogMean_bound q (X / s) hq hY
                dsimp [Rω, Cω]
                exact mul_le_mul_of_nonneg_left hω (abs_nonneg _)
        _ = Cω * ∑ s ∈ Finset.Icc 1 X,
              |petermannCorrectionArithmetic q h s| := by
                rw [Finset.mul_sum]
                apply Finset.sum_congr rfl
                intro s hs
                ring
        _ ≤ Cω * B1 := by
                have hC0 : 0 ≤ Cω := by
                  dsimp [Cω]
                  positivity
                apply mul_le_mul_of_nonneg_left _ hC0
                calc
                  (∑ s ∈ Finset.Icc 1 X,
                      |petermannCorrectionArithmetic q h s|)
                    ≤ ∑' s : ℕ,
                        |petermannCorrectionArithmetic q h s| := by
                          exact (summable_abs_petermannCorrectionArithmetic q h hh).sum_le_tsum
                            (Finset.Icc 1 X) (fun s hs => abs_nonneg _)
                  _ ≤ B1 := by
                    dsimp [B1]
                    exact petermannCorrectionL1_uniform_le q h hh
    have hDist : |D| ≤ omegaRankinBound * BM := by
      unfold D
      rw [abs_mul]
      have hR := abs_logarithmicEulerResidue_omega_le_rankin q hq
      have hS := abs_moving_log_distortion_sum_le q h X hh hX
      exact mul_le_mul hR hS (abs_nonneg _) hR0
    have hTail : |T| ≤ omegaRankinBound * BL := by
      unfold T
      rw [show Rω * Real.log (X : ℝ) *
            ((∑ s ∈ Finset.Icc 1 X,
                petermannCorrectionArithmetic q h s) -
              petermannCorrectionMass q h) =
          Rω * (Real.log (X : ℝ) *
            ((∑ s ∈ Finset.Icc 1 X,
                petermannCorrectionArithmetic q h s) -
              petermannCorrectionMass q h)) by ring]
      rw [abs_mul]
      have hR := abs_logarithmicEulerResidue_omega_le_rankin q hq
      have hS := abs_log_mul_petermannCorrection_tail_le q h X hh hX
      exact mul_le_mul hR hS (abs_nonneg _) hR0
    have hdecomp :
        (∑ s ∈ Finset.Icc 1 X,
            petermannCorrectionArithmetic q h s *
              coefficientPartialSum (omegaCoeff q) (X / s)) -
          (petermannCorrectionMass q h * Rω) * Real.log (X : ℝ) =
        E + D + T := by
      unfold E D T
      have hsum :
          (∑ s ∈ Finset.Icc 1 X,
              petermannCorrectionArithmetic q h s *
                coefficientPartialSum (omegaCoeff q) (X / s)) =
            ∑ s ∈ Finset.Icc 1 X,
              ((petermannCorrectionArithmetic q h s *
                  (coefficientPartialSum (omegaCoeff q) (X / s) -
                    Rω * Real.log (((X / s : ℕ) : ℝ)))) +
                (Rω * (petermannCorrectionArithmetic q h s *
                  (Real.log (((X / s : ℕ) : ℝ)) -
                    Real.log (X : ℝ)))) +
                (Rω * Real.log (X : ℝ) *
                  petermannCorrectionArithmetic q h s)) := by
        apply Finset.sum_congr rfl
        intro s hs
        ring
      rw [hsum]
      rw [Finset.sum_add_distrib, Finset.sum_add_distrib]
      rw [Finset.mul_sum]
      rw [mul_sub, Finset.mul_sum]
      ring
    rw [hdecomp]
    have htri1 : |E + D + T| ≤ |E + D| + |T| :=
      abs_add_le (E + D) T
    have htri2 : |E + D| ≤ |E| + |D| :=
      abs_add_le E D
    calc
      |E + D + T|
        ≤ |E| + |D| + |T| := by linarith
      _ ≤ Cω * B1 +
          omegaRankinBound * BM +
          omegaRankinBound * BL := by linarith
      _ = ((2 * (6 * q) + 9) * omegaRankinBound) *
            petermannCorrectionL1UniformBound +
          omegaRankinBound *
            (petermannCorrectionConvolutionMomentBound +
              petermannCorrectionLogUniformBound) := by
            dsimp [Cω, B1, BM, BL]
            ring

#print axioms movingVPrincipalLogMeanSpec

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def movingVReciprocalTerm
    (q h n : ℕ) : ℝ :=
  movingVCoeff q h n / (n : ℝ)

noncomputable def petermannCorrectionReciprocalTerm
    (q h s : ℕ) : ℝ :=
  petermannCorrectionArithmetic q h s / (s : ℝ)

noncomputable def omegaReciprocalPrefix
    (q X : ℕ) : ℝ :=
  ∑ d ∈ Finset.Icc 1 X, omegaReciprocalTerm q d

noncomputable def movingVReciprocalPrefix
    (q h X : ℕ) : ℝ :=
  ∑ n ∈ Finset.Icc 1 X, movingVReciprocalTerm q h n

theorem movingVCoeff_nonneg
    (q h n : ℕ) :
    0 ≤ movingVCoeff q h n := by
  unfold movingVCoeff
  by_cases hn0 : n = 0
  · simp [hn0]
  · rw [if_neg hn0]
    by_cases hs : Squarefree n ∧ n.Coprime (6 * q)
    · rw [if_pos hs]
      apply Finset.prod_nonneg
      intro p hp
      have hpPrime := (Nat.mem_primeFactors.mp hp).1
      have hpDvd := (Nat.mem_primeFactors.mp hp).2.1
      have hpcop : p.Coprime (6 * q) :=
        hs.2.coprime_dvd_left hpDvd
      have hp5 : 5 ≤ p :=
        omega_rankin_five_le_of_prime_coprime_six hpPrime hpcop
      have hpR : (5 : ℝ) ≤ (p : ℝ) := by exact_mod_cast hp5
      by_cases hph : p ∣ h
      · rw [if_pos hph]
        have hp2 : 0 < (p : ℝ) - 2 := by linarith
        exact le_of_lt (one_div_pos.mpr hp2)
      · rw [if_neg hph]
        have hp3 : 0 < (p : ℝ) - 3 := by linarith
        exact le_of_lt (one_div_pos.mpr hp3)
    · simp [hs]

theorem movingVReciprocalTerm_nonneg
    (q h n : ℕ) :
    0 ≤ movingVReciprocalTerm q h n := by
  unfold movingVReciprocalTerm
  exact div_nonneg (movingVCoeff_nonneg q h n) (by positivity)

theorem movingVReciprocalPrefix_eq_correction
    (q h X : ℕ) :
    movingVReciprocalPrefix q h X =
      ∑ s ∈ Finset.Icc 1 X,
        petermannCorrectionReciprocalTerm q h s *
          omegaReciprocalPrefix q (X / s) := by
  classical
  unfold movingVReciprocalPrefix movingVReciprocalTerm
  calc
    (∑ n ∈ Finset.Icc 1 X, movingVCoeff q h n / (n : ℝ))
      = ∑ n ∈ Finset.Icc 1 X, movingVArithmetic q h n / (n : ℝ) := by
          apply Finset.sum_congr rfl
          intro n hn
          rw [movingVArithmetic_apply]
    _ = ∑ n ∈ Finset.Icc 1 X,
          ∑ ds ∈ n.divisorsAntidiagonal,
            (omegaArithmetic q ds.1 *
              petermannCorrectionArithmetic q h ds.2) / (n : ℝ) := by
          apply Finset.sum_congr rfl
          intro n hn
          rw [movingVArithmetic_eq_omega_mul_petermannCorrection,
            ArithmeticFunction.mul_apply, Finset.sum_div]
    _ = ∑ x ∈ petermannDivisorSigma X,
          (omegaArithmetic q x.2.1 *
            petermannCorrectionArithmetic q h x.2.2) / (x.1 : ℝ) := by
          rw [petermannDivisorSigma, Finset.sum_sigma']
    _ = ∑ x ∈ petermannDivisorSigma X,
          petermannCorrectionReciprocalTerm q h x.2.2 *
            omegaReciprocalTerm q x.2.1 := by
          apply Finset.sum_congr rfl
          intro x hx
          rw [petermannDivisorSigma, Finset.mem_sigma] at hx
          have hn := Finset.mem_Icc.mp hx.1
          have hmul : x.2.1 * x.2.2 = x.1 :=
            (Nat.prodMk_mem_divisorsAntidiag (by omega)).mp hx.2
          have hd0 : x.2.1 ≠ 0 := by
            intro hd
            rw [hd, zero_mul] at hmul
            omega
          have hs0 : x.2.2 ≠ 0 := by
            intro hs
            rw [hs, mul_zero] at hmul
            omega
          unfold petermannCorrectionReciprocalTerm omegaReciprocalTerm
          rw [← hmul, Nat.cast_mul]
          field_simp [show (x.2.1 : ℝ) ≠ 0 by exact_mod_cast hd0,
            show (x.2.2 : ℝ) ≠ 0 by exact_mod_cast hs0]
    _ = ∑ s ∈ Finset.Icc 1 X,
          ∑ d ∈ Finset.Icc 1 (X / s),
            petermannCorrectionReciprocalTerm q h s *
              omegaReciprocalTerm q d := by
          exact sum_petermannDivisorSigma_eq_nested X
            (fun s d =>
              petermannCorrectionReciprocalTerm q h s *
                omegaReciprocalTerm q d)
    _ = ∑ s ∈ Finset.Icc 1 X,
        petermannCorrectionReciprocalTerm q h s *
          omegaReciprocalPrefix q (X / s) := by
          apply Finset.sum_congr rfl
          intro s hs
          unfold omegaReciprocalPrefix
          rw [Finset.mul_sum]

#print axioms movingVReciprocalPrefix_eq_correction
#print axioms movingVReciprocalTerm_nonneg

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem omegaReciprocalPrefix_eq_shifted
    (q X : ℕ) :
    omegaReciprocalPrefix q X =
      ∑ j ∈ Finset.range X, omegaReciprocalTerm q (j + 1) := by
  unfold omegaReciprocalPrefix
  refine Finset.sum_bij
    (fun d hd => d - 1)
    ?_ ?_ ?_ ?_
  · intro d hd
    rw [Finset.mem_Icc] at hd
    rw [Finset.mem_range]
    omega
  · intro d1 hd1 d2 hd2 heq
    rw [Finset.mem_Icc] at hd1 hd2
    omega
  · intro j hj
    rw [Finset.mem_range] at hj
    refine ⟨j + 1, ?_, ?_⟩
    · rw [Finset.mem_Icc]
      omega
    · omega
  · intro d hd
    rw [Finset.mem_Icc] at hd
    congr 1
    omega

theorem omegaReciprocalPrefix_nonneg
    (q X : ℕ) :
    0 ≤ omegaReciprocalPrefix q X := by
  unfold omegaReciprocalPrefix
  exact Finset.sum_nonneg fun d hd => omegaReciprocalTerm_nonneg q d

theorem omegaReciprocalPrefix_le
    (q X : ℕ) :
    omegaReciprocalPrefix q X ≤ 1 + 4 * omegaRankinBound := by
  rw [omegaReciprocalPrefix_eq_shifted]
  exact shifted_omegaReciprocal_sum_range_le q X

theorem omegaReciprocalPrefix_sub_eq_finiteTail
    (q Y Z : ℕ) (hYZ : Y ≤ Z) :
    omegaReciprocalPrefix q Z - omegaReciprocalPrefix q Y =
      ∑ j ∈ Finset.Ico Y Z, omegaReciprocalTerm q (j + 1) := by
  rw [omegaReciprocalPrefix_eq_shifted, omegaReciprocalPrefix_eq_shifted]
  exact (Finset.sum_Ico_eq_sub (fun j => omegaReciprocalTerm q (j + 1)) hYZ).symm

#print axioms omegaReciprocalPrefix_sub_eq_finiteTail

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem movingVCoeff_le_omegaCoeff
    (q h n : ℕ) :
    movingVCoeff q h n ≤ omegaCoeff q n := by
  unfold movingVCoeff omegaCoeff
  by_cases hn0 : n = 0
  · simp [hn0]
  · rw [if_neg hn0, if_neg hn0]
    by_cases hs : Squarefree n ∧ n.Coprime (6 * q)
    · rw [if_pos hs, if_pos hs]
      apply Finset.prod_le_prod₀
      · intro p hp
        have hpPrime := (Nat.mem_primeFactors.mp hp).1
        have hpDvd := (Nat.mem_primeFactors.mp hp).2.1
        have hpcop : p.Coprime (6 * q) :=
          hs.2.coprime_dvd_left hpDvd
        have hp5 : 5 ≤ p :=
          omega_rankin_five_le_of_prime_coprime_six hpPrime hpcop
        have hpR : (5 : ℝ) ≤ (p : ℝ) := by exact_mod_cast hp5
        by_cases hph : p ∣ h
        · rw [if_pos hph]
          have hp2 : 0 < (p : ℝ) - 2 := by linarith
          exact le_of_lt (one_div_pos.mpr hp2)
        · rw [if_neg hph]
          have hp3 : 0 < (p : ℝ) - 3 := by linarith
          exact le_of_lt (one_div_pos.mpr hp3)
      · intro p hp
        have hpPrime := (Nat.mem_primeFactors.mp hp).1
        have hpDvd := (Nat.mem_primeFactors.mp hp).2.1
        have hpcop : p.Coprime (6 * q) :=
          hs.2.coprime_dvd_left hpDvd
        have hp5 : 5 ≤ p :=
          omega_rankin_five_le_of_prime_coprime_six hpPrime hpcop
        have hpR : (5 : ℝ) ≤ (p : ℝ) := by exact_mod_cast hp5
        by_cases hph : p ∣ h
        · rw [if_pos hph]
          have hp2 : 0 < (p : ℝ) - 2 := by linarith
          have hp3 : 0 < (p : ℝ) - 3 := by linarith
          exact one_div_le_one_div_of_le hp3 (by linarith)
        · rw [if_neg hph]
    · simp [hs]

theorem movingVReciprocalTerm_le_omega
    (q h n : ℕ) :
    movingVReciprocalTerm q h n ≤ omegaReciprocalTerm q n := by
  unfold movingVReciprocalTerm
  rw [omegaReciprocalTerm_eq_omegaCoeff_div]
  exact div_le_div_of_nonneg_right
    (movingVCoeff_le_omegaCoeff q h n) (by positivity)

theorem summable_movingVReciprocalTerm
    (q h : ℕ) :
    Summable (movingVReciprocalTerm q h) := by
  exact Summable.of_nonneg_of_le
    (movingVReciprocalTerm_nonneg q h)
    (movingVReciprocalTerm_le_omega q h)
    (summable_omegaReciprocalTerm q)

noncomputable def movingVReciprocalTail
    (q h X : ℕ) : ℝ :=
  ∑' j : ℕ, movingVReciprocalTerm q h (X + 1 + j)

theorem summable_movingVReciprocalTail
    (q h X : ℕ) :
    Summable (fun j : ℕ => movingVReciprocalTerm q h (X + 1 + j)) := by
  have hs :
      Summable (fun j : ℕ => movingVReciprocalTerm q h (j + (X + 1))) :=
    (summable_nat_add_iff (f := movingVReciprocalTerm q h) (X + 1)).2
      (summable_movingVReciprocalTerm q h)
  simpa [Nat.add_comm, Nat.add_left_comm, Nat.add_assoc] using hs

theorem movingVReciprocalTail_nonneg
    (q h X : ℕ) :
    0 ≤ movingVReciprocalTail q h X := by
  unfold movingVReciprocalTail
  exact tsum_nonneg fun j => movingVReciprocalTerm_nonneg q h (X + 1 + j)

theorem movingVReciprocalTail_le_omega
    (q h X : ℕ) :
    movingVReciprocalTail q h X ≤ omegaReciprocalTail q X := by
  unfold movingVReciprocalTail omegaReciprocalTail
  exact Summable.tsum_le_tsum
    (fun j => movingVReciprocalTerm_le_omega q h (X + 1 + j))
    (summable_movingVReciprocalTail q h X)
    (summable_omegaReciprocalTail q X)

theorem movingVReciprocalTail_manuscript
    (q h H : ℕ) (hH : 2 ≤ H) :
    |((H - 1 : ℕ) : ℝ) * movingVReciprocalTail q h (H - 1)| ≤
      4 * omegaRankinBound := by
  have hX : 0 < H - 1 := by omega
  have hXR : (0 : ℝ) < (H - 1 : ℕ) := by exact_mod_cast hX
  have htail :=
    (movingVReciprocalTail_le_omega q h (H - 1)).trans
      (omegaReciprocalTail_le q (H - 1) hX)
  have htail0 := movingVReciprocalTail_nonneg q h (H - 1)
  have hR0 : 0 ≤ omegaRankinBound := by
    unfold omegaRankinBound
    positivity
  rw [abs_mul, abs_of_nonneg (le_of_lt hXR), abs_of_nonneg htail0]
  calc
    ((H - 1 : ℕ) : ℝ) * movingVReciprocalTail q h (H - 1)
      ≤ ((H - 1 : ℕ) : ℝ) *
          (4 * omegaRankinBound * (((H - 1 : ℕ) : ℝ)⁻¹)) :=
        mul_le_mul_of_nonneg_left htail (le_of_lt hXR)
    _ = 4 * omegaRankinBound := by
      have hXne : (((H - 1 : ℕ) : ℝ)) ≠ 0 := ne_of_gt hXR
      field_simp [hXne]

#print axioms movingVCoeff_le_omegaCoeff
#print axioms movingVReciprocalTail_manuscript

end PaperB.FixedQ
