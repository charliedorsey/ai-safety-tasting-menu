import PaperB.FixedQ.SignedForbiddenThalenDecoratedExteriorRows

open scoped BigOperators

namespace PaperB.FixedQ

/-- The source's exact prime-divisibility Boolean indicator, with its
literal natural modulus. -/
theorem thalen_primeSetProduct_indicator_eq_local_product
    (T : Finset ℕ) (y : ℕ) (hp : ∀ p ∈ T, p.Prime) :
    (∏ p ∈ T, if p ∣ y then (1 : ℝ) else 0) =
      (if primeSetProduct T ∣ y then (1 : ℝ) else 0) := by
  classical
  have hprod (U : Finset ℕ) :
      (∏ p ∈ U, if p ∣ y then (1 : ℝ) else 0) =
        (if ∀ p ∈ U, p ∣ y then (1 : ℝ) else 0) := by
    induction U using Finset.induction_on with
    | empty => simp
    | @insert p R hnot ih =>
      rw [Finset.prod_insert hnot]
      rw [ih]
      simp only [Finset.forall_mem_insert]
      by_cases h1 : p ∣ y <;>
        by_cases h2 : ∀ z ∈ R, z ∣ y <;>
        simp [h1, h2]
  calc
    _ = (if ∀ p ∈ T, p ∣ y then (1 : ℝ) else 0) := hprod T
    _ = (if primeSetProduct T ∣ y then (1 : ℝ) else 0) := by
      simp only [primeSetProduct_dvd_iff hp]

/-- Source constrained row mass is exactly a weighted product of
the source's local zero/one indicators for both oriented endpoints. -/
theorem thalen_rowConstrainedMass_eq_local_indicators
    (lambda : ℕ → ℝ) (H : ℕ) (B C : Finset ℕ)
    (hpB : ∀ p ∈ B, p.Prime)
    (hpC : ∀ p ∈ C, p.Prime) :
    rowConstrainedMass lambda H (primeSetProduct B) (primeSetProduct C) =
      ∑ y ∈ Finset.Ioo 0 H, lambda y *
        ((∏ p ∈ B, if p ∣ y then (1 : ℝ) else 0) *
         (∏ p ∈ C, if p ∣ H - y then (1 : ℝ) else 0)) := by
  unfold rowConstrainedMass
  apply Finset.sum_congr rfl
  intro y hy
  rw [thalen_primeSetProduct_indicator_eq_local_product B y hpB,
    thalen_primeSetProduct_indicator_eq_local_product C (H - y) hpC]
  by_cases hb : primeSetProduct B ∣ y <;>
    by_cases hc : primeSetProduct C ∣ H - y <;>
    simp [hb, hc]

#print axioms thalen_primeSetProduct_indicator_eq_local_product
#print axioms thalen_rowConstrainedMass_eq_local_indicators

end PaperB.FixedQ
