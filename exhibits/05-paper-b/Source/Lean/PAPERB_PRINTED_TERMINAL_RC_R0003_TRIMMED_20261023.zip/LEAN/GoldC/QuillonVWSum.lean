import GoldC.QuillonTypeIIEval

/-!
# Quillon CSC3 F7.4h: Vaughan assembly for `Σ Λ(n) e(c n̄/s)`

* `Kmax_bound`: `‖K_s(b, c u)‖ ≤ 3^{|P|/4} s^{3/4} G₀(c)^{1/4}` for every unit `u`.
* **`vw_lambda`**: for `V ≤ A ≤ B`, `‖Σ_{n∈(A,B]} Λ(n)·1_unit(n)e(c n̄/s)‖ ≤ TypeI₁ + TypeI₂ + TypeII`,
  with all three explicit.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset ArithmeticFunction

namespace GoldC.QuillonVWSum

open GoldC.QuillonVW GoldC.QuillonTypeII GoldC.QuillonPartition GoldC.QuillonTypeIIEval
  GoldC.QuillonWCell

lemma cast_mul_unit_zero_iff {s : ℕ} (p : ℕ) (hp : p.Prime) (hps : p ∣ s) (c u : ZMod s)
    (hu : IsUnit u) : (ZMod.cast (c * u) : ZMod p) = 0 ↔ (ZMod.cast c : ZMod p) = 0 := by
  have := Fact.mk hp
  set φ := ZMod.castHom hps (ZMod p)
  have hφ : ∀ x : ZMod s, (ZMod.cast x : ZMod p) = φ x := fun x => (ZMod.castHom_apply x).symm
  rw [hφ, hφ, map_mul]
  have hu' : φ u ≠ 0 := (hu.map φ).ne_zero
  constructor
  · intro h; exact (mul_eq_zero.1 h).resolve_right hu'
  · intro h; rw [h, zero_mul]

section
variable {s : ℕ} [NeZero s]

/-- The Kloosterman sup bound, uniform over unit twists of the frequency. -/
noncomputable def Kmax (P : Finset ℕ) (c : ZMod s) : ℝ :=
  (3 : ℝ) ^ ((P.card : ℝ) / 4) * (s : ℝ) ^ ((3 : ℝ) / 4) *
    (∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) = 0), (p : ℝ)) ^ ((1 : ℝ) / 4)

lemma Kmax_nonneg (P : Finset ℕ) (c : ZMod s) : 0 ≤ Kmax P c := by
  unfold Kmax; positivity

lemma Kmax_bound (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p) (c : ZMod s) :
    ∀ u : ZMod s, IsUnit u → ∀ b : ZMod s, ‖GoldC.QuillonKl.K s b (c * u)‖ ≤ Kmax P c := by
  intro u hu b
  refine (norm_K_le_KB P hP s hsP b (c * u)).trans ((KB_le P hP (c * u)).trans (le_of_eq ?_))
  unfold Kmax
  have hsR : (∏ p ∈ P, (p : ℝ)) = (s : ℝ) := by rw [hsP, Nat.cast_prod]
  rw [hsR]
  congr 2
  apply Finset.prod_congr _ (fun _ _ => rfl)
  apply Finset.filter_congr
  intro p hp
  exact cast_mul_unit_zero_iff p (hP p hp) (by rw [hsP]; exact Finset.dvd_prod_of_mem _ hp) c u hu

/-- **Vaughan assembly.** -/
theorem vw_lambda (hs2 : 2 ≤ s) (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p)
    (c : ZMod s) (U V T A B : ℕ) (hVA : V ≤ A) (hAB : A ≤ B) (hU : 2 ≤ U) (hT : 2 ≤ T) :
    ‖∑ n ∈ Ioc A B, ((vonMangoldt n : ℝ) : ℂ) * kphase c n‖ ≤
      2 * Real.log B * Kmax P c * (B * (1 + Real.log U) / s + U * (1 + Real.log s)) +
      Real.log B * Kmax P c * (B * (1 + Real.log (U * V : ℕ)) / s + (U * V : ℕ) * (1 + Real.log s)) +
      (Real.sqrt (2 * (1 + Real.log (tseq U T (Jstop U T V B (by omega) (by omega)))) ^ 4) *
        Real.sqrt (Real.log B ^ 2 * B * (Jstop U T V B (by omega) (by omega) : ℝ) *
          (2 * B / ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ) +
            2 * (tseq U T (Jstop U T V B (by omega) (by omega)) : ℝ) +
            s * B / (U * ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ)) +
            s)) +
      Real.log B * (1 + Real.log (tseq U T (Jstop U T V B (by omega) (by omega)))) ^ 4 *
        (2 * B / T + 2 * B / U + 2 * (tseq U T (Jstop U T V B (by omega) (by omega)) : ℝ))) := by
  have hsplit : ∑ n ∈ Ioc A B, ((vonMangoldt n : ℝ) : ℂ) * kphase c n =
      ∑ n ∈ Ioc A B, ((((GoldC.QuillonVaughan.trunc U μR) * log) n : ℝ) : ℂ) * kphase c n -
      ∑ n ∈ Ioc A B, ((((GoldC.QuillonVaughan.trunc U μR) *
        (GoldC.QuillonVaughan.trunc V vonMangoldt) * ζR) n : ℝ) : ℂ) * kphase c n +
      ∑ n ∈ Ioc A B, ((((GoldC.QuillonVaughan.upper U μR) *
        (GoldC.QuillonVaughan.upper V vonMangoldt) * ζR) n : ℝ) : ℂ) * kphase c n := by
    rw [← sum_sub_distrib, ← sum_add_distrib]
    refine sum_congr rfl fun n hn => ?_
    have hn' : V < n := lt_of_le_of_lt hVA (mem_Ioc.1 hn).1
    rw [GoldC.QuillonVaughan.vaughan_apply U V n hn']
    push_cast; ring
  rw [hsplit]
  have hK := Kmax_bound P hP hsP c
  have hK0 := Kmax_nonneg P c
  refine (norm_add_le _ _).trans (add_le_add ((norm_sub_le _ _).trans (add_le_add ?_ ?_)) ?_)
  · exact typeI1 hs2 c U A B hAB (Kmax P c) hK hK0
  · exact typeI2 hs2 c U V A B hAB (Kmax P c) hK hK0
  · exact typeII_eval P hP hsP c U V T A B hAB hU hT

end

end GoldC.QuillonVWSum

#print axioms GoldC.QuillonVWSum.vw_lambda
