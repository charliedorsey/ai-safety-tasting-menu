import Mathlib.Analysis.Calculus.Deriv.ZPow
import Mathlib.Analysis.Calculus.Deriv.Shift
import Mathlib.Analysis.Calculus.IteratedDeriv.Defs
import Mathlib.Analysis.Calculus.ContDiff.Operations
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Algebra.BigOperators.Module
import Mathlib.Data.Nat.Factorial.Basic

/-!
# `GoldC.VKCore` — the isolated order-uniform Vinogradov input, and what follows from it

Mathlib-only; no `GoldC` source file is imported or restated.  **No axiom, no `sorry`.**

* `UniformVinogradovEstimate` is the exact analytic theorem that must still be proved
  (T. Tao, *254A Notes 5*, Theorem 2(ii); Titchmarsh Ch. VI; Iwaniec–Kowalski §8.5).
  It is a `Prop`, used only as an explicit hypothesis.  Its constants `c, C` may depend on the
  implied constants `A₀, B₀` of the hypotheses but on **nothing else**: not on the derivative
  order `k`, the scale `N`, the size `T`, the phase `f`, or the interval.  A fixed-order estimate
  whose constants depend on `k` (e.g. Heath-Brown 2017, Thm 1) does **not** inhabit it.
* `ReciprocalPhaseVK σ` is the smallest consumer-facing analytic statement that Type I needs:
  the reciprocal phase `X/(x+θ)` only, super-polylogarithmic saving in the range
  `log L ≥ (log T)^σ`.
* `recipPhase_derivHyp` (**proved**): the reciprocal phase satisfies the all-order derivative
  hypothesis with the explicit constant `A₀ = 2`, uniformly in the order.
* `reciprocalPhaseVK_of_uniform` (**proved**): `2/3 < σ → UniformVinogradovEstimate →
  ReciprocalPhaseVK σ`.
* `typeI_class_sum_le` (**proved, conditional on `ReciprocalPhaseVK σ`**): the harmonic-weighted
  Type I class sum `Σ_j e(X₀/(j+θ))/(Q(j+θ))` over any run of consecutive `j` inside the
  dyadic window is `≤ (log T)^{-A}/Q`, for every `A`, all large `T`.
-/

open scoped ContDiff BigOperators
open Real Filter Topology Finset

namespace GoldC.VK

/-! ## Exponential sums over runs of consecutive integers -/

/-- `e(x) = exp(2πix)`. -/
noncomputable def eAdd (x : ℝ) : ℂ := Complex.exp (2 * Real.pi * Complex.I * (x : ℂ))

lemma norm_eAdd (x : ℝ) : ‖eAdd x‖ = 1 := by
  unfold eAdd
  rw [Complex.norm_exp]
  simp

/-- `Σ_{0 ≤ i < n} e(f(a+i))`: the exponential sum over the `n` consecutive integers
`a, a+1, …, a+n-1`.  (Every set of integers in an interval is such a run.) -/
noncomputable def expSum (f : ℝ → ℝ) (a : ℤ) (n : ℕ) : ℂ :=
  ∑ i ∈ range n, eAdd (f ((a : ℝ) + i))

/-- The real interval spanned by the run `a, …, a+n-1`. -/
def runIcc (a : ℤ) (n : ℕ) : Set ℝ := Set.Icc (a : ℝ) ((a : ℝ) + n - 1)

/-! ## The isolated analytic theorem (NOT proved here) -/

/-- Tao's hypothesis (3): `|f^{(j)}(x)| = exp(O(j²)) T/N^j` for **all** `j ≥ 1`, with the
`O`-constant `A₀`, two-sided. -/
def DerivHyp (A₀ N T : ℝ) (f : ℝ → ℝ) (I : Set ℝ) : Prop :=
  ∀ j : ℕ, 1 ≤ j → ∀ x ∈ I,
    Real.exp (-(A₀ * (j : ℝ) ^ 2)) * (T / N ^ j) ≤ |iteratedDeriv j f x| ∧
    |iteratedDeriv j f x| ≤ Real.exp (A₀ * (j : ℝ) ^ 2) * (T / N ^ j)

/-- **The order-uniform Vinogradov exponential-sum estimate** (Tao, *254A Notes 5*, Thm 2(ii)).

For `2 ≤ N ≤ B₀ T`, any run of at most `N + 1` consecutive integers (an interval of length
`≤ N`), `f` smooth on an open set containing the interval and obeying hypothesis (3) with
constant `A₀`, and any `k ≥ 1` with `T ≤ N^k`:
`|Σ e(f(n))| ≤ C · N · N^{-c/k²}`,
where `c > 0` and `C` depend only on `(A₀, B₀)`.

This is a `Prop`, not an axiom.  Everything downstream takes it as an explicit hypothesis. -/
def UniformVinogradovEstimate : Prop :=
  ∀ A₀ B₀ : ℝ, 0 < A₀ → 0 < B₀ →
    ∃ c C : ℝ, 0 < c ∧ 0 ≤ C ∧
      ∀ (N T : ℝ) (k : ℕ) (f : ℝ → ℝ) (a : ℤ) (n : ℕ) (U : Set ℝ),
        2 ≤ N → N ≤ B₀ * T → 1 ≤ k → T ≤ N ^ k →
        (n : ℝ) - 1 ≤ N →
        IsOpen U → runIcc a n ⊆ U → ContDiffOn ℝ ∞ f U →
        DerivHyp A₀ N T f (runIcc a n) →
        ‖expSum f a n‖ ≤ C * N * N ^ (-(c / (k : ℝ) ^ 2))

/-! ## The source reciprocal phase -/

/-- The Type I reciprocal phase `x ↦ X/(x+θ)` (source: `kH/(Ars)` with `s = C·Q·(j+θ)`). -/
noncomputable def recipPhase (X θ : ℝ) : ℝ → ℝ := fun x => X / (x + θ)

/-- Iterated derivatives of `x ↦ c (x+θ)^m`, globally (Lean's junk values agree at the pole). -/
lemma iterate_deriv_shift_zpow (c θ : ℝ) (m : ℤ) (k : ℕ) :
    deriv^[k] (fun x : ℝ => c * (x + θ) ^ m) =
      fun x => c * (∏ i ∈ range k, ((m : ℝ) - i)) * (x + θ) ^ (m - k) := by
  induction k with
  | zero => funext x; simp
  | succ k ih =>
    rw [Function.iterate_succ_apply', ih]
    funext x
    have hd : deriv (fun x : ℝ => (x + θ) ^ (m - (k : ℤ))) x =
        ((m - (k : ℤ) : ℤ) : ℝ) * (x + θ) ^ (m - (k : ℤ) - 1) := by
      rw [deriv_comp_add_const (f := fun y : ℝ => y ^ (m - (k : ℤ)))]
      exact deriv_zpow _ _
    have hconst : deriv (fun x : ℝ =>
        c * (∏ i ∈ range k, ((m : ℝ) - i)) * (x + θ) ^ (m - (k : ℤ))) x =
        c * (∏ i ∈ range k, ((m : ℝ) - i)) *
          deriv (fun x : ℝ => (x + θ) ^ (m - (k : ℤ))) x := by
      rw [deriv_const_mul_field']
    rw [hconst, hd, prod_range_succ]
    have e1 : m - ((k + 1 : ℕ) : ℤ) = m - (k : ℤ) - 1 := by push_cast; ring
    rw [e1]
    push_cast
    ring

/-- `∏_{i<k} (-1 - i) = (-1)^k k!`. -/
lemma prod_neg_one_sub (k : ℕ) :
    (∏ i ∈ range k, (((-1 : ℤ) : ℝ) - i)) = (-1) ^ k * (k.factorial : ℝ) := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [prod_range_succ, ih, Nat.factorial_succ, pow_succ]
    push_cast
    ring

/-- **Exact all-order derivatives of the reciprocal phase.** -/
theorem iteratedDeriv_recipPhase (X θ : ℝ) (k : ℕ) (x : ℝ) :
    iteratedDeriv k (recipPhase X θ) x =
      X * ((-1) ^ k * (k.factorial : ℝ)) * (x + θ) ^ ((-1 : ℤ) - k) := by
  have hf : recipPhase X θ = fun x : ℝ => X * (x + θ) ^ (-1 : ℤ) := by
    funext x; simp [recipPhase, div_eq_mul_inv]
  rw [iteratedDeriv_eq_iterate, hf, iterate_deriv_shift_zpow, prod_neg_one_sub]

lemma abs_iteratedDeriv_recipPhase {X θ x : ℝ} (hX : 0 ≤ X) (hx : 0 < x + θ) (k : ℕ) :
    |iteratedDeriv k (recipPhase X θ) x| = (k.factorial : ℝ) * X / (x + θ) ^ (k + 1) := by
  rw [iteratedDeriv_recipPhase]
  have hz : (x + θ) ^ ((-1 : ℤ) - k) = ((x + θ) ^ (k + 1))⁻¹ := by
    rw [show ((-1 : ℤ) - k) = -((k + 1 : ℕ) : ℤ) by push_cast; ring, zpow_neg, zpow_natCast]
  rw [hz, abs_mul, abs_mul, abs_mul, abs_pow, abs_neg, abs_one, one_pow, one_mul,
    abs_of_nonneg hX, abs_of_nonneg (by positivity : (0 : ℝ) ≤ (k.factorial : ℝ)),
    abs_of_pos (by positivity : (0 : ℝ) < ((x + θ) ^ (k + 1))⁻¹)]
  field_simp

/-- `j! ≤ exp(2 j²)`. -/
lemma factorial_le_exp_two_sq (j : ℕ) : (j.factorial : ℝ) ≤ Real.exp (2 * (j : ℝ) ^ 2) := by
  have h1 : (j.factorial : ℝ) ≤ (j : ℝ) ^ j := by exact_mod_cast Nat.factorial_le_pow j
  rcases Nat.eq_zero_or_pos j with rfl | hj
  · simp
  have hjr : (1 : ℝ) ≤ j := by exact_mod_cast hj
  have h2 : (j : ℝ) ^ j ≤ Real.exp (j : ℝ) ^ j :=
    pow_le_pow_left₀ (by positivity) (by linarith [Real.add_one_le_exp (j : ℝ)]) j
  rw [← Real.exp_nat_mul] at h2
  calc (j.factorial : ℝ) ≤ Real.exp (j * j) := h1.trans h2
    _ ≤ Real.exp (2 * (j : ℝ) ^ 2) := by
        apply Real.exp_le_exp.2; nlinarith

/-- `2^{j+1} ≤ exp(2 j²)` for `j ≥ 1`. -/
lemma two_pow_succ_le_exp (j : ℕ) (hj : 1 ≤ j) :
    (2 : ℝ) ^ (j + 1) ≤ Real.exp (2 * (j : ℝ) ^ 2) := by
  have hjr : (1 : ℝ) ≤ j := by exact_mod_cast hj
  have h2 : (2 : ℝ) ≤ Real.exp 1 := by
    have := Real.add_one_le_exp (1 : ℝ); linarith
  calc (2 : ℝ) ^ (j + 1) ≤ Real.exp 1 ^ (j + 1) := pow_le_pow_left₀ (by norm_num) h2 _
    _ = Real.exp ((j + 1 : ℕ) * 1) := by rw [← Real.exp_nat_mul]
    _ ≤ Real.exp (2 * (j : ℝ) ^ 2) := by
        apply Real.exp_le_exp.2; push_cast; nlinarith

/-- **The source-phase derivative hypothesis, every order, constant `A₀ = 2`.**
On the dyadic window `x + θ ∈ [L, 2L]`, `f = X/(x+θ)` obeys
`exp(-2j²) T/L^j ≤ |f^{(j)}(x)| ≤ exp(2j²) T/L^j` with `T = X/L`, for **all** `j ≥ 1`. -/
theorem recipPhase_derivHyp {X θ L : ℝ} (hX : 0 ≤ X) (hL : 0 < L) (I : Set ℝ)
    (hI : ∀ x ∈ I, L ≤ x + θ ∧ x + θ ≤ 2 * L) :
    DerivHyp 2 L (X / L) (recipPhase X θ) I := by
  intro j hj x hx
  obtain ⟨hlo, hhi⟩ := hI x hx
  have hxθ : 0 < x + θ := lt_of_lt_of_le hL hlo
  rw [abs_iteratedDeriv_recipPhase hX hxθ j]
  have hLj : 0 < L ^ j := pow_pos hL j
  have hfac := factorial_le_exp_two_sq j
  have h2p := two_pow_succ_le_exp j hj
  have hfac1 : (1 : ℝ) ≤ j.factorial := by exact_mod_cast Nat.one_le_iff_ne_zero.2 (Nat.factorial_ne_zero j)
  have hpow_lo : L ^ (j + 1) ≤ (x + θ) ^ (j + 1) := pow_le_pow_left₀ hL.le hlo _
  have hpow_hi : (x + θ) ^ (j + 1) ≤ (2 * L) ^ (j + 1) := pow_le_pow_left₀ hxθ.le hhi _
  have hpos : 0 < (x + θ) ^ (j + 1) := pow_pos hxθ _
  have hT : X / L / L ^ j = X / L ^ (j + 1) := by
    rw [div_div, pow_succ]; ring_nf
  constructor
  · -- lower bound
    rw [hT]
    have hexp : Real.exp (-(2 * (j : ℝ) ^ 2)) = (Real.exp (2 * (j : ℝ) ^ 2))⁻¹ := Real.exp_neg _
    rw [hexp]
    have hE : 0 < Real.exp (2 * (j : ℝ) ^ 2) := Real.exp_pos _
    rw [inv_mul_le_iff₀ hE]
    -- X / L^(j+1) ≤ exp(2j²) · j! X/(x+θ)^(j+1)
    have key : X / L ^ (j + 1) ≤ (2 : ℝ) ^ (j + 1) * (X / (2 * L) ^ (j + 1)) := by
      apply le_of_eq
      rw [mul_pow]
      field_simp
    calc X / L ^ (j + 1) ≤ (2 : ℝ) ^ (j + 1) * (X / (2 * L) ^ (j + 1)) := key
      _ ≤ Real.exp (2 * (j : ℝ) ^ 2) * ((j.factorial : ℝ) * X / (x + θ) ^ (j + 1)) := by
          apply mul_le_mul h2p _ (by positivity) hE.le
          rw [mul_div_assoc]
          calc X / (2 * L) ^ (j + 1) ≤ X / (x + θ) ^ (j + 1) :=
                div_le_div_of_nonneg_left hX hpos hpow_hi
            _ ≤ (j.factorial : ℝ) * (X / (x + θ) ^ (j + 1)) :=
                le_mul_of_one_le_left (div_nonneg hX hpos.le) hfac1
  · -- upper bound
    rw [hT]
    calc (j.factorial : ℝ) * X / (x + θ) ^ (j + 1) = (j.factorial : ℝ) * (X / (x + θ) ^ (j + 1)) := by
          ring
      _ ≤ (j.factorial : ℝ) * (X / L ^ (j + 1)) := by
          apply mul_le_mul_of_nonneg_left _ (by positivity)
          exact div_le_div_of_nonneg_left hX (pow_pos hL _) hpow_lo
      _ ≤ Real.exp (2 * (j : ℝ) ^ 2) * (X / L ^ (j + 1)) :=
          mul_le_mul_of_nonneg_right hfac (div_nonneg hX (pow_pos hL _).le)

lemma recipPhase_contDiffOn (X θ : ℝ) :
    ContDiffOn ℝ ∞ (recipPhase X θ) (Set.Ioi (-θ)) := by
  unfold recipPhase
  apply ContDiffOn.div contDiffOn_const (contDiffOn_id.add contDiffOn_const)
  intro x hx
  have : -θ < x := hx
  simp only [id]
  linarith

/-! ## The minimal consumer statement and its derivation from the uniform estimate -/

/-- **Smallest Type I analytic input.** For every `A > 0`, for all large `T`:
for every scale `L ≥ 2` with `L ≤ T` and `log L ≥ (log T)^σ`, every shift `θ`, and every run of
consecutive integers `a, …, a+n-1` with all `x+θ ∈ [L, 2L]`,
`|Σ e(TL/(x+θ))| ≤ L (log T)^{-A}`. -/
def ReciprocalPhaseVK (σ : ℝ) : Prop :=
  ∀ A : ℝ, 0 < A → ∃ T₀ : ℝ, ∀ (L T θ : ℝ) (a : ℤ) (n : ℕ),
    T₀ ≤ T → 2 ≤ L → L ≤ T → Real.log T ^ σ ≤ Real.log L →
    (∀ x ∈ runIcc a n, L ≤ x + θ ∧ x + θ ≤ 2 * L) →
    ‖expSum (recipPhase (T * L) θ) a n‖ ≤ L * Real.log T ^ (-A)

/-- Elementary rate fact: `C exp(-κ y^δ) ≤ y^{-A}` eventually. -/
lemma eventually_const_mul_exp_neg_le (C κ δ A : ℝ) (hκ : 0 < κ) (hδ : 0 < δ) :
    ∃ y₀ : ℝ, 1 ≤ y₀ ∧ ∀ y : ℝ, y₀ ≤ y → C * Real.exp (-(κ * y ^ δ)) ≤ y ^ (-A) := by
  -- z = y^δ → ∞ and z^{A/δ} exp(-κ z) → 0.
  have ht := tendsto_rpow_mul_exp_neg_mul_atTop_nhds_zero (A / δ) κ hκ
  have hz : Tendsto (fun y : ℝ => y ^ δ) atTop atTop := tendsto_rpow_atTop hδ
  have hcomp := ht.comp hz
  have hev : ∀ᶠ y in atTop, ((y ^ δ) ^ (A / δ) * Real.exp (-κ * y ^ δ)) * |C| ≤ 1 := by
    have : Tendsto (fun y : ℝ => ((y ^ δ) ^ (A / δ) * Real.exp (-κ * y ^ δ)) * |C|) atTop (𝓝 0) := by
      simpa using hcomp.mul_const |C|
    exact this.eventually (ge_mem_nhds (by norm_num))
  obtain ⟨y₁, hy₁⟩ := eventually_atTop.1 hev
  refine ⟨max y₁ 1, le_max_right _ _, fun y hy => ?_⟩
  have hy1 : 1 ≤ y := (le_max_right _ _).trans hy
  have hy0 : 0 < y := by linarith
  have h := hy₁ y ((le_max_left _ _).trans hy)
  have hpow : (y ^ δ) ^ (A / δ) = y ^ A := by
    rw [← Real.rpow_mul hy0.le]; congr 1; field_simp
  rw [hpow] at h
  have hyA : 0 < y ^ A := Real.rpow_pos_of_pos hy0 A
  have hneg : y ^ (-A) = (y ^ A)⁻¹ := Real.rpow_neg hy0.le A
  rw [hneg]
  have hE : 0 < Real.exp (-(κ * y ^ δ)) := Real.exp_pos _
  have h' : y ^ A * (Real.exp (-(κ * y ^ δ)) * |C|) ≤ 1 := by
    have : -κ * y ^ δ = -(κ * y ^ δ) := by ring
    rw [this] at h; linarith [h]
  calc C * Real.exp (-(κ * y ^ δ)) ≤ |C| * Real.exp (-(κ * y ^ δ)) :=
        mul_le_mul_of_nonneg_right (le_abs_self C) hE.le
    _ = (y ^ A)⁻¹ * (y ^ A * (Real.exp (-(κ * y ^ δ)) * |C|)) := by
        field_simp
    _ ≤ (y ^ A)⁻¹ * 1 := mul_le_mul_of_nonneg_left h' (inv_nonneg.2 hyA.le)
    _ = (y ^ A)⁻¹ := mul_one _

/-- **Rate step.** With `k = ⌈log T / log L⌉`, `T ≥ L ≥ 2` and `log L ≥ (log T)^σ`:
`L^{-c/k²} ≤ exp(-(c/4) (log T)^{3σ-2})`. -/
lemma saving_le {c L T σ : ℝ} (hc : 0 < c) (hL : 2 ≤ L) (hLT : L ≤ T)
    (hσ : Real.log T ^ σ ≤ Real.log L) :
    L ^ (-(c / ((⌈Real.log T / Real.log L⌉₊ : ℕ) : ℝ) ^ 2)) ≤
      Real.exp (-(c / 4 * Real.log T ^ (3 * σ - 2))) := by
  set ℓ := Real.log L with hℓ
  set τ := Real.log T with hτ
  have hℓpos : 0 < ℓ := Real.log_pos (by linarith)
  have hℓτ : ℓ ≤ τ := Real.log_le_log (by linarith) hLT
  have hτpos : 0 < τ := lt_of_lt_of_le hℓpos hℓτ
  set ρ := τ / ℓ with hρ
  have hρ1 : 1 ≤ ρ := by rw [hρ, le_div_iff₀ hℓpos]; linarith
  set k : ℕ := ⌈ρ⌉₊ with hk
  have hk_le : (k : ℝ) ≤ 2 * ρ := by
    have := Nat.ceil_lt_add_one (show (0 : ℝ) ≤ ρ by linarith)
    linarith
  have hk_pos : (0 : ℝ) < k := by
    have : ρ ≤ (k : ℝ) := Nat.le_ceil ρ
    linarith
  have hLpos : 0 < L := by linarith
  rw [Real.rpow_def_of_pos hLpos]
  apply Real.exp_le_exp.2
  -- goal: log L * (-(c/k²)) ≤ -(c/4 · τ^{3σ-2})
  have hk2 : (k : ℝ) ^ 2 ≤ 4 * ρ ^ 2 := by nlinarith
  have hρ' : ρ ^ 2 = τ ^ 2 / ℓ ^ 2 := by rw [hρ, div_pow]
  -- c/k² ≥ c ℓ² / (4 τ²)
  have hck : c * ℓ ^ 2 / (4 * τ ^ 2) ≤ c / (k : ℝ) ^ 2 := by
    rw [div_le_div_iff₀ (by positivity) (by positivity)]
    have : (k : ℝ) ^ 2 * ℓ ^ 2 ≤ 4 * τ ^ 2 := by
      have := mul_le_mul_of_nonneg_right hk2 (sq_nonneg ℓ)
      rw [hρ'] at this
      field_simp at this
      linarith
    nlinarith
  -- ℓ³/τ² ≥ τ^{3σ-2}
  have hℓσ : τ ^ σ ≤ ℓ := hσ
  have hτσ : 0 < τ ^ σ := Real.rpow_pos_of_pos hτpos σ
  have hcube : τ ^ (3 * σ - 2) ≤ ℓ ^ 3 / τ ^ 2 := by
    rw [le_div_iff₀ (by positivity)]
    have e : τ ^ (3 * σ - 2) * τ ^ 2 = (τ ^ σ) ^ 3 := by
      rw [← Real.rpow_natCast, ← Real.rpow_natCast, ← Real.rpow_add hτpos,
        ← Real.rpow_mul hτpos.le]
      congr 1; push_cast; ring
    rw [e]
    exact pow_le_pow_left₀ hτσ.le hℓσ 3
  have : c / 4 * τ ^ (3 * σ - 2) ≤ ℓ * (c / (k : ℝ) ^ 2) := by
    calc c / 4 * τ ^ (3 * σ - 2) ≤ c / 4 * (ℓ ^ 3 / τ ^ 2) :=
          mul_le_mul_of_nonneg_left hcube (by positivity)
      _ = ℓ * (c * ℓ ^ 2 / (4 * τ ^ 2)) := by field_simp
      _ ≤ ℓ * (c / (k : ℝ) ^ 2) := mul_le_mul_of_nonneg_left hck hℓpos.le
  linarith

/-- **The uniform Vinogradov estimate implies the minimal Type I input** for every `σ > 2/3`.
The derivative hypothesis is discharged by `recipPhase_derivHyp` (constant `A₀ = 2`), the
smoothness by `recipPhase_contDiffOn`, and the rate by `saving_le`. -/
theorem reciprocalPhaseVK_of_uniform {σ : ℝ} (hσ : 2 / 3 < σ)
    (hV : UniformVinogradovEstimate) : ReciprocalPhaseVK σ := by
  obtain ⟨c, C, hc, hC, hbound⟩ := hV 2 1 (by norm_num) (by norm_num)
  intro A hA
  obtain ⟨y₀, hy₀1, hy₀⟩ :=
    eventually_const_mul_exp_neg_le C (c / 4) (3 * σ - 2) A (by positivity) (by linarith)
  refine ⟨Real.exp y₀, fun L T θ a n hT hL hLT hσL hwin => ?_⟩
  have hLpos : 0 < L := by linarith
  have hTpos : 0 < T := by linarith
  have hlogT : y₀ ≤ Real.log T := by
    rw [Real.le_log_iff_exp_le hTpos]; exact hT
  set k : ℕ := ⌈Real.log T / Real.log L⌉₊ with hk
  have hℓpos : 0 < Real.log L := Real.log_pos (by linarith)
  have hρ1 : 1 ≤ Real.log T / Real.log L := by
    rw [le_div_iff₀ hℓpos, one_mul]; exact Real.log_le_log hLpos hLT
  have hk1 : 1 ≤ k := by
    have : (1 : ℝ) ≤ k := hρ1.trans (Nat.le_ceil _)
    exact_mod_cast this
  have hTLk : T ≤ L ^ k := by
    have h1 : Real.log T ≤ k * Real.log L := by
      have := Nat.le_ceil (Real.log T / Real.log L)
      rw [div_le_iff₀ hℓpos] at this; linarith
    rw [← Real.exp_log hTpos, ← Real.rpow_natCast, Real.rpow_def_of_pos hLpos]
    apply Real.exp_le_exp.2; linarith
  -- window ⇒ run length ≤ L
  have hlen : (n : ℝ) - 1 ≤ L := by
    rcases Nat.eq_zero_or_pos n with rfl | hn
    · simp; linarith
    have ha : (a : ℝ) ∈ runIcc a n := by
      refine ⟨le_refl _, ?_⟩
      have : (1 : ℝ) ≤ n := by exact_mod_cast hn
      linarith
    have hb : (a : ℝ) + n - 1 ∈ runIcc a n := by
      refine ⟨?_, le_refl _⟩
      have : (1 : ℝ) ≤ n := by exact_mod_cast hn
      linarith
    have h1 := (hwin _ ha).1
    have h2 := (hwin _ hb).2
    linarith
  have hsub : runIcc a n ⊆ Set.Ioi (-θ) := by
    intro x hx
    have := (hwin x hx).1
    show -θ < x
    linarith
  have hder : DerivHyp 2 L T (recipPhase (T * L) θ) (runIcc a n) := by
    have h := recipPhase_derivHyp (X := T * L) (θ := θ) (by positivity) hLpos (runIcc a n) hwin
    rwa [mul_div_assoc, div_self hLpos.ne', mul_one] at h
  have hmain := hbound L T k (recipPhase (T * L) θ) a n (Set.Ioi (-θ)) hL
    (by rw [one_mul]; exact hLT) hk1 hTLk hlen isOpen_Ioi hsub (recipPhase_contDiffOn _ _) hder
  have hsave := saving_le hc hL hLT hσL
  have hy := hy₀ (Real.log T) hlogT
  calc ‖expSum (recipPhase (T * L) θ) a n‖ ≤ C * L * L ^ (-(c / (k : ℝ) ^ 2)) := hmain
    _ ≤ C * L * Real.exp (-(c / 4 * Real.log T ^ (3 * σ - 2))) :=
        mul_le_mul_of_nonneg_left hsave (by positivity)
    _ = L * (C * Real.exp (-(c / 4 * Real.log T ^ (3 * σ - 2)))) := by ring
    _ ≤ L * Real.log T ^ (-A) := mul_le_mul_of_nonneg_left hy hLpos.le

/-! ## Abel summation and the harmonic-weighted Type I class sum -/

/-- Abel summation: nonnegative nonincreasing weights cost only the first weight. -/
theorem abel_antitone {z : ℕ → ℂ} {w : ℕ → ℝ} (n : ℕ) (hw0 : ∀ i, 0 ≤ w i)
    (hwm : ∀ i, w (i + 1) ≤ w i) {B : ℝ}
    (hB : ∀ m ≤ n, ‖∑ i ∈ range m, z i‖ ≤ B) :
    ‖∑ i ∈ range n, (w i : ℂ) * z i‖ ≤ w 0 * B := by
  have hB0 : 0 ≤ B := le_trans (norm_nonneg _) (hB 0 (Nat.zero_le _))
  -- induction on n with the stronger statement involving the last weight
  -- S_n = Σ_{i<n} w_i z_i = w_{n-1} Z_n + Σ_{i<n-1} (w_i - w_{i+1}) Z_{i+1}
  set Z : ℕ → ℂ := fun m => ∑ i ∈ range m, z i with hZ
  have hrep : ∀ m, ∑ i ∈ range m, (w i : ℂ) * z i =
      (w m : ℂ) * Z m + ∑ i ∈ range m, ((w i - w (i + 1) : ℝ) : ℂ) * Z (i + 1) := by
    intro m
    induction m with
    | zero => simp [hZ]
    | succ m ih =>
      rw [sum_range_succ, ih, sum_range_succ]
      simp only [hZ, sum_range_succ]
      push_cast
      ring
  have hmono : ∀ m, w m ≤ w 0 := by
    intro m; induction m with
    | zero => exact le_refl _
    | succ m ih => exact (hwm m).trans ih
  have htel : ∀ m, ∑ i ∈ range m, (w i - w (i + 1)) = w 0 - w m := by
    intro m; induction m with
    | zero => simp
    | succ m ih => rw [sum_range_succ, ih]; ring
  rw [hrep n]
  calc ‖(w n : ℂ) * Z n + ∑ i ∈ range n, ((w i - w (i + 1) : ℝ) : ℂ) * Z (i + 1)‖
      ≤ ‖(w n : ℂ) * Z n‖ + ‖∑ i ∈ range n, ((w i - w (i + 1) : ℝ) : ℂ) * Z (i + 1)‖ :=
        norm_add_le _ _
    _ ≤ w n * B + ∑ i ∈ range n, (w i - w (i + 1)) * B := by
        gcongr
        · rw [norm_mul, Complex.norm_real, Real.norm_of_nonneg (hw0 n)]
          exact mul_le_mul_of_nonneg_left (hB n le_rfl) (hw0 n)
        · refine (norm_sum_le _ _).trans (sum_le_sum fun i hi => ?_)
          rw [norm_mul, Complex.norm_real, Real.norm_of_nonneg (sub_nonneg.2 (hwm i))]
          exact mul_le_mul_of_nonneg_left (hB (i + 1) (mem_range.1 hi))
            (sub_nonneg.2 (hwm i))
    _ = w 0 * B := by rw [← sum_mul, htel]; ring

/-- **Type I class sum, harmonic weights (conditional on `ReciprocalPhaseVK σ` only).**

Source shape (C2 §4.4, supplier §4): `V = Σ_j e(X₀/(j+θ)) / t_j` with `t_j = Q (j+θ)`, over any
run of consecutive `j` with `j + θ ∈ [L, 2L]`, where `X₀ = T L`.  Then for every `A > 0` and all
large `T`, in the VK range `L ≤ T`, `log L ≥ (log T)^σ`:  `|V| ≤ (log T)^{-A} / Q`.
(Trivially `|V| ≤ (n/L)/Q ≤ 1/Q`; the gain is the full `(log T)^{-A}`, for every sub-run.) -/
theorem typeI_class_sum_le {σ : ℝ} (hVK : ReciprocalPhaseVK σ) (A : ℝ) (hA : 0 < A) :
    ∃ T₀ : ℝ, ∀ (L T θ Q : ℝ) (a : ℤ) (n : ℕ),
      T₀ ≤ T → 2 ≤ L → L ≤ T → Real.log T ^ σ ≤ Real.log L → 0 < Q →
      (∀ x ∈ runIcc a n, L ≤ x + θ ∧ x + θ ≤ 2 * L) →
      ‖∑ i ∈ range n, ((1 / (Q * ((a : ℝ) + i + θ)) : ℝ) : ℂ) *
          eAdd (recipPhase (T * L) θ ((a : ℝ) + i))‖ ≤ Real.log T ^ (-A) / Q := by
  obtain ⟨T₀, hT₀⟩ := hVK A hA
  refine ⟨T₀, fun L T θ Q a n hT hL hLT hσL hQ hwin => ?_⟩
  have hLpos : 0 < L := by linarith
  -- every prefix run lies in the window
  have hprefix : ∀ m ≤ n, ∀ x ∈ runIcc a m, L ≤ x + θ ∧ x + θ ≤ 2 * L := by
    intro m hm x hx
    apply hwin
    refine ⟨hx.1, hx.2.trans ?_⟩
    have : (m : ℝ) ≤ n := by exact_mod_cast hm
    linarith
  -- the weights as a function of i (extended by the boundary value past n, still antitone)
  set w : ℕ → ℝ := fun i => 1 / (Q * ((a : ℝ) + i + θ)) with hw
  -- positivity of a + i + θ for i < n, and a + θ ≥ L
  by_cases hn : n = 0
  · subst hn; simp
    exact div_nonneg (Real.rpow_nonneg (Real.log_nonneg (by linarith)) _) hQ.le
  have haθ : L ≤ (a : ℝ) + θ := by
    have ha : (a : ℝ) ∈ runIcc a n := by
      refine ⟨le_refl _, ?_⟩
      have : (1 : ℝ) ≤ n := by exact_mod_cast Nat.one_le_iff_ne_zero.2 hn
      linarith
    exact (hwin _ ha).1
  have hpos : ∀ i : ℕ, 0 < (a : ℝ) + i + θ := by
    intro i; have : (0 : ℝ) ≤ i := Nat.cast_nonneg i; linarith
  have hw0 : ∀ i, 0 ≤ w i := fun i => by
    simp only [hw]; exact div_nonneg zero_le_one (mul_pos hQ (hpos i)).le
  have hwm : ∀ i, w (i + 1) ≤ w i := fun i => by
    simp only [hw]
    apply one_div_le_one_div_of_le (mul_pos hQ (hpos i))
    apply mul_le_mul_of_nonneg_left _ hQ.le
    push_cast; linarith
  have hB : ∀ m ≤ n, ‖∑ i ∈ range m, eAdd (recipPhase (T * L) θ ((a : ℝ) + i))‖ ≤
      L * Real.log T ^ (-A) := by
    intro m hm
    exact hT₀ L T θ a m hT hL hLT hσL (hprefix m hm)
  have habel := abel_antitone (z := fun i => eAdd (recipPhase (T * L) θ ((a : ℝ) + i)))
    (w := w) n hw0 hwm hB
  have hw0le : w 0 ≤ 1 / (Q * L) := by
    simp only [hw]
    apply one_div_le_one_div_of_le (mul_pos hQ hLpos)
    apply mul_le_mul_of_nonneg_left _ hQ.le
    simpa using haθ
  calc ‖∑ i ∈ range n, ((1 / (Q * ((a : ℝ) + i + θ)) : ℝ) : ℂ) *
          eAdd (recipPhase (T * L) θ ((a : ℝ) + i))‖
      = ‖∑ i ∈ range n, (w i : ℂ) * eAdd (recipPhase (T * L) θ ((a : ℝ) + i))‖ := rfl
    _ ≤ w 0 * (L * Real.log T ^ (-A)) := habel
    _ ≤ 1 / (Q * L) * (L * Real.log T ^ (-A)) := by
        apply mul_le_mul_of_nonneg_right hw0le
        exact mul_nonneg hLpos.le (Real.rpow_nonneg (Real.log_nonneg (by linarith)) _)
    _ = Real.log T ^ (-A) / Q := by field_simp

end GoldC.VK
