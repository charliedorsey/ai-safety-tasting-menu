import PaperB.Analytic.CharacterAdditiveTwist

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset

noncomputable def etaHarmonicReciprocalMode
    (q : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (Y : ℕ) (A : ℝ) : ℂ :=
  ∑ m ∈ Finset.Icc 1 Y,
    ((chi m) / (m : ℂ)) * eR (A / (m : ℝ))

noncomputable def etaHarmonicAdditiveMode
    (Y : ℕ) (A xi : ℝ) : ℂ :=
  ∑ m ∈ Finset.Icc 1 Y,
    (m : ℂ)⁻¹ * eR (A / (m : ℝ) + xi * (m : ℝ))

theorem etaHarmonicReciprocalMode_eq_additive_dft
    (q Y : ℕ) [NeZero (Nat.lcm 6 q)]
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (A : ℝ) :
    etaHarmonicReciprocalMode q chi Y A =
      ((Nat.lcm 6 q : ℕ) : ℂ)⁻¹ *
        ∑ h : ZMod (Nat.lcm 6 q),
          ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h *
            etaHarmonicAdditiveMode Y A
              ((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) := by
  unfold etaHarmonicReciprocalMode etaHarmonicAdditiveMode
  calc
    (∑ m ∈ Finset.Icc 1 Y,
      ((chi m) / (m : ℂ)) * eR (A / (m : ℝ)))
      =
    ∑ m ∈ Finset.Icc 1 Y,
      ((((Nat.lcm 6 q : ℕ) : ℂ)⁻¹ *
        ∑ h : ZMod (Nat.lcm 6 q),
          eR (((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) * (m : ℝ)) *
            ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h) *
        (m : ℂ)⁻¹ *
        eR (A / (m : ℝ))) := by
        apply Finset.sum_congr rfl
        intro m hm
        rw [dirichletCharacter_additive_eR_inversion]
        ring
    _ =
      ((Nat.lcm 6 q : ℕ) : ℂ)⁻¹ *
        ∑ h : ZMod (Nat.lcm 6 q),
          ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h *
            (∑ m ∈ Finset.Icc 1 Y,
              (m : ℂ)⁻¹ *
                eR (A / (m : ℝ) +
                  ((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) *
                    (m : ℝ))) := by
        classical
        simp_rw [eR_add]
        simp_rw [Finset.mul_sum, Finset.sum_mul]
        rw [Finset.sum_comm]
        apply Finset.sum_congr rfl
        intro h hh
        apply Finset.sum_congr rfl
        intro m hm
        ring

end PaperB.Analytic
