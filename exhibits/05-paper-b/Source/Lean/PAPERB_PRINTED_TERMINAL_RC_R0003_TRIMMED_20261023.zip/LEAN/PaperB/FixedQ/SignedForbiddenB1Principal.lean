import PaperB.ExactAccounting.H1FloorFamilyBridge
import PaperB.Analytic.PetermannEtaR0002

open scoped BigOperators

namespace PaperB.FixedQ

open PaperB.Analytic

noncomputable def manuscriptS1Principal
    (q r H : ℕ) [NeZero (fixedQPeriod q)] : ℝ :=
  freeHighBaseline q *
    principalBoundaryAverage (fixedQPeriod q)
      (freeReducedFixedQLowWeight q r) *
    logarithmicEulerResidue (etaCoeff q) *
    Real.log ((H - 1 : ℕ) : ℝ)

theorem manuscriptS1Kernel_sub_principal_sublog_of_progression
    (q : ℕ) (hq : 0 < q) [NeZero (fixedQPeriod q)] :
    ∀ ε : ℝ, 0 < ε →
      ∃ H0 : ℕ, ∀ r b H n : ℕ,
        q.Coprime r →
        2 ≤ H →
        H0 ≤ H →
        2 * H = positiveGapRepresentative q r b + n * q →
        |PaperB.Closure.manuscriptS1Kernel q r (2 * H) -
            manuscriptS1Principal q r H| ≤
          ε * Real.log ((2 * H : ℕ) : ℝ) := by
  intro ε hε
  let δ : ℝ := ε / 4
  have hδ : 0 < δ := by
    dsimp [δ]
    positivity
  have heta := petermannEtaR0002 q hq
  obtain ⟨T0, hSaw⟩ :=
    supportedSawtoothSum_eta_sublog_of_r0002 q hq heta δ hδ
  let Cden : ℝ :=
    oneDimensionalDensityCoeffBound q * (1 + 4 * etaRankinBound)
  let Cbnd : ℝ := etaBoundaryRemainderBound q
  let Ctail : ℝ := 16 * etaRankinBound
  let Ctot : ℝ := Cden + Cbnd + Ctail
  have hEta : 0 ≤ etaRankinBound := by
    unfold etaRankinBound
    exact (Real.exp_pos _).le
  have hDB : 0 ≤ oneDimensionalDensityCoeffBound q := by
    unfold oneDimensionalDensityCoeffBound
    positivity
  have hCden0 : 0 ≤ Cden := by
    dsimp [Cden]
    exact mul_nonneg hDB (by positivity)
  have hCbnd0 : 0 ≤ Cbnd := by
    dsimp [Cbnd, etaBoundaryRemainderBound]
    exact mul_nonneg (mul_nonneg (by positivity) (by positivity))
      (add_nonneg (mul_nonneg (by positivity) hEta)
        (mul_nonneg (by positivity) hEta))
  have hCtail0 : 0 ≤ Ctail := by
    dsimp [Ctail]
    exact mul_nonneg (by norm_num) hEta
  have hCtot0 : 0 ≤ Ctot := by
    dsimp [Ctot]
    positivity
  obtain ⟨Nconst, hNconst⟩ :=
    fixedConstant_le_epsilon_log_eventually Ctot δ hδ
  obtain ⟨NT, hNT⟩ := exists_nat_ge T0
  let H0 : ℕ :=
    max 3 (max (Nconst + 1)
      (max (NT + 1) (2 * fixedQPeriod q + 2)))
  refine ⟨H0, ?_⟩
  intro r b H n hr hH hH0 hprog
  have hHm1 : 1 ≤ H - 1 := by omega
  have hHm1pos : 0 < H - 1 := by omega
  have hNconstH : Nconst ≤ H - 1 := by
    dsimp [H0] at hH0
    omega
  have hTH : T0 ≤ ((H - 1 : ℕ) : ℝ) := by
    have hNT' : T0 ≤ (NT : ℝ) := hNT
    have hNTH : NT ≤ H - 1 := by
      dsimp [H0] at hH0
      omega
    exact hNT'.trans (by exact_mod_cast hNTH)
  have h2L : (2 * fixedQPeriod q : ℝ) ≤ ((H - 1 : ℕ) : ℝ) := by
    have : 2 * fixedQPeriod q ≤ H - 1 := by
      dsimp [H0] at hH0
      omega
    exact_mod_cast this
  have hlogmono :
      Real.log (((H - 1 : ℕ) : ℝ)) ≤
        Real.log (((2 * H : ℕ) : ℝ)) := by
    apply Real.log_le_log
    · exact_mod_cast hHm1pos
    · exact_mod_cast (show H - 1 ≤ 2 * H by omega)
  have hlog0 :
      0 ≤ Real.log (((H - 1 : ℕ) : ℝ)) :=
    Real.log_nonneg (by exact_mod_cast hHm1)
  have hD :=
    abs_oneDimensionalDensityCoeff_le
      (q := q) (a := r) (b := b) (H := H) (n := n)
      hq hprog
  have hE0 := etaReciprocalPrefix_nonneg q (H - 1)
  have hE := etaReciprocalPrefix_le q (H - 1)
  have hDensity :
      |freeHighBaseline q *
          oneDimensionalDensityCoeff q r H *
          etaReciprocalPrefix q (H - 1)| ≤ Cden := by
    have hf : |freeHighBaseline q| ≤ 1 := by
      unfold freeHighBaseline
      exact abs_cStarReal_le_one q 0
    rw [abs_mul, abs_mul, abs_of_nonneg hE0]
    calc
      |freeHighBaseline q| *
          |oneDimensionalDensityCoeff q r H| *
          etaReciprocalPrefix q (H - 1)
        ≤ 1 * oneDimensionalDensityCoeffBound q *
            (1 + 4 * etaRankinBound) := by
          gcongr
      _ = Cden := by
        dsimp [Cden]
        ring
  have hBoundary :=
    abs_etaBoundary_remainder_le q r H hq hr hH
  have hSawRaw :=
    hSaw (freeReducedFixedQLowWeight q r)
      (fun z hz => abs_freeReducedFixedQLowWeight_le_six q r z)
      (((H - 1 : ℕ) : ℝ)) (H - 1)
      hTH h2L hHm1 (le_refl _)
  have hf : |freeHighBaseline q| ≤ 1 := by
    unfold freeHighBaseline
    exact abs_cStarReal_le_one q 0
  have hSawScaled :
      |freeHighBaseline q *
          supportedSawtoothSum
            (fixedQPeriod q)
            (freeReducedFixedQLowWeight q r)
            (etaCoeff q)
            (((H - 1 : ℕ) : ℝ)) (H - 1)| ≤
        δ * Real.log (((H - 1 : ℕ) : ℝ)) := by
    rw [abs_mul]
    calc
      |freeHighBaseline q| *
          |supportedSawtoothSum
            (fixedQPeriod q)
            (freeReducedFixedQLowWeight q r)
            (etaCoeff q)
            (((H - 1 : ℕ) : ℝ)) (H - 1)|
        ≤ 1 * (δ * Real.log (((H - 1 : ℕ) : ℝ))) := by
          exact mul_le_mul hf hSawRaw (abs_nonneg _) (by norm_num)
      _ = _ := one_mul _
  let N : ℝ := admissibleInteriorCount q r (2 * H)
  let Et := etaReciprocalTail q (H - 1)
  have hN0 : 0 ≤ N := by
    dsimp [N]
    positivity
  have hEtail0 : 0 ≤ Et := by
    dsimp [Et]
    exact etaReciprocalTail_nonneg q (H - 1)
  have hNnat := admissibleInteriorCount_le_height q r (2 * H)
  have hNXnat :
      admissibleInteriorCount q r (2 * H) ≤ 4 * (H - 1) := by
    calc
      admissibleInteriorCount q r (2 * H) ≤ 2 * H := hNnat
      _ ≤ 4 * (H - 1) := by omega
  have hNX : N ≤ 4 * (((H - 1 : ℕ) : ℝ)) := by
    dsimp [N]
    exact_mod_cast hNXnat
  have hEt := etaReciprocalTail_manuscript q H hH
  have hEt0raw : 0 ≤ etaReciprocalTail q (H - 1) :=
    etaReciprocalTail_nonneg q (H - 1)
  have hXEt :
      (((H - 1 : ℕ) : ℝ)) * Et ≤ 4 * etaRankinBound := by
    dsimp [Et]
    simpa [abs_of_nonneg hEt0raw] using hEt
  have hNE : N * Et ≤ Ctail := by
    calc
      N * Et ≤ (4 * (((H - 1 : ℕ) : ℝ))) * Et :=
        mul_le_mul_of_nonneg_right hNX hEtail0
      _ = 4 * ((((H - 1 : ℕ) : ℝ)) * Et) := by ring
      _ ≤ 4 * (4 * etaRankinBound) :=
        mul_le_mul_of_nonneg_left hXEt (by norm_num)
      _ = Ctail := by
        dsimp [Ctail]
        ring
  have hTail :
      |freeHighBaseline q * N * Et| ≤ Ctail := by
    rw [abs_mul, abs_mul, abs_of_nonneg hN0, abs_of_nonneg hEtail0]
    calc
      |freeHighBaseline q| * N * Et ≤ 1 * N * Et := by
        exact mul_le_mul_of_nonneg_right
          (mul_le_mul_of_nonneg_right hf hN0) hEtail0
      _ = N * Et := by ring
      _ ≤ Ctail := hNE
  have hConst :
      Ctot ≤ δ * Real.log (((H - 1 : ℕ) : ℝ)) :=
    hNconst (H - 1) hNconstH
  rw [PaperB.ExactAccounting.manuscriptS1Kernel_eq_manuscriptS1FloorKernel
    hq hr hH]
  unfold manuscriptS1FloorKernel manuscriptS1Principal
  dsimp
  let D := freeHighBaseline q *
      oneDimensionalDensityCoeff q r H *
      etaReciprocalPrefix q (H - 1)
  let Bnd := freeHighBaseline q *
      supportedBoundarySum
        (fixedQPeriod q)
        (freeReducedFixedQLowWeight q r)
        (etaCoeff q) (H - 1)
  let P := freeHighBaseline q *
      principalBoundaryAverage (fixedQPeriod q)
        (freeReducedFixedQLowWeight q r) *
      logarithmicEulerResidue (etaCoeff q) *
      Real.log ((H - 1 : ℕ) : ℝ)
  let Saw := freeHighBaseline q *
      supportedSawtoothSum
        (fixedQPeriod q)
        (freeReducedFixedQLowWeight q r)
        (etaCoeff q) (((H - 1 : ℕ) : ℝ)) (H - 1)
  let Tail := freeHighBaseline q * N * Et
  have htarget :
      freeHighBaseline q *
          (oneDimensionalDensityCoeff q r H * etaReciprocalPrefix q (H - 1) +
            supportedBoundarySum (fixedQPeriod q)
              (freeReducedFixedQLowWeight q r) (etaCoeff q) (H - 1) -
            supportedSawtoothSum (fixedQPeriod q)
              (freeReducedFixedQLowWeight q r) (etaCoeff q)
              (((H - 1 : ℕ) : ℝ)) (H - 1) -
            (admissibleInteriorCount q r (2 * H) : ℝ) *
              etaReciprocalTail q (H - 1)) -
        freeHighBaseline q *
          principalBoundaryAverage (fixedQPeriod q)
            (freeReducedFixedQLowWeight q r) *
          logarithmicEulerResidue (etaCoeff q) *
          Real.log ((H - 1 : ℕ) : ℝ) =
        D + (Bnd - P) - Saw - Tail := by
    dsimp [D, Bnd, P, Saw, Tail, N, Et]
    ring
  rw [htarget]
  calc
    |D + (Bnd - P) - Saw - Tail|
      ≤ |D| + |Bnd - P| + |Saw| + |Tail| := by
        calc
          |_|
            ≤ |D + (Bnd - P) - Saw| + |Tail| := abs_sub _ _
          _ ≤ (|D + (Bnd - P)| + |Saw|) + |Tail| := by
            gcongr
            exact abs_sub _ _
          _ ≤ (|D| + |Bnd - P| + |Saw|) + |Tail| := by
            gcongr
            exact abs_add_le _ _
          _ = _ := by ring
    _ ≤ Cden + Cbnd +
          δ * Real.log (((H - 1 : ℕ) : ℝ)) + Ctail := by
        exact add_le_add
          (add_le_add
            (add_le_add hDensity (by simpa [Bnd, P] using hBoundary))
            (by simpa [Saw] using hSawScaled))
          (by simpa [Tail, N, Et] using hTail)
    _ = Ctot + δ * Real.log (((H - 1 : ℕ) : ℝ)) := by
        dsimp [Ctot]
        ring
    _ ≤ (δ * Real.log (((H - 1 : ℕ) : ℝ))) +
          δ * Real.log (((H - 1 : ℕ) : ℝ)) :=
        add_le_add hConst le_rfl
    _ = (ε / 2) * Real.log (((H - 1 : ℕ) : ℝ)) := by
        dsimp [δ]
        ring
    _ ≤ ε * Real.log (((2 * H : ℕ) : ℝ)) := by
        have hhalf : ε / 2 ≤ ε := by linarith
        calc
          (ε / 2) * Real.log (((H - 1 : ℕ) : ℝ))
            ≤ ε * Real.log (((H - 1 : ℕ) : ℝ)) :=
              mul_le_mul_of_nonneg_right hhalf hlog0
          _ ≤ ε * Real.log (((2 * H : ℕ) : ℝ)) :=
              mul_le_mul_of_nonneg_left hlogmono (le_of_lt hε)

#print axioms manuscriptS1Kernel_sub_principal_sublog_of_progression

end PaperB.FixedQ
