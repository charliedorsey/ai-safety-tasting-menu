import PaperB.FixedQ.H2BooleanCoreSourceSplit

open scoped BigOperators

namespace PaperB.FixedQ

/--
Ownership-neutral Route-B normalization adapter.
Once Riven supplies a discrepancy D with
ordinaryBooleanInteriorDiscrepancy = 2^card * D on active support,
the weighted ordinary Boolean core has exactly the source-tilt Cauchy shape.
-/
theorem abs_ordinaryBooleanCoreTerm_eq_weighted_of_interior_normalization
    {q A H : ℕ} {S : Finset ℕ}
    (hAct : S ∈ activeOrdinaryTwoDimensionalSet q H)
    (D : Finset ℕ → ℝ)
    (hD :
      ordinaryBooleanInteriorDiscrepancy
          (fixedQLowWeight q A H) H S =
        (2 : ℝ) ^ S.card * D S) :
    |ordinaryBooleanCoreTerm q A H S| =
      finiteOmegaWeightReal S * (2 : ℝ) ^ S.card * |D S| := by
  rw [ordinaryBooleanCoreTerm, Set.indicator_of_mem hAct]
  rw [hD, abs_mul, abs_mul]
  have hw0 : 0 ≤ finiteOmegaWeightReal S :=
    finiteOmegaWeightReal_nonneg_of_active hAct.2
  rw [abs_of_nonneg hw0]
  have h20 : 0 ≤ (2 : ℝ) ^ S.card := pow_nonneg (by norm_num) _
  rw [abs_of_nonneg h20]
  ring

#print axioms abs_ordinaryBooleanCoreTerm_eq_weighted_of_interior_normalization

end PaperB.FixedQ
