import Mathlib.Data.ZMod.Units
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic

/-!
# Oriel Upper — CRT reindexing of coprime residues

For coprime `P, m` and `e` coprime to `Q = P m`:
`∑_{c < Q, (c,Q)=1} Φ(e c mod P, e c mod m) = ∑_{v ∈ (ZMod P)ˣ} ∑_{t ∈ (ZMod m)ˣ} Φ v t`.
-/

open Finset

namespace OrielUpper

theorem oriel_crt_units_sum {P m : ℕ} [NeZero P] [NeZero m] (hcop : Nat.Coprime P m)
    {e : ℕ} (he : Nat.Coprime e (P * m)) (Φ : ZMod P → ZMod m → ℝ) :
    ∑ c ∈ (range (P * m)).filter (fun c => Nat.Coprime c (P * m)),
        Φ ((e * c : ℕ) : ZMod P) ((e * c : ℕ) : ZMod m) =
      ∑ v : (ZMod P)ˣ, ∑ t : (ZMod m)ˣ, Φ v t := by
  haveI : NeZero (P * m) := ⟨Nat.mul_ne_zero (NeZero.ne P) (NeZero.ne m)⟩
  set Q := P * m
  set CRT := ZMod.chineseRemainder hcop
  have hcrt : ∀ k : ℕ, CRT (k : ZMod Q) = ((k : ZMod P), (k : ZMod m)) := by
    intro k; rw [map_natCast]; rfl
  -- step 1: residues ↔ units of ZMod Q
  have step1 : ∑ c ∈ (range Q).filter (fun c => Nat.Coprime c Q),
      Φ ((e * c : ℕ) : ZMod P) ((e * c : ℕ) : ZMod m) =
      ∑ x : (ZMod Q)ˣ, Φ ((e * (x : ZMod Q).val : ℕ) : ZMod P)
        ((e * (x : ZMod Q).val : ℕ) : ZMod m) := by
    apply Finset.sum_nbij' (fun c => if h : Nat.Coprime c Q then ZMod.unitOfCoprime c h else 1)
      (fun x => (x : ZMod Q).val)
    · intro c _; exact mem_univ _
    · intro x _
      rw [mem_filter, mem_range]
      refine ⟨ZMod.val_lt _, ?_⟩
      rw [← ZMod.isUnit_iff_coprime, ZMod.natCast_zmod_val]
      exact x.isUnit
    · intro c hc
      rw [mem_filter, mem_range] at hc
      simp only [dif_pos hc.2, ZMod.coe_unitOfCoprime, ZMod.val_natCast]
      exact Nat.mod_eq_of_lt hc.1
    · intro x _
      have hx : Nat.Coprime (x : ZMod Q).val Q := by
        rw [← ZMod.isUnit_iff_coprime, ZMod.natCast_zmod_val]; exact x.isUnit
      simp only [dif_pos hx]
      apply Units.ext
      rw [ZMod.coe_unitOfCoprime, ZMod.natCast_zmod_val]
    · intro c hc
      rw [mem_filter, mem_range] at hc
      simp only [dif_pos hc.2, ZMod.coe_unitOfCoprime, ZMod.val_natCast,
        Nat.mod_eq_of_lt hc.1]
  -- step 2: through the CRT components
  have hcomp : ∀ x : (ZMod Q)ˣ,
      Φ ((e * (x : ZMod Q).val : ℕ) : ZMod P) ((e * (x : ZMod Q).val : ℕ) : ZMod m) =
      Φ (CRT ((ZMod.unitOfCoprime e he : ZMod Q) * x)).1
        (CRT ((ZMod.unitOfCoprime e he : ZMod Q) * x)).2 := by
    intro x
    have : ((ZMod.unitOfCoprime e he : ZMod Q) * (x : ZMod Q)) =
        ((e * (x : ZMod Q).val : ℕ) : ZMod Q) := by
      rw [ZMod.coe_unitOfCoprime]; push_cast; rw [ZMod.natCast_zmod_val]
    rw [this, hcrt]
  rw [step1, sum_congr rfl (fun x _ => hcomp x)]
  -- step 3: remove the unit factor
  have step3 : ∑ x : (ZMod Q)ˣ, Φ (CRT ((ZMod.unitOfCoprime e he : ZMod Q) * x)).1
        (CRT ((ZMod.unitOfCoprime e he : ZMod Q) * x)).2 =
      ∑ x : (ZMod Q)ˣ, Φ (CRT (x : ZMod Q)).1 (CRT (x : ZMod Q)).2 := by
    apply Fintype.sum_equiv (Equiv.mulLeft (ZMod.unitOfCoprime e he))
    intro x; simp [Units.val_mul]
  rw [step3]
  -- step 4: units of the product
  let E : (ZMod Q)ˣ ≃ (ZMod P)ˣ × (ZMod m)ˣ :=
    ((Units.mapEquiv CRT.toMulEquiv).trans MulEquiv.prodUnits).toEquiv
  rw [← Fintype.sum_prod_type']
  apply Fintype.sum_equiv E
  intro x
  rfl

end OrielUpper
