import GeneralKloosterman.Local

/-!
# Prime-power Kloosterman sums: local arithmetic and square-root cancellation

All statements are proved directly in `ZMod (p ^ k)` — **no CRT is used**: `p ^ k` is local
arithmetic. The Kloosterman sum is `kSum N a b = ∑_{x ∈ (ZMod N)ˣ} ψ(b x + a x⁻¹)`, literally
the toolkit's `kloostermanUnitSum` (bridged by `rfl` in `GeneralKloosterman.Bridge`).

* `kSum_eq_sum_stationary` — first-order stationary phase: for `h² = 0`,
  `S = ∑_{x : h (b x - a x⁻¹) = 0} ψ(b x + a x⁻¹)`.
* `kSum_eq_zero_of_dvd_left/right` — **gcd-degenerate vanishing** (`k ≥ 2`, exactly one coefficient
  divisible by `p`): `S = 0`.
* `kSum_descent` — **descent** `S(d a', d b'; d M) = (φ(dM)/φ(M)) · S(a', b'; M)`.
* `sq_eq_sq_split`, `card_sqClass_le` — square roots modulo `p ^ m`: at most two classes modulo
  `p ^ (m - e)` (`e = 0` for odd `p`, `e = 1` for `p = 2`).
* `norm_kSum_unit_le_count` — unit coefficients, `k ≥ 2`: `‖S‖ ≤ 2 p^(k - (m - e))`, `m = ⌊k/2⌋`.
* `norm_kSum_unit_odd_le` — **odd `p`, unit coefficients, `k ≥ 2`: `‖S(a,b;p^k)‖ ≤ 2 √(p^k)`**
  (even `k` from stationary phase, odd `k` adding Weyl differencing of the residual quadratic sum).
-/

open Finset ComplexConjugate

namespace GenKloosterman

local notation "ψ" => ZMod.stdAddChar

/-- The Kloosterman sum `S(a, b; N) = ∑_{x ∈ (ZMod N)ˣ} ψ(b x + a x⁻¹)`. -/
noncomputable def kSum (N : ℕ) [NeZero N] (a b : ZMod N) : ℂ :=
  ∑ x : (ZMod N)ˣ, ψ (b * (x : ZMod N) + a * ((x⁻¹ : (ZMod N)ˣ) : ZMod N))

section General
variable {N : ℕ} [NeZero N]

theorem norm_kSum_le_card (a b : ZMod N) : ‖kSum N a b‖ ≤ Nat.totient N := by
  unfold kSum
  refine (norm_sum_le _ _).trans ?_
  simp [ZMod.card_units_eq_totient]

/-- Restricted first-order stationary phase (weight form). -/
theorem sum_weight_stationary (h : ZMod N) (hh : h ^ 2 = 0) (a b : ZMod N)
    (w : (ZMod N)ˣ → ℂ)
    (hw : ∀ t x, w (x * shiftUnit h (by rw [pow_succ, hh, zero_mul]) t) = w x) :
    ∑ x : (ZMod N)ˣ, w x * ψ (b * (x : ZMod N) + a * ((x⁻¹ : (ZMod N)ˣ) : ZMod N)) =
      ∑ x : (ZMod N)ˣ, if h * (b * (x : ZMod N) - a * ((x⁻¹ : (ZMod N)ˣ) : ZMod N)) = 0 then
        w x * ψ (b * (x : ZMod N) + a * ((x⁻¹ : (ZMod N)ˣ) : ZMod N)) else 0 := by
  have hN : (N : ℂ) ≠ 0 := by exact_mod_cast NeZero.ne N
  have key := averaging_identity h (by rw [pow_succ, hh, zero_mul]) a b w hw
  simp_rw [hh, zero_mul, quadSum_zero_right] at key
  apply mul_left_cancel₀ hN
  rw [key, mul_sum]
  refine sum_congr rfl fun x _ => ?_
  split_ifs <;> ring

/-- **First-order stationary phase.** -/
theorem kSum_eq_sum_stationary (h : ZMod N) (hh : h ^ 2 = 0) (a b : ZMod N) :
    kSum N a b = ∑ x : (ZMod N)ˣ,
      if h * (b * (x : ZMod N) - a * ((x⁻¹ : (ZMod N)ˣ) : ZMod N)) = 0 then
        ψ (b * (x : ZMod N) + a * ((x⁻¹ : (ZMod N)ˣ) : ZMod N)) else 0 := by
  have := sum_weight_stationary h hh a b (fun _ => 1) (fun _ _ => rfl)
  simpa [kSum] using this

end General

/-! ## Valuation bookkeeping in `ZMod (p ^ k)` -/

section Val
variable {p : ℕ} [hp : Fact p.Prime]

instance neZero_pow (k : ℕ) : NeZero (p ^ k) := ⟨pow_ne_zero k hp.out.ne_zero⟩

/-- `p ^ j · z = 0` in `ZMod (p ^ k)` iff `p ^ (k - j) ∣ z.val` (for `j ≤ k`). -/
theorem pow_mul_eq_zero_iff {k j : ℕ} (hj : j ≤ k) (z : ZMod (p ^ k)) :
    (p : ZMod (p ^ k)) ^ j * z = 0 ↔ p ^ (k - j) ∣ z.val := by
  have e : (p : ZMod (p ^ k)) ^ j * z = ((p ^ j * z.val : ℕ) : ZMod (p ^ k)) := by
    push_cast; rw [ZMod.natCast_zmod_val]
  rw [e, ZMod.natCast_eq_zero_iff]
  generalize z.val = v
  have hk : p ^ k = p ^ j * p ^ (k - j) := by rw [← pow_add, Nat.add_sub_cancel' hj]
  rw [hk]
  exact Nat.mul_dvd_mul_iff_left (pow_pos hp.out.pos j)

omit hp in
theorem pow_eq_zero_of_le {k j : ℕ} (hj : k ≤ j) : (p : ZMod (p ^ k)) ^ j = 0 := by
  have : (p : ZMod (p ^ k)) ^ j = ((p ^ j : ℕ) : ZMod (p ^ k)) := by push_cast; rfl
  rw [this, ZMod.natCast_eq_zero_iff]
  exact pow_dvd_pow p hj

/-- Reduction `ZMod (p ^ k) → ZMod (p ^ n)` for `n ≤ k`. -/
abbrev red {k : ℕ} (n : ℕ) (hn : n ≤ k) : ZMod (p ^ k) →+* ZMod (p ^ n) :=
  ZMod.castHom (pow_dvd_pow p hn) (ZMod (p ^ n))

theorem red_eq_zero_iff {k n : ℕ} (hn : n ≤ k) (z : ZMod (p ^ k)) :
    red n hn z = 0 ↔ p ^ n ∣ z.val := by
  rw [ZMod.castHom_apply, ZMod.cast_eq_val, ZMod.natCast_eq_zero_iff]

theorem val_red {k n : ℕ} (hn : n ≤ k) (z : ZMod (p ^ k)) :
    (red n hn z).val = z.val % p ^ n := by
  rw [ZMod.castHom_apply, ZMod.cast_eq_val, ZMod.val_natCast]

theorem isUnit_iff_not_dvd {k : ℕ} (hk : 1 ≤ k) (z : ZMod (p ^ k)) :
    IsUnit z ↔ ¬ p ∣ z.val := by
  rw [← ZMod.natCast_zmod_val z, ZMod.isUnit_iff_coprime, ZMod.val_natCast,
    Nat.mod_eq_of_lt (ZMod.val_lt z)]
  constructor
  · intro hc hdvd
    have := Nat.Coprime.coprime_dvd_right (dvd_pow_self p (by omega)) hc
    exact hp.out.one_lt.ne' (Nat.Coprime.eq_one_of_dvd (Nat.coprime_comm.mp this) hdvd)
  · intro hnd
    exact Nat.Coprime.pow_right k ((Nat.coprime_comm).mp ((Nat.Prime.coprime_iff_not_dvd hp.out).2 hnd))

theorem totient_pow_succ_div (k : ℕ) (hk : 1 ≤ k) :
    Nat.totient (p * p ^ k) / Nat.totient (p ^ k) = p := by
  rw [← pow_succ', Nat.totient_prime_pow_succ hp.out, Nat.totient_prime_pow hp.out (by omega)]
  have h1 : p ^ k = p * p ^ (k - 1) := by rw [← pow_succ']; congr 1; omega
  rw [h1, mul_assoc]
  exact Nat.mul_div_cancel _ (Nat.mul_pos (pow_pos hp.out.pos _) (Nat.sub_pos_of_lt hp.out.one_lt))

end Val

/-! ## gcd-degenerate vanishing -/

section Degenerate
variable {p : ℕ} [hp : Fact p.Prime]

/-- Exactly one coefficient divisible by `p`, `k ≥ 2`: the sum vanishes (left form). -/
theorem kSum_eq_zero_of_dvd_left {k : ℕ} (hk : 2 ≤ k) (a b : ZMod (p ^ k))
    (ha : p ∣ a.val) (hb : IsUnit b) : kSum (p ^ k) a b = 0 := by
  have hh : ((p : ZMod (p ^ k)) ^ (k - 1)) ^ 2 = 0 := by
    rw [← pow_mul]; exact pow_eq_zero_of_le (by omega)
  rw [kSum_eq_sum_stationary _ hh]
  refine sum_eq_zero fun x _ => ?_
  rw [ite_eq_right_iff.mpr]
  intro h0
  have hpa : (p : ZMod (p ^ k)) ^ (k - 1) * a = 0 :=
    (pow_mul_eq_zero_iff (by omega) a).2 (by rwa [show k - (k - 1) = 1 by omega, pow_one])
  have h1 : (p : ZMod (p ^ k)) ^ (k - 1) * (b * x) = 0 := by
    have : (p : ZMod (p ^ k)) ^ (k - 1) * (b * x) =
        (p : ZMod (p ^ k)) ^ (k - 1) * (b * x - a * ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k))) +
          ((p : ZMod (p ^ k)) ^ (k - 1) * a) * ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k)) := by ring
    rw [this, h0, hpa, zero_mul, add_zero]
  rw [pow_mul_eq_zero_iff (by omega), show k - (k - 1) = 1 by omega, pow_one] at h1
  exact ((isUnit_iff_not_dvd (by omega) _).1 (hb.mul x.isUnit) h1).elim

/-- Exactly one coefficient divisible by `p`, `k ≥ 2`: the sum vanishes (right form). -/
theorem kSum_eq_zero_of_dvd_right {k : ℕ} (hk : 2 ≤ k) (a b : ZMod (p ^ k))
    (ha : IsUnit a) (hb : p ∣ b.val) : kSum (p ^ k) a b = 0 := by
  have hh : ((p : ZMod (p ^ k)) ^ (k - 1)) ^ 2 = 0 := by
    rw [← pow_mul]; exact pow_eq_zero_of_le (by omega)
  rw [kSum_eq_sum_stationary _ hh]
  refine sum_eq_zero fun x _ => ?_
  rw [ite_eq_right_iff.mpr]
  intro h0
  have hpb : (p : ZMod (p ^ k)) ^ (k - 1) * b = 0 :=
    (pow_mul_eq_zero_iff (by omega) b).2 (by rwa [show k - (k - 1) = 1 by omega, pow_one])
  have h1 : (p : ZMod (p ^ k)) ^ (k - 1) * (a * ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k))) = 0 := by
    have : (p : ZMod (p ^ k)) ^ (k - 1) * (a * ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k))) =
        ((p : ZMod (p ^ k)) ^ (k - 1) * b) * x -
          (p : ZMod (p ^ k)) ^ (k - 1) * (b * x - a * ((x⁻¹ : (ZMod (p ^ k))ˣ) : ZMod (p ^ k))) := by
      ring
    rw [this, h0, hpb, zero_mul, sub_zero]
  rw [pow_mul_eq_zero_iff (by omega), show k - (k - 1) = 1 by omega, pow_one] at h1
  exact ((isUnit_iff_not_dvd (by omega) _).1 (ha.mul (x⁻¹).isUnit) h1).elim

end Degenerate

/-! ## Descent `S(d a', d b'; d M) = (φ(dM)/φ(M)) S(a', b'; M)` -/

section Descent

theorem stdAddChar_natMul {d M : ℕ} [NeZero M] [NeZero (d * M)] (w : ZMod (d * M)) :
    ψ ((d : ZMod (d * M)) * w) =
      ψ (ZMod.castHom (Dvd.intro_left d rfl) (ZMod M) w) := by
  have hd : d ≠ 0 := fun h => NeZero.ne (d * M) (by rw [h, zero_mul])
  rw [ZMod.castHom_apply, ZMod.cast_eq_val]
  rw [show ((d : ZMod (d * M)) * w) = ((((d * w.val : ℕ) : ℤ)) : ZMod (d * M)) by
    push_cast; rw [ZMod.natCast_zmod_val]]
  rw [show ((w.val : ℕ) : ZMod M) = (((w.val : ℕ) : ℤ) : ZMod M) by push_cast; rfl]
  rw [ZMod.stdAddChar_coe, ZMod.stdAddChar_coe]
  congr 1
  have hd' : (d : ℂ) ≠ 0 := by exact_mod_cast hd
  have hM' : (M : ℂ) ≠ 0 := by exact_mod_cast NeZero.ne M
  push_cast
  field_simp

/-- Summing a function of the reduced unit over `(ZMod N)ˣ`. -/
theorem sum_comp_unitsMap {N M : ℕ} [NeZero N] [NeZero M] (h : M ∣ N) (F : (ZMod M)ˣ → ℂ) :
    ∑ x : (ZMod N)ˣ, F (ZMod.unitsMap h x) =
      ((Nat.totient N / Nat.totient M : ℕ) : ℂ) * ∑ y : (ZMod M)ˣ, F y := by
  classical
  let f := ZMod.unitsMap (m := N) h
  have hsurj := ZMod.unitsMap_surjective (m := N) h
  have hall : ∀ y : (ZMod M)ˣ, #{x : (ZMod N)ˣ | f x = y} = #{x : (ZMod N)ˣ | f x = 1} :=
    fun y => MonoidHom.card_fiber_eq_of_mem_range f (hsurj y) (hsurj 1)
  have htot : ∑ y : (ZMod M)ˣ, #{x : (ZMod N)ˣ | f x = y} = Nat.totient N := by
    rw [← card_eq_sum_card_fiberwise (fun x _ => mem_univ (f x))]
    simp [ZMod.card_units_eq_totient]
  simp_rw [hall] at htot
  rw [sum_const, card_univ, ZMod.card_units_eq_totient, smul_eq_mul] at htot
  have hM : 0 < Nat.totient M := Nat.totient_pos.2 (Nat.pos_of_ne_zero (NeZero.ne M))
  have hc : Nat.totient N / Nat.totient M = #{x : (ZMod N)ˣ | f x = 1} := by
    rw [← htot, Nat.mul_div_cancel_left _ hM]
  rw [hc, ← Finset.sum_fiberwise univ f (fun x => F (f x)), mul_sum]
  refine sum_congr rfl fun y _ => ?_
  rw [sum_congr rfl (g := fun _ => F y) (fun x hx => by rw [(mem_filter.1 hx).2]), sum_const,
    nsmul_eq_mul, hall y]

/-- **Descent.** -/
theorem kSum_descent {d M : ℕ} [NeZero M] [NeZero (d * M)] (a' b' : ZMod (d * M)) :
    kSum (d * M) ((d : ZMod (d * M)) * a') ((d : ZMod (d * M)) * b') =
      ((Nat.totient (d * M) / Nat.totient M : ℕ) : ℂ) *
        kSum M (ZMod.castHom (Dvd.intro_left d rfl) (ZMod M) a')
          (ZMod.castHom (Dvd.intro_left d rfl) (ZMod M) b') := by
  unfold kSum
  rw [← sum_comp_unitsMap (Dvd.intro_left d rfl)]
  refine sum_congr rfl fun x _ => ?_
  have e1 : (d : ZMod (d * M)) * b' * (x : ZMod (d * M)) +
      (d : ZMod (d * M)) * a' * ((x⁻¹ : (ZMod (d * M))ˣ) : ZMod (d * M)) =
      (d : ZMod (d * M)) * (b' * x + a' * ((x⁻¹ : (ZMod (d * M))ˣ) : ZMod (d * M))) := by ring
  have hx1 : ((ZMod.unitsMap (Dvd.intro_left d rfl) x : (ZMod M)ˣ) : ZMod M) =
      ZMod.castHom (Dvd.intro_left d rfl) (ZMod M) (x : ZMod (d * M)) := rfl
  have hx2 : (((ZMod.unitsMap (Dvd.intro_left d rfl) x)⁻¹ : (ZMod M)ˣ) : ZMod M) =
      ZMod.castHom (Dvd.intro_left d rfl) (ZMod M) ((x⁻¹ : (ZMod (d * M))ˣ) : ZMod (d * M)) := by
    rw [← map_inv]; rfl
  rw [e1, stdAddChar_natMul, map_add, map_mul, map_mul, hx1, hx2]

end Descent

end GenKloosterman
