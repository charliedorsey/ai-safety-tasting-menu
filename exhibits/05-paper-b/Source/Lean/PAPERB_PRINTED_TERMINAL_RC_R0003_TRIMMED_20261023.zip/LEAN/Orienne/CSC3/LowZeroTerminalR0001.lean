import Orienne.CSC3.PhysicalLongBridgeQ0001

open scoped BigOperators Classical
namespace Thistle.LOW

/-- The literal physical LOW sector is exactly empty at the zero cutoff.
    This uses the original source, not a copied or approximate sum. -/
theorem lowSector_zero_exact (q a h : ℕ) :
    Merivelle.Central.lowSector (fun _ : ℕ => 0) q a h = 0 := by
  simp [Merivelle.Central.lowSector,
    GoldC.regionSumCard, GoldC.regionPairSumCard]

/-- The original signed physical LOW source has uniform sublog rate for
    the identically-zero cutoff, with the exact anchor quantifiers. -/
theorem lowSector_zero_sublog :
    Merivelle.Central.SourceUniformSublog
      (Merivelle.Central.lowSector (fun _ : ℕ => 0)) := by
  intro q _ _ eps heps
  refine ⟨1, ?_⟩
  intro a h _ hh _ _
  have hh1 : (1 : ℝ) ≤ h := by exact_mod_cast (show 1 ≤ h by omega)
  have hnonneg := mul_nonneg heps.le (Real.log_nonneg hh1)
  simpa only [lowSector_zero_exact, abs_zero] using hnonneg

theorem zero_cutoff_order :
    ∀ h : ℕ, (fun _ : ℕ => 0) h ≤ GoldC.orienneCentralHighCut h := by
  intro h
  exact Nat.zero_le _

/-- A striking consequence of the literal *arbitrary-cutoff* CORE and LONG
    theorems: choosing the zero LOW cutoff closes the remaining premise.
    This theorem must receive an independent mathematical/source audit. -/
theorem paperB_terminal_via_empty_low :
    PaperB.Closure.PaperBTerminalStatement := by
  exact Orienne.CSC3.paperB_terminal_of_native_low
    (fun _ : ℕ => 0) (1 / 4 : ℝ)
    (by norm_num) (by norm_num)
    zero_cutoff_order lowSector_zero_sublog

#print axioms Thistle.LOW.lowSector_zero_exact
#print axioms Thistle.LOW.lowSector_zero_sublog
#print axioms Thistle.LOW.paperB_terminal_via_empty_low

end Thistle.LOW
