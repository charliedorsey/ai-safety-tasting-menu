import PaperB.Analytic.PetermannEtaFejerCore
import PaperB.Analytic.PetermannEtaHarmonicSmoothing

namespace PaperB.Analytic

open Real Finset Nat

lemma eta_near_jump_round_bound_fejer
    {q m : ℕ} {A S : ℝ} {r : ℤ}
    (hne : ¬ etaHarmonicAwayFromJump q A r S m) :
    let phase : ℝ :=
      A / (m : ℝ) +
        (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)
    |phase - (round phase : ℝ)| ≤ 1 / (2 * S) := by
  dsimp
  unfold etaHarmonicAwayFromJump at hne
  rw [abs_sub_round_eq_min, sawSmoothHalfWidth] at *
  push_neg at hne
  by_cases hleft : Int.fract
      (A / (m : ℝ) +
        (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) ≤ 1 / (2 * S)
  · exact le_trans (min_le_left _ _) hleft
  · have hlow : 1 / (2 * S) < Int.fract
        (A / (m : ℝ) +
          (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) := lt_of_not_ge hleft
    have hright := hne hlow
    exact le_trans (min_le_right _ _) (le_of_lt (by linarith))

lemma eta_near_jump_fejer_majorant
    {q J m : ℕ} (hJ : 1 ≤ J)
    {A : ℝ} {r : ℤ}
    (hne : ¬ etaHarmonicAwayFromJump q A r (8 * (J : ℝ)) m) :
    (1 : ℝ) ≤
      (4 / (J : ℝ)^2) *
        ‖etaFejerPhaseSumCore J
          (A / (m : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))‖^2 := by
  let x : ℝ :=
    A / (m : ℝ) +
      (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)
  have hnear := eta_near_jump_round_bound_fejer
    (q := q) (m := m) (A := A)
    (S := 8 * (J : ℝ)) (r := r) hne
  have hnear' : |x - (round x : ℝ)| ≤ 1 / (16 * (J : ℝ)) := by
    simpa [x, show (2 : ℝ) * (8 * (J : ℝ)) = 16 * (J : ℝ) by ring] using hnear
  exact etaFejerCore_majorant hJ hnear'

#print axioms eta_near_jump_fejer_majorant

end PaperB.Analytic
