import Orienne.Publication.F01PrintedLiteralBridgeR0001
import Orienne.CSC3.LowZeroTerminalR0001

/-! A literal printed-Euler public terminal, assembled from the unchanged
independently reviewed F-01 proof and the unconditional native terminal. -/
namespace Orienne.Publication

/-- The frozen manuscript's independently defined printed A and B singular
series obey the uniform fixed-squarefree-q level-one epsilon estimate. -/
theorem paperB_printed_terminal :
    ∀ q : ℕ, 0 < q → Squarefree q →
      ∀ ε : ℝ, 0 < ε →
      ∃ h0 : ℕ, ∀ a b h : ℕ,
        q.Coprime a → q.Coprime b →
        Nat.ModEq q (a + h) b →
        (¬ 2 ∣ q → 2 ∣ h) →
        0 < h → h0 ≤ h →
        |Merivelle.F01.printedA1Literal q a h -
          Elarienne.F01B.printedB1Literal q a b h| ≤
          ε * Real.log (h : ℝ) := by
  intro q hq hsq ε hε
  obtain ⟨h0, hmain⟩ :=
    Thistle.LOW.paperB_terminal_via_empty_low q hq hsq ε hε
  refine ⟨h0, ?_⟩
  intro a b h ha hb hcompat hparity hpos hlarge
  rw [Elarienne.F01B.printedA_sub_printedB_eq_manuscriptKernels
    q a b h hq hcompat hparity]
  exact hmain a b h ha hb hcompat hparity hpos hlarge

#print axioms paperB_printed_terminal
end Orienne.Publication
