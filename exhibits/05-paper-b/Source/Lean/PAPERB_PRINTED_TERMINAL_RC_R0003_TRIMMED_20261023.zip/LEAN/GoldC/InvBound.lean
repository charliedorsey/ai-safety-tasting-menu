import GoldC.CentralDecomp
import Mathlib.NumberTheory.Harmonic.Bounds
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
import Mathlib.Data.Nat.Squarefree

/-!
# `GoldC.InvBound` — the density-diagonal part is negligible (a genuine rate)

`|InvPart q a h| ≤ 4 · (1 + log h)³ · Z(h)^{-1/2} · exp K₀` with an absolute constant `K₀`
(`InvPart_le`), hence `InvPart = o(1)`, uniformly in `q`, `a` (`InvPart_sublog`).

Ingredients: `0 ≤ λ ≤ 4`; `n = rs > Z(h)` on the quarter mask; the Euler product
`Σ_{e} 2^{|e|} ω(e) n(e)^{-1/2} ≤ ∏_{p ≥ 5} (1 + 2/((p-3)√p)) ≤ exp K₀`; and
`Σ_d V_d ≤ ∏_{p | h} (1 + 1/(p-2)) ≤ (Σ_{k | h} 1/k)³ ≤ (1 + log h)³`.
-/

open scoped BigOperators Classical
open Finset Real Filter Topology

namespace GoldC

/-! ## Pointwise bounds on the source weight -/

lemma endpoint_le_triple (p H y : ℕ) : endpointOccupiedCount p H ≤ tripleOccupiedCount p H y := by
  unfold endpointOccupiedCount tripleOccupiedCount
  apply Finset.card_le_card
  intro x hx
  simp only [Finset.mem_insert, Finset.mem_singleton] at hx ⊢
  tauto

lemma triple_le (p H y : ℕ) (hp : 0 < p) : tripleOccupiedCount p H y ≤ p := by
  unfold tripleOccupiedCount
  calc ({0 % p, y % p, H % p} : Finset ℕ).card ≤ (Finset.range p).card := by
        apply Finset.card_le_card
        intro x hx
        simp only [Finset.mem_insert, Finset.mem_singleton] at hx
        rw [Finset.mem_range]
        rcases hx with rfl | rfl | rfl <;> exact Nat.mod_lt _ hp
    _ = p := Finset.card_range p

lemma occupiedLocalRatio_bounds {p : ℕ} (hp : 2 ≤ p) (H y : ℕ) :
    0 ≤ occupiedLocalRatio p H y ∧ occupiedLocalRatio p H y ≤ 2 := by
  unfold occupiedLocalRatio
  have hpR : (2 : ℝ) ≤ p := by exact_mod_cast hp
  have ht := triple_le p H y (by omega)
  have het := endpoint_le_triple p H y
  set t := tripleOccupiedCount p H y
  set e := endpointOccupiedCount p H
  have htR : (t : ℝ) ≤ p := by exact_mod_cast ht
  have hetR : (e : ℝ) ≤ t := by exact_mod_cast het
  have hp0 : (0 : ℝ) < p := by linarith
  have h1p : (1 / 2 : ℝ) ≤ 1 - 1 / (p : ℝ) := by
    have : (1 : ℝ) / p ≤ 1 / 2 := by
      rw [div_le_div_iff₀ hp0 (by norm_num)]; linarith
    linarith
  have hnum0 : 0 ≤ 1 - (t : ℝ) / p := by
    rw [sub_nonneg, div_le_one hp0]; exact htR
  by_cases hden : 1 - (e : ℝ) / p = 0
  · rw [hden, div_zero, zero_div]; norm_num
  · have hden_pos : 0 < 1 - (e : ℝ) / p := by
      rcases lt_or_gt_of_ne hden with h | h
      · exfalso
        have : (p : ℝ) < e := by
          rw [sub_neg, one_lt_div hp0] at h; exact h
        linarith
      · exact h
    have hle : 1 - (t : ℝ) / p ≤ 1 - (e : ℝ) / p := by
      have : (e : ℝ) / p ≤ t / p := div_le_div_of_nonneg_right hetR hp0.le
      linarith
    have hq : (1 - (t : ℝ) / p) / (1 - (e : ℝ) / p) ≤ 1 := (div_le_one hden_pos).2 hle
    have hq0 : 0 ≤ (1 - (t : ℝ) / p) / (1 - (e : ℝ) / p) := div_nonneg hnum0 hden_pos.le
    refine ⟨div_nonneg hq0 (by linarith), ?_⟩
    rw [div_le_iff₀ (by linarith)]
    nlinarith

lemma occupiedWeight_bounds (q a H y : ℕ) :
    0 ≤ occupiedWeight q a H y ∧ occupiedWeight q a H y ≤ 4 := by
  unfold occupiedWeight
  have hprod : 0 ≤ (∏ p ∈ lowPrimeSet, if p ∣ q then (1 : ℝ) else occupiedLocalRatio p H y) ∧
      (∏ p ∈ lowPrimeSet, if p ∣ q then (1 : ℝ) else occupiedLocalRatio p H y) ≤ 4 := by
    have hb : ∀ p ∈ lowPrimeSet, 0 ≤ (if p ∣ q then (1 : ℝ) else occupiedLocalRatio p H y) ∧
        (if p ∣ q then (1 : ℝ) else occupiedLocalRatio p H y) ≤ 2 := by
      intro p hp
      have hp2 : 2 ≤ p := by
        simp only [lowPrimeSet, Finset.mem_insert, Finset.mem_singleton] at hp
        rcases hp with rfl | rfl <;> norm_num
      split_ifs
      · norm_num
      · exact occupiedLocalRatio_bounds hp2 H y
    unfold lowPrimeSet at hb ⊢
    rw [Finset.prod_insert (by norm_num), Finset.prod_singleton]
    obtain ⟨h1, h2⟩ := hb 2 (by simp)
    obtain ⟨h3, h4⟩ := hb 3 (by simp)
    exact ⟨mul_nonneg h1 h3, by nlinarith⟩
  split_ifs
  · rw [one_mul]; exact hprod
  · rw [zero_mul]; norm_num

lemma meanWeight_bounds (q a' H : ℕ) : 0 ≤ meanWeight q a' H ∧ meanWeight q a' H ≤ 4 := by
  unfold meanWeight
  rcases Nat.eq_zero_or_pos q with rfl | hq
  · simp
  have hq' : (0 : ℝ) < 6 * q := by positivity
  constructor
  · exact div_nonneg (Finset.sum_nonneg fun y _ => (occupiedWeight_bounds q a' H y).1) hq'.le
  · rw [div_le_iff₀ hq']
    calc (∑ y ∈ Finset.range (6 * q), occupiedWeight q a' H y)
        ≤ ∑ y ∈ Finset.range (6 * q), (4 : ℝ) :=
          Finset.sum_le_sum fun y _ => (occupiedWeight_bounds q a' H y).2
      _ = 4 * (6 * q) := by rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul]; push_cast; ring

/-! ## Euler-product bound over the parents `e` -/

/-- The prime-local factor `2/((p-3)√p)`. -/
noncomputable def eulerLocal (p : ℕ) : ℝ := 2 / (((p : ℝ) - 3) * Real.sqrt p)

lemma eulerLocal_nonneg {p : ℕ} (hp : 5 ≤ p) : 0 ≤ eulerLocal p := by
  unfold eulerLocal
  have : (5 : ℝ) ≤ p := by exact_mod_cast hp
  apply div_nonneg (by norm_num)
  apply mul_nonneg (by linarith) (Real.sqrt_nonneg _)

lemma eulerLocal_le {p : ℕ} (hp : 5 ≤ p) : eulerLocal p ≤ 5 * (1 / (p : ℝ) ^ (3 / 2 : ℝ)) := by
  unfold eulerLocal
  have h5 : (5 : ℝ) ≤ p := by exact_mod_cast hp
  have hp0 : (0 : ℝ) < p := by linarith
  have hs : (0 : ℝ) < Real.sqrt p := Real.sqrt_pos.2 hp0
  have h32 : (p : ℝ) ^ (3 / 2 : ℝ) = p * Real.sqrt p := by
    rw [show (3 / 2 : ℝ) = 1 + 1 / 2 by norm_num, Real.rpow_add hp0, Real.rpow_one,
      Real.sqrt_eq_rpow]
  rw [h32, mul_one_div, div_le_div_iff₀ (by nlinarith) (by positivity)]
  nlinarith

/-- An absolute constant: `K₀ = Σ_{m ≥ 0} 5 m^{-3/2}`. -/
noncomputable def K0 : ℝ := ∑' m : ℕ, 5 * (1 / (m : ℝ) ^ (3 / 2 : ℝ))

lemma summable_K0 : Summable (fun m : ℕ => 5 * (1 / (m : ℝ) ^ (3 / 2 : ℝ))) :=
  (Real.summable_one_div_nat_rpow.2 (by norm_num)).mul_left 5

lemma sum_eulerLocal_le {S : Finset ℕ} (hS : ∀ p ∈ S, 5 ≤ p) : ∑ p ∈ S, eulerLocal p ≤ K0 := by
  calc ∑ p ∈ S, eulerLocal p ≤ ∑ p ∈ S, 5 * (1 / (p : ℝ) ^ (3 / 2 : ℝ)) :=
        Finset.sum_le_sum fun p hp => eulerLocal_le (hS p hp)
    _ ≤ K0 := by
        unfold K0
        refine summable_K0.sum_le_tsum S fun m _ => ?_
        have : (0 : ℝ) ≤ (m : ℝ) ^ (3 / 2 : ℝ) := Real.rpow_nonneg (Nat.cast_nonneg m) _
        positivity

lemma prod_euler_le_exp {S : Finset ℕ} (hS : ∀ p ∈ S, 5 ≤ p) :
    ∏ p ∈ S, (1 + eulerLocal p) ≤ Real.exp K0 := by
  calc ∏ p ∈ S, (1 + eulerLocal p) ≤ ∏ p ∈ S, Real.exp (eulerLocal p) :=
        Finset.prod_le_prod₀ (fun p hp => by have := eulerLocal_nonneg (hS p hp); linarith)
          (fun p _ => by have := Real.add_one_le_exp (eulerLocal p); linarith)
    _ = Real.exp (∑ p ∈ S, eulerLocal p) := (Real.exp_sum _ _).symm
    _ ≤ Real.exp K0 := Real.exp_le_exp.2 (sum_eulerLocal_le hS)

/-- For `n(e) > Z`: `2^{|e|} ω(e) / n(e) ≤ Z^{-1/2} ∏_{p ∈ e} eulerLocal p`. -/
lemma term_le {e : Finset ℕ} (he : ∀ p ∈ e, 5 ≤ p) {Z : ℝ} (hZ : 0 < Z)
    (hn : Z < (primeSetProduct e : ℝ)) :
    (2 : ℝ) ^ e.card * omegaWeight e / (primeSetProduct e : ℝ) ≤
      (1 / Real.sqrt Z) * ∏ p ∈ e, eulerLocal p := by
  have hpos : ∀ p ∈ e, (0 : ℝ) < p := fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast he p hp
    linarith
  set X : ℝ := ∏ p ∈ e, (1 / Real.sqrt p) with hX
  have hX0 : 0 ≤ X := Finset.prod_nonneg fun p hp => by positivity
  have hnR : (primeSetProduct e : ℝ) = ∏ p ∈ e, (p : ℝ) := by
    unfold primeSetProduct; push_cast; rfl
  have hX2 : X ^ 2 = 1 / (primeSetProduct e : ℝ) := by
    rw [hX, ← Finset.prod_pow, hnR, one_div, ← Finset.prod_inv_distrib]
    refine Finset.prod_congr rfl fun p hp => ?_
    rw [div_pow, Real.sq_sqrt (hpos p hp).le, one_pow, one_div]
  have hXle : X ≤ 1 / Real.sqrt Z := by
    have hZs : 0 < Real.sqrt Z := Real.sqrt_pos.2 hZ
    have h1 : X ^ 2 ≤ (1 / Real.sqrt Z) ^ 2 := by
      rw [hX2, div_pow, Real.sq_sqrt hZ.le, one_pow]
      exact one_div_le_one_div_of_le hZ hn.le
    exact (pow_le_pow_iff_left₀ hX0 (by positivity) (by norm_num)).1 h1
  have hfac : (2 : ℝ) ^ e.card * omegaWeight e / (primeSetProduct e : ℝ) =
      (∏ p ∈ e, eulerLocal p) * X := by
    have hL : (2 : ℝ) ^ e.card * omegaWeight e / (primeSetProduct e : ℝ) =
        ∏ p ∈ e, (2 * (1 / ((p : ℝ) - 3)) / p) := by
      rw [hnR, omegaWeight, ← Finset.prod_const, ← Finset.prod_mul_distrib,
        ← Finset.prod_div_distrib]
    rw [hL, hX, ← Finset.prod_mul_distrib]
    refine Finset.prod_congr rfl fun p hp => ?_
    have hp0 := hpos p hp
    have hs : (0 : ℝ) < Real.sqrt p := Real.sqrt_pos.2 hp0
    have hsq : Real.sqrt p * Real.sqrt p = p := Real.mul_self_sqrt hp0.le
    have hp3 : (0 : ℝ) < (p : ℝ) - 3 := by
      have : (5 : ℝ) ≤ p := by exact_mod_cast he p hp
      linarith
    unfold eulerLocal
    rw [div_mul_div_comm, mul_one, mul_assoc, hsq]
    field_simp
  rw [hfac, mul_comm (1 / Real.sqrt Z)]
  exact mul_le_mul_of_nonneg_left hXle (Finset.prod_nonneg fun p hp => eulerLocal_nonneg (he p hp))

/-- **Euler bound over parents**: `Σ_{e ⊆ S, n(e) > Z} 2^{|e|} ω(e)/n(e) ≤ Z^{-1/2} e^{K₀}`. -/
theorem parents_bound {S : Finset ℕ} (hS : ∀ p ∈ S, 5 ≤ p) {Z : ℝ} (hZ : 0 < Z)
    (E : Finset (Finset ℕ)) (hE : ∀ e ∈ E, e ⊆ S ∧ Z < (primeSetProduct e : ℝ)) :
    ∑ e ∈ E, (2 : ℝ) ^ e.card * omegaWeight e / (primeSetProduct e : ℝ) ≤
      (1 / Real.sqrt Z) * Real.exp K0 := by
  have hsub : E ⊆ S.powerset := fun e he => Finset.mem_powerset.2 (hE e he).1
  calc ∑ e ∈ E, (2 : ℝ) ^ e.card * omegaWeight e / (primeSetProduct e : ℝ)
      ≤ ∑ e ∈ E, (1 / Real.sqrt Z) * ∏ p ∈ e, eulerLocal p :=
        Finset.sum_le_sum fun e he =>
          term_le (fun p hp => hS p ((hE e he).1 hp)) hZ (hE e he).2
    _ ≤ ∑ e ∈ S.powerset, (1 / Real.sqrt Z) * ∏ p ∈ e, eulerLocal p := by
        apply Finset.sum_le_sum_of_subset_of_nonneg hsub
        intro e he _
        exact mul_nonneg (by positivity) (Finset.prod_nonneg fun p hp =>
          eulerLocal_nonneg (hS p (Finset.mem_powerset.1 he hp)))
    _ = (1 / Real.sqrt Z) * ∏ p ∈ S, (1 + eulerLocal p) := by
        rw [← Finset.mul_sum, Finset.prod_one_add]
    _ ≤ (1 / Real.sqrt Z) * Real.exp K0 :=
        mul_le_mul_of_nonneg_left (prod_euler_le_exp hS) (by positivity)

/-! ## The decoration sum -/

lemma inv_sub_two_le (p : ℕ) (hp : 3 ≤ p) :
    1 + 1 / ((p : ℝ) - 2) ≤ (1 + 1 / (p : ℝ)) ^ 3 := by
  have h3 : (3 : ℝ) ≤ p := by exact_mod_cast hp
  have hp2 : (0 : ℝ) < (p : ℝ) - 2 := by linarith
  have hp0 : (0 : ℝ) < p := by linarith
  have hx : (0 : ℝ) ≤ 1 / p := by positivity
  have h1 : 1 / ((p : ℝ) - 2) ≤ 3 / p := by
    rw [div_le_div_iff₀ hp2 hp0]; linarith
  have h2 : 1 + 3 / (p : ℝ) ≤ (1 + 1 / p) ^ 3 := by
    have : (3 : ℝ) / p = 3 * (1 / p) := by ring
    rw [this]; nlinarith [sq_nonneg (1 / (p : ℝ)), pow_two_nonneg (1 / (p : ℝ))]
  linarith

/-- `Σ_{k ∣ h} 1/k ≤ 1 + log h`. -/
lemma sum_divisors_inv_le (h : ℕ) : ∑ k ∈ h.divisors, (1 / (k : ℝ)) ≤ 1 + Real.log h := by
  rcases Nat.eq_zero_or_pos h with rfl | hh
  · simp
  calc ∑ k ∈ h.divisors, (1 / (k : ℝ)) ≤ ∑ k ∈ Finset.Icc 1 h, (1 / (k : ℝ)) := by
        apply Finset.sum_le_sum_of_subset_of_nonneg
        · intro k hk
          rw [Nat.mem_divisors] at hk
          rw [Finset.mem_Icc]
          exact ⟨Nat.pos_of_dvd_of_pos hk.1 hh, Nat.le_of_dvd hh hk.1⟩
        · intro k _ _; positivity
    _ = (harmonic h : ℝ) := by
        rw [harmonic_eq_sum_Icc]; push_cast
        refine Finset.sum_congr rfl fun k _ => by rw [one_div]
    _ ≤ 1 + Real.log h := harmonic_le_one_add_log h

/-- `∏_{p ∈ P} (1 + 1/p) ≤ 1 + log h` for a set `P` of primes dividing `h`. -/
lemma prod_one_add_inv_le {h : ℕ} {P : Finset ℕ} (hP : ∀ p ∈ P, p.Prime ∧ p ∣ h) (hh : 0 < h) :
    ∏ p ∈ P, (1 + 1 / (p : ℝ)) ≤ 1 + Real.log h := by
  rw [Finset.prod_one_add]
  have hinj : Set.InjOn (fun T : Finset ℕ => ∏ p ∈ T, p) (P.powerset : Set (Finset ℕ)) := by
    intro T hT T' hT' heq
    have hT1 : ∀ p ∈ T, p.Prime := fun p hp => (hP p (Finset.mem_powerset.1 hT hp)).1
    have hT2 : ∀ p ∈ T', p.Prime := fun p hp => (hP p (Finset.mem_powerset.1 hT' hp)).1
    have := congrArg Nat.primeFactors heq
    simp only at this
    rwa [Nat.primeFactors_prod hT1, Nat.primeFactors_prod hT2] at this
  calc ∑ T ∈ P.powerset, ∏ p ∈ T, (1 / (p : ℝ))
      = ∑ T ∈ P.powerset, 1 / ((∏ p ∈ T, p : ℕ) : ℝ) := by
        refine Finset.sum_congr rfl fun T _ => ?_
        push_cast; rw [Finset.prod_div_distrib, Finset.prod_const_one]
    _ = ∑ k ∈ P.powerset.image (fun T => ∏ p ∈ T, p), 1 / (k : ℝ) :=
        (Finset.sum_image (f := fun k : ℕ => 1 / (k : ℝ)) hinj).symm
    _ ≤ ∑ k ∈ h.divisors, (1 / (k : ℝ)) := by
        apply Finset.sum_le_sum_of_subset_of_nonneg
        · intro k hk
          obtain ⟨T, hT, rfl⟩ := Finset.mem_image.1 hk
          rw [Nat.mem_divisors]
          refine ⟨?_, hh.ne'⟩
          have hTp : ∀ p ∈ T, p.Prime ∧ p ∣ h := fun p hp => hP p (Finset.mem_powerset.1 hT hp)
          calc ∏ p ∈ T, p ∣ ∏ p ∈ h.primeFactors, p :=
                Finset.prod_dvd_prod_of_subset T h.primeFactors id fun p hp =>
                  Nat.mem_primeFactors.2 ⟨(hTp p hp).1, (hTp p hp).2, hh.ne'⟩
            _ ∣ h := Nat.prod_primeFactors_dvd h
        · intro k _ _; positivity
    _ ≤ 1 + Real.log h := sum_divisors_inv_le h

/-- **Decoration mass**: `Σ_{d} V_d ≤ (1 + log h)³` over any family of decorations. -/
theorem decoration_mass_le (q h : ℕ) (hh : 0 < h)
    (Dset : Finset (Finset ℕ)) (hD : Dset ⊆ (decoratedHeightPrimeSet q h).powerset) :
    ∑ d ∈ Dset, decorationWeight h d ≤ (1 + Real.log h) ^ 3 := by
  set P := decoratedHeightPrimeSet q h
  have hPf : ∀ p ∈ P, p.Prime ∧ p ∣ h ∧ 5 ≤ p := by
    intro p hp
    unfold P decoratedHeightPrimeSet at hp
    rw [Finset.mem_filter, Nat.mem_primeFactors] at hp
    exact ⟨hp.1.1, hp.1.2.1, hp.2.1⟩
  have hV : ∀ d ∈ P.powerset, decorationWeight h d = ∏ p ∈ d, (1 / ((p : ℝ) - 2)) := by
    intro d hd
    unfold decorationWeight
    refine Finset.prod_congr rfl fun p hp => ?_
    simp only [(hPf p (Finset.mem_powerset.1 hd hp)).2.1, ↓reduceIte]
  have hVnn : ∀ d ∈ P.powerset, 0 ≤ decorationWeight h d := by
    intro d hd
    rw [hV d hd]
    exact Finset.prod_nonneg fun p hp => by
      have : (5 : ℝ) ≤ p := by exact_mod_cast (hPf p (Finset.mem_powerset.1 hd hp)).2.2
      have : (0 : ℝ) < (p : ℝ) - 2 := by linarith
      positivity
  calc ∑ d ∈ Dset, decorationWeight h d ≤ ∑ d ∈ P.powerset, decorationWeight h d :=
        Finset.sum_le_sum_of_subset_of_nonneg hD fun d hd _ => hVnn d hd
    _ = ∏ p ∈ P, (1 + 1 / ((p : ℝ) - 2)) := by
        rw [Finset.prod_one_add]
        exact Finset.sum_congr rfl hV
    _ ≤ ∏ p ∈ P, (1 + 1 / (p : ℝ)) ^ 3 :=
        Finset.prod_le_prod₀ (fun p hp => by
          have : (5 : ℝ) ≤ p := by exact_mod_cast (hPf p hp).2.2
          have : (0 : ℝ) < (p : ℝ) - 2 := by linarith
          positivity) fun p hp => inv_sub_two_le p (by have := (hPf p hp).2.2; omega)
    _ = (∏ p ∈ P, (1 + 1 / (p : ℝ))) ^ 3 := Finset.prod_pow _ _ _
    _ ≤ (1 + Real.log h) ^ 3 := by
        have h0 : 0 ≤ ∏ p ∈ P, (1 + 1 / (p : ℝ)) := Finset.prod_nonneg fun p _ => by positivity
        exact pow_le_pow_left₀ h0 (prod_one_add_inv_le (fun p hp => ⟨(hPf p hp).1, (hPf p hp).2.1⟩) hh) 3

/-! ## The bound on `InvPart` -/

lemma omegaWeight_nonneg {e : Finset ℕ} (he : ∀ p ∈ e, 5 ≤ p) : 0 ≤ omegaWeight e := by
  unfold omegaWeight
  exact Finset.prod_nonneg fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast he p hp
    have : (0 : ℝ) < (p : ℝ) - 3 := by linarith
    positivity

lemma prod_B_mul_prod_sdiff {e B : Finset ℕ} (hB : B ⊆ e) :
    primeSetProduct B * primeSetProduct (e \ B) = primeSetProduct e := by
  unfold primeSetProduct
  rw [mul_comm, Finset.prod_sdiff hB]

lemma card_splits_le (e : Finset ℕ) : ((e.powerset.erase e).erase ∅).card ≤ 2 ^ e.card := by
  calc ((e.powerset.erase e).erase ∅).card ≤ (e.powerset.erase e).card := Finset.card_erase_le
    _ ≤ e.powerset.card := Finset.card_erase_le
    _ = 2 ^ e.card := Finset.card_powerset e

lemma decorationWeight_nonneg {q h : ℕ} {d : Finset ℕ} (hd : d ⊆ decoratedHeightPrimeSet q h) :
    0 ≤ decorationWeight h d := by
  unfold decorationWeight
  refine Finset.prod_nonneg fun p hp => ?_
  have hp' := hd hp
  unfold decoratedHeightPrimeSet at hp'
  rw [Finset.mem_filter] at hp'
  have h5 : (5 : ℝ) ≤ p := by exact_mod_cast hp'.2.1
  by_cases hph : p ∣ h
  · simp only [hph, ↓reduceIte]
    have : (0 : ℝ) < (p : ℝ) - 2 := by linarith
    exact (one_div_pos.2 this).le
  · simp only [hph, ↓reduceIte]
    have : (0 : ℝ) < (p : ℝ) - 3 := by linarith
    exact (one_div_pos.2 this).le

/-- Inner bound for one decoration. -/
lemma inner_abs_le (q h D H : ℕ) (d : Finset ℕ) (F : ℕ → ℕ → ℕ → ℕ → ℝ) (C : ℝ) (hC : 0 ≤ C)
    (hF : ∀ e ∈ quarterParents q h H d (H ^ 2 + 1), ∀ B ∈ ((e.powerset.erase e).erase ∅),
      |F D H (primeSetProduct B) (primeSetProduct (e \ B))|
        ≤ C / ((primeSetProduct B : ℝ) * (primeSetProduct (e \ B) : ℝ))) :
    |∑ e ∈ quarterParents q h H d (H ^ 2 + 1), ∑ B ∈ ((e.powerset.erase e).erase ∅),
        (if centralGate h H (primeSetProduct B) (primeSetProduct (e \ B)) then
          omegaWeight e * F D H (primeSetProduct B) (primeSetProduct (e \ B)) else 0)|
      ≤ C * ((1 / Real.sqrt (originalZ h)) * Real.exp K0) := by
  have hZn : 0 < originalZ h := by unfold originalZ; exact pow_pos (by norm_num) _
  have hZ : (0 : ℝ) < originalZ h := by exact_mod_cast hZn
  have hS5 : ∀ p ∈ ordinaryFiniteSupport q H d (H ^ 2 + 1), 5 ≤ p :=
    fun p hp => (prime_of_mem_support hp).2.1
  have hE : ∀ e ∈ quarterParents q h H d (H ^ 2 + 1),
      e ⊆ ordinaryFiniteSupport q H d (H ^ 2 + 1) ∧
        (originalZ h : ℝ) < (primeSetProduct e : ℝ) := by
    intro e he
    unfold quarterParents at he
    rw [Finset.mem_filter, Finset.mem_powerset] at he
    exact ⟨he.1, by exact_mod_cast he.2.1⟩
  refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
  calc _ ≤ ∑ e ∈ quarterParents q h H d (H ^ 2 + 1),
        C * ((2 : ℝ) ^ e.card * omegaWeight e / (primeSetProduct e : ℝ)) := by
        refine Finset.sum_le_sum fun e he => ?_
        have he5 : ∀ p ∈ e, 5 ≤ p := fun p hp => hS5 p ((hE e he).1 hp)
        have hω := omegaWeight_nonneg he5
        have hnpos : (0 : ℝ) < (primeSetProduct e : ℝ) := lt_trans hZ (hE e he).2
        refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
        have hterm : ∀ B ∈ ((e.powerset.erase e).erase ∅),
            |(if centralGate h H (primeSetProduct B) (primeSetProduct (e \ B)) then
              omegaWeight e * F D H (primeSetProduct B) (primeSetProduct (e \ B))
              else 0)| ≤ omegaWeight e * C / (primeSetProduct e : ℝ) := by
          intro B hB
          have hBe : B ⊆ e := by
            simp only [Finset.mem_erase, Finset.mem_powerset] at hB; exact hB.2.2
          have hprod : (primeSetProduct B : ℝ) * (primeSetProduct (e \ B) : ℝ) =
              (primeSetProduct e : ℝ) := by exact_mod_cast prod_B_mul_prod_sdiff hBe
          have hFB := hF e he B hB
          rw [hprod] at hFB
          by_cases hg : centralGate h H (primeSetProduct B) (primeSetProduct (e \ B))
          · simp only [hg, ↓reduceIte]
            rw [abs_mul, abs_of_nonneg hω, mul_div_assoc]
            exact mul_le_mul_of_nonneg_left hFB hω
          · simp only [hg, ↓reduceIte, abs_zero]
            exact div_nonneg (mul_nonneg hω hC) hnpos.le
        calc _ ≤ ∑ B ∈ ((e.powerset.erase e).erase ∅), omegaWeight e * C / (primeSetProduct e : ℝ) :=
              Finset.sum_le_sum hterm
          _ = (((e.powerset.erase e).erase ∅).card : ℝ) *
                (omegaWeight e * C / (primeSetProduct e : ℝ)) := by
              rw [Finset.sum_const, nsmul_eq_mul]
          _ ≤ (2 : ℝ) ^ e.card * (omegaWeight e * C / (primeSetProduct e : ℝ)) := by
              apply mul_le_mul_of_nonneg_right _ (div_nonneg (mul_nonneg hω hC) hnpos.le)
              exact_mod_cast card_splits_le e
          _ = C * ((2 : ℝ) ^ e.card * omegaWeight e / (primeSetProduct e : ℝ)) := by ring
    _ = C * ∑ e ∈ quarterParents q h H d (H ^ 2 + 1),
          (2 : ℝ) ^ e.card * omegaWeight e / (primeSetProduct e : ℝ) := by rw [Finset.mul_sum]
    _ ≤ C * ((1 / Real.sqrt (originalZ h)) * Real.exp K0) :=
        mul_le_mul_of_nonneg_left (parents_bound hS5 hZ _ hE) hC

/-- A generic bound for the source sum: if every source row functional is at most `C/(rs)`,
then `|centralSum| ≤ C (1 + log h)³ Z(h)^{-1/2} e^{K₀}`. -/
theorem centralSum_abs_le (q h : ℕ) (hh : 0 < h) (F : ℕ → ℕ → ℕ → ℕ → ℝ) (C : ℝ) (hC : 0 ≤ C)
    (hF : ∀ d e B, SourceIndex q h d e B →
      |F (primeSetProduct d) (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct (e \ B))|
        ≤ C / ((primeSetProduct B : ℝ) * (primeSetProduct (e \ B) : ℝ))) :
    |centralSum q h F| ≤ C * (1 + Real.log h) ^ 3 * ((1 / Real.sqrt (originalZ h)) * Real.exp K0) := by
  have hK : (0 : ℝ) ≤ (1 / Real.sqrt (originalZ h)) * Real.exp K0 :=
    mul_nonneg (div_nonneg zero_le_one (Real.sqrt_nonneg _)) (Real.exp_pos _).le
  unfold centralSum
  refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
  refine (Finset.sum_le_sum (g := fun d => decorationWeight h d *
    (C * ((1 / Real.sqrt (originalZ h)) * Real.exp K0))) fun d hd => ?_).trans ?_
  · have hsub : d ⊆ decoratedHeightPrimeSet q h :=
      Finset.mem_powerset.1 (Finset.mem_of_mem_filter d hd)
    have hV := decorationWeight_nonneg hsub
    rw [abs_mul, abs_of_nonneg hV]
    exact mul_le_mul_of_nonneg_left (inner_abs_le q h _ _ d F C hC
      fun e he B hB => hF d e B ⟨hd, he, hB⟩) hV
  · rw [← Finset.sum_mul]
    calc _ ≤ (1 + Real.log h) ^ 3 * (C * ((1 / Real.sqrt (originalZ h)) * Real.exp K0)) :=
          mul_le_mul_of_nonneg_right (decoration_mass_le q h hh _ (Finset.filter_subset _ _))
            (mul_nonneg hC hK)
      _ = C * (1 + Real.log h) ^ 3 * ((1 / Real.sqrt (originalZ h)) * Real.exp K0) := by ring

/-- **`|InvPart| ≤ 4 (1 + log h)³ Z(h)^{-1/2} e^{K₀}`**, uniformly in `q` and `a`. -/
theorem InvPart_le (q a h : ℕ) (hh : 0 < h) :
    |InvPart q a h| ≤ 4 * (1 + Real.log h) ^ 3 * ((1 / Real.sqrt (originalZ h)) * Real.exp K0) := by
  refine centralSum_abs_le q h hh _ 4 (by norm_num) fun d e B hidx => ?_
  obtain ⟨-, hr, hs, -, -, -⟩ := source_pair_facts hidx
  have hμ := meanWeight_bounds q (reducedAnchor q a (primeSetProduct d)) (h / primeSetProduct d)
  have hn : (0 : ℝ) < (primeSetProduct B : ℝ) * (primeSetProduct (e \ B) : ℝ) := by
    have : (0 : ℝ) < primeSetProduct B := by exact_mod_cast (by omega : 0 < primeSetProduct B)
    have : (0 : ℝ) < primeSetProduct (e \ B) := by
      exact_mod_cast (by omega : 0 < primeSetProduct (e \ B))
    positivity
  rw [abs_of_nonneg (div_nonneg hμ.1 hn.le)]
  exact div_le_div_of_nonneg_right hμ.2 hn.le

/-! ## The rate: `InvPart → 0` uniformly -/

lemma inv_sqrt_originalZ_le (h : ℕ) :
    1 / Real.sqrt (originalZ h) ≤
      Real.exp (-(10 * Real.log 2) * (Real.log (h : ℝ)) ^ booleanSigma) := by
  set n := booleanSourceCutoff h with hn
  have hZ : (originalZ h : ℝ) = ((2 : ℝ) ^ (10 * (n + 1))) ^ 2 := by
    unfold originalZ; rw [← hn]; push_cast; rw [← pow_mul]; ring_nf
  have h2 : (0 : ℝ) < (2 : ℝ) ^ (10 * (n + 1)) := by positivity
  rw [hZ, Real.sqrt_sq h2.le]
  have hexp : (2 : ℝ) ^ (10 * (n + 1)) = Real.exp (Real.log 2 * ((10 * (n + 1) : ℕ) : ℝ)) := by
    rw [← Real.rpow_natCast, Real.rpow_def_of_pos (by norm_num)]
  rw [hexp, one_div, ← Real.exp_neg, Real.exp_le_exp]
  have hfl : (Real.log (h : ℝ)) ^ booleanSigma < (n : ℝ) + 1 := by
    rw [hn]; unfold booleanSourceCutoff; exact Nat.lt_floor_add_one _
  have hl2 : (0 : ℝ) < Real.log 2 := Real.log_pos (by norm_num)
  push_cast
  nlinarith

lemma booleanSigma_pos : (0 : ℝ) < booleanSigma := by unfold booleanSigma; norm_num

/-- The majorant `32 e^{K₀} · x^{3/σ} e^{-(10 log 2) x}` at `x = (log h)^σ` tends to `0`. -/
lemma majorant_tendsto :
    Tendsto (fun h : ℕ => 32 * Real.exp K0 *
      (((Real.log (h : ℝ)) ^ booleanSigma) ^ (3 / booleanSigma) *
        Real.exp (-(10 * Real.log 2) * (Real.log (h : ℝ)) ^ booleanSigma))) atTop (𝓝 0) := by
  have hb : (0 : ℝ) < 10 * Real.log 2 := by have := Real.log_pos (by norm_num : (1 : ℝ) < 2); linarith
  have h1 := tendsto_rpow_mul_exp_neg_mul_atTop_nhds_zero (3 / booleanSigma) (10 * Real.log 2) hb
  have h2 : Tendsto (fun h : ℕ => (Real.log (h : ℝ)) ^ booleanSigma) atTop atTop :=
    (tendsto_rpow_atTop booleanSigma_pos).comp
      (Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop)
  have := (h1.comp h2).const_mul (32 * Real.exp K0)
  rw [mul_zero] at this
  exact this

/-- For `log h ≥ 1`: `|InvPart| ≤ majorant(h)`. -/
lemma InvPart_le_majorant (q a h : ℕ) (hh : 0 < h) (hL : 1 ≤ Real.log h) :
    |InvPart q a h| ≤ 32 * Real.exp K0 *
      (((Real.log (h : ℝ)) ^ booleanSigma) ^ (3 / booleanSigma) *
        Real.exp (-(10 * Real.log 2) * (Real.log (h : ℝ)) ^ booleanSigma)) := by
  refine (InvPart_le q a h hh).trans ?_
  set L := Real.log (h : ℝ)
  have hL0 : 0 ≤ L := by linarith
  have hpow : (L ^ booleanSigma) ^ (3 / booleanSigma) = L ^ 3 := by
    rw [← Real.rpow_mul hL0, mul_div_cancel₀ _ booleanSigma_pos.ne', show (3 : ℝ) = ((3 : ℕ) : ℝ) by norm_num,
      Real.rpow_natCast]
  rw [hpow]
  have hcube : (1 + L) ^ 3 ≤ 8 * L ^ 3 := by
    have : 1 + L ≤ 2 * L := by linarith
    calc (1 + L) ^ 3 ≤ (2 * L) ^ 3 := pow_le_pow_left₀ (by linarith) this 3
      _ = 8 * L ^ 3 := by ring
  have hz := inv_sqrt_originalZ_le h
  have hK := Real.exp_pos K0
  have hE := Real.exp_pos (-(10 * Real.log 2) * L ^ booleanSigma)
  have hL3 : 0 ≤ L ^ 3 := pow_nonneg hL0 3
  have hzz : 0 ≤ 1 / Real.sqrt (originalZ h) := div_nonneg zero_le_one (Real.sqrt_nonneg _)
  calc 4 * (1 + L) ^ 3 * ((1 / Real.sqrt (originalZ h)) * Real.exp K0)
      ≤ 4 * (8 * L ^ 3) * (Real.exp (-(10 * Real.log 2) * L ^ booleanSigma) * Real.exp K0) := by
        apply mul_le_mul (mul_le_mul_of_nonneg_left hcube (by norm_num))
          (mul_le_mul_of_nonneg_right hz hK.le) (mul_nonneg hzz hK.le) (by positivity)
    _ = 32 * Real.exp K0 * (L ^ 3 * Real.exp (-(10 * Real.log 2) * L ^ booleanSigma)) := by ring

/-- **Rate for the density-diagonal part.** For every `ε > 0` there is `H₀` such that
`|InvPart q a h| ≤ ε` for all `q`, `a` and all `h ≥ H₀`. -/
theorem InvPart_small (ε : ℝ) (hε : 0 < ε) :
    ∃ H0 : ℕ, ∀ q a h : ℕ, H0 ≤ h → |InvPart q a h| ≤ ε := by
  have hev := (majorant_tendsto.eventually (gt_mem_nhds hε))
  have hev2 : ∀ᶠ h : ℕ in atTop, 1 ≤ Real.log (h : ℝ) := by
    have := (Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop).eventually
      (eventually_ge_atTop (1 : ℝ))
    exact this
  obtain ⟨H0, hH0⟩ := eventually_atTop.1 ((hev.and hev2).and (eventually_ge_atTop 1))
  refine ⟨H0, fun q a h hh => ?_⟩
  obtain ⟨⟨h1, h2⟩, h3⟩ := hH0 h hh
  exact (InvPart_le_majorant q a h (by omega) h2).trans h1.le

/-- In the target's normalisation: `|InvPart| ≤ ε log h` eventually, uniformly in `q`, `a`. -/
theorem InvPart_sublog (ε : ℝ) (hε : 0 < ε) :
    ∃ H0 : ℕ, ∀ q a h : ℕ, H0 ≤ h → |InvPart q a h| ≤ ε * Real.log (h : ℝ) := by
  obtain ⟨H1, hH1⟩ := InvPart_small ε hε
  have hev : ∀ᶠ h : ℕ in atTop, 1 ≤ Real.log (h : ℝ) :=
    (Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop).eventually (eventually_ge_atTop 1)
  obtain ⟨H2, hH2⟩ := eventually_atTop.1 hev
  refine ⟨max H1 H2, fun q a h hh => ?_⟩
  have := hH1 q a h (le_of_max_le_left hh)
  have hl := hH2 h (le_of_max_le_right hh)
  nlinarith

end GoldC
