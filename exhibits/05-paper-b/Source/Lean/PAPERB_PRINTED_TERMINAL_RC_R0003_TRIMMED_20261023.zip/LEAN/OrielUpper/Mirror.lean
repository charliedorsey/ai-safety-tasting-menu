import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.NumberTheory.Primorial
import Mathlib.Data.Nat.GCD.BigOperators
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.Nat.Squarefree

/-!
# Oriel Upper — verbatim mirror of the Paper B source objects

Every body below is copied character-for-character from the frozen source
(`m2_freeze_r0012`), under the same `open` context as its home file, so that each
mirror constant is definitionally equal to its source twin.  The single change is
that the ordinary product cutoff `globalProperBooleanProductCutoff` (only ever
used as `Z h`) is abstracted into a parameter `Z`; the bridge instantiates it.

Source files:
* `PaperB/FixedQ/DivisorExpansion.lean` — `c0 c1 highPrimeLocalRatio activeHighPrime
  activeHighPrimeDecidable finiteVWeightReal finiteOmegaWeightReal lowPrimeSet
  lowPrimeLocalRatio fixedQLowWeight`
* `PaperB/FixedQ/RowReduction.lean` — `rowWeightMass rowConstrainedMass rowDiscrepancy
  decoratedHeightPrimeSet`
* `PaperB/FixedQ/PairRowBridge.lean` — `primeSetProduct`
* `PaperB/FixedQ/SignedForbiddenThalenActiveExteriorFinite.lean` —
  `thalenActiveOrdinaryFiniteSupport`
* `PaperB/FixedQ/TwoDimensionalClosure.lean` — `decoratedReducedAnchor`
* `ScratchEdrinR0051QuarterSumStabilize.lean` — `edrinR0051QuarterParents` (Z abstracted)
* `ScratchElarinR0033ActualVKConsumer.lean` — `edrinParentPairRow elarinR0031VKLowProduct`
* `ScratchVirelleR0037FourRegionGate.lean` — `virelleR0037Upper`
* `ScratchAuvrenR0056FourCompleteQuarterSockets.lean` — `auvrenR0056CompleteQuarter`
  (Z abstracted)
* `ScratchVirelleR0061Gate3TerminalBudget.lean` — `virelleR0061CompleteRegionSublog`
  (Z abstracted)
-/

section DivisorExpansion
open scoped BigOperators
namespace OrielUpper.Mirror

def c0 (p : ℕ) : ℚ :=
  (p : ℚ) * ((p : ℚ) - 3) / (((p : ℚ) - 1) * ((p : ℚ) - 2))

def c1 (p : ℕ) : ℚ :=
  (p : ℚ) * ((p : ℚ) - 2) / (((p : ℚ) - 1) ^ 2)

def highPrimeLocalRatio (p h y : ℕ) : ℚ :=
  if p ∣ h then
    if p ∣ y then (p : ℚ) / ((p : ℚ) - 1) else c1 p
  else
    if p ∣ y then (p : ℚ) / ((p : ℚ) - 1)
    else if p ∣ h - y then (p : ℚ) / ((p : ℚ) - 1) else c0 p

def activeHighPrime (q p : ℕ) : Prop :=
  p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q

instance activeHighPrimeDecidable (q p : ℕ) :
    Decidable (activeHighPrime q p) := by
  unfold activeHighPrime
  infer_instance

noncomputable def finiteVWeightReal (h : ℕ) (s : Finset ℕ) : ℝ :=
  ∏ p ∈ s, if p ∣ h then 1 / ((p : ℝ) - 2) else 1 / ((p : ℝ) - 3)

noncomputable def finiteOmegaWeightReal (s : Finset ℕ) : ℝ :=
  ∏ p ∈ s, 1 / ((p : ℝ) - 3)

def lowPrimeSet : Finset ℕ := {2, 3}

noncomputable def lowPrimeLocalRatio
    (p h y : ℕ) : ℝ :=
  ((highPrimeLocalRatio p h y : ℚ) : ℝ)

noncomputable def fixedQLowWeight
    (q a h y : ℕ) : ℝ :=
  (if q.Coprime (a + y) then 1 else 0) *
    ∏ p ∈ lowPrimeSet,
      if p ∣ q then 1 else lowPrimeLocalRatio p h y

end OrielUpper.Mirror
end DivisorExpansion

section RowReduction
open scoped BigOperators
namespace OrielUpper.Mirror

noncomputable def rowWeightMass
    (lambda : ℕ → ℝ) (H : ℕ) : ℝ :=
  ∑ y ∈ Finset.Ioo 0 H, lambda y

noncomputable def rowConstrainedMass
    (lambda : ℕ → ℝ) (H e1 e2 : ℕ) : ℝ :=
  ∑ y ∈ Finset.Ioo 0 H,
    if e1 ∣ y ∧ e2 ∣ H - y then lambda y else 0

noncomputable def rowDiscrepancy
    (lambda : ℕ → ℝ) (H e1 e2 : ℕ) : ℝ :=
  rowConstrainedMass lambda H e1 e2 -
    rowWeightMass lambda H / ((e1 : ℝ) * (e2 : ℝ))

def decoratedHeightPrimeSet (q h : ℕ) : Finset ℕ :=
  h.primeFactors.filter fun p => 5 ≤ p ∧ ¬ p ∣ q

end OrielUpper.Mirror
end RowReduction

section PairRowBridge
open scoped BigOperators
namespace OrielUpper.Mirror

def primeSetProduct (s : Finset ℕ) : ℕ := ∏ p ∈ s, p

end OrielUpper.Mirror
end PairRowBridge

section ThalenFinite
open scoped BigOperators
open Filter
namespace OrielUpper.Mirror

def thalenActiveOrdinaryFiniteSupport
    (q H : ℕ) (d : Finset ℕ) (N : ℕ) : Finset ℕ :=
  (Finset.range N).filter
    (fun p => activeHighPrime q p ∧ ¬ p ∣ H ∧ p ∉ d)

end OrielUpper.Mirror
end ThalenFinite

section TwoDimensionalClosure
open scoped BigOperators
namespace OrielUpper.Mirror

noncomputable def decoratedReducedAnchor
    (q a d : ℕ) : ℕ :=
  if hdq : d.Coprime q then
    (((((ZMod.unitOfCoprime d hdq)⁻¹ : (ZMod q)ˣ) : ZMod q) *
      (a : ZMod q)).val)
  else 0

end OrielUpper.Mirror
end TwoDimensionalClosure

section R0051
namespace OrielUpper.Mirror

/-- `edrinR0051QuarterParents` with `globalProperBooleanProductCutoff` abstracted as `Z`. -/
noncomputable def edrinR0051QuarterParents (Z : ℕ → ℕ) (q h H : ℕ) (d : Finset ℕ) (N : ℕ) :
    Finset (Finset ℕ) :=
  ((thalenActiveOrdinaryFiniteSupport q H d N).powerset).filter
    (fun e => Z h < primeSetProduct e ∧
      4 * primeSetProduct e ≤ H ^ 2)

end OrielUpper.Mirror
end R0051

section R0033
open scoped BigOperators Classical
namespace OrielUpper.Mirror

noncomputable def edrinParentPairRow
    (q A H : ℕ) (e B : Finset ℕ) : ℝ :=
  finiteOmegaWeightReal e *
    rowDiscrepancy (fixedQLowWeight q A H) H
      (primeSetProduct B) (primeSetProduct (e \ B))

def elarinR0031VKLowProduct (h H r s : ℕ) : Prop :=
  (r * s : ℝ) ≤ (H : ℝ) / Real.exp ((Real.log (h : ℝ)) ^ (1/4 : ℝ))

end OrielUpper.Mirror
end R0033

section R0037
open scoped BigOperators Classical
namespace OrielUpper.Mirror

def virelleR0037Upper (h H r s : ℕ) : Prop :=
  ¬ elarinR0031VKLowProduct h H r s

end OrielUpper.Mirror
end R0037

section R0056
open scoped Classical
namespace OrielUpper.Mirror

/-- `auvrenR0056CompleteQuarter` with the cutoff abstracted as `Z`. -/
noncomputable def auvrenR0056CompleteQuarter (Z : ℕ → ℕ)
    (q a h : ℕ) (R : ℕ → ℕ → ℕ → ℕ → Prop) : ℝ :=
  ∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
    finiteVWeightReal h d *
    (∑ e ∈ edrinR0051QuarterParents Z q h
      (h / primeSetProduct d) d ((h / primeSetProduct d) ^ 2 + 1),
      ∑ B ∈ ((e.powerset.erase e).erase ∅),
        if R h (h / primeSetProduct d)
          (primeSetProduct B) (primeSetProduct (e \ B))
        then edrinParentPairRow q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) e B else 0)

end OrielUpper.Mirror
end R0056

section R0061
namespace OrielUpper.Mirror

/-- `virelleR0061CompleteRegionSublog` with the cutoff abstracted as `Z`. -/
def virelleR0061CompleteRegionSublog (Z : ℕ → ℕ)
    (R : ℕ → ℕ → ℕ → ℕ → Prop) : Prop :=
  ∀ q : ℕ, 0 < q → Squarefree q →
    ∀ eps : ℝ, 0 < eps →
      ∃ H0 : ℕ, ∀ a h : ℕ,
        q.Coprime a → 0 < h → (¬ 2 ∣ q → 2 ∣ h) →
        H0 ≤ h →
        |auvrenR0056CompleteQuarter Z q a h R| ≤
          eps * Real.log (h : ℝ)

end OrielUpper.Mirror
end R0061
