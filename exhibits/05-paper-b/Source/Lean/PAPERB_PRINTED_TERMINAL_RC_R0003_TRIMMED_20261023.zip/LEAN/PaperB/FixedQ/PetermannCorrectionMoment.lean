import PaperB.FixedQ.PetermannConvolutionGlobal
import Mathlib.NumberTheory.EulerProduct.Basic
import Mathlib.Analysis.PSeries

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def petermannLocalMass (p : ℕ) : ℝ :=
  ∑' nu : ℕ, |petermannCorrectionPrimePower p (nu + 1)|

noncomputable def petermannLocalLogMoment (p : ℕ) : ℝ :=
  ∑' nu : ℕ,
    |petermannCorrectionPrimePower p (nu + 1)| *
      ((nu + 1 : ℕ) : ℝ) * Real.log p

lemma abs_petermannA_of_five_le {p : ℕ} (hp5 : 5 ≤ p) :
    |petermannA p| = 1 / ((p : ℝ) - 3) := by
  unfold petermannA
  have hpR : (5 : ℝ) ≤ p := by exact_mod_cast hp5
  have hp3 : 0 < (p : ℝ) - 3 := by linarith
  rw [abs_of_pos (one_div_pos.mpr hp3)]

lemma abs_petermannB_sub_A_of_five_le {p : ℕ} (hp5 : 5 ≤ p) :
    |petermannB p - petermannA p| =
      1 / (((p : ℝ) - 2) * ((p : ℝ) - 3)) := by
  unfold petermannA petermannB
  have hpR : (5 : ℝ) ≤ p := by exact_mod_cast hp5
  have hp2 : 0 < (p : ℝ) - 2 := by linarith
  have hp3 : 0 < (p : ℝ) - 3 := by linarith
  have hle : 1 / ((p : ℝ) - 2) - 1 / ((p : ℝ) - 3) < 0 := by
    rw [sub_neg]
    exact one_div_lt_one_div_of_lt hp3 (by linarith)
  rw [abs_of_neg hle]
  field_simp
  ring

lemma abs_petermannCorrectionPrimePower_succ_of_five_le
    {p nu : ℕ} (hp5 : 5 ≤ p) :
    |petermannCorrectionPrimePower p (nu + 1)| =
      (1 / (((p : ℝ) - 2) * ((p : ℝ) - 3))) *
        (1 / ((p : ℝ) - 3)) ^ nu := by
  rw [petermannCorrectionPrimePower_succ, abs_mul, abs_pow,
    abs_neg, abs_petermannA_of_five_le hp5,
    abs_petermannB_sub_A_of_five_le hp5]

theorem petermannLocalMass_eq
    {p : ℕ} (hp5 : 5 ≤ p) :
    petermannLocalMass p =
      1 / (((p : ℝ) - 2) * ((p : ℝ) - 4)) := by
  unfold petermannLocalMass
  rw [show (fun nu : ℕ => |petermannCorrectionPrimePower p (nu + 1)|) =
      fun nu => (1 / (((p : ℝ) - 2) * ((p : ℝ) - 3))) *
        (1 / ((p : ℝ) - 3)) ^ nu by
    funext nu
    exact abs_petermannCorrectionPrimePower_succ_of_five_le hp5]
  rw [tsum_mul_left]
  have hpR : (5 : ℝ) ≤ p := by exact_mod_cast hp5
  have hp3pos : 0 < (p : ℝ) - 3 := by linarith
  have hp3 : 1 < (p : ℝ) - 3 := by linarith
  have hr0 : 0 ≤ 1 / ((p : ℝ) - 3) := by positivity
  have hr1 : 1 / ((p : ℝ) - 3) < 1 := by
    exact (div_lt_one hp3pos).2 (by linarith)
  rw [tsum_geometric_of_lt_one hr0 hr1]
  field_simp
  ring

theorem petermannLocalMass_le
    {p : ℕ} (hp5 : 5 ≤ p) :
    petermannLocalMass p ≤ 10 / (p : ℝ)^2 := by
  rw [petermannLocalMass_eq hp5]
  have hp : (5 : ℝ) ≤ p := by exact_mod_cast hp5
  have hpPos : 0 < (p : ℝ) := by linarith
  have hp2m : 0 < (p : ℝ) - 2 := by linarith
  have hp4m : 0 < (p : ℝ) - 4 := by linarith
  have hden : 0 < ((p : ℝ) - 2) * ((p : ℝ) - 4) :=
    mul_pos hp2m hp4m
  have hp2 : 0 < (p : ℝ)^2 := sq_pos_of_pos hpPos
  rw [div_le_div_iff₀ hden hp2]
  nlinarith

#print axioms petermannLocalMass_eq
#print axioms petermannLocalMass_le

end PaperB.FixedQ

namespace PaperB.FixedQ

private lemma hasSum_succ_mul_geometric
    {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r < 1) :
    HasSum (fun n : ℕ => ((n + 1 : ℕ) : ℝ) * r ^ n)
      (1 / (1 - r)^2) := by
  have hrabs : |r| < 1 := by
    rw [abs_of_nonneg hr0]
    exact hr1
  have h1 := hasSum_coe_mul_geometric_of_norm_lt_one (r := r) hrabs
  have h2 := hasSum_geometric_of_lt_one hr0 hr1
  have hadd := h1.add h2
  convert hadd using 1
  · funext n
    norm_num [Nat.cast_add]
    ring
  · field_simp
    ring

theorem petermannLocalLogMoment_eq
    {p : ℕ} (hp5 : 5 ≤ p) :
    petermannLocalLogMoment p =
      ((p : ℝ) - 3) * Real.log p /
        (((p : ℝ) - 2) * ((p : ℝ) - 4)^2) := by
  unfold petermannLocalLogMoment
  rw [show
      (fun nu : ℕ =>
        |petermannCorrectionPrimePower p (nu + 1)| *
          ((nu + 1 : ℕ) : ℝ) * Real.log p) =
      fun nu =>
        (1 / (((p : ℝ) - 2) * ((p : ℝ) - 3))) *
          (((nu + 1 : ℕ) : ℝ) * (1 / ((p : ℝ) - 3)) ^ nu) *
            Real.log p by
    funext nu
    rw [abs_petermannCorrectionPrimePower_succ_of_five_le hp5]
    ring]
  rw [show
      (fun nu : ℕ =>
        (1 / (((p : ℝ) - 2) * ((p : ℝ) - 3))) *
          (((nu + 1 : ℕ) : ℝ) * (1 / ((p : ℝ) - 3)) ^ nu) *
            Real.log p) =
      fun nu =>
        ((1 / (((p : ℝ) - 2) * ((p : ℝ) - 3))) * Real.log p) *
          (((nu + 1 : ℕ) : ℝ) * (1 / ((p : ℝ) - 3)) ^ nu) by
    funext nu
    ring]
  rw [tsum_mul_left]
  have hpR : (5 : ℝ) ≤ p := by exact_mod_cast hp5
  have hp3pos : 0 < (p : ℝ) - 3 := by linarith
  have hr0 : 0 ≤ 1 / ((p : ℝ) - 3) := by positivity
  have hr1 : 1 / ((p : ℝ) - 3) < 1 := by
    exact (div_lt_one hp3pos).2 (by linarith)
  rw [(hasSum_succ_mul_geometric hr0 hr1).tsum_eq]
  field_simp
  ring

theorem petermannLocalLogMoment_le
    {p : ℕ} (hp5 : 5 ≤ p) :
    petermannLocalLogMoment p ≤
      20 * Real.log p / (p : ℝ)^2 := by
  rw [petermannLocalLogMoment_eq hp5]
  have hp : (5 : ℝ) ≤ p := by exact_mod_cast hp5
  have hpPos : 0 < (p : ℝ) := by linarith
  have hp2m : 0 < (p : ℝ) - 2 := by linarith
  have hp3m : 0 < (p : ℝ) - 3 := by linarith
  have hp4m : 0 < (p : ℝ) - 4 := by linarith
  have hlog : 0 ≤ Real.log p := Real.log_nonneg (by linarith)
  have hden : 0 < ((p : ℝ) - 2) * ((p : ℝ) - 4)^2 := by positivity
  have hp2 : 0 < (p : ℝ)^2 := sq_pos_of_pos hpPos
  have hcoef :
      ((p : ℝ) - 3) / (((p : ℝ) - 2) * ((p : ℝ) - 4)^2) ≤
        20 / (p : ℝ)^2 := by
    rw [div_le_div_iff₀ hden hp2]
    nlinarith [sq_nonneg ((p : ℝ) - 5)]
  calc
    ((p : ℝ) - 3) * Real.log p /
        (((p : ℝ) - 2) * ((p : ℝ) - 4)^2)
      = (((p : ℝ) - 3) /
          (((p : ℝ) - 2) * ((p : ℝ) - 4)^2)) * Real.log p := by ring
    _ ≤ (20 / (p : ℝ)^2) * Real.log p :=
      mul_le_mul_of_nonneg_right hcoef hlog
    _ = 20 * Real.log p / (p : ℝ)^2 := by ring

#print axioms petermannLocalLogMoment_eq
#print axioms petermannLocalLogMoment_le

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def petermannCorrectionPrimeSet
    (q h : ℕ) : Finset ℕ :=
  h.primeFactors.filter (fun p => p.Coprime (6 * q))

lemma mem_petermannCorrectionPrimeSet_iff
    {q h p : ℕ} :
    p ∈ petermannCorrectionPrimeSet q h ↔
      p ∈ h.primeFactors ∧ p.Coprime (6 * q) := by
  simp [petermannCorrectionPrimeSet]

lemma prime_of_mem_petermannCorrectionPrimeSet
    {q h p : ℕ} (hp : p ∈ petermannCorrectionPrimeSet q h) :
    p.Prime := by
  exact Nat.prime_of_mem_primeFactors
    (mem_petermannCorrectionPrimeSet_iff.mp hp).1

lemma dvd_height_of_mem_petermannCorrectionPrimeSet
    {q h p : ℕ} (hp : p ∈ petermannCorrectionPrimeSet q h) :
    p ∣ h := by
  exact Nat.dvd_of_mem_primeFactors
    (mem_petermannCorrectionPrimeSet_iff.mp hp).1

lemma coprime_of_mem_petermannCorrectionPrimeSet
    {q h p : ℕ} (hp : p ∈ petermannCorrectionPrimeSet q h) :
    p.Coprime (6 * q) :=
  (mem_petermannCorrectionPrimeSet_iff.mp hp).2

lemma five_le_of_mem_petermannCorrectionPrimeSet
    {q h p : ℕ} (hp : p ∈ petermannCorrectionPrimeSet q h) :
    5 ≤ p := by
  have hprime := prime_of_mem_petermannCorrectionPrimeSet hp
  have hcop := coprime_of_mem_petermannCorrectionPrimeSet hp
  have hndvd : ¬ p ∣ 6 * q :=
    hprime.coprime_iff_not_dvd.mp hcop
  have hp2 : p ≠ 2 := by
    intro h
    subst p
    apply hndvd
    exact dvd_mul_of_dvd_left (by norm_num : 2 ∣ 6) q
  have hp3 : p ≠ 3 := by
    intro h
    subst p
    apply hndvd
    exact dvd_mul_of_dvd_left (by norm_num : 3 ∣ 6) q
  have hp4 : p ≠ 4 := by
    intro h
    subst p
    exact (by decide : ¬ Nat.Prime 4) hprime
  have hpge2 : 2 ≤ p := hprime.two_le
  omega

lemma petermannCorrectionArithmetic_prime_pow_eq_of_mem
    {q h p nu : ℕ}
    (hp : p ∈ petermannCorrectionPrimeSet q h) :
    petermannCorrectionArithmetic q h (p ^ nu) =
      petermannCorrectionPrimePower p nu := by
  have hprime := prime_of_mem_petermannCorrectionPrimeSet hp
  have hcop := coprime_of_mem_petermannCorrectionPrimeSet hp
  have hdvd := dvd_height_of_mem_petermannCorrectionPrimeSet hp
  rw [petermannCorrectionArithmetic_prime_pow q h hprime]
  by_cases hnu : nu = 0
  · subst nu
    simp [petermannCorrectionPrimePower_zero]
  · simp [hnu, hcop, hdvd]

lemma summable_abs_petermannCorrectionPrimePower
    {p : ℕ} (hp5 : 5 ≤ p) :
    Summable (fun nu : ℕ => |petermannCorrectionPrimePower p nu|) := by
  have htail :
      Summable (fun nu : ℕ =>
        |petermannCorrectionPrimePower p (nu + 1)|) := by
    rw [show
        (fun nu : ℕ => |petermannCorrectionPrimePower p (nu + 1)|) =
        fun nu =>
          (1 / (((p : ℝ) - 2) * ((p : ℝ) - 3))) *
            (1 / ((p : ℝ) - 3)) ^ nu by
      funext nu
      exact abs_petermannCorrectionPrimePower_succ_of_five_le hp5]
    have hpR : (5 : ℝ) ≤ p := by exact_mod_cast hp5
    have hp3pos : 0 < (p : ℝ) - 3 := by linarith
    have hr0 : 0 ≤ 1 / ((p : ℝ) - 3) := by positivity
    have hr1 : 1 / ((p : ℝ) - 3) < 1 := by
      exact (div_lt_one hp3pos).2 (by linarith)
    exact (summable_geometric_of_lt_one hr0 hr1).mul_left _
  exact (summable_nat_add_iff 1).mp (by simpa using htail)

lemma tsum_abs_petermannCorrectionPrimePower
    {p : ℕ} (hp5 : 5 ≤ p) :
    (∑' nu : ℕ, |petermannCorrectionPrimePower p nu|) =
      1 + petermannLocalMass p := by
  have hs := summable_abs_petermannCorrectionPrimePower hp5
  rw [hs.tsum_eq_zero_add]
  simp [petermannCorrectionPrimePower_zero, petermannLocalMass]

lemma summable_abs_petermannCorrectionArithmetic_prime_pow
    (q h : ℕ) {p : ℕ} (hp : p.Prime) :
    Summable (fun nu : ℕ =>
      |petermannCorrectionArithmetic q h (p ^ nu)|) := by
  by_cases hcond : p.Coprime (6 * q) ∧ p ∣ h
  · have hndvd : ¬ p ∣ 6 * q :=
      hp.coprime_iff_not_dvd.mp hcond.1
    have hp2 : p ≠ 2 := by
      intro hh
      subst p
      apply hndvd
      exact dvd_mul_of_dvd_left (by norm_num : 2 ∣ 6) q
    have hp3 : p ≠ 3 := by
      intro hh
      subst p
      apply hndvd
      exact dvd_mul_of_dvd_left (by norm_num : 3 ∣ 6) q
    have hp4 : p ≠ 4 := by
      intro hh
      subst p
      exact (by decide : ¬ Nat.Prime 4) hp
    have hp5 : 5 ≤ p := by
      have hpge2 : 2 ≤ p := hp.two_le
      omega
    exact (summable_abs_petermannCorrectionPrimePower hp5).congr
      (fun nu => by
        rw [petermannCorrectionArithmetic_prime_pow q h hp]
        by_cases hnu : nu = 0
        · subst nu
          simp [petermannCorrectionPrimePower_zero]
        · rw [if_neg hnu, if_pos hcond])
  · have hfin :
        (fun nu : ℕ =>
          |petermannCorrectionArithmetic q h (p ^ nu)|) =
        fun nu => if nu = 0 then 1 else 0 := by
      funext nu
      rw [petermannCorrectionArithmetic_prime_pow q h hp]
      by_cases hnu : nu = 0
      · subst nu
        simp
      · rw [if_neg hnu, if_neg hcond, if_neg hnu]
        simp
    rw [hfin]
    exact (hasSum_ite_eq 0 (1 : ℝ)).summable

#print axioms summable_abs_petermannCorrectionPrimePower
#print axioms tsum_abs_petermannCorrectionPrimePower
#print axioms summable_abs_petermannCorrectionArithmetic_prime_pow

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma petermannCorrectionArithmetic_eq_zero_of_not_factored
    {q h n : ℕ} (hh : h ≠ 0)
    (hn : n ∉ Nat.factoredNumbers (petermannCorrectionPrimeSet q h)) :
    petermannCorrectionArithmetic q h n = 0 := by
  by_cases hn0 : n = 0
  · subst n
    simp
  · have hnsub :
        ¬ n.primeFactors ⊆ petermannCorrectionPrimeSet q h := by
      intro hs
      apply hn
      exact Nat.mem_factoredNumbers_iff_primeFactors_subset.mpr ⟨hn0, hs⟩
    rw [Finset.not_subset] at hnsub
    rcases hnsub with ⟨p, hpn, hpnot⟩
    rw [petermannCorrectionArithmetic_apply, petermannCorrectionCoeff, if_neg hn0]
    apply Finset.prod_eq_zero hpn
    unfold petermannCorrectionLocal
    have hpprime : p.Prime := Nat.prime_of_mem_primeFactors hpn
    have hpdvdn : p ∣ n := Nat.dvd_of_mem_primeFactors hpn
    have hnu : n.factorization p ≠ 0 :=
      (hpprime.factorization_pos_of_dvd hn0 hpdvdn).ne'
    rw [if_neg hnu]
    have hnot : ¬ (p.Prime ∧ p.Coprime (6 * q) ∧ p ∣ h) := by
      intro hcond
      apply hpnot
      rw [mem_petermannCorrectionPrimeSet_iff]
      refine ⟨?_, hcond.2.1⟩
      exact Nat.mem_primeFactors.mpr ⟨hpprime, hcond.2.2, hh⟩
    rw [if_neg hnot]

lemma petermannCorrectionAbs_mul_of_coprime
    (q h : ℕ) {m n : ℕ} (hmn : m.Coprime n) :
    |petermannCorrectionArithmetic q h (m * n)| =
      |petermannCorrectionArithmetic q h m| *
        |petermannCorrectionArithmetic q h n| := by
  rw [(petermannCorrectionArithmetic_multiplicative q h).map_mul_of_coprime hmn,
    abs_mul]

lemma petermannCorrectionAbs_one (q h : ℕ) :
    |petermannCorrectionArithmetic q h 1| = 1 := by
  simp [petermannCorrectionArithmetic, petermannCorrectionCoeff]

theorem summable_abs_petermannCorrectionArithmetic
    (q h : ℕ) (hh : h ≠ 0) :
    Summable (fun n : ℕ => |petermannCorrectionArithmetic q h n|) := by
  let s := petermannCorrectionPrimeSet q h
  let f : ℕ → ℝ := fun n => |petermannCorrectionArithmetic q h n|
  have hs := EulerProduct.summable_and_hasSum_factoredNumbers_prod_filter_prime_tsum
    (f := f)
    (petermannCorrectionAbs_one q h)
    (fun {_m _n} hcop => petermannCorrectionAbs_mul_of_coprime q h hcop)
    (fun {_p} hp => by
      simpa [f, Real.norm_eq_abs] using
        summable_abs_petermannCorrectionArithmetic_prime_pow q h hp)
    s
  have hsub :
      Summable (fun m : Nat.factoredNumbers s => f m) := by
    simpa [f, Real.norm_eq_abs] using hs.1
  have hind :
      Summable ((Nat.factoredNumbers s).indicator f) :=
    (summable_subtype_iff_indicator.mp hsub)
  exact hind.congr (fun n => by
    by_cases hnmem : n ∈ Nat.factoredNumbers s
    · simp [Set.indicator, hnmem, f, petermannCorrectionArithmetic_apply]
    · have hz :
          petermannCorrectionArithmetic q h n = 0 := by
        apply petermannCorrectionArithmetic_eq_zero_of_not_factored hh
        simpa [s] using hnmem
      simp [Set.indicator, hnmem, f, hz,
        petermannCorrectionArithmetic_apply])

noncomputable def petermannCorrectionL1UniformBound : ℝ :=
  ∑' s : Finset ℕ, ∏ p ∈ s, 10 / (p : ℝ)^2

lemma summable_petermannPrimeMajorant :
    Summable (fun p : ℕ => 10 / (p : ℝ)^2) := by
  have hs :
      Summable (fun p : ℕ => (10 : ℝ) * (1 / (p : ℝ)^2)) :=
    (Real.summable_one_div_nat_pow.mpr (by norm_num : 1 < (2 : ℕ))).mul_left 10
  simpa [div_eq_mul_inv] using hs

lemma summable_petermannFinsetMajorant :
    Summable (fun s : Finset ℕ => ∏ p ∈ s, 10 / (p : ℝ)^2) := by
  exact summable_finsetProd_of_summable_norm
    (by
      simpa [Real.norm_eq_abs, abs_of_nonneg (by positivity : ∀ p : ℕ, 0 ≤ 10 / (p : ℝ)^2)]
        using summable_petermannPrimeMajorant)

lemma petermannLocalMass_nonneg (p : ℕ) :
    0 ≤ petermannLocalMass p := by
  unfold petermannLocalMass
  exact tsum_nonneg (fun _ => abs_nonneg _)

theorem petermannCorrectionL1_tsum_eq_prod
    (q h : ℕ) (hh : h ≠ 0) :
    (∑' n : ℕ, |petermannCorrectionArithmetic q h n|) =
      ∏ p ∈ petermannCorrectionPrimeSet q h, (1 + petermannLocalMass p) := by
  let s := petermannCorrectionPrimeSet q h
  let f : ℕ → ℝ := fun n => |petermannCorrectionArithmetic q h n|
  have hs := EulerProduct.summable_and_hasSum_factoredNumbers_prod_filter_prime_tsum
    (f := f)
    (petermannCorrectionAbs_one q h)
    (fun {_m _n} hcop => petermannCorrectionAbs_mul_of_coprime q h hcop)
    (fun {_p} hp => by
      simpa [f, Real.norm_eq_abs] using
        summable_abs_petermannCorrectionArithmetic_prime_pow q h hp)
    s
  have hlocal :
      ∀ p ∈ s, (∑' nu : ℕ, f (p ^ nu)) = 1 + petermannLocalMass p := by
    intro p hp
    have hp5 : 5 ≤ p := by
      apply five_le_of_mem_petermannCorrectionPrimeSet
      simpa [s] using hp
    have hpeq :
        ∀ nu : ℕ, f (p ^ nu) = |petermannCorrectionPrimePower p nu| := by
      intro nu
      simp only [f]
      rw [petermannCorrectionArithmetic_prime_pow_eq_of_mem
        (by simpa [s] using hp)]
    rw [show (fun nu : ℕ => f (p ^ nu)) =
        fun nu => |petermannCorrectionPrimePower p nu| by
      funext nu
      exact hpeq nu]
    exact tsum_abs_petermannCorrectionPrimePower hp5
  have hprod :
      (∏ p ∈ s with p.Prime, ∑' nu : ℕ, f (p ^ nu)) =
        ∏ p ∈ s, (1 + petermannLocalMass p) := by
    have hprime : ∀ p ∈ s, p.Prime := by
      intro p hp
      apply prime_of_mem_petermannCorrectionPrimeSet
      simpa [s] using hp
    rw [Finset.filter_eq_self.mpr hprime]
    apply Finset.prod_congr rfl
    intro p hp
    exact hlocal p hp
  have hsubtsum :
      (∑' m : Nat.factoredNumbers s, f m) =
        ∏ p ∈ s, (1 + petermannLocalMass p) := by
    rw [← hprod]
    exact hs.2.tsum_eq
  have hglobal := summable_abs_petermannCorrectionArithmetic q h hh
  calc
    (∑' n : ℕ, |petermannCorrectionArithmetic q h n|)
      = ∑' n : ℕ, f n := rfl
    _ = ∑' m : Nat.factoredNumbers s, f m := by
      rw [tsum_subtype]
      apply tsum_congr
      intro n
      by_cases hnmem : n ∈ Nat.factoredNumbers s
      · simp [Set.indicator, hnmem, f, petermannCorrectionArithmetic_apply]
      · have hz : petermannCorrectionArithmetic q h n = 0 := by
          apply petermannCorrectionArithmetic_eq_zero_of_not_factored hh
          simpa [s] using hnmem
        have hz' : petermannCorrectionCoeff q h n = 0 := by
          simpa [petermannCorrectionArithmetic_apply] using hz
        simp [Set.indicator, hnmem, f, hz, hz',
          petermannCorrectionArithmetic_apply]
    _ = ∏ p ∈ s, (1 + petermannLocalMass p) := hsubtsum
    _ = ∏ p ∈ petermannCorrectionPrimeSet q h,
          (1 + petermannLocalMass p) := by rfl

theorem petermannCorrectionL1_uniform_le
    (q h : ℕ) (hh : h ≠ 0) :
    (∑' n : ℕ, |petermannCorrectionArithmetic q h n|) ≤
      petermannCorrectionL1UniformBound := by
  rw [petermannCorrectionL1_tsum_eq_prod q h hh]
  let s := petermannCorrectionPrimeSet q h
  have hprod :
      (∏ p ∈ s, (1 + petermannLocalMass p)) =
        ∑ t ∈ s.powerset, ∏ p ∈ t, petermannLocalMass p := by
    simpa [add_comm] using
      (Finset.prod_add
        (fun p : ℕ => petermannLocalMass p)
        (fun _p : ℕ => (1 : ℝ)) s)
  rw [show (∏ p ∈ petermannCorrectionPrimeSet q h,
      (1 + petermannLocalMass p)) =
      ∏ p ∈ s, (1 + petermannLocalMass p) by rfl, hprod]
  have hterm :
      ∀ t ∈ s.powerset,
        (∏ p ∈ t, petermannLocalMass p) ≤
          ∏ p ∈ t, 10 / (p : ℝ)^2 := by
    intro t ht
    have hsubset : t ⊆ s := Finset.mem_powerset.mp ht
    induction t using Finset.induction_on with
    | empty => simp
    | @insert p t hpnot ih =>
        have hps : p ∈ s := hsubset (by simp)
        have htsub : t ⊆ s := by
          intro x hx
          exact hsubset (by simp [hx])
        have hp5 : 5 ≤ p := by
          apply five_le_of_mem_petermannCorrectionPrimeSet
          simpa [s] using hps
        have hpmass := petermannLocalMass_le hp5
        have hmass_nonneg := petermannLocalMass_nonneg p
        have hmaj_nonneg : 0 ≤ 10 / (p : ℝ)^2 := by positivity
        rw [Finset.prod_insert hpnot, Finset.prod_insert hpnot]
        exact mul_le_mul hpmass
          ((ih (Finset.mem_powerset.mpr htsub)) htsub)
          (Finset.prod_nonneg (fun x hx => petermannLocalMass_nonneg x))
          hmaj_nonneg
  calc
    (∑ t ∈ s.powerset, ∏ p ∈ t, petermannLocalMass p)
      ≤ ∑ t ∈ s.powerset, ∏ p ∈ t, 10 / (p : ℝ)^2 := by
        exact Finset.sum_le_sum (fun t ht => hterm t ht)
    _ ≤ petermannCorrectionL1UniformBound := by
      unfold petermannCorrectionL1UniformBound
      exact (summable_petermannFinsetMajorant.sum_le_tsum
        s.powerset (fun t ht => by
          exact Finset.prod_nonneg (fun p hp => by positivity)))

#print axioms petermannCorrectionArithmetic_eq_zero_of_not_factored
#print axioms summable_abs_petermannCorrectionArithmetic
#print axioms petermannCorrectionL1_tsum_eq_prod
#print axioms petermannCorrectionL1_uniform_le

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma summable_abs_petermannCorrectionPrimePower_log
    {p : ℕ} (hp5 : 5 ≤ p) :
    Summable (fun nu : ℕ =>
      |petermannCorrectionPrimePower p nu| *
        (nu : ℝ) * Real.log p) := by
  have htail :
      Summable (fun nu : ℕ =>
        |petermannCorrectionPrimePower p (nu + 1)| *
          ((nu + 1 : ℕ) : ℝ) * Real.log p) := by
    rw [show
        (fun nu : ℕ =>
          |petermannCorrectionPrimePower p (nu + 1)| *
            ((nu + 1 : ℕ) : ℝ) * Real.log p) =
        fun nu =>
          (1 / (((p : ℝ) - 2) * ((p : ℝ) - 3))) *
            (((nu + 1 : ℕ) : ℝ) * (1 / ((p : ℝ) - 3)) ^ nu) *
              Real.log p by
      funext nu
      rw [abs_petermannCorrectionPrimePower_succ_of_five_le hp5]
      ring]
    have hpR : (5 : ℝ) ≤ p := by exact_mod_cast hp5
    have hp3pos : 0 < (p : ℝ) - 3 := by linarith
    have hr0 : 0 ≤ 1 / ((p : ℝ) - 3) := by positivity
    have hr1 : 1 / ((p : ℝ) - 3) < 1 := by
      exact (div_lt_one hp3pos).2 (by linarith)
    have hs :=
      (hasSum_succ_mul_geometric hr0 hr1).summable
    exact (hs.mul_left
      (1 / (((p : ℝ) - 2) * ((p : ℝ) - 3)))).mul_right
        (Real.log p)
  exact (summable_nat_add_iff 1).mp (by simpa using htail)

lemma tsum_abs_petermannCorrectionPrimePower_log
    {p : ℕ} (hp5 : 5 ≤ p) :
    (∑' nu : ℕ,
      |petermannCorrectionPrimePower p nu| *
        (nu : ℝ) * Real.log p) =
      petermannLocalLogMoment p := by
  have hs := summable_abs_petermannCorrectionPrimePower_log hp5
  rw [hs.tsum_eq_zero_add]
  simp [petermannLocalLogMoment]

lemma petermannCorrectionArithmetic_prime_log_tsum_eq
    {q h p : ℕ}
    (hp : p ∈ petermannCorrectionPrimeSet q h) :
    (∑' nu : ℕ,
      |petermannCorrectionArithmetic q h (p ^ nu)| *
        (nu : ℝ) * Real.log p) =
      petermannLocalLogMoment p := by
  have hp5 := five_le_of_mem_petermannCorrectionPrimeSet hp
  rw [show
      (fun nu : ℕ =>
        |petermannCorrectionArithmetic q h (p ^ nu)| *
          (nu : ℝ) * Real.log p) =
      fun nu =>
        |petermannCorrectionPrimePower p nu| *
          (nu : ℝ) * Real.log p by
    funext nu
    rw [petermannCorrectionArithmetic_prime_pow_eq_of_mem hp]]
  exact tsum_abs_petermannCorrectionPrimePower_log hp5

#print axioms summable_abs_petermannCorrectionPrimePower_log
#print axioms tsum_abs_petermannCorrectionPrimePower_log
#print axioms petermannCorrectionArithmetic_prime_log_tsum_eq

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def petermannFactoredLogMoment
    (q h : ℕ) (s : Finset ℕ) : ℝ :=
  ∑' m : Nat.factoredNumbers s,
    |petermannCorrectionArithmetic q h m| * Real.log (m : ℕ)

lemma petermannLocalLogMoment_nonneg
    {p : ℕ} (hp5 : 5 ≤ p) :
    0 ≤ petermannLocalLogMoment p := by
  unfold petermannLocalLogMoment
  apply tsum_nonneg
  intro nu
  have hpR : (5 : ℝ) ≤ p := by exact_mod_cast hp5
  have hlog : 0 ≤ Real.log p := Real.log_nonneg (by linarith)
  positivity

lemma log_prime_pow_mul_factored
    {p : ℕ} (hp : p.Prime) {s : Finset ℕ}
    (nu : ℕ) (m : Nat.factoredNumbers s) :
    Real.log (((p : ℝ) ^ nu) * ((m : ℕ) : ℝ)) =
      (nu : ℝ) * Real.log p + Real.log (m : ℕ) := by
  have hp0 : (p : ℝ) ≠ 0 := by exact_mod_cast hp.ne_zero
  have hm0n : (m : ℕ) ≠ 0 := Nat.ne_zero_of_mem_factoredNumbers m.property
  have hm0 : ((m : ℕ) : ℝ) ≠ 0 := by exact_mod_cast hm0n
  rw [Real.log_mul (pow_ne_zero _ hp0) hm0, Real.log_pow]

lemma summable_active_prime_log_sequence
    {q h p : ℕ} (hp : p ∈ petermannCorrectionPrimeSet q h) :
    Summable (fun nu : ℕ =>
      |petermannCorrectionArithmetic q h (p ^ nu)| *
        (nu : ℝ) * Real.log p) := by
  have hp5 := five_le_of_mem_petermannCorrectionPrimeSet hp
  exact (summable_abs_petermannCorrectionPrimePower_log hp5).congr
    (fun nu => by
      rw [petermannCorrectionArithmetic_prime_pow_eq_of_mem hp])

lemma petermannFactoredMass_eq_prod
    (q h : ℕ) (s : Finset ℕ)
    (hsactive : s ⊆ petermannCorrectionPrimeSet q h) :
    (∑' m : Nat.factoredNumbers s,
      |petermannCorrectionArithmetic q h m|) =
      ∏ p ∈ s, (1 + petermannLocalMass p) := by
  let f : ℕ → ℝ := fun n => |petermannCorrectionArithmetic q h n|
  have he :=
    EulerProduct.summable_and_hasSum_factoredNumbers_prod_filter_prime_tsum
      (f := f)
      (petermannCorrectionAbs_one q h)
      (fun {_m _n} hcop => petermannCorrectionAbs_mul_of_coprime q h hcop)
      (fun {_p} hp => by
        simpa [f, Real.norm_eq_abs] using
          summable_abs_petermannCorrectionArithmetic_prime_pow q h hp)
      s
  have hprime : ∀ p ∈ s, p.Prime := by
    intro p hp
    exact prime_of_mem_petermannCorrectionPrimeSet (hsactive hp)
  change (∑' m : Nat.factoredNumbers s, f m) =
      ∏ p ∈ s, (1 + petermannLocalMass p)
  have heq :
      (∑' m : Nat.factoredNumbers s, f m) =
        ∏ p ∈ s with p.Prime, ∑' n : ℕ, f (p ^ n) :=
    he.2.tsum_eq
  rw [heq, Finset.filter_eq_self.mpr hprime]
  apply Finset.prod_congr rfl
  intro p hp
  have hpa := hsactive hp
  have hp5 := five_le_of_mem_petermannCorrectionPrimeSet hpa
  rw [show
      (fun nu : ℕ => f (p ^ nu)) =
      fun nu => |petermannCorrectionPrimePower p nu| by
    funext nu
    simp only [f]
    rw [petermannCorrectionArithmetic_prime_pow_eq_of_mem hpa]]
  exact tsum_abs_petermannCorrectionPrimePower hp5

theorem petermannFactoredLogMoment_bound
    (q h : ℕ) (s : Finset ℕ)
    (hsactive : s ⊆ petermannCorrectionPrimeSet q h) :
    Summable (fun m : Nat.factoredNumbers s =>
      |petermannCorrectionArithmetic q h m| * Real.log (m : ℕ)) ∧
    petermannFactoredLogMoment q h s ≤
      (∏ p ∈ s, (1 + petermannLocalMass p)) *
        (∑ p ∈ s, petermannLocalLogMoment p) := by
  induction s using Finset.induction_on with
  | empty =>
      have hset : Nat.factoredNumbers (∅ : Finset ℕ) = ({1} : Set ℕ) :=
        Nat.factoredNumbers_empty
      constructor
      · rw [hset]
        exact (Set.finite_singleton 1).summable
          (fun n : ℕ =>
            |petermannCorrectionArithmetic q h n| * Real.log n)
      · unfold petermannFactoredLogMoment
        rw [hset]
        simp
  | @insert p s hpnot ih =>
      have hpa : p ∈ petermannCorrectionPrimeSet q h :=
        hsactive (by simp)
      have hpsactive : s ⊆ petermannCorrectionPrimeSet q h := by
        intro x hx
        exact hsactive (by simp [hx])
      have hpprime := prime_of_mem_petermannCorrectionPrimeSet hpa
      have hp5 := five_le_of_mem_petermannCorrectionPrimeSet hpa
      obtain ⟨ihsum, ihbound⟩ := ih hpsactive
      let f : ℕ → ℝ := fun n => |petermannCorrectionArithmetic q h n|
      let g : Nat.factoredNumbers s → ℝ :=
        fun m => f m * Real.log (m : ℕ)
      have hmassSub :
          Summable (fun m : Nat.factoredNumbers s => f m) := by
        have he :=
          EulerProduct.summable_and_hasSum_factoredNumbers_prod_filter_prime_tsum
            (f := f)
            (petermannCorrectionAbs_one q h)
            (fun {_m _n} hcop => petermannCorrectionAbs_mul_of_coprime q h hcop)
            (fun {_p} hp => by
              simpa [f, Real.norm_eq_abs] using
                summable_abs_petermannCorrectionArithmetic_prime_pow q h hp)
            s
        simpa [Real.norm_eq_abs, f, abs_of_nonneg] using he.1
      have hlocalMass :
          Summable (fun nu : ℕ => f (p ^ nu)) := by
        simpa [f, abs_of_nonneg] using
          summable_abs_petermannCorrectionArithmetic_prime_pow q h hpprime
      have hlocalLog :
          Summable (fun nu : ℕ =>
            f (p ^ nu) * (nu : ℝ) * Real.log p) := by
        simpa [f] using summable_active_prime_log_sequence hpa
      have hg : Summable g := by
        simpa [g, f] using ihsum
      have hterm1 :
          Summable (fun x : ℕ × Nat.factoredNumbers s =>
            (f (p ^ x.1) * (x.1 : ℝ) * Real.log p) * f x.2) := by
        apply Summable.mul_of_nonneg hlocalLog hmassSub
        · intro nu
          have hlog : 0 ≤ Real.log p :=
            Real.log_nonneg (by exact_mod_cast hpprime.one_le)
          positivity
        · intro m
          exact abs_nonneg _
      have hterm2 :
          Summable (fun x : ℕ × Nat.factoredNumbers s =>
            f (p ^ x.1) * g x.2) := by
        apply Summable.mul_of_nonneg hlocalMass hg
        · intro nu
          exact abs_nonneg _
        · intro m
          have hm1 : 1 ≤ (m : ℕ) :=
            Nat.one_le_iff_ne_zero.mpr
              (Nat.ne_zero_of_mem_factoredNumbers m.property)
          have hlogm : 0 ≤ Real.log (m : ℕ) :=
            Real.log_nonneg (by exact_mod_cast hm1)
          change 0 ≤ f m * Real.log (m : ℕ)
          exact mul_nonneg (abs_nonneg _) hlogm
      have hpair :
          Summable (fun x : ℕ × Nat.factoredNumbers s =>
            |petermannCorrectionArithmetic q h
                (p ^ x.1 * (x.2 : ℕ))| *
              Real.log (p ^ x.1 * (x.2 : ℕ))) := by
        have hadd := hterm1.add hterm2
        exact hadd.congr (fun x => by
          have hcop :=
            hpprime.factoredNumbers_coprime hpnot x.2.property
          rw [(petermannCorrectionArithmetic_multiplicative q h).map_mul_of_coprime
                (Nat.Coprime.pow_left _ hcop),
              abs_mul,
              log_prime_pow_mul_factored hpprime x.1 x.2]
          simp only [f, g]
          ring)
      have hins :
          Summable (fun m : Nat.factoredNumbers (insert p s) =>
            |petermannCorrectionArithmetic q h m| *
              Real.log (m : ℕ)) := by
        rw [← (Nat.equivProdNatFactoredNumbers hpprime hpnot).summable_iff]
        simpa [Function.comp_def, Nat.equivProdNatFactoredNumbers_apply'] using hpair
      constructor
      · exact hins
      · unfold petermannFactoredLogMoment
        rw [← (Nat.equivProdNatFactoredNumbers hpprime hpnot).tsum_eq]
        simp_rw [Nat.equivProdNatFactoredNumbers_apply']
        have hsplit :
            (∑' x : ℕ × Nat.factoredNumbers s,
              |petermannCorrectionArithmetic q h
                  (p ^ x.1 * (x.2 : ℕ))| *
                Real.log (p ^ x.1 * (x.2 : ℕ))) =
            (∑' x : ℕ × Nat.factoredNumbers s,
              (f (p ^ x.1) * (x.1 : ℝ) * Real.log p) * f x.2) +
            (∑' x : ℕ × Nat.factoredNumbers s,
              f (p ^ x.1) * g x.2) := by
          rw [← hterm1.tsum_add hterm2]
          apply tsum_congr
          intro x
          have hcop :=
            hpprime.factoredNumbers_coprime hpnot x.2.property
          rw [(petermannCorrectionArithmetic_multiplicative q h).map_mul_of_coprime
                (Nat.Coprime.pow_left _ hcop),
              abs_mul,
              log_prime_pow_mul_factored hpprime x.1 x.2]
          simp only [f, g]
          ring
        have hsplit' :
            (∑' x : ℕ × Nat.factoredNumbers s,
              |petermannCorrectionArithmetic q h
                  (p ^ x.1 * (x.2 : ℕ))| *
                Real.log ((p ^ x.1 * (x.2 : ℕ) : ℕ) : ℝ)) =
            (∑' x : ℕ × Nat.factoredNumbers s,
              (f (p ^ x.1) * (x.1 : ℝ) * Real.log p) * f x.2) +
            (∑' x : ℕ × Nat.factoredNumbers s,
              f (p ^ x.1) * g x.2) := by
          simpa [Nat.cast_mul, Nat.cast_pow] using hsplit
        have hmassEq := petermannFactoredMass_eq_prod q h s hpsactive
        have hlocalMassEq :
            (∑' nu : ℕ, f (p ^ nu)) =
              1 + petermannLocalMass p := by
          rw [show (fun nu : ℕ => f (p ^ nu)) =
              fun nu => |petermannCorrectionPrimePower p nu| by
            funext nu
            simp only [f]
            rw [petermannCorrectionArithmetic_prime_pow_eq_of_mem hpa]]
          exact tsum_abs_petermannCorrectionPrimePower hp5
        have hgEq :
            (∑' m : Nat.factoredNumbers s, g m) =
              petermannFactoredLogMoment q h s := by
          rfl
        have hprimeLogEq :
            (∑' nu : ℕ,
              f (p ^ nu) * (nu : ℝ) * Real.log p) =
              petermannLocalLogMoment p := by
          simpa [f] using
            petermannCorrectionArithmetic_prime_log_tsum_eq hpa
        have hterm1Eval :
            (∑' x : ℕ × Nat.factoredNumbers s,
              (f (p ^ x.1) * (x.1 : ℝ) * Real.log p) * f x.2) =
              petermannLocalLogMoment p *
                (∏ r ∈ s, (1 + petermannLocalMass r)) := by
          rw [hterm1.tsum_prod]
          calc
            (∑' nu : ℕ, ∑' m : Nat.factoredNumbers s,
                (f (p ^ nu) * (nu : ℝ) * Real.log p) * f m)
              = ∑' nu : ℕ,
                  (f (p ^ nu) * (nu : ℝ) * Real.log p) *
                    (∑' m : Nat.factoredNumbers s, f m) := by
                      apply tsum_congr
                      intro nu
                      rw [tsum_mul_left]
            _ = (∑' nu : ℕ,
                  f (p ^ nu) * (nu : ℝ) * Real.log p) *
                    (∑' m : Nat.factoredNumbers s, f m) := by
                      rw [tsum_mul_right]
            _ = _ := by rw [hprimeLogEq, hmassEq]
        have hterm2Eval :
            (∑' x : ℕ × Nat.factoredNumbers s,
              f (p ^ x.1) * g x.2) =
              (1 + petermannLocalMass p) *
                petermannFactoredLogMoment q h s := by
          rw [hterm2.tsum_prod]
          calc
            (∑' nu : ℕ, ∑' m : Nat.factoredNumbers s,
                f (p ^ nu) * g m)
              = ∑' nu : ℕ,
                  f (p ^ nu) * (∑' m : Nat.factoredNumbers s, g m) := by
                      apply tsum_congr
                      intro nu
                      rw [tsum_mul_left]
            _ = (∑' nu : ℕ, f (p ^ nu)) *
                  (∑' m : Nat.factoredNumbers s, g m) := by
                    rw [tsum_mul_right]
            _ = _ := by rw [hlocalMassEq, hgEq]
        rw [hsplit', hterm1Eval, hterm2Eval,
          Finset.prod_insert hpnot, Finset.sum_insert hpnot]
        have hA : 1 ≤ 1 + petermannLocalMass p := by
          linarith [petermannLocalMass_nonneg p]
        have hB : 0 ≤ petermannLocalLogMoment p :=
          petermannLocalLogMoment_nonneg hp5
        have hProd : 0 ≤ ∏ r ∈ s, (1 + petermannLocalMass r) := by
          apply Finset.prod_nonneg
          intro r hr
          linarith [petermannLocalMass_nonneg r]
        have hSum : 0 ≤ ∑ r ∈ s, petermannLocalLogMoment r := by
          apply Finset.sum_nonneg
          intro r hr
          have hr5 := five_le_of_mem_petermannCorrectionPrimeSet (hpsactive hr)
          exact petermannLocalLogMoment_nonneg hr5
        calc
          petermannLocalLogMoment p *
                (∏ r ∈ s, (1 + petermannLocalMass r)) +
              (1 + petermannLocalMass p) *
                petermannFactoredLogMoment q h s
            ≤ petermannLocalLogMoment p *
                (∏ r ∈ s, (1 + petermannLocalMass r)) +
              (1 + petermannLocalMass p) *
                ((∏ r ∈ s, (1 + petermannLocalMass r)) *
                  (∑ r ∈ s, petermannLocalLogMoment r)) := by
                    gcongr
            _ ≤ (1 + petermannLocalMass p) *
                (∏ r ∈ s, (1 + petermannLocalMass r)) *
                  (petermannLocalLogMoment p +
                    ∑ r ∈ s, petermannLocalLogMoment r) := by
                    have hBP : 0 ≤
                        petermannLocalLogMoment p *
                          (∏ r ∈ s, (1 + petermannLocalMass r)) :=
                      mul_nonneg hB hProd
                    have hscale :
                        petermannLocalLogMoment p *
                            (∏ r ∈ s, (1 + petermannLocalMass r)) ≤
                          (1 + petermannLocalMass p) *
                            (petermannLocalLogMoment p *
                              (∏ r ∈ s, (1 + petermannLocalMass r))) := by
                      simpa using mul_le_mul_of_nonneg_right hA hBP
                    calc
                      petermannLocalLogMoment p *
                            (∏ r ∈ s, (1 + petermannLocalMass r)) +
                          (1 + petermannLocalMass p) *
                            ((∏ r ∈ s, (1 + petermannLocalMass r)) *
                              (∑ r ∈ s, petermannLocalLogMoment r))
                        ≤ (1 + petermannLocalMass p) *
                              (petermannLocalLogMoment p *
                                (∏ r ∈ s, (1 + petermannLocalMass r))) +
                            (1 + petermannLocalMass p) *
                              ((∏ r ∈ s, (1 + petermannLocalMass r)) *
                                (∑ r ∈ s, petermannLocalLogMoment r)) :=
                          add_le_add hscale (le_refl _)
                      _ = _ := by ring
            _ = _ := by ring

#print axioms petermannFactoredLogMoment_bound

end PaperB.FixedQ

namespace PaperB.FixedQ

open Filter Asymptotics

lemma summable_log_div_sq :
    Summable (fun n : ℕ => Real.log (n : ℝ) / (n : ℝ)^2) := by
  have hlog :
      (fun n : ℕ => Real.log (n : ℝ)) =O[Filter.atTop]
        (fun n : ℕ => (n : ℝ) ^ (1 / 2 : ℝ)) := by
    exact
      (isLittleO_log_rpow_atTop
        (by norm_num : (0 : ℝ) < 1 / 2)).isBigO.comp_tendsto
        tendsto_natCast_atTop_atTop
  have hpow :
      (fun n : ℕ => (n : ℝ) ^ (-2 : ℝ)) =O[Filter.atTop]
        (fun n : ℕ => (n : ℝ) ^ (-2 : ℝ)) :=
    isBigO_refl _ _
  have hmul := hlog.mul hpow
  have hbig :
      (fun n : ℕ => Real.log (n : ℝ) * (n : ℝ) ^ (-2 : ℝ))
        =O[Filter.atTop]
      (fun n : ℕ => (n : ℝ) ^ (-3 / 2 : ℝ)) := by
    apply hmul.congr' EventuallyEq.rfl
    filter_upwards [eventually_atTop.2 ⟨1, fun n hn => hn⟩] with n hn
    have hn0 : (0 : ℝ) < n := by exact_mod_cast hn
    rw [← Real.rpow_add hn0]
    congr 1
    norm_num
  have hs :
      Summable (fun n : ℕ =>
        Real.log (n : ℝ) * (n : ℝ) ^ (-2 : ℝ)) := by
    apply summable_of_isBigO_nat
      (Real.summable_nat_rpow.mpr
        (by norm_num : (-3 / 2 : ℝ) < -1))
    exact hbig
  exact hs.congr (fun n => by
    have hnnonneg : (0 : ℝ) ≤ n := by positivity
    rw [show (-2 : ℝ) = -(2 : ℝ) by norm_num,
      Real.rpow_neg hnnonneg]
    simp [div_eq_mul_inv])

lemma summable_petermannLogPrimeMajorant :
    Summable (fun p : ℕ =>
      20 * Real.log p / (p : ℝ)^2) := by
  exact (summable_log_div_sq.mul_left 20).congr (fun p => by ring)

lemma petermannLogPrimeMajorant_nonneg (p : ℕ) :
    0 ≤ 20 * Real.log p / (p : ℝ)^2 := by
  by_cases hp0 : p = 0
  · subst p
    simp
  · have hp1 : 1 ≤ p := Nat.one_le_iff_ne_zero.mpr hp0
    have hlog : 0 ≤ Real.log p := Real.log_nonneg (by exact_mod_cast hp1)
    positivity

noncomputable def petermannCorrectionLogUniformBound : ℝ :=
  petermannCorrectionL1UniformBound *
    ∑' p : ℕ, 20 * Real.log p / (p : ℝ)^2

theorem summable_abs_petermannCorrectionArithmetic_log
    (q h : ℕ) (hh : h ≠ 0) :
    Summable (fun n : ℕ =>
      |petermannCorrectionArithmetic q h n| * Real.log n) := by
  let s := petermannCorrectionPrimeSet q h
  have hsub :
      Summable (fun m : Nat.factoredNumbers s =>
        |petermannCorrectionArithmetic q h m| * Real.log (m : ℕ)) :=
    (petermannFactoredLogMoment_bound q h s (by
      intro p hp
      simpa [s] using hp)).1
  have hind :
      Summable ((Nat.factoredNumbers s).indicator
        (fun n : ℕ =>
          |petermannCorrectionArithmetic q h n| * Real.log n)) :=
    summable_subtype_iff_indicator.mp hsub
  exact hind.congr (fun n => by
    by_cases hnmem : n ∈ Nat.factoredNumbers s
    · simp [Set.indicator, hnmem]
    · have hz : petermannCorrectionArithmetic q h n = 0 := by
        apply petermannCorrectionArithmetic_eq_zero_of_not_factored hh
        simpa [s] using hnmem
      simp [Set.indicator, hnmem, hz])

theorem petermannCorrectionLog_tsum_eq_factored
    (q h : ℕ) (hh : h ≠ 0) :
    (∑' n : ℕ,
      |petermannCorrectionArithmetic q h n| * Real.log n) =
    petermannFactoredLogMoment q h
      (petermannCorrectionPrimeSet q h) := by
  let s := petermannCorrectionPrimeSet q h
  change
    (∑' n : ℕ,
      |petermannCorrectionArithmetic q h n| * Real.log n) =
    ∑' m : Nat.factoredNumbers s,
      |petermannCorrectionArithmetic q h m| * Real.log (m : ℕ)
  have hsupp :
      Function.support
        (fun n : ℕ =>
          |petermannCorrectionArithmetic q h n| * Real.log n) ⊆
        Nat.factoredNumbers s := by
    intro n hn
    by_contra hnmem
    have hz : petermannCorrectionArithmetic q h n = 0 := by
      apply petermannCorrectionArithmetic_eq_zero_of_not_factored hh
      simpa [s] using hnmem
    apply hn
    simp [hz]
  exact (tsum_subtype_eq_of_support_subset hsupp).symm

theorem petermannCorrectionLog_uniform_le
    (q h : ℕ) (hh : h ≠ 0) :
    (∑' n : ℕ,
      |petermannCorrectionArithmetic q h n| * Real.log n) ≤
      petermannCorrectionLogUniformBound := by
  rw [petermannCorrectionLog_tsum_eq_factored q h hh]
  let s := petermannCorrectionPrimeSet q h
  have hfact :=
    (petermannFactoredLogMoment_bound q h s (by
      intro p hp
      simpa [s] using hp)).2
  have hprod :
      (∏ p ∈ s, (1 + petermannLocalMass p)) ≤
        petermannCorrectionL1UniformBound := by
    rw [← petermannCorrectionL1_tsum_eq_prod q h hh]
    exact petermannCorrectionL1_uniform_le q h hh
  have hsum :
      (∑ p ∈ s, petermannLocalLogMoment p) ≤
        ∑' p : ℕ, 20 * Real.log p / (p : ℝ)^2 := by
    calc
      (∑ p ∈ s, petermannLocalLogMoment p)
        ≤ ∑ p ∈ s, 20 * Real.log p / (p : ℝ)^2 := by
          apply Finset.sum_le_sum
          intro p hp
          apply petermannLocalLogMoment_le
          apply five_le_of_mem_petermannCorrectionPrimeSet
          simpa [s] using hp
      _ ≤ ∑' p : ℕ, 20 * Real.log p / (p : ℝ)^2 :=
        summable_petermannLogPrimeMajorant.sum_le_tsum
          s (fun p hp => petermannLogPrimeMajorant_nonneg p)
  have hprod0 : 0 ≤ ∏ p ∈ s, (1 + petermannLocalMass p) := by
    apply Finset.prod_nonneg
    intro p hp
    linarith [petermannLocalMass_nonneg p]
  have hsum0 : 0 ≤ ∑ p ∈ s, petermannLocalLogMoment p := by
    apply Finset.sum_nonneg
    intro p hp
    exact petermannLocalLogMoment_nonneg
      (five_le_of_mem_petermannCorrectionPrimeSet
        (by simpa [s] using hp))
  have hB0 : 0 ≤ petermannCorrectionL1UniformBound := by
    unfold petermannCorrectionL1UniformBound
    exact tsum_nonneg (fun t =>
      Finset.prod_nonneg (fun p hp => by positivity))
  have hP0 :
      0 ≤ ∑' p : ℕ, 20 * Real.log p / (p : ℝ)^2 :=
    tsum_nonneg petermannLogPrimeMajorant_nonneg
  calc
    petermannFactoredLogMoment q h s
      ≤ (∏ p ∈ s, (1 + petermannLocalMass p)) *
          (∑ p ∈ s, petermannLocalLogMoment p) := hfact
    _ ≤ petermannCorrectionL1UniformBound *
          (∑' p : ℕ, 20 * Real.log p / (p : ℝ)^2) := by
            exact mul_le_mul hprod hsum hsum0 hB0
    _ = petermannCorrectionLogUniformBound := rfl

noncomputable def petermannCorrectionConvolutionMomentBound : ℝ :=
  petermannCorrectionL1UniformBound +
    petermannCorrectionLogUniformBound

theorem summable_petermannCorrectionConvolutionMoment
    (q h : ℕ) (hh : h ≠ 0) :
    Summable (fun n : ℕ =>
      |petermannCorrectionArithmetic q h n| * (1 + Real.log n)) := by
  have h1 := summable_abs_petermannCorrectionArithmetic q h hh
  have hlog := summable_abs_petermannCorrectionArithmetic_log q h hh
  have hadd := h1.add hlog
  exact hadd.congr (fun n => by ring)

theorem petermannCorrectionConvolutionMoment_uniform_le
    (q h : ℕ) (hh : h ≠ 0) :
    (∑' n : ℕ,
      |petermannCorrectionArithmetic q h n| * (1 + Real.log n)) ≤
      petermannCorrectionConvolutionMomentBound := by
  have h1 := summable_abs_petermannCorrectionArithmetic q h hh
  have hlog := summable_abs_petermannCorrectionArithmetic_log q h hh
  have hsum :
      (∑' n : ℕ,
        |petermannCorrectionArithmetic q h n| * (1 + Real.log n)) =
      (∑' n : ℕ, |petermannCorrectionArithmetic q h n|) +
      (∑' n : ℕ,
        |petermannCorrectionArithmetic q h n| * Real.log n) := by
    rw [show
        (fun n : ℕ =>
          |petermannCorrectionArithmetic q h n| * (1 + Real.log n)) =
        fun n =>
          |petermannCorrectionArithmetic q h n| +
          |petermannCorrectionArithmetic q h n| * Real.log n by
      funext n
      ring]
    exact (h1.tsum_add hlog)
  rw [hsum]
  unfold petermannCorrectionConvolutionMomentBound
  exact add_le_add
    (petermannCorrectionL1_uniform_le q h hh)
    (petermannCorrectionLog_uniform_le q h hh)

#print axioms summable_abs_petermannCorrectionArithmetic_log
#print axioms petermannCorrectionLog_uniform_le
#print axioms summable_petermannCorrectionConvolutionMoment
#print axioms petermannCorrectionConvolutionMoment_uniform_le

end PaperB.FixedQ
