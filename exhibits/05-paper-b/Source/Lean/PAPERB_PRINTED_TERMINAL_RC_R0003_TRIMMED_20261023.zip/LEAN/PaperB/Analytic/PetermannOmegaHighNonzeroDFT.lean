import PaperB.Analytic.Kusmin
import PaperB.Analytic.DerivTest
import PaperB.FixedQ.FixedConductorCompletion

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset

lemma reciprocal_linear_phase_diff
    {A xi : ℝ} {m : ℕ} (hm : 0 < m) :
    (A / ((m + 1 : ℕ) : ℝ) + xi * ((m + 1 : ℕ) : ℝ)) -
      (A / (m : ℝ) + xi * (m : ℝ))
      = xi - A / ((m : ℝ) * ((m + 1 : ℕ) : ℝ)) := by
  have hmR : (0 : ℝ) < m := by exact_mod_cast hm
  have hm1R : (0 : ℝ) < (m + 1 : ℕ) := by positivity
  push_cast
  field_simp [hmR.ne', hm1R.ne']
  ring

lemma reciprocal_perturbation_antitone
    {A : ℝ} (hA : 0 ≤ A) {m n : ℕ}
    (hm : 0 < m) (hmn : m ≤ n) :
    A / ((n : ℝ) * ((n + 1 : ℕ) : ℝ)) ≤
      A / ((m : ℝ) * ((m + 1 : ℕ) : ℝ)) := by
  have hmR : (0 : ℝ) < m := by exact_mod_cast hm
  have hnR : (0 : ℝ) < n := by
    exact_mod_cast lt_of_lt_of_le hm hmn
  have hden : (m : ℝ) * ((m + 1 : ℕ) : ℝ) ≤
      (n : ℝ) * ((n + 1 : ℕ) : ℝ) := by
    exact mul_le_mul (by exact_mod_cast hmn) (by exact_mod_cast Nat.add_le_add_right hmn 1)
      (by positivity) (by positivity)
  exact div_le_div_of_nonneg_left hA (by positivity) hden



lemma dft_nonzero_delta_pos_le_half
    {N : ℕ} [NeZero N] {h : ZMod N} (hh : h ≠ 0) :
    let delta := (zmodFrequencyDistance h : ℝ) / (2 * (N : ℝ))
    0 < delta ∧ delta ≤ 1 / 2 := by
  dsimp
  have hN : (0 : ℝ) < N := by exact_mod_cast (NeZero.pos N)
  have hd : (0 : ℝ) < zmodFrequencyDistance h := by
    exact_mod_cast zmodFrequencyDistance_pos hh
  have h2d : (2 : ℝ) * zmodFrequencyDistance h ≤ N := by
    exact_mod_cast two_mul_zmodFrequencyDistance_le h
  constructor
  · positivity
  · apply (div_le_iff₀ (by positivity : (0 : ℝ) < 2 * N)).2
    nlinarith

lemma dft_nonzero_phase_gap_bounds
    {N : ℕ} [NeZero N] {h : ZMod N} (hh : h ≠ 0)
    {p : ℝ} (hp0 : 0 ≤ p)
    (hp : p ≤ (zmodFrequencyDistance h : ℝ) / (2 * (N : ℝ))) :
    let delta := (zmodFrequencyDistance h : ℝ) / (2 * (N : ℝ))
    delta ≤ (h.val : ℝ) / (N : ℝ) - p ∧
      (h.val : ℝ) / (N : ℝ) - p ≤ 1 - delta := by
  dsimp
  have hN : (0 : ℝ) < N := by exact_mod_cast (NeZero.pos N)
  have hdleval : zmodFrequencyDistance h ≤ h.val := by
    exact min_le_left _ _
  have hdlecomp : zmodFrequencyDistance h ≤ N - h.val := by
    exact min_le_right _ _
  have hvlt : h.val < N := ZMod.val_lt h
  have hcastSub : ((N - h.val : ℕ) : ℝ) = (N : ℝ) - (h.val : ℝ) := by
    rw [Nat.cast_sub (Nat.le_of_lt hvlt)]
  have hdlevalR : (zmodFrequencyDistance h : ℝ) ≤ (h.val : ℝ) := by
    exact_mod_cast hdleval
  have hdlecompR :
      (zmodFrequencyDistance h : ℝ) ≤ (N : ℝ) - (h.val : ℝ) := by
    rw [← hcastSub]
    exact_mod_cast hdlecomp
  constructor
  · apply (le_sub_iff_add_le).2
    calc
      (zmodFrequencyDistance h : ℝ) / (2 * (N : ℝ)) + p
          ≤ (zmodFrequencyDistance h : ℝ) / (2 * (N : ℝ)) +
              (zmodFrequencyDistance h : ℝ) / (2 * (N : ℝ)) := by
        linarith
      _ = (zmodFrequencyDistance h : ℝ) / (N : ℝ) := by
        field_simp [hN.ne']
        ring
      _ ≤ (h.val : ℝ) / (N : ℝ) :=
        div_le_div_of_nonneg_right hdlevalR hN.le
  · have hxi :
        (h.val : ℝ) / (N : ℝ) ≤
          1 - (zmodFrequencyDistance h : ℝ) / (N : ℝ) := by
      apply (div_le_iff₀ hN).2
      field_simp [hN.ne']
      nlinarith [hdlecompR]
    have hdelta_nonneg :
        0 ≤ (zmodFrequencyDistance h : ℝ) / (2 * (N : ℝ)) := by positivity
    have hdelta_le :
        (zmodFrequencyDistance h : ℝ) / (2 * (N : ℝ)) ≤
          (zmodFrequencyDistance h : ℝ) / (N : ℝ) := by
      have hd0 : 0 ≤ (zmodFrequencyDistance h : ℝ) := by positivity
      exact div_le_div_of_nonneg_left hd0 hN
        (by nlinarith [hN] : (N : ℝ) ≤ 2 * N)
    linarith


theorem omega_high_nonzero_dft_prefix_bound_of_perturbation
    {N : ℕ} [NeZero N] {h : ZMod N} (hh : h ≠ 0)
    {A : ℝ} (hA : 0 ≤ A) {W : ℕ} (hW : 0 < W)
    (hpert :
      A / ((W : ℝ) * ((W + 1 : ℕ) : ℝ)) ≤
        (zmodFrequencyDistance h : ℝ) / (2 * (N : ℝ))) :
    ∀ k : ℕ,
      ‖∑ j ∈ Finset.range k,
          eR (A / ((W + j : ℕ) : ℝ) +
            ((h.val : ℝ) / (N : ℝ)) * ((W + j : ℕ) : ℝ))‖
        ≤ 1 + 1 /
          ((zmodFrequencyDistance h : ℝ) / (2 * (N : ℝ))) := by
  intro k
  let delta : ℝ :=
    (zmodFrequencyDistance h : ℝ) / (2 * (N : ℝ))
  obtain ⟨hdelta0, hdeltahalf⟩ :=
    dft_nonzero_delta_pos_le_half hh
  by_cases hk0 : k = 0
  · subst k
    simp
    positivity
  · have hk1 : 1 ≤ k := Nat.one_le_iff_ne_zero.mpr hk0
    let f : ℕ → ℝ := fun n =>
      A / ((W + n : ℕ) : ℝ) +
        ((h.val : ℝ) / (N : ℝ)) * ((W + n : ℕ) : ℝ)
    have hdiff : ∀ n : ℕ,
        f (n + 1) - f n =
          (h.val : ℝ) / (N : ℝ) -
            A / (((W + n : ℕ) : ℝ) * ((W + n + 1 : ℕ) : ℝ)) := by
      intro n
      simpa [f, Nat.add_assoc, Nat.add_comm, Nat.add_left_comm] using
        (reciprocal_linear_phase_diff
          (A := A) (xi := (h.val : ℝ) / (N : ℝ))
          (m := W + n) (by omega))
    have hgap : ∀ n : ℕ,
        0 < n → n ≤ k - 1 →
        delta ≤ f (n + 1) - f n ∧
          f (n + 1) - f n ≤ 1 - delta := by
      intro n hn0 hnk
      have hp0 :
          0 ≤ A / (((W + n : ℕ) : ℝ) * ((W + n + 1 : ℕ) : ℝ)) := by
        positivity
      have hpmono :=
        reciprocal_perturbation_antitone hA
          (m := W) (n := W + n) hW (by omega)
      have hp :
          A / (((W + n : ℕ) : ℝ) * ((W + n + 1 : ℕ) : ℝ)) ≤ delta := by
        exact hpmono.trans hpert
      have hb := dft_nonzero_phase_gap_bounds hh hp0 hp
      simpa [delta, hdiff n] using hb
    have hmono : ∀ n : ℕ,
        0 < n → n < k - 1 →
        f (n + 1) - f n ≤ f (n + 2) - f (n + 1) := by
      intro n hn0 hnk
      rw [hdiff n, hdiff (n + 1)]
      have hpmono :=
        reciprocal_perturbation_antitone hA
          (m := W + n) (n := W + n + 1) (by omega) (by omega)
      have hpmono' :
          A / (((W + (n + 1) : ℕ) : ℝ) *
              ((W + (n + 1) + 1 : ℕ) : ℝ)) ≤
            A / (((W + n : ℕ) : ℝ) *
              ((W + n + 1 : ℕ) : ℝ)) := by
        simpa [Nat.add_assoc] using hpmono
      linarith
    have hKL := kusmin_landau
      (f := f) (a := 0) (b := k - 1)
      (δ := delta) (m := (0 : ℤ))
      hdelta0 hdeltahalf
      (fun n hn0 hnk => by simpa using (hgap n hn0 hnk).1)
      (fun n hn0 hnk => by simpa using (hgap n hn0 hnk).2)
      hmono
    have htail :
        ‖∑ n ∈ Finset.Ioc 0 (k - 1), eR (f n)‖ ≤ 1 / delta := by
      simpa only [eR_eq_eK] using hKL
    have hrange :
        Finset.range k = insert 0 (Finset.Ioc 0 (k - 1)) := by
      ext n
      simp
      omega
    rw [hrange, Finset.sum_insert (by simp)]
    calc
      ‖eR (f 0) + ∑ n ∈ Finset.Ioc 0 (k - 1), eR (f n)‖
          ≤ ‖eR (f 0)‖ +
              ‖∑ n ∈ Finset.Ioc 0 (k - 1), eR (f n)‖ :=
        norm_add_le _ _
      _ ≤ 1 + 1 / delta := by
        rw [norm_eR]
        linarith
      _ = 1 + 1 /
          ((zmodFrequencyDistance h : ℝ) / (2 * (N : ℝ))) := rfl


theorem omega_high_nonzero_dft_reciprocal_weight_range_bound_of_perturbation
    {N : ℕ} [NeZero N] {h : ZMod N} (hh : h ≠ 0)
    {A : ℝ} (hA : 0 ≤ A) {W : ℕ} (hW : 0 < W)
    (hpert :
      A / ((W : ℝ) * ((W + 1 : ℕ) : ℝ)) ≤
        (zmodFrequencyDistance h : ℝ) / (2 * (N : ℝ)))
    (L : ℕ) :
    ‖∑ j ∈ Finset.range L,
        (((W + j : ℕ) : ℂ)⁻¹ *
          eR (A / ((W + j : ℕ) : ℝ) +
            ((h.val : ℝ) / (N : ℝ)) * ((W + j : ℕ) : ℝ)))‖
      ≤ 2 * (1 + 1 /
          ((zmodFrequencyDistance h : ℝ) / (2 * (N : ℝ)))) / W := by
  let C : ℝ :=
    1 + 1 / ((zmodFrequencyDistance h : ℝ) / (2 * (N : ℝ)))
  have hdelta0 :
      0 < (zmodFrequencyDistance h : ℝ) / (2 * (N : ℝ)) :=
    (dft_nonzero_delta_pos_le_half hh).1
  have hC0 : 0 ≤ C := by
    dsimp [C]
    positivity
  have hprefix := omega_high_nonzero_dft_prefix_bound_of_perturbation
    hh hA hW hpert
  have hparts := partialSummation_reciprocal_weight_le
    W L hW
    (fun j =>
      eR (A / ((W + j : ℕ) : ℝ) +
        ((h.val : ℝ) / (N : ℝ)) * ((W + j : ℕ) : ℝ)))
    (C := C) hC0 (fun k hk => by
      simpa [C] using hprefix k)
  simpa [C, reciprocalNatWeight, mul_comm] using hparts

theorem omega_high_nonzero_dft_reciprocal_weight_shell_bound_of_perturbation
    {N : ℕ} [NeZero N] {h : ZMod N} (hh : h ≠ 0)
    {A : ℝ} (hA : 0 ≤ A) {W B : ℕ}
    (hW : 0 < W) (hWB : W ≤ B)
    (hpert :
      A / ((W : ℝ) * ((W + 1 : ℕ) : ℝ)) ≤
        (zmodFrequencyDistance h : ℝ) / (2 * (N : ℝ))) :
    ‖∑ m ∈ Finset.Icc W B,
        ((m : ℂ)⁻¹ *
          eR (A / (m : ℝ) +
            ((h.val : ℝ) / (N : ℝ)) * (m : ℝ)))‖
      ≤ 2 * (1 + 1 /
          ((zmodFrequencyDistance h : ℝ) / (2 * (N : ℝ)))) / W := by
  have hrange :=
    omega_high_nonzero_dft_reciprocal_weight_range_bound_of_perturbation
      hh hA hW hpert (B + 1 - W)
  have hset : Finset.Icc W B = Finset.Ico W (B + 1) := by
    ext m
    simp
  rw [hset, Finset.sum_Ico_eq_sum_range]
  have hlen : B + 1 - W = B + 1 - W := rfl
  simpa [Nat.add_assoc, Nat.add_comm, Nat.add_left_comm] using hrange


lemma high_window_reciprocal_perturbation_le_dft_delta
    {N : ℕ} [NeZero N] {h : ZMod N} (hh : h ≠ 0)
    {A : ℝ} {W : ℕ}
    (hAthresh : (2 * (N : ℝ)) ^ 2 ≤ A)
    (hhigh : A ^ (3 / 4 : ℝ) < (W : ℝ)) :
    A / ((W : ℝ) * ((W + 1 : ℕ) : ℝ)) ≤
      (zmodFrequencyDistance h : ℝ) / (2 * (N : ℝ)) := by
  have hN : (0 : ℝ) < N := by exact_mod_cast (NeZero.pos N)
  have h2N : (0 : ℝ) < 2 * (N : ℝ) := by positivity
  have hA0 : 0 < A := lt_of_lt_of_le (by positivity) hAthresh
  have hA : 0 ≤ A := hA0.le
  have hW0 : (0 : ℝ) < W := by
    have hrpow0 : 0 ≤ A ^ (3 / 4 : ℝ) := Real.rpow_nonneg hA _
    linarith
  have hWsquare0 : (0 : ℝ) < (W : ℝ) * ((W + 1 : ℕ) : ℝ) := by
    positivity
  have hNsqrt : 2 * (N : ℝ) ≤ Real.sqrt A := by
    exact (Real.le_sqrt (by positivity) hA).2 hAthresh
  have hmul :
      (2 * (N : ℝ)) * A ≤ Real.sqrt A * A :=
    mul_le_mul_of_nonneg_right hNsqrt hA
  have hrpow_sq :
      (A ^ (3 / 4 : ℝ)) ^ 2 = A * Real.sqrt A := by
    calc
      (A ^ (3 / 4 : ℝ)) ^ 2
          = (A ^ (3 / 4 : ℝ)) ^ (2 : ℝ) := by
              exact (Real.rpow_two (A ^ (3 / 4 : ℝ))).symm
      _ = A ^ ((3 / 4 : ℝ) * 2) := by
              rw [← Real.rpow_mul hA]
      _ = A ^ (1 + 1 / 2 : ℝ) := by norm_num
      _ = A ^ (1 : ℝ) * A ^ (1 / 2 : ℝ) := by
              rw [Real.rpow_add hA0]
      _ = A * Real.sqrt A := by
              rw [Real.rpow_one, Real.sqrt_eq_rpow]
  have hrpow0 : 0 ≤ A ^ (3 / 4 : ℝ) := Real.rpow_nonneg hA _
  have hWsq :
      (A ^ (3 / 4 : ℝ)) ^ 2 < (W : ℝ) ^ 2 := by
    nlinarith
  have hden :
      (2 * (N : ℝ)) * A ≤
        (W : ℝ) * ((W + 1 : ℕ) : ℝ) := by
    have hWsq_le :
        (W : ℝ) ^ 2 ≤ (W : ℝ) * ((W + 1 : ℕ) : ℝ) := by
      push_cast
      nlinarith
    rw [hrpow_sq] at hWsq
    nlinarith [hmul, hWsq_le]
  have hone :
      A / ((W : ℝ) * ((W + 1 : ℕ) : ℝ)) ≤
        1 / (2 * (N : ℝ)) := by
    exact (div_le_div_iff₀ hWsquare0 h2N).2 (by
      nlinarith [hden])
  have hd1 : (1 : ℝ) ≤ zmodFrequencyDistance h := by
    exact_mod_cast zmodFrequencyDistance_pos hh
  have hdone :
      1 / (2 * (N : ℝ)) ≤
        (zmodFrequencyDistance h : ℝ) / (2 * (N : ℝ)) := by
    exact div_le_div_of_nonneg_right hd1 h2N.le
  exact hone.trans hdone


theorem omega_high_nonzero_dft_reciprocal_weight_shell_bound
    (q : ℕ) [NeZero (Nat.lcm 6 q)]
    {h : ZMod (Nat.lcm 6 q)} (hh : h ≠ 0)
    {A : ℝ} {W B : ℕ}
    (hAthresh :
      (2 * ((Nat.lcm 6 q : ℕ) : ℝ)) ^ 2 ≤ A)
    (hhigh : A ^ (3 / 4 : ℝ) < (W : ℝ))
    (hWB : W ≤ B) (_hB2 : B ≤ 2 * W) :
    ‖∑ m ∈ Finset.Icc W B,
        ((m : ℂ)⁻¹ *
          eR (A / (m : ℝ) +
            ((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) * (m : ℝ)))‖
      ≤ 2 * (1 +
          (2 * ((Nat.lcm 6 q : ℕ) : ℝ)) /
            (zmodFrequencyDistance h : ℝ)) / (W : ℝ) := by
  have hNpos : 0 < Nat.lcm 6 q := NeZero.pos _
  have hA0 : 0 ≤ A := by
    have hbase :
        0 ≤ (2 * ((Nat.lcm 6 q : ℕ) : ℝ)) ^ 2 := sq_nonneg _
    exact hbase.trans hAthresh
  have hW : 0 < W := by
    have hrpow0 : 0 ≤ A ^ (3 / 4 : ℝ) := Real.rpow_nonneg hA0 _
    exact_mod_cast (show (0 : ℝ) < W by linarith)
  have hpert :
      A / ((W : ℝ) * ((W + 1 : ℕ) : ℝ)) ≤
        (zmodFrequencyDistance h : ℝ) /
          (2 * ((Nat.lcm 6 q : ℕ) : ℝ)) := by
    exact high_window_reciprocal_perturbation_le_dft_delta
      (N := Nat.lcm 6 q) hh hAthresh hhigh
  have hshell :=
    omega_high_nonzero_dft_reciprocal_weight_shell_bound_of_perturbation
      (N := Nat.lcm 6 q) hh hA0 hW hWB hpert
  have hdpos : (0 : ℝ) < zmodFrequencyDistance h := by
    exact_mod_cast zmodFrequencyDistance_pos hh
  have hNreal : (0 : ℝ) < Nat.lcm 6 q := by exact_mod_cast hNpos
  have hsimp :
      1 / ((zmodFrequencyDistance h : ℝ) /
          (2 * ((Nat.lcm 6 q : ℕ) : ℝ))) =
        (2 * ((Nat.lcm 6 q : ℕ) : ℝ)) /
          (zmodFrequencyDistance h : ℝ) := by
    field_simp [hdpos.ne', hNreal.ne']
  simpa [hsimp] using hshell

#print axioms reciprocal_linear_phase_diff
#print axioms reciprocal_perturbation_antitone
#print axioms dft_nonzero_delta_pos_le_half
#print axioms dft_nonzero_phase_gap_bounds
#print axioms omega_high_nonzero_dft_prefix_bound_of_perturbation
#print axioms omega_high_nonzero_dft_reciprocal_weight_range_bound_of_perturbation
#print axioms omega_high_nonzero_dft_reciprocal_weight_shell_bound_of_perturbation
#print axioms high_window_reciprocal_perturbation_le_dft_delta
#print axioms omega_high_nonzero_dft_reciprocal_weight_shell_bound

end PaperB.Analytic
