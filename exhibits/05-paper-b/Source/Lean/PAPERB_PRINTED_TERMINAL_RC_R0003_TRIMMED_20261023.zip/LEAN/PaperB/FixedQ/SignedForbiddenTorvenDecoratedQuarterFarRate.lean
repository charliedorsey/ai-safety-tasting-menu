import PaperB.FixedQ.SignedForbiddenTorvenDecoratedQuarterFarGlobal

open scoped BigOperators Classical
namespace PaperB.FixedQ

/-- Source-native reduced proper far sum at the ORIGINAL height cutoff Z(h).
The reduced height H and height divisor D are independent parameters here. -/
noncomputable def torvenReducedProperQuarterFarSigned
    (q A H D Z : ℕ) : ℝ :=
  ∑' m : ℕ,
    if Z < m ∧ H ^ 2 < 4 * m then
      torvenSourceProperNaturalTerm q A H D m
    else 0

/-- Pointwise proper natural geometric far-sector bound, summed BEFORE
height decoration; no absolute values are inserted in the remaining core. -/
theorem torven_abs_reducedProperQuarterFar_le_shiu
    {q A H D Z : ℕ}
    (hH : 2 ≤ H) (h2 : ¬ 2 ∣ q → 2 ∣ H) :
    |torvenReducedProperQuarterFarSigned q A H D Z| ≤
      6 * (H : ℝ) * fixedQShiuReciprocalFarTail q (H / 2) := by
  let t := H / 2
  let f : ℕ → ℝ := fun m =>
    if Z < m ∧ H ^ 2 < 4 * m then
      torvenSourceProperNaturalTerm q A H D m else 0
  let g : ℕ → ℝ := fun m =>
    if t ^ 2 < m then fixedQShiuWeight q m / (m : ℝ) else 0
  have ht : 0 < t := by dsimp [t]; omega
  have hg : Summable g :=
    summable_fixedQShiuReciprocalFarTailTerm q ht
  have hmajor : ∀ m, |f m| ≤ 6 * (H : ℝ) * g m := by
    intro m
    dsimp [f, g]
    by_cases hc : Z < m ∧ H ^ 2 < 4 * m
    · rw [if_pos hc, if_pos (torven_half_square_lt_of_quad_product_gt_sq hc.2)]
      exact torven_abs_sourceProperNaturalTerm_quad_far_le_shiu hH h2 hc.2
    · rw [if_neg hc, abs_zero]
      by_cases ht2 : t ^ 2 < m
      · rw [if_pos ht2]
        exact mul_nonneg
          (mul_nonneg (by norm_num) (Nat.cast_nonneg H))
          (div_nonneg (fixedQShiuWeight_nonneg q m) (Nat.cast_nonneg m))
      · rw [if_neg ht2]; norm_num
  have hgmul : Summable (fun m => 6 * (H : ℝ) * g m) :=
    hg.mul_left (6 * (H : ℝ))
  have hf : Summable f := by
    apply Summable.of_norm_bounded hgmul
    intro m
    simpa [Real.norm_eq_abs] using hmajor m
  have hnormsum :
      (∑' m, |f m|) ≤ ∑' m, 6 * (H : ℝ) * g m :=
    hf.norm.tsum_le_tsum hmajor hgmul
  unfold torvenReducedProperQuarterFarSigned
  change |∑' m, f m| ≤ _
  calc
    |∑' m, f m| ≤ ∑' m, |f m| := by
      simpa [Real.norm_eq_abs] using norm_tsum_le_tsum_norm hf.norm
    _ ≤ ∑' m, 6 * (H : ℝ) * g m := hnormsum
    _ = 6 * (H : ℝ) * (∑' m, g m) := by rw [tsum_mul_left]
    _ = 6 * (H : ℝ) * fixedQShiuReciprocalFarTail q (H / 2) := rfl

#print axioms torven_abs_reducedProperQuarterFar_le_shiu

end PaperB.FixedQ

namespace PaperB.FixedQ

/-- An unconditional q-only bound for any reduced positive height,
including the exactly vanishing H=1 boundary. -/
theorem torven_abs_reducedProperQuarterFar_le_uniform
    {q A H D Z : ℕ}
    (hH : 0 < H) (h2 : ¬ 2 ∣ q → 2 ∣ H) :
    |torvenReducedProperQuarterFarSigned q A H D Z| ≤
      18 * fixedQShiuQuarterMoment q := by
  by_cases hsmall : H = 1
  · subst H
    have hzero : torvenReducedProperQuarterFarSigned q A 1 D Z = 0 := by
      unfold torvenReducedProperQuarterFarSigned
      simp [torven_sourceProperNaturalTerm_height_one_zero]
    rw [hzero, abs_zero]
    exact mul_nonneg (by norm_num) (fixedQShiuQuarterMoment_nonneg q)
  · have hH2 : 2 ≤ H := by omega
    let t : ℕ := H / 2
    have ht : 0 < t := by dsimp [t]; omega
    have ht1 : 1 ≤ t := ht
    have hHr : H ≤ 3 * t := by dsimp [t]; omega
    have hHrR : (H : ℝ) ≤ 3 * (t : ℝ) := by exact_mod_cast hHr
    have htR : (0 : ℝ) < t := by exact_mod_cast ht
    have ht1R : (1 : ℝ) ≤ t := by exact_mod_cast ht1
    have hm0 : 0 ≤ fixedQShiuQuarterMoment q :=
      fixedQShiuQuarterMoment_nonneg q
    have hqbound := torven_abs_reducedProperQuarterFar_le_shiu
      (q := q) (A := A) (H := H) (D := D) (Z := Z) hH2 h2
    have hquarter := fixedQShiuReciprocalFarTail_le_quarter q ht
    have hpow :
        (t : ℝ) * (t : ℝ) ^ (-3 / 2 : ℝ) =
          (t : ℝ) ^ (-1 / 2 : ℝ) := by
      calc
        (t : ℝ) * (t : ℝ) ^ (-3 / 2 : ℝ)
          = (t : ℝ) ^ (1 : ℝ) *
              (t : ℝ) ^ (-3 / 2 : ℝ) := by simp
        _ = (t : ℝ) ^ ((1 : ℝ) + (-3 / 2 : ℝ)) := by
              rw [← Real.rpow_add htR]
        _ = (t : ℝ) ^ (-1 / 2 : ℝ) := by norm_num
    have hdecay : (t : ℝ) ^ (-1 / 2 : ℝ) ≤ 1 :=
      Real.rpow_le_one_of_one_le_of_nonpos ht1R (by norm_num)
    have hpositive :
        0 ≤ (t : ℝ) ^ (-3 / 2 : ℝ) * fixedQShiuQuarterMoment q :=
      mul_nonneg (Real.rpow_nonneg (Nat.cast_nonneg t) _) hm0
    calc
      |torvenReducedProperQuarterFarSigned q A H D Z|
        ≤ 6 * (H : ℝ) * fixedQShiuReciprocalFarTail q t := by
          simpa [t] using hqbound
      _ ≤ 6 * (H : ℝ) *
          ((t : ℝ) ^ (-3 / 2 : ℝ) * fixedQShiuQuarterMoment q) := by
            exact mul_le_mul_of_nonneg_left hquarter (by positivity)
      _ ≤ (18 * (t : ℝ)) *
          ((t : ℝ) ^ (-3 / 2 : ℝ) * fixedQShiuQuarterMoment q) := by
            exact mul_le_mul_of_nonneg_right (by nlinarith [hHrR]) hpositive
      _ = (18 * fixedQShiuQuarterMoment q) *
          ((t : ℝ) * (t : ℝ) ^ (-3 / 2 : ℝ)) := by ring
      _ = (18 * fixedQShiuQuarterMoment q) *
          ((t : ℝ) ^ (-1 / 2 : ℝ)) := by rw [hpow]
      _ ≤ 18 * fixedQShiuQuarterMoment q := by
            simpa using mul_le_mul_of_nonneg_left hdecay
              (mul_nonneg (by norm_num) hm0)

#print axioms torven_abs_reducedProperQuarterFar_le_uniform

end PaperB.FixedQ

namespace PaperB.FixedQ

/-- The full height-TIED decorated proper natural far sector, with
D=product(d), H=h/D, and one original exterior cutoff Z(h). -/
noncomputable def torvenDecoratedProperQuarterFarNatural
    (q a h Z : ℕ) : ℝ :=
  ∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
    finiteVWeightReal h d *
      torvenReducedProperQuarterFarSigned q
        (decoratedReducedAnchor q a (primeSetProduct d))
        (h / primeSetProduct d) (primeSetProduct d) Z

noncomputable def torvenDecoratedProperQuarterFarConstant (q : ℕ) : ℝ :=
  (18 * fixedQShiuQuarterMoment q) * weakDecoratedMertensC

lemma torvenDecoratedProperQuarterFarConstant_nonneg (q : ℕ) :
    0 ≤ torvenDecoratedProperQuarterFarConstant q := by
  unfold torvenDecoratedProperQuarterFarConstant
  have hM := fixedQShiuQuarterMoment_nonneg q
  have hW : 0 ≤ weakDecoratedMertensC := by
    unfold weakDecoratedMertensC weakMertensC
    positivity
  positivity

/-- Complete decorated natural proper far-sector bound;
no free-D uniformity and no change from Z(h) to Z(h/D). -/
theorem torven_abs_decoratedProperQuarterFarNatural_le_loglog
    {q a h Z : ℕ}
    (hh16 : 16 ≤ h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    |torvenDecoratedProperQuarterFarNatural q a h Z| ≤
      torvenDecoratedProperQuarterFarConstant q *
        Real.log (Real.log (h : ℝ)) := by
  let P := (decoratedHeightPrimeSet q h).powerset
  let B : ℝ := 18 * fixedQShiuQuarterMoment q
  have hB : 0 ≤ B := by
    dsimp [B]
    exact mul_nonneg (by norm_num) (fixedQShiuQuarterMoment_nonneg q)
  have hHpos : 0 < h := by omega
  have hpoint : ∀ d ∈ P,
      |finiteVWeightReal h d *
        torvenReducedProperQuarterFarSigned q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) (primeSetProduct d) Z| ≤
        finiteVWeightReal h d * B := by
    intro d hd
    have hv0 : 0 ≤ finiteVWeightReal h d := by
      apply finiteVWeightReal_nonneg_of_active
      exact decoratedHeightPrimeSet_active (Finset.mem_powerset.mp hd)
    have hReduced : 0 < h / primeSetProduct d :=
      decoratedReducedHeight_pos_of_mem hHpos hd
    have hpar : ¬ 2 ∣ q → 2 ∣ h / primeSetProduct d :=
      decoratedReducedHeight_parity_of_mem h2 hd
    rw [abs_mul, abs_of_nonneg hv0]
    exact mul_le_mul_of_nonneg_left
      (torven_abs_reducedProperQuarterFar_le_uniform hReduced hpar) hv0
  have hmass :
      (∑ d ∈ P, finiteVWeightReal h d) ≤
        weakDecoratedMertensC * Real.log (Real.log (h : ℝ)) :=
    (sum_decorated_finiteVWeightReal_lt_weakMertens
      (q := q) hh16).le
  unfold torvenDecoratedProperQuarterFarNatural
  calc
    |∑ d ∈ P, finiteVWeightReal h d *
        torvenReducedProperQuarterFarSigned q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) (primeSetProduct d) Z|
      ≤ ∑ d ∈ P, |finiteVWeightReal h d *
          torvenReducedProperQuarterFarSigned q
            (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d) (primeSetProduct d) Z| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ d ∈ P, finiteVWeightReal h d * B :=
      Finset.sum_le_sum hpoint
    _ = (∑ d ∈ P, finiteVWeightReal h d) * B := by
      rw [Finset.sum_mul]
    _ ≤ (weakDecoratedMertensC * Real.log (Real.log (h : ℝ))) * B :=
      mul_le_mul_of_nonneg_right hmass hB
    _ = torvenDecoratedProperQuarterFarConstant q *
        Real.log (Real.log (h : ℝ)) := by
      dsimp [torvenDecoratedProperQuarterFarConstant, B]
      ring

#print axioms torven_abs_decoratedProperQuarterFarNatural_le_loglog

end PaperB.FixedQ

namespace PaperB.FixedQ

/-- Unconditional sublog bound for the entire height-tied decorated proper
natural quarter-square far sector, uniformly at ANY original cutoff Z. -/
theorem torven_decoratedProperQuarterFarNatural_sublog (q : ℕ) :
    ∀ ε : ℝ, 0 < ε →
      ∃ h0 : ℕ,
        ∀ a h Z : ℕ,
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          h0 ≤ h →
          |torvenDecoratedProperQuarterFarNatural q a h Z| ≤
            ε * Real.log (h : ℝ) := by
  intro ε hε
  let C : ℝ := torvenDecoratedProperQuarterFarConstant q
  have hlo0 :
      (fun x : ℝ => Real.log (Real.log x)) =o[Filter.atTop]
        Real.log := by
    simpa [Function.comp_def] using
      Real.isLittleO_log_id_atTop.comp_tendsto Real.tendsto_log_atTop
  have hlo :
      (fun x : ℝ => C * Real.log (Real.log x)) =o[Filter.atTop]
        Real.log := hlo0.const_mul_left C
  have hev := hlo.bound hε
  rw [Filter.eventually_atTop] at hev
  obtain ⟨T, hT⟩ := hev
  obtain ⟨N, hN⟩ := exists_nat_ge T
  refine ⟨max 16 N, ?_⟩
  intro a h Z h2 hh hlarge
  have hh16 : 16 ≤ h :=
    (le_max_left 16 N).trans hlarge
  have hNh : N ≤ h :=
    (le_max_right 16 N).trans hlarge
  have hTR : T ≤ (h : ℝ) :=
    hN.trans (by exact_mod_cast hNh)
  have hasym := hT (h : ℝ) hTR
  have hll0 : 0 ≤ Real.log (Real.log (h : ℝ)) := by
    have h1 := one_le_log_log_nat_of_sixteen_le hh16
    linarith
  have hlog0 : 0 ≤ Real.log (h : ℝ) :=
    Real.log_nonneg (by exact_mod_cast (show 1 ≤ h by omega))
  have hC0 : 0 ≤ C := torvenDecoratedProperQuarterFarConstant_nonneg q
  rw [Real.norm_eq_abs,
    abs_of_nonneg (mul_nonneg hC0 hll0),
    Real.norm_eq_abs, abs_of_nonneg hlog0] at hasym
  exact (torven_abs_decoratedProperQuarterFarNatural_le_loglog
      (q := q) (a := a) (h := h) (Z := Z) hh16 h2).trans hasym

#print axioms torven_decoratedProperQuarterFarNatural_sublog

end PaperB.FixedQ
