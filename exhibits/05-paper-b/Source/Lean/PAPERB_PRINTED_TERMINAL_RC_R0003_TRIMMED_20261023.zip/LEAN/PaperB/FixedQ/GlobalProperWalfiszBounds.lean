import PaperB.FixedQ.GlobalProperSmallBoxRate

set_option maxHeartbeats 1000000

open Filter Real Asymptotics
namespace PaperB.FixedQ

lemma globalProper_log_cutoff (h : ℕ) :
    Nat.log 2 (globalProperBooleanProductCutoff h) =
      globalProperBooleanBlockCount h := by
  unfold globalProperBooleanProductCutoff
  exact Nat.log_pow (by norm_num) _

lemma globalProper_block_cast_le {h : ℕ} (hh : 0 < h) :
    (globalProperBooleanBlockCount h : ℝ) ≤
      20 * ((Real.log (h : ℝ)) ^ h2BooleanSigma + 1) := by
  unfold globalProperBooleanBlockCount
  push_cast
  have hs := h2BooleanSourceCutoff_cast_le hh
  nlinarith

lemma h2BooleanSigma_le_one : h2BooleanSigma ≤ 1 := by
  rw [h2BooleanSigma_eq]
  norm_num

lemma globalProper_block_succ_cast_le
    {h : ℕ} (hh : 0 < h)
    (hS1 : 1 ≤ (Real.log (h : ℝ)) ^ h2BooleanSigma) :
    (((Nat.log 2 (globalProperBooleanProductCutoff h) + 1 : ℕ) : ℝ)) ≤
      41 * (Real.log (h : ℝ)) ^ h2BooleanSigma := by
  rw [globalProper_log_cutoff]
  have hK := globalProper_block_cast_le hh
  push_cast
  have hSgap :
      21 ≤ 21 * (Real.log (h : ℝ)) ^ h2BooleanSigma := by
    nlinarith
  linarith

lemma globalProper_top_log_le
    {N0 h : ℕ} (hN0 : 0 < N0)
    (hlogN :
      Real.log (N0 : ℝ) ≤
        (Real.log (h : ℝ)) ^ h2BooleanSigma)
    (hJ :
      (((Nat.log 2 (globalProperBooleanProductCutoff h) + 1 : ℕ) : ℝ)) ≤
        41 * (Real.log (h : ℝ)) ^ h2BooleanSigma) :
    Real.log
        ((N0 * 2 ^ (Nat.log 2 (globalProperBooleanProductCutoff h) + 1) : ℕ) : ℝ)
      ≤ 42 * (Real.log (h : ℝ)) ^ h2BooleanSigma := by
  let J := Nat.log 2 (globalProperBooleanProductCutoff h) + 1
  have hlog2 : Real.log (2 : ℝ) ≤ 1 := by
    nlinarith [Real.log_le_sub_one_of_pos (by norm_num : (0 : ℝ) < 2)]
  have hJS :
      (J : ℝ) * Real.log 2 ≤
        41 * (Real.log (h : ℝ)) ^ h2BooleanSigma := by
    calc
      (J : ℝ) * Real.log 2 ≤ (J : ℝ) * 1 := by
        exact mul_le_mul_of_nonneg_left hlog2 (Nat.cast_nonneg J)
      _ ≤ 41 * (Real.log (h : ℝ)) ^ h2BooleanSigma := by
        rw [mul_one]
        exact hJ
  have hlogeq :
      Real.log
          ((N0 * 2 ^ J : ℕ) : ℝ) =
        Real.log (N0 : ℝ) + (J : ℝ) * Real.log 2 := by
    push_cast
    rw [Real.log_mul (by exact_mod_cast hN0.ne') (by positivity)]
    rw [Real.log_pow]
  rw [show Nat.log 2 (globalProperBooleanProductCutoff h) + 1 = J by rfl]
  rw [hlogeq]
  linarith

lemma globalProper_top_log_pos
    {N0 h : ℕ} (hN0 : 0 < N0) :
    0 <
      Real.log
        ((N0 * 2 ^ (Nat.log 2 (globalProperBooleanProductCutoff h) + 1) : ℕ) : ℝ) := by
  let J := Nat.log 2 (globalProperBooleanProductCutoff h) + 1
  have hJ1 : 1 ≤ J := by dsimp [J]; omega
  have hp : 2 ≤ 2 ^ J := by
    simpa using (Nat.pow_le_pow_right (n := 2) (by norm_num) hJ1)
  have hN1 : 1 ≤ N0 := Nat.one_le_iff_ne_zero.mpr hN0.ne'
  have hU2 : 2 ≤ N0 * 2 ^ J := by
    calc
      2 = 1 * 2 := by norm_num
      _ ≤ N0 * 2 ^ J := Nat.mul_le_mul hN1 hp
  apply Real.log_pos
  exact_mod_cast (show 1 < N0 * 2 ^ J by omega)

lemma globalProper_top_loglog_le
    {N0 h : ℕ} (hN0 : 0 < N0)
    (hL : 1 ≤ Real.log (h : ℝ))
    (hLL : 1 ≤ Real.log (Real.log (h : ℝ)))
    (hS1 : 1 ≤ (Real.log (h : ℝ)) ^ h2BooleanSigma)
    (hUS :
      Real.log
          ((N0 * 2 ^ (Nat.log 2 (globalProperBooleanProductCutoff h) + 1) : ℕ) : ℝ)
        ≤ 42 * (Real.log (h : ℝ)) ^ h2BooleanSigma) :
    Real.log
      (Real.log
        ((N0 * 2 ^ (Nat.log 2 (globalProperBooleanProductCutoff h) + 1) : ℕ) : ℝ))
      ≤ 42 * Real.log (Real.log (h : ℝ)) := by
  let L := Real.log (h : ℝ)
  let S := L ^ h2BooleanSigma
  have hlogUpos := globalProper_top_log_pos (h := h) hN0
  have hSpos : 0 < S := by
    dsimp [S, L]
    exact lt_of_lt_of_le zero_lt_one hS1
  have h42Spos : 0 < 42 * S := mul_pos (by norm_num) hSpos
  have hlogMono :
      Real.log
        (Real.log
          ((N0 * 2 ^ (Nat.log 2 (globalProperBooleanProductCutoff h) + 1) : ℕ) : ℝ))
        ≤ Real.log (42 * S) := by
    have hUS' :
        Real.log
            ((N0 * 2 ^ (Nat.log 2 (globalProperBooleanProductCutoff h) + 1) : ℕ) : ℝ)
          ≤ 42 * S := by
      exact hUS
    exact Real.strictMonoOn_log.monotoneOn hlogUpos h42Spos hUS'
  have hlog42 : Real.log (42 : ℝ) ≤ 41 := by
    nlinarith [Real.log_le_sub_one_of_pos (by norm_num : (0 : ℝ) < 42)]
  have hlogS : Real.log S = h2BooleanSigma * Real.log L := by
    dsimp [S]
    rw [Real.log_rpow (lt_of_lt_of_le zero_lt_one hL)]
  have hlog42S :
      Real.log (42 * S) ≤ 42 * Real.log L := by
    rw [Real.log_mul (by norm_num : (42 : ℝ) ≠ 0) hSpos.ne', hlogS]
    have hsMul :
        h2BooleanSigma * Real.log L ≤ Real.log L := by
      exact mul_le_of_le_one_left
        (le_trans (by norm_num) hLL)
        h2BooleanSigma_le_one
    linarith
  have hlog42S' :
      Real.log (42 * S) ≤ 42 * Real.log (Real.log (h : ℝ)) := by
    exact hlog42S
  exact hlogMono.trans hlog42S'

theorem globalProperWalfiszBounds (N0 : ℕ) (hN0 : 0 < N0) :
    ∃ H0 : ℕ, ∀ h : ℕ, H0 ≤ h →
      16 ≤ h ∧
      1 ≤ Real.log (h : ℝ) ∧
      1 ≤ Real.log (Real.log (h : ℝ)) ∧
      1 ≤ (Real.log (h : ℝ)) ^ h2BooleanSigma ∧
      (((Nat.log 2 (globalProperBooleanProductCutoff h) + 1 : ℕ) : ℝ)) ≤
        41 * (Real.log (h : ℝ)) ^ h2BooleanSigma ∧
      Real.log
          ((N0 * 2 ^ (Nat.log 2 (globalProperBooleanProductCutoff h) + 1) : ℕ) : ℝ)
        ≤ 42 * (Real.log (h : ℝ)) ^ h2BooleanSigma ∧
      Real.log
        (Real.log
          ((N0 * 2 ^ (Nat.log 2 (globalProperBooleanProductCutoff h) + 1) : ℕ) : ℝ))
        ≤ 42 * Real.log (Real.log (h : ℝ)) := by
  have hlog : Tendsto (fun h : ℕ => Real.log (h : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hll : Tendsto
      (fun h : ℕ => Real.log (Real.log (h : ℝ))) atTop atTop :=
    Real.tendsto_log_atTop.comp hlog
  have hS : Tendsto
      (fun h : ℕ => (Real.log (h : ℝ)) ^ h2BooleanSigma) atTop atTop :=
    (tendsto_rpow_atTop h2BooleanSigma_pos).comp hlog
  have hEv : ∀ᶠ h : ℕ in atTop,
      16 ≤ h ∧
      1 ≤ Real.log (h : ℝ) ∧
      1 ≤ Real.log (Real.log (h : ℝ)) ∧
      1 ≤ (Real.log (h : ℝ)) ^ h2BooleanSigma ∧
      Real.log (N0 : ℝ) ≤ (Real.log (h : ℝ)) ^ h2BooleanSigma := by
    filter_upwards [
      eventually_ge_atTop 16,
      hlog.eventually (eventually_ge_atTop 1),
      hll.eventually (eventually_ge_atTop 1),
      hS.eventually (eventually_ge_atTop 1),
      hS.eventually (eventually_ge_atTop (Real.log (N0 : ℝ)))
    ] with h hh16 hL hLL hS1 hN
    exact ⟨hh16, hL, hLL, hS1, hN⟩
  rw [Filter.eventually_atTop] at hEv
  rcases hEv with ⟨H0, hH0⟩
  refine ⟨H0, ?_⟩
  intro h hh0
  rcases hH0 h hh0 with ⟨hh16, hL, hLL, hS1, hN⟩
  have hh : 0 < h := by omega
  have hJ := globalProper_block_succ_cast_le hh hS1
  have hU := globalProper_top_log_le hN0 hN hJ
  have hLLU := globalProper_top_loglog_le hN0 hL hLL hS1 hU
  exact ⟨hh16, hL, hLL, hS1, hJ, hU, hLLU⟩

#print axioms globalProper_log_cutoff
#print axioms globalProper_block_cast_le
#print axioms globalProper_block_succ_cast_le
#print axioms globalProper_top_log_le
#print axioms globalProper_top_loglog_le
#print axioms globalProperWalfiszBounds

end PaperB.FixedQ
