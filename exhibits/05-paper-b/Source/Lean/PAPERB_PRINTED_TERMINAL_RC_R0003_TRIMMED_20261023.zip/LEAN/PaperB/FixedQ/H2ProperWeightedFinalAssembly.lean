import PaperB.FixedQ.H2ProperWeightedConsumer
import PaperB.FixedQ.H2ProperMomentTransfer
import Mathlib.Algebra.Order.Chebyshev

open scoped BigOperators ComplexConjugate

namespace PaperB.FixedQ

theorem fixedQProperWeightedBooleanIntervalDiscrepancy_erdosTuran_sq
    {q a H : ℕ} {S : Finset ℕ}
    (hq : 0 < q)
    (hActive : ∀ p ∈ S, activeHighPrime q p)
    (hOrd : S ∈ ordinaryTwoDimensionalSet H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H)
    (J : ℕ) (hJ : 1 ≤ J) :
    (fixedQProperWeightedDiscrepancy q a H S) ^ 2 ≤
      (6 * (fixedQPeriod q : ℝ)) ^ 2 *
        (32 / ((J : ℝ) ^ 2) +
          32 * (1 + Real.log (J : ℝ)) *
            (∑ j ∈ Finset.Icc 1 J,
              ‖fixedProductProperFourierCoeff S
                (fun p hp => (hActive p hp).1)
                ((j : ZMod (primeSetProduct S)) *
                  ((fixedProductBooleanPeriodicTwist
                    (fixedQPeriod q) H S
                    (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
                    ((ordinary_primeSetProduct_coprime_height_iff
                      (fun p hp => (hActive p hp).1)).mp hOrd).symm :
                      (ZMod (primeSetProduct S))ˣ) :
                    ZMod (primeSetProduct S)))‖ ^ 2 / (j : ℝ))) := by
  let P := fixedQPeriod q
  let hPrime : ∀ p ∈ S, p.Prime := fun p hp => (hActive p hp).1
  let hPcop : P.Coprime (primeSetProduct S) :=
    (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
  let hHcop : H.Coprime (primeSetProduct S) :=
    ((ordinary_primeSetProduct_coprime_height_iff hPrime).mp hOrd).symm
  let u := fixedProductBooleanPeriodicTwist P H S hPcop hHcop
  let B : ℝ :=
    32 / ((J : ℝ) ^ 2) +
      32 * (1 + Real.log (J : ℝ)) *
        (∑ j ∈ Finset.Icc 1 J,
          (fixedProductProperTwistedFrequencyMass S hPrime u j) ^ 2 /
            (j : ℝ))
  let term : Fin P → ℝ := fun c =>
    occupiedFixedQLowWeight q a H (c.1 + 1) *
      fixedProductProperAffineRootIntervalDiscrepancy
        S hPrime u
        (fixedProductBooleanPeriodicShift P S hPcop c.1)
        (periodicResidueLength P H c.1 % primeSetProduct S)
  have hPpos : 0 < P := by
    dsimp [P]
    unfold fixedQPeriod
    exact Nat.lcm_pos (by norm_num) hq
  have hmpos : 0 < primeSetProduct S := primeSetProduct_pos hPrime
  have hexact :=
    fixedQProperWeightedDiscrepancy_eq_periodic_affine_sum
      (q := q) (A := a) (H := H) (S := S)
      hq hActive hOrd h2admissible
  have hpoint : ∀ c : Fin P, (term c) ^ 2 ≤ 36 * B := by
    intro c
    have hw :=
      abs_occupiedFixedQLowWeight_le_six
        q a H (c.1 + 1) h2admissible
    have hwsq : (occupiedFixedQLowWeight q a H (c.1 + 1)) ^ 2 ≤ 36 := by
      calc
        (occupiedFixedQLowWeight q a H (c.1 + 1)) ^ 2 =
            |occupiedFixedQLowWeight q a H (c.1 + 1)| ^ 2 := by
              rw [sq_abs]
        _ ≤ (6 : ℝ) ^ 2 := by
              exact (sq_le_sq₀ (abs_nonneg _) (by norm_num)).2 hw
        _ = 36 := by norm_num
    have hET :=
      fixedProductProperAffineRootInterval_erdosTuran_sq
        S hPrime u
        (fixedProductBooleanPeriodicShift P S hPcop c.1)
        (periodicResidueLength P H c.1 % primeSetProduct S)
        J (Nat.mod_lt _ hmpos) hJ
    have hB0 : 0 ≤ B := (sq_nonneg
      (fixedProductProperAffineRootIntervalDiscrepancy
        S hPrime u
        (fixedProductBooleanPeriodicShift P S hPcop c.1)
        (periodicResidueLength P H c.1 % primeSetProduct S))).trans
      (by simpa [B] using hET)
    dsimp [term]
    rw [mul_pow]
    exact mul_le_mul hwsq (by simpa [B] using hET)
      (sq_nonneg _) (by norm_num)
  have hcs :
      (∑ c : Fin P, term c) ^ 2 ≤
        (P : ℝ) * ∑ c : Fin P, (term c) ^ 2 := by
    simpa using
      (sq_sum_le_card_mul_sum_sq
        (s := (Finset.univ : Finset (Fin P))) (f := term))
  calc
    (fixedQProperWeightedDiscrepancy q a H S) ^ 2
      = (∑ c : Fin P, term c) ^ 2 := by
          rw [hexact]
    _ ≤ (P : ℝ) * ∑ c : Fin P, (term c) ^ 2 := hcs
    _ ≤ (P : ℝ) * ∑ _c : Fin P, 36 * B := by
          gcongr with c hc
          exact hpoint c
    _ = (6 * (P : ℝ)) ^ 2 * B := by
          simp
          ring
    _ = _ := by
          dsimp [P, B, hPrime, hPcop, hHcop, u,
            fixedProductProperTwistedFrequencyMass]

noncomputable def h2BooleanProperFourierNormSqTwisted
    (q : ℕ) (S : Finset ℕ) (j : ℕ)
    (u0 : (ZMod (primeSetProduct S))ˣ) : ℝ :=
  if hA : ∀ p ∈ S, activeHighPrime q p then
    ‖fixedProductProperFourierCoeff S
      (fun p hp => (hA p hp).1)
      ((j : ZMod (primeSetProduct S)) *
        (u0 : ZMod (primeSetProduct S)))‖ ^ 2
  else 0

lemma h2BooleanProperFourierNormSqTwisted_nonneg
    (q : ℕ) (S : Finset ℕ) (j : ℕ)
    (u0 : (ZMod (primeSetProduct S))ˣ) :
    0 ≤ h2BooleanProperFourierNormSqTwisted q S j u0 := by
  unfold h2BooleanProperFourierNormSqTwisted
  split_ifs
  · positivity
  · exact le_rfl

noncomputable def h2BooleanDyadicProperFrequencySecondMomentTwisted
    (q M j : ℕ)
    (u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ) : ℝ :=
  ∑ S ∈ h2BooleanDyadicSets q M,
    finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
      h2BooleanProperFourierNormSqTwisted q S j (u S)

lemma h2BooleanProperFourierNormSqTwisted_le_transfer
    {q M j : ℕ} {S : Finset ℕ}
    (hS : S ∈ h2BooleanDyadicSets q M)
    (hM : 2 ≤ M)
    (u0 : (ZMod (primeSetProduct S))ˣ) :
    h2BooleanProperFourierNormSqTwisted q S j u0 ≤
      2 * h2BooleanFourierNormSqTwisted q S j u0 +
        8 * (((4 : ℝ) ^ S.card)⁻¹) := by
  have hActive := h2BooleanDyadicSets_active hS
  have hPrime : ∀ p ∈ S, p.Prime := fun p hp => (hActive p hp).1
  have hmpos : 0 < primeSetProduct S := primeSetProduct_pos hPrime
  letI : NeZero (primeSetProduct S) := ⟨hmpos.ne'⟩
  have hne : S.Nonempty := by
    by_contra h
    have hS0 : S = ∅ := Finset.not_nonempty_iff_eq_empty.mp h
    subst S
    have hr := h2BooleanDyadicSets_range hS
    simp [primeSetProduct] at hr
    omega
  let t : ZMod (primeSetProduct S) :=
    (j : ZMod (primeSetProduct S)) * (u0 : ZMod (primeSetProduct S))
  have hid :=
    fixedProductProperFourierCoeff_eq_full_sub_endpoints
      S hPrime hne t
  have hchi := norm_stdAddChar_eq_one (primeSetProduct S) t
  unfold h2BooleanProperFourierNormSqTwisted
    h2BooleanFourierNormSqTwisted
  rw [dif_pos hActive, dif_pos hActive]
  exact properCoeffSquare_le_full_add_endpoint_correction hid hchi

theorem h2BooleanOrdinaryDyadicProperWeightedDiscrepancyL2_le_ET
    {q A H M J : ℕ}
    (hq : 0 < q)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H)
    (hJ : 1 ≤ J) :
    (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
        |fixedQProperWeightedDiscrepancy q A H S| ^ 2) ≤
      (6 * (fixedQPeriod q : ℝ)) ^ 2 *
        ((32 / ((J : ℝ) ^ 2)) *
          (∑ S ∈ h2BooleanDyadicSets q M,
            finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) +
        32 * (1 + Real.log (J : ℝ)) *
          (∑ j ∈ Finset.Icc 1 J,
            h2BooleanDyadicProperFrequencySecondMomentTwisted
              q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ))) := by
  let F := h2BooleanOrdinaryDyadicSets q H M
  let G := h2BooleanDyadicSets q M
  let C : ℝ := (6 * (fixedQPeriod q : ℝ)) ^ 2
  let a0 : ℝ := 32 / ((J : ℝ) ^ 2)
  let b0 : ℝ := 32 * (1 + Real.log (J : ℝ))
  let Q : Finset ℕ → ℝ := fun S =>
    ∑ j ∈ Finset.Icc 1 J,
      h2BooleanProperFourierNormSqTwisted q S j
        (fixedQPeriodicTotalTwist q H S) / (j : ℝ)
  have hpoint : ∀ S ∈ F,
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
          |fixedQProperWeightedDiscrepancy q A H S| ^ 2
        ≤
      (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) *
        (C * (a0 + b0 * Q S)) := by
    intro S hSF
    have hm := h2BooleanOrdinaryDyadicSets_mem hSF
    have hActive := h2BooleanDyadicSets_active hm.1
    have hPrime : ∀ p ∈ S, p.Prime := fun p hp => (hActive p hp).1
    have hET :=
      fixedQProperWeightedBooleanIntervalDiscrepancy_erdosTuran_sq
        (q := q) (a := A) (H := H) (S := S)
        hq hActive hm.2 h2admissible J hJ
    have htw :=
      fixedQPeriodicTotalTwist_eq_periodic
        (q := q) (H := H) hActive hm.2
    have hfreq :
        (∑ j ∈ Finset.Icc 1 J,
          ‖fixedProductProperFourierCoeff S hPrime
            ((j : ZMod (primeSetProduct S)) *
              ((fixedProductBooleanPeriodicTwist
                (fixedQPeriod q) H S
                (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
                ((ordinary_primeSetProduct_coprime_height_iff hPrime).mp hm.2).symm :
                  (ZMod (primeSetProduct S))ˣ) :
                ZMod (primeSetProduct S)))‖ ^ 2 / (j : ℝ)) =
          Q S := by
      unfold Q h2BooleanProperFourierNormSqTwisted
      apply Finset.sum_congr rfl
      intro j hj
      rw [dif_pos hActive]
      rw [htw]
    have hET' :
        |fixedQProperWeightedDiscrepancy q A H S| ^ 2 ≤
          C * (a0 + b0 * Q S) := by
      rw [sq_abs]
      rw [hfreq] at hET
      simpa [C, a0, b0] using hET
    have hw0 :
        0 ≤ finiteOmegaWeightReal S * h2BooleanV0 ^ S.card :=
      mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hActive)
        (pow_nonneg h2BooleanV0_nonneg _)
    exact mul_le_mul_of_nonneg_left hET' hw0
  have hsumPoint :
      (∑ S ∈ F,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
          |fixedQProperWeightedDiscrepancy q A H S| ^ 2) ≤
      ∑ S ∈ F,
        (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) *
          (C * (a0 + b0 * Q S)) := by
    apply Finset.sum_le_sum
    intro S hS
    exact hpoint S hS
  have hsub : F ⊆ G := by
    intro S hS
    exact (h2BooleanOrdinaryDyadicSets_mem hS).1
  have hconst :
      (∑ S ∈ F,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) ≤
      ∑ S ∈ G,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card := by
    apply Finset.sum_le_sum_of_subset_of_nonneg hsub
    intro S hSG hnot
    have hActive := h2BooleanDyadicSets_active hSG
    exact mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hActive)
      (pow_nonneg h2BooleanV0_nonneg _)
  have hfreqsum :
      (∑ S ∈ F,
        (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) * Q S) ≤
      ∑ j ∈ Finset.Icc 1 J,
        h2BooleanDyadicProperFrequencySecondMomentTwisted
          q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ) := by
    calc
      (∑ S ∈ F,
        (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) * Q S)
        = ∑ j ∈ Finset.Icc 1 J, ∑ S ∈ F,
            (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
              h2BooleanProperFourierNormSqTwisted q S j
                (fixedQPeriodicTotalTwist q H S)) / (j : ℝ) := by
          unfold Q
          rw [Finset.sum_comm]
          apply Finset.sum_congr rfl
          intro S hSF
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro j hj
          ring
      _ ≤ ∑ j ∈ Finset.Icc 1 J, ∑ S ∈ G,
            (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
              h2BooleanProperFourierNormSqTwisted q S j
                (fixedQPeriodicTotalTwist q H S)) / (j : ℝ) := by
          apply Finset.sum_le_sum
          intro j hj
          apply Finset.sum_le_sum_of_subset_of_nonneg hsub
          intro S hSG hnot
          have hActive := h2BooleanDyadicSets_active hSG
          exact div_nonneg
            (mul_nonneg
              (mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hActive)
                (pow_nonneg h2BooleanV0_nonneg _))
              (h2BooleanProperFourierNormSqTwisted_nonneg
                q S j (fixedQPeriodicTotalTwist q H S)))
            (by positivity)
      _ = _ := by
          apply Finset.sum_congr rfl
          intro j hj
          rw [← Finset.sum_div]
          unfold h2BooleanDyadicProperFrequencySecondMomentTwisted
          rfl
  have hlogJ0 : 0 ≤ 1 + Real.log (J : ℝ) := by
    have hJR : (1 : ℝ) ≤ (J : ℝ) := by exact_mod_cast hJ
    exact add_nonneg (by norm_num) (Real.log_nonneg hJR)
  calc
    _ ≤ ∑ S ∈ F,
        (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) *
          (C * (a0 + b0 * Q S)) := hsumPoint
    _ = C * (a0 * (∑ S ∈ F,
          finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) +
        b0 * (∑ S ∈ F,
          (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) * Q S)) := by
      calc
        _ = (∑ S ∈ F,
              (C * a0) *
                (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card)) +
            (∑ S ∈ F,
              (C * b0) *
                ((finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) * Q S)) := by
              rw [← Finset.sum_add_distrib]
              apply Finset.sum_congr rfl
              intro S hS
              ring
        _ = _ := by
              rw [← Finset.mul_sum, ← Finset.mul_sum]
              ring
    _ ≤ C * (a0 * (∑ S ∈ G,
          finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) +
        b0 * (∑ j ∈ Finset.Icc 1 J,
          h2BooleanDyadicProperFrequencySecondMomentTwisted
            q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ))) := by
      have hC0 : 0 ≤ C := by dsimp [C]; positivity
      have ha0 : 0 ≤ a0 := by dsimp [a0]; positivity
      have hb0 : 0 ≤ b0 := by dsimp [b0]; positivity
      gcongr
    _ = _ := by rfl

lemma h2BooleanProperMomentHarmonic_le
    {q M J : ℕ}
    {u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ}
    {C X : ℝ}
    (hJ : 1 ≤ J)
    (hC : 0 ≤ C)
    (hX : 0 ≤ X)
    (hmom : ∀ j ∈ Finset.Icc 1 J,
      h2BooleanDyadicProperFrequencySecondMomentTwisted q M j u ≤
        C * X * (1 + Real.log (j : ℝ)) ^ (h2BooleanV0 / 2)) :
    (1 + Real.log (J : ℝ)) *
      (∑ j ∈ Finset.Icc 1 J,
        h2BooleanDyadicProperFrequencySecondMomentTwisted q M j u /
          (j : ℝ)) ≤
      C * X *
        (1 + Real.log (J : ℝ)) ^ (h2BooleanV0 / 2 + 2) := by
  let L : ℝ := 1 + Real.log (J : ℝ)
  have hJR : (1 : ℝ) ≤ (J : ℝ) := by exact_mod_cast hJ
  have hL1 : 1 ≤ L := by
    dsimp [L]
    linarith [Real.log_nonneg hJR]
  have hhalf0 : 0 ≤ h2BooleanV0 / 2 :=
    div_nonneg h2BooleanV0_nonneg (by norm_num)
  have hsum :
      (∑ j ∈ Finset.Icc 1 J,
        h2BooleanDyadicProperFrequencySecondMomentTwisted q M j u /
          (j : ℝ)) ≤
        C * X * L ^ (h2BooleanV0 / 2) *
          (∑ j ∈ Finset.Icc 1 J, (1 : ℝ) / (j : ℝ)) := by
    calc
      _ ≤ ∑ j ∈ Finset.Icc 1 J,
          (C * X * L ^ (h2BooleanV0 / 2)) / (j : ℝ) := by
        apply Finset.sum_le_sum
        intro j hj
        have hjI := Finset.mem_Icc.mp hj
        have hjR : (1 : ℝ) ≤ (j : ℝ) := by exact_mod_cast hjI.1
        have hjJ : (j : ℝ) ≤ (J : ℝ) := by exact_mod_cast hjI.2
        have hlogle := Real.log_le_log (by positivity) hjJ
        have hbase :
            1 + Real.log (j : ℝ) ≤ L := by
          dsimp [L]
          linarith
        have hpow :
            (1 + Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) ≤
              L ^ (h2BooleanV0 / 2) := by
          apply Real.rpow_le_rpow
          · linarith [Real.log_nonneg hjR]
          · exact hbase
          · exact hhalf0
        have hm := hmom j hj
        have hden : 0 ≤ (j : ℝ) := by positivity
        exact div_le_div_of_nonneg_right
          (hm.trans (mul_le_mul_of_nonneg_left hpow (mul_nonneg hC hX)))
          hden
      _ = _ := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro j hj
        ring
  have hharm :
      (∑ j ∈ Finset.Icc 1 J, (1 : ℝ) / (j : ℝ)) ≤ L := by
    simpa [L] using frequency_harmonic_factor_le_log J
  have hCX : 0 ≤ C * X := mul_nonneg hC hX
  have hLp0 : 0 ≤ L ^ (h2BooleanV0 / 2) :=
    Real.rpow_nonneg (le_trans (by norm_num) hL1) _
  calc
    L * (∑ j ∈ Finset.Icc 1 J,
      h2BooleanDyadicProperFrequencySecondMomentTwisted q M j u /
        (j : ℝ))
      ≤ L * (C * X * L ^ (h2BooleanV0 / 2) *
          (∑ j ∈ Finset.Icc 1 J, (1 : ℝ) / (j : ℝ))) := by
            exact mul_le_mul_of_nonneg_left hsum
              (le_trans (by norm_num) hL1)
    _ ≤ L * (C * X * L ^ (h2BooleanV0 / 2) * L) := by
          gcongr
    _ = C * X * L ^ (h2BooleanV0 / 2 + 2) := by
          have hLpos : 0 < L := lt_of_lt_of_le zero_lt_one hL1
          rw [show h2BooleanV0 / 2 + 2 =
            h2BooleanV0 / 2 + (2 : ℝ) by ring]
          rw [Real.rpow_add hLpos]
          rw [Real.rpow_two]
          ring

theorem h2BooleanDyadicProperFrequencySecondMomentTwisted_le_rate_concrete
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ M0 : ℕ,
      0 ≤ C ∧
      ∀ M j : ℕ,
      ∀ u : ∀ S : Finset ℕ, (ZMod (primeSetProduct S))ˣ,
      H2BooleanTwistFamilyCompatible
        q (h2BooleanRoughCutoff M) M j u →
      M0 ≤ M →
      3 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      1 ≤ j →
      3 ≤ Nat.nthRoot 4 M →
      (h2BooleanRoughCutoff M) ^ 2 ≤ M →
      ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
      ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
      1 ≤ Real.log (M : ℝ) →
      h2BooleanTailCorrectionConst ≤
        (1 / 8 : ℝ) * (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) →
      Real.exp (-(1 / 8 : ℝ) *
        (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) ≤
          (Real.log (M : ℝ)) ^ (-4 : ℝ) →
      h2BooleanDyadicProperFrequencySecondMomentTwisted q M j u ≤
        C * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
          (1 + Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by
  rcases h2BooleanDyadicProperFrequencySecondMomentTwisted_le_rate q hq with
    ⟨C, M0, hrate⟩
  refine ⟨|C|, M0, abs_nonneg C, ?_⟩
  intro M j u hcompat hM0 hM3 hY4 hj hroot hYsq
    hquarter hk hlog hTail hdec
  let properSq : Finset ℕ → ℝ :=
    fun S => h2BooleanProperFourierNormSqTwisted q S j (u S)
  have hM2 : 2 ≤ M := by omega
  have hproper : ∀ S ∈ h2BooleanDyadicSets q M,
      properSq S ≤
        2 * h2BooleanFourierNormSqTwisted q S j (u S) +
          8 * (((4 : ℝ) ^ S.card)⁻¹) := by
    intro S hS
    exact h2BooleanProperFourierNormSqTwisted_le_transfer hS hM2 (u S)
  have hraw := hrate M j u properSq hproper hcompat hM0 hM3 hY4 hj
    hroot hYsq hquarter hk hlog hTail hdec
  have hX0 : 0 ≤ (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) :=
    Real.rpow_nonneg (le_trans (by norm_num) hlog) _
  have hLj0 : 0 ≤
      (1 + Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by
    have hjR : (1 : ℝ) ≤ (j : ℝ) := by exact_mod_cast hj
    exact Real.rpow_nonneg
      (add_nonneg (by norm_num) (Real.log_nonneg hjR)) _
  have hcoef :
      C * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
          (1 + Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) ≤
      |C| * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
          (1 + Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by
    exact mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_right (le_abs_self C) hX0) hLj0
  simpa [h2BooleanDyadicProperFrequencySecondMomentTwisted, properSq] using
    hraw.trans hcoef

theorem h2BooleanOrdinaryDyadicProperWeightedDiscrepancyL2_le_rate
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ M0 : ℕ,
      0 ≤ C ∧
      ∀ A H M : ℕ,
        (¬ 2 ∣ q → 2 ∣ H) →
        M0 ≤ M →
        3 ≤ M →
        4 ≤ h2BooleanRoughCutoff M →
        3 ≤ Nat.nthRoot 4 M →
        (h2BooleanRoughCutoff M) ^ 2 ≤ M →
        ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
        ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
        2 ≤ Real.log (M : ℝ) →
        1 ≤ Real.log (Real.log (M : ℝ)) →
        h2BooleanTailCorrectionConst ≤
          (1 / 8 : ℝ) *
            (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) →
        Real.exp (-(1 / 8 : ℝ) *
            (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) ≤
          (Real.log (M : ℝ)) ^ (-4 : ℝ) →
        (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
          finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
            |fixedQProperWeightedDiscrepancy
              q A H S| ^ 2) ≤
          C * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
            (Real.log (Real.log (M : ℝ))) ^ (4 : ℝ) := by
  rcases h2BooleanDyadicProperFrequencySecondMomentTwisted_le_rate_concrete q hq with
    ⟨CP, MP, hCP0, hProperRate⟩
  rcases h2BooleanETTruncation_le_main_rate q hq with
    ⟨CT, MT, hCT0, hTrunc⟩
  let α : ℝ := h2BooleanV0 / 2 + 2
  let CM : ℝ := 32 * CP * (2 : ℝ) ^ α
  let C : ℝ := (6 * (fixedQPeriod q : ℝ)) ^ 2 * (CT + CM)
  refine ⟨C, max MP MT, ?_, ?_⟩
  · dsimp [C, CM, α]
    positivity
  · intro A H M h2admissible hM0 hM3 hY4 hroot hYsq
      hquarter hk hlog2 hll hTail hdec
    have hMP : MP ≤ M := (le_max_left MP MT).trans hM0
    have hMT : MT ≤ M := (le_max_right MP MT).trans hM0
    have hM2 : 2 ≤ M := by omega
    have hlog1 : 1 ≤ Real.log (M : ℝ) := by linarith
    let J := h2BooleanETCutoff M
    have hJ : 1 ≤ J := by
      dsimp [J]
      exact h2BooleanETCutoff_one_le hlog1
    have hraw :=
      h2BooleanOrdinaryDyadicProperWeightedDiscrepancyL2_le_ET
        (q := q) (A := A) (H := H) (M := M) (J := J)
        hq h2admissible hJ
    have htr := hTrunc M hMT hM2 hquarter hk hlog2
    have hmom : ∀ j ∈ Finset.Icc 1 J,
        h2BooleanDyadicProperFrequencySecondMomentTwisted
            q M j (fixedQPeriodicTotalTwist q H) ≤
          CP * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
            (1 + Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by
      intro j hj
      have hj1 : 1 ≤ j := (Finset.mem_Icc.mp hj).1
      exact hProperRate M j (fixedQPeriodicTotalTwist q H)
        (fixedQPeriodicTotalTwist_familyCompatible
          q H (h2BooleanRoughCutoff M) M j)
        hMP hM3 hY4 hj1 hroot hYsq hquarter hk hlog1 hTail hdec
    let X : ℝ := (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1)
    let LL : ℝ := Real.log (Real.log (M : ℝ))
    have hX0 : 0 ≤ X :=
      Real.rpow_nonneg (le_trans (by norm_num) hlog1) _
    have hharm :=
      h2BooleanProperMomentHarmonic_le
        (q := q) (M := M) (J := J)
        (u := fixedQPeriodicTotalTwist q H)
        (C := CP) (X := X) hJ hCP0 hX0
        (by
          intro j hj
          simpa [X] using hmom j hj)
    have hllpow :=
      h2BooleanET_loglog_power_le_four
        (M := M) hlog1 hll
    have htr' :
        (32 / ((J : ℝ) ^ 2)) *
            (∑ S ∈ h2BooleanDyadicSets q M,
              finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) ≤
          CT * X * LL ^ (4 : ℝ) := by
      have hLL1 : 1 ≤ LL := by simpa [LL] using hll
      have hLL4one : 1 ≤ LL ^ (4 : ℝ) :=
        Real.one_le_rpow hLL1 (by norm_num)
      have hbase0 : 0 ≤ CT * X := mul_nonneg hCT0 hX0
      calc
        _ ≤ CT * X := by simpa [J, X] using htr
        _ ≤ CT * X * LL ^ (4 : ℝ) := by
          simpa using mul_le_mul_of_nonneg_left hLL4one hbase0
    have hmoment' :
        32 * (1 + Real.log (J : ℝ)) *
          (∑ j ∈ Finset.Icc 1 J,
            h2BooleanDyadicProperFrequencySecondMomentTwisted
              q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ)) ≤
          CM * X * LL ^ (4 : ℝ) := by
      have hleft :
          (1 + Real.log (J : ℝ)) *
            (∑ j ∈ Finset.Icc 1 J,
              h2BooleanDyadicProperFrequencySecondMomentTwisted
                q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ)) ≤
            CP * X * (1 + Real.log (J : ℝ)) ^ α := by
        simpa [α] using hharm
      have hαpow0 : 0 ≤ (2 : ℝ) ^ α :=
        Real.rpow_nonneg (by norm_num) _
      calc
        32 * (1 + Real.log (J : ℝ)) *
            (∑ j ∈ Finset.Icc 1 J,
              h2BooleanDyadicProperFrequencySecondMomentTwisted
                q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ))
          = 32 * ((1 + Real.log (J : ℝ)) *
            (∑ j ∈ Finset.Icc 1 J,
              h2BooleanDyadicProperFrequencySecondMomentTwisted
                q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ))) := by ring
        _ ≤ 32 * (CP * X * (1 + Real.log (J : ℝ)) ^ α) := by
          gcongr
        _ ≤ 32 * (CP * X * ((2 : ℝ) ^ α * LL ^ (4 : ℝ))) := by
          gcongr
        _ = CM * X * LL ^ (4 : ℝ) := by
          dsimp [CM]
          ring
    calc
      (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
          |fixedQProperWeightedDiscrepancy q A H S| ^ 2)
        ≤ (6 * (fixedQPeriod q : ℝ)) ^ 2 *
          ((32 / ((J : ℝ) ^ 2)) *
            (∑ S ∈ h2BooleanDyadicSets q M,
              finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) +
          32 * (1 + Real.log (J : ℝ)) *
            (∑ j ∈ Finset.Icc 1 J,
              h2BooleanDyadicProperFrequencySecondMomentTwisted
                q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ))) := hraw
      _ ≤ (6 * (fixedQPeriod q : ℝ)) ^ 2 *
          ((CT * X * LL ^ (4 : ℝ)) +
           (CM * X * LL ^ (4 : ℝ))) := by
            gcongr
      _ = C * X * LL ^ (4 : ℝ) := by
            dsimp [C]
            ring
      _ = _ := by rfl

noncomputable def h2BooleanProperWeightedDyadicShell
    (q A H M : ℕ) : ℝ :=
  ∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
    finiteOmegaWeightReal S * (2 : ℝ) ^ S.card *
      |fixedQProperWeightedDiscrepancy q A H S|

lemma h2BooleanProperWeightedDyadicShell_nonneg
    (q A H M : ℕ) :
    0 ≤ h2BooleanProperWeightedDyadicShell q A H M := by
  unfold h2BooleanProperWeightedDyadicShell
  apply Finset.sum_nonneg
  intro S hS
  have hm := h2BooleanOrdinaryDyadicSets_mem hS
  have hA := h2BooleanDyadicSets_active hm.1
  exact mul_nonneg
    (mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hA)
      (pow_nonneg (by norm_num) _))
    (abs_nonneg _)

theorem h2BooleanProperWeightedDyadicShell_cauchy_sq
    {q A H M : ℕ} :
    (h2BooleanProperWeightedDyadicShell q A H M) ^ 2 ≤
      (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
        finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) *
      (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
          |fixedQProperWeightedDiscrepancy q A H S| ^ 2) := by
  unfold h2BooleanProperWeightedDyadicShell
  apply ordinaryBooleanWeightedCauchy_source_tilts
  intro S hS
  have hm := h2BooleanOrdinaryDyadicSets_mem hS
  have hA := h2BooleanDyadicSets_active hm.1
  exact finiteOmegaWeightReal_nonneg_of_active hA

theorem h2BooleanProperWeightedDyadicShell_le_rate_of_conditions
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ M0 : ℕ,
      0 ≤ C ∧
      ∀ A H M : ℕ,
        (¬ 2 ∣ q → 2 ∣ H) →
        M0 ≤ M →
        3 ≤ M →
        4 ≤ h2BooleanRoughCutoff M →
        3 ≤ Nat.nthRoot 4 M →
        (h2BooleanRoughCutoff M) ^ 2 ≤ M →
        ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
        ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
        2 ≤ Real.log (M : ℝ) →
        1 ≤ Real.log (Real.log (M : ℝ)) →
        h2BooleanTailCorrectionConst ≤
          (1 / 8 : ℝ) *
            (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) →
        Real.exp (-(1 / 8 : ℝ) *
            (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) ≤
          (Real.log (M : ℝ)) ^ (-4 : ℝ) →
        h2BooleanProperWeightedDyadicShell q A H M ≤
          C * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
            (Real.log (Real.log (M : ℝ))) ^ 2 := by
  rcases h2BooleanDyadicFirstWeightMoment_le_log_rate q hq with
    ⟨C1, M1, hC1, hFirst⟩
  rcases h2BooleanOrdinaryDyadicProperWeightedDiscrepancyL2_le_rate q hq with
    ⟨C2, M2, hC2, hL2⟩
  let C : ℝ := C1 * C2 + 1
  refine ⟨C, max M1 M2, ?_, ?_⟩
  · dsimp [C]
    nlinarith [mul_nonneg hC1 hC2]
  · intro A H M h2admissible hM0 hM3 hY4 hroot hYsq
      hquarter hk hlog2 hll hTail hdec
    have hM2 : 2 ≤ M := by omega
    have hM1 : M1 ≤ M := (le_max_left M1 M2).trans hM0
    have hM2' : M2 ≤ M := (le_max_right M1 M2).trans hM0
    have hlog1 : 1 ≤ Real.log (M : ℝ) := by linarith
    let F := h2BooleanOrdinaryDyadicSets q H M
    let G := h2BooleanDyadicSets q M
    let D : Finset ℕ → ℝ :=
      fun S => fixedQProperWeightedDiscrepancy q A H S
    let X : ℝ := (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1)
    let LL : ℝ := Real.log (Real.log (M : ℝ))
    let Shell : ℝ := h2BooleanProperWeightedDyadicShell q A H M
    have hFirstRate :
        (∑ S ∈ G,
          finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) ≤ C1 * X := by
      simpa [G, X] using hFirst M hM1 hM2 hquarter hk hlog1
    have hL2Rate :
        (∑ S ∈ F,
          finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * |D S| ^ 2) ≤
          C2 * X * LL ^ (4 : ℝ) := by
      simpa [F, D, X, LL] using
        hL2 A H M h2admissible hM2' hM3 hY4 hroot hYsq
          hquarter hk hlog2 hll hTail hdec
    have hCauchy :
        Shell ^ 2 ≤
          (∑ S ∈ F,
            finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) *
          (∑ S ∈ F,
            finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * |D S| ^ 2) := by
      simpa [Shell, F, D] using
        h2BooleanProperWeightedDyadicShell_cauchy_sq
          (q := q) (A := A) (H := H) (M := M)
    have hsub : F ⊆ G := by
      intro S hS
      exact (h2BooleanOrdinaryDyadicSets_mem hS).1
    have hFirstSub :
        (∑ S ∈ F,
          finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) ≤
        ∑ S ∈ G,
          finiteOmegaWeightReal S * h2BooleanX0 ^ S.card := by
      apply Finset.sum_le_sum_of_subset_of_nonneg hsub
      intro S hSG hnot
      have hActive := h2BooleanDyadicSets_active hSG
      exact mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hActive)
        (pow_nonneg h2BooleanX0_nonneg _)
    have hF2nonneg :
        0 ≤ ∑ S ∈ F,
          finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * |D S| ^ 2 := by
      apply Finset.sum_nonneg
      intro S hSF
      have hm := h2BooleanOrdinaryDyadicSets_mem hSF
      have hActive := h2BooleanDyadicSets_active hm.1
      exact mul_nonneg
        (mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hActive)
          (pow_nonneg h2BooleanV0_nonneg _))
        (sq_nonneg _)
    have hX0 : 0 ≤ X := by
      dsimp [X]
      exact Real.rpow_nonneg (le_trans (by norm_num) hlog1) _
    have hLL1 : 1 ≤ LL := by simpa [LL] using hll
    have hC1X0 : 0 ≤ C1 * X := mul_nonneg hC1 hX0
    have hSq :
        Shell ^ 2 ≤ (C1 * X) * (C2 * X * LL ^ (4 : ℝ)) := by
      calc
        Shell ^ 2
          ≤ (∑ S ∈ F,
              finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) *
            (∑ S ∈ F,
              finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * |D S| ^ 2) :=
                hCauchy
        _ ≤ (∑ S ∈ G,
              finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) *
            (∑ S ∈ F,
              finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * |D S| ^ 2) :=
                mul_le_mul_of_nonneg_right hFirstSub hF2nonneg
        _ ≤ (C1 * X) *
            (∑ S ∈ F,
              finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * |D S| ^ 2) :=
                mul_le_mul_of_nonneg_right hFirstRate hF2nonneg
        _ ≤ (C1 * X) * (C2 * X * LL ^ (4 : ℝ)) :=
                mul_le_mul_of_nonneg_left hL2Rate hC1X0
    let K : ℝ := C1 * C2
    let Z : ℝ := X ^ 2 * LL ^ (4 : ℕ)
    have hLL4 : LL ^ (4 : ℝ) = LL ^ (4 : ℕ) :=
      Real.rpow_natCast LL 4
    have hK0 : 0 ≤ K := by dsimp [K]; exact mul_nonneg hC1 hC2
    have hZ0 : 0 ≤ Z := by dsimp [Z]; positivity
    have hKle : K ≤ (K + 1) ^ 2 := by nlinarith [sq_nonneg K]
    have hProd :
        (C1 * X) * (C2 * X * LL ^ (4 : ℝ)) ≤
          (C * X * LL ^ 2) ^ 2 := by
      have hleft :
          (C1 * X) * (C2 * X * LL ^ (4 : ℝ)) = K * Z := by
        rw [hLL4]
        dsimp [K, Z]
        ring
      have hright :
          (C * X * LL ^ 2) ^ 2 = (K + 1) ^ 2 * Z := by
        dsimp [C, K, Z]
        ring
      rw [hleft, hright]
      exact mul_le_mul_of_nonneg_right hKle hZ0
    have hC0 : 0 ≤ C := by
      dsimp [C]
      exact add_nonneg (mul_nonneg hC1 hC2) (by norm_num)
    have hTarget0 : 0 ≤ C * X * LL ^ 2 :=
      mul_nonneg (mul_nonneg hC0 hX0) (sq_nonneg LL)
    have hSqTarget : Shell ^ 2 ≤ (C * X * LL ^ 2) ^ 2 :=
      hSq.trans hProd
    have hShell : Shell ≤ C * X * LL ^ 2 :=
      le_of_sq_le_sq hSqTarget hTarget0
    simpa [Shell, C, X, LL] using hShell

#print axioms fixedQProperWeightedBooleanIntervalDiscrepancy_erdosTuran_sq
#print axioms h2BooleanOrdinaryDyadicProperWeightedDiscrepancyL2_le_ET
#print axioms h2BooleanProperMomentHarmonic_le
#print axioms h2BooleanOrdinaryDyadicProperWeightedDiscrepancyL2_le_rate
#print axioms h2BooleanProperWeightedDyadicShell_cauchy_sq
#print axioms h2BooleanProperWeightedDyadicShell_le_rate_of_conditions

end PaperB.FixedQ
