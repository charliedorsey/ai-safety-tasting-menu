import PaperB.FixedQ.GlobalProperProductSplit
import PaperB.FixedQ.GlobalProperSmallBoxTerminal
import PaperB.TerminalAssembly

open Filter Real Asymptotics
open scoped BigOperators

namespace PaperB.FixedQ

theorem twoDimensionalRemainderContract_of_globalProper_split_inputs
    (hSmall : ∀ q : ℕ, 0 < q → Squarefree q →
      GlobalProperSmallBoxLogPowerSaving q)
    (hExt : ∀ q : ℕ, 0 < q → Squarefree q →
      GlobalProperExteriorSublog q) :
    PaperB.Closure.TwoDimensionalRemainderContract := by
  intro q hq hsq eps heps
  let delta : ℝ := eps / 3
  have hdelta : 0 < delta := by
    dsimp [delta]
    positivity
  obtain ⟨hA, hAspec⟩ :=
    globalProperAnalytic_sublog_of_split q hq
      (hSmall q hq hsq)
      (hExt q hq hsq) delta hdelta
  have hC0 : 0 ≤ fixedQDensityDefectUniformBound q := by
    unfold fixedQDensityDefectUniformBound
    positivity
  obtain ⟨hO, hOspec⟩ :=
    PaperB.Closure.exists_nat_threshold_const_le_eps_log hC0 hdelta
  obtain ⟨hD, hDspec⟩ :=
    decoratedDensityRemainder_sublog q hq delta hdelta
  refine ⟨max hA (max hO hD), ?_⟩
  intro a b h ha hb hcompat h2 hh hlarge
  have hAh : hA ≤ h := (le_max_left hA (max hO hD)).trans hlarge
  have hOh : hO ≤ h :=
    (le_max_left hO hD).trans
      ((le_max_right hA (max hO hD)).trans hlarge)
  have hDh : hD ≤ h :=
    (le_max_right hO hD).trans
      ((le_max_right hA (max hO hD)).trans hlarge)
  have han := hAspec a b h ha hb hcompat h2 hh hAh
  have hordDensity :=
    abs_cStar_mul_ordinaryDensityCore_le
      (q := q) (a := a) (h := h) hq hh h2
  have hord := hOspec h hOh
  have hdecDensity := hDspec a h h2 hh hDh
  have hreflect := PaperB.Closure.reflected_coprime_equiv hq hcompat
  rw [twoDimensionalFamilyRemainder_eq_ordinary_add_decorated hreflect]
  rw [ordinaryTwoDimensionalRemainder_eq_cores hq hh h2 hreflect]
  rw [decoratedTwoDimensionalRemainder_eq_analytic_add_density
    hq hh h2 hreflect]
  rw [mul_add, mul_add, mul_add]
  calc
    |(cStarReal q h * ordinaryBooleanCore q a h +
        cStarReal q h * ordinaryDensityCore q a h) +
      (cStarReal q h * decoratedAnalyticRemainder q a h +
        cStarReal q h * decoratedDensityRemainder q a h)|
      = |cStarReal q h *
          (ordinaryBooleanCore q a h +
            decoratedAnalyticRemainder q a h) +
          cStarReal q h * ordinaryDensityCore q a h +
          cStarReal q h * decoratedDensityRemainder q a h| := by
            congr 1
            ring
    _ ≤ |cStarReal q h *
          (ordinaryBooleanCore q a h +
            decoratedAnalyticRemainder q a h)| +
        |cStarReal q h * ordinaryDensityCore q a h| +
        |cStarReal q h * decoratedDensityRemainder q a h| := by
          exact (abs_add_le _ _).trans
            (add_le_add (abs_add_le _ _) (le_refl _))
    _ ≤ delta * Real.log (h : ℝ) +
          fixedQDensityDefectUniformBound q +
          delta * Real.log (h : ℝ) := by
        exact add_le_add
          (add_le_add han hordDensity) hdecDensity
    _ ≤ delta * Real.log (h : ℝ) +
          delta * Real.log (h : ℝ) +
          delta * Real.log (h : ℝ) := by
        exact add_le_add
          (add_le_add (le_refl _) hord)
          (le_refl _)
    _ = eps * Real.log (h : ℝ) := by
        dsimp [delta]
        ring

theorem paperBTerminal_of_globalProper_split_inputs
    (hSmall : ∀ q : ℕ, 0 < q → Squarefree q →
      GlobalProperSmallBoxLogPowerSaving q)
    (hExt : ∀ q : ℕ, 0 < q → Squarefree q →
      GlobalProperExteriorSublog q) :
    PaperB.Closure.PaperBTerminalStatement := by
  have hTwoDim : PaperB.Closure.TwoDimensionalRemainderContract :=
    twoDimensionalRemainderContract_of_globalProper_split_inputs hSmall hExt
  intro q hq hsq eps heps
  let delta : ℝ := eps / 3
  have hdelta : 0 < delta := by
    dsimp [delta]
    positivity
  obtain ⟨hH1, hH1spec⟩ :=
    PaperB.Admission.sourceNativeH1Control_fixedQ q hq hsq delta hdelta
  obtain ⟨hS, hSspec⟩ :=
    PaperB.TerminalAssembly.shiftedTwoDimensionalRemainder_sublog_of_contract
      hTwoDim q hq hsq delta hdelta
  refine ⟨max hH1 hS, ?_⟩
  intro a b h ha hb hcompat h2 hh hlarge
  have hH1h : hH1 ≤ h := (le_max_left hH1 hS).trans hlarge
  have hSh : hS ≤ h := (le_max_right hH1 hS).trans hlarge
  obtain ⟨hleft, hright⟩ :=
    hH1spec a b h ha hb hcompat h2 hh hH1h
  have hshift :=
    hSspec a b h ha hb hcompat h2 hh hSh
  have hreflect := PaperB.Closure.reflected_coprime_equiv hq hcompat
  have hboundary :=
    heightBoundaryFamily_add_pureHeight_eq_reflectedPureLeft hreflect
  rw [PaperB.ExactAccounting.manuscriptA1Kernel_sub_manuscriptB1Kernel_eq_reassigned_boundary_ledger
    h2]
  rw [hboundary]
  calc
    |(cStarReal q h * pureLeftFamily q a h -
          PaperB.Closure.manuscriptS1Kernel q a h) +
        (cStarReal q h *
            pureLeftFamily q (PaperB.Closure.reflectedResidue q b) h -
          PaperB.Closure.manuscriptS1Kernel q
            (PaperB.Closure.reflectedResidue q b) h) +
        cStarReal q h *
          (twoDimensionalFamilyRemainder q a h -
            ∑' e : Finset ℕ, pureHeightSupportTerm q a h e)|
      ≤ |cStarReal q h * pureLeftFamily q a h -
            PaperB.Closure.manuscriptS1Kernel q a h| +
          |cStarReal q h *
              pureLeftFamily q (PaperB.Closure.reflectedResidue q b) h -
            PaperB.Closure.manuscriptS1Kernel q
              (PaperB.Closure.reflectedResidue q b) h| +
          |cStarReal q h *
            (twoDimensionalFamilyRemainder q a h -
              ∑' e : Finset ℕ, pureHeightSupportTerm q a h e)| := by
        exact (abs_add_le _ _).trans
          (add_le_add (abs_add_le _ _) (le_refl _))
    _ ≤ delta * Real.log (h : ℝ) +
          delta * Real.log (h : ℝ) +
          delta * Real.log (h : ℝ) := by
        exact add_le_add (add_le_add hleft hright) hshift
    _ = eps * Real.log (h : ℝ) := by
        dsimp [delta]
        ring

theorem paperBTerminal_of_globalProper_split
    (hExt : ∀ q : ℕ, 0 < q → Squarefree q →
      GlobalProperExteriorSublog q) :
    PaperB.Closure.PaperBTerminalStatement :=
  paperBTerminal_of_globalProper_split_inputs
    (fun q hq _hsq => globalProperSmallBoxLogPowerSaving q hq)
    hExt

#print axioms twoDimensionalRemainderContract_of_globalProper_split_inputs
#print axioms paperBTerminal_of_globalProper_split_inputs
#print axioms paperBTerminal_of_globalProper_split

end PaperB.FixedQ
