import PaperB.FixedQ.SupportRow

namespace PaperB.FixedQ

theorem one_le_correction_tprod
    (q h : ℕ) :
    1 ≤ ∏' p : ℕ, (1 + normalizationCorrection q h p) := by
  rw [tprod_one_add_normalizationCorrection_eq_tsum_finset q h]
  have hsumm :
      Summable (fun s : Finset ℕ =>
        ∏ p ∈ s, normalizationCorrection q h p) :=
    summable_finsetProd_of_summable_norm
      (summable_norm_normalizationCorrection q h)
  have hle := hsumm.le_tsum (∅ : Finset ℕ) (by
    intro s hs
    exact Finset.prod_nonneg fun p hp =>
      normalizationCorrection_nonneg q h p)
  simpa using hle

theorem cStarReal_nonneg (q h : ℕ) :
    0 ≤ cStarReal q h := by
  rw [cStarReal, tprod_normalizationBaseline_eq_inv q h]
  have hinv :
      (∏' p : ℕ, (1 + normalizationCorrection q h p)⁻¹) =
        (∏' p : ℕ, (1 + normalizationCorrection q h p))⁻¹ := by
    exact
      (multipliable_one_add_normalizationCorrection q h).tprod_inv₀
        (correction_tprod_ne_zero q h)
  rw [hinv]
  exact inv_nonneg.mpr
    (le_trans (by norm_num) (one_le_correction_tprod q h))

theorem cStarReal_le_one (q h : ℕ) :
    cStarReal q h ≤ 1 := by
  rw [cStarReal, tprod_normalizationBaseline_eq_inv q h]
  have hinv :
      (∏' p : ℕ, (1 + normalizationCorrection q h p)⁻¹) =
        (∏' p : ℕ, (1 + normalizationCorrection q h p))⁻¹ := by
    exact
      (multipliable_one_add_normalizationCorrection q h).tprod_inv₀
        (correction_tprod_ne_zero q h)
  rw [hinv]
  exact inv_le_one_of_one_le₀ (one_le_correction_tprod q h)

theorem abs_cStarReal_le_one (q h : ℕ) :
    |cStarReal q h| ≤ 1 := by
  rw [abs_of_nonneg (cStarReal_nonneg q h)]
  exact cStarReal_le_one q h

#print axioms one_le_correction_tprod
#print axioms cStarReal_nonneg
#print axioms cStarReal_le_one
#print axioms abs_cStarReal_le_one

end PaperB.FixedQ
