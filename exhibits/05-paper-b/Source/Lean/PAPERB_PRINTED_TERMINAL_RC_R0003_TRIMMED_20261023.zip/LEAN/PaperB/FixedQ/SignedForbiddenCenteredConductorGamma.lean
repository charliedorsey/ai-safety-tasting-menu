import PaperB.FixedQ.SignedForbiddenCenteredOuterGammaBridge
import Mathlib.Analysis.SpecialFunctions.Log.Summable

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def sourceCenteredConductorPrimeMajorant (p : ℕ) : ℝ :=
  15 * (p : ℝ) ^ (-9 / 8 : ℝ)

lemma sourceCenteredConductorPrimeMajorant_nonneg (p : ℕ) :
    0 ≤ sourceCenteredConductorPrimeMajorant p := by
  unfold sourceCenteredConductorPrimeMajorant
  positivity

lemma two_mul_gammaPrimeTerm_mul_threeEighth_le_majorant
    {p : ℕ} (hp5 : 5 ≤ p) :
    2 * gammaPrimeTerm p * (p : ℝ) ^ (3 / 8 : ℝ) ≤
      sourceCenteredConductorPrimeMajorant p := by
  unfold gammaPrimeTerm sourceCenteredConductorPrimeMajorant
  rw [if_pos hp5]
  let x : ℝ := p
  have hx5 : (5 : ℝ) ≤ x := by
    dsimp [x]
    exact_mod_cast hp5
  have hx0 : 0 < x := by linarith
  have hd : 0 < x - 3 := by linarith
  have hsqrt : Real.sqrt x = x ^ (1 / 2 : ℝ) :=
    Real.sqrt_eq_rpow x
  have hrpow :
      (Real.sqrt x)⁻¹ * x ^ (3 / 8 : ℝ) =
        x ^ (-1 / 8 : ℝ) := by
    rw [hsqrt]
    rw [← Real.rpow_neg hx0.le]
    rw [← Real.rpow_add hx0]
    congr 1
    norm_num
  have hid :
      x ^ (-1 / 8 : ℝ) = x * x ^ (-9 / 8 : ℝ) := by
    calc
      x ^ (-1 / 8 : ℝ)
          = x ^ ((1 : ℝ) + (-9 / 8 : ℝ)) := by norm_num
      _ = x ^ (1 : ℝ) * x ^ (-9 / 8 : ℝ) :=
        Real.rpow_add hx0 1 (-9 / 8)
      _ = x * x ^ (-9 / 8 : ℝ) := by rw [Real.rpow_one]
  have hcoef : 6 * x / (x - 3) ≤ 15 := by
    rw [div_le_iff₀ hd]
    nlinarith
  change 2 * (3 / ((x - 3) * Real.sqrt x)) *
      x ^ (3 / 8 : ℝ) ≤ 15 * x ^ (-9 / 8 : ℝ)
  rw [show 3 / ((x - 3) * Real.sqrt x) =
      (3 / (x - 3)) * (Real.sqrt x)⁻¹ by
        field_simp [hd.ne', (Real.sqrt_pos.2 hx0).ne']]
  have hshape :
      2 * ((3 / (x - 3)) * (Real.sqrt x)⁻¹) *
          x ^ (3 / 8 : ℝ) =
        (2 * (3 / (x - 3))) *
          ((Real.sqrt x)⁻¹ * x ^ (3 / 8 : ℝ)) := by
    ring
  rw [hshape, hrpow, hid]
  have hpow0 : 0 ≤ x ^ (-9 / 8 : ℝ) :=
    Real.rpow_nonneg hx0.le _
  calc
    2 * (3 / (x - 3)) * (x * x ^ (-9 / 8 : ℝ))
        = (6 * x / (x - 3)) * x ^ (-9 / 8 : ℝ) := by ring
    _ ≤ 15 * x ^ (-9 / 8 : ℝ) :=
      mul_le_mul_of_nonneg_right hcoef hpow0

noncomputable def sourceCenteredConductorEnhancedPrimeMajorant (p : ℕ) : ℝ :=
  30 * (p : ℝ) ^ (-9 / 8 : ℝ)

lemma sourceCenteredConductorEnhancedPrimeMajorant_nonneg (p : ℕ) :
    0 ≤ sourceCenteredConductorEnhancedPrimeMajorant p := by
  unfold sourceCenteredConductorEnhancedPrimeMajorant
  positivity

lemma conductorGamma_mul_divisorFactor_le_enhancedMajorant
    {p : ℕ} (hp5 : 5 ≤ p) :
    (2 * gammaPrimeTerm p * (p : ℝ) ^ (3 / 8 : ℝ)) *
        (1 + invSqrtNat p) ≤
      sourceCenteredConductorEnhancedPrimeMajorant p := by
  have hbase :=
    two_mul_gammaPrimeTerm_mul_threeEighth_le_majorant hp5
  have hinv : invSqrtNat p ≤ 1 := by
    unfold invSqrtNat
    have hp1 : (1 : ℝ) ≤ p := by exact_mod_cast (show 1 ≤ p by omega)
    have hs1 : (1 : ℝ) ≤ Real.sqrt (p : ℝ) := by
      have := Real.sqrt_le_sqrt hp1
      simpa using this
    have hp0 : (0 : ℝ) < p := by exact_mod_cast (show 0 < p by omega)
    exact (inv_le_one₀ (Real.sqrt_pos.2 hp0)).2 hs1
  have hi0 : 0 ≤ invSqrtNat p := by
    unfold invSqrtNat
    positivity
  have hfac : 0 ≤ 1 + invSqrtNat p := by linarith
  have hfac2 : 1 + invSqrtNat p ≤ 2 := by linarith
  have hmaj0 : 0 ≤ sourceCenteredConductorPrimeMajorant p :=
    sourceCenteredConductorPrimeMajorant_nonneg p
  calc
    (2 * gammaPrimeTerm p * (p : ℝ) ^ (3 / 8 : ℝ)) *
        (1 + invSqrtNat p)
      ≤ sourceCenteredConductorPrimeMajorant p *
          (1 + invSqrtNat p) :=
        mul_le_mul_of_nonneg_right hbase hfac
    _ ≤ sourceCenteredConductorPrimeMajorant p * 2 :=
      mul_le_mul_of_nonneg_left hfac2 hmaj0
    _ = sourceCenteredConductorEnhancedPrimeMajorant p := by
      unfold sourceCenteredConductorPrimeMajorant
      unfold sourceCenteredConductorEnhancedPrimeMajorant
      ring

lemma gammaPrimeTerm_mul_threeEighth_mul_divisorFactor_le_enhancedMajorant
    {p : ℕ} (hp5 : 5 ≤ p) :
    gammaPrimeTerm p * (p : ℝ) ^ (3 / 8 : ℝ) *
        (1 + invSqrtNat p) ≤
      sourceCenteredConductorEnhancedPrimeMajorant p := by
  have h0 :
      0 ≤ gammaPrimeTerm p * (p : ℝ) ^ (3 / 8 : ℝ) *
        (1 + invSqrtNat p) := by
    have hg : 0 ≤ gammaPrimeTerm p := gammaPrimeTerm_nonneg p
    have hr : 0 ≤ (p : ℝ) ^ (3 / 8 : ℝ) :=
      Real.rpow_nonneg (by positivity : (0 : ℝ) ≤ (p : ℝ)) (3 / 8 : ℝ)
    have hi : 0 ≤ invSqrtNat p := by
      unfold invSqrtNat
      positivity
    positivity
  have hdouble :
      gammaPrimeTerm p * (p : ℝ) ^ (3 / 8 : ℝ) *
          (1 + invSqrtNat p) ≤
        (2 * gammaPrimeTerm p * (p : ℝ) ^ (3 / 8 : ℝ)) *
          (1 + invSqrtNat p) := by
    nlinarith
  exact hdouble.trans
    (conductorGamma_mul_divisorFactor_le_enhancedMajorant hp5)

lemma summable_sourceCenteredConductorEnhancedPrimeMajorant :
    Summable sourceCenteredConductorEnhancedPrimeMajorant := by
  unfold sourceCenteredConductorEnhancedPrimeMajorant
  exact (Real.summable_nat_rpow.mpr
    (by norm_num : (-9 / 8 : ℝ) < -1)).mul_left 30

lemma summable_sourceCenteredConductorEnhancedFinsetProduct :
    Summable (fun s : Finset ℕ =>
      ∏ p ∈ s, sourceCenteredConductorEnhancedPrimeMajorant p) := by
  exact summable_finsetProd_of_summable_nonneg
    sourceCenteredConductorEnhancedPrimeMajorant_nonneg
    summable_sourceCenteredConductorEnhancedPrimeMajorant

lemma summable_sourceCenteredConductorPrimeMajorant :
    Summable sourceCenteredConductorPrimeMajorant := by
  unfold sourceCenteredConductorPrimeMajorant
  exact (Real.summable_nat_rpow.mpr
    (by norm_num : (-9 / 8 : ℝ) < -1)).mul_left 15

lemma summable_sourceCenteredConductorFinsetProduct :
    Summable (fun s : Finset ℕ =>
      ∏ p ∈ s, sourceCenteredConductorPrimeMajorant p) := by
  exact summable_finsetProd_of_summable_nonneg
    sourceCenteredConductorPrimeMajorant_nonneg
    summable_sourceCenteredConductorPrimeMajorant

#print axioms two_mul_gammaPrimeTerm_mul_threeEighth_le_majorant
#print axioms summable_sourceCenteredConductorPrimeMajorant
#print axioms summable_sourceCenteredConductorFinsetProduct

end PaperB.FixedQ
