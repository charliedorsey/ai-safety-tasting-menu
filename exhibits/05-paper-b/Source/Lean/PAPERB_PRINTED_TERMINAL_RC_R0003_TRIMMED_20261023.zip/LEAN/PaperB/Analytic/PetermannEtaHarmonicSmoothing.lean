import PaperB.Analytic.PetermannEtaHarmonicExpansion
import PaperB.Analytic.PetermannEtaHarmonicFourier
import PaperB.Analytic.PetermannOmegaNearJumpSplit

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset

noncomputable def etaHarmonicSawtoothSum
    (q : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (A : ℝ) (Y : ℕ) : ℂ :=
  ∑ m ∈ Finset.Icc 1 Y,
    ((chi m) / (m : ℂ)) *
      (petermannSawtooth
        (A / (m : ℝ) +
          (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ)

def EtaHarmonicSawtoothSpec (q : ℕ) : Prop :=
  ∀ eps : ℝ, 0 < eps →
    ∃ A0 : ℝ, 0 < A0 ∧
      ∀ (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
        (r : ℤ) (A : ℝ) (Y : ℕ),
        A0 ≤ A →
        1 ≤ Y →
        (Y : ℝ) ≤ A →
        ‖etaHarmonicSawtoothSum q chi r A Y‖ ≤ eps * Real.log A

noncomputable def etaHarmonicSmoothedSum
    (q : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (A : ℝ) (Y H : ℕ) (S : ℝ) : ℂ :=
  ∑ m ∈ Finset.Icc 1 Y,
    ((chi m) / (m : ℂ)) *
      sawSmoothPartial S H
        ((A / (m : ℝ) +
          (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
          AddCircle (1 : ℝ))

noncomputable def etaHarmonicSmoothingRemainder
    (q : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (A : ℝ) (Y H : ℕ) (S : ℝ) : ℂ :=
  ∑ m ∈ Finset.Icc 1 Y,
    ((chi m) / (m : ℂ)) *
      ((petermannSawtooth
          (A / (m : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
        sawSmoothPartial S H
          ((A / (m : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
            AddCircle (1 : ℝ)))

theorem etaHarmonicSawtoothSum_eq_smoothed_add_remainder
    (q : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (A : ℝ) (Y H : ℕ) (S : ℝ) :
    etaHarmonicSawtoothSum q chi r A Y =
      etaHarmonicSmoothedSum q chi r A Y H S +
      etaHarmonicSmoothingRemainder q chi r A Y H S := by
  unfold etaHarmonicSawtoothSum etaHarmonicSmoothedSum
    etaHarmonicSmoothingRemainder
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro m hm
  ring

noncomputable def etaHarmonicAwayFromJump
    (q : ℕ) (A : ℝ) (r : ℤ) (S : ℝ) (m : ℕ) : Prop :=
  sawSmoothHalfWidth S <
      Int.fract
        (A / (m : ℝ) +
          (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) ∧
    Int.fract
        (A / (m : ℝ) +
          (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) ≤
      1 - sawSmoothHalfWidth S

noncomputable def etaHarmonicNearJumpMass
    (q : ℕ) (A : ℝ) (r : ℤ) (Y : ℕ) (S : ℝ) : ℝ := by
  classical
  exact
    ∑ m ∈ (Finset.Icc 1 Y).filter
        (fun m => ¬ etaHarmonicAwayFromJump q A r S m),
      1 / (m : ℝ)

lemma eta_harmonic_point_norm_le_near_const
    (q : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (A S : ℝ) (r : ℤ) (H m : ℕ)
    (hm : 1 ≤ m) :
    ‖((chi m) / (m : ℂ)) *
      ((petermannSawtooth
          (A / (m : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
        sawSmoothPartial S H
          ((A / (m : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
            AddCircle (1 : ℝ)))‖
      ≤ (1 / (m : ℝ)) *
          (1 / 2 + sawSmoothPartialNormBound S H) := by
  have hchi := norm_dirichletCharacter_nat_le_one (q := q) (e := m) chi
  have hmpos : (0 : ℝ) < m := by exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hm)
  have hsaw := abs_petermannSawtooth_le_half
    (A / (m : ℝ) +
      (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))
  have hsmooth := norm_sawSmoothPartial_le S H
    ((A / (m : ℝ) +
      (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
      AddCircle (1 : ℝ))
  have hdiff :
      ‖((petermannSawtooth
          (A / (m : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
        sawSmoothPartial S H
          ((A / (m : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
            AddCircle (1 : ℝ)))‖
        ≤ 1 / 2 + sawSmoothPartialNormBound S H := by
    calc
      ‖((petermannSawtooth
          (A / (m : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
        sawSmoothPartial S H
          ((A / (m : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
            AddCircle (1 : ℝ)))‖
        ≤ ‖(petermannSawtooth
            (A / (m : ℝ) +
              (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ)‖ +
          ‖sawSmoothPartial S H
            ((A / (m : ℝ) +
              (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
              AddCircle (1 : ℝ))‖ := norm_sub_le _ _
      _ ≤ 1 / 2 + sawSmoothPartialNormBound S H := by
        rw [Complex.norm_real, Real.norm_eq_abs]
        exact add_le_add hsaw hsmooth
  rw [norm_mul, norm_div, Complex.norm_natCast]
  have hconst0 : 0 ≤ 1 / 2 + sawSmoothPartialNormBound S H := by
    have := sawSmoothPartialNormBound_nonneg S H
    positivity
  calc
    (‖chi (m : ZMod (Nat.lcm 6 q))‖ / (m : ℝ)) *
        ‖((petermannSawtooth
          (A / (m : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
          sawSmoothPartial S H
            ((A / (m : ℝ) +
              (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
              AddCircle (1 : ℝ)))‖
      ≤ (1 / (m : ℝ)) *
          (1 / 2 + sawSmoothPartialNormBound S H) := by
        have hrec : 0 ≤ 1 / (m : ℝ) := by positivity
        have hchiRec :
            ‖chi (m : ZMod (Nat.lcm 6 q))‖ / (m : ℝ) ≤
              1 / (m : ℝ) := by
          simpa [div_eq_mul_inv] using
            mul_le_mul_of_nonneg_right hchi (by positivity : 0 ≤ (m : ℝ)⁻¹)
        exact mul_le_mul hchiRec hdiff (norm_nonneg _) hrec

theorem etaHarmonicSmoothingRemainder_le_away_add_near
    {S : ℝ} (hS : 1 < S) {H : ℕ} (hH : 1 ≤ H)
    (q Y : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (A : ℝ) :
    ‖etaHarmonicSmoothingRemainder q chi r A Y H S‖
      ≤
    (S / (Real.pi ^ 2 * H)) * (harmonic Y : ℝ) +
      (1 / 2 + sawSmoothPartialNormBound S H) *
        etaHarmonicNearJumpMass q A r Y S := by
  classical
  let E := Finset.Icc 1 Y
  let away : ℕ → Prop := fun m => etaHarmonicAwayFromJump q A r S m
  let f : ℕ → ℂ := fun m =>
    ((chi m) / (m : ℂ)) *
      ((petermannSawtooth
          (A / (m : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) -
        sawSmoothPartial S H
          ((A / (m : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
            AddCircle (1 : ℝ)))
  unfold etaHarmonicSmoothingRemainder
  change ‖∑ m ∈ E, f m‖ ≤ _
  rw [← Finset.sum_filter_add_sum_filter_not E away f]
  calc
    ‖(∑ m ∈ E.filter away, f m) +
        (∑ m ∈ E.filter (fun m => ¬ away m), f m)‖
      ≤ ‖∑ m ∈ E.filter away, f m‖ +
          ‖∑ m ∈ E.filter (fun m => ¬ away m), f m‖ := norm_add_le _ _
    _ ≤
      (S / (Real.pi ^ 2 * H)) *
          (∑ m ∈ E.filter away, 1 / (m : ℝ)) +
        (1 / 2 + sawSmoothPartialNormBound S H) *
          (∑ m ∈ E.filter (fun m => ¬ away m), 1 / (m : ℝ)) := by
      apply add_le_add
      · have hpoint : ∀ m ∈ E.filter away,
            ‖f m‖ ≤ (1 / (m : ℝ)) * (S / (Real.pi ^ 2 * H)) := by
          intro m hm
          have hmE := (Finset.mem_filter.mp hm).1
          have hmI := Finset.mem_Icc.mp hmE
          have hmAway : away m := (Finset.mem_filter.mp hm).2
          have herr := petermannSawtooth_partial_error_le hS hH
            hmAway.1 hmAway.2
          have hchi := norm_dirichletCharacter_nat_le_one (q := q) (e := m) chi
          have hmpos : (0 : ℝ) < m := by
            exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hmI.1)
          dsimp [f]
          rw [norm_mul, norm_div, Complex.norm_natCast]
          have hrec : 0 ≤ 1 / (m : ℝ) := by positivity
          have hchiRec :
              ‖chi (m : ZMod (Nat.lcm 6 q))‖ / (m : ℝ) ≤
                1 / (m : ℝ) := by
            simpa [div_eq_mul_inv] using
              mul_le_mul_of_nonneg_right hchi
                (by positivity : 0 ≤ (m : ℝ)⁻¹)
          exact mul_le_mul hchiRec herr (norm_nonneg _) hrec
        calc
          ‖∑ m ∈ E.filter away, f m‖
            ≤ ∑ m ∈ E.filter away, ‖f m‖ := norm_sum_le _ _
          _ ≤ ∑ m ∈ E.filter away,
              (1 / (m : ℝ)) * (S / (Real.pi ^ 2 * H)) :=
            Finset.sum_le_sum hpoint
          _ = (S / (Real.pi ^ 2 * H)) *
              (∑ m ∈ E.filter away, 1 / (m : ℝ)) := by
            rw [Finset.mul_sum]
            apply Finset.sum_congr rfl
            intro m hm
            ring
      · have hpoint : ∀ m ∈ E.filter (fun m => ¬ away m),
            ‖f m‖ ≤ (1 / (m : ℝ)) *
              (1 / 2 + sawSmoothPartialNormBound S H) := by
          intro m hm
          have hmE := (Finset.mem_filter.mp hm).1
          have hmI := Finset.mem_Icc.mp hmE
          exact eta_harmonic_point_norm_le_near_const q chi A S r H m hmI.1
        calc
          ‖∑ m ∈ E.filter (fun m => ¬ away m), f m‖
            ≤ ∑ m ∈ E.filter (fun m => ¬ away m), ‖f m‖ := norm_sum_le _ _
          _ ≤ ∑ m ∈ E.filter (fun m => ¬ away m),
              (1 / (m : ℝ)) *
                (1 / 2 + sawSmoothPartialNormBound S H) :=
            Finset.sum_le_sum hpoint
          _ = (1 / 2 + sawSmoothPartialNormBound S H) *
              (∑ m ∈ E.filter (fun m => ¬ away m), 1 / (m : ℝ)) := by
            rw [Finset.mul_sum]
            apply Finset.sum_congr rfl
            intro m hm
            ring
    _ ≤
      (S / (Real.pi ^ 2 * H)) * (harmonic Y : ℝ) +
        (1 / 2 + sawSmoothPartialNormBound S H) *
          etaHarmonicNearJumpMass q A r Y S := by
      have hAway :
          (∑ m ∈ E.filter away, 1 / (m : ℝ)) ≤ (harmonic Y : ℝ) := by
        have hsub := Finset.filter_subset away E
        have hEq :
            (∑ m ∈ E, 1 / (m : ℝ)) = (harmonic Y : ℝ) := by
          unfold E
          calc
            (∑ m ∈ Finset.Icc 1 Y, 1 / (m : ℝ))
                = shiftedHarmonicReal Y := by
                  unfold shiftedHarmonicReal
                  refine Finset.sum_bij (fun m hm => m - 1) ?_ ?_ ?_ ?_
                  · intro m hm
                    rw [Finset.mem_Icc] at hm
                    rw [Finset.mem_range]
                    omega
                  · intro m1 hm1 m2 hm2 h
                    rw [Finset.mem_Icc] at hm1 hm2
                    omega
                  · intro j hj
                    rw [Finset.mem_range] at hj
                    refine ⟨j + 1, ?_, ?_⟩
                    · rw [Finset.mem_Icc]
                      omega
                    · omega
                  · intro m hm
                    rw [Finset.mem_Icc] at hm
                    have hp : 1 ≤ m := hm.1
                    have hsubcast :
                        ((m - 1 : ℕ) : ℝ) = (m : ℝ) - 1 := by
                      rw [Nat.cast_sub hp]
                      norm_num
                    rw [hsubcast]
                    ring
            _ = (harmonic Y : ℝ) := shiftedHarmonicReal_eq_harmonic Y
        rw [← hEq]
        exact Finset.sum_le_sum_of_subset_of_nonneg hsub
          (fun m hm hnot => by positivity)
      have hfac : 0 ≤ S / (Real.pi ^ 2 * H) := by positivity
      have hnearEq :
          (∑ m ∈ E.filter (fun m => ¬ away m), 1 / (m : ℝ)) =
            etaHarmonicNearJumpMass q A r Y S := by
        rfl
      rw [hnearEq]
      gcongr

lemma sawSmoothPair_eta_harmonic_phase
    (S A : ℝ) (L k m : ℕ) (r : ℤ) :
    sawSmoothPair S k
        ((A / (m : ℝ) + (r : ℝ) / (L : ℝ) : ℝ) :
          AddCircle (1 : ℝ)) =
      sawSmoothCoeff S (k + 1 : ℕ) *
        eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) / (L : ℝ)) *
        eR (((k + 1 : ℕ) : ℝ) * A / (m : ℝ)) +
      sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
        eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) / (L : ℝ)) *
        eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * A / (m : ℝ)) := by
  unfold sawSmoothPair
  rw [sawSmoothMode_coe_eq_coeff_mul_eR,
    sawSmoothMode_coe_eq_coeff_mul_eR]
  push_cast
  have hpos :
      (((k : ℝ) + 1) *
        (A / (m : ℝ) + (r : ℝ) / (L : ℝ))) =
      (((k : ℝ) + 1) * (r : ℝ) / (L : ℝ)) +
        (((k : ℝ) + 1) * A / (m : ℝ)) := by ring
  have hneg :
      (-((k : ℝ) + 1) *
        (A / (m : ℝ) + (r : ℝ) / (L : ℝ))) =
      (-((k : ℝ) + 1) * (r : ℝ) / (L : ℝ)) +
        (-((k : ℝ) + 1) * A / (m : ℝ)) := by ring
  rw [hpos, hneg, eR_add, eR_add]
  ring

theorem etaHarmonicSmoothedSum_eq_reciprocal_modes
    {S : ℝ} (hS : 1 < S)
    (q Y H : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (A : ℝ) :
    etaHarmonicSmoothedSum q chi r A Y H S =
      ∑ k ∈ Finset.range H,
        (sawSmoothCoeff S (k + 1 : ℕ) *
            eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) /
              ((Nat.lcm 6 q : ℕ) : ℝ)) *
            etaHarmonicReciprocalMode q chi Y
              ((((k + 1 : ℕ) : ℝ) * A)) +
          sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
            eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) /
              ((Nat.lcm 6 q : ℕ) : ℝ)) *
            etaHarmonicReciprocalMode q chi Y
              ((-((k + 1 : ℕ) : ℤ) : ℝ) * A)) := by
  unfold etaHarmonicSmoothedSum etaHarmonicReciprocalMode
  calc
    (∑ m ∈ Finset.Icc 1 Y,
      ((chi m) / (m : ℂ)) *
        sawSmoothPartial S H
          ((A / (m : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ) : ℝ) :
            AddCircle (1 : ℝ)))
      =
    ∑ m ∈ Finset.Icc 1 Y,
      ((chi m) / (m : ℂ)) *
        ∑ k ∈ Finset.range H,
          (sawSmoothCoeff S (k + 1 : ℕ) *
            eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) /
              ((Nat.lcm 6 q : ℕ) : ℝ)) *
            eR (((((k + 1 : ℕ) : ℝ) * A) / (m : ℝ))) +
          sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
            eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) /
              ((Nat.lcm 6 q : ℕ) : ℝ)) *
            eR (((-((k + 1 : ℕ) : ℤ) : ℝ) * A) / (m : ℝ))) := by
        apply Finset.sum_congr rfl
        intro m hm
        rw [sawSmoothPartial_eq_pair_sum hS]
        simp_rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro k hk
        rw [sawSmoothPair_eta_harmonic_phase]
    _ =
      ∑ m ∈ Finset.Icc 1 Y,
        ∑ k ∈ Finset.range H,
          ((chi m) / (m : ℂ)) *
            (sawSmoothCoeff S (k + 1 : ℕ) *
              eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) /
                ((Nat.lcm 6 q : ℕ) : ℝ)) *
              eR (((k + 1 : ℕ) : ℝ) * A / (m : ℝ)) +
            sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
              eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) /
                ((Nat.lcm 6 q : ℕ) : ℝ)) *
              eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * A / (m : ℝ))) := by
        apply Finset.sum_congr rfl
        intro m hm
        rw [Finset.mul_sum]
    _ =
      ∑ k ∈ Finset.range H,
        ∑ m ∈ Finset.Icc 1 Y,
          ((chi m) / (m : ℂ)) *
            (sawSmoothCoeff S (k + 1 : ℕ) *
              eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) /
                ((Nat.lcm 6 q : ℕ) : ℝ)) *
              eR (((k + 1 : ℕ) : ℝ) * A / (m : ℝ)) +
            sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
              eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) /
                ((Nat.lcm 6 q : ℕ) : ℝ)) *
              eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * A / (m : ℝ))) := by
        rw [Finset.sum_comm]
    _ =
      ∑ k ∈ Finset.range H,
        (sawSmoothCoeff S (k + 1 : ℕ) *
            eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) /
              ((Nat.lcm 6 q : ℕ) : ℝ)) *
            (∑ m ∈ Finset.Icc 1 Y,
              ((chi m) / (m : ℂ)) *
                eR (((k + 1 : ℕ) : ℝ) * A / (m : ℝ))) +
          sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
            eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) /
              ((Nat.lcm 6 q : ℕ) : ℝ)) *
            (∑ m ∈ Finset.Icc 1 Y,
              ((chi m) / (m : ℂ)) *
                eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * A / (m : ℝ)))) := by
        apply Finset.sum_congr rfl
        intro k hk
        simp_rw [mul_add]
        rw [Finset.sum_add_distrib]
        congr 1
        · rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro m hm
          ring
        · rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro m hm
          ring

theorem etaHarmonicSmoothedSum_expansion
    {S : ℝ} (hS : 1 < S)
    (q Y H : ℕ) [NeZero (Nat.lcm 6 q)]
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (A : ℝ) :
    etaHarmonicSmoothedSum q chi r A Y H S =
      ∑ k ∈ Finset.range H,
        (sawSmoothCoeff S (k + 1 : ℕ) *
            eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) /
              ((Nat.lcm 6 q : ℕ) : ℝ)) *
            (((Nat.lcm 6 q : ℕ) : ℂ)⁻¹ *
              ∑ h : ZMod (Nat.lcm 6 q),
                ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h *
                  etaHarmonicAdditiveMode Y
                    (((k + 1 : ℕ) : ℝ) * A)
                    ((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))) +
          sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
            eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) /
              ((Nat.lcm 6 q : ℕ) : ℝ)) *
            (((Nat.lcm 6 q : ℕ) : ℂ)⁻¹ *
              ∑ h : ZMod (Nat.lcm 6 q),
                ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h *
                  etaHarmonicAdditiveMode Y
                    ((-((k + 1 : ℕ) : ℤ) : ℝ) * A)
                    ((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)))) := by
  rw [etaHarmonicSmoothedSum_eq_reciprocal_modes hS]
  apply Finset.sum_congr rfl
  intro k hk
  rw [etaHarmonicReciprocalMode_eq_additive_dft,
      etaHarmonicReciprocalMode_eq_additive_dft]


#print axioms etaHarmonicSmoothedSum_expansion
#print axioms etaHarmonicSawtoothSum_eq_smoothed_add_remainder
#print axioms etaHarmonicSmoothingRemainder_le_away_add_near

end PaperB.Analytic
