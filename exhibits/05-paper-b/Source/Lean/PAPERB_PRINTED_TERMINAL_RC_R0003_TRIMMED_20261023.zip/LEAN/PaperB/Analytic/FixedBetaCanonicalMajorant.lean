import PaperB.Analytic.FixedBetaActualTerms
import PaperB.Analytic.FixedBetaSharpLambda
import PaperB.Analytic.ReciprocalFiniteOrderEnvelope

namespace PaperB.Analytic

open Real Finset Nat

theorem fixedBeta_sourceScale_interval_majorant_canonical
    (beta : ℝ) (k : ℕ) (hk : 2 ≤ k) :
    ∀ (xi : ℝ) (W B : ℕ),
      0 < W → k ≤ W → W ≤ B → B ≤ 2 * W →
      ‖∑ n ∈ Finset.Icc W B,
          eR (((W : ℝ) ^ beta⁻¹) / (n : ℝ) + xi * (n : ℝ))‖
        ≤
      1 + reciprocalFiniteOrderConst k *
        ((fixedBetaUpperConst k ^ fixedBetaA k) *
            (W : ℝ) ^ fixedBetaFirstExponent beta k
          +
          (fixedBetaLowerConst k ^ (-(fixedBetaA k))) *
            (W : ℝ) ^ fixedBetaSecondExponent beta k) := by
  intro xi W B hW hkW hWB hB2
  have hWr : (0 : ℝ) < (W : ℝ) := by exact_mod_cast hW
  have hApos : 0 < (W : ℝ) ^ beta⁻¹ := Real.rpow_pos_of_pos hWr _
  have hbase := reciprocalFiniteOrderConst_spec hk
    ((W : ℝ) ^ beta⁻¹) xi W B hApos.ne' hkW hWB hB2
  dsimp at hbase
  have hlam := fixedBeta_actual_lambda_squeeze
    (W := W) (beta := beta) (k := k) hW hkW
  let lam : ℝ :=
    ((W : ℝ) ^ beta⁻¹) * (k.factorial : ℝ) *
      ((((2 * W + k : ℕ) : ℝ)) ^ (k + 1))⁻¹
  let lo : ℝ :=
    fixedBetaLowerConst k *
      (W : ℝ) ^ fixedBetaLambdaExponent beta k
  let hi : ℝ :=
    fixedBetaUpperConst k *
      (W : ℝ) ^ fixedBetaLambdaExponent beta k
  have hlam' : lo ≤ lam ∧ lam ≤ hi := by
    simpa [lam, lo, hi, fixedBetaLowerConst, fixedBetaUpperConst] using hlam
  have ha : 0 < fixedBetaA k := fixedBetaA_pos hk
  have hb : 0 ≤ fixedBetaB k := fixedBetaB_nonneg hk
  have hlamPos : 0 < lam := by
    dsimp [lam]
    positivity
  have hloPos : 0 < lo := by
    dsimp [lo]
    exact mul_pos (fixedBetaLowerConst_pos k)
      (Real.rpow_pos_of_pos hWr _)
  have hhiPos : 0 < hi := by
    dsimp [hi]
    exact mul_pos (fixedBetaUpperConst_pos k)
      (Real.rpow_pos_of_pos hWr _)
  have hlen0 : 0 ≤ (B : ℝ) - (W : ℝ) := by
    exact sub_nonneg.mpr (by exact_mod_cast hWB)
  have hlenW : (B : ℝ) - (W : ℝ) ≤ (W : ℝ) := by
    have hB2r : (B : ℝ) ≤ 2 * (W : ℝ) := by exact_mod_cast hB2
    linarith
  have hpowHi : lam ^ fixedBetaA k ≤ hi ^ fixedBetaA k := by
    exact Real.rpow_le_rpow hlamPos.le hlam'.2 ha.le
  have hpowLo : lo ^ fixedBetaA k ≤ lam ^ fixedBetaA k := by
    exact Real.rpow_le_rpow hloPos.le hlam'.1 ha.le
  have hnegPow :
      lam ^ (-(fixedBetaA k)) ≤ lo ^ (-(fixedBetaA k)) := by
    rw [Real.rpow_neg hlamPos.le, Real.rpow_neg hloPos.le]
    exact (inv_le_inv₀
      (Real.rpow_pos_of_pos hlamPos (fixedBetaA k))
      (Real.rpow_pos_of_pos hloPos (fixedBetaA k))).2 hpowLo
  have hlenPow :
      ((B : ℝ) - (W : ℝ)) ^ fixedBetaB k
        ≤ (W : ℝ) ^ fixedBetaB k := by
    exact Real.rpow_le_rpow hlen0 hlenW hb
  have hfirst :
      ((B : ℝ) - (W : ℝ)) * lam ^ fixedBetaA k
        ≤
      (fixedBetaUpperConst k ^ fixedBetaA k) *
        (W : ℝ) ^ fixedBetaFirstExponent beta k := by
    calc
      ((B : ℝ) - (W : ℝ)) * lam ^ fixedBetaA k
        ≤ (W : ℝ) * hi ^ fixedBetaA k := by
          gcongr
      _ = (fixedBetaUpperConst k ^ fixedBetaA k) *
          (W : ℝ) ^ fixedBetaFirstExponent beta k := by
            simpa [hi] using
              (fixedBeta_first_model_identity
                (W := (W : ℝ)) (beta := beta) (k := k) hWr hk)
  have hsecond :
      ((B : ℝ) - (W : ℝ)) ^ fixedBetaB k *
          lam ^ (-(fixedBetaA k))
        ≤
      (fixedBetaLowerConst k ^ (-(fixedBetaA k))) *
        (W : ℝ) ^ fixedBetaSecondExponent beta k := by
    calc
      ((B : ℝ) - (W : ℝ)) ^ fixedBetaB k *
          lam ^ (-(fixedBetaA k))
        ≤
      (W : ℝ) ^ fixedBetaB k *
          lo ^ (-(fixedBetaA k)) := by
            gcongr
      _ = (fixedBetaLowerConst k ^ (-(fixedBetaA k))) *
          (W : ℝ) ^ fixedBetaSecondExponent beta k := by
            simpa [lo] using
              (fixedBeta_second_model_identity
                (W := (W : ℝ)) (beta := beta) (k := k) hWr hk)
  have hbase' :
      ‖∑ n ∈ Finset.Icc W B,
          eR (((W : ℝ) ^ beta⁻¹) / (n : ℝ) + xi * (n : ℝ))‖
        ≤ 1 + reciprocalFiniteOrderConst k *
          (((B : ℝ) - (W : ℝ)) * lam ^ fixedBetaA k +
            ((B : ℝ) - (W : ℝ)) ^ fixedBetaB k *
              lam ^ (-(fixedBetaA k))) := by
    simpa [lam, fixedBetaA, fixedBetaB, abs_of_pos hApos] using hbase
  have hC0 : 0 ≤ reciprocalFiniteOrderConst k :=
    le_trans (by norm_num) (reciprocalFiniteOrderConst_ge_one k)
  have hsum := add_le_add hfirst hsecond
  have hmul := mul_le_mul_of_nonneg_left hsum hC0
  exact hbase'.trans (add_le_add (le_refl 1) hmul)

#print axioms fixedBeta_sourceScale_interval_majorant_canonical

end PaperB.Analytic
