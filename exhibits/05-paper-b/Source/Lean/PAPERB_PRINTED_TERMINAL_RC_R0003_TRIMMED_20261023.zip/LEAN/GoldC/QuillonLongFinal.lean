import GoldC.QuillonLRP

/-!
# Quillon LONG L10: **LONG end to end** — `SourceUniformSublog (signedLongMiddle Jlow Jhigh δ)`

* `split7`: exact seven-way split of a masked summand (instance-agnostic).
* `long_pair_decomp`: for every decoration `d`, with `P = longEither δ`,

      regionPairSumMiddleWhere (LONG) d (foldRow …)
        = WL + CL + RL + ManyL + EdgeL + ResL + WRL           (exact, `pairSum_eq_double` + `split7`)

  LONG-left (`s^{1+δ} < r`):  W′ (`WL ≤ Λ^{−80}`), region C (`CL ≤ Λ^{−15}`);
  LONG-right (`r^{1+δ} < s`): R (`RL ≤ Λ^{−75}`), many factors (`ManyL ≤ Λ^{−50}`),
  edge (`EdgeL ≤ Λ^{19/20}`), rough×rough (`ResL ≤ Λ^{7/10}`), Weil W′ (`WRL ≤ Λ^{−80}`).
* `long_pair_le`: `|LONG pair sum at d| ≤ 7Λ^{19/20}`, eventually, uniformly in `a, d ⊆ primeFactors h,
  Jlow, Jhigh`.
* **`long_sublog`** `(hW : WeilHyp)`: `SourceUniformSublog (signedLongMiddle Jlow Jhigh δ)` for
  `0 < δ < 1/3`, arbitrary cutoffs. Lemma G controls the decoration mass.

The ONLY input beyond the copied source and Mathlib is the named hypothesis `WeilHyp`, which is the
exact statement of the GREEN `Orienne.CSC3.norm_quillon_K_weil`. No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonLongFinal

open Classical
open GoldC.QuillonEv GoldC.QuillonSetup GoldC.QuillonLam GoldC.QuillonCEv GoldC.QuillonCFinal
  GoldC.QuillonREv GoldC.QuillonWContext GoldC.QuillonRPhysical GoldC.QuillonResPhysical
  GoldC.QuillonCPhysical GoldC.QuillonLSetup GoldC.QuillonLW GoldC.QuillonLC GoldC.QuillonLR
  GoldC.QuillonLWR GoldC.QuillonLRes GoldC.QuillonLRP GoldC.QuillonLWeil
open GoldC.QuillonCopyS GoldC.QuillonCopyF GoldC.QuillonCopyM GoldC.QuillonWPhysical

lemma split7 {e1 e2 e3 m L W J Km Ed WR : Prop} (f : ℝ) (i0 : Decidable (e1 ∧ e2 ∧ e3 ∧ m))
    (i1 : Decidable (e1 ∧ e2 ∧ e3 ∧ (m ∧ (L ∧ W))))
    (i2 : Decidable (e1 ∧ e2 ∧ e3 ∧ (m ∧ (L ∧ ¬ W))))
    (i3 : Decidable (e1 ∧ e2 ∧ e3 ∧ (m ∧ (¬ L ∧ J))))
    (i4 : Decidable (e1 ∧ e2 ∧ e3 ∧ (m ∧ (¬ L ∧ ¬ J ∧ Km))))
    (i5 : Decidable (e1 ∧ e2 ∧ e3 ∧ (m ∧ (¬ L ∧ ¬ J ∧ ¬ Km ∧ Ed))))
    (i6 : Decidable (e1 ∧ e2 ∧ e3 ∧ (m ∧ (¬ L ∧ ¬ J ∧ ¬ Km ∧ ¬ Ed ∧ ¬ WR))))
    (i7 : Decidable (e1 ∧ e2 ∧ e3 ∧ (m ∧ (¬ L ∧ ¬ J ∧ ¬ Km ∧ ¬ Ed ∧ WR)))) :
    @ite _ (e1 ∧ e2 ∧ e3 ∧ m) i0 f 0 =
      @ite _ _ i1 f 0 + @ite _ _ i2 f 0 + @ite _ _ i3 f 0 + @ite _ _ i4 f 0 +
        @ite _ _ i5 f 0 + @ite _ _ i6 f 0 + @ite _ _ i7 f 0 := by
  by_cases ha : e1 ∧ e2 ∧ e3 ∧ m
  · obtain ⟨h1, h2, h3, hm⟩ := ha
    by_cases hL : L
    · by_cases hW : W
      · simp [h1, h2, h3, hm, hL, hW]
      · simp [h1, h2, h3, hm, hL, hW]
    by_cases hJ : J
    · simp [h1, h2, h3, hm, hL, hJ]
    by_cases hK : Km
    · simp [h1, h2, h3, hm, hL, hJ, hK]
    by_cases hE : Ed
    · simp [h1, h2, h3, hm, hL, hJ, hK, hE]
    by_cases hR : WR
    · simp [h1, h2, h3, hm, hL, hJ, hK, hE, hR]
    · simp [h1, h2, h3, hm, hL, hJ, hK, hE, hR]
  · have n1 : ¬ (e1 ∧ e2 ∧ e3 ∧ (m ∧ (L ∧ W))) := fun ⟨a, b, c, d, _⟩ => ha ⟨a, b, c, d⟩
    have n2 : ¬ (e1 ∧ e2 ∧ e3 ∧ (m ∧ (L ∧ ¬ W))) := fun ⟨a, b, c, d, _⟩ => ha ⟨a, b, c, d⟩
    have n3 : ¬ (e1 ∧ e2 ∧ e3 ∧ (m ∧ (¬ L ∧ J))) := fun ⟨a, b, c, d, _⟩ => ha ⟨a, b, c, d⟩
    have n4 : ¬ (e1 ∧ e2 ∧ e3 ∧ (m ∧ (¬ L ∧ ¬ J ∧ Km))) := fun ⟨a, b, c, d, _⟩ => ha ⟨a, b, c, d⟩
    have n5 : ¬ (e1 ∧ e2 ∧ e3 ∧ (m ∧ (¬ L ∧ ¬ J ∧ ¬ Km ∧ Ed))) := fun ⟨a, b, c, d, _⟩ => ha ⟨a, b, c, d⟩
    have n6 : ¬ (e1 ∧ e2 ∧ e3 ∧ (m ∧ (¬ L ∧ ¬ J ∧ ¬ Km ∧ ¬ Ed ∧ ¬ WR))) :=
      fun ⟨a, b, c, d, _⟩ => ha ⟨a, b, c, d⟩
    have n7 : ¬ (e1 ∧ e2 ∧ e3 ∧ (m ∧ (¬ L ∧ ¬ J ∧ ¬ Km ∧ ¬ Ed ∧ WR))) :=
      fun ⟨a, b, c, d, _⟩ => ha ⟨a, b, c, d⟩
    rw [if_neg ha, if_neg n1, if_neg n2, if_neg n3, if_neg n4, if_neg n5, if_neg n6, if_neg n7]; ring

/-- **Exact seven-cell decomposition of the LONG pair sum at decoration `d`.** -/
theorem long_pair_decomp (Jlow Jhigh q a h : ℕ) (δ : ℝ) (d : Finset ℕ) :
    regionPairSumMiddleWhere Jlow Jhigh q h (centralGate h) (longEither δ) d
        (foldRow q a (primeSetProduct d)) =
      WLPart Jlow Jhigh q a h δ d + CLPart Jlow Jhigh q a h δ d + RLPart Jlow Jhigh q a h δ d +
        ManyLPart Jlow Jhigh q a h δ d + EdgeLPart Jlow Jhigh q a h δ d +
        ResLPart Jlow Jhigh q a h δ d + WRLPart Jlow Jhigh q a h δ d := by
  rw [pairSum_eq_double]
  unfold WLPart CLPart RLPart ManyLPart EdgeLPart ResLPart WRLPart RMR Tsrc
  simp only [← sum_add_distrib]
  refine sum_congr rfl fun B _ => sum_congr rfl fun C _ => ?_
  unfold pairTerm
  exact split7 _ _ _ _ _ _ _ _ _

/-- **The LONG pair sum at any decoration is `≤ 7Λ^{19/20}`** (given `WeilHyp`). -/
theorem long_pair_le (hW : WeilHyp) (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (Jlow Jhigh a h : ℕ) (d : Finset ℕ), Λ₀ ≤ Real.log h → 2 ≤ h →
      d ⊆ h.primeFactors →
      |regionPairSumMiddleWhere Jlow Jhigh q h (centralGate h) (longEither δ) d
          (foldRow q a (primeSetProduct d))| ≤ 7 * (Real.log h) ^ (19 / 20 : ℝ) := by
  obtain ⟨Λ₁, hΛ₁, h1⟩ := WL_physical q hq δ hδ0 hδ1
  obtain ⟨Λ₂, hΛ₂, h2⟩ := CL_physical q hq δ hδ0 hδ1
  obtain ⟨Λ₃, hΛ₃, h3⟩ := RL_physical q hq δ hδ0 hδ1
  obtain ⟨Λ₄, hΛ₄, h4⟩ := ManyL_physical q hq δ
  obtain ⟨Λ₅, hΛ₅, h5⟩ := EdgeL_physical q hq δ hδ0
  obtain ⟨Λ₆, hΛ₆, h6⟩ := ResL_physical q hq δ hδ0
  obtain ⟨Λ₇, hΛ₇, h7⟩ := WRL_physical hW q hq δ hδ0 hδ1
  refine ⟨max Λ₁ (max Λ₂ (max Λ₃ (max Λ₄ (max Λ₅ (max Λ₆ Λ₇))))), le_trans hΛ₁ (le_max_left _ _), ?_⟩
  intro Jlow Jhigh a h d hΛ hh hd
  have L1 : Λ₁ ≤ Real.log h := le_trans (by simp) hΛ
  have L2 : Λ₂ ≤ Real.log h := le_trans (by simp) hΛ
  have L3 : Λ₃ ≤ Real.log h := le_trans (by simp) hΛ
  have L4 : Λ₄ ≤ Real.log h := le_trans (by simp) hΛ
  have L5 : Λ₅ ≤ Real.log h := le_trans (by simp) hΛ
  have L6 : Λ₆ ≤ Real.log h := le_trans (by simp) hΛ
  have L7 : Λ₇ ≤ Real.log h := le_trans (by simp) hΛ
  have hΛ1 : 1 ≤ Real.log h := by linarith
  rw [long_pair_decomp]
  have c1 := h1 Jlow Jhigh a h d L1 hh
  have c2 := h2 Jlow Jhigh a h d L2 hh hd
  have c3 := h3 Jlow Jhigh a h d L3 hh
  have c4 := h4 Jlow Jhigh a h d L4 hh
  have c5 := h5 Jlow Jhigh a h d L5 hh
  have c6 := h6 Jlow Jhigh a h d L6 hh
  have c7 := h7 Jlow Jhigh a h d L7 hh
  have m1 : (Real.log h) ^ (-(80 : ℝ)) ≤ (Real.log h) ^ (19 / 20 : ℝ) :=
    Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)
  have m2 : (Real.log h) ^ (-(15 : ℝ)) ≤ (Real.log h) ^ (19 / 20 : ℝ) :=
    Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)
  have m3 : (Real.log h) ^ (-(75 : ℝ)) ≤ (Real.log h) ^ (19 / 20 : ℝ) :=
    Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)
  have m4 : (Real.log h) ^ (-(50 : ℝ)) ≤ (Real.log h) ^ (19 / 20 : ℝ) :=
    Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)
  have m6 : (Real.log h) ^ (7 / 10 : ℝ) ≤ (Real.log h) ^ (19 / 20 : ℝ) :=
    Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)
  set A1 := WLPart Jlow Jhigh q a h δ d
  set A2 := CLPart Jlow Jhigh q a h δ d
  set A3 := RLPart Jlow Jhigh q a h δ d
  set A4 := ManyLPart Jlow Jhigh q a h δ d
  set A5 := EdgeLPart Jlow Jhigh q a h δ d
  set A6 := ResLPart Jlow Jhigh q a h δ d
  set A7 := WRLPart Jlow Jhigh q a h δ d
  have t : |A1 + A2 + A3 + A4 + A5 + A6 + A7| ≤ |A1| + |A2| + |A3| + |A4| + |A5| + |A6| + |A7| := by
    have := abs_add_le (A1 + A2 + A3 + A4 + A5 + A6) A7
    have := abs_add_le (A1 + A2 + A3 + A4 + A5) A6
    have := abs_add_le (A1 + A2 + A3 + A4) A5
    have := abs_add_le (A1 + A2 + A3) A4
    have := abs_add_le (A1 + A2) A3
    have := abs_add_le A1 A2
    linarith
  linarith

open GoldC.QuillonCopyM in
/-- **LONG (δ < 1/3) end to end, given `WeilHyp`.** `signedLongMiddle Jlow Jhigh δ` is uniformly sublogarithmic,
for arbitrary cutoff functions `Jlow` and `Jhigh`. -/
theorem long_sublog (hW : WeilHyp) (Jlow Jhigh : ℕ → ℕ) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    SourceUniformSublog (signedLongMiddle Jlow Jhigh δ) := by
  intro q hq _hsq eps heps
  obtain ⟨Λ₁, hΛ₁, hP⟩ := long_pair_le hW q hq δ hδ0 hδ1
  obtain ⟨Λ₂, hΛ₂, hpl⟩ := polylog_le 8 (1 / 1000) (by norm_num)
  obtain ⟨Λ₃, hΛ₃, hK⟩ := const_le_rpow (1792 * Real.exp 10 / eps) (49 / 1000) (by norm_num)
  set Λs := max Λ₁ (max Λ₂ Λ₃) with hΛs
  refine ⟨⌈Real.exp Λs⌉₊ + 16, ?_⟩
  intro a h _ha _hh0 _hpar hH0
  have hh16 : 16 ≤ h := by omega
  have hh0 : (0 : ℝ) < h := by exact_mod_cast (show 0 < h by omega)
  have hlog : Λs ≤ Real.log h := by
    have h1 : Real.exp Λs ≤ h := by
      have : (⌈Real.exp Λs⌉₊ : ℝ) ≤ h := by exact_mod_cast (show ⌈Real.exp Λs⌉₊ ≤ h by omega)
      exact le_trans (Nat.le_ceil _) this
    calc Λs = Real.log (Real.exp Λs) := (Real.log_exp _).symm
      _ ≤ Real.log h := Real.log_le_log (Real.exp_pos _) h1
  have L1 : Λ₁ ≤ Real.log h := le_trans (by simp [hΛs]) hlog
  have L2 : Λ₂ ≤ Real.log h := le_trans (by simp [hΛs]) hlog
  have L3 : Λ₃ ≤ Real.log h := le_trans (by simp [hΛs]) hlog
  set Λ := Real.log h with hΛdef
  have hΛ2 : 2 ≤ Λ := le_trans hΛ₁ L1
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  -- unfold the CORE sum
  show |signedLongMiddle Jlow Jhigh δ q a h| ≤ eps * Λ
  unfold signedLongMiddle regionSumMiddleWhere regionDecorations
  set P := GoldC.QuillonCopyG.decoratedHeightPrimeSet q h with hPdef
  have hV0 : ∀ d ∈ P.powerset, 0 ≤ GoldC.QuillonCopyG.decorationWeight h d := by
    intro d hd
    unfold GoldC.QuillonCopyG.decorationWeight
    refine prod_nonneg fun p hp => ?_
    have h5 := (GoldC.QuillonCopyG.mem_P (mem_powerset.1 hd hp)).2.2.1
    have : (5 : ℝ) ≤ p := by exact_mod_cast h5
    split_ifs
    · exact div_nonneg zero_le_one (by linarith)
    · exact div_nonneg zero_le_one (by linarith)
  have hdpf : ∀ d ∈ P.powerset, d ⊆ h.primeFactors := by
    intro d hd p hp
    obtain ⟨hpp, hph, -, hh0'⟩ := GoldC.QuillonCopyG.mem_P (mem_powerset.1 hd hp)
    exact Nat.mem_primeFactors.2 ⟨hpp, hph, hh0'⟩
  have hG := GoldC.QuillonCopyG.decoration_mass_le_loglog_pow q h hh16
  rw [← hPdef] at hG
  have hll : (Real.log Λ / Real.log 2 + 1) ^ 8 ≤ 256 * (1 + Real.log Λ) ^ 8 := by
    have hl2 : (1 / 2 : ℝ) < Real.log 2 := GoldC.QuillonLam.log2_gt_half
    have hlΛ : 0 ≤ Real.log Λ := Real.log_nonneg hΛ1
    have h1 : Real.log Λ / Real.log 2 + 1 ≤ 2 * (1 + Real.log Λ) := by
      have : Real.log Λ / Real.log 2 ≤ 2 * Real.log Λ := by
        rw [div_le_iff₀ (by linarith)]; nlinarith
      linarith
    calc (Real.log Λ / Real.log 2 + 1) ^ 8 ≤ (2 * (1 + Real.log Λ)) ^ 8 :=
          pow_le_pow_left₀ (by positivity) h1 8
      _ = 256 * (1 + Real.log Λ) ^ 8 := by ring
  have hpl' := hpl Λ L2
  have hK' := hK Λ L3
  calc |∑ d ∈ P.powerset, GoldC.QuillonCopyG.decorationWeight h d *
          regionPairSumMiddleWhere (Jlow h) (Jhigh h) q h (centralGate h) (longEither δ) d
            (foldRow q a (primeSetProduct d))|
      ≤ ∑ d ∈ P.powerset, GoldC.QuillonCopyG.decorationWeight h d * (7 * Λ ^ (19 / 20 : ℝ)) := by
        refine le_trans (abs_sum_le_sum_abs _ _) (sum_le_sum fun d hd => ?_)
        rw [abs_mul, abs_of_nonneg (hV0 d hd)]
        exact mul_le_mul_of_nonneg_left (hP (Jlow h) (Jhigh h) a h d L1 (by omega) (hdpf d hd)) (hV0 d hd)
    _ = (∑ d ∈ P.powerset, GoldC.QuillonCopyG.decorationWeight h d) * (7 * Λ ^ (19 / 20 : ℝ)) := by
        rw [sum_mul]
    _ ≤ (Real.exp 10 * (256 * Λ ^ (1 / 1000 : ℝ))) * (7 * Λ ^ (19 / 20 : ℝ)) := by
        apply mul_le_mul_of_nonneg_right _ (by positivity)
        refine le_trans hG ?_
        apply mul_le_mul_of_nonneg_left _ (Real.exp_pos _).le
        exact le_trans hll (by linarith)
    _ = 1792 * Real.exp 10 * Λ ^ (951 / 1000 : ℝ) := by
        rw [show Λ ^ (951 / 1000 : ℝ) = Λ ^ (1 / 1000 : ℝ) * Λ ^ (19 / 20 : ℝ) by
          rw [← Real.rpow_add hΛ0]; norm_num]
        ring
    _ ≤ eps * Λ := by
        have e : Λ = Λ ^ (49 / 1000 : ℝ) * Λ ^ (951 / 1000 : ℝ) := by
          rw [← Real.rpow_add hΛ0]; norm_num
        have hp : 0 ≤ Λ ^ (951 / 1000 : ℝ) := by positivity
        have h1 : 1792 * Real.exp 10 ≤ eps * Λ ^ (49 / 1000 : ℝ) := by
          rw [div_le_iff₀ heps] at hK'; linarith
        calc 1792 * Real.exp 10 * Λ ^ (951 / 1000 : ℝ) ≤ eps * Λ ^ (49 / 1000 : ℝ) * Λ ^ (951 / 1000 : ℝ) :=
              mul_le_mul_of_nonneg_right h1 hp
          _ = eps * Λ := by rw [mul_assoc, ← e]

end GoldC.QuillonLongFinal

#print axioms GoldC.QuillonLongFinal.split7
#print axioms GoldC.QuillonLongFinal.long_pair_decomp
#print axioms GoldC.QuillonLongFinal.long_pair_le
#print axioms GoldC.QuillonLongFinal.long_sublog
