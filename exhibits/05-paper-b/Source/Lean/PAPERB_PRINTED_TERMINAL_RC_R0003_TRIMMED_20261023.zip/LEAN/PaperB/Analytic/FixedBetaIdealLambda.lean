import PaperB.Analytic.FixedBetaConstSublinear

namespace PaperB.Analytic

open Real

lemma fixedBeta_ideal_lambda_identity
    {W beta : ℝ} {k : ℕ}
    (hW : 0 < W) :
    (W ^ beta⁻¹) * (k.factorial : ℝ) *
        (W ^ (k + 1))⁻¹
      =
    (k.factorial : ℝ) *
        W ^ fixedBetaLambdaExponent beta k := by
  rw [fixedBetaLambdaExponent]
  have hsub := Real.rpow_sub hW beta⁻¹ (k + 1 : ℝ)
  have hnat : W ^ (k + 1 : ℝ) = W ^ (k + 1) := by
    simpa using Real.rpow_natCast W (k + 1)
  rw [hsub, hnat]
  field_simp [ne_of_gt (pow_pos hW (k + 1))]

#print axioms fixedBeta_ideal_lambda_identity

end PaperB.Analytic
