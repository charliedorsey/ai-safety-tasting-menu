import PaperB.FixedQ.GlobalProperWalfiszBounds
import PaperB.FixedQ.GlobalProperSmallBoxRate

set_option maxHeartbeats 1500000

open Filter Real Asymptotics
open scoped BigOperators

namespace PaperB.FixedQ

lemma globalProper_top_loglog_nonneg
    {N0 h : ℕ} (hN0 : 0 < N0) :
    0 ≤
      Real.log
        (Real.log
          ((N0 * 2 ^ (Nat.log 2 (globalProperBooleanProductCutoff h) + 1) : ℕ) : ℝ)) := by
  let J := Nat.log 2 (globalProperBooleanProductCutoff h) + 1
  have hK20 : 20 ≤ globalProperBooleanBlockCount h := by
    unfold globalProperBooleanBlockCount
    omega
  have hJ21 : 21 ≤ J := by
    dsimp [J]
    rw [globalProper_log_cutoff]
    omega
  have hp4 : 4 ≤ 2 ^ J := by
    have h2pow : 2 ^ 2 ≤ 2 ^ J :=
      Nat.pow_le_pow_right (by norm_num) (by omega)
    norm_num at h2pow ⊢
    exact h2pow
  have hN1 : 1 ≤ N0 := Nat.one_le_iff_ne_zero.mpr hN0.ne'
  have hU4 : 4 ≤ N0 * 2 ^ J := by
    calc
      4 = 1 * 4 := by norm_num
      _ ≤ N0 * 2 ^ J := Nat.mul_le_mul hN1 hp4
  have hUpos : 0 < (N0 * 2 ^ J : ℕ) := by positivity
  have hexpU : Real.exp 1 < ((N0 * 2 ^ J : ℕ) : ℝ) := by
    have h3U : (3 : ℝ) ≤ ((N0 * 2 ^ J : ℕ) : ℝ) := by
      exact_mod_cast (show 3 ≤ N0 * 2 ^ J by omega)
    exact Real.exp_one_lt_three.trans_le h3U
  have hlogU1 :
      1 < Real.log ((N0 * 2 ^ J : ℕ) : ℝ) := by
    exact (Real.lt_log_iff_exp_lt (by exact_mod_cast hUpos)).2 hexpU
  have hlogUpos : 0 < Real.log ((N0 * 2 ^ J : ℕ) : ℝ) := by linarith
  have hloglog0 :
      0 ≤ Real.log (Real.log ((N0 * 2 ^ J : ℕ) : ℝ)) :=
    Real.log_nonneg hlogU1.le
  exact hloglog0

lemma globalProperOrdinaryGeometricRate_le_walfisz
    {q N0 h : ℕ} {C : ℝ}
    (hC : 0 ≤ C) (hN0 : 0 < N0)
    (hL : 1 ≤ Real.log (h : ℝ))
    (hLL : 1 ≤ Real.log (Real.log (h : ℝ)))
    (hJ :
      (((Nat.log 2 (globalProperBooleanProductCutoff h) + 1 : ℕ) : ℝ)) ≤
        41 * (Real.log (h : ℝ)) ^ h2BooleanSigma)
    (hU :
      Real.log
          ((N0 * 2 ^ (Nat.log 2 (globalProperBooleanProductCutoff h) + 1) : ℕ) : ℝ)
        ≤ 42 * (Real.log (h : ℝ)) ^ h2BooleanSigma)
    (hLLU :
      Real.log
        (Real.log
          ((N0 * 2 ^ (Nat.log 2 (globalProperBooleanProductCutoff h) + 1) : ℕ) : ℝ))
        ≤ 42 * Real.log (Real.log (h : ℝ))) :
    globalProperOrdinaryGeometricRate q N0 C
        (globalProperBooleanProductCutoff h) ≤
      ((12 * (fixedQPeriod q : ℝ)) *
          h2BooleanInitialProperWeightMass q N0 +
        41 * C * (42 : ℝ) ^ (h2BooleanX0 - 1) * (42 : ℝ)^2) *
      (Real.log (h : ℝ)) ^
        (h2BooleanSigma * h2BooleanX0) *
      (Real.log (Real.log (h : ℝ))) ^ 2 := by
  let L : ℝ := Real.log (h : ℝ)
  let LL : ℝ := Real.log L
  let S : ℝ := L ^ h2BooleanSigma
  let J : ℝ :=
    ((Nat.log 2 (globalProperBooleanProductCutoff h) + 1 : ℕ) : ℝ)
  let U : ℕ :=
    N0 * 2 ^ (Nat.log 2 (globalProperBooleanProductCutoff h) + 1)
  let B : ℝ :=
    (12 * (fixedQPeriod q : ℝ)) *
      h2BooleanInitialProperWeightMass q N0
  let G : ℝ :=
    41 * C * (42 : ℝ) ^ (h2BooleanX0 - 1) * (42 : ℝ)^2
  have hL0 : 0 ≤ L := le_trans zero_le_one hL
  have hLL0 : 0 ≤ LL := by
    exact le_trans zero_le_one hLL
  have hS1 : 1 ≤ S := by
    dsimp [S, L]
    exact Real.one_le_rpow hL h2BooleanSigma_pos.le
  have hS0 : 0 ≤ S := le_trans zero_le_one hS1
  have hSpos : 0 < S := lt_of_lt_of_le zero_lt_one hS1
  have ha0 : 0 ≤ h2BooleanX0 - 1 :=
    sub_nonneg.mpr h2BooleanX0_one_le_public
  have hlogU0 : 0 ≤ Real.log (U : ℝ) := by
    have hp := globalProper_top_log_pos (h := h) hN0
    exact hp.le
  have hpowU :
      (Real.log (U : ℝ)) ^ (h2BooleanX0 - 1) ≤
        (42 * S) ^ (h2BooleanX0 - 1) := by
    apply Real.rpow_le_rpow hlogU0
    · exact hU
    · exact ha0
  have hpowFact :
      (42 * S) ^ (h2BooleanX0 - 1) =
        (42 : ℝ) ^ (h2BooleanX0 - 1) *
          S ^ (h2BooleanX0 - 1) := by
    rw [Real.mul_rpow (by norm_num : (0 : ℝ) ≤ 42) hS0]
  have hLLU0 :
      0 ≤ Real.log (Real.log (U : ℝ)) := by
    exact globalProper_top_loglog_nonneg (h := h) hN0
  have hLLUsq :
      (Real.log (Real.log (U : ℝ))) ^ 2 ≤
        (42 * LL) ^ 2 := by
    have hLLU' :
        Real.log (Real.log (U : ℝ)) ≤ 42 * LL := by
      exact hLLU
    have h42LL0 : 0 ≤ 42 * LL := mul_nonneg (by norm_num) hLL0
    nlinarith
  have hSprod :
      S * S ^ (h2BooleanX0 - 1) =
        S ^ h2BooleanX0 := by
    calc
      S * S ^ (h2BooleanX0 - 1) =
          S ^ (1 : ℝ) * S ^ (h2BooleanX0 - 1) := by simp
      _ = S ^ ((1 : ℝ) + (h2BooleanX0 - 1)) := by
        rw [Real.rpow_add hSpos]
      _ = S ^ h2BooleanX0 := by ring_nf
  have hSrho :
      S ^ h2BooleanX0 =
        L ^ (h2BooleanSigma * h2BooleanX0) := by
    dsimp [S]
    exact (Real.rpow_mul hL0 h2BooleanSigma h2BooleanX0).symm
  have hrho0 :
      0 ≤ h2BooleanSigma * h2BooleanX0 :=
    mul_nonneg h2BooleanSigma_pos.le
      (le_trans zero_le_one h2BooleanX0_one_le_public)
  have hLrho1 :
      1 ≤ L ^ (h2BooleanSigma * h2BooleanX0) :=
    Real.one_le_rpow hL hrho0
  have hLLsq1 : 1 ≤ LL ^ 2 := by nlinarith
  have hT1 :
      1 ≤ L ^ (h2BooleanSigma * h2BooleanX0) * LL ^ 2 := by
    calc
      1 = 1 * 1 := by norm_num
      _ ≤ L ^ (h2BooleanSigma * h2BooleanX0) * LL ^ 2 :=
        mul_le_mul hLrho1 hLLsq1 (by norm_num)
          (le_trans zero_le_one hLrho1)
  have hB0 : 0 ≤ B := by
    dsimp [B]
    have hi := h2BooleanInitialProperWeightMass_nonneg q N0
    positivity
  have hG0 : 0 ≤ G := by
    dsimp [G]
    positivity
  have hJ' : J ≤ 41 * S := by
    exact hJ
  have hgeom :
      J * C * (Real.log (U : ℝ)) ^ (h2BooleanX0 - 1) *
          (Real.log (Real.log (U : ℝ))) ^ 2
        ≤ G * L ^ (h2BooleanSigma * h2BooleanX0) * LL ^ 2 := by
    have h41S0 : 0 ≤ 41 * S := mul_nonneg (by norm_num) hS0
    have hJC :
        J * C ≤ (41 * S) * C :=
      mul_le_mul_of_nonneg_right hJ' hC
    have hp0 :
        0 ≤ (Real.log (U : ℝ)) ^ (h2BooleanX0 - 1) :=
      Real.rpow_nonneg hlogU0 _
    have hpB0 :
        0 ≤ (42 * S) ^ (h2BooleanX0 - 1) :=
      Real.rpow_nonneg (mul_nonneg (by norm_num) hS0) _
    have hcoef0 : 0 ≤ (41 * S) * C :=
      mul_nonneg h41S0 hC
    have hJCP :
        J * C * (Real.log (U : ℝ)) ^ (h2BooleanX0 - 1) ≤
          (41 * S) * C * (42 * S) ^ (h2BooleanX0 - 1) := by
      calc
        J * C * (Real.log (U : ℝ)) ^ (h2BooleanX0 - 1)
          ≤ (41 * S) * C * (Real.log (U : ℝ)) ^ (h2BooleanX0 - 1) :=
            mul_le_mul_of_nonneg_right hJC hp0
        _ ≤ (41 * S) * C * (42 * S) ^ (h2BooleanX0 - 1) :=
            mul_le_mul_of_nonneg_left hpowU hcoef0
    have hcoefB0 :
        0 ≤ (41 * S) * C * (42 * S) ^ (h2BooleanX0 - 1) :=
      mul_nonneg hcoef0 hpB0
    calc
      J * C * (Real.log (U : ℝ)) ^ (h2BooleanX0 - 1) *
          (Real.log (Real.log (U : ℝ))) ^ 2
        ≤ (41 * S) * C * (42 * S) ^ (h2BooleanX0 - 1) *
            (Real.log (Real.log (U : ℝ))) ^ 2 :=
          mul_le_mul_of_nonneg_right hJCP (sq_nonneg _)
      _ ≤ (41 * S) * C * (42 * S) ^ (h2BooleanX0 - 1) *
            (42 * LL) ^ 2 :=
          mul_le_mul_of_nonneg_left hLLUsq hcoefB0
      _ = G * L ^ (h2BooleanSigma * h2BooleanX0) * LL ^ 2 := by
        rw [hpowFact, mul_pow]
        calc
          (41 * S) * C *
                ((42 : ℝ) ^ (h2BooleanX0 - 1) *
                  S ^ (h2BooleanX0 - 1)) *
                ((42 : ℝ) ^ 2 * LL ^ 2)
              =
            (41 * C * (42 : ℝ) ^ (h2BooleanX0 - 1)) *
              (S * S ^ (h2BooleanX0 - 1)) *
              ((42 : ℝ) ^ 2 * LL ^ 2) := by ring
          _ =
            (41 * C * (42 : ℝ) ^ (h2BooleanX0 - 1)) *
              L ^ (h2BooleanSigma * h2BooleanX0) *
              ((42 : ℝ) ^ 2 * LL ^ 2) := by
                rw [hSprod, hSrho]
          _ = G * L ^ (h2BooleanSigma * h2BooleanX0) * LL ^ 2 := by
                dsimp [G]
                ring
  unfold globalProperOrdinaryGeometricRate
  change B +
      J * C * (Real.log (U : ℝ)) ^ (h2BooleanX0 - 1) *
        (Real.log (Real.log (U : ℝ))) ^ 2 ≤
    (B + G) * L ^ (h2BooleanSigma * h2BooleanX0) * LL ^ 2
  calc
    B + J * C * (Real.log (U : ℝ)) ^ (h2BooleanX0 - 1) *
          (Real.log (Real.log (U : ℝ))) ^ 2
      ≤ B + G * L ^ (h2BooleanSigma * h2BooleanX0) * LL ^ 2 :=
        add_le_add (le_refl B) hgeom
    _ ≤ B * (L ^ (h2BooleanSigma * h2BooleanX0) * LL ^ 2) +
          G * L ^ (h2BooleanSigma * h2BooleanX0) * LL ^ 2 := by
        have hB :
            B ≤ B * (L ^ (h2BooleanSigma * h2BooleanX0) * LL ^ 2) := by
          calc
            B = B * 1 := by ring
            _ ≤ B * (L ^ (h2BooleanSigma * h2BooleanX0) * LL ^ 2) :=
              mul_le_mul_of_nonneg_left hT1 hB0
        exact add_le_add hB (le_refl _)
    _ = (B + G) * L ^ (h2BooleanSigma * h2BooleanX0) * LL ^ 2 := by
        ring

theorem globalProperSmallBoxLogPowerSaving
    (q : ℕ) (hq : 0 < q) :
    GlobalProperSmallBoxLogPowerSaving q := by
  obtain ⟨C, N0, hC, hN0, hRate⟩ :=
    globalProperDecoratedSmallMajorant_le_geometric_rate q hq
  obtain ⟨H0, hW⟩ := globalProperWalfiszBounds N0 hN0
  let B : ℝ :=
    (12 * (fixedQPeriod q : ℝ)) *
      h2BooleanInitialProperWeightMass q N0
  let G : ℝ :=
    41 * C * (42 : ℝ) ^ (h2BooleanX0 - 1) * (42 : ℝ)^2
  let Ctot : ℝ := weakDecoratedMertensC * (B + G)
  refine ⟨Ctot, h2BooleanSigma * h2BooleanX0, 3, H0, ?_, ?_, ?_⟩
  · dsimp [Ctot, B, G]
    have hw : 0 ≤ weakDecoratedMertensC := by
      unfold weakDecoratedMertensC weakMertensC
      positivity
    have hi := h2BooleanInitialProperWeightMass_nonneg q N0
    positivity
  · exact h2BooleanSigma_mul_X0_lt_one
  · intro a h ha hh h2 hH
    rcases hW h hH with
      ⟨hh16, hL, hLL, hS1, hJ, hU, hLLU⟩
    have hMajor :=
      hRate a h (globalProperBooleanProductCutoff h) hh16 h2
    have hCore :=
      globalProperOrdinaryGeometricRate_le_walfisz
        (q := q) hC hN0 hL hLL hJ hU hLLU
    have hAbs :=
      abs_globalProperSmallAnalytic_le_decoratedMajorant
        (q := q) (a := a) (h := h)
        (Z := globalProperBooleanProductCutoff h) hq hh h2
    calc
      |globalProperSmallAnalytic q a h
          (globalProperBooleanProductCutoff h)|
        ≤ globalProperDecoratedSmallMajorant q a h
            (globalProperBooleanProductCutoff h) := hAbs
      _ ≤ (weakDecoratedMertensC *
            Real.log (Real.log (h : ℝ))) *
          globalProperOrdinaryGeometricRate q N0 C
            (globalProperBooleanProductCutoff h) := hMajor
      _ ≤ (weakDecoratedMertensC *
            Real.log (Real.log (h : ℝ))) *
          ((B + G) *
            (Real.log (h : ℝ)) ^
              (h2BooleanSigma * h2BooleanX0) *
            (Real.log (Real.log (h : ℝ))) ^ 2) := by
          have hw : 0 ≤ weakDecoratedMertensC := by
            unfold weakDecoratedMertensC weakMertensC
            positivity
          have houter0 :
              0 ≤ weakDecoratedMertensC *
                Real.log (Real.log (h : ℝ)) :=
            mul_nonneg hw (le_trans zero_le_one hLL)
          exact mul_le_mul_of_nonneg_left hCore houter0
      _ = Ctot *
          (Real.log (h : ℝ)) ^
            (h2BooleanSigma * h2BooleanX0) *
          (Real.log (Real.log (h : ℝ))) ^ 3 := by
          dsimp [Ctot]
          ring

#print axioms globalProper_top_loglog_nonneg
#print axioms globalProperOrdinaryGeometricRate_le_walfisz
#print axioms globalProperSmallBoxLogPowerSaving

end PaperB.FixedQ
