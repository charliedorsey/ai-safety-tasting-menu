import GoldB.VinoMain
import GoldB.SfrakBounds

/-!
# GoldB.Params — the constants of the Karatsuba lemma

All constants depend only on `(c0, c1, c2, c3)`.
-/

namespace GoldB

structure KParams where
  c0 : ℝ
  c1 : ℝ
  c2 : ℝ
  c3 : ℝ
  h0 : 0 < c0
  h0' : c0 < 1
  h3 : 0 < c3
  h32 : c3 ≤ c2
  h21 : c2 < c1
  h1 : c1 < 1

namespace KParams

variable (K : KParams)

noncomputable def ρ : ℝ := min K.c3 (min (K.c1 / 4) ((K.c1 - K.c2) / 2))
noncomputable def L1 : ℝ := Real.log (8 / (K.ρ * K.c0 ^ 2))
noncomputable def γ1 : ℝ := K.ρ * K.c0 ^ 2 / (128 * K.L1 ^ 2)
noncomputable def δ0 : ℝ := min 1 (K.ρ * K.c0 ^ 2 / 16)
noncomputable def Kc : ℝ := Real.exp (84 + Real.log (1 / K.δ0))
noncomputable def tau (k : ℕ) : ℕ := ⌈(k : ℝ) * K.L1⌉₊
noncomputable def eta (k : ℕ) : ℝ := min (1 / (2 * (k : ℝ) ^ 2 * (k + 1))) ((K.c1 - K.c2) / 4)
noncomputable def aexp (k : ℕ) : ℝ := K.c1 / 2 - K.eta k
noncomputable def uu (k : ℕ) (P : ℝ) : ℝ := P ^ K.aexp k
noncomputable def P2 (k : ℕ) (P : ℝ) : ℕ := ⌊K.uu k P⌋₊
noncomputable def QQ (k : ℕ) (P : ℝ) : ℕ := K.P2 k P + 1

lemma c1_pos : 0 < K.c1 := by linarith [K.h3, K.h32, K.h21]
lemma gap_pos : 0 < K.c1 - K.c2 := by linarith [K.h21]

lemma ρ_pos : 0 < K.ρ := by
  unfold ρ
  have := K.c1_pos; have := K.gap_pos; have := K.h3
  apply lt_min this; apply lt_min <;> linarith

lemma ρ_le_c3 : K.ρ ≤ K.c3 := min_le_left _ _
lemma ρ_le_c1 : K.ρ ≤ K.c1 / 4 := (min_le_right _ _).trans (min_le_left _ _)
lemma ρ_le_gap : K.ρ ≤ (K.c1 - K.c2) / 2 := (min_le_right _ _).trans (min_le_right _ _)
lemma ρ_lt_one : K.ρ < 1 := lt_of_le_of_lt K.ρ_le_c3 (by linarith [K.h32, K.h21, K.h1])

lemma ρc_pos : 0 < K.ρ * K.c0 ^ 2 := mul_pos K.ρ_pos (pow_pos K.h0 2)
lemma ρc_lt_one : K.ρ * K.c0 ^ 2 < 1 := by
  have h1 : K.c0 ^ 2 < 1 := by nlinarith [K.h0, K.h0']
  have h2 : 0 < K.c0 ^ 2 := pow_pos K.h0 2
  nlinarith [K.ρ_pos, K.ρ_lt_one]

lemma L1_ge_one : 1 ≤ K.L1 := by
  unfold L1
  have h8 : (8 : ℝ) ≤ 8 / (K.ρ * K.c0 ^ 2) := by
    rw [le_div_iff₀ K.ρc_pos]; nlinarith [K.ρc_lt_one]
  have he : Real.exp 1 ≤ 8 := by
    have := Real.exp_one_lt_d9; linarith
  rw [Real.le_log_iff_exp_le (by linarith)]
  linarith

lemma L1_pos : 0 < K.L1 := lt_of_lt_of_le one_pos K.L1_ge_one

lemma exp_neg_L1 : Real.exp (-K.L1) = K.ρ * K.c0 ^ 2 / 8 := by
  unfold L1
  rw [Real.exp_neg, Real.exp_log (div_pos (by norm_num) K.ρc_pos)]
  field_simp

lemma γ1_pos : 0 < K.γ1 := by
  unfold γ1; have := K.ρc_pos; have := K.L1_pos; positivity

lemma δ0_pos : 0 < K.δ0 := by
  unfold δ0; exact lt_min one_pos (by have := K.ρc_pos; positivity)
lemma δ0_le_one : K.δ0 ≤ 1 := min_le_left _ _
lemma δ0_le : K.δ0 ≤ K.ρ * K.c0 ^ 2 / 16 := min_le_right _ _

lemma Kc_pos : 0 < K.Kc := Real.exp_pos _

lemma tau_ge (k : ℕ) : k ≤ K.tau k := by
  unfold tau
  have h : (k : ℝ) ≤ (⌈(k : ℝ) * K.L1⌉₊ : ℝ) :=
    (le_mul_of_one_le_right (by positivity) K.L1_ge_one).trans (Nat.le_ceil _)
  exact_mod_cast h

lemma tau_ge' (k : ℕ) : (k : ℝ) * K.L1 ≤ K.tau k := Nat.le_ceil _

lemma tau_le (k : ℕ) (hk : 1 ≤ k) : (K.tau k : ℝ) ≤ 2 * k * K.L1 := by
  unfold tau
  have h1 : (1 : ℝ) ≤ k * K.L1 := by
    have : (1 : ℝ) ≤ k := by exact_mod_cast hk
    nlinarith [K.L1_ge_one]
  have := Nat.ceil_lt_add_one (by positivity : (0 : ℝ) ≤ k * K.L1)
  linarith

lemma eta_nonneg (k : ℕ) : 0 ≤ K.eta k := by
  unfold eta; exact le_min (by positivity) (by linarith [K.gap_pos])
/-- REPAIR NOTE (Quillon): the archived statement had no `1 ≤ k`; it is false at `k = 0`
(`1/(2·0²·1) = 0` in Lean, so `eta 0 = 0`).  The only strict use is in `left_bound`, where
`1 ≤ k` holds; `aexp_le` now uses `eta_nonneg`. -/
lemma eta_pos (k : ℕ) (hk : 1 ≤ k) : 0 < K.eta k := by
  have hk' : (0 : ℝ) < k := by exact_mod_cast hk
  unfold eta
  exact lt_min (one_div_pos.mpr (mul_pos (mul_pos two_pos (pow_pos hk' 2)) (by linarith)))
    (by linarith [K.gap_pos])
lemma eta_le_gap (k : ℕ) : K.eta k ≤ (K.c1 - K.c2) / 4 := min_le_right _ _
lemma eta_le_k (k : ℕ) : K.eta k ≤ 1 / (2 * (k : ℝ) ^ 2 * (k + 1)) := min_le_left _ _

lemma aexp_ge (k : ℕ) : K.c1 / 4 ≤ K.aexp k := by
  unfold aexp; have := K.eta_le_gap k; have := K.h32; have := K.h3; linarith
lemma aexp_le (k : ℕ) : K.aexp k ≤ K.c1 / 2 := by
  unfold aexp; have := K.eta_nonneg k; linarith
lemma aexp_pos (k : ℕ) : 0 < K.aexp k := lt_of_lt_of_le (by linarith [K.c1_pos]) (K.aexp_ge k)
lemma two_aexp_gap (k : ℕ) : K.ρ ≤ 2 * K.aexp k - K.c2 := by
  unfold aexp; have := K.eta_le_gap k; have := K.ρ_le_gap; linarith
lemma ρ_le_aexp (k : ℕ) : K.ρ ≤ K.aexp k := K.ρ_le_c1.trans (K.aexp_ge k)

lemma uu_ge_one (k : ℕ) {P : ℝ} (hP : 1 ≤ P) : 1 ≤ K.uu k P :=
  Real.one_le_rpow hP (K.aexp_pos k).le

lemma P2_ge_one (k : ℕ) {P : ℝ} (hP : 1 ≤ P) : 1 ≤ K.P2 k P :=
  Nat.le_floor (by exact_mod_cast K.uu_ge_one k hP)

lemma P2_le_uu (k : ℕ) {P : ℝ} (hP : 1 ≤ P) : (K.P2 k P : ℝ) ≤ K.uu k P :=
  Nat.floor_le (by linarith [K.uu_ge_one k hP])

lemma uu_le_two_P2 (k : ℕ) {P : ℝ} (hP : 1 ≤ P) : K.uu k P ≤ 2 * K.P2 k P := by
  have h1 := K.uu_ge_one k hP
  have h2 := Nat.lt_floor_add_one (K.uu k P)
  have h3 : (1 : ℝ) ≤ K.P2 k P := by exact_mod_cast K.P2_ge_one k hP
  unfold P2 at h3 ⊢
  linarith

lemma QQ_le (k : ℕ) {P : ℝ} (hP : 1 ≤ P) : (K.QQ k P : ℝ) ≤ 2 * K.uu k P := by
  unfold QQ; push_cast
  have := K.P2_le_uu k hP; have := K.uu_ge_one k hP; linarith

/-- the Vinogradov saving after `tau k` steps -/
lemma Del_le (k : ℕ) (hk : 1 ≤ k) : Del k (K.tau k) ≤ (k : ℝ) ^ 2 * (K.ρ * K.c0 ^ 2 / 8) := by
  unfold Del
  have hk' : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hb := base_mem k hk
  have hexp : (1 - 1 / (k : ℝ)) ^ (K.tau k) ≤ Real.exp (-K.L1) := by
    have h1 : 1 - 1 / (k : ℝ) ≤ Real.exp (-(1 / (k : ℝ))) := by
      have := Real.add_one_le_exp (-(1 / (k : ℝ))); linarith
    calc (1 - 1 / (k : ℝ)) ^ (K.tau k) ≤ (Real.exp (-(1 / (k : ℝ)))) ^ (K.tau k) :=
          pow_le_pow_left₀ hb.1 h1 _
      _ = Real.exp (-(K.tau k : ℝ) / k) := by
          rw [← Real.exp_nat_mul]; congr 1; field_simp
      _ ≤ Real.exp (-K.L1) := by
          apply Real.exp_le_exp.mpr
          rw [neg_div, neg_le_neg_iff, le_div_iff₀ (by linarith)]
          have := K.tau_ge' k; linarith
  rw [K.exp_neg_L1] at hexp
  calc kap k * (1 - 1 / (k : ℝ)) ^ (K.tau k) ≤ (k : ℝ) ^ 2 * (K.ρ * K.c0 ^ 2 / 8) :=
        mul_le_mul (kap_le_sq k hk) hexp (pow_nonneg hb.1 _) (by positivity)

lemma Dexp_le (k : ℕ) (hk : 1 ≤ k) : (Dexp k (K.tau k) : ℝ) ≤ 31 * ((k : ℝ) * K.tau k) ^ 2 := by
  unfold Dexp
  have ht : (k : ℝ) ≤ K.tau k := by exact_mod_cast K.tau_ge k
  have hk' : (1 : ℝ) ≤ k := by exact_mod_cast hk
  push_cast
  have hτ1 : (1 : ℝ) ≤ K.tau k := le_trans hk' ht
  have hk0 : (0 : ℝ) ≤ k := by positivity
  have hkk : (k : ℝ) ^ 2 ≤ (K.tau k : ℝ) ^ 2 := pow_le_pow_left₀ hk0 ht 2
  have h1 : (k : ℝ) ^ 4 ≤ (k : ℝ) ^ 2 * (K.tau k : ℝ) ^ 2 := by
    have := mul_le_mul_of_nonneg_left hkk (by positivity : (0 : ℝ) ≤ (k : ℝ) ^ 2)
    nlinarith
  have h2 : (k : ℝ) ^ 2 * K.tau k ≤ (k : ℝ) ^ 2 * (K.tau k : ℝ) ^ 2 := by
    apply mul_le_mul_of_nonneg_left _ (by positivity); nlinarith
  have h3 : (k : ℝ) * (K.tau k : ℝ) ^ 2 ≤ (k : ℝ) ^ 2 * (K.tau k : ℝ) ^ 2 := by
    apply mul_le_mul_of_nonneg_right _ (by positivity); nlinarith
  nlinarith [h1, h2, h3]

end KParams

end GoldB
