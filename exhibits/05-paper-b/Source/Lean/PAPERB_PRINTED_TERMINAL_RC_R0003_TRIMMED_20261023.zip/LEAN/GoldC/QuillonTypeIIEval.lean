import GoldC.QuillonTypeII
import GoldC.QuillonPartition

/-!
# Quillon CSC3 F7.4g: Type II with the near-geometric partition, closed form

With `t = tseq U T`, `J = Jstop`, `t_J = t J` and `g' = ∏_{p∈P, p∤c} p`:

    ‖TypeII‖ ≤ √(2(1+log t_J)⁴) · √(log²B · B · J · (2B/g' + 2t_J + sB/(Ug') + s))
             + log B · (1+log t_J)⁴ · (2B/T + 4B/U + 2t_J).

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset ArithmeticFunction

namespace GoldC.QuillonTypeIIEval

open GoldC.QuillonVW GoldC.QuillonTypeII GoldC.QuillonPartition GoldC.QuillonDivisorMoment

lemma telescope_R (f : ℕ → ℝ) (t : ℕ → ℕ) (htm : Monotone t) (J : ℕ) :
    ∑ j ∈ range J, ∑ d ∈ Ioc (t j) (t (j + 1)), f d = ∑ d ∈ Ioc (t 0) (t J), f d := by
  induction J with
  | zero => simp
  | succ J ih =>
    rw [sum_range_succ, ih, sum_Ioc_consecutive _ (htm (Nat.zero_le J)) (htm (Nat.le_succ J))]

lemma floor_diff_le (B t t' : ℕ) (ht : 1 ≤ t) (htt' : t ≤ t') :
    ((B / t - B / t' : ℕ) : ℝ) ≤ (B : ℝ) * ((t' : ℝ) - t) / ((t : ℝ) * t') + 1 := by
  have htR : (0 : ℝ) < t := by exact_mod_cast ht
  have ht'R : (0 : ℝ) < t' := by exact_mod_cast (ht.trans htt')
  have hle : B / t' ≤ B / t := Nat.div_le_div_left htt' ht
  rw [Nat.cast_sub hle]
  have h1 : ((B / t : ℕ) : ℝ) ≤ (B : ℝ) / t := Nat.cast_div_le
  have h2 : (B : ℝ) / t' < ((B / t' : ℕ) : ℝ) + 1 := by
    rw [div_lt_iff₀ ht'R]
    have hdm := Nat.div_add_mod B t'
    have hml := Nat.mod_lt B (show 0 < t' by omega)
    have : B < (B / t' + 1) * t' := by nlinarith
    exact_mod_cast this
  have e : (B : ℝ) * ((t' : ℝ) - t) / ((t : ℝ) * t') = (B : ℝ) / t - (B : ℝ) / t' := by
    field_simp
  rw [e]; linarith

lemma tau_ge_one (d : ℕ) (hd : 1 ≤ d) : (1 : ℝ) ≤ (d.divisors.card : ℝ) := by
  have : 1 ≤ d.divisors.card := Finset.card_pos.2 ⟨1, Nat.one_mem_divisors.2 (by omega)⟩
  exact_mod_cast this

lemma tau_div_sum (x : ℕ) :
    ∑ d ∈ Ioc 0 x, (d.divisors.card : ℝ) * (1 / (d : ℝ)) ≤ (1 + Real.log x) ^ 4 := by
  refine (sum_le_sum fun d hd => ?_).trans (tau_sq_moment x)
  have h1 := tau_ge_one d (mem_Ioc.1 hd).1
  have h0 : (0 : ℝ) ≤ 1 / (d : ℝ) := by positivity
  apply mul_le_mul_of_nonneg_right _ h0
  nlinarith

lemma tau_sum (x : ℕ) :
    ∑ d ∈ Ioc 0 x, (d.divisors.card : ℝ) ≤ x * (1 + Real.log x) ^ 4 := by
  calc _ ≤ ∑ d ∈ Ioc 0 x, (x : ℝ) * ((d.divisors.card : ℝ) * (1 / (d : ℝ))) := by
        refine sum_le_sum fun d hd => ?_
        have hd' := mem_Ioc.1 hd
        have hdR : (0 : ℝ) < d := by exact_mod_cast hd'.1
        have hxd : (d : ℝ) ≤ x := by exact_mod_cast hd'.2
        rw [← mul_assoc, mul_comm (x : ℝ), mul_assoc, mul_one_div]
        rw [le_mul_iff_one_le_right (by have := tau_ge_one d hd'.1; linarith)]
        rw [le_div_iff₀ hdR]; linarith
    _ = (x : ℝ) * ∑ d ∈ Ioc 0 x, (d.divisors.card : ℝ) * (1 / (d : ℝ)) := by rw [mul_sum]
    _ ≤ _ := mul_le_mul_of_nonneg_left (tau_div_sum x) (by positivity)

lemma delta_le (B U T t d : ℕ) (hU : 1 ≤ U) (hT : 1 ≤ T) (htU : U ≤ t)
    (hd : d ∈ Ioc t (t + t / T + 1)) :
    ((B / t - B / (t + t / T + 1) : ℕ) : ℝ) ≤
      (B : ℝ) / (T * d) + (B : ℝ) / (U * d) + 1 := by
  have hd' := mem_Ioc.1 hd
  have ht1 : 1 ≤ t := hU.trans htU
  have h := floor_diff_le B t (t + t / T + 1) ht1 (by omega)
  have htR : (0 : ℝ) < t := by exact_mod_cast ht1
  have hTR : (0 : ℝ) < T := by exact_mod_cast hT
  have hUR : (0 : ℝ) < U := by exact_mod_cast hU
  have hdR : (0 : ℝ) < d := by exact_mod_cast (show 0 < d by omega)
  have ht'R : (0 : ℝ) < ((t + t / T + 1 : ℕ) : ℝ) := by positivity
  have hdt' : (d : ℝ) ≤ ((t + t / T + 1 : ℕ) : ℝ) := by exact_mod_cast hd'.2
  have hUt : (U : ℝ) ≤ t := by exact_mod_cast htU
  have hB : (0 : ℝ) ≤ B := by positivity
  have hdiff : ((t + t / T + 1 : ℕ) : ℝ) - t ≤ (t : ℝ) / T + 1 := by
    push_cast
    have : ((t / T : ℕ) : ℝ) ≤ (t : ℝ) / T := Nat.cast_div_le
    linarith
  calc ((B / t - B / (t + t / T + 1) : ℕ) : ℝ)
      ≤ (B : ℝ) * (((t + t / T + 1 : ℕ) : ℝ) - t) / ((t : ℝ) * ((t + t / T + 1 : ℕ) : ℝ)) + 1 := h
    _ ≤ (B : ℝ) * ((t : ℝ) / T + 1) / ((t : ℝ) * ((t + t / T + 1 : ℕ) : ℝ)) + 1 := by
        gcongr
    _ = (B : ℝ) / (T * ((t + t / T + 1 : ℕ) : ℝ)) + (B : ℝ) / ((t : ℝ) * ((t + t / T + 1 : ℕ) : ℝ)) + 1 := by
        field_simp
    _ ≤ (B : ℝ) / (T * d) + (B : ℝ) / (U * d) + 1 := by
        gcongr

lemma main_term_le (A B U t t' tJ s g : ℕ) (hU : 1 ≤ U) (htU : U ≤ t) (ht' : t' ≤ 2 * t)
    (htJ : t ≤ tJ) (hs : 1 ≤ s) (hg : 1 ≤ g) :
    (t : ℝ) * ((((t' : ℕ) : ℝ) / s + 1) * s *
        (Real.log B ^ 2 * (((B / t - A / t : ℕ) : ℝ) * (((B / t - A / t : ℕ) : ℝ) / g + 1)))) ≤
      Real.log B ^ 2 * B * (2 * B / g + 2 * tJ + s * B / (U * g) + s) := by
  have ht1 : 1 ≤ t := hU.trans htU
  have htR : (0 : ℝ) < t := by exact_mod_cast ht1
  have hsR : (0 : ℝ) < s := by exact_mod_cast hs
  have hgR : (0 : ℝ) < g := by exact_mod_cast hg
  have hUR : (0 : ℝ) < U := by exact_mod_cast hU
  set L : ℝ := ((B / t - A / t : ℕ) : ℝ) with hL
  have hL0 : 0 ≤ L := by positivity
  have hLB : L ≤ (B : ℝ) / t := by
    have : ((B / t - A / t : ℕ) : ℝ) ≤ ((B / t : ℕ) : ℝ) := by exact_mod_cast Nat.sub_le _ _
    exact this.trans Nat.cast_div_le
  have htL : (t : ℝ) * L ≤ B := by
    have := mul_le_mul_of_nonneg_left hLB htR.le
    rwa [mul_div_cancel₀ _ htR.ne'] at this
  have hts : (((t' : ℕ) : ℝ) / s + 1) * s = t' + s := by field_simp
  have ht'R : ((t' : ℕ) : ℝ) ≤ 2 * t := by exact_mod_cast ht'
  have hlog : 0 ≤ Real.log B ^ 2 := sq_nonneg _
  have hB : (0 : ℝ) ≤ B := by positivity
  have hLg : L / g ≤ (B : ℝ) / (t * g) := by
    rw [div_le_div_iff₀ hgR (by positivity)]
    calc L * (t * g) = (t * L) * g := by ring
      _ ≤ B * g := mul_le_mul_of_nonneg_right htL hgR.le
  have htJR : (t : ℝ) ≤ tJ := by exact_mod_cast htJ
  have hUt : (U : ℝ) ≤ t := by exact_mod_cast htU
  calc (t : ℝ) * ((((t' : ℕ) : ℝ) / s + 1) * s * (Real.log B ^ 2 * (L * (L / g + 1))))
      = Real.log B ^ 2 * (((t' : ℕ) : ℝ) + s) * ((t * L) * (L / g + 1)) := by rw [hts]; ring
    _ ≤ Real.log B ^ 2 * (2 * t + s) * (B * ((B : ℝ) / (t * g) + 1)) := by
        gcongr
    _ = Real.log B ^ 2 * B * (2 * B / g + 2 * t + s * B / (t * g) + s) := by
        field_simp; ring
    _ ≤ Real.log B ^ 2 * B * (2 * B / g + 2 * tJ + s * B / (U * g) + s) := by
        gcongr

section eval
variable {s : ℕ} [NeZero s]

/-- **Type II, closed form** for the near-geometric partition. -/
theorem typeII_eval (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p)
    (c : ZMod s) (U V T A B : ℕ) (hAB : A ≤ B) (hU : 2 ≤ U) (hT : 2 ≤ T) :
    ‖∑ n ∈ Ioc A B, ((((GoldC.QuillonVaughan.upper U μR) *
        (GoldC.QuillonVaughan.upper V vonMangoldt) * ζR) n : ℝ) : ℂ) * kphase c n‖ ≤
      Real.sqrt (2 * (1 + Real.log (tseq U T (Jstop U T V B (by omega) (by omega)))) ^ 4) *
        Real.sqrt (Real.log B ^ 2 * B * (Jstop U T V B (by omega) (by omega) : ℝ) *
          (2 * B / ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ) +
            2 * (tseq U T (Jstop U T V B (by omega) (by omega)) : ℝ) +
            s * B / (U * ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ)) +
            s)) +
      Real.log B * (1 + Real.log (tseq U T (Jstop U T V B (by omega) (by omega)))) ^ 4 *
        (2 * B / T + 2 * B / U + 2 * (tseq U T (Jstop U T V B (by omega) (by omega)) : ℝ)) := by
  classical
  set J := Jstop U T V B (by omega) (by omega) with hJ
  set t := tseq U T with ht
  set tJ := t J with htJdef
  set g : ℕ := ∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p with hg
  have hg1 : 1 ≤ g := Nat.one_le_iff_ne_zero.2 (Finset.prod_ne_zero_iff.2 fun p hp =>
    (hP p (filter_subset _ _ hp)).ne_zero)
  have hs1 : 1 ≤ s := Nat.one_le_iff_ne_zero.2 (NeZero.ne s)
  have hspec : B < (V + 1) * t J := Jstop_spec V B (by omega) (by omega)
  have habs := typeII_abstract P hP hsP c U V A B hAB t J rfl (by omega) tseq_mono hspec
  refine habs.trans (add_le_add ?_ ?_)
  · -- main terms
    have htpos : ∀ j, (0 : ℝ) < t j := fun j => by
      have := tseq_ge (U := U) (T := T) j
      show (0 : ℝ) < (tseq U T j : ℝ)
      exact_mod_cast (show 0 < tseq U T j by omega)
    set X : ℕ → ℝ := fun j => ∑ d ∈ Ioc (t j) (t (j + 1)), ((d.divisors.card : ℝ)) ^ 2 with hX
    set Z : ℕ → ℝ := fun j => (((t (j + 1) : ℕ) : ℝ) / s + 1) * s *
      (Real.log B ^ 2 * (((B / t j - A / t j : ℕ) : ℝ) * (((B / t j - A / t j : ℕ) : ℝ) /
        (g : ℝ) + 1))) with hZ
    have hX0 : ∀ j, 0 ≤ X j := fun j => sum_nonneg fun _ _ => by positivity
    have hZ0 : ∀ j, 0 ≤ Z j := fun j => by simp only [hZ]; positivity
    have hsplit : ∀ j ∈ range J, Real.sqrt (X j * (((t (j + 1) : ℕ) : ℝ) / s + 1) * s *
        (Real.log B ^ 2 * (((B / t j - A / t j : ℕ) : ℝ) * (((B / t j - A / t j : ℕ) : ℝ) /
          (g : ℝ) + 1)))) = Real.sqrt (X j / t j) * Real.sqrt (t j * Z j) := by
      intro j _
      rw [← Real.sqrt_mul (div_nonneg (hX0 j) (htpos j).le)]
      congr 1
      simp only [hZ]
      have := (htpos j).ne'
      field_simp
    rw [sum_congr rfl hsplit]
    refine (Real.sum_sqrt_mul_sqrt_le _ (fun j => div_nonneg (hX0 j) (htpos j).le)
      (fun j => mul_nonneg (htpos j).le (hZ0 j))).trans ?_
    apply mul_le_mul _ _ (Real.sqrt_nonneg _) (Real.sqrt_nonneg _)
    · apply Real.sqrt_le_sqrt
      calc ∑ j ∈ range J, X j / t j
          ≤ ∑ j ∈ range J, ∑ d ∈ Ioc (t j) (t (j + 1)),
              2 * (((d.divisors.card : ℝ)) ^ 2 * (1 / (d : ℝ))) := by
            refine sum_le_sum fun j _ => ?_
            simp only [hX, sum_div]
            refine sum_le_sum fun d hd => ?_
            have hd' := mem_Ioc.1 hd
            have h2 := tseq_succ_le (U := U) hT hU j
            have hdR : (0 : ℝ) < d := by exact_mod_cast (show 0 < d by omega)
            have hd2 : (d : ℝ) ≤ 2 * t j := by exact_mod_cast hd'.2.trans h2
            rw [div_le_iff₀ (htpos j)]
            have : (0 : ℝ) ≤ ((d.divisors.card : ℝ)) ^ 2 := by positivity
            calc ((d.divisors.card : ℝ)) ^ 2 = ((d.divisors.card : ℝ)) ^ 2 * (d * (1 / d)) := by
                  field_simp
              _ ≤ ((d.divisors.card : ℝ)) ^ 2 * (2 * t j * (1 / d)) := by gcongr
              _ = _ := by ring
        _ = ∑ d ∈ Ioc (t 0) tJ, 2 * (((d.divisors.card : ℝ)) ^ 2 * (1 / (d : ℝ))) :=
            telescope_R _ t tseq_mono J
        _ ≤ ∑ d ∈ Ioc 0 tJ, 2 * (((d.divisors.card : ℝ)) ^ 2 * (1 / (d : ℝ))) :=
            sum_le_sum_of_subset_of_nonneg (Ioc_subset_Ioc_left (Nat.zero_le _))
              fun _ _ _ => by positivity
        _ = 2 * ∑ d ∈ Ioc 0 tJ, ((d.divisors.card : ℝ)) ^ 2 * (1 / (d : ℝ)) := by rw [mul_sum]
        _ ≤ 2 * (1 + Real.log tJ) ^ 4 := by
            gcongr; exact tau_sq_moment tJ
    · apply Real.sqrt_le_sqrt
      calc ∑ j ∈ range J, t j * Z j
          ≤ ∑ _j ∈ range J, Real.log B ^ 2 * B * (2 * B / g + 2 * tJ + s * B / (U * g) + s) := by
            refine sum_le_sum fun j hj => ?_
            have hjJ : j ≤ J := (mem_range.1 hj).le
            exact main_term_le A B U (t j) (t (j + 1)) tJ s g (by omega) (tseq_ge j)
              (tseq_succ_le hT hU j) (tseq_mono hjJ) hs1 hg1
        _ = _ := by rw [sum_const, card_range, nsmul_eq_mul]; ring
  · -- boundary terms
    have hlogB : 0 ≤ Real.log B := Real.log_natCast_nonneg B
    calc _ ≤ ∑ j ∈ range J, ∑ d ∈ Ioc (t j) (t (j + 1)), (d.divisors.card : ℝ) *
          (Real.log B * (2 * B / T * (1 / (d : ℝ)) + 2 * B / U * (1 / (d : ℝ)) + 2)) := by
          refine sum_le_sum fun j _ => sum_le_sum fun d hd => ?_
          apply mul_le_mul_of_nonneg_left _ (by positivity)
          apply mul_le_mul_of_nonneg_left _ hlogB
          have hd' : d ∈ Ioc (t j) (t j + t j / T + 1) := by rw [← tseq_succ]; exact hd
          have h1 := delta_le A U T (t j) d (by omega) (by omega) (tseq_ge j) hd'
          have h2 := delta_le B U T (t j) d (by omega) (by omega) (tseq_ge j) hd'
          rw [← tseq_succ] at h1 h2
          have hAB' : (A : ℝ) ≤ B := by exact_mod_cast hAB
          have hdR : (0 : ℝ) < d := by
            have := (mem_Ioc.1 hd).1; exact_mod_cast (show 0 < d by omega)
          have hTR : (0 : ℝ) < T := by exact_mod_cast (show 0 < T by omega)
          have hUR : (0 : ℝ) < U := by exact_mod_cast (show 0 < U by omega)
          have e1 : (A : ℝ) / (T * d) ≤ (B : ℝ) / (T * d) := by gcongr
          have e2 : (A : ℝ) / (U * d) ≤ (B : ℝ) / (U * d) := by gcongr
          have e3 : 2 * (B : ℝ) / T * (1 / d) + 2 * B / U * (1 / d) + 2 =
              2 * ((B : ℝ) / (T * d) + (B : ℝ) / (U * d) + 1) := by field_simp
          rw [e3]; linarith
      _ = ∑ d ∈ Ioc (t 0) tJ, (d.divisors.card : ℝ) *
          (Real.log B * (2 * B / T * (1 / (d : ℝ)) + 2 * B / U * (1 / (d : ℝ)) + 2)) :=
          telescope_R _ t tseq_mono J
      _ ≤ ∑ d ∈ Ioc 0 tJ, (d.divisors.card : ℝ) *
          (Real.log B * (2 * B / T * (1 / (d : ℝ)) + 2 * B / U * (1 / (d : ℝ)) + 2)) :=
          sum_le_sum_of_subset_of_nonneg (Ioc_subset_Ioc_left (Nat.zero_le _))
            fun _ _ _ => by positivity
      _ = Real.log B * ((2 * B / T + 2 * B / U) *
            ∑ d ∈ Ioc 0 tJ, (d.divisors.card : ℝ) * (1 / (d : ℝ)) +
          2 * ∑ d ∈ Ioc 0 tJ, (d.divisors.card : ℝ)) := by
          rw [mul_sum, mul_sum, ← sum_add_distrib, mul_sum]
          refine sum_congr rfl fun d _ => by ring
      _ ≤ Real.log B * ((2 * B / T + 2 * B / U) * (1 + Real.log tJ) ^ 4 +
          2 * (tJ * (1 + Real.log tJ) ^ 4)) := by
          gcongr
          · exact tau_div_sum tJ
          · exact tau_sum tJ
      _ = _ := by ring

end eval

end GoldC.QuillonTypeIIEval

#print axioms GoldC.QuillonTypeIIEval.floor_diff_le
#print axioms GoldC.QuillonTypeIIEval.tau_sum
#print axioms GoldC.QuillonTypeIIEval.delta_le
#print axioms GoldC.QuillonTypeIIEval.main_term_le
#print axioms GoldC.QuillonTypeIIEval.typeII_eval
