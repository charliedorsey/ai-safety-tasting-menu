import OrielUpper.Mirror
import OrielUpper.ShellD

/-!
# Oriel Upper — reduction toolkit: prime-set weights and the periodic row weight
-/

open Finset

namespace OrielUpper

lemma gW_prod_primes (F : ℕ) {s : Finset ℕ} (hs : ∀ p ∈ s, p.Prime) :
    gW F (∏ p ∈ s, p) = ∏ p ∈ s, gW F p := by
  induction s using Finset.induction_on with
  | empty => simp [gW_one]
  | insert a s ha ih =>
    rw [prod_insert ha, prod_insert ha]
    have hcop : Nat.Coprime a (∏ p ∈ s, p) := by
      apply Nat.Coprime.prod_right
      intro p hp
      exact (Nat.coprime_primes (hs a (mem_insert_self a s)) (hs p (mem_insert_of_mem hp))).mpr
        (fun h => ha (h ▸ hp))
    rw [show gW F (a * ∏ p ∈ s, p) = gW F a * gW F (∏ p ∈ s, p) from
      (GW_isMultiplicative F).map_mul_of_coprime hcop, ih (fun p hp => hs p (mem_insert_of_mem hp))]

lemma bW_prod_primes (F : ℕ) {s : Finset ℕ} (hs : ∀ p ∈ s, p.Prime ∧ allowedP F p) :
    bW F (∏ p ∈ s, p) = ∏ p ∈ s, 1 / ((p : ℝ) - 3) := by
  unfold bW
  rw [gW_prod_primes F (fun p hp => (hs p hp).1), Nat.cast_prod, ← prod_div_distrib]
  apply prod_congr rfl
  intro p hp
  rw [gW_prime F (hs p hp).1, if_pos (hs p hp).2]
  have h5 : (5 : ℝ) ≤ p := by exact_mod_cast (hs p hp).2.1
  field_simp

/-! ### The periodic model of the source row weight -/

section Lambda
open OrielUpper.Mirror

lemma dvd_sub_iff_of_mod {p P H y : ℕ} (hpP : p ∣ P) (hP : 0 < P) (hy : y < H) :
    p ∣ H - y ↔ p ∣ (H + P) - y % P := by
  have h1 := Nat.div_add_mod y P
  have h2 := Nat.mod_lt y hP
  have key : (H + P) - y % P = (H - y) + P * (y / P + 1) := by
    rw [Nat.mul_succ]
    generalize P * (y / P) = K at h1 ⊢
    omega
  rw [key]
  exact (Nat.dvd_add_left (Dvd.dvd.mul_right hpP _)).symm

lemma highPrimeLocalRatio_periodic {p P H y : ℕ} (hpP : p ∣ P) (hP : 0 < P) (hy : y < H) :
    highPrimeLocalRatio p H y = highPrimeLocalRatio p (H + P) (y % P) := by
  have e1 : p ∣ H ↔ p ∣ H + P := (Nat.dvd_add_left hpP).symm
  have e2 : p ∣ y ↔ p ∣ y % P := by
    rw [Nat.dvd_mod_iff hpP]
  have e3 := dvd_sub_iff_of_mod hpP hP hy
  unfold highPrimeLocalRatio
  simp only [e1, e2, e3]

lemma coprime_add_mod {q a y P : ℕ} (hqP : q ∣ P) :
    q.Coprime (a + y) ↔ q.Coprime (a + y % P) := by
  have : (a + y) % q = (a + y % P) % q := by
    rw [Nat.add_mod, Nat.add_mod a (y % P), Nat.mod_mod_of_dvd y hqP]
  show Nat.gcd q (a + y) = 1 ↔ Nat.gcd q (a + y % P) = 1
  rw [Nat.gcd_rec q (a + y), Nat.gcd_rec q (a + y % P), this]

/-- The source row weight is `6q`-periodic on `(0, H)`. -/
lemma fixedQLowWeight_periodic {q A H y : ℕ} (hq : 0 < q) (hy : y < H) :
    fixedQLowWeight q A H y = fixedQLowWeight q A (H + 6 * q) (y % (6 * q)) := by
  have hP : 0 < 6 * q := by omega
  unfold fixedQLowWeight
  have hc := coprime_add_mod (q := q) (a := A) (y := y) (P := 6 * q) (Dvd.intro_left 6 rfl)
  congr 1
  · by_cases h : q.Coprime (A + y)
    · rw [if_pos h, if_pos (hc.mp h)]
    · rw [if_neg h, if_neg (fun h' => h (hc.mpr h'))]
  apply prod_congr rfl
  intro p hp
  have hp6 : p ∣ 6 * q := by
    simp only [lowPrimeSet, mem_insert, mem_singleton] at hp
    rcases hp with rfl | rfl
    · exact Dvd.dvd.mul_right (by norm_num) q
    · exact Dvd.dvd.mul_right (by norm_num) q
  unfold lowPrimeLocalRatio
  rw [highPrimeLocalRatio_periodic hp6 hP hy]

lemma abs_highPrimeLocalRatio_two (h y : ℕ) : |((highPrimeLocalRatio 2 h y : ℚ) : ℝ)| ≤ 2 := by
  unfold highPrimeLocalRatio c0 c1
  split_ifs <;> norm_num

lemma abs_highPrimeLocalRatio_three (h y : ℕ) :
    |((highPrimeLocalRatio 3 h y : ℚ) : ℝ)| ≤ 3 / 2 := by
  unfold highPrimeLocalRatio c0 c1
  split_ifs <;> norm_num

lemma abs_fixedQLowWeight_le (q a h y : ℕ) : |fixedQLowWeight q a h y| ≤ 3 := by
  unfold fixedQLowWeight lowPrimeSet
  rw [prod_insert (by norm_num), prod_singleton]
  have h2 : |(if 2 ∣ q then (1 : ℝ) else lowPrimeLocalRatio 2 h y)| ≤ 2 := by
    split_ifs
    · norm_num
    · exact abs_highPrimeLocalRatio_two h y
  have h3 : |(if 3 ∣ q then (1 : ℝ) else lowPrimeLocalRatio 3 h y)| ≤ 3 / 2 := by
    split_ifs
    · norm_num
    · exact abs_highPrimeLocalRatio_three h y
  have hc : |(if q.Coprime (a + y) then (1 : ℝ) else 0)| ≤ 1 := by
    split_ifs <;> norm_num
  rw [abs_mul, abs_mul]
  calc |(if q.Coprime (a + y) then (1 : ℝ) else 0)| *
        (|(if 2 ∣ q then (1 : ℝ) else lowPrimeLocalRatio 2 h y)| *
          |(if 3 ∣ q then (1 : ℝ) else lowPrimeLocalRatio 3 h y)|)
      ≤ 1 * (2 * (3 / 2)) := by
        apply mul_le_mul hc (mul_le_mul h2 h3 (abs_nonneg _) (by norm_num))
          (by positivity) (by norm_num)
    _ = 3 := by norm_num

/-- The model on `ZMod (6q)`. -/
noncomputable def lamZ (q A H : ℕ) (z : ZMod (6 * q)) : ℝ :=
  fixedQLowWeight q A (H + 6 * q) z.val

theorem rowHyp_source {q A H F : ℕ} (hq : 0 < q) (hqF : q ∣ F) (hHF : H ∣ F) :
    haveI : NeZero (6 * q) := ⟨by omega⟩
    RowHyp (6 * q) F H (fixedQLowWeight q A H) (lamZ q A H) 3 := by
  haveI : NeZero (6 * q) := ⟨by omega⟩
  refine ⟨?_, ?_, ?_, hHF⟩
  · intro y _ hy
    unfold lamZ
    rw [ZMod.val_natCast, fixedQLowWeight_periodic hq hy]
  · intro z; exact abs_fixedQLowWeight_le _ _ _ _
  · intro p hp hpP
    rcases (Nat.Prime.dvd_mul hp).mp hpP with h6 | hq'
    · left
      have : p ≤ 6 := Nat.le_of_dvd (by norm_num) h6
      interval_cases p <;> simp_all (config := {decide := true})
    · right; exact hq'.trans hqF

end Lambda

end OrielUpper
