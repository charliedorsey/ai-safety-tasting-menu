import PaperB.Analytic.SawtoothReconstruction

open scoped BigOperators

namespace PaperB.Analytic

open Real Finset

noncomputable def sawSmoothMode
    (T : ℝ) (n : ℤ) (x : AddCircle (1 : ℝ)) : ℂ :=
  sawSmoothCoeff T n • fourier n x

noncomputable def sawSmoothPair
    (T : ℝ) (k : ℕ) (x : AddCircle (1 : ℝ)) : ℂ :=
  sawSmoothMode T (k + 1 : ℕ) x +
    sawSmoothMode T (-((k + 1 : ℕ) : ℤ)) x

noncomputable def sawSmoothPartial
    (T : ℝ) (H : ℕ) (x : AddCircle (1 : ℝ)) : ℂ :=
  sawSmoothMode T 0 x +
    ∑ k ∈ Finset.range H, sawSmoothPair T k x

lemma norm_fourier_point (n : ℤ) (x : AddCircle (1 : ℝ)) :
    ‖fourier n x‖ = 1 := by
  rw [fourier_apply, Circle.norm_coe]

lemma summable_sawSmoothMode
    {T : ℝ} (hT : 1 < T) (x : AddCircle (1 : ℝ)) :
    Summable (fun n : ℤ => sawSmoothMode T n x) := by
  apply Summable.of_norm
  simpa [sawSmoothMode, norm_smul, norm_fourier_point] using
    summable_norm_sawSmoothCoeff hT

lemma summable_sawSmoothPair
    {T : ℝ} (hT : 1 < T) (x : AddCircle (1 : ℝ)) :
    Summable (fun k : ℕ => sawSmoothPair T k x) := by
  have hm := summable_sawSmoothMode hT x
  have hp : Summable (fun k : ℕ => sawSmoothMode T (k + 1 : ℕ) x) := by
    have hi : Function.Injective (fun k : ℕ => ((k + 1 : ℕ) : ℤ)) := by
      intro a b hab
      have hnat : a + 1 = b + 1 := Int.ofNat_injective hab
      exact Nat.add_right_cancel hnat
    simpa [Function.comp_def] using hm.comp_injective hi
  have hn : Summable (fun k : ℕ =>
      sawSmoothMode T (-((k + 1 : ℕ) : ℤ)) x) := by
    have hi : Function.Injective (fun k : ℕ => -((k + 1 : ℕ) : ℤ)) := by
      intro a b hab
      have hab' : ((a + 1 : ℕ) : ℤ) = ((b + 1 : ℕ) : ℤ) := by
        exact neg_injective hab
      have hnat : a + 1 = b + 1 := Int.ofNat_injective hab'
      exact Nat.add_right_cancel hnat
    simpa [Function.comp_def] using hm.comp_injective hi
  simpa [sawSmoothPair] using hp.add hn

lemma tsum_sawSmoothMode_eq_zero_add_tsum_pair
    {T : ℝ} (hT : 1 < T) (x : AddCircle (1 : ℝ)) :
    (∑' n : ℤ, sawSmoothMode T n x) =
      sawSmoothMode T 0 x + ∑' k : ℕ, sawSmoothPair T k x := by
  have hm := summable_sawSmoothMode hT x
  have hp : Summable (fun k : ℕ => sawSmoothMode T (k + 1 : ℕ) x) := by
    have hi : Function.Injective (fun k : ℕ => ((k + 1 : ℕ) : ℤ)) := by
      intro a b hab
      have hnat : a + 1 = b + 1 := Int.ofNat_injective hab
      exact Nat.add_right_cancel hnat
    simpa [Function.comp_def] using hm.comp_injective hi
  have hn : Summable (fun k : ℕ =>
      sawSmoothMode T (-((k + 1 : ℕ) : ℤ)) x) := by
    have hi : Function.Injective (fun k : ℕ => -((k + 1 : ℕ) : ℤ)) := by
      intro a b hab
      have hab' : ((a + 1 : ℕ) : ℤ) = ((b + 1 : ℕ) : ℤ) := neg_injective hab
      have hnat : a + 1 = b + 1 := Int.ofNat_injective hab'
      exact Nat.add_right_cancel hnat
    simpa [Function.comp_def] using hm.comp_injective hi
  rw [tsum_int_eq_zero_add_tsum_pnat hm]
  have hpos :
      (∑' n : ℕ+, sawSmoothMode T (n : ℤ) x) =
        ∑' k : ℕ, sawSmoothMode T (k + 1 : ℕ) x := by
    simpa using
      (tsum_pnat_eq_tsum_succ
        (f := fun m : ℕ => sawSmoothMode T (m : ℤ) x))
  have hneg :
      (∑' n : ℕ+, sawSmoothMode T (-(n : ℤ)) x) =
        ∑' k : ℕ, sawSmoothMode T (-((k + 1 : ℕ) : ℤ)) x := by
    simpa using
      (tsum_pnat_eq_tsum_succ
        (f := fun m : ℕ => sawSmoothMode T (-(m : ℤ)) x))
  rw [hpos, hneg, add_assoc]
  congr 1
  rw [← hp.tsum_add hn]
  apply tsum_congr
  intro k
  rfl

lemma norm_sawSmoothMode
    (T : ℝ) (n : ℤ) (x : AddCircle (1 : ℝ)) :
    ‖sawSmoothMode T n x‖ = ‖sawSmoothCoeff T n‖ := by
  rw [sawSmoothMode, norm_smul, norm_fourier_point, mul_one]

theorem tsum_norm_sawSmoothPair_tail_le
    {T : ℝ} (hT : 1 < T) {H : ℕ} (hH : 1 ≤ H)
    (x : AddCircle (1 : ℝ)) :
    (∑' k : ℕ, ‖sawSmoothPair T (k + H) x‖)
      ≤ T / (Real.pi ^ 2 * H) := by
  apply tsum_le_of_sum_le' (by positivity)
  intro s
  obtain ⟨L, hsL⟩ := Finset.exists_nat_subset_range s
  calc
    (∑ k ∈ s, ‖sawSmoothPair T (k + H) x‖)
      ≤ ∑ k ∈ Finset.range L, ‖sawSmoothPair T (k + H) x‖ := by
        exact Finset.sum_le_sum_of_subset_of_nonneg hsL
          (fun i hi hnot => norm_nonneg _)
    _ ≤ ∑ k ∈ Finset.range L,
        (‖sawSmoothCoeff T (H + k + 1 : ℕ)‖ +
         ‖sawSmoothCoeff T (-((H + k + 1 : ℕ) : ℤ))‖) := by
      apply Finset.sum_le_sum
      intro k hk
      rw [sawSmoothPair]
      calc
        ‖sawSmoothMode T (k + H + 1 : ℕ) x +
            sawSmoothMode T (-((k + H + 1 : ℕ) : ℤ)) x‖
          ≤ ‖sawSmoothMode T (k + H + 1 : ℕ) x‖ +
            ‖sawSmoothMode T (-((k + H + 1 : ℕ) : ℤ)) x‖ :=
              norm_add_le _ _
        _ = ‖sawSmoothCoeff T (H + k + 1 : ℕ)‖ +
            ‖sawSmoothCoeff T (-((H + k + 1 : ℕ) : ℤ))‖ := by
              rw [norm_sawSmoothMode, norm_sawSmoothMode]
              simp [Nat.add_comm, Nat.add_left_comm, Nat.add_assoc]
    _ ≤ T / (Real.pi ^ 2 * H) :=
      sawSmoothCoeff_two_sided_band_tail hT hH

theorem sawSmoothPartial_error_le
    {T : ℝ} (hT : 1 < T) {H : ℕ} (hH : 1 ≤ H)
    (x : AddCircle (1 : ℝ)) :
    ‖smoothedSawCircle T hT x - sawSmoothPartial T H x‖
      ≤ T / (Real.pi ^ 2 * H) := by
  have hm := summable_sawSmoothMode hT x
  have hp := summable_sawSmoothPair hT x
  have hfull :
      smoothedSawCircle T hT x =
        sawSmoothMode T 0 x + ∑' k : ℕ, sawSmoothPair T k x := by
    rw [← tsum_sawSmoothMode_eq_zero_add_tsum_pair hT x]
    exact (hasSum_sawSmooth_fourier_series hT x).tsum_eq.symm
  have hsplit := hp.sum_add_tsum_nat_add H
  rw [hfull, sawSmoothPartial]
  have hdiff :
      sawSmoothMode T 0 x + (∑' k : ℕ, sawSmoothPair T k x) -
          (sawSmoothMode T 0 x +
            ∑ k ∈ Finset.range H, sawSmoothPair T k x)
        = ∑' k : ℕ, sawSmoothPair T (k + H) x := by
    rw [← hsplit]
    abel
  rw [hdiff]
  apply le_trans (norm_tsum_le_tsum_norm ?_)
    (tsum_norm_sawSmoothPair_tail_le hT hH x)
  have htail :
      Summable (fun k : ℕ => sawSmoothPair T (k + H) x) := by
    simpa [Nat.add_comm] using (summable_nat_add_iff H).2 hp
  exact htail.norm

#print axioms tsum_sawSmoothMode_eq_zero_add_tsum_pair
#print axioms tsum_norm_sawSmoothPair_tail_le
#print axioms sawSmoothPartial_error_le

end PaperB.Analytic
