import PaperB.FixedQ.SignedForbiddenAggregateRateTerminal
import PaperB.FixedQ.SignedForbiddenCenteredConductorRate
import PaperB.FixedQ.SignedForbiddenVaalerErrorSourceRate
import PaperB.FixedQ.SignedForbiddenOuterMeanWeightBridge

namespace PaperB.FixedQ

/-- Conditional analytic join immediately upstream of
`paperBTerminal_of_signedForbiddenAggregateRate`.

The exact source decomposition is deliberately a socket: Caelis supplies the
source-main transport and Ilyra supplies the signed-mean/principal term.  The
four rate hypotheses are all in the canonical strict exponent already used by
the centered and Vaaler-error courts. -/
theorem signedForbiddenAggregateRate_of_component_rates
    {q : ℕ} (hq : 0 < q) (hsq : Squarefree q)
    (centered meanError vaalerError farTail : ℕ → ℕ → ℝ)
    (hDecomp :
      ∀ a b h : ℕ,
        q.Coprime a →
        q.Coprime b →
        Nat.ModEq q (a + h) b →
        (¬ 2 ∣ q → 2 ∣ h) →
        0 < h →
        cStarReal q h * signedForbiddenCompletedMainAggregate q a h -
            signedMainB1Principal q (h / 2) =
          centered a h + meanError a h + vaalerError a h + farTail a h)
    (hCentered :
      ∃ C : ℝ, ∃ H0 : ℕ,
        0 ≤ C ∧
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          H0 ≤ h →
          |centered a h| ≤
            C * (Real.log (h : ℝ)) ^
                (h2BooleanSigma * h2BooleanX0) *
              (Real.log (Real.log (h : ℝ))) ^ 2)
    (hMean :
      ∃ C : ℝ, ∃ H0 : ℕ,
        0 ≤ C ∧
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          H0 ≤ h →
          |meanError a h| ≤
            C * (Real.log (h : ℝ)) ^
                (h2BooleanSigma * h2BooleanX0) *
              (Real.log (Real.log (h : ℝ))) ^ 2)
    (hVaaler :
      ∃ C : ℝ, ∃ H0 : ℕ,
        0 ≤ C ∧
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          H0 ≤ h →
          |vaalerError a h| ≤
            C * (Real.log (h : ℝ)) ^
                (h2BooleanSigma * h2BooleanX0) *
              (Real.log (Real.log (h : ℝ))) ^ 2)
    (hFar :
      ∃ C : ℝ, ∃ H0 : ℕ,
        0 ≤ C ∧
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          H0 ≤ h →
          |farTail a h| ≤
            C * (Real.log (h : ℝ)) ^
                (h2BooleanSigma * h2BooleanX0) *
              (Real.log (Real.log (h : ℝ))) ^ 2) :
    ∃ C rho : ℝ, ∃ k H0 : ℕ,
      0 ≤ C ∧ rho < 1 ∧
      ∀ a b h : ℕ,
        q.Coprime a →
        q.Coprime b →
        Nat.ModEq q (a + h) b →
        (¬ 2 ∣ q → 2 ∣ h) →
        0 < h →
        H0 ≤ h →
        |cStarReal q h * signedForbiddenCompletedMainAggregate q a h -
            signedMainB1Principal q (h / 2)| ≤
          C * (Real.log (h : ℝ)) ^ rho *
            (Real.log (Real.log (h : ℝ))) ^ k := by
  rcases hCentered with ⟨Cc, Hc, hCc, hCentered⟩
  rcases hMean with ⟨Cm, Hm, hCm, hMean⟩
  rcases hVaaler with ⟨Ce, He, hCe, hVaaler⟩
  rcases hFar with ⟨Ct, Ht, hCt, hFar⟩
  let H0 := max Hc (max Hm (max He Ht))
  refine ⟨Cc + Cm + Ce + Ct,
    h2BooleanSigma * h2BooleanX0, 2, H0, ?_, ?_, ?_⟩
  · linarith
  · exact h2BooleanSigma_mul_X0_lt_one
  · intro a b h ha hb hcompat h2 hh hH0
    have hHc : Hc ≤ h :=
      (le_max_left Hc (max Hm (max He Ht))).trans hH0
    have hHm : Hm ≤ h :=
      (le_max_left Hm (max He Ht)).trans
        ((le_max_right Hc (max Hm (max He Ht))).trans hH0)
    have hHe : He ≤ h :=
      (le_max_left He Ht).trans
        ((le_max_right Hm (max He Ht)).trans
          ((le_max_right Hc (max Hm (max He Ht))).trans hH0))
    have hHt : Ht ≤ h :=
      (le_max_right He Ht).trans
        ((le_max_right Hm (max He Ht)).trans
          ((le_max_right Hc (max Hm (max He Ht))).trans hH0))
    have hc := hCentered a b h ha hb hcompat h2 hh hHc
    have hm := hMean a b h ha hb hcompat h2 hh hHm
    have he := hVaaler a b h ha hb hcompat h2 hh hHe
    have ht := hFar a b h ha hb hcompat h2 hh hHt
    have htri :
        |centered a h + meanError a h + vaalerError a h + farTail a h| ≤
          |centered a h| + |meanError a h| +
            |vaalerError a h| + |farTail a h| := by
      have h1 := abs_add_le (centered a h) (meanError a h)
      have h2' := abs_add_le
        (centered a h + meanError a h) (vaalerError a h)
      have h3 := abs_add_le
        (centered a h + meanError a h + vaalerError a h) (farTail a h)
      linarith
    rw [hDecomp a b h ha hb hcompat h2 hh]
    calc
      |centered a h + meanError a h + vaalerError a h + farTail a h|
        ≤ |centered a h| + |meanError a h| +
            |vaalerError a h| + |farTail a h| := htri
      _ ≤
          Cc * (Real.log (h : ℝ)) ^
              (h2BooleanSigma * h2BooleanX0) *
              (Real.log (Real.log (h : ℝ))) ^ 2 +
          Cm * (Real.log (h : ℝ)) ^
              (h2BooleanSigma * h2BooleanX0) *
              (Real.log (Real.log (h : ℝ))) ^ 2 +
          Ce * (Real.log (h : ℝ)) ^
              (h2BooleanSigma * h2BooleanX0) *
              (Real.log (Real.log (h : ℝ))) ^ 2 +
          Ct * (Real.log (h : ℝ)) ^
              (h2BooleanSigma * h2BooleanX0) *
              (Real.log (Real.log (h : ℝ))) ^ 2 := by
            exact add_le_add (add_le_add (add_le_add hc hm) he) ht
      _ = (Cc + Cm + Ce + Ct) *
          (Real.log (h : ℝ)) ^
              (h2BooleanSigma * h2BooleanX0) *
          (Real.log (Real.log (h : ℝ))) ^ 2 := by
            ring

#print axioms signedForbiddenAggregateRate_of_component_rates

/-- Direct conditional terminal test for the join theorem. -/
theorem paperBTerminal_of_signedForbidden_component_rates
    (centered meanError vaalerError farTail :
      ℕ → ℕ → ℕ → ℝ)
    (hDecomp :
      ∀ q : ℕ, 0 < q → Squarefree q →
      ∀ a b h : ℕ,
        q.Coprime a →
        q.Coprime b →
        Nat.ModEq q (a + h) b →
        (¬ 2 ∣ q → 2 ∣ h) →
        0 < h →
        cStarReal q h * signedForbiddenCompletedMainAggregate q a h -
            signedMainB1Principal q (h / 2) =
          centered q a h + meanError q a h +
            vaalerError q a h + farTail q a h)
    (hCentered :
      ∀ q : ℕ, 0 < q → Squarefree q →
      ∃ C : ℝ, ∃ H0 : ℕ,
        0 ≤ C ∧
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          H0 ≤ h →
          |centered q a h| ≤
            C * (Real.log (h : ℝ)) ^
                (h2BooleanSigma * h2BooleanX0) *
              (Real.log (Real.log (h : ℝ))) ^ 2)
    (hMean :
      ∀ q : ℕ, 0 < q → Squarefree q →
      ∃ C : ℝ, ∃ H0 : ℕ,
        0 ≤ C ∧
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          H0 ≤ h →
          |meanError q a h| ≤
            C * (Real.log (h : ℝ)) ^
                (h2BooleanSigma * h2BooleanX0) *
              (Real.log (Real.log (h : ℝ))) ^ 2)
    (hVaaler :
      ∀ q : ℕ, 0 < q → Squarefree q →
      ∃ C : ℝ, ∃ H0 : ℕ,
        0 ≤ C ∧
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          H0 ≤ h →
          |vaalerError q a h| ≤
            C * (Real.log (h : ℝ)) ^
                (h2BooleanSigma * h2BooleanX0) *
              (Real.log (Real.log (h : ℝ))) ^ 2)
    (hFar :
      ∀ q : ℕ, 0 < q → Squarefree q →
      ∃ C : ℝ, ∃ H0 : ℕ,
        0 ≤ C ∧
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          H0 ≤ h →
          |farTail q a h| ≤
            C * (Real.log (h : ℝ)) ^
                (h2BooleanSigma * h2BooleanX0) *
              (Real.log (Real.log (h : ℝ))) ^ 2) :
    PaperB.Closure.PaperBTerminalStatement := by
  apply paperBTerminal_of_signedForbiddenAggregateRate
  intro q hq hsq
  exact signedForbiddenAggregateRate_of_component_rates
    hq hsq
    (centered q) (meanError q) (vaalerError q) (farTail q)
    (hDecomp q hq hsq)
    (hCentered q hq hsq)
    (hMean q hq hsq)
    (hVaaler q hq hsq)
    (hFar q hq hsq)

#print axioms paperBTerminal_of_signedForbidden_component_rates

end PaperB.FixedQ
