import PaperB.FixedQ.EtaLinearMean
import PaperB.FixedQ.OmegaCorrectionRankin

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def omegaLinearPartialSum (q X : ℕ) : ℝ :=
  ∑ n ∈ Finset.Icc 1 X, omegaLinearArithmetic q n

theorem omegaLinearPartialSum_eq_correction_coprime
    (q X : ℕ) :
    omegaLinearPartialSum q X =
      ∑ d ∈ Finset.Icc 1 X,
        omegaLinearCorrectionArithmetic q d *
          (coprimePrefixCount (6 * q) (X / d) : ℝ) := by
  classical
  unfold omegaLinearPartialSum
  calc
    (∑ n ∈ Finset.Icc 1 X, omegaLinearArithmetic q n)
      = ∑ n ∈ Finset.Icc 1 X,
          (coprimeIndicatorArithmetic q *
            omegaLinearCorrectionArithmetic q) n := by
          apply Finset.sum_congr rfl
          intro n hn
          have hfun := omegaLinearArithmetic_eq_correction_mul_coprime q
          have hnval := congrArg (fun f : ArithmeticFunction ℝ => f n) hfun
          simpa [mul_comm] using hnval
    _ = ∑ n ∈ Finset.Icc 1 X,
          ∑ ds ∈ n.divisorsAntidiagonal,
            omegaLinearCorrectionArithmetic q ds.2 *
              coprimeIndicatorArithmetic q ds.1 := by
          apply Finset.sum_congr rfl
          intro n hn
          rw [ArithmeticFunction.mul_apply]
          apply Finset.sum_congr rfl
          intro ds hds
          ring
    _ = ∑ x ∈ petermannDivisorSigma X,
          omegaLinearCorrectionArithmetic q x.2.2 *
            coprimeIndicatorArithmetic q x.2.1 := by
          rw [petermannDivisorSigma, Finset.sum_sigma']
    _ = ∑ d ∈ Finset.Icc 1 X,
          ∑ m ∈ Finset.Icc 1 (X / d),
            omegaLinearCorrectionArithmetic q d *
              coprimeIndicatorArithmetic q m := by
          exact sum_petermannDivisorSigma_eq_nested X
            (fun d m =>
              omegaLinearCorrectionArithmetic q d *
                coprimeIndicatorArithmetic q m)
    _ = ∑ d ∈ Finset.Icc 1 X,
        omegaLinearCorrectionArithmetic q d *
          (coprimePrefixCount (6 * q) (X / d) : ℝ) := by
          apply Finset.sum_congr rfl
          intro d hd
          have hind :
              (∑ m ∈ Finset.Icc 1 (X / d),
                coprimeIndicatorArithmetic q m) =
                (coprimePrefixCount (6 * q) (X / d) : ℝ) := by
            unfold coprimePrefixCount
            have hterm :
                ∀ m ∈ Finset.Icc 1 (X / d),
                  coprimeIndicatorArithmetic q m =
                    (if (6 * q).Coprime m then (1 : ℝ) else 0) := by
              intro m hm
              rw [coprimeIndicatorArithmetic_apply]
              have hm0 : m ≠ 0 := by
                rw [Finset.mem_Icc] at hm
                omega
              rw [coprimeIndicatorCoeff, if_neg hm0]
              simpa [Nat.coprime_comm]
            calc
              (∑ m ∈ Finset.Icc 1 (X / d),
                coprimeIndicatorArithmetic q m)
                  = ∑ m ∈ Finset.Icc 1 (X / d),
                      (if (6 * q).Coprime m then (1 : ℝ) else 0) := by
                        apply Finset.sum_congr rfl
                        intro m hm
                        exact hterm m hm
              _ = (((Finset.Icc 1 (X / d)).filter
                    (fun m => (6 * q).Coprime m)).card : ℝ) := by
                      exact Finset.sum_boole _ _

          rw [← hind, Finset.mul_sum]

#print axioms omegaLinearPartialSum_eq_correction_coprime

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def omegaCorrectionInvTerm (q n : ℕ) : ℝ :=
  omegaLinearCorrectionArithmetic q n / (n : ℝ)

noncomputable def omegaCorrectionInvMass (q : ℕ) : ℝ :=
  ∑' n : ℕ, omegaCorrectionInvTerm q n

theorem norm_omegaCorrectionInvTerm_le_rankin
    (q n : ℕ) :
    ‖omegaCorrectionInvTerm q n‖ ≤ omegaCorrectionRankin q n := by
  by_cases hn0 : n = 0
  · subst n
    simp [omegaCorrectionInvTerm, omegaCorrectionRankin,
      omegaLinearCorrectionArithmetic, omegaLinearCorrectionCoeff]
  · have hn1 : 1 ≤ n := Nat.one_le_iff_ne_zero.mpr hn0
    have hnR : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn1
    have hpow :
        (n : ℝ) ^ (-1 : ℝ) ≤ (n : ℝ) ^ (-3 / 4 : ℝ) :=
      Real.rpow_le_rpow_of_exponent_le hnR (by norm_num)
    rw [omegaCorrectionInvTerm, Real.norm_eq_abs, abs_div]
    rw [omegaCorrectionRankin, if_neg hn0]
    have hnpos : (0 : ℝ) < n := by positivity
    rw [abs_of_pos hnpos, div_eq_mul_inv, ← Real.rpow_neg_one]
    exact mul_le_mul_of_nonneg_left hpow (abs_nonneg _)

theorem summable_omegaCorrectionInvTerm (q : ℕ) :
    Summable (omegaCorrectionInvTerm q) := by
  exact (summable_omegaCorrectionRankin q).of_norm_bounded
    (norm_omegaCorrectionInvTerm_le_rankin q)

theorem tsum_abs_omegaCorrectionInvTerm_le_bound (q : ℕ) :
    (∑' n : ℕ, |omegaCorrectionInvTerm q n|) ≤ omegaRankinBound := by
  calc
    (∑' n : ℕ, |omegaCorrectionInvTerm q n|)
        ≤ ∑' n : ℕ, omegaCorrectionRankin q n := by
          exact (summable_omegaCorrectionInvTerm q).abs.tsum_le_tsum
            (fun n => by
              simpa [Real.norm_eq_abs] using
                norm_omegaCorrectionInvTerm_le_rankin q n)
            (summable_omegaCorrectionRankin q)
    _ ≤ omegaRankinBound := tsum_omegaCorrectionRankin_le_bound q

#print axioms summable_omegaCorrectionInvTerm

end PaperB.FixedQ


namespace PaperB.FixedQ

@[simp] theorem omegaCorrectionInvTerm_zero (q : ℕ) :
    omegaCorrectionInvTerm q 0 = 0 := by
  simp [omegaCorrectionInvTerm]

@[simp] theorem omegaCorrectionInvTerm_one (q : ℕ) :
    omegaCorrectionInvTerm q 1 = 1 := by
  simp [omegaCorrectionInvTerm, omegaLinearCorrectionArithmetic,
    omegaLinearCorrectionCoeff]

theorem omegaCorrectionInvTerm_mul_of_coprime
    (q : ℕ) {m n : ℕ} (hcop : m.Coprime n) :
    omegaCorrectionInvTerm q (m * n) =
      omegaCorrectionInvTerm q m * omegaCorrectionInvTerm q n := by
  by_cases hm0 : m = 0
  · subst m
    have hn1 : n = 1 := by simpa using hcop
    subst n
    simp
  · by_cases hn0 : n = 0
    · subst n
      have hm1 : m = 1 := by simpa using hcop
      subst m
      simp
    · unfold omegaCorrectionInvTerm
      rw [(omegaLinearCorrectionArithmetic_multiplicative q).map_mul_of_coprime hcop]
      have hmR : (m : ℝ) ≠ 0 := by exact_mod_cast hm0
      have hnR : (n : ℝ) ≠ 0 := by exact_mod_cast hn0
      push_cast
      field_simp [hmR, hnR]

theorem omegaCorrectionInvTerm_prime_pow_zero_of_three_le
    (q : ℕ) {p nu : ℕ} (hp : p.Prime) (hnu : 3 ≤ nu) :
    omegaCorrectionInvTerm q (p ^ nu) = 0 := by
  unfold omegaCorrectionInvTerm
  rw [omegaLinearCorrectionArithmetic_prime_pow q hp]
  have h0 : nu ≠ 0 := by omega
  have h1 : nu ≠ 1 := by omega
  have h2 : nu ≠ 2 := by omega
  simp [omegaLinearCorrectionLocal, hp, h0, h1, h2]


end PaperB.FixedQ


namespace PaperB.FixedQ

theorem omegaCorrectionInvTerm_prime_active
    (q : ℕ) {p : ℕ} (hp : p.Prime) (hcop : p.Coprime (6 * q)) :
    omegaCorrectionInvTerm q p =
      3 / ((p : ℝ) * ((p : ℝ) - 3)) := by
  unfold omegaCorrectionInvTerm
  have hlocal :=
    omegaLinearCorrectionArithmetic_prime_pow (q := q) (p := p) (i := 1) hp
  have hcoeff :
      omegaLinearCorrectionArithmetic q p = 3 / ((p : ℝ) - 3) := by
    have h := hlocal
    simp [omegaLinearCorrectionLocal, hp] at h
    rw [if_pos hcop] at h
    simpa using h
  rw [hcoeff]
  have hpR : (p : ℝ) ≠ 0 := by exact_mod_cast hp.ne_zero
  field_simp [hpR]

theorem omegaCorrectionInvTerm_prime_sq_active
    (q : ℕ) {p : ℕ} (hp : p.Prime) (hcop : p.Coprime (6 * q)) :
    omegaCorrectionInvTerm q (p ^ 2) =
      -1 / ((p : ℝ) * ((p : ℝ) - 3)) := by
  unfold omegaCorrectionInvTerm
  have hlocal :=
    omegaLinearCorrectionArithmetic_prime_pow (q := q) (p := p) (i := 2) hp
  have hcoeff :
      omegaLinearCorrectionArithmetic q (p ^ 2) =
        -(p : ℝ) / ((p : ℝ) - 3) := by
    have h := hlocal
    simp [omegaLinearCorrectionLocal, hp] at h
    rw [if_pos hcop] at h
    simpa using h
  rw [hcoeff]
  have hpR : (p : ℝ) ≠ 0 := by exact_mod_cast hp.ne_zero
  rw [Nat.cast_pow]
  field_simp [hpR]

theorem omegaCorrectionInvTerm_prime_inactive
    (q : ℕ) {p : ℕ} (hp : p.Prime) (hcop : ¬ p.Coprime (6 * q)) :
    omegaCorrectionInvTerm q p = 0 := by
  unfold omegaCorrectionInvTerm
  have hlocal :=
    omegaLinearCorrectionArithmetic_prime_pow (q := q) (p := p) (i := 1) hp
  have hcoeff : omegaLinearCorrectionArithmetic q p = 0 := by
    have h := hlocal
    simp [omegaLinearCorrectionLocal, hp] at h
    rw [if_neg hcop] at h
    simpa using h
  rw [hcoeff]
  simp

theorem omegaCorrectionInvTerm_prime_sq_inactive
    (q : ℕ) {p : ℕ} (hp : p.Prime) (hcop : ¬ p.Coprime (6 * q)) :
    omegaCorrectionInvTerm q (p ^ 2) = 0 := by
  unfold omegaCorrectionInvTerm
  have hlocal :=
    omegaLinearCorrectionArithmetic_prime_pow (q := q) (p := p) (i := 2) hp
  have hcoeff : omegaLinearCorrectionArithmetic q (p ^ 2) = 0 := by
    have h := hlocal
    simp [omegaLinearCorrectionLocal, hp] at h
    rw [if_neg hcop] at h
    simpa using h
  rw [hcoeff]
  simp

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem tsum_omegaCorrectionInvTerm_prime_pow
    (q : ℕ) {p : ℕ} (hp : p.Prime) :
    (∑' nu : ℕ, omegaCorrectionInvTerm q (p ^ nu)) =
      1 + normalizationCorrection q 1 p := by
  rw [tsum_eq_sum (s := ({0, 1, 2} : Finset ℕ))]
  · by_cases hactive : p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q
    · have hcop : p.Coprime (6 * q) := by
        apply hp.coprime_iff_not_dvd.mpr
        intro hd
        rcases hp.dvd_mul.mp hd with h6 | hq
        · have hp6 : p ∣ 2 * 3 := by simpa using h6
          rcases hp.dvd_mul.mp hp6 with h2 | h3
          · have : p ≤ 2 := Nat.le_of_dvd (by norm_num) h2
            omega
          · have : p ≤ 3 := Nat.le_of_dvd (by norm_num) h3
            omega
        · exact hactive.2.2 hq
      have hpnot1 : ¬ p ∣ 1 := hp.not_dvd_one
      rw [show normalizationCorrection q 1 p =
          2 / ((p : ℝ) * ((p : ℝ) - 3)) by
        simp [normalizationCorrection, hactive, hpnot1]]
      simp [omegaCorrectionInvTerm_one,
        omegaCorrectionInvTerm_prime_active q hp hcop,
        omegaCorrectionInvTerm_prime_sq_active q hp hcop]
      have hp0 : (p : ℝ) ≠ 0 := by exact_mod_cast hp.ne_zero
      have hp3 : (p : ℝ) - 3 ≠ 0 := by
        exact sub_ne_zero.mpr (by exact_mod_cast (show p ≠ 3 by omega))
      field_simp [hp0, hp3]
      norm_num
    · have hnotcop : ¬ p.Coprime (6 * q) := by
        intro hcop
        have hp5 : 5 ≤ p := omega_rankin_five_le_of_prime_coprime_six hp hcop
        have hpq : ¬ p ∣ q := by
          intro hd
          exact (hp.coprime_iff_not_dvd.mp hcop)
            (dvd_mul_of_dvd_right hd 6)
        exact hactive ⟨hp, hp5, hpq⟩
      rw [show normalizationCorrection q 1 p = 0 by
        simp [normalizationCorrection, hactive]]
      simp [omegaCorrectionInvTerm_one,
        omegaCorrectionInvTerm_prime_inactive q hp hnotcop,
        omegaCorrectionInvTerm_prime_sq_inactive q hp hnotcop]
  · intro nu hnu
    have hnot : nu ∉ ({0, 1, 2} : Finset ℕ) := hnu
    have hge : 3 ≤ nu := by
      simp at hnot
      omega
    exact omegaCorrectionInvTerm_prime_pow_zero_of_three_le q hp hge

#print axioms tsum_omegaCorrectionInvTerm_prime_pow

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem omegaCorrectionInvMass_eq_correction_tprod
    (q : ℕ) :
    omegaCorrectionInvMass q =
      ∏' p : ℕ, (1 + normalizationCorrection q 1 p) := by
  have hEP :=
    EulerProduct.eulerProduct_hasProd_mulIndicator
      (omegaCorrectionInvTerm_one q)
      (fun {_m _n} hcop => omegaCorrectionInvTerm_mul_of_coprime q hcop)
      (summable_omegaCorrectionInvTerm q).norm
      (omegaCorrectionInvTerm_zero q)
  have heq :
      Set.mulIndicator {p : ℕ | p.Prime}
        (fun p => ∑' nu : ℕ, omegaCorrectionInvTerm q (p ^ nu)) =
      (fun p : ℕ => 1 + normalizationCorrection q 1 p) := by
    funext p
    by_cases hp : p.Prime
    · simp [Set.mulIndicator, hp, tsum_omegaCorrectionInvTerm_prime_pow q hp]
    · simp [Set.mulIndicator, hp, normalizationCorrection]
  have ht := hEP.tprod_eq
  rw [heq] at ht
  unfold omegaCorrectionInvMass
  exact ht.symm

theorem cStarOne_mul_omegaCorrectionInvMass
    (q : ℕ) :
    cStarReal q 1 * omegaCorrectionInvMass q = 1 := by
  unfold cStarReal
  rw [omegaCorrectionInvMass_eq_correction_tprod q]
  exact normalizationBaseline_tprod_mul_correction_tprod q 1

#print axioms omegaCorrectionInvMass_eq_correction_tprod
#print axioms cStarOne_mul_omegaCorrectionInvMass

end PaperB.FixedQ
namespace PaperB.FixedQ

theorem movingVCoeff_one_eq_omegaCoeff
    (q : ℕ) :
    movingVCoeff q 1 = omegaCoeff q := by
  funext e
  unfold movingVCoeff omegaCoeff
  by_cases he0 : e = 0
  · simp [he0]
  · rw [if_neg he0, if_neg he0]
    by_cases hs : Squarefree e ∧ e.Coprime (6 * q)
    · rw [if_pos hs, if_pos hs]
      apply Finset.prod_congr rfl
      intro p hp
      have hpPrime : p.Prime := Nat.prime_of_mem_primeFactors hp
      rw [if_neg hpPrime.not_dvd_one]
    · rw [if_neg hs, if_neg hs]

theorem six_mul_density_mul_omegaCorrectionInvMass_eq_residue
    (q : ℕ) (hq : 0 < q) :
    ((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
        omegaCorrectionInvMass q =
      logarithmicEulerResidue (omegaCoeff q) := by
  have hFR := principalHighCoefficient_moving q 1 hq
  rw [movingVCoeff_one_eq_omegaCoeff q] at hFR
  have hFI := cStarOne_mul_omegaCorrectionInvMass q
  have hD := fixedQPeriod_density_eq_six_mul_density q hq
  calc
    ((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
        omegaCorrectionInvMass q
        = ((Nat.totient (fixedQPeriod q) : ℝ) /
            (fixedQPeriod q : ℝ)) * omegaCorrectionInvMass q := by
              rw [hD]
    _ = (cStarReal q 1 *
          logarithmicEulerResidue (omegaCoeff q)) *
          omegaCorrectionInvMass q := by rw [hFR]
    _ = logarithmicEulerResidue (omegaCoeff q) *
          (cStarReal q 1 * omegaCorrectionInvMass q) := by ring
    _ = logarithmicEulerResidue (omegaCoeff q) := by rw [hFI, mul_one]

#print axioms six_mul_density_mul_omegaCorrectionInvMass_eq_residue

end PaperB.FixedQ
namespace PaperB.FixedQ

theorem omegaCoeff_eq_omegaLinearArithmetic_div
    (q n : ℕ) (hn : n ≠ 0) :
    omegaCoeff q n = omegaLinearArithmetic q n / (n : ℝ) := by
  change omegaCoeff q n =
    ((n : ℝ) * omegaCoeff q n) / (n : ℝ)
  have hnR : (n : ℝ) ≠ 0 := by exact_mod_cast hn
  field_simp [hnR]

theorem omegaCoeff_eq_correction_divisor_sum
    (q n : ℕ) (hn : n ≠ 0) :
    omegaCoeff q n =
      ∑ ds ∈ n.divisorsAntidiagonal,
        omegaCorrectionInvTerm q ds.2 *
          (coprimeIndicatorArithmetic q ds.1 / (ds.1 : ℝ)) := by
  rw [omegaCoeff_eq_omegaLinearArithmetic_div q n hn]
  have hfun := omegaLinearArithmetic_eq_correction_mul_coprime q
  have hnval := congrArg (fun f : ArithmeticFunction ℝ => f n) hfun
  rw [hnval]
  rw [mul_comm]
  rw [ArithmeticFunction.mul_apply]
  rw [Finset.sum_div]
  apply Finset.sum_congr rfl
  intro ds hds
  have hprod : ds.1 * ds.2 = n :=
    (Nat.mem_divisorsAntidiagonal.mp hds).1
  have hleft : ds.1 ≠ 0 :=
    Nat.left_ne_zero_of_mem_divisorsAntidiagonal hds
  have hright : ds.2 ≠ 0 :=
    Nat.right_ne_zero_of_mem_divisorsAntidiagonal hds
  unfold omegaCorrectionInvTerm
  rw [show (n : ℝ) = (ds.1 : ℝ) * (ds.2 : ℝ) by
    exact_mod_cast hprod.symm]
  have hlR : (ds.1 : ℝ) ≠ 0 := by exact_mod_cast hleft
  have hrR : (ds.2 : ℝ) ≠ 0 := by exact_mod_cast hright
  field_simp [hlR, hrR]

#print axioms omegaCoeff_eq_correction_divisor_sum

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def omegaPartialSum (q X : ℕ) : ℝ :=
  ∑ n ∈ Finset.Icc 1 X, omegaCoeff q n

theorem omegaPartialSum_eq_correction_harmonic
    (q X : ℕ) :
    omegaPartialSum q X =
      ∑ d ∈ Finset.Icc 1 X,
        omegaCorrectionInvTerm q d *
          coprimeHarmonicIccReal (6 * q) (X / d) := by
  classical
  unfold omegaPartialSum
  calc
    (∑ n ∈ Finset.Icc 1 X, omegaCoeff q n)
      = ∑ n ∈ Finset.Icc 1 X,
          ∑ ds ∈ n.divisorsAntidiagonal,
            omegaCorrectionInvTerm q ds.2 *
              (coprimeIndicatorArithmetic q ds.1 / (ds.1 : ℝ)) := by
          apply Finset.sum_congr rfl
          intro n hn
          have hn0 : n ≠ 0 := by
            rw [Finset.mem_Icc] at hn
            omega
          exact omegaCoeff_eq_correction_divisor_sum q n hn0
    _ = ∑ x ∈ petermannDivisorSigma X,
          omegaCorrectionInvTerm q x.2.2 *
            (coprimeIndicatorArithmetic q x.2.1 / (x.2.1 : ℝ)) := by
          rw [petermannDivisorSigma, Finset.sum_sigma']
    _ = ∑ d ∈ Finset.Icc 1 X,
          ∑ m ∈ Finset.Icc 1 (X / d),
            omegaCorrectionInvTerm q d *
              (coprimeIndicatorArithmetic q m / (m : ℝ)) := by
          exact sum_petermannDivisorSigma_eq_nested X
            (fun d m =>
              omegaCorrectionInvTerm q d *
                (coprimeIndicatorArithmetic q m / (m : ℝ)))
    _ = ∑ d ∈ Finset.Icc 1 X,
        omegaCorrectionInvTerm q d *
          coprimeHarmonicIccReal (6 * q) (X / d) := by
          apply Finset.sum_congr rfl
          intro d hd
          rw [← Finset.mul_sum]
          congr 1
          unfold coprimeHarmonicIccReal
          apply Finset.sum_congr rfl
          intro m hm
          have hm0 : m ≠ 0 := by
            rw [Finset.mem_Icc] at hm
            omega
          rw [coprimeIndicatorArithmetic_apply]
          rw [coprimeIndicatorCoeff, if_neg hm0]
          simpa [Nat.coprime_comm]

#print axioms omegaPartialSum_eq_correction_harmonic

end PaperB.FixedQ
namespace PaperB.FixedQ

theorem sum_Icc_abs_omegaCorrectionInvTerm_le_bound
    (q X : ℕ) :
    (∑ n ∈ Finset.Icc 1 X, |omegaCorrectionInvTerm q n|) ≤
      omegaRankinBound := by
  calc
    (∑ n ∈ Finset.Icc 1 X, |omegaCorrectionInvTerm q n|)
        ≤ ∑' n : ℕ, |omegaCorrectionInvTerm q n| := by
          exact (summable_omegaCorrectionInvTerm q).abs.sum_le_tsum
            (Finset.Icc 1 X) (fun n hn => abs_nonneg _)
    _ ≤ omegaRankinBound := tsum_abs_omegaCorrectionInvTerm_le_bound q

theorem abs_omegaCorrectionInvTerm_mul_log_le_four_rankin
    (q n : ℕ) :
    |omegaCorrectionInvTerm q n * Real.log n| ≤
      4 * omegaCorrectionRankin q n := by
  by_cases hn0 : n = 0
  · subst n
    simp
  · have hnpos : (0 : ℝ) < n := by positivity
    have hn1 : 1 ≤ n := Nat.one_le_iff_ne_zero.mpr hn0
    have hlog0 : 0 ≤ Real.log (n : ℝ) :=
      Real.log_nonneg (by exact_mod_cast hn1)
    have hlog :=
      Real.log_natCast_le_rpow_div n
        (show (0 : ℝ) < (1 / 4 : ℝ) by norm_num)
    rw [omegaCorrectionInvTerm, omegaCorrectionRankin, if_neg hn0]
    rw [abs_mul, abs_div, abs_of_pos hnpos, abs_of_nonneg hlog0]
    have hpow :
        (n : ℝ)⁻¹ * ((n : ℝ) ^ (1 / 4 : ℝ)) =
          (n : ℝ) ^ (-3 / 4 : ℝ) := by
      rw [← Real.rpow_neg_one]
      rw [← Real.rpow_add hnpos]
      norm_num
    calc
      |omegaLinearCorrectionArithmetic q n| / (n : ℝ) *
          Real.log (n : ℝ)
          ≤ |omegaLinearCorrectionArithmetic q n| / (n : ℝ) *
              ((n : ℝ) ^ (1 / 4 : ℝ) / (1 / 4 : ℝ)) := by
                exact mul_le_mul_of_nonneg_left hlog
                  (div_nonneg (abs_nonneg _) hnpos.le)
      _ = |omegaLinearCorrectionArithmetic q n| * (n : ℝ)⁻¹ *
          ((n : ℝ) ^ (1 / 4 : ℝ) * 4) := by
            rw [div_eq_mul_inv, div_eq_mul_inv]
            norm_num
      _ = 4 * (|omegaLinearCorrectionArithmetic q n| *
          ((n : ℝ)⁻¹ * (n : ℝ) ^ (1 / 4 : ℝ))) := by ring
      _ = 4 * (|omegaLinearCorrectionArithmetic q n| *
          (n : ℝ) ^ (-3 / 4 : ℝ)) := by rw [hpow]

theorem sum_Icc_abs_omegaCorrectionInvTerm_mul_log_le
    (q X : ℕ) :
    (∑ n ∈ Finset.Icc 1 X,
      |omegaCorrectionInvTerm q n * Real.log n|) ≤
      4 * omegaRankinBound := by
  calc
    (∑ n ∈ Finset.Icc 1 X,
      |omegaCorrectionInvTerm q n * Real.log n|)
        ≤ ∑ n ∈ Finset.Icc 1 X,
            4 * omegaCorrectionRankin q n := by
              exact Finset.sum_le_sum fun n hn =>
                abs_omegaCorrectionInvTerm_mul_log_le_four_rankin q n
    _ = 4 * ∑ n ∈ Finset.Icc 1 X,
          omegaCorrectionRankin q n := by
            rw [Finset.mul_sum]
    _ ≤ 4 * omegaRankinBound := by
      apply mul_le_mul_of_nonneg_left _ (by norm_num)
      calc
        (∑ n ∈ Finset.Icc 1 X, omegaCorrectionRankin q n)
            ≤ ∑' n : ℕ, omegaCorrectionRankin q n := by
              exact (summable_omegaCorrectionRankin q).sum_le_tsum
                (Finset.Icc 1 X)
                (fun n hn => omegaCorrectionRankin_nonneg q n)
        _ ≤ omegaRankinBound := tsum_omegaCorrectionRankin_le_bound q

#print axioms abs_omegaCorrectionInvTerm_mul_log_le_four_rankin

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem abs_log_mul_omegaCorrectionInv_tail_le
    (q X : ℕ) (hX : 1 ≤ X) :
    |Real.log X *
      ((∑ d ∈ Finset.Icc 1 X, omegaCorrectionInvTerm q d) -
        omegaCorrectionInvMass q)| ≤
      4 * omegaRankinBound := by
  let s : Finset ℕ := Finset.Icc 1 X
  have hsum := summable_omegaCorrectionInvTerm q
  have hdecomp := hsum.sum_add_tsum_subtype_compl s
  unfold omegaCorrectionInvMass at hdecomp
  have htail :
      (∑ d ∈ s, omegaCorrectionInvTerm q d) -
          (∑' d : ℕ, omegaCorrectionInvTerm q d) =
        -(∑' d : {d // d ∉ s}, omegaCorrectionInvTerm q d) := by
    linarith
  rw [show (∑ d ∈ Finset.Icc 1 X, omegaCorrectionInvTerm q d) =
      ∑ d ∈ s, omegaCorrectionInvTerm q d by rfl]
  unfold omegaCorrectionInvMass
  rw [htail]
  have hlog0 : 0 ≤ Real.log (X : ℝ) :=
    Real.log_nonneg (by exact_mod_cast hX)
  have hpoint :
      ∀ d : {d // d ∉ s},
        ‖Real.log (X : ℝ) * omegaCorrectionInvTerm q d.1‖ ≤
          4 * omegaCorrectionRankin q d.1 := by
    intro d
    by_cases hd0 : d.1 = 0
    · simp [hd0]
    · have hdnot : d.1 ∉ Finset.Icc 1 X := d.2
      have hd1 : 1 ≤ d.1 := Nat.one_le_iff_ne_zero.mpr hd0
      have hXd : X < d.1 := by
        rw [Finset.mem_Icc] at hdnot
        push_neg at hdnot
        exact hdnot hd1
      have hlogle : Real.log (X : ℝ) ≤ Real.log (d.1 : ℝ) := by
        exact Real.log_le_log
          (by positivity : (0 : ℝ) < X)
          (by exact_mod_cast hXd.le)
      have hlogd0 : 0 ≤ Real.log (d.1 : ℝ) :=
        Real.log_nonneg (by exact_mod_cast hd1)
      have hbase :=
        abs_omegaCorrectionInvTerm_mul_log_le_four_rankin q d.1
      rw [Real.norm_eq_abs, abs_mul, abs_of_nonneg hlog0]
      rw [abs_mul, abs_of_nonneg hlogd0] at hbase
      exact (mul_le_mul_of_nonneg_right hlogle (abs_nonneg _)).trans
        (by simpa [mul_comm] using hbase)
  have hsubsum :
      Summable (fun d : {d // d ∉ s} =>
        Real.log (X : ℝ) * omegaCorrectionInvTerm q d.1) := by
    exact (hsum.subtype _).mul_left _
  have hnorm0 :
      ‖∑' d : {d // d ∉ s},
          Real.log (X : ℝ) * omegaCorrectionInvTerm q d.1‖ ≤
        ∑' d : {d // d ∉ s},
          ‖Real.log (X : ℝ) * omegaCorrectionInvTerm q d.1‖ :=
    norm_tsum_le_tsum_norm hsubsum.norm
  have hnorm1 :
      (∑' d : {d // d ∉ s},
          ‖Real.log (X : ℝ) * omegaCorrectionInvTerm q d.1‖) ≤
        ∑' d : {d // d ∉ s}, 4 * omegaCorrectionRankin q d.1 := by
    exact hsubsum.norm.tsum_le_tsum hpoint
      ((summable_omegaCorrectionRankin q).subtype _ |>.mul_left 4)
  have hnorm := hnorm0.trans hnorm1
  have hmajor :
      (∑' d : {d // d ∉ s}, 4 * omegaCorrectionRankin q d.1) ≤
        4 * omegaRankinBound := by
    rw [tsum_mul_left]
    have hrankDecomp :=
      (summable_omegaCorrectionRankin q).sum_add_tsum_subtype_compl s
    have hfin0 :
        0 ≤ ∑ d ∈ s, omegaCorrectionRankin q d := by
      exact Finset.sum_nonneg (fun d hd => omegaCorrectionRankin_nonneg q d)
    have hsub :
        (∑' d : {d // d ∉ s}, omegaCorrectionRankin q d.1) ≤
          ∑' d : ℕ, omegaCorrectionRankin q d := by
      linarith
    exact mul_le_mul_of_nonneg_left
      (hsub.trans (tsum_omegaCorrectionRankin_le_bound q)) (by norm_num)
  have htotal := hnorm.trans hmajor
  rw [mul_neg, abs_neg]
  rw [← tsum_mul_left]
  simpa [Real.norm_eq_abs] using htotal

#print axioms abs_log_mul_omegaCorrectionInv_tail_le

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def omegaHarmonicError (q X d : ℕ) : ℝ :=
  coprimeHarmonicIccReal (6 * q) (X / d) -
    ((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
      (Real.log X - Real.log d)

theorem abs_omegaHarmonicError_le
    (q X d : ℕ) (hq : 0 < q)
    (hd1 : 1 ≤ d) (hdX : d ≤ X) :
    |omegaHarmonicError q X d| ≤ 2 * (6 * q) + 1 := by
  unfold omegaHarmonicError
  simpa [Nat.cast_mul] using
    (abs_coprimeHarmonicIcc_sub_log_ratio_le
      (6 * q) X d (mul_pos (by norm_num) hq) hd1 hdX)

theorem omegaPrincipalError_decomposition
    (q X : ℕ) (hq : 0 < q) :
    omegaPartialSum q X -
        logarithmicEulerResidue (omegaCoeff q) * Real.log X =
      (∑ d ∈ Finset.Icc 1 X,
        omegaCorrectionInvTerm q d * omegaHarmonicError q X d) -
      ((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
        (∑ d ∈ Finset.Icc 1 X,
          omegaCorrectionInvTerm q d * Real.log d) +
      ((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
        Real.log X *
        ((∑ d ∈ Finset.Icc 1 X, omegaCorrectionInvTerm q d) -
          omegaCorrectionInvMass q) := by
  rw [omegaPartialSum_eq_correction_harmonic]
  have hR :=
    six_mul_density_mul_omegaCorrectionInvMass_eq_residue q hq
  rw [← hR]
  let D : ℝ := (Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)
  have hsumerr :
      (∑ d ∈ Finset.Icc 1 X,
        omegaCorrectionInvTerm q d * omegaHarmonicError q X d) =
      (∑ d ∈ Finset.Icc 1 X,
        omegaCorrectionInvTerm q d *
          coprimeHarmonicIccReal (6 * q) (X / d)) -
      D * Real.log X *
        (∑ d ∈ Finset.Icc 1 X, omegaCorrectionInvTerm q d) +
      D * (∑ d ∈ Finset.Icc 1 X,
        omegaCorrectionInvTerm q d * Real.log d) := by
    calc
      (∑ d ∈ Finset.Icc 1 X,
        omegaCorrectionInvTerm q d * omegaHarmonicError q X d)
          = ∑ d ∈ Finset.Icc 1 X,
              (omegaCorrectionInvTerm q d *
                coprimeHarmonicIccReal (6 * q) (X / d) -
               D * Real.log X * omegaCorrectionInvTerm q d +
               D * (omegaCorrectionInvTerm q d * Real.log d)) := by
                apply Finset.sum_congr rfl
                intro d hd
                unfold omegaHarmonicError D
                ring
      _ = (∑ d ∈ Finset.Icc 1 X,
              omegaCorrectionInvTerm q d *
                coprimeHarmonicIccReal (6 * q) (X / d)) -
            D * Real.log X *
              (∑ d ∈ Finset.Icc 1 X, omegaCorrectionInvTerm q d) +
            D * (∑ d ∈ Finset.Icc 1 X,
              omegaCorrectionInvTerm q d * Real.log d) := by
                rw [Finset.sum_add_distrib, Finset.sum_sub_distrib]
                rw [← Finset.mul_sum, ← Finset.mul_sum]
  rw [hsumerr]
  dsimp [D]
  ring

theorem abs_omegaHarmonicErrorSum_le
    (q X : ℕ) (hq : 0 < q) :
    |∑ d ∈ Finset.Icc 1 X,
        omegaCorrectionInvTerm q d * omegaHarmonicError q X d| ≤
      (2 * (6 * q) + 1) * omegaRankinBound := by
  calc
    |∑ d ∈ Finset.Icc 1 X,
        omegaCorrectionInvTerm q d * omegaHarmonicError q X d|
        ≤ ∑ d ∈ Finset.Icc 1 X,
            |omegaCorrectionInvTerm q d * omegaHarmonicError q X d| := by
              exact Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ d ∈ Finset.Icc 1 X,
          (2 * (6 * q) + 1) * |omegaCorrectionInvTerm q d| := by
            apply Finset.sum_le_sum
            intro d hd
            rw [abs_mul]
            have hmem := Finset.mem_Icc.mp hd
            have hE := abs_omegaHarmonicError_le q X d hq hmem.1 hmem.2
            have ha0 := abs_nonneg (omegaCorrectionInvTerm q d)
            nlinarith
    _ = (2 * (6 * q) + 1) *
          ∑ d ∈ Finset.Icc 1 X, |omegaCorrectionInvTerm q d| := by
            rw [Finset.mul_sum]
    _ ≤ (2 * (6 * q) + 1) * omegaRankinBound := by
      apply mul_le_mul_of_nonneg_left
      · exact sum_Icc_abs_omegaCorrectionInvTerm_le_bound q X
      · positivity

theorem abs_omegaLogMomentTerm_le
    (q X : ℕ) (hq : 0 < q) :
    |((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
      (∑ d ∈ Finset.Icc 1 X,
        omegaCorrectionInvTerm q d * Real.log d)| ≤
      4 * omegaRankinBound := by
  let D : ℝ := (Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)
  have hLpos : 0 < 6 * q := mul_pos (by norm_num) hq
  have hD0 : 0 ≤ D := by
    dsimp [D]
    positivity
  have hD1 : D ≤ 1 := by
    dsimp [D]
    rw [div_le_one (by positivity : (0 : ℝ) < (6 * q : ℕ))]
    exact_mod_cast Nat.totient_le (6 * q)
  have hsum :
      |∑ d ∈ Finset.Icc 1 X,
        omegaCorrectionInvTerm q d * Real.log d| ≤
      4 * omegaRankinBound := by
    calc
      |∑ d ∈ Finset.Icc 1 X,
        omegaCorrectionInvTerm q d * Real.log d|
          ≤ ∑ d ∈ Finset.Icc 1 X,
              |omegaCorrectionInvTerm q d * Real.log d| := by
                exact Finset.abs_sum_le_sum_abs _ _
      _ ≤ 4 * omegaRankinBound :=
        sum_Icc_abs_omegaCorrectionInvTerm_mul_log_le q X
  change |D * (∑ d ∈ Finset.Icc 1 X,
    omegaCorrectionInvTerm q d * Real.log d)| ≤ _
  rw [abs_mul, abs_of_nonneg hD0]
  have hB0 : 0 ≤ omegaRankinBound := by
    unfold omegaRankinBound
    positivity
  nlinarith [abs_nonneg
    (∑ d ∈ Finset.Icc 1 X,
      omegaCorrectionInvTerm q d * Real.log d)]

theorem abs_omegaTailTerm_le
    (q X : ℕ) (hq : 0 < q) (hX : 1 ≤ X) :
    |((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
      Real.log X *
      ((∑ d ∈ Finset.Icc 1 X, omegaCorrectionInvTerm q d) -
        omegaCorrectionInvMass q)| ≤
      4 * omegaRankinBound := by
  let D : ℝ := (Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)
  have hD0 : 0 ≤ D := by
    dsimp [D]
    positivity
  have hD1 : D ≤ 1 := by
    dsimp [D]
    rw [div_le_one (by positivity : (0 : ℝ) < (6 * q : ℕ))]
    exact_mod_cast Nat.totient_le (6 * q)
  have htail := abs_log_mul_omegaCorrectionInv_tail_le q X hX
  change |D * Real.log X *
      ((∑ d ∈ Finset.Icc 1 X, omegaCorrectionInvTerm q d) -
        omegaCorrectionInvMass q)| ≤ _
  rw [show D * Real.log X *
      ((∑ d ∈ Finset.Icc 1 X, omegaCorrectionInvTerm q d) -
        omegaCorrectionInvMass q) =
      D * (Real.log X *
        ((∑ d ∈ Finset.Icc 1 X, omegaCorrectionInvTerm q d) -
          omegaCorrectionInvMass q)) by ring]
  rw [abs_mul, abs_of_nonneg hD0]
  have hB0 : 0 ≤ omegaRankinBound := by
    unfold omegaRankinBound
    positivity
  nlinarith [abs_nonneg
    (Real.log X *
      ((∑ d ∈ Finset.Icc 1 X, omegaCorrectionInvTerm q d) -
        omegaCorrectionInvMass q))]

theorem omegaPrincipalLogMean_bound
    (q X : ℕ) (hq : 0 < q) (hX : 1 ≤ X) :
    |omegaPartialSum q X -
      logarithmicEulerResidue (omegaCoeff q) * Real.log X| ≤
      (2 * (6 * q) + 9) * omegaRankinBound := by
  rw [omegaPrincipalError_decomposition q X hq]
  have hA := abs_omegaHarmonicErrorSum_le q X hq
  have hB := abs_omegaLogMomentTerm_le q X hq
  have hC := abs_omegaTailTerm_le q X hq hX
  calc
    |(∑ d ∈ Finset.Icc 1 X,
        omegaCorrectionInvTerm q d * omegaHarmonicError q X d) -
      ((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
        (∑ d ∈ Finset.Icc 1 X,
          omegaCorrectionInvTerm q d * Real.log d) +
      ((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
        Real.log X *
        ((∑ d ∈ Finset.Icc 1 X, omegaCorrectionInvTerm q d) -
          omegaCorrectionInvMass q)|
      ≤
      |∑ d ∈ Finset.Icc 1 X,
        omegaCorrectionInvTerm q d * omegaHarmonicError q X d| +
      |((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
        (∑ d ∈ Finset.Icc 1 X,
          omegaCorrectionInvTerm q d * Real.log d)| +
      |((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
        Real.log X *
        ((∑ d ∈ Finset.Icc 1 X, omegaCorrectionInvTerm q d) -
          omegaCorrectionInvMass q)| := by
            calc
              |((∑ d ∈ Finset.Icc 1 X,
                omegaCorrectionInvTerm q d * omegaHarmonicError q X d) -
                ((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
                  (∑ d ∈ Finset.Icc 1 X,
                    omegaCorrectionInvTerm q d * Real.log d)) +
                ((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
                  Real.log X *
                  ((∑ d ∈ Finset.Icc 1 X, omegaCorrectionInvTerm q d) -
                    omegaCorrectionInvMass q)|
                  ≤
                |(∑ d ∈ Finset.Icc 1 X,
                  omegaCorrectionInvTerm q d * omegaHarmonicError q X d) -
                  ((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
                    (∑ d ∈ Finset.Icc 1 X,
                      omegaCorrectionInvTerm q d * Real.log d)| +
                |((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
                  Real.log X *
                  ((∑ d ∈ Finset.Icc 1 X, omegaCorrectionInvTerm q d) -
                    omegaCorrectionInvMass q)| :=
                    abs_add_le _ _
              _ ≤
                |∑ d ∈ Finset.Icc 1 X,
                  omegaCorrectionInvTerm q d * omegaHarmonicError q X d| +
                |((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
                  (∑ d ∈ Finset.Icc 1 X,
                    omegaCorrectionInvTerm q d * Real.log d)| +
                |((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
                  Real.log X *
                  ((∑ d ∈ Finset.Icc 1 X, omegaCorrectionInvTerm q d) -
                    omegaCorrectionInvMass q)| := by
                    have hsub := abs_sub
                      (∑ d ∈ Finset.Icc 1 X,
                        omegaCorrectionInvTerm q d * omegaHarmonicError q X d)
                      (((Nat.totient (6 * q) : ℝ) / ((6 * q : ℕ) : ℝ)) *
                        (∑ d ∈ Finset.Icc 1 X,
                          omegaCorrectionInvTerm q d * Real.log d))
                    linarith
    _ ≤ (2 * (6 * q) + 9) * omegaRankinBound := by
      have hR0 : 0 ≤ omegaRankinBound := by
        unfold omegaRankinBound
        positivity
      nlinarith

#print axioms omegaPrincipalLogMean_bound

end PaperB.FixedQ
