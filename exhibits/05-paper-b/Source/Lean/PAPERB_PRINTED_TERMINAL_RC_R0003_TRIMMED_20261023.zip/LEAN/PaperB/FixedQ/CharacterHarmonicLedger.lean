import PaperB.FixedQ.CharacterPeriodLedger
import PaperB.FixedQ.FixedConductorCompletion

open scoped BigOperators

namespace PaperB.FixedQ

theorem shifted_dirichletCharacter_sum_eq
    {L : ℕ} (chi : DirichletCharacter ℂ L)
    (k : ℕ) :
    (∑ j ∈ Finset.range k, chi (j + 1)) =
      (∑ n ∈ Finset.range (k + 1), chi n) - chi 0 := by
  induction k with
  | zero =>
      simp
  | succ k ih =>
      rw [Finset.sum_range_succ, Finset.sum_range_succ, ih]
      simp [Nat.cast_add, Nat.cast_one, add_comm]
      abel

theorem norm_shifted_dirichletCharacter_prefix_le
    {L : ℕ} (hL : 0 < L)
    (chi : DirichletCharacter ℂ L)
    (hchi : chi ≠ 1)
    (k : ℕ) :
    ‖∑ j ∈ Finset.range k, chi (j + 1)‖ ≤ L + 1 := by
  rw [shifted_dirichletCharacter_sum_eq chi k]
  calc
    ‖(∑ n ∈ Finset.range (k + 1), chi n) - chi 0‖
        ≤ ‖∑ n ∈ Finset.range (k + 1), chi n‖ + ‖chi 0‖ := norm_sub_le _ _
    _ ≤ L + 1 := by
      have hsum := norm_dirichletCharacter_sum_range_le_period hL chi hchi (k + 1)
      have hzero := chi.norm_le_one (0 : ZMod L)
      exact add_le_add hsum hzero

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem norm_shifted_character_harmonic_sum_le
    {L : ℕ} (hL : 0 < L)
    (chi : DirichletCharacter ℂ L)
    (hchi : chi ≠ 1)
    (X : ℕ) :
    ‖∑ j ∈ Finset.range X,
        chi (j + 1) * reciprocalNatWeight 1 j‖ ≤
      2 * (L + 1) := by
  have hprefix :
      ∀ k ≤ X, ‖∑ j ∈ Finset.range k, chi (j + 1)‖ ≤ (L + 1 : ℝ) := by
    intro k hk
    exact_mod_cast norm_shifted_dirichletCharacter_prefix_le hL chi hchi k
  have h :=
    partialSummation_reciprocal_weight_le
      1 X (by norm_num) (fun j => chi (j + 1))
      (C := (L + 1 : ℝ)) (by positivity) hprefix
  simpa using h

#print axioms norm_shifted_dirichletCharacter_prefix_le
#print axioms norm_shifted_character_harmonic_sum_le

end PaperB.FixedQ
