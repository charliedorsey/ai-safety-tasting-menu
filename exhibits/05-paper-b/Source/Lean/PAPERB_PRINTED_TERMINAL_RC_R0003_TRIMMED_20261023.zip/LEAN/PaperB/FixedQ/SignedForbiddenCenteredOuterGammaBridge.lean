import PaperB.FixedQ.SignedForbiddenCenteredOuterSummation

open scoped BigOperators

namespace PaperB.FixedQ

lemma source_gammaPrimeTerm_le_invSqrtNat_of_six
    {p : ℕ} (hp6 : 6 ≤ p) :
    gammaPrimeTerm p ≤ invSqrtNat p := by
  unfold gammaPrimeTerm invSqrtNat
  rw [if_pos (by omega : 5 ≤ p)]
  have hpR : (6 : ℝ) ≤ p := by exact_mod_cast hp6
  have hd : (0 : ℝ) < (p : ℝ) - 3 := by linarith
  have hs : 0 < Real.sqrt (p : ℝ) := by
    apply Real.sqrt_pos.2
    positivity
  have hcoef : 3 / ((p : ℝ) - 3) ≤ 1 := by
    rw [div_le_one hd]
    linarith
  calc
    3 / (((p : ℝ) - 3) * Real.sqrt (p : ℝ))
        = (3 / ((p : ℝ) - 3)) * (Real.sqrt (p : ℝ))⁻¹ := by
            field_simp [hd.ne', hs.ne']
    _ ≤ 1 * (Real.sqrt (p : ℝ))⁻¹ := by
          exact mul_le_mul_of_nonneg_right hcoef (by positivity)
    _ = (Real.sqrt (p : ℝ))⁻¹ := by ring

lemma source_gammaPrimeTerm_five :
    gammaPrimeTerm 5 = (3 / 2 : ℝ) * invSqrtNat 5 := by
  unfold gammaPrimeTerm invSqrtNat
  rw [if_pos (by norm_num : 5 ≤ 5)]
  have hs : Real.sqrt (5 : ℝ) ≠ 0 := by positivity
  norm_num
  field_simp [hs]

lemma source_gammaFinsetProduct_le_threeHalves_invSqrtPrimeSetProduct
    (S : Finset ℕ) (h5 : ∀ p ∈ S, 5 ≤ p) :
    (∏ p ∈ S, gammaPrimeTerm p) ≤
      (3 / 2 : ℝ) * invSqrtNat (primeSetProduct S) := by
  have hInv :
      (∏ p ∈ S, invSqrtNat p) =
        invSqrtNat (primeSetProduct S) := by
    symm
    exact invSqrtNat_finset_prod S
  by_cases hmem : 5 ∈ S
  · have hrest6 : ∀ p ∈ S.erase 5, 6 ≤ p := by
      intro p hp
      have hpS : p ∈ S := Finset.mem_of_mem_erase hp
      have hpne : p ≠ 5 := (Finset.mem_erase.mp hp).1
      have hp5 := h5 p hpS
      omega
    have hrest :
        (∏ p ∈ S.erase 5, gammaPrimeTerm p) ≤
          ∏ p ∈ S.erase 5, invSqrtNat p := by
      apply Finset.prod_le_prod₀
      · intro p hp
        exact gammaPrimeTerm_nonneg p
      · intro p hp
        exact source_gammaPrimeTerm_le_invSqrtNat_of_six (hrest6 p hp)
    rw [← Finset.mul_prod_erase S gammaPrimeTerm hmem]
    rw [source_gammaPrimeTerm_five]
    have h5inv : 0 ≤ invSqrtNat 5 := by
      unfold invSqrtNat
      positivity
    have hfac : 0 ≤ (3 / 2 : ℝ) * invSqrtNat 5 := by positivity
    calc
      ((3 / 2 : ℝ) * invSqrtNat 5) *
          (∏ p ∈ S.erase 5, gammaPrimeTerm p)
        ≤ ((3 / 2 : ℝ) * invSqrtNat 5) *
          (∏ p ∈ S.erase 5, invSqrtNat p) :=
            mul_le_mul_of_nonneg_left hrest hfac
      _ = (3 / 2 : ℝ) * (∏ p ∈ S, invSqrtNat p) := by
            rw [← Finset.mul_prod_erase S invSqrtNat hmem]
            ring
      _ = (3 / 2 : ℝ) * invSqrtNat (primeSetProduct S) := by
            rw [hInv]
  · have hall6 : ∀ p ∈ S, 6 ≤ p := by
      intro p hp
      have hp5 := h5 p hp
      have hpne : p ≠ 5 := fun h => hmem (h ▸ hp)
      omega
    have hprod :
        (∏ p ∈ S, gammaPrimeTerm p) ≤
          ∏ p ∈ S, invSqrtNat p := by
      apply Finset.prod_le_prod₀
      · intro p hp
        exact gammaPrimeTerm_nonneg p
      · intro p hp
        exact source_gammaPrimeTerm_le_invSqrtNat_of_six (hall6 p hp)
    have hInv0 : 0 ≤ invSqrtNat (primeSetProduct S) := by
      unfold invSqrtNat
      positivity
    calc
      (∏ p ∈ S, gammaPrimeTerm p)
        ≤ ∏ p ∈ S, invSqrtNat p := hprod
      _ = invSqrtNat (primeSetProduct S) := hInv
      _ ≤ (3 / 2 : ℝ) * invSqrtNat (primeSetProduct S) := by
          nlinarith

theorem source_abs_sum_im_gammaChannels_uniform_forbidden_of_fullGamma
    {q : ℕ} (S Rset : Finset ℕ)
    (hSact : ∀ p ∈ S, activeHighPrime q p)
    (hRact : ∀ p ∈ Rset, activeHighPrime q p)
    (hdis : Disjoint S Rset)
    (channel : Finset ℕ → ℕ → ℂ)
    {K : ℝ} (hK : 0 ≤ K)
    (hchan : ∀ s ∈ S.powerset,
      ∀ c ∈ (primeSetProduct s * primeSetProduct Rset).divisors,
        ‖channel s c‖ ≤
          K * (∏ p ∈ (s ∪ Rset), gammaPrimeTerm p) *
            invSqrtNat c) :
    |∑ s ∈ S.powerset,
      ∑ c ∈ (primeSetProduct s * primeSetProduct Rset).divisors,
        (channel s c).im| ≤
      ((3 / 2 : ℝ) * K) *
        Real.exp (∑' n : ℕ, sourceEnhancedGammaPrimeTerm n) := by
  apply source_abs_sum_im_gammaChannels_uniform_forbidden
    S Rset hSact hRact hdis channel
    (K := (3 / 2 : ℝ) * K)
  · positivity
  · intro s hs c hc
    have hsub : s ⊆ S := Finset.mem_powerset.mp hs
    have hdis' : Disjoint s Rset := hdis.mono_left hsub
    have hR5 : ∀ p ∈ Rset, 5 ≤ p := by
      intro p hp
      exact (hRact p hp).2.1
    have hRgamma :=
      source_gammaFinsetProduct_le_threeHalves_invSqrtPrimeSetProduct
        Rset hR5
    have hSgamma :
        0 ≤ ∏ p ∈ s, gammaPrimeTerm p := by
      exact Finset.prod_nonneg
        (fun p hp => gammaPrimeTerm_nonneg p)
    have hic : 0 ≤ invSqrtNat c := by
      unfold invSqrtNat
      positivity
    calc
      ‖channel s c‖
        ≤ K * (∏ p ∈ (s ∪ Rset), gammaPrimeTerm p) *
            invSqrtNat c := hchan s hs c hc
      _ = K * ((∏ p ∈ s, gammaPrimeTerm p) *
            (∏ p ∈ Rset, gammaPrimeTerm p)) * invSqrtNat c := by
          rw [Finset.prod_union hdis']
      _ ≤ K * ((∏ p ∈ s, gammaPrimeTerm p) *
            ((3 / 2 : ℝ) * invSqrtNat (primeSetProduct Rset))) *
            invSqrtNat c := by
          have hinner :
              (∏ p ∈ s, gammaPrimeTerm p) *
                  (∏ p ∈ Rset, gammaPrimeTerm p) ≤
                (∏ p ∈ s, gammaPrimeTerm p) *
                  ((3 / 2 : ℝ) * invSqrtNat (primeSetProduct Rset)) :=
            mul_le_mul_of_nonneg_left hRgamma hSgamma
          have hKinner := mul_le_mul_of_nonneg_left hinner hK
          exact mul_le_mul_of_nonneg_right hKinner hic
      _ = ((3 / 2 : ℝ) * K) *
            (∏ p ∈ s, gammaPrimeTerm p) *
            invSqrtNat (primeSetProduct Rset) * invSqrtNat c := by
          ring

#print axioms source_gammaPrimeTerm_le_invSqrtNat_of_six
#print axioms source_gammaPrimeTerm_five
#print axioms source_gammaFinsetProduct_le_threeHalves_invSqrtPrimeSetProduct
#print axioms source_abs_sum_im_gammaChannels_uniform_forbidden_of_fullGamma

end PaperB.FixedQ
