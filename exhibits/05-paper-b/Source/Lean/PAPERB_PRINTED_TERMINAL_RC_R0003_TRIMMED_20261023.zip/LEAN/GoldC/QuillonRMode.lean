import GoldC.QuillonRLemma
import GoldC.QuillonAbel

/-!
# Quillon CSC3 F5d: the R route with a `u`-dependent amplitude (exact-DFT coefficients)

* `cauchy_class_split_amp`: as `cauchy_class_split`, but the inner coefficient is `a v · c v u`.
  After Cauchy, each class sum carries the amplitude `A_{vv'}(u) = c v u · conj(c v' u)`.
* `class_amp_bound`: VK along `ρ + Q t` with a bounded-variation amplitude (Abel summation):

      ‖Σ_{t∈(N,M]} A t · e(Y/(ρ+Qt))‖ ≤ (‖A M‖ + Σ‖ΔA‖) · C·(N e^{−c log³N/log²(|Y|/Q)} + N²/(|Y|/Q)).

  This removes the need for any Fourier truncation in R. The coefficients
  `a_{vu}(k) = (i/2vu)cot(πk/vu)` are handled exactly.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonR

open GoldC.QuillonAbel

theorem cauchy_class_split_amp {Q : ℕ} (hQ : 1 ≤ Q) (𝒰 I 𝒱 : Finset ℕ) (h𝒰 : 𝒰 ⊆ I)
    (a b : ℕ → ℂ) (c : ℕ → ℕ → ℂ) (φ : ℕ → ℕ → ℝ) (G : ℕ → ℕ → ℂ)
    (hG : ∀ v ρ, ‖G v ρ‖ ≤ 1) :
    ‖∑ u ∈ 𝒰, b u * ∑ v ∈ 𝒱, a v * (c v u * (eR (φ v u) * G v (u % Q)))‖ ^ 2 ≤
      (∑ u ∈ 𝒰, ‖b u‖ ^ 2) *
        ∑ v ∈ 𝒱, ∑ v' ∈ 𝒱, ‖a v‖ * ‖a v'‖ *
          ∑ ρ ∈ range Q, ‖∑ u ∈ I.filter (fun u => u % Q = ρ),
            (c v u * (starRingEnd ℂ) (c v' u)) * eR (φ v u - φ v' u)‖ := by
  set F : ℕ → ℂ := fun u => ∑ v ∈ 𝒱, a v * (c v u * (eR (φ v u) * G v (u % Q))) with hF
  have hCS : ‖∑ u ∈ 𝒰, b u * F u‖ ^ 2 ≤ (∑ u ∈ 𝒰, ‖b u‖ ^ 2) * ∑ u ∈ 𝒰, ‖F u‖ ^ 2 := by
    calc ‖∑ u ∈ 𝒰, b u * F u‖ ^ 2 ≤ (∑ u ∈ 𝒰, ‖b u‖ * ‖F u‖) ^ 2 := by
          refine pow_le_pow_left₀ (norm_nonneg _) ?_ 2
          exact (norm_sum_le _ _).trans (le_of_eq (Finset.sum_congr rfl fun u _ => norm_mul _ _))
      _ ≤ _ := Finset.sum_mul_sq_le_sq_mul_sq _ _ _
  refine hCS.trans (mul_le_mul_of_nonneg_left ?_ (Finset.sum_nonneg fun u _ => by positivity))
  have hdrop : ∑ u ∈ 𝒰, ‖F u‖ ^ 2 ≤ ∑ u ∈ I, ‖F u‖ ^ 2 :=
    Finset.sum_le_sum_of_subset_of_nonneg h𝒰 fun u _ _ => by positivity
  refine hdrop.trans ?_
  have hexp : ∀ u, ((‖F u‖ ^ 2 : ℝ) : ℂ) = ∑ v ∈ 𝒱, ∑ v' ∈ 𝒱,
      a v * (starRingEnd ℂ) (a v') * ((c v u * (starRingEnd ℂ) (c v' u)) *
        eR (φ v u - φ v' u) * (G v (u % Q) * (starRingEnd ℂ) (G v' (u % Q)))) := by
    intro u
    rw [Complex.ofReal_pow, ← Complex.mul_conj']
    simp only [hF, map_sum, map_mul]
    rw [Finset.sum_mul_sum]
    refine Finset.sum_congr rfl fun v _ => Finset.sum_congr rfl fun v' _ => ?_
    rw [eR_sub]; ring
  have hreal : ∑ u ∈ I, ‖F u‖ ^ 2 = ‖∑ u ∈ I, ((‖F u‖ ^ 2 : ℝ) : ℂ)‖ := by
    rw [← Complex.ofReal_sum, Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (Finset.sum_nonneg fun u _ => by positivity)]
  rw [hreal]
  simp_rw [hexp]
  rw [Finset.sum_comm]
  refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun v _ => ?_)
  rw [Finset.sum_comm]
  refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun v' _ => ?_)
  have hsplit : ∑ u ∈ I, a v * (starRingEnd ℂ) (a v') * ((c v u * (starRingEnd ℂ) (c v' u)) *
        eR (φ v u - φ v' u) * (G v (u % Q) * (starRingEnd ℂ) (G v' (u % Q)))) =
      a v * (starRingEnd ℂ) (a v') * ∑ ρ ∈ range Q, (G v ρ * (starRingEnd ℂ) (G v' ρ)) *
        ∑ u ∈ I.filter (fun u => u % Q = ρ),
          (c v u * (starRingEnd ℂ) (c v' u)) * eR (φ v u - φ v' u) := by
    rw [← Finset.mul_sum]
    congr 1
    rw [← Finset.sum_fiberwise_of_maps_to (g := fun u => u % Q) (t := range Q)
      (fun u _ => Finset.mem_range.2 (Nat.mod_lt _ (by omega)))]
    refine Finset.sum_congr rfl fun ρ _ => ?_
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun u hu => ?_
    rw [(Finset.mem_filter.1 hu).2]; ring
  rw [hsplit, norm_mul, norm_mul, Complex.norm_conj]
  gcongr
  refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun ρ _ => ?_)
  rw [norm_mul, norm_mul, Complex.norm_conj]
  have h1 := hG v ρ
  have h2 := hG v' ρ
  calc ‖G v ρ‖ * ‖G v' ρ‖ * ‖∑ u ∈ I.filter (fun u => u % Q = ρ),
        (c v u * (starRingEnd ℂ) (c v' u)) * eR (φ v u - φ v' u)‖
      ≤ 1 * 1 * ‖∑ u ∈ I.filter (fun u => u % Q = ρ),
        (c v u * (starRingEnd ℂ) (c v' u)) * eR (φ v u - φ v' u)‖ := by gcongr
    _ = _ := by ring

/-- **VK along a class with a bounded-variation amplitude.** -/
theorem class_amp_bound :
    ∃ c C : ℝ, 0 < c ∧ 0 ≤ C ∧
      ∀ (Q ρ N M : ℕ) (Y : ℝ) (A : ℕ → ℂ), 1 ≤ Q → ρ < Q → 1 ≤ N → N ≤ M → M ≤ 2 * N →
        2 * (Q : ℝ) ≤ |Y| →
        ‖∑ t ∈ Ioc N M, A t * eR (Y / ((ρ : ℝ) + Q * t))‖ ≤
          (‖A M‖ + ∑ n ∈ Ico (N + 1) M, ‖A (n + 1) - A n‖) *
            (C * ((N : ℝ) * Real.exp (-(c * Real.log (N : ℝ) ^ 3 / Real.log (|Y| / Q) ^ 2)) +
              (N : ℝ) ^ 2 / (|Y| / Q))) := by
  obtain ⟨c, C, hc, hC, hS⟩ := suzuki_AP
  refine ⟨c, C, hc, hC, fun Q ρ N M Y A hQ hρ hN hNM hM hY => ?_⟩
  refine abel_bound A (fun t => eR (Y / ((ρ : ℝ) + Q * t))) N M hNM _ fun j hj1 hj2 => ?_
  unfold psum
  exact hS Q ρ N j Y hQ hρ hN (by omega) hY

end GoldC.QuillonR

#print axioms GoldC.QuillonR.cauchy_class_split_amp
#print axioms GoldC.QuillonR.class_amp_bound
