import PaperB.FixedQ.TwoDimensionalClosure

open scoped BigOperators

namespace PaperB.FixedQ

theorem pureHeightSupportTerm_reflect
    {q a r h : ℕ} (e : Finset ℕ)
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    pureHeightSupportTerm q a h e =
      pureHeightSupportTerm q r h e := by
  by_cases heq : heightPrimePart h e = e
  · have hsel := heightSelectedPairTerm_reflect
      (q := q) (a := a) (r := r) (h := h) e hreflect
    simpa [pureHeightSupportTerm, heightSelectedPairTerm,
      pureLeftPairTerm, heq] using hsel
  · simp [pureHeightSupportTerm, heq]

theorem tsum_pureHeightSupportTerm_reflect
    {q a r h : ℕ}
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    (∑' e : Finset ℕ, pureHeightSupportTerm q a h e) =
      ∑' e : Finset ℕ, pureHeightSupportTerm q r h e := by
  apply tsum_congr
  intro e
  exact pureHeightSupportTerm_reflect e hreflect

theorem heightBoundaryFamily_add_pureHeight_eq_reflectedPureLeft
    {q a r h : ℕ}
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    heightBoundaryFamily q a h +
      (∑' e : Finset ℕ, pureHeightSupportTerm q a h e) =
        pureLeftFamily q r h := by
  unfold heightBoundaryFamily pureLeftFamily
  rw [tsum_heightBoundaryPairTerm_reflect hreflect]
  rw [tsum_pureHeightSupportTerm_reflect hreflect]
  ring

#print axioms pureHeightSupportTerm_reflect
#print axioms tsum_pureHeightSupportTerm_reflect
#print axioms heightBoundaryFamily_add_pureHeight_eq_reflectedPureLeft

end PaperB.FixedQ
