import PaperB.FixedQ.SignedForbiddenThalenFixedQLowSpectral

open scoped BigOperators

namespace PaperB.FixedQ

/-- Finite original-source outer support contribution, preserving the
literal proper-partition discrepancy and original q-fixed row weight. -/
noncomputable def thalenFiniteOuterSourceTerm
    (q a H : ℕ) (e : Finset ℕ) : ℝ :=
  finiteOmegaWeightReal e *
    ordinaryBooleanInteriorDiscrepancy (fixedQLowWeight q a H) H e

/-- Exact finite cutoff localization. Nothing commutes with the cutoff:
the missing small-support signed term remains explicitly present. -/
theorem thalen_finite_exterior_eq_full_sub_small
    (q a H Z : ℕ) (S : Finset ℕ) :
    (∑ e ∈ S.powerset.filter (fun e => Z < primeSetProduct e),
       thalenFiniteOuterSourceTerm q a H e) =
      (∑ e ∈ S.powerset, thalenFiniteOuterSourceTerm q a H e) -
      (∑ e ∈ S.powerset.filter
        (fun e => primeSetProduct e ≤ Z),
        thalenFiniteOuterSourceTerm q a H e) := by
  have hs := Finset.sum_filter_add_sum_filter_not
    S.powerset (fun e => Z < primeSetProduct e)
    (thalenFiniteOuterSourceTerm q a H)
  simp only [not_lt] at hs
  linarith

#print axioms thalen_finite_exterior_eq_full_sub_small

end PaperB.FixedQ
