import PaperB.Analytic.PetermannEtaHarmonicSmoothedSublog
import PaperB.Analytic.PetermannEtaFejerPairs
import PaperB.FixedQ.PrimeReciprocalDyadic

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset

lemma sawSmoothPartialNormBound_le_harmonic
    {S : ℝ} (hS : 1 < S) (H : ℕ) :
    sawSmoothPartialNormBound S H ≤ (harmonic H : ℝ) := by
  rw [sawSmoothPartialNormBound, sawSmoothCoeff_zero hS, norm_zero, zero_add]
  have hterm : ∀ k ∈ Finset.range H,
      ‖sawSmoothCoeff S (k + 1 : ℕ)‖ +
          ‖sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ))‖
        ≤ 1 / ((k + 1 : ℕ) : ℝ) := by
    intro k hk
    let j := k + 1
    have hj : 1 ≤ j := by dsimp [j]; omega
    have hp := sawSmoothCoeff_le_linear hS
      (show (j : ℤ) ≠ 0 by exact_mod_cast (show j ≠ 0 by omega))
    have hn := sawSmoothCoeff_le_linear hS
      (show (-(j : ℤ)) ≠ 0 by
        simp [show j ≠ 0 by omega])
    have hjR : 0 < (j : ℝ) := by exact_mod_cast (show 0 < j by omega)
    have hpi : (1 : ℝ) ≤ Real.pi := by
      linarith [Real.one_le_pi_div_two]
    have habsp : |((j : ℤ) : ℝ)| = (j : ℝ) := by
      simp [abs_of_pos hjR]
    have habsn : |((-(j : ℤ) : ℤ) : ℝ)| = (j : ℝ) := by
      simp [abs_of_pos hjR]
    rw [habsp] at hp
    rw [habsn] at hn
    have hden : (j : ℝ) ≤ Real.pi * (j : ℝ) := by
      simpa only [one_mul] using mul_le_mul_of_nonneg_right hpi hjR.le
    have hinv : 1 / (Real.pi * (j : ℝ)) ≤ 1 / (j : ℝ) := by
      exact one_div_le_one_div_of_le hjR hden
    have hpair :
        ‖sawSmoothCoeff S (j : ℤ)‖ +
            ‖sawSmoothCoeff S (-(j : ℤ))‖
          ≤ 1 / (Real.pi * (j : ℝ)) := by
      have heq :
          2 * (1 / (2 * Real.pi * (j : ℝ))) =
            1 / (Real.pi * (j : ℝ)) := by
        field_simp [Real.pi_ne_zero, ne_of_gt hjR]
      calc
        ‖sawSmoothCoeff S (j : ℤ)‖ +
            ‖sawSmoothCoeff S (-(j : ℤ))‖
          ≤ 2 * (1 / (2 * Real.pi * (j : ℝ))) := by linarith
        _ = 1 / (Real.pi * (j : ℝ)) := heq
    simpa [j] using hpair.trans hinv
  calc
    (∑ k ∈ Finset.range H,
      (‖sawSmoothCoeff S (k + 1 : ℕ)‖ +
        ‖sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ))‖))
      ≤ ∑ k ∈ Finset.range H, 1 / ((k + 1 : ℕ) : ℝ) :=
        Finset.sum_le_sum hterm
    _ = (harmonic H : ℝ) := by
      simpa [shiftedHarmonicReal] using shiftedHarmonicReal_eq_harmonic H

lemma harmonic_pow_six_le
    (N : ℕ) (hN : 1 ≤ N) :
    (harmonic (N ^ 6) : ℝ) ≤ 1 + 2 * (N : ℝ) ^ 3 := by
  have hh := harmonic_le_one_add_log (N ^ 6)
  have hpos : 0 < N ^ 6 := by positivity
  have hlog := log_nat_le_two_sqrt_nat hpos
  have hsqrt :
      Real.sqrt ((N ^ 6 : ℕ) : ℝ) = (N : ℝ) ^ 3 := by
    have hN0 : 0 ≤ (N : ℝ) := by positivity
    rw [show ((N ^ 6 : ℕ) : ℝ) = ((N : ℝ) ^ 3) ^ 2 by
      norm_num [pow_succ]; ring]
    rw [Real.sqrt_sq_eq_abs, abs_of_nonneg (pow_nonneg hN0 3)]
  rw [hsqrt] at hlog
  linarith

set_option maxHeartbeats 1000000 in
theorem etaHarmonicSawtoothSpec_of_pos
    (q : ℕ) (hq : 0 < q) :
    EtaHarmonicSawtoothSpec q := by
  letI : NeZero (Nat.lcm 6 q) :=
    ⟨Nat.ne_of_gt (Nat.lcm_pos (by norm_num) hq)⟩
  intro eps heps
  obtain ⟨N, hNgt⟩ := exists_nat_gt (max 2 (200 / eps))
  have hN2 : 2 ≤ N := by
    have hN2lt : 2 < N := by
      exact_mod_cast (lt_of_le_of_lt (le_max_left (2 : ℝ) (200 / eps)) hNgt)
    omega
  have hNpos : 0 < N := by omega
  have hNR : 0 < (N : ℝ) := by exact_mod_cast hNpos
  have hNbudget : 200 / eps < (N : ℝ) := by
    exact lt_of_le_of_lt (le_max_right (2 : ℝ) (200 / eps)) hNgt
  have hmulN : 200 < eps * (N : ℝ) := by
    have h := (div_lt_iff₀ heps).mp hNbudget
    simpa [mul_comm] using h
  let J : ℕ := N ^ 4
  let H : ℕ := N ^ 6
  let S : ℝ := 8 * (J : ℝ)
  let beta : ℝ := 1 / (J : ℝ)
  have hN1 : 1 ≤ N := by omega
  have hJ1 : 1 ≤ J := by
    dsimp [J]
    exact one_le_pow₀ hN1
  have hH1 : 1 ≤ H := by
    dsimp [H]
    exact one_le_pow₀ hN1
  have hS : 1 < S := by
    dsimp [S]
    have : (1 : ℝ) ≤ (J : ℝ) := by exact_mod_cast hJ1
    nlinarith
  have hbeta : 0 < beta := by
    dsimp [beta, J]
    positivity
  obtain ⟨Aadd, hAadd1, hadd⟩ :=
    etaHarmonicAdditiveMode_scaled_uniform_sublog hbeta J
  obtain ⟨Asm, hAsm0, hsm⟩ :=
    etaHarmonicSmoothedSum_scaled_uniform_sublog
      (show 0 < eps / 3 by positivity) q H hS
  let A0 : ℝ := max (Aadd : ℝ) (max Asm (Real.exp 1))
  refine ⟨A0, ?_, ?_⟩
  · dsimp [A0]
    have he : Real.exp 1 ≤ max Asm (Real.exp 1) := le_max_right _ _
    have hm : max Asm (Real.exp 1) ≤ max (Aadd : ℝ) (max Asm (Real.exp 1)) :=
      le_max_right _ _
    exact lt_of_lt_of_le (Real.exp_pos 1) (he.trans hm)
  · intro chi r A Y hA0A hY1 hYA
    have hAadd : (Aadd : ℝ) ≤ A :=
      (le_max_left (Aadd : ℝ) (max Asm (Real.exp 1))).trans hA0A
    have hAsm : Asm ≤ A := by
      exact (le_max_left Asm (Real.exp 1)).trans
        ((le_max_right (Aadd : ℝ) (max Asm (Real.exp 1))).trans hA0A)
    have hAexp : Real.exp 1 ≤ A := by
      exact (le_max_right Asm (Real.exp 1)).trans
        ((le_max_right (Aadd : ℝ) (max Asm (Real.exp 1))).trans hA0A)
    have hA1 : (1 : ℝ) ≤ A := by
      have he1 : (1 : ℝ) ≤ Real.exp 1 := by
        rw [← Real.exp_zero]
        exact Real.exp_le_exp.mpr (by norm_num)
      exact he1.trans hAexp
    have hlog1 : 1 ≤ Real.log A := by
      have := Real.log_le_log (Real.exp_pos 1) hAexp
      simpa using this
    have hlog0 : 0 ≤ Real.log A := by linarith
    have hsm' :
        ‖etaHarmonicSmoothedSum q chi r A Y H S‖
          ≤ (eps / 3) * Real.log A :=
      hsm chi r A Y hAsm hY1 hYA
    have hmode :
        ∀ {A' : ℝ} {j : ℕ},
          1 ≤ j → j ≤ J →
          |A'| = (j : ℝ) * A →
          ‖etaHarmonicAdditiveMode Y A' 0‖ ≤ beta * Real.log A := by
      intro A' j hj1 hjJ hAbs
      exact hadd hAadd hY1 hYA hj1 hjJ hAbs
    have hnear :=
      etaHarmonicNearJumpMass_fejer_budget
        (q := q) (Y := Y) (J := J) hJ1
        (A := A) (beta := beta) (r := r)
        hY1 hA1 hYA hbeta.le hlog1 hmode
    have hB := sawSmoothPartialNormBound_le_harmonic hS H
    have hBh := harmonic_pow_six_le N (by omega)
    have hBbound :
        sawSmoothPartialNormBound S H ≤ 1 + 2 * (N : ℝ)^3 := by
      exact hB.trans (by simpa [H] using hBh)
    have hharmY : (harmonic Y : ℝ) ≤ 2 * Real.log A := by
      have hHY := harmonic_le_one_add_log Y
      have hlogY : Real.log (Y : ℝ) ≤ Real.log A := by
        have hYpos : 0 < (Y : ℝ) := by exact_mod_cast (show 0 < Y by omega)
        exact Real.log_le_log hYpos hYA
      linarith
    have hpi : (1 : ℝ) ≤ Real.pi := by
      linarith [Real.one_le_pi_div_two]
    have hpi2 : (1 : ℝ) ≤ Real.pi ^ 2 := by
      nlinarith
    have hAwayFac :
        S / (Real.pi ^ 2 * H) ≤ 8 / ((N : ℝ)^2) := by
      dsimp [S, H, J]
      have hNne : (N : ℝ) ≠ 0 := ne_of_gt hNR
      have hpiPos : 0 < Real.pi ^ 2 := sq_pos_of_pos Real.pi_pos
      rw [div_le_iff₀ (mul_pos hpiPos (by positivity : (0 : ℝ) < (N ^ 6 : ℕ)))]
      push_cast
      field_simp [hNne]
      nlinarith [hpi2]
    have hNearCoef :
        (1 / 2 + sawSmoothPartialNormBound S H) *
            (8 / (J : ℝ) + 4 * beta)
          ≤ 50 / (N : ℝ) := by
      have hN1R : (1 : ℝ) ≤ N := by exact_mod_cast (show 1 ≤ N by omega)
      have hJcast : (J : ℝ) = (N : ℝ)^4 := by simp [J]
      rw [hJcast]
      dsimp [beta]
      rw [hJcast]
      have hN4pos : 0 < (N : ℝ)^4 := by positivity
      have hleft :
          1 / 2 + sawSmoothPartialNormBound S H
            ≤ 3 / 2 + 2 * (N : ℝ)^3 := by linarith
      calc
        (1 / 2 + sawSmoothPartialNormBound S H) *
            (8 / ((N : ℝ)^4) + 4 * (1 / ((N : ℝ)^4)))
          ≤ (3 / 2 + 2 * (N : ℝ)^3) *
              (8 / ((N : ℝ)^4) + 4 * (1 / ((N : ℝ)^4))) := by
                apply mul_le_mul_of_nonneg_right hleft
                positivity
        _ = 18 / ((N : ℝ)^4) + 24 / (N : ℝ) := by
              field_simp [ne_of_gt hNR]
              ring
        _ ≤ 50 / (N : ℝ) := by
              have hN3 : (1 : ℝ) ≤ (N : ℝ)^3 := one_le_pow₀ hN1R
              have hN4 : (N : ℝ) ≤ (N : ℝ)^4 := by
                calc
                  (N : ℝ) = (N : ℝ) * 1 := by ring
                  _ ≤ (N : ℝ) * ((N : ℝ)^3) :=
                    mul_le_mul_of_nonneg_left hN3 hNR.le
                  _ = (N : ℝ)^4 := by ring
              have hinv : 1 / ((N : ℝ)^4) ≤ 1 / (N : ℝ) :=
                one_div_le_one_div_of_le hNR hN4
              calc
                18 / ((N : ℝ)^4) + 24 / (N : ℝ)
                  ≤ 18 / (N : ℝ) + 24 / (N : ℝ) := by
                    have hx : 18 / ((N : ℝ)^4) ≤ 18 / (N : ℝ) := by
                      simpa [div_eq_mul_inv] using
                        mul_le_mul_of_nonneg_left hinv (by norm_num : (0 : ℝ) ≤ 18)
                    exact add_le_add hx le_rfl
                _ ≤ 50 / (N : ℝ) := by
                    have hpos : 0 < (N : ℝ) := hNR
                    field_simp [hpos.ne']
                    nlinarith
    have hsmall1 : 16 / ((N : ℝ)^2) ≤ eps / 6 := by
      have hN1 : (1 : ℝ) ≤ N := by exact_mod_cast (show 1 ≤ N by omega)
      have hN2ge : (N : ℝ)^2 ≥ (N : ℝ) := by nlinarith
      have hbase : 16 / (N : ℝ) ≤ eps / 6 := by
        rw [div_le_iff₀ hNR, div_eq_mul_inv] at *
        nlinarith
      exact (div_le_div_of_nonneg_left (by norm_num) hNR hN2ge).trans hbase
    have hsmall2 : 50 / (N : ℝ) ≤ eps / 3 := by
      rw [div_le_iff₀ hNR]
      nlinarith
    have hrem0 := etaHarmonicSmoothingRemainder_le_away_add_near
      hS hH1 q Y chi r A
    have hharm0 : 0 ≤ (harmonic Y : ℝ) := by
      exact_mod_cast (harmonic_pos (show Y ≠ 0 by omega)).le
    have haway0 : 0 ≤ 8 / ((N : ℝ)^2) := by positivity
    have hnearFac0 :
        0 ≤ 1 / 2 + sawSmoothPartialNormBound S H := by
      have := sawSmoothPartialNormBound_nonneg S H
      positivity
    have hAwayTerm :
        (S / (Real.pi ^ 2 * H)) * (harmonic Y : ℝ)
          ≤ (16 / ((N : ℝ)^2)) * Real.log A := by
      calc
        (S / (Real.pi ^ 2 * H)) * (harmonic Y : ℝ)
          ≤ (8 / ((N : ℝ)^2)) * (harmonic Y : ℝ) :=
            mul_le_mul_of_nonneg_right hAwayFac hharm0
        _ ≤ (8 / ((N : ℝ)^2)) * (2 * Real.log A) :=
            mul_le_mul_of_nonneg_left hharmY haway0
        _ = (16 / ((N : ℝ)^2)) * Real.log A := by ring
    have hnearS :
        etaHarmonicNearJumpMass q A r Y S
          ≤ (8 / (J : ℝ) + 4 * beta) * Real.log A := by
      simpa [S] using hnear
    have hNearTerm :
        (1 / 2 + sawSmoothPartialNormBound S H) *
            etaHarmonicNearJumpMass q A r Y S
          ≤ (eps / 3) * Real.log A := by
      calc
        (1 / 2 + sawSmoothPartialNormBound S H) *
            etaHarmonicNearJumpMass q A r Y S
          ≤ (1 / 2 + sawSmoothPartialNormBound S H) *
              ((8 / (J : ℝ) + 4 * beta) * Real.log A) :=
            mul_le_mul_of_nonneg_left hnearS hnearFac0
        _ = ((1 / 2 + sawSmoothPartialNormBound S H) *
              (8 / (J : ℝ) + 4 * beta)) * Real.log A := by ring
        _ ≤ (50 / (N : ℝ)) * Real.log A :=
            mul_le_mul_of_nonneg_right hNearCoef hlog0
        _ ≤ (eps / 3) * Real.log A :=
            mul_le_mul_of_nonneg_right hsmall2 hlog0
    have hrem :
        ‖etaHarmonicSmoothingRemainder q chi r A Y H S‖
          ≤ (2 * eps / 3) * Real.log A := by
      calc
        ‖etaHarmonicSmoothingRemainder q chi r A Y H S‖
          ≤ (S / (Real.pi ^ 2 * H)) * (harmonic Y : ℝ) +
              (1 / 2 + sawSmoothPartialNormBound S H) *
                etaHarmonicNearJumpMass q A r Y S := hrem0
        _ ≤ (16 / ((N : ℝ)^2)) * Real.log A +
              (eps / 3) * Real.log A := add_le_add hAwayTerm hNearTerm
        _ ≤ (eps / 6) * Real.log A +
              (eps / 3) * Real.log A := by
                exact add_le_add
                  (mul_le_mul_of_nonneg_right hsmall1 hlog0) le_rfl
        _ ≤ (2 * eps / 3) * Real.log A := by
              have : eps / 6 + eps / 3 ≤ 2 * eps / 3 := by linarith
              nlinarith [mul_nonneg heps.le hlog0]
    rw [etaHarmonicSawtoothSum_eq_smoothed_add_remainder]
    calc
      ‖etaHarmonicSmoothedSum q chi r A Y H S +
          etaHarmonicSmoothingRemainder q chi r A Y H S‖
        ≤ ‖etaHarmonicSmoothedSum q chi r A Y H S‖ +
            ‖etaHarmonicSmoothingRemainder q chi r A Y H S‖ :=
          norm_add_le _ _
      _ ≤ (eps / 3) * Real.log A +
            (2 * eps / 3) * Real.log A := add_le_add hsm' hrem
      _ = eps * Real.log A := by ring

#print axioms etaHarmonicSawtoothSpec_of_pos

end PaperB.Analytic
