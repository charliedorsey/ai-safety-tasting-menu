import PaperB.FixedQ.FixedConductorCompletion
import PaperB.Analytic.FixedBetaUniformMajorant
import PaperB.Analytic.PetermannFixedBetaBranchScale

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

theorem fixedBeta_middle_source_window_uniform_majorant
    {beta0 A xi : ℝ} {W B : ℕ}
    (hb00 : 0 < beta0) (hb01 : beta0 < 1)
    (hA1 : 1 < A) (hW1 : 1 < W)
    (hlow : A ^ beta0 ≤ (W : ℝ))
    (hhigh : (W : ℝ) ≤ A ^ (3 / 4 : ℝ))
    (hKW : fixedBetaNaturalOrder beta0 ≤ W)
    (hWB : W ≤ B) (hB2 : B ≤ 2 * W) :
    ‖∑ n ∈ Finset.Icc W B,
        eR (A / (n : ℝ) + xi * (n : ℝ))‖
      ≤ 1 + fixedBetaUniformMajorantConst beta0 *
        (W : ℝ) ^ fixedBetaUniformExponent
          (fixedBetaNaturalOrder beta0) := by
  let beta : ℝ := Real.log (W : ℝ) / Real.log A
  have hApos : 0 < A := lt_trans zero_lt_one hA1
  have hWpos : (0 : ℝ) < W := by exact_mod_cast (lt_trans Nat.zero_lt_one hW1)
  have hlogA : 0 < Real.log A := Real.log_pos hA1
  have hlogA0 : Real.log A ≠ 0 := ne_of_gt hlogA
  have hscale : (W : ℝ) = A ^ beta := by
    rw [Real.rpow_def_of_pos hApos]
    have hexp :
        Real.log A * beta = Real.log (W : ℝ) := by
      dsimp [beta]
      field_simp [hlogA0]
    rw [hexp, Real.exp_log hWpos]
  have hbb : beta0 ≤ beta := by
    have hrpow : A ^ beta0 ≤ A ^ beta := by
      simpa [hscale] using hlow
    exact (Real.rpow_le_rpow_left_iff hA1).mp hrpow
  have hb34 : beta ≤ 3 / 4 := by
    have hrpow : A ^ beta ≤ A ^ (3 / 4 : ℝ) := by
      simpa [hscale] using hhigh
    exact (Real.rpow_le_rpow_left_iff hA1).mp hrpow
  have hWposNat : 0 < W := by omega
  have hmaj :=
    fixedBeta_sourceScale_interval_uniform_majorant
      hb00 hb01 hbb hb34 xi W B hKW hWposNat hWB hB2
  have hbeta0 : 0 < beta := lt_of_lt_of_le hb00 hbb
  have hsource : A = (W : ℝ) ^ beta⁻¹ :=
    source_scale_rpow_inversion hApos hbeta0.ne' hscale
  rw [← hsource] at hmaj
  exact hmaj

private lemma sum_range_shift_eq_Icc_middle
    (f : ℕ → ℂ) (W D : ℕ) (hWD : W ≤ D) :
    (∑ j ∈ Finset.range (D - W + 1), f (W + j)) =
      ∑ n ∈ Finset.Icc W D, f n := by
  apply Finset.sum_bij (fun j _ => W + j)
  · intro j hj
    rw [Finset.mem_range] at hj
    rw [Finset.mem_Icc]
    omega
  · intro j1 hj1 j2 hj2 h
    omega
  · intro n hn
    rw [Finset.mem_Icc] at hn
    refine ⟨n - W, ?_, ?_⟩
    · rw [Finset.mem_range]
      omega
    · omega
  · intro j hj
    rfl

theorem fixedBeta_middle_source_window_reciprocal_weight_uniform
    {beta0 A xi : ℝ} {W B : ℕ}
    (hb00 : 0 < beta0) (hb01 : beta0 < 1)
    (hA1 : 1 < A) (hW1 : 1 < W)
    (hlow : A ^ beta0 ≤ (W : ℝ))
    (hhigh : (W : ℝ) ≤ A ^ (3 / 4 : ℝ))
    (hKW : fixedBetaNaturalOrder beta0 ≤ W)
    (hWB : W ≤ B) (hB2 : B ≤ 2 * W) :
    ‖∑ m ∈ Finset.Icc W B,
        (m : ℂ)⁻¹ * eR (A / (m : ℝ) + xi * (m : ℝ))‖
      ≤ 2 * (1 + fixedBetaUniformMajorantConst beta0 *
          (W : ℝ) ^ fixedBetaUniformExponent
            (fixedBetaNaturalOrder beta0)) / (W : ℝ) := by
  let C : ℝ := 1 + fixedBetaUniformMajorantConst beta0 *
      (W : ℝ) ^ fixedBetaUniformExponent (fixedBetaNaturalOrder beta0)
  have hC0 : 0 ≤ C := by
    dsimp [C]
    have hc := fixedBetaUniformMajorantConst_nonneg beta0
    positivity
  let L := B - W + 1
  let c : ℕ → ℂ := fun j =>
    eR (A / ((W + j : ℕ) : ℝ) + xi * ((W + j : ℕ) : ℝ))
  have hprefix : ∀ k ≤ L,
      ‖∑ j ∈ Finset.range k, c j‖ ≤ C := by
    intro k hk
    by_cases hk0 : k = 0
    · subst k
      simp [C]
      exact hC0
    · have hk1 : 1 ≤ k := Nat.one_le_iff_ne_zero.mpr hk0
      let D := W + k - 1
      have hWD : W ≤ D := by dsimp [D]; omega
      have hDB : D ≤ B := by dsimp [D, L] at *; omega
      have hD2 : D ≤ 2 * W := hDB.trans hB2
      have hmain :=
        fixedBeta_middle_source_window_uniform_majorant
          (xi := xi) hb00 hb01 hA1 hW1 hlow hhigh hKW hWD hD2
      have hlen : D - W + 1 = k := by dsimp [D]; omega
      change ‖∑ j ∈ Finset.range k,
        eR (A / ((W + j : ℕ) : ℝ) + xi * ((W + j : ℕ) : ℝ))‖ ≤ C
      rw [← hlen, sum_range_shift_eq_Icc_middle
        (fun n => eR (A / (n : ℝ) + xi * (n : ℝ))) W D hWD]
      simpa [C] using hmain
  have hW0 : 0 < W := by omega
  have hps := partialSummation_reciprocal_weight_le
    W L hW0 c hC0 hprefix
  have hlen : L = B - W + 1 := rfl
  have hsum :
      (∑ j ∈ Finset.range L, c j * reciprocalNatWeight W j) =
        ∑ m ∈ Finset.Icc W B,
          (m : ℂ)⁻¹ * eR (A / (m : ℝ) + xi * (m : ℝ)) := by
    dsimp [L]
    rw [← sum_range_shift_eq_Icc_middle
      (fun m => (m : ℂ)⁻¹ *
        eR (A / (m : ℝ) + xi * (m : ℝ))) W B hWB]
    apply Finset.sum_congr rfl
    intro j hj
    dsimp [c, reciprocalNatWeight]
    push_cast
    ring
  rw [hsum] at hps
  simpa [C] using hps



theorem reciprocal_weight_dyadic_inv_rpow_aggregate
    (f : ℕ → ℂ) {a c theta : ℝ}
    (ha : 0 ≤ a) (hc : 0 ≤ c) (htheta : theta < 1)
    {M N : ℕ} (hM : 0 < M) (hMN : M ≤ N)
    (hshell : ∀ W B : ℕ,
      M ≤ W → 0 < W → W ≤ B → B ≤ 2 * W → B ≤ N →
      ‖∑ m ∈ Finset.Icc W B, f m‖
        ≤ a / (W : ℝ) + c * (W : ℝ) ^ (theta - 1)) :
    ‖∑ m ∈ Finset.Icc M N, f m‖
      ≤ 2 * a / (M : ℝ) +
          (c / (1 - (2 : ℝ) ^ (theta - 1))) *
            (M : ℝ) ^ (theta - 1) := by
  let e : ℝ := theta - 1
  let q : ℝ := (2 : ℝ) ^ e
  have he : e < 0 := by dsimp [e]; linarith
  have hq0 : 0 < q := by
    dsimp [q]
    exact Real.rpow_pos_of_pos (by norm_num) _
  have hq1 : q < 1 := by
    dsimp [q]
    exact Real.rpow_lt_one_of_one_lt_of_neg (by norm_num) he
  have hden : 0 < 1 - q := sub_pos.mpr hq1
  generalize hgap : N - M = gap
  induction gap using Nat.strong_induction_on generalizing M N with
  | h gap ih =>
      by_cases hsmall : N ≤ 2 * M
      · have hs := hshell M N le_rfl hM hMN hsmall le_rfl
        have hMr : (0 : ℝ) < M := by exact_mod_cast hM
        have hpow0 : 0 ≤ (M : ℝ) ^ e := Real.rpow_nonneg hMr.le _
        have hcoef0 : 0 ≤ c / (1 - q) := by positivity
        have hqnon : 0 ≤ q := hq0.le
        calc
          ‖∑ m ∈ Finset.Icc M N, f m‖
              ≤ a / (M : ℝ) + c * (M : ℝ) ^ e := by
                simpa [e] using hs
          _ ≤ 2 * a / (M : ℝ) +
                (c / (1 - q)) * (M : ℝ) ^ e := by
            have haM : 0 ≤ a / (M : ℝ) := by positivity
            have hcfrac : c ≤ c / (1 - q) := by
              have hdenle : 1 - q ≤ 1 := by linarith
              exact (le_div_iff₀ hden).2 (by
                nlinarith [mul_le_mul_of_nonneg_left hdenle hc])
            apply _root_.add_le_add
            · calc
                a / (M : ℝ) ≤ a / (M : ℝ) + a / (M : ℝ) :=
                  le_add_of_nonneg_right haM
                _ = 2 * a / (M : ℝ) := by ring
            · exact mul_le_mul_of_nonneg_right hcfrac hpow0
      · have h2MN : 2 * M < N := lt_of_not_ge hsmall
        let M' := 2 * M + 1
        have hMp : 0 < M' := by dsimp [M']; omega
        have hMpN : M' ≤ N := by dsimp [M']; omega
        have hgaplt : N - M' < gap := by
          rw [← hgap]
          dsimp [M']
          omega
        have hs := hshell M (2 * M) le_rfl hM (by omega) (by omega) (by omega)
        have hshell' : ∀ W B : ℕ,
            M' ≤ W → 0 < W → W ≤ B → B ≤ 2 * W → B ≤ N →
            ‖∑ m ∈ Finset.Icc W B, f m‖
              ≤ a / (W : ℝ) + c * (W : ℝ) ^ (theta - 1) := by
          intro W B hMpW hW hWB hB2 hBN
          have hMW : M ≤ W := by
            dsimp [M'] at hMpW
            omega
          exact hshell W B hMW hW hWB hB2 hBN
        have hi := ih (N - M') hgaplt
          (M := M') (N := N) hMp hMpN hshell' rfl
        have hdis : Disjoint (Finset.Icc M (2 * M)) (Finset.Icc M' N) := by
          rw [Finset.disjoint_left]
          intro x hx1 hx2
          rw [Finset.mem_Icc] at hx1 hx2
          dsimp [M'] at hx2
          omega
        have hunion :
            Finset.Icc M N =
              Finset.Icc M (2 * M) ∪ Finset.Icc M' N := by
          ext x
          simp only [Finset.mem_Icc, Finset.mem_union]
          dsimp [M']
          omega
        have hMr : (0 : ℝ) < M := by exact_mod_cast hM
        have hMpr : (0 : ℝ) < M' := by exact_mod_cast hMp
        have hMpge : (2 : ℝ) * (M : ℝ) ≤ (M' : ℝ) := by
          dsimp [M']
          push_cast
          linarith
        have hinv :
            2 * a / (M' : ℝ) ≤ a / (M : ℝ) := by
          rw [div_le_iff₀ hMpr]
          have hm := mul_le_mul_of_nonneg_left hMpge ha
          field_simp [hMr.ne']
          nlinarith [hm]
        have hrpow :
            (M' : ℝ) ^ e ≤ q * (M : ℝ) ^ e := by
          have h2Mpos : (0 : ℝ) < 2 * (M : ℝ) := by positivity
          have hanti :=
            Real.rpow_le_rpow_of_nonpos h2Mpos hMpge he.le
          have hsplit :
              (2 * (M : ℝ)) ^ e = q * (M : ℝ) ^ e := by
            rw [Real.mul_rpow (by norm_num : (0 : ℝ) ≤ 2) hMr.le]
          simpa [hsplit] using hanti
        rw [hunion, Finset.sum_union hdis]
        calc
          ‖(∑ m ∈ Finset.Icc M (2 * M), f m) +
              (∑ m ∈ Finset.Icc M' N, f m)‖
            ≤ ‖∑ m ∈ Finset.Icc M (2 * M), f m‖ +
                ‖∑ m ∈ Finset.Icc M' N, f m‖ := norm_add_le _ _
          _ ≤ (a / (M : ℝ) + c * (M : ℝ) ^ e) +
                (2 * a / (M' : ℝ) +
                  (c / (1 - q)) * (M' : ℝ) ^ e) := by
            exact add_le_add (by simpa [e] using hs) (by simpa [e, q] using hi)
          _ ≤ 2 * a / (M : ℝ) +
                (c / (1 - q)) * (M : ℝ) ^ e := by
            have hpowM : 0 ≤ (M : ℝ) ^ e := Real.rpow_nonneg hMr.le _
            have hcoef : 0 ≤ c / (1 - q) := by positivity
            have htailpow :
                (c / (1 - q)) * (M' : ℝ) ^ e ≤
                  (c / (1 - q)) * (q * (M : ℝ) ^ e) :=
              mul_le_mul_of_nonneg_left hrpow hcoef
            have hgeom :
                c * (M : ℝ) ^ e +
                    (c / (1 - q)) * (q * (M : ℝ) ^ e) =
                  (c / (1 - q)) * (M : ℝ) ^ e := by
              field_simp [ne_of_gt hden]
              ring
            have hfirst :
                a / (M : ℝ) + 2 * a / (M' : ℝ) ≤
                  2 * a / (M : ℝ) := by
              calc
                a / (M : ℝ) + 2 * a / (M' : ℝ)
                    ≤ a / (M : ℝ) + a / (M : ℝ) :=
                  (by
                    simpa [add_comm] using
                      add_le_add_left hinv (a / (M : ℝ)))
                _ = 2 * a / (M : ℝ) := by ring
            calc
              (a / (M : ℝ) + c * (M : ℝ) ^ e) +
                  (2 * a / (M' : ℝ) +
                    (c / (1 - q)) * (M' : ℝ) ^ e)
                = (a / (M : ℝ) + 2 * a / (M' : ℝ)) +
                    (c * (M : ℝ) ^ e +
                      (c / (1 - q)) * (M' : ℝ) ^ e) := by ring
              _ ≤ (2 * a / (M : ℝ)) +
                    (c * (M : ℝ) ^ e +
                      (c / (1 - q)) * (q * (M : ℝ) ^ e)) :=
                add_le_add hfirst (add_le_add_right htailpow _)
              _ = 2 * a / (M : ℝ) +
                    (c / (1 - q)) * (M : ℝ) ^ e := by rw [hgeom]
      <;> simpa [e, q]




theorem fixedBeta_middle_reciprocal_weight_tail_bound
    {beta0 A xi : ℝ} {M N : ℕ}
    (hb00 : 0 < beta0) (hb01 : beta0 < 1)
    (hA1 : 1 < A)
    (hM1 : 1 < M)
    (hlow : A ^ beta0 ≤ (M : ℝ))
    (hhigh : (N : ℝ) ≤ A ^ (3 / 4 : ℝ))
    (hKM : fixedBetaNaturalOrder beta0 ≤ M)
    (hMN : M ≤ N) :
    ‖∑ m ∈ Finset.Icc M N,
        (m : ℂ)⁻¹ * eR (A / (m : ℝ) + xi * (m : ℝ))‖
      ≤
      4 / (M : ℝ) +
        ((2 * fixedBetaUniformMajorantConst beta0) /
          (1 - (2 : ℝ) ^
            (fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) - 1))) *
          (M : ℝ) ^
            (fixedBetaUniformExponent (fixedBetaNaturalOrder beta0) - 1) := by
  let theta := fixedBetaUniformExponent (fixedBetaNaturalOrder beta0)
  let C := fixedBetaUniformMajorantConst beta0
  have htheta : theta < 1 := by
    dsimp [theta]
    exact fixedBetaUniformExponent_lt_one _
  have hM : 0 < M := by omega
  have ha : 0 ≤ (2 : ℝ) := by norm_num
  have hc : 0 ≤ 2 * C := by
    exact mul_nonneg (by norm_num)
      (fixedBetaUniformMajorantConst_nonneg beta0)
  have hshell : ∀ W B : ℕ,
      M ≤ W → 0 < W → W ≤ B → B ≤ 2 * W → B ≤ N →
      ‖∑ m ∈ Finset.Icc W B,
          (m : ℂ)⁻¹ * eR (A / (m : ℝ) + xi * (m : ℝ))‖
        ≤ 2 / (W : ℝ) +
          (2 * C) * (W : ℝ) ^ (theta - 1) := by
    intro W B hMW hW hWB hB2 hBN
    have hW1 : 1 < W := lt_of_lt_of_le hM1 hMW
    have hlowW : A ^ beta0 ≤ (W : ℝ) := by
      exact hlow.trans (by exact_mod_cast hMW)
    have hhighW : (W : ℝ) ≤ A ^ (3 / 4 : ℝ) := by
      have hWN : W ≤ N := hWB.trans hBN
      have hWNr : (W : ℝ) ≤ (N : ℝ) := by exact_mod_cast hWN
      exact hWNr.trans hhigh
    have hKW : fixedBetaNaturalOrder beta0 ≤ W := hKM.trans hMW
    have hs := fixedBeta_middle_source_window_reciprocal_weight_uniform
      (xi := xi) hb00 hb01 hA1 hW1 hlowW hhighW hKW hWB hB2
    calc
      ‖∑ m ∈ Finset.Icc W B,
          (m : ℂ)⁻¹ * eR (A / (m : ℝ) + xi * (m : ℝ))‖
        ≤ 2 * (1 + C * (W : ℝ) ^ theta) / (W : ℝ) := by
          simpa [C, theta] using hs
      _ = 2 / (W : ℝ) +
          (2 * C) * (W : ℝ) ^ (theta - 1) := by
          have hWr : (0 : ℝ) < W := by exact_mod_cast hW
          rw [Real.rpow_sub_one (ne_of_gt hWr)]
          field_simp [ne_of_gt hWr]
  have hagg := reciprocal_weight_dyadic_inv_rpow_aggregate
    (f := fun m => (m : ℂ)⁻¹ *
      eR (A / (m : ℝ) + xi * (m : ℝ)))
    ha hc htheta hM hMN hshell
  have hagg' := hagg
  dsimp [C, theta] at hagg' ⊢
  convert hagg' using 1 <;> ring

#print axioms fixedBeta_middle_source_window_reciprocal_weight_uniform
#print axioms reciprocal_weight_dyadic_inv_rpow_aggregate
#print axioms fixedBeta_middle_reciprocal_weight_tail_bound

end PaperB.Analytic
