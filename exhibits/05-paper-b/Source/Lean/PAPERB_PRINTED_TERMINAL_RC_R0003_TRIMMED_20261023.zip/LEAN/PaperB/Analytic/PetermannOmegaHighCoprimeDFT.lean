import PaperB.Analytic.PetermannOmegaHighNonzeroDFT
import PaperB.Analytic.PetermannOmegaHighZeroMode
import PaperB.Analytic.CharacterAdditiveTwist
import PaperB.FixedQ.EtaLinearConvolution

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset

lemma coprimeIndicator_eq_principalCharacter
    (q n : ℕ) [NeZero (6 * q)] (hn0 : n ≠ 0) :
    (((coprimeIndicatorArithmetic q n : ℝ) : ℂ)) =
      (1 : DirichletCharacter ℂ (6 * q)) n := by
  rw [coprimeIndicatorArithmetic_apply, coprimeIndicatorCoeff, if_neg hn0]
  by_cases hc : n.Coprime (6 * q)
  · rw [if_pos hc]
    have hu : IsUnit (n : ZMod (6 * q)) :=
      (ZMod.isUnit_iff_coprime n (6 * q)).2 hc
    rw [MulChar.one_apply hu]
    norm_num
  · rw [if_neg hc]
    have hnu : ¬ IsUnit (n : ZMod (6 * q)) := by
      exact fun hu => hc ((ZMod.isUnit_iff_coprime n (6 * q)).1 hu)
    rw [MulChar.apply_eq_zero_iff.mpr hnu]
    norm_num

lemma coprimeIndicator_additive_eR_inversion
    (q n : ℕ) [NeZero (6 * q)] (hn0 : n ≠ 0) :
    (((coprimeIndicatorArithmetic q n : ℝ) : ℂ)) =
      ((6 * q : ℕ) : ℂ)⁻¹ *
        ∑ a : ZMod (6 * q),
          eR (((a.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (n : ℝ)) *
            ZMod.dft
              (fun x : ZMod (6 * q) =>
                (1 : DirichletCharacter ℂ (6 * q)) x) a := by
  rw [coprimeIndicator_eq_principalCharacter q n hn0]
  exact dirichletCharacter_additive_eR_inversion
    (1 : DirichletCharacter ℂ (6 * q)) n

#print axioms coprimeIndicator_eq_principalCharacter
#print axioms coprimeIndicator_additive_eR_inversion

end PaperB.Analytic

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset

lemma principalCharacter_dft_norm_le
    (q : ℕ) [NeZero (6 * q)] (a : ZMod (6 * q)) :
    ‖ZMod.dft
        (fun x : ZMod (6 * q) =>
          (1 : DirichletCharacter ℂ (6 * q)) x) a‖
      ≤ (6 * q : ℕ) := by
  rw [ZMod.dft_apply]
  calc
    ‖∑ x : ZMod (6 * q),
        ZMod.stdAddChar (-(x * a)) •
          (1 : DirichletCharacter ℂ (6 * q)) x‖
      ≤ ∑ x : ZMod (6 * q),
          ‖ZMod.stdAddChar (-(x * a)) •
            (1 : DirichletCharacter ℂ (6 * q)) x‖ := norm_sum_le _ _
    _ ≤ ∑ _x : ZMod (6 * q), (1 : ℝ) := by
      apply Finset.sum_le_sum
      intro x hx
      rw [norm_smul]
      have hchar :=
        (1 : DirichletCharacter ℂ (6 * q)).norm_le_one x
      have hadd : ‖ZMod.stdAddChar (-(x * a))‖ = 1 := by
        simp [ZMod.stdAddChar_apply]
      rw [hadd, one_mul]
      exact hchar
    _ = (6 * q : ℕ) := by simp

lemma eR_zmod_frequency_add
    {N : ℕ} [NeZero N] (g a : ZMod N) (n : ℕ) :
    eR (((g.val : ℝ) / (N : ℝ)) * (n : ℝ)) *
      eR (((a.val : ℝ) / (N : ℝ)) * (n : ℝ)) =
    eR ((((g + a).val : ℝ) / (N : ℝ)) * (n : ℝ)) := by
  rw [← zmod_stdAddChar_mul_nat_eq_eR g n]
  rw [← zmod_stdAddChar_mul_nat_eq_eR a n]
  rw [← zmod_stdAddChar_mul_nat_eq_eR (g + a) n]
  rw [← ZMod.stdAddChar.map_add_eq_mul]
  congr 1
  ring

theorem omega_high_any_dft_reciprocal_weight_shell_bound
    {N : ℕ} [NeZero N] (g : ZMod N)
    {A : ℝ} {W B : ℕ}
    (hAthresh : (2 * (N : ℝ)) ^ 2 ≤ A)
    (hhigh : A ^ (3 / 4 : ℝ) < (W : ℝ))
    (hWB : W ≤ B) (hB2 : B ≤ 2 * W) :
    ‖∑ m ∈ Finset.Icc W B,
        ((m : ℂ)⁻¹ *
          eR (A / (m : ℝ) +
            ((g.val : ℝ) / (N : ℝ)) * (m : ℝ)))‖
      ≤ max (12 * (W : ℝ) / A)
          (2 * (1 + 2 * (N : ℝ)) / (W : ℝ)) := by
  have hNpos : 0 < N := NeZero.pos N
  have hA4 : (4 : ℝ) ≤ A := by
    have hN1 : (1 : ℝ) ≤ N := by exact_mod_cast hNpos
    nlinarith [hAthresh]
  have hA0 : 0 ≤ A := le_trans (by norm_num) hA4
  have hW : 0 < W := by
    have hr := Real.rpow_nonneg hA0 (3 / 4 : ℝ)
    exact_mod_cast (show (0 : ℝ) < W by linarith)
  by_cases hg : g = 0
  · subst g
    simp only [ZMod.val_zero, Nat.cast_zero, zero_div, zero_mul, add_zero]
    exact (omega_high_zero_mode_reciprocal_weight_tail
      hA4 hW hWB hB2 hhigh).trans (le_max_left _ _)
  · have hpert :=
      high_window_reciprocal_perturbation_le_dft_delta
        (N := N) hg hAthresh hhigh
    have hraw :=
      omega_high_nonzero_dft_reciprocal_weight_shell_bound_of_perturbation
        (N := N) hg hA0 hW hWB hpert
    have hd1 : (1 : ℝ) ≤ zmodFrequencyDistance g := by
      exact_mod_cast zmodFrequencyDistance_pos hg
    have hNreal : (0 : ℝ) < N := by exact_mod_cast hNpos
    have hdelta0 :
        0 < (zmodFrequencyDistance g : ℝ) / (2 * (N : ℝ)) := by
      positivity
    have hinv :
        1 / ((zmodFrequencyDistance g : ℝ) / (2 * (N : ℝ)))
          ≤ 2 * (N : ℝ) := by
      rw [one_div_div]
      exact div_le_self (by positivity : 0 ≤ 2 * (N : ℝ)) hd1
    have hWreal : (0 : ℝ) < W := by exact_mod_cast hW
    have hmajor :
        2 * (1 + 1 /
            ((zmodFrequencyDistance g : ℝ) / (2 * (N : ℝ)))) /
              (W : ℝ)
          ≤ 2 * (1 + 2 * (N : ℝ)) / (W : ℝ) := by
      have hadd :
          1 + 1 / ((zmodFrequencyDistance g : ℝ) / (2 * (N : ℝ)))
            ≤ 1 + 2 * (N : ℝ) := by linarith
      exact div_le_div_of_nonneg_right
        (mul_le_mul_of_nonneg_left hadd (by norm_num)) hWreal.le
    exact hraw.trans (hmajor.trans (le_max_right _ _))

#print axioms principalCharacter_dft_norm_le
#print axioms eR_zmod_frequency_add
#print axioms omega_high_any_dft_reciprocal_weight_shell_bound

end PaperB.Analytic


namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset

lemma coprime_weighted_high_shell_dft_expansion
    (q : ℕ) [NeZero (6 * q)] (g : ZMod (6 * q))
    {A : ℝ} {W B : ℕ} (hW : 0 < W) :
    (∑ m ∈ Finset.Icc W B,
        (((coprimeIndicatorArithmetic q m : ℝ) : ℂ) *
          (m : ℂ)⁻¹ *
          eR (A / (m : ℝ) +
            ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))) =
      ((6 * q : ℕ) : ℂ)⁻¹ *
        ∑ a : ZMod (6 * q),
          ZMod.dft
              (fun x : ZMod (6 * q) =>
                (1 : DirichletCharacter ℂ (6 * q)) x) a *
            (∑ m ∈ Finset.Icc W B,
              (m : ℂ)⁻¹ *
                eR (A / (m : ℝ) +
                  (((g + a).val : ℝ) /
                    ((6 * q : ℕ) : ℝ)) * (m : ℝ))) := by
  calc
    (∑ m ∈ Finset.Icc W B,
        (((coprimeIndicatorArithmetic q m : ℝ) : ℂ) *
          (m : ℂ)⁻¹ *
          eR (A / (m : ℝ) +
            ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ))))
      =
    ∑ m ∈ Finset.Icc W B,
      ((((6 * q : ℕ) : ℂ)⁻¹ *
        ∑ a : ZMod (6 * q),
          eR (((a.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)) *
            ZMod.dft
              (fun x : ZMod (6 * q) =>
                (1 : DirichletCharacter ℂ (6 * q)) x) a) *
        (m : ℂ)⁻¹ *
        eR (A / (m : ℝ) +
          ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ))) := by
      apply Finset.sum_congr rfl
      intro m hm
      have hm0 : m ≠ 0 := by
        have hmW := (Finset.mem_Icc.mp hm).1
        omega
      rw [coprimeIndicator_additive_eR_inversion q m hm0]
    _ =
      ((6 * q : ℕ) : ℂ)⁻¹ *
        ∑ m ∈ Finset.Icc W B,
          ∑ a : ZMod (6 * q),
            (eR (((a.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)) *
              ZMod.dft
                (fun x : ZMod (6 * q) =>
                  (1 : DirichletCharacter ℂ (6 * q)) x) a) *
              (m : ℂ)⁻¹ *
              eR (A / (m : ℝ) +
                ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro m hm
      rw [Finset.mul_sum, Finset.sum_mul, Finset.sum_mul]
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro a ha
      ring
    _ =
      ((6 * q : ℕ) : ℂ)⁻¹ *
        ∑ a : ZMod (6 * q),
          ∑ m ∈ Finset.Icc W B,
            (eR (((a.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)) *
              ZMod.dft
                (fun x : ZMod (6 * q) =>
                  (1 : DirichletCharacter ℂ (6 * q)) x) a) *
              (m : ℂ)⁻¹ *
              eR (A / (m : ℝ) +
                ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)) := by
      rw [Finset.sum_comm]
    _ =
      ((6 * q : ℕ) : ℂ)⁻¹ *
        ∑ a : ZMod (6 * q),
          ZMod.dft
              (fun x : ZMod (6 * q) =>
                (1 : DirichletCharacter ℂ (6 * q)) x) a *
            (∑ m ∈ Finset.Icc W B,
              (m : ℂ)⁻¹ *
                eR (A / (m : ℝ) +
                  (((g + a).val : ℝ) /
                    ((6 * q : ℕ) : ℝ)) * (m : ℝ))) := by
      congr 1
      apply Finset.sum_congr rfl
      intro a ha
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro m hm
      rw [eR_add, eR_add]
      calc
        eR (((a.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)) *
              ZMod.dft
                (fun x : ZMod (6 * q) =>
                  (1 : DirichletCharacter ℂ (6 * q)) x) a *
              (m : ℂ)⁻¹ *
              (eR (A / (m : ℝ)) *
                eR (((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))
          =
            ZMod.dft
                (fun x : ZMod (6 * q) =>
                  (1 : DirichletCharacter ℂ (6 * q)) x) a *
              ((m : ℂ)⁻¹ *
                (eR (A / (m : ℝ)) *
                  (eR (((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)) *
                    eR (((a.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ))))) := by
              ring
        _ = _ := by
              rw [eR_zmod_frequency_add g a m]

theorem omega_high_coprime_dft_reciprocal_weight_shell_bound
    (q : ℕ) [NeZero (6 * q)] (g : ZMod (6 * q))
    {A : ℝ} {W B : ℕ}
    (hAthresh : (2 * ((6 * q : ℕ) : ℝ)) ^ 2 ≤ A)
    (hhigh : A ^ (3 / 4 : ℝ) < (W : ℝ))
    (hWB : W ≤ B) (hB2 : B ≤ 2 * W) :
    ‖∑ m ∈ Finset.Icc W B,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR (A / (m : ℝ) +
            ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖
      ≤ (6 * q : ℝ) *
          max (12 * (W : ℝ) / A)
            (2 * (1 + 2 * ((6 * q : ℕ) : ℝ)) / (W : ℝ)) := by
  have hq0 : q ≠ 0 := by
    intro hq
    subst q
    exact (NeZero.ne (6 * 0)) rfl
  have hW : 0 < W := by
    have hA0 : 0 ≤ A := by
      have hb : 0 ≤ (2 * ((6 * q : ℕ) : ℝ)) ^ 2 := sq_nonneg _
      exact hb.trans hAthresh
    have hr := Real.rpow_nonneg hA0 (3 / 4 : ℝ)
    exact_mod_cast (show (0 : ℝ) < W by linarith)
  have hexp := coprime_weighted_high_shell_dft_expansion
    q g (A := A) (W := W) (B := B) hW
  have hP : (0 : ℝ) < 6 * q := by positivity
  have hmode : ∀ a : ZMod (6 * q),
      ‖∑ m ∈ Finset.Icc W B,
          (m : ℂ)⁻¹ *
            eR (A / (m : ℝ) +
              (((g + a).val : ℝ) /
                ((6 * q : ℕ) : ℝ)) * (m : ℝ))‖
        ≤ max (12 * (W : ℝ) / A)
          (2 * (1 + 2 * ((6 * q : ℕ) : ℝ)) / (W : ℝ)) := by
    intro a
    exact omega_high_any_dft_reciprocal_weight_shell_bound
      (N := 6 * q) (g + a) hAthresh hhigh hWB hB2
  have hrewrite :
      (∑ m ∈ Finset.Icc W B,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR (A / (m : ℝ) +
            ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))) =
      (∑ m ∈ Finset.Icc W B,
        (((coprimeIndicatorArithmetic q m : ℝ) : ℂ) *
          (m : ℂ)⁻¹ *
          eR (A / (m : ℝ) +
            ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))) := by
    apply Finset.sum_congr rfl
    intro m hm
    have hm0 : (m : ℝ) ≠ 0 := by
      have hmW := (Finset.mem_Icc.mp hm).1
      have hmNat0 : m ≠ 0 := by omega
      exact_mod_cast hmNat0
    push_cast
    rw [div_eq_mul_inv]
  rw [hrewrite, hexp]
  rw [norm_mul, norm_inv, Complex.norm_natCast]
  have hPnat : 0 < 6 * q := by
    exact NeZero.pos _
  have hPreal : (0 : ℝ) < ((6 * q : ℕ) : ℝ) := by
    exact_mod_cast hPnat
  calc
    (((6 * q : ℕ) : ℝ))⁻¹ *
        ‖∑ a : ZMod (6 * q),
          ZMod.dft
              (fun x : ZMod (6 * q) =>
                (1 : DirichletCharacter ℂ (6 * q)) x) a *
            (∑ m ∈ Finset.Icc W B,
              (m : ℂ)⁻¹ *
                eR (A / (m : ℝ) +
                  (((g + a).val : ℝ) /
                    ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖
      ≤ (((6 * q : ℕ) : ℝ))⁻¹ *
          ∑ a : ZMod (6 * q),
            ‖ZMod.dft
                (fun x : ZMod (6 * q) =>
                  (1 : DirichletCharacter ℂ (6 * q)) x) a *
              (∑ m ∈ Finset.Icc W B,
                (m : ℂ)⁻¹ *
                  eR (A / (m : ℝ) +
                    (((g + a).val : ℝ) /
                      ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖ := by
        gcongr
        exact norm_sum_le _ _
    _ ≤ (((6 * q : ℕ) : ℝ))⁻¹ *
          ∑ _a : ZMod (6 * q),
            (((6 * q : ℕ) : ℝ) *
              max (12 * (W : ℝ) / A)
                (2 * (1 + 2 * ((6 * q : ℕ) : ℝ)) /
                  (W : ℝ))) := by
        gcongr with a
        rw [norm_mul]
        exact mul_le_mul
          (principalCharacter_dft_norm_le q a)
          (hmode a) (norm_nonneg _) (by positivity)
    _ = (((6 * q : ℕ) : ℝ)) *
          max (12 * (W : ℝ) / A)
            (2 * (1 + 2 * ((6 * q : ℕ) : ℝ)) / (W : ℝ)) := by
        simp
        field_simp [hPreal.ne']
    _ = (6 * q : ℝ) *
          max (12 * (W : ℝ) / A)
            (2 * (1 + 2 * ((6 * q : ℕ) : ℝ)) / (W : ℝ)) := by
        push_cast
        ring

#print axioms coprime_weighted_high_shell_dft_expansion
theorem reciprocal_weight_dyadic_linear_inv_aggregate
    (f : ℕ → ℂ) {alpha beta : ℝ} (ha : 0 ≤ alpha) (hb : 0 ≤ beta)
    {M N : ℕ} (hM : 0 < M) (hMN : M ≤ N)
    (hshell : ∀ W B : ℕ,
      M ≤ W → 0 < W → W ≤ B → B ≤ 2 * W → B ≤ N →
      ‖∑ m ∈ Finset.Icc W B, f m‖
        ≤ alpha * (W : ℝ) + beta / (W : ℝ)) :
    ‖∑ m ∈ Finset.Icc M N, f m‖
      ≤ 2 * alpha * (N : ℝ) - alpha * (M : ℝ) +
          2 * beta / (M : ℝ) := by
  generalize hgap : N - M = gap
  induction gap using Nat.strong_induction_on generalizing M N with
  | h gap ih =>
      by_cases hsmall : N ≤ 2 * M
      · have hs := hshell M N le_rfl hM hMN hsmall le_rfl
        have hMr : (0 : ℝ) < M := by exact_mod_cast hM
        have hMNreal : (M : ℝ) ≤ N := by exact_mod_cast hMN
        calc
          ‖∑ m ∈ Finset.Icc M N, f m‖
              ≤ alpha * (M : ℝ) + beta / (M : ℝ) := hs
          _ ≤ 2 * alpha * (N : ℝ) - alpha * (M : ℝ) +
                2 * beta / (M : ℝ) := by
            have haMN := mul_le_mul_of_nonneg_left hMNreal ha
            have hbdiv : 0 ≤ beta / (M : ℝ) := by positivity
            have halpha :
                alpha * (M : ℝ) ≤
                  2 * alpha * (N : ℝ) - alpha * (M : ℝ) := by
              nlinarith [haMN]
            have hbeta :
                beta / (M : ℝ) ≤ 2 * beta / (M : ℝ) := by
              calc
                beta / (M : ℝ)
                    ≤ beta / (M : ℝ) + beta / (M : ℝ) :=
                  le_add_of_nonneg_right hbdiv
                _ = 2 * beta / (M : ℝ) := by ring
            exact add_le_add halpha hbeta
      · have h2MN : 2 * M < N := lt_of_not_ge hsmall
        let M' := 2 * M + 1
        have hMp : 0 < M' := by dsimp [M']; omega
        have hMpN : M' ≤ N := by dsimp [M']; omega
        have hgaplt : N - M' < gap := by
          rw [← hgap]
          dsimp [M']
          omega
        have hs := hshell M (2 * M) le_rfl hM (by omega) (by omega) (by omega)
        have hshell' : ∀ W B : ℕ,
            M' ≤ W → 0 < W → W ≤ B → B ≤ 2 * W → B ≤ N →
            ‖∑ m ∈ Finset.Icc W B, f m‖
              ≤ alpha * (W : ℝ) + beta / (W : ℝ) := by
          intro W B hMpW hW hWB hB2 hBN
          have hMW : M ≤ W := by
            dsimp [M'] at hMpW
            omega
          exact hshell W B hMW hW hWB hB2 hBN
        have hi := ih (N - M') hgaplt
          (M := M') (N := N) hMp hMpN hshell' rfl
        have hleft : Finset.Icc M (2 * M) ⊆ Finset.Icc M N := by
          intro x hx
          rw [Finset.mem_Icc] at hx ⊢
          omega
        have hright : Finset.Icc M' N ⊆ Finset.Icc M N := by
          intro x hx
          rw [Finset.mem_Icc] at hx ⊢
          dsimp [M'] at hx
          omega
        have hdis : Disjoint (Finset.Icc M (2 * M)) (Finset.Icc M' N) := by
          rw [Finset.disjoint_left]
          intro x hx1 hx2
          rw [Finset.mem_Icc] at hx1 hx2
          dsimp [M'] at hx2
          omega
        have hunion :
            Finset.Icc M N =
              Finset.Icc M (2 * M) ∪ Finset.Icc M' N := by
          ext x
          simp only [Finset.mem_Icc, Finset.mem_union]
          dsimp [M']
          omega
        rw [hunion, Finset.sum_union hdis]
        calc
          ‖(∑ m ∈ Finset.Icc M (2 * M), f m) +
              (∑ m ∈ Finset.Icc M' N, f m)‖
            ≤ ‖∑ m ∈ Finset.Icc M (2 * M), f m‖ +
                ‖∑ m ∈ Finset.Icc M' N, f m‖ := norm_add_le _ _
          _ ≤ (alpha * (M : ℝ) + beta / (M : ℝ)) +
                (2 * alpha * (N : ℝ) - alpha * (M' : ℝ) +
                  2 * beta / (M' : ℝ)) := add_le_add hs hi
          _ ≤ 2 * alpha * (N : ℝ) - alpha * (M : ℝ) +
                2 * beta / (M : ℝ) := by
            have hMr : (0 : ℝ) < M := by exact_mod_cast hM
            have hMpr : (0 : ℝ) < M' := by exact_mod_cast hMp
            have hMpge : (2 : ℝ) * (M : ℝ) ≤ (M' : ℝ) := by
              dsimp [M']
              push_cast
              linarith
            have hbinv :
                2 * beta / (M' : ℝ) ≤ beta / (M : ℝ) := by
              rw [div_le_iff₀ hMpr, div_eq_mul_inv]
              have := mul_le_mul_of_nonneg_left hMpge hb
              field_simp [hMr.ne']
              nlinarith
            have hMpeq : (M' : ℝ) = 2 * (M : ℝ) + 1 := by
              dsimp [M']
              push_cast
              ring
            have halphaRec :
                alpha * (M : ℝ) +
                    (2 * alpha * (N : ℝ) - alpha * (M' : ℝ))
                  ≤ 2 * alpha * (N : ℝ) - alpha * (M : ℝ) := by
              rw [hMpeq]
              nlinarith [ha]
            have hbetaRec :
                beta / (M : ℝ) + 2 * beta / (M' : ℝ)
                  ≤ 2 * beta / (M : ℝ) := by
              calc
                beta / (M : ℝ) + 2 * beta / (M' : ℝ)
                    ≤ beta / (M : ℝ) + beta / (M : ℝ) := by
                  simpa [add_comm] using
                    (add_le_add_right hbinv (beta / (M : ℝ)))
                _ = 2 * beta / (M : ℝ) := by ring
            calc
              (alpha * (M : ℝ) + beta / (M : ℝ)) +
                  (2 * alpha * (N : ℝ) - alpha * (M' : ℝ) +
                    2 * beta / (M' : ℝ))
                = (alpha * (M : ℝ) +
                    (2 * alpha * (N : ℝ) - alpha * (M' : ℝ))) +
                    (beta / (M : ℝ) + 2 * beta / (M' : ℝ)) := by ring
              _ ≤ (2 * alpha * (N : ℝ) - alpha * (M : ℝ)) +
                    2 * beta / (M : ℝ) :=
                  add_le_add halphaRec hbetaRec
              _ = 2 * alpha * (N : ℝ) - alpha * (M : ℝ) +
                    2 * beta / (M : ℝ) := by ring



theorem omega_high_coprime_dft_reciprocal_weight_tail_bound
    (q : ℕ) [NeZero (6 * q)] (g : ZMod (6 * q))
    {A : ℝ} {M N : ℕ}
    (hAthresh : (2 * ((6 * q : ℕ) : ℝ)) ^ 2 ≤ A)
    (hM : 0 < M)
    (hhigh : A ^ (3 / 4 : ℝ) < (M : ℝ))
    (hMN : M ≤ N) :
    ‖∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR (A / (m : ℝ) +
            ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖
      ≤ 2 * (((6 * q : ℕ) : ℝ) * 12 / A) * (N : ℝ) -
          (((6 * q : ℕ) : ℝ) * 12 / A) * (M : ℝ) +
          2 * (((6 * q : ℕ) : ℝ) *
            (2 * (1 + 2 * ((6 * q : ℕ) : ℝ)))) / (M : ℝ) := by
  let alpha : ℝ := ((6 * q : ℕ) : ℝ) * 12 / A
  let beta : ℝ := ((6 * q : ℕ) : ℝ) *
    (2 * (1 + 2 * ((6 * q : ℕ) : ℝ)))
  have hA0 : 0 ≤ A := by
    have hb : 0 ≤ (2 * ((6 * q : ℕ) : ℝ)) ^ 2 := sq_nonneg _
    exact hb.trans hAthresh
  have hApos : 0 < A := by
    have hP : 0 < 6 * q := NeZero.pos _
    have hPr : (0 : ℝ) < ((6 * q : ℕ) : ℝ) := by exact_mod_cast hP
    have hb : 0 < (2 * ((6 * q : ℕ) : ℝ)) ^ 2 := sq_pos_of_pos (by positivity)
    exact lt_of_lt_of_le hb hAthresh
  have ha : 0 ≤ alpha := by
    dsimp [alpha]
    positivity
  have hb : 0 ≤ beta := by
    dsimp [beta]
    positivity
  have hshell : ∀ W B : ℕ,
      M ≤ W → 0 < W → W ≤ B → B ≤ 2 * W → B ≤ N →
      ‖∑ m ∈ Finset.Icc W B,
          (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
            eR (A / (m : ℝ) +
              ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖
        ≤ alpha * (W : ℝ) + beta / (W : ℝ) := by
    intro W B hMW hW hWB hB2 hBN
    have hhighW : A ^ (3 / 4 : ℝ) < (W : ℝ) := by
      have hcast : (M : ℝ) ≤ W := by exact_mod_cast hMW
      exact lt_of_lt_of_le hhigh hcast
    have hs := omega_high_coprime_dft_reciprocal_weight_shell_bound
      q g hAthresh hhighW hWB hB2
    have hmax :
        max (12 * (W : ℝ) / A)
            (2 * (1 + 2 * ((6 * q : ℕ) : ℝ)) / (W : ℝ))
          ≤ 12 * (W : ℝ) / A +
            2 * (1 + 2 * ((6 * q : ℕ) : ℝ)) / (W : ℝ) :=
      max_le_add_of_nonneg
        (by positivity)
        (by positivity)
    have hPnon : 0 ≤ (((6 * q : ℕ) : ℝ)) := by positivity
    calc
      ‖∑ m ∈ Finset.Icc W B,
          (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
            eR (A / (m : ℝ) +
              ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖
        ≤ ((6 * q : ℕ) : ℝ) *
            max (12 * (W : ℝ) / A)
              (2 * (1 + 2 * ((6 * q : ℕ) : ℝ)) / (W : ℝ)) := by
          simpa [Nat.cast_mul] using hs
      _ ≤ ((6 * q : ℕ) : ℝ) *
          (12 * (W : ℝ) / A +
            2 * (1 + 2 * ((6 * q : ℕ) : ℝ)) / (W : ℝ)) :=
        mul_le_mul_of_nonneg_left hmax hPnon
      _ = alpha * (W : ℝ) + beta / (W : ℝ) := by
        dsimp [alpha, beta]
        ring
  have hagg := reciprocal_weight_dyadic_linear_inv_aggregate
    (f := fun m =>
      (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
        eR (A / (m : ℝ) +
          ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ))))
    ha hb hM hMN hshell
  simpa [alpha, beta] using hagg




noncomputable def omegaHighReciprocalBaseRate (q : ℕ) : ℝ :=
  let P : ℝ := ((6 * q : ℕ) : ℝ)
  24 * P ^ 2 + 4 * P * (1 + 2 * P)

lemma omegaHighReciprocalBaseRate_nonneg (q : ℕ) :
    0 ≤ omegaHighReciprocalBaseRate q := by
  unfold omegaHighReciprocalBaseRate
  positivity

theorem omega_high_coprime_dft_reciprocal_weight_tail_rate_bound
    (q : ℕ) [NeZero (6 * q)] (g : ZMod (6 * q))
    {A : ℝ} {M N : ℕ}
    (hAthresh : (2 * ((6 * q : ℕ) : ℝ)) ^ 2 ≤ A)
    (hM : 0 < M)
    (hhigh : A ^ (3 / 4 : ℝ) < (M : ℝ))
    (hMN : M ≤ N)
    (hscale : (N : ℝ) ≤ ((6 * q : ℕ) : ℝ) * A) :
    ‖∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR (A / (m : ℝ) +
            ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖
      ≤ omegaHighReciprocalBaseRate q := by
  let P : ℝ := ((6 * q : ℕ) : ℝ)
  have hP : 0 < P := by
    dsimp [P]
    exact_mod_cast (NeZero.pos (6 * q))
  have hApos : 0 < A := by
    have hsq : 0 < (2 * P) ^ 2 := sq_pos_of_pos (by positivity)
    exact lt_of_lt_of_le hsq (by simpa [P] using hAthresh)
  have hMr : (0 : ℝ) < M := by exact_mod_cast hM
  have hM1 : (1 : ℝ) ≤ M := by exact_mod_cast (Nat.one_le_iff_ne_zero.mpr (Nat.ne_of_gt hM))
  have htail :=
    omega_high_coprime_dft_reciprocal_weight_tail_bound
      q g hAthresh hM hhigh hMN
  have hNA :
      (N : ℝ) / A ≤ P := by
    rw [div_le_iff₀ hApos]
    simpa [P, mul_comm] using hscale
  have hfirst :
      2 * (P * 12 / A) * (N : ℝ) ≤ 24 * P ^ 2 := by
    have hP0 : 0 ≤ P := hP.le
    have hm :
        (24 * P) * ((N : ℝ) / A) ≤ (24 * P) * P :=
      mul_le_mul_of_nonneg_left hNA (by positivity)
    calc
      2 * (P * 12 / A) * (N : ℝ)
          = (24 * P) * ((N : ℝ) / A) := by ring
      _ ≤ (24 * P) * P := hm
      _ = 24 * P ^ 2 := by ring
  have hsecond :
      2 * (P * (2 * (1 + 2 * P))) / (M : ℝ)
        ≤ 4 * P * (1 + 2 * P) := by
    have hnum0 : 0 ≤ 4 * P * (1 + 2 * P) := by positivity
    have hinv : 1 / (M : ℝ) ≤ 1 := by
      rw [div_le_iff₀ hMr]
      nlinarith
    calc
      2 * (P * (2 * (1 + 2 * P))) / (M : ℝ)
          = (4 * P * (1 + 2 * P)) * (1 / (M : ℝ)) := by ring
      _ ≤ (4 * P * (1 + 2 * P)) * 1 :=
        mul_le_mul_of_nonneg_left hinv hnum0
      _ = 4 * P * (1 + 2 * P) := by ring
  have hmiddle_nonneg : 0 ≤ (P * 12 / A) * (M : ℝ) := by positivity
  calc
    ‖∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR (A / (m : ℝ) +
            ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖
      ≤ 2 * (P * 12 / A) * (N : ℝ) -
          (P * 12 / A) * (M : ℝ) +
          2 * (P * (2 * (1 + 2 * P))) / (M : ℝ) := by
            simpa [P] using htail
    _ ≤ 2 * (P * 12 / A) * (N : ℝ) +
          2 * (P * (2 * (1 + 2 * P))) / (M : ℝ) := by
            linarith
    _ ≤ 24 * P ^ 2 + 4 * P * (1 + 2 * P) :=
      add_le_add hfirst hsecond
    _ = omegaHighReciprocalBaseRate q := by
      simp [omegaHighReciprocalBaseRate, P]

theorem omega_high_coprime_dft_reciprocal_weight_tail_sublog
    (q : ℕ) [NeZero (6 * q)] :
    ∀ eps : ℝ, 0 < eps →
      ∃ T0 : ℝ, ∀
        (g : ZMod (6 * q)) (A : ℝ) (M N : ℕ) (T : ℝ),
        (2 * ((6 * q : ℕ) : ℝ)) ^ 2 ≤ A →
        0 < M →
        A ^ (3 / 4 : ℝ) < (M : ℝ) →
        M ≤ N →
        (N : ℝ) ≤ ((6 * q : ℕ) : ℝ) * A →
        T0 ≤ T →
        Real.exp 1 ≤ T →
        ‖∑ m ∈ Finset.Icc M N,
            (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
              eR (A / (m : ℝ) +
                ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖
          ≤ eps * Real.log T := by
  intro eps heps
  let C : ℝ := omegaHighReciprocalBaseRate q
  let T0 : ℝ := Real.exp (C / eps)
  refine ⟨T0, ?_⟩
  intro g A M N T hAthresh hM hhigh hMN hscale hT0 hT1
  have hrate :=
    omega_high_coprime_dft_reciprocal_weight_tail_rate_bound
      q g hAthresh hM hhigh hMN hscale
  have hC0 : 0 ≤ C := by
    dsimp [C]
    exact omegaHighReciprocalBaseRate_nonneg q
  have hlog :
      C / eps ≤ Real.log T := by
    have hpos : 0 < T0 := by
      dsimp [T0]
      exact Real.exp_pos _
    have hmono := Real.log_le_log hpos hT0
    simpa [T0] using hmono
  have hmul := mul_le_mul_of_nonneg_left hlog heps.le
  have heps0 : eps ≠ 0 := ne_of_gt heps
  have hCeps : C = eps * (C / eps) := by
    field_simp [heps0]
  calc
    ‖∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR (A / (m : ℝ) +
            ((g.val : ℝ) / ((6 * q : ℕ) : ℝ)) * (m : ℝ)))‖
      ≤ C := by simpa [C] using hrate
    _ = eps * (C / eps) := hCeps
    _ ≤ eps * Real.log T := hmul

#print axioms reciprocal_weight_dyadic_linear_inv_aggregate
#print axioms omega_high_coprime_dft_reciprocal_weight_tail_bound
#print axioms omega_high_coprime_dft_reciprocal_weight_tail_rate_bound
#print axioms omega_high_coprime_dft_reciprocal_weight_tail_sublog

#print axioms omega_high_coprime_dft_reciprocal_weight_shell_bound

end PaperB.Analytic
