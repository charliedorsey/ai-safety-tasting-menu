import PaperB.FixedQ.H2BooleanLocalUnitMoment
import Mathlib.Analysis.Normed.Ring.Finite

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def h2BooleanGenericPrimeLocalFactor
    {p : ℕ} [NeZero p]
    (ψ : AddChar (ZMod p) ℂ)
    (j : ZMod p) (a : (ZMod p)ˣ) : ℂ :=
  (2 : ℂ)⁻¹ * (1 + ψ (j * (a : ZMod p)))

lemma h2_sum_units_addChar_mul
    {p : ℕ} [NeZero p] (hp : p.Prime)
    (ψ : AddChar (ZMod p) ℂ) (hψ : ψ ≠ 1)
    (j : ZMod p) :
    (∑ a : (ZMod p)ˣ, ψ (j * (a : ZMod p))) =
      if j = 0 then (p - 1 : ℂ) else -1 := by
  letI : Fact p.Prime := ⟨hp⟩
  letI : Fintype (ZMod p)ˣ := h2FintypeZModUnits p
  by_cases hj : j = 0
  · subst j
    simp [ZMod.card_units_eq_totient, Nat.totient_prime hp]
    rw [Nat.cast_sub hp.one_le]
    norm_num
  · rw [if_neg hj]
    have hprim : ψ.IsPrimitive := AddChar.IsPrimitive.of_ne_one hψ
    have htotal :
        (∑ x : ZMod p, ψ (j * x)) = 0 := by
      simpa [mul_comm, hj] using AddChar.sum_mulShift j hprim
    have hsplit :=
      Fintype.sum_eq_add_sum_subtype_ne
        (fun x : ZMod p => ψ (j * x)) 0
    have hnonzero :
        (∑ x : {x : ZMod p // x ≠ 0}, ψ (j * (x : ZMod p))) = -1 := by
      rw [hsplit] at htotal
      simp at htotal
      rw [add_comm] at htotal
      exact eq_neg_of_add_eq_zero_left htotal
    calc
      (∑ a : (ZMod p)ˣ, ψ (j * (a : ZMod p))) =
        ∑ x : {x : ZMod p // x ≠ 0}, ψ (j * (x : ZMod p)) := by
          exact Fintype.sum_equiv
            (h2UnitsEquivNeZero p)
            (fun a : (ZMod p)ˣ => ψ (j * (a : ZMod p)))
            (fun x : {x : ZMod p // x ≠ 0} => ψ (j * (x : ZMod p)))
            (fun a => rfl)
      _ = -1 := hnonzero

lemma h2BooleanGenericPrimeLocalFactor_norm_sq
    {p : ℕ} [NeZero p]
    (ψ : AddChar (ZMod p) ℂ)
    (j : ZMod p) (a : (ZMod p)ˣ) :
    ‖h2BooleanGenericPrimeLocalFactor ψ j a‖ ^ 2 =
      (1 / 2 : ℝ) + (ψ (j * (a : ZMod p))).re / 2 := by
  unfold h2BooleanGenericPrimeLocalFactor
  rw [← Complex.normSq_eq_norm_sq]
  rw [Complex.normSq_mul, Complex.normSq_inv]
  have hz : Complex.normSq (ψ (j * (a : ZMod p))) = 1 := by
    rw [Complex.normSq_eq_norm_sq, AddChar.norm_apply]
    norm_num
  rw [Complex.normSq_add, Complex.normSq_one, hz]
  simp only [one_mul, Complex.conj_re]
  norm_num
  ring

lemma h2_average_genericPrimeLocalFactor_eq_m3
    {p : ℕ} [NeZero p] (hp : p.Prime)
    (ψ : AddChar (ZMod p) ℂ) (hψ : ψ ≠ 1)
    (j : ℤ) :
    ((Fintype.card (ZMod p)ˣ : ℝ)⁻¹) *
      (∑ a : (ZMod p)ˣ,
        ‖h2BooleanGenericPrimeLocalFactor ψ (j : ZMod p) a‖ ^ 2) =
      (PaperB.Boolean.booleanLocalSecondMoment p j : ℝ) := by
  letI : Fact p.Prime := ⟨hp⟩
  letI : Fintype (ZMod p)ˣ := h2FintypeZModUnits p
  simp_rw [h2BooleanGenericPrimeLocalFactor_norm_sq]
  rw [Finset.sum_add_distrib]
  simp only [Finset.sum_const, nsmul_eq_mul]
  rw [← Finset.sum_div]
  have hchar := h2_sum_units_addChar_mul hp ψ hψ (j : ZMod p)
  have hre := congrArg Complex.re hchar
  simp only [Complex.re_sum] at hre
  rw [hre]
  have hcard :
      (Fintype.card (ZMod p)ˣ : ℝ) = (p : ℝ) - 1 := by
    rw [ZMod.card_units_eq_totient, Nat.totient_prime hp]
    rw [Nat.cast_sub hp.one_le]
    norm_num
  rw [hcard]
  rw [PaperB.Boolean.booleanLocalSecondMoment_eq p j hp]
  have hp1 : (1 : ℝ) < p := by exact_mod_cast hp.one_lt
  by_cases hdiv : (p : ℤ) ∣ j
  · have hz : (j : ZMod p) = 0 :=
      (ZMod.intCast_zmod_eq_zero_iff_dvd j p).2 hdiv
    simp [hdiv, hz, Nat.totient_prime hp]
    rw [Nat.cast_sub hp.one_le]
    norm_num
    field_simp [ne_of_gt (sub_pos.mpr hp1)]
    norm_num
  · have hz : (j : ZMod p) ≠ 0 := by
      exact fun h => hdiv ((ZMod.intCast_zmod_eq_zero_iff_dvd j p).1 h)
    simp [hdiv, hz, Nat.totient_prime hp]
    rw [Nat.cast_sub hp.one_le]
    norm_num
    field_simp [ne_of_gt (sub_pos.mpr hp1)]
    ring

#print axioms h2_sum_units_addChar_mul
#print axioms h2_average_genericPrimeLocalFactor_eq_m3

end PaperB.FixedQ
