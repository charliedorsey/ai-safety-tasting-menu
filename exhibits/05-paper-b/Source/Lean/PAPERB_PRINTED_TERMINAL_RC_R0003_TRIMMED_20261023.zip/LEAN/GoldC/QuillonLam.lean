import GoldC.QuillonAsymp
import GoldC.QuillonResidue

/-!
# Quillon CSC3 F8.2: the `Λ`-calculus toolkit (eventual inequalities in `Λ = log h`)

* `natlog_le`: `Nat.log 2 n ≤ log n / log 2`.
* `const_le_rpow`: `K ≤ Λ^c` eventually.
* `Aω_le`: `e^{37.5}(1 + log₂ log₂ N)^{30} ≤ Λ^c` eventually, uniformly in `log N ≤ kΛ`.
* `prodU_le`: `∏_U (1 + 1/(p−3)) ≤ e^{10}(log₂N + 1)^{10}` for primes `5 ≤ p ≤ N`;
  `prodU_le_pow`: `≤ e^{10}(2k+1)^{10}Λ^{10}` if `log N ≤ kΛ`.
* `decay`: `Λ^k · exp(−cΛ^τ) ≤ Λ^{−m}` eventually.
* `exp_ge`: `exp(cΛ^τ) ≥ x₀` eventually.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonLam

open GoldC.QuillonWContext

lemma log2_gt_half : (1 / 2 : ℝ) < Real.log 2 := by
  have := Real.log_two_gt_d9; linarith

lemma natlog_le (n : ℕ) : (Nat.log 2 n : ℝ) ≤ Real.log n / Real.log 2 := by
  rcases Nat.eq_zero_or_pos n with rfl | hn
  · simp
  have h1 : 2 ^ Nat.log 2 n ≤ n := Nat.pow_log_le_self 2 hn.ne'
  have h2 : ((2 : ℝ)) ^ Nat.log 2 n ≤ n := by exact_mod_cast h1
  have h3 := Real.log_le_log (by positivity) h2
  rw [Real.log_pow] at h3
  rw [le_div_iff₀ (Real.log_pos (by norm_num))]; exact h3

lemma natlog_le_of (n : ℕ) (L : ℝ) (h : Real.log n ≤ L) : (Nat.log 2 n : ℝ) ≤ 2 * max L 0 := by
  have h1 := natlog_le n
  have hl2 := log2_gt_half
  have hl0 : 0 ≤ Real.log n := Real.log_natCast_nonneg n
  calc (Nat.log 2 n : ℝ) ≤ Real.log n / Real.log 2 := h1
    _ ≤ Real.log n / (1 / 2) := div_le_div_of_nonneg_left hl0 (by norm_num) hl2.le
    _ = 2 * Real.log n := by ring
    _ ≤ 2 * max L 0 := by have := le_max_left L 0; linarith

lemma const_le_rpow (K c : ℝ) (hc : 0 < c) :
    ∃ Λ₀ : ℝ, 1 ≤ Λ₀ ∧ ∀ Λ : ℝ, Λ₀ ≤ Λ → K ≤ Λ ^ c := by
  refine ⟨max 1 ((max K 1) ^ (1 / c)), le_max_left _ _, fun Λ hΛ => ?_⟩
  have hΛ1 : 1 ≤ Λ := le_trans (le_max_left _ _) hΛ
  have hK1 : 1 ≤ max K 1 := le_max_right _ _
  have h1 : (max K 1) ^ (1 / c) ≤ Λ := le_trans (le_max_right _ _) hΛ
  calc K ≤ max K 1 := le_max_left _ _
    _ = ((max K 1) ^ (1 / c)) ^ c := by
        rw [← Real.rpow_mul (by linarith)]; field_simp; simp
    _ ≤ Λ ^ c := Real.rpow_le_rpow (by positivity) h1 hc.le

/-- polylog absorption: `(1 + log Λ)^m ≤ Λ^c` eventually. -/
lemma polylog_le (m : ℕ) (c : ℝ) (hc : 0 < c) :
    ∃ Λ₀ : ℝ, 1 ≤ Λ₀ ∧ ∀ Λ : ℝ, Λ₀ ≤ Λ → (1 + Real.log Λ) ^ m ≤ Λ ^ c :=
  GoldC.QuillonAsymp.one_add_log_pow_le m c hc

theorem Aω_le (k c : ℝ) (hk : 0 < k) (hc : 0 < c) :
    ∃ Λ₀ : ℝ, 1 ≤ Λ₀ ∧ ∀ Λ : ℝ, Λ₀ ≤ Λ → ∀ N : ℕ, Real.log N ≤ k * Λ →
      Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 N) : ℝ) ^ 30 ≤ Λ ^ c := by
  set A₁ := 1 + 2 * |Real.log (2 * k)| with hA₁
  obtain ⟨Λ₁, hΛ₁, h1⟩ := polylog_le 30 (c / 2) (by positivity)
  obtain ⟨Λ₂, hΛ₂, h2⟩ := const_le_rpow (Real.exp 37.5 * (A₁ + 2) ^ 30) (c / 2) (by positivity)
  refine ⟨max Λ₁ Λ₂, le_trans hΛ₁ (le_max_left _ _), fun Λ hΛ N hN => ?_⟩
  have hΛ1 : 1 ≤ Λ := le_trans hΛ₁ (le_trans (le_max_left _ _) hΛ)
  have hlogΛ : 0 ≤ Real.log Λ := Real.log_nonneg hΛ1
  -- `Nat.log 2 N ≤ 2kΛ`
  have hn1 : (Nat.log 2 N : ℝ) ≤ 2 * (k * Λ) := by
    have := natlog_le_of N (k * Λ) hN
    have : max (k * Λ) 0 = k * Λ := max_eq_left (by positivity)
    linarith
  -- `1 + Nat.log 2 (Nat.log 2 N) ≤ (A₁ + 2)(1 + log Λ)`
  have hn2 : (1 + Nat.log 2 (Nat.log 2 N) : ℝ) ≤ (A₁ + 2) * (1 + Real.log Λ) := by
    rcases Nat.eq_zero_or_pos (Nat.log 2 N) with h0 | hpos
    · rw [h0]; simp
      have : 0 ≤ |Real.log (2 * k)| := abs_nonneg _
      nlinarith
    · have hpos' : (0 : ℝ) < Nat.log 2 N := by exact_mod_cast hpos
      have h3 := natlog_le_of (Nat.log 2 N) (Real.log (2 * k) + Real.log Λ) (by
        rw [← Real.log_mul (by positivity) (by linarith)]
        exact Real.log_le_log hpos' (by linarith))
      have h4 : max (Real.log (2 * k) + Real.log Λ) 0 ≤ |Real.log (2 * k)| + Real.log Λ := by
        apply max_le
        · have := le_abs_self (Real.log (2 * k)); linarith
        · have := abs_nonneg (Real.log (2 * k)); linarith
      have : 0 ≤ |Real.log (2 * k)| := abs_nonneg _
      rw [hA₁]; nlinarith
  have hn0 : (0 : ℝ) ≤ 1 + Nat.log 2 (Nat.log 2 N) := by positivity
  calc Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 N) : ℝ) ^ 30
      ≤ Real.exp 37.5 * ((A₁ + 2) * (1 + Real.log Λ)) ^ 30 := by gcongr
    _ = (Real.exp 37.5 * (A₁ + 2) ^ 30) * (1 + Real.log Λ) ^ 30 := by rw [mul_pow]; ring
    _ ≤ Λ ^ (c / 2) * Λ ^ (c / 2) := by
        apply mul_le_mul (h2 Λ (le_trans (le_max_right _ _) hΛ))
          (h1 Λ (le_trans (le_max_left _ _) hΛ)) (by positivity) (by positivity)
    _ = Λ ^ c := by rw [← Real.rpow_add (by linarith)]; ring_nf

theorem prodU_le (U : Finset ℕ) (hU : ∀ p ∈ U, p.Prime ∧ 5 ≤ p) (N : ℕ) (hUN : ∀ p ∈ U, p ≤ N) :
    ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) ≤ Real.exp 10 * ((Nat.log 2 N : ℝ) + 1) ^ 10 := by
  rw [← sum_ωR_powerset]
  exact GoldC.QuillonResidue.smooth_mass U hU (Nat.log 2 N) fun p hp =>
    lt_of_le_of_lt (hUN p hp) (Nat.lt_pow_succ_log_self (by norm_num) N)

theorem prodU_le_pow (U : Finset ℕ) (hU : ∀ p ∈ U, p.Prime ∧ 5 ≤ p) (N : ℕ) (hUN : ∀ p ∈ U, p ≤ N)
    (k Λ : ℝ) (hk : 0 ≤ k) (hΛ : 1 ≤ Λ) (hN : Real.log N ≤ k * Λ) :
    ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) ≤ Real.exp 10 * (2 * k + 1) ^ 10 * Λ ^ (10 : ℝ) := by
  have h1 := prodU_le U hU N hUN
  have h2 : (Nat.log 2 N : ℝ) + 1 ≤ (2 * k + 1) * Λ := by
    have := natlog_le_of N (k * Λ) hN
    have : max (k * Λ) 0 = k * Λ := max_eq_left (by positivity)
    nlinarith
  calc _ ≤ Real.exp 10 * ((Nat.log 2 N : ℝ) + 1) ^ 10 := h1
    _ ≤ Real.exp 10 * ((2 * k + 1) * Λ) ^ 10 := by gcongr
    _ = Real.exp 10 * (2 * k + 1) ^ 10 * Λ ^ (10 : ℝ) := by
        rw [mul_pow, show Λ ^ (10 : ℝ) = Λ ^ (10 : ℕ) by exact_mod_cast Real.rpow_natCast Λ 10]; ring

/-- `Λ^k · exp(−cΛ^τ) ≤ Λ^{−m}` eventually. -/
theorem decay (k m c τ : ℝ) (hkm : 0 ≤ k + m) (hc : 0 < c) (hτ : 0 < τ) :
    ∃ Λ₀ : ℝ, 1 ≤ Λ₀ ∧ ∀ Λ : ℝ, Λ₀ ≤ Λ → Λ ^ k * Real.exp (-(c * Λ ^ τ)) ≤ Λ ^ (-m) := by
  obtain ⟨Λ₀, hΛ₀, h⟩ := GoldC.QuillonAsymp.rpow_le_exp_rpow (k + m) c τ hkm hc hτ
  refine ⟨Λ₀, hΛ₀, fun Λ hΛ => ?_⟩
  have hΛ0 : 0 < Λ := by linarith
  have h1 := h Λ hΛ
  have e : Λ ^ k = Λ ^ (k + m) * Λ ^ (-m) := by rw [← Real.rpow_add hΛ0]; ring_nf
  rw [e]
  have hexp : Real.exp (-(c * Λ ^ τ)) = (Real.exp (c * Λ ^ τ))⁻¹ := by rw [Real.exp_neg]
  rw [hexp]
  have hE : 0 < Real.exp (c * Λ ^ τ) := Real.exp_pos _
  have hm : 0 < Λ ^ (-m) := Real.rpow_pos_of_pos hΛ0 _
  calc Λ ^ (k + m) * Λ ^ (-m) * (Real.exp (c * Λ ^ τ))⁻¹
      ≤ Real.exp (c * Λ ^ τ) * Λ ^ (-m) * (Real.exp (c * Λ ^ τ))⁻¹ := by gcongr
    _ = Λ ^ (-m) := by field_simp

/-- `x₀ ≤ exp(cΛ^τ)` eventually. -/
theorem exp_ge (x₀ c τ : ℝ) (hc : 0 < c) (hτ : 0 < τ) :
    ∃ Λ₀ : ℝ, 1 ≤ Λ₀ ∧ ∀ Λ : ℝ, Λ₀ ≤ Λ → x₀ ≤ Real.exp (c * Λ ^ τ) := by
  obtain ⟨Λ₀, hΛ₀, h⟩ := const_le_rpow (|x₀| / c) τ hτ
  refine ⟨Λ₀, hΛ₀, fun Λ hΛ => ?_⟩
  have h1 := h Λ hΛ
  have h2 : |x₀| ≤ c * Λ ^ τ := by rw [div_le_iff₀ hc] at h1; linarith
  have h3 := Real.add_one_le_exp (c * Λ ^ τ)
  have := le_abs_self x₀
  linarith

end GoldC.QuillonLam

#print axioms GoldC.QuillonLam.Aω_le
#print axioms GoldC.QuillonLam.prodU_le_pow
#print axioms GoldC.QuillonLam.decay
#print axioms GoldC.QuillonLam.exp_ge
