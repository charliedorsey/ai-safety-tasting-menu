import PaperB.FixedQ.EtaCharacterBound
import PaperB.FixedQ.OmegaLinearMean

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def omegaCharacterPartialSum
    (q X : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q)) : ℂ :=
  ∑ n ∈ Finset.Icc 1 X, (chi n) * (omegaCoeff q n : ℂ)

theorem characterOmegaPartialSum_eq_correction_harmonic
    (q X : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q)) :
    omegaCharacterPartialSum q X chi =
      ∑ d ∈ Finset.Icc 1 X,
        (chi d) * (omegaCorrectionInvTerm q d : ℂ) *
          characterHarmonicIcc chi (X / d) := by
  classical
  unfold omegaCharacterPartialSum
  calc
    (∑ n ∈ Finset.Icc 1 X, (chi n) * (omegaCoeff q n : ℂ))
      = ∑ n ∈ Finset.Icc 1 X,
          ∑ ds ∈ n.divisorsAntidiagonal,
            (chi n) *
              ((omegaCorrectionInvTerm q ds.2 : ℂ) *
                ((coprimeIndicatorArithmetic q ds.1 : ℝ) : ℂ) /
                  (ds.1 : ℂ)) := by
          apply Finset.sum_congr rfl
          intro n hn
          have hn0 : n ≠ 0 := by
            rw [Finset.mem_Icc] at hn
            omega
          rw [omegaCoeff_eq_correction_divisor_sum q n hn0]
          push_cast
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro ds hds
          ring
    _ = ∑ n ∈ Finset.Icc 1 X,
          ∑ ds ∈ n.divisorsAntidiagonal,
            (chi ds.2) * (omegaCorrectionInvTerm q ds.2 : ℂ) *
              ((chi ds.1) *
                ((coprimeIndicatorArithmetic q ds.1 : ℝ) : ℂ) /
                  (ds.1 : ℂ)) := by
          apply Finset.sum_congr rfl
          intro n hn
          apply Finset.sum_congr rfl
          intro ds hds
          have hprod : ds.1 * ds.2 = n :=
            (Nat.mem_divisorsAntidiagonal.mp hds).1
          have hcast0 :=
            congrArg (fun t : ℕ => (t : ZMod (Nat.lcm 6 q))) hprod
          have hcast :
              (ds.1 : ZMod (Nat.lcm 6 q)) *
                  (ds.2 : ZMod (Nat.lcm 6 q)) =
                (n : ZMod (Nat.lcm 6 q)) := by
            simpa [Nat.cast_mul] using hcast0
          rw [← hcast, map_mul]
          ring
    _ = ∑ x ∈ petermannDivisorSigma X,
          (chi x.2.2) * (omegaCorrectionInvTerm q x.2.2 : ℂ) *
            ((chi x.2.1) *
              ((coprimeIndicatorArithmetic q x.2.1 : ℝ) : ℂ) /
                (x.2.1 : ℂ)) := by
          rw [petermannDivisorSigma, Finset.sum_sigma']
    _ = ∑ d ∈ Finset.Icc 1 X,
          ∑ m ∈ Finset.Icc 1 (X / d),
            (chi d) * (omegaCorrectionInvTerm q d : ℂ) *
              ((chi m) *
                ((coprimeIndicatorArithmetic q m : ℝ) : ℂ) /
                  (m : ℂ)) := by
          exact sum_petermannDivisorSigma_eq_nested X
            (fun d m =>
              (chi d) * (omegaCorrectionInvTerm q d : ℂ) *
                ((chi m) *
                  ((coprimeIndicatorArithmetic q m : ℝ) : ℂ) /
                    (m : ℂ)))
    _ = ∑ d ∈ Finset.Icc 1 X,
        (chi d) * (omegaCorrectionInvTerm q d : ℂ) *
          characterHarmonicIcc chi (X / d) := by
          apply Finset.sum_congr rfl
          intro d hd
          rw [← Finset.mul_sum]
          congr 1
          unfold characterHarmonicIcc
          apply Finset.sum_congr rfl
          intro m hm
          have hm0 : m ≠ 0 := by
            rw [Finset.mem_Icc] at hm
            omega
          rw [dirichletCharacter_mul_coprimeIndicator q m chi hm0]
          have hmR : (m : ℂ) ≠ 0 := by
            exact_mod_cast hm0
          simp [div_eq_mul_inv, hmR, Complex.ofReal_inv, mul_assoc]

#print axioms characterOmegaPartialSum_eq_correction_harmonic

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem norm_omegaCharacterPartialSum_le
    (q X : ℕ) (hq : 0 < q)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (hchi : chi ≠ 1) :
    ‖omegaCharacterPartialSum q X chi‖ ≤
      2 * ((Nat.lcm 6 q : ℕ) + 1) * omegaRankinBound := by
  rw [characterOmegaPartialSum_eq_correction_harmonic]
  let L := Nat.lcm 6 q
  have hL : 0 < L := Nat.lcm_pos (by norm_num) hq
  have hR0 : 0 ≤ omegaRankinBound := by
    unfold omegaRankinBound
    positivity
  calc
    ‖∑ d ∈ Finset.Icc 1 X,
        (chi d) * (omegaCorrectionInvTerm q d : ℂ) *
          characterHarmonicIcc chi (X / d)‖
      ≤ ∑ d ∈ Finset.Icc 1 X,
          ‖(chi d) * (omegaCorrectionInvTerm q d : ℂ) *
            characterHarmonicIcc chi (X / d)‖ := by
            exact norm_sum_le _ _
    _ ≤ ∑ d ∈ Finset.Icc 1 X,
          |omegaCorrectionInvTerm q d| * (2 * (L + 1)) := by
            apply Finset.sum_le_sum
            intro d hd
            have hchi1 := chi.norm_le_one (d : ZMod L)
            have hharm :=
              norm_characterHarmonicIcc_le hL chi hchi (X / d)
            rw [norm_mul, norm_mul, Complex.norm_real]
            have hInv0 : 0 ≤ |omegaCorrectionInvTerm q d| := abs_nonneg _
            have hH0 : 0 ≤ ‖characterHarmonicIcc chi (X / d)‖ :=
              norm_nonneg _
            calc
              ‖chi (d : ZMod L)‖ * |omegaCorrectionInvTerm q d| *
                  ‖characterHarmonicIcc chi (X / d)‖
                  ≤ |omegaCorrectionInvTerm q d| *
                      ‖characterHarmonicIcc chi (X / d)‖ := by
                    apply mul_le_mul_of_nonneg_right _ hH0
                    simpa using
                      mul_le_mul_of_nonneg_right hchi1 hInv0
              _ ≤ |omegaCorrectionInvTerm q d| * (2 * (L + 1)) :=
                    mul_le_mul_of_nonneg_left hharm hInv0
    _ = (2 * (L + 1)) *
          ∑ d ∈ Finset.Icc 1 X, |omegaCorrectionInvTerm q d| := by
            rw [Finset.mul_sum]
            apply Finset.sum_congr rfl
            intro d hd
            ring
    _ ≤ (2 * (L + 1)) * omegaRankinBound := by
            apply mul_le_mul_of_nonneg_left _ (by positivity)
            calc
              (∑ d ∈ Finset.Icc 1 X, |omegaCorrectionInvTerm q d|)
                  ≤ ∑' d : ℕ, |omegaCorrectionInvTerm q d| := by
                    exact (summable_omegaCorrectionInvTerm q).abs.sum_le_tsum
                      (Finset.Icc 1 X) (fun d hd => abs_nonneg _)
              _ ≤ omegaRankinBound :=
                    tsum_abs_omegaCorrectionInvTerm_le_bound q
    _ = 2 * ((Nat.lcm 6 q : ℕ) + 1) * omegaRankinBound := by
            rfl

#print axioms norm_omegaCharacterPartialSum_le

end PaperB.FixedQ
