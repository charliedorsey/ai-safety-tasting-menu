import PaperB.Analytic.Basic
import Mathlib.Algebra.Order.Round
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds

open scoped BigOperators

namespace PaperB.Analytic
open Real Finset Nat

lemma eR_int_core (z : ℤ) : eR (z : ℝ) = 1 := by
  rw [eR]
  have heq :
      2 * Real.pi * Complex.I * ((z : ℝ) : ℂ) =
        (z : ℂ) * (2 * (Real.pi : ℂ) * Complex.I) := by
    push_cast
    ring
  rw [heq, Complex.exp_int_mul_two_pi_mul_I]

lemma eR_add_int_core (x : ℝ) (z : ℤ) :
    eR (x + z) = eR x := by
  rw [eR_add, eR_int_core, mul_one]

lemma eR_nat_mul_sub_round_core (k : ℕ) (x : ℝ) :
    eR ((k : ℝ) * x) =
      eR ((k : ℝ) * (x - (round x : ℝ))) := by
  have hz :
      (k : ℝ) * x =
        (k : ℝ) * (x - (round x : ℝ)) + ((k : ℤ) * round x : ℤ) := by
    push_cast
    ring
  rw [hz, eR_add_int_core]

lemma norm_eR_sub_one_le_core (x : ℝ) :
    ‖eR x - 1‖ ≤ 2 * Real.pi * |x| := by
  have hid :
      eR x = Complex.exp (Complex.I * (2 * Real.pi * x : ℝ)) := by
    rw [eR]
    congr 1
    push_cast
    ring
  rw [hid]
  have h := Real.norm_exp_I_mul_ofReal_sub_one_le
    (x := 2 * Real.pi * x)
  simpa [Real.norm_eq_abs, abs_mul, abs_of_pos Real.pi_pos,
    mul_assoc, mul_left_comm, mul_comm] using h

noncomputable def etaFejerPhaseSumCore (J : ℕ) (x : ℝ) : ℂ :=
  ∑ k ∈ Finset.range J, eR ((k : ℝ) * x)

lemma etaFejerPhaseSumCore_sub_natCast_norm_le
    {J : ℕ} {x d : ℝ}
    (hd : d = x - (round x : ℝ)) :
    ‖etaFejerPhaseSumCore J x - (J : ℂ)‖
      ≤ Real.pi * (J : ℝ) * ((J : ℝ) - 1) * |d| := by
  rw [show (J : ℂ) = ∑ _k ∈ Finset.range J, (1 : ℂ) by simp]
  unfold etaFejerPhaseSumCore
  rw [← Finset.sum_sub_distrib]
  calc
    ‖∑ k ∈ Finset.range J, (eR ((k : ℝ) * x) - 1)‖
      ≤ ∑ k ∈ Finset.range J, ‖eR ((k : ℝ) * x) - 1‖ :=
        norm_sum_le _ _
    _ = ∑ k ∈ Finset.range J,
        ‖eR ((k : ℝ) * d) - 1‖ := by
      apply Finset.sum_congr rfl
      intro k hk
      rw [eR_nat_mul_sub_round_core]
      rw [hd]
    _ ≤ ∑ k ∈ Finset.range J,
        2 * Real.pi * |((k : ℝ) * d)| := by
      apply Finset.sum_le_sum
      intro k hk
      exact norm_eR_sub_one_le_core _
    _ = Real.pi * (J : ℝ) * ((J : ℝ) - 1) * |d| := by
      have hkabs : ∀ k : ℕ, |(k : ℝ)| = (k : ℝ) := by
        intro k
        exact abs_of_nonneg (Nat.cast_nonneg k)
      simp_rw [abs_mul, hkabs]
      calc
        (∑ k ∈ Finset.range J, 2 * Real.pi * ((k : ℝ) * |d|))
          = (2 * Real.pi * |d|) *
              ∑ k ∈ Finset.range J, (k : ℝ) := by
                rw [Finset.mul_sum]
                apply Finset.sum_congr rfl
                intro k hk
                ring
        _ = Real.pi * (J : ℝ) * ((J : ℝ) - 1) * |d| := by
          have hsum :
              (∑ k ∈ Finset.range J, (k : ℝ)) =
                (J : ℝ) * ((J : ℝ) - 1) / 2 := by
            induction J with
            | zero => simp
            | succ n ih =>
                rw [Finset.sum_range_succ, ih]
                push_cast
                ring
          rw [hsum]
          ring

lemma etaFejerPhaseSumCore_norm_ge_half
    {J : ℕ} (hJ : 1 ≤ J)
    {x S : ℝ} (hS : S = 8 * (J : ℝ))
    (hnear : |x - (round x : ℝ)| ≤ 1 / (2 * S)) :
    (J : ℝ) / 2 ≤ ‖etaFejerPhaseSumCore J x‖ := by
  let d := x - (round x : ℝ)
  have hdiff := etaFejerPhaseSumCore_sub_natCast_norm_le
    (J := J) (x := x) (d := d) rfl
  have hpi : Real.pi < 4 := Real.pi_lt_four
  have hJr : (1 : ℝ) ≤ (J : ℝ) := by exact_mod_cast hJ
  have hJpos : 0 < (J : ℝ) := lt_of_lt_of_le (by norm_num) hJr
  have hJ0 : (J : ℝ) ≠ 0 := ne_of_gt hJpos
  have hd : |d| ≤ 1 / (16 * (J : ℝ)) := by
    dsimp [d]
    rw [hS] at hnear
    have hden :
        (2 : ℝ) * (8 * (J : ℝ)) = 16 * (J : ℝ) := by ring
    rw [hden] at hnear
    exact hnear
  have hdiff2 :
      ‖etaFejerPhaseSumCore J x - (J : ℂ)‖ ≤ (J : ℝ) / 4 := by
    calc
      ‖etaFejerPhaseSumCore J x - (J : ℂ)‖
        ≤ Real.pi * (J : ℝ) * ((J : ℝ) - 1) * |d| := hdiff
      _ ≤ Real.pi * (J : ℝ) * ((J : ℝ) - 1) *
          (1 / (16 * (J : ℝ))) := by
            gcongr
      _ = Real.pi * ((J : ℝ) - 1) / 16 := by
            field_simp [hJ0]
      _ ≤ (J : ℝ) / 4 := by
            rw [div_le_iff₀ (by norm_num : (0 : ℝ) < 16)]
            nlinarith
  have hrev0 := norm_sub_norm_le (J : ℂ) (etaFejerPhaseSumCore J x)
  have hJnorm : ‖(J : ℂ)‖ = (J : ℝ) := by simp
  have hsym :
      ‖(J : ℂ) - etaFejerPhaseSumCore J x‖ =
        ‖etaFejerPhaseSumCore J x - (J : ℂ)‖ := by
    rw [← norm_neg]
    congr 1
    ring
  rw [hJnorm, hsym] at hrev0
  linarith

lemma etaFejerCore_majorant
    {J : ℕ} (hJ : 1 ≤ J)
    {x : ℝ}
    (hnear : |x - (round x : ℝ)| ≤ 1 / (16 * (J : ℝ))) :
    (1 : ℝ) ≤
      (4 / (J : ℝ)^2) * ‖etaFejerPhaseSumCore J x‖^2 := by
  have hnear' :
      |x - (round x : ℝ)| ≤ 1 / (2 * (8 * (J : ℝ))) := by
    simpa only [show (2 : ℝ) * (8 * (J : ℝ)) = 16 * (J : ℝ) by ring] using hnear
  have hnorm := etaFejerPhaseSumCore_norm_ge_half
    hJ (x := x) (S := 8 * (J : ℝ)) rfl hnear'
  have hJr : 0 < (J : ℝ) := by exact_mod_cast (show 0 < J by omega)
  have hsq :
      (J : ℝ)^2 ≤ 4 * ‖etaFejerPhaseSumCore J x‖^2 := by
    nlinarith [sq_nonneg (‖etaFejerPhaseSumCore J x‖ - (J : ℝ) / 2)]
  have hJ2 : 0 < (J : ℝ)^2 := sq_pos_of_pos hJr
  calc
    (1 : ℝ) = (J : ℝ)^2 / (J : ℝ)^2 := by
      field_simp [ne_of_gt hJr]
    _ ≤ (4 * ‖etaFejerPhaseSumCore J x‖^2) / (J : ℝ)^2 := by
      exact div_le_div_of_nonneg_right hsq hJ2.le
    _ = (4 / (J : ℝ)^2) * ‖etaFejerPhaseSumCore J x‖^2 := by
      ring

#print axioms etaFejerCore_majorant
end PaperB.Analytic
