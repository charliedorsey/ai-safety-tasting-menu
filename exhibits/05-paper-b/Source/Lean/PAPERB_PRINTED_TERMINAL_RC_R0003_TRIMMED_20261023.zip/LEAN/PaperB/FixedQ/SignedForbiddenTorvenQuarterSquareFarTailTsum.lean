import PaperB.FixedQ.SignedForbiddenTorvenQuarterSquareFarTail
import PaperB.FixedQ.SignedForbiddenNaturalFarTailTsum

open scoped BigOperators
namespace PaperB.FixedQ

lemma torven_half_square_lt_of_quad_product_gt_sq
    {H m : ℕ} (hgt : H ^ 2 < 4 * m) :
    (H / 2) ^ 2 < m := by
  have htwice : 2 * (H / 2) ≤ H := by omega
  have hpow : (2 * (H / 2)) ^ 2 ≤ H ^ 2 := by
    gcongr
  have hquarter : 4 * (H / 2) ^ 2 ≤ H ^ 2 := by
    nlinarith [hpow]
  omega

/-- Complete natural-modulus geometric far tail controlled by quarter moment. -/
theorem torven_abs_sourceForbiddenNaturalQuarterTail_tsum_le
    {q a H : ℕ}
    (hq : 0 < q) (hH : 2 ≤ H)
    (h2 : ¬ 2 ∣ q → 2 ∣ H)
    (d : Finset ℕ) :
    |∑' m : ℕ,
        if H ^ 2 < 4 * m then
          sourceForbiddenBooleanNaturalTerm
            q a H (primeSetProduct d) m
        else 0| ≤
      6 * (H : ℝ) * fixedQShiuReciprocalFarTail q (H / 2) := by
  let S : Set ℕ := {m | H ^ 2 < 4 * m}
  let f : ℕ → ℝ := fun m =>
    if H ^ 2 < 4 * m then
      sourceForbiddenBooleanNaturalTerm q a H (primeSetProduct d) m
    else 0
  let g : ℕ → ℝ := fun m =>
    if (H / 2) ^ 2 < m then fixedQShiuWeight q m / (m : ℝ) else 0
  have hhalf : 0 < H / 2 := by omega
  have hHpos : 0 < H := by omega
  have hsrc0 :=
    summable_sourceForbiddenBooleanNaturalTerm
      (q := q) (a := a) (H := H) hq hHpos h2 d
  have hf : Summable f := by
    have hind := hsrc0.indicator S
    exact hind.congr (fun m => by
      dsimp [f, S]
      by_cases hm : H ^ 2 < 4 * m <;> simp [Set.indicator, hm])
  have hg : Summable g := by
    dsimp [g]
    exact summable_fixedQShiuReciprocalFarTailTerm q hhalf
  have hmajor : ∀ m, |f m| ≤ 6 * (H : ℝ) * g m := by
    intro m
    dsimp [f, g]
    by_cases hm : H ^ 2 < 4 * m
    · rw [if_pos hm, if_pos (torven_half_square_lt_of_quad_product_gt_sq hm)]
      exact torven_abs_sourceForbiddenBooleanNaturalTerm_quad_far_le h2 hm
    · rw [if_neg hm]
      simp only [abs_zero]
      by_cases ht : (H / 2) ^ 2 < m
      · rw [if_pos ht]
        exact mul_nonneg
          (mul_nonneg (by norm_num) (Nat.cast_nonneg H))
          (div_nonneg (fixedQShiuWeight_nonneg q m) (Nat.cast_nonneg m))
      · rw [if_neg ht]
        norm_num
  have hgmul : Summable (fun m => 6 * (H : ℝ) * g m) :=
    hg.mul_left (6 * (H : ℝ))
  have hnormsum :
      (∑' m, |f m|) ≤ ∑' m, 6 * (H : ℝ) * g m := by
    exact hf.norm.tsum_le_tsum hmajor hgmul
  calc
    |∑' m, f m| ≤ ∑' m, |f m| := by
      simpa [Real.norm_eq_abs] using norm_tsum_le_tsum_norm hf.norm
    _ ≤ ∑' m, 6 * (H : ℝ) * g m := hnormsum
    _ = 6 * (H : ℝ) * (∑' m, g m) := by rw [tsum_mul_left]
    _ = 6 * (H : ℝ) * fixedQShiuReciprocalFarTail q (H / 2) := by
      rfl

#print axioms torven_half_square_lt_of_quad_product_gt_sq
#print axioms torven_abs_sourceForbiddenNaturalQuarterTail_tsum_le

end PaperB.FixedQ
