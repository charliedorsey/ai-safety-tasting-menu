import PaperB.FixedQ.SignedForbiddenEndpointComponentRate
import PaperB.FixedQ.DecoratedAnalyticPerEBridge
import PaperB.FixedQ.SignedForbiddenBridge
import PaperB.FixedQ.H3DecoratedAnalyticShell
import PaperB.FixedQ.H2GlobalReaggregation
import PaperB.FixedQ.PureHeightReflection
import PaperB.ExactAccounting.H1FloorFamilyBridge
import PaperB.Admission.H1

open scoped BigOperators

namespace PaperB.FixedQ

theorem decoratedLeftEndpoint_union_reconstruct
    {q a h : ℕ} {d n : Finset ℕ}
    (hd : d ⊆ decoratedHeightPrimeSet q h)
    (hn : n ∈ activeOrdinaryTwoDimensionalSet q
      (h / primeSetProduct d))
    (hdis : Disjoint d n)
    (hne : n.Nonempty) :
    decoratedAnalyticPairTerm q a h (d ∪ n) (d ∪ n) =
      finiteVWeightReal h d *
        dForbiddenBooleanLeftEndpointTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) d n := by
  classical
  have hheight := heightPrimePart_union_eq_left_of_reduced_ordinary hd hn hdis
  have hAall : ∀ p ∈ d ∪ n, activeHighPrime q p := by
    intro p hp
    rcases Finset.mem_union.mp hp with hpd | hpn
    · exact decoratedHeightPrimeSet_active hd p hpd
    · exact hn.2 p hpn
  have hrec := decoratedAnalyticPairTerm_eq_partition
    (q := q) (a := a) (h := h) (e := d ∪ n) (e1 := d ∪ n)
    (fun _ hp => hp) hAall (by simpa [hheight])
  rw [dForbiddenBooleanLeftEndpointTerm, if_pos ⟨hdis, hne⟩]
  rw [Set.indicator_of_mem hn]
  have hnd : n \ d = n := by
    ext p
    simp only [Finset.mem_sdiff, and_iff_left_iff_imp]
    intro hpn hpd
    exact (Finset.disjoint_left.mp hdis hpd hpn).elim
  have hsdiff : (d ∪ n) \ d = n := by
    rw [Finset.union_sdiff_left, hnd]
  simpa [decoratedHeightProduct, decoratedReducedHeight, hheight, hsdiff,
    mul_assoc] using hrec

theorem decoratedRightEndpoint_union_reconstruct
    {q a h : ℕ} {d n : Finset ℕ}
    (hd : d ⊆ decoratedHeightPrimeSet q h)
    (hn : n ∈ activeOrdinaryTwoDimensionalSet q
      (h / primeSetProduct d))
    (hdis : Disjoint d n)
    (hne : n.Nonempty) :
    decoratedAnalyticPairTerm q a h (d ∪ n) d =
      finiteVWeightReal h d *
        dForbiddenBooleanRightEndpointTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) d n := by
  classical
  have hheight := heightPrimePart_union_eq_left_of_reduced_ordinary hd hn hdis
  have hAall : ∀ p ∈ d ∪ n, activeHighPrime q p := by
    intro p hp
    rcases Finset.mem_union.mp hp with hpd | hpn
    · exact decoratedHeightPrimeSet_active hd p hpd
    · exact hn.2 p hpn
  have hrec := decoratedAnalyticPairTerm_eq_partition
    (q := q) (a := a) (h := h) (e := d ∪ n) (e1 := d)
    (Finset.subset_union_left) hAall (by simpa [hheight])
  rw [dForbiddenBooleanRightEndpointTerm, if_pos ⟨hdis, hne⟩]
  rw [Set.indicator_of_mem hn]
  have hnd : n \ d = n := by
    ext p
    simp only [Finset.mem_sdiff, and_iff_left_iff_imp]
    intro hpn hpd
    exact (Finset.disjoint_left.mp hdis hpd hpn).elim
  have hsdiff : (d ∪ n) \ d = n := by
    rw [Finset.union_sdiff_left, hnd]
  simpa [decoratedHeightProduct, decoratedReducedHeight, hheight, hsdiff,
    mul_assoc] using hrec

#print axioms decoratedLeftEndpoint_union_reconstruct
#print axioms decoratedRightEndpoint_union_reconstruct


def decoratedMixedEndpointSupport (q h : ℕ) : Set (Finset ℕ) :=
  {e | (∀ p ∈ e, activeHighPrime q p) ∧
    (heightPrimePart h e).Nonempty ∧
    heightPrimePart h e ≠ e}

noncomputable def decoratedHeightRestrictedLeftEndpointPairTerm
    (q a h : ℕ) (dn : Finset ℕ × Finset ℕ) : ℝ :=
  let d := dn.1
  let n := dn.2
  if d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty then
    finiteVWeightReal h d *
      dForbiddenBooleanLeftEndpointTerm q
        (decoratedReducedAnchor q a (primeSetProduct d))
        (h / primeSetProduct d) d n
  else 0

noncomputable def decoratedHeightRestrictedRightEndpointPairTerm
    (q a h : ℕ) (dn : Finset ℕ × Finset ℕ) : ℝ :=
  let d := dn.1
  let n := dn.2
  if d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty then
    finiteVWeightReal h d *
      dForbiddenBooleanRightEndpointTerm q
        (decoratedReducedAnchor q a (primeSetProduct d))
        (h / primeSetProduct d) d n
  else 0

noncomputable def decoratedHeightRestrictedLeftEndpointReindexTerm
    (q a h : ℕ)
    (x : (Finset ℕ × Finset ℕ) ⊕ Finset ℕ) : ℝ :=
  match x with
  | Sum.inl dn => decoratedHeightRestrictedLeftEndpointPairTerm q a h dn
  | Sum.inr _ => 0

noncomputable def decoratedHeightRestrictedRightEndpointReindexTerm
    (q a h : ℕ)
    (x : (Finset ℕ × Finset ℕ) ⊕ Finset ℕ) : ℝ :=
  match x with
  | Sum.inl dn => decoratedHeightRestrictedRightEndpointPairTerm q a h dn
  | Sum.inr _ => 0

theorem mixedLeft_indicator_eq_reindexTerm
    {q a h : ℕ} (hh : 0 < h) (e : Finset ℕ) :
    (decoratedMixedEndpointSupport q h).indicator
        (fun e => decoratedAnalyticPairTerm q a h e e) e =
      decoratedHeightRestrictedLeftEndpointReindexTerm q a h
        (decoratedAnalyticSignedReindexKey q h e) := by
  classical
  by_cases hs : e ∈ decoratedMixedEndpointSupport q h
  · rw [Set.indicator_of_mem hs]
    rcases hs with ⟨hA, hdne, hall⟩
    let d := heightPrimePart h e
    let n := e \ d
    have hdsub : d ⊆ decoratedHeightPrimeSet q h := by
      dsimp [d]
      exact heightPrimePart_subset_decoratedHeightPrimeSet_of_active hh hA
    have hdmem : d ∈ (decoratedHeightPrimeSet q h).powerset :=
      Finset.mem_powerset.mpr hdsub
    have hdne' : d.Nonempty := by
      simpa [d] using hdne
    have hdis : Disjoint d n := by
      dsimp [n]
      exact Finset.disjoint_sdiff
    have hn : n ∈ activeOrdinaryTwoDimensionalSet q
        (h / primeSetProduct d) := by
      have h0 := decorated_nonheight_activeOrdinary
        (q := q) (h := h) (e := e) hA
      simpa [d, n, decoratedReducedHeight, decoratedHeightProduct] using h0
    have hnne : n.Nonempty := by
      dsimp [n, d]
      apply Finset.sdiff_nonempty.mpr
      intro hsub
      apply hall
      exact Finset.Subset.antisymm (Finset.filter_subset _ _) hsub
    have hu : d ∪ n = e := by
      dsimp [d, n]
      exact Finset.union_sdiff_of_subset (Finset.filter_subset _ _)
    have hrec := decoratedLeftEndpoint_union_reconstruct
      (q := q) (a := a) (h := h) (d := d) (n := n)
      hdsub hn hdis hnne
    rw [decoratedAnalyticSignedReindexKey, if_pos hA]
    simp only [decoratedHeightRestrictedLeftEndpointReindexTerm]
    change decoratedAnalyticPairTerm q a h e e =
      (if _ : d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty then
        finiteVWeightReal h d *
          dForbiddenBooleanLeftEndpointTerm q
            (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d) d n
      else 0)
    simpa [hu, hdmem, hdne'] using hrec
  · simp only [Set.indicator, hs, if_false]
    by_cases hA : ∀ p ∈ e, activeHighPrime q p
    · rw [decoratedAnalyticSignedReindexKey, if_pos hA]
      simp only [decoratedHeightRestrictedLeftEndpointReindexTerm]
      let d := heightPrimePart h e
      let n := e \ d
      by_cases hdne : d.Nonempty
      · have hall : d = e := by
          by_contra hne
          apply hs
          exact ⟨hA, hdne, hne⟩
        have hdsub : d ⊆ decoratedHeightPrimeSet q h := by
          dsimp [d]
          exact heightPrimePart_subset_decoratedHeightPrimeSet_of_active hh hA
        have hdmem : d ∈ (decoratedHeightPrimeSet q h).powerset :=
          Finset.mem_powerset.mpr hdsub
        have hn0 : n = ∅ := by
          dsimp [n]
          rw [hall, Finset.sdiff_self]
        change 0 =
          decoratedHeightRestrictedLeftEndpointPairTerm q a h (d, n)
        rw [decoratedHeightRestrictedLeftEndpointPairTerm,
          if_pos ⟨hdmem, hdne⟩]
        have hterm :
            dForbiddenBooleanLeftEndpointTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) d n = 0 := by
          rw [hn0]
          simp [dForbiddenBooleanLeftEndpointTerm]
        rw [hterm, mul_zero]
      · change 0 =
          decoratedHeightRestrictedLeftEndpointPairTerm q a h (d, n)
        rw [decoratedHeightRestrictedLeftEndpointPairTerm,
          if_neg (by intro hg; exact hdne hg.2)]
    · rw [decoratedAnalyticSignedReindexKey, if_neg hA]
      simp [decoratedHeightRestrictedLeftEndpointReindexTerm]

theorem mixedRight_indicator_eq_reindexTerm
    {q a h : ℕ} (hh : 0 < h) (e : Finset ℕ) :
    (decoratedMixedEndpointSupport q h).indicator
        (fun e => decoratedAnalyticPairTerm q a h e (heightPrimePart h e)) e =
      decoratedHeightRestrictedRightEndpointReindexTerm q a h
        (decoratedAnalyticSignedReindexKey q h e) := by
  classical
  by_cases hs : e ∈ decoratedMixedEndpointSupport q h
  · rw [Set.indicator_of_mem hs]
    rcases hs with ⟨hA, hdne, hall⟩
    let d := heightPrimePart h e
    let n := e \ d
    have hdsub : d ⊆ decoratedHeightPrimeSet q h := by
      dsimp [d]
      exact heightPrimePart_subset_decoratedHeightPrimeSet_of_active hh hA
    have hdmem : d ∈ (decoratedHeightPrimeSet q h).powerset :=
      Finset.mem_powerset.mpr hdsub
    have hdne' : d.Nonempty := by
      simpa [d] using hdne
    have hdis : Disjoint d n := by
      dsimp [n]
      exact Finset.disjoint_sdiff
    have hn : n ∈ activeOrdinaryTwoDimensionalSet q
        (h / primeSetProduct d) := by
      have h0 := decorated_nonheight_activeOrdinary
        (q := q) (h := h) (e := e) hA
      simpa [d, n, decoratedReducedHeight, decoratedHeightProduct] using h0
    have hnne : n.Nonempty := by
      dsimp [n, d]
      apply Finset.sdiff_nonempty.mpr
      intro hsub
      apply hall
      exact Finset.Subset.antisymm (Finset.filter_subset _ _) hsub
    have hu : d ∪ n = e := by
      dsimp [d, n]
      exact Finset.union_sdiff_of_subset (Finset.filter_subset _ _)
    have hrec := decoratedRightEndpoint_union_reconstruct
      (q := q) (a := a) (h := h) (d := d) (n := n)
      hdsub hn hdis hnne
    rw [decoratedAnalyticSignedReindexKey, if_pos hA]
    simp only [decoratedHeightRestrictedRightEndpointReindexTerm]
    change decoratedAnalyticPairTerm q a h e d =
      (if _ : d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty then
        finiteVWeightReal h d *
          dForbiddenBooleanRightEndpointTerm q
            (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d) d n
      else 0)
    simpa [hu, hdmem, hdne'] using hrec
  · simp only [Set.indicator, hs, if_false]
    by_cases hA : ∀ p ∈ e, activeHighPrime q p
    · rw [decoratedAnalyticSignedReindexKey, if_pos hA]
      simp only [decoratedHeightRestrictedRightEndpointReindexTerm]
      let d := heightPrimePart h e
      let n := e \ d
      by_cases hdne : d.Nonempty
      · have hall : d = e := by
          by_contra hne
          apply hs
          exact ⟨hA, hdne, hne⟩
        have hdsub : d ⊆ decoratedHeightPrimeSet q h := by
          dsimp [d]
          exact heightPrimePart_subset_decoratedHeightPrimeSet_of_active hh hA
        have hdmem : d ∈ (decoratedHeightPrimeSet q h).powerset :=
          Finset.mem_powerset.mpr hdsub
        have hn0 : n = ∅ := by
          dsimp [n]
          rw [hall, Finset.sdiff_self]
        change 0 =
          decoratedHeightRestrictedRightEndpointPairTerm q a h (d, n)
        rw [decoratedHeightRestrictedRightEndpointPairTerm,
          if_pos ⟨hdmem, hdne⟩]
        have hterm :
            dForbiddenBooleanRightEndpointTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) d n = 0 := by
          rw [hn0]
          simp [dForbiddenBooleanRightEndpointTerm]
        rw [hterm, mul_zero]
      · change 0 =
          decoratedHeightRestrictedRightEndpointPairTerm q a h (d, n)
        rw [decoratedHeightRestrictedRightEndpointPairTerm,
          if_neg (by intro hg; exact hdne hg.2)]
    · rw [decoratedAnalyticSignedReindexKey, if_neg hA]
      simp [decoratedHeightRestrictedRightEndpointReindexTerm]


noncomputable def decoratedHeightRestrictedLeftEndpointAbsPairTerm
    (q a h : ℕ) (dn : Finset ℕ × Finset ℕ) : ℝ :=
  let d := dn.1
  let n := dn.2
  if d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty then
    finiteVWeightReal h d *
      |dForbiddenBooleanLeftEndpointTerm q
        (decoratedReducedAnchor q a (primeSetProduct d))
        (h / primeSetProduct d) d n|
  else 0

noncomputable def decoratedHeightRestrictedRightEndpointAbsPairTerm
    (q a h : ℕ) (dn : Finset ℕ × Finset ℕ) : ℝ :=
  let d := dn.1
  let n := dn.2
  if d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty then
    finiteVWeightReal h d *
      |dForbiddenBooleanRightEndpointTerm q
        (decoratedReducedAnchor q a (primeSetProduct d))
        (h / primeSetProduct d) d n|
  else 0

lemma decoratedHeightRestrictedLeftEndpointAbsPairTerm_nonneg
    (q a h : ℕ) (dn : Finset ℕ × Finset ℕ) :
    0 ≤ decoratedHeightRestrictedLeftEndpointAbsPairTerm q a h dn := by
  rcases dn with ⟨d, n⟩
  unfold decoratedHeightRestrictedLeftEndpointAbsPairTerm
  dsimp
  by_cases hd : d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty
  · rw [if_pos hd]
    apply mul_nonneg
    · exact finiteVWeightReal_nonneg_of_active
        (decoratedHeightPrimeSet_active (Finset.mem_powerset.mp hd.1))
    · exact abs_nonneg _
  · rw [if_neg hd]

lemma decoratedHeightRestrictedRightEndpointAbsPairTerm_nonneg
    (q a h : ℕ) (dn : Finset ℕ × Finset ℕ) :
    0 ≤ decoratedHeightRestrictedRightEndpointAbsPairTerm q a h dn := by
  rcases dn with ⟨d, n⟩
  unfold decoratedHeightRestrictedRightEndpointAbsPairTerm
  dsimp
  by_cases hd : d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty
  · rw [if_pos hd]
    apply mul_nonneg
    · exact finiteVWeightReal_nonneg_of_active
        (decoratedHeightPrimeSet_active (Finset.mem_powerset.mp hd.1))
    · exact abs_nonneg _
  · rw [if_neg hd]

theorem abs_decoratedHeightRestrictedLeftEndpointPairTerm_eq
    (q a h : ℕ) (dn : Finset ℕ × Finset ℕ) :
    |decoratedHeightRestrictedLeftEndpointPairTerm q a h dn| =
      decoratedHeightRestrictedLeftEndpointAbsPairTerm q a h dn := by
  classical
  rcases dn with ⟨d, n⟩
  unfold decoratedHeightRestrictedLeftEndpointPairTerm
    decoratedHeightRestrictedLeftEndpointAbsPairTerm
  dsimp
  by_cases hd : d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty
  · rw [if_pos hd, if_pos hd, abs_mul]
    have hv0 : 0 ≤ finiteVWeightReal h d :=
      finiteVWeightReal_nonneg_of_active
        (decoratedHeightPrimeSet_active (Finset.mem_powerset.mp hd.1))
    rw [abs_of_nonneg hv0]
  · rw [if_neg hd, if_neg hd, abs_zero]

theorem abs_decoratedHeightRestrictedRightEndpointPairTerm_eq
    (q a h : ℕ) (dn : Finset ℕ × Finset ℕ) :
    |decoratedHeightRestrictedRightEndpointPairTerm q a h dn| =
      decoratedHeightRestrictedRightEndpointAbsPairTerm q a h dn := by
  classical
  rcases dn with ⟨d, n⟩
  unfold decoratedHeightRestrictedRightEndpointPairTerm
    decoratedHeightRestrictedRightEndpointAbsPairTerm
  dsimp
  by_cases hd : d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty
  · rw [if_pos hd, if_pos hd, abs_mul]
    have hv0 : 0 ≤ finiteVWeightReal h d :=
      finiteVWeightReal_nonneg_of_active
        (decoratedHeightPrimeSet_active (Finset.mem_powerset.mp hd.1))
    rw [abs_of_nonneg hv0]
  · rw [if_neg hd, if_neg hd, abs_zero]

theorem summable_decoratedHeightRestrictedLeftEndpointAbsPairTerm
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    Summable (decoratedHeightRestrictedLeftEndpointAbsPairTerm q a h) := by
  rw [summable_prod_of_nonneg
    (decoratedHeightRestrictedLeftEndpointAbsPairTerm_nonneg q a h)]
  constructor
  · intro d
    by_cases hd : d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty
    · have hHpos := decoratedReducedHeight_pos_of_mem hh hd.1
      have hHpar := decoratedReducedHeight_parity_of_mem h2 hd.1
      have hs := summable_dForbiddenBooleanLeftEndpointTerm
        (q := q)
        (a := decoratedReducedAnchor q a (primeSetProduct d))
        (H := h / primeSetProduct d)
        hq hHpos hHpar d
      have hv0 : 0 ≤ finiteVWeightReal h d :=
        finiteVWeightReal_nonneg_of_active
          (decoratedHeightPrimeSet_active (Finset.mem_powerset.mp hd.1))
      simpa [decoratedHeightRestrictedLeftEndpointAbsPairTerm, hd,
        Real.norm_eq_abs] using hs.norm.mul_left (finiteVWeightReal h d)
    · have hd' : ¬(d ⊆ decoratedHeightPrimeSet q h ∧ d.Nonempty) := by
        simpa [Finset.mem_powerset] using hd
      simp [decoratedHeightRestrictedLeftEndpointAbsPairTerm, hd']
  · apply summable_of_hasFiniteSupport
    refine (decoratedHeightPrimeSet q h).powerset.finite_toSet.subset ?_
    intro d hd
    by_contra hdmem
    have hdsub : ¬ d ⊆ decoratedHeightPrimeSet q h := by
      simpa [Finset.mem_powerset] using hdmem
    have hz : (∑' n : Finset ℕ,
        decoratedHeightRestrictedLeftEndpointAbsPairTerm q a h (d, n)) = 0 := by
      simp [decoratedHeightRestrictedLeftEndpointAbsPairTerm, hdsub]
    exact hd hz

theorem summable_decoratedHeightRestrictedRightEndpointAbsPairTerm
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    Summable (decoratedHeightRestrictedRightEndpointAbsPairTerm q a h) := by
  rw [summable_prod_of_nonneg
    (decoratedHeightRestrictedRightEndpointAbsPairTerm_nonneg q a h)]
  constructor
  · intro d
    by_cases hd : d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty
    · have hHpos := decoratedReducedHeight_pos_of_mem hh hd.1
      have hHpar := decoratedReducedHeight_parity_of_mem h2 hd.1
      have hs := summable_dForbiddenBooleanRightEndpointTerm
        (q := q)
        (a := decoratedReducedAnchor q a (primeSetProduct d))
        (H := h / primeSetProduct d)
        hq hHpos hHpar d
      have hv0 : 0 ≤ finiteVWeightReal h d :=
        finiteVWeightReal_nonneg_of_active
          (decoratedHeightPrimeSet_active (Finset.mem_powerset.mp hd.1))
      simpa [decoratedHeightRestrictedRightEndpointAbsPairTerm, hd,
        Real.norm_eq_abs] using hs.norm.mul_left (finiteVWeightReal h d)
    · have hd' : ¬(d ⊆ decoratedHeightPrimeSet q h ∧ d.Nonempty) := by
        simpa [Finset.mem_powerset] using hd
      simp [decoratedHeightRestrictedRightEndpointAbsPairTerm, hd']
  · apply summable_of_hasFiniteSupport
    refine (decoratedHeightPrimeSet q h).powerset.finite_toSet.subset ?_
    intro d hd
    by_contra hdmem
    have hdsub : ¬ d ⊆ decoratedHeightPrimeSet q h := by
      simpa [Finset.mem_powerset] using hdmem
    have hz : (∑' n : Finset ℕ,
        decoratedHeightRestrictedRightEndpointAbsPairTerm q a h (d, n)) = 0 := by
      simp [decoratedHeightRestrictedRightEndpointAbsPairTerm, hdsub]
    exact hd hz

theorem summable_decoratedHeightRestrictedLeftEndpointPairTerm
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    Summable (decoratedHeightRestrictedLeftEndpointPairTerm q a h) := by
  apply Summable.of_norm
  exact (summable_decoratedHeightRestrictedLeftEndpointAbsPairTerm
    (q := q) (a := a) (h := h) hq hh h2).congr (fun dn => by
      rw [Real.norm_eq_abs,
        abs_decoratedHeightRestrictedLeftEndpointPairTerm_eq])

theorem summable_decoratedHeightRestrictedRightEndpointPairTerm
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    Summable (decoratedHeightRestrictedRightEndpointPairTerm q a h) := by
  apply Summable.of_norm
  exact (summable_decoratedHeightRestrictedRightEndpointAbsPairTerm
    (q := q) (a := a) (h := h) hq hh h2).congr (fun dn => by
      rw [Real.norm_eq_abs,
        abs_decoratedHeightRestrictedRightEndpointPairTerm_eq])

theorem tsum_leftEndpointReindex_eq_outer
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    (∑' x, decoratedHeightRestrictedLeftEndpointReindexTerm q a h x) =
      ∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
        finiteVWeightReal h d *
          (∑' n : Finset ℕ,
            dForbiddenBooleanLeftEndpointTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) d n) := by
  have hPair := summable_decoratedHeightRestrictedLeftEndpointPairTerm
    (q := q) (a := a) (h := h) hq hh h2
  have hInl : Summable
      (decoratedHeightRestrictedLeftEndpointReindexTerm q a h ∘ Sum.inl) := by
    simpa [Function.comp_def, decoratedHeightRestrictedLeftEndpointReindexTerm] using hPair
  have hInr : Summable
      (decoratedHeightRestrictedLeftEndpointReindexTerm q a h ∘ Sum.inr) := by
    simp [Function.comp_def, decoratedHeightRestrictedLeftEndpointReindexTerm]
  rw [Summable.tsum_sum hInl hInr]
  simp only [decoratedHeightRestrictedLeftEndpointReindexTerm, tsum_zero, add_zero]
  rw [hPair.tsum_prod]
  rw [tsum_eq_sum (s := (decoratedHeightPrimeSet q h).powerset.erase ∅)]
  · apply Finset.sum_congr rfl
    intro d hd
    have hdps := (Finset.mem_erase.mp hd).2
    have hdne : d.Nonempty :=
      Finset.nonempty_iff_ne_empty.mpr (Finset.mem_erase.mp hd).1
    have hHpos := decoratedReducedHeight_pos_of_mem hh hdps
    have hHpar := decoratedReducedHeight_parity_of_mem h2 hdps
    have hs := summable_dForbiddenBooleanLeftEndpointTerm
      (q := q)
      (a := decoratedReducedAnchor q a (primeSetProduct d))
      (H := h / primeSetProduct d)
      hq hHpos hHpar d
    have hgate : d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty :=
      ⟨hdps, hdne⟩
    simpa [decoratedHeightRestrictedLeftEndpointPairTerm, hgate] using
      hs.tsum_mul_left (finiteVWeightReal h d)
  · intro d hd
    have hout : ¬(d ⊆ decoratedHeightPrimeSet q h ∧ d.Nonempty) := by
      intro hg
      apply hd
      apply Finset.mem_erase.mpr
      exact ⟨Finset.nonempty_iff_ne_empty.mp hg.2,
        Finset.mem_powerset.mpr hg.1⟩
    simp [decoratedHeightRestrictedLeftEndpointPairTerm, hout]

theorem tsum_rightEndpointReindex_eq_outer
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    (∑' x, decoratedHeightRestrictedRightEndpointReindexTerm q a h x) =
      ∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
        finiteVWeightReal h d *
          (∑' n : Finset ℕ,
            dForbiddenBooleanRightEndpointTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) d n) := by
  have hPair := summable_decoratedHeightRestrictedRightEndpointPairTerm
    (q := q) (a := a) (h := h) hq hh h2
  have hInl : Summable
      (decoratedHeightRestrictedRightEndpointReindexTerm q a h ∘ Sum.inl) := by
    simpa [Function.comp_def, decoratedHeightRestrictedRightEndpointReindexTerm] using hPair
  have hInr : Summable
      (decoratedHeightRestrictedRightEndpointReindexTerm q a h ∘ Sum.inr) := by
    simp [Function.comp_def, decoratedHeightRestrictedRightEndpointReindexTerm]
  rw [Summable.tsum_sum hInl hInr]
  simp only [decoratedHeightRestrictedRightEndpointReindexTerm, tsum_zero, add_zero]
  rw [hPair.tsum_prod]
  rw [tsum_eq_sum (s := (decoratedHeightPrimeSet q h).powerset.erase ∅)]
  · apply Finset.sum_congr rfl
    intro d hd
    have hdps := (Finset.mem_erase.mp hd).2
    have hdne : d.Nonempty :=
      Finset.nonempty_iff_ne_empty.mpr (Finset.mem_erase.mp hd).1
    have hHpos := decoratedReducedHeight_pos_of_mem hh hdps
    have hHpar := decoratedReducedHeight_parity_of_mem h2 hdps
    have hs := summable_dForbiddenBooleanRightEndpointTerm
      (q := q)
      (a := decoratedReducedAnchor q a (primeSetProduct d))
      (H := h / primeSetProduct d)
      hq hHpos hHpar d
    have hgate : d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty :=
      ⟨hdps, hdne⟩
    simpa [decoratedHeightRestrictedRightEndpointPairTerm, hgate] using
      hs.tsum_mul_left (finiteVWeightReal h d)
  · intro d hd
    have hout : ¬(d ⊆ decoratedHeightPrimeSet q h ∧ d.Nonempty) := by
      intro hg
      apply hd
      apply Finset.mem_erase.mpr
      exact ⟨Finset.nonempty_iff_ne_empty.mp hg.2,
        Finset.mem_powerset.mpr hg.1⟩
    simp [decoratedHeightRestrictedRightEndpointPairTerm, hout]



theorem leftEndpointReindex_support_subset_range
    {q a h : ℕ} :
    Function.support (decoratedHeightRestrictedLeftEndpointReindexTerm q a h) ⊆
      Set.range (decoratedAnalyticSignedReindexKey q h) := by
  classical
  intro x hx
  cases x with
  | inr e =>
      exfalso
      exact hx (by simp [decoratedHeightRestrictedLeftEndpointReindexTerm])
  | inl dn =>
      rcases dn with ⟨d, n⟩
      by_cases hgate :
          d ⊆ decoratedHeightPrimeSet q h ∧ d.Nonempty
      · have hgateMem :
          d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty :=
          ⟨Finset.mem_powerset.mpr hgate.1, hgate.2⟩
        have hterm :
            dForbiddenBooleanLeftEndpointTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) d n ≠ 0 := by
          intro hz
          apply hx
          simp [decoratedHeightRestrictedLeftEndpointReindexTerm,
            decoratedHeightRestrictedLeftEndpointPairTerm, hgateMem, hz]
        have hdis : Disjoint d n := by
          by_contra hndis
          apply hterm
          simp [dForbiddenBooleanLeftEndpointTerm, hndis]
        have hnne : n.Nonempty := by
          by_contra hnempty
          have hn0 : n = ∅ := Finset.not_nonempty_iff_eq_empty.mp hnempty
          subst n
          apply hterm
          simp [dForbiddenBooleanLeftEndpointTerm]
        have hn : n ∈ activeOrdinaryTwoDimensionalSet q
            (h / primeSetProduct d) := by
          by_contra hnact
          apply hterm
          simp [dForbiddenBooleanLeftEndpointTerm, hdis, hnne,
            pureLeftPairTerm, ordinaryEndpointDensityCorrection,
            Set.indicator, hnact]
        refine ⟨d ∪ n, ?_⟩
        exact decoratedAnalyticSignedReindexKey_union hgate.1 hn hdis
      · exfalso
        apply hx
        simp [decoratedHeightRestrictedLeftEndpointReindexTerm,
          decoratedHeightRestrictedLeftEndpointPairTerm, hgate]

theorem rightEndpointReindex_support_subset_range
    {q a h : ℕ} :
    Function.support (decoratedHeightRestrictedRightEndpointReindexTerm q a h) ⊆
      Set.range (decoratedAnalyticSignedReindexKey q h) := by
  classical
  intro x hx
  cases x with
  | inr e =>
      exfalso
      exact hx (by simp [decoratedHeightRestrictedRightEndpointReindexTerm])
  | inl dn =>
      rcases dn with ⟨d, n⟩
      by_cases hgate :
          d ⊆ decoratedHeightPrimeSet q h ∧ d.Nonempty
      · have hgateMem :
          d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty :=
          ⟨Finset.mem_powerset.mpr hgate.1, hgate.2⟩
        have hterm :
            dForbiddenBooleanRightEndpointTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) d n ≠ 0 := by
          intro hz
          apply hx
          simp [decoratedHeightRestrictedRightEndpointReindexTerm,
            decoratedHeightRestrictedRightEndpointPairTerm, hgateMem, hz]
        have hdis : Disjoint d n := by
          by_contra hndis
          apply hterm
          simp [dForbiddenBooleanRightEndpointTerm, hndis]
        have hnne : n.Nonempty := by
          by_contra hnempty
          have hn0 : n = ∅ := Finset.not_nonempty_iff_eq_empty.mp hnempty
          subst n
          apply hterm
          simp [dForbiddenBooleanRightEndpointTerm]
        have hn : n ∈ activeOrdinaryTwoDimensionalSet q
            (h / primeSetProduct d) := by
          by_contra hnact
          apply hterm
          simp [dForbiddenBooleanRightEndpointTerm, hdis, hnne,
            Set.indicator, hnact]
        refine ⟨d ∪ n, ?_⟩
        exact decoratedAnalyticSignedReindexKey_union hgate.1 hn hdis
      · exfalso
        apply hx
        simp [decoratedHeightRestrictedRightEndpointReindexTerm,
          decoratedHeightRestrictedRightEndpointPairTerm, hgate]

theorem mixedLeft_tsum_eq_reindex_tsum
    {q a h : ℕ} (hh : 0 < h) :
    (∑' e : Finset ℕ,
      (decoratedMixedEndpointSupport q h).indicator
        (fun e => decoratedAnalyticPairTerm q a h e e) e) =
      ∑' x : (Finset ℕ × Finset ℕ) ⊕ Finset ℕ,
        decoratedHeightRestrictedLeftEndpointReindexTerm q a h x := by
  classical
  let f : Finset ℕ → ℝ :=
    (decoratedMixedEndpointSupport q h).indicator
      (fun e => decoratedAnalyticPairTerm q a h e e)
  let g : (Finset ℕ × Finset ℕ) ⊕ Finset ℕ → ℝ :=
    decoratedHeightRestrictedLeftEndpointReindexTerm q a h
  let key := decoratedAnalyticSignedReindexKey q h
  have hgrange : Function.support g ⊆ Set.range key := by
    simpa [g, key] using
      (leftEndpointReindex_support_subset_range (q := q) (a := a) (h := h))
  let i : Function.support g → Finset ℕ :=
    fun x => Classical.choose (hgrange x.property)
  have hikey : ∀ x : Function.support g, key (i x) = x.1 := by
    intro x
    exact Classical.choose_spec (hgrange x.property)
  have hi : Function.Injective i := by
    intro x y hxy
    apply Subtype.ext
    have hk := congrArg key hxy
    rw [hikey x, hikey y] at hk
    exact hk
  have hpoint : ∀ e : Finset ℕ, f e = g (key e) := by
    intro e
    simpa [f, g, key] using mixedLeft_indicator_eq_reindexTerm
      (q := q) (a := a) hh e
  have hfsupp : Function.support f ⊆ Set.range i := by
    intro e he
    have hgne : g (key e) ≠ 0 := by
      intro hz
      exact he (by rw [hpoint e, hz])
    let x : Function.support g := ⟨key e, hgne⟩
    refine ⟨x, ?_⟩
    have hk : key (i x) = key e := by
      simpa [x] using hikey x
    exact decoratedAnalyticSignedReindexKey_injective q h hk
  have hfg : ∀ x : Function.support g, f (i x) = g x.1 := by
    intro x
    rw [hpoint]
    rw [hikey x]
  exact tsum_eq_tsum_of_ne_zero_bij i hi hfsupp hfg

theorem mixedRight_tsum_eq_reindex_tsum
    {q a h : ℕ} (hh : 0 < h) :
    (∑' e : Finset ℕ,
      (decoratedMixedEndpointSupport q h).indicator
        (fun e => decoratedAnalyticPairTerm q a h e (heightPrimePart h e)) e) =
      ∑' x : (Finset ℕ × Finset ℕ) ⊕ Finset ℕ,
        decoratedHeightRestrictedRightEndpointReindexTerm q a h x := by
  classical
  let f : Finset ℕ → ℝ :=
    (decoratedMixedEndpointSupport q h).indicator
      (fun e => decoratedAnalyticPairTerm q a h e (heightPrimePart h e))
  let g : (Finset ℕ × Finset ℕ) ⊕ Finset ℕ → ℝ :=
    decoratedHeightRestrictedRightEndpointReindexTerm q a h
  let key := decoratedAnalyticSignedReindexKey q h
  have hgrange : Function.support g ⊆ Set.range key := by
    simpa [g, key] using
      (rightEndpointReindex_support_subset_range (q := q) (a := a) (h := h))
  let i : Function.support g → Finset ℕ :=
    fun x => Classical.choose (hgrange x.property)
  have hikey : ∀ x : Function.support g, key (i x) = x.1 := by
    intro x
    exact Classical.choose_spec (hgrange x.property)
  have hi : Function.Injective i := by
    intro x y hxy
    apply Subtype.ext
    have hk := congrArg key hxy
    rw [hikey x, hikey y] at hk
    exact hk
  have hpoint : ∀ e : Finset ℕ, f e = g (key e) := by
    intro e
    simpa [f, g, key] using mixedRight_indicator_eq_reindexTerm
      (q := q) (a := a) hh e
  have hfsupp : Function.support f ⊆ Set.range i := by
    intro e he
    have hgne : g (key e) ≠ 0 := by
      intro hz
      exact he (by rw [hpoint e, hz])
    let x : Function.support g := ⟨key e, hgne⟩
    refine ⟨x, ?_⟩
    have hk : key (i x) = key e := by
      simpa [x] using hikey x
    exact decoratedAnalyticSignedReindexKey_injective q h hk
  have hfg : ∀ x : Function.support g, f (i x) = g x.1 := by
    intro x
    rw [hpoint]
    rw [hikey x]
  exact tsum_eq_tsum_of_ne_zero_bij i hi hfsupp hfg

theorem signedForbiddenDecoratedLeftEndpointSum_eq_mixedSource
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    (∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
      finiteVWeightReal h d *
        (∑' n : Finset ℕ,
          dForbiddenBooleanLeftEndpointTerm q
            (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d) d n)) =
      ∑' e : Finset ℕ,
        (decoratedMixedEndpointSupport q h).indicator
          (fun e => decoratedAnalyticPairTerm q a h e e) e := by
  rw [mixedLeft_tsum_eq_reindex_tsum hh]
  exact (tsum_leftEndpointReindex_eq_outer hq hh h2).symm

theorem signedForbiddenDecoratedRightEndpointSum_eq_mixedSource
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    (∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
      finiteVWeightReal h d *
        (∑' n : Finset ℕ,
          dForbiddenBooleanRightEndpointTerm q
            (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d) d n)) =
      ∑' e : Finset ℕ,
        (decoratedMixedEndpointSupport q h).indicator
          (fun e => decoratedAnalyticPairTerm q a h e
            (heightPrimePart h e)) e := by
  rw [mixedRight_tsum_eq_reindex_tsum hh]
  exact (tsum_rightEndpointReindex_eq_outer hq hh h2).symm


def decoratedOrdinaryEndpointSupport (q h : ℕ) : Set (Finset ℕ) :=
  {e | e ∈ activeOrdinaryTwoDimensionalSet q h ∧ e.Nonempty}

theorem ordinaryLeftEndpoint_eq_ordinarySource
    {q a h : ℕ} (e : Finset ℕ) :
    dForbiddenBooleanLeftEndpointTerm q
      (decoratedReducedAnchor q a 1) h ∅ e =
      (decoratedOrdinaryEndpointSupport q h).indicator
        (fun e => decoratedAnalyticPairTerm q a h e e) e := by
  classical
  by_cases he : e ∈ decoratedOrdinaryEndpointSupport q h
  · rw [Set.indicator_of_mem he]
    rcases he with ⟨hact, hne⟩
    have hact' : e ∈ activeOrdinaryTwoDimensionalSet q
        (h / primeSetProduct (∅ : Finset ℕ)) := by
      simpa [primeSetProduct] using hact
    have hrec := decoratedLeftEndpoint_union_reconstruct
      (q := q) (a := a) (h := h) (d := ∅) (n := e)
      (by simp) hact' (by simp) hne
    simpa [primeSetProduct, finiteVWeightReal] using hrec.symm
  · simp only [Set.indicator, he, if_false]
    have he' : ¬ (e ∈ activeOrdinaryTwoDimensionalSet q h ∧ e.Nonempty) := by
      simpa [decoratedOrdinaryEndpointSupport] using he
    simp [dForbiddenBooleanLeftEndpointTerm]
    aesop

theorem ordinaryRightEndpoint_eq_ordinarySource
    {q a h : ℕ} (e : Finset ℕ) :
    dForbiddenBooleanRightEndpointTerm q
      (decoratedReducedAnchor q a 1) h ∅ e =
      (decoratedOrdinaryEndpointSupport q h).indicator
        (fun e => decoratedAnalyticPairTerm q a h e (heightPrimePart h e)) e := by
  classical
  by_cases he : e ∈ decoratedOrdinaryEndpointSupport q h
  · rw [Set.indicator_of_mem he]
    rcases he with ⟨hact, hne⟩
    have hheight : heightPrimePart h e = ∅ := by
      exact hact.1
    have hact' : e ∈ activeOrdinaryTwoDimensionalSet q
        (h / primeSetProduct (∅ : Finset ℕ)) := by
      simpa [primeSetProduct] using hact
    have hrec := decoratedRightEndpoint_union_reconstruct
      (q := q) (a := a) (h := h) (d := ∅) (n := e)
      (by simp) hact' (by simp) hne
    simpa [hheight, primeSetProduct, finiteVWeightReal] using hrec.symm
  · simp only [Set.indicator, he, if_false]
    have he' : ¬ (e ∈ activeOrdinaryTwoDimensionalSet q h ∧ e.Nonempty) := by
      simpa [decoratedOrdinaryEndpointSupport] using he
    simp [dForbiddenBooleanRightEndpointTerm]
    aesop

theorem tsum_ordinaryLeftEndpoint_eq_ordinarySource
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    (∑' e : Finset ℕ,
      dForbiddenBooleanLeftEndpointTerm q
        (decoratedReducedAnchor q a 1) h ∅ e) =
      ∑' e : Finset ℕ,
        (decoratedOrdinaryEndpointSupport q h).indicator
          (fun e => decoratedAnalyticPairTerm q a h e e) e := by
  apply tsum_congr
  intro e
  exact ordinaryLeftEndpoint_eq_ordinarySource e

theorem tsum_ordinaryRightEndpoint_eq_ordinarySource
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    (∑' e : Finset ℕ,
      dForbiddenBooleanRightEndpointTerm q
        (decoratedReducedAnchor q a 1) h ∅ e) =
      ∑' e : Finset ℕ,
        (decoratedOrdinaryEndpointSupport q h).indicator
          (fun e => decoratedAnalyticPairTerm q a h e (heightPrimePart h e)) e := by
  apply tsum_congr
  intro e
  exact ordinaryRightEndpoint_eq_ordinarySource e

theorem completedSupport_indicator_eq_ordinary_add_mixed
    {q h : ℕ} (e : Finset ℕ) :
    (completedBooleanSupport q h).indicator (fun _ => (1 : ℝ)) e =
      (decoratedOrdinaryEndpointSupport q h).indicator (fun _ => (1 : ℝ)) e +
      (decoratedMixedEndpointSupport q h).indicator (fun _ => (1 : ℝ)) e := by
  classical
  by_cases hA : ∀ p ∈ e, activeHighPrime q p
  · by_cases hall : heightPrimePart h e = e
    · have hc : e ∉ completedBooleanSupport q h := by
        intro he
        exact he.2 hall
      have hm : e ∉ decoratedMixedEndpointSupport q h := by
        intro he
        exact he.2.2 hall
      have ho : e ∉ decoratedOrdinaryEndpointSupport q h := by
        intro he
        have hheight : heightPrimePart h e = ∅ := he.1.1
        have he0 : e = ∅ := by
          rw [← hall, hheight]
        have hne := he.2
        rw [he0] at hne
        exact Finset.not_nonempty_empty hne
      simp [Set.indicator, hc, hm, ho]
    · have hc : e ∈ completedBooleanSupport q h := ⟨hA, hall⟩
      by_cases hd0 : heightPrimePart h e = ∅
      · have hord : e ∈ activeOrdinaryTwoDimensionalSet q h := by
          exact ⟨hd0, hA⟩
        have hne : e.Nonempty := by
          by_contra hne
          have he0 : e = ∅ := Finset.not_nonempty_iff_eq_empty.mp hne
          subst e
          exact hall (by simp [heightPrimePart])
        have ho : e ∈ decoratedOrdinaryEndpointSupport q h := ⟨hord, hne⟩
        have hm : e ∉ decoratedMixedEndpointSupport q h := by
          intro he
          have hne := he.2.1
          rw [hd0] at hne
          exact Finset.not_nonempty_empty hne
        simp [Set.indicator, hc, ho, hm]
      · have hdne : (heightPrimePart h e).Nonempty :=
          Finset.nonempty_iff_ne_empty.mpr hd0
        have hm : e ∈ decoratedMixedEndpointSupport q h :=
          ⟨hA, hdne, hall⟩
        have ho : e ∉ decoratedOrdinaryEndpointSupport q h := by
          intro he
          exact hd0 he.1.1
        simp [Set.indicator, hc, hm, ho]
  · have hc : e ∉ completedBooleanSupport q h := by
      intro he
      exact hA he.1
    have hm : e ∉ decoratedMixedEndpointSupport q h := by
      intro he
      exact hA he.1
    have ho : e ∉ decoratedOrdinaryEndpointSupport q h := by
      intro he
      exact hA he.1.2
    simp [Set.indicator, hc, hm, ho]

theorem completedFullAnalytic_tsum_eq_ordinary_add_mixed
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    (∑' e : Finset ℕ,
      (completedBooleanSupport q h).indicator
        (fun e => decoratedAnalyticPairTerm q a h e e) e) =
      (∑' e : Finset ℕ,
        dForbiddenBooleanLeftEndpointTerm q
          (decoratedReducedAnchor q a 1) h ∅ e) +
      (∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
        finiteVWeightReal h d *
          (∑' n : Finset ℕ,
            dForbiddenBooleanLeftEndpointTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) d n)) := by
  rw [tsum_ordinaryLeftEndpoint_eq_ordinarySource hq hh h2]
  rw [signedForbiddenDecoratedLeftEndpointSum_eq_mixedSource hq hh h2]
  let fo : Finset ℕ → ℝ :=
    (decoratedOrdinaryEndpointSupport q h).indicator
      (fun e => decoratedAnalyticPairTerm q a h e e)
  let fm : Finset ℕ → ℝ :=
    (decoratedMixedEndpointSupport q h).indicator
      (fun e => decoratedAnalyticPairTerm q a h e e)
  have hso : Summable fo := by
    have hs := summable_dForbiddenBooleanLeftEndpointTerm
      (q := q) (a := decoratedReducedAnchor q a 1) (H := h)
      hq hh h2 ∅
    exact hs.congr (fun e => by
      simpa [fo] using ordinaryLeftEndpoint_eq_ordinarySource
        (q := q) (a := a) (h := h) e)
  have hsm : Summable fm := by
    have hpair := summable_decoratedHeightRestrictedLeftEndpointPairTerm
      (q := q) (a := a) (h := h) hq hh h2
    have hre : Summable
        (decoratedHeightRestrictedLeftEndpointReindexTerm q a h) := by
      apply (Sum.inl_injective.summable_iff ?_).mp
      · simpa [Function.comp_def, decoratedHeightRestrictedLeftEndpointReindexTerm]
          using hpair
      · intro x hx
        cases x with
        | inl dn => exact (hx ⟨dn, rfl⟩).elim
        | inr e => simp [decoratedHeightRestrictedLeftEndpointReindexTerm]
    exact (hre.comp_injective
      (decoratedAnalyticSignedReindexKey_injective q h)).congr
        (fun e => by
          simpa [fm] using
            (mixedLeft_indicator_eq_reindexTerm
              (q := q) (a := a) hh e).symm)
  rw [← hso.tsum_add hsm]
  apply tsum_congr
  intro e
  classical
  by_cases hc : e ∈ completedBooleanSupport q h
  · rw [Set.indicator_of_mem hc]
    have hsplit := completedSupport_indicator_eq_ordinary_add_mixed
      (q := q) (h := h) e
    have hval : (1 : ℝ) =
        (decoratedOrdinaryEndpointSupport q h).indicator (fun _ => (1 : ℝ)) e +
        (decoratedMixedEndpointSupport q h).indicator (fun _ => (1 : ℝ)) e := by
      simpa [Set.indicator_of_mem hc] using hsplit
    by_cases ho : e ∈ decoratedOrdinaryEndpointSupport q h
    · have hm : e ∉ decoratedMixedEndpointSupport q h := by
        intro hm
        have hne := hm.2.1
        rw [ho.1.1] at hne
        exact Finset.not_nonempty_empty hne
      simp [fo, fm, Set.indicator, ho, hm]
    · have hm : e ∈ decoratedMixedEndpointSupport q h := by
        by_contra hm
        simp [Set.indicator, ho, hm] at hval
      simp [fo, fm, Set.indicator, ho, hm]
  · simp only [Set.indicator, hc, if_false]
    have hsplit := completedSupport_indicator_eq_ordinary_add_mixed
      (q := q) (h := h) e
    have ho : e ∉ decoratedOrdinaryEndpointSupport q h := by
      intro ho
      apply hc
      have hA := ho.1.2
      have hhpart := ho.1.1
      exact ⟨hA, by
        intro heq
        have he0 : e = ∅ := by
          rw [← heq, hhpart]
        have hne := ho.2
        rw [he0] at hne
        exact Finset.not_nonempty_empty hne⟩
    have hm : e ∉ decoratedMixedEndpointSupport q h := by
      intro hm
      exact hc ⟨hm.1, hm.2.2⟩
    simp [fo, fm, Set.indicator, ho, hm]



theorem completedEmptyAnalytic_tsum_eq_ordinary_add_mixed
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    (∑' e : Finset ℕ,
      (completedBooleanSupport q h).indicator
        (fun e => decoratedAnalyticPairTerm q a h e (heightPrimePart h e)) e) =
      (∑' e : Finset ℕ,
        dForbiddenBooleanRightEndpointTerm q
          (decoratedReducedAnchor q a 1) h ∅ e) +
      (∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
        finiteVWeightReal h d *
          (∑' n : Finset ℕ,
            dForbiddenBooleanRightEndpointTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) d n)) := by
  rw [tsum_ordinaryRightEndpoint_eq_ordinarySource hq hh h2]
  rw [signedForbiddenDecoratedRightEndpointSum_eq_mixedSource hq hh h2]
  let fo : Finset ℕ → ℝ :=
    (decoratedOrdinaryEndpointSupport q h).indicator
      (fun e => decoratedAnalyticPairTerm q a h e (heightPrimePart h e))
  let fm : Finset ℕ → ℝ :=
    (decoratedMixedEndpointSupport q h).indicator
      (fun e => decoratedAnalyticPairTerm q a h e (heightPrimePart h e))
  have hso : Summable fo := by
    have hs := summable_dForbiddenBooleanRightEndpointTerm
      (q := q) (a := decoratedReducedAnchor q a 1) (H := h)
      hq hh h2 ∅
    exact hs.congr (fun e => by
      simpa [fo] using ordinaryRightEndpoint_eq_ordinarySource
        (q := q) (a := a) (h := h) e)
  have hsm : Summable fm := by
    have hpair := summable_decoratedHeightRestrictedRightEndpointPairTerm
      (q := q) (a := a) (h := h) hq hh h2
    have hre : Summable
        (decoratedHeightRestrictedRightEndpointReindexTerm q a h) := by
      apply (Sum.inl_injective.summable_iff ?_).mp
      · simpa [Function.comp_def, decoratedHeightRestrictedRightEndpointReindexTerm]
          using hpair
      · intro x hx
        cases x with
        | inl dn => exact (hx ⟨dn, rfl⟩).elim
        | inr e => simp [decoratedHeightRestrictedRightEndpointReindexTerm]
    exact (hre.comp_injective
      (decoratedAnalyticSignedReindexKey_injective q h)).congr
        (fun e => by
          simpa [fm] using
            (mixedRight_indicator_eq_reindexTerm
              (q := q) (a := a) hh e).symm)
  rw [← hso.tsum_add hsm]
  apply tsum_congr
  intro e
  classical
  by_cases hc : e ∈ completedBooleanSupport q h
  · rw [Set.indicator_of_mem hc]
    have hsplit := completedSupport_indicator_eq_ordinary_add_mixed
      (q := q) (h := h) e
    have hval : (1 : ℝ) =
        (decoratedOrdinaryEndpointSupport q h).indicator (fun _ => (1 : ℝ)) e +
        (decoratedMixedEndpointSupport q h).indicator (fun _ => (1 : ℝ)) e := by
      simpa [Set.indicator_of_mem hc] using hsplit
    by_cases ho : e ∈ decoratedOrdinaryEndpointSupport q h
    · have hm : e ∉ decoratedMixedEndpointSupport q h := by
        intro hm
        have hne := hm.2.1
        rw [ho.1.1] at hne
        exact Finset.not_nonempty_empty hne
      simp [fo, fm, Set.indicator, ho, hm]
    · have hm : e ∈ decoratedMixedEndpointSupport q h := by
        by_contra hm
        simp [Set.indicator, ho, hm] at hval
      simp [fo, fm, Set.indicator, ho, hm]
  · simp only [Set.indicator, hc, if_false]
    have ho : e ∉ decoratedOrdinaryEndpointSupport q h := by
      intro ho
      apply hc
      have hA := ho.1.2
      have hhpart := ho.1.1
      exact ⟨hA, by
        intro heq
        have he0 : e = ∅ := by
          rw [← heq, hhpart]
        have hne := ho.2
        rw [he0] at hne
        exact Finset.not_nonempty_empty hne⟩
    have hm : e ∉ decoratedMixedEndpointSupport q h := by
      intro hm
      exact hc ⟨hm.1, hm.2.2⟩
    simp [fo, fm, Set.indicator, ho, hm]


theorem combinedFullEndpoint_eq_completedAnalytic_add_density
    {q a h : ℕ} (e : Finset ℕ) :
    combinedBooleanFullEndpointTerm q a h e =
      (completedBooleanSupport q h).indicator
        (fun e => decoratedAnalyticPairTerm q a h e e) e +
      (completedBooleanSupport q h).indicator
        (fun e => decoratedDensityPairTerm q a h e e) e := by
  classical
  by_cases hA : ∀ p ∈ e, activeHighPrime q p
  · by_cases hall : heightPrimePart h e = e
    · have hnot : e ∉ completedBooleanSupport q h := by
        intro he
        exact he.2 hall
      simp [combinedBooleanFullEndpointTerm, hall, Set.indicator, hnot]
    · have hmem : e ∈ completedBooleanSupport q h := ⟨hA, hall⟩
      simp [combinedBooleanFullEndpointTerm, hall, Set.indicator, hmem]
  · have hnot : e ∉ completedBooleanSupport q h := by
      intro he
      exact hA he.1
    by_cases hall : heightPrimePart h e = e
    · simp [combinedBooleanFullEndpointTerm, hall, Set.indicator, hnot]
    · have hz := pairCoefficient_eq_zero_of_not_all_active
        (q := q) (h := h) (e := e) (e1 := e) hA
      simp [combinedBooleanFullEndpointTerm, hall, Set.indicator, hnot,
        decoratedAnalyticPairTerm, decoratedDensityPairTerm, hz]

theorem combinedEmptyEndpoint_eq_completedAnalytic_add_density
    {q a h : ℕ} (e : Finset ℕ) :
    combinedBooleanEmptyEndpointTerm q a h e =
      (completedBooleanSupport q h).indicator
        (fun e => decoratedAnalyticPairTerm q a h e (heightPrimePart h e)) e +
      (completedBooleanSupport q h).indicator
        (fun e => decoratedDensityPairTerm q a h e (heightPrimePart h e)) e := by
  classical
  by_cases hA : ∀ p ∈ e, activeHighPrime q p
  · by_cases hall : heightPrimePart h e = e
    · have hnot : e ∉ completedBooleanSupport q h := by
        intro he
        exact he.2 hall
      simp [combinedBooleanEmptyEndpointTerm, hall, Set.indicator, hnot]
    · have hmem : e ∈ completedBooleanSupport q h := ⟨hA, hall⟩
      simp [combinedBooleanEmptyEndpointTerm, hall, Set.indicator, hmem]
  · have hnot : e ∉ completedBooleanSupport q h := by
      intro he
      exact hA he.1
    by_cases hall : heightPrimePart h e = e
    · simp [combinedBooleanEmptyEndpointTerm, hall, Set.indicator, hnot]
    · have hz := pairCoefficient_eq_zero_of_not_all_active
        (q := q) (h := h) (e := e)
        (e1 := heightPrimePart h e) hA
      simp [combinedBooleanEmptyEndpointTerm, hall, Set.indicator, hnot,
        decoratedAnalyticPairTerm, decoratedDensityPairTerm, hz]

theorem completedFullAnalytic_add_density_eq_sourceFamily
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    (∑' e : Finset ℕ,
      (completedBooleanSupport q h).indicator
        (fun e => decoratedAnalyticPairTerm q a h e e) e) +
    (∑' e : Finset ℕ,
      (completedBooleanSupport q h).indicator
        (fun e => decoratedDensityPairTerm q a h e e) e) =
      pureLeftFamily q a h -
        ∑' e : Finset ℕ, pureHeightSupportTerm q a h e := by
  let A : Finset ℕ → ℝ :=
    (completedBooleanSupport q h).indicator
      (fun e => decoratedAnalyticPairTerm q a h e e)
  let D : Finset ℕ → ℝ :=
    (completedBooleanSupport q h).indicator
      (fun e => decoratedDensityPairTerm q a h e e)
  let C : Finset ℕ → ℝ := combinedBooleanFullEndpointTerm q a h
  have hC : Summable C := by
    simpa [C] using summable_combinedBooleanFullEndpointTerm
      (q := q) (a := a) (h := h) hq
  have hD : Summable D := by
    simpa [D] using summable_completedBooleanFullDensityTerm
      (q := q) (a := a) (h := h) hq hh h2
  have hA : Summable A := by
    have hs := hC.sub hD
    exact hs.congr (fun e => by
      have hp := combinedFullEndpoint_eq_completedAnalytic_add_density
        (q := q) (a := a) (h := h) e
      dsimp [A, D, C]
      linarith)
  rw [← hA.tsum_add hD]
  calc
    (∑' x : Finset ℕ, (A x + D x))
      = ∑' x : Finset ℕ, C x := by
          apply tsum_congr
          intro e
          have hp := combinedFullEndpoint_eq_completedAnalytic_add_density
            (q := q) (a := a) (h := h) e
          simpa [A, D, C] using hp.symm
    _ = pureLeftFamily q a h -
        ∑' e : Finset ℕ, pureHeightSupportTerm q a h e := by
          simpa [C] using
            tsum_combinedBooleanFullEndpoint_eq_pureLeft_sub_pureHeight
              (q := q) (a := a) (h := h) hq

theorem completedEmptyAnalytic_add_density_eq_sourceFamily
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h)
    {r : ℕ}
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    (∑' e : Finset ℕ,
      (completedBooleanSupport q h).indicator
        (fun e => decoratedAnalyticPairTerm q a h e (heightPrimePart h e)) e) +
    (∑' e : Finset ℕ,
      (completedBooleanSupport q h).indicator
        (fun e => decoratedDensityPairTerm q a h e (heightPrimePart h e)) e) =
      heightBoundaryFamily q a h := by
  let A : Finset ℕ → ℝ :=
    (completedBooleanSupport q h).indicator
      (fun e => decoratedAnalyticPairTerm q a h e (heightPrimePart h e))
  let D : Finset ℕ → ℝ :=
    (completedBooleanSupport q h).indicator
      (fun e => decoratedDensityPairTerm q a h e (heightPrimePart h e))
  let C : Finset ℕ → ℝ := combinedBooleanEmptyEndpointTerm q a h
  have hC : Summable C := by
    simpa [C] using summable_combinedBooleanEmptyEndpointTerm
      (q := q) (a := a) (r := r) (h := h) hq hreflect
  have hD : Summable D := by
    simpa [D] using summable_completedBooleanEmptyDensityTerm
      (q := q) (a := a) (h := h) hq hh h2
  have hA : Summable A := by
    have hs := hC.sub hD
    exact hs.congr (fun e => by
      have hp := combinedEmptyEndpoint_eq_completedAnalytic_add_density
        (q := q) (a := a) (h := h) e
      dsimp [A, D, C]
      linarith)
  rw [← hA.tsum_add hD]
  calc
    (∑' x : Finset ℕ, (A x + D x))
      = ∑' x : Finset ℕ, C x := by
          apply tsum_congr
          intro e
          have hp := combinedEmptyEndpoint_eq_completedAnalytic_add_density
            (q := q) (a := a) (h := h) e
          simpa [A, D, C] using hp.symm
    _ = heightBoundaryFamily q a h := by
          simpa [C] using
            tsum_combinedBooleanEmptyEndpoint_eq_heightBoundary
              (q := q) (a := a) (h := h) hq

theorem signedForbiddenLeftEndpoint_outer_source_identity
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    (∑' e : Finset ℕ,
      dForbiddenBooleanLeftEndpointTerm q
        (decoratedReducedAnchor q a 1) h ∅ e) +
    (∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
      finiteVWeightReal h d *
        (∑' n : Finset ℕ,
          dForbiddenBooleanLeftEndpointTerm q
            (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d) d n)) +
    (∑' e : Finset ℕ,
      (completedBooleanSupport q h).indicator
        (fun e => decoratedDensityPairTerm q a h e e) e) =
      pureLeftFamily q a h -
        ∑' e : Finset ℕ, pureHeightSupportTerm q a h e := by
  rw [← completedFullAnalytic_tsum_eq_ordinary_add_mixed hq hh h2]
  exact completedFullAnalytic_add_density_eq_sourceFamily hq hh h2

theorem signedForbiddenRightEndpoint_outer_source_identity
    {q a h r : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h)
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    (∑' e : Finset ℕ,
      dForbiddenBooleanRightEndpointTerm q
        (decoratedReducedAnchor q a 1) h ∅ e) +
    (∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
      finiteVWeightReal h d *
        (∑' n : Finset ℕ,
          dForbiddenBooleanRightEndpointTerm q
            (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d) d n)) +
    (∑' e : Finset ℕ,
      (completedBooleanSupport q h).indicator
        (fun e => decoratedDensityPairTerm q a h e (heightPrimePart h e)) e) =
      heightBoundaryFamily q a h := by
  rw [← completedEmptyAnalytic_tsum_eq_ordinary_add_mixed hq hh h2]
  exact completedEmptyAnalytic_add_density_eq_sourceFamily
    hq hh h2 hreflect


noncomputable def signedForbiddenDecoratedLeftEndpointPackage
    (q a h : ℕ) : ℝ :=
  (∑' e : Finset ℕ,
    dForbiddenBooleanLeftEndpointTerm q
      (decoratedReducedAnchor q a 1) h ∅ e) +
  (∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
    finiteVWeightReal h d *
      (∑' n : Finset ℕ,
        dForbiddenBooleanLeftEndpointTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) d n)) +
  (∑' e : Finset ℕ,
    (completedBooleanSupport q h).indicator
      (fun e => decoratedDensityPairTerm q a h e e) e) +
  (∑' e : Finset ℕ, pureHeightSupportTerm q a h e)

noncomputable def signedForbiddenDecoratedRightEndpointPackage
    (q a h : ℕ) : ℝ :=
  (∑' e : Finset ℕ,
    dForbiddenBooleanRightEndpointTerm q
      (decoratedReducedAnchor q a 1) h ∅ e) +
  (∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
    finiteVWeightReal h d *
      (∑' n : Finset ℕ,
        dForbiddenBooleanRightEndpointTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) d n)) +
  (∑' e : Finset ℕ,
    (completedBooleanSupport q h).indicator
      (fun e => decoratedDensityPairTerm q a h e
        (heightPrimePart h e)) e) +
  (∑' e : Finset ℕ, pureHeightSupportTerm q a h e)

theorem signedForbiddenDecoratedLeftEndpointPackage_eq_pureLeft
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    signedForbiddenDecoratedLeftEndpointPackage q a h =
      pureLeftFamily q a h := by
  unfold signedForbiddenDecoratedLeftEndpointPackage
  have hsrc :=
    signedForbiddenLeftEndpoint_outer_source_identity
      (q := q) (a := a) (h := h) hq hh h2
  linarith

theorem signedForbiddenDecoratedRightEndpointPackage_eq_reflectedPureLeft
    {q a b h : ℕ} (hq : 0 < q)
    (hcompat : Nat.ModEq q (a + h) b)
    (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    signedForbiddenDecoratedRightEndpointPackage q a h =
      pureLeftFamily q (PaperB.Closure.reflectedResidue q b) h := by
  have hreflect :
      ∀ z ∈ Finset.Ioo 0 h,
        q.Coprime (a + (h - z)) ↔
          q.Coprime (PaperB.Closure.reflectedResidue q b + z) :=
    PaperB.Closure.reflected_coprime_equiv hq hcompat
  unfold signedForbiddenDecoratedRightEndpointPackage
  have hsrc :=
    signedForbiddenRightEndpoint_outer_source_identity
      (q := q) (a := a) (h := h)
      (r := PaperB.Closure.reflectedResidue q b)
      hq hh h2 hreflect
  have href :=
    heightBoundaryFamily_add_pureHeight_eq_reflectedPureLeft hreflect
  linarith

def SignedForbiddenDecoratedEndpointSublogSpec (q : ℕ) : Prop :=
  0 < q →
  Squarefree q →
  ∀ eps : ℝ, 0 < eps →
    ∃ h0 : ℕ,
      ∀ a b h : ℕ,
        q.Coprime a →
        q.Coprime b →
        Nat.ModEq q (a + h) b →
        (¬ 2 ∣ q → 2 ∣ h) →
        0 < h →
        h0 ≤ h →
        |cStarReal q h *
              signedForbiddenDecoratedLeftEndpointPackage q a h -
            PaperB.Closure.manuscriptS1Kernel q a h| ≤
          eps * Real.log (h : ℝ) ∧
        |cStarReal q h *
              signedForbiddenDecoratedRightEndpointPackage q a h -
            PaperB.Closure.manuscriptS1Kernel q
              (PaperB.Closure.reflectedResidue q b) h| ≤
          eps * Real.log (h : ℝ)

theorem signedForbiddenDecoratedEndpoint_sublog
    (q : ℕ) :
    SignedForbiddenDecoratedEndpointSublogSpec q := by
  intro hq hsq eps heps
  obtain ⟨h0, hH1⟩ :=
    PaperB.Admission.sourceNativeH1Control_fixedQ
      q hq hsq eps heps
  refine ⟨h0, ?_⟩
  intro a b h ha hb hcompat h2 hh hlarge
  obtain ⟨hleft, hright⟩ :=
    hH1 a b h ha hb hcompat h2 hh hlarge
  have hL :=
    signedForbiddenDecoratedLeftEndpointPackage_eq_pureLeft
      (q := q) (a := a) (h := h) hq hh h2
  have hR :=
    signedForbiddenDecoratedRightEndpointPackage_eq_reflectedPureLeft
      (q := q) (a := a) (b := b) (h := h)
      hq hcompat hh h2
  constructor
  · simpa [hL] using hleft
  · simpa [hR] using hright

#print axioms signedForbiddenDecoratedLeftEndpointPackage_eq_pureLeft
#print axioms signedForbiddenDecoratedRightEndpointPackage_eq_reflectedPureLeft
#print axioms signedForbiddenDecoratedEndpoint_sublog

#print axioms signedForbiddenLeftEndpoint_outer_source_identity
#print axioms signedForbiddenRightEndpoint_outer_source_identity

#print axioms completedFullAnalytic_tsum_eq_ordinary_add_mixed
#print axioms completedEmptyAnalytic_tsum_eq_ordinary_add_mixed

#print axioms signedForbiddenDecoratedLeftEndpointSum_eq_mixedSource
#print axioms signedForbiddenDecoratedRightEndpointSum_eq_mixedSource


#print axioms mixedLeft_indicator_eq_reindexTerm
#print axioms mixedRight_indicator_eq_reindexTerm

end PaperB.FixedQ
