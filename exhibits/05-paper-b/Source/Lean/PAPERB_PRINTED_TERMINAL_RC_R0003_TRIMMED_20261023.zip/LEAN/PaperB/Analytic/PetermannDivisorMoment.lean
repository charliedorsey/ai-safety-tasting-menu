import Mathlib.NumberTheory.ArithmeticFunction.Misc
import Mathlib.NumberTheory.Harmonic.Bounds

open scoped ArithmeticFunction.zeta ArithmeticFunction.sigma

namespace PaperB.Analytic

open Finset Nat ArithmeticFunction

def tauSq : ArithmeticFunction ℕ where
  toFun n := (σ 0 n) ^ 2
  map_zero' := by simp

lemma tauSq_apply (n : ℕ) : tauSq n = (σ 0 n) ^ 2 := rfl

lemma tauSq_isMultiplicative : tauSq.IsMultiplicative := by
  refine ⟨by simp [tauSq], ?_⟩
  intro m n hcop
  rw [tauSq_apply, tauSq_apply, tauSq_apply]
  rw [isMultiplicative_sigma.map_mul_of_coprime hcop]
  ring

lemma tau_conv_tau_prime_pow_formula
    {p i : ℕ} (hp : p.Prime) :
    (σ 0 * σ 0) (p ^ i)
      = ∑ j ∈ Finset.range (i + 1), (j + 1) * (i - j + 1) := by
  rw [mul_apply]
  have hanti := Nat.sum_divisorsAntidiagonal
    (fun a b : ℕ => (σ 0) a * (σ 0) b) (n := p ^ i)
  rw [hanti]
  rw [divisors_prime_pow hp]
  simp only [Finset.sum_map]
  apply Finset.sum_congr rfl
  intro j hj
  change (σ 0) (p ^ j) * (σ 0) (p ^ i / p ^ j) =
    (j + 1) * (i - j + 1)
  have hjle : j ≤ i := by
    simpa [Finset.mem_range] using hj
  have hpow : p ^ i = p ^ j * p ^ (i - j) := by
    rw [← pow_add]
    congr
    omega
  rw [sigma_zero_apply_prime_pow hp]
  rw [hpow]
  simp [hp.ne_zero]
  rw [sigma_zero_apply_prime_pow hp]

lemma tau_conv_tau_prime_pow_ge
    {p i : ℕ} (hp : p.Prime) :
    (σ 0 * σ 0) (p ^ i) ≥ (σ 0 (p ^ i)) ^ 2 := by
  rw [tau_conv_tau_prime_pow_formula hp, sigma_zero_apply_prime_pow hp]
  have hterm :
      ∀ j ∈ Finset.range (i + 1),
        (i + 1) ≤ (j + 1) * (i - j + 1) := by
    intro j hj
    have hjle : j ≤ i := by
      simpa [Finset.mem_range] using hj
    obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le hjle
    simp
    nlinarith
  calc
    (i + 1) ^ 2
      = ∑ _j ∈ Finset.range (i + 1), (i + 1) := by
          simp [pow_two]
    _ ≤ ∑ j ∈ Finset.range (i + 1), (j + 1) * (i - j + 1) := by
          exact Finset.sum_le_sum hterm

lemma tauSq_le_tau_conv_tau (n : ℕ) :
    tauSq n ≤ (σ 0 * σ 0) n := by
  by_cases hn : n = 0
  · subst n
    simp [tauSq]
  have hfac1 :=
    ArithmeticFunction.IsMultiplicative.multiplicative_factorization
      tauSq tauSq_isMultiplicative hn
  have hmult2 : (σ 0 * σ 0).IsMultiplicative :=
    isMultiplicative_sigma.mul isMultiplicative_sigma
  have hfac2 :=
    ArithmeticFunction.IsMultiplicative.multiplicative_factorization
      (σ 0 * σ 0) hmult2 hn
  rw [hfac1, hfac2]
  apply Finset.prod_le_prod
  intro p hp
  exact tau_conv_tau_prime_pow_ge (prime_of_mem_primeFactors hp)


lemma sum_sigma_zero_eq_div_sum (N : ℕ) :
    (∑ n ∈ Finset.Ioc 0 N, σ 0 n) =
      ∑ d ∈ Finset.Ioc 0 N, N / d := by
  rw [← zeta_mul_pow_eq_sigma (k := 0), pow_zero_eq_zeta]
  rw [sum_Ioc_mul_eq_sum_sum]
  apply Finset.sum_congr rfl
  intro n hn
  have hn0 : n ≠ 0 := by
    simp only [Finset.mem_Ioc] at hn
    omega
  simp only [zeta_apply, if_neg hn0, one_mul]
  have hinner :
      (∑ m ∈ Finset.Ioc 0 (N / n), if m = 0 then 0 else 1)
        = N / n := by
    calc
      (∑ m ∈ Finset.Ioc 0 (N / n), if m = 0 then 0 else 1)
          = ∑ _m ∈ Finset.Ioc 0 (N / n), 1 := by
              apply Finset.sum_congr rfl
              intro m hm
              rw [if_neg]
              simp only [Finset.mem_Ioc] at hm
              omega
      _ = (Finset.Ioc 0 (N / n)).card := by simp
      _ = N / n := by simp
  exact hinner

lemma sum_sigma_zero_real_le_harmonic (N : ℕ) :
    (∑ n ∈ Finset.Ioc 0 N, (σ 0 n : ℝ))
      ≤ (N : ℝ) * (harmonic N : ℝ) := by
  rw [← Nat.cast_sum]
  rw [sum_sigma_zero_eq_div_sum]
  rw [Nat.cast_sum]
  calc
    (∑ d ∈ Finset.Ioc 0 N, ((N / d : ℕ) : ℝ))
      ≤ ∑ d ∈ Finset.Ioc 0 N, (N : ℝ) / (d : ℝ) := by
        apply Finset.sum_le_sum
        intro d hd
        exact Nat.cast_div_le
    _ = (N : ℝ) * ∑ d ∈ Finset.Ioc 0 N, ((d : ℝ)⁻¹) := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro d hd
        rw [div_eq_mul_inv]
    _ = (N : ℝ) * (harmonic N : ℝ) := by
        congr 1
        rw [harmonic_eq_sum_Icc]
        have hs : Finset.Ioc 0 N = Finset.Icc 1 N := by
          ext d
          simp
          omega
        rw [hs]
        simp


noncomputable def invNatAF : ArithmeticFunction ℝ where
  toFun n := if n = 0 then 0 else ((n : ℝ)⁻¹)
  map_zero' := by simp

lemma invNatAF_apply_of_pos {n : ℕ} (hn : 0 < n) :
    invNatAF n = ((n : ℝ)⁻¹) := by
  rw [invNatAF]
  simp [hn.ne']

lemma invNatAF_conv_self_apply {n : ℕ} (hn : n ≠ 0) :
    (invNatAF * invNatAF) n =
      (σ 0 n : ℝ) * ((n : ℝ)⁻¹) := by
  rw [mul_apply]
  have hanti := Nat.sum_divisorsAntidiagonal
    (fun a b : ℕ => invNatAF a * invNatAF b) (n := n)
  rw [hanti]
  calc
    (∑ d ∈ n.divisors, invNatAF d * invNatAF (n / d))
      = ∑ _d ∈ n.divisors, ((n : ℝ)⁻¹) := by
          apply Finset.sum_congr rfl
          intro d hd
          have hdpos : 0 < d := Nat.pos_of_mem_divisors hd
          have hddvd : d ∣ n := (Nat.mem_divisors.mp hd).1
          have hqpos : 0 < n / d := by
            apply Nat.div_pos
            · exact Nat.le_of_dvd (Nat.zero_lt_of_ne_zero hn) hddvd
            · exact hdpos
          rw [invNatAF_apply_of_pos hdpos, invNatAF_apply_of_pos hqpos]
          have hmul : (n / d) * d = n := Nat.div_mul_cancel hddvd
          rw [← mul_inv_rev]
          rw [← Nat.cast_mul, hmul]
    _ = (n.divisors.card : ℝ) * ((n : ℝ)⁻¹) := by
          simp
    _ = (σ 0 n : ℝ) * ((n : ℝ)⁻¹) := by
          rw [sigma_zero_apply]

lemma sum_invNatAF_eq_harmonic (N : ℕ) :
    (∑ n ∈ Finset.Ioc 0 N, invNatAF n) = (harmonic N : ℝ) := by
  calc
    (∑ n ∈ Finset.Ioc 0 N, invNatAF n)
      = ∑ n ∈ Finset.Ioc 0 N, ((n : ℝ)⁻¹) := by
          apply Finset.sum_congr rfl
          intro n hn
          have hnpos : 0 < n := by
            simp only [Finset.mem_Ioc] at hn
            omega
          rw [invNatAF_apply_of_pos hnpos]
    _ = (harmonic N : ℝ) := by
          rw [harmonic_eq_sum_Icc]
          have hs : Finset.Ioc 0 N = Finset.Icc 1 N := by
            ext n
            simp
            omega
          rw [hs]
          simp

lemma sum_weighted_sigma_zero_le_harmonic_sq (N : ℕ) :
    (∑ n ∈ Finset.Ioc 0 N,
      (σ 0 n : ℝ) * ((n : ℝ)⁻¹))
      ≤ (harmonic N : ℝ) ^ 2 := by
  have hconv :
      (∑ n ∈ Finset.Ioc 0 N, (invNatAF * invNatAF) n)
        = ∑ n ∈ Finset.Ioc 0 N,
            invNatAF n * ∑ m ∈ Finset.Ioc 0 (N / n), invNatAF m :=
    sum_Ioc_mul_eq_sum_sum invNatAF invNatAF N
  calc
    (∑ n ∈ Finset.Ioc 0 N,
      (σ 0 n : ℝ) * ((n : ℝ)⁻¹))
      = ∑ n ∈ Finset.Ioc 0 N, (invNatAF * invNatAF) n := by
          apply Finset.sum_congr rfl
          intro n hn
          have hn0 : n ≠ 0 := by
            simp only [Finset.mem_Ioc] at hn
            omega
          rw [invNatAF_conv_self_apply hn0]
    _ = ∑ n ∈ Finset.Ioc 0 N,
            invNatAF n * ∑ m ∈ Finset.Ioc 0 (N / n), invNatAF m := hconv
    _ ≤ ∑ n ∈ Finset.Ioc 0 N,
            invNatAF n * (harmonic N : ℝ) := by
          apply Finset.sum_le_sum
          intro n hn
          have hnpos : 0 < n := by
            simp only [Finset.mem_Ioc] at hn
            omega
          have hnonneg : 0 ≤ invNatAF n := by
            rw [invNatAF_apply_of_pos hnpos]
            positivity
          apply mul_le_mul_of_nonneg_left _ hnonneg
          have hsubset :
              Finset.Ioc 0 (N / n) ⊆ Finset.Ioc 0 N := by
            intro m hm
            simp only [Finset.mem_Ioc] at hm ⊢
            exact ⟨hm.1, le_trans hm.2 (Nat.div_le_self N n)⟩
          calc
            (∑ m ∈ Finset.Ioc 0 (N / n), invNatAF m)
              ≤ ∑ m ∈ Finset.Ioc 0 N, invNatAF m := by
                apply Finset.sum_le_sum_of_subset_of_nonneg hsubset
                intro m hm hnot
                by_cases hm0 : m = 0
                · subst m
                  simp [invNatAF]
                · rw [invNatAF]
                  simp [hm0]
            _ = (harmonic N : ℝ) := sum_invNatAF_eq_harmonic N
    _ = (harmonic N : ℝ) ^ 2 := by
          rw [← Finset.sum_mul]
          rw [sum_invNatAF_eq_harmonic]
          ring



noncomputable def tauRealAF : ArithmeticFunction ℝ where
  toFun n := (σ 0 n : ℝ)
  map_zero' := by simp

lemma tauRealAF_apply (n : ℕ) : tauRealAF n = (σ 0 n : ℝ) := rfl

lemma tauRealAF_conv_self_apply (n : ℕ) :
    (tauRealAF * tauRealAF) n = ((σ 0 * σ 0) n : ℝ) := by
  rw [mul_apply, mul_apply]
  rw [Nat.cast_sum]
  apply Finset.sum_congr rfl
  intro x hx
  rw [tauRealAF_apply, tauRealAF_apply, Nat.cast_mul]

lemma sum_tauSq_real_le_tauReal_conv (N : ℕ) :
    (∑ n ∈ Finset.Ioc 0 N, (tauSq n : ℝ))
      ≤ ∑ n ∈ Finset.Ioc 0 N, (tauRealAF * tauRealAF) n := by
  apply Finset.sum_le_sum
  intro n hn
  rw [tauRealAF_conv_self_apply]
  exact_mod_cast tauSq_le_tau_conv_tau n

lemma harmonic_cast_le_log_bound {M N : ℕ}
    (hM1 : 1 ≤ M) (hMN : M ≤ N) :
    (harmonic M : ℝ) ≤ 1 + Real.log (N : ℝ) := by
  calc
    (harmonic M : ℝ) ≤ 1 + Real.log (M : ℝ) := harmonic_le_one_add_log M
    _ ≤ 1 + Real.log (N : ℝ) := by
      gcongr

lemma inner_tau_sum_le_source_scale
    {N n : ℕ} (hnpos : 0 < n) (hnN : n ≤ N) :
    (∑ m ∈ Finset.Ioc 0 (N / n), tauRealAF m)
      ≤ (N : ℝ) * ((n : ℝ)⁻¹) * (1 + Real.log (N : ℝ)) := by
  have hq1 : 1 ≤ N / n := by
    exact (Nat.one_le_div_iff hnpos).2 hnN
  have hqN : N / n ≤ N := Nat.div_le_self N n
  have hsum :
      (∑ m ∈ Finset.Ioc 0 (N / n), tauRealAF m)
        ≤ ((N / n : ℕ) : ℝ) * (harmonic (N / n) : ℝ) := by
    simpa [tauRealAF] using sum_sigma_zero_real_le_harmonic (N / n)
  have hcastdiv : ((N / n : ℕ) : ℝ) ≤ (N : ℝ) * ((n : ℝ)⁻¹) := by
    calc
      ((N / n : ℕ) : ℝ) ≤ (N : ℝ) / (n : ℝ) := Nat.cast_div_le
      _ = (N : ℝ) * ((n : ℝ)⁻¹) := by rw [div_eq_mul_inv]
  have hharm :
      (harmonic (N / n) : ℝ) ≤ 1 + Real.log (N : ℝ) :=
    harmonic_cast_le_log_bound hq1 hqN
  have hnonneg_q : 0 ≤ ((N / n : ℕ) : ℝ) := by positivity
  have hnonneg_h : 0 ≤ (harmonic (N / n) : ℝ) := by
    rw [harmonic_eq_sum_Icc]
    positivity
  have hnonneg_Ndiv : 0 ≤ (N : ℝ) * ((n : ℝ)⁻¹) := by positivity
  have hnonneg_log : 0 ≤ 1 + Real.log (N : ℝ) := by
    have hN1 : 1 ≤ N := le_trans (Nat.one_le_iff_ne_zero.mpr hnpos.ne') hnN
    have hlog : 0 ≤ Real.log (N : ℝ) := Real.log_nonneg (by exact_mod_cast hN1)
    linarith
  exact hsum.trans <|
    mul_le_mul hcastdiv hharm hnonneg_h hnonneg_Ndiv

theorem petermann_divisor_square_moment
    (N : ℕ) (hN : 1 ≤ N) :
    (∑ n ∈ Finset.Ioc 0 N, ((σ 0 n : ℝ) ^ 2))
      ≤ (N : ℝ) * (1 + Real.log (N : ℝ)) ^ 3 := by
  have hconv :
      (∑ n ∈ Finset.Ioc 0 N, (tauRealAF * tauRealAF) n)
        = ∑ n ∈ Finset.Ioc 0 N,
            tauRealAF n *
              ∑ m ∈ Finset.Ioc 0 (N / n), tauRealAF m :=
    sum_Ioc_mul_eq_sum_sum tauRealAF tauRealAF N
  have hL : 0 ≤ 1 + Real.log (N : ℝ) := by
    have hlog : 0 ≤ Real.log (N : ℝ) := Real.log_nonneg (by exact_mod_cast hN)
    linarith
  have hH : 0 ≤ (harmonic N : ℝ) := by
    rw [harmonic_eq_sum_Icc]
    positivity
  calc
    (∑ n ∈ Finset.Ioc 0 N, ((σ 0 n : ℝ) ^ 2))
      = ∑ n ∈ Finset.Ioc 0 N, (tauSq n : ℝ) := by
          apply Finset.sum_congr rfl
          intro n hn
          rw [tauSq_apply]
          norm_num
    _ ≤ ∑ n ∈ Finset.Ioc 0 N, (tauRealAF * tauRealAF) n :=
      sum_tauSq_real_le_tauReal_conv N
    _ = ∑ n ∈ Finset.Ioc 0 N,
            tauRealAF n *
              ∑ m ∈ Finset.Ioc 0 (N / n), tauRealAF m := hconv
    _ ≤ ∑ n ∈ Finset.Ioc 0 N,
            tauRealAF n *
              ((N : ℝ) * ((n : ℝ)⁻¹) * (1 + Real.log (N : ℝ))) := by
          apply Finset.sum_le_sum
          intro n hnmem
          have hnrange : 0 < n ∧ n ≤ N := Finset.mem_Ioc.mp hnmem
          have hnpos : 0 < n := hnrange.1
          have hnN : n ≤ N := hnrange.2
          have htau : 0 ≤ tauRealAF n := by
            rw [tauRealAF_apply]
            positivity
          exact mul_le_mul_of_nonneg_left
            (inner_tau_sum_le_source_scale hnpos hnN) htau
    _ = (N : ℝ) * (1 + Real.log (N : ℝ)) *
          (∑ n ∈ Finset.Ioc 0 N,
            (σ 0 n : ℝ) * ((n : ℝ)⁻¹)) := by
          simp_rw [tauRealAF_apply]
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro n hnmem
          ring
    _ ≤ (N : ℝ) * (1 + Real.log (N : ℝ)) *
          ((harmonic N : ℝ) ^ 2) := by
          have hNL : 0 ≤ (N : ℝ) * (1 + Real.log (N : ℝ)) := by positivity
          exact mul_le_mul_of_nonneg_left
            (sum_weighted_sigma_zero_le_harmonic_sq N) hNL
    _ ≤ (N : ℝ) * (1 + Real.log (N : ℝ)) ^ 3 := by
          have hh := harmonic_le_one_add_log N
          have hsq :
              (harmonic N : ℝ) ^ 2 ≤ (1 + Real.log (N : ℝ)) ^ 2 := by
            nlinarith
          nlinarith [mul_nonneg (show 0 ≤ (N : ℝ) by positivity) hL]


#print axioms petermann_divisor_square_moment
#print axioms sum_weighted_sigma_zero_le_harmonic_sq
#print axioms tauSq_le_tau_conv_tau

end PaperB.Analytic
