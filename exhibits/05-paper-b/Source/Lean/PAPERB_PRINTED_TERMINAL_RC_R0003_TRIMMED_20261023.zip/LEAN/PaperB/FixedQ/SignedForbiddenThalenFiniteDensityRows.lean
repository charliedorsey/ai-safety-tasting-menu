import PaperB.FixedQ.SignedForbiddenThalenDecoratedExteriorRows

open scoped BigOperators

namespace PaperB.FixedQ

private theorem thalen_reciprocal_primeSetProduct (T : Finset ℕ) :
    (1 / (primeSetProduct T : ℝ)) =
      ∏ p ∈ T, 1 / (p : ℝ) := by
  simp [primeSetProduct, one_div, Finset.prod_inv_distrib]

/-- Literal proper-partition source density, without changing rowWeightMass,
is the finite signed disjoint-support Euler density. -/
theorem thalen_finite_source_density_eq_rows (S : Finset ℕ) :
    (∑ e ∈ S.powerset,
      finiteOmegaWeightReal e *
        (∑ B ∈ ((e.powerset.erase e).erase ∅),
          1 / ((primeSetProduct B : ℝ) *
            (primeSetProduct (e \ B) : ℝ)))) =
      thalenFiniteProperSourceDensity S := by
  let w : ℕ → ℝ := fun p => 1 / ((p : ℝ) - 3)
  let L : ℕ → ℝ := fun p => 1 / (p : ℝ)
  have hsum :
      (∑ e ∈ S.powerset,
        finiteOmegaWeightReal e *
          (∑ B ∈ ((e.powerset.erase e).erase ∅),
            1 / ((primeSetProduct B : ℝ) *
              (primeSetProduct (e \ B) : ℝ)))) =
      (∑ e ∈ S.powerset,
        (∏ p ∈ e, w p) *
          (∑ B ∈ ((e.powerset.erase e).erase ∅),
            (∏ p ∈ B, L p) * (∏ p ∈ e \ B, L p))) := by
    apply Finset.sum_congr rfl
    intro e he
    congr 1
    apply Finset.sum_congr rfl
    intro B hB
    dsimp [L]
    rw [← thalen_reciprocal_primeSetProduct B,
      ← thalen_reciprocal_primeSetProduct (e \ B)]
    simp only [one_div, mul_inv_rev]
    ac_rfl
  rw [hsum, thalen_outer_support_proper_euler]
  dsimp [w, L, thalenFiniteProperSourceDensity, thalenFiniteA]
  have hlocal1 : ∀ p : ℕ,
      (1 / ((p : ℝ) - 3)) * (1 / (p : ℝ) + 1 / (p : ℝ)) =
        2 / ((p : ℝ) * ((p : ℝ) - 3)) := by
    intro p
    simp only [one_div, div_eq_mul_inv, mul_inv_rev, one_mul]
    ring
  have hlocal2 : ∀ p : ℕ,
      (1 / ((p : ℝ) - 3)) * (1 / (p : ℝ)) =
        1 / ((p : ℝ) * ((p : ℝ) - 3)) := by
    intro p
    simp only [one_div, mul_inv_rev] <;> ring
  simp_rw [hlocal1, hlocal2]
  ring

#print axioms thalen_finite_source_density_eq_rows

end PaperB.FixedQ
