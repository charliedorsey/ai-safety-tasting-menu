import PaperB.FixedQ.H3HeightForbiddenCore

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def dForbiddenBooleanAbsFamily
    (q a H : ℕ) (d : Finset ℕ) : ℝ :=
  ∑' n : Finset ℕ, |dForbiddenReducedBooleanCoreTerm q a H d n|

noncomputable def ordinaryBooleanAbsFamily
    (q a H : ℕ) : ℝ :=
  ∑' n : Finset ℕ, |ordinaryBooleanCoreTerm q a H n|

lemma abs_dForbiddenReducedBooleanCoreTerm_le
    (q a H : ℕ) (d n : Finset ℕ) :
    |dForbiddenReducedBooleanCoreTerm q a H d n| ≤
      |ordinaryBooleanCoreTerm q a H n| := by
  by_cases hdis : Disjoint d n
  · simp [dForbiddenReducedBooleanCoreTerm, hdis]
  · simp [dForbiddenReducedBooleanCoreTerm, hdis]

theorem dForbiddenBooleanAbsFamily_le_full
    {q a H : ℕ} {d : Finset ℕ}
    (hfull : Summable (fun n : Finset ℕ =>
      |ordinaryBooleanCoreTerm q a H n|)) :
    dForbiddenBooleanAbsFamily q a H d ≤
      ordinaryBooleanAbsFamily q a H := by
  unfold dForbiddenBooleanAbsFamily ordinaryBooleanAbsFamily
  have hrestricted : Summable (fun n : Finset ℕ =>
      |dForbiddenReducedBooleanCoreTerm q a H d n|) :=
    hfull.of_nonneg_of_le
      (fun n => abs_nonneg _)
      (fun n => abs_dForbiddenReducedBooleanCoreTerm_le q a H d n)
  exact Summable.tsum_le_tsum
    (fun n => abs_dForbiddenReducedBooleanCoreTerm_le q a H d n)
    hrestricted hfull

lemma heightPrimePart_nonempty_of_forbidden
    {h : ℕ} {e : Finset ℕ}
    (he : e ∈ (ordinaryTwoDimensionalSet h)ᶜ) :
    (heightPrimePart h e).Nonempty := by
  rw [Set.mem_compl_iff] at he
  unfold ordinaryTwoDimensionalSet at he
  simpa [Finset.nonempty_iff_ne_empty] using he

noncomputable def decoratedHeightRestrictedAbsPairTerm
    (q a h : ℕ) (dn : Finset ℕ × Finset ℕ) : ℝ :=
  let d := dn.1
  let n := dn.2
  if hd : d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty then
    finiteVWeightReal h d *
      |dForbiddenReducedBooleanCoreTerm q
        (decoratedReducedAnchor q a (primeSetProduct d))
        (h / primeSetProduct d) d n|
  else 0

noncomputable def decoratedHeightRestrictedAbsReindexMajorant
    (q a h : ℕ)
    (x : (Finset ℕ × Finset ℕ) ⊕ Finset ℕ) : ℝ :=
  match x with
  | Sum.inl dn => decoratedHeightRestrictedAbsPairTerm q a h dn
  | Sum.inr _ => 0

lemma decoratedHeightRestrictedAbsPairTerm_nonneg
    (q a h : ℕ) (dn : Finset ℕ × Finset ℕ) :
    0 ≤ decoratedHeightRestrictedAbsPairTerm q a h dn := by
  rcases dn with ⟨d, n⟩
  unfold decoratedHeightRestrictedAbsPairTerm
  dsimp
  split_ifs with hd
  · have hv0 : 0 ≤ finiteVWeightReal h d := by
      apply finiteVWeightReal_nonneg_of_active
      exact decoratedHeightPrimeSet_active (Finset.mem_powerset.mp hd.1)
    exact mul_nonneg hv0 (abs_nonneg _)
  · exact le_rfl

lemma decoratedHeightRestrictedAbsReindexMajorant_nonneg
    (q a h : ℕ) (x : (Finset ℕ × Finset ℕ) ⊕ Finset ℕ) :
    0 ≤ decoratedHeightRestrictedAbsReindexMajorant q a h x := by
  cases x with
  | inl dn =>
      exact decoratedHeightRestrictedAbsPairTerm_nonneg q a h dn
  | inr e =>
      simp [decoratedHeightRestrictedAbsReindexMajorant]

lemma abs_heightForbidden_indicator_le_reindexMajorant
    {q a h : ℕ} (hh : 0 < h) (e : Finset ℕ) :
    |(ordinaryTwoDimensionalSet h)ᶜ.indicator
        (decoratedHeightForbiddenCoreTerm q a h) e| ≤
      decoratedHeightRestrictedAbsReindexMajorant q a h
        (decoratedAnalyticSignedReindexKey q h e) := by
  classical
  by_cases he : e ∈ (ordinaryTwoDimensionalSet h)ᶜ
  · rw [Set.indicator_of_mem he]
    by_cases hA : ∀ p ∈ e, activeHighPrime q p
    · let d := heightPrimePart h e
      let n := e \ d
      have hdsub : d ⊆ decoratedHeightPrimeSet q h := by
        dsimp [d]
        exact heightPrimePart_subset_decoratedHeightPrimeSet_of_active hh hA
      have hdmem : d ∈ (decoratedHeightPrimeSet q h).powerset :=
        Finset.mem_powerset.mpr hdsub
      have hdne : d.Nonempty := by
        dsimp [d]
        exact heightPrimePart_nonempty_of_forbidden he
      have hdis : Disjoint d n := by
        dsimp [n]
        exact Finset.disjoint_sdiff
      have hn : n ∈ activeOrdinaryTwoDimensionalSet q
          (h / primeSetProduct d) := by
        have h0 := decorated_nonheight_activeOrdinary
          (q := q) (h := h) (e := e) hA
        simpa [d, n, decoratedReducedHeight, decoratedHeightProduct] using h0
      have hrec := decoratedHeightForbiddenCoreTerm_union_reconstruct
        (q := q) (a := a) (h := h)
        (d := d) (n := n) hdsub hn hdis
      have hu : d ∪ n = e := by
        dsimp [d, n]
        exact Finset.union_sdiff_of_subset (Finset.filter_subset _ _)
      rw [hu] at hrec
      rw [hrec]
      rw [decoratedAnalyticSignedReindexKey, if_pos hA]
      simp only [decoratedHeightRestrictedAbsReindexMajorant,
        decoratedHeightRestrictedAbsPairTerm]
      change
        |finiteVWeightReal h d *
          ordinaryBooleanCoreTerm q
            (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d) n| ≤
        (if _ : d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty then
          finiteVWeightReal h d *
            |dForbiddenReducedBooleanCoreTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) d n|
        else 0)
      split_ifs with hgate
      · have hv0 : 0 ≤ finiteVWeightReal h d := by
          apply finiteVWeightReal_nonneg_of_active
          exact decoratedHeightPrimeSet_active hdsub
        rw [abs_mul, abs_of_nonneg hv0]
        simp [dForbiddenReducedBooleanCoreTerm, hdis]
      · exact (hgate ⟨hdmem, hdne⟩).elim
    · rw [decoratedAnalyticSignedReindexKey, if_neg hA]
      simp [decoratedHeightForbiddenCoreTerm,
        decoratedHeightRestrictedAbsReindexMajorant, hA]
  · simp [Set.indicator, he]
    exact decoratedHeightRestrictedAbsReindexMajorant_nonneg q a h _

theorem summable_decoratedHeightRestrictedAbsPairTerm
    {q a h : ℕ}
    (hAbs : ∀ d ∈ (decoratedHeightPrimeSet q h).powerset,
      Summable (fun n : Finset ℕ =>
        |ordinaryBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) n|)) :
    Summable (decoratedHeightRestrictedAbsPairTerm q a h) := by
  rw [summable_prod_of_nonneg
    (fun dn => decoratedHeightRestrictedAbsPairTerm_nonneg q a h dn)]
  constructor
  · intro d
    by_cases hd :
        d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty
    · have hr := (hAbs d hd.1).of_nonneg_of_le
        (fun n => abs_nonneg _)
        (fun n =>
          abs_dForbiddenReducedBooleanCoreTerm_le q
            (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d) d n)
      simpa [decoratedHeightRestrictedAbsPairTerm, hd] using
        hr.mul_left (finiteVWeightReal h d)
    · have hd' :
          ¬(d ⊆ decoratedHeightPrimeSet q h ∧ d.Nonempty) := by
          simpa [Finset.mem_powerset] using hd
      simp [decoratedHeightRestrictedAbsPairTerm, hd']
  · apply summable_of_hasFiniteSupport
    refine (decoratedHeightPrimeSet q h).powerset.finite_toSet.subset ?_
    intro d hd
    by_contra hdmem
    have hdsub : ¬ d ⊆ decoratedHeightPrimeSet q h := by
      simpa [Finset.mem_powerset] using hdmem
    have hz : (∑' n : Finset ℕ,
        decoratedHeightRestrictedAbsPairTerm q a h (d, n)) = 0 := by
      simp [decoratedHeightRestrictedAbsPairTerm, hdsub]
    exact hd hz

theorem summable_decoratedHeightRestrictedAbsReindexMajorant
    {q a h : ℕ}
    (hAbs : ∀ d ∈ (decoratedHeightPrimeSet q h).powerset,
      Summable (fun n : Finset ℕ =>
        |ordinaryBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) n|)) :
    Summable (decoratedHeightRestrictedAbsReindexMajorant q a h) := by
  have hp := summable_decoratedHeightRestrictedAbsPairTerm
    (q := q) (a := a) (h := h) hAbs
  apply (Sum.inl_injective.summable_iff ?_).mp
  · simpa [Function.comp_def, decoratedHeightRestrictedAbsReindexMajorant] using hp
  · intro x hx
    cases x with
    | inl dn => exact (hx ⟨dn, rfl⟩).elim
    | inr e => simp [decoratedHeightRestrictedAbsReindexMajorant]

noncomputable def decoratedHeightRestrictedBooleanMajorant
    (q a h : ℕ) : ℝ :=
  ∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
    finiteVWeightReal h d *
      dForbiddenBooleanAbsFamily q
        (decoratedReducedAnchor q a (primeSetProduct d))
        (h / primeSetProduct d) d

theorem tsum_reindexMajorant_eq_heightRestrictedBooleanMajorant
    {q a h : ℕ}
    (hAbs : ∀ d ∈ (decoratedHeightPrimeSet q h).powerset,
      Summable (fun n : Finset ℕ =>
        |ordinaryBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) n|)) :
    (∑' x, decoratedHeightRestrictedAbsReindexMajorant q a h x) =
      decoratedHeightRestrictedBooleanMajorant q a h := by
  have hPair := summable_decoratedHeightRestrictedAbsPairTerm
    (q := q) (a := a) (h := h) hAbs
  have hInl : Summable
      (decoratedHeightRestrictedAbsReindexMajorant q a h ∘ Sum.inl) := by
    simpa [Function.comp_def, decoratedHeightRestrictedAbsReindexMajorant] using hPair
  have hInr : Summable
      (decoratedHeightRestrictedAbsReindexMajorant q a h ∘ Sum.inr) := by
    simp [Function.comp_def, decoratedHeightRestrictedAbsReindexMajorant]
  rw [Summable.tsum_sum hInl hInr]
  simp only [decoratedHeightRestrictedAbsReindexMajorant, tsum_zero, add_zero]
  rw [hPair.tsum_prod]
  unfold decoratedHeightRestrictedBooleanMajorant
  rw [tsum_eq_sum (s := (decoratedHeightPrimeSet q h).powerset.erase ∅)]
  · apply Finset.sum_congr rfl
    intro d hd
    have hdps : d ∈ (decoratedHeightPrimeSet q h).powerset :=
      (Finset.mem_erase.mp hd).2
    have hdne : d.Nonempty := by
      exact Finset.nonempty_iff_ne_empty.mpr (Finset.mem_erase.mp hd).1
    have hres : Summable (fun n : Finset ℕ =>
        |dForbiddenReducedBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) d n|) :=
      (hAbs d hdps).of_nonneg_of_le
        (fun n => abs_nonneg _)
        (fun n => abs_dForbiddenReducedBooleanCoreTerm_le q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) d n)
    have hgate :
        d ∈ (decoratedHeightPrimeSet q h).powerset ∧ d.Nonempty :=
      ⟨hdps, hdne⟩
    simpa [decoratedHeightRestrictedAbsPairTerm, hgate,
      dForbiddenBooleanAbsFamily] using
      hres.tsum_mul_left (finiteVWeightReal h d)
  · intro d hd
    have hout :
        ¬(d ⊆ decoratedHeightPrimeSet q h ∧ d.Nonempty) := by
      intro hg
      apply hd
      apply Finset.mem_erase.mpr
      exact ⟨Finset.nonempty_iff_ne_empty.mp hg.2, Finset.mem_powerset.mpr hg.1⟩
    simp [decoratedHeightRestrictedAbsPairTerm, hout]

theorem abs_decoratedAnalyticRemainder_le_heightRestrictedBooleanMajorant
    {q a h : ℕ} (hh : 0 < h)
    (hSource : Summable
      ((ordinaryTwoDimensionalSet h)ᶜ.indicator
        (decoratedHeightForbiddenCoreTerm q a h)))
    (hAbs : ∀ d ∈ (decoratedHeightPrimeSet q h).powerset,
      Summable (fun n : Finset ℕ =>
        |ordinaryBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) n|)) :
    |decoratedAnalyticRemainder q a h| ≤
      decoratedHeightRestrictedBooleanMajorant q a h := by
  let f : Finset ℕ → ℝ :=
    (ordinaryTwoDimensionalSet h)ᶜ.indicator
      (decoratedHeightForbiddenCoreTerm q a h)
  let g : (Finset ℕ × Finset ℕ) ⊕ Finset ℕ → ℝ :=
    decoratedHeightRestrictedAbsReindexMajorant q a h
  have hfAbs : Summable (fun e => |f e|) := by
    simpa [f, Real.norm_eq_abs] using hSource.norm
  have hg : Summable g := by
    simpa [g] using
      summable_decoratedHeightRestrictedAbsReindexMajorant
        (q := q) (a := a) (h := h) hAbs
  have hfg :
      (∑' e : Finset ℕ, |f e|) ≤ ∑' x, g x := by
    apply hfAbs.tsum_le_tsum_of_inj
      (decoratedAnalyticSignedReindexKey q h)
      (decoratedAnalyticSignedReindexKey_injective q h)
    · intro x hx
      exact decoratedHeightRestrictedAbsReindexMajorant_nonneg q a h x
    · intro e
      simpa [f, g] using
        abs_heightForbidden_indicator_le_reindexMajorant
          (q := q) (a := a) hh e
    · exact hg
  rw [decoratedAnalyticRemainder_eq_height_forbidden_core]
  change |∑' e : Finset ℕ, f e| ≤ _
  calc
    |∑' e : Finset ℕ, f e| ≤ ∑' e : Finset ℕ, |f e| := by
      simpa [Real.norm_eq_abs] using norm_tsum_le_tsum_norm hSource.norm
    _ ≤ ∑' x, g x := hfg
    _ = decoratedHeightRestrictedBooleanMajorant q a h := by
      simpa [g] using
        tsum_reindexMajorant_eq_heightRestrictedBooleanMajorant
          (q := q) (a := a) (h := h) hAbs

theorem abs_cStar_mul_decoratedAnalyticRemainder_le_heightRestrictedBooleanMajorant
    {q a h : ℕ} (hh : 0 < h)
    (hSource : Summable
      ((ordinaryTwoDimensionalSet h)ᶜ.indicator
        (decoratedHeightForbiddenCoreTerm q a h)))
    (hAbs : ∀ d ∈ (decoratedHeightPrimeSet q h).powerset,
      Summable (fun n : Finset ℕ =>
        |ordinaryBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) n|)) :
    |cStarReal q h * decoratedAnalyticRemainder q a h| ≤
      decoratedHeightRestrictedBooleanMajorant q a h := by
  rw [abs_mul]
  have hc := abs_cStarReal_le_one q h
  have hr := abs_decoratedAnalyticRemainder_le_heightRestrictedBooleanMajorant
    (q := q) (a := a) hh hSource hAbs
  have hM0 : 0 ≤ decoratedHeightRestrictedBooleanMajorant q a h := by
    unfold decoratedHeightRestrictedBooleanMajorant
    apply Finset.sum_nonneg
    intro d hd
    apply mul_nonneg
    · apply finiteVWeightReal_nonneg_of_active
      exact decoratedHeightPrimeSet_active
        (Finset.mem_powerset.mp (Finset.mem_erase.mp hd).2)
    · exact tsum_nonneg (fun _ => abs_nonneg _)
  calc
    |cStarReal q h| * |decoratedAnalyticRemainder q a h|
      ≤ 1 * |decoratedAnalyticRemainder q a h| := by
        exact mul_le_mul_of_nonneg_right hc (abs_nonneg _)
    _ ≤ 1 * decoratedHeightRestrictedBooleanMajorant q a h := by
        gcongr
    _ = decoratedHeightRestrictedBooleanMajorant q a h := one_mul _

noncomputable def decoratedHeightFullBooleanMajorant
    (q a h : ℕ) : ℝ :=
  ∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
    finiteVWeightReal h d *
      ordinaryBooleanAbsFamily q
        (decoratedReducedAnchor q a (primeSetProduct d))
        (h / primeSetProduct d)

theorem decoratedHeightRestrictedBooleanMajorant_le_full
    {q a h : ℕ}
    (hAbs : ∀ d ∈ (decoratedHeightPrimeSet q h).powerset,
      Summable (fun n : Finset ℕ =>
        |ordinaryBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) n|)) :
    decoratedHeightRestrictedBooleanMajorant q a h ≤
      decoratedHeightFullBooleanMajorant q a h := by
  unfold decoratedHeightRestrictedBooleanMajorant
    decoratedHeightFullBooleanMajorant
  apply Finset.sum_le_sum
  intro d hd
  have hdps : d ∈ (decoratedHeightPrimeSet q h).powerset :=
    (Finset.mem_erase.mp hd).2
  have hv0 : 0 ≤ finiteVWeightReal h d := by
    apply finiteVWeightReal_nonneg_of_active
    exact decoratedHeightPrimeSet_active (Finset.mem_powerset.mp hdps)
  exact mul_le_mul_of_nonneg_left
    (dForbiddenBooleanAbsFamily_le_full (hfull := hAbs d hdps)) hv0

theorem abs_cStar_mul_decoratedAnalyticRemainder_le_heightFullBooleanMajorant
    {q a h : ℕ} (hh : 0 < h)
    (hSource : Summable
      ((ordinaryTwoDimensionalSet h)ᶜ.indicator
        (decoratedHeightForbiddenCoreTerm q a h)))
    (hAbs : ∀ d ∈ (decoratedHeightPrimeSet q h).powerset,
      Summable (fun n : Finset ℕ =>
        |ordinaryBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) n|)) :
    |cStarReal q h * decoratedAnalyticRemainder q a h| ≤
      decoratedHeightFullBooleanMajorant q a h :=
  (abs_cStar_mul_decoratedAnalyticRemainder_le_heightRestrictedBooleanMajorant
    (q := q) (a := a) hh hSource hAbs).trans
      (decoratedHeightRestrictedBooleanMajorant_le_full hAbs)

theorem summable_heightForbiddenCore_indicator
    {q a r h : ℕ}
    (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h)
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    Summable
      ((ordinaryTwoDimensionalSet h)ᶜ.indicator
        (decoratedHeightForbiddenCoreTerm q a h)) := by
  have hs := summable_decoratedAnalyticPerE_indicator
    (q := q) (a := a) (r := r) hq hh h2admissible hreflect
  apply hs.congr
  intro e
  by_cases he : e ∈ (ordinaryTwoDimensionalSet h)ᶜ
  · rw [Set.indicator_of_mem he, Set.indicator_of_mem he]
    by_cases hAall : ∀ p ∈ e, activeHighPrime q p
    · exact decoratedAnalyticPerE_eq_height_forbidden_core_term hAall
    · have hper : decoratedAnalyticPerE q a h e = 0 := by
        unfold decoratedAnalyticPerE
        apply Finset.sum_eq_zero
        intro e1 he1
        have hz := pairCoefficient_eq_zero_of_not_all_active
          (q := q) (h := h) (e := e) (e1 := e1) hAall
        simp [decoratedAnalyticPairTerm, hz]
      rw [hper]
      simp [decoratedHeightForbiddenCoreTerm, hAall]
  · simp [Set.indicator, he]

theorem abs_cStar_mul_decoratedAnalyticRemainder_le_heightFullBooleanMajorant_of_live
    {q a r h : ℕ}
    (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h)
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z))
    (hAbs : ∀ d ∈ (decoratedHeightPrimeSet q h).powerset,
      Summable (fun n : Finset ℕ =>
        |ordinaryBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) n|)) :
    |cStarReal q h * decoratedAnalyticRemainder q a h| ≤
      decoratedHeightFullBooleanMajorant q a h :=
  abs_cStar_mul_decoratedAnalyticRemainder_le_heightFullBooleanMajorant
    hh
    (summable_heightForbiddenCore_indicator hq hh h2admissible hreflect)
    hAbs

theorem abs_cStar_mul_decoratedAnalyticRemainder_le_of_boolean_bounds
    {q a r h : ℕ}
    (hq : 0 < q) (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h)
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z))
    (B : Finset ℕ → ℝ)
    (hAbs : ∀ d ∈ (decoratedHeightPrimeSet q h).powerset,
      Summable (fun n : Finset ℕ =>
        |ordinaryBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) n|))
    (hB : ∀ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
      ordinaryBooleanAbsFamily q
        (decoratedReducedAnchor q a (primeSetProduct d))
        (h / primeSetProduct d) ≤ B d) :
    |cStarReal q h * decoratedAnalyticRemainder q a h| ≤
      ∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
        finiteVWeightReal h d * B d := by
  refine (abs_cStar_mul_decoratedAnalyticRemainder_le_heightFullBooleanMajorant_of_live
    hq hh h2admissible hreflect hAbs).trans ?_
  unfold decoratedHeightFullBooleanMajorant
  apply Finset.sum_le_sum
  intro d hd
  have hdps : d ∈ (decoratedHeightPrimeSet q h).powerset :=
    (Finset.mem_erase.mp hd).2
  have hv0 : 0 ≤ finiteVWeightReal h d := by
    apply finiteVWeightReal_nonneg_of_active
    exact decoratedHeightPrimeSet_active (Finset.mem_powerset.mp hdps)
  exact mul_le_mul_of_nonneg_left (hB d hd) hv0

#print axioms summable_heightForbiddenCore_indicator
#print axioms abs_cStar_mul_decoratedAnalyticRemainder_le_of_boolean_bounds
#print axioms dForbiddenBooleanAbsFamily_le_full
#print axioms heightPrimePart_nonempty_of_forbidden
#print axioms abs_heightForbidden_indicator_le_reindexMajorant
#print axioms summable_decoratedHeightRestrictedAbsReindexMajorant
#print axioms abs_cStar_mul_decoratedAnalyticRemainder_le_heightRestrictedBooleanMajorant
#print axioms decoratedHeightRestrictedBooleanMajorant_le_full
#print axioms abs_cStar_mul_decoratedAnalyticRemainder_le_heightFullBooleanMajorant

end PaperB.FixedQ
