import GoldB.Invariance
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.LinearAlgebra.Matrix.Nondegenerate
import Mathlib.RingTheory.MvPolynomial.Symmetric.NewtonIdentities
import Mathlib.RingTheory.Polynomial.Vieta
import Mathlib.NumberTheory.Multiplicity
import Mathlib.Data.ZMod.Basic

/-!
# GoldB.Congruence

The congruence-counting lemma behind the p-adic proof of Vinogradov's mean value
theorem: for a prime `p > k` and integers in a set of diameter `< p^k`, the number
of `k`-tuples, pairwise incongruent mod `p`, with prescribed power sums
`∑ (x_i - c)^j mod p^j` (`1 ≤ j ≤ k`) is at most `k! p^{k(k-1)/2}`.

Two ingredients:
* **Hensel / Vandermonde injectivity**: the Jacobian `(j x_i^{j-1})` is invertible mod `p`;
* **Newton's identities**: power sums `1..k` determine the multiset mod `p` (as `p > k`).
-/

open Finset

namespace GoldB

/-- The linearised power-sum system is nonsingular mod `p`. -/
lemma jac_kernel (p : ℕ) [Fact p.Prime] (k : ℕ) (hk : k < p) (x d : Fin k → ZMod p)
    (hx : Function.Injective x)
    (h : ∀ j : Fin k, ∑ i, (((j : ℕ) + 1 : ℕ) : ZMod p) * x i ^ (j : ℕ) * d i = 0) :
    d = 0 := by
  set Mx : Matrix (Fin k) (Fin k) (ZMod p) :=
    Matrix.diagonal (fun j : Fin k => (((j : ℕ) + 1 : ℕ) : ZMod p)) *
      (Matrix.vandermonde x).transpose
  have hM : Mx.mulVec d = 0 := by
    ext j
    simp only [Mx, Matrix.mulVec, dotProduct, Matrix.diagonal_mul, Matrix.transpose_apply,
      Matrix.vandermonde_apply, Pi.zero_apply]
    rw [← h j]
  have hdet : Mx.det ≠ 0 := by
    simp only [Mx]
    rw [Matrix.det_mul, Matrix.det_diagonal, Matrix.det_transpose, Matrix.det_vandermonde]
    apply mul_ne_zero
    · rw [Finset.prod_ne_zero_iff]; intro j _
      rw [Ne, ZMod.natCast_eq_zero_iff]
      intro hd
      have := Nat.le_of_dvd (Nat.succ_pos _) hd
      have := j.isLt
      omega
    · rw [Finset.prod_ne_zero_iff]; intro i _
      rw [Finset.prod_ne_zero_iff]; intro l hl
      rw [sub_ne_zero]
      intro he
      have := hx he
      rw [Finset.mem_Ioi] at hl
      rw [this] at hl
      exact lt_irrefl _ hl
  exact Matrix.eq_zero_of_mulVec_eq_zero hdet hM

/-- one Hensel lifting step -/
lemma hensel_step (p : ℕ) [hp : Fact p.Prime] (k : ℕ) (hk : k < p) (x y : Fin k → ℤ)
    (hdist : ∀ i l, i ≠ l → ¬ ((p : ℤ) ∣ x i - x l))
    (hsum : ∀ j : Fin k, (p : ℤ) ^ k ∣ psv k y j - psv k x j)
    (t : ℕ) (ht1 : 1 ≤ t) (htk : t < k) (hxy : ∀ i, (p : ℤ) ^ t ∣ y i - x i) :
    ∀ i, (p : ℤ) ^ (t + 1) ∣ y i - x i := by
  choose d hd using hxy
  have hpz : (p : ℤ) ≠ 0 := by exact_mod_cast hp.out.ne_zero
  -- linearisation
  have hlin : ∀ j : Fin k, (p : ℤ) ∣ ∑ i, (((j : ℕ) + 1 : ℕ) : ℤ) * x i ^ (j : ℕ) * d i := by
    intro j
    have hsq : ∀ i, (p : ℤ) ^ (2 * t) ∣
        y i ^ ((j : ℕ) + 1) - x i ^ ((j : ℕ) + 1) -
          (p : ℤ) ^ t * ((((j : ℕ) + 1 : ℕ) : ℤ) * x i ^ (j : ℕ) * d i) := by
      intro i
      have hy : y i = x i + (p : ℤ) ^ t * d i := by linarith [hd i]
      have h0 := sq_dvd_add_pow_sub_sub ((p : ℤ) ^ t * d i) (x i) ((j : ℕ) + 1)
      have h1 : (p : ℤ) ^ (2 * t) ∣ ((p : ℤ) ^ t * d i) ^ 2 := by
        rw [mul_pow, ← pow_mul, mul_comm t 2]; exact dvd_mul_right _ _
      have h2 := h1.trans h0
      rw [hy]
      convert h2 using 1
      simp only [Nat.add_sub_cancel]
      push_cast; ring
    have hsum' : (p : ℤ) ^ (2 * t) ∣
        (psv k y j - psv k x j) -
          (p : ℤ) ^ t * ∑ i, (((j : ℕ) + 1 : ℕ) : ℤ) * x i ^ (j : ℕ) * d i := by
      have : (psv k y j - psv k x j) -
          (p : ℤ) ^ t * ∑ i, (((j : ℕ) + 1 : ℕ) : ℤ) * x i ^ (j : ℕ) * d i =
          ∑ i, (y i ^ ((j : ℕ) + 1) - x i ^ ((j : ℕ) + 1) -
            (p : ℤ) ^ t * ((((j : ℕ) + 1 : ℕ) : ℤ) * x i ^ (j : ℕ) * d i)) := by
        simp only [psv, Finset.mul_sum, ← Finset.sum_sub_distrib]
      rw [this]
      exact Finset.dvd_sum (fun i _ => hsq i)
    have hA : (p : ℤ) ^ (t + 1) ∣ (psv k y j - psv k x j) := by
      exact (pow_dvd_pow _ (by omega)).trans (hsum j)
    have hB : (p : ℤ) ^ (t + 1) ∣ (psv k y j - psv k x j) -
          (p : ℤ) ^ t * ∑ i, (((j : ℕ) + 1 : ℕ) : ℤ) * x i ^ (j : ℕ) * d i :=
      (pow_dvd_pow _ (by omega)).trans hsum'
    have hC : (p : ℤ) ^ (t + 1) ∣
        (p : ℤ) ^ t * ∑ i, (((j : ℕ) + 1 : ℕ) : ℤ) * x i ^ (j : ℕ) * d i := by
      have := dvd_sub hA hB
      simpa using this
    rw [pow_succ] at hC
    exact (mul_dvd_mul_iff_left (pow_ne_zero _ hpz)).mp hC
  -- reduce mod p
  have hinj : Function.Injective (fun i => (x i : ZMod p)) := by
    intro i l h
    by_contra hne
    apply hdist i l hne
    simp only at h
    rw [ZMod.intCast_eq_intCast_iff_dvd_sub] at h
    have h' : (p : ℤ) ∣ -(x l - x i) := dvd_neg.mpr h
    simpa using h'
  have hker := jac_kernel p k hk (fun i => (x i : ZMod p)) (fun i => (d i : ZMod p)) hinj
    (by
      intro j
      have := (ZMod.intCast_zmod_eq_zero_iff_dvd _ p).mpr (hlin j)
      push_cast at this ⊢
      exact this)
  intro i
  have hdi : (p : ℤ) ∣ d i := by
    have := congrFun hker i
    simpa [ZMod.intCast_zmod_eq_zero_iff_dvd] using this
  rw [hd i, pow_succ]
  exact mul_dvd_mul_left _ hdi

/-- **Hensel injectivity** -/
theorem hensel_inj (p : ℕ) [Fact p.Prime] (k : ℕ) (hk : k < p) (x y : Fin k → ℤ)
    (hdist : ∀ i l, i ≠ l → ¬ ((p : ℤ) ∣ x i - x l))
    (hsum : ∀ j : Fin k, (p : ℤ) ^ k ∣ psv k y j - psv k x j)
    (hxy : ∀ i, (p : ℤ) ∣ y i - x i) : ∀ i, (p : ℤ) ^ k ∣ y i - x i := by
  rcases Nat.eq_zero_or_pos k with h0 | hpos
  · intro i; exact absurd i.isLt (by omega)
  have key : ∀ t, 1 ≤ t → t ≤ k → ∀ i, (p : ℤ) ^ t ∣ y i - x i := by
    intro t ht1 htk
    induction t with
    | zero => omega
    | succ t ih =>
      rcases Nat.eq_zero_or_pos t with h0 | htpos
      · subst h0; simpa using hxy
      · exact hensel_step p k hk x y hdist hsum t htpos (by omega) (ih htpos (by omega))
  exact key k hpos le_rfl

/-! ## Newton identities: power sums determine the multiset -/

theorem multiset_eq_of_psum {F : Type*} [Field F] (k : ℕ)
    (hchar : ∀ m : ℕ, 1 ≤ m → m ≤ k → (m : F) ≠ 0) (z w : Fin k → F)
    (h : ∀ m : ℕ, 1 ≤ m → m ≤ k → ∑ i, z i ^ m = ∑ i, w i ^ m) :
    (Finset.univ.val.map z) = (Finset.univ.val.map w) := by
  classical
  -- elementary symmetric functions agree
  have he : ∀ m, m ≤ k → (Finset.univ.val.map z).esymm m = (Finset.univ.val.map w).esymm m := by
    intro m
    induction m using Nat.strong_induction_on with
    | _ m ih =>
      intro hm
      rcases Nat.eq_zero_or_pos m with h0 | hpos
      · subst h0; simp [Multiset.esymm]
      have hN := MvPolynomial.mul_esymm_eq_sum (σ := Fin k) (R := F) m
      have hz := congrArg (MvPolynomial.aeval z) hN
      have hw := congrArg (MvPolynomial.aeval w) hN
      simp only [map_mul, map_natCast, map_sum, map_pow, map_neg, map_one,
        MvPolynomial.aeval_esymm_eq_multiset_esymm] at hz hw
      have hps : ∀ (f : Fin k → F) (n : ℕ),
          MvPolynomial.aeval f (MvPolynomial.psum (Fin k) F n) = ∑ i, f i ^ n := by
        intro f n; simp [MvPolynomial.psum]
      simp only [hps] at hz hw
      have hrhs : ∑ a ∈ antidiagonal m with a.1 < m,
            (-1 : F) ^ a.1 * (Finset.univ.val.map z).esymm a.1 * ∑ i, z i ^ a.2 =
          ∑ a ∈ antidiagonal m with a.1 < m,
            (-1 : F) ^ a.1 * (Finset.univ.val.map w).esymm a.1 * ∑ i, w i ^ a.2 := by
        apply Finset.sum_congr rfl
        intro a ha
        rw [Finset.mem_filter, Finset.mem_antidiagonal] at ha
        rw [ih a.1 ha.2 (by omega), h a.2 (by omega) (by omega)]
      rw [hrhs, ← hw] at hz
      exact mul_left_cancel₀ (hchar m hpos hm) hz
  -- the monic polynomials with these roots agree
  set sz := Finset.univ.val.map z
  set sw := Finset.univ.val.map w
  have hcz : Multiset.card sz = k := by simp [sz]
  have hcw : Multiset.card sw = k := by simp [sw]
  have hpoly : (sz.map fun a => Polynomial.X - Polynomial.C a).prod =
      (sw.map fun a => Polynomial.X - Polynomial.C a).prod := by
    ext j
    rcases le_or_gt j k with hj | hj
    · rw [Multiset.prod_X_sub_C_coeff sz (by rw [hcz]; exact hj),
        Multiset.prod_X_sub_C_coeff sw (by rw [hcw]; exact hj), hcz, hcw,
        he (k - j) (by omega)]
    · rw [Polynomial.coeff_eq_zero_of_natDegree_lt, Polynomial.coeff_eq_zero_of_natDegree_lt]
      · rw [Polynomial.natDegree_multiset_prod_X_sub_C_eq_card, hcw]; exact hj
      · rw [Polynomial.natDegree_multiset_prod_X_sub_C_eq_card, hcz]; exact hj
  have := congrArg Polynomial.roots hpoly
  rwa [Polynomial.roots_multiset_prod_X_sub_C, Polynomial.roots_multiset_prod_X_sub_C] at this

/-- at most `k!` injective residue tuples with prescribed power sums -/
theorem newton_card (p : ℕ) [Fact p.Prime] (k : ℕ) (hk : k < p) (μ : Fin k → ZMod p) :
    ((Finset.univ : Finset (Fin k → ZMod p)).filter (fun z => Function.Injective z ∧
      ∀ j : Fin k, ∑ i, z i ^ ((j : ℕ) + 1) = μ j)).card ≤ k.factorial := by
  classical
  set S := (Finset.univ : Finset (Fin k → ZMod p)).filter (fun z => Function.Injective z ∧
      ∀ j : Fin k, ∑ i, z i ^ ((j : ℕ) + 1) = μ j)
  rcases S.eq_empty_or_nonempty with hS | ⟨z0, hz0⟩
  · rw [hS]; simp
  have hchar : ∀ m : ℕ, 1 ≤ m → m ≤ k → (m : ZMod p) ≠ 0 := by
    intro m hm1 hmk
    rw [Ne, ZMod.natCast_eq_zero_iff]
    intro hd
    have := Nat.le_of_dvd (by omega) hd
    omega
  have hz0' := (Finset.mem_filter.mp hz0).2
  have hsub : S ⊆ (Finset.univ : Finset (Equiv.Perm (Fin k))).image (fun σ : Equiv.Perm (Fin k) => z0 ∘ ⇑σ) := by
    intro z hz
    have hz' := (Finset.mem_filter.mp hz).2
    have hms : Finset.univ.val.map z = Finset.univ.val.map z0 := by
      apply multiset_eq_of_psum k hchar
      intro m hm1 hmk
      have a := hz'.2 ⟨m - 1, by omega⟩
      have b := hz0'.2 ⟨m - 1, by omega⟩
      simp only [show m - 1 + 1 = m by omega] at a b
      rw [a, b]
    have hrange : Set.range z = Set.range z0 := by
      ext v
      have := congrArg (fun s => v ∈ s) hms
      simp only [Multiset.mem_map, Finset.mem_val, Finset.mem_univ, true_and,
        eq_iff_iff] at this
      simpa [Set.mem_range] using this
    let σ : Equiv.Perm (Fin k) :=
      (Equiv.ofInjective z hz'.1).trans
        ((Set.equivOfEq hrange).trans (Equiv.ofInjective z0 hz0'.1).symm)
    rw [Finset.mem_image]
    refine ⟨σ, Finset.mem_univ _, ?_⟩
    ext i
    simp only [Function.comp_apply, σ, Equiv.trans_apply]
    have := Equiv.apply_ofInjective_symm hz0'.1
      ((Set.equivOfEq hrange) ((Equiv.ofInjective z hz'.1) i))
    rw [this]
    simp
  calc S.card ≤ ((Finset.univ : Finset (Equiv.Perm (Fin k))).image (fun σ : Equiv.Perm (Fin k) => z0 ∘ ⇑σ)).card :=
        card_le_card hsub
    _ ≤ (Finset.univ : Finset (Equiv.Perm (Fin k))).card := card_image_le
    _ = k.factorial := by rw [Finset.card_univ, Fintype.card_perm, Fintype.card_fin]

/-! ## the congruence counting lemma -/

lemma sum_fin_reflect (k : ℕ) : ∑ j : Fin k, (k - (j + 1)) = k * (k - 1) / 2 := by
  rw [Fin.sum_univ_eq_sum_range (fun j => k - (j + 1)) k]
  have h1 : ∑ j ∈ range k, (k - (j + 1)) = ∑ j ∈ range k, j := by
    rw [← Finset.sum_range_reflect]
    apply Finset.sum_congr rfl; intro j hj
    have := mem_range.mp hj; omega
  rw [h1, Finset.sum_range_id]

theorem cong_count (p : ℕ) [hp : Fact p.Prime] (k : ℕ) (hk : k < p) (A : Finset ℤ)
    (hA : ∀ a ∈ A, ∀ b ∈ A, |a - b| < (p : ℤ) ^ k) (c : ℤ) (l : Fin k → ℤ) :
    ((tup k A).filter (fun x => (∀ i i', i ≠ i' → ¬ ((p : ℤ) ∣ x i - x i')) ∧
      ∀ j : Fin k, (p : ℤ) ^ ((j : ℕ) + 1) ∣ psv k (fun i => x i - c) j - l j)).card ≤
      k.factorial * p ^ (k * (k - 1) / 2) := by
  classical
  set S := (tup k A).filter (fun x => (∀ i i', i ≠ i' → ¬ ((p : ℤ) ∣ x i - x i')) ∧
      ∀ j : Fin k, (p : ℤ) ^ ((j : ℕ) + 1) ∣ psv k (fun i => x i - c) j - l j)
  let ρ : (Fin k → ℤ) → (Fin k → ZMod p) := fun x i => ((x i - c : ℤ) : ZMod p)
  set μ : Fin k → ZMod p := fun j => (l j : ZMod p)
  have hpz : (0 : ℤ) < p := by exact_mod_cast hp.out.pos
  -- the image of the reduction lies in the Newton set
  have himg : S.image ρ ⊆ (Finset.univ : Finset (Fin k → ZMod p)).filter (fun z =>
      Function.Injective z ∧ ∀ j : Fin k, ∑ i, z i ^ ((j : ℕ) + 1) = μ j) := by
    intro z hz
    rw [Finset.mem_image] at hz
    obtain ⟨x, hx, rfl⟩ := hz
    have hx' := (Finset.mem_filter.mp hx).2
    rw [Finset.mem_filter]
    refine ⟨Finset.mem_univ _, ?_, ?_⟩
    · intro i i' h
      by_contra hne
      apply hx'.1 i i' hne
      simp only [ρ] at h
      rw [ZMod.intCast_eq_intCast_iff_dvd_sub] at h
      have : (p : ℤ) ∣ -((x i' - c) - (x i - c)) := dvd_neg.mpr h
      have e : -((x i' - c) - (x i - c)) = x i - x i' := by ring
      rwa [e] at this
    · intro j
      have hd : (p : ℤ) ∣ psv k (fun i => x i - c) j - l j :=
        (dvd_pow_self (p : ℤ) (Nat.succ_ne_zero _)).trans (hx'.2 j)
      have := (ZMod.intCast_eq_intCast_iff_dvd_sub (l j) (psv k (fun i => x i - c) j) p).mpr
        hd
      simp only [μ, ρ]
      rw [this]
      simp [psv]
  have hcard_img : (S.image ρ).card ≤ k.factorial :=
    (card_le_card himg).trans (newton_card p k hk μ)
  -- each fibre injects into a box of size p^{k(k-1)/2}
  let T : Finset (Fin k → ℤ) :=
    Fintype.piFinset fun j : Fin k => Finset.Ico (0 : ℤ) ((p : ℤ) ^ (k - ((j : ℕ) + 1)))
  have hT : T.card = p ^ (k * (k - 1) / 2) := by
    simp only [T, Fintype.card_piFinset, Int.card_Ico, sub_zero]
    have : ∀ j : Fin k, (((p : ℤ) ^ (k - ((j : ℕ) + 1))).toNat) = p ^ (k - ((j : ℕ) + 1)) := by
      intro j; rw [← Nat.cast_pow, Int.toNat_natCast]
    simp_rw [this]
    rw [Finset.prod_pow_eq_pow_sum, sum_fin_reflect]
  let Φ : (Fin k → ℤ) → (Fin k → ℤ) := fun x j =>
    ((psv k (fun i => x i - c) j - l j) / (p : ℤ) ^ ((j : ℕ) + 1)) %
      ((p : ℤ) ^ (k - ((j : ℕ) + 1)))
  have hfib : ∀ z ∈ S.image ρ, (S.filter fun x => ρ x = z).card ≤ p ^ (k * (k - 1) / 2) := by
    intro z _
    rw [← hT]
    apply Finset.card_le_card_of_injOn Φ
    · intro x _
      simp only [T, Finset.mem_coe, Fintype.mem_piFinset, Finset.mem_Ico]
      intro j
      have hpos : (0 : ℤ) < (p : ℤ) ^ (k - ((j : ℕ) + 1)) := pow_pos hpz _
      exact ⟨Int.emod_nonneg _ hpos.ne', Int.emod_lt_of_pos _ hpos⟩
    · intro x hx y hy hxy
      simp only [coe_filter, Set.mem_setOf_eq] at hx hy
      have hxS := (Finset.mem_filter.mp hx.1).2
      have hyS := (Finset.mem_filter.mp hy.1).2
      have hxA := Fintype.mem_piFinset.mp (Finset.mem_filter.mp hx.1).1
      have hyA := Fintype.mem_piFinset.mp (Finset.mem_filter.mp hy.1).1
      -- congruence mod p^k of the shifted power sums
      have hsum : ∀ j : Fin k, (p : ℤ) ^ k ∣
          psv k (fun i => y i - c) j - psv k (fun i => x i - c) j := by
        intro j
        obtain ⟨qx, hqx⟩ := hxS.2 j
        obtain ⟨qy, hqy⟩ := hyS.2 j
        have hpj : (p : ℤ) ^ ((j : ℕ) + 1) ≠ 0 := pow_ne_zero _ hpz.ne'
        have e := congrFun hxy j
        simp only [Φ] at e
        rw [hqx, hqy, Int.mul_ediv_cancel_left _ hpj, Int.mul_ediv_cancel_left _ hpj] at e
        have hm : (p : ℤ) ^ (k - ((j : ℕ) + 1)) ∣ qy - qx :=
          Int.ModEq.dvd e
        have : psv k (fun i => y i - c) j - psv k (fun i => x i - c) j =
            (p : ℤ) ^ ((j : ℕ) + 1) * (qy - qx) := by linear_combination hqy - hqx
        rw [this]
        have hk' : (p : ℤ) ^ k = (p : ℤ) ^ ((j : ℕ) + 1) * (p : ℤ) ^ (k - ((j : ℕ) + 1)) := by
          rw [← pow_add]; congr 1; have := j.isLt; omega
        rw [hk']
        exact mul_dvd_mul_left _ hm
      have hdist : ∀ i i', i ≠ i' → ¬ ((p : ℤ) ∣ (x i - c) - (x i' - c)) := by
        intro i i' h; rw [show (x i - c) - (x i' - c) = x i - x i' by ring]; exact hxS.1 i i' h
      have hmodp : ∀ i, (p : ℤ) ∣ (y i - c) - (x i - c) := by
        intro i
        have := congrFun (hx.2.trans hy.2.symm) i
        simp only [ρ] at this
        rw [ZMod.intCast_eq_intCast_iff_dvd_sub] at this
        exact this
      have hH := hensel_inj p k hk (fun i => x i - c) (fun i => y i - c) hdist hsum hmodp
      ext i
      have h1 := hH i
      rw [show (y i - c) - (x i - c) = y i - x i by ring] at h1
      have h2 : |y i - x i| < (p : ℤ) ^ k := hA _ (hyA i) _ (hxA i)
      have := Int.eq_zero_of_abs_lt_dvd h1 h2
      linarith
  calc S.card = ∑ z ∈ S.image ρ, (S.filter fun x => ρ x = z).card :=
        Finset.card_eq_sum_card_image ρ S
    _ ≤ ∑ z ∈ S.image ρ, p ^ (k * (k - 1) / 2) := Finset.sum_le_sum hfib
    _ = (S.image ρ).card * p ^ (k * (k - 1) / 2) := by rw [Finset.sum_const, smul_eq_mul]
    _ ≤ k.factorial * p ^ (k * (k - 1) / 2) := Nat.mul_le_mul_right _ hcard_img

end GoldB
