import PaperB.FixedQ.SignedForbiddenTorvenQuarterSquareFarTailTsum
import PaperB.FixedQ.SignedForbiddenTavrenGlobalExteriorSignedHeightSum
import PaperB.FixedQ.SignedForbiddenMainHeightOne
import PaperB.FixedQ.PureHeightTerminal

open scoped BigOperators Classical
namespace PaperB.FixedQ

/-- Literal proper-Boolean analogue of the already paid natural full-Boolean source.
    The coprimality filter retains the exact reduced source D. -/
noncomputable def torvenSourceProperNaturalTerm
    (q A H D m : ℕ) : ℝ :=
  if 1 < m ∧ Squarefree m ∧ m.Coprime (H * (6 * q) * D) then
    ordinaryBooleanCoreTerm q A H m.primeFactors
  else 0

lemma torven_ordinaryBooleanCoreTerm_height_one_zero
    (q A : ℕ) (S : Finset ℕ) :
    ordinaryBooleanCoreTerm q A 1 S = 0 := by
  have hcore : ordinaryBooleanInteriorDiscrepancy (fixedQLowWeight q A 1) 1 S = 0 := by
    unfold ordinaryBooleanInteriorDiscrepancy
    simp [fixedProductPartitionDiscrepancy_height_one]
  simp [ordinaryBooleanCoreTerm, hcore, Set.indicator]

lemma torven_sourceProperNaturalTerm_height_one_zero
    (q A D m : ℕ) : torvenSourceProperNaturalTerm q A 1 D m = 0 := by
  simp [torvenSourceProperNaturalTerm, torven_ordinaryBooleanCoreTerm_height_one_zero]

lemma torven_abs_sourceProperNaturalTerm_quad_far_le_shiu
    {q A H D m : ℕ}
    (hH : 2 ≤ H) (h2 : ¬ 2 ∣ q → 2 ∣ H)
    (hgt : H ^ 2 < 4 * m) :
    |torvenSourceProperNaturalTerm q A H D m| ≤
      6 * (H : ℝ) * (fixedQShiuWeight q m / (m : ℝ)) := by
  by_cases hc : 1 < m ∧ Squarefree m ∧ m.Coprime (H * (6 * q) * D)
  · have hprod : primeSetProduct m.primeFactors = m :=
      Nat.prod_primeFactors_of_squarefree hc.2.1
    rw [torvenSourceProperNaturalTerm, if_pos hc]
    simpa [hprod] using
      (torven_abs_ordinaryBooleanCoreTerm_quad_far_le_shiu
        (q := q) (A := A) (H := H) h2 hH m.primeFactors
        (by simpa [hprod] using hgt))
  · rw [torvenSourceProperNaturalTerm, if_neg hc, abs_zero]
    exact mul_nonneg
      (mul_nonneg (by norm_num) (Nat.cast_nonneg H))
      (div_nonneg (fixedQShiuWeight_nonneg q m) (Nat.cast_nonneg m))

#print axioms torven_ordinaryBooleanCoreTerm_height_one_zero
#print axioms torven_abs_sourceProperNaturalTerm_quad_far_le_shiu

end PaperB.FixedQ
