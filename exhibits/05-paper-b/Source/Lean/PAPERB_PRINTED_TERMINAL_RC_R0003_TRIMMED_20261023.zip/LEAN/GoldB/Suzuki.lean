import GoldB.Final
import GoldB.QuillonSelectedOrders
import GoldB.QuillonDerivativeWindow

/-!
# GoldB.Suzuki — the shifted reciprocal phase over arbitrary sharp clips

Instantiates `karatsuba_lemma` with `(c0,c1,c2,c3) = (1/39, 25/26, 599/624, 1/4)` and the
certified scratch facts R0007 (selected orders), R0010 (top derivative), R0015 (normalized
derivative) and R0016 (selected window), for `f(x) = Y/(x+ϑ)` over `Finset.Ioc N U`.

`shiftedExpMode`/`shiftedModeSum` below are verbatim copies of the production definitions in
`PaperB/Gate3/AuvrenClassicalTransfer.lean` (namespace `OrielUpper`), restated here because
that module's imports are not in the archive.
-/

open Finset

namespace GoldB.Iface

noncomputable def shiftedExpMode (j : ℕ) (X ϑ γ : ℝ) (m : ℕ) : ℂ :=
  Complex.exp (2 * Real.pi * Complex.I *
    ((j : ℂ) * (((X / ((m : ℝ) + ϑ) + γ) : ℝ) : ℂ)))

noncomputable def shiftedModeSum (j : ℕ) (X ϑ γ : ℝ) (N U : ℕ) : ℂ :=
  ∑ m ∈ Finset.Ioc N U, shiftedExpMode j X ϑ γ m

/-- verbatim `OrielUpper.ShiftedSuzukiCore` -/
def ShiftedSuzukiCore : Prop :=
  ∃ c C : ℝ, 0 < c ∧ 0 ≤ C ∧
    ∀ Y : ℝ, 2 ≤ Y → ∀ N : ℕ, 1 ≤ N →
    ∀ ϑ : ℝ, 0 ≤ ϑ → ϑ ≤ 1 →
    ∀ U : ℕ, U ≤ 2 * N →
      ‖shiftedModeSum 1 Y ϑ 0 N U‖ ≤
        C * ((N : ℝ) * Real.exp
          (-(c * Real.log (N : ℝ)^3 / Real.log Y^2)) +
          (N : ℝ)^2 / Y)

/-- the complementary low-`Y` (Kusmin–Landau) branch, as an exact Prop -/
def ShiftedSuzukiLowY : Prop :=
  ∃ c C : ℝ, 0 < c ∧ 0 ≤ C ∧
    ∀ Y : ℝ, 2 ≤ Y → ∀ N : ℕ, 4096 ≤ N →
    ∀ ϑ : ℝ, 0 ≤ ϑ → ϑ ≤ 1 →
    ∀ U : ℕ, U ≤ 2 * N →
      Real.log Y < (3 / 2) * (Real.log (N : ℝ) + Real.log 2) →
      ‖shiftedModeSum 1 Y ϑ 0 N U‖ ≤
        C * ((N : ℝ) * Real.exp
          (-(c * Real.log (N : ℝ)^3 / Real.log Y^2)) +
          (N : ℝ)^2 / Y)

lemma shiftedModeSum_eq (Y ϑ : ℝ) (N U : ℕ) :
    shiftedModeSum 1 Y ϑ 0 N U =
      ∑ n ∈ Finset.Ioc (N : ℤ) (U : ℤ), GoldB.ee (Y / ((n : ℝ) + ϑ)) := by
  unfold shiftedModeSum shiftedExpMode GoldB.ee
  apply Finset.sum_nbij' (fun m : ℕ => (m : ℤ)) (fun n : ℤ => n.toNat)
  · intro m hm; simp only [Finset.mem_coe, Finset.mem_Ioc] at hm ⊢; omega
  · intro n hn; simp only [Finset.mem_coe, Finset.mem_Ioc] at hn ⊢; omega
  · intro m _; simp
  · intro n hn; simp only [Finset.mem_coe, Finset.mem_Ioc] at hn; simp; omega
  · intro m _; simp

lemma norm_shiftedModeSum_le (Y ϑ : ℝ) (N U : ℕ) (hU : U ≤ 2 * N) :
    ‖shiftedModeSum 1 Y ϑ 0 N U‖ ≤ N := by
  rw [shiftedModeSum_eq]
  calc ‖∑ n ∈ Finset.Ioc (N : ℤ) (U : ℤ), GoldB.ee (Y / ((n : ℝ) + ϑ))‖
      ≤ ∑ n ∈ Finset.Ioc (N : ℤ) (U : ℤ), ‖GoldB.ee (Y / ((n : ℝ) + ϑ))‖ := norm_sum_le _ _
    _ = ((Finset.Ioc (N : ℤ) (U : ℤ)).card : ℝ) := by simp
    _ ≤ N := by
        rw [Int.card_Ioc]
        have : ((U : ℤ) - N).toNat ≤ N := by omega
        exact_mod_cast this

end GoldB.Iface

namespace GoldB

open GoldB.Iface OrielUpper

/-- the Karatsuba constants for the shifted reciprocal phase -/
theorem shifted_highY_bound :
    ∃ c C : ℝ, 0 < c ∧ 0 ≤ C ∧
      ∀ Y : ℝ, 2 ≤ Y → ∀ N : ℕ, 4096 ≤ N → ∀ ϑ : ℝ, 0 ≤ ϑ → ϑ ≤ 1 →
      ∀ U : ℕ, U ≤ 2 * N →
        (3 / 2) * (Real.log (N : ℝ) + Real.log 2) ≤ Real.log Y →
        ‖shiftedModeSum 1 Y ϑ 0 N U‖ ≤
          C * ((N : ℝ) * Real.exp (-(c * Real.log (N : ℝ) ^ 3 / Real.log Y ^ 2))) := by
  obtain ⟨γ, C, hγ, hγ1, hC, hK⟩ := karatsuba_lemma (1 / 39) (25 / 26) (599 / 624) (1 / 4)
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  refine ⟨γ / 676, C, by positivity, hC, ?_⟩
  intro Y hY N hN ϑ hϑ0 hϑ1 U hU hreg
  set P : ℝ := (N : ℝ)
  have hP : (4096 : ℝ) ≤ P := by simp only [P]; exact_mod_cast hN
  have hP0 : 0 < P := by linarith
  have hP1 : 1 < P := by linarith
  have hY0 : 0 < Y := by linarith
  have hlP : 0 < Real.log P := Real.log_pos hP1
  set t := Real.log Y / Real.log P
  have hl2 : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have ht : (3 / 2 : ℝ) ≤ t := by
    simp only [t]; rw [le_div_iff₀ hlP]; nlinarith
  set k := veylanSuzukiOrder t
  set Js := veylanSuzukiSelected t
  obtain ⟨hcnt1, hcnt2, hcnt3⟩ := veylan_suzuki_selected_count t ht
  have hk39 : 39 ≤ k := by
    simp only [k, veylanSuzukiOrder]
    apply Nat.le_floor; push_cast; linarith
  have hk : 1 ≤ k := by omega
  set f : ℝ → ℝ := fun z => Y / (z + ϑ)
  -- the hypotheses of the Karatsuba lemma
  have hsmooth : ∀ x ∈ Set.Icc P (P + P), ContDiffAt ℝ (k + 1) f x := by
    intro x hx
    have hx0 : x + ϑ ≠ 0 := by have := hx.1; linarith
    exact contDiffAt_const.div (contDiffAt_id.add contDiffAt_const) hx0
  have hnorm : ∀ x ∈ Set.Icc P (P + P), ∀ j : ℕ,
      |iteratedDeriv j f x| / j.factorial = Y / (x + ϑ) ^ (j + 1) := by
    intro x hx j
    have hx0 : 0 < x + ϑ := by have := hx.1; linarith
    have := veylan_suzuki_normalized_derivative Y ϑ x j hY0.le hx0
    rw [Real.norm_eq_abs, abs_div, abs_of_pos (by exact_mod_cast Nat.factorial_pos j :
      (0 : ℝ) < j.factorial)] at this
    exact this
  have hA : ∀ x ∈ Set.Icc P (P + P),
      |iteratedDeriv (k + 1) f x| / (k + 1).factorial ≤ P ^ (-((25 / 26 : ℝ) * (k + 1))) := by
    intro x hx
    rw [hnorm x hx]
    have := veylan_suzuki_top_derivative_upper P x ϑ Y k hP1 hx.1 hϑ0 hY0 rfl
    simpa [pow_succ, add_assoc] using this
  have hJs : Js ⊆ Finset.Icc 1 k := by
    intro j hj
    obtain ⟨h1, _, _, h4⟩ := veylan_suzuki_selected_order t ht j hj
    exact Finset.mem_Icc.mpr ⟨h1, h4⟩
  have hJc : (1 / 39 : ℝ) * k ≤ Js.card := by
    have := hcnt2; simp only [k] at this ⊢; linarith
  have hB : ∀ j ∈ Js, ∀ x ∈ Set.Icc P (P + P),
      P ^ (-((599 / 624 : ℝ) * j)) ≤ |iteratedDeriv j f x| / j.factorial ∧
        |iteratedDeriv j f x| / j.factorial ≤ P ^ (-((1 / 4 : ℝ) * j)) := by
    intro j hj x hx
    have hwin := veylan_suzuki_literal_selected_derivative_window P x ϑ Y j hP hx.1
      (by linarith [hx.2]) hϑ0 hϑ1 hY0 hreg hj
    have e : |iteratedDeriv j f x| / j.factorial =
        ‖iteratedDeriv j (fun z : ℝ => Y / (z + ϑ)) x / (j.factorial : ℝ)‖ := by
      rw [Real.norm_eq_abs, abs_div,
        abs_of_pos (by exact_mod_cast Nat.factorial_pos j : (0 : ℝ) < j.factorial)]
    rw [e]
    refine ⟨?_, hwin.2⟩
    have := hwin.1
    convert this using 2; ring
  -- apply the lemma with X = N, P = N, P1 = U - N
  have hmain := hK k hk P P hP1.le f hsmooth hA Js hJs hJc hB ((U : ℝ) - N) (by
    have : (U : ℝ) ≤ 2 * N := by exact_mod_cast hU
    simp only [P]; linarith)
  have hfl1 : ⌊P⌋ = (N : ℤ) := by simp [P]
  have hfl2 : ⌊P + ((U : ℝ) - N)⌋ = (U : ℤ) := by simp [P]
  rw [hfl1, hfl2] at hmain
  rw [shiftedModeSum_eq]
  refine hmain.trans ?_
  -- compare exponents
  apply mul_le_mul_of_nonneg_left _ hC
  have hkt : (k : ℝ) ≤ 26 * t := Nat.floor_le (by positivity)
  have hkpos : (0 : ℝ) < k := by exact_mod_cast (by omega : 0 < k)
  have hlY : 0 < Real.log Y := by
    have := ht; simp only [t] at this; rw [le_div_iff₀ hlP] at this; nlinarith
  have hexp : P ^ (1 - γ / (k : ℝ) ^ 2) = P * Real.exp (-(γ / (k : ℝ) ^ 2 * Real.log P)) := by
    rw [Real.rpow_def_of_pos hP0, sub_eq_add_neg, mul_add, Real.exp_add, mul_one,
      Real.exp_log hP0]
    ring_nf
  rw [hexp]
  apply mul_le_mul_of_nonneg_left _ hP0.le
  apply Real.exp_le_exp.mpr
  rw [neg_le_neg_iff]
  -- γ log³ P / (676 log² Y) ≤ γ log P / k²
  have hk2 : (k : ℝ) ^ 2 ≤ 676 * Real.log Y ^ 2 / Real.log P ^ 2 := by
    have : (k : ℝ) ≤ 26 * (Real.log Y / Real.log P) := hkt
    have h2 : (k : ℝ) ^ 2 ≤ (26 * (Real.log Y / Real.log P)) ^ 2 :=
      pow_le_pow_left₀ hkpos.le this 2
    calc (k : ℝ) ^ 2 ≤ (26 * (Real.log Y / Real.log P)) ^ 2 := h2
      _ = 676 * Real.log Y ^ 2 / Real.log P ^ 2 := by field_simp; ring
  rw [div_le_iff₀ (by positivity)]
  rw [le_div_iff₀ (by positivity)] at hk2
  have : γ / 676 * Real.log P ^ 3 / Real.log Y ^ 2 * Real.log Y ^ 2 =
      γ / 676 * Real.log P ^ 3 := by field_simp
  -- compatibility repair: `div_le_iff₀` now yields `a ≤ b * c` directly
  calc γ / 676 * Real.log P ^ 3
      ≤ γ / (k : ℝ) ^ 2 * Real.log P * Real.log Y ^ 2 := by
        rw [show γ / (k : ℝ) ^ 2 * Real.log P * Real.log Y ^ 2 =
            γ * Real.log P * Real.log Y ^ 2 / (k : ℝ) ^ 2 by ring, le_div_iff₀ (by positivity)]
        have hγ0 : 0 ≤ γ := hγ.le
        nlinarith [mul_le_mul_of_nonneg_left hk2 (by positivity : (0 : ℝ) ≤ γ * Real.log P)]

/-- **Gold B shifted corollary**: the high-`Y` and small-`N` cases of `ShiftedSuzukiCore`,
over the literal sharp clips `Finset.Ioc N U`, all `ϑ ∈ [0,1]`, constants uniform. -/
theorem shifted_suzuki_highY :
    ∃ c C : ℝ, 0 < c ∧ 0 ≤ C ∧
      ∀ Y : ℝ, 2 ≤ Y → ∀ N : ℕ, 1 ≤ N → ∀ ϑ : ℝ, 0 ≤ ϑ → ϑ ≤ 1 →
      ∀ U : ℕ, U ≤ 2 * N →
        (N < 4096 ∨ (3 / 2) * (Real.log (N : ℝ) + Real.log 2) ≤ Real.log Y) →
        ‖shiftedModeSum 1 Y ϑ 0 N U‖ ≤
          C * ((N : ℝ) * Real.exp (-(c * Real.log (N : ℝ) ^ 3 / Real.log Y ^ 2)) +
            (N : ℝ) ^ 2 / Y) := by
  obtain ⟨c, C, hc, hC, hH⟩ := shifted_highY_bound
  set c' := min c 1
  set E0 : ℝ := c' * Real.log 4096 ^ 3 / Real.log 2 ^ 2
  refine ⟨c', max C (Real.exp E0), lt_min hc one_pos, le_max_of_le_left hC, ?_⟩
  intro Y hY N hN ϑ hϑ0 hϑ1 U hU hcase
  have hNr : (1 : ℝ) ≤ N := by exact_mod_cast hN
  have hY2 : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hlY : Real.log 2 ≤ Real.log Y := Real.log_le_log (by norm_num) hY
  have hlN : 0 ≤ Real.log (N : ℝ) := Real.log_nonneg hNr
  have hNY : 0 ≤ (N : ℝ) ^ 2 / Y := by positivity
  have hexpmono : Real.exp (-(c * Real.log (N : ℝ) ^ 3 / Real.log Y ^ 2)) ≤
      Real.exp (-(c' * Real.log (N : ℝ) ^ 3 / Real.log Y ^ 2)) := by
    apply Real.exp_le_exp.mpr; rw [neg_le_neg_iff]
    apply div_le_div_of_nonneg_right _ (by positivity)
    exact mul_le_mul_of_nonneg_right (min_le_left _ _) (by positivity)
  rcases hcase with hsmall | hbig
  · -- trivial bound for small N
    have hlN2 : Real.log (N : ℝ) ≤ Real.log 4096 :=
      Real.log_le_log (by positivity) (by exact_mod_cast hsmall.le)
    have hE : c' * Real.log (N : ℝ) ^ 3 / Real.log Y ^ 2 ≤ E0 := by
      simp only [E0]
      have hc'0 : 0 ≤ c' := le_min hc.le zero_le_one
      calc c' * Real.log (N : ℝ) ^ 3 / Real.log Y ^ 2
          ≤ c' * Real.log 4096 ^ 3 / Real.log Y ^ 2 := by
            gcongr
        _ ≤ c' * Real.log 4096 ^ 3 / Real.log 2 ^ 2 := by
            apply div_le_div_of_nonneg_left (by positivity) (by positivity)
            exact pow_le_pow_left₀ hY2.le hlY 2
    have h1 : (1 : ℝ) ≤ Real.exp E0 * Real.exp (-(c' * Real.log (N : ℝ) ^ 3 / Real.log Y ^ 2)) := by
      rw [← Real.exp_add]; exact Real.one_le_exp (by linarith)
    calc ‖shiftedModeSum 1 Y ϑ 0 N U‖ ≤ N := norm_shiftedModeSum_le Y ϑ N U hU
      _ ≤ Real.exp E0 * ((N : ℝ) * Real.exp (-(c' * Real.log (N : ℝ) ^ 3 / Real.log Y ^ 2))) := by
          nlinarith
      _ ≤ max C (Real.exp E0) * ((N : ℝ) * Real.exp (-(c' * Real.log (N : ℝ) ^ 3 /
            Real.log Y ^ 2)) + (N : ℝ) ^ 2 / Y) := by
          apply mul_le_mul (le_max_right _ _) (by linarith) (by positivity) (by positivity)
  · by_cases hN4 : 4096 ≤ N
    · calc ‖shiftedModeSum 1 Y ϑ 0 N U‖
          ≤ C * ((N : ℝ) * Real.exp (-(c * Real.log (N : ℝ) ^ 3 / Real.log Y ^ 2))) :=
            hH Y hY N hN4 ϑ hϑ0 hϑ1 U hU hbig
        _ ≤ max C (Real.exp E0) * ((N : ℝ) * Real.exp (-(c' * Real.log (N : ℝ) ^ 3 /
              Real.log Y ^ 2)) + (N : ℝ) ^ 2 / Y) := by
            apply mul_le_mul (le_max_left _ _) _ (by positivity) (by positivity)
            have := mul_le_mul_of_nonneg_left hexpmono (by positivity : (0 : ℝ) ≤ N)
            linarith
    · push_neg at hN4
      -- same as the small case
      have hlN2 : Real.log (N : ℝ) ≤ Real.log 4096 :=
        Real.log_le_log (by positivity) (by exact_mod_cast hN4.le)
      have hE : c' * Real.log (N : ℝ) ^ 3 / Real.log Y ^ 2 ≤ E0 := by
        simp only [E0]
        have hc'0 : 0 ≤ c' := le_min hc.le zero_le_one
        calc c' * Real.log (N : ℝ) ^ 3 / Real.log Y ^ 2
            ≤ c' * Real.log 4096 ^ 3 / Real.log Y ^ 2 := by gcongr
          _ ≤ c' * Real.log 4096 ^ 3 / Real.log 2 ^ 2 := by
              apply div_le_div_of_nonneg_left (by positivity) (by positivity)
              exact pow_le_pow_left₀ hY2.le hlY 2
      have h1 : (1 : ℝ) ≤ Real.exp E0 * Real.exp (-(c' * Real.log (N : ℝ) ^ 3 / Real.log Y ^ 2)) := by
        rw [← Real.exp_add]; exact Real.one_le_exp (by linarith)
      calc ‖shiftedModeSum 1 Y ϑ 0 N U‖ ≤ N := norm_shiftedModeSum_le Y ϑ N U hU
        _ ≤ Real.exp E0 * ((N : ℝ) * Real.exp (-(c' * Real.log (N : ℝ) ^ 3 / Real.log Y ^ 2))) := by
            nlinarith
        _ ≤ max C (Real.exp E0) * ((N : ℝ) * Real.exp (-(c' * Real.log (N : ℝ) ^ 3 /
              Real.log Y ^ 2)) + (N : ℝ) ^ 2 / Y) := by
            apply mul_le_mul (le_max_right _ _) (by linarith) (by positivity) (by positivity)

/-- **join**: the low-`Y` branch is the only remaining input for `ShiftedSuzukiCore`. -/
theorem shiftedSuzukiCore_of_lowY (hLow : ShiftedSuzukiLowY) : ShiftedSuzukiCore := by
  obtain ⟨c1, C1, hc1, hC1, hH⟩ := shifted_suzuki_highY
  obtain ⟨c2, C2, hc2, hC2, hL⟩ := hLow
  refine ⟨min c1 c2, C1 + C2, lt_min hc1 hc2, by positivity, ?_⟩
  intro Y hY N hN ϑ hϑ0 hϑ1 U hU
  have hNr : (1 : ℝ) ≤ N := by exact_mod_cast hN
  have hNY : 0 ≤ (N : ℝ) ^ 2 / Y := by
    have hY0' : (0 : ℝ) < Y := by linarith
    positivity
  set R := fun c : ℝ => (N : ℝ) * Real.exp (-(c * Real.log (N : ℝ) ^ 3 / Real.log Y ^ 2)) +
    (N : ℝ) ^ 2 / Y
  have hmono : ∀ c, min c1 c2 ≤ c → R c ≤ R (min c1 c2) := by
    intro c hc
    simp only [R]
    have : Real.exp (-(c * Real.log (N : ℝ) ^ 3 / Real.log Y ^ 2)) ≤
        Real.exp (-(min c1 c2 * Real.log (N : ℝ) ^ 3 / Real.log Y ^ 2)) := by
      apply Real.exp_le_exp.mpr; rw [neg_le_neg_iff]
      apply div_le_div_of_nonneg_right _ (by positivity)
      exact mul_le_mul_of_nonneg_right hc (pow_nonneg (Real.log_nonneg hNr) 3)
    have := mul_le_mul_of_nonneg_left this (by positivity : (0 : ℝ) ≤ N)
    linarith
  have hR0 : ∀ c, 0 ≤ R c := fun c => by simp only [R]; positivity
  by_cases hcase : N < 4096 ∨ (3 / 2) * (Real.log (N : ℝ) + Real.log 2) ≤ Real.log Y
  · calc ‖shiftedModeSum 1 Y ϑ 0 N U‖ ≤ C1 * R c1 := hH Y hY N hN ϑ hϑ0 hϑ1 U hU hcase
      _ ≤ C1 * R (min c1 c2) := mul_le_mul_of_nonneg_left (hmono c1 (min_le_left _ _)) hC1
      _ ≤ (C1 + C2) * R (min c1 c2) := by
          have := hR0 (min c1 c2); nlinarith
  · push_neg at hcase
    calc ‖shiftedModeSum 1 Y ϑ 0 N U‖ ≤ C2 * R c2 :=
          hL Y hY N hcase.1 ϑ hϑ0 hϑ1 U hU hcase.2
      _ ≤ C2 * R (min c1 c2) := mul_le_mul_of_nonneg_left (hmono c2 (min_le_right _ _)) hC2
      _ ≤ (C1 + C2) * R (min c1 c2) := by
          have := hR0 (min c1 c2); nlinarith

end GoldB
