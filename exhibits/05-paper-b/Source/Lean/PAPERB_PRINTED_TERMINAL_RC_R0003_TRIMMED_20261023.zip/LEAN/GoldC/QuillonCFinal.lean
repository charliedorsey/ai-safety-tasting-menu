import GoldC.QuillonCEv
import GoldC.QuillonCCellApp

/-!
# Quillon CSC3 F8.9: the region-C cell (Parseval-W + VW + Rankin) is `≤ Λ^{−30}` per fixed `C`

* `CTerm_ev`: each `CTerm` on a dyadic piece `(a, b]` with `Lw_C ≤ a < b ≤ 2a ≤ …` is `≤ Λ^{−40}`.
  The chain is `CTerm_le`, then `Pα_le`, `Pβ_le`, `Vα_le`, `Vβ_le`, then `C_combine`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonCFinal

open GoldC.QuillonEv GoldC.QuillonSetup GoldC.QuillonLam GoldC.QuillonCEv GoldC.QuillonCEst
  GoldC.QuillonWContext

lemma Xp_le {h : ℕ} (hΛ : 1 ≤ Real.log h) : (Xp h : ℝ) ≤ 2 * (Real.log h) ^ (200 : ℝ) := by
  have h1 := Nat.ceil_lt_add_one (show 0 ≤ (Real.log h) ^ (200 : ℝ) by positivity)
  have : 1 ≤ (Real.log h) ^ (200 : ℝ) := Real.one_le_rpow hΛ (by norm_num)
  unfold Xp; linarith

lemma Tpp_bounds {h : ℕ} (hΛ : 1 ≤ Real.log h) :
    (Real.log h) ^ (100 : ℝ) ≤ (Tpp h : ℝ) ∧ (Tpp h : ℝ) ≤ 2 * (Real.log h) ^ (100 : ℝ) := by
  have h1 := Nat.ceil_lt_add_one (show 0 ≤ (Real.log h) ^ (100 : ℝ) by positivity)
  have : 1 ≤ (Real.log h) ^ (100 : ℝ) := Real.one_le_rpow hΛ (by norm_num)
  unfold Tpp; exact ⟨Nat.le_ceil _, by linarith⟩

lemma Tvp_bounds {h : ℕ} (hΛ : 1 ≤ Real.log h) :
    (Real.log h) ^ (600 : ℝ) ≤ (Tvp h : ℝ) ∧ (Tvp h : ℝ) ≤ 8 * (Real.log h) ^ (600 : ℝ) := by
  have hΛ0 : 0 < Real.log h := by linarith
  have h1 := Xp_ge (h := h) hΛ
  have h2 := Xp_le (h := h) hΛ
  have e : (Real.log h) ^ (600 : ℝ) = ((Real.log h) ^ (200 : ℝ)) ^ 3 := by
    rw [← Real.rpow_natCast, ← Real.rpow_mul hΛ0.le]; norm_num
  unfold Tvp; push_cast
  constructor
  · rw [e]; exact pow_le_pow_left₀ (by positivity) h1 3
  · calc (Xp h : ℝ) ^ 3 ≤ (2 * (Real.log h) ^ (200 : ℝ)) ^ 3 :=
          pow_le_pow_left₀ (by positivity) h2 3
      _ = 8 * (Real.log h) ^ (600 : ℝ) := by rw [e]; ring

/-- `1/Y ≤ 2 s^{−u₀}`. -/
lemma inv_Yp_le {δ : ℝ} (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) {s : ℕ} (hs : (2 : ℝ) ≤ (s : ℝ) ^ u0 δ) :
    (s : ℝ) ^ u0 δ / 2 ≤ (Yp δ s : ℝ) := by
  have := Nat.lt_floor_add_one ((s : ℝ) ^ u0 δ)
  unfold Yp; linarith


lemma two_le_rpow_16 (s : ℝ) (hs65 : 65536 ≤ s) : (2 : ℝ) ≤ s ^ (1 / 16 : ℝ) := by
  calc (2 : ℝ) = (65536 : ℝ) ^ (1 / 16 : ℝ) := by
        rw [show (65536 : ℝ) = 2 ^ (16 : ℝ) by norm_num, ← Real.rpow_mul (by norm_num)]; norm_num
    _ ≤ s ^ (1 / 16 : ℝ) := Real.rpow_le_rpow (by norm_num) hs65 (by norm_num)

lemma le_rpow_big (Λ : ℝ) (hΛ : 1 ≤ Λ) (k : ℝ) (hk : 1 ≤ k) : Λ ≤ Λ ^ k := by
  calc Λ = Λ ^ (1 : ℝ) := (Real.rpow_one _).symm
    _ ≤ Λ ^ k := Real.rpow_le_rpow_of_exponent_le hΛ hk

/-- basic large-`s` facts. -/
lemma s_facts (Λ s u c₀ : ℝ) (hΛ : 2 ≤ Λ) (hu0 : 0 < u) (hu1 : u ≤ 1 / 8) (hc₀ : c₀ ≤ 1)
    (hs16 : (2 : ℝ) ^ (16 / u) ≤ s)
    (hτ : (1 + Real.log s) ^ 2 * s ^ (-c₀) ≤ Λ ^ (-(3000 : ℝ))) :
    65536 ≤ s ∧ 1 ≤ s ∧ 2 ≤ s ^ u ∧ Λ ^ (3000 : ℝ) ≤ s := by
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  have hs1 : (1 : ℝ) ≤ s := le_trans (Real.one_le_rpow (by norm_num) (by positivity)) hs16
  have hs0 : 0 < s := by linarith
  have hsu2 : (2 : ℝ) ≤ s ^ u := by
    calc (2 : ℝ) ≤ ((2 : ℝ) ^ (16 / u)) ^ u := by
          rw [← Real.rpow_mul (by norm_num), div_mul_cancel₀ _ hu0.ne']
          calc (2 : ℝ) = 2 ^ (1 : ℝ) := (Real.rpow_one 2).symm
            _ ≤ 2 ^ (16 : ℝ) := Real.rpow_le_rpow_of_exponent_le (by norm_num) (by norm_num)
      _ ≤ s ^ u := Real.rpow_le_rpow (by positivity) hs16 hu0.le
  have hs65 : (65536 : ℝ) ≤ s := by
    calc (65536 : ℝ) = 2 ^ (16 : ℝ) := by norm_num
      _ ≤ 2 ^ (16 / u) := Real.rpow_le_rpow_of_exponent_le (by norm_num) (by
          rw [le_div_iff₀ hu0]; nlinarith)
      _ ≤ s := hs16
  have hsinv : s ^ (-(1 : ℝ)) ≤ Λ ^ (-(3000 : ℝ)) :=
    le_trans (le_trans (rpow_le_tau hs1 (by linarith)) (t_le_tau hs1)) hτ
  have hsΛ : Λ ^ (3000 : ℝ) ≤ s := by
    rw [Real.rpow_neg_one, Real.rpow_neg hΛ0.le] at hsinv
    exact (inv_le_inv₀ hs0 (by positivity)).1 hsinv
  exact ⟨hs65, hs1, hsu2, hsΛ⟩

lemma sb_fact (Λ s b ε : ℝ) (hΛ : 2 ≤ Λ) (hs : 0 < s) (hb : 0 < b)
    (hse : s ^ (-ε) ≤ Λ ^ (-(3001 : ℝ))) (hden : s ^ (1 + ε) / 2 ≤ b) :
    s / b ≤ Λ ^ (-(3000 : ℝ)) := by
  have hΛ0 : 0 < Λ := by linarith
  rw [div_le_iff₀ hb]
  have e : s = s ^ (-ε) * s ^ (1 + ε) := by rw [rp hs]; norm_num
  have h3001 : Λ ^ (-(3001 : ℝ)) * 2 ≤ Λ ^ (-(3000 : ℝ)) := by
    have e3 : Λ ^ (-(3000 : ℝ)) = Λ ^ (-(3001 : ℝ)) * Λ ^ (1 : ℝ) := by rw [rp hΛ0]; norm_num
    rw [e3, Real.rpow_one]
    have : 0 ≤ Λ ^ (-(3001 : ℝ)) := by positivity
    nlinarith
  have hq0 : 0 ≤ s ^ (-ε) := by positivity
  calc s = s ^ (-ε) * s ^ (1 + ε) := e
    _ ≤ s ^ (-ε) * (2 * b) := by apply mul_le_mul_of_nonneg_left _ hq0; linarith
    _ ≤ Λ ^ (-(3001 : ℝ)) * (2 * b) := mul_le_mul_of_nonneg_right hse (by positivity)
    _ = (Λ ^ (-(3001 : ℝ)) * 2) * b := by ring
    _ ≤ Λ ^ (-(3000 : ℝ)) * b := mul_le_mul_of_nonneg_right h3001 hb.le

lemma small_mul (Λ k : ℝ) (hΛ : 200000 ≤ Λ) (hk0 : 0 ≤ k) (hk : k ≤ 100) (x : ℝ)
    (hx : x ≤ Λ ^ (-(3000 : ℝ))) : k * x ≤ Λ ^ (-(100 : ℝ)) := by
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  have e3 : Λ ^ (-(100 : ℝ)) = Λ ^ (-(3000 : ℝ)) * Λ ^ (2900 : ℝ) := by rw [rp hΛ0]; norm_num
  have hb : (100 : ℝ) ≤ Λ ^ (2900 : ℝ) := le_trans (by linarith) (le_rpow_big Λ hΛ1 2900 (by norm_num))
  have hp : 0 ≤ Λ ^ (-(3000 : ℝ)) := by positivity
  calc k * x ≤ 100 * Λ ^ (-(3000 : ℝ)) := by
        rcases le_or_gt 0 x with hx0 | hx0
        · exact mul_le_mul hk hx hx0 (by norm_num)
        · nlinarith
    _ ≤ Λ ^ (2900 : ℝ) * Λ ^ (-(3000 : ℝ)) := mul_le_mul_of_nonneg_right hb hp
    _ = Λ ^ (-(100 : ℝ)) := by rw [e3]; ring

lemma Y_facts (Λ s u c₀ Yr : ℝ) (n : ℕ) (hΛ : 200000 ≤ Λ) (hu0 : 0 < u) (hu1 : u ≤ 1) (hc₀ : c₀ ≤ u / 3)
    (hs1 : 1 ≤ s) (hY : s ^ u / 2 ≤ Yr) (hsu2 : 2 ≤ s ^ u)
    (hτ : (1 + Real.log s) ^ 2 * s ^ (-c₀) ≤ Λ ^ (-(3000 : ℝ))) (h4n : (4 : ℝ) ^ n ≤ s ^ (c₀ / 2))
    (hc₀0 : 0 < c₀) :
    2 / Yr ≤ Λ ^ (-(100 : ℝ)) ∧ 12.5 / Yr ≤ Λ ^ (-(100 : ℝ)) ∧
      (Real.sqrt (2 / s) + 1 / Real.sqrt Yr) * 2 ^ n ≤ 3 * Λ ^ (-(100 : ℝ)) := by
  have hs0 : 0 < s := by linarith
  have hY0 : 0 < Yr := by linarith
  set τ := (1 + Real.log s) ^ 2 * s ^ (-c₀) with hτdef
  have hYinv : 1 / Yr ≤ 2 * τ := by
    have h1 : 1 / Yr ≤ 2 * s ^ (-u) := by
      rw [div_le_iff₀ hY0]
      have e : s ^ (-u) * s ^ u = 1 := by rw [rp hs0]; norm_num
      have : 0 ≤ s ^ (-u) := by positivity
      nlinarith
    have h2 : s ^ (-u) ≤ τ := le_trans (rpow_le_tau hs1 (by linarith)) (t_le_tau hs1)
    linarith
  have hτ0 : 0 ≤ τ := by positivity
  refine ⟨?_, ?_, ?_⟩
  · calc 2 / Yr = 2 * (1 / Yr) := by ring
      _ ≤ 2 * (2 * τ) := by gcongr
      _ = 4 * τ := by ring
      _ ≤ Λ ^ (-(100 : ℝ)) := small_mul Λ 4 hΛ (by norm_num) (by norm_num) τ hτ
  · calc (12.5 : ℝ) / Yr = 12.5 * (1 / Yr) := by ring
      _ ≤ 12.5 * (2 * τ) := by gcongr
      _ = 25 * τ := by ring
      _ ≤ Λ ^ (-(100 : ℝ)) := small_mul Λ 25 hΛ (by norm_num) (by norm_num) τ hτ
  · have hs2 : Real.sqrt 2 ≤ 1.5 := sqrt_le_of (by norm_num) (by norm_num)
    have q1 : Real.sqrt (2 / s) ≤ 1.5 * s ^ (-(u / 2)) := by
      have e : Real.sqrt (2 / s) = Real.sqrt 2 * s ^ (-(1 / 2 : ℝ)) := by
        rw [Real.sqrt_div' _ hs0.le, Real.sqrt_eq_rpow s, Real.rpow_neg hs0.le]; field_simp
      have hq : s ^ (-(1 / 2 : ℝ)) ≤ s ^ (-(u / 2)) :=
        Real.rpow_le_rpow_of_exponent_le hs1 (by linarith)
      have : 0 ≤ s ^ (-(1 / 2 : ℝ)) := by positivity
      rw [e]; nlinarith
    have q2 : 1 / Real.sqrt Yr ≤ 1.5 * s ^ (-(u / 2)) := by
      have hq : Real.sqrt (s ^ u / 2) = s ^ (u / 2) / Real.sqrt 2 := by
        rw [Real.sqrt_div' _ (by norm_num), Real.sqrt_eq_rpow, ← Real.rpow_mul hs0.le]; ring_nf
      have hpos : 0 < Real.sqrt (s ^ u / 2) := Real.sqrt_pos.2 (by positivity)
      have h1 : 1 / Real.sqrt Yr ≤ 1 / Real.sqrt (s ^ u / 2) :=
        one_div_le_one_div_of_le hpos (Real.sqrt_le_sqrt hY)
      rw [hq] at h1
      have e : 1 / (s ^ (u / 2) / Real.sqrt 2) = Real.sqrt 2 * s ^ (-(u / 2)) := by
        rw [Real.rpow_neg hs0.le]; field_simp
      rw [e] at h1
      have : 0 ≤ s ^ (-(u / 2)) := by positivity
      nlinarith
    have h2n : (2 : ℝ) ^ n ≤ s ^ (c₀ / 2) :=
      le_trans (pow_le_pow_left₀ (by norm_num) (by norm_num) _) h4n
    have hτ' : s ^ (-c₀) ≤ τ := t_le_tau hs1
    calc (Real.sqrt (2 / s) + 1 / Real.sqrt Yr) * 2 ^ n
        ≤ (3 * s ^ (-(u / 2))) * s ^ (c₀ / 2) := by gcongr; linarith
      _ = 3 * s ^ (-(u / 2) + c₀ / 2) := by rw [← rp hs0]; ring
      _ ≤ 3 * s ^ (-c₀) :=
          mul_le_mul_of_nonneg_left (Real.rpow_le_rpow_of_exponent_le hs1 (by linarith)) (by norm_num)
      _ ≤ 3 * τ := by gcongr
      _ ≤ 3 * Λ ^ (-(100 : ℝ)) := by
          have := small_mul Λ 1 hΛ (by norm_num) (by norm_num) τ hτ
          linarith


lemma aX_fact (Λ s : ℝ) (a X : ℕ) (hΛ : 200000 ≤ Λ) (hX1 : 1 ≤ X) (hXle : (X : ℝ) ≤ 2 * Λ ^ (200 : ℝ))
    (ha : s / 2 ≤ a) (hsΛ : Λ ^ (3000 : ℝ) ≤ s) :
    s / (8 * Λ ^ (200 : ℝ)) ≤ ((a / X : ℕ) : ℝ) := by
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  have hd := natdiv_ge a X hX1
  have hXpos : (0 : ℝ) < X := by exact_mod_cast hX1
  have hp : 0 < Λ ^ (200 : ℝ) := by positivity
  have hs0 : 0 < s := lt_of_lt_of_le (by positivity) hsΛ
  have h1 : s / 2 / (2 * Λ ^ (200 : ℝ)) ≤ (a : ℝ) / X :=
    div_le_div₀ (by positivity) ha hXpos hXle
  have hge : 8 * Λ ^ (200 : ℝ) ≤ s := by
    have e3 : Λ ^ (3000 : ℝ) = Λ ^ (200 : ℝ) * Λ ^ (2800 : ℝ) := by rw [rp hΛ0]; norm_num
    have : (8 : ℝ) ≤ Λ ^ (2800 : ℝ) := le_trans (by linarith) (le_rpow_big Λ hΛ1 2800 (by norm_num))
    rw [e3] at hsΛ; nlinarith
  have h2 : s / (8 * Λ ^ (200 : ℝ)) + 1 ≤ s / 2 / (2 * Λ ^ (200 : ℝ)) := by
    have e : s / 2 / (2 * Λ ^ (200 : ℝ)) = 2 * (s / (8 * Λ ^ (200 : ℝ))) := by field_simp; ring
    have : 1 ≤ s / (8 * Λ ^ (200 : ℝ)) := by rw [le_div_iff₀ (by positivity)]; linarith
    linarith
  linarith

lemma Uv_b_facts (s b : ℕ) (hs65 : (65536 : ℝ) ≤ s) (hb : (s : ℝ) / 2 ≤ b) :
    2 ≤ Uvp s ∧ Uvp s ≤ b := by
  have hs0 : (0 : ℝ) < s := by linarith
  have hs1 : (1 : ℝ) ≤ s := by linarith
  have h16 := two_le_rpow_16 (s : ℝ) hs65
  refine ⟨?_, ?_⟩
  · unfold Uvp; exact Nat.le_floor (by push_cast; exact h16)
  · have hfl : (Uvp s : ℝ) ≤ (s : ℝ) ^ (1 / 16 : ℝ) := Nat.floor_le (by positivity)
    have h15 : (2 : ℝ) ≤ (s : ℝ) ^ (15 / 16 : ℝ) :=
      le_trans h16 (Real.rpow_le_rpow_of_exponent_le hs1 (by norm_num))
    have e : (s : ℝ) = (s : ℝ) ^ (1 / 16 : ℝ) * (s : ℝ) ^ (15 / 16 : ℝ) := by rw [rp hs0]; norm_num
    have hp : 0 ≤ (s : ℝ) ^ (1 / 16 : ℝ) := by positivity
    have : (s : ℝ) ^ (1 / 16 : ℝ) * 2 ≤ s := by
      calc (s : ℝ) ^ (1 / 16 : ℝ) * 2 ≤ (s : ℝ) ^ (1 / 16 : ℝ) * (s : ℝ) ^ (15 / 16 : ℝ) :=
            mul_le_mul_of_nonneg_left h15 hp
        _ = s := e.symm
    have : (Uvp s : ℝ) ≤ b := by linarith
    exact_mod_cast this

lemma XY_fact (Λ : ℝ) (s : ℕ) (X Y b : ℕ) (u : ℝ) (hΛ : 200000 ≤ Λ) (hu1 : u ≤ 1 / 8)
    (hs65 : (65536 : ℝ) ≤ s) (hsΛ : Λ ^ (3000 : ℝ) ≤ s) (hXle : (X : ℝ) ≤ 2 * Λ ^ (200 : ℝ))
    (hY : (Y : ℝ) ≤ (s : ℝ) ^ u) (hb : (s : ℝ) / 2 ≤ b) : X * Y ≤ b := by
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  have hs0 : (0 : ℝ) < s := by linarith
  have hs1 : (1 : ℝ) ≤ s := by linarith
  have hY8 : (Y : ℝ) ≤ (s : ℝ) ^ (1 / 8 : ℝ) := le_trans hY (Real.rpow_le_rpow_of_exponent_le hs1 hu1)
  have hX8 : (X : ℝ) ≤ (s : ℝ) ^ (1 / 8 : ℝ) := by
    have h1 : (2 * Λ ^ (200 : ℝ)) ^ (8 : ℝ) ≤ Λ ^ (3000 : ℝ) := by
      rw [Real.mul_rpow (by norm_num) (by positivity), ← Real.rpow_mul hΛ0.le]
      have e : Λ ^ (3000 : ℝ) = Λ ^ ((200 : ℝ) * 8) * Λ ^ (1400 : ℝ) := by rw [rp hΛ0]; norm_num
      rw [e]
      have : (2 : ℝ) ^ (8 : ℝ) ≤ Λ ^ (1400 : ℝ) := by
        have : (2 : ℝ) ^ (8 : ℝ) = 256 := by norm_num
        rw [this]; exact le_trans (by linarith) (le_rpow_big Λ hΛ1 1400 (by norm_num))
      have : 0 ≤ Λ ^ ((200 : ℝ) * 8) := by positivity
      nlinarith
    have h2 : 2 * Λ ^ (200 : ℝ) ≤ (s : ℝ) ^ (1 / 8 : ℝ) := by
      calc 2 * Λ ^ (200 : ℝ) = ((2 * Λ ^ (200 : ℝ)) ^ (8 : ℝ)) ^ (1 / 8 : ℝ) := by
            rw [← Real.rpow_mul (by positivity)]; norm_num
        _ ≤ (s : ℝ) ^ (1 / 8 : ℝ) := Real.rpow_le_rpow (by positivity) (le_trans h1 hsΛ) (by norm_num)
    linarith
  have h14 : (s : ℝ) ^ (1 / 8 : ℝ) * (s : ℝ) ^ (1 / 8 : ℝ) ≤ (s : ℝ) / 2 := by
    rw [rp hs0]
    have e : (s : ℝ) = (s : ℝ) ^ (1 / 8 + 1 / 8 : ℝ) * (s : ℝ) ^ (3 / 4 : ℝ) := by rw [rp hs0]; norm_num
    have h34 : (2 : ℝ) ≤ (s : ℝ) ^ (3 / 4 : ℝ) :=
      le_trans (two_le_rpow_16 _ hs65) (Real.rpow_le_rpow_of_exponent_le hs1 (by norm_num))
    have : 0 ≤ (s : ℝ) ^ (1 / 8 + 1 / 8 : ℝ) := by positivity
    have : (s : ℝ) ^ (1 / 8 + 1 / 8 : ℝ) * 2 ≤ s := by
      calc (s : ℝ) ^ (1 / 8 + 1 / 8 : ℝ) * 2 ≤ (s : ℝ) ^ (1 / 8 + 1 / 8 : ℝ) * (s : ℝ) ^ (3 / 4 : ℝ) :=
            mul_le_mul_of_nonneg_left h34 this
        _ = s := e.symm
    linarith
  have : ((X * Y : ℕ) : ℝ) ≤ b := by
    push_cast
    calc (X : ℝ) * Y ≤ (s : ℝ) ^ (1 / 8 : ℝ) * (s : ℝ) ^ (1 / 8 : ℝ) :=
          mul_le_mul hX8 hY8 (by positivity) (by positivity)
      _ ≤ (s : ℝ) / 2 := h14
      _ ≤ b := hb
  exact_mod_cast this


set_option maxHeartbeats 4000000 in
/-- **Each region-C `CTerm` is `≤ Λ^{−40}`**, eventually in `h`, uniformly in admissible `s` and
dyadic pieces `(a, b]` with `s^{1+ε}/2 ≤ a < b ≤ 2a`, `b ≤ H²`. -/
theorem CTerm_ev (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (h H : ℕ), Λ₀ ≤ Real.log h → H ≤ h →
      ∀ (s M : ℕ) [NeZero s] [NeZero M] (C U' JP : Finset ℕ), (∀ p ∈ C, p.Prime) → s = ∏ p ∈ C, p →
        M = 6 * q → 5 * (Real.log h) ^ σ₀ ≤ Real.log (s : ℝ) →
        (∀ p ∈ U', p.Prime ∧ 5 ≤ p ∧ p ≤ H ^ 2) →
        ∀ (A : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s),
          (∀ ρ j, 1 ≤ j → ‖A ρ j‖ ≤ (300 * (q : ℝ) ^ 2) / j) →
          (∀ j, 1 ≤ j → C.filter (fun p => (ZMod.cast (c j) : ZMod p) = 0) = C.filter (fun p => p ∣ j)) →
          ∀ (Ec a b : ℕ), (Ec : ℝ) ≤ (Real.log h) ^ 2 →
            (s : ℝ) ^ (1 + εp h) / 2 ≤ a → a < b → b ≤ 2 * a → b ≤ H ^ 2 →
            GoldC.QuillonCCellApp.CTerm C (Icc 1 (6 * q * h)) A c U' JP (Xp h) (Yp δ s) (Tpp h)
              (Uvp s) (Uvp s) (Tvp h) Ec a b ≤ (Real.log h) ^ (-(40 : ℝ)) := by
  have ha0 := a0_pos hδ0 hδ1
  have ha0' := a0_le hδ0
  have hu0 : 0 < u0 δ := by unfold u0; linarith
  have hu1 : u0 δ ≤ 1 / 8 := by unfold u0; linarith
  set Ab : ℝ := 300 * (q : ℝ) ^ 2 with hAb
  set E : ℝ := Real.exp 10 * (2 * 2 + 1) ^ 10 with hE
  set Mr : ℝ := ((6 * q : ℕ) : ℝ) with hMr
  set Kc : ℝ := 5 * Mr * (Mr * Ab * 2) * 82944 + E * (Mr * Ab * 2) * 2 + Mr * Ab * 2 * E with hKc
  have hKc0 : 0 ≤ Kc := by positivity
  obtain ⟨Λ₁, hΛ₁, hτ⟩ := GoldC.QuillonEv.sdecay 2 (u0 δ / 8) 3000 (by positivity) (by norm_num)
  obtain ⟨Λ₂, hΛ₂, hε⟩ := edecay 3001 (by norm_num)
  obtain ⟨L₀, hL₀, h4⟩ := GoldC.QuillonAsymp.four_pow_card_le (u0 δ / 8 / 2) (by positivity)
  obtain ⟨Λ₃, hΛ₃, hsl⟩ := s_large (max (Real.exp L₀) (2 ^ (16 / u0 δ)))
  obtain ⟨Λ₄, hΛ₄, hAω⟩ := Aω_le 5 (1 / 2) (by norm_num) (by norm_num)
  obtain ⟨Λ₅, hΛ₅, hK⟩ := const_le_rpow (Kc + Mr + 6 * q + 6 + 200000) 1 one_pos
  refine ⟨max 2 (max Λ₁ (max Λ₂ (max Λ₃ (max Λ₄ (max Λ₅ (1 + Real.log (6 * q))))))), le_max_left _ _, ?_⟩
  intro h H hΛ hHh s M _ _ C U' JP hC hsC hM hlog hU' A c hA hc Ec a b hEc ha hab hb2 hbH
  set Λ := Real.log h with hΛdef
  have hge : ∀ x, x ≤ max 2 (max Λ₁ (max Λ₂ (max Λ₃ (max Λ₄ (max Λ₅ (1 + Real.log (6 * q))))))) → x ≤ Λ :=
    fun x hx => le_trans hx hΛ
  have hΛ2 : 2 ≤ Λ := hge _ (le_max_left _ _)
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  have L1 := hge Λ₁ (by simp)
  have L2 := hge Λ₂ (by simp)
  have L3 := hge Λ₃ (by simp)
  have L4 := hge Λ₄ (by simp)
  have L5 := hge Λ₅ (by simp)
  have L6 := hge (1 + Real.log (6 * q)) (by simp)
  clear hge hΛ
  have hKΛ := hK Λ L5
  rw [Real.rpow_one] at hKΛ
  have hΛbig : 200000 ≤ Λ := by
    have : (0 : ℝ) ≤ Mr + 6 * q + 6 := by positivity
    linarith
  have hKcΛ : Kc ≤ Λ := by
    have : (0 : ℝ) ≤ Mr + 6 * q + 6 + 200000 := by positivity
    linarith
  have hMΛ : Mr ≤ Λ := by
    have : (0 : ℝ) ≤ 6 * q + 6 + 200000 := by positivity
    linarith
  have hh1n : 1 ≤ h := by
    rcases Nat.eq_zero_or_pos h with h0 | h0
    · exfalso
      have : Real.log (h : ℝ) = 0 := by rw [h0]; simp
      linarith
    · exact h0
  have hh0 : (0 : ℝ) < h := by exact_mod_cast hh1n
  have hspos : 0 < s := by rw [hsC]; exact prod_pos fun p hp => (hC p hp).pos
  have hs0 : (0 : ℝ) < s := by exact_mod_cast hspos
  have hsbig := hsl Λ L3 s hs0 hlog
  have hsL₀ : L₀ ≤ Real.log s := by
    rw [← Real.log_exp L₀]; exact Real.log_le_log (Real.exp_pos _) (le_trans (le_max_left _ _) hsbig)
  have hτΛ := hτ Λ L1 s hs0 hlog
  obtain ⟨hs65, hs1, hsu2, hsΛ⟩ := s_facts Λ s (u0 δ) (u0 δ / 8) hΛ2 hu0 hu1 (by linarith)
    (le_trans (le_max_right _ _) hsbig) hτΛ
  have h4n : (4 : ℝ) ^ C.card ≤ (s : ℝ) ^ (u0 δ / 8 / 2) := by
    have := h4 C hC (by rw [← hsC]; exact hsL₀); rwa [← hsC] at this
  -- `a`, `b`
  have hε0 : 0 ≤ εp h := by unfold εp; positivity
  have hs1e : (s : ℝ) ≤ (s : ℝ) ^ (1 + εp h) := by
    calc (s : ℝ) = (s : ℝ) ^ (1 : ℝ) := (Real.rpow_one _).symm
      _ ≤ (s : ℝ) ^ (1 + εp h) := Real.rpow_le_rpow_of_exponent_le hs1 (by linarith)
  have habR : (a : ℝ) ≤ b := by exact_mod_cast hab.le
  have haR : (s : ℝ) / 2 ≤ a := le_trans (by linarith) ha
  have hbR : (s : ℝ) / 2 ≤ b := le_trans haR habR
  have hb1 : 1 ≤ b := by
    have : (1 : ℝ) ≤ b := by linarith
    exact_mod_cast this
  have hb0 : (0 : ℝ) < b := by linarith
  have hbh : Real.log b ≤ 2 * Λ := by
    have h1 : (b : ℝ) ≤ (h : ℝ) ^ 2 := by
      have : b ≤ h ^ 2 := le_trans hbH (Nat.pow_le_pow_left hHh 2)
      exact_mod_cast this
    have := Real.log_le_log hb0 h1
    rwa [Real.log_pow, Nat.cast_ofNat] at this
  have hlb : (Nat.log 2 b : ℝ) + 1 ≤ 5 * Λ := by
    have := natlog_le_of b (2 * Λ) hbh
    rw [max_eq_left (show (0 : ℝ) ≤ 2 * Λ by linarith)] at this
    linarith
  have hsb : (s : ℝ) / b ≤ Λ ^ (-(3000 : ℝ)) :=
    sb_fact Λ s b (εp h) hΛ2 hs0 hb0 (hε Λ L2 s hs0 hlog) (le_trans ha habR)
  -- `X`, `Y`, `Tp`, `Tv`, `Uv`
  have hXge := Xp_ge (h := h) hΛ1
  have hXle := Xp_le (h := h) hΛ1
  have hX1 : 1 ≤ Xp h := by
    have : (1 : ℝ) ≤ Xp h := le_trans (Real.one_le_rpow hΛ1 (by norm_num)) hXge
    exact_mod_cast this
  obtain ⟨hTp1, hTp2⟩ := Tpp_bounds (h := h) hΛ1
  obtain ⟨hTv1, hTv2⟩ := Tvp_bounds (h := h) hΛ1
  have hYge := inv_Yp_le hδ0 hδ1 hsu2
  have hY1 : 1 ≤ Yp δ s := by
    have : (1 : ℝ) ≤ Yp δ s := by linarith
    exact_mod_cast this
  obtain ⟨hY2, hY12, hsY⟩ := Y_facts Λ s (u0 δ) (u0 δ / 8) (Yp δ s) C.card hΛbig hu0 (by linarith)
    (by linarith) hs1 hYge hsu2 hτΛ h4n (by positivity)
  have haX := aX_fact Λ s a (Xp h) hΛbig hX1 hXle haR hsΛ
  have ha6 : 6 ≤ a / Xp h := by
    have h6 : (6 * q + 6 : ℝ) ≤ (s : ℝ) / (8 * Λ ^ (200 : ℝ)) := by
      rw [le_div_iff₀ (by positivity)]
      have e3 : Λ ^ (3000 : ℝ) = Λ ^ (1 : ℝ) * Λ ^ (200 : ℝ) * Λ ^ (2799 : ℝ) := by
        rw [rp hΛ0, rp hΛ0]; norm_num
      have hb8 : (8 : ℝ) ≤ Λ ^ (2799 : ℝ) := le_trans (by linarith) (le_rpow_big Λ hΛ1 2799 (by norm_num))
      have hq6 : (6 * q + 6 : ℝ) ≤ Λ := by
        have : (0 : ℝ) ≤ Kc + Mr + 200000 := by positivity
        linarith
      rw [e3, Real.rpow_one] at hsΛ
      have hp : 0 < Λ ^ (200 : ℝ) := by positivity
      calc (6 * q + 6 : ℝ) * (8 * Λ ^ (200 : ℝ)) ≤ Λ * (8 * Λ ^ (200 : ℝ)) :=
            mul_le_mul_of_nonneg_right hq6 (by positivity)
        _ ≤ Λ * (Λ ^ (2799 : ℝ) * Λ ^ (200 : ℝ)) :=
            mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right hb8 hp.le) hΛ0.le
        _ = Λ * Λ ^ (200 : ℝ) * Λ ^ (2799 : ℝ) := by ring
        _ ≤ s := hsΛ
    have : (6 : ℝ) ≤ ((a / Xp h : ℕ) : ℝ) := by
      have : (0 : ℝ) ≤ q := by positivity
      linarith
    exact_mod_cast this
  obtain ⟨hUv2, hUvb⟩ := Uv_b_facts s b hs65 hbR
  have hXYb := XY_fact Λ s (Xp h) (Yp δ s) b (u0 δ) hΛbig hu1 hs65 hsΛ hXle (Yp_le δ s) hbR
  -- weights
  have hAωb : (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30) ^ 2 ≤ Λ := by
    have h1 := hAω Λ L4 b (by linarith)
    have h0 : 0 ≤ Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30 := by positivity
    calc _ ≤ (Λ ^ (1 / 2 : ℝ)) ^ 2 := pow_le_pow_left₀ h0 h1 2
      _ = Λ := by rw [← Real.rpow_natCast, ← Real.rpow_mul hΛ0.le]; norm_num
  have hU'5 : ∀ p ∈ U', 5 ≤ p := fun p hp => (hU' p hp).2.1
  have hlogh2 : Real.log ((h ^ 2 : ℕ) : ℝ) ≤ 2 * Λ := by
    push_cast; rw [Real.log_pow]; push_cast; exact le_rfl
  have hWU : ∏ p ∈ U', (1 + 1 / ((p : ℝ) - 3)) ≤ E * Λ ^ (10 : ℝ) :=
    prodU_le_pow U' (fun p hp => ⟨(hU' p hp).1, (hU' p hp).2.1⟩) (h ^ 2)
      (fun p hp => le_trans (hU' p hp).2.2 (Nat.pow_le_pow_left hHh 2)) 2 Λ (by norm_num) hΛ1 hlogh2
  have hSm : ∑ B' ∈ (U'.filter (fun p => p < Xp h)).powerset, ωR B' ≤ E * Λ ^ (10 : ℝ) := by
    rw [sum_ωR_powerset]
    exact prodU_le_pow _ (fun p hp => ⟨(hU' p (filter_subset _ _ hp)).1, (hU' p (filter_subset _ _ hp)).2.1⟩)
      (h ^ 2) (fun p hp => le_trans (hU' p (filter_subset _ _ hp)).2.2 (Nat.pow_le_pow_left hHh 2)) 2 Λ
      (by norm_num) hΛ1 hlogh2
  have hJm : 1 + Real.log ((6 * q * h : ℕ) : ℝ) ≤ 2 * Λ := by
    push_cast
    rw [Real.log_mul (by positivity) hh0.ne']
    linarith
  have hK1 : (((Nat.log 2 (b / (Xp h * Yp δ s)) + 1 : ℕ)) : ℝ) ≤ 5 * Λ := by
    have h1 : Nat.log 2 (b / (Xp h * Yp δ s)) ≤ Nat.log 2 b := Nat.log_mono_right (Nat.div_le_self _ _)
    have : (Nat.log 2 (b / (Xp h * Yp δ s)) : ℝ) ≤ Nat.log 2 b := by exact_mod_cast h1
    push_cast; linarith
  subst hM
  have hM1 : 1 ≤ 6 * q := by omega
  have hMΛ' : ((6 * q : ℕ) : ℝ) ≤ Λ := hMΛ
  have hCT := GoldC.QuillonCEst.CTerm_le (s := s) (M := 6 * q) C hC hsC (6 * q * h) A c Ab (by positivity)
    hA hc U' JP hU'5 (Xp h) (Yp δ s) (Tpp h) (Uvp s) (Uvp s) (Tvp h) Ec a a b hX1 hY1
    (by have : (1 : ℝ) ≤ Tpp h := le_trans (Real.one_le_rpow hΛ1 (by norm_num)) hTp1
        exact_mod_cast this)
    (by omega) le_rfl hb2 hab.le ha6 hUv2 (by omega)
    (by have : (1 : ℝ) ≤ Tvp h := le_trans (Real.one_le_rpow hΛ1 (by norm_num)) hTv1
        exact_mod_cast this)
    hUvb hXYb
  refine le_trans hCT ?_
  have hPα := Pα_le Λ hΛ2 s (Xp h) (Yp δ s) (Tpp h) b _ (by positivity) hAωb hb1 hbh hlb hTp1 hTp2 hXge
    (le_trans hsb (Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num))) hY2
  have hPβ := Pβ_le Λ hΛ2 s (Yp δ s) (Tpp h) b C.card _ (by positivity) hAωb hb1 hbh hlb hTp2 hsY
  have hVα := Vα_le Λ hΛ2 (by linarith) s (Xp h) a b (Uvp s) (Tvp h) Ec (6 * q) (u0 δ / 8) (by linarith)
    hs65 hτΛ hsb hX1 hXle hbR hb1 hbh rfl hTv1 hTv2 hEc haX hM1 hMΛ' hlb
  have hVβ := Vβ_le Λ hΛ2 (by linarith) s (Xp h) b (Uvp s) (Tvp h) (6 * q) C.card (u0 δ / 8)
    (by positivity) (by linarith) hs65 hτΛ h4n hX1 hXle hbR hb1 hbh rfl hTv2 hM1 hMΛ' hlb
  have hL3 := (L3b_le Λ hΛ2 b hb1 hbh).1
  have hP0 : 0 ≤ Pα s (Xp h) (Yp δ s) (Tpp h) b
      ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30) ^ 2) +
      Pβ s (Yp δ s) (Tpp h) b ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30) ^ 2) * 2 ^ C.card := by
    unfold Pα Pβ; positivity
  have hV0 : 0 ≤ Vα s (Xp h) a b (Uvp s) (Uvp s) (Tvp h) Ec (6 * q) +
      Vβ s (Xp h) b (Uvp s) (Uvp s) (Tvp h) (6 * q) C.card * 2 ^ C.card := by
    unfold Vα Vβ
    have : 0 ≤ Real.log (b : ℝ) := Real.log_nonneg (by exact_mod_cast hb1)
    have : 0 ≤ Real.log ((Uvp s * Uvp s : ℕ) : ℝ) := Real.log_natCast_nonneg _
    have : 0 ≤ Real.log (s : ℝ) := Real.log_nonneg hs1
    positivity
  have hSm0 : 0 ≤ ∑ B' ∈ (U'.filter (fun p => p < Xp h)).powerset, ωR B' :=
    sum_nonneg fun B' hB' => ωR_nonneg B' fun p hp => hU'5 p (filter_subset _ _ ((mem_powerset.1 hB') hp))
  have hWU0 : 0 ≤ ∏ p ∈ U', (1 + 1 / ((p : ℝ) - 3)) := prod_nonneg fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast hU'5 p hp
    have : 0 ≤ 1 / ((p : ℝ) - 3) := div_nonneg zero_le_one (by linarith)
    linarith
  have hPsum : Pα s (Xp h) (Yp δ s) (Tpp h) b
      ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30) ^ 2) +
      Pβ s (Yp δ s) (Tpp h) b ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30) ^ 2) * 2 ^ C.card ≤
      82944 * Λ ^ (-(45 : ℝ)) := by
    have := add_le_add hPα hPβ; linarith
  have hVsum := add_le_add hVα hVβ
  exact C_combine Λ _ _ Ab _ _ _ _ _ _ E hΛ2 (by positivity) (by positivity) (by positivity) hK1
    (by have := Real.log_natCast_nonneg (6 * q * h); linarith) hJm hP0 hPsum hV0 (by linarith)
    hSm0 hSm hWU0 hWU (by positivity) hY12 (by positivity) (by rw [Real.rpow_one]; exact hKcΛ)

end GoldC.QuillonCFinal

#print axioms GoldC.QuillonCFinal.CTerm_ev
