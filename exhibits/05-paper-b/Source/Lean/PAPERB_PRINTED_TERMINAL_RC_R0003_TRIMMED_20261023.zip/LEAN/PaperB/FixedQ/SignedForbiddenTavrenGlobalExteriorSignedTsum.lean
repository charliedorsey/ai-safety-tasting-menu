import PaperB.FixedQ.SignedForbiddenTavrenGlobalExteriorSignedReindex

open scoped BigOperators Classical

namespace PaperB.FixedQ

/-- The signed pair's absolute value equals the EXISTING proved
absolute pair majorant, giving summability without losing sign
in the subsequent reindexed identity. -/
theorem tavren_globalExteriorSignedPair_abs_eq_oldAbsPair
    (q a h Z : ℕ) (dn : Finset ℕ × Finset ℕ) :
    |tavrenGlobalExteriorSignedPairTerm q a h Z dn| =
      globalProperExteriorAbsPairTerm q a h Z dn := by
  classical
  rcases dn with ⟨d, n⟩
  unfold tavrenGlobalExteriorSignedPairTerm
    globalProperExteriorAbsPairTerm
  dsimp
  by_cases hd : d ∈ (decoratedHeightPrimeSet q h).powerset
  · by_cases hm : Z < primeSetProduct n
    · have hv0 : 0 ≤ finiteVWeightReal h d := by
        apply finiteVWeightReal_nonneg_of_active
        exact decoratedHeightPrimeSet_active (Finset.mem_powerset.mp hd)
      simp [hd, hm, abs_mul, abs_of_nonneg hv0]
    · simp [hd, hm]
  · simp [hd]

theorem tavren_summable_globalExteriorSignedPair
    {q a h Z : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    Summable (tavrenGlobalExteriorSignedPairTerm q a h Z) := by
  apply Summable.of_norm
  have hAbs :=
    summable_globalProperExteriorAbsPairTerm
      (q := q) (a := a) (h := h) (Z := Z) hq hh h2
  exact hAbs.congr (fun dn => by
    rw [Real.norm_eq_abs,
      tavren_globalExteriorSignedPair_abs_eq_oldAbsPair q a h Z dn])

theorem tavren_summable_globalExteriorSignedReindex
    {q a h Z : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    Summable (tavrenGlobalExteriorSignedReindexTerm q a h Z) := by
  have hp := tavren_summable_globalExteriorSignedPair
    (q := q) (a := a) (h := h) (Z := Z) hq hh h2
  apply (Sum.inl_injective.summable_iff ?_).mp
  · simpa [Function.comp_def, tavrenGlobalExteriorSignedReindexTerm]
      using hp
  · intro x hx
    cases x with
    | inl dn => exact (hx ⟨dn, rfl⟩).elim
    | inr e => simp [tavrenGlobalExteriorSignedReindexTerm]

/-- Every nonzero signed pair genuinely comes from one active source e;
in particular the induced height divisor d must divide h. -/
theorem tavren_globalExteriorSignedReindex_support_subset_range
    {q a h Z : ℕ} :
    Function.support (tavrenGlobalExteriorSignedReindexTerm q a h Z) ⊆
      Set.range (decoratedAnalyticSignedReindexKey q h) := by
  classical
  intro x hx
  cases x with
  | inr e =>
      exfalso
      exact hx (by simp [tavrenGlobalExteriorSignedReindexTerm])
  | inl dn =>
      rcases dn with ⟨d,n⟩
      by_cases hd : d ∈ (decoratedHeightPrimeSet q h).powerset
      · by_cases hgt : Z < primeSetProduct n
        · have hterm :
              dForbiddenReducedBooleanCoreTerm q
                (decoratedReducedAnchor q a (primeSetProduct d))
                (h / primeSetProduct d) d n ≠ 0 := by
            intro hz
            apply hx
            simp [tavrenGlobalExteriorSignedReindexTerm,
              tavrenGlobalExteriorSignedPairTerm, hd, hgt, hz]
          have hdis : Disjoint d n := by
            by_contra hndis
            apply hterm
            simp [dForbiddenReducedBooleanCoreTerm, hndis]
          have hn : n ∈ activeOrdinaryTwoDimensionalSet q
              (h / primeSetProduct d) := by
            by_contra hnact
            apply hterm
            simp [dForbiddenReducedBooleanCoreTerm, hdis,
              ordinaryBooleanCoreTerm, Set.indicator, hnact]
          refine ⟨d ∪ n, ?_⟩
          exact decoratedAnalyticSignedReindexKey_union
            (Finset.mem_powerset.mp hd) hn hdis
        · exfalso
          apply hx
          simp [tavrenGlobalExteriorSignedReindexTerm,
            tavrenGlobalExteriorSignedPairTerm, hd, hgt]
      · exfalso
        apply hx
        simp [tavrenGlobalExteriorSignedReindexTerm,
          tavrenGlobalExteriorSignedPairTerm, hd]

/-- The actual exterior signed tsum, not its total-variation
majorant, reindexes bijectively under the native CRT height key. -/
theorem tavren_globalProperExteriorAnalytic_eq_signedReindex_tsum
    {q a h Z : ℕ} (hh : 0 < h) :
    globalProperExteriorAnalytic q a h Z =
      ∑' x : (Finset ℕ × Finset ℕ) ⊕ Finset ℕ,
        tavrenGlobalExteriorSignedReindexTerm q a h Z x := by
  classical
  let f : Finset ℕ → ℝ :=
    (globalProperSmallSet h Z)ᶜ.indicator
      (decoratedAnalyticPerE q a h)
  let g : (Finset ℕ × Finset ℕ) ⊕ Finset ℕ → ℝ :=
    tavrenGlobalExteriorSignedReindexTerm q a h Z
  let key := decoratedAnalyticSignedReindexKey q h
  have hgrange : Function.support g ⊆ Set.range key := by
    simpa [g, key] using
      (tavren_globalExteriorSignedReindex_support_subset_range
        (q := q) (a := a) (h := h) (Z := Z))
  let i : Function.support g → Finset ℕ :=
    fun x => Classical.choose (hgrange x.property)
  have hikey : ∀ x : Function.support g, key (i x) = x.1 := by
    intro x
    exact Classical.choose_spec (hgrange x.property)
  have hi : Function.Injective i := by
    intro x y hxy
    apply Subtype.ext
    have hk := congrArg key hxy
    rw [hikey x, hikey y] at hk
    exact hk
  have hpoint : ∀ e : Finset ℕ, f e = g (key e) := by
    intro e
    simpa [f, g, key] using
      tavren_globalExterior_indicator_eq_signedReindex
        (q := q) (a := a) (h := h) (Z := Z) hh e
  have hfsupp : Function.support f ⊆ Set.range i := by
    intro e he
    have hgne : g (key e) ≠ 0 := by
      intro hz
      exact he (by rw [hpoint e, hz])
    let x : Function.support g := ⟨key e, hgne⟩
    refine ⟨x, ?_⟩
    have hk : key (i x) = key e := by
      simpa [x] using hikey x
    exact decoratedAnalyticSignedReindexKey_injective q h hk
  have hfg : ∀ x : Function.support g, f (i x) = g x.1 := by
    intro x
    rw [hpoint]
    rw [hikey x]
  unfold globalProperExteriorAnalytic
  exact tsum_eq_tsum_of_ne_zero_bij i hi hfsupp hfg

#print axioms tavren_globalExteriorSignedPair_abs_eq_oldAbsPair
#print axioms tavren_globalProperExteriorAnalytic_eq_signedReindex_tsum

end PaperB.FixedQ
