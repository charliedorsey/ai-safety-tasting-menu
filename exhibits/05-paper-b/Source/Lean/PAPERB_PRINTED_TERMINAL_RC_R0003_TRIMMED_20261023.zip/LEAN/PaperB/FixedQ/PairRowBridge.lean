import PaperB.FixedQ.RowReduction

open scoped BigOperators

namespace PaperB.FixedQ

def primeSetProduct (s : Finset ℕ) : ℕ := ∏ p ∈ s, p

lemma primeSetProduct_pos
    {s : Finset ℕ} (hs : ∀ p ∈ s, p.Prime) :
    0 < primeSetProduct s := by
  unfold primeSetProduct
  apply Finset.prod_pos
  intro p hp
  exact (hs p hp).pos

lemma primeSetProduct_dvd_iff
    {s : Finset ℕ} {y : ℕ}
    (hs : ∀ p ∈ s, p.Prime) :
    primeSetProduct s ∣ y ↔ ∀ p ∈ s, p ∣ y := by
  constructor
  · intro h p hp
    exact (Finset.dvd_prod_of_mem (fun x : ℕ => x) hp).trans h
  · intro hall
    induction s using Finset.induction_on with
    | empty =>
        simp [primeSetProduct]
    | @insert a s ha ih =>
        have haPrime : a.Prime := hs a (Finset.mem_insert_self a s)
        have hsPrime : ∀ p ∈ s, p.Prime := by
          intro p hp
          exact hs p (Finset.mem_insert_of_mem hp)
        have haD : a ∣ y := hall a (Finset.mem_insert_self a s)
        have hsD : primeSetProduct s ∣ y := by
          apply ih hsPrime
          intro p hp
          exact hall p (Finset.mem_insert_of_mem hp)
        have hcop : a.Coprime (primeSetProduct s) := by
          unfold primeSetProduct
          apply Nat.Coprime.prod_right
          intro p hp
          apply haPrime.coprime_iff_not_dvd.mpr
          intro hap
          have hcases := (Nat.dvd_prime (hsPrime p hp)).mp hap
          rcases hcases with h1 | heq
          · exact haPrime.ne_one h1
          · exact ha (heq ▸ hp)
        have hprod := hcop.mul_dvd_of_dvd_of_dvd haD hsD
        simpa [primeSetProduct, ha] using hprod

def pairLeftModulus (e1 : Finset ℕ) : ℕ :=
  primeSetProduct e1

def pairRightModulus (e e1 : Finset ℕ) : ℕ :=
  primeSetProduct (e \ e1)

theorem pairDenominator_eq_moduli
    (e e1 : Finset ℕ) :
    pairDenominator e e1 =
      (pairLeftModulus e1 : ℝ) * (pairRightModulus e e1 : ℝ) := by
  unfold pairDenominator pairLeftModulus pairRightModulus primeSetProduct
  push_cast
  rfl

theorem pairCount_eq_rowConstrainedMass
    {q h : ℕ} {lambda : ℕ → ℝ} {e e1 : Finset ℕ}
    (hL : ∀ p ∈ e1, activeHighPrime q p)
    (hR : ∀ p ∈ e \ e1, activeHighPrime q p ∧ ¬ p ∣ h) :
    pairCount q h lambda e e1 =
      rowConstrainedMass lambda h
        (pairLeftModulus e1) (pairRightModulus e e1) := by
  unfold pairCount rowConstrainedMass
  apply Finset.sum_congr rfl
  intro y hy
  have hLp : ∀ p ∈ e1, p.Prime := by
    intro p hp
    exact (hL p hp).1
  have hRp : ∀ p ∈ e \ e1, p.Prime := by
    intro p hp
    exact (hR p hp).1.1
  have hLeft :
      pairLeftModulus e1 ∣ y ↔ ∀ p ∈ e1, p ∣ y := by
    exact primeSetProduct_dvd_iff hLp
  have hRight :
      pairRightModulus e e1 ∣ h - y ↔
        ∀ p ∈ e \ e1, p ∣ h - y := by
    exact primeSetProduct_dvd_iff hRp
  have hcond :
      ((∀ p ∈ e1, activeHighPrime q p ∧ p ∣ y) ∧
        (∀ p ∈ e \ e1,
          activeHighPrime q p ∧ ¬ p ∣ h ∧ p ∣ h - y)) ↔
      pairLeftModulus e1 ∣ y ∧
        pairRightModulus e e1 ∣ h - y := by
    constructor
    · intro hc
      constructor
      · exact hLeft.mpr (fun p hp => (hc.1 p hp).2)
      · exact hRight.mpr (fun p hp => (hc.2 p hp).2.2)
    · intro hc
      constructor
      · intro p hp
        exact ⟨hL p hp, hLeft.mp hc.1 p hp⟩
      · intro p hp
        exact ⟨(hR p hp).1, (hR p hp).2,
          hRight.mp hc.2 p hp⟩
  simp only [hcond]

theorem pairDelta_eq_rowDiscrepancyShape
    {q h : ℕ} {lambda : ℕ → ℝ} {N : ℝ}
    {e e1 : Finset ℕ}
    (hL : ∀ p ∈ e1, activeHighPrime q p)
    (hR : ∀ p ∈ e \ e1, activeHighPrime q p ∧ ¬ p ∣ h) :
    pairDelta q h lambda N e e1 =
      rowConstrainedMass lambda h
          (pairLeftModulus e1) (pairRightModulus e e1) -
        N / ((pairLeftModulus e1 : ℝ) *
          (pairRightModulus e e1 : ℝ)) := by
  unfold pairDelta
  rw [pairCount_eq_rowConstrainedMass hL hR,
    pairDenominator_eq_moduli]

theorem pairDelta_eq_fixedQRowDelta
    {q a h : ℕ} {e e1 : Finset ℕ}
    (hL : ∀ p ∈ e1, activeHighPrime q p)
    (hR : ∀ p ∈ e \ e1, activeHighPrime q p ∧ ¬ p ∣ h) :
    pairDelta q h (fixedQLowWeight q a h)
        (admissibleInteriorCount q a h : ℝ) e e1 =
      fixedQRowDelta q a h
        (pairLeftModulus e1) (pairRightModulus e e1) := by
  rw [pairDelta_eq_rowDiscrepancyShape hL hR]
  rfl

#print axioms primeSetProduct_dvd_iff
#print axioms pairDelta_eq_fixedQRowDelta

end PaperB.FixedQ
