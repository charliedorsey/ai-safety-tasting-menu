import PaperB.FixedQ.SignedForbiddenCompletedMainPrincipalBridge

namespace PaperB.FixedQ

/--
Direct B6 consumer: a uniform log-power estimate for the exact
signed-forbidden completed-main aggregate closes the Paper B terminal.
-/
theorem paperBTerminal_of_signedForbiddenAggregateRate
    (hRate :
      ∀ q : ℕ, 0 < q → Squarefree q →
        ∃ C rho : ℝ, ∃ k H0 : ℕ,
          0 ≤ C ∧ rho < 1 ∧
          ∀ a b h : ℕ,
            q.Coprime a →
            q.Coprime b →
            Nat.ModEq q (a + h) b →
            (¬ 2 ∣ q → 2 ∣ h) →
            0 < h →
            H0 ≤ h →
            |cStarReal q h * signedForbiddenCompletedMainAggregate q a h -
                signedMainB1Principal q (h / 2)| ≤
              C * (Real.log (h : ℝ)) ^ rho *
                (Real.log (Real.log (h : ℝ))) ^ k) :
    PaperB.Closure.PaperBTerminalStatement := by
  apply paperBTerminal_of_principalLogPower
  intro q hq hsq
  exact completedMainPrincipalLogPowerSaving_of_signedForbiddenAggregateRate
    hq (hRate q hq hsq)

#print axioms paperBTerminal_of_signedForbiddenAggregateRate

end PaperB.FixedQ
