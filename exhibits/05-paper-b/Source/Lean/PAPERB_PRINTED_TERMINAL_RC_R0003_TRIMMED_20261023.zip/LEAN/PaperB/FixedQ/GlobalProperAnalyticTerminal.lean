import PaperB.FixedQ.DecoratedTerminalSpine
import PaperB.FixedQ.H3DecoratedAnalyticTerminal
import PaperB.FixedQ.PureHeightTerminal
import PaperB.Admission.H1
import PaperB.ExactAccounting.H1Reassignment

open Filter Real Asymptotics
open scoped BigOperators

namespace PaperB.FixedQ

def GlobalProperAnalyticLogPowerSaving (q : ℕ) : Prop :=
  ∃ C rho : ℝ, ∃ k H0 : ℕ,
    0 ≤ C ∧ rho < 1 ∧
      ∀ a h : ℕ,
        q.Coprime a →
        0 < h →
        (¬ 2 ∣ q → 2 ∣ h) →
        H0 ≤ h →
        |ordinaryBooleanCore q a h +
          decoratedAnalyticRemainder q a h| ≤
          C * (Real.log (h : ℝ)) ^ rho *
            (Real.log (Real.log (h : ℝ))) ^ k

theorem globalProperAnalytic_sublog_of_log_power
    (q : ℕ) (hq : 0 < q)
    (hRate : GlobalProperAnalyticLogPowerSaving q) :
    ∀ eps : ℝ, 0 < eps →
      ∃ h0 : ℕ, ∀ a h : ℕ,
        q.Coprime a →
        0 < h →
        (¬ 2 ∣ q → 2 ∣ h) →
        h0 ≤ h →
        |cStarReal q h *
          (ordinaryBooleanCore q a h +
            decoratedAnalyticRemainder q a h)| ≤
          eps * Real.log (h : ℝ) := by
  intro eps heps
  rcases hRate with ⟨C, rho, k, H0, hC, hrho, hRateQ⟩
  obtain ⟨hAbsorb, hAbsorbSpec⟩ :=
    eventually_const_mul_loglog_pow_mul_log_rpow_le_no_extra
      (C := C) (rho := rho) (k := k) hC hrho eps heps
  refine ⟨max H0 hAbsorb, ?_⟩
  intro a h ha hh h2 hlarge
  have hH0 : H0 ≤ h := (le_max_left H0 hAbsorb).trans hlarge
  have hAh : hAbsorb ≤ h := (le_max_right H0 hAbsorb).trans hlarge
  have hr := hRateQ a h ha hh h2 hH0
  have hc := abs_cStarReal_le_one q h
  rw [abs_mul]
  calc
    |cStarReal q h| *
        |ordinaryBooleanCore q a h +
          decoratedAnalyticRemainder q a h|
      ≤ 1 * (C * (Real.log (h : ℝ)) ^ rho *
          (Real.log (Real.log (h : ℝ))) ^ k) := by
        gcongr
    _ = C * (Real.log (Real.log (h : ℝ))) ^ k *
          (Real.log (h : ℝ)) ^ rho := by ring
    _ ≤ eps * Real.log (h : ℝ) := hAbsorbSpec h hAh

theorem twoDimensionalRemainder_sublog_of_globalProperAnalytic
    (q : ℕ) (hq : 0 < q)
    (hRate : GlobalProperAnalyticLogPowerSaving q) :
    ∀ eps : ℝ, 0 < eps →
      ∃ h0 : ℕ, ∀ a b h : ℕ,
        q.Coprime a →
        q.Coprime b →
        Nat.ModEq q (a + h) b →
        (¬ 2 ∣ q → 2 ∣ h) →
        0 < h →
        h0 ≤ h →
        |cStarReal q h * twoDimensionalFamilyRemainder q a h| ≤
          eps * Real.log (h : ℝ) := by
  intro eps heps
  let delta : ℝ := eps / 3
  have hdelta : 0 < delta := by
    dsimp [delta]
    positivity
  obtain ⟨hA, hAspec⟩ :=
    globalProperAnalytic_sublog_of_log_power q hq hRate delta hdelta
  have hC0 : 0 ≤ fixedQDensityDefectUniformBound q := by
    unfold fixedQDensityDefectUniformBound
    positivity
  obtain ⟨hO, hOspec⟩ :=
    PaperB.Closure.exists_nat_threshold_const_le_eps_log hC0 hdelta
  obtain ⟨hD, hDspec⟩ :=
    decoratedDensityRemainder_sublog q hq delta hdelta
  refine ⟨max hA (max hO hD), ?_⟩
  intro a b h ha hb hcompat h2 hh hlarge
  have hAh : hA ≤ h := (le_max_left hA (max hO hD)).trans hlarge
  have hOh : hO ≤ h :=
    (le_max_left hO hD).trans
      ((le_max_right hA (max hO hD)).trans hlarge)
  have hDh : hD ≤ h :=
    (le_max_right hO hD).trans
      ((le_max_right hA (max hO hD)).trans hlarge)
  have han := hAspec a h ha hh h2 hAh
  have hordDensity :=
    abs_cStar_mul_ordinaryDensityCore_le
      (q := q) (a := a) (h := h) hq hh h2
  have hord := hOspec h hOh
  have hdecDensity := hDspec a h h2 hh hDh
  have hreflect := PaperB.Closure.reflected_coprime_equiv hq hcompat
  rw [twoDimensionalFamilyRemainder_eq_ordinary_add_decorated hreflect]
  rw [ordinaryTwoDimensionalRemainder_eq_cores hq hh h2 hreflect]
  rw [decoratedTwoDimensionalRemainder_eq_analytic_add_density
    hq hh h2 hreflect]
  rw [mul_add, mul_add, mul_add]
  calc
    |(cStarReal q h * ordinaryBooleanCore q a h +
        cStarReal q h * ordinaryDensityCore q a h) +
      (cStarReal q h * decoratedAnalyticRemainder q a h +
        cStarReal q h * decoratedDensityRemainder q a h)|
      = |cStarReal q h *
          (ordinaryBooleanCore q a h +
            decoratedAnalyticRemainder q a h) +
          cStarReal q h * ordinaryDensityCore q a h +
          cStarReal q h * decoratedDensityRemainder q a h| := by
            congr 1
            ring
    _ ≤ |cStarReal q h *
          (ordinaryBooleanCore q a h +
            decoratedAnalyticRemainder q a h)| +
        |cStarReal q h * ordinaryDensityCore q a h| +
        |cStarReal q h * decoratedDensityRemainder q a h| := by
          exact (abs_add_le _ _).trans
            (add_le_add (abs_add_le _ _) (le_refl _))
    _ ≤ delta * Real.log (h : ℝ) +
          fixedQDensityDefectUniformBound q +
          delta * Real.log (h : ℝ) := by
        exact add_le_add
          (add_le_add han hordDensity) hdecDensity
    _ ≤ delta * Real.log (h : ℝ) +
          delta * Real.log (h : ℝ) +
          delta * Real.log (h : ℝ) := by
        exact add_le_add
          (add_le_add (le_refl _) hord)
          (le_refl _)
    _ = eps * Real.log (h : ℝ) := by
        dsimp [delta]
        ring

theorem shiftedTwoDimensional_sublog_of_globalProperAnalytic
    (q : ℕ) (hq : 0 < q)
    (hRate : GlobalProperAnalyticLogPowerSaving q) :
    ∀ eps : ℝ, 0 < eps →
      ∃ h0 : ℕ, ∀ a b h : ℕ,
        q.Coprime a →
        q.Coprime b →
        Nat.ModEq q (a + h) b →
        (¬ 2 ∣ q → 2 ∣ h) →
        0 < h →
        h0 ≤ h →
        |cStarReal q h *
          (twoDimensionalFamilyRemainder q a h -
            ∑' e : Finset ℕ, pureHeightSupportTerm q a h e)| ≤
          eps * Real.log (h : ℝ) := by
  intro eps heps
  let delta : ℝ := eps / 2
  have hdelta : 0 < delta := by
    dsimp [delta]
    positivity
  obtain ⟨hD, hDspec⟩ :=
    twoDimensionalRemainder_sublog_of_globalProperAnalytic
      q hq hRate delta hdelta
  obtain ⟨hP, hPspec⟩ :=
    pureHeight_terminal_sublog q hq delta hdelta
  refine ⟨max hD hP, ?_⟩
  intro a b h ha hb hcompat h2 hh hlarge
  have hDh : hD ≤ h := (le_max_left hD hP).trans hlarge
  have hPh : hP ≤ h := (le_max_right hD hP).trans hlarge
  have hDest := hDspec a b h ha hb hcompat h2 hh hDh
  have hPest := hPspec a h h2 hh hPh
  rw [mul_sub]
  calc
    |cStarReal q h * twoDimensionalFamilyRemainder q a h -
        cStarReal q h *
          (∑' e : Finset ℕ, pureHeightSupportTerm q a h e)|
      ≤ |cStarReal q h * twoDimensionalFamilyRemainder q a h| +
        |cStarReal q h *
          (∑' e : Finset ℕ, pureHeightSupportTerm q a h e)| :=
            abs_sub _ _
    _ ≤ delta * Real.log (h : ℝ) +
          delta * Real.log (h : ℝ) :=
      add_le_add hDest hPest
    _ = eps * Real.log (h : ℝ) := by
      dsimp [delta]
      ring

theorem paperBTerminal_of_globalProperAnalytic
    (hRate : ∀ q : ℕ, 0 < q → Squarefree q →
      GlobalProperAnalyticLogPowerSaving q) :
    PaperB.Closure.PaperBTerminalStatement := by
  intro q hq hsq eps heps
  let delta : ℝ := eps / 3
  have hdelta : 0 < delta := by
    dsimp [delta]
    positivity
  obtain ⟨hH1, hH1spec⟩ :=
    PaperB.Admission.sourceNativeH1Control_fixedQ q hq hsq delta hdelta
  obtain ⟨hS, hSspec⟩ :=
    shiftedTwoDimensional_sublog_of_globalProperAnalytic
      q hq (hRate q hq hsq) delta hdelta
  refine ⟨max hH1 hS, ?_⟩
  intro a b h ha hb hcompat h2 hh hlarge
  have hH1h : hH1 ≤ h := (le_max_left hH1 hS).trans hlarge
  have hSh : hS ≤ h := (le_max_right hH1 hS).trans hlarge
  obtain ⟨hleft, hright⟩ :=
    hH1spec a b h ha hb hcompat h2 hh hH1h
  have hshift :=
    hSspec a b h ha hb hcompat h2 hh hSh
  have hreflect := PaperB.Closure.reflected_coprime_equiv hq hcompat
  have hboundary :=
    heightBoundaryFamily_add_pureHeight_eq_reflectedPureLeft hreflect
  rw [PaperB.ExactAccounting.manuscriptA1Kernel_sub_manuscriptB1Kernel_eq_reassigned_boundary_ledger
    h2]
  rw [hboundary]
  calc
    |(cStarReal q h * pureLeftFamily q a h -
          PaperB.Closure.manuscriptS1Kernel q a h) +
        (cStarReal q h *
            pureLeftFamily q (PaperB.Closure.reflectedResidue q b) h -
          PaperB.Closure.manuscriptS1Kernel q
            (PaperB.Closure.reflectedResidue q b) h) +
        cStarReal q h *
          (twoDimensionalFamilyRemainder q a h -
            ∑' e : Finset ℕ, pureHeightSupportTerm q a h e)|
      ≤ |cStarReal q h * pureLeftFamily q a h -
            PaperB.Closure.manuscriptS1Kernel q a h| +
          |cStarReal q h *
              pureLeftFamily q (PaperB.Closure.reflectedResidue q b) h -
            PaperB.Closure.manuscriptS1Kernel q
              (PaperB.Closure.reflectedResidue q b) h| +
          |cStarReal q h *
            (twoDimensionalFamilyRemainder q a h -
              ∑' e : Finset ℕ, pureHeightSupportTerm q a h e)| := by
        exact (abs_add_le _ _).trans
          (add_le_add (abs_add_le _ _) (le_refl _))
    _ ≤ delta * Real.log (h : ℝ) +
          delta * Real.log (h : ℝ) +
          delta * Real.log (h : ℝ) := by
        exact add_le_add (add_le_add hleft hright) hshift
    _ = eps * Real.log (h : ℝ) := by
        dsimp [delta]
        ring

#print axioms globalProperAnalytic_sublog_of_log_power
#print axioms twoDimensionalRemainder_sublog_of_globalProperAnalytic
#print axioms shiftedTwoDimensional_sublog_of_globalProperAnalytic
#print axioms paperBTerminal_of_globalProperAnalytic

end PaperB.FixedQ
