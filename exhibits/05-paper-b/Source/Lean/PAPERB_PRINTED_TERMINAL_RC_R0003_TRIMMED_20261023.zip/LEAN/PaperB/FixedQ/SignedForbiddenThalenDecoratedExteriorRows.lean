import PaperB.FixedQ.SignedForbiddenThalenFiniteExteriorRowIdentity

open scoped BigOperators

namespace PaperB.FixedQ

/-- Consumer-facing decorated finite exterior in literal row and density
coordinates. The sharp support cutoff is not exchanged with any Euler
product; the low-support term remains signed and explicit. -/
theorem thalen_decorated_finite_exterior_eq_rows_sub_density_sub_small
    (q A H Z : ℕ) (d S : Finset ℕ)
    (hact : ∀ n ∈ S.powerset,
      n ∈ activeOrdinaryTwoDimensionalSet q H)
    (hdis : Disjoint d S) :
    (∑ n ∈ S.powerset.filter (fun n => Z < primeSetProduct n),
       dForbiddenReducedBooleanCoreTerm q A H d n) =
      (∑ e ∈ S.powerset,
        finiteOmegaWeightReal e *
          (∑ B ∈ ((e.powerset.erase e).erase ∅),
            rowConstrainedMass (fixedQLowWeight q A H) H
              (primeSetProduct B) (primeSetProduct (e \ B)))) -
      rowWeightMass (fixedQLowWeight q A H) H *
        (∑ e ∈ S.powerset,
          finiteOmegaWeightReal e *
            (∑ B ∈ ((e.powerset.erase e).erase ∅),
              1 / ((primeSetProduct B : ℝ) *
                (primeSetProduct (e \ B) : ℝ)))) -
      (∑ e ∈ S.powerset.filter
        (fun e => primeSetProduct e ≤ Z),
        thalenFiniteOuterSourceTerm q A H e) := by
  calc
    _ = (∑ e ∈ S.powerset.filter (fun e => Z < primeSetProduct e),
      thalenFiniteOuterSourceTerm q A H e) := by
        apply Finset.sum_congr rfl
        intro n hn
        exact thalen_dForbidden_eq_finiteOuterSourceTerm
          (Finset.disjoint_of_subset_right (Finset.mem_powerset.mp (Finset.mem_filter.mp hn).1) hdis)
          (hact n (Finset.mem_filter.mp hn).1)
    _ = _ := thalen_finite_exterior_eq_rows_sub_density_sub_small q A H Z S

#print axioms thalen_decorated_finite_exterior_eq_rows_sub_density_sub_small

end PaperB.FixedQ
