import PaperB.Analytic.FixedBetaSublinear

namespace PaperB.Analytic

open Real

theorem const_mul_rpow_lt_one_is_sublinear
    {C theta eps : ℝ}
    (hC : 0 ≤ C) (htheta : theta < 1) (heps : 0 < eps) :
    ∃ W0 : ℝ, ∀ W : ℝ, W0 ≤ W → 1 ≤ W →
      C * W ^ theta ≤ eps * W := by
  by_cases hC0 : C = 0
  · refine ⟨1, ?_⟩
    intro W hW hW1
    rw [hC0, zero_mul]
    exact mul_nonneg heps.le (le_trans zero_le_one hW1)
  · have hCpos : 0 < C := lt_of_le_of_ne hC (Ne.symm hC0)
    have hepsC : 0 < eps / C := div_pos heps hCpos
    obtain ⟨W0, hW0⟩ :=
      rpow_lt_one_is_sublinear htheta hepsC
    refine ⟨W0, ?_⟩
    intro W hWW0 hW1
    have h := hW0 W hWW0 hW1
    have hmul := mul_le_mul_of_nonneg_left h hC
    calc
      C * W ^ theta
        ≤ C * ((eps / C) * W) := hmul
      _ = eps * W := by
        field_simp [ne_of_gt hCpos]

theorem fixedBeta_two_powers_const_sublinear
    {beta C1 C2 : ℝ}
    (hb0 : 0 < beta) (hb1 : beta < 1)
    (hC1 : 0 ≤ C1) (hC2 : 0 ≤ C2)
    {eps : ℝ} (heps : 0 < eps) :
    ∃ k : ℕ, 2 ≤ k ∧
      ∃ W0 : ℝ, ∀ W : ℝ, W0 ≤ W → 1 ≤ W →
        C1 * W ^ fixedBetaFirstExponent beta k ≤ eps * W ∧
        C2 * W ^ fixedBetaSecondExponent beta k ≤ eps * W := by
  obtain ⟨k, hk, hfirst, hsecond⟩ :=
    exists_fixedBeta_exponent_ledger hb0 hb1
  obtain ⟨W01, hW01⟩ :=
    const_mul_rpow_lt_one_is_sublinear hC1 hfirst heps
  obtain ⟨W02, hW02⟩ :=
    const_mul_rpow_lt_one_is_sublinear hC2 hsecond heps
  refine ⟨k, hk, max W01 W02, ?_⟩
  intro W hW hW1
  constructor
  · exact hW01 W (le_trans (le_max_left _ _) hW) hW1
  · exact hW02 W (le_trans (le_max_right _ _) hW) hW1

#print axioms const_mul_rpow_lt_one_is_sublinear
#print axioms fixedBeta_two_powers_const_sublinear

end PaperB.Analytic
