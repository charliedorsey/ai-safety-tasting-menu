import OrielLR.AsymB

/-!
# Oriel L/R — the Gate 3 Left and Right suppliers

Both theorems are conditional on exactly one named premise, `ShiftedKaratsuba`
(see `OrielLR/Hyp.lean`), and are stated against the ACTUAL source cutoff
`globalProperBooleanProductCutoff h = 2^{20(⌊(log h)^{2/3+1/100}⌋+1)}`.
-/

open Filter Topology
open OrielUpper.Mirror

namespace OrielUpper

lemma ev_small (k : ℕ) {c δ : ℝ} (hc : 0 < c) (hδ : 0 < δ) (K : ℝ) :
    ∀ᶠ ℓ : ℝ in atTop, K * ((ℓ + 2) ^ k * Real.exp (-(c * ℓ ^ δ))) ≤ 1 := by
  have h := (tendsto_poly_exp k hc hδ).const_mul K
  rw [mul_zero] at h
  exact h.eventually (Iic_mem_nhds one_pos)

lemma Vb_nonneg (h : ℕ) : 0 ≤ Vb h := by unfold Vb; positivity

lemma thH_pow8 {h : ℕ} (hh : 1 ≤ h) : thH h ^ 8 = (Real.log (h : ℝ) + 2) ^ (1 / 8 : ℝ) := by
  unfold thH
  rw [← Real.rpow_natCast, ← Real.rpow_mul (by linarith [logh_nonneg hh])]
  norm_num

lemma kV_nonneg {q : ℕ} (hq : 1 ≤ q) : 0 ≤ kV q := by
  unfold kV
  exact mul_nonneg (Real.exp_pos _).le (pow_nonneg (by linarith [cq_pos hq]) 7)

/-- All eventual requirements at once, pulled back to heights. -/
theorem eventual_bound {q : ℕ} (hq : 1 ≤ q) {cK Ck : ℝ} (hcK : 0 < cK) {eps : ℝ}
    (heps : 0 < eps) :
    ∃ H0 : ℕ, ∀ h : ℕ, H0 ≤ h →
      2 ≤ h ∧ GrowCond q h ∧ Vb h * Gfun q Ck cK (Real.log (h : ℝ)) ≤ eps * Real.log (h : ℝ) := by
  have hσ : (0 : ℝ) < h2BooleanSigma := by unfold h2BooleanSigma; norm_num
  have hσ4 : (1 / 4 : ℝ) < h2BooleanSigma := by unfold h2BooleanSigma; norm_num
  have hev : ∀ᶠ ℓ : ℝ in atTop,
      (48 * ℓ ^ (1 / 4 : ℝ) + Real.log (200 * (q : ℝ) ^ 2) ≤ ℓ ^ h2BooleanSigma) ∧
      ga q * ((ℓ + 2) ^ 2 * Real.exp (-(1 * ℓ ^ h2BooleanSigma))) ≤ 1 ∧
      gb q * ((ℓ + 2) ^ 3 * Real.exp (-(2 * ℓ ^ (1 / 4 : ℝ)))) ≤ 1 ∧
      gc q Ck * ((ℓ + 2) ^ 4 * Real.exp (-((27 * cK) * ℓ ^ (3 / 100 : ℝ)))) ≤ 1 ∧
      gd q Ck * ((ℓ + 2) ^ 4 * Real.exp (-(1 * ℓ ^ (1 / 4 : ℝ)))) ≤ 1 ∧
      kV q * (g0 q + 4) * (ℓ + 2) ^ (1 / 8 : ℝ) ≤ eps * ℓ := by
    refine (eventually_rpow_dom (by norm_num) hσ4 48 _).and ?_
    refine (ev_small 2 one_pos hσ _).and ?_
    refine (ev_small 3 two_pos (by norm_num) _).and ?_
    refine (ev_small 4 (by positivity) (by norm_num) _).and ?_
    refine (ev_small 4 one_pos (by norm_num) _).and ?_
    exact eventually_small_root heps
  obtain ⟨L0, hL0⟩ := eventually_atTop.mp hev
  refine ⟨⌈Real.exp L0⌉₊ + 2, fun h hH => ?_⟩
  have hh2 : 2 ≤ h := by omega
  have hh1 : 1 ≤ h := by omega
  have hhr : Real.exp L0 ≤ (h : ℝ) := by
    have := Nat.le_ceil (Real.exp L0)
    have : ((⌈Real.exp L0⌉₊ : ℕ) : ℝ) ≤ h := by exact_mod_cast (by omega : ⌈Real.exp L0⌉₊ ≤ h)
    linarith
  have hL : L0 ≤ Real.log (h : ℝ) := by
    rw [Real.le_log_iff_exp_le (by exact_mod_cast (show 0 < h by omega))]
    exact hhr
  obtain ⟨c0, c1, c2, c3, c4, c5⟩ := hL0 _ hL
  refine ⟨hh2, c0, ?_⟩
  set ℓ := Real.log (h : ℝ)
  have hG : Gfun q Ck cK ℓ ≤ 4 + g0 q := by unfold Gfun; linarith
  have hg0 : 0 ≤ g0 q := by unfold g0 gPr; positivity
  have hV := Vb_le hq hh1
  have hθ := thH_ge_one hh1
  have h78 : thH h ^ 7 ≤ thH h ^ 8 := pow_le_pow_right₀ hθ (by norm_num)
  rw [thH_pow8 hh1] at h78
  have hkV := kV_nonneg hq
  calc Vb h * Gfun q Ck cK ℓ ≤ Vb h * (4 + g0 q) :=
        mul_le_mul_of_nonneg_left hG (Vb_nonneg h)
    _ ≤ (kV q * thH h ^ 7) * (4 + g0 q) := mul_le_mul_of_nonneg_right hV (by linarith)
    _ ≤ (kV q * (ℓ + 2) ^ (1 / 8 : ℝ)) * (4 + g0 q) := by
        apply mul_le_mul_of_nonneg_right _ (by linarith)
        exact mul_le_mul_of_nonneg_left h78 hkV
    _ = kV q * (g0 q + 4) * (ℓ + 2) ^ (1 / 8 : ℝ) := by ring
    _ ≤ eps * ℓ := c5

/-- **Gate 3, Left region** (conditional on `ShiftedKaratsuba` only), for the actual
source cutoff `globalProperBooleanProductCutoff`. -/
theorem left_complete_region_sublog (hK : ShiftedKaratsuba) :
    virelleR0061CompleteRegionSublog globalProperBooleanProductCutoff virelleR0037Left := by
  obtain ⟨cK, Ck, hcK, hCk, hKB⟩ := hK.elim
  intro q hq _ eps heps
  obtain ⟨H0, hH0⟩ := eventual_bound (q := q) hq (Ck := Ck) hcK heps
  refine ⟨H0, fun a h _ _ _ hH => ?_⟩
  obtain ⟨hh2, hgc, hfin⟩ := hH0 h hH
  obtain ⟨n1, n2, n3, -⟩ := nat_conds hq (Ycond hq hgc)
  have hm := left_master hcK hCk hKB globalProperBooleanProductCutoff (a := a) hq (by omega)
    (Yv_cube h) n1 n2 (Dv_ge_one h) n3 (Lbv_spec h)
  exact hm.trans ((mul_le_mul_of_nonneg_left (slice_G hq hh2 hcK hCk hgc) (Vb_nonneg h)).trans
    hfin)

/-- **Gate 3, Right region** (conditional on `ShiftedKaratsuba` only), for the actual
source cutoff.  Proved through its own orientation (`right_slice`), not by reflection. -/
theorem right_complete_region_sublog (hK : ShiftedKaratsuba) :
    virelleR0061CompleteRegionSublog globalProperBooleanProductCutoff virelleR0037Right := by
  obtain ⟨cK, Ck, hcK, hCk, hKB⟩ := hK.elim
  intro q hq _ eps heps
  obtain ⟨H0, hH0⟩ := eventual_bound (q := q) hq (Ck := Ck) hcK heps
  refine ⟨H0, fun a h _ _ _ hH => ?_⟩
  obtain ⟨hh2, hgc, hfin⟩ := hH0 h hH
  obtain ⟨n1, n2, n3, -⟩ := nat_conds hq (Ycond hq hgc)
  have hm := right_master hcK hCk hKB globalProperBooleanProductCutoff (a := a) hq (by omega)
    (Yv_cube h) n1 n2 (Dv_ge_one h) n3 (Lbv_spec h)
  exact hm.trans ((mul_le_mul_of_nonneg_left (slice_G hq hh2 hcK hCk hgc) (Vb_nonneg h)).trans
    hfin)

end OrielUpper
