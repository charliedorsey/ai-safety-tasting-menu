import Mathlib

/-!
# Local tools: character sums, stationary-phase averaging, Weyl differencing, fibre counts

Everything here is source-neutral and holds in `ZMod N` for an arbitrary modulus `N`.

* `sum_stdAddChar_mul` — complete additive character sum `∑_t ψ(c t) = N·[c = 0]`.
* `quadSum` — the quadratic sum `G(α, β) = ∑_t ψ(α t + β t²)`.
* `normSq_quadSum_le` — **Weyl differencing**: `‖G(α,β)‖² ≤ N · #{u | 2βu = 0}`.
* `shiftUnit` — for `h³ = 0`, the unit `1 + h t` with inverse `1 - h t + h² t²`.
* `averaging_identity` — **second-order stationary-phase averaging**: for any weight `w` on
  units invariant under `x ↦ x (1 + h t)`,
  `N · ∑ₓ w x ψ(b x + a x⁻¹) = ∑ₓ w x ψ(b x + a x⁻¹) · G(h (b x - a x⁻¹), h² a x⁻¹)`.
* `card_fiber_castHom` — fibres of `ZMod N → ZMod d` (`d ∣ N`) have `N / d` elements.
-/

open Finset ComplexConjugate

namespace GenKloosterman

local notation "ψ" => ZMod.stdAddChar

section Char
variable {N : ℕ} [NeZero N]

/-- Complete additive character sums. -/
theorem sum_stdAddChar_mul (c : ZMod N) :
    ∑ t : ZMod N, ψ (c * t) = if c = 0 then (N : ℂ) else 0 := by
  split_ifs with hc
  · subst hc; simp
  · have hne : (ZMod.stdAddChar (N := N)).mulShift c ≠ 1 :=
      ZMod.isPrimitive_stdAddChar N hc
    simpa [AddChar.mulShift_apply] using AddChar.sum_eq_zero_of_ne_one hne

theorem norm_stdAddChar (z : ZMod N) : ‖ψ z‖ = 1 := by
  rw [ZMod.stdAddChar_apply]; exact Circle.norm_coe _

/-- The quadratic exponential sum `G(α, β) = ∑_t ψ(α t + β t²)`. -/
noncomputable def quadSum (α β : ZMod N) : ℂ := ∑ t : ZMod N, ψ (α * t + β * t ^ 2)

/-- Exact Weyl-differencing identity. -/
theorem quadSum_mul_conj (α β : ZMod N) :
    quadSum α β * conj (quadSum α β) =
      (N : ℂ) * ∑ u : ZMod N, if 2 * β * u = 0 then ψ (α * u + β * u ^ 2) else 0 := by
  unfold quadSum
  rw [map_sum, sum_mul_sum]
  have step : ∀ t s : ZMod N, ψ (α * t + β * t ^ 2) * conj (ψ (α * s + β * s ^ 2)) =
      ψ (α * (t - s) + β * (t - s) ^ 2) * ψ ((2 * β * (t - s)) * s) := by
    intro t s
    rw [← AddChar.map_neg_eq_conj, ← AddChar.map_add_eq_mul, ← AddChar.map_add_eq_mul]
    congr 1; ring
  simp_rw [step]
  rw [Finset.sum_comm]
  -- reindex the outer variable `t = s + u`
  have hre : ∀ s : ZMod N, ∑ t : ZMod N, ψ (α * (t - s) + β * (t - s) ^ 2) *
      ψ ((2 * β * (t - s)) * s) =
      ∑ u : ZMod N, ψ (α * u + β * u ^ 2) * ψ ((2 * β * u) * s) := by
    intro s
    exact Fintype.sum_equiv (Equiv.subRight s) _ _ (fun t => rfl)
  simp_rw [hre]
  rw [Finset.sum_comm, mul_sum]
  refine sum_congr rfl fun u _ => ?_
  rw [← mul_sum, sum_stdAddChar_mul]
  split_ifs <;> ring

/-- **Weyl differencing bound** `‖G(α,β)‖² ≤ N · #{u | 2βu = 0}`. -/
theorem normSq_quadSum_le (α β : ZMod N) :
    ‖quadSum α β‖ ^ 2 ≤ (N : ℝ) * #{u : ZMod N | 2 * β * u = 0} := by
  have h := congrArg (‖·‖) (quadSum_mul_conj α β)
  rw [norm_mul, Complex.norm_conj, ← sq, norm_mul, Complex.norm_natCast] at h
  rw [h]
  gcongr
  calc ‖∑ u : ZMod N, if 2 * β * u = 0 then ψ (α * u + β * u ^ 2) else 0‖
      ≤ ∑ u : ZMod N, ‖if 2 * β * u = 0 then ψ (α * u + β * u ^ 2) else 0‖ := norm_sum_le _ _
    _ = ∑ u : ZMod N, if 2 * β * u = 0 then (1 : ℝ) else 0 := by
        refine sum_congr rfl fun u _ => ?_
        split_ifs <;> simp
    _ = #{u : ZMod N | 2 * β * u = 0} := by
        rw [← sum_boole]

theorem norm_quadSum_le (α β : ZMod N) :
    ‖quadSum α β‖ ≤ Real.sqrt ((N : ℝ) * #{u : ZMod N | 2 * β * u = 0}) :=
  Real.le_sqrt_of_sq_le (normSq_quadSum_le α β)

/-- With `β = 0` the quadratic sum is the complete linear sum. -/
theorem quadSum_zero_right (α : ZMod N) :
    quadSum α 0 = if α = 0 then (N : ℂ) else 0 := by
  unfold quadSum
  simp only [zero_mul, add_zero]
  exact sum_stdAddChar_mul α

end Char

/-! ## Stationary-phase averaging -/

section Averaging
variable {N : ℕ} [NeZero N]

/-- For `h³ = 0`, `1 + h t` is a unit with inverse `1 - h t + h² t²`. -/
def shiftUnit (h : ZMod N) (hh : h ^ 3 = 0) (t : ZMod N) : (ZMod N)ˣ where
  val := 1 + h * t
  inv := 1 - h * t + h ^ 2 * t ^ 2
  val_inv := by linear_combination t ^ 3 * hh
  inv_val := by linear_combination t ^ 3 * hh

/-- **Second-order stationary-phase averaging identity.** -/
theorem averaging_identity (h : ZMod N) (hh : h ^ 3 = 0) (a b : ZMod N)
    (w : (ZMod N)ˣ → ℂ) (hw : ∀ t x, w (x * shiftUnit h hh t) = w x) :
    (N : ℂ) * ∑ x : (ZMod N)ˣ, w x * ψ (b * (x : ZMod N) + a * ((x⁻¹ : (ZMod N)ˣ) : ZMod N)) =
      ∑ x : (ZMod N)ˣ, w x * ψ (b * (x : ZMod N) + a * ((x⁻¹ : (ZMod N)ˣ) : ZMod N)) *
        quadSum (h * (b * (x : ZMod N) - a * ((x⁻¹ : (ZMod N)ˣ) : ZMod N))) (h ^ 2 * (a * ((x⁻¹ : (ZMod N)ˣ) : ZMod N))) := by
  have hshift : ∀ t, ∑ x : (ZMod N)ˣ, w x * ψ (b * (x : ZMod N) + a * ((x⁻¹ : (ZMod N)ˣ) : ZMod N)) =
      ∑ x : (ZMod N)ˣ, w x * ψ (b * (x : ZMod N) + a * ((x⁻¹ : (ZMod N)ˣ) : ZMod N)) *
        ψ (h * (b * (x : ZMod N) - a * ((x⁻¹ : (ZMod N)ˣ) : ZMod N)) * t +
          h ^ 2 * (a * ((x⁻¹ : (ZMod N)ˣ) : ZMod N)) * t ^ 2) := by
    intro t
    rw [← Fintype.sum_equiv (Equiv.mulRight (shiftUnit h hh t))
      (fun x => w (x * shiftUnit h hh t) *
        ψ (b * ((x * shiftUnit h hh t : (ZMod N)ˣ) : ZMod N) +
          a * (((x * shiftUnit h hh t)⁻¹ : (ZMod N)ˣ) : ZMod N)))
      (fun x => w x * ψ (b * (x : ZMod N) + a * ((x⁻¹ : (ZMod N)ˣ) : ZMod N))) (fun _ => rfl)]
    refine sum_congr rfl fun x _ => ?_
    rw [hw, mul_assoc, ← AddChar.map_add_eq_mul]
    congr 2
    simp only [mul_inv_rev, Units.val_mul, shiftUnit]
    -- `(1 - h t + h² t²) = (1 + h t)⁻¹`
    change b * (x * (1 + h * t)) + a * ((1 - h * t + h ^ 2 * t ^ 2) * ((x⁻¹ : (ZMod N)ˣ) : ZMod N)) = _
    ring
  have hsum : (N : ℂ) * ∑ x : (ZMod N)ˣ, w x * ψ (b * (x : ZMod N) + a * ((x⁻¹ : (ZMod N)ˣ) : ZMod N)) =
      ∑ _t : ZMod N, ∑ x : (ZMod N)ˣ, w x * ψ (b * (x : ZMod N) + a * ((x⁻¹ : (ZMod N)ˣ) : ZMod N)) := by
    rw [sum_const, card_univ, ZMod.card, nsmul_eq_mul]
  rw [hsum]
  rw [Finset.sum_congr rfl (fun t _ => hshift t)]
  rw [Finset.sum_comm]
  refine sum_congr rfl fun x _ => ?_
  rw [← mul_sum]
  rfl

end Averaging

/-! ## Fibre counts for reduction maps -/

section Fibre

/-- Fibres of the reduction `ZMod N → ZMod d` have exactly `N / d` elements. -/
theorem card_fiber_castHom {N d : ℕ} [NeZero N] (hd : d ∣ N) (z : ZMod d) :
    #{x : ZMod N | ZMod.castHom hd (ZMod d) x = z} = N / d := by
  classical
  have hd0 : d ≠ 0 := fun h => NeZero.ne N (Nat.eq_zero_of_zero_dvd (h ▸ hd))
  have : NeZero d := ⟨hd0⟩
  let f : ZMod N →+ ZMod d := (ZMod.castHom hd (ZMod d)).toAddMonoidHom
  have hsurj := ZMod.castHom_surjective hd
  have hall : ∀ y : ZMod d, #{x : ZMod N | f x = y} = #{x : ZMod N | f x = 0} := fun y =>
    AddMonoidHom.card_fiber_eq_of_mem_range f (hsurj y) (hsurj 0)
  have htot : ∑ y : ZMod d, #{x : ZMod N | f x = y} = N := by
    rw [← card_eq_sum_card_fiberwise (fun x _ => mem_univ (f x))]
    simp
  simp_rw [hall] at htot
  rw [sum_const, card_univ, ZMod.card, smul_eq_mul] at htot
  change #{x : ZMod N | f x = z} = N / d
  rw [hall z]
  rw [mul_comm] at htot
  exact (Nat.div_eq_of_eq_mul_left (Nat.pos_of_ne_zero hd0) htot.symm).symm

end Fibre

end GenKloosterman
