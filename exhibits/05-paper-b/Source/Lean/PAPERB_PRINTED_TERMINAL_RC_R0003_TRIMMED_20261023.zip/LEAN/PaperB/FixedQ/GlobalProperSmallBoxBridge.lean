import PaperB.FixedQ.GlobalProperProductSplit
import PaperB.FixedQ.H2ProperSmallProductRate
import PaperB.FixedQ.H3DecoratedAnalyticShell

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def globalProperSmallAbsPairTerm
    (q a h Z : ℕ) (dn : Finset ℕ × Finset ℕ) : ℝ :=
  let d := dn.1
  let n := dn.2
  if hd : d ∈ (decoratedHeightPrimeSet q h).powerset then
    if primeSetProduct n ≤ Z then
      finiteVWeightReal h d *
        |dForbiddenReducedBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) d n|
    else 0
  else 0

noncomputable def globalProperSmallAbsReindexMajorant
    (q a h Z : ℕ)
    (x : (Finset ℕ × Finset ℕ) ⊕ Finset ℕ) : ℝ :=
  match x with
  | Sum.inl dn => globalProperSmallAbsPairTerm q a h Z dn
  | Sum.inr _ => 0

lemma globalProperSmallAbsPairTerm_nonneg
    (q a h Z : ℕ) (dn : Finset ℕ × Finset ℕ) :
    0 ≤ globalProperSmallAbsPairTerm q a h Z dn := by
  rcases dn with ⟨d,n⟩
  unfold globalProperSmallAbsPairTerm
  dsimp
  split_ifs with hd hm
  · have hv0 : 0 ≤ finiteVWeightReal h d := by
      apply finiteVWeightReal_nonneg_of_active
      exact decoratedHeightPrimeSet_active (Finset.mem_powerset.mp hd)
    exact mul_nonneg hv0 (abs_nonneg _)
  · exact le_rfl
  · exact le_rfl

lemma globalProperSmallAbsReindexMajorant_nonneg
    (q a h Z : ℕ)
    (x : (Finset ℕ × Finset ℕ) ⊕ Finset ℕ) :
    0 ≤ globalProperSmallAbsReindexMajorant q a h Z x := by
  cases x with
  | inl dn => exact globalProperSmallAbsPairTerm_nonneg q a h Z dn
  | inr e => simp [globalProperSmallAbsReindexMajorant]

lemma abs_globalProperSmallTerm_le_reindexMajorant
    {q a h Z : ℕ} (hh : 0 < h) (e : Finset ℕ) :
    |(globalProperSmallSet h Z).indicator
        (decoratedAnalyticPerE q a h) e| ≤
      globalProperSmallAbsReindexMajorant q a h Z
        (decoratedAnalyticSignedReindexKey q h e) := by
  classical
  by_cases hsmall : e ∈ globalProperSmallSet h Z
  · rw [Set.indicator_of_mem hsmall]
    by_cases hA : ∀ p ∈ e, activeHighPrime q p
    · let d := heightPrimePart h e
      let n := e \ d
      have hdsub : d ⊆ decoratedHeightPrimeSet q h := by
        dsimp [d]
        exact heightPrimePart_subset_decoratedHeightPrimeSet_of_active hh hA
      have hdmem : d ∈ (decoratedHeightPrimeSet q h).powerset :=
        Finset.mem_powerset.mpr hdsub
      have hdis : Disjoint d n := by
        dsimp [n]
        exact Finset.disjoint_sdiff
      have hn : n ∈ activeOrdinaryTwoDimensionalSet q
          (h / primeSetProduct d) := by
        have h0 := decorated_nonheight_activeOrdinary
          (q := q) (h := h) (e := e) hA
        simpa [d, n, decoratedReducedHeight, decoratedHeightProduct] using h0
      have hm : primeSetProduct n ≤ Z := by
        simpa [globalProperSmallSet, d, n] using hsmall
      have hmain :=
        decoratedAnalyticPerE_eq_height_weight_mul_boolean
          (q := q) (a := a) (h := h) (e := e) hA
      have hcore :
          ordinaryBooleanCoreTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) n =
            finiteOmegaWeightReal n *
              ordinaryBooleanInteriorDiscrepancy
                (fixedQLowWeight q
                  (decoratedReducedAnchor q a (primeSetProduct d))
                  (h / primeSetProduct d))
                (h / primeSetProduct d) n := by
        rw [ordinaryBooleanCoreTerm, Set.indicator_of_mem hn]
      have hforbid :
          dForbiddenReducedBooleanCoreTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) d n =
            ordinaryBooleanCoreTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) n := by
        simp [dForbiddenReducedBooleanCoreTerm, hdis]
      rw [decoratedAnalyticSignedReindexKey, if_pos hA]
      simp only [globalProperSmallAbsReindexMajorant]
      change |decoratedAnalyticPerE q a h e| ≤
        globalProperSmallAbsPairTerm q a h Z (d,n)
      unfold globalProperSmallAbsPairTerm
      dsimp
      rw [if_pos hdmem, if_pos hm]
      have hmain' :
          decoratedAnalyticPerE q a h e =
            finiteVWeightReal h d * finiteOmegaWeightReal n *
              ordinaryBooleanInteriorDiscrepancy
                (fixedQLowWeight q
                  (decoratedReducedAnchor q a (primeSetProduct d))
                  (h / primeSetProduct d))
                (h / primeSetProduct d) n := by
        simpa [d, n, decoratedHeightProduct, decoratedReducedHeight] using hmain
      rw [hmain', hforbid, hcore]
      have hv0 : 0 ≤ finiteVWeightReal h d := by
        apply finiteVWeightReal_nonneg_of_active
        exact decoratedHeightPrimeSet_active hdsub
      simp [abs_mul, abs_of_nonneg hv0, mul_assoc]
    · rw [decoratedAnalyticSignedReindexKey, if_neg hA]
      have hz := decoratedAnalyticPerE_eq_zero_of_not_all_active
        (q := q) (a := a) (h := h) (e := e) hA
      simp [globalProperSmallAbsReindexMajorant, hz]
  · simp [Set.indicator, hsmall]
    exact globalProperSmallAbsReindexMajorant_nonneg q a h Z _

theorem summable_globalProperSmallAbsPairTerm
    {q a h Z : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    Summable (globalProperSmallAbsPairTerm q a h Z) := by
  rw [summable_prod_of_nonneg
    (fun dn => globalProperSmallAbsPairTerm_nonneg q a h Z dn)]
  constructor
  · intro d
    by_cases hd : d ∈ (decoratedHeightPrimeSet q h).powerset
    · have hHpos := decoratedReducedHeight_pos_of_mem hh hd
      have hHpar := decoratedReducedHeight_parity_of_mem h2 hd
      have hs := summable_abs_ordinaryBooleanCoreTerm
        (q := q)
        (a := decoratedReducedAnchor q a (primeSetProduct d))
        (h := h / primeSetProduct d)
        hq hHpos hHpar
      have hforbid := hs.of_nonneg_of_le
        (fun n => abs_nonneg _)
        (fun n => abs_dForbiddenReducedBooleanCoreTerm_le q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) d n)
      have hv0 : 0 ≤ finiteVWeightReal h d := by
        apply finiteVWeightReal_nonneg_of_active
        exact decoratedHeightPrimeSet_active (Finset.mem_powerset.mp hd)
      have hmul := hforbid.mul_left (finiteVWeightReal h d)
      apply hmul.of_nonneg_of_le
        (fun n => globalProperSmallAbsPairTerm_nonneg q a h Z (d,n))
      intro n
      unfold globalProperSmallAbsPairTerm
      dsimp
      rw [if_pos hd]
      by_cases hm : primeSetProduct n ≤ Z
      · rw [if_pos hm]
      · rw [if_neg hm]
        exact mul_nonneg hv0 (abs_nonneg _)
    · simp [globalProperSmallAbsPairTerm, hd]
  · apply summable_of_hasFiniteSupport
    refine (decoratedHeightPrimeSet q h).powerset.finite_toSet.subset ?_
    intro d hd
    by_contra hdmem
    have hnotSub : ¬ d ⊆ decoratedHeightPrimeSet q h := by
      simpa using hdmem
    have hz : (∑' n : Finset ℕ,
        globalProperSmallAbsPairTerm q a h Z (d,n)) = 0 := by
      simp [globalProperSmallAbsPairTerm, hnotSub]
    exact hd hz

theorem summable_globalProperSmallAbsReindexMajorant
    {q a h Z : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    Summable (globalProperSmallAbsReindexMajorant q a h Z) := by
  have hp := summable_globalProperSmallAbsPairTerm
    (q := q) (a := a) (h := h) (Z := Z) hq hh h2
  apply (Sum.inl_injective.summable_iff ?_).mp
  · simpa [Function.comp_def, globalProperSmallAbsReindexMajorant] using hp
  · intro x hx
    cases x with
    | inl dn => exact (hx ⟨dn, rfl⟩).elim
    | inr e => simp [globalProperSmallAbsReindexMajorant]

noncomputable def globalProperDecoratedSmallMajorant
    (q a h Z : ℕ) : ℝ :=
  ∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
    finiteVWeightReal h d *
      h2BooleanProperCoreSmallMajorant q
        (decoratedReducedAnchor q a (primeSetProduct d))
        (h / primeSetProduct d) Z

theorem tsum_globalProperSmallAbsReindexMajorant_le
    {q a h Z : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    (∑' x, globalProperSmallAbsReindexMajorant q a h Z x) ≤
      globalProperDecoratedSmallMajorant q a h Z := by
  have hp := summable_globalProperSmallAbsPairTerm
    (q := q) (a := a) (h := h) (Z := Z) hq hh h2
  have hInl : Summable
      (globalProperSmallAbsReindexMajorant q a h Z ∘ Sum.inl) := by
    simpa [Function.comp_def, globalProperSmallAbsReindexMajorant] using hp
  have hInr : Summable
      (globalProperSmallAbsReindexMajorant q a h Z ∘ Sum.inr) := by
    simp [Function.comp_def, globalProperSmallAbsReindexMajorant]
  rw [Summable.tsum_sum hInl hInr]
  simp only [globalProperSmallAbsReindexMajorant, tsum_zero, add_zero]
  rw [hp.tsum_prod]
  unfold globalProperDecoratedSmallMajorant
  rw [tsum_eq_sum (s := (decoratedHeightPrimeSet q h).powerset)]
  · apply Finset.sum_le_sum
    intro d hd
    have hv0 : 0 ≤ finiteVWeightReal h d := by
      apply finiteVWeightReal_nonneg_of_active
      exact decoratedHeightPrimeSet_active (Finset.mem_powerset.mp hd)
    have hsCore : Summable (fun n : Finset ℕ =>
        |ordinaryBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) n|) := by
      have hHpos := decoratedReducedHeight_pos_of_mem hh hd
      have hHpar := decoratedReducedHeight_parity_of_mem h2 hd
      exact summable_abs_ordinaryBooleanCoreTerm hq hHpos hHpar
    have hpoint : ∀ n : Finset ℕ,
        globalProperSmallAbsPairTerm q a h Z (d,n) ≤
          finiteVWeightReal h d *
            (if n ∈ h2BooleanGlobalSmallSets q
                (h / primeSetProduct d) Z then
              |ordinaryBooleanCoreTerm q
                (decoratedReducedAnchor q a (primeSetProduct d))
                (h / primeSetProduct d) n|
             else 0) := by
      intro n
      unfold globalProperSmallAbsPairTerm
      dsimp
      rw [if_pos hd]
      by_cases hm : primeSetProduct n ≤ Z
      · rw [if_pos hm]
        by_cases hn : n ∈ activeOrdinaryTwoDimensionalSet q
            (h / primeSetProduct d)
        · by_cases hne : n.Nonempty
          · have hsmall : n ∈ h2BooleanGlobalSmallSets q
                (h / primeSetProduct d) Z :=
              h2BooleanGlobalSmallSets_of_active_le hn hne hm
            rw [if_pos hsmall]
            have hdisjBound :=
              abs_dForbiddenReducedBooleanCoreTerm_le q
                (decoratedReducedAnchor q a (primeSetProduct d))
                (h / primeSetProduct d) d n
            exact mul_le_mul_of_nonneg_left hdisjBound hv0
          · have hn0 : n = ∅ := Finset.not_nonempty_iff_eq_empty.mp hne
            subst n
            have hcore0 :
                ordinaryBooleanCoreTerm q
                  (decoratedReducedAnchor q a (primeSetProduct d))
                  (h / primeSetProduct d) ∅ = 0 := by
              exact ordinaryBooleanCoreTerm_empty q
                (decoratedReducedAnchor q a (primeSetProduct d))
                (h / primeSetProduct d)
            have hforbid0 :
                dForbiddenReducedBooleanCoreTerm q
                  (decoratedReducedAnchor q a (primeSetProduct d))
                  (h / primeSetProduct d) d ∅ = 0 := by
              simp [dForbiddenReducedBooleanCoreTerm, hcore0]
            rw [hforbid0, abs_zero, mul_zero]
            positivity
        · have hcore0 :
              ordinaryBooleanCoreTerm q
                (decoratedReducedAnchor q a (primeSetProduct d))
                (h / primeSetProduct d) n = 0 := by
            simp [ordinaryBooleanCoreTerm, Set.indicator, hn]
          have hforbid0 :
              dForbiddenReducedBooleanCoreTerm q
                (decoratedReducedAnchor q a (primeSetProduct d))
                (h / primeSetProduct d) d n = 0 := by
            simp [dForbiddenReducedBooleanCoreTerm, hcore0]
          rw [hforbid0, abs_zero, mul_zero]
          positivity
      · rw [if_neg hm]
        positivity
    have htargetSummable : Summable (fun n : Finset ℕ =>
        finiteVWeightReal h d *
          (if n ∈ h2BooleanGlobalSmallSets q
              (h / primeSetProduct d) Z then
            |ordinaryBooleanCoreTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) n|
           else 0)) := by
      apply Summable.mul_left
      apply summable_of_hasFiniteSupport
      refine (h2BooleanGlobalSmallSets q
        (h / primeSetProduct d) Z).finite_toSet.subset ?_
      intro n hn
      by_contra hnot
      have hnot' : n ∉ h2BooleanGlobalSmallSets q
          (h / primeSetProduct d) Z := by simpa using hnot
      exact hn (by simp [hnot'])
    have hpairSummable : Summable (fun n =>
        globalProperSmallAbsPairTerm q a h Z (d,n)) := by
      have hrows := (summable_prod_of_nonneg
        (fun dn => globalProperSmallAbsPairTerm_nonneg q a h Z dn)).mp hp
      exact hrows.1 d
    calc
      (∑' n : Finset ℕ, globalProperSmallAbsPairTerm q a h Z (d,n))
        ≤ ∑' n : Finset ℕ,
            finiteVWeightReal h d *
              (if n ∈ h2BooleanGlobalSmallSets q
                  (h / primeSetProduct d) Z then
                |ordinaryBooleanCoreTerm q
                  (decoratedReducedAnchor q a (primeSetProduct d))
                  (h / primeSetProduct d) n|
               else 0) :=
          Summable.tsum_le_tsum hpoint hpairSummable htargetSummable
      _ = finiteVWeightReal h d *
          h2BooleanProperCoreSmallMajorant q
            (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d) Z := by
          rw [tsum_mul_left]
          unfold h2BooleanProperCoreSmallMajorant
          rw [tsum_eq_sum (s := h2BooleanGlobalSmallSets q
            (h / primeSetProduct d) Z)]
          · simp
          · intro n hn
            simp [hn]
  · intro d hd
    simp [globalProperSmallAbsPairTerm, hd]

theorem abs_globalProperSmallAnalytic_le_decoratedMajorant
    {q a h Z : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    |globalProperSmallAnalytic q a h Z| ≤
      globalProperDecoratedSmallMajorant q a h Z := by
  have hs := summable_global_decoratedAnalyticPerE
    (q := q) (a := a)
    (r := PaperB.Closure.reflectedResidue q (a+h))
    hq hh h2
    (PaperB.Closure.reflected_coprime_equiv hq (Nat.ModEq.refl _))
  have hsource :=
    hs.indicator (globalProperSmallSet h Z)
  have htarget := summable_globalProperSmallAbsReindexMajorant
    (q := q) (a := a) (h := h) (Z := Z) hq hh h2
  have hcompare :
      (∑' e : Finset ℕ,
        |(globalProperSmallSet h Z).indicator
          (decoratedAnalyticPerE q a h) e|) ≤
      ∑' x, globalProperSmallAbsReindexMajorant q a h Z x := by
    apply hsource.norm.tsum_le_tsum_of_inj
      (decoratedAnalyticSignedReindexKey q h)
      (decoratedAnalyticSignedReindexKey_injective q h)
    · intro x hx
      exact globalProperSmallAbsReindexMajorant_nonneg q a h Z x
    · intro e
      simpa [Real.norm_eq_abs] using
        abs_globalProperSmallTerm_le_reindexMajorant
          (q := q) (a := a) (h := h) (Z := Z) hh e
    · exact htarget
  unfold globalProperSmallAnalytic
  calc
    |∑' e : Finset ℕ,
      (globalProperSmallSet h Z).indicator
        (decoratedAnalyticPerE q a h) e|
      ≤ ∑' e : Finset ℕ,
        |(globalProperSmallSet h Z).indicator
          (decoratedAnalyticPerE q a h) e| := by
          simpa [Real.norm_eq_abs] using norm_tsum_le_tsum_norm hsource.norm
    _ ≤ ∑' x, globalProperSmallAbsReindexMajorant q a h Z x := hcompare
    _ ≤ globalProperDecoratedSmallMajorant q a h Z :=
      tsum_globalProperSmallAbsReindexMajorant_le hq hh h2

#print axioms abs_globalProperSmallAnalytic_le_decoratedMajorant

end PaperB.FixedQ
