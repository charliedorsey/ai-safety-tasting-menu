import GoldC.QuillonKlComposite
import GoldC.QuillonSawDFT

/-!
# Quillon CSC3 F2: completion of incomplete inverse sums

For `s ≥ 2`, an interval `(N, M]` and `c : ZMod s`:

    ‖Σ_{N<n≤M, (n,s)=1} e(c n̄/s)‖ ≤ Kmax · ((M − N)/s + 1 + log s),

for any `Kmax ≥ ‖K_s(c, b)‖` over all `b`. Combined with `K_squarefree_bound`, this is the W′
off-diagonal input. It is exact Fourier analysis on `ZMod s` plus a geometric-series bound (Jordan);
there is no truncation.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonCompletion

open GoldC.QuillonKl

variable {s : ℕ} [NeZero s]

local notation "ψ" => (ZMod.stdAddChar : AddChar (ZMod s) ℂ)

lemma K_symm (a b : ZMod s) : K s a b = K s b a := by
  unfold K
  refine Fintype.sum_equiv (Equiv.inv _) _ _ fun x => ?_
  simp only [Equiv.inv_apply, inv_inv]
  congr 1; ring

lemma orth (t : ZMod s) : ∑ x : ZMod s, ψ (x * t) = if t = 0 then (s : ℂ) else 0 := by
  rw [AddChar.sum_mulShift t (ZMod.isPrimitive_stdAddChar s)]
  simp [ZMod.card]

/-- Finite Fourier inversion on `ZMod s`. -/
lemma fourier_inv (f : ZMod s → ℂ) (x : ZMod s) :
    f x = (1 / (s : ℂ)) * ∑ b : ZMod s, (∑ y : ZMod s, f y * ψ (-(b * y))) * ψ (b * x) := by
  have hs : (s : ℂ) ≠ 0 := by exact_mod_cast NeZero.ne s
  have : ∑ b : ZMod s, (∑ y : ZMod s, f y * ψ (-(b * y))) * ψ (b * x) =
      ∑ y : ZMod s, f y * ∑ b : ZMod s, ψ (b * (x - y)) := by
    simp_rw [Finset.sum_mul]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun y _ => ?_
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun b _ => ?_
    rw [mul_assoc, ← AddChar.map_add_eq_mul]; congr 2; ring
  rw [this]
  simp_rw [orth, sub_eq_zero]
  rw [Finset.sum_eq_single x]
  · simp; field_simp
  · intro y _ hy; simp [Ne.symm hy]
  · simp

/-- The Fourier transform of `1_{unit}(y)·ψ(c y⁻¹)` is a Kloosterman sum. -/
lemma hat_eq_K (c b : ZMod s) :
    ∑ y : ZMod s, (if IsUnit y then ψ (c * y⁻¹) else 0) * ψ (-(b * y)) = K s (-b) c := by
  unfold K
  simp_rw [ite_mul, zero_mul]
  rw [← Finset.sum_filter]
  refine Finset.sum_bij' (fun y hy => (Finset.mem_filter.1 hy).2.unit)
    (fun x _ => (x : ZMod s)) ?_ ?_ ?_ ?_ ?_
  · intro y _; exact Finset.mem_univ _
  · intro x _; exact Finset.mem_filter.2 ⟨Finset.mem_univ _, x.isUnit⟩
  · intro y hy; simp
  · intro x _; ext; simp
  · intro y hy
    rw [← AddChar.map_add_eq_mul]
    congr 1
    have hu := (Finset.mem_filter.1 hy).2
    simp only [IsUnit.unit_spec]
    rw [show ((hu.unit⁻¹ : (ZMod s)ˣ) : ZMod s) = y⁻¹ by
      rw [← ZMod.inv_coe_unit, IsUnit.unit_spec]]
    ring

/-- **Completion identity.** -/
theorem completion (c : ZMod s) (I : Finset ℕ) :
    ∑ n ∈ I, (if IsUnit (n : ZMod s) then ψ (c * (n : ZMod s)⁻¹) else 0) =
      (1 / (s : ℂ)) * ∑ b : ZMod s, K s (-b) c * ∑ n ∈ I, ψ (b * n) := by
  set f : ZMod s → ℂ := fun y => if IsUnit y then ψ (c * y⁻¹) else 0
  have hf : ∀ n : ℕ, (if IsUnit (n : ZMod s) then ψ (c * (n : ZMod s)⁻¹) else 0) = f n := fun n => rfl
  simp_rw [hf]
  conv_lhs => arg 2; ext n; rw [fourier_inv f (n : ZMod s)]
  rw [← Finset.mul_sum]
  congr 1
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun b _ => ?_
  rw [← Finset.mul_sum, hat_eq_K]

/-! ## Geometric-series bound and the final incomplete-sum estimate -/

lemma psi_eq_zeta_pow (b : ZMod s) : ψ b = GoldC.QuillonSawDFT.zeta s ^ b.val := by
  rw [ZMod.stdAddChar_apply, ZMod.toCircle_apply]
  unfold GoldC.QuillonSawDFT.zeta
  rw [← Complex.exp_nat_mul]
  congr 1; ring

lemma norm_psi_sub_one_ge (hs : 2 ≤ s) (b : ZMod s) (hb : b ≠ 0) :
    4 * (min b.val (s - b.val) : ℕ) / (s : ℝ) ≤ ‖ψ b - 1‖ := by
  have hv0 : 0 < b.val := Nat.pos_of_ne_zero (by rwa [ZMod.val_ne_zero])
  have hvs : b.val < s := ZMod.val_lt b
  have hk : s - b.val ∈ Finset.Ioo 0 s := Finset.mem_Ioo.2 ⟨by omega, by omega⟩
  have := GoldC.QuillonSawDFT.norm_zeta_sub_one_ge s (s - b.val) hs hk
  have hz : GoldC.QuillonSawDFT.zeta s ^ (-((s - b.val : ℕ) : ℤ)) = ψ b := by
    rw [psi_eq_zeta_pow]
    have hζ := GoldC.QuillonSawDFT.zeta_prim s (by omega)
    rw [show (-((s - b.val : ℕ) : ℤ)) = (b.val : ℤ) - (s : ℤ) by push_cast [Nat.cast_sub hvs.le]; ring,
      zpow_sub₀ (GoldC.QuillonSawDFT.zeta_ne_zero s), zpow_natCast, zpow_natCast, hζ.pow_eq_one,
      div_one]
  rw [hz] at this
  have hmin : min (s - b.val) (s - (s - b.val)) = min b.val (s - b.val) := by
    rw [Nat.sub_sub_self hvs.le, min_comm]
  rw [hmin] at this
  exact this

lemma geom_bound (hs : 2 ≤ s) (b : ZMod s) (hb : b ≠ 0) (N M : ℕ) :
    ‖∑ n ∈ Ioc N M, ψ (b * n)‖ ≤ (s : ℝ) / (2 * (min b.val (s - b.val) : ℕ)) := by
  have hv0 : 0 < b.val := Nat.pos_of_ne_zero (by rwa [ZMod.val_ne_zero])
  have hvs : b.val < s := ZMod.val_lt b
  set w := ψ b
  have hw1 : ‖w‖ = 1 := by
    simp [w, ZMod.stdAddChar_apply]
  have hpow : ∀ n : ℕ, ψ (b * n) = w ^ n := by
    intro n
    rw [mul_comm, ← nsmul_eq_mul, AddChar.map_nsmul_eq_pow]
  simp_rw [hpow]
  have hwne : w ≠ 1 := by
    intro h
    have := norm_psi_sub_one_ge hs b hb
    rw [show ψ b = w from rfl, h, sub_self, norm_zero] at this
    have : (0 : ℝ) < 4 * (min b.val (s - b.val) : ℕ) / (s : ℝ) := by
      have : 0 < min b.val (s - b.val) := lt_min hv0 (by omega)
      positivity
    linarith
  have hsub : w - 1 ≠ 0 := sub_ne_zero.2 hwne
  -- Σ_{n∈(N,M]} w^n = (w^(M+1) - w^(N+1))/(w-1) when N ≤ M
  rcases le_or_gt N M with hNM | hNM
  · have hgeom : ∑ n ∈ Ioc N M, w ^ n = (w ^ (M + 1) - w ^ (N + 1)) / (w - 1) := by
      rw [← Finset.Ico_add_one_add_one_eq_Ioc, Finset.sum_Ico_eq_sub _ (by omega),
        geom_sum_eq hwne, geom_sum_eq hwne]
      field_simp; ring
    rw [hgeom, norm_div]
    have hlow := norm_psi_sub_one_ge hs b hb
    have hpos : 0 < ‖w - 1‖ := norm_pos_iff.2 hsub
    have hnum : ‖w ^ (M + 1) - w ^ (N + 1)‖ ≤ 2 := by
      refine (norm_sub_le _ _).trans ?_
      rw [norm_pow, norm_pow, hw1, one_pow, one_pow]; norm_num
    have hmin : (0 : ℝ) < (min b.val (s - b.val) : ℕ) := by
      have : 0 < min b.val (s - b.val) := lt_min hv0 (by omega)
      exact_mod_cast this
    have hsR : (0 : ℝ) < s := by exact_mod_cast (show 0 < s by omega)
    rw [div_le_div_iff₀ hpos (by positivity)]
    calc ‖w ^ (M + 1) - w ^ (N + 1)‖ * (2 * ((min b.val (s - b.val) : ℕ) : ℝ))
        ≤ 2 * (2 * ((min b.val (s - b.val) : ℕ) : ℝ)) := by gcongr
      _ = (s : ℝ) * (4 * ((min b.val (s - b.val) : ℕ) : ℝ) / (s : ℝ)) := by field_simp; ring
      _ ≤ (s : ℝ) * ‖w - 1‖ := by gcongr
  · rw [Finset.Ioc_eq_empty (by omega), Finset.sum_empty, norm_zero]
    have : 0 < min b.val (s - b.val) := lt_min hv0 (by omega)
    positivity

/-- `Σ_b ‖Σ_{n∈(N,M]} e(bn/s)‖ ≤ (M − N) + s(1 + log s)`. -/
lemma sumG_le (hs : 2 ≤ s) (N M : ℕ) (_hNM : N ≤ M) :
    ∑ b : ZMod s, ‖∑ n ∈ Ioc N M, ψ (b * n)‖ ≤ ((M - N : ℕ) : ℝ) + s * (1 + Real.log s) := by
  rw [← Finset.add_sum_erase _ _ (Finset.mem_univ (0 : ZMod s))]
  have hG0 : ‖∑ n ∈ Ioc N M, ψ ((0 : ZMod s) * n)‖ ≤ ((M - N : ℕ) : ℝ) := by
    simp only [zero_mul, AddChar.map_zero_eq_one, Finset.sum_const, Nat.card_Ioc,
      nsmul_eq_mul, mul_one, Complex.norm_natCast]
    rfl
  have hrest : ∑ b ∈ (Finset.univ : Finset (ZMod s)).erase 0,
      ‖∑ n ∈ Ioc N M, ψ (b * n)‖ ≤ s * (1 + Real.log s) := by
    calc ∑ b ∈ (Finset.univ : Finset (ZMod s)).erase 0, ‖∑ n ∈ Ioc N M, ψ (b * n)‖
        ≤ ∑ b ∈ (Finset.univ : Finset (ZMod s)).erase 0,
            (s : ℝ) / 2 * (1 / (b.val : ℝ) + 1 / ((s - b.val : ℕ) : ℝ)) := by
          refine Finset.sum_le_sum fun b hb => ?_
          have hb0 : b ≠ 0 := Finset.ne_of_mem_erase hb
          have hv0 : 0 < b.val := Nat.pos_of_ne_zero (by rwa [ZMod.val_ne_zero])
          have hvs : b.val < s := ZMod.val_lt b
          refine (geom_bound hs b hb0 N M).trans ?_
          have hm : (0 : ℝ) < (min b.val (s - b.val) : ℕ) := by
            exact_mod_cast lt_min hv0 (by omega)
          have hvR : (0 : ℝ) < b.val := by exact_mod_cast hv0
          have hsvR : (0 : ℝ) < ((s - b.val : ℕ) : ℝ) := by exact_mod_cast (show 0 < s - b.val by omega)
          rcases le_total b.val (s - b.val) with h | h
          · rw [min_eq_left h]
            have : (s : ℝ) / (2 * (b.val : ℝ)) = (s : ℝ) / 2 * (1 / (b.val : ℝ)) := by
              field_simp
            rw [this]
            have : (0 : ℝ) ≤ (s : ℝ) / 2 * (1 / ((s - b.val : ℕ) : ℝ)) := by positivity
            linarith [show (s : ℝ) / 2 * (1 / (b.val : ℝ) + 1 / ((s - b.val : ℕ) : ℝ)) =
              (s : ℝ) / 2 * (1 / (b.val : ℝ)) + (s : ℝ) / 2 * (1 / ((s - b.val : ℕ) : ℝ)) by ring]
          · rw [min_eq_right h]
            have : (s : ℝ) / (2 * ((s - b.val : ℕ) : ℝ)) =
                (s : ℝ) / 2 * (1 / ((s - b.val : ℕ) : ℝ)) := by field_simp
            rw [this]
            have : (0 : ℝ) ≤ (s : ℝ) / 2 * (1 / (b.val : ℝ)) := by positivity
            linarith [show (s : ℝ) / 2 * (1 / (b.val : ℝ) + 1 / ((s - b.val : ℕ) : ℝ)) =
              (s : ℝ) / 2 * (1 / (b.val : ℝ)) + (s : ℝ) / 2 * (1 / ((s - b.val : ℕ) : ℝ)) by ring]
      _ = (s : ℝ) / 2 * (∑ b ∈ (Finset.univ : Finset (ZMod s)).erase 0, 1 / (b.val : ℝ) +
            ∑ b ∈ (Finset.univ : Finset (ZMod s)).erase 0, 1 / ((s - b.val : ℕ) : ℝ)) := by
          rw [← Finset.sum_add_distrib, Finset.mul_sum]
      _ ≤ (s : ℝ) / 2 * ((1 + Real.log s) + (1 + Real.log s)) := by
          have hH : ∀ g : ℕ → ℕ, (∀ b ∈ (Finset.univ : Finset (ZMod s)).erase 0,
              g b.val ∈ Finset.Icc 1 s) → Set.InjOn (fun b : ZMod s => g b.val)
                ((Finset.univ : Finset (ZMod s)).erase 0 : Set (ZMod s)) →
              ∑ b ∈ (Finset.univ : Finset (ZMod s)).erase 0, 1 / ((g b.val : ℕ) : ℝ) ≤
                1 + Real.log s := by
            intro g hg hinj
            have h1 : ∑ b ∈ (Finset.univ : Finset (ZMod s)).erase 0, 1 / ((g b.val : ℕ) : ℝ) =
                ∑ k ∈ ((Finset.univ : Finset (ZMod s)).erase 0).image (fun b => g b.val),
                  1 / (k : ℝ) := (Finset.sum_image (f := fun k : ℕ => 1 / (k : ℝ)) hinj).symm
            rw [h1]
            have h2 : ∑ k ∈ ((Finset.univ : Finset (ZMod s)).erase 0).image (fun b => g b.val),
                1 / (k : ℝ) ≤ ∑ k ∈ Finset.Icc 1 s, 1 / (k : ℝ) := by
              apply Finset.sum_le_sum_of_subset_of_nonneg
              · intro k hk
                obtain ⟨b, hb, rfl⟩ := Finset.mem_image.1 hk
                exact hg b hb
              · intro k _ _; positivity
            have h3 := harmonic_le_one_add_log s
            rw [harmonic_eq_sum_Icc] at h3; push_cast at h3
            simp only [one_div] at h2 ⊢
            linarith
          have hA := hH (fun v => v) (fun b hb => by
              have hb0 : b ≠ 0 := Finset.ne_of_mem_erase hb
              have hv0 : 0 < b.val := Nat.pos_of_ne_zero (by rwa [ZMod.val_ne_zero])
              exact Finset.mem_Icc.2 ⟨hv0, (ZMod.val_lt b).le⟩)
            (fun a _ b _ h => ZMod.val_injective s h)
          have hB := hH (fun v => s - v) (fun b hb => by
              have hb0 : b ≠ 0 := Finset.ne_of_mem_erase hb
              have hv0 : 0 < b.val := Nat.pos_of_ne_zero (by rwa [ZMod.val_ne_zero])
              have hvs := ZMod.val_lt b
              exact Finset.mem_Icc.2 ⟨by omega, by omega⟩)
            (fun a _ b _ h => by
              have ha := ZMod.val_lt a; have hb := ZMod.val_lt b
              simp only at h
              exact ZMod.val_injective s (by omega))
          gcongr
      _ = s * (1 + Real.log s) := by ring
  linarith

/-- **Incomplete inverse sum**: `‖Σ_{N<n≤M,(n,s)=1} e(c n̄/s)‖ ≤ Kmax·((M−N)/s + 1 + log s)`. -/
theorem incomplete_bound (hs : 2 ≤ s) (c : ZMod s) (N M : ℕ) (hNM : N ≤ M) (Kmax : ℝ)
    (hK : ∀ b : ZMod s, ‖K s b c‖ ≤ Kmax) :
    ‖∑ n ∈ Ioc N M, (if IsUnit (n : ZMod s) then ψ (c * (n : ZMod s)⁻¹) else 0)‖ ≤
      Kmax * (((M - N : ℕ) : ℝ) / s + 1 + Real.log s) := by
  have hsR : (0 : ℝ) < s := by exact_mod_cast (show 0 < s by omega)
  have hK0 : 0 ≤ Kmax := (norm_nonneg _).trans (hK 0)
  rw [completion]
  rw [norm_mul, norm_div, norm_one, Complex.norm_natCast]
  -- Σ_b ‖K‖‖G‖ ≤ Kmax Σ_b ‖G‖
  have h1 : ‖∑ b : ZMod s, K s (-b) c * ∑ n ∈ Ioc N M, ψ (b * n)‖ ≤
      Kmax * ∑ b : ZMod s, ‖∑ n ∈ Ioc N M, ψ (b * n)‖ := by
    refine (norm_sum_le _ _).trans ?_
    rw [Finset.mul_sum]
    refine Finset.sum_le_sum fun b _ => ?_
    rw [norm_mul]
    exact mul_le_mul_of_nonneg_right (hK (-b)) (norm_nonneg _)
  -- Σ_b ‖G(b)‖ ≤ (M − N) + s(1 + log s)
  have h2 := sumG_le hs N M hNM
  calc 1 / (s : ℝ) * ‖∑ b : ZMod s, K s (-b) c * ∑ n ∈ Ioc N M, ψ (b * n)‖
      ≤ 1 / (s : ℝ) * (Kmax * (((M - N : ℕ) : ℝ) + s * (1 + Real.log s))) := by
        gcongr
        exact h1.trans (mul_le_mul_of_nonneg_left h2 hK0)
    _ = Kmax * (((M - N : ℕ) : ℝ) / s + 1 + Real.log s) := by field_simp; ring

/-! ## Arithmetic-progression version (modulus `Q` coprime to `s`) -/

/-- **Incomplete inverse sum along an AP**: for `(Q, s) = 1`,
`‖Σ_{t∈(N,M]} 1_{unit}(a+Qt)·e(c (a+Qt)⁻¹/s)‖ ≤ Kmax·((M−N)/s + 1 + log s)`. -/
theorem incomplete_bound_AP (hs : 2 ≤ s) (c : ZMod s) (a Q N M : ℕ) (hQ : Nat.Coprime Q s)
    (hNM : N ≤ M) (Kmax : ℝ) (hK : ∀ b : ZMod s, ‖K s b c‖ ≤ Kmax) :
    ‖∑ t ∈ Ioc N M, (if IsUnit ((a + Q * t : ℕ) : ZMod s) then
        ψ (c * ((a + Q * t : ℕ) : ZMod s)⁻¹) else 0)‖ ≤
      Kmax * (((M - N : ℕ) : ℝ) / s + 1 + Real.log s) := by
  have hsR : (0 : ℝ) < s := by exact_mod_cast (show 0 < s by omega)
  have hK0 : 0 ≤ Kmax := (norm_nonneg _).trans (hK 0)
  set f : ZMod s → ℂ := fun y => if IsUnit y then ψ (c * y⁻¹) else 0 with hf
  have hrw : ∀ t, (if IsUnit ((a + Q * t : ℕ) : ZMod s) then
      ψ (c * ((a + Q * t : ℕ) : ZMod s)⁻¹) else 0) = f ((a + Q * t : ℕ) : ZMod s) := fun t => rfl
  simp_rw [hrw]
  conv_lhs => arg 1; arg 2; ext t; rw [fourier_inv f ((a + Q * t : ℕ) : ZMod s)]
  rw [← Finset.mul_sum, Finset.sum_comm]
  have hhat : ∀ b : ZMod s, (∑ y : ZMod s, f y * ψ (-(b * y))) = K s (-b) c := fun b => hat_eq_K c b
  simp_rw [hhat]
  rw [norm_mul, norm_div, norm_one, Complex.norm_natCast]
  have hQu : IsUnit (Q : ZMod s) := (ZMod.unitOfCoprime Q hQ).isUnit
  -- per-b geometric bound after the substitution b ↦ bQ
  have hgeo : ∀ b : ZMod s, ‖∑ t ∈ Ioc N M, K s (-b) c * ψ (b * ((a + Q * t : ℕ) : ZMod s))‖ ≤
      Kmax * ‖∑ t ∈ Ioc N M, ψ ((b * Q) * t)‖ := by
    intro b
    have : ∑ t ∈ Ioc N M, K s (-b) c * ψ (b * ((a + Q * t : ℕ) : ZMod s)) =
        K s (-b) c * ψ (b * a) * ∑ t ∈ Ioc N M, ψ ((b * Q) * t) := by
      rw [Finset.mul_sum]
      refine Finset.sum_congr rfl fun t _ => ?_
      rw [mul_assoc, ← AddChar.map_add_eq_mul]; push_cast; congr 2; ring
    rw [this, norm_mul, norm_mul]
    have hψ : ‖ψ (b * a)‖ = 1 := by simp [ZMod.stdAddChar_apply]
    rw [hψ, mul_one]
    exact mul_le_mul_of_nonneg_right (hK (-b)) (norm_nonneg _)
  have h1 : ‖∑ b : ZMod s, ∑ t ∈ Ioc N M, K s (-b) c * ψ (b * ((a + Q * t : ℕ) : ZMod s))‖ ≤
      Kmax * ∑ b : ZMod s, ‖∑ t ∈ Ioc N M, ψ (b * t)‖ := by
    refine (norm_sum_le _ _).trans ?_
    refine (Finset.sum_le_sum fun b _ => hgeo b).trans ?_
    rw [← Finset.mul_sum]
    refine mul_le_mul_of_nonneg_left (le_of_eq ?_) hK0
    -- reindex b ↦ b·Q (a bijection since Q is a unit)
    exact Fintype.sum_equiv (Units.mulRight hQu.unit) _ _ fun b => by simp [Units.mulRight_apply]
  -- reuse the consecutive-integer bound for Σ_b ‖G(b)‖
  have h2 : ∑ b : ZMod s, ‖∑ t ∈ Ioc N M, ψ (b * t)‖ ≤
      ((M - N : ℕ) : ℝ) + s * (1 + Real.log s) := by
    exact sumG_le hs N M hNM
  calc 1 / (s : ℝ) * ‖∑ b : ZMod s, ∑ t ∈ Ioc N M, K s (-b) c * ψ (b * ((a + Q * t : ℕ) : ZMod s))‖
      ≤ 1 / (s : ℝ) * (Kmax * (((M - N : ℕ) : ℝ) + s * (1 + Real.log s))) := by
        gcongr
        exact h1.trans (mul_le_mul_of_nonneg_left h2 hK0)
    _ = Kmax * (((M - N : ℕ) : ℝ) / s + 1 + Real.log s) := by field_simp; ring

end GoldC.QuillonCompletion

#print axioms GoldC.QuillonCompletion.K_symm
#print axioms GoldC.QuillonCompletion.completion
#print axioms GoldC.QuillonCompletion.geom_bound
#print axioms GoldC.QuillonCompletion.incomplete_bound
#print axioms GoldC.QuillonCompletion.incomplete_bound_AP
