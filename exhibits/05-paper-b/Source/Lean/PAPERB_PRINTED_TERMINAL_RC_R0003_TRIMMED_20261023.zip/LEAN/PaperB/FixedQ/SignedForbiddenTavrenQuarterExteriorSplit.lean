import PaperB.FixedQ.SignedForbiddenTavrenGlobalExteriorSignedHeightSum
import PaperB.FixedQ.SignedForbiddenTorvenQuarterSquareFarTailTsum

open scoped BigOperators Classical

namespace PaperB.FixedQ

/-- Partition a summable signed family without introducing a norm. -/
private theorem tavren_tsum_split_at_predicate
    {alpha : Type*} [Countable alpha] (f : alpha → ℝ)
    (hf : Summable f) (P : alpha → Prop) :
    (∑' x, f x) =
      (∑' x, if P x then f x else 0) +
      (∑' x, if ¬ P x then f x else 0) := by
  classical
  have hleft : Summable (fun x => if P x then f x else 0) := by
    apply (hf.indicator {x | P x}).congr
    intro x
    by_cases hx : P x <;> simp [Set.indicator, hx]
  have hright : Summable (fun x => if ¬ P x then f x else 0) := by
    apply (hf.indicator {x | ¬ P x}).congr
    intro x
    by_cases hx : P x <;> simp [Set.indicator, hx]
  rw [← hleft.tsum_add hright]
  apply tsum_congr
  intro x
  by_cases hx : P x <;> simp [hx]

/-- The signed reduced source window Z(h)<m and 4m<=H_d^2. -/
noncomputable def tavrenReducedExteriorQuarterMiddleCore
    (q A H Z : ℕ) (d : Finset ℕ) : ℝ :=
  ∑' n : Finset ℕ,
    if 4 * primeSetProduct n ≤ H ^ 2 then
      if Z < primeSetProduct n then
        dForbiddenReducedBooleanCoreTerm q A H d n
      else 0
    else 0

/-- The signed reduced source far sector 4m>H_d^2,
still using the same original global cutoff Z(h). -/
noncomputable def tavrenReducedExteriorQuarterFarCore
    (q A H Z : ℕ) (d : Finset ℕ) : ℝ :=
  ∑' n : Finset ℕ,
    if H ^ 2 < 4 * primeSetProduct n then
      if Z < primeSetProduct n then
        dForbiddenReducedBooleanCoreTerm q A H d n
      else 0
    else 0

/-- The ordinary source reduced exterior splits exactly at
4*m=H_d^2 without an absolute value on either side. -/
theorem tavrenReducedExteriorSignedCore_eq_quarterMiddle_add_far
    {q A H Z : ℕ} (d : Finset ℕ)
    (hq : 0 < q) (hH : 0 < H)
    (h2 : ¬ 2 ∣ q → 2 ∣ H) :
    tavrenReducedExteriorSignedCore q A H Z d =
      tavrenReducedExteriorQuarterMiddleCore q A H Z d +
      tavrenReducedExteriorQuarterFarCore q A H Z d := by
  let f : Finset ℕ → ℝ := fun n =>
    if Z < primeSetProduct n then
      dForbiddenReducedBooleanCoreTerm q A H d n else 0
  have hf : Summable f := by
    exact tavren_summable_reducedExteriorSignedCore hq hH h2 d
  have hsplit := tavren_tsum_split_at_predicate f hf
    (fun n => 4 * primeSetProduct n ≤ H ^ 2)
  have hfarEq :
      (∑' n : Finset ℕ,
        if ¬ 4 * primeSetProduct n ≤ H ^ 2 then f n else 0) =
      (∑' n : Finset ℕ,
        if H ^ 2 < 4 * primeSetProduct n then f n else 0) := by
    apply tsum_congr
    intro n
    by_cases hn : 4 * primeSetProduct n ≤ H ^ 2
    · have hnot : ¬ H ^ 2 < 4 * primeSetProduct n := by omega
      simp [hn, hnot]
    · have hgt : H ^ 2 < 4 * primeSetProduct n := by omega
      simp [hn, hgt]
  unfold tavrenReducedExteriorSignedCore
    tavrenReducedExteriorQuarterMiddleCore
    tavrenReducedExteriorQuarterFarCore
  change (∑' n, f n) =
    (∑' n, if 4 * primeSetProduct n ≤ H ^ 2 then f n else 0) +
    (∑' n, if H ^ 2 < 4 * primeSetProduct n then f n else 0)
  calc
    (∑' n, f n) =
      (∑' n, if 4 * primeSetProduct n ≤ H ^ 2 then f n else 0) +
      (∑' n, if ¬ 4 * primeSetProduct n ≤ H ^ 2 then f n else 0) := by
        convert hsplit using 1
        · congr 1
          all_goals
            apply tsum_congr
            intro n
            by_cases hn : 4 * primeSetProduct n ≤ H ^ 2 <;> simp [hn]
    _ = _ := by rw [hfarEq]

/-- Sum over every permitted height-decoration layer, preserving its
source coefficient and reduced H_d=h/product d. -/
noncomputable def tavrenGlobalExteriorQuarterMiddle
    (q a h Z : ℕ) : ℝ :=
  ∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
    finiteVWeightReal h d *
      tavrenReducedExteriorQuarterMiddleCore q
        (decoratedReducedAnchor q a (primeSetProduct d))
        (h / primeSetProduct d) Z d

noncomputable def tavrenGlobalExteriorQuarterFar
    (q a h Z : ℕ) : ℝ :=
  ∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
    finiteVWeightReal h d *
      tavrenReducedExteriorQuarterFarCore q
        (decoratedReducedAnchor q a (primeSetProduct d))
        (h / primeSetProduct d) Z d

/-- The literal signed global proper exterior, filtered at the
quarter-square cutoff inside each source-imposed reduced height.
The original Z(h) is shared by ALL layers; all signs are retained. -/
theorem tavren_globalProperExterior_eq_quarterMiddle_add_far
    {q a h Z : ℕ}
    (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    globalProperExteriorAnalytic q a h Z =
      tavrenGlobalExteriorQuarterMiddle q a h Z +
      tavrenGlobalExteriorQuarterFar q a h Z := by
  rw [tavren_globalProperExterior_eq_signedHeightSum hq hh h2]
  unfold tavrenGlobalExteriorQuarterMiddle tavrenGlobalExteriorQuarterFar
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro d hd
  have hHpos := decoratedReducedHeight_pos_of_mem hh hd
  have hHpar := decoratedReducedHeight_parity_of_mem h2 hd
  have hsplit := tavrenReducedExteriorSignedCore_eq_quarterMiddle_add_far
    (q := q)
    (A := decoratedReducedAnchor q a (primeSetProduct d))
    (H := h / primeSetProduct d) (Z := Z) d hq
    (by simpa [decoratedReducedHeight, decoratedHeightProduct] using hHpos)
    (by simpa [decoratedReducedHeight, decoratedHeightProduct] using hHpar)
  rw [hsplit]
  ring

/-- Specialization to the literal source cutoff Z(h), NOT Z(h/D_d). -/
theorem tavren_globalProperExterior_sourceCutoff_quarterSplit
    {q a h : ℕ} (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    globalProperExteriorAnalytic q a h
        (globalProperBooleanProductCutoff h) =
      tavrenGlobalExteriorQuarterMiddle q a h
        (globalProperBooleanProductCutoff h) +
      tavrenGlobalExteriorQuarterFar q a h
        (globalProperBooleanProductCutoff h) :=
  tavren_globalProperExterior_eq_quarterMiddle_add_far hq hh h2

#print axioms tavrenReducedExteriorSignedCore_eq_quarterMiddle_add_far
#print axioms tavren_globalProperExterior_eq_quarterMiddle_add_far
#print axioms tavren_globalProperExterior_sourceCutoff_quarterSplit

end PaperB.FixedQ
