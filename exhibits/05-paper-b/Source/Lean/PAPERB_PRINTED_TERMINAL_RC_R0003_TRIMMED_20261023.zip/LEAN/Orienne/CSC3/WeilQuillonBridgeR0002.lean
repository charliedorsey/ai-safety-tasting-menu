import GeneralKloosterman.General
import GoldC.QuillonCompletion

open scoped BigOperators
namespace Orienne.CSC3

/-- Exact normalization identity: Quillon's complete unit-character sum
is the RML/GenKloosterman complete unit-character sum, with both phase
coefficients in the same order. -/
theorem quillon_K_eq_rml (s : ℕ) [NeZero s] (a b : ZMod s) :
    GoldC.QuillonKl.K s a b = GenKloosterman.kSum s b a := by
  rfl

/-- General-modulus Weil–Estermann bound on the actual complete
Quillon Kloosterman sum, with full gcd conductor retained. -/
theorem norm_quillon_K_weil (s : ℕ) [NeZero s] (a b : ZMod s) :
    ‖GoldC.QuillonKl.K s a b‖ ≤
      (s.divisors.card : ℝ) *
        Real.sqrt (Nat.gcd (Nat.gcd a.val b.val) s * s) := by
  rw [quillon_K_eq_rml]
  simpa only [GenKloosterman.kgcd, Nat.gcd_comm b.val a.val] using (GenKloosterman.norm_kSum_le s b a)

#print axioms quillon_K_eq_rml
#print axioms norm_quillon_K_weil
end Orienne.CSC3
