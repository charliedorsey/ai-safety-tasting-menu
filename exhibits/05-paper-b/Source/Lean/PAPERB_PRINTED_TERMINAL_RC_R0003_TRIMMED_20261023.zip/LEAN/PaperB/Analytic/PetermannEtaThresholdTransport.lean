import PaperB.Analytic.PetermannEtaHarmonicSawtooth
import PaperB.FixedQ.HarmonicLogTail

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

lemma eta_harmonic_Icc_le_one_div_add_log_ratio
    {M N : ℕ} (hM : 1 ≤ M) (hMN : M ≤ N) :
    (∑ m ∈ Finset.Icc M N, (1 : ℝ) / (m : ℝ))
      ≤ (1 : ℝ) / (M : ℝ) +
        (Real.log ((N + 1 : ℕ) : ℝ) - Real.log (M : ℝ)) := by
  have hIcc :
      (∑ m ∈ Finset.Icc M N, (1 : ℝ) / (m : ℝ)) =
        ∑ j ∈ Finset.range (N + 1 - M),
          (1 : ℝ) / ((M + j : ℕ) : ℝ) := by
    rw [show Finset.Icc M N = Finset.Ico M (N + 1) by
      ext m
      simp]
    rw [Finset.sum_Ico_eq_sum_range]
  rw [hIcc]
  have h := shifted_harmonic_range_le
    (K := M) (N := N + 1 - M) hM
  have hsum : M + (N + 1 - M) = N + 1 := by omega
  simpa [hsum] using h

private lemma eta_sum_Icc_split
    {M : Type} [AddCommMonoid M] (f : Nat -> M)
    {a b c : Nat} (hab : a <= b) (hbc : b <= c) :
    (∑ n ∈ Icc a c, f n) =
      (∑ n ∈ Icc a b, f n) +
      (∑ n ∈ Icc (b + 1) c, f n) := by
  have hdis : Disjoint (Icc a b) (Icc (b + 1) c) := by
    rw [Finset.disjoint_left]
    intro x hx1 hx2
    simp only [mem_Icc] at hx1 hx2
    omega
  have hunion : Icc a b ∪ Icc (b + 1) c = Icc a c := by
    ext x
    simp only [mem_union, mem_Icc]
    constructor
    · intro hx
      rcases hx with hx | hx
      · exact ⟨hx.1, hx.2.trans hbc⟩
      · exact ⟨hab.trans (by omega), hx.2⟩
    · intro hx
      by_cases hxb : x <= b
      · exact Or.inl ⟨hx.1, hxb⟩
      · exact Or.inr ⟨by omega, hx.2⟩
  rw [← hunion, sum_union hdis]

lemma norm_etaHarmonicSawtooth_Icc_le_half_harmonic
    (q : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (A : ℝ) {M Y : ℕ} (hM : 1 ≤ M) :
    ‖∑ m ∈ Finset.Icc M Y,
      ((chi m) / (m : ℂ)) *
        (petermannSawtooth
          (A / (m : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ)‖
      ≤ (1 / 2 : ℝ) *
        (∑ m ∈ Finset.Icc M Y, (1 : ℝ) / (m : ℝ)) := by
  calc
    ‖∑ m ∈ Finset.Icc M Y,
      ((chi m) / (m : ℂ)) *
        (petermannSawtooth
          (A / (m : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ)‖
      ≤ ∑ m ∈ Finset.Icc M Y,
          ‖((chi m) / (m : ℂ)) *
            (petermannSawtooth
              (A / (m : ℝ) +
                (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ)‖ :=
        norm_sum_le _ _
    _ ≤ ∑ m ∈ Finset.Icc M Y, (1 / 2 : ℝ) * (1 / (m : ℝ)) := by
      apply Finset.sum_le_sum
      intro m hm
      have hmI := Finset.mem_Icc.mp hm
      have hmpos : (0 : ℝ) < m := by
        exact_mod_cast (show 0 < m by omega)
      have hchi := norm_dirichletCharacter_nat_le_one (q := q) (e := m) chi
      have hsaw := abs_petermannSawtooth_le_half
        (A / (m : ℝ) +
          (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))
      rw [norm_mul, norm_div, Complex.norm_natCast,
        Complex.norm_real, Real.norm_eq_abs]
      have hrec : 0 ≤ (m : ℝ)⁻¹ := by positivity
      have hc :
          ‖chi (m : ZMod (Nat.lcm 6 q))‖ * (m : ℝ)⁻¹ ≤
            1 * (m : ℝ)⁻¹ :=
        mul_le_mul_of_nonneg_right hchi hrec
      have hsaw0 : 0 ≤
          |petermannSawtooth
            (A / (m : ℝ) +
              (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))| := abs_nonneg _
      calc
        (‖chi (m : ZMod (Nat.lcm 6 q))‖ / (m : ℝ)) *
            |petermannSawtooth
              (A / (m : ℝ) +
                (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))|
          = (‖chi (m : ZMod (Nat.lcm 6 q))‖ * (m : ℝ)⁻¹) *
            |petermannSawtooth
              (A / (m : ℝ) +
                (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))| := by
              rw [div_eq_mul_inv]
        _ ≤ (1 * (m : ℝ)⁻¹) * (1 / 2) :=
          mul_le_mul hc hsaw hsaw0
            (mul_nonneg (by norm_num) hrec)
        _ = (1 / 2 : ℝ) * (1 / (m : ℝ)) := by
          rw [one_mul, div_eq_mul_inv]
          ring
    _ = (1 / 2 : ℝ) *
        (∑ m ∈ Finset.Icc M Y, (1 : ℝ) / (m : ℝ)) := by
      rw [Finset.mul_sum]

theorem etaHarmonicSawtooth_fixed_stretch
    (q : ℕ) (hq : 0 < q)
    (hspec : EtaHarmonicSawtoothSpec q) :
    ∀ eps : ℝ, 0 < eps →
      ∃ A0 : ℝ, 0 < A0 ∧
      ∃ C : ℝ, 0 ≤ C ∧
      ∀ (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
        (r : ℤ) (A : ℝ) (Y : ℕ),
        A0 ≤ A →
        1 ≤ Y →
        (Y : ℝ) ≤ (Nat.lcm 6 q : ℝ) * A →
        ‖etaHarmonicSawtoothSum q chi r A Y‖
          ≤ eps * Real.log A + C := by
  intro eps heps
  obtain ⟨Abase, hAbase0, hbase⟩ := hspec eps heps
  let L : ℕ := Nat.lcm 6 q
  have hLpos : 0 < L := Nat.lcm_pos (by norm_num) hq
  have hL1 : 1 ≤ L := by omega
  let C : ℝ := (1 / 2 : ℝ) * (1 + Real.log ((L + 1 : ℕ) : ℝ))
  have hlogLp0 : 0 ≤ Real.log ((L + 1 : ℕ) : ℝ) := by
    apply Real.log_nonneg
    exact_mod_cast (show 1 ≤ L + 1 by omega)
  have hC0 : 0 ≤ C := by
    dsimp [C]
    positivity
  let A0 : ℝ := max Abase 2
  refine ⟨A0, ?_, C, hC0, ?_⟩
  · exact lt_of_lt_of_le (by norm_num) (le_max_right _ _)
  · intro chi r A Y hA0A hY1 hYstretch
    have hAbase : Abase ≤ A :=
      (le_max_left Abase 2).trans hA0A
    have hA2 : (2 : ℝ) ≤ A :=
      (le_max_right Abase 2).trans hA0A
    have hA1 : (1 : ℝ) ≤ A := by linarith
    have hApos : 0 < A := by linarith
    have hlog0 : 0 ≤ Real.log A := Real.log_nonneg hA1
    by_cases hYA : (Y : ℝ) ≤ A
    · have hmain := hbase chi r A Y hAbase hY1 hYA
      exact hmain.trans (by
        have hC := hC0
        linarith)
    · have hAY : A < (Y : ℝ) := lt_of_not_ge hYA
      let K : ℕ := Nat.floor A
      have hK1 : 1 ≤ K := by
        dsimp [K]
        apply Nat.le_floor
        exact_mod_cast hA1
      have hKcast : (K : ℝ) ≤ A := by
        dsimp [K]
        exact Nat.floor_le hApos.le
      have hKltYreal : (K : ℝ) < (Y : ℝ) := hKcast.trans_lt hAY
      have hKltY : K < Y := by exact_mod_cast hKltYreal
      have hprefix :=
        hbase chi r A K hAbase hK1 hKcast
      have hsplit :
          etaHarmonicSawtoothSum q chi r A Y =
            etaHarmonicSawtoothSum q chi r A K +
              ∑ m ∈ Finset.Icc (K + 1) Y,
                ((chi m) / (m : ℂ)) *
                  (petermannSawtooth
                    (A / (m : ℝ) +
                      (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) := by
        unfold etaHarmonicSawtoothSum
        exact eta_sum_Icc_split
          (fun m =>
            ((chi m) / (m : ℂ)) *
              (petermannSawtooth
                (A / (m : ℝ) +
                  (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ))
          hK1 (Nat.le_of_lt hKltY)
      have htailH :=
        eta_harmonic_Icc_le_one_div_add_log_ratio
          (M := K + 1) (N := Y) (by omega) (by omega)
      have hA_lt_K1 : A < (K + 1 : ℕ) := by
        dsimp [K]
        simpa using Nat.lt_floor_add_one A
      have hYN :
          ((Y + 1 : ℕ) : ℝ) ≤
            ((L + 1 : ℕ) : ℝ) * ((K + 1 : ℕ) : ℝ) := by
        have hYLA : (Y : ℝ) ≤ (L : ℝ) * A := by
          simpa [L] using hYstretch
        have hA_K1 : A ≤ ((K + 1 : ℕ) : ℝ) := hA_lt_K1.le
        have hLK :
            (L : ℝ) * A ≤ (L : ℝ) * ((K + 1 : ℕ) : ℝ) :=
          mul_le_mul_of_nonneg_left hA_K1 (by positivity)
        calc
          ((Y + 1 : ℕ) : ℝ) = (Y : ℝ) + 1 := by norm_num
          _ ≤ (L : ℝ) * ((K + 1 : ℕ) : ℝ) + 1 := by
            linarith
          _ ≤ ((L : ℝ) + 1) * ((K + 1 : ℕ) : ℝ) := by
            have hK1R : (1 : ℝ) ≤ (K + 1 : ℕ) := by exact_mod_cast (show 1 ≤ K + 1 by omega)
            nlinarith
          _ = ((L + 1 : ℕ) : ℝ) * ((K + 1 : ℕ) : ℝ) := by norm_num
      have hK1pos : (0 : ℝ) < ((K + 1 : ℕ) : ℝ) := by positivity
      have hLp1pos : (0 : ℝ) < ((L + 1 : ℕ) : ℝ) := by positivity
      have hY1pos : (0 : ℝ) < ((Y + 1 : ℕ) : ℝ) := by positivity
      have hlogratio :
          Real.log ((Y + 1 : ℕ) : ℝ) -
              Real.log ((K + 1 : ℕ) : ℝ)
            ≤ Real.log ((L + 1 : ℕ) : ℝ) := by
        have hlog := Real.log_le_log hY1pos hYN
        rw [Real.log_mul hLp1pos.ne' hK1pos.ne'] at hlog
        linarith
      have hinvK : (1 : ℝ) / ((K + 1 : ℕ) : ℝ) ≤ 1 := by
        have hK1R : (1 : ℝ) ≤ ((K + 1 : ℕ) : ℝ) := by
          exact_mod_cast (show 1 ≤ K + 1 by omega)
        have := one_div_le_one_div_of_le (by norm_num : (0 : ℝ) < 1) hK1R
        simpa using this
      have htailMass :
          (∑ m ∈ Finset.Icc (K + 1) Y,
              (1 : ℝ) / (m : ℝ))
            ≤ 1 + Real.log ((L + 1 : ℕ) : ℝ) := by
        calc
          (∑ m ∈ Finset.Icc (K + 1) Y,
              (1 : ℝ) / (m : ℝ))
            ≤ (1 : ℝ) / ((K + 1 : ℕ) : ℝ) +
                (Real.log ((Y + 1 : ℕ) : ℝ) -
                  Real.log ((K + 1 : ℕ) : ℝ)) := htailH
          _ ≤ 1 + Real.log ((L + 1 : ℕ) : ℝ) :=
            add_le_add hinvK hlogratio
      have htail :=
        norm_etaHarmonicSawtooth_Icc_le_half_harmonic
          q chi r A (M := K + 1) (Y := Y) (by omega)
      rw [hsplit]
      calc
        ‖etaHarmonicSawtoothSum q chi r A K +
            ∑ m ∈ Finset.Icc (K + 1) Y,
              ((chi m) / (m : ℂ)) *
                (petermannSawtooth
                  (A / (m : ℝ) +
                    (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ)‖
          ≤ ‖etaHarmonicSawtoothSum q chi r A K‖ +
              ‖∑ m ∈ Finset.Icc (K + 1) Y,
                ((chi m) / (m : ℂ)) *
                  (petermannSawtooth
                    (A / (m : ℝ) +
                      (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ)‖ :=
            norm_add_le _ _
        _ ≤ eps * Real.log A +
              (1 / 2 : ℝ) *
                (∑ m ∈ Finset.Icc (K + 1) Y,
                  (1 : ℝ) / (m : ℝ)) :=
            add_le_add hprefix htail
        _ ≤ eps * Real.log A +
              (1 / 2 : ℝ) *
                (1 + Real.log ((L + 1 : ℕ) : ℝ)) := by
            exact add_le_add le_rfl
              (mul_le_mul_of_nonneg_left htailMass (by norm_num))
        _ = eps * Real.log A + C := by rfl

#print axioms etaHarmonicSawtooth_fixed_stretch

end PaperB.Analytic
