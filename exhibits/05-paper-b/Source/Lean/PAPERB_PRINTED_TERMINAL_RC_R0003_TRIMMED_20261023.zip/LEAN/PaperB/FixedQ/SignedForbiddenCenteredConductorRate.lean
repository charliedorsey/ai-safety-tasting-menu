import PaperB.FixedQ.SignedForbiddenCenteredConductorOuter
import PaperB.FixedQ.H2BooleanParameters

open scoped BigOperators

namespace PaperB.FixedQ

/-- Uniform centered outer court upgraded to the canonical strict log-power
shape used by the signed MAIN terminal.  This remains abstract in the source
channel: Caelis's S1 transport is the only intended later instantiation. -/
theorem sourceCenteredConductorEnhancedOuter_strictLogRate
    (S Rset : Finset ℕ) (hdis : Disjoint S Rset)
    (channel : Finset ℕ → ℝ)
    {K : ℝ} (hK : 0 ≤ K)
    (hchan : ∀ s ∈ S.powerset,
      |channel s| ≤
        K * (∏ p ∈ (s ∪ Rset),
          sourceCenteredConductorEnhancedPrimeMajorant p)) :
    ∃ C rho : ℝ, ∃ k : ℕ,
      0 ≤ C ∧ rho < 1 ∧
      ∀ h : ℕ, 16 ≤ h →
        |∑ s ∈ S.powerset, channel s| ≤
          C * (Real.log (h : ℝ)) ^ rho *
            (Real.log (Real.log (h : ℝ))) ^ k := by
  let E : ℝ :=
    Real.exp (∑' n : ℕ, sourceCenteredConductorEnhancedPrimeMajorant n)
  refine ⟨K * E ^ (2 : ℕ),
    h2BooleanSigma * h2BooleanX0, 2, ?_, h2BooleanSigma_mul_X0_lt_one, ?_⟩
  · dsimp [E]
    positivity
  · intro h hh
    have hbase :=
      sourceCenteredConductorEnhancedOuter_uniform_bound
        S Rset hdis channel hK hchan
    have hll1 :
        (1 : ℝ) ≤ Real.log (Real.log (h : ℝ)) :=
      one_le_log_log_nat_of_sixteen_le hh
    have hlogpos : 0 < Real.log (h : ℝ) := by
      exact Real.log_pos (by exact_mod_cast (show 1 < h by omega))
    have hexp :
        Real.exp 1 ≤ Real.exp (Real.log (Real.log (h : ℝ))) :=
      Real.exp_le_exp.mpr hll1
    rw [Real.exp_log hlogpos] at hexp
    have hexp1 : (1 : ℝ) ≤ Real.exp 1 := by
      rw [Real.one_le_exp_iff]
      norm_num
    have hlog1 : (1 : ℝ) ≤ Real.log (h : ℝ) :=
      hexp1.trans hexp
    have hrho0 :
        0 ≤ h2BooleanSigma * h2BooleanX0 := by
      exact mul_nonneg h2BooleanSigma_pos.le h2BooleanX0_pos.le
    have hlogpow1 :
        (1 : ℝ) ≤ (Real.log (h : ℝ)) ^
          (h2BooleanSigma * h2BooleanX0) :=
      Real.one_le_rpow hlog1 hrho0
    have hllpow1 :
        (1 : ℝ) ≤ (Real.log (Real.log (h : ℝ))) ^ (2 : ℕ) := by
      nlinarith [sq_nonneg
        (Real.log (Real.log (h : ℝ)) - 1)]
    have hC0 : 0 ≤ K * E ^ (2 : ℕ) := by
      dsimp [E]
      positivity
    calc
      |∑ s ∈ S.powerset, channel s|
        ≤ K * E ^ (2 : ℕ) := by simpa [E] using hbase
      _ ≤ (K * E ^ (2 : ℕ)) *
          (Real.log (h : ℝ)) ^
            (h2BooleanSigma * h2BooleanX0) := by
          exact le_mul_of_one_le_right hC0 hlogpow1
      _ ≤ (K * E ^ (2 : ℕ)) *
          (Real.log (h : ℝ)) ^
            (h2BooleanSigma * h2BooleanX0) *
          (Real.log (Real.log (h : ℝ))) ^ (2 : ℕ) := by
          have hleft :
              0 ≤ (K * E ^ (2 : ℕ)) *
                (Real.log (h : ℝ)) ^
                  (h2BooleanSigma * h2BooleanX0) :=
            mul_nonneg hC0 (Real.rpow_nonneg (by linarith) _)
          exact le_mul_of_one_le_right hleft hllpow1

#print axioms sourceCenteredConductorEnhancedOuter_strictLogRate

end PaperB.FixedQ
