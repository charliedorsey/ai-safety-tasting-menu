import GoldB.QuillonLowY

/-!
# Quillon CSC3 F5a: the R-route engine (VK along a residue class, plus Cauchy with a class split)

Inputs: `GoldB.shiftedSuzukiCore_unconditional` (Hunt B, GREEN). No other analytic input.

* `suzuki_AP`: for `Q ≥ 1`, `ρ < Q`, `1 ≤ N`, `M ≤ 2N`, `|Y| ≥ 2Q`,

      ‖Σ_{t∈(N,M]} e(Y/(ρ + Q t))‖ ≤ C·(N·exp(-c log³N / log²(|Y|/Q)) + N²·Q/|Y|).

  This holds for either sign of `Y`.
* `cauchy_class_split`: for any finite `𝒰, 𝒱`, any coefficients `a, b` and phases
  `F(v,u) = e(φ v u)·G v (u % Q)` with `‖G‖ ≤ 1`,

      ‖Σ_u b_u Σ_v a_v F(v,u)‖² ≤ (Σ_u ‖b_u‖²) · Σ_{v,v'} ‖a_v‖‖a_v'‖ · Σ_{ρ<Q} ‖Σ_{u∈I, u%Q=ρ} e(φ v u − φ v' u)‖,

  where the extended `u`-range is any `I ⊇ 𝒰`. This is the R0003 "absolute" Cauchy step: the
  mask on `u` is dropped by positivity, and the class phase is removed exactly per residue.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonR

/-- `e(x) = exp(2πi x)`. -/
noncomputable def eR (x : ℝ) : ℂ := Complex.exp (2 * Real.pi * Complex.I * (x : ℂ))

lemma norm_eR (x : ℝ) : ‖eR x‖ = 1 := by
  unfold eR
  rw [show 2 * Real.pi * Complex.I * (x : ℂ) = ((2 * Real.pi * x : ℝ) : ℂ) * Complex.I by
    push_cast; ring]
  exact Complex.norm_exp_ofReal_mul_I _

lemma eR_eq (x : ℝ) : eR x = Complex.exp (((2 * Real.pi * x : ℝ) : ℂ) * Complex.I) := by
  unfold eR; congr 1; push_cast; ring

lemma eR_neg (x : ℝ) : eR (-x) = (starRingEnd ℂ) (eR x) := by
  rw [eR_eq, eR_eq, ← Complex.exp_conj, map_mul, Complex.conj_ofReal, Complex.conj_I]
  congr 1; push_cast; ring

lemma eR_add (x y : ℝ) : eR (x + y) = eR x * eR y := by
  unfold eR; rw [← Complex.exp_add]; congr 1; push_cast; ring

lemma eR_sub (x y : ℝ) : eR (x - y) = eR x * (starRingEnd ℂ) (eR y) := by
  rw [sub_eq_add_neg, eR_add, eR_neg]

/-- **VK along a residue class.** -/
theorem suzuki_AP : ∃ c C : ℝ, 0 < c ∧ 0 ≤ C ∧
    ∀ (Q ρ N M : ℕ) (Y : ℝ), 1 ≤ Q → ρ < Q → 1 ≤ N → M ≤ 2 * N → 2 * (Q : ℝ) ≤ |Y| →
      ‖∑ t ∈ Ioc N M, eR (Y / ((ρ : ℝ) + Q * t))‖ ≤
        C * ((N : ℝ) * Real.exp (-(c * Real.log (N : ℝ) ^ 3 / Real.log (|Y| / Q) ^ 2)) +
          (N : ℝ) ^ 2 / (|Y| / Q)) := by
  obtain ⟨c, C, hc, hC, hS⟩ := GoldB.shiftedSuzukiCore_unconditional
  refine ⟨c, C, hc, hC, fun Q ρ N M Y hQ hρ hN hM hY => ?_⟩
  have hQR : (0 : ℝ) < Q := by exact_mod_cast hQ
  set ϑ : ℝ := (ρ : ℝ) / Q with hϑ
  have hϑ0 : 0 ≤ ϑ := by positivity
  have hϑ1 : ϑ ≤ 1 := by
    rw [hϑ, div_le_one hQR]; exact_mod_cast hρ.le
  have hY2 : 2 ≤ |Y| / Q := by rw [le_div_iff₀ hQR]; linarith
  have key := hS (|Y| / Q) hY2 N hN ϑ hϑ0 hϑ1 M hM
  -- termwise identity: Y/(ρ + Q t) = (Y/Q)/(t + ϑ)
  have hterm : ∀ t ∈ Ioc N M, eR (Y / ((ρ : ℝ) + Q * t)) =
      eR ((Y / Q) / ((t : ℝ) + ϑ)) := by
    intro t _
    congr 1
    rw [hϑ]; field_simp; ring
  rw [Finset.sum_congr rfl hterm]
  rcases le_or_gt 0 Y with hY0 | hY0
  · have habs : |Y| = Y := abs_of_nonneg hY0
    have : ∑ t ∈ Ioc N M, eR ((Y / Q) / ((t : ℝ) + ϑ)) =
        GoldB.Iface.shiftedModeSum 1 (|Y| / Q) ϑ 0 N M := by
      unfold GoldB.Iface.shiftedModeSum GoldB.Iface.shiftedExpMode
      refine Finset.sum_congr rfl fun t _ => ?_
      unfold eR; rw [habs]; push_cast; ring_nf
    rw [this]; exact key
  · have habs : |Y| = -Y := abs_of_neg hY0
    have : ∑ t ∈ Ioc N M, eR ((Y / Q) / ((t : ℝ) + ϑ)) =
        (starRingEnd ℂ) (GoldB.Iface.shiftedModeSum 1 (|Y| / Q) ϑ 0 N M) := by
      unfold GoldB.Iface.shiftedModeSum
      rw [map_sum]
      refine Finset.sum_congr rfl fun t _ => ?_
      have : GoldB.Iface.shiftedExpMode 1 (|Y| / Q) ϑ 0 t = eR (-((Y / Q) / ((t : ℝ) + ϑ))) := by
        unfold GoldB.Iface.shiftedExpMode eR; rw [habs]; push_cast; ring_nf
      rw [this, eR_neg, Complex.conj_conj]
    rw [this, Complex.norm_conj]; exact key

/-! ## Cauchy with the `u`-mask dropped and the class phase split exactly -/

theorem cauchy_class_split {Q : ℕ} (hQ : 1 ≤ Q) (𝒰 I 𝒱 : Finset ℕ) (h𝒰 : 𝒰 ⊆ I)
    (a b : ℕ → ℂ) (φ : ℕ → ℕ → ℝ) (G : ℕ → ℕ → ℂ) (hG : ∀ v ρ, ‖G v ρ‖ ≤ 1) :
    ‖∑ u ∈ 𝒰, b u * ∑ v ∈ 𝒱, a v * (eR (φ v u) * G v (u % Q))‖ ^ 2 ≤
      (∑ u ∈ 𝒰, ‖b u‖ ^ 2) *
        ∑ v ∈ 𝒱, ∑ v' ∈ 𝒱, ‖a v‖ * ‖a v'‖ *
          ∑ ρ ∈ range Q, ‖∑ u ∈ I.filter (fun u => u % Q = ρ), eR (φ v u - φ v' u)‖ := by
  set F : ℕ → ℂ := fun u => ∑ v ∈ 𝒱, a v * (eR (φ v u) * G v (u % Q)) with hF
  -- Cauchy–Schwarz
  have hCS : ‖∑ u ∈ 𝒰, b u * F u‖ ^ 2 ≤ (∑ u ∈ 𝒰, ‖b u‖ ^ 2) * ∑ u ∈ 𝒰, ‖F u‖ ^ 2 := by
    have h1 : ‖∑ u ∈ 𝒰, b u * F u‖ ≤ ∑ u ∈ 𝒰, ‖b u‖ * ‖F u‖ :=
      (norm_sum_le _ _).trans (le_of_eq (Finset.sum_congr rfl fun u _ => norm_mul _ _))
    have h3 : (∑ u ∈ 𝒰, ‖b u‖ * ‖F u‖) ^ 2 ≤
        (∑ u ∈ 𝒰, ‖b u‖ ^ 2) * ∑ u ∈ 𝒰, ‖F u‖ ^ 2 :=
      Finset.sum_mul_sq_le_sq_mul_sq 𝒰 (fun u => ‖b u‖) (fun u => ‖F u‖)
    calc ‖∑ u ∈ 𝒰, b u * F u‖ ^ 2 ≤ (∑ u ∈ 𝒰, ‖b u‖ * ‖F u‖) ^ 2 := by
          gcongr
      _ ≤ _ := h3
  refine hCS.trans (mul_le_mul_of_nonneg_left ?_ (Finset.sum_nonneg fun u _ => by positivity))
  -- drop the mask: Σ_{𝒰} ‖F‖² ≤ Σ_I ‖F‖²
  have hdrop : ∑ u ∈ 𝒰, ‖F u‖ ^ 2 ≤ ∑ u ∈ I, ‖F u‖ ^ 2 :=
    Finset.sum_le_sum_of_subset_of_nonneg h𝒰 fun u _ _ => by positivity
  refine hdrop.trans ?_
  -- expand ‖F u‖² = Σ_{v,v'} a_v conj(a_v') e(φ v u - φ v' u) G v ρ conj(G v' ρ)
  have hexp : ∀ u, ((‖F u‖ ^ 2 : ℝ) : ℂ) = ∑ v ∈ 𝒱, ∑ v' ∈ 𝒱,
      a v * (starRingEnd ℂ) (a v') * (eR (φ v u - φ v' u) *
        (G v (u % Q) * (starRingEnd ℂ) (G v' (u % Q)))) := by
    intro u
    rw [Complex.ofReal_pow, ← Complex.mul_conj', hF]
    simp only [map_sum, map_mul]
    rw [Finset.sum_mul_sum]
    refine Finset.sum_congr rfl fun v _ => Finset.sum_congr rfl fun v' _ => ?_
    rw [eR_sub]; ring
  -- regroup by classes
  have hreal : ∑ u ∈ I, ‖F u‖ ^ 2 = ‖∑ u ∈ I, ((‖F u‖ ^ 2 : ℝ) : ℂ)‖ := by
    rw [← Complex.ofReal_sum, Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (Finset.sum_nonneg fun u _ => by positivity)]
  rw [hreal]
  simp_rw [hexp]
  rw [Finset.sum_comm]
  refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun v _ => ?_)
  rw [Finset.sum_comm]
  refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun v' _ => ?_)
  -- split I by residue classes
  have hsplit : ∑ u ∈ I, a v * (starRingEnd ℂ) (a v') * (eR (φ v u - φ v' u) *
        (G v (u % Q) * (starRingEnd ℂ) (G v' (u % Q)))) =
      a v * (starRingEnd ℂ) (a v') * ∑ ρ ∈ range Q, (G v ρ * (starRingEnd ℂ) (G v' ρ)) *
        ∑ u ∈ I.filter (fun u => u % Q = ρ), eR (φ v u - φ v' u) := by
    rw [← Finset.mul_sum]
    congr 1
    rw [← Finset.sum_fiberwise_of_maps_to (g := fun u => u % Q) (t := range Q)
      (fun u _ => Finset.mem_range.2 (Nat.mod_lt _ (by omega)))]
    refine Finset.sum_congr rfl fun ρ _ => ?_
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun u hu => ?_
    rw [(Finset.mem_filter.1 hu).2]; ring
  rw [hsplit, norm_mul, norm_mul, Complex.norm_conj]
  gcongr
  refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun ρ _ => ?_)
  rw [norm_mul, norm_mul, Complex.norm_conj]
  have h1 := hG v ρ
  have h2 := hG v' ρ
  calc ‖G v ρ‖ * ‖G v' ρ‖ * ‖∑ u ∈ I.filter (fun u => u % Q = ρ), eR (φ v u - φ v' u)‖
      ≤ 1 * 1 * ‖∑ u ∈ I.filter (fun u => u % Q = ρ), eR (φ v u - φ v' u)‖ := by gcongr
    _ = _ := by ring

/-! ## Residue-class reindexing and the assembled R bound -/

lemma classFilter_eq_image (Q ρ U₀ U₁ : ℕ) (hQ : 1 ≤ Q) (hρ : ρ < Q) (hρU : ρ ≤ U₀) :
    (Ioc U₀ U₁).filter (fun u => u % Q = ρ) =
      (Ioc ((U₀ - ρ) / Q) ((U₁ - ρ) / Q)).image (fun t => ρ + Q * t) := by
  have hQ0 : 0 < Q := by omega
  ext u
  simp only [Finset.mem_filter, Finset.mem_Ioc, Finset.mem_image]
  constructor
  · rintro ⟨⟨h1, h2⟩, h3⟩
    have hdm : Q * (u / Q) + ρ = u := by
      have := Nat.div_add_mod u Q; rw [h3] at this; exact this
    have hq : u / Q * Q = u - ρ := by rw [Nat.mul_comm]; omega
    refine ⟨u / Q, ⟨?_, ?_⟩, by omega⟩
    · rw [Nat.div_lt_iff_lt_mul hQ0]; omega
    · rw [Nat.le_div_iff_mul_le hQ0]; omega
  · rintro ⟨t, ⟨h1, h2⟩, rfl⟩
    have ht : t * Q = Q * t := Nat.mul_comm _ _
    have h1' : U₀ - ρ < t * Q := (Nat.div_lt_iff_lt_mul hQ0).1 h1
    have h2' : t * Q ≤ U₁ - ρ := (Nat.le_div_iff_mul_le hQ0).1 h2
    refine ⟨⟨by omega, by omega⟩, ?_⟩
    rw [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt hρ]

/-- One class, one off-diagonal pair: VK along the class. -/
theorem class_offdiag :
    ∃ c C : ℝ, 0 < c ∧ 0 ≤ C ∧
      ∀ (Q ρ U₀ U₁ : ℕ) (Y : ℝ), 1 ≤ Q → ρ < Q → 2 * Q ≤ U₀ → U₁ + 2 * Q ≤ 2 * U₀ →
        2 * (Q : ℝ) ≤ |Y| →
        ‖∑ u ∈ (Ioc U₀ U₁).filter (fun u => u % Q = ρ), eR (Y / u)‖ ≤
          C * ((((U₀ - ρ) / Q : ℕ) : ℝ) * Real.exp (-(c * Real.log (((U₀ - ρ) / Q : ℕ) : ℝ) ^ 3 /
              Real.log (|Y| / Q) ^ 2)) + (((U₀ - ρ) / Q : ℕ) : ℝ) ^ 2 / (|Y| / Q)) := by
  obtain ⟨c, C, hc, hC, hS⟩ := suzuki_AP
  refine ⟨c, C, hc, hC, fun Q ρ U₀ U₁ Y hQ hρ hU₀ hU₁ hY => ?_⟩
  rw [classFilter_eq_image Q ρ U₀ U₁ hQ hρ (by omega)]
  have hinj : Set.InjOn (fun t => ρ + Q * t) (Ioc ((U₀ - ρ) / Q) ((U₁ - ρ) / Q) : Set ℕ) := by
    intro x _ y _ h
    exact Nat.eq_of_mul_eq_mul_left (show 0 < Q by omega) (Nat.add_left_cancel h)
  rw [Finset.sum_image hinj]
  have hN : 1 ≤ (U₀ - ρ) / Q := by
    rw [Nat.le_div_iff_mul_le (by omega)]; omega
  have hM : (U₁ - ρ) / Q ≤ 2 * ((U₀ - ρ) / Q) := by
    set N := (U₀ - ρ) / Q
    have h1 : Q * N + (U₀ - ρ) % Q = U₀ - ρ := Nat.div_add_mod (U₀ - ρ) Q
    have h2 := Nat.mod_lt (U₀ - ρ) (show 0 < Q by omega)
    have h3 : (U₁ - ρ) / Q < 2 * N + 1 := by
      rw [Nat.div_lt_iff_lt_mul (by omega), show (2 * N + 1) * Q = 2 * (Q * N) + Q by ring]
      omega
    omega
  have := hS Q ρ ((U₀ - ρ) / Q) ((U₁ - ρ) / Q) Y hQ hρ hN hM hY
  simp only [Nat.cast_add, Nat.cast_mul]
  exact this

end GoldC.QuillonR

#print axioms GoldC.QuillonR.classFilter_eq_image
#print axioms GoldC.QuillonR.class_offdiag
#print axioms GoldC.QuillonR.suzuki_AP
#print axioms GoldC.QuillonR.cauchy_class_split
