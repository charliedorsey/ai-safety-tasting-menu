import Orienne.CSC3.PhysicalCoreBridgeR0001
import PaperB.Gate3.CentralTransfer.MiddleLongCoreConsumer

/-!
A real production-source CORE discharge with the already-verified
Quillon R0014 complete signed analytic rate. This does not assume CORE.
The exact remaining physical source obligations are LONG, LOW, HIGH.
-/

open scoped BigOperators Classical
namespace Orienne.CSC3

/-- Signed MIDDLE follows from signed LONG alone: native CORE is paid. -/
theorem native_middle_sublog_of_long
    (Jlow Jhigh : ℕ → ℕ) (δ : ℝ)
    (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3)
    (hLong : Merivelle.Central.SourceUniformSublog
      (Merivelle.Central.signedLongMiddle Jlow Jhigh δ)) :
    Merivelle.Central.SourceUniformSublog
      (Merivelle.Central.middleSector Jlow Jhigh) :=
  Merivelle.Central.middleSublog_of_long_core Jlow Jhigh δ hLong
    (core_source_native_sublog Jlow Jhigh δ hδ0 hδ1)

/-- Literal Paper B terminal statement from only three remaining
source-true signed sector rates; no copied CORE observable occurs
in either the conclusion or the hypotheses. -/
theorem paperB_terminal_of_native_low_high_long
    (Jlow Jhigh : ℕ → ℕ) (δ : ℝ)
    (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3)
    (hord : ∀ h, Jlow h ≤ Jhigh h)
    (hLow : Merivelle.Central.SourceUniformSublog
      (Merivelle.Central.lowSector Jlow))
    (hHigh : Merivelle.Central.SourceUniformSublog
      (Merivelle.Central.highSector Jhigh))
    (hLong : Merivelle.Central.SourceUniformSublog
      (Merivelle.Central.signedLongMiddle Jlow Jhigh δ)) :
    PaperB.Closure.PaperBTerminalStatement :=
  Merivelle.Central.paperB_terminal_of_low_high_long_core
    Jlow Jhigh δ hord hLow hHigh hLong
    (core_source_native_sublog Jlow Jhigh δ hδ0 hδ1)

#print axioms native_middle_sublog_of_long
#print axioms paperB_terminal_of_native_low_high_long
end Orienne.CSC3
