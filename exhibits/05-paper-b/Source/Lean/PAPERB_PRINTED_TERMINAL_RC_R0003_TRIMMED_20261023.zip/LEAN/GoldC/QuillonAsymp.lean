import GoldC.QuillonDivisorMoment
import GoldC.QuillonWContext
import Mathlib.Analysis.SpecialFunctions.Pow.Real

/-!
# Quillon CSC3 F7.9a: asymptotic toolkit (number of prime factors, gcd mode sums)

* `card_le_y`: for a set `C` of primes and any `y > 1`, `|C| ≤ y + 1 + log(∏C)/log y`.
* `four_pow_card_le`: for every `η > 0` there is `L₀` such that `log ∏C ≥ L₀` implies
  `4^{|C|} ≤ (∏C)^η`. This is the bound `ω(s) = o(log s)` in the form the routes use.
* `gcd_mode_sum`: `Σ_{j≤J} (1/j)·(∏_{p∈C, p|j} p)^a ≤ (1 + log J)·∏_{p∈C}(1 + p^{a−1})` for `0 ≤ a ≤ 1`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonAsymp

lemma card_le_y (C : Finset ℕ) (hC : ∀ p ∈ C, p.Prime) (y : ℝ) (hy : 1 < y) :
    (C.card : ℝ) ≤ y + 1 + Real.log ((∏ p ∈ C, p : ℕ) : ℝ) / Real.log y := by
  classical
  set Cs := C.filter (fun p : ℕ => (p : ℝ) < y) with hCs
  set Cb := C.filter (fun p : ℕ => ¬ (p : ℝ) < y) with hCb
  have hsplit : C.card = Cs.card + Cb.card := (card_filter_add_card_filter_not _).symm
  -- small primes
  have hs : (Cs.card : ℝ) ≤ y + 1 := by
    have hsub : Cs ⊆ range ⌈y⌉₊ := by
      intro p hp
      rw [hCs, mem_filter] at hp
      rw [mem_range]
      exact Nat.cast_lt.1 (lt_of_lt_of_le hp.2 (Nat.le_ceil y))
    have := card_le_card hsub
    rw [card_range] at this
    have h2 : (⌈y⌉₊ : ℝ) ≤ y + 1 := (Nat.ceil_lt_add_one (by linarith)).le
    exact (Nat.cast_le.2 this).trans h2
  -- large primes
  have hlogy : 0 < Real.log y := Real.log_pos hy
  have hb : (Cb.card : ℝ) ≤ Real.log ((∏ p ∈ C, p : ℕ) : ℝ) / Real.log y := by
    rw [le_div_iff₀ hlogy]
    have hpos : ∀ p ∈ C, (0 : ℝ) < p := fun p hp => by exact_mod_cast (hC p hp).pos
    have h1 : y ^ Cb.card ≤ ∏ p ∈ Cb, (p : ℝ) := by
      rw [← prod_const]
      refine prod_le_prod₀ (fun _ _ => by linarith) fun p hp => ?_
      rw [hCb, mem_filter] at hp; push Not at hp; exact hp.2
    have h2 : ∏ p ∈ Cb, (p : ℝ) ≤ ∏ p ∈ C, (p : ℝ) := by
      rw [← prod_filter_mul_prod_filter_not C (fun p : ℕ => ¬ (p : ℝ) < y)]
      have h1' : (1 : ℝ) ≤ ∏ p ∈ C.filter (fun p : ℕ => ¬ ¬ (p : ℝ) < y), (p : ℝ) :=
        one_le_prod₀ fun p hp => by exact_mod_cast (hC p (filter_subset _ _ hp)).one_le
      have h0 : 0 ≤ ∏ p ∈ Cb, (p : ℝ) := prod_nonneg fun p _ => Nat.cast_nonneg _
      rw [hCb] at h0 ⊢
      nlinarith
    have h3 : Real.log (y ^ Cb.card) ≤ Real.log ((∏ p ∈ C, p : ℕ) : ℝ) := by
      apply Real.log_le_log (by positivity)
      push_cast; linarith
    rw [Real.log_pow] at h3
    linarith
  rw [hsplit, Nat.cast_add]; linarith

/-- `ω(s) = o(log s)`, in the form `4^{ω(s)} ≤ s^η`. -/
theorem four_pow_card_le (η : ℝ) (hη : 0 < η) :
    ∃ L₀ : ℝ, 0 < L₀ ∧ ∀ C : Finset ℕ, (∀ p ∈ C, p.Prime) →
      L₀ ≤ Real.log ((∏ p ∈ C, p : ℕ) : ℝ) →
        (4 : ℝ) ^ C.card ≤ ((∏ p ∈ C, p : ℕ) : ℝ) ^ η := by
  set c := Real.log 4 with hc
  have hc0 : 0 < c := Real.log_pos (by norm_num)
  set L₀ := max 16 (max ((8 * c / η) ^ 2) (Real.exp (8 * c / η))) with hL₀
  refine ⟨L₀, by positivity, fun C hC hL => ?_⟩
  set ℓ := Real.log ((∏ p ∈ C, p : ℕ) : ℝ) with hℓ
  have hℓ16 : 16 ≤ ℓ := le_trans (le_max_left _ _) hL
  have hℓsq : (8 * c / η) ^ 2 ≤ ℓ := le_trans (le_trans (le_max_left _ _) (le_max_right _ _)) hL
  have hℓexp : Real.exp (8 * c / η) ≤ ℓ := le_trans (le_trans (le_max_right _ _) (le_max_right _ _)) hL
  have hsqrt : 4 ≤ Real.sqrt ℓ := by
    rw [show (4 : ℝ) = Real.sqrt 16 by rw [show (16 : ℝ) = 4 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]]
    exact Real.sqrt_le_sqrt hℓ16
  have hcard := card_le_y C hC (Real.sqrt ℓ) (by linarith)
  have hlogsqrt : Real.log (Real.sqrt ℓ) = Real.log ℓ / 2 := by
    rw [Real.log_sqrt (by linarith)]
  have hlogℓ : 8 * c / η ≤ Real.log ℓ := by
    rw [← Real.log_exp (8 * c / η)]; exact Real.log_le_log (Real.exp_pos _) hℓexp
  have hlogℓpos : 0 < Real.log ℓ := lt_of_lt_of_le (by positivity) hlogℓ
  have hsq2 : 8 * c / η ≤ Real.sqrt ℓ := by
    rw [← Real.sqrt_sq (by positivity : 0 ≤ 8 * c / η)]; exact Real.sqrt_le_sqrt hℓsq
  have hsqℓ : Real.sqrt ℓ * Real.sqrt ℓ = ℓ := Real.mul_self_sqrt (by linarith)
  -- `|C|·c ≤ η ℓ`
  have hkey : (C.card : ℝ) * c ≤ η * ℓ := by
    rw [hlogsqrt] at hcard
    have e1 : ℓ / (Real.log ℓ / 2) = 2 * ℓ / Real.log ℓ := by field_simp
    rw [e1] at hcard
    have t1 : (Real.sqrt ℓ + 1) * c ≤ η * ℓ / 2 := by
      have : (Real.sqrt ℓ + 1) * c ≤ 2 * Real.sqrt ℓ * c := by nlinarith
      have h2 : 2 * Real.sqrt ℓ * c ≤ η * ℓ / 2 := by
        have h8 : 8 * c ≤ η * Real.sqrt ℓ := by
          have := hsq2; rw [div_le_iff₀ hη] at this; linarith
        have hs0 : 0 ≤ Real.sqrt ℓ := Real.sqrt_nonneg _
        nlinarith
      linarith
    have t2 : 2 * ℓ / Real.log ℓ * c ≤ η * ℓ / 2 := by
      rw [div_mul_eq_mul_div, div_le_iff₀ hlogℓpos]
      have := mul_le_mul_of_nonneg_left hlogℓ (show 0 ≤ η * ℓ / 2 by positivity)
      have h4 : η * ℓ / 2 * (8 * c / η) = 4 * c * ℓ := by field_simp; ring
      nlinarith
    nlinarith
  have hprod_pos : (0 : ℝ) < ((∏ p ∈ C, p : ℕ) : ℝ) := by
    have : 0 < ∏ p ∈ C, p := prod_pos fun p hp => (hC p hp).pos
    exact_mod_cast this
  rw [← Real.exp_log hprod_pos, ← Real.exp_mul, ← hℓ]
  rw [show (4 : ℝ) ^ C.card = Real.exp (C.card * c) by
    rw [hc, mul_comm, Real.exp_mul, Real.exp_log (by norm_num)]; norm_cast]
  exact Real.exp_le_exp.2 (by linarith)

/-- A set of distinct primes divides `j` iff each of them does. -/
lemma prod_dvd_iff (D : Finset ℕ) (hD : ∀ p ∈ D, p.Prime) (j : ℕ) :
    (∏ p ∈ D, p) ∣ j ↔ ∀ p ∈ D, p ∣ j := by
  constructor
  · intro h p hp; exact (dvd_prod_of_mem _ hp).trans h
  · intro h
    exact Finset.prod_primes_dvd j (fun p hp => (hD p hp).prime) h

/-- **The gcd mode sum.** -/
theorem gcd_mode_sum (C : Finset ℕ) (hC : ∀ p ∈ C, p.Prime) (J : ℕ) (a : ℝ) (ha0 : 0 ≤ a)
    (ha1 : a ≤ 1) :
    ∑ j ∈ Icc 1 J, (1 / (j : ℝ)) * (((∏ p ∈ C.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ a) ≤
      (1 + Real.log J) * ∏ p ∈ C, (1 + (p : ℝ) ^ (a - 1)) := by
  classical
  set w : Finset ℕ → ℝ := fun D => ∏ p ∈ D, ((p : ℝ) ^ a - 1) with hw
  have hw0 : ∀ D ⊆ C, 0 ≤ w D := fun D hD => prod_nonneg fun p hp => by
    have : (1 : ℝ) ≤ (p : ℝ) ^ a := Real.one_le_rpow (by exact_mod_cast (hC p (hD hp)).one_le) ha0
    linarith
  have hexp : ∀ j, (((∏ p ∈ C.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ a) =
      ∑ D ∈ C.powerset, (if (∏ p ∈ D, p) ∣ j then w D else 0) := by
    intro j
    rw [Nat.cast_prod, ← Real.finset_prod_rpow _ _ (fun p _ => Nat.cast_nonneg p)]
    have h1 : ∏ p ∈ C.filter (fun p => p ∣ j), (p : ℝ) ^ a =
        ∏ p ∈ C.filter (fun p => p ∣ j), (1 + ((p : ℝ) ^ a - 1)) :=
      prod_congr rfl fun p _ => by ring
    rw [h1, prod_one_add]
    rw [← sum_filter]
    apply sum_congr
    · ext D
      simp only [mem_powerset, mem_filter]
      constructor
      · intro hD
        exact ⟨hD.trans (filter_subset _ _), (prod_dvd_iff D (fun p hp => hC p ((hD.trans
          (filter_subset _ _)) hp)) j).2 fun p hp => (mem_filter.1 (hD hp)).2⟩
      · rintro ⟨hD, hdvd⟩ p hp
        exact mem_filter.2 ⟨hD hp, (prod_dvd_iff D (fun p hp => hC p (hD hp)) j).1 hdvd p hp⟩
    · intro D _; rfl
  have hJ : Icc 1 J = Ioc 0 J := by ext j; simp only [mem_Icc, mem_Ioc]; omega
  calc ∑ j ∈ Icc 1 J, (1 / (j : ℝ)) * (((∏ p ∈ C.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ a)
      = ∑ D ∈ C.powerset, w D * ∑ j ∈ (Ioc 0 J).filter (fun j => (∏ p ∈ D, p) ∣ j), (1 / (j : ℝ)) := by
        simp only [hexp, mul_sum]
        rw [hJ, sum_comm]
        refine sum_congr rfl fun D _ => ?_
        rw [sum_filter]
        refine sum_congr rfl fun j _ => ?_
        split_ifs <;> ring
    _ ≤ ∑ D ∈ C.powerset, w D * ((1 / ((∏ p ∈ D, p : ℕ) : ℝ)) * (1 + Real.log J)) := by
        refine sum_le_sum fun D hD => mul_le_mul_of_nonneg_left ?_ (hw0 D (mem_powerset.1 hD))
        exact GoldC.QuillonDivisorMoment.sum_inv_multiples _ J (Nat.one_le_iff_ne_zero.2 (prod_ne_zero_iff.2 fun p hp =>
          (hC p ((mem_powerset.1 hD) hp)).ne_zero))
    _ ≤ ∑ D ∈ C.powerset, (∏ p ∈ D, (p : ℝ) ^ (a - 1)) * (1 + Real.log J) := by
        refine sum_le_sum fun D hD => ?_
        have hDC := mem_powerset.1 hD
        have hlog : 0 ≤ 1 + Real.log J := GoldC.QuillonDivisorMoment.one_add_log_nonneg J
        rw [← mul_assoc]
        apply mul_le_mul_of_nonneg_right _ hlog
        rw [Nat.cast_prod, one_div, ← prod_inv_distrib]
        simp only [hw]
        rw [← prod_mul_distrib]
        refine prod_le_prod₀ (fun p hp => ?_) fun p hp => ?_
        · have : (1 : ℝ) ≤ (p : ℝ) ^ a := Real.one_le_rpow (by exact_mod_cast (hC p (hDC hp)).one_le) ha0
          have : (0 : ℝ) < p := by exact_mod_cast (hC p (hDC hp)).pos
          have : 0 ≤ (p : ℝ) ^ a - 1 := by linarith
          positivity
        · have hp0 : (0 : ℝ) < p := by exact_mod_cast (hC p (hDC hp)).pos
          rw [Real.rpow_sub hp0, Real.rpow_one, div_eq_mul_inv]
          apply mul_le_mul_of_nonneg_right _ (by positivity)
          linarith
    _ = (1 + Real.log J) * ∏ p ∈ C, (1 + (p : ℝ) ^ (a - 1)) := by
        rw [← sum_mul, mul_comm, prod_one_add]

/-- `b^{ω(s)} ≤ s^η` for large `log s` (any base `b ≥ 2`). -/
theorem base_pow_card_le (b : ℝ) (hb : 2 ≤ b) (η : ℝ) (hη : 0 < η) :
    ∃ L₀ : ℝ, 0 < L₀ ∧ ∀ C : Finset ℕ, (∀ p ∈ C, p.Prime) →
      L₀ ≤ Real.log ((∏ p ∈ C, p : ℕ) : ℝ) →
        b ^ C.card ≤ ((∏ p ∈ C, p : ℕ) : ℝ) ^ η := by
  -- reduce to base 4: `b ≤ 4^{t}` with `t = log b / log 4`
  set t := Real.log b / Real.log 4 with ht
  have hl4 : 0 < Real.log 4 := Real.log_pos (by norm_num)
  have hlb : 0 < Real.log b := Real.log_pos (by linarith)
  have ht0 : 0 < t := div_pos hlb hl4
  obtain ⟨L₀, hL₀, hL⟩ := four_pow_card_le (η / t) (div_pos hη ht0)
  refine ⟨L₀, hL₀, fun C hC hLC => ?_⟩
  have h1 := hL C hC hLC
  have hb4 : b = (4 : ℝ) ^ t := by
    rw [ht, Real.rpow_def_of_pos (by norm_num),
      show Real.log 4 * (Real.log b / Real.log 4) = Real.log b by field_simp,
      Real.exp_log (by linarith)]
  have hprod_pos : (0 : ℝ) < ((∏ p ∈ C, p : ℕ) : ℝ) := by
    have : 0 < ∏ p ∈ C, p := prod_pos fun p hp => (hC p hp).pos
    exact_mod_cast this
  calc b ^ C.card = ((4 : ℝ) ^ C.card) ^ t := by
        rw [hb4, ← Real.rpow_natCast, ← Real.rpow_natCast, ← Real.rpow_mul (by norm_num),
          ← Real.rpow_mul (by norm_num), mul_comm]
    _ ≤ (((∏ p ∈ C, p : ℕ) : ℝ) ^ (η / t)) ^ t :=
        Real.rpow_le_rpow (by positivity) h1 ht0.le
    _ = ((∏ p ∈ C, p : ℕ) : ℝ) ^ η := by
        rw [← Real.rpow_mul hprod_pos.le, div_mul_cancel₀ _ ht0.ne']

/-- `(1 + log x)^m ≤ x^c` for large `x`. -/
theorem one_add_log_pow_le (m : ℕ) (c : ℝ) (hc : 0 < c) :
    ∃ x₀ : ℝ, 1 ≤ x₀ ∧ ∀ x : ℝ, x₀ ≤ x → (1 + Real.log x) ^ m ≤ x ^ c := by
  rcases Nat.eq_zero_or_pos m with hm | hm
  · refine ⟨1, le_rfl, fun x hx => ?_⟩
    rw [hm, pow_zero]; exact Real.one_le_rpow hx hc.le
  set η := c / (2 * m) with hη
  have hmR : (0 : ℝ) < m := by exact_mod_cast hm
  have hη0 : 0 < η := by positivity
  set K := (1 + 1 / η) ^ m with hK
  have hK1 : 1 ≤ K := one_le_pow₀ (by have : 0 < 1 / η := by positivity
                                      linarith)
  refine ⟨max 1 (K ^ (2 / c)), le_max_left _ _, fun x hx => ?_⟩
  have hx1 : 1 ≤ x := le_trans (le_max_left _ _) hx
  have hx0 : 0 < x := by linarith
  have hxη : 1 ≤ x ^ η := Real.one_le_rpow hx1 hη0.le
  have hlog : 1 + Real.log x ≤ (1 + 1 / η) * x ^ η := by
    have := Real.log_le_rpow_div hx0.le hη0
    have : x ^ η / η = (1 / η) * x ^ η := by ring
    nlinarith
  have hlog0 : 0 ≤ 1 + Real.log x := by have := Real.log_nonneg hx1; linarith
  have h1 : (1 + Real.log x) ^ m ≤ K * x ^ (c / 2) := by
    calc (1 + Real.log x) ^ m ≤ ((1 + 1 / η) * x ^ η) ^ m := pow_le_pow_left₀ hlog0 hlog m
      _ = K * (x ^ η) ^ m := by rw [mul_pow]
      _ = K * x ^ (c / 2) := by
          rw [← Real.rpow_natCast, ← Real.rpow_mul hx0.le]; congr 2; rw [hη]; field_simp
  have h2 : K ≤ x ^ (c / 2) := by
    have hx2 : K ^ (2 / c) ≤ x := le_trans (le_max_right _ _) hx
    calc K = (K ^ (2 / c)) ^ (c / 2) := by
          rw [← Real.rpow_mul (by linarith)]; field_simp; simp
      _ ≤ x ^ (c / 2) := Real.rpow_le_rpow (by positivity) hx2 (by positivity)
  calc (1 + Real.log x) ^ m ≤ K * x ^ (c / 2) := h1
    _ ≤ x ^ (c / 2) * x ^ (c / 2) := mul_le_mul_of_nonneg_right h2 (by positivity)
    _ = x ^ c := by rw [← Real.rpow_add hx0]; ring_nf

/-- `Λ^k ≤ exp(c Λ^σ)` for large `Λ`. -/
theorem rpow_le_exp_rpow (k c σ : ℝ) (hk : 0 ≤ k) (hc : 0 < c) (hσ : 0 < σ) :
    ∃ Λ₀ : ℝ, 1 ≤ Λ₀ ∧ ∀ Λ : ℝ, Λ₀ ≤ Λ → Λ ^ k ≤ Real.exp (c * Λ ^ σ) := by
  set τ := σ / 2 with hτ
  have hτ0 : 0 < τ := by positivity
  -- `k log Λ ≤ (k/τ) Λ^τ ≤ c Λ^σ` once `Λ^τ ≥ k/(τ c)`
  set A := k / (τ * c) with hA
  refine ⟨max 1 ((A + 1) ^ (1 / τ)), le_max_left _ _, fun Λ hΛ => ?_⟩
  have hΛ1 : 1 ≤ Λ := le_trans (le_max_left _ _) hΛ
  have hΛ0 : 0 < Λ := by linarith
  rw [← Real.exp_log (Real.rpow_pos_of_pos hΛ0 k), Real.log_rpow hΛ0]
  apply Real.exp_le_exp.2
  have hlog := Real.log_le_rpow_div hΛ0.le hτ0
  have hΛτ : A + 1 ≤ Λ ^ τ := by
    have h1 : (A + 1) ^ (1 / τ) ≤ Λ := le_trans (le_max_right _ _) hΛ
    have hA0 : 0 ≤ A := by positivity
    calc A + 1 = ((A + 1) ^ (1 / τ)) ^ τ := by
          rw [← Real.rpow_mul (by linarith)]; field_simp; simp
      _ ≤ Λ ^ τ := Real.rpow_le_rpow (by positivity) h1 hτ0.le
  have hσ2 : Λ ^ σ = Λ ^ τ * Λ ^ τ := by
    rw [← Real.rpow_add hΛ0]; congr 1; rw [hτ]; ring
  have hΛτ0 : 0 < Λ ^ τ := Real.rpow_pos_of_pos hΛ0 τ
  calc k * Real.log Λ ≤ k * (Λ ^ τ / τ) := mul_le_mul_of_nonneg_left hlog hk
    _ = (k / τ) * Λ ^ τ := by ring
    _ ≤ (c * Λ ^ τ) * Λ ^ τ := by
        apply mul_le_mul_of_nonneg_right _ hΛτ0.le
        have : k / τ = c * A := by rw [hA]; field_simp
        rw [this]; nlinarith
    _ = c * Λ ^ σ := by rw [hσ2]; ring

end GoldC.QuillonAsymp

#print axioms GoldC.QuillonAsymp.card_le_y
#print axioms GoldC.QuillonAsymp.four_pow_card_le
#print axioms GoldC.QuillonAsymp.gcd_mode_sum
#print axioms GoldC.QuillonAsymp.base_pow_card_le
#print axioms GoldC.QuillonAsymp.one_add_log_pow_le
#print axioms GoldC.QuillonAsymp.rpow_le_exp_rpow
