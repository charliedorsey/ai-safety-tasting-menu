import Mathlib.NumberTheory.Primorial
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Tactic

/-!
# Quillon CSC3 F7.1: the MIDDLE pair sum as a double sum over `(r, s)`

Verbatim copies (namespace `GoldC.QuillonCopyS`) of the curated `GoldC/SourceCore.lean` definitions
`primeSetProduct`, `activeHighPrime`, `omegaWeight`, `booleanSigma`, `booleanSourceCutoff`,
`originalZ`, `ordinaryFiniteSupport` and `quarterParents`, together with the curated
`Merivelle.Central.regionPairSumMiddleWhere`.

**Theorem `pairSum_eq_double`.** For any gate, predicate and row `G`:

    regionPairSumMiddleWhere Jlow Jhigh q h gate P d G
      = Σ_{B ⊆ T} Σ_{C ⊆ T} 1[B≠∅, C≠∅, Disjoint B C, Z<∏B∏C, 4∏B∏C ≤ H², Jlow ≤ |B|+|C| < Jhigh,
                               P(∏B,∏C), gate H (∏B) (∏C)] · ω(B)ω(C) · G H (∏B) (∏C),

where `T = ordinaryFiniteSupport q H d (H²+1)` and `H = h / ∏d`. This is exact. The ordered pair
`(B, C) = (B, e∖B)` replaces the parent/orientation pair `(e, B)`, and `ω(e) = ω(B)ω(C)`.

No axiom, no `sorry`.
-/

open scoped BigOperators Classical
open Finset

namespace GoldC.QuillonCopyS

def primeSetProduct (s : Finset ℕ) : ℕ := ∏ p ∈ s, p

def activeHighPrime (q p : ℕ) : Prop := p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q

noncomputable def omegaWeight (s : Finset ℕ) : ℝ :=
  ∏ p ∈ s, 1 / ((p : ℝ) - 3)

noncomputable def booleanSigma : ℝ := 2 / 3 + 1 / 100
noncomputable def booleanSourceCutoff (h : ℕ) : ℕ :=
  ⌊(Real.log (h : ℝ)) ^ booleanSigma⌋₊
noncomputable def originalZ (h : ℕ) : ℕ :=
  2 ^ (20 * (booleanSourceCutoff h + 1))

noncomputable def ordinaryFiniteSupport (q H : ℕ) (d : Finset ℕ) (N : ℕ) : Finset ℕ :=
  (Finset.range N).filter
    (fun p => activeHighPrime q p ∧ ¬ p ∣ H ∧ p ∉ d)

noncomputable def quarterParents
    (q h H : ℕ) (d : Finset ℕ) (N : ℕ) : Finset (Finset ℕ) :=
  ((ordinaryFiniteSupport q H d N).powerset).filter
    (fun e => originalZ h < primeSetProduct e ∧
      4 * primeSetProduct e ≤ H ^ 2)

/-- verbatim copy of `Merivelle.Central.regionPairSumMiddleWhere` -/
noncomputable def regionPairSumMiddleWhere
    (Jlow Jhigh q h : ℕ)
    (gate : ℕ → ℕ → ℕ → Prop)
    (P : ℕ → ℕ → Prop)
    (d : Finset ℕ) (G : ℕ → ℕ → ℕ → ℝ) : ℝ :=
  ∑ e ∈ (quarterParents q h (h / primeSetProduct d) d
      ((h / primeSetProduct d)^2+1)).filter
        (fun e => Jlow ≤ e.card ∧ e.card < Jhigh),
    ∑ B ∈ (((e.powerset.erase e).erase ∅).filter
        (fun B => P (primeSetProduct B) (primeSetProduct (e \ B)))),
      if gate (h / primeSetProduct d)
          (primeSetProduct B) (primeSetProduct (e \ B)) then
        omegaWeight e * G (h / primeSetProduct d)
          (primeSetProduct B) (primeSetProduct (e \ B))
      else 0

lemma primeSetProduct_union {B C : Finset ℕ} (h : Disjoint B C) :
    primeSetProduct (B ∪ C) = primeSetProduct B * primeSetProduct C := by
  unfold primeSetProduct; rw [Finset.prod_union h]

lemma omegaWeight_union {B C : Finset ℕ} (h : Disjoint B C) :
    omegaWeight (B ∪ C) = omegaWeight B * omegaWeight C := by
  unfold omegaWeight; rw [Finset.prod_union h]

/-- The summand of the double sum. -/
noncomputable def pairTerm (Jlow Jhigh _q h : ℕ) (gate : ℕ → ℕ → ℕ → Prop) (P : ℕ → ℕ → Prop)
    (H : ℕ) (G : ℕ → ℕ → ℕ → ℝ) (B C : Finset ℕ) : ℝ :=
  if B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C ∧
      originalZ h < primeSetProduct B * primeSetProduct C ∧
      4 * (primeSetProduct B * primeSetProduct C) ≤ H ^ 2 ∧
      Jlow ≤ B.card + C.card ∧ B.card + C.card < Jhigh ∧
      P (primeSetProduct B) (primeSetProduct C) ∧
      gate H (primeSetProduct B) (primeSetProduct C) then
    omegaWeight B * omegaWeight C * G H (primeSetProduct B) (primeSetProduct C)
  else 0

/-- **Exact double-sum form of the MIDDLE pair sum.** -/
theorem pairSum_eq_double (Jlow Jhigh q h : ℕ) (gate : ℕ → ℕ → ℕ → Prop) (P : ℕ → ℕ → Prop)
    (d : Finset ℕ) (G : ℕ → ℕ → ℕ → ℝ) :
    regionPairSumMiddleWhere Jlow Jhigh q h gate P d G =
      ∑ B ∈ (ordinaryFiniteSupport q (h / primeSetProduct d) d
          ((h / primeSetProduct d) ^ 2 + 1)).powerset,
        ∑ C ∈ (ordinaryFiniteSupport q (h / primeSetProduct d) d
          ((h / primeSetProduct d) ^ 2 + 1)).powerset,
          pairTerm Jlow Jhigh q h gate P (h / primeSetProduct d) G B C := by
  set H := h / primeSetProduct d
  set T := ordinaryFiniteSupport q H d (H ^ 2 + 1)
  unfold regionPairSumMiddleWhere
  -- Step 1: rewrite the inner B-sum as a sum over all B ⊆ T with an indicator
  -- Step 2: reindex (e, B) ↦ (B, e \ B), whose inverse is (B, C) ↦ (B ∪ C, B)
  rw [Finset.sum_sigma', ← Finset.sum_product']
  conv_lhs => rw [← Finset.sum_filter_ne_zero]
  conv_rhs => rw [← Finset.sum_filter_ne_zero]
  -- forward facts for an index (e, B)
  have fwd : ∀ x : (_ : Finset ℕ) × Finset ℕ,
      x ∈ ((quarterParents q h H d (H ^ 2 + 1)).filter (fun e => Jlow ≤ e.card ∧ e.card < Jhigh)).sigma
        (fun e => ((e.powerset.erase e).erase ∅).filter
          (fun B => P (primeSetProduct B) (primeSetProduct (e \ B)))) →
      x.2 ⊆ T ∧ x.1 \ x.2 ⊆ T ∧ Disjoint x.2 (x.1 \ x.2) ∧ x.2 ∪ (x.1 \ x.2) = x.1 ∧
      (if gate H (primeSetProduct x.2) (primeSetProduct (x.1 \ x.2)) then
        omegaWeight x.1 * G H (primeSetProduct x.2) (primeSetProduct (x.1 \ x.2)) else 0) =
        pairTerm Jlow Jhigh q h gate P H G x.2 (x.1 \ x.2) := by
    intro x hx
    rw [Finset.mem_sigma, Finset.mem_filter, Finset.mem_filter, Finset.mem_erase,
      Finset.mem_erase, Finset.mem_powerset] at hx
    obtain ⟨⟨he, hc1, hc2⟩, ⟨hBne, hBe, hBsub⟩, hP⟩ := hx
    unfold quarterParents at he
    rw [Finset.mem_filter, Finset.mem_powerset] at he
    obtain ⟨heT, hZ, hH⟩ := he
    have hdisj : Disjoint x.2 (x.1 \ x.2) := Finset.disjoint_sdiff
    have hunion : x.2 ∪ (x.1 \ x.2) = x.1 := Finset.union_sdiff_of_subset hBsub
    have hcard : x.2.card + (x.1 \ x.2).card = x.1.card := by
      rw [← Finset.card_union_of_disjoint hdisj, hunion]
    have hprod : primeSetProduct x.2 * primeSetProduct (x.1 \ x.2) = primeSetProduct x.1 := by
      rw [← primeSetProduct_union hdisj, hunion]
    have hCne : x.1 \ x.2 ≠ ∅ := by
      intro h0; apply hBe; rw [Finset.sdiff_eq_empty_iff_subset] at h0
      exact Finset.Subset.antisymm hBsub h0
    refine ⟨hBsub.trans heT, Finset.sdiff_subset.trans heT, hdisj, hunion, ?_⟩
    unfold pairTerm
    by_cases hg : gate H (primeSetProduct x.2) (primeSetProduct (x.1 \ x.2))
    · rw [if_pos hg, if_pos ⟨hBne, hCne, hdisj, by rw [hprod]; exact hZ, by rw [hprod]; exact hH,
        by rw [hcard]; exact hc1, by rw [hcard]; exact hc2, hP, hg⟩, ← omegaWeight_union hdisj,
        hunion]
    · rw [if_neg hg, if_neg (fun h0 => hg h0.2.2.2.2.2.2.2.2)]
  -- backward facts for a nonzero (B, C)
  have bwd : ∀ y : Finset ℕ × Finset ℕ, y.1 ⊆ T → y.2 ⊆ T →
      pairTerm Jlow Jhigh q h gate P H G y.1 y.2 ≠ 0 →
      (⟨y.1 ∪ y.2, y.1⟩ : (_ : Finset ℕ) × Finset ℕ) ∈
        ((quarterParents q h H d (H ^ 2 + 1)).filter (fun e => Jlow ≤ e.card ∧ e.card < Jhigh)).sigma
          (fun e => ((e.powerset.erase e).erase ∅).filter
            (fun B => P (primeSetProduct B) (primeSetProduct (e \ B)))) ∧
      (y.1 ∪ y.2) \ y.1 = y.2 := by
    intro y hBT hCT hne
    unfold pairTerm at hne
    split_ifs at hne with hcond
    · obtain ⟨hBne, hCne, hdisj, hZ, hH, hc1, hc2, hP, hg⟩ := hcond
      have hsd : (y.1 ∪ y.2) \ y.1 = y.2 := by
        rw [Finset.union_sdiff_left]; exact hdisj.symm.sdiff_eq_left
      have hcard : (y.1 ∪ y.2).card = y.1.card + y.2.card := Finset.card_union_of_disjoint hdisj
      refine ⟨?_, hsd⟩
      rw [Finset.mem_sigma, Finset.mem_filter, Finset.mem_filter, Finset.mem_erase,
        Finset.mem_erase, Finset.mem_powerset]
      refine ⟨⟨?_, by rw [hcard]; exact hc1, by rw [hcard]; exact hc2⟩, ⟨hBne, ?_,
        Finset.subset_union_left⟩, by rw [hsd]; exact hP⟩
      · unfold quarterParents
        rw [Finset.mem_filter, Finset.mem_powerset]
        exact ⟨Finset.union_subset hBT hCT, by rw [primeSetProduct_union hdisj]; exact hZ,
          by rw [primeSetProduct_union hdisj]; exact hH⟩
      · intro h0
        apply hCne
        simp only at h0
        have : y.2 ⊆ y.1 := by rw [h0]; exact Finset.subset_union_right
        exact Finset.eq_empty_of_forall_notMem fun p hp =>
          Finset.disjoint_left.1 hdisj (this hp) hp
    · exact absurd rfl hne
  refine Finset.sum_nbij' (fun x => (x.2, x.1 \ x.2)) (fun y => ⟨y.1 ∪ y.2, y.1⟩) ?_ ?_ ?_ ?_ ?_
  · intro x hx
    rw [Finset.mem_filter] at hx
    obtain ⟨hBT, hCT, -, -, heq⟩ := fwd x hx.1
    rw [Finset.mem_filter, Finset.mem_product, Finset.mem_powerset,
      Finset.mem_powerset]
    exact ⟨⟨hBT, hCT⟩, by rw [← heq]; exact hx.2⟩
  · intro y hy
    rw [Finset.mem_filter, Finset.mem_product, Finset.mem_powerset,
      Finset.mem_powerset] at hy
    obtain ⟨hmem, hsd⟩ := bwd y hy.1.1 hy.1.2 hy.2
    rw [Finset.mem_filter]
    refine ⟨hmem, ?_⟩
    obtain ⟨-, -, -, -, heq⟩ := fwd _ hmem
    simp only at heq ⊢
    rw [heq, hsd]; exact hy.2
  · intro x hx
    rw [Finset.mem_filter] at hx
    obtain ⟨-, -, -, hunion, -⟩ := fwd x hx.1
    ext <;> simp [hunion]
  · intro y hy
    rw [Finset.mem_filter, Finset.mem_product, Finset.mem_powerset,
      Finset.mem_powerset] at hy
    obtain ⟨-, hsd⟩ := bwd y hy.1.1 hy.1.2 hy.2
    ext <;> simp [hsd]
  · intro x hx
    rw [Finset.mem_filter] at hx
    exact (fwd x hx.1).2.2.2.2

end GoldC.QuillonCopyS

#print axioms GoldC.QuillonCopyS.pairSum_eq_double
