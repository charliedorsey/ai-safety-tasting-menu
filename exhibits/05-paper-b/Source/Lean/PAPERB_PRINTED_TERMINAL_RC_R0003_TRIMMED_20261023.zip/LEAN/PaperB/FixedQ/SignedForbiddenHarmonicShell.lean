import PaperB.FixedQ.H2BooleanFinalAssembly
import PaperB.FixedQ.H2PeriodicTwistCoherence
import PaperB.FixedQ.H2BooleanETConsumer

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def h2BooleanTwistedRootMass
    (q H : ℕ) (S : Finset ℕ) (j : ℕ) : ℝ :=
  Real.sqrt
    (h2BooleanFourierNormSqTwisted
      q S j (fixedQPeriodicTotalTwist q H S))

lemma h2BooleanTwistedRootMass_nonneg
    (q H : ℕ) (S : Finset ℕ) (j : ℕ) :
    0 ≤ h2BooleanTwistedRootMass q H S j := by
  unfold h2BooleanTwistedRootMass
  exact Real.sqrt_nonneg _

lemma h2BooleanTwistedRootMass_sq
    (q H : ℕ) (S : Finset ℕ) (j : ℕ) :
    (h2BooleanTwistedRootMass q H S j) ^ 2 =
      h2BooleanFourierNormSqTwisted
        q S j (fixedQPeriodicTotalTwist q H S) := by
  unfold h2BooleanTwistedRootMass
  rw [Real.sq_sqrt]
  exact h2BooleanFourierNormSqTwisted_nonneg _ _ _ _

noncomputable def sourcePeriodicHarmonicMass
    (q H J : ℕ) (S : Finset ℕ) : ℝ :=
  ∑ j ∈ Finset.Icc 1 J,
    h2BooleanTwistedRootMass q H S j / (j : ℝ)

lemma sourcePeriodicHarmonicMass_nonneg
    (q H J : ℕ) (S : Finset ℕ) :
    0 ≤ sourcePeriodicHarmonicMass q H J S := by
  unfold sourcePeriodicHarmonicMass
  apply Finset.sum_nonneg
  intro j hj
  exact div_nonneg (h2BooleanTwistedRootMass_nonneg q H S j) (by positivity)

theorem sourcePeriodicHarmonicMass_shell_sq_le
    (q H M J : ℕ) (hJ : 1 ≤ J) :
    (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
        finiteOmegaWeightReal S * (2 : ℝ) ^ S.card *
          sourcePeriodicHarmonicMass q H J S) ^ 2 ≤
      (∑ S ∈ h2BooleanDyadicSets q M,
        finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) *
      ((1 + Real.log (J : ℝ)) *
        (∑ j ∈ Finset.Icc 1 J,
          h2BooleanDyadicFrequencySecondMomentTwisted
            q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ))) := by
  let F := h2BooleanOrdinaryDyadicSets q H M
  let G := h2BooleanDyadicSets q M
  let D : Finset ℕ → ℝ := fun S =>
    sourcePeriodicHarmonicMass q H J S
  have hw : ∀ S ∈ F, 0 ≤ finiteOmegaWeightReal S := by
    intro S hS
    have hActive :=
      h2BooleanDyadicSets_active (h2BooleanOrdinaryDyadicSets_mem hS).1
    exact finiteOmegaWeightReal_nonneg_of_active hActive
  have hC := ordinaryBooleanWeightedCauchy_source_tilts F D hw
  have hDabs : ∀ S ∈ F, |D S| = D S := by
    intro S hS
    exact abs_of_nonneg (sourcePeriodicHarmonicMass_nonneg q H J S)
  have hfirst :
      (∑ S ∈ F,
        finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) ≤
      ∑ S ∈ G,
        finiteOmegaWeightReal S * h2BooleanX0 ^ S.card := by
    apply Finset.sum_le_sum_of_subset_of_nonneg
    · intro S hS
      exact (h2BooleanOrdinaryDyadicSets_mem hS).1
    · intro S hSG hnot
      have hActive := h2BooleanDyadicSets_active hSG
      exact mul_nonneg
        (finiteOmegaWeightReal_nonneg_of_active hActive)
        (pow_nonneg h2BooleanX0_nonneg _)
  let Q : Finset ℕ → ℝ := fun S =>
    ∑ j ∈ Finset.Icc 1 J,
      h2BooleanFourierNormSqTwisted
        q S j (fixedQPeriodicTotalTwist q H S) / (j : ℝ)
  have hpoint : ∀ S ∈ F,
      (D S) ^ 2 ≤ (1 + Real.log (J : ℝ)) * Q S := by
    intro S hS
    have hc :=
      frequency_harmonic_cauchy
        (fun j => h2BooleanTwistedRootMass q H S j) J
        (fun j hj => h2BooleanTwistedRootMass_nonneg q H S j)
    have hh := frequency_harmonic_factor_le_log J
    have hQ0 : 0 ≤ Q S := by
      dsimp [Q]
      apply Finset.sum_nonneg
      intro j hj
      exact div_nonneg
        (h2BooleanFourierNormSqTwisted_nonneg _ _ _ _) (by positivity)
    have hc' :
        (D S) ^ 2 ≤
          (∑ j ∈ Finset.Icc 1 J, (1 : ℝ) / (j : ℝ)) * Q S := by
      dsimp [D, sourcePeriodicHarmonicMass, Q]
      simpa [h2BooleanTwistedRootMass_sq] using hc
    exact hc'.trans (mul_le_mul_of_nonneg_right hh hQ0)
  have hsecond :
      (∑ S ∈ F,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * |D S| ^ 2) ≤
      (1 + Real.log (J : ℝ)) *
        (∑ j ∈ Finset.Icc 1 J,
          h2BooleanDyadicFrequencySecondMomentTwisted
            q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ)) := by
    calc
      (∑ S ∈ F,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * |D S| ^ 2)
        = ∑ S ∈ F,
          (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) * (D S)^2 := by
            apply Finset.sum_congr rfl
            intro S hS
            rw [hDabs S hS]
      _ ≤ ∑ S ∈ F,
          (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) *
            ((1 + Real.log (J : ℝ)) * Q S) := by
            apply Finset.sum_le_sum
            intro S hS
            have hActive :=
              h2BooleanDyadicSets_active
                (h2BooleanOrdinaryDyadicSets_mem hS).1
            exact mul_le_mul_of_nonneg_left
              (hpoint S hS)
              (mul_nonneg
                (finiteOmegaWeightReal_nonneg_of_active hActive)
                (pow_nonneg h2BooleanV0_nonneg _))
      _ = (1 + Real.log (J : ℝ)) *
          (∑ S ∈ F,
            (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) * Q S) := by
            rw [Finset.mul_sum]
            apply Finset.sum_congr rfl
            intro S hS
            ring
      _ ≤ (1 + Real.log (J : ℝ)) *
          (∑ j ∈ Finset.Icc 1 J,
            h2BooleanDyadicFrequencySecondMomentTwisted
              q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ)) := by
            have hlog0 : 0 ≤ 1 + Real.log (J : ℝ) := by
              have hJR : (1 : ℝ) ≤ J := by exact_mod_cast hJ
              linarith [Real.log_nonneg hJR]
            apply mul_le_mul_of_nonneg_left _ hlog0
            calc
              (∑ S ∈ F,
                (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) * Q S)
                = ∑ j ∈ Finset.Icc 1 J, ∑ S ∈ F,
                    (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
                      h2BooleanFourierNormSqTwisted
                        q S j (fixedQPeriodicTotalTwist q H S)) /
                      (j : ℝ) := by
                    dsimp [Q]
                    rw [Finset.sum_comm]
                    apply Finset.sum_congr rfl
                    intro S hS
                    rw [Finset.mul_sum]
                    apply Finset.sum_congr rfl
                    intro j hj
                    ring
              _ ≤ ∑ j ∈ Finset.Icc 1 J, ∑ S ∈ G,
                    (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
                      h2BooleanFourierNormSqTwisted
                        q S j (fixedQPeriodicTotalTwist q H S)) /
                      (j : ℝ) := by
                    apply Finset.sum_le_sum
                    intro j hj
                    apply Finset.sum_le_sum_of_subset_of_nonneg
                    · intro S hS
                      exact (h2BooleanOrdinaryDyadicSets_mem hS).1
                    · intro S hSG hnot
                      have hActive := h2BooleanDyadicSets_active hSG
                      exact div_nonneg
                        (mul_nonneg
                          (mul_nonneg
                            (finiteOmegaWeightReal_nonneg_of_active hActive)
                            (pow_nonneg h2BooleanV0_nonneg _))
                          (h2BooleanFourierNormSqTwisted_nonneg _ _ _ _))
                        (by positivity)
              _ = _ := by
                    apply Finset.sum_congr rfl
                    intro j hj
                    rw [← Finset.sum_div]
                    unfold h2BooleanDyadicFrequencySecondMomentTwisted
                    rfl
  have hsumD :
      (∑ S ∈ F,
        finiteOmegaWeightReal S * (2 : ℝ) ^ S.card * |D S|) =
      ∑ S ∈ F,
        finiteOmegaWeightReal S * (2 : ℝ) ^ S.card * D S := by
    apply Finset.sum_congr rfl
    intro S hS
    rw [hDabs S hS]
  have hleft :
      (∑ S ∈ F,
        finiteOmegaWeightReal S * (2 : ℝ) ^ S.card * D S) ^ 2 ≤
      (∑ S ∈ F,
        finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) *
      (∑ S ∈ F,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * |D S| ^ 2) := by
    rw [← hsumD]
    exact hC
  calc
    (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
        finiteOmegaWeightReal S * (2 : ℝ) ^ S.card *
          sourcePeriodicHarmonicMass q H J S) ^ 2
      = (∑ S ∈ F,
          finiteOmegaWeightReal S * (2 : ℝ) ^ S.card * D S) ^ 2 := by rfl
    _ ≤ (∑ S ∈ F,
          finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) *
        (∑ S ∈ F,
          finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * |D S| ^ 2) := hleft
    _ ≤ (∑ S ∈ G,
          finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) *
        ((1 + Real.log (J : ℝ)) *
          (∑ j ∈ Finset.Icc 1 J,
            h2BooleanDyadicFrequencySecondMomentTwisted
              q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ))) := by
          have hBF0 : 0 ≤
              ∑ S ∈ F,
                finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * |D S| ^ 2 := by
            apply Finset.sum_nonneg
            intro S hS
            have hActive :=
              h2BooleanDyadicSets_active
                (h2BooleanOrdinaryDyadicSets_mem hS).1
            exact mul_nonneg
              (mul_nonneg
                (finiteOmegaWeightReal_nonneg_of_active hActive)
                (pow_nonneg h2BooleanV0_nonneg _))
              (sq_nonneg _)
          have hAG0 : 0 ≤
              ∑ S ∈ G,
                finiteOmegaWeightReal S * h2BooleanX0 ^ S.card := by
            apply Finset.sum_nonneg
            intro S hS
            have hActive := h2BooleanDyadicSets_active hS
            exact mul_nonneg
              (finiteOmegaWeightReal_nonneg_of_active hActive)
              (pow_nonneg h2BooleanX0_nonneg _)
          calc
            (∑ S ∈ F,
                finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) *
              (∑ S ∈ F,
                finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * |D S| ^ 2)
              ≤ (∑ S ∈ G,
                  finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) *
                (∑ S ∈ F,
                  finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * |D S| ^ 2) :=
                mul_le_mul_of_nonneg_right hfirst hBF0
            _ ≤ (∑ S ∈ G,
                  finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) *
                ((1 + Real.log (J : ℝ)) *
                  (∑ j ∈ Finset.Icc 1 J,
                    h2BooleanDyadicFrequencySecondMomentTwisted
                      q M j (fixedQPeriodicTotalTwist q H) / (j : ℝ))) :=
                mul_le_mul_of_nonneg_left hsecond hAG0

#print axioms sourcePeriodicHarmonicMass_shell_sq_le

end PaperB.FixedQ
