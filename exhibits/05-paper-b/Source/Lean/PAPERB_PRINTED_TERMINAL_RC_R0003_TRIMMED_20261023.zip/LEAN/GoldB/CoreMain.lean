import GoldB.CoreThm

/-!
# GoldB.CoreMain — logarithmic assembly of the double-sum bound
-/

open Finset

namespace GoldB

/-- Compatibility repair: numeric fact hoisted out of `core_bound` (heartbeat budget). -/
lemma GoldB.coreMain_log28_le : Real.log 28 ≤ 4 := by
  rw [Real.log_le_iff_le_exp (by norm_num)]
  have h := Real.exp_one_gt_d9
  have h27 : (2.7 : ℝ) ≤ Real.exp 1 := by linarith
  calc (28 : ℝ) ≤ 2.7 ^ 4 := by norm_num
    _ ≤ Real.exp 1 ^ 4 := pow_le_pow_left₀ (by norm_num) h27 4
    _ = Real.exp 4 := by rw [← Real.exp_nat_mul]; norm_num

/-- Compatibility repair: the `γ`-comparison of `core_bound`, hoisted (heartbeat budget). -/
lemma GoldB.coreMain_gamma_aux (b k L ρc : ℝ) (hk : 0 < k) (hL : 0 < L) (hρ : 0 < ρc)
    (hb0 : 0 ≤ b) (hbL : b ≤ 2 * k ^ 2 * L) :
    2 * b ^ 2 * (ρc / (128 * L ^ 2)) / k ^ 2 ≤ k ^ 2 * ρc / 16 := by
  rw [div_le_iff₀ (by positivity)]
  have hb2 : b ^ 2 ≤ 4 * k ^ 4 * L ^ 2 := by
    have := pow_le_pow_left₀ hb0 hbL 2
    calc b ^ 2 ≤ (2 * k ^ 2 * L) ^ 2 := this
      _ = 4 * k ^ 4 * L ^ 2 := by ring
  calc 2 * b ^ 2 * (ρc / (128 * L ^ 2)) = b ^ 2 * (ρc / (64 * L ^ 2)) := by ring
    _ ≤ 4 * k ^ 4 * L ^ 2 * (ρc / (64 * L ^ 2)) :=
        mul_le_mul_of_nonneg_right hb2 (by positivity)
    _ = k ^ 2 * ρc / 16 * k ^ 2 := by field_simp; ring

namespace KParams

variable (K : KParams)

-- Compatibility repair: heartbeat budget only (no statement/proof-term change).
set_option maxHeartbeats 1600000 in
theorem core_bound (k : ℕ) (hk : 1 ≤ k) (P : ℝ) (hP1 : 1 < P) (hP : 2 ≤ P ^ K.c3)
    (B : Fin k → ℝ) (S : Finset (Fin k)) (hS : K.c0 * k ≤ S.card)
    (hB : ∀ j ∈ S, P ^ (-(K.c2 * ((j : ℕ) + 1))) ≤ |B j| ∧ |B j| ≤ P ^ (-(K.c3 * ((j : ℕ) + 1)))) :
    ‖∑ y ∈ Zr (K.QQ k P), ∑ z ∈ Zr (K.QQ k P), ee (∑ j, B j * ((y : ℝ) * z) ^ ((j : ℕ) + 1))‖ ≤
      K.Kc * (K.QQ k P : ℝ) ^ 2 * P ^ (-(K.γ1 / (2 * (k : ℝ) ^ 2))) := by
  set τ := K.tau k
  set b := k * τ
  set Q := K.QQ k P
  set V := ‖∑ y ∈ Zr Q, ∑ z ∈ Zr Q, ee (∑ j, B j * ((y : ℝ) * z) ^ ((j : ℕ) + 1))‖
  have hP0 : 0 < P := by linarith
  have hlP : 0 < Real.log P := Real.log_pos hP1
  have hkr : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hτk : k ≤ τ := K.tau_ge k
  have hb1 : 1 ≤ b := Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero (by omega) (by omega))
  have hbr : (1 : ℝ) ≤ b := by exact_mod_cast hb1
  have hbk2 : (k : ℝ) ^ 2 ≤ b := by
    have : (k : ℝ) ≤ τ := by exact_mod_cast hτk
    simp only [b]; push_cast; nlinarith only [this, hkr]
  have hkb : (k : ℝ) ≤ b := le_trans (by nlinarith only [hkr]) hbk2
  have hbL : (b : ℝ) ≤ 2 * (k : ℝ) ^ 2 * K.L1 := by
    have := K.tau_le k hk
    simp only [b]; push_cast; nlinarith
  have hP2 : 1 ≤ K.P2 k P := K.P2_ge_one k hP1.le
  have hQ1 : 1 ≤ Q := by simp [Q, QQ]
  have hQr : (1 : ℝ) ≤ Q := by exact_mod_cast hQ1
  have hds := double_sum k b Q hb1 hQ1 B
  rcases eq_or_lt_of_le (norm_nonneg (∑ y ∈ Zr Q, ∑ z ∈ Zr Q,
      ee (∑ j, B j * ((y : ℝ) * z) ^ ((j : ℕ) + 1)))) with hV0 | hVpos
  · change 0 = V at hV0
    rw [← hV0]
    have := K.Kc_pos
    positivity
  change 0 < V at hVpos
  -- the mean value theorem
  set J := (Jc k b (Zr Q) : ℝ)
  have hJ1 : (1 : ℝ) ≤ J := by
    have := Jc_pos k b (Zr Q) ⟨0, by simp [Zr]; omega⟩
    simp only [J]; exact_mod_cast this
  have hJle : J ≤ Dv k τ * (Q : ℝ) ^ (Eexp k τ) := by
    simp only [J]; rw [Jc_Zr_eq]; exact vmvt k hk τ Q hQ1
  -- the factors
  have hSf := K.Sfrak_uniform k hk P hP1 hP B S hB
  -- take logarithms
  set lP := Real.log P
  set lQ := Real.log (Q : ℝ)
  set lV := Real.log V
  set l2 := Real.log 2
  set Δ := Del k τ
  set Ssel : ℝ := ∑ j ∈ S, ((j : ℕ) + 1 : ℝ)
  have hSpos : ∀ j : Fin k, 0 < Sfrak b Q j (B j) := fun j => Sfrak_pos _ _ _ _
  have hF1 : 4 * (b : ℝ) ^ 2 * lV ≤ (8 * (b : ℝ) ^ 2 - 4 * b) * lQ + 2 * Real.log J +
      ∑ j : Fin k, Real.log (Sfrak b Q j (B j)) := by
    have hpos : 0 < V ^ (4 * b ^ 2) := by positivity
    have := Real.log_le_log hpos hds
    rw [Real.log_pow, Real.log_mul (by positivity) (prod_pos (fun j _ => hSpos j)).ne',
      Real.log_mul (by positivity) (by positivity), Real.log_pow, Real.log_pow,
      Real.log_prod (fun j _ => (hSpos j).ne')] at this
    have e : ((8 * b ^ 2 - 4 * b : ℕ) : ℝ) = 8 * (b : ℝ) ^ 2 - 4 * b := by
      rw [Nat.cast_sub (by nlinarith)]; push_cast; ring
    rw [e] at this; push_cast at this; linarith
  have hF2 : Real.log J ≤ (Dexp k τ : ℝ) * l2 + Eexp k τ * lQ := by
    calc Real.log J ≤ Real.log (Dv k τ * (Q : ℝ) ^ (Eexp k τ)) :=
          Real.log_le_log (by linarith) hJle
      _ = (Dexp k τ : ℝ) * l2 + Eexp k τ * lQ := by
          unfold Dv
          rw [Real.log_mul (by positivity) (by positivity), Real.log_pow,
            Real.log_rpow (by linarith)]
  have hEexp : Eexp k τ = 2 * (b : ℝ) - (k : ℝ) * (k + 1) / 2 + Δ := by
    simp only [Eexp, kap, b, Δ]; push_cast; ring
  -- per-factor log bound
  have hlogS : ∀ j : Fin k, Real.log (Sfrak b Q j (B j)) ≤
      Real.log 28 + ((j : ℕ) + 1 : ℝ) * Real.log 4 + Real.log (1 + k * lP) +
        2 * (Real.log b + ((j : ℕ) + 1 : ℝ) * Real.log (K.P2 k P)) +
          (if j ∈ S then -(K.ρ * ((j : ℕ) + 1)) * lP else 0) := by
    intro j
    have h := hSf j
    have hL : (Lbox b Q j : ℝ) = b * (K.P2 k P : ℝ) ^ ((j : ℕ) + 1) := by
      simp [Lbox, Q, QQ]
    have hpos1 : (0 : ℝ) < 1 + k * lP := by positivity
    have hP2r : (0 : ℝ) < K.P2 k P := by exact_mod_cast hP2
    calc Real.log (Sfrak b Q j (B j))
        ≤ Real.log (28 * 4 ^ ((j : ℕ) + 1) * (1 + k * lP) * (Lbox b Q j : ℝ) ^ 2 *
            (if j ∈ S then P ^ (-(K.ρ * ((j : ℕ) + 1))) else 1)) :=
          Real.log_le_log (hSpos j) h
      _ = _ := by
          rw [hL]
          split_ifs with hj
          · rw [Real.log_mul (by positivity) (by positivity), Real.log_mul (by positivity)
              (by positivity), Real.log_mul (by positivity) (by positivity),
              Real.log_mul (by positivity) (by positivity), Real.log_pow, Real.log_rpow hP0,
              Real.log_pow, Real.log_mul (by positivity) (by positivity), Real.log_pow]
            push_cast; ring
          · rw [Real.log_mul (by positivity) (by positivity), Real.log_mul (by positivity)
              (by positivity), Real.log_mul (by positivity) (by positivity),
              Real.log_mul (by positivity) (by positivity), Real.log_pow, Real.log_one,
              Real.log_pow, Real.log_mul (by positivity) (by positivity), Real.log_pow]
            push_cast; ring
  have hsumS : ∑ j : Fin k, (if j ∈ S then -(K.ρ * ((j : ℕ) + 1)) * lP else 0) = -(K.ρ * lP) * Ssel := by
    rw [← sum_filter, Finset.filter_mem_eq_inter, univ_inter, mul_sum]
    apply sum_congr rfl; intro j _; ring
  have hsum1 := sum_fin_succ_cast k
  have hF3 : ∑ j : Fin k, Real.log (Sfrak b Q j (B j)) ≤
      k * Real.log 28 + (k : ℝ) * (k + 1) / 2 * Real.log 4 + k * Real.log (1 + k * lP) +
        2 * k * Real.log b + (k : ℝ) * (k + 1) * Real.log (K.P2 k P) - K.ρ * lP * Ssel := by
    refine (sum_le_sum (fun j _ => hlogS j)).trans (le_of_eq ?_)
    rw [sum_add_distrib, hsumS]
    have hsum0 : ∑ j : Fin k, ((j : ℕ) : ℝ) = (k : ℝ) * (k + 1) / 2 - k := by
      have h := hsum1; rw [sum_add_distrib] at h; simp at h; linarith
    simp only [sum_add_distrib, sum_const, card_univ, Fintype.card_fin, nsmul_eq_mul, ← sum_mul,
      mul_add, ← mul_sum, hsum0]
    ring
  -- auxiliary facts
  have hF4 : Real.log (K.P2 k P) ≤ lQ := by
    apply Real.log_le_log (by exact_mod_cast hP2); simp [Q, QQ]
  have hF5 : lQ ≤ l2 + lP / 2 := by
    have hQle := K.QQ_le k hP1.le
    have hu : Real.log (K.uu k P) = K.aexp k * lP := Real.log_rpow hP0 _
    have : lQ ≤ l2 + Real.log (K.uu k P) := by
      rw [← Real.log_mul (by norm_num) (by linarith [K.uu_ge_one k hP1.le])]
      exact Real.log_le_log (by linarith) hQle
    have ha := K.aexp_le k
    have hc1 : K.c1 < 1 := K.h1
    nlinarith
  have hF6 : K.c0 ^ 2 * (k : ℝ) ^ 2 / 4 ≤ Ssel := by
    have h := sel_sum_ge S
    have : K.c0 * k ≤ (S.card : ℝ) := hS
    have h0 : 0 ≤ K.c0 * k := by have := K.h0; positivity
    nlinarith
  have hΔ0 : 0 ≤ Δ := Del_nonneg k τ hk
  have hΔk : Δ ≤ (k : ℝ) ^ 2 := (Del_le_kap k τ hk).trans (kap_le_sq k hk)
  have hΔρ : Δ ≤ (k : ℝ) ^ 2 * (K.ρ * K.c0 ^ 2 / 8) := K.Del_le k hk
  have hF8 : (Dexp k τ : ℝ) ≤ 31 * (b : ℝ) ^ 2 := by
    have := K.Dexp_le k hk; simp only [b]; push_cast at this ⊢; linarith
  have hδ := one_add_log_le P K.δ0 hP1.le K.δ0_pos K.δ0_le_one
  have hlk : Real.log (1 + k * lP) ≤ Real.log k + (Real.log (1 / K.δ0) + K.δ0 * lP) := by
    have : 1 + k * lP ≤ k * (1 + lP) := by
      have : k * (1 + lP) - (1 + k * lP) = (k : ℝ) - 1 := by ring
      linarith
    calc Real.log (1 + k * lP) ≤ Real.log (k * (1 + lP)) :=
          Real.log_le_log (by positivity) this
      _ = Real.log k + Real.log (1 + lP) := Real.log_mul (by positivity) (by positivity)
      _ ≤ _ := by linarith [hδ]
  have hlogk : Real.log k ≤ k := (Real.log_le_sub_one_of_pos (by positivity)).trans (by linarith)
  have hlogb : Real.log b ≤ b := (Real.log_le_sub_one_of_pos (by positivity)).trans (by linarith)
  have hl2 : l2 ≤ 1 := by
    have := Real.log_two_lt_d9; simp only [l2]; linarith
  have hl28 : Real.log 28 ≤ 4 := GoldB.coreMain_log28_le
  have hl4 : Real.log 4 ≤ 2 := by
    rw [show (4 : ℝ) = 2 ^ 2 by norm_num, Real.log_pow]; push_cast; linarith
  have hlδ : 0 ≤ Real.log (1 / K.δ0) :=
    Real.log_nonneg (by rw [le_div_iff₀ K.δ0_pos]; linarith [K.δ0_le_one])
  have hlQ0 : 0 ≤ lQ := Real.log_nonneg hQr
  have hγ : 2 * (b : ℝ) ^ 2 * K.γ1 / (k : ℝ) ^ 2 ≤ (k : ℝ) ^ 2 * (K.ρ * K.c0 ^ 2) / 16 := by
    unfold γ1
    exact GoldB.coreMain_gamma_aux b k K.L1 (K.ρ * K.c0 ^ 2) (by positivity) K.L1_pos K.ρc_pos
      (by positivity) hbL
  have hbsq : (b : ℝ) ≤ (b : ℝ) ^ 2 := by nlinarith only [hbr]
  -- products prepared for linear arithmetic
  have P1 : 2 * Δ * lQ ≤ 2 * Δ * l2 + Δ * lP := by
    have hm := mul_le_mul_of_nonneg_left hF5 hΔ0
    linarith only [hm]
  have P2' : (k : ℝ) * (k + 1) * Real.log (K.P2 k P) ≤ (k : ℝ) * (k + 1) * lQ := by
    apply mul_le_mul_of_nonneg_left hF4; positivity
  have P3 : 2 * Δ * l2 ≤ 2 * (k : ℝ) ^ 2 := by
    have hm := mul_le_mul_of_nonneg_left hl2 hΔ0
    linarith only [hm, hΔk]
  have P4 : 2 * (Dexp k τ : ℝ) * l2 ≤ 62 * (b : ℝ) ^ 2 := by
    have h0 : (0 : ℝ) ≤ Dexp k τ := by positivity
    have hm := mul_le_mul_of_nonneg_left hl2 h0
    linarith only [hm, hF8]
  have P5 : (k : ℝ) * Real.log 28 ≤ 4 * (b : ℝ) ^ 2 := by
    have hm := mul_le_mul_of_nonneg_left hl28 (by positivity : (0 : ℝ) ≤ k)
    linarith only [hm, hkb, hbsq]
  have P6 : (k : ℝ) * (k + 1) / 2 * Real.log 4 ≤ 2 * (b : ℝ) ^ 2 := by
    have hm := mul_le_mul_of_nonneg_left hl4 (by positivity : (0 : ℝ) ≤ (k : ℝ) * (k + 1) / 2)
    have hkk : (k : ℝ) * k ≤ (b : ℝ) * b := mul_le_mul hkb hkb (by positivity) (by positivity)
    nlinarith only [hm, hkk, hkb, hbsq]
  have P7 : (k : ℝ) * Real.log (1 + k * lP) ≤
      (b : ℝ) ^ 2 + (b : ℝ) ^ 2 * Real.log (1 / K.δ0) + (k : ℝ) ^ 2 * (K.ρ * K.c0 ^ 2 / 16) * lP := by
    have h1 : (k : ℝ) * Real.log (1 + k * lP) ≤
        k * Real.log k + k * Real.log (1 / K.δ0) + k * K.δ0 * lP := by
      calc (k : ℝ) * Real.log (1 + k * lP)
          ≤ k * (Real.log k + (Real.log (1 / K.δ0) + K.δ0 * lP)) :=
            mul_le_mul_of_nonneg_left hlk (by positivity)
        _ = _ := by ring
    have h2 : (k : ℝ) * Real.log k ≤ (b : ℝ) ^ 2 := by
      have hm := mul_le_mul_of_nonneg_left hlogk (by positivity : (0 : ℝ) ≤ k)
      have hkk : (k : ℝ) * k ≤ (b : ℝ) * b := mul_le_mul hkb hkb (by positivity) (by positivity)
      nlinarith only [hm, hkk]
    have h3 : (k : ℝ) * Real.log (1 / K.δ0) ≤ (b : ℝ) ^ 2 * Real.log (1 / K.δ0) := by
      apply mul_le_mul_of_nonneg_right _ hlδ; linarith only [hkb, hbsq]
    have h4 : (k : ℝ) * K.δ0 * lP ≤ (k : ℝ) ^ 2 * (K.ρ * K.c0 ^ 2 / 16) * lP := by
      apply mul_le_mul_of_nonneg_right _ hlP.le
      have hm := mul_le_mul_of_nonneg_left K.δ0_le (by positivity : (0 : ℝ) ≤ k)
      have hkk : (k : ℝ) ≤ (k : ℝ) ^ 2 := by nlinarith only [hkr]
      have hm2 := mul_le_mul_of_nonneg_right hkk (by have := K.ρc_pos; positivity :
        (0 : ℝ) ≤ K.ρ * K.c0 ^ 2 / 16)
      linarith only [hm, hm2]
    linarith
  have P8 : 2 * (k : ℝ) * Real.log b ≤ 2 * (b : ℝ) ^ 2 := by
    have hm := mul_le_mul_of_nonneg_left hlogb (by positivity : (0 : ℝ) ≤ k)
    have hkk : (k : ℝ) * b ≤ (b : ℝ) * b := mul_le_mul_of_nonneg_right hkb (by positivity)
    nlinarith only [hm, hkk]
  have P9 : Δ * lP ≤ (k : ℝ) ^ 2 * (K.ρ * K.c0 ^ 2 / 8) * lP :=
    mul_le_mul_of_nonneg_right hΔρ hlP.le
  have P10 : K.ρ * lP * (K.c0 ^ 2 * (k : ℝ) ^ 2 / 4) ≤ K.ρ * lP * Ssel :=
    mul_le_mul_of_nonneg_left hF6 (by have := K.ρ_pos; positivity)
  have P11 : 2 * (b : ℝ) ^ 2 * K.γ1 / (k : ℝ) ^ 2 * lP ≤
      (k : ℝ) ^ 2 * (K.ρ * K.c0 ^ 2) / 16 * lP := mul_le_mul_of_nonneg_right hγ hlP.le
  have P12 : 2 * (k : ℝ) ^ 2 ≤ 2 * (b : ℝ) ^ 2 := by
    have hkk : (k : ℝ) * k ≤ (b : ℝ) * b := mul_le_mul hkb hkb (by positivity) (by positivity)
    nlinarith only [hkk]
  have P2E : 2 * (Eexp k τ * lQ) = (4 * (b : ℝ) - (k : ℝ) * (k + 1) + 2 * Δ) * lQ := by
    rw [hEexp]; ring
  -- the main inequality, multiplied by 4b².  Linear combination (all coefficients 1):
  --   hF1 + 2·hF2 (via P2E) + hF3 + P2'  ⇒  4b² lV ≤ 8b² lQ + 2Δ lQ + 2Dexp l2 + k l28
  --        + (k(k+1)/2) l4 + k log(1+k lP) + 2k log b − ρ lP Ssel
  --   P1: 2Δ lQ ≤ 2Δ l2 + Δ lP;  P3+P12: 2Δ l2 ≤ 2b²;  P4: ≤ 62b²;  P5: ≤ 4b²;  P6: ≤ 2b²;
  --   P7: k log(1+k lP) ≤ b² + b² log(1/δ0) + (k²ρc0²/16) lP;  P8: ≤ 2b²;
  --   P9: Δ lP ≤ (k²ρc0²/8) lP;  P10: −ρ lP Ssel ≤ −(ρc0²k²/4) lP;  P11: γ-comparison.
  --   Total: 73b² + b² log(1/δ0) − (k²ρc0²/16) lP ≤ 336b² + 4b² log(1/δ0) − (2b²γ1/k²) lP.
  have hmain : 4 * (b : ℝ) ^ 2 * lV ≤ 4 * (b : ℝ) ^ 2 *
      ((84 + Real.log (1 / K.δ0)) + 2 * lQ - K.γ1 / (2 * (k : ℝ) ^ 2) * lP) := by
    have e1 : 4 * (b : ℝ) ^ 2 * ((84 + Real.log (1 / K.δ0)) + 2 * lQ -
        K.γ1 / (2 * (k : ℝ) ^ 2) * lP) = 336 * (b : ℝ) ^ 2 + 4 * (b : ℝ) ^ 2 * Real.log (1 / K.δ0) +
          8 * (b : ℝ) ^ 2 * lQ - 2 * (b : ℝ) ^ 2 * K.γ1 / (k : ℝ) ^ 2 * lP := by
      field_simp; ring
    rw [e1]
    have hbd : 0 ≤ (b : ℝ) ^ 2 * Real.log (1 / K.δ0) := by positivity
    linarith [hF1, hF2, hF3, P1, P2', P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P2E]
  have hdiv : lV ≤ (84 + Real.log (1 / K.δ0)) + 2 * lQ - K.γ1 / (2 * (k : ℝ) ^ 2) * lP :=
    le_of_mul_le_mul_left hmain (by positivity)
  -- exponentiate
  have hrhs : Real.log (K.Kc * (Q : ℝ) ^ 2 * P ^ (-(K.γ1 / (2 * (k : ℝ) ^ 2)))) =
      (84 + Real.log (1 / K.δ0)) + 2 * lQ - K.γ1 / (2 * (k : ℝ) ^ 2) * lP := by
    unfold Kc
    rw [Real.log_mul (by positivity) (by positivity), Real.log_mul (by positivity) (by positivity),
      Real.log_exp, Real.log_pow, Real.log_rpow hP0]
    push_cast; ring
  rw [← Real.log_le_log_iff hVpos (by have := K.Kc_pos; positivity), hrhs]
  exact hdiv

end KParams

end GoldB
