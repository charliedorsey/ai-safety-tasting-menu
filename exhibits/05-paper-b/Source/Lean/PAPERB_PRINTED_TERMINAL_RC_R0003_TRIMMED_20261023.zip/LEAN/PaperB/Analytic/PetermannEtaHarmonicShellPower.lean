import PaperB.Analytic.ReciprocalFiniteOrderEnvelope
import PaperB.Analytic.FixedBetaActualTerms
import PaperB.Analytic.FixedOrderDenominatorSqueeze

open scoped BigOperators

namespace PaperB.Analytic

open Real Finset Nat

noncomputable def etaShellDelta (k : ℕ) : ℝ :=
  (k + 1 : ℝ) * fixedBetaA k - 4 / (2 : ℝ)^k

noncomputable def etaShellC1 (k H : ℕ) : ℝ :=
  2 * reciprocalFiniteOrderConst k *
    (((H : ℝ) * fixedBetaUpperConst k) ^ fixedBetaA k)

noncomputable def etaShellC2 (k : ℕ) : ℝ :=
  2 * reciprocalFiniteOrderConst k *
    (fixedBetaLowerConst k ^ (-(fixedBetaA k)))

lemma etaShellDelta_pos {k : ℕ} (hk : 2 ≤ k) :
    0 < etaShellDelta k := by
  unfold etaShellDelta fixedBetaA
  have hx : 0 < (2 : ℝ)^k := by positivity
  have hp : (4 : ℝ) ≤ (2 : ℝ)^k := by
    have h := pow_le_pow_right₀ (a := (2 : ℝ)) (by norm_num) hk
    norm_num at h ⊢
    exact h
  have hd : 0 < (2 : ℝ)^k - 2 := by linarith
  have htarget :
      4 / (2 : ℝ)^k < ((k : ℝ) + 1) / ((2 : ℝ)^k - 2) := by
    rw [div_lt_div_iff₀ hx hd]
    by_cases hk2 : k = 2
    · subst k
      norm_num
    · have hk4 : 4 ≤ k + 1 := by omega
      have hkr : (4 : ℝ) ≤ (k : ℝ) + 1 := by exact_mod_cast hk4
      nlinarith
  simpa [div_eq_mul_inv] using htarget

lemma etaShellDelta_two : etaShellDelta 2 = 1 / 2 := by
  norm_num [etaShellDelta, fixedBetaA]

lemma etaShell_upper_endpoint_identity {V A : ℝ} {k H : ℕ} (hV : 0 < V) (hA : 0 ≤ A) :
    (((H : ℝ) * A * fixedBetaUpperConst k) *
        V ^ (-(k + 1 : ℝ))) ^ fixedBetaA k
      =
    (((H : ℝ) * fixedBetaUpperConst k) ^ fixedBetaA k) *
      A ^ fixedBetaA k *
      V ^ (-((k + 1 : ℝ) * fixedBetaA k)) := by
  have hH : 0 ≤ (H : ℝ) := by positivity
  have hC : 0 ≤ fixedBetaUpperConst k := (fixedBetaUpperConst_pos k).le
  have hAll : 0 ≤ (H : ℝ) * A * fixedBetaUpperConst k := by positivity
  have hVpow : 0 ≤ V ^ (-(k + 1 : ℝ)) := Real.rpow_nonneg hV.le _
  rw [Real.mul_rpow hAll hVpow]
  have hassoc :
      (H : ℝ) * A * fixedBetaUpperConst k =
        ((H : ℝ) * fixedBetaUpperConst k) * A := by ring
  rw [hassoc]
  rw [Real.mul_rpow (mul_nonneg hH hC) hA]
  rw [← Real.rpow_mul hV.le]
  ring

lemma etaShell_lower_endpoint_identity {V A : ℝ} {k : ℕ} (hV : 0 < V) (hA : 0 < A) :
    (V ^ (1 - 4 / (2 : ℝ)^k) *
      ((A * fixedBetaLowerConst k) *
        V ^ (-(k + 1 : ℝ))) ^ (-(fixedBetaA k))) / V
      =
    fixedBetaLowerConst k ^ (-(fixedBetaA k)) *
      A ^ (-(fixedBetaA k)) *
      V ^ etaShellDelta k := by
  have hC : 0 ≤ fixedBetaLowerConst k := (fixedBetaLowerConst_pos k).le
  have hAC : 0 ≤ A * fixedBetaLowerConst k := mul_nonneg hA.le hC
  have hVpow : 0 ≤ V ^ (-(k + 1 : ℝ)) := Real.rpow_nonneg hV.le _
  rw [Real.mul_rpow hAC hVpow]
  rw [Real.mul_rpow hA.le hC]
  rw [← Real.rpow_mul hV.le]
  have hpre :
      V ^ (1 - 4 / (2 : ℝ)^k) *
          ((A ^ (-(fixedBetaA k)) *
              fixedBetaLowerConst k ^ (-(fixedBetaA k))) *
            V ^ (-(k + 1 : ℝ) * (-(fixedBetaA k))))
        =
      fixedBetaLowerConst k ^ (-(fixedBetaA k)) *
        A ^ (-(fixedBetaA k)) *
        V ^ (1 + etaShellDelta k) := by
    calc
      _ =
        fixedBetaLowerConst k ^ (-(fixedBetaA k)) *
          A ^ (-(fixedBetaA k)) *
          (V ^ (1 - 4 / (2 : ℝ)^k) *
            V ^ (-(k + 1 : ℝ) * (-(fixedBetaA k)))) := by ring
      _ =
        fixedBetaLowerConst k ^ (-(fixedBetaA k)) *
          A ^ (-(fixedBetaA k)) *
          V ^ ((1 - 4 / (2 : ℝ)^k) +
            (-(k + 1 : ℝ) * (-(fixedBetaA k)))) := by
              rw [← Real.rpow_add hV]
      _ = _ := by
        congr 1
        unfold etaShellDelta
        ring
  rw [hpre]
  have hpow :
      V ^ (1 + etaShellDelta k) =
        V ^ (etaShellDelta k) * V := by
    calc
      V ^ (1 + etaShellDelta k)
        = V ^ (etaShellDelta k + 1) := by congr 1 <;> ring
      _ = V ^ (etaShellDelta k) * V ^ (1 : ℝ) := by
        rw [Real.rpow_add hV]
      _ = V ^ (etaShellDelta k) * V := by simp
  rw [hpow]
  field_simp [hV.ne']


theorem eta_reciprocal_weighted_shell_power_majorant
    (k H j : ℕ) (hk : 2 ≤ k) (hj1 : 1 ≤ j) (hjH : j ≤ H)
    (A A' xi : ℝ) (hA : 0 < A) (hAbs : |A'| = (j : ℝ) * A)
    (V B : ℕ) (hkV : k ≤ V) (hVB : V ≤ B) (hB2 : B ≤ 2 * V) :
    ‖∑ n ∈ Finset.Icc V B,
        ((((n : ℝ)⁻¹ : ℝ) : ℂ) *
          eR (A' / (n : ℝ) + xi * (n : ℝ)))‖
      ≤
    2 / (V : ℝ) +
      etaShellC1 k H * A ^ fixedBetaA k *
        (V : ℝ) ^ (-((k + 1 : ℝ) * fixedBetaA k)) +
      etaShellC2 k * A ^ (-(fixedBetaA k)) *
        (V : ℝ) ^ etaShellDelta k := by
  have hV : 0 < V := lt_of_lt_of_le (by omega : 0 < k) hkV
  have hVr : 0 < (V : ℝ) := by exact_mod_cast hV
  have hApr : 0 ≤ A := hA.le
  have hjr1 : (1 : ℝ) ≤ (j : ℝ) := by exact_mod_cast hj1
  have hjrH : (j : ℝ) ≤ (H : ℝ) := by exact_mod_cast hjH
  have hA' : A' ≠ 0 := by
    intro hzero
    rw [hzero, abs_zero] at hAbs
    have hjpos : 0 < (j : ℝ) := lt_of_lt_of_le (by norm_num) hjr1
    nlinarith
  have hbase := reciprocalFiniteOrderNatIcc_weighted k hk
    A' xi V B hA' hkV hVB hB2
  dsimp at hbase
  let lam : ℝ :=
    |A'| * (k.factorial : ℝ) *
      ((((2 * V + k : ℕ) : ℝ)) ^ (k + 1))⁻¹
  have hlamPos : 0 < lam := by
    dsimp [lam]
    have habs : 0 < |A'| := abs_pos.mpr hA'
    positivity
  have hinv := fixedOrder_denominator_inv_squeeze hV hkV
  have hcoeff0 : 0 ≤ |A'| * (k.factorial : ℝ) := by positivity
  have hlamUpper0 :
      lam ≤ |A'| * (k.factorial : ℝ) *
        (((2 : ℝ) * (V : ℝ)) ^ (k + 1))⁻¹ := by
    dsimp [lam]
    exact mul_le_mul_of_nonneg_left hinv.2 hcoeff0
  have hlamLower0 :
      |A'| * (k.factorial : ℝ) *
        ((3 * (V : ℝ)) ^ (k + 1))⁻¹ ≤ lam := by
    dsimp [lam]
    exact mul_le_mul_of_nonneg_left hinv.1 hcoeff0
  have hupperId :
      |A'| * (k.factorial : ℝ) *
        (((2 : ℝ) * (V : ℝ)) ^ (k + 1))⁻¹ =
      ((j : ℝ) * A * fixedBetaUpperConst k) *
        (V : ℝ) ^ (-(k + 1 : ℝ)) := by
    rw [hAbs]
    rw [fixedBetaUpperConst, mul_pow, mul_inv_rev]
    have hpow :
        (V : ℝ) ^ (-(k + 1 : ℝ)) =
          (((V : ℝ) ^ (k + 1))⁻¹) := by
      rw [Real.rpow_neg hVr.le]
      norm_cast
    rw [hpow]
    ring
  have hlowerId :
      |A'| * (k.factorial : ℝ) *
        ((3 * (V : ℝ)) ^ (k + 1))⁻¹ =
      ((j : ℝ) * A * fixedBetaLowerConst k) *
        (V : ℝ) ^ (-(k + 1 : ℝ)) := by
    rw [hAbs]
    rw [fixedBetaLowerConst, mul_pow, mul_inv_rev]
    have hpow :
        (V : ℝ) ^ (-(k + 1 : ℝ)) =
          (((V : ℝ) ^ (k + 1))⁻¹) := by
      rw [Real.rpow_neg hVr.le]
      norm_cast
    rw [hpow]
    ring
  rw [hupperId] at hlamUpper0
  rw [hlowerId] at hlamLower0
  have hUpperH :
      lam ≤ ((H : ℝ) * A * fixedBetaUpperConst k) *
        (V : ℝ) ^ (-(k + 1 : ℝ)) := by
    apply hlamUpper0.trans
    have hfac0 :
        0 ≤ A * fixedBetaUpperConst k *
          (V : ℝ) ^ (-(k + 1 : ℝ)) := by
      exact mul_nonneg
        (mul_nonneg hA.le (fixedBetaUpperConst_pos k).le)
        (Real.rpow_nonneg hVr.le _)
    have hm := mul_le_mul_of_nonneg_right hjrH hfac0
    simpa [mul_assoc] using hm
  have hLowerOne :
      (A * fixedBetaLowerConst k) *
        (V : ℝ) ^ (-(k + 1 : ℝ)) ≤ lam := by
    apply le_trans ?_ hlamLower0
    have hfac0 :
        0 ≤ A * fixedBetaLowerConst k *
          (V : ℝ) ^ (-(k + 1 : ℝ)) := by
      exact mul_nonneg
        (mul_nonneg hA.le (fixedBetaLowerConst_pos k).le)
        (Real.rpow_nonneg hVr.le _)
    have hm := mul_le_mul_of_nonneg_right hjr1 hfac0
    simpa [mul_assoc] using hm
  have ha : 0 < fixedBetaA k := fixedBetaA_pos hk
  have hHnat : 0 < H := lt_of_lt_of_le (by omega : 0 < j) hjH
  have hHr : 0 < (H : ℝ) := by exact_mod_cast hHnat
  have hUpperPos :
      0 < ((H : ℝ) * A * fixedBetaUpperConst k) *
        (V : ℝ) ^ (-(k + 1 : ℝ)) := by
    exact mul_pos
      (mul_pos (mul_pos hHr hA) (fixedBetaUpperConst_pos k))
      (Real.rpow_pos_of_pos hVr _)
  have hLowerPos :
      0 < (A * fixedBetaLowerConst k) *
        (V : ℝ) ^ (-(k + 1 : ℝ)) := by
    exact mul_pos
      (mul_pos hA (fixedBetaLowerConst_pos k))
      (Real.rpow_pos_of_pos hVr _)
  have hpUpper :
      lam ^ fixedBetaA k ≤
        (((H : ℝ) * A * fixedBetaUpperConst k) *
          (V : ℝ) ^ (-(k + 1 : ℝ))) ^ fixedBetaA k :=
    Real.rpow_le_rpow hlamPos.le hUpperH ha.le
  have hpLower :
      ((A * fixedBetaLowerConst k) *
        (V : ℝ) ^ (-(k + 1 : ℝ))) ^ fixedBetaA k
        ≤ lam ^ fixedBetaA k :=
    Real.rpow_le_rpow hLowerPos.le hLowerOne ha.le
  have hneg :
      lam ^ (-(fixedBetaA k)) ≤
        ((A * fixedBetaLowerConst k) *
          (V : ℝ) ^ (-(k + 1 : ℝ))) ^ (-(fixedBetaA k)) := by
    rw [Real.rpow_neg hlamPos.le, Real.rpow_neg hLowerPos.le]
    exact (inv_le_inv₀
      (Real.rpow_pos_of_pos hlamPos (fixedBetaA k))
      (Real.rpow_pos_of_pos hLowerPos (fixedBetaA k))).2 hpLower
  have hCk0 : 0 ≤ reciprocalFiniteOrderConst k :=
    le_trans (by norm_num) (reciprocalFiniteOrderConst_ge_one k)
  have hfirst :
      2 * reciprocalFiniteOrderConst k * lam ^ fixedBetaA k ≤
        etaShellC1 k H * A ^ fixedBetaA k *
          (V : ℝ) ^ (-((k + 1 : ℝ) * fixedBetaA k)) := by
    have hC0 : 0 ≤ 2 * reciprocalFiniteOrderConst k :=
      mul_nonneg (by norm_num) hCk0
    have hm := mul_le_mul_of_nonneg_left hpUpper hC0
    rw [etaShell_upper_endpoint_identity hVr hApr] at hm
    simpa [etaShellC1, mul_assoc] using hm
  have hsecond :
      2 * reciprocalFiniteOrderConst k *
        ((V : ℝ) ^ (1 - 4 / (2 : ℝ)^k) *
          lam ^ (-(fixedBetaA k))) / (V : ℝ)
      ≤
      etaShellC2 k * A ^ (-(fixedBetaA k)) *
        (V : ℝ) ^ etaShellDelta k := by
    have hVpow0 :
        0 ≤ (V : ℝ) ^ (1 - 4 / (2 : ℝ)^k) :=
      Real.rpow_nonneg hVr.le _
    have hm0 :
        (V : ℝ) ^ (1 - 4 / (2 : ℝ)^k) *
            lam ^ (-(fixedBetaA k))
          ≤
        (V : ℝ) ^ (1 - 4 / (2 : ℝ)^k) *
          (((A * fixedBetaLowerConst k) *
            (V : ℝ) ^ (-(k + 1 : ℝ))) ^ (-(fixedBetaA k))) :=
      mul_le_mul_of_nonneg_left hneg hVpow0
    have htwoC : 0 ≤ 2 * reciprocalFiniteOrderConst k :=
      mul_nonneg (by norm_num) hCk0
    have hm1 := mul_le_mul_of_nonneg_left hm0 htwoC
    have hm2 :
        (2 * reciprocalFiniteOrderConst k *
          ((V : ℝ) ^ (1 - 4 / (2 : ℝ)^k) *
            lam ^ (-(fixedBetaA k)))) / (V : ℝ)
          ≤
        (2 * reciprocalFiniteOrderConst k *
          ((V : ℝ) ^ (1 - 4 / (2 : ℝ)^k) *
            (((A * fixedBetaLowerConst k) *
              (V : ℝ) ^ (-(k + 1 : ℝ))) ^ (-(fixedBetaA k))))) /
            (V : ℝ) := by
      exact div_le_div_of_nonneg_right hm1 hVr.le
    have hid := etaShell_lower_endpoint_identity
      (V := (V : ℝ)) (A := A) (k := k) hVr hA
    calc
      2 * reciprocalFiniteOrderConst k *
          ((V : ℝ) ^ (1 - 4 / (2 : ℝ)^k) *
            lam ^ (-(fixedBetaA k))) / (V : ℝ)
        ≤
      2 * reciprocalFiniteOrderConst k *
          ((V : ℝ) ^ (1 - 4 / (2 : ℝ)^k) *
            (((A * fixedBetaLowerConst k) *
              (V : ℝ) ^ (-(k + 1 : ℝ))) ^ (-(fixedBetaA k)))) /
            (V : ℝ) := hm2
      _ =
      2 * reciprocalFiniteOrderConst k *
        (((V : ℝ) ^ (1 - 4 / (2 : ℝ)^k) *
            (((A * fixedBetaLowerConst k) *
              (V : ℝ) ^ (-(k + 1 : ℝ))) ^ (-(fixedBetaA k)))) /
          (V : ℝ)) := by ring
      _ =
      etaShellC2 k * A ^ (-(fixedBetaA k)) *
        (V : ℝ) ^ etaShellDelta k := by
          rw [hid]
          simp [etaShellC2]
          ring
  have hraw :
      ‖∑ n ∈ Finset.Icc V B,
          ((((n : ℝ)⁻¹ : ℝ) : ℂ) *
            eR (A' / (n : ℝ) + xi * (n : ℝ)))‖
        ≤
      2 / (V : ℝ) +
      2 * reciprocalFiniteOrderConst k * lam ^ fixedBetaA k +
      2 * reciprocalFiniteOrderConst k *
        ((V : ℝ) ^ (1 - 4 / (2 : ℝ)^k) *
          lam ^ (-(fixedBetaA k))) / (V : ℝ) := by
    have hVne : (V : ℝ) ≠ 0 := hVr.ne'
    calc
      ‖∑ n ∈ Finset.Icc V B,
          ((((n : ℝ)⁻¹ : ℝ) : ℂ) *
            eR (A' / (n : ℝ) + xi * (n : ℝ)))‖
        ≤
        2 * (1 + reciprocalFiniteOrderConst k *
          ((V : ℝ) * lam ^ fixedBetaA k +
            (V : ℝ) ^ fixedBetaB k *
              lam ^ (-(fixedBetaA k)))) / (V : ℝ) := by
            simpa [lam, fixedBetaA, fixedBetaB] using hbase
      _ =
        2 / (V : ℝ) +
        2 * reciprocalFiniteOrderConst k * lam ^ fixedBetaA k +
        2 * reciprocalFiniteOrderConst k *
          ((V : ℝ) ^ (1 - 4 / (2 : ℝ)^k) *
            lam ^ (-(fixedBetaA k))) / (V : ℝ) := by
              rw [fixedBetaB]
              field_simp [hVne]
              ring
  exact hraw.trans
    (add_le_add (add_le_add le_rfl hfirst) hsecond)

lemma etaShell_upper_edge_exponent_nonpos
    {k : ℕ} (hk : 3 ≤ k) :
    -(fixedBetaA k) + etaShellDelta k / (k : ℝ) ≤ 0 := by
  have hkpos : 0 < (k : ℝ) := by exact_mod_cast (show 0 < k by omega)
  unfold etaShellDelta fixedBetaA
  have hx : 0 < (2 : ℝ)^k := by positivity
  have hd : 0 < (2 : ℝ)^k - 2 := by
    have hp : (8 : ℝ) ≤ (2 : ℝ)^k := by
      have h := pow_le_pow_right₀ (a := (2 : ℝ)) (by norm_num) hk
      norm_num at h ⊢
      exact h
    linarith
  have hpow8 : (8 : ℝ) ≤ (2 : ℝ)^k := by
    have h := pow_le_pow_right₀ (a := (2 : ℝ)) (by norm_num) hk
    norm_num at h ⊢
    exact h
  have ha4 : 1 / ((2 : ℝ)^k - 2) ≤ 4 / (2 : ℝ)^k := by
    rw [div_le_div_iff₀ hd hx]
    nlinarith
  have hmain :
      -(1 / ((2 : ℝ)^k - 2)) +
        (((k : ℝ) + 1) * (1 / ((2 : ℝ)^k - 2)) -
          4 / (2 : ℝ)^k) / (k : ℝ)
        =
      (1 / (k : ℝ)) *
        (1 / ((2 : ℝ)^k - 2) - 4 / (2 : ℝ)^k) := by
    field_simp [hkpos.ne', hd.ne', hx.ne']
    ring
  rw [hmain]
  exact mul_nonpos_of_nonneg_of_nonpos (by positivity) (sub_nonpos.mpr ha4)

lemma etaShell_two_terminal_le_one
    {A V : ℝ} (hA : 0 < A) (hV : 0 ≤ V) (hVA : V ≤ A) :
    A ^ (-(fixedBetaA 2)) * V ^ etaShellDelta 2 ≤ 1 := by
  rw [etaShellDelta_two]
  have ha2 : fixedBetaA 2 = 1 / 2 := by norm_num [fixedBetaA]
  rw [ha2]
  rw [Real.rpow_neg hA.le]
  have hVsqrt : V ^ (1 / 2 : ℝ) ≤ A ^ (1 / 2 : ℝ) := by
    exact Real.rpow_le_rpow hV hVA (by norm_num)
  have hAsqrt : 0 < A ^ (1 / 2 : ℝ) := Real.rpow_pos_of_pos hA _
  rw [inv_mul_le_iff₀ hAsqrt]
  simpa [mul_comm] using hVsqrt


#print axioms etaShell_upper_edge_exponent_nonpos
#print axioms etaShell_two_terminal_le_one

#print axioms eta_reciprocal_weighted_shell_power_majorant
#print axioms etaShellDelta_pos
#print axioms etaShellDelta_two

end PaperB.Analytic
