import PaperB.Analytic.FiniteOrderDerivative
import PaperB.Analytic.FiniteDifferenceMVT
import PaperB.Analytic.AffineBlind

namespace PaperB.Analytic

open Real Finset
open scoped ComplexConjugate

/-- Explicit derivative tower for the reciprocal phase A/x. -/
noncomputable def reciprocalD (A : ℝ) (j : ℕ) (x : ℝ) : ℝ :=
  A * (-1 : ℝ) ^ j * (j.factorial : ℝ) * x ^ (-((j + 1 : ℕ) : ℤ))

lemma reciprocalD_zero (A x : ℝ) :
    reciprocalD A 0 x = A / x := by
  simp [reciprocalD, div_eq_mul_inv]

/-- The reciprocal derivative tower differentiates exactly one level up away from zero. -/
lemma reciprocalD_hasDerivAt (A : ℝ) :
    ∀ j : ℕ, ∀ x : ℝ, x ≠ 0 →
      HasDerivAt (reciprocalD A j) (reciprocalD A (j + 1) x) x := by
  intro j x hx
  have hz : HasDerivAt (fun y : ℝ => y ^ (-((j + 1 : ℕ) : ℤ)))
      (((-((j + 1 : ℕ) : ℤ) : ℤ) : ℝ) *
        x ^ (-((j + 1 : ℕ) : ℤ) - 1)) x :=
    hasDerivAt_zpow _ x (Or.inl hx)
  have hc := hz.const_mul (A * (-1 : ℝ) ^ j * (j.factorial : ℝ))
  have hfun : reciprocalD A j =
      fun y : ℝ => A * (-1 : ℝ) ^ j * (j.factorial : ℝ) *
        y ^ (-((j + 1 : ℕ) : ℤ)) := rfl
  have hval :
      A * (-1 : ℝ) ^ j * (j.factorial : ℝ) *
          (((-((j + 1 : ℕ) : ℤ) : ℤ) : ℝ) *
            x ^ (-((j + 1 : ℕ) : ℤ) - 1))
        = reciprocalD A (j + 1) x := by
    simp only [reciprocalD]
    rw [show -((j + 1 : ℕ) : ℤ) - 1 =
        -(((j + 1) + 1 : ℕ) : ℤ) from by push_cast; ring,
      Nat.factorial_succ]
    push_cast
    ring
  rw [hfun, ← hval]
  exact hc

lemma reciprocalD_signed_top (A : ℝ) (k : ℕ) (x : ℝ) :
    (-1 : ℝ) ^ k * reciprocalD A k x =
      A * (k.factorial : ℝ) * x ^ (-((k + 1 : ℕ) : ℤ)) := by
  rw [reciprocalD]
  have hs : (-1 : ℝ) ^ k * (-1 : ℝ) ^ k = 1 := by
    rw [← pow_add, ← two_mul, pow_mul]
    norm_num
  calc
    (-1 : ℝ) ^ k *
        (A * (-1 : ℝ) ^ k * (k.factorial : ℝ) *
          x ^ (-((k + 1 : ℕ) : ℤ)))
      = A * (((-1 : ℝ) ^ k * (-1 : ℝ) ^ k)) *
          (k.factorial : ℝ) * x ^ (-((k + 1 : ℕ) : ℤ)) := by ring
    _ = A * (k.factorial : ℝ) * x ^ (-((k + 1 : ℕ) : ℤ)) := by
      rw [hs]
      ring

/-- The k-th forward difference of the sign-corrected sampled reciprocal phase
is trapped by the endpoint values of its k-th derivative. -/
lemma reciprocal_dk_window
    (A : ℝ) (hA : 0 < A) (k N : ℕ) (hk : 2 ≤ k) (hN : k ≤ N)
    (n : ℤ) (hn1 : (N : ℤ) < n) (hn2 : n < 2 * (N : ℤ)) :
    A * (k.factorial : ℝ) *
        (((2 * N + k : ℕ) : ℝ) ^ (k + 1))⁻¹
      ≤ dk k (fun m : ℤ => (-1 : ℝ) ^ k * (A / (m : ℝ))) n
    ∧ dk k (fun m : ℤ => (-1 : ℝ) ^ k * (A / (m : ℝ))) n
      ≤ A * (k.factorial : ℝ) * ((N : ℝ) ^ (k + 1))⁻¹ := by
  have hN1 : 1 ≤ N := by omega
  have hnpos : (0 : ℤ) < n := lt_trans (by exact_mod_cast hN1) hn1
  have hn0R : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hnpos
  have hfacpos : (0 : ℝ) < (k.factorial : ℝ) := by
    exact_mod_cast Nat.factorial_pos k
  have hcoefpos : 0 < A * (k.factorial : ℝ) := mul_pos hA hfacpos
  set Phi : ℕ → ℝ → ℝ := fun j x => (-1 : ℝ) ^ k * reciprocalD A j x with hPhi
  have hderiv : ∀ j : ℕ, ∀ x : ℝ, 0 < x →
      HasDerivAt (Phi j) (Phi (j + 1) x) x := by
    intro j x hx
    simpa only [hPhi] using
      (reciprocalD_hasDerivAt A j x (ne_of_gt hx)).const_mul ((-1 : ℝ) ^ k)
  have htop : ∀ x : ℝ,
      Phi k x = A * (k.factorial : ℝ) * (x ^ (k + 1))⁻¹ := by
    intro x
    simp only [hPhi, reciprocalD_signed_top]
    rw [zpow_neg, zpow_natCast]
  have hPhi0 :
      (fun m : ℤ => Phi 0 (m : ℝ)) =
        (fun m : ℤ => (-1 : ℝ) ^ k * (A / (m : ℝ))) := by
    funext m
    simp only [hPhi, reciprocalD_zero]
  have hupper : ∀ x : ℝ, (n : ℝ) ≤ x → x ≤ (n : ℝ) + (k : ℝ) →
      Phi k x ≤ A * (k.factorial : ℝ) * ((N : ℝ) ^ (k + 1))⁻¹ := by
    intro x hx1 _
    rw [htop x]
    have hxpos : 0 < x := lt_of_lt_of_le hn0R hx1
    have hNle : (N : ℝ) ≤ x := by
      have : (N : ℝ) < (n : ℝ) := by exact_mod_cast hn1
      linarith
    have hpow : (N : ℝ) ^ (k + 1) ≤ x ^ (k + 1) :=
      pow_le_pow_left₀ (by positivity) hNle _
    have hinv : (x ^ (k + 1))⁻¹ ≤ ((N : ℝ) ^ (k + 1))⁻¹ :=
      inv_anti₀ (by positivity) hpow
    exact mul_le_mul_of_nonneg_left hinv (le_of_lt hcoefpos)
  have hlower : ∀ x : ℝ, (n : ℝ) ≤ x → x ≤ (n : ℝ) + (k : ℝ) →
      A * (k.factorial : ℝ) *
          (((2 * N + k : ℕ) : ℝ) ^ (k + 1))⁻¹ ≤ Phi k x := by
    intro x hx1 hx2
    rw [htop x]
    have hxpos : 0 < x := lt_of_lt_of_le hn0R hx1
    have hxle : x ≤ ((2 * N + k : ℕ) : ℝ) := by
      have hn2R : (n : ℝ) ≤ 2 * (N : ℝ) := by
        have : (n : ℝ) < 2 * (N : ℝ) := by exact_mod_cast hn2
        linarith
      push_cast at hx2 ⊢
      linarith
    have hpow : x ^ (k + 1) ≤ ((2 * N + k : ℕ) : ℝ) ^ (k + 1) :=
      pow_le_pow_left₀ (le_of_lt hxpos) hxle _
    have hinv : (((2 * N + k : ℕ) : ℝ) ^ (k + 1))⁻¹ ≤ (x ^ (k + 1))⁻¹ :=
      inv_anti₀ (by positivity) hpow
    exact mul_le_mul_of_nonneg_left hinv (le_of_lt hcoefpos)
  have hbound := dk_bound_of_deriv_tower n hnpos k Phi
    (A * (k.factorial : ℝ) * (((2 * N + k : ℕ) : ℝ) ^ (k + 1))⁻¹)
    (A * (k.factorial : ℝ) * ((N : ℝ) ^ (k + 1))⁻¹)
    hderiv hlower hupper
  rw [hPhi0] at hbound
  exact hbound

/-- Negating the phase leaves the exponential-sum norm unchanged. -/
lemma norm_sum_eR_neg (s : Finset ℤ) (a : ℤ → ℝ) :
    ‖∑ n ∈ s, eR (-(a n))‖ = ‖∑ n ∈ s, eR (a n)‖ := by
  have h : conj (∑ n ∈ s, eR (a n)) = ∑ n ∈ s, eR (-(a n)) := by
    rw [map_sum]
    exact Finset.sum_congr rfl (fun n _ => conj_eR (a n))
  rw [← h, RCLike.norm_conj]

/-- Multiplication of the phase by (-1)^k does not change the sum norm. -/
lemma norm_sum_eR_signed (s : Finset ℤ) (a : ℤ → ℝ) (k : ℕ) :
    ‖∑ n ∈ s, eR ((-1 : ℝ) ^ k * a n)‖ = ‖∑ n ∈ s, eR (a n)‖ := by
  rcases Nat.even_or_odd k with he | ho
  · simp only [he.neg_one_pow, one_mul]
  · simp only [ho.neg_one_pow, neg_one_mul]
    exact norm_sum_eR_neg s a

/-- Fixed-order reciprocal exponential-sum estimate, uniform in the additive
linear twist xi. This is the Paper-B oscillatory specialization. -/
theorem reciprocalFiniteOrder
    (k : ℕ) (hk : 2 ≤ k) :
    ∃ C : ℝ, 1 ≤ C ∧
      ∀ (A xi : ℝ) (N : ℕ), 0 < A → k ≤ N →
        let lam :=
          A * (k.factorial : ℝ) *
            (((2 * N + k : ℕ) : ℝ) ^ (k + 1))⁻¹
        ‖∑ n ∈ Finset.Ioc (N : ℤ) (2 * N),
            eR (A / (n : ℝ) + xi * (n : ℝ))‖
          ≤ C * ((N : ℝ) * lam ^ (1 / ((2 : ℝ) ^ k - 2))
            + (N : ℝ) ^ (1 - 4 / (2 : ℝ) ^ k) *
              lam ^ (-(1 / ((2 : ℝ) ^ k - 2)))) := by
  obtain ⟨C0, hC01, hC0⟩ := finiteOrderDerivativeTest k hk
  refine ⟨C0 * ((3 : ℝ) ^ (k + 1)) ^ (4 / (2 : ℝ) ^ k), ?_, ?_⟩
  · have h3 : (1 : ℝ) ≤ ((3 : ℝ) ^ (k + 1)) ^ (4 / (2 : ℝ) ^ k) :=
      Real.one_le_rpow (one_le_pow₀ (by norm_num)) (by positivity)
    nlinarith [hC01, h3, mul_nonneg (sub_nonneg.mpr hC01) (sub_nonneg.mpr h3)]
  · intro A xi N hA hkN
    dsimp
    have hN1 : 1 ≤ N := by omega
    have hNR : (0 : ℝ) < (N : ℝ) := by exact_mod_cast hN1
    set lam : ℝ :=
      A * (k.factorial : ℝ) *
        (((2 * N + k : ℕ) : ℝ) ^ (k + 1))⁻¹ with hlam
    have hlampos : 0 < lam := by
      rw [hlam]
      positivity
    set cc : ℝ :=
      ((2 * N + k : ℕ) : ℝ) ^ (k + 1) / (N : ℝ) ^ (k + 1) with hcc
    have hcc1 : 1 ≤ cc := by
      rw [hcc, one_le_div (by positivity)]
      apply pow_le_pow_left₀ (by positivity)
      push_cast
      linarith
    have hratio : ((2 * N + k : ℕ) : ℝ) / (N : ℝ) ≤ 3 := by
      rw [div_le_iff₀ hNR]
      push_cast
      have : (k : ℝ) ≤ (N : ℝ) := by exact_mod_cast hkN
      linarith
    have hcc3 : cc ≤ (3 : ℝ) ^ (k + 1) := by
      rw [hcc, ← div_pow]
      exact pow_le_pow_left₀ (by positivity) hratio _
    have hclam :
        cc * lam = A * (k.factorial : ℝ) * ((N : ℝ) ^ (k + 1))⁻¹ := by
      rw [hcc, hlam]
      field_simp
    set phase : ℤ → ℝ := fun m => A / (m : ℝ) + xi * (m : ℝ) with hphase
    set g : ℤ → ℝ := fun m => (-1 : ℝ) ^ k * phase m with hg
    have hgform :
        g = fun m : ℤ =>
          (-1 : ℝ) ^ k * (A / (m : ℝ)) +
            (((-1 : ℝ) ^ k) * xi) * (m : ℝ) := by
      funext m
      simp only [hg, hphase]
      ring
    have hdiff := fun (n : ℤ) (h1 : (N : ℤ) < n) (h2 : n < 2 * (N : ℤ)) =>
      reciprocal_dk_window A hA k N hk hkN n h1 h2
    have hbase := hC0 g (N : ℤ) (2 * (N : ℤ)) lam cc
      (by omega) hlampos hcc1
      (fun n h1 h2 => by
        rw [hgform, dk_add_linear
          (fun m : ℤ => (-1 : ℝ) ^ k * (A / (m : ℝ)))
          (((-1 : ℝ) ^ k) * xi) hk n, hlam]
        exact (hdiff n h1 h2).1)
      (fun n h1 h2 => by
        rw [hgform, dk_add_linear
          (fun m : ℤ => (-1 : ℝ) ^ k * (A / (m : ℝ)))
          (((-1 : ℝ) ^ k) * xi) hk n, hclam]
        exact (hdiff n h1 h2).2)
    have hlen : ((2 * (N : ℤ) : ℤ) : ℝ) - ((N : ℤ) : ℝ) = (N : ℝ) := by
      push_cast
      ring
    rw [hlen] at hbase
    have hnorm :
        ‖∑ n ∈ Finset.Ioc (N : ℤ) (2 * N), eR (g n)‖ =
          ‖∑ n ∈ Finset.Ioc (N : ℤ) (2 * N), eR (phase n)‖ := by
      simp only [hg]
      exact norm_sum_eR_signed _ phase k
    rw [hnorm] at hbase
    simp only [hphase] at hbase
    refine le_trans hbase ?_
    have hX : 0 ≤
        (N : ℝ) * lam ^ (1 / ((2 : ℝ) ^ k - 2)) +
          (N : ℝ) ^ (1 - 4 / (2 : ℝ) ^ k) *
            lam ^ (-(1 / ((2 : ℝ) ^ k - 2))) := by positivity
    apply mul_le_mul_of_nonneg_right _ hX
    apply mul_le_mul_of_nonneg_left _ (le_trans zero_le_one hC01)
    exact Real.rpow_le_rpow (le_trans zero_le_one hcc1) hcc3 (by positivity)

#print axioms reciprocalFiniteOrder

end PaperB.Analytic
