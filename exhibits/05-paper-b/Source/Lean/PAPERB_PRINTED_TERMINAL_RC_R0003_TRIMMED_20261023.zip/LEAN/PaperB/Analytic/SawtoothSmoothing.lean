import PaperB.FixedQ.PetermannInterface
import Mathlib.Analysis.Fourier.AddCircle
import Mathlib.Analysis.SpecialFunctions.Integrals.Basic
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic
import Mathlib.Topology.Algebra.Order.Floor

open scoped BigOperators ComplexConjugate

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Set MeasureTheory

noncomputable def sawSmoothHalfWidth (T : ℝ) : ℝ := 1 / (2 * T)

noncomputable def smoothedSawCell (T x : ℝ) : ℝ :=
  if x ≤ sawSmoothHalfWidth T then
    (1 - T) * x
  else if x ≤ 1 - sawSmoothHalfWidth T then
    x - 1 / 2
  else
    (1 - T) * (x - 1)

noncomputable def smoothedSawtooth (T x : ℝ) : ℝ :=
  smoothedSawCell T (Int.fract x)

lemma sawSmoothHalfWidth_pos {T : ℝ} (hT : 0 < T) :
    0 < sawSmoothHalfWidth T := by
  rw [sawSmoothHalfWidth]
  positivity

lemma sawSmoothHalfWidth_lt_half {T : ℝ} (hT : 1 < T) :
    sawSmoothHalfWidth T < 1 / 2 := by
  rw [sawSmoothHalfWidth]
  have hT0 : 0 < T := lt_trans zero_lt_one hT
  rw [div_lt_iff₀ (mul_pos (by norm_num : (0:ℝ)<2) hT0)]
  nlinarith

lemma sawSmoothHalfWidth_le_one_sub {T : ℝ} (hT : 1 ≤ T) :
    sawSmoothHalfWidth T ≤ 1 - sawSmoothHalfWidth T := by
  by_cases hTeq : T = 1
  · subst T
    norm_num [sawSmoothHalfWidth]
  · have hTlt : 1 < T := lt_of_le_of_ne hT (Ne.symm hTeq)
    have h := sawSmoothHalfWidth_lt_half hTlt
    linarith

lemma smoothedSawCell_zero {T : ℝ} (hT : 0 < T) :
    smoothedSawCell T 0 = 0 := by
  have ha : 0 ≤ sawSmoothHalfWidth T := (sawSmoothHalfWidth_pos hT).le
  simp [smoothedSawCell, ha]

lemma smoothedSawCell_one {T : ℝ} (hT : 1 < T) :
    smoothedSawCell T 1 = 0 := by
  have hT0 : 0 < T := lt_trans zero_lt_one hT
  have ha : 0 < sawSmoothHalfWidth T := sawSmoothHalfWidth_pos hT0
  have hnot1 : ¬ (1 ≤ sawSmoothHalfWidth T) := by
    rw [sawSmoothHalfWidth]
    have h2T : 0 < 2 * T := by positivity
    rw [not_le, div_lt_iff₀ h2T]
    nlinarith
  have hnot2 : ¬ (1 ≤ 1 - sawSmoothHalfWidth T) := by
    linarith
  simp [smoothedSawCell, hnot1, hnot2]

lemma continuous_smoothedSawCell {T : ℝ} (hT : 1 < T) :
    Continuous (smoothedSawCell T) := by
  have hT0 : 0 < T := lt_trans zero_lt_one hT
  let a : ℝ := sawSmoothHalfWidth T
  let b : ℝ := 1 - sawSmoothHalfWidth T
  have hright :
      Continuous (fun x : ℝ =>
        if x ≤ b then x - 1/2 else (1-T)*(x-1)) := by
    apply Continuous.if_le
      (by fun_prop) (by fun_prop) continuous_id continuous_const
    intro x hx
    dsimp [b] at hx
    subst x
    have hTne : T ≠ 0 := ne_of_gt hT0
    rw [sawSmoothHalfWidth]
    field_simp [hTne] <;> ring
  have hfull :
      Continuous (fun x : ℝ =>
        if x ≤ a then (1 - T) * x
        else if x ≤ b then x - 1/2 else (1 - T) * (x - 1)) := by
    apply Continuous.if_le
      (by fun_prop) hright continuous_id continuous_const
    intro x hx
    dsimp [a] at hx
    subst x
    have hab : sawSmoothHalfWidth T ≤ 1 - sawSmoothHalfWidth T :=
      sawSmoothHalfWidth_le_one_sub hT.le
    rw [if_pos hab]
    have hTne : T ≠ 0 := ne_of_gt hT0
    rw [sawSmoothHalfWidth]
    field_simp [hTne] <;> ring
  unfold smoothedSawCell
  simpa only [a, b] using hfull

lemma continuous_smoothedSawtooth {T : ℝ} (hT : 1 < T) :
    Continuous (smoothedSawtooth T) := by
  have hT0 : 0 < T := lt_trans zero_lt_one hT
  unfold smoothedSawtooth
  apply ContinuousOn.comp_fract''
    (continuous_smoothedSawCell hT).continuousOn
  rw [smoothedSawCell_zero hT0, smoothedSawCell_one hT]

lemma smoothedSawtooth_periodic (T : ℝ) :
    Function.Periodic (smoothedSawtooth T) 1 := by
  intro x
  rw [smoothedSawtooth, smoothedSawtooth]
  have hx : x + 1 = x + ((1:ℤ):ℝ) := by norm_num
  rw [hx, Int.fract_add_intCast]

lemma smoothedSawtooth_eq_petermannSawtooth
    {T x : ℝ} (hT : 1 < T)
    (hlo : sawSmoothHalfWidth T < Int.fract x)
    (hhi : Int.fract x ≤ 1 - sawSmoothHalfWidth T) :
    smoothedSawtooth T x = petermannSawtooth x := by
  rw [smoothedSawtooth, smoothedSawCell]
  rw [if_neg (not_le.mpr hlo), if_pos hhi]
  unfold petermannSawtooth
  rw [Int.fract]

#print axioms continuous_smoothedSawtooth
#print axioms smoothedSawtooth_eq_petermannSawtooth

end PaperB.Analytic
