import Mathlib.RingTheory.RootsOfUnity.Complex
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.Complex.Trigonometric
import Mathlib.NumberTheory.Harmonic.Bounds
import Mathlib.Algebra.Field.GeomSum
import Mathlib.Tactic

/-!
# Quillon CSC3 seam 4: exact finite Fourier expansion of the sawtooth at rational points

This file replaces Vaaler. There is no truncation, so there is no near-integer pointwise error.

Every sawtooth in the selected source is evaluated at a rational `c/m` with `m ∤ c`. We prove the
**exact** finite expansion

    saw(c/m) = Σ_{k<m} a_m(k) · ζ_m^{kc}

with `ζ_m = exp(2πi/m)` and explicit coefficients:
* `a_m(0) = 0`;
* `a_m(k) = 1/(m(ζ^{-k} - 1)) + 1/(2m)` for `0 < k < m`;
* `‖a_m(k)‖ ≤ 1/(4·min(k, m-k)) + 1/(2m)`.

The **gcd tail** is also bounded. For `g ∣ m`, `g ≥ 1`:
`Σ_{0<k<m, g∣k} ‖a_m(k)‖ ≤ (2 + log m)/(2g)`.

So frequencies whose gcd with the modulus is `≥ G` carry total coefficient mass `≤ τ·(2+log m)/(2G)`.
They are paid by size, with no equidistribution input. Every other frequency has an effective
modulus `≥ m/G` and goes to W/VW/R.

Self-contained, Mathlib only. No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset Complex

namespace GoldC.QuillonSawDFT

/-- `ζ_m = exp(2πi/m)`. -/
noncomputable def zeta (m : ℕ) : ℂ := Complex.exp (2 * Real.pi * Complex.I / m)

lemma zeta_prim (m : ℕ) (hm : m ≠ 0) : IsPrimitiveRoot (zeta m) m :=
  Complex.isPrimitiveRoot_exp m hm

lemma zeta_ne_zero (m : ℕ) : zeta m ≠ 0 := Complex.exp_ne_zero _

/-- The centered sawtooth profile on `(0, m)`. -/
noncomputable def prof (m c : ℕ) : ℂ := (((c : ℝ) / m - 1 / 2 : ℝ) : ℂ)

/-- DFT coefficient of the sawtooth profile. -/
noncomputable def sawCoeff (m k : ℕ) : ℂ :=
  (1 / (m : ℂ)) * ∑ c ∈ Ioo 0 m, prof m c * zeta m ^ (-((k : ℤ) * c))

/-- Orthogonality of additive characters mod `m`. -/
lemma orth (m : ℕ) (hm : m ≠ 0) (j : ℤ) :
    ∑ k ∈ range m, zeta m ^ ((k : ℤ) * j) = if (m : ℤ) ∣ j then (m : ℂ) else 0 := by
  have hζ := zeta_prim m hm
  have hk : ∀ k : ℕ, zeta m ^ ((k : ℤ) * j) = (zeta m ^ j) ^ k := by
    intro k; rw [mul_comm, zpow_mul, zpow_natCast]
  simp_rw [hk]
  split_ifs with h
  · rw [(hζ.zpow_eq_one_iff_dvd j).2 h]; simp
  · have hx : zeta m ^ j ≠ 1 := fun h' => h ((hζ.zpow_eq_one_iff_dvd j).1 h')
    rw [geom_sum_eq hx]
    have : (zeta m ^ j) ^ m = 1 := by
      rw [← zpow_natCast, ← zpow_mul, mul_comm, zpow_mul, zpow_natCast, hζ.pow_eq_one, one_zpow]
    rw [this]; simp

/-- **Exact expansion** of the sawtooth profile on `(0, m)`. -/
theorem prof_expansion (m c : ℕ) (hm : 2 ≤ m) (hc : c ∈ Ioo 0 m) :
    prof m c = ∑ k ∈ range m, sawCoeff m k * zeta m ^ ((k : ℤ) * c) := by
  have hm0 : m ≠ 0 := by omega
  have hmC : (m : ℂ) ≠ 0 := by exact_mod_cast hm0
  unfold sawCoeff
  have step : ∀ k ∈ range m,
      (1 / (m : ℂ)) * (∑ c' ∈ Ioo 0 m, prof m c' * zeta m ^ (-((k : ℤ) * c'))) *
        zeta m ^ ((k : ℤ) * c) =
      (1 / (m : ℂ)) * ∑ c' ∈ Ioo 0 m, prof m c' * zeta m ^ ((k : ℤ) * ((c : ℤ) - c')) := by
    intro k _
    rw [mul_assoc, Finset.sum_mul]
    congr 1
    refine Finset.sum_congr rfl fun c' _ => ?_
    rw [mul_assoc, ← zpow_add₀ (zeta_ne_zero m)]
    congr 2; ring
  rw [Finset.sum_congr rfl step, ← Finset.mul_sum, Finset.sum_comm]
  have inner : ∀ c' ∈ Ioo 0 m,
      ∑ k ∈ range m, prof m c' * zeta m ^ ((k : ℤ) * ((c : ℤ) - c')) =
        if c' = c then prof m c' * m else 0 := by
    intro c' hc'
    rw [← Finset.mul_sum, orth m hm0]
    have hc1 := Finset.mem_Ioo.1 hc
    have hc2 := Finset.mem_Ioo.1 hc'
    by_cases h : c' = c
    · subst h; simp
    · have : ¬ (m : ℤ) ∣ ((c : ℤ) - c') := by
        intro hd
        obtain ⟨t, ht⟩ := hd
        have h1 : ((c : ℤ) - c') < m := by omega
        have h2 : -(m : ℤ) < ((c : ℤ) - c') := by omega
        rcases lt_trichotomy t 0 with ht0 | ht0 | ht0
        · have : (m : ℤ) * t ≤ -(m : ℤ) := by nlinarith
          omega
        · rw [ht0, mul_zero] at ht; omega
        · have : (m : ℤ) ≤ (m : ℤ) * t := by nlinarith
          omega
      simp [h, this]
  rw [Finset.sum_congr rfl inner, Finset.sum_ite_eq' (Ioo 0 m) c, if_pos hc]
  field_simp

/-! ## Closed form and size of the coefficients -/

/-- `(x - 1) Σ_{i<n} i x^i = n x^n - Σ_{i<n} x^(i+1)`. -/
lemma arith_geom (x : ℂ) (n : ℕ) :
    (x - 1) * ∑ i ∈ range n, (i : ℂ) * x ^ i = n * x ^ n - ∑ i ∈ range n, x ^ (i + 1) := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [Finset.sum_range_succ, Finset.sum_range_succ, mul_add, ih]
    push_cast; ring

theorem sawCoeff_closed (m k : ℕ) (hm : 2 ≤ m) (hk : k ∈ Ioo 0 m) :
    sawCoeff m k = 1 / ((m : ℂ) * (zeta m ^ (-(k : ℤ)) - 1)) + 1 / (2 * m) := by
  have hm0 : m ≠ 0 := by omega
  have hmC : (m : ℂ) ≠ 0 := by exact_mod_cast hm0
  have hζ := zeta_prim m hm0
  set x := zeta m ^ (-(k : ℤ)) with hxdef
  have hk1 := Finset.mem_Ioo.1 hk
  have hx1 : x ≠ 1 := by
    intro h
    have := (hζ.zpow_eq_one_iff_dvd (-(k : ℤ))).1 h
    rw [dvd_neg] at this
    have := Int.le_of_dvd (by omega) this
    omega
  have hxm : x ^ m = 1 := by
    rw [hxdef, ← zpow_natCast, ← zpow_mul, mul_comm, zpow_mul, zpow_natCast, hζ.pow_eq_one,
      one_zpow]
  have hpow : ∀ c : ℕ, zeta m ^ (-((k : ℤ) * c)) = x ^ c := by
    intro c; rw [hxdef, ← zpow_natCast, ← zpow_mul]; congr 1; ring
  have hgeom : ∑ i ∈ range m, x ^ i = 0 := by
    rw [geom_sum_eq hx1, hxm]; simp
  have hS : ∑ i ∈ range m, (i : ℂ) * x ^ i = m / (x - 1) := by
    have h := arith_geom x m
    have h2 : ∑ i ∈ range m, x ^ (i + 1) = 0 := by
      simp_rw [pow_succ]; rw [← Finset.sum_mul, hgeom, zero_mul]
    rw [h2, hxm, sub_zero, mul_one] at h
    have hx1' : x - 1 ≠ 0 := sub_ne_zero.2 hx1
    field_simp; rw [mul_comm]; exact h
  -- split range m = {0} ∪ Ioo 0 m
  have hsplit : ∀ f : ℕ → ℂ, ∑ i ∈ range m, f i = f 0 + ∑ i ∈ Ioo 0 m, f i := by
    intro f
    rw [Finset.range_eq_Ico, ← Finset.sum_Ioo_add_eq_sum_Ico (by omega), add_comm]
  unfold sawCoeff
  simp_rw [hpow]
  unfold prof
  have e1 : ∑ c ∈ Ioo 0 m, ((((c : ℝ) / m - 1 / 2 : ℝ)) : ℂ) * x ^ c =
      (1 / (m : ℂ)) * ∑ c ∈ Ioo 0 m, (c : ℂ) * x ^ c - (1 / 2) * ∑ c ∈ Ioo 0 m, x ^ c := by
    rw [Finset.mul_sum, Finset.mul_sum, ← Finset.sum_sub_distrib]
    refine Finset.sum_congr rfl fun c _ => ?_
    push_cast; ring
  have e2 : ∑ c ∈ Ioo 0 m, (c : ℂ) * x ^ c = m / (x - 1) := by
    have := hsplit (fun i => (i : ℂ) * x ^ i); rw [hS] at this; simp at this; exact this.symm
  have e3 : ∑ c ∈ Ioo 0 m, x ^ c = -1 := by
    have := hsplit (fun i => x ^ i); rw [hgeom] at this; simp at this; linear_combination -this
  rw [e1, e2, e3]
  have hx1' : x - 1 ≠ 0 := sub_ne_zero.2 hx1
  field_simp
  ring

/-- `‖ζ^{-k} - 1‖ ≥ 4·min(k, m-k)/m` for `0 < k < m` (Jordan). -/
lemma norm_zeta_sub_one_ge (m k : ℕ) (hm : 2 ≤ m) (hk : k ∈ Ioo 0 m) :
    4 * (min k (m - k) : ℕ) / (m : ℝ) ≤ ‖zeta m ^ (-(k : ℤ)) - 1‖ := by
  have hk1 := Finset.mem_Ioo.1 hk
  have hmR : (0 : ℝ) < m := by exact_mod_cast (show 0 < m by omega)
  have hexp : zeta m ^ (-(k : ℤ)) = Complex.exp (Complex.I * ((-(2 * Real.pi * k / m) : ℝ))) := by
    unfold zeta
    rw [← Complex.exp_int_mul]
    congr 1; push_cast; field_simp
  rw [hexp, Complex.norm_exp_I_mul_ofReal_sub_one]
  have hθ : (-(2 * Real.pi * k / m)) / 2 = -(Real.pi * k / m) := by ring
  rw [hθ, Real.sin_neg, mul_neg, norm_neg, Real.norm_eq_abs, abs_mul, abs_two]
  have hpi := Real.pi_pos
  -- sin(πk/m) ≥ 2·min(k,m-k)/m
  have key : 2 * (min k (m - k) : ℕ) / (m : ℝ) ≤ Real.sin (Real.pi * k / m) := by
    rcases le_total k (m - k) with hle | hle
    · rw [min_eq_left hle]
      have h0 : 0 ≤ Real.pi * k / m := by positivity
      have h1 : Real.pi * k / m ≤ Real.pi / 2 := by
        rw [div_le_div_iff₀ hmR (by norm_num)]
        have : (2 * k : ℝ) ≤ m := by
          have : 2 * k ≤ m := by omega
          exact_mod_cast this
        nlinarith
      have := Real.mul_le_sin h0 h1
      calc 2 * (k : ℝ) / m = 2 / Real.pi * (Real.pi * k / m) := by field_simp
        _ ≤ _ := this
    · rw [min_eq_right hle]
      have hmk : ((m - k : ℕ) : ℝ) = (m : ℝ) - k := by
        rw [Nat.cast_sub (by omega)]
      have hrefl : Real.sin (Real.pi * k / m) = Real.sin (Real.pi * ((m - k : ℕ) : ℝ) / m) := by
        rw [hmk, show Real.pi * ((m : ℝ) - k) / m = Real.pi - Real.pi * k / m by field_simp,
          Real.sin_pi_sub]
      rw [hrefl]
      have h0 : 0 ≤ Real.pi * ((m - k : ℕ) : ℝ) / m := by positivity
      have h1 : Real.pi * ((m - k : ℕ) : ℝ) / m ≤ Real.pi / 2 := by
        rw [div_le_div_iff₀ hmR (by norm_num)]
        have : (2 * (m - k : ℕ) : ℝ) ≤ m := by
          have : 2 * (m - k) ≤ m := by omega
          exact_mod_cast this
        nlinarith
      have := Real.mul_le_sin h0 h1
      calc 2 * ((m - k : ℕ) : ℝ) / m = 2 / Real.pi * (Real.pi * ((m - k : ℕ) : ℝ) / m) := by
            field_simp
        _ ≤ _ := this
  have hs0 : 0 ≤ Real.sin (Real.pi * k / m) := le_trans (by positivity) key
  rw [abs_of_nonneg hs0]
  have h4 : 4 * ((min k (m - k) : ℕ) : ℝ) / m = 2 * (2 * ((min k (m - k) : ℕ) : ℝ) / m) := by ring
  rw [h4]
  linarith

/-- **Coefficient size**: `‖a_m(k)‖ ≤ 1/(4·min(k,m-k)) + 1/(2m)` for `0 < k < m`. -/
theorem norm_sawCoeff_le (m k : ℕ) (hm : 2 ≤ m) (hk : k ∈ Ioo 0 m) :
    ‖sawCoeff m k‖ ≤ 1 / (4 * (min k (m - k) : ℕ)) + 1 / (2 * m) := by
  have hk1 := Finset.mem_Ioo.1 hk
  have hmR : (0 : ℝ) < m := by exact_mod_cast (show 0 < m by omega)
  have hmin : (0 : ℝ) < (min k (m - k) : ℕ) := by
    have : 0 < min k (m - k) := lt_min (by omega) (by omega)
    exact_mod_cast this
  rw [sawCoeff_closed m k hm hk]
  have hlow := norm_zeta_sub_one_ge m k hm hk
  have hpos : 0 < ‖zeta m ^ (-(k : ℤ)) - 1‖ := lt_of_lt_of_le (by positivity) hlow
  refine (norm_add_le _ _).trans (add_le_add ?_ ?_)
  · rw [norm_div, norm_one, norm_mul, Complex.norm_natCast]
    rw [div_le_div_iff₀ (by positivity) (by positivity), one_mul, one_mul]
    calc 4 * ((min k (m - k) : ℕ) : ℝ) = (m : ℝ) * (4 * (min k (m - k) : ℕ) / (m : ℝ)) := by
          field_simp
      _ ≤ (m : ℝ) * ‖zeta m ^ (-(k : ℤ)) - 1‖ := by
          exact mul_le_mul_of_nonneg_left hlow hmR.le
  · rw [norm_div, norm_one, norm_mul, Complex.norm_natCast]
    simp

/-! ## gcd tail: frequencies divisible by `g` carry mass `≤ (2 + log m)/(2g)` -/

theorem gcd_tail_le (m g : ℕ) (hm : 2 ≤ m) (hg : 1 ≤ g) (hgm : g ∣ m) :
    ∑ k ∈ (Ioo 0 m).filter (fun k => g ∣ k), ‖sawCoeff m k‖ ≤
      (2 + Real.log m) / (2 * g) := by
  obtain ⟨n, rfl⟩ := hgm
  have hn : 1 ≤ n := by
    rcases Nat.eq_zero_or_pos n with h | h
    · subst h; omega
    · exact h
  have hgR : (0 : ℝ) < g := by exact_mod_cast hg
  have hnR : (0 : ℝ) < n := by exact_mod_cast hn
  -- reindex k = g j, j ∈ Ioo 0 n
  have himg : (Ioo 0 (g * n)).filter (fun k => g ∣ k) = (Ioo 0 n).image (fun j => g * j) := by
    ext k
    simp only [Finset.mem_filter, Finset.mem_Ioo, Finset.mem_image]
    constructor
    · rintro ⟨⟨h1, h2⟩, j, rfl⟩
      refine ⟨j, ⟨?_, ?_⟩, rfl⟩
      · rcases Nat.eq_zero_or_pos j with h | h
        · subst h; omega
        · exact h
      · exact (Nat.mul_lt_mul_left (by omega)).1 h2
    · rintro ⟨j, ⟨h1, h2⟩, rfl⟩
      exact ⟨⟨Nat.mul_pos (by omega) h1, Nat.mul_lt_mul_of_pos_left h2 (by omega)⟩, ⟨j, rfl⟩⟩
  have hinj : Set.InjOn (fun j => g * j) (Ioo 0 n : Set ℕ) := by
    intro a _ b _ h; exact Nat.eq_of_mul_eq_mul_left (by omega) h
  rw [himg, Finset.sum_image hinj]
  -- bound each term: 1/(4 min) ≤ (1/(4g))(1/j + 1/(n-j)), and 1/(2gn)
  have hterm : ∀ j ∈ Ioo 0 n, ‖sawCoeff (g * n) (g * j)‖ ≤
      (1 / (4 * g)) * (1 / (j : ℝ) + 1 / ((n - j : ℕ) : ℝ)) + 1 / (2 * (g * n : ℕ)) := by
    intro j hj
    have hj1 := Finset.mem_Ioo.1 hj
    have hk : g * j ∈ Ioo 0 (g * n) := by
      rw [Finset.mem_Ioo]
      exact ⟨Nat.mul_pos (by omega) hj1.1, Nat.mul_lt_mul_of_pos_left hj1.2 (by omega)⟩
    have hm2 : 2 ≤ g * n := by
      have : 2 ≤ n := by omega
      nlinarith
    refine (norm_sawCoeff_le (g * n) (g * j) hm2 hk).trans ?_
    have hmin : min (g * j) (g * n - g * j) = g * min j (n - j) := by
      rw [← Nat.mul_sub, Nat.mul_min_mul_left]
    rw [hmin]
    have hjR : (0 : ℝ) < j := by exact_mod_cast hj1.1
    have hnjR : (0 : ℝ) < ((n - j : ℕ) : ℝ) := by
      have : 0 < n - j := by omega
      exact_mod_cast this
    gcongr
    -- 1/(4 g min(j,n-j)) ≤ (1/(4g))(1/j + 1/(n-j))
    push_cast
    rcases le_total j (n - j) with h | h
    · rw [min_eq_left (show (j : ℝ) ≤ ((n - j : ℕ) : ℝ) by exact_mod_cast h)]
      have : (1 : ℝ) / (4 * (g * j)) = (1 / (4 * g)) * (1 / j) := by field_simp
      rw [this]
      have : (0 : ℝ) ≤ 1 / ((n - j : ℕ) : ℝ) := by positivity
      push_cast at this
      nlinarith [show (0 : ℝ) < 1 / (4 * g) by positivity]
    · rw [min_eq_right (show ((n - j : ℕ) : ℝ) ≤ (j : ℝ) by exact_mod_cast h)]
      have : (1 : ℝ) / (4 * (g * ((n - j : ℕ) : ℝ))) = (1 / (4 * g)) * (1 / ((n - j : ℕ) : ℝ)) := by
        field_simp
      rw [this]
      have : (0 : ℝ) ≤ 1 / (j : ℝ) := by positivity
      nlinarith [show (0 : ℝ) < 1 / (4 * g) by positivity]
  refine (Finset.sum_le_sum hterm).trans ?_
  rw [Finset.sum_add_distrib, ← Finset.mul_sum, Finset.sum_add_distrib]
  -- Σ 1/j = Σ 1/(n-j) ≤ 1 + log n ≤ 1 + log m
  have hrefl : ∑ j ∈ Ioo 0 n, 1 / ((n - j : ℕ) : ℝ) = ∑ j ∈ Ioo 0 n, 1 / (j : ℝ) := by
    apply Finset.sum_nbij' (fun j => n - j) (fun j => n - j)
    · intro j hj; simp only [Finset.mem_Ioo] at hj ⊢; omega
    · intro j hj; simp only [Finset.mem_Ioo] at hj ⊢; omega
    · intro j hj; simp only [Finset.mem_Ioo] at hj; omega
    · intro j hj; simp only [Finset.mem_Ioo] at hj; omega
    · intro j hj; simp only [Finset.mem_Ioo] at hj; congr 2
  have hH : ∑ j ∈ Ioo 0 n, 1 / (j : ℝ) ≤ 1 + Real.log (g * n : ℕ) := by
    have h1 : ∑ j ∈ Ioo 0 n, 1 / (j : ℝ) ≤ ∑ j ∈ Finset.Icc 1 n, 1 / (j : ℝ) := by
      apply Finset.sum_le_sum_of_subset_of_nonneg
      · intro j hj; simp only [Finset.mem_Ioo, Finset.mem_Icc] at hj ⊢; omega
      · intro j _ _; positivity
    have h2 := harmonic_le_one_add_log n
    rw [harmonic_eq_sum_Icc] at h2; push_cast at h2
    have h3 : Real.log n ≤ Real.log (g * n : ℕ) := by
      apply Real.log_le_log hnR
      push_cast
      nlinarith [show (1 : ℝ) ≤ g by exact_mod_cast hg]
    simp only [one_div] at h1 ⊢
    linarith
  have hcard : ∑ _j ∈ Ioo 0 n, 1 / (2 * ((g * n : ℕ) : ℝ)) ≤ 1 / (2 * g) := by
    have hc : (((Ioo 0 n).card : ℕ) : ℝ) ≤ n := by
      rw [Nat.card_Ioo]; exact_mod_cast (by omega : n - 0 - 1 ≤ n)
    rw [Finset.sum_const, nsmul_eq_mul]
    calc (((Ioo 0 n).card : ℕ) : ℝ) * (1 / (2 * ((g * n : ℕ) : ℝ)))
        ≤ (n : ℝ) * (1 / (2 * ((g * n : ℕ) : ℝ))) :=
          mul_le_mul_of_nonneg_right hc (by positivity)
      _ = 1 / (2 * g) := by push_cast; field_simp
  rw [hrefl]
  have hlogpos : 0 ≤ Real.log (g * n : ℕ) := Real.log_nonneg (by
    have : 1 ≤ g * n := Nat.mul_pos (by omega) (by omega)
    exact_mod_cast this)
  calc 1 / (4 * (g : ℝ)) * (∑ j ∈ Ioo 0 n, 1 / (j : ℝ) + ∑ j ∈ Ioo 0 n, 1 / (j : ℝ)) +
        ∑ _j ∈ Ioo 0 n, 1 / (2 * ((g * n : ℕ) : ℝ))
      ≤ 1 / (4 * (g : ℝ)) * (2 * (1 + Real.log (g * n : ℕ))) + 1 / (2 * g) := by
        gcongr; linarith
    _ = (2 + Real.log (g * n : ℕ)) / (2 * g) := by field_simp; ring

end GoldC.QuillonSawDFT

#print axioms GoldC.QuillonSawDFT.prof_expansion
#print axioms GoldC.QuillonSawDFT.sawCoeff_closed
#print axioms GoldC.QuillonSawDFT.norm_sawCoeff_le
#print axioms GoldC.QuillonSawDFT.gcd_tail_le
