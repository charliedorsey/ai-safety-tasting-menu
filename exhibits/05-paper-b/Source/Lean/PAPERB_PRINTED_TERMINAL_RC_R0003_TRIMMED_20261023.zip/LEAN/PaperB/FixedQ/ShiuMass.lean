import PaperB.FixedQ.ShiuWeight
import PaperB.FixedQ.FixedConductorCompletion

open scoped BigOperators

namespace PaperB.FixedQ

lemma prime_squarefree_local {p : ℕ} (hp : p.Prime) : Squarefree p := by
  intro x hxx
  have hxdiv : x ∣ p := by
    rcases hxx with ⟨c, hc⟩
    refine ⟨x * c, ?_⟩
    rw [hc]
    ring
  rcases hp.eq_one_or_self_of_dvd x hxdiv with hx | hx
  · subst x
    simp
  · subst x
    have hle : p * p ≤ p := Nat.le_of_dvd hp.pos hxx
    have hp2 := hp.two_le
    nlinarith

theorem fixedQShiuWeight_prime_eq
    {q p : ℕ} (hp : p.Prime) (hc : p.Coprime (6 * q)) :
    fixedQShiuWeight q p = fixedQShiuPrimeFactor p := by
  rw [fixedQShiuWeight_apply, fixedQShiuWeightNat]
  rw [if_neg hp.ne_zero]
  have hs : Squarefree p := prime_squarefree_local hp
  rw [if_pos ⟨hs, hc⟩]
  simp [hp]

theorem prime_ge_five_of_coprime_six
    {p q : ℕ} (hp : p.Prime) (hc : p.Coprime (6 * q)) :
    5 ≤ p := by
  have hpNotDvdSix : ¬ p ∣ 6 := by
    intro hp6
    have hp6q : p ∣ 6 * q := dvd_mul_of_dvd_left hp6 q
    have hpone : p ∣ 1 := by
      rw [← hc.gcd_eq_one]
      exact Nat.dvd_gcd (dvd_refl p) hp6q
    exact hp.not_dvd_one hpone
  have hpne2 : p ≠ 2 := by
    intro h
    subst p
    apply hpNotDvdSix
    norm_num
  have hpne3 : p ≠ 3 := by
    intro h
    subst p
    apply hpNotDvdSix
    norm_num
  have hpne4 : p ≠ 4 := by
    intro h
    subst p
    have h2d : 2 ∣ 4 := by norm_num
    have hcases := (Nat.dvd_prime hp).mp h2d
    rcases hcases with h | h <;> norm_num at h
  have hp2 := hp.two_le
  omega

theorem fixedQShiu_prime_term_le
    {q p : ℕ} (hp : p.Prime) :
    fixedQShiuWeight q p / (p : ℝ) ≤
      5 * ((p : ℝ)⁻¹ ^ 2) := by
  by_cases hc : p.Coprime (6 * q)
  · have hp5 : 5 ≤ p := prime_ge_five_of_coprime_six hp hc
    rw [fixedQShiuWeight_prime_eq hp hc]
    unfold fixedQShiuPrimeFactor
    rw [if_pos hp5]
    have hpR : (5 : ℝ) ≤ (p : ℝ) := by exact_mod_cast hp5
    have hp0 : (0 : ℝ) < (p : ℝ) := by positivity
    have hpm3 : (0 : ℝ) < (p : ℝ) - 3 := by linarith
    field_simp [hp0.ne', hpm3.ne']
    nlinarith
  · rw [fixedQShiuWeight_apply, fixedQShiuWeightNat]
    rw [if_neg hp.ne_zero]
    have hzero : ¬ (Squarefree p ∧ p.Coprime (6 * q)) := by
      intro h
      exact hc h.2
    rw [if_neg hzero]
    have hnon : 0 ≤ 5 * ((p : ℝ)⁻¹ ^ 2) := by positivity
    simpa using hnon

theorem fixedQShiu_primeMass_le
    (q X k : ℕ) :
    PaperB.M4B.primeMass (fixedQShiuWeight q) X k ≤ (5 : ℝ) := by
  classical
  let P : Finset ℕ := X.primesLE.filter fun p => ¬ p ∣ k
  let T : Finset ℕ := Finset.Icc 2 X
  have hterm :
      (∑ p ∈ P, fixedQShiuWeight q p / (p : ℝ)) ≤
        ∑ p ∈ P, 5 * ((p : ℝ)⁻¹ ^ 2) := by
    apply Finset.sum_le_sum
    intro p hpP
    have hpPrime : p.Prime :=
      (Nat.mem_primesLE.mp (Finset.mem_filter.mp hpP).1).2
    exact fixedQShiu_prime_term_le hpPrime
  have hsubset : P ⊆ T := by
    intro p hpP
    have hpLE := Nat.mem_primesLE.mp (Finset.mem_filter.mp hpP).1
    exact Finset.mem_Icc.mpr ⟨hpLE.2.two_le, hpLE.1⟩
  have hnonneg :
      ∀ p ∈ T, p ∉ P → 0 ≤ 5 * ((p : ℝ)⁻¹ ^ 2) := by
    intro p hpT hpnot
    positivity
  have hsubsum :
      (∑ p ∈ P, 5 * ((p : ℝ)⁻¹ ^ 2)) ≤
        ∑ n ∈ T, 5 * ((n : ℝ)⁻¹ ^ 2) := by
    exact Finset.sum_le_sum_of_subset_of_nonneg hsubset hnonneg
  have htail :
      (∑ n ∈ T, ((n : ℝ)⁻¹ ^ 2)) ≤ (1 : ℝ) := by
    simpa [T] using
      (finite_square_tail_le_inv (F := 1) (M := X) (by norm_num))
  have hT :
      (∑ n ∈ T, 5 * ((n : ℝ)⁻¹ ^ 2)) ≤ (5 : ℝ) := by
    rw [← Finset.mul_sum]
    nlinarith
  unfold PaperB.M4B.primeMass
  change (∑ p ∈ P, fixedQShiuWeight q p / (p : ℝ)) ≤ (5 : ℝ)
  exact hterm.trans (hsubsum.trans hT)

theorem fixedQShiu_exp_primeMass_le
    (q X k : ℕ) :
    Real.exp (PaperB.M4B.primeMass (fixedQShiuWeight q) X k) ≤
      Real.exp (5 : ℝ) := by
  exact Real.exp_le_exp.mpr (fixedQShiu_primeMass_le q X k)

noncomputable def fixedQShiuCoprimeHarmonicTerm
    (q h n : ℕ) : ℝ :=
  if n.Coprime h then fixedQShiuWeight q n / (n : ℝ) else 0

lemma fixedQShiuCoprimeHarmonicTerm_nonneg
    (q h n : ℕ) :
    0 ≤ fixedQShiuCoprimeHarmonicTerm q h n := by
  unfold fixedQShiuCoprimeHarmonicTerm
  split_ifs
  · exact div_nonneg (fixedQShiuWeight_nonneg q n) (by positivity)
  · exact le_rfl

lemma sum_range_fixedQShiuCoprimeHarmonicTerm_le_exp_five
    (q h N : ℕ) :
    (∑ n ∈ Finset.range N, fixedQShiuCoprimeHarmonicTerm q h n)
      ≤ Real.exp (5 : ℝ) := by
  cases N with
  | zero => simpa using (Real.exp_pos (5 : ℝ)).le
  | succ K =>
      have hrange :
          Finset.range (K + 1) = insert 0 (Finset.Icc 1 K) := by
        ext n
        simp
        omega
      rw [hrange, Finset.sum_insert (by simp)]
      have hzero : fixedQShiuCoprimeHarmonicTerm q h 0 = 0 := by
        simp [fixedQShiuCoprimeHarmonicTerm, fixedQShiuWeight_apply,
          fixedQShiuWeightNat]
      rw [hzero, zero_add]
      have heq :
          (∑ n ∈ Finset.Icc 1 K,
            fixedQShiuCoprimeHarmonicTerm q h n) =
            PaperB.M4B.coprimeHarmonicMass (fixedQShiuWeight q) K h := by
        unfold PaperB.M4B.coprimeHarmonicMass
        simp_rw [Finset.sum_filter]
        apply Finset.sum_congr rfl
        intro n hn
        simp [fixedQShiuCoprimeHarmonicTerm]
      rw [heq]
      exact (PaperB.M4B.squarefree_coprime_harmonic_upper
        (fixedQShiuWeight_envelope q) K h).trans
          (fixedQShiu_exp_primeMass_le q K h)


theorem summable_fixedQShiuCoprimeHarmonicTerm
    (q h : ℕ) :
    Summable (fixedQShiuCoprimeHarmonicTerm q h) := by
  exact summable_of_sum_range_le
    (fixedQShiuCoprimeHarmonicTerm_nonneg q h)
    (sum_range_fixedQShiuCoprimeHarmonicTerm_le_exp_five q h)


theorem tsum_fixedQShiuWeight_div_coprime_le_exp_five
    (q h : ℕ) :
    (∑' n : ℕ, fixedQShiuCoprimeHarmonicTerm q h n)
      ≤ Real.exp (5 : ℝ) := by
  apply tsum_le_of_sum_le' (by positivity)
  intro s
  obtain ⟨N, hsN⟩ := Finset.exists_nat_subset_range s
  calc
    (∑ n ∈ s, fixedQShiuCoprimeHarmonicTerm q h n)
      ≤ ∑ n ∈ Finset.range N,
          fixedQShiuCoprimeHarmonicTerm q h n := by
        exact Finset.sum_le_sum_of_subset_of_nonneg hsN
          (fun n hn hnot => fixedQShiuCoprimeHarmonicTerm_nonneg q h n)
    _ ≤ Real.exp (5 : ℝ) :=
      sum_range_fixedQShiuCoprimeHarmonicTerm_le_exp_five q h N


#print axioms fixedQShiu_primeMass_le
#print axioms fixedQShiu_exp_primeMass_le

end PaperB.FixedQ
