import OrielUpper.ShellA

/-!
# Oriel Upper — the two fixed-variable inner bounds (both orientations)
-/

open Finset

namespace OrielUpper

variable {P : ℕ} [NeZero P]

lemma bW_mul_ne_zero {F r n : ℕ} (h : bW (F * r) n ≠ 0) : bW F n ≠ 0 ∧ Nat.Coprime r n := by
  rw [bW_mul_left] at h
  by_cases hc : Nat.Coprime r n
  · rw [if_pos hc] at h; exact ⟨h, hc⟩
  · rw [if_neg hc] at h; exact absurd rfl h

lemma RowHyp.hcop {F H : ℕ} {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {B : ℝ}
    (hR : RowHyp P F H w Λ B) (m : ℕ) : ∀ n, bW (F * m) n ≠ 0 → Nat.Coprime n (P * m) := by
  intro n hn
  obtain ⟨h1, h2⟩ := bW_mul_ne_zero hn
  exact Nat.Coprime.mul_right (hR.coprime_P h1) h2.symm

/-- Generic inner bound shape. -/
noncomputable def innerBound (P : ℕ) (B E1 E34 M D : ℝ) (a m : ℕ) : ℝ :=
  (2 * P + 1) * B * (1 + Real.log 4) * E1 * ((m.divisors.card : ℝ) / m + 2 / a) +
    E34 * (2 * P * B * (8 * M + 4 * P + 5) * ((m : ℝ) ^ 2 / a) * D ^ (3 / 4 : ℝ) +
      (2 * P + 2) * B * (1 + Real.log 4) * D ^ (-(1 / 4 : ℝ)))

lemma innerBound_nonneg {B E1 E34 M D : ℝ} {a m : ℕ} (hB : 0 ≤ B) (hE1 : 0 ≤ E1)
    (hE34 : 0 ≤ E34) (hM : 0 ≤ M) (hD : 0 < D) :
    0 ≤ innerBound P B E1 E34 M D a m := by
  unfold innerBound
  have : 0 ≤ Real.log 4 := Real.log_nonneg (by norm_num)
  positivity

/-- Orientation 1: fixed `r`, varying `s ∈ (a/r, b/r]`. -/
theorem s1_inner {F H : ℕ} {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {B : ℝ}
    (hR : RowHyp P F H w Λ B) {a b r : ℕ} (hr1 : 1 ≤ r) (hra : r ≤ a) (hb2 : b ≤ 2 * a)
    (hrW : bW F r ≠ 0) {M D E1 E34 : ℝ} (hHM : (H : ℝ) ≤ 2 * M * a) (hM : 0 ≤ M)
    (hD : 0 < D) (hE1 : Asig (F * r) (b / r) 1 ≤ E1)
    (hE34 : Asig (F * r) (b / r) (3 / 4) ≤ E34) :
    |∑ s ∈ Ioc (a / r) (b / r), bW (F * r) s * rowDisc w H r s| ≤
      innerBound P B E1 E34 M D a r := by
  have hr0 : 0 < r := hr1
  haveI : NeZero r := ⟨hr0.ne'⟩
  have hB0 := hR.B_nonneg
  have hE1' : 0 ≤ E1 := le_trans (Asig_nonneg _ _ _) hE1
  have hE34' : 0 ≤ E34 := le_trans (Asig_nonneg _ _ _) hE34
  have hA1 : 1 ≤ a / r := (Nat.one_le_div_iff hr0).mpr hra
  by_cases hAB : a / r ≤ b / r
  swap
  · rw [Ioc_eq_empty (by omega), sum_empty, abs_zero]
    exact innerBound_nonneg hB0 hE1' hE34' hM hD
  have hrP : Nat.Coprime r P := hR.coprime_P hrW
  have hHr : IsUnit (H : ZMod r) := (ZMod.isUnit_iff_coprime H r).mpr (hR.coprime_H hrW)
  have hsum : ∑ s ∈ Ioc (a / r) (b / r), bW (F * r) s * rowDisc w H r s =
      ∑ s ∈ Ioc (a / r) (b / r), bW (F * r) s *
        (psiR r H Λ (H : ZMod P) (-1) (s : ZMod P) (s : ZMod r) (((H - 1 : ℕ) : ℝ) / s) +
          cZero H w Λ / ((r : ℝ) * s)) := by
    apply sum_congr rfl
    intro s hs
    have hs0 : 0 < s := by have := (mem_Ioc.mp hs).1; omega
    rw [oriel_rowDisc_left hR.hw hr0 hs0]
    rfl
  rw [hsum]
  have hfv := oriel_fixed_var (m := r) (H := H) (F := F * r) hR.hB (α := (H : ZMod P))
    isUnit_one.neg hrP hHr (hR.hcop r) hA1 hAB (X0 := ((H - 1 : ℕ) : ℝ)) (by positivity)
    (oriel_centering hR.hw hR.hB) hD
  refine hfv.trans ?_
  have ha : (0 : ℝ) < a := by exact_mod_cast (show 0 < a by omega)
  have hamA : (a : ℝ) ≤ 2 * r * ((a / r : ℕ) : ℝ) := by exact_mod_cast two_mul_div_ge hr0 hra
  have hBn : b / r ≤ 4 * (a / r) := by
    have := div_le_three_max (a := a) (b := b) hr0 hb2
    rw [max_eq_left hA1] at this; omega
  have hX0H : ((H - 1 : ℕ) : ℝ) ≤ H := by exact_mod_cast Nat.sub_le H 1
  unfold innerBound
  exact fv_rhs_le (Nat.cast_nonneg P) hB0 (log_ratio_nonneg hA1 hAB) (log_ratio_le hA1 hBn)
    (Asig_nonneg _ _ _) hE1 (Asig_nonneg _ _ _) hE34 (Nat.cast_nonneg _)
    (by exact_mod_cast hr1) (by exact_mod_cast hA1) ha hamA (Nat.cast_nonneg _) hX0H hHM hM hD

/-- Orientation 2: fixed `s`, varying `r ∈ (A, b/s]` with `a/s ≤ A`. -/
theorem s2_inner {F H : ℕ} {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {B : ℝ}
    (hR : RowHyp P F H w Λ B) {a b s A : ℕ} (hs1 : 1 ≤ s) (hsa : s ≤ a) (hb2 : b ≤ 2 * a)
    (hAs : a / s ≤ A) (hsW : bW F s ≠ 0) {M D E1 E34 : ℝ} (hHM : (H : ℝ) ≤ 2 * M * a)
    (hM : 0 ≤ M) (hD : 0 < D) (hE1 : Asig (F * s) (b / s) 1 ≤ E1)
    (hE34 : Asig (F * s) (b / s) (3 / 4) ≤ E34) :
    |∑ r ∈ Ioc A (b / s), bW (F * s) r * rowDisc w H r s| ≤
      innerBound P B E1 E34 M D a s := by
  have hs0 : 0 < s := hs1
  haveI : NeZero s := ⟨hs0.ne'⟩
  have hB0 := hR.B_nonneg
  have hE1' : 0 ≤ E1 := le_trans (Asig_nonneg _ _ _) hE1
  have hE34' : 0 ≤ E34 := le_trans (Asig_nonneg _ _ _) hE34
  have hA1' : 1 ≤ a / s := (Nat.one_le_div_iff hs0).mpr hsa
  have hA1 : 1 ≤ A := le_trans hA1' hAs
  by_cases hAB : A ≤ b / s
  swap
  · rw [Ioc_eq_empty (by omega), sum_empty, abs_zero]
    exact innerBound_nonneg hB0 hE1' hE34' hM hD
  have hsP : Nat.Coprime s P := hR.coprime_P hsW
  have hHs : IsUnit (H : ZMod s) := (ZMod.isUnit_iff_coprime H s).mpr (hR.coprime_H hsW)
  have hsum : ∑ r ∈ Ioc A (b / s), bW (F * s) r * rowDisc w H r s =
      ∑ r ∈ Ioc A (b / s), bW (F * s) r *
        (psiR s H Λ 0 1 (r : ZMod P) (r : ZMod s) (((H - 1 : ℕ) : ℝ) / r) +
          cZero H w Λ / ((s : ℝ) * r)) := by
    apply sum_congr rfl
    intro r hr
    have hr0 : 0 < r := by have := (mem_Ioc.mp hr).1; omega
    rw [oriel_rowDisc_right hR.hw hr0 hs0, mul_comm (r : ℝ) (s : ℝ)]
    rfl
  rw [hsum]
  have hfv := oriel_fixed_var (m := s) (H := H) (F := F * s) hR.hB (α := (0 : ZMod P))
    isUnit_one hsP hHs (hR.hcop s) hA1 hAB (X0 := ((H - 1 : ℕ) : ℝ)) (by positivity)
    (oriel_centering hR.hw hR.hB) hD
  refine hfv.trans ?_
  have ha : (0 : ℝ) < a := by exact_mod_cast (show 0 < a by omega)
  have hamA : (a : ℝ) ≤ 2 * s * (A : ℝ) := by
    have h1 := two_mul_div_ge hs0 hsa
    have h2 : 2 * s * (a / s) ≤ 2 * s * A := Nat.mul_le_mul_left _ hAs
    exact_mod_cast h1.trans h2
  have hBn : b / s ≤ 4 * A := by
    have := div_le_three_max (a := a) (b := b) hs0 hb2
    rw [max_eq_left hA1'] at this; omega
  have hX0H : ((H - 1 : ℕ) : ℝ) ≤ H := by exact_mod_cast Nat.sub_le H 1
  unfold innerBound
  exact fv_rhs_le (Nat.cast_nonneg P) hB0 (log_ratio_nonneg hA1 hAB) (log_ratio_le hA1 hBn)
    (Asig_nonneg _ _ _) hE1 (Asig_nonneg _ _ _) hE34 (Nat.cast_nonneg _)
    (by exact_mod_cast hs1) (by exact_mod_cast hA1) ha hamA (Nat.cast_nonneg _) hX0H hHM hM hD

end OrielUpper
