import PaperB.FixedQ.DecoratedTerminalSpine
import PaperB.FixedQ.H2BooleanCauchy
import Mathlib.Algebra.Order.BigOperators.Ring.Finset

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def dForbiddenReducedBooleanCoreTerm
    (q a H : ℕ) (d n : Finset ℕ) : ℝ :=
  if Disjoint d n then ordinaryBooleanCoreTerm q a H n else 0

noncomputable def dForbiddenBooleanMainTerm
    (q a H : ℕ) (d n : Finset ℕ) : ℝ :=
  if Disjoint d n ∧ n.Nonempty then
    (activeOrdinaryTwoDimensionalSet q H).indicator
      (fun n => finiteOmegaWeightReal n *
        ((2 : ℝ) ^ n.card *
          fixedProductBooleanDiscrepancy (fixedQLowWeight q a H) H n)) n
  else 0

noncomputable def dForbiddenBooleanLeftEndpointTerm
    (q a H : ℕ) (d n : Finset ℕ) : ℝ :=
  if Disjoint d n ∧ n.Nonempty then
    (activeOrdinaryTwoDimensionalSet q H).indicator
      (fun n => finiteOmegaWeightReal n *
        fixedProductPartitionDiscrepancy
          (fixedQLowWeight q a H) H n n) n
  else 0

noncomputable def dForbiddenBooleanRightEndpointTerm
    (q a H : ℕ) (d n : Finset ℕ) : ℝ :=
  if Disjoint d n ∧ n.Nonempty then
    (activeOrdinaryTwoDimensionalSet q H).indicator
      (fun n => finiteOmegaWeightReal n *
        fixedProductPartitionDiscrepancy
          (fixedQLowWeight q a H) H n ∅) n
  else 0

theorem dForbiddenReducedBooleanCoreTerm_split
    (q a H : ℕ) (d n : Finset ℕ) :
    dForbiddenReducedBooleanCoreTerm q a H d n =
      dForbiddenBooleanMainTerm q a H d n -
        dForbiddenBooleanLeftEndpointTerm q a H d n -
        dForbiddenBooleanRightEndpointTerm q a H d n := by
  classical
  by_cases hdis : Disjoint d n
  · by_cases hne : n.Nonempty
    · rw [dForbiddenReducedBooleanCoreTerm, if_pos hdis]
      rw [dForbiddenBooleanMainTerm, if_pos ⟨hdis, hne⟩]
      rw [dForbiddenBooleanLeftEndpointTerm, if_pos ⟨hdis, hne⟩]
      rw [dForbiddenBooleanRightEndpointTerm, if_pos ⟨hdis, hne⟩]
      by_cases hact : n ∈ activeOrdinaryTwoDimensionalSet q H
      · simp only [ordinaryBooleanCoreTerm, Set.indicator_of_mem hact]
        rw [ordinaryBooleanInteriorDiscrepancy_eq_full_sub_endpoints
          (fixedQLowWeight q a H) H hne]
        ring
      · simp [ordinaryBooleanCoreTerm, Set.indicator, hact]
    · have hn0 : n = ∅ := Finset.not_nonempty_iff_eq_empty.mp hne
      subst n
      simp [dForbiddenReducedBooleanCoreTerm, dForbiddenBooleanMainTerm,
        dForbiddenBooleanLeftEndpointTerm, dForbiddenBooleanRightEndpointTerm,
        ordinaryBooleanCoreTerm, ordinaryBooleanInteriorDiscrepancy]
  · simp [dForbiddenReducedBooleanCoreTerm, dForbiddenBooleanMainTerm,
      dForbiddenBooleanLeftEndpointTerm, dForbiddenBooleanRightEndpointTerm, hdis]

#print axioms dForbiddenReducedBooleanCoreTerm_split


noncomputable def dForbiddenBooleanShiuMainTerm
    (q a H : ℕ) (d n : Finset ℕ) : ℝ :=
  if Disjoint d n ∧ n.Nonempty then
    (activeOrdinaryTwoDimensionalSet q H).indicator
      (fun n => fixedQShiuWeight q (primeSetProduct n) *
        fixedProductBooleanDiscrepancy (fixedQLowWeight q a H) H n) n
  else 0

theorem dForbiddenBooleanMainTerm_eq_shiu
    (q a H : ℕ) (d n : Finset ℕ) :
    dForbiddenBooleanMainTerm q a H d n =
      dForbiddenBooleanShiuMainTerm q a H d n := by
  classical
  by_cases hc : Disjoint d n ∧ n.Nonempty
  · rw [dForbiddenBooleanMainTerm, if_pos hc]
    rw [dForbiddenBooleanShiuMainTerm, if_pos hc]
    by_cases hact : n ∈ activeOrdinaryTwoDimensionalSet q H
    · rw [Set.indicator_of_mem hact, Set.indicator_of_mem hact]
      have hw := fixedQShiuWeight_primeSetProduct_eq_card_mul_finiteOmegaWeightReal
        (q := q) (n := n) hact.2
      rw [hw]
      ring
    · simp [Set.indicator, hact]
  · simp [dForbiddenBooleanMainTerm, dForbiddenBooleanShiuMainTerm, hc]

#print axioms dForbiddenBooleanMainTerm_eq_shiu


noncomputable def dForbiddenBooleanMainMajorantTerm
    (q a H : ℕ) (d n : Finset ℕ) : ℝ :=
  if Disjoint d n ∧ n.Nonempty then
    (activeOrdinaryTwoDimensionalSet q H).indicator
      (fun n => fixedQShiuWeight q (primeSetProduct n) *
        |fixedProductBooleanDiscrepancy (fixedQLowWeight q a H) H n|) n
  else 0

theorem abs_dForbiddenBooleanShiuMainTerm_eq_majorant
    (q a H : ℕ) (d n : Finset ℕ) :
    |dForbiddenBooleanShiuMainTerm q a H d n| =
      dForbiddenBooleanMainMajorantTerm q a H d n := by
  classical
  by_cases hc : Disjoint d n ∧ n.Nonempty
  · rw [dForbiddenBooleanShiuMainTerm, if_pos hc]
    rw [dForbiddenBooleanMainMajorantTerm, if_pos hc]
    by_cases hact : n ∈ activeOrdinaryTwoDimensionalSet q H
    · rw [Set.indicator_of_mem hact, Set.indicator_of_mem hact, abs_mul]
      rw [abs_of_nonneg (fixedQShiuWeight_nonneg q (primeSetProduct n))]
    · simp [Set.indicator, hact]
  · simp [dForbiddenBooleanShiuMainTerm,
      dForbiddenBooleanMainMajorantTerm, hc]

lemma dForbiddenBooleanMainMajorantTerm_nonneg
    (q a H : ℕ) (d n : Finset ℕ) :
    0 ≤ dForbiddenBooleanMainMajorantTerm q a H d n := by
  classical
  unfold dForbiddenBooleanMainMajorantTerm
  split_ifs with hc
  · by_cases hact : n ∈ activeOrdinaryTwoDimensionalSet q H
    · rw [Set.indicator_of_mem hact]
      exact mul_nonneg (fixedQShiuWeight_nonneg q (primeSetProduct n)) (abs_nonneg _)
    · simp [Set.indicator, hact]
  · exact le_rfl

#print axioms abs_dForbiddenBooleanShiuMainTerm_eq_majorant
#print axioms dForbiddenBooleanMainMajorantTerm_nonneg


theorem heightPrimePart_union_eq_left_of_reduced_ordinary
    {q h : ℕ} {d n : Finset ℕ}
    (hd : d ⊆ decoratedHeightPrimeSet q h)
    (hn : n ∈ activeOrdinaryTwoDimensionalSet q
      (h / primeSetProduct d))
    (hdis : Disjoint d n) :
    heightPrimePart h (d ∪ n) = d := by
  classical
  let D := primeSetProduct d
  let H := h / D
  have hdPrime : ∀ p ∈ d, p.Prime := by
    intro p hp
    have hpSet := Finset.mem_filter.mp (hd hp)
    exact Nat.prime_of_mem_primeFactors hpSet.1
  have hdDvd : D ∣ h := by
    dsimp [D]
    apply (primeSetProduct_dvd_iff hdPrime).2
    intro p hp
    have hpSet := Finset.mem_filter.mp (hd hp)
    exact Nat.dvd_of_mem_primeFactors hpSet.1
  have hfact : D * H = h := by
    dsimp [H]
    exact Nat.mul_div_cancel' hdDvd
  have hpfD : D.primeFactors = d := by
    dsimp [D, primeSetProduct]
    exact Nat.primeFactors_prod hdPrime
  have hnOrd : n ∈ ordinaryTwoDimensionalSet H := by
    simpa [H, D] using hn.1
  have hnNotH : ∀ p ∈ n, ¬ p ∣ H :=
    ordinaryTwoDimensionalSet_iff.mp hnOrd
  ext p
  constructor
  · intro hp
    have hp' := Finset.mem_filter.mp hp
    have hpU : p ∈ d ∪ n := hp'.1
    have hph : p ∣ h := hp'.2
    rcases Finset.mem_union.mp hpU with hpd | hpn
    · exact hpd
    · have hpPrime : p.Prime := (hn.2 p hpn).1
      have hpNotDmem : p ∉ d := by
        intro hpd
        exact Finset.disjoint_left.mp hdis hpd hpn
      have hpNotD : ¬ p ∣ D := by
        intro hpD
        have hD0 : D ≠ 0 := by
          exact Nat.ne_of_gt (primeSetProduct_pos hdPrime)
        have hpPF : p ∈ D.primeFactors :=
          Nat.mem_primeFactors.mpr ⟨hpPrime, hpD, hD0⟩
        exact hpNotDmem (by simpa [hpfD] using hpPF)
      have hpMul : p ∣ D * H := by simpa [hfact] using hph
      have hpH : p ∣ H := (hpPrime.dvd_mul.mp hpMul).resolve_left hpNotD
      exfalso
      exact (hnNotH p hpn) hpH
  · intro hpd
    have hpSet := Finset.mem_filter.mp (hd hpd)
    have hph : p ∣ h := Nat.dvd_of_mem_primeFactors hpSet.1
    exact Finset.mem_filter.mpr ⟨Finset.mem_union_left n hpd, hph⟩

#print axioms heightPrimePart_union_eq_left_of_reduced_ordinary


theorem decoratedHeightForbiddenCoreTerm_union_reconstruct
    {q a h : ℕ} {d n : Finset ℕ}
    (hd : d ⊆ decoratedHeightPrimeSet q h)
    (hn : n ∈ activeOrdinaryTwoDimensionalSet q
      (h / primeSetProduct d))
    (hdis : Disjoint d n) :
    decoratedHeightForbiddenCoreTerm q a h (d ∪ n) =
      finiteVWeightReal h d *
        ordinaryBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) n := by
  classical
  have hheight := heightPrimePart_union_eq_left_of_reduced_ordinary hd hn hdis
  have hAall : ∀ p ∈ d ∪ n, activeHighPrime q p := by
    intro p hp
    rcases Finset.mem_union.mp hp with hpd | hpn
    · have hpSet := Finset.mem_filter.mp (hd hpd)
      exact ⟨Nat.prime_of_mem_primeFactors hpSet.1, hpSet.2.1, hpSet.2.2⟩
    · exact hn.2 p hpn
  have hnd : n \ d = n := by
    ext p
    simp only [Finset.mem_sdiff, and_iff_left_iff_imp]
    intro hpn hpd
    exact (Finset.disjoint_left.mp hdis hpd hpn).elim
  have hsdiff : (d ∪ n) \ d = n := by
    rw [Finset.union_sdiff_left, hnd]
  unfold decoratedHeightForbiddenCoreTerm
  simp only [hheight, hsdiff, dif_pos hAall]
  rw [if_pos hdis]

#print axioms decoratedHeightForbiddenCoreTerm_union_reconstruct


noncomputable def decoratedAnalyticSignedReindexKey
    (q h : ℕ) (e : Finset ℕ) :
    (Finset ℕ × Finset ℕ) ⊕ Finset ℕ :=
  if ∀ p ∈ e, activeHighPrime q p then
    Sum.inl (heightPrimePart h e, e \ heightPrimePart h e)
  else Sum.inr e

theorem decoratedAnalyticSignedReindexKey_injective
    (q h : ℕ) :
    Function.Injective (decoratedAnalyticSignedReindexKey q h) := by
  intro e₁ e₂ hkey
  by_cases hA₁ : ∀ p ∈ e₁, activeHighPrime q p
  · by_cases hA₂ : ∀ p ∈ e₂, activeHighPrime q p
    · rw [decoratedAnalyticSignedReindexKey, if_pos hA₁,
        decoratedAnalyticSignedReindexKey, if_pos hA₂] at hkey
      have hk := Sum.inl.inj hkey
      have hd : heightPrimePart h e₁ = heightPrimePart h e₂ := congrArg Prod.fst hk
      have hn : e₁ \ heightPrimePart h e₁ = e₂ \ heightPrimePart h e₂ := congrArg Prod.snd hk
      have hu₁ : heightPrimePart h e₁ ∪ (e₁ \ heightPrimePart h e₁) = e₁ :=
        Finset.union_sdiff_of_subset (Finset.filter_subset _ _)
      have hu₂ : heightPrimePart h e₂ ∪ (e₂ \ heightPrimePart h e₂) = e₂ :=
        Finset.union_sdiff_of_subset (Finset.filter_subset _ _)
      have hu :
          heightPrimePart h e₁ ∪ (e₁ \ heightPrimePart h e₁) =
            heightPrimePart h e₂ ∪ (e₂ \ heightPrimePart h e₂) := by
        exact congrArg (fun x : Finset ℕ × Finset ℕ => x.1 ∪ x.2) hk
      exact hu₁.symm.trans (hu.trans hu₂)
    · rw [decoratedAnalyticSignedReindexKey, if_pos hA₁,
        decoratedAnalyticSignedReindexKey, if_neg hA₂] at hkey
      cases hkey
  · by_cases hA₂ : ∀ p ∈ e₂, activeHighPrime q p
    · rw [decoratedAnalyticSignedReindexKey, if_neg hA₁,
        decoratedAnalyticSignedReindexKey, if_pos hA₂] at hkey
      cases hkey
    · rw [decoratedAnalyticSignedReindexKey, if_neg hA₁,
        decoratedAnalyticSignedReindexKey, if_neg hA₂] at hkey
      exact Sum.inr.inj hkey

#print axioms decoratedAnalyticSignedReindexKey_injective


theorem disjoint_iff_primeSetProduct_coprime
    {d n : Finset ℕ}
    (hdPrime : ∀ p ∈ d, p.Prime)
    (hnPrime : ∀ p ∈ n, p.Prime) :
    Disjoint d n ↔ (primeSetProduct d).Coprime (primeSetProduct n) := by
  constructor
  · intro hdis
    unfold primeSetProduct
    apply Nat.Coprime.prod_left
    intro p hpD
    apply Nat.Coprime.prod_right
    intro r hrN
    exact (Nat.coprime_primes (hdPrime p hpD) (hnPrime r hrN)).2
      (fun hpr => (Finset.disjoint_left.mp hdis) hpD (hpr ▸ hrN))
  · intro hcop
    rw [Finset.disjoint_left]
    intro p hpD hpN
    have hpDivD : p ∣ primeSetProduct d := by
      unfold primeSetProduct
      exact Finset.dvd_prod_of_mem (fun x : ℕ => x) hpD
    have hpDivN : p ∣ primeSetProduct n := by
      unfold primeSetProduct
      exact Finset.dvd_prod_of_mem (fun x : ℕ => x) hpN
    have hpCop : p.Coprime (primeSetProduct n) :=
      Nat.Coprime.of_dvd_left hpDivD hcop
    exact ((hdPrime p hpD).coprime_iff_not_dvd.mp hpCop) hpDivN

theorem dForbidden_source_coprime
    {q H : ℕ} {d n : Finset ℕ}
    (hdActive : ∀ p ∈ d, activeHighPrime q p)
    (hn : n ∈ activeOrdinaryTwoDimensionalSet q H)
    (hdis : Disjoint d n) :
    (primeSetProduct n).Coprime
      (H * (6 * q) * primeSetProduct d) := by
  have hnPrime : ∀ p ∈ n, p.Prime := fun p hp => (hn.2 p hp).1
  have hdPrime : ∀ p ∈ d, p.Prime := fun p hp => (hdActive p hp).1
  have hnH : (primeSetProduct n).Coprime H :=
    (ordinary_primeSetProduct_coprime_height_iff hnPrime).1 hn.1
  have hn6q : (primeSetProduct n).Coprime (6 * q) :=
    activePrimeSetProduct_coprime hn.2
  have hnD : (primeSetProduct n).Coprime (primeSetProduct d) :=
    (disjoint_iff_primeSetProduct_coprime hdPrime hnPrime).1 hdis |>.symm
  exact Nat.Coprime.mul_right (Nat.Coprime.mul_right hnH hn6q) hnD

#print axioms disjoint_iff_primeSetProduct_coprime
#print axioms dForbidden_source_coprime


theorem decoratedHeightPrimeSet_active
    {q h : ℕ} {d : Finset ℕ}
    (hd : d ⊆ decoratedHeightPrimeSet q h) :
    ∀ p ∈ d, activeHighPrime q p := by
  intro p hp
  have hmem := Finset.mem_filter.mp (hd hp)
  exact ⟨Nat.prime_of_mem_primeFactors hmem.1, hmem.2.1, hmem.2.2⟩

theorem dForbidden_source_coprime_iff
    {q h H : ℕ} {d n : Finset ℕ}
    (hd : d ⊆ decoratedHeightPrimeSet q h)
    (hn : n ∈ activeOrdinaryTwoDimensionalSet q H) :
    Disjoint d n ↔
      (primeSetProduct n).Coprime
        (H * (6 * q) * primeSetProduct d) := by
  have hdActive := decoratedHeightPrimeSet_active hd
  have hdPrime : ∀ p ∈ d, p.Prime := fun p hp => (hdActive p hp).1
  have hnPrime : ∀ p ∈ n, p.Prime := fun p hp => (hn.2 p hp).1
  constructor
  · intro hdis
    exact dForbidden_source_coprime hdActive hn hdis
  · intro hcop
    have hnD : (primeSetProduct n).Coprime (primeSetProduct d) :=
      (Nat.coprime_mul_iff_right.mp hcop).2
    exact (disjoint_iff_primeSetProduct_coprime hdPrime hnPrime).2 hnD.symm

#print axioms decoratedHeightPrimeSet_active
#print axioms dForbidden_source_coprime_iff


noncomputable def sourceForbiddenBooleanMainMajorantTerm
    (q a H : ℕ) (d n : Finset ℕ) : ℝ :=
  if (primeSetProduct n).Coprime
      (H * (6 * q) * primeSetProduct d) ∧ n.Nonempty then
    (activeOrdinaryTwoDimensionalSet q H).indicator
      (fun n => fixedQShiuWeight q (primeSetProduct n) *
        |fixedProductBooleanDiscrepancy (fixedQLowWeight q a H) H n|) n
  else 0

theorem dForbiddenBooleanMainMajorantTerm_eq_source
    {q a h H : ℕ} {d n : Finset ℕ}
    (hd : d ⊆ decoratedHeightPrimeSet q h) :
    dForbiddenBooleanMainMajorantTerm q a H d n =
      sourceForbiddenBooleanMainMajorantTerm q a H d n := by
  classical
  by_cases hact : n ∈ activeOrdinaryTwoDimensionalSet q H
  · have hiff := dForbidden_source_coprime_iff hd hact
    by_cases hne : n.Nonempty
    · by_cases hdis : Disjoint d n
      · have hcop := hiff.mp hdis
        simp [dForbiddenBooleanMainMajorantTerm,
          sourceForbiddenBooleanMainMajorantTerm, hdis, hcop, hne,
          Set.indicator_of_mem hact]
      · have hncop : ¬ (primeSetProduct n).Coprime
            (H * (6 * q) * primeSetProduct d) := by
          exact fun hc => hdis (hiff.mpr hc)
        simp [dForbiddenBooleanMainMajorantTerm,
          sourceForbiddenBooleanMainMajorantTerm, hdis, hncop, hne]
    · have hn0 : n = ∅ := Finset.not_nonempty_iff_eq_empty.mp hne
      subst n
      simp [dForbiddenBooleanMainMajorantTerm,
        sourceForbiddenBooleanMainMajorantTerm]
  · simp [dForbiddenBooleanMainMajorantTerm,
      sourceForbiddenBooleanMainMajorantTerm, Set.indicator, hact]

#print axioms dForbiddenBooleanMainMajorantTerm_eq_source


noncomputable def sourceForbiddenBooleanNaturalMajorantTerm
    (q a H D m : ℕ) : ℝ :=
  if 1 < m ∧ Squarefree m ∧ m.Coprime (H * (6 * q) * D) then
    fixedQShiuWeight q m *
      |fixedProductBooleanDiscrepancy
        (fixedQLowWeight q a H) H m.primeFactors|
  else 0

theorem sourceForbiddenBooleanMainMajorantTerm_eq_natural
    {q a H : ℕ} {d n : Finset ℕ}
    (hact : n ∈ activeOrdinaryTwoDimensionalSet q H) :
    sourceForbiddenBooleanMainMajorantTerm q a H d n =
      sourceForbiddenBooleanNaturalMajorantTerm
        q a H (primeSetProduct d) (primeSetProduct n) := by
  classical
  have hnPrime : ∀ p ∈ n, p.Prime := fun p hp => (hact.2 p hp).1
  have hsq : Squarefree (primeSetProduct n) :=
    primeSetProduct_squarefree hnPrime
  have hpf : (primeSetProduct n).primeFactors = n :=
    Nat.primeFactors_prod hnPrime
  by_cases hne : n.Nonempty
  · obtain ⟨p, hp⟩ := hne
    have hne' : n.Nonempty := ⟨p, hp⟩
    have hpPrime := hnPrime p hp
    have hpDiv : p ∣ primeSetProduct n := by
      unfold primeSetProduct
      exact Finset.dvd_prod_of_mem (fun x : ℕ => x) hp
    have hprodPos : 0 < primeSetProduct n := primeSetProduct_pos hnPrime
    have hpLe : p ≤ primeSetProduct n := Nat.le_of_dvd hprodPos hpDiv
    have hgt : 1 < primeSetProduct n := hpPrime.two_le.trans hpLe
    by_cases hcop : (primeSetProduct n).Coprime
        (H * (6 * q) * primeSetProduct d)
    · simp [sourceForbiddenBooleanMainMajorantTerm,
        sourceForbiddenBooleanNaturalMajorantTerm, hact, hne', hcop,
        hsq, hgt, hpf]
    · simp [sourceForbiddenBooleanMainMajorantTerm,
        sourceForbiddenBooleanNaturalMajorantTerm, hact, hne', hcop,
        hsq, hgt, hpf]
  · have hn0 : n = ∅ := Finset.not_nonempty_iff_eq_empty.mp hne
    subst n
    simp [sourceForbiddenBooleanMainMajorantTerm,
      sourceForbiddenBooleanNaturalMajorantTerm, primeSetProduct]

#print axioms sourceForbiddenBooleanMainMajorantTerm_eq_natural



#print axioms dForbiddenReducedBooleanCoreTerm_split
#print axioms decoratedHeightForbiddenCoreTerm_union_reconstruct
#print axioms decoratedAnalyticSignedReindexKey_injective
#print axioms sourceForbiddenBooleanMainMajorantTerm_eq_natural

end PaperB.FixedQ
