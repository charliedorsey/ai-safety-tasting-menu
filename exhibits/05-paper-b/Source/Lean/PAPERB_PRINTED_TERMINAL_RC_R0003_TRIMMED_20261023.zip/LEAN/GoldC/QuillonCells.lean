import Mathlib.Data.Finset.Powerset
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Data.Real.Archimedean
import Mathlib.Tactic

/-!
# Quillon CSC3 F7.7a: cell bookkeeping (exact)

* `exists_Ioc_of_convex`: a convex predicate on `ℕ` that is bounded above and lies above `Y` is
  exactly an interval `(I₀, I₁]` with `Y ≤ I₀`. This turns every source mask (for a fixed outer
  variable) into an `Ioc`.
* `convex_of_up_down`: a conjunction of an up-closed and a down-closed predicate is convex.
* `powerset_filter_disjoint`: `{B ⊆ T : Disjoint B C} = 𝒫(T∖C)`.
* `double_sum_fixC` and `double_sum_fixB`: the ordered pair sum
  `Σ_{B,C ⊆ T} 1[B≠∅, C≠∅, B∩C=∅, Mk B C] f B C`, with either variable outside.
* `cell_split4`: the exact four-cell split by indicators.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonCells

/-! ## Convex masks are intervals -/

theorem exists_Ioc_of_convex (P : ℕ → Prop) [DecidablePred P] (N Y : ℕ)
    (hbdd : ∀ r, P r → r ≤ N) (hlow : ∀ r, P r → Y < r)
    (hconv : ∀ a b c, a ≤ b → b ≤ c → P a → P c → P b) :
    ∃ I₀ I₁ : ℕ, Y ≤ I₀ ∧ I₁ ≤ max N Y ∧ ∀ r, P r ↔ r ∈ Ioc I₀ I₁ := by
  classical
  set S := (range (N + 1)).filter P with hS
  have hmemS : ∀ r, r ∈ S ↔ P r := by
    intro r; rw [hS, mem_filter, mem_range]
    exact ⟨fun h => h.2, fun h => ⟨Nat.lt_succ_of_le (hbdd r h), h⟩⟩
  rcases S.eq_empty_or_nonempty with hE | hne
  · refine ⟨Y, Y, le_rfl, le_max_right _ _, fun r => ?_⟩
    rw [Ioc_self]
    constructor
    · intro hr; have := (hmemS r).2 hr; rw [hE] at this; exact absurd this (notMem_empty r)
    · intro h; exact absurd h (notMem_empty r)
  · set m := S.min' hne with hm
    set M := S.max' hne with hM
    have hPm : P m := (hmemS m).1 (S.min'_mem hne)
    have hPM : P M := (hmemS M).1 (S.max'_mem hne)
    have hmY : Y < m := hlow m hPm
    refine ⟨m - 1, M, by omega, (hbdd M hPM).trans (le_max_left _ _), fun r => ?_⟩
    rw [mem_Ioc]
    constructor
    · intro hr
      have hrS := (hmemS r).2 hr
      exact ⟨by have := S.min'_le r hrS; omega, S.le_max' r hrS⟩
    · rintro ⟨h1, h2⟩
      exact hconv m r M (by omega) h2 hPm hPM

lemma convex_of_up_down (U D : ℕ → Prop) (hU : ∀ a b, a ≤ b → U a → U b)
    (hD : ∀ a b, a ≤ b → D b → D a) :
    ∀ a b c, a ≤ b → b ≤ c → (U a ∧ D a) → (U c ∧ D c) → (U b ∧ D b) :=
  fun a b c hab hbc ha hc => ⟨hU a b hab ha.1, hD b c hbc hc.2⟩

/-! ## Disjoint subsets -/

lemma powerset_filter_disjoint (T C : Finset ℕ) :
    T.powerset.filter (fun B => Disjoint B C) = (T \ C).powerset := by
  ext B
  simp only [mem_filter, mem_powerset, subset_sdiff]

/-- The ordered pair sum with `C` outside. -/
theorem double_sum_fixC (T : Finset ℕ) (Mk : Finset ℕ → Finset ℕ → Prop) [∀ B C, Decidable (Mk B C)]
    (f : Finset ℕ → Finset ℕ → ℝ) :
    ∑ B ∈ T.powerset, ∑ C ∈ T.powerset,
        (if B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C ∧ Mk B C then f B C else 0) =
      ∑ C ∈ T.powerset.filter (fun C => C ≠ ∅), ∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
        (if Mk B C then f B C else 0) := by
  classical
  rw [sum_comm, sum_filter]
  refine sum_congr rfl fun C _ => ?_
  split_ifs with hC
  · rw [← powerset_filter_disjoint, filter_filter, sum_filter]
    refine sum_congr rfl fun B _ => ?_
    by_cases hB : B ≠ ∅ <;> by_cases hd : Disjoint B C <;> by_cases hm : Mk B C <;> simp [hB, hd, hm, hC]
  · refine sum_eq_zero fun B _ => ?_
    rw [if_neg]; tauto

/-- The ordered pair sum with `B` outside. -/
theorem double_sum_fixB (T : Finset ℕ) (Mk : Finset ℕ → Finset ℕ → Prop) [∀ B C, Decidable (Mk B C)]
    (f : Finset ℕ → Finset ℕ → ℝ) :
    ∑ B ∈ T.powerset, ∑ C ∈ T.powerset,
        (if B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C ∧ Mk B C then f B C else 0) =
      ∑ B ∈ T.powerset.filter (fun B => B ≠ ∅), ∑ C ∈ (T \ B).powerset.filter (fun C => C ≠ ∅),
        (if Mk B C then f B C else 0) := by
  classical
  rw [sum_filter]
  refine sum_congr rfl fun B _ => ?_
  split_ifs with hB
  · rw [← powerset_filter_disjoint, filter_filter, sum_filter]
    refine sum_congr rfl fun C _ => ?_
    have hdc : Disjoint C B ↔ Disjoint B C := disjoint_comm
    by_cases hC : C ≠ ∅ <;> by_cases hd : Disjoint B C <;> by_cases hm : Mk B C <;>
      simp [hB, hd, hm, hC, hdc]
  · refine sum_eq_zero fun C _ => ?_
    rw [if_neg]; tauto

/-- The exact four-cell split by indicators. -/
lemma cell_split4 {ι : Type*} (S : Finset ι) (A W Bg Sm : ι → Prop) [DecidablePred A]
    [DecidablePred W] [DecidablePred Bg] [DecidablePred Sm] (f : ι → ℝ) :
    ∑ i ∈ S, (if A i then f i else 0) =
      ∑ i ∈ S, (if A i ∧ W i then f i else 0) +
      ∑ i ∈ S, (if A i ∧ ¬ W i ∧ Bg i then f i else 0) +
      ∑ i ∈ S, (if A i ∧ ¬ W i ∧ ¬ Bg i ∧ Sm i then f i else 0) +
      ∑ i ∈ S, (if A i ∧ ¬ W i ∧ ¬ Bg i ∧ ¬ Sm i then f i else 0) := by
  rw [← sum_add_distrib, ← sum_add_distrib, ← sum_add_distrib]
  refine sum_congr rfl fun i _ => ?_
  by_cases ha : A i <;> by_cases hw : W i <;> by_cases hb : Bg i <;> by_cases hs : Sm i <;>
    simp [ha, hw, hb, hs]

end GoldC.QuillonCells

#print axioms GoldC.QuillonCells.exists_Ioc_of_convex
#print axioms GoldC.QuillonCells.double_sum_fixC
#print axioms GoldC.QuillonCells.double_sum_fixB
#print axioms GoldC.QuillonCells.cell_split4
