import PaperB.FixedQ.SignedForbiddenEndpointPetermann
import PaperB.FixedQ.PureHeightReflection
import PaperB.ExactAccounting.H1FloorFamilyBridge

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def ordinaryEndpointDensityCorrection
    (q a H : ℕ) (n : Finset ℕ) : ℝ :=
  finiteOmegaWeightReal n *
    ((rowWeightMass (fixedQLowWeight q a H) H -
      (admissibleInteriorCount q a H : ℝ)) /
      (primeSetProduct n : ℝ))

theorem finiteOmega_mul_full_partition_eq_pureLeft_sub_density
    {q a H : ℕ} {n : Finset ℕ}
    (hact : n ∈ activeOrdinaryTwoDimensionalSet q H) :
    finiteOmegaWeightReal n *
        fixedProductPartitionDiscrepancy
          (fixedQLowWeight q a H) H n n =
      pureLeftPairTerm q a H n -
        ordinaryEndpointDensityCorrection q a H n := by
  have hOrd := hact.1
  have hA := hact.2
  have hH := ordinaryTwoDimensionalSet_iff.mp hOrd
  have hcoef :=
    pairCoefficient_eq_finiteOmega_of_ordinary
      (q := q) (h := H) (e := n) (e1 := n)
      (Finset.Subset.rfl) hA hH
  have hdelta :=
    pairDelta_eq_rowDiscrepancy_add_densityDefect
      (q := q) (a := a) (h := H)
      (e := n) (e1 := n)
      (Finset.Subset.rfl) hA hH
  rw [fixedProductPartitionDiscrepancy_full_left]
  unfold pureLeftPairTerm ordinaryEndpointDensityCorrection
  rw [hcoef, hdelta]
  simp [pairLeftModulus, pairRightModulus, primeSetProduct]
  ring

theorem dForbiddenBooleanLeftEndpointTerm_eq_masked_pureLeft_sub_density
    {q a H : ℕ} {d n : Finset ℕ}
    (hact : n ∈ activeOrdinaryTwoDimensionalSet q H) :
    dForbiddenBooleanLeftEndpointTerm q a H d n =
      if Disjoint d n then
        pureLeftPairTerm q a H n -
          ordinaryEndpointDensityCorrection q a H n
      else 0 := by
  classical
  by_cases hdis : Disjoint d n
  · by_cases hne : n.Nonempty
    · rw [dForbiddenBooleanLeftEndpointTerm, if_pos ⟨hdis, hne⟩]
      rw [Set.indicator_of_mem hact]
      rw [if_pos hdis]
      exact finiteOmega_mul_full_partition_eq_pureLeft_sub_density hact
    · have hn0 : n = ∅ := Finset.not_nonempty_iff_eq_empty.mp hne
      subst n
      have hzero :
          pureLeftPairTerm q a H ∅ -
              ordinaryEndpointDensityCorrection q a H ∅ = 0 := by
        have hmain :=
          finiteOmega_mul_full_partition_eq_pureLeft_sub_density
            (q := q) (a := a) (H := H) (n := ∅) hact
        rw [fixedProductPartitionDiscrepancy_full_left] at hmain
        have hp0 : primeSetProduct (∅ : Finset ℕ) = 1 := by
          simp [primeSetProduct]
        rw [hp0, rowDiscrepancy_one_one_zero] at hmain
        simpa using hmain.symm
      rw [dForbiddenBooleanLeftEndpointTerm]
      simp [hdis, hzero]
  · simp [dForbiddenBooleanLeftEndpointTerm, hdis]

#print axioms finiteOmega_mul_full_partition_eq_pureLeft_sub_density
#print axioms dForbiddenBooleanLeftEndpointTerm_eq_masked_pureLeft_sub_density

end PaperB.FixedQ
