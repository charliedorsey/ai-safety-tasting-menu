import GoldC.QuillonRMode
import GoldC.QuillonCot
import GoldC.QuillonOmega

/-!
# Quillon CSC3 F7.5l: one R piece (fixed `r`, Cauchy over `u`, Ramaré primes `v`)

For a mode with amplitude `ampC(j, v·L·u)`, smooth phase `e(Y/(vu))` and class phase `G(v, u mod Q)`:

    ‖Σ_u b_u Σ_v a_v 1[vu∈(S₀,S₁]] ampC(j,vLu) e(Y/(vu)) G(v,u%Q)‖² ≤ 2A⁴·Ψ_R,

where `Ψ_R = 1/V₁ + 3C·e^{−c log³Nm/log²(|Y|/Q)} + 9C·U₀V₁(1+log 2V₁)/|Y|`. The constants `(c, C)` are those of
`class_amp_bound` (Hunt B).

This file proves the per-class off-diagonal step `R_offdiag_class`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonRPiece

open GoldC.QuillonR GoldC.QuillonCot

lemma R_offdiag_class (c C : ℝ) (hc : 0 < c) (hC : 0 ≤ C)
    (hcab : ∀ (Q ρ N M : ℕ) (Y : ℝ) (A : ℕ → ℂ), 1 ≤ Q → ρ < Q → 1 ≤ N → N ≤ M → M ≤ 2 * N →
        2 * (Q : ℝ) ≤ |Y| →
        ‖∑ t ∈ Ioc N M, A t * eR (Y / ((ρ : ℝ) + Q * t))‖ ≤
          (‖A M‖ + ∑ n ∈ Ico (N + 1) M, ‖A (n + 1) - A n‖) *
            (C * ((N : ℝ) * Real.exp (-(c * Real.log (N : ℝ) ^ 3 / Real.log (|Y| / Q) ^ 2)) +
              (N : ℝ) ^ 2 / (|Y| / Q))))
    (Q ρ a b j v v' L : ℕ) (Y : ℝ) (hQ : 1 ≤ Q) (hρ : ρ < Q) (ha : 4 * Q ≤ a)
    (hab : b + 2 * Q ≤ 2 * a) (hY : 2 * (Q : ℝ) ≤ |Y|) (hj : 1 ≤ j) (hL : 1 ≤ L)
    (hv : 1 ≤ v) (hv' : 1 ≤ v') :
    ‖∑ u ∈ (Ioc a b).filter (fun u => u % Q = ρ),
        ((ampC j (v * (L * u)) * ampC j (v' * (L * u)) : ℝ) : ℂ) * eR (Y / u)‖ ≤
      2 * (C * ((((a - ρ) / Q : ℕ) : ℝ) * Real.exp (-(c * Real.log (((a - ρ) / Q : ℕ) : ℝ) ^ 3 /
        Real.log (|Y| / Q) ^ 2)) + (((a - ρ) / Q : ℕ) : ℝ) ^ 2 / (|Y| / Q))) := by
  set N := (a - ρ) / Q with hN
  set M := (b - ρ) / Q with hM
  have hQR : (0 : ℝ) < Q := by exact_mod_cast hQ
  have hYQ : 0 < |Y| / Q := by
    have : (0 : ℝ) < |Y| := by linarith
    positivity
  have hRHS0 : 0 ≤ 2 * (C * ((N : ℝ) * Real.exp (-(c * Real.log (N : ℝ) ^ 3 /
        Real.log (|Y| / Q) ^ 2)) + (N : ℝ) ^ 2 / (|Y| / Q))) := by positivity
  rw [classFilter_eq_image Q ρ a b hQ hρ (by omega)]
  have hinj : Set.InjOn (fun t => ρ + Q * t) (Ioc N M : Set ℕ) := by
    intro x _ y _ h
    exact Nat.eq_of_mul_eq_mul_left (show 0 < Q by omega) (Nat.add_left_cancel h)
  rw [sum_image hinj]
  have hN1 : 1 ≤ N := by rw [hN, Nat.le_div_iff_mul_le (by omega)]; omega
  have hM2 : M ≤ 2 * N := by
    have h1 : Q * N + (a - ρ) % Q = a - ρ := Nat.div_add_mod (a - ρ) Q
    have h2 := Nat.mod_lt (a - ρ) (show 0 < Q by omega)
    have h3 : M < 2 * N + 1 := by
      rw [hM, Nat.div_lt_iff_lt_mul (by omega), show (2 * N + 1) * Q = 2 * (Q * N) + Q by ring]
      omega
    omega
  rcases Nat.lt_or_ge N M with hNM | hNM
  · set A : ℕ → ℂ := fun t =>
      ((ampC j (v * (L * (ρ + Q * t))) * ampC j (v' * (L * (ρ + Q * t))) : ℝ) : ℂ) with hA
    have hcast : ∀ t ∈ Ioc N M, ((ampC j (v * (L * (ρ + Q * t))) * ampC j (v' * (L * (ρ + Q * t))) : ℝ) : ℂ) *
        eR (Y / ((ρ + Q * t : ℕ) : ℝ)) = A t * eR (Y / ((ρ : ℝ) + Q * t)) := by
      intro t _; simp only [hA]; push_cast; rfl
    rw [sum_congr rfl hcast]
    refine (hcab Q ρ N M Y A hQ hρ hN1 hNM.le hM2 hY).trans ?_
    have hab2 := ampC_abel_factor j v v' hj (fun t => L * (ρ + Q * t)) N M (by omega)
      (fun t _ _ => Nat.mul_le_mul_left L (by nlinarith))
      (fun t h1 _ => by
        have : 1 ≤ L * (ρ + Q * t) := by
          have : 1 ≤ ρ + Q * t := by nlinarith
          nlinarith
        exact ⟨by nlinarith, by nlinarith⟩)
    have hpos : 0 ≤ C * ((N : ℝ) * Real.exp (-(c * Real.log (N : ℝ) ^ 3 /
        Real.log (|Y| / Q) ^ 2)) + (N : ℝ) ^ 2 / (|Y| / Q)) := by positivity
    exact mul_le_mul_of_nonneg_right hab2 hpos
  · rw [Ioc_eq_empty (by omega), sum_empty, norm_zero]; exact hRHS0

lemma sum_inv_gap_left (v V : ℕ) :
    ∑ w ∈ Ioc V (v - 1), (1 / ((v : ℝ) - w)) ≤ 1 + Real.log (v - V : ℕ) := by
  have himg : Ioc V (v - 1) = (Ioc 0 (v - 1 - V)).image (fun d => v - d) := by
    ext w
    simp only [mem_Ioc, mem_image]
    constructor
    · rintro ⟨h1, h2⟩; exact ⟨v - w, ⟨by omega, by omega⟩, by omega⟩
    · rintro ⟨d, ⟨h1, h2⟩, rfl⟩; exact ⟨by omega, by omega⟩
  rw [himg, sum_image (fun d₁ h₁ d₂ h₂ h => by
    have := mem_Ioc.1 h₁; have := mem_Ioc.1 h₂; omega)]
  calc ∑ d ∈ Ioc 0 (v - 1 - V), (1 / ((v : ℝ) - ((v - d : ℕ) : ℝ)))
      = ∑ d ∈ Ioc 0 (v - 1 - V), (1 / (d : ℝ)) := by
        refine sum_congr rfl fun d hd => ?_
        have := (mem_Ioc.1 hd)
        rw [Nat.cast_sub (by omega)]; ring_nf
    _ ≤ 1 + Real.log (v - 1 - V : ℕ) := GoldC.QuillonVW.harm_Ioc_le _
    _ ≤ 1 + Real.log (v - V : ℕ) := by
        have : Real.log (v - 1 - V : ℕ) ≤ Real.log (v - V : ℕ) := by
          rcases Nat.eq_zero_or_pos (v - 1 - V) with h | h
          · rw [h, Nat.cast_zero, Real.log_zero]; exact Real.log_natCast_nonneg _
          · exact Real.log_le_log (by exact_mod_cast h) (by exact_mod_cast (show v - 1 - V ≤ v - V by omega))
        linarith

lemma sum_inv_gap_right (v W : ℕ) :
    ∑ w ∈ Ioc v W, (1 / ((w : ℝ) - v)) ≤ 1 + Real.log (W - v : ℕ) := by
  have himg : Ioc v W = (Ioc 0 (W - v)).image (fun d => v + d) := by
    ext w
    simp only [mem_Ioc, mem_image]
    constructor
    · rintro ⟨h1, h2⟩; exact ⟨w - v, ⟨by omega, by omega⟩, by omega⟩
    · rintro ⟨d, ⟨h1, h2⟩, rfl⟩; exact ⟨by omega, by omega⟩
  rw [himg, sum_image (fun d₁ _ d₂ _ h => by omega)]
  calc ∑ d ∈ Ioc 0 (W - v), (1 / (((v + d : ℕ) : ℝ) - v))
      = ∑ d ∈ Ioc 0 (W - v), (1 / (d : ℝ)) := by
        refine sum_congr rfl fun d _ => ?_
        push_cast; ring_nf
    _ ≤ _ := GoldC.QuillonVW.harm_Ioc_le _

/-- `Σ_{v'∈S, v'≠v} 1/|v−v'| ≤ 2(1+log V)` for `S ⊆ (V, 2V]`. -/
lemma sum_inv_dist (S : Finset ℕ) (V v : ℕ) (hS : S ⊆ Ioc V (2 * V)) (hv : v ∈ S) :
    ∑ w ∈ S.erase v, (1 / |(v : ℝ) - w|) ≤ 2 * (1 + Real.log V) := by
  classical
  have hvV := mem_Ioc.1 (hS hv)
  have hsub : S.erase v ⊆ Ioc V (v - 1) ∪ Ioc v (2 * V) := by
    intro w hw
    have := mem_Ioc.1 (hS (mem_of_mem_erase hw))
    have hne := ne_of_mem_erase hw
    simp only [mem_union, mem_Ioc]; omega
  have hlog1 : Real.log (v - V : ℕ) ≤ Real.log V := by
    rcases Nat.eq_zero_or_pos (v - V) with h | h
    · rw [h, Nat.cast_zero, Real.log_zero]; exact Real.log_natCast_nonneg _
    · exact Real.log_le_log (by exact_mod_cast h) (by exact_mod_cast (show v - V ≤ V by omega))
  have hlog2 : Real.log (2 * V - v : ℕ) ≤ Real.log V := by
    rcases Nat.eq_zero_or_pos (2 * V - v) with h | h
    · rw [h, Nat.cast_zero, Real.log_zero]; exact Real.log_natCast_nonneg _
    · exact Real.log_le_log (by exact_mod_cast h) (by exact_mod_cast (show 2 * V - v ≤ V by omega))
  calc ∑ w ∈ S.erase v, (1 / |(v : ℝ) - w|)
      ≤ ∑ w ∈ Ioc V (v - 1) ∪ Ioc v (2 * V), (1 / |(v : ℝ) - w|) :=
        sum_le_sum_of_subset_of_nonneg hsub fun _ _ _ => by positivity
    _ = ∑ w ∈ Ioc V (v - 1), (1 / |(v : ℝ) - w|) + ∑ w ∈ Ioc v (2 * V), (1 / |(v : ℝ) - w|) := by
        rw [sum_union (by rw [disjoint_left]; intro w h1 h2; simp only [mem_Ioc] at h1 h2; omega)]
    _ = ∑ w ∈ Ioc V (v - 1), (1 / ((v : ℝ) - w)) + ∑ w ∈ Ioc v (2 * V), (1 / ((w : ℝ) - v)) := by
        congr 1
        · refine sum_congr rfl fun w hw => ?_
          have := mem_Ioc.1 hw
          have : (w : ℝ) < v := by exact_mod_cast (show w < v by omega)
          rw [abs_of_pos (by linarith)]
        · refine sum_congr rfl fun w hw => ?_
          have := mem_Ioc.1 hw
          have : (v : ℝ) < w := by exact_mod_cast this.1
          rw [abs_of_neg (by linarith)]; ring_nf
    _ ≤ (1 + Real.log (v - V : ℕ)) + (1 + Real.log (2 * V - v : ℕ)) :=
        add_le_add (sum_inv_gap_left v V) (sum_inv_gap_right v (2 * V))
    _ ≤ 2 * (1 + Real.log V) := by linarith

lemma mem_Ioc_div_iff' (I₀ I₁ p n : ℕ) (hp : 1 ≤ p) :
    n ∈ Ioc (I₀ / p) (I₁ / p) ↔ p * n ∈ Ioc I₀ I₁ := by
  simp only [mem_Ioc]
  constructor
  · rintro ⟨h1, h2⟩
    refine ⟨?_, ?_⟩
    · rw [Nat.div_lt_iff_lt_mul (by omega)] at h1; linarith [mul_comm n p]
    · rw [Nat.le_div_iff_mul_le (by omega)] at h2; linarith [mul_comm n p]
  · rintro ⟨h1, h2⟩
    refine ⟨?_, ?_⟩
    · rw [Nat.div_lt_iff_lt_mul (by omega)]; linarith [mul_comm n p]
    · rw [Nat.le_div_iff_mul_le (by omega)]; linarith [mul_comm n p]

/-- The coupled amplitude `c(v,u) = 1[vu ∈ (S₀,S₁]]·ampC(j, v·L·u)`. -/
noncomputable def ampI (S₀ S₁ j L v u : ℕ) : ℂ :=
  if v * u ∈ Ioc S₀ S₁ then ((ampC j (v * (L * u)) : ℝ) : ℂ) else 0

lemma norm_ampI_le (S₀ S₁ j L v u : ℕ) (hj : 1 ≤ j) (hvLu : 1 ≤ v * (L * u)) :
    ‖ampI S₀ S₁ j L v u‖ ≤ 1 := by
  unfold ampI; split_ifs
  · rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (ampC_bounds j _ hj hvLu).1]
    exact (ampC_bounds j _ hj hvLu).2
  · simp

/-- The off-diagonal `(v ≠ v')` class total. -/
lemma R_pair_off (c C : ℝ) (hc : 0 < c) (hC : 0 ≤ C)
    (hcab : ∀ (Q ρ N M : ℕ) (Y : ℝ) (A : ℕ → ℂ), 1 ≤ Q → ρ < Q → 1 ≤ N → N ≤ M → M ≤ 2 * N →
        2 * (Q : ℝ) ≤ |Y| →
        ‖∑ t ∈ Ioc N M, A t * eR (Y / ((ρ : ℝ) + Q * t))‖ ≤
          (‖A M‖ + ∑ n ∈ Ico (N + 1) M, ‖A (n + 1) - A n‖) *
            (C * ((N : ℝ) * Real.exp (-(c * Real.log (N : ℝ) ^ 3 / Real.log (|Y| / Q) ^ 2)) +
              (N : ℝ) ^ 2 / (|Y| / Q))))
    (Q U₀ U₁ V₁ S₀ S₁ j L v v' : ℕ) (Y : ℝ) (hQ : 1 ≤ Q) (hU₀ : 4 * Q ≤ U₀)
    (hU₁ : U₁ + 2 * Q ≤ 2 * U₀) (hV₁ : 1 ≤ V₁) (hv : v ∈ Ioc V₁ (2 * V₁))
    (hv' : v' ∈ Ioc V₁ (2 * V₁)) (hvv' : v ≠ v') (hY : 8 * (Q : ℝ) * V₁ ^ 2 ≤ |Y|)
    (hj : 1 ≤ j) (hL : 1 ≤ L) :
    ∑ ρ ∈ range Q, ‖∑ u ∈ (Ioc U₀ U₁).filter (fun u => u % Q = ρ),
        (ampI S₀ S₁ j L v u * (starRingEnd ℂ) (ampI S₀ S₁ j L v' u)) *
          eR (Y / ((v : ℝ) * u) - Y / ((v' : ℝ) * u))‖ ≤
      4 * C * U₀ * Real.exp (-(c * Real.log (((U₀ - Q) / Q : ℕ) : ℝ) ^ 3 / Real.log (|Y| / Q) ^ 2)) +
        32 * C * U₀ ^ 2 * V₁ ^ 2 / (|Y| * |(v : ℝ) - v'|) := by
  classical
  have hvR := mem_Ioc.1 hv; have hv'R := mem_Ioc.1 hv'
  have hQR : (0 : ℝ) < Q := by exact_mod_cast hQ
  have hV₁R : (1 : ℝ) ≤ V₁ := by exact_mod_cast hV₁
  have hvpos : (0 : ℝ) < v := by exact_mod_cast (show 0 < v by omega)
  have hv'pos : (0 : ℝ) < v' := by exact_mod_cast (show 0 < v' by omega)
  have hvle : (v : ℝ) ≤ 2 * V₁ := by exact_mod_cast hvR.2
  have hv'le : (v' : ℝ) ≤ 2 * V₁ := by exact_mod_cast hv'R.2
  have hdist : (1 : ℝ) ≤ |(v : ℝ) - v'| := by
    rcases lt_or_gt_of_ne hvv' with h | h
    · have : (v : ℝ) + 1 ≤ v' := by exact_mod_cast h
      rw [abs_of_neg (by linarith)]; linarith
    · have : (v' : ℝ) + 1 ≤ v := by exact_mod_cast h
      rw [abs_of_pos (by linarith)]; linarith
  set Y' : ℝ := Y / v - Y / v' with hY'
  have hY'eq : |Y'| = |Y| * |(v : ℝ) - v'| / ((v : ℝ) * v') := by
    rw [hY', show Y / (v : ℝ) - Y / v' = Y * ((v' : ℝ) - v) / ((v : ℝ) * v') by field_simp,
      abs_div, abs_mul, abs_of_pos (by positivity : (0 : ℝ) < (v : ℝ) * v'), abs_sub_comm]
  have hvv'le : (v : ℝ) * v' ≤ 4 * V₁ ^ 2 := by nlinarith
  have hYpos : 0 < |Y| := by have : (0 : ℝ) < 8 * Q * V₁ ^ 2 := by positivity
                             linarith
  have hY'lb : |Y| / (4 * V₁ ^ 2) ≤ |Y'| := by
    rw [hY'eq, div_le_div_iff₀ (by positivity) (by positivity)]
    calc |Y| * ((v : ℝ) * v') ≤ |Y| * (4 * V₁ ^ 2) := mul_le_mul_of_nonneg_left hvv'le (abs_nonneg _)
      _ ≤ |Y| * |(v : ℝ) - v'| * (4 * V₁ ^ 2) := by
          have h4 : (0 : ℝ) ≤ 4 * V₁ ^ 2 := by positivity
          have := mul_le_mul_of_nonneg_left hdist (abs_nonneg Y)
          nlinarith
  have hY'2Q : 2 * (Q : ℝ) ≤ |Y'| := by
    refine le_trans ?_ hY'lb
    rw [le_div_iff₀ (by positivity)]
    have : 2 * (Q : ℝ) * (4 * V₁ ^ 2) = 8 * Q * V₁ ^ 2 := by ring
    linarith
  have hY'ub : |Y'| ≤ |Y| := by
    rw [hY'eq, div_le_iff₀ (by positivity)]
    have h1 : (1 : ℝ) ≤ v := by linarith [hV₁R, (by exact_mod_cast hvR.1 : (V₁ : ℝ) < v)]
    have h1' : (1 : ℝ) ≤ v' := by linarith [hV₁R, (by exact_mod_cast hv'R.1 : (V₁ : ℝ) < v')]
    have : |(v : ℝ) - v'| ≤ (v : ℝ) * v' := by
      have hA : (v : ℝ) ≤ v * v' := le_mul_of_one_le_right hvpos.le h1'
      have hB : (v' : ℝ) ≤ v * v' := le_mul_of_one_le_left hv'pos.le h1
      rw [abs_le]; constructor <;> linarith
    nlinarith
  -- per class
  set Nm := (U₀ - Q) / Q with hNm
  have hNm3 : 3 ≤ Nm := by rw [hNm, Nat.le_div_iff_mul_le (by omega)]; omega
  set em := Real.exp (-(c * Real.log (Nm : ℝ) ^ 3 / Real.log (|Y| / Q) ^ 2)) with hem
  have hlogYQ' : 0 < Real.log (|Y'| / Q) := Real.log_pos (by rw [lt_div_iff₀ hQR]; linarith)
  have hlogle : Real.log (|Y'| / Q) ≤ Real.log (|Y| / Q) :=
    Real.log_le_log (div_pos (by linarith) hQR) (div_le_div_of_nonneg_right hY'ub hQR.le)
  have hper : ∀ ρ ∈ range Q, ‖∑ u ∈ (Ioc U₀ U₁).filter (fun u => u % Q = ρ),
      (ampI S₀ S₁ j L v u * (starRingEnd ℂ) (ampI S₀ S₁ j L v' u)) *
        eR (Y / ((v : ℝ) * u) - Y / ((v' : ℝ) * u))‖ ≤
      2 * C * (2 * U₀ / Q * em + 16 * U₀ ^ 2 * V₁ ^ 2 / (Q * |Y| * |(v : ℝ) - v'|)) := by
    intro ρ hρ
    have hρQ := mem_range.1 hρ
    set a := max U₀ (max (S₀ / v) (S₀ / v')) with ha
    set b := min U₁ (min (S₁ / v) (S₁ / v')) with hb
    have hset : ((Ioc U₀ U₁).filter (fun u => u % Q = ρ)).filter
        (fun u => v * u ∈ Ioc S₀ S₁ ∧ v' * u ∈ Ioc S₀ S₁) = (Ioc a b).filter (fun u => u % Q = ρ) := by
      ext u
      simp only [mem_filter]
      rw [← mem_Ioc_div_iff' S₀ S₁ v u (by omega),
        ← mem_Ioc_div_iff' S₀ S₁ v' u (by omega)]
      simp only [mem_Ioc, ha, hb, max_lt_iff, le_min_iff]
      tauto
    have hrw : ∑ u ∈ (Ioc U₀ U₁).filter (fun u => u % Q = ρ),
        (ampI S₀ S₁ j L v u * (starRingEnd ℂ) (ampI S₀ S₁ j L v' u)) *
          eR (Y / ((v : ℝ) * u) - Y / ((v' : ℝ) * u)) =
        ∑ u ∈ (Ioc a b).filter (fun u => u % Q = ρ),
          ((ampC j (v * (L * u)) * ampC j (v' * (L * u)) : ℝ) : ℂ) * eR (Y' / u) := by
      rw [← hset, sum_filter (p := fun u => v * u ∈ Ioc S₀ S₁ ∧ v' * u ∈ Ioc S₀ S₁)]
      refine sum_congr rfl fun u hu => ?_
      have hu0 : (0 : ℝ) < u := by
        have := (mem_Ioc.1 (mem_filter.1 hu).1).1; exact_mod_cast (show 0 < u by omega)
      have hphase : Y / ((v : ℝ) * u) - Y / ((v' : ℝ) * u) = Y' / u := by
        rw [hY']; field_simp
      unfold ampI
      by_cases h1 : v * u ∈ Ioc S₀ S₁ <;> by_cases h2 : v' * u ∈ Ioc S₀ S₁ <;>
        simp [h1, h2, hphase, Complex.conj_ofReal]
    rw [hrw]
    by_cases hab : a ≤ b
    · have hoff := R_offdiag_class c C hc hC hcab Q ρ a b j v v' L Y' hQ hρQ
        (le_trans hU₀ (le_max_left _ _)) (by
          have : b ≤ U₁ := min_le_left _ _
          have : U₀ ≤ a := le_max_left _ _
          omega) hY'2Q hj hL (by omega) (by omega)
      refine hoff.trans ?_
      set N := (a - ρ) / Q with hN
      have hNNm : Nm ≤ N := Nat.div_le_div_right (by have := le_max_left U₀ (max (S₀ / v) (S₀ / v')); omega)
      have hNup : (N : ℝ) ≤ 2 * U₀ / Q := by
        rw [le_div_iff₀ hQR]
        have h1 : N * Q ≤ a - ρ := Nat.div_mul_le_self _ _
        have h2 : a ≤ U₁ := le_trans hab (min_le_left _ _)
        have : (N : ℝ) * Q ≤ (a : ℝ) := by
          have : N * Q ≤ a := le_trans h1 (Nat.sub_le _ _)
          exact_mod_cast this
        have : (a : ℝ) ≤ 2 * U₀ := by exact_mod_cast (show a ≤ 2 * U₀ by omega)
        linarith
      have hN1 : (1 : ℝ) ≤ N := by exact_mod_cast (show 1 ≤ N by omega)
      have hlogN : Real.log (Nm : ℝ) ≤ Real.log N :=
        Real.log_le_log (by exact_mod_cast (show 0 < Nm by omega)) (by exact_mod_cast hNNm)
      have hlogNm : 0 ≤ Real.log (Nm : ℝ) := Real.log_natCast_nonneg _
      have hexp : Real.exp (-(c * Real.log (N : ℝ) ^ 3 / Real.log (|Y'| / Q) ^ 2)) ≤ em := by
        rw [hem]; apply Real.exp_le_exp.2; rw [neg_le_neg_iff]
        have h3 : Real.log (Nm : ℝ) ^ 3 ≤ Real.log N ^ 3 := pow_le_pow_left₀ hlogNm hlogN 3
        have h4 : Real.log (|Y'| / Q) ^ 2 ≤ Real.log (|Y| / Q) ^ 2 :=
          pow_le_pow_left₀ hlogYQ'.le hlogle 2
        calc c * Real.log (Nm : ℝ) ^ 3 / Real.log (|Y| / Q) ^ 2
            ≤ c * Real.log (N : ℝ) ^ 3 / Real.log (|Y| / Q) ^ 2 := by gcongr
          _ ≤ c * Real.log (N : ℝ) ^ 3 / Real.log (|Y'| / Q) ^ 2 := by
              apply div_le_div_of_nonneg_left (by positivity) (by positivity) h4
      have hsq : (N : ℝ) ^ 2 / (|Y'| / Q) ≤ 16 * U₀ ^ 2 * V₁ ^ 2 / (Q * |Y| * |(v : ℝ) - v'|) := by
        have hY'pos : 0 < |Y'| := by linarith
        have hden : 0 < |Y| * |(v : ℝ) - v'| / (4 * V₁ ^ 2) := by positivity
        have hY'lb2 : |Y| * |(v : ℝ) - v'| / (4 * V₁ ^ 2) ≤ |Y'| := by
          rw [hY'eq]
          exact div_le_div_of_nonneg_left (by positivity) (by positivity) hvv'le
        calc (N : ℝ) ^ 2 / (|Y'| / Q) = (N : ℝ) ^ 2 * Q / |Y'| := by field_simp
          _ ≤ (N : ℝ) ^ 2 * Q / (|Y| * |(v : ℝ) - v'| / (4 * V₁ ^ 2)) :=
              div_le_div_of_nonneg_left (by positivity) hden hY'lb2
          _ ≤ (2 * U₀ / Q) ^ 2 * Q / (|Y| * |(v : ℝ) - v'| / (4 * V₁ ^ 2)) := by
              gcongr
          _ = 16 * U₀ ^ 2 * V₁ ^ 2 / (Q * |Y| * |(v : ℝ) - v'|) := by
              field_simp; ring
      have : 0 ≤ C := hC
      calc 2 * (C * ((N : ℝ) * Real.exp (-(c * Real.log (N : ℝ) ^ 3 / Real.log (|Y'| / Q) ^ 2)) +
            (N : ℝ) ^ 2 / (|Y'| / Q)))
          ≤ 2 * (C * (2 * U₀ / Q * em + 16 * U₀ ^ 2 * V₁ ^ 2 / (Q * |Y| * |(v : ℝ) - v'|))) := by
            gcongr
        _ = _ := by ring
    · rw [Ioc_eq_empty (by omega), filter_empty, sum_empty, norm_zero]
      positivity
  calc _ ≤ ∑ _ρ ∈ range Q, 2 * C * (2 * U₀ / Q * em + 16 * U₀ ^ 2 * V₁ ^ 2 / (Q * |Y| * |(v : ℝ) - v'|)) :=
        sum_le_sum hper
    _ = _ := by rw [sum_const, card_range, nsmul_eq_mul]; field_simp; ring

/-- **One R piece.** -/
theorem R_piece (c C : ℝ) (hc : 0 < c) (hC : 0 ≤ C)
    (hcab : ∀ (Q ρ N M : ℕ) (Y : ℝ) (A : ℕ → ℂ), 1 ≤ Q → ρ < Q → 1 ≤ N → N ≤ M → M ≤ 2 * N →
        2 * (Q : ℝ) ≤ |Y| →
        ‖∑ t ∈ Ioc N M, A t * eR (Y / ((ρ : ℝ) + Q * t))‖ ≤
          (‖A M‖ + ∑ n ∈ Ico (N + 1) M, ‖A (n + 1) - A n‖) *
            (C * ((N : ℝ) * Real.exp (-(c * Real.log (N : ℝ) ^ 3 / Real.log (|Y| / Q) ^ 2)) +
              (N : ℝ) ^ 2 / (|Y| / Q))))
    (Q : ℕ) (hQ : 1 ≤ Q) (𝒰 𝒱 : Finset ℕ) (U₀ U₁ V₁ S₀ S₁ j L : ℕ) (Y : ℝ)
    (hU₀ : 4 * Q ≤ U₀) (hU₁ : U₁ + 2 * Q ≤ 2 * U₀) (h𝒰 : 𝒰 ⊆ Ioc U₀ U₁)
    (h𝒱 : 𝒱 ⊆ Ioc V₁ (2 * V₁)) (hV₁ : 1 ≤ V₁) (hY : 8 * (Q : ℝ) * V₁ ^ 2 ≤ |Y|)
    (hj : 1 ≤ j) (hL : 1 ≤ L) (a b : ℕ → ℂ) (A : ℝ) (hA : 0 ≤ A)
    (ha : ∀ v ∈ 𝒱, ‖a v‖ ≤ A / v) (hb : ∀ u ∈ 𝒰, ‖b u‖ ≤ A / u)
    (G : ℕ → ℕ → ℂ) (hG : ∀ v ρ, ‖G v ρ‖ ≤ 1) :
    ‖∑ u ∈ 𝒰, b u * ∑ v ∈ 𝒱, a v *
        (ampI S₀ S₁ j L v u * (eR (Y / ((v : ℝ) * u)) * G v (u % Q)))‖ ^ 2 ≤
      2 * A ^ 4 * (2 / V₁ + 4 * C * Real.exp (-(c * Real.log (((U₀ - Q) / Q : ℕ) : ℝ) ^ 3 /
        Real.log (|Y| / Q) ^ 2)) + 64 * C * U₀ * V₁ * (1 + Real.log V₁) / |Y|) := by
  classical
  set em := Real.exp (-(c * Real.log (((U₀ - Q) / Q : ℕ) : ℝ) ^ 3 / Real.log (|Y| / Q) ^ 2)) with hem
  have hcs := cauchy_class_split_amp hQ 𝒰 (Ioc U₀ U₁) 𝒱 h𝒰 a b (ampI S₀ S₁ j L)
    (fun v u => Y / ((v : ℝ) * u)) G hG
  refine hcs.trans ?_
  have hU₀R : (0 : ℝ) < U₀ := by exact_mod_cast (show 0 < U₀ by omega)
  have hV₁R : (1 : ℝ) ≤ V₁ := by exact_mod_cast hV₁
  have hYpos : 0 < |Y| := by have : (0 : ℝ) < 8 * Q * V₁ ^ 2 := by positivity
                             linarith
  -- coefficient sums
  have hSb : ∑ u ∈ 𝒰, ‖b u‖ ^ 2 ≤ 2 * A ^ 2 / U₀ := by
    calc ∑ u ∈ 𝒰, ‖b u‖ ^ 2 ≤ ∑ u ∈ 𝒰.filter (fun u => U₀ + 1 ≤ u), A ^ 2 * (1 / ((u : ℝ) ^ 2)) := by
          rw [filter_true_of_mem (p := fun u => U₀ + 1 ≤ u) fun u hu => (mem_Ioc.1 (h𝒰 hu)).1]
          refine sum_le_sum fun u hu => ?_
          have : (0 : ℝ) < u := by have := (mem_Ioc.1 (h𝒰 hu)).1; exact_mod_cast (show 0 < u by omega)
          calc ‖b u‖ ^ 2 ≤ (A / u) ^ 2 := pow_le_pow_left₀ (norm_nonneg _) (hb u hu) 2
            _ = _ := by field_simp
      _ = A ^ 2 * ∑ u ∈ 𝒰.filter (fun u => U₀ + 1 ≤ u), (1 / ((u : ℝ) ^ 2)) := by rw [mul_sum]
      _ ≤ A ^ 2 * (2 / ((U₀ + 1 : ℕ) : ℝ)) :=
          mul_le_mul_of_nonneg_left (GoldC.QuillonOmega.sum_inv_sq_tail 𝒰 (U₀ + 1) (by omega)) (sq_nonneg A)
      _ ≤ 2 * A ^ 2 / U₀ := by
          rw [mul_div_assoc', mul_comm (A ^ 2) 2]
          apply div_le_div_of_nonneg_left (by positivity) hU₀R; push_cast; linarith
  have hSa : ∑ v ∈ 𝒱, ‖a v‖ ^ 2 ≤ 2 * A ^ 2 / V₁ := by
    calc ∑ v ∈ 𝒱, ‖a v‖ ^ 2 ≤ ∑ v ∈ 𝒱.filter (fun v => V₁ + 1 ≤ v), A ^ 2 * (1 / ((v : ℝ) ^ 2)) := by
          rw [filter_true_of_mem (p := fun v => V₁ + 1 ≤ v) fun v hv => (mem_Ioc.1 (h𝒱 hv)).1]
          refine sum_le_sum fun v hv => ?_
          have : (0 : ℝ) < v := by have := (mem_Ioc.1 (h𝒱 hv)).1; exact_mod_cast (show 0 < v by omega)
          calc ‖a v‖ ^ 2 ≤ (A / v) ^ 2 := pow_le_pow_left₀ (norm_nonneg _) (ha v hv) 2
            _ = _ := by field_simp
      _ = A ^ 2 * ∑ v ∈ 𝒱.filter (fun v => V₁ + 1 ≤ v), (1 / ((v : ℝ) ^ 2)) := by rw [mul_sum]
      _ ≤ A ^ 2 * (2 / ((V₁ + 1 : ℕ) : ℝ)) :=
          mul_le_mul_of_nonneg_left (GoldC.QuillonOmega.sum_inv_sq_tail 𝒱 (V₁ + 1) (by omega)) (sq_nonneg A)
      _ ≤ 2 * A ^ 2 / V₁ := by
          rw [mul_div_assoc', mul_comm (A ^ 2) 2]
          apply div_le_div_of_nonneg_left (by positivity) (by linarith); push_cast; linarith
  have hav : ∀ v ∈ 𝒱, ‖a v‖ ≤ A / V₁ := fun v hv => by
    have : (V₁ : ℝ) ≤ v := by exact_mod_cast (mem_Ioc.1 (h𝒱 hv)).1.le
    exact (ha v hv).trans (div_le_div_of_nonneg_left hA (by linarith) this)
  have hcard : (𝒱.card : ℝ) ≤ V₁ := by
    have := card_le_card h𝒱
    rw [Nat.card_Ioc] at this
    exact_mod_cast (show 𝒱.card ≤ V₁ by omega)
  -- the pair bounds
  have hdiag : ∀ v ∈ 𝒱, ∑ ρ ∈ range Q, ‖∑ u ∈ (Ioc U₀ U₁).filter (fun u => u % Q = ρ),
      (ampI S₀ S₁ j L v u * (starRingEnd ℂ) (ampI S₀ S₁ j L v u)) *
        eR (Y / ((v : ℝ) * u) - Y / ((v : ℝ) * u))‖ ≤ U₀ := by
    intro v hv
    have hv1 : 1 ≤ v := by have := (mem_Ioc.1 (h𝒱 hv)).1; omega
    calc _ ≤ ∑ ρ ∈ range Q, ∑ u ∈ (Ioc U₀ U₁).filter (fun u => u % Q = ρ), (1 : ℝ) := by
          refine sum_le_sum fun ρ _ => (norm_sum_le _ _).trans (sum_le_sum fun u hu => ?_)
          have hu1 : 1 ≤ u := by have := (mem_Ioc.1 (mem_filter.1 hu).1).1; omega
          have h1 : 1 ≤ v * (L * u) := Nat.one_le_iff_ne_zero.2 (by positivity)
          rw [norm_mul, norm_mul, Complex.norm_conj, GoldC.QuillonR.norm_eR]
          have := norm_ampI_le S₀ S₁ j L v u hj h1
          nlinarith [norm_nonneg (ampI S₀ S₁ j L v u)]
      _ = ∑ u ∈ Ioc U₀ U₁, (1 : ℝ) := by
          rw [sum_fiberwise_of_maps_to (g := fun u => u % Q)]
          intro u _; exact mem_range.2 (Nat.mod_lt _ (by omega))
      _ ≤ U₀ := by
          rw [sum_const, Nat.card_Ioc, nsmul_eq_mul, mul_one]
          exact_mod_cast (show U₁ - U₀ ≤ U₀ by omega)
  have hpair : ∀ v ∈ 𝒱, ∀ v' ∈ 𝒱.erase v, ∑ ρ ∈ range Q, ‖∑ u ∈ (Ioc U₀ U₁).filter (fun u => u % Q = ρ),
      (ampI S₀ S₁ j L v u * (starRingEnd ℂ) (ampI S₀ S₁ j L v' u)) *
        eR (Y / ((v : ℝ) * u) - Y / ((v' : ℝ) * u))‖ ≤
      4 * C * U₀ * em + 32 * C * U₀ ^ 2 * V₁ ^ 2 / (|Y| * |(v : ℝ) - v'|) := by
    intro v hv v' hv'
    exact R_pair_off c C hc hC hcab Q U₀ U₁ V₁ S₀ S₁ j L v v' Y hQ hU₀ hU₁ hV₁ (h𝒱 hv)
      (h𝒱 (mem_of_mem_erase hv')) (ne_of_mem_erase hv').symm hY hj hL
  set W : ℕ → ℕ → ℝ := fun v v' => ∑ ρ ∈ range Q, ‖∑ u ∈ (Ioc U₀ U₁).filter (fun u => u % Q = ρ),
      (ampI S₀ S₁ j L v u * (starRingEnd ℂ) (ampI S₀ S₁ j L v' u)) *
        eR (Y / ((v : ℝ) * u) - Y / ((v' : ℝ) * u))‖ with hW
  have hem0 : 0 ≤ em := (Real.exp_pos _).le
  have hlogV : 0 ≤ Real.log V₁ := Real.log_natCast_nonneg _
  have hinner : ∑ v ∈ 𝒱, ∑ v' ∈ 𝒱, ‖a v‖ * ‖a v'‖ * W v v' ≤
      2 * A ^ 2 * U₀ / V₁ + 4 * A ^ 2 * C * U₀ * em +
        64 * A ^ 2 * C * U₀ ^ 2 * V₁ * (1 + Real.log V₁) / |Y| := by
    have hstep : ∀ v ∈ 𝒱, ∑ v' ∈ 𝒱, ‖a v‖ * ‖a v'‖ * W v v' ≤
        ‖a v‖ ^ 2 * U₀ + ∑ v' ∈ 𝒱.erase v, (A / V₁) ^ 2 *
          (4 * C * U₀ * em + 32 * C * U₀ ^ 2 * V₁ ^ 2 / (|Y| * |(v : ℝ) - v'|)) := by
      intro v hv
      rw [← add_sum_erase 𝒱 _ hv]
      apply add_le_add
      · calc ‖a v‖ * ‖a v‖ * W v v ≤ ‖a v‖ * ‖a v‖ * U₀ :=
              mul_le_mul_of_nonneg_left (hdiag v hv) (by positivity)
          _ = ‖a v‖ ^ 2 * U₀ := by ring
      · refine sum_le_sum fun v' hv' => ?_
        have hv'm := mem_of_mem_erase hv'
        have hW0 : 0 ≤ W v v' := sum_nonneg fun _ _ => norm_nonneg _
        calc ‖a v‖ * ‖a v'‖ * W v v' ≤ (A / V₁) * (A / V₁) *
              (4 * C * U₀ * em + 32 * C * U₀ ^ 2 * V₁ ^ 2 / (|Y| * |(v : ℝ) - v'|)) := by
              apply mul_le_mul (mul_le_mul (hav v hv) (hav v' hv'm) (norm_nonneg _) (by positivity))
                (hpair v hv v' hv') hW0 (by positivity)
          _ = _ := by ring
    refine (sum_le_sum hstep).trans ?_
    rw [sum_add_distrib]
    have h1 : ∑ v ∈ 𝒱, ‖a v‖ ^ 2 * (U₀ : ℝ) ≤ 2 * A ^ 2 * U₀ / V₁ := by
      rw [← sum_mul]
      calc (∑ v ∈ 𝒱, ‖a v‖ ^ 2) * (U₀ : ℝ) ≤ 2 * A ^ 2 / V₁ * U₀ :=
            mul_le_mul_of_nonneg_right hSa hU₀R.le
        _ = _ := by ring
    have h2 : ∑ v ∈ 𝒱, ∑ v' ∈ 𝒱.erase v, (A / V₁) ^ 2 *
        (4 * C * U₀ * em + 32 * C * U₀ ^ 2 * V₁ ^ 2 / (|Y| * |(v : ℝ) - v'|)) ≤
        4 * A ^ 2 * C * U₀ * em + 64 * A ^ 2 * C * U₀ ^ 2 * V₁ * (1 + Real.log V₁) / |Y| := by
      have hsplit : ∀ v ∈ 𝒱, ∑ v' ∈ 𝒱.erase v, (A / V₁) ^ 2 *
          (4 * C * U₀ * em + 32 * C * U₀ ^ 2 * V₁ ^ 2 / (|Y| * |(v : ℝ) - v'|)) =
          (A / V₁) ^ 2 * (4 * C * U₀ * em) * ((𝒱.erase v).card : ℝ) +
            (A / V₁) ^ 2 * (32 * C * U₀ ^ 2 * V₁ ^ 2 / |Y|) *
              ∑ v' ∈ 𝒱.erase v, (1 / |(v : ℝ) - v'|) := by
        intro v _
        rw [show ∑ v' ∈ 𝒱.erase v, (A / V₁) ^ 2 *
            (4 * C * U₀ * em + 32 * C * U₀ ^ 2 * V₁ ^ 2 / (|Y| * |(v : ℝ) - v'|)) =
            ∑ v' ∈ 𝒱.erase v, ((A / V₁) ^ 2 * (4 * C * U₀ * em) +
              (A / V₁) ^ 2 * (32 * C * U₀ ^ 2 * V₁ ^ 2 / |Y|) * (1 / |(v : ℝ) - v'|)) from
          sum_congr rfl fun v' _ => by ring]
        rw [sum_add_distrib, sum_const, nsmul_eq_mul, ← mul_sum]
        ring
      rw [sum_congr rfl hsplit, sum_add_distrib, ← mul_sum, ← mul_sum]
      have hc1 : ∑ v ∈ 𝒱, ((𝒱.erase v).card : ℝ) ≤ (V₁ : ℝ) ^ 2 := by
        calc ∑ v ∈ 𝒱, ((𝒱.erase v).card : ℝ) ≤ ∑ _v ∈ 𝒱, (𝒱.card : ℝ) :=
              sum_le_sum fun v _ => by exact_mod_cast card_erase_le
          _ = (𝒱.card : ℝ) ^ 2 := by rw [sum_const, nsmul_eq_mul, sq]
          _ ≤ (V₁ : ℝ) ^ 2 := pow_le_pow_left₀ (by positivity) hcard 2
      have hc2 : ∑ v ∈ 𝒱, ∑ v' ∈ 𝒱.erase v, (1 / |(v : ℝ) - v'|) ≤ V₁ * (2 * (1 + Real.log V₁)) := by
        calc _ ≤ ∑ _v ∈ 𝒱, 2 * (1 + Real.log V₁) :=
              sum_le_sum fun v hv => sum_inv_dist 𝒱 V₁ v h𝒱 hv
          _ = (𝒱.card : ℝ) * (2 * (1 + Real.log V₁)) := by rw [sum_const, nsmul_eq_mul]
          _ ≤ _ := by gcongr
      have hC0 : 0 ≤ C := hC
      calc (A / V₁) ^ 2 * (4 * C * U₀ * em) * ∑ v ∈ 𝒱, ((𝒱.erase v).card : ℝ) +
            (A / V₁) ^ 2 * (32 * C * U₀ ^ 2 * V₁ ^ 2 / |Y|) *
              ∑ v ∈ 𝒱, ∑ v' ∈ 𝒱.erase v, (1 / |(v : ℝ) - v'|)
          ≤ (A / V₁) ^ 2 * (4 * C * U₀ * em) * (V₁ : ℝ) ^ 2 +
            (A / V₁) ^ 2 * (32 * C * U₀ ^ 2 * V₁ ^ 2 / |Y|) * (V₁ * (2 * (1 + Real.log V₁))) := by
            gcongr
        _ = _ := by field_simp; ring
    linarith
  calc (∑ u ∈ 𝒰, ‖b u‖ ^ 2) * ∑ v ∈ 𝒱, ∑ v' ∈ 𝒱, ‖a v‖ * ‖a v'‖ * W v v'
      ≤ (2 * A ^ 2 / U₀) * (2 * A ^ 2 * U₀ / V₁ + 4 * A ^ 2 * C * U₀ * em +
          64 * A ^ 2 * C * U₀ ^ 2 * V₁ * (1 + Real.log V₁) / |Y|) := by
        apply mul_le_mul hSb hinner (sum_nonneg fun v _ => sum_nonneg fun v' _ => by
          have : 0 ≤ W v v' := sum_nonneg fun _ _ => norm_nonneg _
          positivity) (by positivity)
    _ = _ := by field_simp

end GoldC.QuillonRPiece

#print axioms GoldC.QuillonRPiece.R_offdiag_class
#print axioms GoldC.QuillonRPiece.sum_inv_dist
#print axioms GoldC.QuillonRPiece.R_pair_off
#print axioms GoldC.QuillonRPiece.R_piece
