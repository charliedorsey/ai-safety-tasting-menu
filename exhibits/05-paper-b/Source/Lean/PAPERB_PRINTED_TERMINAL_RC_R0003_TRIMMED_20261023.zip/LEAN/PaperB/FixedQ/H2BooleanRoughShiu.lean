import PaperB.FixedQ.H2BooleanShiuLift
import PaperB.FixedQ.H2PrimeReciprocalMertens
import PaperB.FixedQ.PrimeReciprocalPow2Majorant

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def h2BooleanRoughTiltLiftNat
    (q Y : ℕ) (c : ℝ) (n : ℕ) : ℝ :=
  if ∀ p ∈ n.primeFactors, Y < p
  then h2BooleanTiltLift q c n
  else 0

noncomputable def h2BooleanRoughTiltLift
    (q Y : ℕ) (c : ℝ) : ArithmeticFunction ℝ :=
  ⟨h2BooleanRoughTiltLiftNat q Y c, by
    simp [h2BooleanRoughTiltLiftNat, h2BooleanTiltLiftNat]⟩

@[simp] theorem h2BooleanRoughTiltLift_apply
    (q Y : ℕ) (c : ℝ) (n : ℕ) :
    h2BooleanRoughTiltLift q Y c n =
      h2BooleanRoughTiltLiftNat q Y c n := rfl

lemma h2_rough_support_mul_iff
    {Y m n : ℕ} (hm0 : m ≠ 0) (hn0 : n ≠ 0) :
    (∀ p ∈ (m * n).primeFactors, Y < p) ↔
      (∀ p ∈ m.primeFactors, Y < p) ∧
      (∀ p ∈ n.primeFactors, Y < p) := by
  rw [Nat.primeFactors_mul hm0 hn0]
  constructor
  · intro h
    constructor
    · intro p hp
      exact h p (Finset.mem_union_left _ hp)
    · intro p hp
      exact h p (Finset.mem_union_right _ hp)
  · rintro ⟨hm, hn⟩ p hp
    rcases Finset.mem_union.mp hp with hp | hp
    · exact hm p hp
    · exact hn p hp
private theorem h2BooleanRoughTiltLift_multiplicative_aux
    (q Y : ℕ) (c : ℝ) :
    h2BooleanRoughTiltLiftNat q Y c 1 = 1 ∧
    ∀ {m n : ℕ}, m.Coprime n →
      h2BooleanRoughTiltLiftNat q Y c (m * n) =
        h2BooleanRoughTiltLiftNat q Y c m *
          h2BooleanRoughTiltLiftNat q Y c n := by
  constructor
  · unfold h2BooleanRoughTiltLiftNat
    rw [if_pos (by simp)]
    change h2BooleanTiltLift q c 1 = 1
    exact (h2BooleanTiltLift_multiplicative q c).map_one
  · intro m n hcop
    by_cases hm0 : m = 0
    · subst m
      have hn1 : n = 1 := by simpa using hcop
      subst n
      simp [h2BooleanRoughTiltLiftNat]
    · by_cases hn0 : n = 0
      · subst n
        have hm1 : m = 1 := by simpa using hcop
        subst m
        simp [h2BooleanRoughTiltLiftNat]
      · have hsup := h2_rough_support_mul_iff (Y := Y) hm0 hn0
        by_cases hm : ∀ p ∈ m.primeFactors, Y < p
        · by_cases hn : ∀ p ∈ n.primeFactors, Y < p
          · have hmn : ∀ p ∈ (m*n).primeFactors, Y < p :=
              hsup.mpr ⟨hm,hn⟩
            rw [h2BooleanRoughTiltLiftNat, if_pos hmn,
              h2BooleanRoughTiltLiftNat, if_pos hm,
              h2BooleanRoughTiltLiftNat, if_pos hn]
            exact (h2BooleanTiltLift_multiplicative q c).map_mul_of_coprime hcop
          · have hmn : ¬ ∀ p ∈ (m*n).primeFactors, Y < p := fun h => hn (hsup.mp h).2
            rw [h2BooleanRoughTiltLiftNat, if_neg hmn,
              h2BooleanRoughTiltLiftNat, if_pos hm,
              h2BooleanRoughTiltLiftNat, if_neg hn]
            ring
        · have hmn : ¬ ∀ p ∈ (m*n).primeFactors, Y < p := fun h => hm (hsup.mp h).1
          rw [h2BooleanRoughTiltLiftNat, if_neg hmn,
            h2BooleanRoughTiltLiftNat, if_neg hm]
          ring

theorem h2BooleanRoughTiltLift_multiplicative
    (q Y : ℕ) (c : ℝ) :
    (h2BooleanRoughTiltLift q Y c).IsMultiplicative := by
  constructor
  · exact (h2BooleanRoughTiltLift_multiplicative_aux q Y c).1
  · intro m n hcop
    exact (h2BooleanRoughTiltLift_multiplicative_aux q Y c).2 hcop
lemma h2BooleanRoughTiltLift_nonneg
    (q Y n : ℕ) {c : ℝ} (hc : 0 ≤ c) :
    0 ≤ h2BooleanRoughTiltLift q Y c n := by
  rw [h2BooleanRoughTiltLift_apply]
  unfold h2BooleanRoughTiltLiftNat
  split_ifs
  · exact h2BooleanTiltLift_nonneg q n hc
  · exact le_rfl

lemma h2BooleanRoughTiltLift_le
    (q Y n : ℕ) {c : ℝ} (hc : 0 ≤ c) :
    h2BooleanRoughTiltLift q Y c n ≤
      h2BooleanTiltLift q c n := by
  rw [h2BooleanRoughTiltLift_apply]
  unfold h2BooleanRoughTiltLiftNat
  split_ifs
  · exact le_rfl
  · exact h2BooleanTiltLift_nonneg q n hc

lemma h2BooleanRoughTiltLift_squarefree_support
    (q Y n : ℕ) {c : ℝ} (hc : 0 ≤ c) (hn : ¬ Squarefree n) :
    h2BooleanRoughTiltLift q Y c n = 0 := by
  have hfull := h2BooleanTiltLift_squarefree_support q n c hn
  have hnon := h2BooleanRoughTiltLift_nonneg q Y n hc
  have hle := h2BooleanRoughTiltLift_le q Y n hc
  rw [hfull] at hle
  linarith

lemma h2BooleanRoughTiltLift_prime_le_eight
    (q Y p : ℕ) {c : ℝ} (hc0 : 0 ≤ c) (hc : c ≤ 3/2)
    (hp : p.Prime) :
    h2BooleanRoughTiltLift q Y c p ≤ 8 := by
  exact (h2BooleanRoughTiltLift_le q Y p hc0).trans
    (h2BooleanTiltLift_prime_le_eight q p hc0 hc hp)

lemma h2BooleanRoughTiltLift_growth
    (q Y n : ℕ) {c : ℝ} (hc0 : 0 ≤ c) (hc : c ≤ 3/2) :
    h2BooleanRoughTiltLift q Y c n ≤
      (8 : ℝ)^h2BooleanShiuGrowthThreshold *
        (n : ℝ)^(1/1280 : ℝ) := by
  exact (h2BooleanRoughTiltLift_le q Y n hc0).trans
    (h2BooleanTiltLift_growth q n hc0 hc)
theorem h2BooleanRoughTiltLift_envelope
    (q Y : ℕ) {c : ℝ} (hc0 : 0 ≤ c) (hc : c ≤ 3/2) :
    PaperB.M4B.FixedQuarterEnvelope
      (h2BooleanRoughTiltLift q Y c) 8
      ((8 : ℝ)^h2BooleanShiuGrowthThreshold) := by
  refine ⟨h2BooleanRoughTiltLift_multiplicative q Y c,
    (fun n => h2BooleanRoughTiltLift_nonneg q Y n hc0),
    (fun n hn => h2BooleanRoughTiltLift_squarefree_support q Y n hc0 hn),
    (fun p hp => h2BooleanRoughTiltLift_prime_le_eight q Y p hc0 hc hp),
    by norm_num, pow_nonneg (by norm_num) _, ?_⟩
  intro n
  simpa using h2BooleanRoughTiltLift_growth q Y n hc0 hc

theorem h2BooleanRoughTiltLift_progression
    (q Y : ℕ) {c : ℝ} (hc0 : 0 ≤ c) (hc : c ≤ 3/2) :
    ∃ C : ℝ, ∃ X0 : ℕ, ∀ x y k a : ℕ,
      X0 ≤ x →
      (x : ℝ)^(1/4 : ℝ) < (y : ℝ) →
      y ≤ x →
      (k : ℝ) < (y : ℝ)^(3/4 : ℝ) →
      0 < a → a < k → a.Coprime k →
      PaperB.M4B.progressionSum
        (h2BooleanRoughTiltLift q Y c) x y k a ≤
      C * ((y : ℝ)/((k.totient : ℝ)*Real.log (x : ℝ))) *
        Real.exp (PaperB.M4B.primeMass
          (h2BooleanRoughTiltLift q Y c) x k) :=
  PaperB.M4B.shiuFixedQuarter_progression
    (h2BooleanRoughTiltLift_envelope q Y hc0 hc)

lemma h2_primesLE_filter_gt_eq_sdiff
    {Y X : ℕ} (hYX : Y ≤ X) :
    X.primesLE.filter (fun p => Y < p) =
      X.primesLE \ Y.primesLE := by
  ext p
  simp only [Finset.mem_filter, Nat.mem_primesLE, Finset.mem_sdiff]
  constructor
  · rintro ⟨⟨hpX, hpP⟩, hpY⟩
    exact ⟨⟨hpX, hpP⟩, by
      intro hmem
      exact (not_le_of_gt hpY) hmem.1⟩
  · rintro ⟨⟨hpX, hpP⟩, hnot⟩
    refine ⟨⟨hpX, hpP⟩, ?_⟩
    have hnotle : ¬ p ≤ Y := by
      intro hpY
      exact hnot ⟨hpY, hpP⟩
    omega

lemma h2_sum_prime_recip_filter_gt_le
    {Y X : ℕ} (hY : 2 ≤ Y) (hYX : Y ≤ X) (hX : 4 ≤ X) :
    (∑ p ∈ X.primesLE.filter (fun p => Y < p),
        (1 : ℝ) / p) ≤
      (Real.log (Real.log (X : ℝ)) + 5) -
        (Real.log (Real.log ((Y + 1 : ℕ) : ℝ)) - 1) := by
  have hsub : Y.primesLE ⊆ X.primesLE := by
    intro p hp
    have hp' := Nat.mem_primesLE.mp hp
    exact Nat.mem_primesLE.mpr ⟨hp'.1.trans hYX, hp'.2⟩
  have hdiff := Finset.sum_sdiff_eq_sub
    (s₁ := Y.primesLE) (s₂ := X.primesLE)
    (f := fun p : ℕ => (1 : ℝ) / p) hsub
  rw [← h2_primesLE_filter_gt_eq_sdiff hYX] at hdiff
  have hupper := sum_prime_recip_le_loglog_add_five hX
  have hlower := h2_sum_prime_recip_ge_loglog_sub_one hY
  rw [hdiff]
  linarith

lemma h2BooleanRoughTiltLift_prime_term_le
    {q Y p : ℕ} {c : ℝ}
    (hc0 : 0 ≤ c) (hc : c ≤ 3/2)
    (hp : p.Prime) :
    h2BooleanRoughTiltLift q Y c p / (p : ℝ) ≤
      if Y < p then
        (2 * c) * ((p : ℝ)⁻¹) +
          24 * ((p : ℝ)⁻¹ ^ 2)
      else 0 := by
  by_cases hYp : Y < p
  · rw [if_pos hYp]
    rw [h2BooleanRoughTiltLift_apply]
    unfold h2BooleanRoughTiltLiftNat
    have hsup : ∀ r ∈ p.primeFactors, Y < r := by
      intro r hr
      have hrp : r = p := by
        have hd := Nat.dvd_of_mem_primeFactors hr
        rcases (Nat.dvd_prime hp).mp hd with h1 | heq
        · exact False.elim
            ((Nat.prime_of_mem_primeFactors hr).ne_one h1)
        · exact heq
      simpa [hrp] using hYp
    rw [if_pos hsup]
    exact h2BooleanTiltLift_prime_term_le hc0 hc hp
  · rw [if_neg hYp]
    rw [h2BooleanRoughTiltLift_apply]
    unfold h2BooleanRoughTiltLiftNat
    have hnsup : ¬ ∀ r ∈ p.primeFactors, Y < r := by
      intro h
      exact hYp (h p (by simp [hp]))
    rw [if_neg hnsup]
    simp

theorem h2BooleanRoughTiltLift_primeMass_le
    (q Y X k : ℕ) {c : ℝ}
    (hc0 : 0 ≤ c) (hc : c ≤ 3/2)
    (hY : 2 ≤ Y) (hYX : Y ≤ X) (hX : 4 ≤ X) :
    PaperB.M4B.primeMass
        (h2BooleanRoughTiltLift q Y c) X k ≤
      (2 * c) *
        ((Real.log (Real.log (X : ℝ)) + 5) -
          (Real.log (Real.log ((Y + 1 : ℕ) : ℝ)) - 1)) +
        24 := by
  classical
  let P : Finset ℕ := X.primesLE.filter fun p => ¬ p ∣ k
  let T : Finset ℕ := X.primesLE.filter fun p => Y < p
  have hterm :
      (∑ p ∈ P,
        h2BooleanRoughTiltLift q Y c p / (p : ℝ)) ≤
        ∑ p ∈ P,
          (if Y < p then
            (2 * c) * ((p : ℝ)⁻¹) +
              24 * ((p : ℝ)⁻¹ ^ 2)
          else 0) := by
    apply Finset.sum_le_sum
    intro p hpP
    have hpPrime : p.Prime :=
      (Nat.mem_primesLE.mp (Finset.mem_filter.mp hpP).1).2
    exact h2BooleanRoughTiltLift_prime_term_le hc0 hc hpPrime
  have hPsubset : P ⊆ X.primesLE := by
    intro p hp
    exact (Finset.mem_filter.mp hp).1
  have hmajorNonneg :
      ∀ p ∈ X.primesLE, p ∉ P →
        0 ≤ if Y < p then
          (2 * c) * ((p : ℝ)⁻¹) +
            24 * ((p : ℝ)⁻¹ ^ 2)
        else 0 := by
    intro p hp hnot
    split_ifs
    · exact add_nonneg
        (mul_nonneg (mul_nonneg (by norm_num) hc0)
          (inv_nonneg.mpr (by positivity)))
        (mul_nonneg (by norm_num) (sq_nonneg _))
    · exact le_rfl
  have hdrop :
      (∑ p ∈ P,
          (if Y < p then
            (2 * c) * ((p : ℝ)⁻¹) +
              24 * ((p : ℝ)⁻¹ ^ 2)
          else 0)) ≤
        ∑ p ∈ X.primesLE,
          (if Y < p then
            (2 * c) * ((p : ℝ)⁻¹) +
              24 * ((p : ℝ)⁻¹ ^ 2)
          else 0) :=
    Finset.sum_le_sum_of_subset_of_nonneg
      hPsubset hmajorNonneg
  have hfilter :
      (∑ p ∈ X.primesLE,
          (if Y < p then
            (2 * c) * ((p : ℝ)⁻¹) +
              24 * ((p : ℝ)⁻¹ ^ 2)
          else 0)) =
        ∑ p ∈ T,
          ((2 * c) * ((p : ℝ)⁻¹) +
            24 * ((p : ℝ)⁻¹ ^ 2)) := by
    unfold T
    rw [Finset.sum_filter]

  have hrecip :
      (∑ p ∈ T, (1 : ℝ) / p) ≤
        (Real.log (Real.log (X : ℝ)) + 5) -
          (Real.log (Real.log ((Y + 1 : ℕ) : ℝ)) - 1) := by
    unfold T
    exact h2_sum_prime_recip_filter_gt_le hY hYX hX
  have hTsubsetIcc : T ⊆ Finset.Icc 2 X := by
    intro p hp
    have hpX :=
      Nat.mem_primesLE.mp (Finset.mem_filter.mp hp).1
    exact Finset.mem_Icc.mpr ⟨hpX.2.two_le, hpX.1⟩
  have hsq :
      (∑ p ∈ T, ((p : ℝ)⁻¹ ^ 2)) ≤ 1 := by
    calc
      (∑ p ∈ T, ((p : ℝ)⁻¹ ^ 2)) ≤
          ∑ n ∈ Finset.Icc 2 X,
            ((n : ℝ)⁻¹ ^ 2) := by
              exact Finset.sum_le_sum_of_subset_of_nonneg
                hTsubsetIcc (fun n hn hnot => by positivity)
      _ ≤ 1 := by
        simpa using
          (finite_square_tail_le_inv
            (F := 1) (M := X) (by norm_num))
  unfold PaperB.M4B.primeMass
  change
    (∑ p ∈ P,
      h2BooleanRoughTiltLift q Y c p / (p : ℝ)) ≤ _
  calc
    (∑ p ∈ P,
      h2BooleanRoughTiltLift q Y c p / (p : ℝ))
        ≤ ∑ p ∈ P,
          (if Y < p then
            (2 * c) * ((p : ℝ)⁻¹) +
              24 * ((p : ℝ)⁻¹ ^ 2)
          else 0) := hterm
    _ ≤ ∑ p ∈ X.primesLE,
          (if Y < p then
            (2 * c) * ((p : ℝ)⁻¹) +
              24 * ((p : ℝ)⁻¹ ^ 2)
          else 0) := hdrop
    _ = ∑ p ∈ T,
          ((2 * c) * ((p : ℝ)⁻¹) +
            24 * ((p : ℝ)⁻¹ ^ 2)) := hfilter
    _ = (2 * c) * (∑ p ∈ T, (1 : ℝ) / p) +
          24 * (∑ p ∈ T, ((p : ℝ)⁻¹ ^ 2)) := by
            simp_rw [one_div]
            rw [Finset.sum_add_distrib,
              Finset.mul_sum, Finset.mul_sum]
    _ ≤ (2 * c) *
          ((Real.log (Real.log (X : ℝ)) + 5) -
            (Real.log (Real.log ((Y + 1 : ℕ) : ℝ)) - 1)) +
          24 * 1 := by
            exact add_le_add
              (mul_le_mul_of_nonneg_left hrecip
                (mul_nonneg (by norm_num) hc0))
              (mul_le_mul_of_nonneg_left hsq (by norm_num))
    _ = _ := by ring

theorem h2BooleanSecondRoughTiltLift_primeMass_le
    (q Y X k : ℕ)
    (hY : 2 ≤ Y) (hYX : Y ≤ X) (hX : 4 ≤ X) :
    PaperB.M4B.primeMass
        (h2BooleanRoughTiltLift q Y h2BooleanSecondTilt) X k ≤
      h2BooleanV0 *
        ((Real.log (Real.log (X : ℝ)) + 5) -
          (Real.log (Real.log ((Y + 1 : ℕ) : ℝ)) - 1)) +
        24 := by
  have h := h2BooleanRoughTiltLift_primeMass_le
    q Y X k h2BooleanSecondTilt_nonneg
      h2BooleanSecondTilt_le_three_halves hY hYX hX
  rwa [two_mul_h2BooleanSecondTilt] at h

#print axioms h2BooleanRoughTiltLift_envelope
#print axioms h2BooleanRoughTiltLift_progression
#print axioms h2_sum_prime_recip_filter_gt_le
#print axioms h2BooleanRoughTiltLift_prime_term_le
#print axioms h2BooleanSecondRoughTiltLift_primeMass_le

end PaperB.FixedQ
