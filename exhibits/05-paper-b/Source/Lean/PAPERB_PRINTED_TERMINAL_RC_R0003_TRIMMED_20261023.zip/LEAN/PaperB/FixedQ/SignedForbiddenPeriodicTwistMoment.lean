import PaperB.FixedQ.H2PeriodicTwistCoherence
import PaperB.FixedQ.H2BooleanDyadicSecondMomentAssembly

namespace PaperB.FixedQ

theorem fixedQPeriodicTotalTwist_dyadicSecondMoment_le
    (q : ℕ) (hq : 0 < q) :
    ∃ M0 : ℕ, ∀ H M j : ℕ,
      M0 ≤ M →
      2 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      1 ≤ j →
      3 ≤ Nat.nthRoot 4 M →
      (h2BooleanRoughCutoff M) ^ 2 ≤ M →
      ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
      ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
      1 ≤ Real.log (M : ℝ) →
      h2BooleanTailCorrectionConst ≤
        (1 / 8 : ℝ) * (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) →
      h2BooleanDyadicFrequencySecondMomentTwisted
          q M j (fixedQPeriodicTotalTwist q H) ≤
        h2BooleanFrequencySecondMomentMajorantAll q M j := by
  rcases h2BooleanDyadicFrequencySecondMomentTwisted_le_quantitative_all q hq with
    ⟨M0, hM⟩
  refine ⟨M0, ?_⟩
  intro H M j hM0 hM2 hY4 hj hroot hYsq hquarter hk hlog hC
  exact hM M j (fixedQPeriodicTotalTwist q H)
    (fixedQPeriodicTotalTwist_familyCompatible
      q H (h2BooleanRoughCutoff M) M j)
    hM0 hM2 hY4 hj hroot hYsq hquarter hk hlog hC

#print axioms fixedQPeriodicTotalTwist_dyadicSecondMoment_le

end PaperB.FixedQ
