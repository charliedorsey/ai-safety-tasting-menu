import GoldC.QuillonLRes

/-!
# Quillon LONG L9: the LONG-right residual cells, physically

On LONG-right (`¬ longInverseLeft`, hence `r^{1+δ} < s ≤ r²` under `MkL`), the pairs with
`C ∩ J_R(B) = ∅` (the VK route `RL_physical` does not apply) split exactly as

* `ManyLPart`: `|C| ≥ K₀ = ⌈100 log Λ⌉`                                — Rankin mass, `≤ Λ^{−50}`;
* `EdgeLPart`: `|C| < K₀`, `r < s^{1/2+3η}`                              — rough `C` × thin `B` window, `≤ Λ^{19/20}`;
* `ResLPart`:  `|C| < K₀`, `r ≥ s^{1/2+3η}`, `B` misses `[X, ⌊s^η⌋]`     — rough × rough, `≤ Λ^{7/10}`;
* `WRLPart`:   `|C| < K₀`, `r ≥ s^{1/2+3η}`, `B` meets `[X, ⌊s^η⌋]`      — Weil W′, `≤ Λ^{−80}` given `WeilHyp`.

`η = Λ^{−1/10}`. No axiom, no `sorry`; `WRL_physical` takes `(hW : WeilHyp)` explicitly.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonLRP

open Classical
open GoldC.QuillonEv GoldC.QuillonSetup GoldC.QuillonLam GoldC.QuillonCEv GoldC.QuillonCFinal
  GoldC.QuillonREv GoldC.QuillonWContext GoldC.QuillonResPhysical GoldC.QuillonRPhysical
  GoldC.QuillonLSetup GoldC.QuillonLW GoldC.QuillonLWR GoldC.QuillonLRes
open GoldC.QuillonCopyS GoldC.QuillonCopyF GoldC.QuillonCopyM GoldC.QuillonWPhysical

/-- the LONG-right Weil residual mask. -/
def RMR (h : ℕ) (δ : ℝ) (T B C : Finset ℕ) : Prop :=
  ¬ longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧ ¬ (C ∩ JR h T B).Nonempty ∧
    ¬ (K0 h ≤ C.card) ∧
    ¬ (((primeSetProduct B : ℕ) : ℝ) < ((primeSetProduct C : ℕ) : ℝ) ^ ((1 : ℝ) / 2 + 3 * ηp h)) ∧
    (B ∩ (T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ YL h (∏ p ∈ C, p))).Nonempty

noncomputable def ManyLPart (Jlow Jhigh q a h : ℕ) (δ : ℝ) (d : Finset ℕ) : ℝ :=
  ∑ B ∈ (Tsrc q h d).powerset, ∑ C ∈ (Tsrc q h d).powerset,
    if B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C ∧
        (MkL Jlow Jhigh h (h / primeSetProduct d) δ B C ∧
          (¬ longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧
            ¬ (C ∩ JR h (Tsrc q h d) B).Nonempty ∧ K0 h ≤ C.card)) then
      omegaWeight B * omegaWeight C *
        foldRow q a (primeSetProduct d) (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct C)
    else 0

noncomputable def EdgeLPart (Jlow Jhigh q a h : ℕ) (δ : ℝ) (d : Finset ℕ) : ℝ :=
  ∑ B ∈ (Tsrc q h d).powerset, ∑ C ∈ (Tsrc q h d).powerset,
    if B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C ∧
        (MkL Jlow Jhigh h (h / primeSetProduct d) δ B C ∧
          (¬ longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧
            ¬ (C ∩ JR h (Tsrc q h d) B).Nonempty ∧ ¬ (K0 h ≤ C.card) ∧
            ((primeSetProduct B : ℕ) : ℝ) < ((primeSetProduct C : ℕ) : ℝ) ^ ((1 : ℝ) / 2 + 3 * ηp h))) then
      omegaWeight B * omegaWeight C *
        foldRow q a (primeSetProduct d) (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct C)
    else 0

noncomputable def ResLPart (Jlow Jhigh q a h : ℕ) (δ : ℝ) (d : Finset ℕ) : ℝ :=
  ∑ B ∈ (Tsrc q h d).powerset, ∑ C ∈ (Tsrc q h d).powerset,
    if B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C ∧
        (MkL Jlow Jhigh h (h / primeSetProduct d) δ B C ∧
          (¬ longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧
            ¬ (C ∩ JR h (Tsrc q h d) B).Nonempty ∧ ¬ (K0 h ≤ C.card) ∧
            ¬ (((primeSetProduct B : ℕ) : ℝ) < ((primeSetProduct C : ℕ) : ℝ) ^ ((1 : ℝ) / 2 + 3 * ηp h)) ∧
            ¬ (B ∩ ((Tsrc q h d) \ C).filter (fun p => Xp h ≤ p ∧ p ≤ YL h (∏ p ∈ C, p))).Nonempty)) then
      omegaWeight B * omegaWeight C *
        foldRow q a (primeSetProduct d) (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct C)
    else 0

noncomputable def WRLPart (Jlow Jhigh q a h : ℕ) (δ : ℝ) (d : Finset ℕ) : ℝ :=
  ∑ B ∈ (Tsrc q h d).powerset, ∑ C ∈ (Tsrc q h d).powerset,
    if B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C ∧
        (MkL Jlow Jhigh h (h / primeSetProduct d) δ B C ∧ RMR h δ (Tsrc q h d) B C) then
      omegaWeight B * omegaWeight C *
        foldRow q a (primeSetProduct d) (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct C)
    else 0

lemma inter_JR {h : ℕ} {T B C : Finset ℕ} (hCB : C ⊆ T \ B) :
    C ∩ JR h T B = C.filter (fun p => Xp h < p ∧ p ≤ 2 ^ Kvp h (∏ p ∈ B, p) * Xp h) := by
  ext p
  simp only [JR, mem_inter, mem_filter]
  constructor
  · rintro ⟨hp, -, hq⟩; exact ⟨hp, hq⟩
  · rintro ⟨hp, hq⟩; exact ⟨hp, hCB hp, hq⟩

lemma prodT_le (q h : ℕ) (d : Finset ℕ) (hh : 1 ≤ Real.log h) :
    ∏ p ∈ Tsrc q h d, (1 + 1 / ((p : ℝ) - 3)) ≤
      Real.exp 10 * (2 * 2 + 1) ^ 10 * (Real.log h) ^ (10 : ℝ) := by
  rw [← sum_ωR_powerset]; exact outer_mass q h d hh

set_option maxHeartbeats 4000000 in
/-- **Many prime factors in `s`** (LONG-right, `C` misses `J_R`): Rankin mass. -/
theorem ManyL_physical (q : ℕ) (hq : 0 < q) (δ : ℝ) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (Jlow Jhigh a h : ℕ) (d : Finset ℕ), Λ₀ ≤ Real.log h → 2 ≤ h →
      |ManyLPart Jlow Jhigh q a h δ d| ≤ (Real.log h) ^ (-(50 : ℝ)) := by
  set Fm : ℝ := 4 + 48 * q with hFm
  set E : ℝ := Real.exp 10 * (2 * 2 + 1) ^ 10 with hE
  obtain ⟨Λ₁, hΛ₁, hK⟩ := const_le_rpow (Fm * E ^ 4) 1 one_pos
  refine ⟨max 2 Λ₁, le_max_left _ _, ?_⟩
  intro Jlow Jhigh a h d hΛ hh
  have L1 : Λ₁ ≤ Real.log h := le_trans (le_max_right _ _) hΛ
  set Λ := Real.log h with hΛdef
  have hΛ2 : 2 ≤ Λ := le_trans (le_max_left _ _) hΛ
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  set T := Tsrc q h d with hT
  have hTf := Tsrc_facts q h d
  have hTf5 : ∀ p ∈ T, 5 ≤ p := fun p hp => (hTf p hp).2.1
  have hP := prodT_le q h d hΛ1
  have hP0 : 0 ≤ ∏ p ∈ T, (1 + 1 / ((p : ℝ) - 3)) := prod_nonneg fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast hTf5 p hp
    have : 0 ≤ 1 / ((p : ℝ) - 3) := div_nonneg zero_le_one (by linarith)
    linarith
  have h3 := three_pow_K0 h hΛ1
  have hEΛ0 : 0 ≤ E * Λ ^ (10 : ℝ) := by positivity
  unfold ManyLPart
  have hc : ∀ B ∈ T.powerset, ∀ C ∈ T.powerset,
      (B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C ∧
        (MkL Jlow Jhigh h (h / primeSetProduct d) δ B C ∧
          (¬ longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧
            ¬ (C ∩ JR h T B).Nonempty ∧ K0 h ≤ C.card))) → True ∧ K0 h ≤ C.card :=
    fun B _ C _ hc => ⟨trivial, hc.2.2.2.2.2.2⟩
  have hmain := dsum_bound T hTf5 _ (fun _ => True) (fun _ C => K0 h ≤ C.card) hc
    (fun B C => foldRow q a (primeSetProduct d) (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct C))
    Fm (by positivity) (fun B C _ => GoldC.QuillonBridge.abs_foldRow_le q a _ _ _ _ hq)
    ((E * Λ ^ (10 : ℝ)) ^ 3 / (3 : ℝ) ^ K0 h)
    (fun B _ _ => (rankin_many T hTf5 (K0 h)).trans
      (div_le_div_of_nonneg_right (pow_le_pow_left₀ hP0 hP 3) (by positivity)))
  refine le_trans hmain ?_
  have hS : ∑ B ∈ T.powerset, (if True then ωR B else 0) ≤ E * Λ ^ (10 : ℝ) := by
    simp only [if_true]; exact outer_mass q h d hΛ1
  have hpos3 : (0 : ℝ) < Λ ^ (100 : ℝ) := by positivity
  have hIM : (E * Λ ^ (10 : ℝ)) ^ 3 / (3 : ℝ) ^ K0 h ≤ (E * Λ ^ (10 : ℝ)) ^ 3 / Λ ^ (100 : ℝ) :=
    div_le_div_of_nonneg_left (by positivity) hpos3 h3
  have e1 : (Λ ^ (10 : ℝ)) ^ 3 = Λ ^ (30 : ℝ) := by
    rw [← Real.rpow_natCast, ← Real.rpow_mul hΛ0.le]; norm_num
  have e2 : Λ ^ (10 : ℝ) * (Λ ^ (30 : ℝ) / Λ ^ (100 : ℝ)) = Λ ^ (-(60 : ℝ)) := by
    rw [div_eq_mul_inv, ← Real.rpow_neg hΛ0.le, ← Real.rpow_add hΛ0, ← Real.rpow_add hΛ0]; norm_num
  have hKΛ := hK Λ L1
  rw [Real.rpow_one] at hKΛ
  have hS0 : 0 ≤ ∑ B ∈ T.powerset, (if True then ωR B else 0) := by
    simp only [if_true]; exact sum_nonneg fun B hB => ωR_nonneg B fun p hp => hTf5 p (mem_powerset.1 hB hp)
  calc Fm * ((∑ B ∈ T.powerset, (if True then ωR B else 0)) * ((E * Λ ^ (10 : ℝ)) ^ 3 / (3 : ℝ) ^ K0 h))
      ≤ Fm * ((E * Λ ^ (10 : ℝ)) * ((E * Λ ^ (10 : ℝ)) ^ 3 / Λ ^ (100 : ℝ))) := by
        apply mul_le_mul_of_nonneg_left _ (by positivity)
        exact mul_le_mul hS hIM (by positivity) hEΛ0
    _ = Fm * E ^ 4 * (Λ ^ (10 : ℝ) * (Λ ^ (30 : ℝ) / Λ ^ (100 : ℝ))) := by
        rw [mul_pow, e1]; ring
    _ = Fm * E ^ 4 * Λ ^ (-(60 : ℝ)) := by rw [e2]
    _ ≤ Λ * Λ ^ (-(60 : ℝ)) := mul_le_mul_of_nonneg_right hKΛ (by positivity)
    _ = Λ ^ (-(59 : ℝ)) := by
        rw [show Λ * Λ ^ (-(60 : ℝ)) = Λ ^ (1 : ℝ) * Λ ^ (-(60 : ℝ)) by rw [Real.rpow_one],
          ← Real.rpow_add hΛ0]; norm_num
    _ ≤ Λ ^ (-(50 : ℝ)) := Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)

set_option maxHeartbeats 4000000 in
/-- **Physical LONG-right Weil W′ theorem** (conditional only on `WeilHyp`). -/
theorem WRL_physical (hW : GoldC.QuillonLWeil.WeilHyp) (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (Jlow Jhigh a h : ℕ) (d : Finset ℕ), Λ₀ ≤ Real.log h → 2 ≤ h →
      |WRLPart Jlow Jhigh q a h δ d| ≤ (Real.log h) ^ (-(80 : ℝ)) := by
  obtain ⟨Λ₁, hΛ₁, hW⟩ := W_final_LR hW q hq δ hδ0 hδ1
  set K : ℝ := Real.exp 10 * (2 * 2 + 1) ^ 10 * 4 with hK
  obtain ⟨Λ₂, hΛ₂, hKΛ⟩ := GoldC.QuillonLam.const_le_rpow K 1 one_pos
  refine ⟨max Λ₁ Λ₂, le_trans hΛ₁ (le_max_left _ _), ?_⟩
  intro Jlow Jhigh a h d hΛ hh
  have hΛa : Λ₁ ≤ Real.log h := le_trans (le_max_left _ _) hΛ
  have hΛb : Λ₂ ≤ Real.log h := le_trans (le_max_right _ _) hΛ
  set Λ := Real.log h with hΛdef
  have hΛ2 : 2 ≤ Λ := le_trans hΛ₁ hΛa
  have hΛ0 : 0 < Λ := by linarith
  set H := h / primeSetProduct d with hH
  set T := Tsrc q h d with hT
  have hTf := Tsrc_facts q h d
  have hHh : H ≤ h := Nat.div_le_self _ _
  unfold WRLPart
  rw [GoldC.QuillonCells.double_sum_fixC]
  -- per-`C` bound
  have hinner : ∀ C ∈ T.powerset.filter (fun C => C ≠ ∅),
      |∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
        (if MkL Jlow Jhigh h H δ B C ∧ RMR h δ T B C then
          omegaWeight B * omegaWeight C *
            foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0)| ≤
        ωR C * (4 * Λ ^ (-(95 : ℝ))) := by
    intro C hC
    have hCT : C ⊆ T := mem_powerset.1 (mem_filter.1 hC).1
    have hω0 : 0 ≤ ωR C := ωR_nonneg C fun p hp => (hTf p (hCT hp)).2.1
    have key := hW a h H (primeSetProduct d) T C
      (fun k => Jlow ≤ k + C.card ∧ k + C.card < Jhigh) hΛa hh hHh hTf hCT
    have e : ∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
        (if MkL Jlow Jhigh h H δ B C ∧ RMR h δ T B C then
          omegaWeight B * omegaWeight C *
            foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0) =
        ωR C * ∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
          (if ((Jlow ≤ B.card + C.card ∧ B.card + C.card < Jhigh) ∧
              GeoWR h H δ C (∏ p ∈ B, p)) ∧
              (B ∩ (T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ YL h (∏ p ∈ C, p))).Nonempty
            then ωR B * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p) else 0) := by
      rw [mul_sum]
      refine sum_congr rfl fun B hB'' => ?_
      have hiff : (MkL Jlow Jhigh h H δ B C ∧ RMR h δ T B C) ↔
          (((Jlow ≤ B.card + C.card ∧ B.card + C.card < Jhigh) ∧
              GeoWR h H δ C (∏ p ∈ B, p)) ∧
              (B ∩ (T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ YL h (∏ p ∈ C, p))).Nonempty) := by
        have hCB : C ⊆ T \ B := fun p hp => by
          have hBC := mem_powerset.1 (mem_filter.1 hB'').1
          exact mem_sdiff.2 ⟨hCT hp, fun hpB => (mem_sdiff.1 (hBC hpB)).2 hp⟩
        unfold RMR
        rw [inter_JR hCB]
        constructor
        · rintro ⟨⟨h1, h2, h3, h4, h5, h6⟩, hnL, hJ, hKm, hEd, hw⟩
          exact ⟨⟨⟨h3, h4⟩, ⟨h1, h2, h5.resolve_left hnL, h6⟩, not_lt.1 hEd, hJ, not_le.1 hKm⟩, hw⟩
        · rintro ⟨⟨⟨h3, h4⟩, ⟨h1, h2, hR, h6⟩, hEd, hJ, hKm⟩, hw⟩
          exact ⟨⟨h1, h2, h3, h4, Or.inr hR, h6⟩, fun hL => not_both δ hδ0.le _ _ ⟨hL, hR⟩, hJ,
            not_le.2 hKm, not_lt.2 hEd, hw⟩
      split_ifs with h1 h2 h2
      · show ωR B * ωR C * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p) =
          ωR C * (ωR B * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p))
        ring
      · exact absurd (hiff.1 h1) h2
      · exact absurd (hiff.2 h2) h1
      · rw [mul_zero]
    rw [e, abs_mul, abs_of_nonneg hω0]
    exact mul_le_mul_of_nonneg_left key hω0
  calc _ ≤ ∑ C ∈ T.powerset.filter (fun C => C ≠ ∅),
        |∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
          (if MkL Jlow Jhigh h H δ B C ∧ RMR h δ T B C then
            omegaWeight B * omegaWeight C *
              foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0)| :=
        abs_sum_le_sum_abs _ _
    _ ≤ ∑ C ∈ T.powerset.filter (fun C => C ≠ ∅), ωR C * (4 * Λ ^ (-(95 : ℝ))) := sum_le_sum hinner
    _ ≤ ∑ C ∈ T.powerset, ωR C * (4 * Λ ^ (-(95 : ℝ))) := by
        apply sum_le_sum_of_subset_of_nonneg (filter_subset _ _)
        intro C hC _
        have hCT : C ⊆ T := mem_powerset.1 hC
        have := ωR_nonneg C fun p hp => (hTf p (hCT hp)).2.1
        positivity
    _ = (∑ C ∈ T.powerset, ωR C) * (4 * Λ ^ (-(95 : ℝ))) := by rw [sum_mul]
    _ ≤ (Real.exp 10 * (2 * 2 + 1) ^ 10 * Λ ^ (10 : ℝ)) * (4 * Λ ^ (-(95 : ℝ))) :=
        mul_le_mul_of_nonneg_right (outer_mass q h d (by linarith)) (by positivity)
    _ = K * Λ ^ (-(85 : ℝ)) := by
        rw [hK, show Λ ^ (-(85 : ℝ)) = Λ ^ (10 : ℝ) * Λ ^ (-(95 : ℝ)) by
          rw [← Real.rpow_add hΛ0]; norm_num]
        ring
    _ ≤ Λ ^ (1 : ℝ) * Λ ^ (-(85 : ℝ)) := mul_le_mul_of_nonneg_right (hKΛ Λ hΛb) (by positivity)
    _ = Λ ^ (-(84 : ℝ)) := by rw [← Real.rpow_add hΛ0]; norm_num
    _ ≤ Λ ^ (-(80 : ℝ)) := Real.rpow_le_rpow_of_exponent_le (by linarith) (by norm_num)

set_option maxHeartbeats 8000000 in
/-- **LONG-right rough × rough residue** (`B` misses `[X, ⌊s^η⌋]`, `C` misses `J_R`). -/
theorem ResL_physical (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (Jlow Jhigh a h : ℕ) (d : Finset ℕ), Λ₀ ≤ Real.log h → 2 ≤ h →
      |ResLPart Jlow Jhigh q a h δ d| ≤ (Real.log h) ^ (7 / 10 : ℝ) := by
  set K : ℝ := 66 * (4 + 48 * q) with hK
  set Fm : ℝ := 4 + 48 * q with hFm
  obtain ⟨Λ₁, hΛ₁, hro⟩ := rough_ev4
  obtain ⟨Λ₂, hΛ₂, hE1⟩ := GoldC.QuillonAsymp.rpow_le_exp_rpow 2 4 (σ₀ - 1 / 10) (by norm_num)
    (by norm_num) (by unfold σ₀; norm_num)
  obtain ⟨Λ₃, hΛ₃, hE2⟩ := GoldC.QuillonAsymp.rpow_le_exp_rpow 2 2 (σ₀ - 1 / 200) (by norm_num)
    (by norm_num) (by unfold σ₀; norm_num)
  obtain ⟨Λ₄, hΛ₄, hKc⟩ := const_le_rpow K (7 / 10 - (1 / 2000 + 1 / 2 + 1 / 40)) (by norm_num)
  obtain ⟨Λ₅, hΛ₅, hAω⟩ := Aω_le 5 (1 / 100) (by norm_num) (by norm_num)
  obtain ⟨Λ₆, hΛ₆, hex8⟩ := GoldC.QuillonLam.exp_ge 8 2 σ₀ (by norm_num) σ₀_pos
  refine ⟨max 16 (max Λ₁ (max Λ₂ (max Λ₃ (max Λ₄ (max Λ₅ Λ₆))))), by norm_num, ?_⟩
  intro Jlow Jhigh a h d hΛ hh
  have L0 : (16 : ℝ) ≤ Real.log h := le_trans (by simp) hΛ
  have L1 : Λ₁ ≤ Real.log h := le_trans (by simp) hΛ
  have L2 : Λ₂ ≤ Real.log h := le_trans (by simp) hΛ
  have L3 : Λ₃ ≤ Real.log h := le_trans (by simp) hΛ
  have L4 : Λ₄ ≤ Real.log h := le_trans (by simp) hΛ
  have L5 : Λ₅ ≤ Real.log h := le_trans (by simp) hΛ
  have L6 : Λ₆ ≤ Real.log h := le_trans (by simp) hΛ
  clear hΛ
  set Λ := Real.log h with hΛdef
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  set H := h / primeSetProduct d with hH
  set T := Tsrc q h d with hT
  have hTf := Tsrc_facts q h d
  have hHh : H ≤ h := Nat.div_le_self _ _
  have hTf5 : ∀ p ∈ T, 5 ≤ p := fun p hp => (hTf p hp).2.1
  have hTp : ∀ p ∈ T, p.Prime ∧ 5 ≤ p := fun p hp => ⟨(hTf p hp).1, (hTf p hp).2.1⟩
  obtain ⟨hε0, hε1⟩ := GoldC.QuillonCPhysical.εp_le_one (h := h) hΛ1
  set ε := εp h with hεdef
  have hεpos : 0 < ε := by rw [hεdef]; unfold εp; positivity
  set η := ηp h with hηdef
  have hηpos : 0 < η := by rw [hηdef]; unfold ηp; positivity
  have hη1 : η ≤ 1 := by
    rw [hηdef]; unfold ηp; exact Real.rpow_le_one_of_one_le_of_nonpos hΛ1 (by norm_num)
  set R₀ := ⌈Real.exp (4 * Λ ^ σ₀)⌉₊ with hR₀
  have hX1 : 1 ≤ Xp h := by have := Xp_two (h := h) (by linarith); omega
  have hXle := Xp_le (h := h) hΛ1
  have hsq16 : 16 * Λ ≤ Λ ^ (2 : ℝ) := by
    rw [show Λ ^ (2 : ℝ) = Λ * Λ by rw [show (2 : ℝ) = (2 : ℕ) by norm_num, Real.rpow_natCast]; ring]
    nlinarith
  have hubC : 16 * Λ ≤ Real.exp (4 * (ε / 2) * Λ ^ σ₀) := by
    have e : 4 * (ε / 2) * Λ ^ σ₀ = 2 * Λ ^ (σ₀ - 1 / 200) := by
      rw [hεdef]; unfold εp
      rw [show 4 * (Λ ^ (-(1 / 200 : ℝ)) / 2) * Λ ^ σ₀ = 2 * (Λ ^ (-(1 / 200 : ℝ)) * Λ ^ σ₀) by ring,
        rp hΛ0]; ring_nf
    rw [e]; linarith [hE2 Λ L3]
  have hmC := hro h L1 T hTp (Xp h + 1)
    (by push_cast; have : (1 : ℝ) ≤ Λ ^ (200 : ℝ) := Real.one_le_rpow hΛ1 (by norm_num); linarith)
    (ε / 2) (by positivity) (by linarith) hubC
  have hε5 : 1 / (ε / 2) ^ 5 = 32 * Λ ^ (1 / 40 : ℝ) := by
    rw [hεdef]; unfold εp
    rw [div_pow, ← Real.rpow_natCast (Λ ^ (-(1 / 200 : ℝ))) 5, ← Real.rpow_mul hΛ0.le]
    have : Λ ^ (-(1 / 200 : ℝ) * ((5 : ℕ) : ℝ)) * Λ ^ (1 / 40 : ℝ) = 1 := by rw [rp hΛ0]; norm_num
    field_simp
    linarith
  rw [hε5] at hmC
  have h40 : 1 + 32 * Λ ^ (1 / 40 : ℝ) ≤ 33 * Λ ^ (1 / 40 : ℝ) := by
    have : 1 ≤ Λ ^ (1 / 40 : ℝ) := Real.one_le_rpow hΛ1 (by norm_num); linarith
  have hc : ∀ B ∈ T.powerset, ∀ C ∈ T.powerset,
      (B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C ∧
        (MkL Jlow Jhigh h H δ B C ∧
          (¬ longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧
            ¬ (C ∩ JR h T B).Nonempty ∧ ¬ (K0 h ≤ C.card) ∧
            ¬ (((primeSetProduct B : ℕ) : ℝ) < ((primeSetProduct C : ℕ) : ℝ) ^ ((1 : ℝ) / 2 + 3 * ηp h)) ∧
            ¬ (B ∩ (T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ YL h (∏ p ∈ C, p))).Nonempty))) →
      (R₀ ≤ ∏ p ∈ B, p ∧ ∏ p ∈ B, p ≤ h ∧ ∀ p ∈ B, p < Xp h ∨ ((∏ q ∈ B, q : ℕ) : ℝ) ^ η < p) ∧
        (R₀ ≤ ∏ p ∈ C, p ∧ ∏ p ∈ C, p ≤ h ∧
          ∀ p ∈ C, p < Xp h + 1 ∨ ((∏ q ∈ C, q : ℕ) : ℝ) ^ (ε / 2) < p) := by
    intro B hB C hC ⟨_, _, hdisj, hMk, hnL, hJR, _, _, hWR⟩
    have hBT : B ⊆ T := mem_powerset.1 hB
    have hCT : C ⊆ T := mem_powerset.1 hC
    have hCB : C ⊆ T \ B := fun p hp => mem_sdiff.2 ⟨hCT hp, fun hpB => disjoint_left.1 hdisj hpB hp⟩
    have hBC : B ⊆ T \ C := fun p hp => mem_sdiff.2 ⟨hBT hp, fun hpC => disjoint_left.1 hdisj hp hpC⟩
    obtain ⟨g1, g2, -, -, g5, g6⟩ := hMk
    have hG : GeoLR h H δ (∏ p ∈ B, p) (∏ p ∈ C, p) := ⟨g1, g2, g5.resolve_left hnL, g6⟩
    obtain ⟨hlogr, hlogs, hr1, hs1, hrh, hsh, -, hrs, -⟩ := admLR h H _ _ δ hδ0 hh hHh hG
    obtain ⟨-, hsr2, -⟩ := g6
    refine ⟨⟨ceil_le_of_log4 hlogr hr1, by exact_mod_cast hrh, ?_⟩,
      ⟨ceil_le_of_log4 hlogs hs1, by exact_mod_cast hsh, C_rough_of h hΛ1 T B C hCB hJR hr1 hsr2⟩⟩
    intro p hp
    by_cases hpX : p < Xp h
    · exact Or.inl hpX
    · right
      have hpY : YL h (∏ p ∈ C, p) < p := by
        by_contra hc'; push_neg at hc'
        exact hWR ⟨p, mem_inter.2 ⟨hp, mem_filter.2 ⟨hBC hp, not_lt.1 hpX, hc'⟩⟩⟩
      have h1 : ((∏ p ∈ C, p : ℕ) : ℝ) ^ η < p := gt_floor_real (by positivity) hpY
      exact lt_of_le_of_lt (Real.rpow_le_rpow (by positivity) hrs hηpos.le) h1
  have hubB : 16 * Λ ≤ Real.exp (4 * η * Λ ^ σ₀) := by
    have e : 4 * η * Λ ^ σ₀ = 4 * Λ ^ (σ₀ - 1 / 10) := by
      rw [hηdef]; unfold ηp; rw [mul_assoc, rp hΛ0]; ring_nf
    rw [e]; linarith [hE1 Λ L2]
  have hmB := hro h L1 T hTp (Xp h) (by linarith [hXle, show (0 : ℝ) ≤ Λ ^ (200 : ℝ) by positivity])
    η hηpos hη1 hubB
  have hη5 : 1 / η ^ 5 = Λ ^ (1 / 2 : ℝ) := by
    rw [hηdef]; unfold ηp
    rw [← Real.rpow_natCast (Λ ^ (-(1 / 10 : ℝ))) 5, ← Real.rpow_mul hΛ0.le, one_div,
      ← Real.rpow_neg hΛ0.le]
    norm_num
  rw [hη5] at hmB
  unfold ResLPart
  have hmain := dsum_bound T hTf5 _ _ _ hc
    (fun B C => foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C)) Fm
    (by positivity) (fun B C _ => GoldC.QuillonBridge.abs_foldRow_le q a _ H _ _ hq) _
    (fun B _ _ => hmC)
  refine le_trans hmain ?_
  have hKΛ := hKc Λ L4
  have h2 : 1 + Λ ^ (1 / 2 : ℝ) ≤ 2 * Λ ^ (1 / 2 : ℝ) := by
    have : 1 ≤ Λ ^ (1 / 2 : ℝ) := Real.one_le_rpow hΛ1 (by norm_num); linarith
  have hA0 : 0 ≤ ∑ B ∈ T.powerset, (if R₀ ≤ ∏ p ∈ B, p ∧ ∏ p ∈ B, p ≤ h ∧
      ∀ p ∈ B, p < Xp h ∨ ((∏ q ∈ B, q : ℕ) : ℝ) ^ η < p then ωR B else 0) :=
    sum_nonneg fun B hB => by
      split_ifs
      · exact ωR_nonneg B fun p hp => hTf5 p (mem_powerset.1 hB hp)
      · exact le_rfl
  calc Fm * ((∑ B ∈ T.powerset, (if R₀ ≤ ∏ p ∈ B, p ∧ ∏ p ∈ B, p ≤ h ∧
        ∀ p ∈ B, p < Xp h ∨ ((∏ q ∈ B, q : ℕ) : ℝ) ^ η < p then ωR B else 0)) *
        (Λ ^ (1 / 4000 : ℝ) * (1 + 32 * Λ ^ (1 / 40 : ℝ))))
      ≤ Fm * ((Λ ^ (1 / 4000 : ℝ) * (2 * Λ ^ (1 / 2 : ℝ))) *
          (Λ ^ (1 / 4000 : ℝ) * (33 * Λ ^ (1 / 40 : ℝ)))) := by
        apply mul_le_mul_of_nonneg_left _ (by positivity)
        apply mul_le_mul (hmB.trans (mul_le_mul_of_nonneg_left h2 (by positivity)))
          (mul_le_mul_of_nonneg_left h40 (by positivity)) (by positivity) (by positivity)
    _ = K * (Λ ^ (1 / 4000 : ℝ) * Λ ^ (1 / 4000 : ℝ) * Λ ^ (1 / 2 : ℝ) * Λ ^ (1 / 40 : ℝ)) := by
        rw [hK, hFm]; ring
    _ = K * Λ ^ (1 / 2000 + 1 / 2 + 1 / 40 : ℝ) := by rw [rp hΛ0, rp hΛ0, rp hΛ0]; norm_num
    _ ≤ Λ ^ (7 / 10 - (1 / 2000 + 1 / 2 + 1 / 40) : ℝ) * Λ ^ (1 / 2000 + 1 / 2 + 1 / 40 : ℝ) :=
        mul_le_mul_of_nonneg_right hKΛ (by positivity)
    _ = Λ ^ (7 / 10 : ℝ) := by rw [rp hΛ0]; norm_num

set_option maxHeartbeats 8000000 in
/-- **LONG-right edge** (`r < s^{1/2+3η}`, `C` misses `J_R`): rough `C` × thin `B` window. -/
theorem EdgeL_physical (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (Jlow Jhigh a h : ℕ) (d : Finset ℕ), Λ₀ ≤ Real.log h → 2 ≤ h →
      |EdgeLPart Jlow Jhigh q a h δ d| ≤ (Real.log h) ^ (19 / 20 : ℝ) := by
  set K : ℝ := 165 * (4 + 48 * q) with hK
  set Fm : ℝ := 4 + 48 * q with hFm
  obtain ⟨Λ₁, hΛ₁, hro⟩ := rough_ev4
  obtain ⟨Λ₂, hΛ₂, hE1⟩ := GoldC.QuillonAsymp.rpow_le_exp_rpow 2 4 (σ₀ - 1 / 10) (by norm_num)
    (by norm_num) (by unfold σ₀; norm_num)
  obtain ⟨Λ₃, hΛ₃, hE2⟩ := GoldC.QuillonAsymp.rpow_le_exp_rpow 2 2 (σ₀ - 1 / 200) (by norm_num)
    (by norm_num) (by unfold σ₀; norm_num)
  obtain ⟨Λ₄, hΛ₄, hKc⟩ := const_le_rpow K (19 / 20 - (1 / 4000 + 1 / 40 + 1 / 100 + 9 / 10)) (by norm_num)
  obtain ⟨Λ₅, hΛ₅, hAω⟩ := Aω_le 5 (1 / 100) (by norm_num) (by norm_num)
  obtain ⟨Λ₆, hΛ₆, hex8⟩ := GoldC.QuillonLam.exp_ge 8 2 σ₀ (by norm_num) σ₀_pos
  obtain ⟨Λ₇, hΛ₇, hyl⟩ := yl_ev
  refine ⟨max 16 (max Λ₁ (max Λ₂ (max Λ₃ (max Λ₄ (max Λ₅ (max Λ₆ Λ₇)))))), by norm_num, ?_⟩
  intro Jlow Jhigh a h d hΛ hh
  have L0 : (16 : ℝ) ≤ Real.log h := le_trans (by simp) hΛ
  have L1 : Λ₁ ≤ Real.log h := le_trans (by simp) hΛ
  have L2 : Λ₂ ≤ Real.log h := le_trans (by simp) hΛ
  have L3 : Λ₃ ≤ Real.log h := le_trans (by simp) hΛ
  have L4 : Λ₄ ≤ Real.log h := le_trans (by simp) hΛ
  have L5 : Λ₅ ≤ Real.log h := le_trans (by simp) hΛ
  have L6 : Λ₆ ≤ Real.log h := le_trans (by simp) hΛ
  have L7 : Λ₇ ≤ Real.log h := le_trans (by simp) hΛ
  clear hΛ
  set Λ := Real.log h with hΛdef
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  set H := h / primeSetProduct d with hH
  set T := Tsrc q h d with hT
  have hTf := Tsrc_facts q h d
  have hHh : H ≤ h := Nat.div_le_self _ _
  have hTf5 : ∀ p ∈ T, 5 ≤ p := fun p hp => (hTf p hp).2.1
  have hTp : ∀ p ∈ T, p.Prime ∧ 5 ≤ p := fun p hp => ⟨(hTf p hp).1, (hTf p hp).2.1⟩
  obtain ⟨hε0, hε1⟩ := GoldC.QuillonCPhysical.εp_le_one (h := h) hΛ1
  set ε := εp h with hεdef
  have hεpos : 0 < ε := by rw [hεdef]; unfold εp; positivity
  set η := ηp h with hηdef
  have hηpos : 0 < η := by rw [hηdef]; unfold ηp; positivity
  have hη1 : η ≤ 1 := by
    rw [hηdef]; unfold ηp; exact Real.rpow_le_one_of_one_le_of_nonpos hΛ1 (by norm_num)
  set R₀ := ⌈Real.exp (4 * Λ ^ σ₀)⌉₊ with hR₀
  have hX1 : 1 ≤ Xp h := by have := Xp_two (h := h) (by linarith); omega
  have hXle := Xp_le (h := h) hΛ1
  have hsq16 : 16 * Λ ≤ Λ ^ (2 : ℝ) := by
    rw [show Λ ^ (2 : ℝ) = Λ * Λ by rw [show (2 : ℝ) = (2 : ℕ) by norm_num, Real.rpow_natCast]; ring]
    nlinarith
  have hubC : 16 * Λ ≤ Real.exp (4 * (ε / 2) * Λ ^ σ₀) := by
    have e : 4 * (ε / 2) * Λ ^ σ₀ = 2 * Λ ^ (σ₀ - 1 / 200) := by
      rw [hεdef]; unfold εp
      rw [show 4 * (Λ ^ (-(1 / 200 : ℝ)) / 2) * Λ ^ σ₀ = 2 * (Λ ^ (-(1 / 200 : ℝ)) * Λ ^ σ₀) by ring,
        rp hΛ0]; ring_nf
    rw [e]; linarith [hE2 Λ L3]
  have hmC := hro h L1 T hTp (Xp h + 1)
    (by push_cast; have : (1 : ℝ) ≤ Λ ^ (200 : ℝ) := Real.one_le_rpow hΛ1 (by norm_num); linarith)
    (ε / 2) (by positivity) (by linarith) hubC
  have hε5 : 1 / (ε / 2) ^ 5 = 32 * Λ ^ (1 / 40 : ℝ) := by
    rw [hεdef]; unfold εp
    rw [div_pow, ← Real.rpow_natCast (Λ ^ (-(1 / 200 : ℝ))) 5, ← Real.rpow_mul hΛ0.le]
    have : Λ ^ (-(1 / 200 : ℝ) * ((5 : ℕ) : ℝ)) * Λ ^ (1 / 40 : ℝ) = 1 := by rw [rp hΛ0]; norm_num
    field_simp
    linarith
  rw [hε5] at hmC
  have h40 : 1 + 32 * Λ ^ (1 / 40 : ℝ) ≤ 33 * Λ ^ (1 / 40 : ℝ) := by
    have : 1 ≤ Λ ^ (1 / 40 : ℝ) := Real.one_le_rpow hΛ1 (by norm_num); linarith
  have hc : ∀ B ∈ T.powerset, ∀ C ∈ T.powerset,
      (B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C ∧
        (MkL Jlow Jhigh h H δ B C ∧
          (¬ longInverseLeft δ (primeSetProduct B) (primeSetProduct C) ∧
            ¬ (C ∩ JR h T B).Nonempty ∧ ¬ (K0 h ≤ C.card) ∧
            ((primeSetProduct B : ℕ) : ℝ) < ((primeSetProduct C : ℕ) : ℝ) ^ ((1 : ℝ) / 2 + 3 * ηp h)))) →
      (R₀ ≤ ∏ p ∈ C, p ∧ ∏ p ∈ C, p ≤ h ∧
          ∀ p ∈ C, p < Xp h + 1 ∨ ((∏ q ∈ C, q : ℕ) : ℝ) ^ (ε / 2) < p) ∧
        (∏ p ∈ B, p) ∈ Ioc (⌊((∏ p ∈ C, p : ℕ) : ℝ) ^ ((1 : ℝ) / 2)⌋₊ - 1)
          ⌊((∏ p ∈ C, p : ℕ) : ℝ) ^ ((1 : ℝ) / 2 + 3 * η)⌋₊ := by
    intro B hB C hC ⟨_, _, hdisj, hMk, hnL, hJR, _, hEd⟩
    have hBT : B ⊆ T := mem_powerset.1 hB
    have hCT : C ⊆ T := mem_powerset.1 hC
    have hCB : C ⊆ T \ B := fun p hp => mem_sdiff.2 ⟨hCT hp, fun hpB => disjoint_left.1 hdisj hpB hp⟩
    obtain ⟨g1, g2, -, -, g5, g6⟩ := hMk
    have hG : GeoLR h H δ (∏ p ∈ B, p) (∏ p ∈ C, p) := ⟨g1, g2, g5.resolve_left hnL, g6⟩
    obtain ⟨hlogr, hlogs, hr1, hs1, hrh, hsh, -, hrs, -⟩ := admLR h H _ _ δ hδ0 hh hHh hG
    obtain ⟨-, hsr2, -⟩ := g6
    refine ⟨⟨ceil_le_of_log4 hlogs hs1, by exact_mod_cast hsh, C_rough_of h hΛ1 T B C hCB hJR hr1 hsr2⟩, ?_⟩
    have hsr : ((∏ p ∈ C, p : ℕ) : ℝ) ^ ((1 : ℝ) / 2) ≤ ((∏ p ∈ B, p : ℕ) : ℝ) := by
      have h2r : ((∏ p ∈ C, p : ℕ) : ℝ) ≤ ((∏ p ∈ B, p : ℕ) : ℝ) ^ 2 := by exact_mod_cast hsr2
      calc ((∏ p ∈ C, p : ℕ) : ℝ) ^ ((1 : ℝ) / 2) ≤ (((∏ p ∈ B, p : ℕ) : ℝ) ^ 2) ^ ((1 : ℝ) / 2) :=
            Real.rpow_le_rpow (by positivity) h2r (by norm_num)
        _ = ((∏ p ∈ B, p : ℕ) : ℝ) := by
            rw [← Real.rpow_natCast, ← Real.rpow_mul (by positivity)]; norm_num
    have hfl : ⌊((∏ p ∈ C, p : ℕ) : ℝ) ^ ((1 : ℝ) / 2)⌋₊ ≤ ∏ p ∈ B, p := Nat.floor_le_of_le hsr
    exact mem_Ioc.2 ⟨by omega, Nat.le_floor hEd.le⟩
  have hIM : ∀ C ∈ T.powerset, (R₀ ≤ ∏ p ∈ C, p ∧ ∏ p ∈ C, p ≤ h ∧
        ∀ p ∈ C, p < Xp h + 1 ∨ ((∏ q ∈ C, q : ℕ) : ℝ) ^ (ε / 2) < p) →
      ∑ B ∈ T.powerset, (if (∏ p ∈ B, p) ∈ Ioc (⌊((∏ p ∈ C, p : ℕ) : ℝ) ^ ((1 : ℝ) / 2)⌋₊ - 1)
          ⌊((∏ p ∈ C, p : ℕ) : ℝ) ^ ((1 : ℝ) / 2 + 3 * η)⌋₊ then ωR B else 0) ≤
        Λ ^ (1 / 100 : ℝ) * (2 + 3 * Λ ^ (9 / 10 : ℝ)) := by
    intro C _ ⟨hR, hsh, _⟩
    have hR1 : 1 ≤ R₀ := Nat.ceil_pos.2 (Real.exp_pos _)
    have hs1 : 1 ≤ ∏ p ∈ C, p := le_trans hR1 hR
    have hs0 : (0 : ℝ) < ((∏ p ∈ C, p : ℕ) : ℝ) := by exact_mod_cast hs1
    have hs1R : (1 : ℝ) ≤ ((∏ p ∈ C, p : ℕ) : ℝ) := by exact_mod_cast hs1
    have hlogs : 4 * Λ ^ σ₀ ≤ Real.log ((∏ p ∈ C, p : ℕ) : ℝ) := by
      have h1 : Real.exp (4 * Λ ^ σ₀) ≤ ((∏ p ∈ C, p : ℕ) : ℝ) :=
        le_trans (Nat.le_ceil _) (by exact_mod_cast hR)
      have := Real.log_le_log (Real.exp_pos _) h1
      rwa [Real.log_exp] at this
    have hlogs_le : Real.log ((∏ p ∈ C, p : ℕ) : ℝ) ≤ Λ :=
      Real.log_le_log hs0 (by exact_mod_cast hsh)
    obtain ⟨-, hη8, -, -⟩ := hyl Λ L7 (∏ p ∈ C, p) hs1 hlogs
    have hη8' : η ≤ 1 / 8 := hη8
    set u := ((∏ p ∈ C, p : ℕ) : ℝ) ^ ((1 : ℝ) / 2) with hu
    set v := ((∏ p ∈ C, p : ℕ) : ℝ) ^ ((1 : ℝ) / 2 + 3 * η) with hv
    set w := ((∏ p ∈ C, p : ℕ) : ℝ) ^ (3 * η) with hw
    have hvuw : v = u * w := by rw [hv, hu, hw, ← Real.rpow_add hs0]
    have hw1 : 1 ≤ w := Real.one_le_rpow hs1R (by positivity)
    have hu8 : 8 ≤ u := by
      have e1 : u = Real.exp (Real.log ((∏ p ∈ C, p : ℕ) : ℝ) * (1 / 2)) := Real.rpow_def_of_pos hs0 _
      rw [e1]
      exact le_trans (hex8 Λ L6) (Real.exp_le_exp.2 (by linarith))
    have huv : u ≤ v := by rw [hvuw]; nlinarith
    have hvs : v ≤ ((∏ p ∈ C, p : ℕ) : ℝ) := by
      calc v ≤ ((∏ p ∈ C, p : ℕ) : ℝ) ^ (1 : ℝ) := Real.rpow_le_rpow_of_exponent_le hs1R (by linarith)
        _ = _ := Real.rpow_one _
    have hfl8 : 8 ≤ ⌊u⌋₊ := Nat.le_floor (by push_cast; exact hu8)
    have ha1 : 1 ≤ ⌊u⌋₊ - 1 := by omega
    have hab : ⌊u⌋₊ - 1 ≤ ⌊v⌋₊ := le_trans (Nat.sub_le _ _) (Nat.floor_mono huv)
    have im := GoldC.QuillonResidue.interval_mass T hTp (⌊u⌋₊ - 1) ⌊v⌋₊ ha1 hab
    have hbR : (⌊v⌋₊ : ℝ) ≤ v := Nat.floor_le (by positivity)
    have hb1 : 1 ≤ ⌊v⌋₊ := le_trans ha1 hab
    have hb0 : (0 : ℝ) < ⌊v⌋₊ := by exact_mod_cast hb1
    have hlogb : Real.log (⌊v⌋₊ : ℝ) ≤ 5 * Λ := by
      have := Real.log_le_log hb0 (hbR.trans hvs); linarith
    have hA := hAω Λ L5 ⌊v⌋₊ hlogb
    have hfu := Nat.lt_floor_add_one u
    have haR : u / 2 ≤ ((⌊u⌋₊ - 1 : ℕ) : ℝ) := by
      rw [Nat.cast_sub (by omega : 1 ≤ ⌊u⌋₊)]; push_cast; linarith
    have hapos : (0 : ℝ) < ((⌊u⌋₊ - 1 : ℕ) : ℝ) := by exact_mod_cast ha1
    have hba : (⌊v⌋₊ : ℝ) / ((⌊u⌋₊ - 1 : ℕ) : ℝ) ≤ 2 * w := by
      rw [div_le_iff₀ hapos]
      calc (⌊v⌋₊ : ℝ) ≤ u * w := hbR.trans (le_of_eq hvuw)
        _ ≤ (2 * ((⌊u⌋₊ - 1 : ℕ) : ℝ)) * w := mul_le_mul_of_nonneg_right (by linarith) (by linarith)
        _ = 2 * w * ((⌊u⌋₊ - 1 : ℕ) : ℝ) := by ring
    have hbapos : (0 : ℝ) < (⌊v⌋₊ : ℝ) / ((⌊u⌋₊ - 1 : ℕ) : ℝ) := div_pos hb0 hapos
    have hηΛ : η * Λ = Λ ^ (9 / 10 : ℝ) := by
      rw [hηdef]; unfold ηp
      rw [show Λ ^ (-(1 / 10 : ℝ)) * Λ = Λ ^ (-(1 / 10 : ℝ)) * Λ ^ (1 : ℝ) by rw [Real.rpow_one], rp hΛ0]
      norm_num
    have hlog : Real.log ((⌊v⌋₊ : ℝ) / ((⌊u⌋₊ - 1 : ℕ) : ℝ)) ≤ 1 + 3 * Λ ^ (9 / 10 : ℝ) := by
      have h1 := Real.log_le_log hbapos hba
      rw [Real.log_mul (by norm_num) (by positivity), hw, Real.log_rpow hs0] at h1
      have hl2 : Real.log 2 ≤ 1 := by have := Real.log_two_lt_d9; linarith
      have : 3 * η * Real.log ((∏ p ∈ C, p : ℕ) : ℝ) ≤ 3 * (η * Λ) := by
        have := mul_le_mul_of_nonneg_left hlogs_le hηpos.le; linarith
      rw [hηΛ] at this
      linarith
    have hlog0 : 0 ≤ Real.log ((⌊v⌋₊ : ℝ) / ((⌊u⌋₊ - 1 : ℕ) : ℝ)) := by
      apply Real.log_nonneg
      rw [le_div_iff₀ hapos, one_mul]; exact_mod_cast hab
    calc _ ≤ _ := im
      _ ≤ Λ ^ (1 / 100 : ℝ) * (2 + 3 * Λ ^ (9 / 10 : ℝ)) :=
          mul_le_mul hA (by linarith) (by linarith) (by positivity)
  unfold EdgeLPart
  have hmain := dsum_bound_swap T hTf5 _ _ _ hc
    (fun B C => foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C)) Fm
    (by positivity) (fun B C _ => GoldC.QuillonBridge.abs_foldRow_le q a _ H _ _ hq) _ hIM
  refine le_trans hmain ?_
  have hKΛ := hKc Λ L4
  have h9 : 2 + 3 * Λ ^ (9 / 10 : ℝ) ≤ 5 * Λ ^ (9 / 10 : ℝ) := by
    have : 1 ≤ Λ ^ (9 / 10 : ℝ) := Real.one_le_rpow hΛ1 (by norm_num); linarith
  calc _ ≤ Fm * ((Λ ^ (1 / 4000 : ℝ) * (33 * Λ ^ (1 / 40 : ℝ))) *
          (Λ ^ (1 / 100 : ℝ) * (5 * Λ ^ (9 / 10 : ℝ)))) := by
        apply mul_le_mul_of_nonneg_left _ (by positivity)
        apply mul_le_mul (hmC.trans (mul_le_mul_of_nonneg_left h40 (by positivity)))
          (mul_le_mul_of_nonneg_left h9 (by positivity)) (by positivity) (by positivity)
    _ = K * (Λ ^ (1 / 4000 : ℝ) * Λ ^ (1 / 40 : ℝ) * Λ ^ (1 / 100 : ℝ) * Λ ^ (9 / 10 : ℝ)) := by
        rw [hK, hFm]; ring
    _ = K * Λ ^ (1 / 4000 + 1 / 40 + 1 / 100 + 9 / 10 : ℝ) := by rw [rp hΛ0, rp hΛ0, rp hΛ0]
    _ ≤ Λ ^ (19 / 20 - (1 / 4000 + 1 / 40 + 1 / 100 + 9 / 10) : ℝ) *
          Λ ^ (1 / 4000 + 1 / 40 + 1 / 100 + 9 / 10 : ℝ) :=
        mul_le_mul_of_nonneg_right hKΛ (by positivity)
    _ = Λ ^ (19 / 20 : ℝ) := by rw [rp hΛ0]; norm_num

end GoldC.QuillonLRP

#print axioms GoldC.QuillonLRP.ManyL_physical
#print axioms GoldC.QuillonLRP.WRL_physical
#print axioms GoldC.QuillonLRP.ResL_physical
#print axioms GoldC.QuillonLRP.EdgeL_physical
