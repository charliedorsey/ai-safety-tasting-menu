import PaperB.FixedQ.H2EndpointDyadic
import PaperB.FixedQ.H2BooleanRateNormalization

open scoped BigOperators
open Filter Real Asymptotics

namespace PaperB.FixedQ

noncomputable def h2EndpointDyadicThreshold (q M0 : ℕ) : ℕ :=
  max M0 (max 2 ((6 * q) ^ 4 + 1))

lemma h2Endpoint_quarter_condition
    {M : ℕ} (hM : 2 ≤ M) :
    ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) := by
  have hnat : 2 * M < M ^ 4 := by
    have hM2 : 2 * M ≤ M * M := by nlinarith
    have hMpos : 0 < M := by omega
    have hM2lt : M * M < M ^ 4 := by
      have hMpow : M * M < (M * M) * (M * M) := by
        nlinarith
      simpa [pow_two, pow_succ, mul_assoc] using hMpow
    omega
  have hcast : ((2 * M : ℕ) : ℝ) < (((M ^ 4 : ℕ) : ℝ)) := by
    exact_mod_cast hnat
  have hr := Real.rpow_lt_rpow
    (show (0 : ℝ) ≤ ((2 * M : ℕ) : ℝ) by positivity)
    hcast (by norm_num : (0 : ℝ) < 1 / 4)
  have hM0 : (0 : ℝ) ≤ (M : ℝ) := by positivity
  have hroot : ((((M ^ 4 : ℕ) : ℝ))) ^ (1 / 4 : ℝ) = (M : ℝ) := by
    norm_num only [Nat.cast_pow]
    rw [← Real.rpow_natCast]
    rw [← Real.rpow_mul hM0]
    norm_num
  rw [hroot] at hr
  simpa using hr

lemma h2Endpoint_three_quarter_condition
    {q M : ℕ} (hM : (6 * q) ^ 4 + 1 ≤ M) :
    ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) := by
  have hnat : (6 * q) ^ 4 < M ^ 3 := by
    have h1 : (6 * q) ^ 4 < M := by omega
    have hM1 : 1 ≤ M := by omega
    have hMM : M ≤ M ^ 3 := by
      calc
        M = M * 1 := by ring
        _ ≤ M * (M * M) := by
          gcongr
          nlinarith
        _ = M ^ 3 := by ring
    exact lt_of_lt_of_le h1 hMM
  have hcast :
      ((((6 * q) ^ 4 : ℕ) : ℝ)) < (((M ^ 3 : ℕ) : ℝ)) := by
    exact_mod_cast hnat
  have hr := Real.rpow_lt_rpow
    (show (0 : ℝ) ≤ (((6 * q) ^ 4 : ℕ) : ℝ) by positivity)
    hcast (by norm_num : (0 : ℝ) < 1 / 4)
  have hq0 : (0 : ℝ) ≤ ((6 * q : ℕ) : ℝ) := by positivity
  have hM0 : (0 : ℝ) ≤ (M : ℝ) := by positivity
  have hleft :
      ((((6 * q) ^ 4 : ℕ) : ℝ)) ^ (1 / 4 : ℝ) =
        ((6 * q : ℕ) : ℝ) := by
    norm_num only [Nat.cast_pow]
    rw [← Real.rpow_natCast]
    rw [← Real.rpow_mul hq0]
    norm_num
  have hright :
      ((((M ^ 3 : ℕ) : ℝ)) ^ (1 / 4 : ℝ)) =
        (M : ℝ) ^ (3 / 4 : ℝ) := by
    norm_num only [Nat.cast_pow]
    rw [← Real.rpow_natCast]
    rw [← Real.rpow_mul hM0]
    norm_num
  rw [hleft, hright] at hr
  simpa using hr

lemma h2Endpoint_log_two_mul_le_two_mul
    {M : ℕ} (hM : 1 ≤ M) :
    Real.log ((2 * M : ℕ) : ℝ) ≤ (2 * M : ℕ) := by
  have hx : (0 : ℝ) < ((2 * M : ℕ) : ℝ) := by positivity
  have hlog := Real.log_le_sub_one_of_pos hx
  have hcast : (1 : ℝ) ≤ ((2 * M : ℕ) : ℝ) := by
    exact_mod_cast (show 1 ≤ 2 * M by omega)
  linarith

noncomputable def h2EndpointInitialShellConst (q B : ℕ) : ℝ :=
  h2EndpointDyadicConst q *
    ∑ M ∈ Finset.Icc 1 B,
      ∑ S ∈ h2BooleanDyadicSets q M,
        finiteOmegaWeightReal S * h2BooleanX0 ^ S.card

lemma h2EndpointInitialShellConst_nonneg (q B : ℕ) :
    0 ≤ h2EndpointInitialShellConst q B := by
  unfold h2EndpointInitialShellConst
  apply mul_nonneg (h2EndpointDyadicConst_nonneg q)
  apply Finset.sum_nonneg
  intro M hM
  apply Finset.sum_nonneg
  intro S hS
  exact mul_nonneg
    (finiteOmegaWeightReal_nonneg_of_active
      (h2BooleanDyadicSets_active hS))
    (pow_nonneg h2BooleanX0_nonneg _)

lemma h2EndpointDyadicShell_le_initialConst
    {q A H B M : ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H)
    (hM1 : 1 ≤ M) (hMB : M ≤ B) :
    h2EndpointDyadicShell q A H M ≤
      h2EndpointInitialShellConst q B := by
  have hshell := h2EndpointDyadicShell_le_firstMoment
    (q := q) (A := A) (H := H) (M := M) hq hH h2admissible
  unfold h2EndpointInitialShellConst
  apply hshell.trans
  apply mul_le_mul_of_nonneg_left _ (h2EndpointDyadicConst_nonneg q)
  have hnon :
      ∀ M' ∈ Finset.Icc 1 B,
        0 ≤ ∑ S ∈ h2BooleanDyadicSets q M',
          finiteOmegaWeightReal S * h2BooleanX0 ^ S.card := by
    intro M' hM'
    apply Finset.sum_nonneg
    intro S hS
    exact mul_nonneg
      (finiteOmegaWeightReal_nonneg_of_active
        (h2BooleanDyadicSets_active hS))
      (pow_nonneg h2BooleanX0_nonneg _)
  exact Finset.single_le_sum
    (s := Finset.Icc 1 B)
    (f := fun M' => ∑ S ∈ h2BooleanDyadicSets q M',
      finiteOmegaWeightReal S * h2BooleanX0 ^ S.card)
    hnon (Finset.mem_Icc.mpr ⟨hM1, hMB⟩)

theorem h2EndpointDyadicShell_polynomial
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ A H M : ℕ,
      0 < H →
      (¬ 2 ∣ q → 2 ∣ H) →
      1 ≤ M →
      h2EndpointDyadicShell q A H M ≤
        C * (M : ℝ) ^ (h2BooleanX0 - 1) := by
  rcases h2EndpointDyadicShell_log_power q hq with
    ⟨C0, M0, hlarge⟩
  let B := h2EndpointDyadicThreshold q M0
  let Csmall := h2EndpointInitialShellConst q B
  let Clarge := |C0| * (2 : ℝ) ^ (h2BooleanX0 - 1)
  let C := Csmall + Clarge
  have halpha : 0 ≤ h2BooleanX0 - 1 :=
    sub_nonneg.mpr h2BooleanX0_one_le
  have hCs : 0 ≤ Csmall := h2EndpointInitialShellConst_nonneg q B
  have hCl : 0 ≤ Clarge := by
    dsimp [Clarge]
    positivity
  refine ⟨C, add_nonneg hCs hCl, ?_⟩
  intro A H M hH h2admissible hM1
  by_cases hMB : M ≤ B
  · have hs := h2EndpointDyadicShell_le_initialConst
      (q := q) (A := A) (H := H) (B := B) (M := M)
      hq hH h2admissible hM1 hMB
    have hpow1 : (1 : ℝ) ≤ (M : ℝ) ^ (h2BooleanX0 - 1) :=
      Real.one_le_rpow (by exact_mod_cast hM1) halpha
    calc
      h2EndpointDyadicShell q A H M ≤ Csmall := hs
      _ ≤ Csmall * (M : ℝ) ^ (h2BooleanX0 - 1) := by
        simpa using mul_le_mul_of_nonneg_left hpow1 hCs
      _ ≤ C * (M : ℝ) ^ (h2BooleanX0 - 1) := by
        apply mul_le_mul_of_nonneg_right _ (Real.rpow_nonneg (by positivity) _)
        dsimp [C]
        linarith
  · have hBM : B ≤ M := by omega
    have hM0 : M0 ≤ M := by
      dsimp [B, h2EndpointDyadicThreshold] at hBM
      exact (le_max_left M0 (max 2 ((6 * q) ^ 4 + 1))).trans hBM
    have hM2 : 2 ≤ M := by
      dsimp [B, h2EndpointDyadicThreshold] at hBM
      exact (le_trans (le_max_left 2 ((6 * q) ^ 4 + 1))
        ((le_max_right M0 (max 2 ((6 * q) ^ 4 + 1))).trans hBM))
    have hMq : (6 * q) ^ 4 + 1 ≤ M := by
      dsimp [B, h2EndpointDyadicThreshold] at hBM
      exact (le_trans (le_max_right 2 ((6 * q) ^ 4 + 1))
        ((le_max_right M0 (max 2 ((6 * q) ^ 4 + 1))).trans hBM))
    have hs := hlarge A H M hH h2admissible hM0
      (h2Endpoint_quarter_condition hM2)
      (h2Endpoint_three_quarter_condition hMq)
    have hlog0 : 0 ≤ Real.log ((2 * M : ℕ) : ℝ) := by
      apply Real.log_nonneg
      exact_mod_cast (show 1 ≤ 2 * M by omega)
    have hlogle := h2Endpoint_log_two_mul_le_two_mul hM1
    have hrpow :
        (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) ≤
          ((2 * M : ℕ) : ℝ) ^ (h2BooleanX0 - 1) :=
      Real.rpow_le_rpow hlog0 hlogle halpha
    have hmul :
        (((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) =
          (2 : ℝ) ^ (h2BooleanX0 - 1) *
            (M : ℝ) ^ (h2BooleanX0 - 1) := by
      norm_num only [Nat.cast_mul, Nat.cast_ofNat]
      rw [Real.mul_rpow (by norm_num) (by positivity)]
    have hs' :
        h2EndpointDyadicShell q A H M ≤
          |C0| * (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) := by
      exact hs.trans (mul_le_mul_of_nonneg_right
        (le_abs_self C0) (Real.rpow_nonneg hlog0 _))
    calc
      h2EndpointDyadicShell q A H M
        ≤ |C0| * (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) := hs'
      _ ≤ |C0| * (((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) :=
        mul_le_mul_of_nonneg_left hrpow (abs_nonneg _)
      _ = Clarge * (M : ℝ) ^ (h2BooleanX0 - 1) := by
        rw [hmul]
        dsimp [Clarge]
        ring
      _ ≤ C * (M : ℝ) ^ (h2BooleanX0 - 1) := by
        apply mul_le_mul_of_nonneg_right _ (Real.rpow_nonneg (by positivity) _)
        dsimp [C]
        linarith

#print axioms h2Endpoint_quarter_condition
#print axioms h2Endpoint_three_quarter_condition
#print axioms h2EndpointDyadicShell_polynomial

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def h2EndpointSmallProductSets (q N : ℕ) : Finset (Finset ℕ) :=
  ((h2BooleanActivePrimesLE q N).powerset).filter
    (fun S => S.Nonempty ∧ primeSetProduct S ≤ N)

noncomputable def h2EndpointSmallProductFamily
    (q A H N : ℕ) : ℝ :=
  ∑ S ∈ h2EndpointSmallProductSets q N,
    (ordinaryBooleanFullEndpointAbsTerm q A H S +
      ordinaryBooleanEmptyEndpointAbsTerm q A H S)

lemma h2EndpointSmallProductSets_active
    {q N : ℕ} {S : Finset ℕ}
    (hS : S ∈ h2EndpointSmallProductSets q N) :
    ∀ p ∈ S, activeHighPrime q p := by
  intro p hp
  have hsub := Finset.mem_powerset.mp (Finset.mem_filter.mp hS).1
  exact (Finset.mem_filter.mp (hsub hp)).2

lemma h2EndpointSmallProductSets_nonempty
    {q N : ℕ} {S : Finset ℕ}
    (hS : S ∈ h2EndpointSmallProductSets q N) :
    S.Nonempty :=
  (Finset.mem_filter.mp hS).2.1

lemma h2EndpointSmallProductSets_product_le
    {q N : ℕ} {S : Finset ℕ}
    (hS : S ∈ h2EndpointSmallProductSets q N) :
    primeSetProduct S ≤ N :=
  (Finset.mem_filter.mp hS).2.2

lemma h2EndpointSmallProductSets_product_ge_five
    {q N : ℕ} {S : Finset ℕ}
    (hS : S ∈ h2EndpointSmallProductSets q N) :
    5 ≤ primeSetProduct S := by
  rcases h2EndpointSmallProductSets_nonempty hS with ⟨p, hp⟩
  have hA := h2EndpointSmallProductSets_active hS p hp
  have hprodpos : 0 < primeSetProduct S :=
    primeSetProduct_pos
      (fun r hr => (h2EndpointSmallProductSets_active hS r hr).1)
  have hdiv : p ∣ primeSetProduct S := by
    unfold primeSetProduct
    exact Finset.dvd_prod_of_mem (fun x : ℕ => x) hp
  exact hA.2.1.trans (Nat.le_of_dvd hprodpos hdiv)

lemma h2EndpointSmallProductSets_mem_dyadic
    {q N : ℕ} {S : Finset ℕ}
    (hS : S ∈ h2EndpointSmallProductSets q N) :
    S ∈ h2BooleanDyadicSets q (primeSetProduct S - 1) := by
  let m := primeSetProduct S
  have hm5 : 5 ≤ m := by
    simpa [m] using h2EndpointSmallProductSets_product_ge_five hS
  have hActive := h2EndpointSmallProductSets_active hS
  have hPrime : ∀ p ∈ S, p.Prime := fun p hp => (hActive p hp).1
  have hmpos : 0 < m := primeSetProduct_pos hPrime
  unfold h2BooleanDyadicSets
  apply Finset.mem_filter.mpr
  constructor
  · apply Finset.mem_powerset.mpr
    intro p hp
    apply Finset.mem_filter.mpr
    constructor
    · apply Nat.mem_primesLE.mpr
      constructor
      · have hpdiv : p ∣ m := by
          dsimp [m, primeSetProduct]
          exact Finset.dvd_prod_of_mem (fun x : ℕ => x) hp
        have hpm : p ≤ m := Nat.le_of_dvd hmpos hpdiv
        have hm2 : m ≤ 2 * (m - 1) := by omega
        omega
      · exact hPrime p hp
    · exact hActive p hp
  · constructor <;> omega

lemma h2EndpointSmallProductSets_key_injective
    {q N : ℕ} :
    Set.InjOn (fun S : Finset ℕ => primeSetProduct S - 1)
      {S | S ∈ h2EndpointSmallProductSets q N} := by
  intro S hS T hT hkey
  change S ∈ h2EndpointSmallProductSets q N at hS
  change T ∈ h2EndpointSmallProductSets q N at hT
  have hmS : 5 ≤ primeSetProduct S :=
    h2EndpointSmallProductSets_product_ge_five hS
  have hmT : 5 ≤ primeSetProduct T :=
    h2EndpointSmallProductSets_product_ge_five hT
  change primeSetProduct S - 1 = primeSetProduct T - 1 at hkey
  have hSsub : (primeSetProduct S - 1) + 1 = primeSetProduct S :=
    Nat.sub_add_cancel (by omega)
  have hTsub : (primeSetProduct T - 1) + 1 = primeSetProduct T :=
    Nat.sub_add_cancel (by omega)
  have hprod : primeSetProduct S = primeSetProduct T := by
    calc
      primeSetProduct S = (primeSetProduct S - 1) + 1 := hSsub.symm
      _ = (primeSetProduct T - 1) + 1 := by rw [hkey]
      _ = primeSetProduct T := hTsub
  have hPrimeS : ∀ p ∈ S, p.Prime :=
    fun p hp => (h2EndpointSmallProductSets_active hS p hp).1
  have hPrimeT : ∀ p ∈ T, p.Prime :=
    fun p hp => (h2EndpointSmallProductSets_active hT p hp).1
  have hpfS : (primeSetProduct S).primeFactors = S := by
    unfold primeSetProduct
    exact Nat.primeFactors_prod hPrimeS
  have hpfT : (primeSetProduct T).primeFactors = T := by
    unfold primeSetProduct
    exact Nat.primeFactors_prod hPrimeT
  rw [← hpfS, ← hpfT, hprod]

lemma h2EndpointCombinedTerm_nonneg_of_active
    {q A H : ℕ} {S : Finset ℕ}
    (hActive : ∀ p ∈ S, activeHighPrime q p) :
    0 ≤ ordinaryBooleanFullEndpointAbsTerm q A H S +
      ordinaryBooleanEmptyEndpointAbsTerm q A H S := by
  have hw0 : 0 ≤ finiteOmegaWeightReal S :=
    finiteOmegaWeightReal_nonneg_of_active hActive
  by_cases hmem : S ∈ activeOrdinaryTwoDimensionalSet q H
  · rw [ordinaryBooleanFullEndpointAbsTerm, Set.indicator_of_mem hmem]
    rw [ordinaryBooleanEmptyEndpointAbsTerm, Set.indicator_of_mem hmem]
    positivity
  · simp [ordinaryBooleanFullEndpointAbsTerm,
      ordinaryBooleanEmptyEndpointAbsTerm, Set.indicator, hmem]

lemma h2EndpointDyadicShell_nonneg
    (q A H M : ℕ) :
    0 ≤ h2EndpointDyadicShell q A H M := by
  unfold h2EndpointDyadicShell
  apply Finset.sum_nonneg
  intro S hS
  exact h2EndpointCombinedTerm_nonneg_of_active
    (h2BooleanDyadicSets_active hS)

lemma h2EndpointDyadicShell_zero
    (q A H : ℕ) :
    h2EndpointDyadicShell q A H 0 = 0 := by
  unfold h2EndpointDyadicShell
  apply Finset.sum_eq_zero
  intro S hS
  have hr := h2BooleanDyadicSets_range hS
  have hA := h2BooleanDyadicSets_active hS
  have hp : 0 < primeSetProduct S :=
    primeSetProduct_pos (fun p hp => (hA p hp).1)
  omega

theorem h2EndpointSmallProductFamily_le_dyadic_sum
    {q A H N : ℕ} :
    h2EndpointSmallProductFamily q A H N ≤
      ∑ i ∈ Finset.range N, h2EndpointDyadicShell q A H i := by
  unfold h2EndpointSmallProductFamily
  let F := h2EndpointSmallProductSets q N
  let key : Finset ℕ → ℕ := fun S => primeSetProduct S - 1
  let f : Finset ℕ → ℝ := fun S =>
    ordinaryBooleanFullEndpointAbsTerm q A H S +
      ordinaryBooleanEmptyEndpointAbsTerm q A H S
  let g : ℕ → ℝ := fun i => h2EndpointDyadicShell q A H i
  change (∑ S ∈ F, f S) ≤ ∑ i ∈ Finset.range N, g i
  apply Finset.sum_le_sum_of_injOn key
  · intro S hSF T hTF hkey
    have hS : S ∈ h2EndpointSmallProductSets q N := by
      simpa [F] using hSF
    have hT : T ∈ h2EndpointSmallProductSets q N := by
      simpa [F] using hTF
    have hSs :
        S ∈ {U : Finset ℕ | U ∈ h2EndpointSmallProductSets q N} := hS
    have hTs :
        T ∈ {U : Finset ℕ | U ∈ h2EndpointSmallProductSets q N} := hT
    exact (h2EndpointSmallProductSets_key_injective (q := q) (N := N))
      hSs hTs hkey
  · intro i hi
    rcases Finset.mem_image.mp hi with ⟨S, hSF, rfl⟩
    have hSN : S ∈ h2EndpointSmallProductSets q N := by
      simpa [F] using hSF
    apply Finset.mem_range.mpr
    have hmle := h2EndpointSmallProductSets_product_le hSN
    have hm5 := h2EndpointSmallProductSets_product_ge_five hSN
    dsimp [key]
    omega
  · intro S hSF
    have hSN : S ∈ h2EndpointSmallProductSets q N := by
      simpa [F] using hSF
    have hdy := h2EndpointSmallProductSets_mem_dyadic hSN
    dsimp [f, g, key]
    unfold h2EndpointDyadicShell
    exact Finset.single_le_sum
      (s := h2BooleanDyadicSets q (primeSetProduct S - 1))
      (f := fun T => ordinaryBooleanFullEndpointAbsTerm q A H T +
        ordinaryBooleanEmptyEndpointAbsTerm q A H T)
      (fun T hT => h2EndpointCombinedTerm_nonneg_of_active
        (h2BooleanDyadicSets_active hT)) hdy
  · intro i hi hnot
    dsimp [g]
    exact h2EndpointDyadicShell_nonneg q A H i

theorem h2EndpointSmallProductFamily_rate
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, 0 ≤ C ∧
      ∀ A H N : ℕ,
        0 < H →
        (¬ 2 ∣ q → 2 ∣ H) →
        1 ≤ Real.log (H : ℝ) →
        (N : ℝ) ≤ (Real.log (H : ℝ)) ^ h2BooleanSigma →
        h2EndpointSmallProductFamily q A H N ≤
          C * (Real.log (H : ℝ)) ^
            (h2BooleanSigma * h2BooleanX0) := by
  rcases h2EndpointDyadicShell_polynomial q hq with
    ⟨C, hC0, hpoly⟩
  refine ⟨C, hC0, ?_⟩
  intro A H N hH h2admissible hlog hNcut
  have hcover :=
    h2EndpointSmallProductFamily_le_dyadic_sum
      (q := q) (A := A) (H := H) (N := N)
  have hshell :
      ∀ i ∈ Finset.range N,
        h2EndpointDyadicShell q A H i ≤
          C * ((i + 1 : ℕ) : ℝ) ^ (h2BooleanX0 - 1) * 1 := by
    intro i hi
    by_cases hi0 : i = 0
    · subst i
      rw [h2EndpointDyadicShell_zero]
      simpa using hC0
    · have hi1 : 1 ≤ i := Nat.one_le_iff_ne_zero.mpr hi0
      have hp := hpoly A H i hH h2admissible hi1
      have halpha : 0 ≤ h2BooleanX0 - 1 :=
        sub_nonneg.mpr h2BooleanX0_one_le
      have hpow :
          (i : ℝ) ^ (h2BooleanX0 - 1) ≤
            ((i + 1 : ℕ) : ℝ) ^ (h2BooleanX0 - 1) := by
        apply Real.rpow_le_rpow
        · positivity
        · exact_mod_cast (show i ≤ i + 1 by omega)
        · exact halpha
      calc
        h2EndpointDyadicShell q A H i
          ≤ C * (i : ℝ) ^ (h2BooleanX0 - 1) := hp
        _ ≤ C * ((i + 1 : ℕ) : ℝ) ^ (h2BooleanX0 - 1) :=
          mul_le_mul_of_nonneg_left hpow hC0
        _ = C * ((i + 1 : ℕ) : ℝ) ^ (h2BooleanX0 - 1) * 1 := by ring
  have hreagg :=
    h2Boolean_generic_dyadic_reaggregation_le_rate
      H N C 1 (fun i => h2EndpointDyadicShell q A H i)
      hlog hNcut hC0 (by norm_num) hshell
  calc
    h2EndpointSmallProductFamily q A H N
      ≤ ∑ i ∈ Finset.range N, h2EndpointDyadicShell q A H i := hcover
    _ ≤ C * (Real.log (H : ℝ)) ^
          (h2BooleanSigma * h2BooleanX0) * 1 := hreagg
    _ = C * (Real.log (H : ℝ)) ^
          (h2BooleanSigma * h2BooleanX0) := by ring

#print axioms h2EndpointSmallProductSets_mem_dyadic
#print axioms h2EndpointSmallProductFamily_le_dyadic_sum
#print axioms h2EndpointSmallProductFamily_rate

end PaperB.FixedQ
