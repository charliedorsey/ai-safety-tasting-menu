import PaperB.Analytic.SawtoothTail
import Mathlib.Analysis.PSeries

open scoped BigOperators

namespace PaperB.Analytic

open Real Set MeasureTheory

lemma sawSmoothCoeff_eq_fourierCoeffOn_cell
    {T : ℝ} (hT : 1 < T) (n : ℤ) :
    sawSmoothCoeff T n =
      fourierCoeffOn (show (0 : ℝ) < 1 by norm_num)
        (fun x : ℝ => (smoothedSawCell T x : ℂ)) n := by
  rw [fourierCoeffOn_eq_integral]
  rw [sawSmoothCoeff]
  simp only [sub_zero, one_div_one, one_smul]
  apply intervalIntegral.integral_congr
  intro x hx
  dsimp only
  rw [smul_eq_mul, fourier_coe_apply]
  congr 1
  rw [sawSmoothFreq]
  push_cast
  ring

lemma summable_norm_sawSmoothCoeff
    {T : ℝ} (hT : 1 < T) :
    Summable (fun n : ℤ => ‖sawSmoothCoeff T n‖) := by
  let C : ℝ := T / (2 * Real.pi ^ 2)
  let g : ℤ → ℝ := fun n => C * (1 / |(n : ℝ)| ^ (2 : ℝ))
  have hbase : Summable (fun n : ℤ => 1 / |(n : ℝ)| ^ (2 : ℝ)) := by
    simpa using (Real.summable_one_div_int_add_rpow 0 2).2 (by norm_num)
  have hg : Summable g := by
    dsimp [g]
    exact hbase.mul_left C
  have hgu : Summable (Function.update g 0 ‖sawSmoothCoeff T 0‖) :=
    hg.update 0 ‖sawSmoothCoeff T 0‖
  apply Summable.of_nonneg_of_le (fun n => norm_nonneg _) ?_ hgu
  intro n
  by_cases hn : n = 0
  · subst n
    simp
  · have hq := sawSmoothCoeff_le_quadratic hT hn
    have hup :
        Function.update g 0 ‖sawSmoothCoeff T 0‖ n = g n := by
      simp [Function.update, hn]
    rw [hup]
    dsimp [g, C]
    rw [Real.rpow_two, sq_abs]
    convert hq using 1 <;> ring


noncomputable def smoothedSawCircle
    (T : ℝ) (hT : 1 < T) : C(AddCircle (1 : ℝ), ℂ) where
  toFun := AddCircle.liftIoc 1 0 (fun x : ℝ => (smoothedSawCell T x : ℂ))
  continuous_toFun := by
    have hend :
        ((smoothedSawCell T 0 : ℝ) : ℂ) =
          ((smoothedSawCell T 1 : ℝ) : ℂ) := by
      rw [smoothedSawCell_zero (lt_trans zero_lt_one hT),
        smoothedSawCell_one hT]
    have hcont :
        Continuous (fun x : ℝ => (smoothedSawCell T x : ℂ)) := by
      simpa [Function.comp_def] using
        Complex.continuous_ofReal.comp (continuous_smoothedSawCell hT)
    exact AddCircle.liftIoc_zero_continuous hend hcont.continuousOn

lemma fourierCoeff_smoothedSawCircle
    {T : ℝ} (hT : 1 < T) (n : ℤ) :
    fourierCoeff (smoothedSawCircle T hT) n = sawSmoothCoeff T n := by
  change fourierCoeff
      (AddCircle.liftIoc (1 : ℝ) 0
        (fun x : ℝ => (smoothedSawCell T x : ℂ))) n =
    sawSmoothCoeff T n
  rw [fourierCoeff_liftIoc_eq, fourierCoeffOn_eq_integral]
  rw [sawSmoothCoeff]
  simp only [zero_add, sub_zero, one_div_one, one_smul]
  apply intervalIntegral.integral_congr
  intro x hx
  dsimp only
  rw [smul_eq_mul, fourier_coe_apply]
  congr 1
  rw [sawSmoothFreq]
  push_cast
  ring

lemma summable_fourierCoeff_smoothedSawCircle
    {T : ℝ} (hT : 1 < T) :
    Summable (fourierCoeff (smoothedSawCircle T hT)) := by
  apply Summable.of_norm
  simpa [fourierCoeff_smoothedSawCircle hT] using
    summable_norm_sawSmoothCoeff hT

theorem hasSum_sawSmooth_fourier_series
    {T : ℝ} (hT : 1 < T) (x : AddCircle (1 : ℝ)) :
    HasSum
      (fun n : ℤ => sawSmoothCoeff T n • fourier n x)
      (smoothedSawCircle T hT x) := by
  simpa [fourierCoeff_smoothedSawCircle hT] using
    has_pointwise_sum_fourier_series_of_summable
      (summable_fourierCoeff_smoothedSawCircle hT) x

#print axioms fourierCoeff_smoothedSawCircle
#print axioms hasSum_sawSmooth_fourier_series

#print axioms sawSmoothCoeff_eq_fourierCoeffOn_cell
#print axioms summable_norm_sawSmoothCoeff

end PaperB.Analytic
