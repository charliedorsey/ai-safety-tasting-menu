import PaperB.Analytic.FiniteDifferenceMVT

namespace PaperB.Analytic

/-- Additivity of the recursive forward-difference operator. -/
lemma dk_add (g f : ℤ → ℝ) (n : ℕ) :
    ∀ m : ℤ, dk n (fun x => g x + f x) m = dk n g m + dk n f m := by
  induction n with
  | zero =>
      intro m
      rfl
  | succ n ih =>
      intro m
      rw [dk_succ, dk_succ, dk_succ, ih (m + 1), ih m]
      ring

/-- Every forward difference of positive order of a constant phase vanishes. -/
lemma dk_const (a : ℝ) (n : ℕ) (m : ℤ) :
    dk (n + 1) (fun _ : ℤ => a) m = 0 := by
  induction n generalizing m with
  | zero =>
      rw [dk_succ]
      simp
  | succ n ih =>
      rw [dk_succ, ih (m + 1), ih m]
      ring

/-- If the first forward difference is constant, every order >= 2 vanishes. -/
lemma dk_eq_zero_of_diff_const {f : ℤ → ℝ} {b : ℝ}
    (hf : ∀ x : ℤ, f (x + 1) - f x = b) {k : ℕ} (hk : 2 ≤ k) (m : ℤ) :
    dk k f m = 0 := by
  obtain ⟨j, rfl⟩ : ∃ j, k = j + 1 + 1 := ⟨k - 2, by omega⟩
  rw [dk_peel_inside f (j + 1) m]
  have hfun : (fun x : ℤ => f (x + 1) - f x) = fun _ : ℤ => b := funext hf
  rw [hfun]
  exact dk_const b j m

lemma dk_linear (b : ℝ) {k : ℕ} (hk : 2 ≤ k) (m : ℤ) :
    dk k (fun x : ℤ => b * (x : ℝ)) m = 0 :=
  dk_eq_zero_of_diff_const (b := b) (fun x => by push_cast; ring) hk m

/-- Linear additive twists are invisible to every derivative-test order >= 2. -/
theorem dk_add_linear (f : ℤ → ℝ) (beta : ℝ) {k : ℕ} (hk : 2 ≤ k) (m : ℤ) :
    dk k (fun x : ℤ => f x + beta * (x : ℝ)) m = dk k f m := by
  have h := dk_add f (fun x : ℤ => beta * (x : ℝ)) k m
  rw [h, dk_linear beta hk m, add_zero]

#print axioms dk_add_linear

end PaperB.Analytic
