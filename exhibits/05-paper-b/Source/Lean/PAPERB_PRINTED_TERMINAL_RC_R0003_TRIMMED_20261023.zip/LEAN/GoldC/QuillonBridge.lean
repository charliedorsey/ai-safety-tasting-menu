import GoldC.QuillonCopyF
import GoldC.QuillonRowNF

/-!
# Quillon CSC3 F8.1: the source summand `foldRow` is the abstract row `rowAbs`

For a valid pair (`r, s ≥ 2`, `(r,s) = 1`, `(r,6q) = (s,6q) = 1`):

    foldRow q a D H r s = rowAbs (6q) H μ Γ r s,

with `μ = meanWeight q (reducedAnchor q a D) H` and `Γ = gammaClass q a D H`.
The chain is: `pot_diff_eq_gammaClass` (source), then `sum_sum_ite_eq` (source), then
`classPart_normal_form` (Quillon, with `Σ_b Γ = 0` from the source's `sum_gammaClass_zero`).
`|foldRow| ≤ 2 + 48q` everywhere.

No axiom, no `sorry`.
-/

open scoped BigOperators Classical
open Finset

namespace GoldC.QuillonBridge

open GoldC.QuillonCopyF GoldC.QuillonCopyC

theorem foldRow_eq_rowAbs (q a D H r s : ℕ) (hq : 0 < q) (hr : 2 ≤ r) (hs : 2 ≤ s)
    (hrM : r.Coprime (6 * q)) (hsM : s.Coprime (6 * q)) :
    foldRow q a D H r s =
      GoldC.QuillonRowNF.rowAbs (6 * q) H (meanWeight q (reducedAnchor q a D) H)
        (gammaClass q a D H) r s := by
  unfold foldRow GoldC.QuillonRowNF.rowAbs
  have hM : 2 ≤ 6 * q := by omega
  congr 1
  rw [pot_diff_eq_gammaClass q a D H (r * s) (crtResidue H r s) hq (crtResidue_lt hs (by omega)),
    ← sum_sum_ite_eq (6 * q) _ _ (Nat.mod_lt _ (by omega)) (Nat.mod_lt _ (by omega))
      (gammaClass q a D H)]
  exact classPart_normal_form hM hs hrM hsM (gammaClass q a D H) (sum_gammaClass_zero q a D H)

lemma abs_saw_le (x : ℝ) : |saw x| ≤ 1 / 2 := by
  unfold saw
  have h0 := Int.fract_nonneg x
  have h1 := Int.fract_lt_one x
  rw [abs_le]; constructor <;> linarith

theorem abs_foldRow_le (q a D H r s : ℕ) (hq : 0 < q) :
    |foldRow q a D H r s| ≤ 4 + 48 * q := by
  unfold foldRow
  have hμ := meanWeight_bounds q (reducedAnchor q a D) H
  have h1 := pot_srcG_bound q (reducedAnchor q a D) H (r * s) (H + r * s - crtResidue H r s) hq
  have h2 := pot_srcG_bound q (reducedAnchor q a D) H (r * s) (crtResidue H r s) hq
  have hs := abs_saw_le ((H : ℝ) * invMod r s / s)
  have e1 : |-(2 * meanWeight q (reducedAnchor q a D) H) * saw ((H : ℝ) * invMod r s / s)| ≤ 4 := by
    rw [abs_mul, abs_neg, abs_mul, abs_two, abs_of_nonneg hμ.1]
    nlinarith [abs_nonneg (saw ((H : ℝ) * invMod r s / s))]
  calc _ ≤ |-(2 * meanWeight q (reducedAnchor q a D) H) * saw ((H : ℝ) * invMod r s / s)| +
        (|pot (srcG q (reducedAnchor q a D) H) (6 * q) (r * s) (H + r * s - crtResidue H r s)| +
          |pot (srcG q (reducedAnchor q a D) H) (6 * q) (r * s) (crtResidue H r s)|) :=
        (abs_add_le _ _).trans (add_le_add le_rfl (abs_sub _ _))
    _ ≤ 4 + (4 * (6 * q) + 4 * (6 * q)) := add_le_add e1 (add_le_add h1 h2)
    _ = 4 + 48 * q := by ring

end GoldC.QuillonBridge

#print axioms GoldC.QuillonBridge.foldRow_eq_rowAbs
#print axioms GoldC.QuillonBridge.abs_foldRow_le
