import PaperB.FixedQ.H2ProperWeightedGeometricPrefix

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def h2BooleanProperCoreSmallMajorant
    (q A H Z : ℕ) : ℝ :=
  ∑ S ∈ h2BooleanGlobalSmallSets q H Z,
    |ordinaryBooleanCoreTerm q A H S|

noncomputable def h2BooleanProperCoreMiddleMajorant
    (q A H N Z : ℕ) : ℝ :=
  ∑ S ∈ (h2BooleanGlobalSmallSets q H Z).filter
      (fun S => N < primeSetProduct S),
    |ordinaryBooleanCoreTerm q A H S|

lemma h2BooleanProperCoreSmallMajorant_nonneg
    (q A H Z : ℕ) :
    0 ≤ h2BooleanProperCoreSmallMajorant q A H Z := by
  unfold h2BooleanProperCoreSmallMajorant
  positivity

theorem h2BooleanProperCoreSmallMajorant_le_initial_add_middle
    {q A H N Z : ℕ}
    (hq : 0 < q)
    (h2 : ¬ 2 ∣ q → 2 ∣ H) :
    h2BooleanProperCoreSmallMajorant q A H Z ≤
      (12 * (fixedQPeriod q : ℝ)) *
        h2BooleanInitialProperWeightMass q N +
      h2BooleanProperCoreMiddleMajorant q A H N Z := by
  classical
  let F := h2BooleanGlobalSmallSets q H Z
  let F0 := F.filter (fun S => primeSetProduct S ≤ N)
  let F1 := F.filter (fun S => N < primeSetProduct S)
  have hpart : F = F0 ∪ F1 := by
    ext S
    simp only [F0, F1, Finset.mem_union, Finset.mem_filter]
    constructor
    · intro hSF
      by_cases hm : primeSetProduct S ≤ N
      · exact Or.inl ⟨hSF, hm⟩
      · exact Or.inr ⟨hSF, Nat.lt_of_not_ge hm⟩
    · rintro (⟨hSF, _⟩ | ⟨hSF, _⟩) <;> exact hSF
  have hdis : Disjoint F0 F1 := by
    rw [Finset.disjoint_left]
    intro S h0 h1
    have a := (Finset.mem_filter.mp h0).2
    have b := (Finset.mem_filter.mp h1).2
    omega
  unfold h2BooleanProperCoreSmallMajorant
  change (∑ S ∈ F, |ordinaryBooleanCoreTerm q A H S|) ≤ _
  rw [hpart, Finset.sum_union hdis]
  have hinit :
      (∑ S ∈ F0, |ordinaryBooleanCoreTerm q A H S|) ≤
        (12 * (fixedQPeriod q : ℝ)) *
          h2BooleanInitialProperWeightMass q N := by
    let G := (h2BooleanActivePrimesLE q (2 * N)).powerset
    let W : Finset ℕ → ℝ := fun S =>
      finiteOmegaWeightReal S * (2 : ℝ) ^ S.card
    have hsub : F0 ⊆ G := by
      intro S hS
      have hSF := (Finset.mem_filter.mp hS).1
      have hmN := (Finset.mem_filter.mp hS).2
      have hE := h2BooleanGlobalSmallSets_mem_endpoint hSF
      have hAct := h2EndpointSmallProductSets_active hE
      apply Finset.mem_powerset.mpr
      intro p hp
      unfold h2BooleanActivePrimesLE
      apply Finset.mem_filter.mpr
      constructor
      · apply Nat.mem_primesLE.mpr
        constructor
        · have hprime : p.Prime := (hAct p hp).1
          have hmpos : 0 < primeSetProduct S :=
            primeSetProduct_pos (fun r hr => (hAct r hr).1)
          have hpdiv : p ∣ primeSetProduct S := by
            unfold primeSetProduct
            exact Finset.dvd_prod_of_mem (fun x : ℕ => x) hp
          have hpN : p ≤ N :=
            (Nat.le_of_dvd hmpos hpdiv).trans hmN
          omega
        · exact (hAct p hp).1
      · exact hAct p hp
    have hpoint : ∀ S ∈ F0,
        |ordinaryBooleanCoreTerm q A H S| ≤
          W S * (12 * (fixedQPeriod q : ℝ)) := by
      intro S hS
      have hSF := (Finset.mem_filter.mp hS).1
      have hE := h2BooleanGlobalSmallSets_mem_endpoint hSF
      have hAct : S ∈ activeOrdinaryTwoDimensionalSet q H :=
        ⟨h2BooleanGlobalSmallSets_ordinary hSF,
          h2EndpointSmallProductSets_active hE⟩
      rw [abs_ordinaryBooleanCoreTerm_eq_fixedQProperWeighted hAct]
      have hD := fixedQProperWeightedDiscrepancy_abs_le_uniform
        (q := q) (A := A) (H := H) (S := S)
        hq hAct.2 hAct.1 h2
      have hW0 : 0 ≤ W S := by
        dsimp [W]
        exact mul_nonneg
          (finiteOmegaWeightReal_nonneg_of_active hAct.2)
          (pow_nonneg (by norm_num) _)
      exact mul_le_mul_of_nonneg_left hD hW0
    calc
      (∑ S ∈ F0, |ordinaryBooleanCoreTerm q A H S|)
        ≤ ∑ S ∈ F0, W S * (12 * (fixedQPeriod q : ℝ)) :=
          Finset.sum_le_sum hpoint
      _ = (∑ S ∈ F0, W S) * (12 * (fixedQPeriod q : ℝ)) := by
        rw [Finset.sum_mul]
      _ ≤ (∑ S ∈ G, W S) * (12 * (fixedQPeriod q : ℝ)) := by
        apply mul_le_mul_of_nonneg_right
        · exact Finset.sum_le_sum_of_subset_of_nonneg hsub
            (fun S hSG hnot => by
              have hsubG := Finset.mem_powerset.mp hSG
              have hA : ∀ p ∈ S, activeHighPrime q p := by
                intro p hp
                exact (Finset.mem_filter.mp (hsubG hp)).2
              dsimp [W]
              exact mul_nonneg
                (finiteOmegaWeightReal_nonneg_of_active hA)
                (pow_nonneg (by norm_num) _))
        · positivity
      _ = (12 * (fixedQPeriod q : ℝ)) *
          h2BooleanInitialProperWeightMass q N := by
        unfold h2BooleanInitialProperWeightMass
        dsimp [G, W]
        ring
  have hmiddle :
      (∑ S ∈ F1, |ordinaryBooleanCoreTerm q A H S|) =
        h2BooleanProperCoreMiddleMajorant q A H N Z := by
    unfold h2BooleanProperCoreMiddleMajorant
    simpa [F1, F]
  rw [hmiddle]
  exact add_le_add hinit (le_refl _)

theorem h2BooleanProperCoreMiddleMajorant_le_geometricPrefix
    {q A H N Z : ℕ}
    (hN : 0 < N) :
    h2BooleanProperCoreMiddleMajorant q A H N Z ≤
      h2BooleanProperGeometricPrefix q A H N (Nat.log 2 Z + 1) := by
  classical
  let F := (h2BooleanGlobalSmallSets q H Z).filter
      (fun S => N < primeSetProduct S)
  let J := Nat.log 2 Z + 1
  let T := (Finset.range J).sigma
      (fun k => h2BooleanGeometricExteriorBand q H N k)
  let i : {S // S ∈ F} → Σ _k : ℕ, Finset ℕ :=
    fun S => ⟨h2BooleanGeometricExteriorBandIndex N S.1, S.1⟩
  have hi : Function.Injective i := by
    intro S U hEq
    apply Subtype.ext
    exact congrArg Sigma.snd hEq
  have himage : F.attach.image i ⊆ T := by
    intro x hx
    rcases Finset.mem_image.mp hx with ⟨S, hSF, rfl⟩
    have hFmem : S.1 ∈ F := S.2
    have hbase := (Finset.mem_filter.mp hFmem).1
    have hgt := (Finset.mem_filter.mp hFmem).2
    have hE := h2BooleanGlobalSmallSets_mem_endpoint hbase
    have hAct : S.1 ∈ activeOrdinaryTwoDimensionalSet q H :=
      ⟨h2BooleanGlobalSmallSets_ordinary hbase,
        h2EndpointSmallProductSets_active hE⟩
    have hne := h2EndpointSmallProductSets_nonempty hE
    have hband := h2BooleanActiveOrdinary_mem_geometricExteriorBand
      hN hAct hne hgt
    have hr := h2BooleanGeometricExterior_range hN hgt
    let k := h2BooleanGeometricExteriorBandIndex N S.1
    have hkpow : 2 ^ k ≤ Z := by
      have hNk : N * 2 ^ k < primeSetProduct S.1 := by
        simpa [k, h2BooleanGeometricExteriorBandIndex,
          h2BooleanGeometricExteriorScale] using hr.1
      have hmZ := h2EndpointSmallProductSets_product_le hE
      have hN1 : 1 ≤ N := Nat.one_le_iff_ne_zero.mpr hN.ne'
      have hkN : 2 ^ k ≤ N * 2 ^ k := by
        simpa [one_mul] using Nat.mul_le_mul_right (2 ^ k) hN1
      omega
    have hklog : k ≤ Nat.log 2 Z :=
      Nat.le_log_of_pow_le (by norm_num) hkpow
    rw [Finset.mem_sigma]
    constructor
    · apply Finset.mem_range.mpr
      simpa [i, J, k] using Nat.lt_succ_of_le hklog
    · simpa [i] using hband
  unfold h2BooleanProperCoreMiddleMajorant
  change (∑ S ∈ F, |ordinaryBooleanCoreTerm q A H S|) ≤ _
  calc
    (∑ S ∈ F, |ordinaryBooleanCoreTerm q A H S|)
      = ∑ S ∈ F.attach, |ordinaryBooleanCoreTerm q A H S.1| := by
        simpa using (Finset.sum_attach
          (s := F) (f := fun S => |ordinaryBooleanCoreTerm q A H S|)).symm
    _ = ∑ x ∈ F.attach.image i,
          |ordinaryBooleanCoreTerm q A H x.2| := by
        symm
        exact Finset.sum_image hi.injOn
    _ ≤ ∑ x ∈ T, |ordinaryBooleanCoreTerm q A H x.2| :=
      Finset.sum_le_sum_of_subset_of_nonneg himage
        (fun x hx hnot => abs_nonneg _)
    _ = ∑ k ∈ Finset.range J,
          h2BooleanGeometricCoreBandMass q A H N k := by
        dsimp [T]
        rw [Finset.sum_sigma]
        apply Finset.sum_congr rfl
        intro k hk
        unfold h2BooleanGeometricCoreBandMass
        rfl
    _ = h2BooleanProperGeometricPrefix q A H N J := by
      unfold h2BooleanProperGeometricPrefix
      apply Finset.sum_congr rfl
      intro k hk
      exact h2BooleanGeometricCoreBandMass_eq_properWeightedShell
        q A H N k
    _ = h2BooleanProperGeometricPrefix q A H N (Nat.log 2 Z + 1) := rfl

#print axioms h2BooleanProperCoreSmallMajorant_le_initial_add_middle
#print axioms h2BooleanProperCoreMiddleMajorant_le_geometricPrefix

end PaperB.FixedQ
