import GoldC.InvBound

/-!
# `GoldC.DigitSplit` — peeling the density share off the digit part

`digitTerm = digitAP - (Σ_{0<y<H} (λ - μ)) / (rs)`. For the source weight and its period mean,
`|Σ_{0<y<H} (λ - μ)| ≤ 4(6q + 1)` (`occupied_partial_sum_le`), so the density share is a
`C/(rs)` functional and is negligible by `centralSum_abs_le` (`DigitDensityPart_small`).
-/

open scoped BigOperators Classical
open Finset Filter Topology

namespace GoldC

/-! ## Partial sums of a mean-zero periodic sequence -/

lemma sum_shift_period (f : ℕ → ℝ) (M : ℕ) (hper : ∀ y, f (y + M) = f y) (K : ℕ) :
    ∑ i ∈ Finset.range M, f (K + i) = ∑ i ∈ Finset.range M, f i := by
  induction K with
  | zero => simp
  | succ K ih =>
    rw [← ih]
    rcases Nat.eq_zero_or_pos M with rfl | hM
    · simp
    obtain ⟨m, rfl⟩ : ∃ m, M = m + 1 := ⟨M - 1, by omega⟩
    rw [Finset.sum_range_succ, Finset.sum_range_succ' (fun i => f (K + i))]
    have h3 : f (K + 1 + m) = f (K + 0) := by
      rw [show K + 1 + m = K + (m + 1) by ring, hper, add_zero]
    rw [h3]
    have h4 : ∑ i ∈ Finset.range m, f (K + 1 + i) = ∑ i ∈ Finset.range m, f (K + (i + 1)) :=
      Finset.sum_congr rfl fun i _ => by ring_nf
    rw [h4]

lemma sum_range_periodic (f : ℕ → ℝ) (M : ℕ) (hper : ∀ y, f (y + M) = f y)
    (hzero : ∑ i ∈ Finset.range M, f i = 0) (Q R : ℕ) :
    ∑ i ∈ Finset.range (M * Q + R), f i = ∑ i ∈ Finset.range R, f i := by
  induction Q with
  | zero => simp
  | succ Q ih =>
    rw [show M * (Q + 1) + R = (M * Q + R) + M by ring, Finset.sum_range_add, ih,
      sum_shift_period f M hper, hzero, add_zero]

/-- `|Σ_{y<K} f| ≤ M·B` for an `M`-periodic sequence with zero period sum and `|f| ≤ B`. -/
lemma abs_sum_range_periodic_le (f : ℕ → ℝ) (M : ℕ) (hM : 0 < M) (hper : ∀ y, f (y + M) = f y)
    (hzero : ∑ i ∈ Finset.range M, f i = 0) (B : ℝ) (hB : ∀ y, |f y| ≤ B) (K : ℕ) :
    |∑ i ∈ Finset.range K, f i| ≤ M * B := by
  have hK : K = M * (K / M) + K % M := (Nat.div_add_mod K M).symm
  rw [hK, sum_range_periodic f M hper hzero]
  have hB0 : 0 ≤ B := le_trans (abs_nonneg _) (hB 0)
  calc |∑ i ∈ Finset.range (K % M), f i| ≤ ∑ i ∈ Finset.range (K % M), |f i| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ i ∈ Finset.range (K % M), B := Finset.sum_le_sum fun i _ => hB i
    _ = (K % M : ℕ) * B := by rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
    _ ≤ M * B := by
        apply mul_le_mul_of_nonneg_right _ hB0
        exact_mod_cast (Nat.mod_lt K hM).le

/-- **Bounded source partial sums**: `|Σ_{0<y<H} (λ(y) - μ)| ≤ 4(6q + 1)`. -/
theorem occupied_partial_sum_le (q a' H : ℕ) (hq : 0 < q) :
    |∑ y ∈ Finset.Ioo 0 H, (occupiedWeight q a' H y - meanWeight q a' H)| ≤ 4 * (6 * q + 1) := by
  set f : ℕ → ℝ := fun y => occupiedWeight q a' H y - meanWeight q a' H
  have hper : ∀ y, f (y + 6 * q) = f y := fun y => by
    simp only [f, occupiedWeight_periodic]
  have hzero : ∑ i ∈ Finset.range (6 * q), f i = 0 := by
    simp only [f, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_range, nsmul_eq_mul]
    unfold meanWeight
    have : (6 * q : ℝ) ≠ 0 := by positivity
    push_cast; field_simp; ring
  have hB : ∀ y, |f y| ≤ 4 := fun y => by
    have h1 := occupiedWeight_bounds q a' H y
    have h2 := meanWeight_bounds q a' H
    simp only [f]; rw [abs_le]; constructor <;> linarith
  have hrange := abs_sum_range_periodic_le f (6 * q) (by omega) hper hzero 4 hB H
  rcases Nat.eq_zero_or_pos H with rfl | hH
  · simp; positivity
  have hsplit : ∑ i ∈ Finset.range H, f i = f 0 + ∑ y ∈ Finset.Ioo 0 H, f y := by
    rw [Finset.range_eq_Ico, Finset.sum_eq_sum_Ico_succ_bot hH]
    rfl
  have : ∑ y ∈ Finset.Ioo 0 H, f y = ∑ i ∈ Finset.range H, f i - f 0 := by rw [hsplit]; ring
  rw [this]
  calc |∑ i ∈ Finset.range H, f i - f 0| ≤ |∑ i ∈ Finset.range H, f i| + |f 0| := abs_sub _ _
    _ ≤ ((6 * q : ℕ) : ℝ) * 4 + 4 := add_le_add hrange (hB 0)
    _ = 4 * (6 * q + 1) := by push_cast; ring

/-! ## The split of the digit part -/

/-- The digit part on the constrained progression. -/
noncomputable def digitAP (lam : ℕ → ℝ) (μ : ℝ) (H r s : ℕ) : ℝ :=
  ∑ y ∈ Finset.Ioo 0 H, if r ∣ y ∧ s ∣ H - y then (lam y - μ) else 0

lemma digitTerm_eq (lam : ℕ → ℝ) (μ : ℝ) (H r s : ℕ) :
    digitTerm lam μ H r s = digitAP lam μ H r s +
      -((∑ y ∈ Finset.Ioo 0 H, (lam y - μ)) / ((r : ℝ) * (s : ℝ))) := by
  unfold digitTerm digitAP; ring

/-- `Σ V_d ω(e) Σ_{y ≡ c (rs)} (λ - μ)`: the constrained digit part (part of the remaining debt). -/
noncomputable def DigitAPPart (q a h : ℕ) : ℝ :=
  centralSum q h (fun D H r s =>
    digitAP (occupiedWeight q (reducedAnchor q a D) H) (meanWeight q (reducedAnchor q a D) H) H r s)

/-- `-Σ V_d ω(e) (Σ_{0<y<H} (λ - μ))/(rs)`: the density share of the digit part (paid). -/
noncomputable def DigitDensityPart (q a h : ℕ) : ℝ :=
  centralSum q h (fun D H r s =>
    -((∑ y ∈ Finset.Ioo 0 H, (occupiedWeight q (reducedAnchor q a D) H y -
        meanWeight q (reducedAnchor q a D) H)) / ((r : ℝ) * (s : ℝ))))

theorem DigitPart_split (q a h : ℕ) :
    DigitPart q a h = DigitAPPart q a h + DigitDensityPart q a h := by
  rw [DigitPart, DigitAPPart, DigitDensityPart, ← centralSum_add]
  refine centralSum_congr fun d e B _ => ?_
  rw [digitTerm_eq]

theorem DigitDensityPart_le (q a h : ℕ) (hq : 0 < q) (hh : 0 < h) :
    |DigitDensityPart q a h| ≤
      4 * (6 * q + 1) * (1 + Real.log h) ^ 3 * ((1 / Real.sqrt (originalZ h)) * Real.exp K0) := by
  refine centralSum_abs_le q h hh _ _ (by positivity) fun d e B hidx => ?_
  obtain ⟨-, hr, hs, -, -, -⟩ := source_pair_facts hidx
  have hn : (0 : ℝ) < (primeSetProduct B : ℝ) * (primeSetProduct (e \ B) : ℝ) := by
    have : (0 : ℝ) < primeSetProduct B := by exact_mod_cast (by omega : 0 < primeSetProduct B)
    have : (0 : ℝ) < primeSetProduct (e \ B) := by
      exact_mod_cast (by omega : 0 < primeSetProduct (e \ B))
    positivity
  rw [abs_neg, abs_div, abs_of_pos hn]
  exact div_le_div_of_nonneg_right (occupied_partial_sum_le q _ _ hq) hn.le

/-- **Rate for the density share of the digit part**: for fixed `q` and every `ε > 0`,
`|DigitDensityPart q a h| ≤ ε` for all `a` and all large `h`. -/
theorem DigitDensityPart_small (q : ℕ) (hq : 0 < q) (ε : ℝ) (hε : 0 < ε) :
    ∃ H0 : ℕ, ∀ a h : ℕ, H0 ≤ h → |DigitDensityPart q a h| ≤ ε := by
  have hc : (0 : ℝ) < 4 * (6 * q + 1) / 4 := by positivity
  obtain ⟨H0, hH0⟩ := InvPart_small (ε / (4 * (6 * q + 1) / 4)) (by positivity)
  -- reuse the InvPart majorant: the bound is the InvPart bound times `(6q + 1)`
  have hev2 : ∀ᶠ h : ℕ in atTop, 1 ≤ Real.log (h : ℝ) :=
    (Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop).eventually (eventually_ge_atTop 1)
  have hev := (majorant_tendsto.eventually (gt_mem_nhds (show (0 : ℝ) < ε / (6 * q + 1) by positivity)))
  obtain ⟨H1, hH1⟩ := eventually_atTop.1 ((hev.and hev2).and (eventually_ge_atTop 1))
  refine ⟨H1, fun a h hh => ?_⟩
  obtain ⟨⟨h1, h2⟩, h3⟩ := hH1 h hh
  have hmaj := InvPart_le_majorant 1 0 h (by omega) h2
  have hbase : 4 * (1 + Real.log h) ^ 3 * ((1 / Real.sqrt (originalZ h)) * Real.exp K0) ≤
      32 * Real.exp K0 * (((Real.log (h : ℝ)) ^ booleanSigma) ^ (3 / booleanSigma) *
        Real.exp (-(10 * Real.log 2) * (Real.log (h : ℝ)) ^ booleanSigma)) := by
    -- the proof of `InvPart_le_majorant` bounds exactly this quantity
    set L := Real.log (h : ℝ)
    have hL0 : 0 ≤ L := by linarith
    have hpow : (L ^ booleanSigma) ^ (3 / booleanSigma) = L ^ 3 := by
      rw [← Real.rpow_mul hL0, mul_div_cancel₀ _ booleanSigma_pos.ne',
        show (3 : ℝ) = ((3 : ℕ) : ℝ) by norm_num, Real.rpow_natCast]
    rw [hpow]
    have hcube : (1 + L) ^ 3 ≤ 8 * L ^ 3 := by
      have : 1 + L ≤ 2 * L := by linarith
      calc (1 + L) ^ 3 ≤ (2 * L) ^ 3 := pow_le_pow_left₀ (by linarith) this 3
        _ = 8 * L ^ 3 := by ring
    have hz := inv_sqrt_originalZ_le h
    have hK := Real.exp_pos K0
    have hzz : 0 ≤ 1 / Real.sqrt (originalZ h) := div_nonneg zero_le_one (Real.sqrt_nonneg _)
    calc 4 * (1 + L) ^ 3 * ((1 / Real.sqrt (originalZ h)) * Real.exp K0)
        ≤ 4 * (8 * L ^ 3) * (Real.exp (-(10 * Real.log 2) * L ^ booleanSigma) * Real.exp K0) := by
          apply mul_le_mul (mul_le_mul_of_nonneg_left hcube (by norm_num))
            (mul_le_mul_of_nonneg_right hz hK.le) (mul_nonneg hzz hK.le) (by positivity)
      _ = 32 * Real.exp K0 * (L ^ 3 * Real.exp (-(10 * Real.log 2) * L ^ booleanSigma)) := by ring
  have hq1 : (0 : ℝ) < 6 * q + 1 := by positivity
  calc |DigitDensityPart q a h|
      ≤ 4 * (6 * q + 1) * (1 + Real.log h) ^ 3 * ((1 / Real.sqrt (originalZ h)) * Real.exp K0) :=
        DigitDensityPart_le q a h hq (by omega)
    _ = (6 * q + 1) * (4 * (1 + Real.log h) ^ 3 * ((1 / Real.sqrt (originalZ h)) * Real.exp K0)) := by
        ring
    _ ≤ (6 * q + 1) * (ε / (6 * q + 1)) := by
        apply mul_le_mul_of_nonneg_left (hbase.trans h1.le) hq1.le
    _ = ε := by field_simp

end GoldC
