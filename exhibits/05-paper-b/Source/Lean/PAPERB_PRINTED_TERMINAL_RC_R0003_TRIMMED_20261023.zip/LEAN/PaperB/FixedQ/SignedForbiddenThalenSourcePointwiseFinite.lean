import PaperB.FixedQ.SignedForbiddenThalenDisjointFinitePacket

open scoped BigOperators

namespace PaperB.FixedQ

/-- Source-safe disjointness of the two shifted divisibility indicators.
The bound y ≤ H is essential because subtraction is in Nat. -/
theorem thalen_prime_shifted_indicators_disjoint
    (p y H : ℕ) (hy : y ≤ H) (hp : ¬ p ∣ H) :
    (if p ∣ y then (1 : ℝ) else 0) *
      (if p ∣ H - y then (1 : ℝ) else 0) = 0 := by
  by_cases hleft : p ∣ y
  · by_cases hright : p ∣ H - y
    · exfalso
      apply hp
      have hh := dvd_add hright hleft
      simpa [Nat.sub_add_cancel hy] using hh
    · simp [hleft, hright]
  · simp [hleft]

/-- Pointwise finite supported source Boolean packet equals the
centered shifted Ramanujan packet, retaining the exact source Euler
normalization and the two pure-side deletions. No cutoff is applied. -/
theorem thalen_finite_source_proper_eq_spectral_pointwise
    (S : Finset ℕ) (H y : ℕ)
    (h5 : ∀ p ∈ S, 5 ≤ p)
    (hH : ∀ p ∈ S, ¬ p ∣ H)
    (hy : y ≤ H) :
    (∑ e ∈ S.powerset,
      (∏ p ∈ e, (1 / ((p : ℝ) - 3))) *
        (∑ A ∈ ((e.powerset.erase e).erase ∅),
          (∏ p ∈ A, (if p ∣ y then (1 : ℝ) else 0)) *
            (∏ p ∈ e \ A,
              (if p ∣ H - y then (1 : ℝ) else 0)))) =
    thalenFiniteCenteredPacket S (thalenFiniteA S) y *
      thalenFiniteCenteredPacket S (thalenFiniteA S) (H-y) := by
  let w : ℕ → ℝ := fun p => 1 / ((p : ℝ) - 3)
  let L : ℕ → ℝ := fun p => if p ∣ y then 1 else 0
  let R : ℕ → ℝ := fun p => if p ∣ H - y then 1 else 0
  have hd : ∀ p ∈ S, L p * R p = 0 := by
    intro p hp
    exact thalen_prime_shifted_indicators_disjoint p y H hy (hH p hp)
  have hproper := thalen_outer_proper_eq_centered_packets S w L R hd
  have hleft := thalen_finite_source_euler S h5 y
  have hright := thalen_finite_source_euler S h5 (H-y)
  dsimp [w,L,R] at hproper
  rw [hproper]
  rw [hleft, hright]
  simp only [mul_ite, mul_one, mul_zero]

#print axioms thalen_finite_source_proper_eq_spectral_pointwise

end PaperB.FixedQ
