import GoldC.QuillonSetup
import GoldC.QuillonEv

/-!
# Quillon LONG L1: source copy of `signedLongMiddle`, oriented LONG masks, admissibility

**Verbatim copy** (namespace `GoldC.QuillonCopyM`) of
* `Merivelle.Central.signedLongMiddle` (from `MiddleLongCoreConsumer.lean`).

**Oriented LONG masks.** `longEither δ r s = longInverseLeft ∨ longInverseRight`; the two are
disjoint (`s^{1+δ} < r` and `r^{1+δ} < s` cannot both hold for `r, s ≥ 1`).
* `GeoLL`: `Z < rs`, `4rs ≤ H²`, `s^{1+δ} < r`, `centralGate`  (r is the long factor);
* `GeoLR`: `Z < rs`, `4rs ≤ H²`, `r^{1+δ} < s`, `centralGate`  (s is the long factor).

**Admissibility with constant 4.** `centralGate` gives `r ≤ s²` and `s ≤ r²`, so on LONG the
short factor `x` satisfies `log Z < 3 log x`, i.e. `log x ≥ (20 log 2 / 3)Λ^σ ≥ 4Λ^σ`.
(The CORE value 5 is NOT available on LONG: `20 log 2 / 3 ≈ 4.62`.)

**Convexity.** `GeoLL` is convex in `r` (fixed `s`); `GeoLR` is convex in `s` (fixed `r`).

**Constant-4 versions** of the abstract eventual lemmas `s_large`, `sdecay`, `edecay`.

No axiom, no `sorry`.
-/

open scoped BigOperators Classical
open Finset

namespace GoldC.QuillonCopyM

open GoldC.QuillonCopyS GoldC.QuillonCopyG GoldC.QuillonCopyF

noncomputable def signedLongMiddle (Jlow Jhigh : ℕ → ℕ)
    (δ : ℝ) (q a h : ℕ) : ℝ :=
  regionSumMiddleWhere (Jlow h) (Jhigh h) q h
    (centralGate h) (longEither δ) (foldRow q a)

end GoldC.QuillonCopyM

namespace GoldC.QuillonLSetup

open GoldC.QuillonCopyS GoldC.QuillonCopyG GoldC.QuillonCopyF GoldC.QuillonCopyM GoldC.QuillonSetup

/-- LONG-left base mask: `r` is the long factor. -/
def GeoLL (h H : ℕ) (δ : ℝ) (r s : ℕ) : Prop :=
  originalZ h < r * s ∧ 4 * (r * s) ≤ H ^ 2 ∧ longInverseLeft δ r s ∧ centralGate h H r s

/-- LONG-right base mask: `s` is the long factor. -/
def GeoLR (h H : ℕ) (δ : ℝ) (r s : ℕ) : Prop :=
  originalZ h < r * s ∧ 4 * (r * s) ≤ H ^ 2 ∧ longInverseRight δ r s ∧ centralGate h H r s

/-- Common log/size facts from `Z < rs` and the gate, given `log x ≤ 2 log y`-type data. -/
lemma adm_core (h H r s : ℕ) (hh : 2 ≤ h) (hHh : H ≤ h) (hZ : originalZ h < r * s)
    (hgate : centralGate h H r s) :
    1 ≤ r ∧ 1 ≤ s ∧ (r : ℝ) ≤ h ∧ (s : ℝ) ≤ h ∧
      ((r : ℝ) * s) * Real.exp ((Real.log h) ^ (1 / 4 : ℝ)) ≤ H ∧
      20 * Real.log 2 * (Real.log h) ^ σ₀ < Real.log r + Real.log s := by
  obtain ⟨hgate1, -, -⟩ := hgate
  have hrs0 : 0 < r * s := lt_of_le_of_lt (Nat.zero_le _) hZ
  have hr1 : 1 ≤ r := Nat.pos_of_ne_zero (by rintro rfl; simp at hrs0)
  have hs1 : 1 ≤ s := Nat.pos_of_ne_zero (by rintro rfl; simp at hrs0)
  have hrR : (1 : ℝ) ≤ r := by exact_mod_cast hr1
  have hsR : (1 : ℝ) ≤ s := by exact_mod_cast hs1
  have hE : 1 ≤ Real.exp ((Real.log h) ^ (1 / 4 : ℝ)) := Real.one_le_exp (by positivity)
  have hHR : (H : ℝ) ≤ h := by exact_mod_cast hHh
  have hrsH : ((r : ℝ) * s) * Real.exp ((Real.log h) ^ (1 / 4 : ℝ)) ≤ H := by
    have := hgate1
    rw [le_div_iff₀ (Real.exp_pos _)] at this
    exact_mod_cast this
  have hrs_le : (r : ℝ) * s ≤ h :=
    calc (r : ℝ) * s ≤ ((r : ℝ) * s) * Real.exp ((Real.log h) ^ (1 / 4 : ℝ)) :=
          le_mul_of_one_le_right (by positivity) hE
      _ ≤ H := hrsH
      _ ≤ h := hHR
  have hrh : (r : ℝ) ≤ h := le_trans (le_mul_of_one_le_right (by positivity) hsR) hrs_le
  have hsh : (s : ℝ) ≤ h := le_trans (le_mul_of_one_le_left (by positivity) hrR) hrs_le
  have hZl := originalZ_ge h
  have hZlt : Real.log (originalZ h : ℝ) < Real.log ((r : ℝ) * s) := by
    apply Real.log_lt_log
    · have : 0 < originalZ h := by unfold originalZ; exact Nat.pow_pos (by norm_num)
      exact_mod_cast this
    · exact_mod_cast hZ
  rw [Real.log_mul (by positivity) (by positivity)] at hZlt
  exact ⟨hr1, hs1, hrh, hsh, hrsH, lt_of_le_of_lt hZl hZlt⟩

lemma four_le_of (Lσ a b : ℝ) (hσ : 0 ≤ Lσ) (hsum : 20 * Real.log 2 * Lσ < a + b) (hab : a ≤ 2 * b) :
    4 * Lσ ≤ b := by
  have hl2 : (0.69 : ℝ) < Real.log 2 := by have := Real.log_two_gt_d9; linarith
  have k1 : 20 * 0.69 * Lσ ≤ 20 * Real.log 2 * Lσ := by
    apply mul_le_mul_of_nonneg_right _ hσ; linarith
  linarith

/-- **Admissibility on LONG-left** (constant 4). -/
theorem admLL (h H r s : ℕ) (δ : ℝ) (hδ0 : 0 < δ) (hh : 2 ≤ h) (hHh : H ≤ h)
    (hG : GeoLL h H δ r s) :
    4 * (Real.log h) ^ σ₀ ≤ Real.log s ∧ 4 * (Real.log h) ^ σ₀ ≤ Real.log r ∧
      1 ≤ r ∧ 1 ≤ s ∧ (r : ℝ) ≤ h ∧ (s : ℝ) ≤ h ∧
      (s : ℝ) ^ (1 + δ) < r ∧ (s : ℝ) ≤ r ∧
      ((r : ℝ) * s) * Real.exp ((Real.log h) ^ (1 / 4 : ℝ)) ≤ H := by
  obtain ⟨hZ, -, hL, hgate⟩ := hG
  obtain ⟨hr1, hs1, hrh, hsh, hrsH, hsum⟩ := adm_core h H r s hh hHh hZ hgate
  obtain ⟨-, -, hrs2⟩ := hgate
  unfold longInverseLeft at hL
  have hrR : (1 : ℝ) ≤ r := by exact_mod_cast hr1
  have hsR : (1 : ℝ) ≤ s := by exact_mod_cast hs1
  have hsr : (s : ℝ) ≤ r := by
    have : (s : ℝ) ≤ (s : ℝ) ^ (1 + δ) := by
      calc (s : ℝ) = (s : ℝ) ^ (1 : ℝ) := (Real.rpow_one _).symm
        _ ≤ _ := Real.rpow_le_rpow_of_exponent_le hsR (by linarith)
    linarith
  have hr2 : Real.log r ≤ 2 * Real.log s := by
    have h2 : (r : ℝ) ≤ (s : ℝ) ^ 2 := by exact_mod_cast hrs2
    have := Real.log_le_log (by positivity) h2
    rwa [Real.log_pow, Nat.cast_ofNat] at this
  have hσ : 0 ≤ (Real.log h) ^ σ₀ := by
    have h1 : (1 : ℝ) ≤ h := by exact_mod_cast (by omega : 1 ≤ h)
    exact Real.rpow_nonneg (Real.log_nonneg h1) _
  have hs4 := four_le_of _ _ _ hσ hsum hr2
  have hlsr : Real.log s ≤ Real.log r := Real.log_le_log (by positivity) hsr
  exact ⟨hs4, le_trans hs4 hlsr, hr1, hs1, hrh, hsh, hL, hsr, hrsH⟩

/-- **Admissibility on LONG-right** (constant 4). -/
theorem admLR (h H r s : ℕ) (δ : ℝ) (hδ0 : 0 < δ) (hh : 2 ≤ h) (hHh : H ≤ h)
    (hG : GeoLR h H δ r s) :
    4 * (Real.log h) ^ σ₀ ≤ Real.log r ∧ 4 * (Real.log h) ^ σ₀ ≤ Real.log s ∧
      1 ≤ r ∧ 1 ≤ s ∧ (r : ℝ) ≤ h ∧ (s : ℝ) ≤ h ∧
      (r : ℝ) ^ (1 + δ) < s ∧ (r : ℝ) ≤ s ∧
      ((r : ℝ) * s) * Real.exp ((Real.log h) ^ (1 / 4 : ℝ)) ≤ H := by
  obtain ⟨hZ, -, hR, hgate⟩ := hG
  obtain ⟨hr1, hs1, hrh, hsh, hrsH, hsum⟩ := adm_core h H r s hh hHh hZ hgate
  obtain ⟨-, hsr2, -⟩ := hgate
  unfold longInverseRight at hR
  have hrR : (1 : ℝ) ≤ r := by exact_mod_cast hr1
  have hsR : (1 : ℝ) ≤ s := by exact_mod_cast hs1
  have hrs : (r : ℝ) ≤ s := by
    have : (r : ℝ) ≤ (r : ℝ) ^ (1 + δ) := by
      calc (r : ℝ) = (r : ℝ) ^ (1 : ℝ) := (Real.rpow_one _).symm
        _ ≤ _ := Real.rpow_le_rpow_of_exponent_le hrR (by linarith)
    linarith
  have hs2 : Real.log s ≤ 2 * Real.log r := by
    have h2 : (s : ℝ) ≤ (r : ℝ) ^ 2 := by exact_mod_cast hsr2
    have := Real.log_le_log (by positivity) h2
    rwa [Real.log_pow, Nat.cast_ofNat] at this
  have hσ : 0 ≤ (Real.log h) ^ σ₀ := by
    have h1 : (1 : ℝ) ≤ h := by exact_mod_cast (by omega : 1 ≤ h)
    exact Real.rpow_nonneg (Real.log_nonneg h1) _
  have hr4 := four_le_of _ _ _ hσ (by linarith) hs2
  have hlrs : Real.log r ≤ Real.log s := Real.log_le_log (by positivity) hrs
  exact ⟨hr4, le_trans hr4 hlrs, hr1, hs1, hrh, hsh, hR, hrs, hrsH⟩

/-- `GeoLL` is convex in `r` for fixed `s`. -/
theorem geoLL_convex_r (h H : ℕ) (δ : ℝ) (s : ℕ) :
    ∀ a b c, a ≤ b → b ≤ c → GeoLL h H δ a s → GeoLL h H δ c s → GeoLL h H δ b s := by
  intro a b c hab hbc ha hc
  obtain ⟨ha1, ha2, ha3, ha4, ha5, ha6⟩ := ha
  obtain ⟨hc1, hc2, hc3, hc4, hc5, hc6⟩ := hc
  unfold longInverseLeft at ha3 hc3
  have habR : (a : ℝ) ≤ b := by exact_mod_cast hab
  refine ⟨lt_of_lt_of_le ha1 (Nat.mul_le_mul_right _ hab), le_trans (by
    have := Nat.mul_le_mul_right s hbc; omega) hc2, ?_, ?_, ?_, ?_⟩
  · unfold longInverseLeft; exact lt_of_lt_of_le ha3 habR
  · exact le_trans (by exact_mod_cast Nat.mul_le_mul_right s hbc) hc4
  · exact le_trans ha5 (Nat.pow_le_pow_left hab 2)
  · exact le_trans hbc hc6

/-- `GeoLR` is convex in `s` for fixed `r`. -/
theorem geoLR_convex_s (h H : ℕ) (δ : ℝ) (r : ℕ) :
    ∀ a b c, a ≤ b → b ≤ c → GeoLR h H δ r a → GeoLR h H δ r c → GeoLR h H δ r b := by
  intro a b c hab hbc ha hc
  obtain ⟨ha1, ha2, ha3, ha4, ha5, ha6⟩ := ha
  obtain ⟨hc1, hc2, hc3, hc4, hc5, hc6⟩ := hc
  unfold longInverseRight at ha3 hc3
  have habR : (a : ℝ) ≤ b := by exact_mod_cast hab
  refine ⟨lt_of_lt_of_le ha1 (Nat.mul_le_mul_left _ hab), le_trans (by
    have := Nat.mul_le_mul_left r hbc; omega) hc2, ?_, ?_, ?_, ?_⟩
  · unfold longInverseRight; exact lt_of_lt_of_le ha3 habR
  · exact le_trans (by exact_mod_cast Nat.mul_le_mul_left r hbc) hc4
  · exact le_trans hbc hc5
  · exact le_trans ha6 (Nat.pow_le_pow_left hab 2)

/-- The two LONG orientations are disjoint. -/
lemma not_both (δ : ℝ) (hδ : 0 ≤ δ) (r s : ℕ) :
    ¬ (longInverseLeft δ r s ∧ longInverseRight δ r s) := by
  rintro ⟨hL, hR⟩
  unfold longInverseLeft at hL
  unfold longInverseRight at hR
  have hr0 : (0 : ℝ) ≤ r := by positivity
  have hs0 : (0 : ℝ) ≤ s := by positivity
  have hrpos : (0 : ℝ) < r := lt_of_le_of_lt (Real.rpow_nonneg hs0 _) hL
  have hspos : (0 : ℝ) < s := lt_of_le_of_lt (Real.rpow_nonneg hr0 _) hR
  have hr1 : (1 : ℝ) ≤ r := by
    have : 0 < r := by exact_mod_cast hrpos
    exact_mod_cast this
  have hs1 : (1 : ℝ) ≤ s := by
    have : 0 < s := by exact_mod_cast hspos
    exact_mod_cast this
  have a1 : (s : ℝ) ≤ (s : ℝ) ^ (1 + δ) := by
    calc (s : ℝ) = (s : ℝ) ^ (1 : ℝ) := (Real.rpow_one _).symm
      _ ≤ _ := Real.rpow_le_rpow_of_exponent_le hs1 (by linarith)
  have a2 : (r : ℝ) ≤ (r : ℝ) ^ (1 + δ) := by
    calc (r : ℝ) = (r : ℝ) ^ (1 : ℝ) := (Real.rpow_one _).symm
      _ ≤ _ := Real.rpow_le_rpow_of_exponent_le hr1 (by linarith)
  linarith

/-! ## Constant-4 versions of the abstract eventual lemmas -/

lemma s_large4 (x₀ : ℝ) :
    ∃ Λ₀ : ℝ, 1 ≤ Λ₀ ∧ ∀ Λ : ℝ, Λ₀ ≤ Λ → ∀ x : ℝ, 0 < x → 4 * Λ ^ σ₀ ≤ Real.log x → x₀ ≤ x := by
  obtain ⟨Λ₀, hΛ₀, h⟩ := GoldC.QuillonLam.exp_ge x₀ 4 σ₀ (by norm_num) GoldC.QuillonEv.σ₀_pos
  refine ⟨Λ₀, hΛ₀, fun Λ hΛ x hx hlog => ?_⟩
  calc x₀ ≤ Real.exp (4 * Λ ^ σ₀) := h Λ hΛ
    _ ≤ Real.exp (Real.log x) := Real.exp_le_exp.2 hlog
    _ = x := Real.exp_log hx

theorem sdecay4 (m : ℕ) (c K : ℝ) (hc : 0 < c) (hK : 0 ≤ K) :
    ∃ Λ₀ : ℝ, 1 ≤ Λ₀ ∧ ∀ Λ : ℝ, Λ₀ ≤ Λ → ∀ x : ℝ, 0 < x → 4 * Λ ^ σ₀ ≤ Real.log x →
      (1 + Real.log x) ^ m * x ^ (-c) ≤ Λ ^ (-K) := by
  obtain ⟨x₀, hx₀, hlog⟩ := GoldC.QuillonAsymp.one_add_log_pow_le m (c / 2) (by positivity)
  obtain ⟨Λ₁, hΛ₁, h1⟩ := s_large4 x₀
  obtain ⟨Λ₂, hΛ₂, h2⟩ := GoldC.QuillonLam.decay 0 K (4 * (c / 2)) σ₀ (by linarith) (by positivity)
    GoldC.QuillonEv.σ₀_pos
  refine ⟨max Λ₁ Λ₂, le_trans hΛ₁ (le_max_left _ _), fun Λ hΛ x hx hlx => ?_⟩
  have hΛ1 : Λ₁ ≤ Λ := le_trans (le_max_left _ _) hΛ
  have hΛ2 : Λ₂ ≤ Λ := le_trans (le_max_right _ _) hΛ
  have hxx₀ := h1 Λ hΛ1 x hx hlx
  have hpow := hlog x hxx₀
  have hdec := h2 Λ hΛ2
  have hΛ0 : 0 < Λ := by linarith
  rw [Real.rpow_zero, one_mul] at hdec
  have hx1 : 0 < x ^ (-c) := Real.rpow_pos_of_pos hx _
  calc (1 + Real.log x) ^ m * x ^ (-c) ≤ x ^ (c / 2) * x ^ (-c) :=
        mul_le_mul_of_nonneg_right hpow hx1.le
    _ = x ^ (-(c / 2)) := by rw [← Real.rpow_add hx]; ring_nf
    _ = Real.exp (-(c / 2) * Real.log x) := by rw [Real.rpow_def_of_pos hx]; ring_nf
    _ ≤ Real.exp (-(4 * (c / 2) * Λ ^ σ₀)) := by
        apply Real.exp_le_exp.2; nlinarith
    _ ≤ Λ ^ (-K) := hdec

theorem edecay4 (K : ℝ) (hK : 0 ≤ K) :
    ∃ Λ₀ : ℝ, 1 ≤ Λ₀ ∧ ∀ Λ : ℝ, Λ₀ ≤ Λ → ∀ x : ℝ, 0 < x → 4 * Λ ^ σ₀ ≤ Real.log x →
      x ^ (-(Λ ^ (-(1 / 200 : ℝ)))) ≤ Λ ^ (-K) := by
  have hτ : 0 < σ₀ - 1 / 200 := by unfold σ₀; norm_num
  obtain ⟨Λ₀, hΛ₀, h⟩ := GoldC.QuillonLam.decay 0 K 4 (σ₀ - 1 / 200) (by linarith) (by norm_num) hτ
  refine ⟨Λ₀, hΛ₀, fun Λ hΛ x hx hlog => ?_⟩
  have hΛ0 : 0 < Λ := by linarith
  have h1 := h Λ hΛ
  rw [Real.rpow_zero, one_mul] at h1
  have he : Λ ^ (-(1 / 200 : ℝ)) * (4 * Λ ^ σ₀) = 4 * Λ ^ (σ₀ - 1 / 200) := by
    rw [mul_left_comm, ← Real.rpow_add hΛ0]; ring_nf
  have hpos : 0 ≤ Λ ^ (-(1 / 200 : ℝ)) := by positivity
  calc x ^ (-(Λ ^ (-(1 / 200 : ℝ)))) = Real.exp (-(Λ ^ (-(1 / 200 : ℝ))) * Real.log x) := by
        rw [Real.rpow_def_of_pos hx]; ring_nf
    _ ≤ Real.exp (-(4 * Λ ^ (σ₀ - 1 / 200))) := by
        apply Real.exp_le_exp.2
        rw [← he]; nlinarith [mul_le_mul_of_nonneg_left hlog hpos]
    _ ≤ Λ ^ (-K) := h1

end GoldC.QuillonLSetup

#print axioms GoldC.QuillonLSetup.admLL
#print axioms GoldC.QuillonLSetup.admLR
#print axioms GoldC.QuillonLSetup.geoLL_convex_r
#print axioms GoldC.QuillonLSetup.geoLR_convex_s
#print axioms GoldC.QuillonLSetup.not_both
#print axioms GoldC.QuillonLSetup.sdecay4
#print axioms GoldC.QuillonLSetup.edecay4
