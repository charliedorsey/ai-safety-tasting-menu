import OrielUpper.Variation2
import OrielUpper.Principal
import OrielUpper.CRT
import OrielUpper.BV
import OrielUpper.Harmonic

/-!
# Oriel Upper — the inner sums of the fixed-variable estimate

For a fixed modulus `m` (the fixed partner `r` or `s`), `Q = P m`, and a divisor
`e`, the inner sum is

`Inner e = ∑_{A/e < k ≤ B/e} 1[(e k, Q) = 1] ψ_{(e k mod P, e k mod m)}(X/(e k)) / (e k)`.

* `oriel_inner_tail`: `|Inner e| ≤ (2P+2) B ℓ / e` (always).
* `oriel_inner_head`: for `(e, Q) = 1`,
  `|Inner e| ≤ τ(m)(2P+1) B ℓ/(m e) + P m · B/A · (2X/(A m) + 4P + 5)`
  (exact CRT reindexing + principal cancellation for the main term, BV for the rest).
-/

open Finset
open scoped ArithmeticFunction.Moebius

namespace OrielUpper

variable {P : ℕ} [NeZero P]

/-- The inner sum attached to a divisor `e`. -/
noncomputable def innerS (m H : ℕ) (Λ : ZMod P → ℝ) (α β : ZMod P) (X0 : ℝ) (A Bn e : ℕ) : ℝ :=
  ∑ k ∈ Ioc (A / e) (Bn / e),
    if Nat.Coprime (e * k) (P * m) then
      psiR m H Λ α β ((e * k : ℕ) : ZMod P) ((e * k : ℕ) : ZMod m) (X0 / (e * k : ℕ)) /
        (e * k : ℕ)
    else 0

lemma isUnit_of_coprime_mul_left {n P m : ℕ} (h : Nat.Coprime n (P * m)) :
    IsUnit ((n : ℕ) : ZMod P) :=
  (ZMod.isUnit_iff_coprime n P).mpr (Nat.Coprime.coprime_mul_right_right h)

lemma isUnit_of_coprime_mul_right {n P m : ℕ} (h : Nat.Coprime n (P * m)) :
    IsUnit ((n : ℕ) : ZMod m) :=
  (ZMod.isUnit_iff_coprime n m).mpr (Nat.Coprime.coprime_mul_left_right h)

theorem oriel_inner_tail {m H : ℕ} [NeZero m] {Λ : ZMod P → ℝ} {B : ℝ}
    (hB : ∀ z, |Λ z| ≤ B) {α β : ZMod P} (hβ : IsUnit β) (hmP : Nat.Coprime m P)
    {X0 : ℝ} (hX0 : 0 ≤ X0) {A Bn e : ℕ} (hA : 1 ≤ A) (hAB : A ≤ Bn) (he : 1 ≤ e) :
    |innerS m H Λ α β X0 A Bn e| ≤
      (2 * P + 2) * B * (1 + Real.log ((Bn : ℝ) / A)) / e := by
  have hm : 0 < m := NeZero.pos m
  have hmPu : IsUnit (m : ZMod P) := (ZMod.isUnit_iff_coprime m P).mpr hmP
  have hB0 : 0 ≤ B := le_trans (abs_nonneg _) (hB 0)
  have her : (0 : ℝ) < e := by exact_mod_cast (show 0 < e by omega)
  unfold innerS
  refine (abs_sum_le_sum_abs _ _).trans ?_
  calc ∑ k ∈ Ioc (A / e) (Bn / e), |if Nat.Coprime (e * k) (P * m) then
          psiR m H Λ α β ((e * k : ℕ) : ZMod P) ((e * k : ℕ) : ZMod m) (X0 / (e * k : ℕ)) /
            (e * k : ℕ) else 0|
      ≤ ∑ k ∈ Ioc (A / e) (Bn / e), (2 * P + 2) * B / e * (1 / k) := by
        apply sum_le_sum
        intro k hk
        have hk1 : 1 ≤ k := Nat.lt_of_le_of_lt (Nat.zero_le _) (mem_Ioc.mp hk).1
        have hkr : (0 : ℝ) < k := by exact_mod_cast (show 0 < k by omega)
        split_ifs with hc
        · have hpos : (0 : ℝ) < (e * k : ℕ) := by positivity
          have hψ := oriel_psi_bound hm hB hmPu hβ (isUnit_of_coprime_mul_left hc)
            (isUnit_of_coprime_mul_right hc) (H := H) (α := α) (x := X0 / (e * k : ℕ)) (by positivity)
          rw [abs_div, abs_of_pos hpos]
          have e1 : (2 * P + 2) * B / e * (1 / k) = (2 * P + 2) * B / (e * k : ℕ) := by
            push_cast; field_simp
          rw [e1]
          exact div_le_div_of_nonneg_right hψ hpos.le
        · simp only [abs_zero]; positivity
    _ = (2 * P + 2) * B / e * ∑ k ∈ Ioc (A / e) (Bn / e), (1 : ℝ) / k := by rw [mul_sum]
    _ ≤ (2 * P + 2) * B / e * (1 + Real.log ((Bn : ℝ) / A)) := by
        apply mul_le_mul_of_nonneg_left (oriel_harmonic_div hA hAB he) (by positivity)
    _ = _ := by ring

end OrielUpper
