import GoldC.QuillonResPhysical
import GoldC.QuillonLWR

/-!
# Quillon LONG L8: LONG-right mass tools

* `rough_ev4`, `ceil_le_of_log4`: constant-4 copies of the rough-set mass (crude sieve).
* `rankin_many`: `Σ_{C⊆T, |C|≥K} ω(C) ≤ (∏_T(1+1/(p−3)))³ / 3^K` (Rankin with weight `3^{|C|}`).
* `three_pow_K0`: `3^{K₀} ≥ Λ^{100}` for `K₀ = ⌈100 log Λ⌉`.
* `dsum_bound_swap`: `dsum_bound` with the outer variable `C`.
* `C_rough_of`: `C` missing `J_R(B)` with `s ≤ r²` forces `p ≤ X ∨ s^{ε/2} < p` for `p ∈ C`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonLRes

open GoldC.QuillonEv GoldC.QuillonSetup GoldC.QuillonLam GoldC.QuillonCEv GoldC.QuillonCFinal
  GoldC.QuillonREv GoldC.QuillonWContext GoldC.QuillonResPhysical

/-- the rough-set mass, eventually. -/
theorem rough_ev4 :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ h : ℕ, Λ₀ ≤ Real.log h → ∀ (T : Finset ℕ), (∀ p ∈ T, p.Prime ∧ 5 ≤ p) →
      ∀ (Xt : ℕ), (Xt : ℝ) ≤ 3 * (Real.log h) ^ (200 : ℝ) →
      ∀ (u : ℝ), 0 < u → u ≤ 1 → 16 * Real.log h ≤ Real.exp (4 * u * (Real.log h) ^ σ₀) →
      ∑ B ∈ T.powerset, (if ⌈Real.exp (4 * (Real.log h) ^ σ₀)⌉₊ ≤ ∏ p ∈ B, p ∧ ∏ p ∈ B, p ≤ h ∧
          ∀ p ∈ B, p < Xt ∨ ((∏ q ∈ B, q : ℕ) : ℝ) ^ u < p then ωR B else 0) ≤
        (Real.log h) ^ (1 / 4000 : ℝ) * (1 + 1 / u ^ 5) := by
  obtain ⟨Λ₁, hΛ₁, hpl⟩ := polylog_le 11 (1 / 8000) (by norm_num)
  obtain ⟨Λ₂, hΛ₂, hc⟩ := const_le_rpow (Real.exp 15 * 403 ^ 10 * 8748) (1 / 8000) (by norm_num)
  refine ⟨max 16 (max Λ₁ Λ₂), by norm_num, ?_⟩
  intro h hΛ T hT Xt hXt u hu0 hu1 hub
  have L1 : Λ₁ ≤ Real.log h := le_trans (by simp) hΛ
  have L2 : Λ₂ ≤ Real.log h := le_trans (by simp) hΛ
  have L0 : (16 : ℝ) ≤ Real.log h := le_trans (by simp) hΛ
  set Λ := Real.log h with hΛdef
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  have hlogΛ : 0 ≤ Real.log Λ := Real.log_nonneg hΛ1
  -- `h ≥ 8`, `m = log₂ h ≥ 3`
  have hh0 : (0 : ℝ) < h := by
    rcases Nat.eq_zero_or_pos h with h0 | h0
    · exfalso; rw [hΛdef, h0] at L0; simp at L0; linarith
    · exact_mod_cast h0
  set m := Nat.log 2 h with hm
  have hm2Λ : (m : ℝ) ≤ 2 * Λ := by
    have := natlog_le_of h Λ le_rfl
    rw [max_eq_left hΛ0.le] at this; exact this
  have hm3 : 3 ≤ m := by
    have h8 : 8 ≤ h := by
      by_contra hc'; push_neg at hc'
      have : (h : ℝ) ≤ 7 := by exact_mod_cast (by omega : h ≤ 7)
      have : Real.log h ≤ Real.log 7 := Real.log_le_log hh0 this
      have : Real.log 7 < 7 := lt_of_le_of_lt (Real.log_le_sub_one_of_pos (by norm_num)) (by norm_num)
      linarith
    have : Nat.log 2 8 ≤ Nat.log 2 h := Nat.log_mono_right h8
    have h83 : Nat.log 2 8 = 3 := by decide
    omega
  set k₀ := Nat.log 2 m + 3 with hk₀
  have hpow1 : 2 ^ Nat.log 2 m ≤ m := Nat.pow_log_le_self 2 (by omega)
  have hpow2 : m < 2 ^ (Nat.log 2 m + 1) := Nat.lt_pow_succ_log_self (by norm_num) m
  have e8 : 2 ^ k₀ = 8 * 2 ^ Nat.log 2 m := by rw [hk₀, pow_add]; ring
  have e2 : 2 ^ (Nat.log 2 m + 1) = 2 * 2 ^ Nat.log 2 m := by rw [pow_succ]; ring
  have hk₀le : (2 : ℝ) ^ k₀ ≤ 16 * Λ := by
    have : 2 ^ k₀ ≤ 8 * m := by rw [e8]; omega
    have : ((2 ^ k₀ : ℕ) : ℝ) ≤ 8 * m := by exact_mod_cast this
    push_cast at this; linarith
  have hk₀ge : 3 * (m : ℝ) ≤ (2 : ℝ) ^ k₀ - 3 := by
    have : 4 * m < 2 ^ k₀ := by rw [e8]; rw [e2] at hpow2; omega
    have : ((4 * m : ℕ) : ℝ) < ((2 ^ k₀ : ℕ) : ℝ) := by exact_mod_cast this
    push_cast at this
    have : (3 : ℝ) ≤ m := by exact_mod_cast hm3
    linarith
  -- `R₀^u ≥ exp(4uΛ^σ)`
  set R₀ := ⌈Real.exp (4 * Λ ^ σ₀)⌉₊ with hR₀
  have hR₀u : Real.exp (4 * u * Λ ^ σ₀) ≤ (R₀ : ℝ) ^ u := by
    have h1 : Real.exp (4 * Λ ^ σ₀) ≤ R₀ := Nat.le_ceil _
    calc Real.exp (4 * u * Λ ^ σ₀) = (Real.exp (4 * Λ ^ σ₀)) ^ u := by
          rw [← Real.exp_mul]; ring_nf
      _ ≤ (R₀ : ℝ) ^ u := Real.rpow_le_rpow (by positivity) h1 hu0.le
  have hK₀ : 3 ≤ k₀ := by omega
  set K := Nat.log 2 Xt with hK
  have hXK : ∀ p ∈ T, p < Xt → p < 2 ^ (K + 1) := fun p _ hp =>
    lt_trans hp (Nat.lt_pow_succ_log_self (by norm_num) Xt)
  have hrt := GoldC.QuillonResidue.rough_total T hT Xt u hu0 hu1 R₀ h k₀ K m hK₀
    (le_trans hk₀le (le_trans hub hR₀u)) hXK (Nat.lt_pow_succ_log_self (by norm_num) h)
  refine le_trans hrt ?_
  -- `κ ≤ e`
  have hκ : Real.exp (3 * (Nat.log 2 h : ℝ) / ((2 : ℝ) ^ k₀ - 3)) ≤ Real.exp 1 := by
    apply Real.exp_le_exp.2
    have h3m : (3 : ℝ) ≤ m := by exact_mod_cast hm3
    have hpos : 0 < (2 : ℝ) ^ k₀ - 3 := by linarith
    rw [div_le_one hpos]
    linarith
  -- `K + 1 ≤ 403(1 + log Λ)`
  have hKb : (K : ℝ) + 1 ≤ 403 * (1 + Real.log Λ) := by
    rcases Nat.eq_zero_or_pos Xt with h0 | hpos
    · rw [hK, h0]; simp; linarith
    · have hXt0 : (0 : ℝ) < Xt := by exact_mod_cast hpos
      have hlogX : Real.log Xt ≤ 2 + 200 * Real.log Λ := by
        have := Real.log_le_log hXt0 hXt
        rw [Real.log_mul (by norm_num) (by positivity), Real.log_rpow hΛ0] at this
        have : Real.log 3 ≤ 2 := by
          have := Real.log_le_sub_one_of_pos (show (0 : ℝ) < 3 by norm_num); linarith
        linarith
      have := natlog_le_of Xt (2 + 200 * Real.log Λ) hlogX
      rw [max_eq_left (by positivity)] at this
      linarith
  have hIb : 1 + Real.log ((m : ℝ) + 1) ≤ 3 * (1 + Real.log Λ) := by
    have h1 : (m : ℝ) + 1 ≤ 3 * Λ := by linarith
    have := Real.log_le_log (by positivity) h1
    rw [Real.log_mul (by norm_num) hΛ0.ne'] at this
    have : Real.log 3 ≤ 2 := by
      have := Real.log_le_sub_one_of_pos (show (0 : ℝ) < 3 by norm_num); linarith
    linarith
  have hP := hpl Λ L1
  have hC := hc Λ L2
  set P := 1 + Real.log Λ with hPdef
  have hP1 : 1 ≤ P := by rw [hPdef]; linarith
  have hu5 : 0 < u ^ 5 := by positivity
  have hK0 : (0 : ℝ) ≤ (K : ℝ) + 1 := by positivity
  have hKp : ((K : ℝ) + 1) ^ 10 ≤ 403 ^ 10 * P ^ 10 := by
    rw [← mul_pow]; exact pow_le_pow_left₀ hK0 hKb 10
  have hP10 : P ^ 10 ≤ P ^ 11 := pow_le_pow_right₀ hP1 (by norm_num)
  have hc8 : Real.exp 15 * 403 ^ 10 * 8748 * P ^ 11 ≤ Λ ^ (1 / 4000 : ℝ) := by
    calc Real.exp 15 * 403 ^ 10 * 8748 * P ^ 11 ≤ Λ ^ (1 / 8000 : ℝ) * Λ ^ (1 / 8000 : ℝ) :=
          mul_le_mul hC hP (by positivity) (by positivity)
      _ = Λ ^ (1 / 4000 : ℝ) := by rw [rp hΛ0]; norm_num
  have hlogI0 : 0 ≤ 1 + Real.log ((m : ℝ) + 1) := by
    have := Real.log_nonneg (show (1 : ℝ) ≤ m + 1 by linarith); linarith
  have hκ0 : 0 ≤ Real.exp (3 * (Nat.log 2 h : ℝ) / ((2 : ℝ) ^ k₀ - 3)) := (Real.exp_pos _).le
  have e5 : Real.exp 1 * Real.exp 4 = Real.exp 5 := by rw [← Real.exp_add]; norm_num
  have e15 : Real.exp 10 * Real.exp 5 = Real.exp 15 := by rw [← Real.exp_add]; norm_num
  calc Real.exp 10 * ((K : ℝ) + 1) ^ 10 *
        (1 + Real.exp (3 * (Nat.log 2 h : ℝ) / ((2 : ℝ) ^ k₀ - 3)) * Real.exp 4 * 2916 *
          (1 + Real.log ((m : ℝ) + 1)) / u ^ 5)
      ≤ Real.exp 10 * (403 ^ 10 * P ^ 10) *
        (1 + Real.exp 1 * Real.exp 4 * 2916 * (3 * P) / u ^ 5) := by
        gcongr
    _ = Real.exp 10 * 403 ^ 10 * P ^ 10 + Real.exp 15 * 403 ^ 10 * 8748 * P ^ 11 * (1 / u ^ 5) := by
        rw [e5, ← e15]; field_simp; ring
    _ ≤ Real.exp 15 * 403 ^ 10 * 8748 * P ^ 11 + Real.exp 15 * 403 ^ 10 * 8748 * P ^ 11 * (1 / u ^ 5) := by
        have h10 : Real.exp 10 ≤ Real.exp 15 * 8748 := by
          have := Real.exp_le_exp.2 (show (10 : ℝ) ≤ 15 by norm_num)
          nlinarith [Real.exp_pos 15]
        have hp10 : 0 ≤ P ^ 10 := by positivity
        apply add_le_add _ le_rfl
        calc Real.exp 10 * 403 ^ 10 * P ^ 10 ≤ (Real.exp 15 * 8748) * 403 ^ 10 * P ^ 10 := by gcongr
          _ = Real.exp 15 * 403 ^ 10 * 8748 * P ^ 10 := by ring
          _ ≤ Real.exp 15 * 403 ^ 10 * 8748 * P ^ 11 := by gcongr
    _ ≤ Λ ^ (1 / 4000 : ℝ) + Λ ^ (1 / 4000 : ℝ) * (1 / u ^ 5) := by gcongr
    _ = Λ ^ (1 / 4000 : ℝ) * (1 + 1 / u ^ 5) := by ring

lemma ceil_le_of_log4 {Λ : ℝ} {n : ℕ} (hn : 4 * Λ ^ σ₀ ≤ Real.log n) (hn1 : 1 ≤ n) :
    ⌈Real.exp (4 * Λ ^ σ₀)⌉₊ ≤ n := by
  apply Nat.ceil_le.2
  have hn0 : (0 : ℝ) < n := by exact_mod_cast hn1
  calc Real.exp (4 * Λ ^ σ₀) ≤ Real.exp (Real.log n) := Real.exp_le_exp.2 hn
    _ = n := Real.exp_log hn0

lemma rankin_many (T : Finset ℕ) (hT : ∀ p ∈ T, 5 ≤ p) (K : ℕ) :
    ∑ C ∈ T.powerset, (if K ≤ C.card then ωR C else 0) ≤
      (∏ p ∈ T, (1 + 1 / ((p : ℝ) - 3))) ^ 3 / 3 ^ K := by
  have hx : ∀ p ∈ T, 0 ≤ 1 / ((p : ℝ) - 3) := fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast hT p hp
    exact div_nonneg zero_le_one (by linarith)
  have h3K : (0 : ℝ) < 3 ^ K := by positivity
  have hpt : ∀ C ∈ T.powerset, (if K ≤ C.card then ωR C else 0) ≤
      (∏ p ∈ C, (3 * (1 / ((p : ℝ) - 3)))) / 3 ^ K := by
    intro C hC
    have hCT := mem_powerset.1 hC
    have hω : 0 ≤ ωR C := prod_nonneg fun p hp => hx p (hCT hp)
    have e : ∏ p ∈ C, (3 * (1 / ((p : ℝ) - 3))) = 3 ^ C.card * ωR C := by
      rw [prod_mul_distrib, prod_const]; rfl
    rw [e]
    split_ifs with hK
    · rw [le_div_iff₀ h3K]
      have : (3 : ℝ) ^ K ≤ 3 ^ C.card := pow_le_pow_right₀ (by norm_num) hK
      nlinarith
    · positivity
  calc _ ≤ ∑ C ∈ T.powerset, (∏ p ∈ C, (3 * (1 / ((p : ℝ) - 3)))) / 3 ^ K := sum_le_sum hpt
    _ = (∏ p ∈ T, (1 + 3 * (1 / ((p : ℝ) - 3)))) / 3 ^ K := by rw [← sum_div, prod_one_add]
    _ ≤ _ := by
        apply div_le_div_of_nonneg_right _ h3K.le
        rw [← prod_pow]
        refine Finset.prod_le_prod₀ (fun p hp => by have := hx p hp; positivity) fun p hp => ?_
        have := hx p hp
        nlinarith [sq_nonneg (1 / ((p : ℝ) - 3)), pow_two_nonneg (1 / ((p : ℝ) - 3)),
          mul_nonneg this (sq_nonneg (1 / ((p : ℝ) - 3)))]

lemma three_pow_K0 (h : ℕ) (hΛ : 1 ≤ Real.log h) :
    (Real.log h) ^ (100 : ℝ) ≤ (3 : ℝ) ^ GoldC.QuillonLWR.K0 h := by
  set Λ := Real.log h
  have hΛ0 : 0 < Λ := by linarith
  have hK : 100 * Real.log Λ ≤ (GoldC.QuillonLWR.K0 h : ℝ) := Nat.le_ceil _
  have hl3 : 1 ≤ Real.log 3 := by
    rw [Real.le_log_iff_exp_le (by norm_num)]
    have := Real.exp_one_lt_d9; linarith
  have e : (3 : ℝ) ^ GoldC.QuillonLWR.K0 h = Real.exp (GoldC.QuillonLWR.K0 h * Real.log 3) := by
    rw [Real.exp_nat_mul, Real.exp_log (by norm_num)]
  rw [e, Real.rpow_def_of_pos hΛ0]
  apply Real.exp_le_exp.2
  have h0 : (0 : ℝ) ≤ GoldC.QuillonLWR.K0 h := Nat.cast_nonneg _
  nlinarith

lemma dsum_bound_swap (T : Finset ℕ) (hT : ∀ p ∈ T, 5 ≤ p) (c : Finset ℕ → Finset ℕ → Prop)
    [∀ B C, Decidable (c B C)] (cB : Finset ℕ → Prop) [DecidablePred cB]
    (cC : Finset ℕ → Finset ℕ → Prop) [∀ B C, Decidable (cC B C)]
    (hc : ∀ B ∈ T.powerset, ∀ C ∈ T.powerset, c B C → cB C ∧ cC C B)
    (F : Finset ℕ → Finset ℕ → ℝ) (Fm : ℝ) (hFm : 0 ≤ Fm)
    (hF : ∀ B C, c B C → |F B C| ≤ Fm) (IM : ℝ)
    (hIM : ∀ C ∈ T.powerset, cB C → ∑ B ∈ T.powerset, (if cC C B then ωR B else 0) ≤ IM) :
    |∑ B ∈ T.powerset, ∑ C ∈ T.powerset, (if c B C then ωR B * ωR C * F B C else 0)| ≤
      Fm * ((∑ C ∈ T.powerset, (if cB C then ωR C else 0)) * IM) := by
  have e : ∑ B ∈ T.powerset, ∑ C ∈ T.powerset, (if c B C then ωR B * ωR C * F B C else 0) =
      ∑ C ∈ T.powerset, ∑ B ∈ T.powerset, (if c B C then ωR C * ωR B * F B C else 0) := by
    rw [Finset.sum_comm]
    refine sum_congr rfl fun C _ => sum_congr rfl fun B _ => ?_
    split_ifs <;> ring
  rw [e]
  exact dsum_bound T hT (fun C B => c B C) cB cC (fun C hC B hB h => hc B hB C hC h)
    (fun C B => F B C) Fm hFm (fun C B h => hF B C h) IM hIM

/-- `C` misses `J_R(B)` (and `s ≤ r²`): every prime of `C` is `≤ X` or `> s^{ε/2}`. -/
lemma C_rough_of (h : ℕ) (hΛ1 : 1 ≤ Real.log h) (T B C : Finset ℕ) (hCB : C ⊆ T \ B)
    (hJR : ¬ (C ∩ GoldC.QuillonRPhysical.JR h T B).Nonempty) (hr1 : 1 ≤ ∏ p ∈ B, p)
    (hsr2 : ∏ p ∈ C, p ≤ (∏ p ∈ B, p) ^ 2) :
    ∀ p ∈ C, p < Xp h + 1 ∨ ((∏ q ∈ C, q : ℕ) : ℝ) ^ (εp h / 2) < p := by
  set r := ∏ p ∈ B, p
  set s := ∏ p ∈ C, p
  obtain ⟨hε0, -⟩ := GoldC.QuillonCPhysical.εp_le_one (h := h) hΛ1
  set ε := εp h
  have hrR : (1 : ℝ) ≤ r := by exact_mod_cast hr1
  have hr0 : (0 : ℝ) < r := by linarith
  have hX1 : 1 ≤ Xp h := by
    have : (1 : ℝ) ≤ Xp h := le_trans (Real.one_le_rpow hΛ1 (by norm_num)) (Xp_ge hΛ1)
    exact_mod_cast this
  intro p hp
  have hpJ : ¬ (Xp h < p ∧ p ≤ 2 ^ Kvp h r * Xp h) := by
    intro hJ
    exact hJR ⟨p, mem_inter.2 ⟨hp, mem_filter.2 ⟨hCB hp, hJ⟩⟩⟩
  by_cases hpX : p ≤ Xp h
  · exact Or.inl (by omega)
  · right
    push_neg at hpX
    have hp2 : 2 ^ Kvp h r * Xp h < p := by
      by_contra hc'; push_neg at hc'; exact hpJ ⟨hpX, hc'⟩
    have hρ1 : (1 : ℝ) ≤ (r : ℝ) ^ ε := Real.one_le_rpow hrR hε0
    obtain ⟨hKv1, -⟩ := Kv_bounds ((r : ℝ) ^ ε) hρ1 (Kvp h r) rfl
    have hX1R : (1 : ℝ) ≤ Xp h := by exact_mod_cast hX1
    have h3 : (r : ℝ) ^ ε < p := by
      have : ((2 ^ Kvp h r * Xp h : ℕ) : ℝ) < p := by exact_mod_cast hp2
      push_cast at this
      nlinarith
    have hsr2' : (s : ℝ) ≤ (r : ℝ) ^ (2 : ℝ) := by
      rw [show (2 : ℝ) = (2 : ℕ) by norm_num, Real.rpow_natCast]; exact_mod_cast hsr2
    have h4 : (s : ℝ) ^ (ε / 2) ≤ (r : ℝ) ^ ε := by
      calc (s : ℝ) ^ (ε / 2) ≤ ((r : ℝ) ^ (2 : ℝ)) ^ (ε / 2) :=
            Real.rpow_le_rpow (by positivity) hsr2' (by positivity)
        _ = (r : ℝ) ^ ε := by rw [← Real.rpow_mul hr0.le]; ring_nf
    exact lt_of_le_of_lt h4 h3

end GoldC.QuillonLRes

#print axioms GoldC.QuillonLRes.rough_ev4
#print axioms GoldC.QuillonLRes.rankin_many
#print axioms GoldC.QuillonLRes.three_pow_K0
#print axioms GoldC.QuillonLRes.dsum_bound_swap
#print axioms GoldC.QuillonLRes.C_rough_of
