import PaperB.FixedQ.SignedForbiddenSourceFacingTerminal
import PaperB.FixedQ.SignedForbiddenB1PrincipalExplicit

open scoped BigOperators

namespace PaperB.FixedQ

open PaperB.Closure

private lemma eidra_height_even
    {q a b h : ℕ}
    (ha : q.Coprime a) (hb : q.Coprime b)
    (hcompat : Nat.ModEq q (a + h) b)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    2 ∣ h := by
  by_cases h2q : 2 ∣ q
  · have h2a : Nat.Coprime 2 a := Nat.Coprime.of_dvd_left h2q ha
    have h2b : Nat.Coprime 2 b := Nat.Coprime.of_dvd_left h2q hb
    have haodd : Odd a := h2a.odd_of_left
    have hbodd : Odd b := h2b.odd_of_left
    obtain ⟨ka, hka⟩ := haodd
    obtain ⟨kb, hkb⟩ := hbodd
    have hmod2 : Nat.ModEq 2 (a + h) b := hcompat.of_dvd h2q
    unfold Nat.ModEq at hmod2
    rw [hka, hkb] at hmod2
    have : h % 2 = 0 := by omega
    exact Nat.dvd_iff_mod_eq_zero.mpr this
  · exact h2admissible h2q

private lemma eidra_gap_compat
    {q a b : ℕ} (hq : 0 < q) :
    Nat.ModEq q (a + positiveGapRepresentative q a b) b := by
  let A := a % q
  let B := b % q
  have hA : A < q := by dsimp [A]; exact Nat.mod_lt _ hq
  have hB : B < q := by dsimp [B]; exact Nat.mod_lt _ hq
  by_cases hEq : A = B
  · have hraw0 : (B + q - A) % q = 0 := by
      rw [hEq]
      simp
    unfold positiveGapRepresentative
    change (a + (if (B + q - A) % q = 0 then q else (B + q - A) % q)) % q = b % q
    rw [if_pos hraw0]
    simp [Nat.add_mod, A, B, hEq]
  · by_cases hAB : A < B
    · have hBA : B - A < q := by omega
      have hraw : (B + q - A) % q = B - A := by
        have heq : B + q - A = q + (B - A) := by omega
        rw [heq]
        simp [Nat.add_mod, Nat.mod_eq_of_lt hBA]
      have hpos : B - A ≠ 0 := by omega
      unfold positiveGapRepresentative
      change (a + (if (B + q - A) % q = 0 then q else (B + q - A) % q)) % q = b % q
      rw [hraw, if_neg hpos, Nat.add_mod]
      rw [Nat.mod_eq_of_lt hBA]
      have hsum : A + (B - A) = B := by omega
      rw [show a % q = A by rfl, hsum, Nat.mod_eq_of_lt hB]
    · have hBA : B < A := by omega
      have hraw_lt : B + q - A < q := by omega
      have hraw_pos : 0 < B + q - A := by omega
      have hraw : (B + q - A) % q = B + q - A :=
        Nat.mod_eq_of_lt hraw_lt
      have hne : B + q - A ≠ 0 := Nat.ne_of_gt hraw_pos
      unfold positiveGapRepresentative
      change (a + (if (B + q - A) % q = 0 then q else (B + q - A) % q)) % q = b % q
      rw [hraw, if_neg hne, Nat.add_mod]
      rw [Nat.mod_eq_of_lt hraw_lt]
      have hsum : A + (B + q - A) = B + q := by omega
      rw [show a % q = A by rfl, hsum, Nat.add_mod, Nat.mod_self, add_zero]
      simp [B, Nat.mod_eq_of_lt (Nat.mod_lt b hq)]

private lemma eidra_height_progression
    {q a b h : ℕ}
    (hq : 0 < q) (hh : 0 < h)
    (hcompat : Nat.ModEq q (a + h) b) :
    ∃ n : ℕ, h = positiveGapRepresentative q a b + n * q := by
  let g := positiveGapRepresentative q a b
  have hgpos : 0 < g := by
    dsimp [g]
    exact positiveGapRepresentative_pos hq
  have hgle : g ≤ q := by
    dsimp [g]
    exact positiveGapRepresentative_le_modulus hq
  have hgap : Nat.ModEq q (a + g) b := by
    dsimp [g]
    exact eidra_gap_compat hq
  have hhg : Nat.ModEq q h g :=
    Nat.ModEq.add_left_cancel' a (hcompat.trans hgap.symm)
  have hgh : g ≤ h := by
    by_cases hqh : q ≤ h
    · exact hgle.trans hqh
    · have hhq : h < q := by omega
      have hgq : g < q := by
        by_contra hng
        have hgeq : g = q := by omega
        unfold Nat.ModEq at hhg
        rw [Nat.mod_eq_of_lt hhq] at hhg
        rw [hgeq, Nat.mod_self] at hhg
        omega
      unfold Nat.ModEq at hhg
      rw [Nat.mod_eq_of_lt hhq, Nat.mod_eq_of_lt hgq] at hhg
      omega
  have hdvd : q ∣ h - g := hhg.symm.dvd'
  obtain ⟨n, hn⟩ := hdvd
  refine ⟨n, ?_⟩
  calc
    h = (h - g) + g := (Nat.sub_add_cancel hgh).symm
    _ = q * n + g := by rw [hn]
    _ = g + n * q := by ac_rfl

private lemma eidra_dvd_add_reflectedResidue
    {q b : ℕ} (hq : 0 < q) :
    q ∣ b + reflectedResidue q b := by
  rw [Nat.dvd_iff_mod_eq_zero]
  unfold reflectedResidue
  rw [Nat.add_mod]
  by_cases hs : b % q = 0
  · simp [hs]
  · have hslt : b % q < q := Nat.mod_lt b hq
    have hsub_lt : q - b % q < q := by omega
    simp only [Nat.mod_eq_of_lt hsub_lt]
    have hsum : b % q + (q - b % q) = q := by omega
    rw [hsum, Nat.mod_self]

private lemma eidra_reflected_compatibility
    {q a b h : ℕ} (hq : 0 < q)
    (hcompat : Nat.ModEq q (a + h) b) :
    Nat.ModEq q
      (reflectedResidue q b + h)
      (reflectedResidue q a) := by
  have hdbr : q ∣ b + reflectedResidue q b :=
    eidra_dvd_add_reflectedResidue hq
  have hdar : q ∣ a + reflectedResidue q a :=
    eidra_dvd_add_reflectedResidue hq
  have hbr0 : Nat.ModEq q (b + reflectedResidue q b) 0 :=
    Nat.modEq_zero_iff_dvd.mpr hdbr
  have har0 : Nat.ModEq q ((a + h) + reflectedResidue q b) 0 :=
    (hcompat.add_right (reflectedResidue q b)).trans hbr0
  have haa0 : Nat.ModEq q (a + reflectedResidue q a) 0 :=
    Nat.modEq_zero_iff_dvd.mpr hdar
  have hsum :
      Nat.ModEq q
        (a + (reflectedResidue q b + h))
        (a + reflectedResidue q a) := by
    have hraw := har0.trans haa0.symm
    simpa [Nat.add_assoc, Nat.add_comm, Nat.add_left_comm] using hraw
  exact Nat.ModEq.add_left_cancel' a hsum

def SourceFacingMainPrincipalContract : Prop :=
  ∀ q : ℕ, 0 < q → Squarefree q →
    ∀ ε : ℝ, 0 < ε →
      ∃ h0 : ℕ,
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          h0 ≤ h →
          |cStarReal q h * completedBooleanMain q a h -
            signedMainB1Principal q (h / 2)| ≤
              ε * Real.log (h : ℝ)

theorem manuscriptB1Kernel_sub_signedMainPrincipal_sublog
    (q : ℕ) (hq : 0 < q) :
    ∀ ε : ℝ, 0 < ε →
      ∃ h0 : ℕ,
        ∀ a b h : ℕ,
          q.Coprime a →
          q.Coprime b →
          Nat.ModEq q (a + h) b →
          (¬ 2 ∣ q → 2 ∣ h) →
          0 < h →
          h0 ≤ h →
          |PaperB.Closure.manuscriptB1Kernel q a b h -
            signedMainB1Principal q (h / 2)| ≤
              ε * Real.log (h : ℝ) := by
  have hP : 0 < fixedQPeriod q := by
    unfold fixedQPeriod
    exact Nat.lcm_pos (by norm_num) hq
  letI : NeZero (fixedQPeriod q) := ⟨Nat.ne_of_gt hP⟩
  intro ε hε
  let δ := ε / 2
  have hδ : 0 < δ := by dsimp [δ]; positivity
  obtain ⟨H0, hS1⟩ :=
    manuscriptS1Kernel_sub_principal_sublog_of_progression q hq δ hδ
  refine ⟨2 * H0 + 4, ?_⟩
  intro a b h ha hb hcompat h2 hh hlarge
  have heven : 2 ∣ h := eidra_height_even ha hb hcompat h2
  let H := h / 2
  have h2H : 2 * H = h := by
    dsimp [H]
    simpa [Nat.mul_comm] using Nat.div_mul_cancel heven
  have hH2 : 2 ≤ H := by omega
  have hH0 : H0 ≤ H := by omega
  obtain ⟨n1, hn1⟩ := eidra_height_progression hq hh hcompat
  have hprog1 : 2 * H = positiveGapRepresentative q a b + n1 * q :=
    h2H.trans hn1
  have hra : q.Coprime (reflectedResidue q a) :=
    coprime_reflectedResidue hq ha
  have hrb : q.Coprime (reflectedResidue q b) :=
    coprime_reflectedResidue hq hb
  have href : Nat.ModEq q
      (reflectedResidue q b + h) (reflectedResidue q a) :=
    eidra_reflected_compatibility hq hcompat
  obtain ⟨n2, hn2⟩ := eidra_height_progression hq hh href
  have hprog2 :
      2 * H = positiveGapRepresentative q
        (reflectedResidue q b) (reflectedResidue q a) + n2 * q :=
    h2H.trans hn2
  have h1 := hS1 a b H n1 ha hH2 hH0 hprog1
  have h2' := hS1 (reflectedResidue q b) (reflectedResidue q a)
    H n2 hrb hH2 hH0 hprog2
  have hsum :
      |PaperB.Closure.manuscriptB1Kernel q a b (2 * H) -
          signedMainB1Principal q H| ≤
        δ * Real.log (((2 * H : ℕ) : ℝ)) +
          δ * Real.log (((2 * H : ℕ) : ℝ)) := by
    rw [PaperB.Closure.manuscriptB1Kernel]
    rw [← manuscriptS1Principal_add_eq_signedMainB1Principal
      hq ha hrb]
    rw [show
      PaperB.Closure.manuscriptS1Kernel q a (2 * H) +
          PaperB.Closure.manuscriptS1Kernel q (reflectedResidue q b) (2 * H) -
        (manuscriptS1Principal q a H +
          manuscriptS1Principal q (reflectedResidue q b) H) =
        (PaperB.Closure.manuscriptS1Kernel q a (2 * H) -
          manuscriptS1Principal q a H) +
        (PaperB.Closure.manuscriptS1Kernel q (reflectedResidue q b) (2 * H) -
          manuscriptS1Principal q (reflectedResidue q b) H) by ring]
    calc
      |(PaperB.Closure.manuscriptS1Kernel q a (2 * H) -
          manuscriptS1Principal q a H) +
        (PaperB.Closure.manuscriptS1Kernel q (reflectedResidue q b) (2 * H) -
          manuscriptS1Principal q (reflectedResidue q b) H)|
        ≤ |PaperB.Closure.manuscriptS1Kernel q a (2 * H) -
            manuscriptS1Principal q a H| +
          |PaperB.Closure.manuscriptS1Kernel q (reflectedResidue q b) (2 * H) -
            manuscriptS1Principal q (reflectedResidue q b) H| := abs_add_le _ _
      _ ≤ _ := add_le_add h1 h2'
  calc
    |PaperB.Closure.manuscriptB1Kernel q a b h -
        signedMainB1Principal q (h / 2)|
      = |PaperB.Closure.manuscriptB1Kernel q a b (2 * H) -
          signedMainB1Principal q H| := by simp [H, h2H]
    _ ≤ δ * Real.log (((2 * H : ℕ) : ℝ)) +
          δ * Real.log (((2 * H : ℕ) : ℝ)) := hsum
    _ = ε * Real.log (h : ℝ) := by
      dsimp [δ]
      rw [h2H]
      ring

theorem sourceFacingMain_of_principalContract
    (hPrincipal : SourceFacingMainPrincipalContract) :
    SourceFacingMainContract := by
  intro q hq hsq ε hε
  let δ := ε / 2
  have hδ : 0 < δ := by dsimp [δ]; positivity
  obtain ⟨hM, hm⟩ := hPrincipal q hq hsq δ hδ
  obtain ⟨hB, hb⟩ := manuscriptB1Kernel_sub_signedMainPrincipal_sublog q hq δ hδ
  refine ⟨max hM hB, ?_⟩
  intro a b h ha hb' hcompat h2 hh hlarge
  have hm' := hm a b h ha hb' hcompat h2 hh
    ((le_max_left hM hB).trans hlarge)
  have hb'' := hb a b h ha hb' hcompat h2 hh
    ((le_max_right hM hB).trans hlarge)
  let P := signedMainB1Principal q (h / 2)
  calc
    |cStarReal q h * completedBooleanMain q a h -
        PaperB.Closure.manuscriptB1Kernel q a b h|
      ≤ |cStarReal q h * completedBooleanMain q a h - P| +
        |PaperB.Closure.manuscriptB1Kernel q a b h - P| := by
          have ht := abs_add_le
            (cStarReal q h * completedBooleanMain q a h - P)
            (P - PaperB.Closure.manuscriptB1Kernel q a b h)
          rw [abs_sub_comm P (PaperB.Closure.manuscriptB1Kernel q a b h)] at ht
          simpa [P, sub_add_sub_cancel] using ht
    _ ≤ δ * Real.log (h : ℝ) + δ * Real.log (h : ℝ) :=
      add_le_add hm' hb''
    _ = ε * Real.log (h : ℝ) := by
      dsimp [δ]
      ring

#print axioms manuscriptB1Kernel_sub_signedMainPrincipal_sublog
#print axioms sourceFacingMain_of_principalContract

end PaperB.FixedQ
