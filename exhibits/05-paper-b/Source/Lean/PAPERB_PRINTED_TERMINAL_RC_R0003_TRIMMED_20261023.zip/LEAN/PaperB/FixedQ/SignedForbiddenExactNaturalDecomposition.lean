import PaperB.FixedQ.SignedForbiddenAggregateNaturalBridge
import PaperB.FixedQ.SignedForbiddenMainCompletion
import PaperB.FixedQ.SignedForbiddenSourceVaalerCutoff

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def sourceForbiddenNaturalVaalerResidual
    (q a H D m J : ℕ) : ℝ :=
  sourceForbiddenBooleanNaturalTerm q a H D m -
    sourceForbiddenNaturalVaalerMain q a H D m J

noncomputable def sourceForbiddenNaturalModerateVaalerMain
    (q a H D J : ℕ) : ℝ :=
  ∑ m ∈ Finset.range (H ^ 2 + 1),
    sourceForbiddenNaturalVaalerMain q a H D m J

noncomputable def sourceForbiddenNaturalModerateVaalerResidual
    (q a H D J : ℕ) : ℝ :=
  ∑ m ∈ Finset.range (H ^ 2 + 1),
    sourceForbiddenNaturalVaalerResidual q a H D m J

noncomputable def sourceForbiddenNaturalFarTail
    (q a H D : ℕ) : ℝ :=
  ∑' m : ℕ,
    if H ^ 2 < m then
      sourceForbiddenBooleanNaturalTerm q a H D m
    else 0

theorem sourceForbiddenNatural_tsum_eq_moderateVaalerMain_add_residual_add_farTail
    {q a H : ℕ} (d : Finset ℕ)
    (hq : 0 < q) (hH : 0 < H)
    (h2 : ¬ 2 ∣ q → 2 ∣ H)
    (J : ℕ) :
    (∑' m : ℕ,
      sourceForbiddenBooleanNaturalTerm
        q a H (primeSetProduct d) m) =
      sourceForbiddenNaturalModerateVaalerMain
        q a H (primeSetProduct d) J +
      sourceForbiddenNaturalModerateVaalerResidual
        q a H (primeSetProduct d) J +
      sourceForbiddenNaturalFarTail
        q a H (primeSetProduct d) := by
  let f : ℕ → ℝ :=
    sourceForbiddenBooleanNaturalTerm q a H (primeSetProduct d)
  have hsum : Summable f :=
    summable_sourceForbiddenBooleanNaturalTerm hq hH h2 d
  have hsplit := hsum.sum_add_tsum_compl
    (s := Finset.range (H ^ 2 + 1))
  have hmoderate :
      ∑ m ∈ Finset.range (H ^ 2 + 1), f m =
        sourceForbiddenNaturalModerateVaalerMain
            q a H (primeSetProduct d) J +
          sourceForbiddenNaturalModerateVaalerResidual
            q a H (primeSetProduct d) J := by
    unfold sourceForbiddenNaturalModerateVaalerMain
      sourceForbiddenNaturalModerateVaalerResidual
      sourceForbiddenNaturalVaalerResidual
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro m hm
    ring
  have htail :
      (∑' m : ↥((↑(Finset.range (H ^ 2 + 1)) : Set ℕ)ᶜ), f m.1) =
        sourceForbiddenNaturalFarTail
          q a H (primeSetProduct d) := by
    unfold sourceForbiddenNaturalFarTail
    let T : Set ℕ := (↑(Finset.range (H ^ 2 + 1)) : Set ℕ)
    have hsub := tsum_subtype Tᶜ f
    calc
      (∑' m : ↥((↑(Finset.range (H ^ 2 + 1)) : Set ℕ)ᶜ), f m.1)
          = ∑' m : ℕ, Tᶜ.indicator f m := by
              simpa [T] using hsub
      _ = ∑' m : ℕ, if H ^ 2 < m then f m else 0 := by
              apply tsum_congr
              intro m
              by_cases hm : H ^ 2 < m
              · have hnotmem : m ∉ Finset.range (H ^ 2 + 1) := by
                  simp [Finset.mem_range]
                  omega
                simp [T, Set.indicator, hm, hnotmem]
              · have hmem : m ∈ Finset.range (H ^ 2 + 1) := by
                  simp [Finset.mem_range]
                  omega
                simp [T, Set.indicator, hm, hmem]
  rw [← hsplit]
  rw [hmoderate, htail]

#print axioms sourceForbiddenNatural_tsum_eq_moderateVaalerMain_add_residual_add_farTail

noncomputable def signedForbiddenCompletedModerateVaalerMainAggregate
    (q a h : ℕ) : ℝ :=
  sourceForbiddenNaturalModerateVaalerMain
      q a h 1 (sourceVaalerCutoff h) +
    ∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
      finiteVWeightReal h d *
        sourceForbiddenNaturalModerateVaalerMain q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d)
          (primeSetProduct d)
          (sourceVaalerCutoff (h / primeSetProduct d))

noncomputable def signedForbiddenCompletedVaalerResidualAggregate
    (q a h : ℕ) : ℝ :=
  sourceForbiddenNaturalModerateVaalerResidual
      q a h 1 (sourceVaalerCutoff h) +
    ∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
      finiteVWeightReal h d *
        sourceForbiddenNaturalModerateVaalerResidual q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d)
          (primeSetProduct d)
          (sourceVaalerCutoff (h / primeSetProduct d))

noncomputable def signedForbiddenCompletedNaturalFarTailAggregate
    (q a h : ℕ) : ℝ :=
  sourceForbiddenNaturalFarTail q a h 1 +
    ∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
      finiteVWeightReal h d *
        sourceForbiddenNaturalFarTail q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d)
          (primeSetProduct d)

theorem signedForbiddenCompletedMainAggregate_eq_vaalerMain_add_residual_add_farTail
    {q a h : ℕ}
    (hq : 0 < q) (ha : q.Coprime a) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    signedForbiddenCompletedMainAggregate q a h =
      signedForbiddenCompletedModerateVaalerMainAggregate q a h +
      signedForbiddenCompletedVaalerResidualAggregate q a h +
      signedForbiddenCompletedNaturalFarTailAggregate q a h := by
  rw [signedForbiddenCompletedMainAggregate_eq_naturalAggregate]
  have h0 :=
    sourceForbiddenNatural_tsum_eq_moderateVaalerMain_add_residual_add_farTail
      (q := q) (a := a) (H := h) (d := ∅)
      hq hh h2 (sourceVaalerCutoff h)
  simp [primeSetProduct] at h0
  rw [h0]
  unfold signedForbiddenCompletedModerateVaalerMainAggregate
    signedForbiddenCompletedVaalerResidualAggregate
    signedForbiddenCompletedNaturalFarTailAggregate
  apply congrArg id
  have hchannels :
      ∀ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
        (∑' m : ℕ,
          sourceForbiddenBooleanNaturalTerm q
            (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d)
            (primeSetProduct d) m) =
          sourceForbiddenNaturalModerateVaalerMain q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d)
              (primeSetProduct d)
              (sourceVaalerCutoff (h / primeSetProduct d)) +
          sourceForbiddenNaturalModerateVaalerResidual q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d)
              (primeSetProduct d)
              (sourceVaalerCutoff (h / primeSetProduct d)) +
          sourceForbiddenNaturalFarTail q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d)
              (primeSetProduct d) := by
    intro d hd
    have hdps :
        d ∈ (decoratedHeightPrimeSet q h).powerset :=
      (Finset.mem_erase.mp hd).2
    have hp := decoratedReducedOrdinaryParameters hq ha hh h2 hdps
    -- The existing parameter package is anchored to an admissible source anchor.
    -- We only use its height/parity fields below.
    have hH : 0 < h / primeSetProduct d := hp.1
    have h2D : ¬ 2 ∣ q → 2 ∣ h / primeSetProduct d := hp.2.2.1
    exact
      sourceForbiddenNatural_tsum_eq_moderateVaalerMain_add_residual_add_farTail
        (q := q)
        (a := decoratedReducedAnchor q a (primeSetProduct d))
        (H := h / primeSetProduct d)
        (d := d) hq hH h2D
        (sourceVaalerCutoff (h / primeSetProduct d))
  calc
    sourceForbiddenNaturalModerateVaalerMain q a h 1 (sourceVaalerCutoff h) +
        sourceForbiddenNaturalModerateVaalerResidual q a h 1 (sourceVaalerCutoff h) +
        sourceForbiddenNaturalFarTail q a h 1 +
        ∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
          finiteVWeightReal h d *
            (∑' m : ℕ,
              sourceForbiddenBooleanNaturalTerm q
                (decoratedReducedAnchor q a (primeSetProduct d))
                (h / primeSetProduct d) (primeSetProduct d) m)
      =
    sourceForbiddenNaturalModerateVaalerMain q a h 1 (sourceVaalerCutoff h) +
        sourceForbiddenNaturalModerateVaalerResidual q a h 1 (sourceVaalerCutoff h) +
        sourceForbiddenNaturalFarTail q a h 1 +
        ∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
          finiteVWeightReal h d *
            (sourceForbiddenNaturalModerateVaalerMain q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) (primeSetProduct d)
              (sourceVaalerCutoff (h / primeSetProduct d)) +
             sourceForbiddenNaturalModerateVaalerResidual q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) (primeSetProduct d)
              (sourceVaalerCutoff (h / primeSetProduct d)) +
             sourceForbiddenNaturalFarTail q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) (primeSetProduct d)) := by
          congr 1
          apply Finset.sum_congr rfl
          intro d hd
          rw [hchannels d hd]
    _ = _ := by
      simp_rw [mul_add, Finset.sum_add_distrib]
      ring

#print axioms signedForbiddenCompletedMainAggregate_eq_vaalerMain_add_residual_add_farTail


end PaperB.FixedQ
