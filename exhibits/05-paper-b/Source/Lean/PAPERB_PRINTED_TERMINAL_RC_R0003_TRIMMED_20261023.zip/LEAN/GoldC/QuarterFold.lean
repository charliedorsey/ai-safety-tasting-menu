import GoldC.C2Fold
import GoldC.DigitSplit
import GoldC.InvBound
import GoldC.Target

/-!
# `GoldC.QuarterFold` — Hunt A: quarter-middle regions, the generalized fold, reflection oddness

Transcription-level (GoldC namespace, independent of the production tree).

* `regionSum q h gate F`: the literal quarter-middle source shape — **all** decorations
  `d ⊆ decoratedHeightPrimeSet q h`, the quarter mask `Z(h) < ∏e`, `4∏e ≤ H_d²`, both ordered
  orientations `∅ ≠ B ⊊ e`, weights `V_d ω(e)`, with an arbitrary pair gate.
* `quarterMiddle q a h = regionSum (no gate) (row discrepancy)`.
* Exact partitions: `quarterMiddle = lower + upper`, `lower = central + left + right`, and the
  balanced lower region over all decorations equals `activeCentral` (inactive decorations vanish).
* The C2 fold extends to every swap-symmetric gate.
* **Reflection oddness**: `Γ(b - ν, -ν) = -Γ(b, ν)` exactly, so only the odd part of the class
  mass enters. The per-class equidistribution `ClassEquidist` (false on Left/Right numerically) is
  replaced by the weaker `RegionOddClassEquidist`.
* Conditional theorem: for every swap-symmetric gate, sawtooth equidistribution plus odd-class
  equidistribution imply the signed region sum is `o(log h)`; the density parts are paid.
-/

open scoped BigOperators Classical
open Finset Real Filter Topology

namespace GoldC

/-! ## Region sums -/

/-- All decorations (no activity filter): the literal exterior sums over every `d`. -/
noncomputable def regionDecorations (q h : ℕ) : Finset (Finset ℕ) :=
  (decoratedHeightPrimeSet q h).powerset

/-- Gated, `ω`-weighted sum over quarter parents and both orientations at a fixed decoration. -/
noncomputable def regionPairSum (q h : ℕ) (gate : ℕ → ℕ → ℕ → Prop) (d : Finset ℕ)
    (G : ℕ → ℕ → ℕ → ℝ) : ℝ :=
  ∑ e ∈ quarterParents q h (h / primeSetProduct d) d ((h / primeSetProduct d) ^ 2 + 1),
    ∑ B ∈ ((e.powerset.erase e).erase ∅),
      if gate (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct (e \ B)) then
        omegaWeight e * G (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct (e \ B))
      else 0

/-- The region sum over all decorations. -/
noncomputable def regionSum (q h : ℕ) (gate : ℕ → ℕ → ℕ → Prop) (F : ℕ → ℕ → ℕ → ℕ → ℝ) : ℝ :=
  ∑ d ∈ regionDecorations q h, decorationWeight h d * regionPairSum q h gate d (F (primeSetProduct d))

/-- The source row: the signed row discrepancy with the reduced anchor and `p = 2, 3` occupancy. -/
noncomputable def srcRow (q a : ℕ) (D H r s : ℕ) : ℝ :=
  rowDiscrepancy (occupiedWeight q (reducedAnchor q a D) H) H r s

/-- **Transcription of the signed quarter-middle** (`Z < ∏n`, `4∏n ≤ H_d²`, all `d`, no gate). -/
noncomputable def quarterMiddle (q a h : ℕ) : ℝ :=
  regionSum q h (fun _ _ _ => True) (srcRow q a)

/-! ## The four Virelle regions -/

noncomputable def lowerGate (h : ℕ) (H r s : ℕ) : Prop :=
  (r * s : ℝ) ≤ (H : ℝ) / Real.exp ((Real.log (h : ℝ)) ^ (1/4 : ℝ))

noncomputable def upperGate (h : ℕ) (H r s : ℕ) : Prop := ¬ lowerGate h H r s

noncomputable def leftGate (h : ℕ) (H r s : ℕ) : Prop := lowerGate h H r s ∧ r ^ 2 < s

noncomputable def rightGate (h : ℕ) (H r s : ℕ) : Prop := lowerGate h H r s ∧ s ^ 2 < r

lemma centralGate_eq (h H r s : ℕ) :
    centralGate h H r s ↔ lowerGate h H r s ∧ s ≤ r ^ 2 ∧ r ≤ s ^ 2 := Iff.rfl

lemma lowerGate_swap (h H r s : ℕ) : lowerGate h H r s ↔ lowerGate h H s r := by
  unfold lowerGate; rw [mul_comm (r : ℝ)]

/-! ## Gate algebra -/

lemma regionSum_gate_congr {q h : ℕ} {g g' : ℕ → ℕ → ℕ → Prop} (F : ℕ → ℕ → ℕ → ℕ → ℝ)
    (hg : ∀ H r s, g H r s ↔ g' H r s) : regionSum q h g F = regionSum q h g' F := by
  have : g = g' := funext fun H => funext fun r => funext fun s => propext (hg H r s)
  rw [this]

/-- Splitting a gate along any predicate. -/
lemma regionSum_split (q h : ℕ) (g P : ℕ → ℕ → ℕ → Prop) (F : ℕ → ℕ → ℕ → ℕ → ℝ) :
    regionSum q h g F = regionSum q h (fun H r s => g H r s ∧ P H r s) F +
      regionSum q h (fun H r s => g H r s ∧ ¬ P H r s) F := by
  unfold regionSum regionPairSum
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun d _ => ?_
  rw [← mul_add, ← Finset.sum_add_distrib]
  congr 1
  refine Finset.sum_congr rfl fun e _ => ?_
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun B _ => ?_
  by_cases hg : g (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct (e \ B)) <;>
    by_cases hp : P (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct (e \ B)) <;>
    simp only [hg, hp, and_true, and_false, not_true_eq_false,
      not_false_eq_true, ↓reduceIte, add_zero, zero_add]

lemma not_sq_lt_of_sq_lt {r s : ℕ} (h : s ^ 2 < r) : ¬ r ^ 2 < s := by
  intro h'
  have h1 : r ≤ r ^ 2 := Nat.le_self_pow (by norm_num) r
  have h2 : s ≤ s ^ 2 := Nat.le_self_pow (by norm_num) s
  omega

/-- **Quarter split**: the quarter-middle is the lower plus the upper region. -/
theorem quarterMiddle_eq_lower_add_upper (q a h : ℕ) :
    quarterMiddle q a h = regionSum q h (lowerGate h) (srcRow q a) +
      regionSum q h (upperGate h) (srcRow q a) := by
  unfold quarterMiddle
  rw [regionSum_split q h _ (lowerGate h)]
  congr 1
  · exact regionSum_gate_congr _ fun H r s => by simp only [true_and]
  · exact regionSum_gate_congr _ fun H r s => by simp only [true_and, upperGate]

/-- **Lower split**: lower = balanced + Left + Right (exact, pure gate logic). -/
theorem lower_eq_central_left_right (q h : ℕ) (F : ℕ → ℕ → ℕ → ℕ → ℝ) :
    regionSum q h (lowerGate h) F = regionSum q h (centralGate h) F +
      regionSum q h (leftGate h) F + regionSum q h (rightGate h) F := by
  have e1 : regionSum q h (fun H r s => lowerGate h H r s ∧ (s ≤ r ^ 2 ∧ r ≤ s ^ 2)) F =
      regionSum q h (centralGate h) F :=
    regionSum_gate_congr _ fun H r s => (centralGate_eq h H r s).symm
  have e2 : regionSum q h (fun H r s => (lowerGate h H r s ∧ ¬ (s ≤ r ^ 2 ∧ r ≤ s ^ 2)) ∧ r ^ 2 < s) F =
      regionSum q h (leftGate h) F := by
    refine regionSum_gate_congr _ fun H r s => ?_
    unfold leftGate
    constructor
    · rintro ⟨⟨hl, -⟩, h2⟩; exact ⟨hl, h2⟩
    · rintro ⟨hl, h2⟩; exact ⟨⟨hl, fun hb => by omega⟩, h2⟩
  have e3 : regionSum q h (fun H r s => (lowerGate h H r s ∧ ¬ (s ≤ r ^ 2 ∧ r ≤ s ^ 2)) ∧ ¬ r ^ 2 < s) F =
      regionSum q h (rightGate h) F := by
    refine regionSum_gate_congr _ fun H r s => ?_
    unfold rightGate
    constructor
    · rintro ⟨⟨hl, hb⟩, h2⟩
      refine ⟨hl, ?_⟩
      by_contra hc
      exact hb ⟨by omega, by omega⟩
    · rintro ⟨hl, h2⟩
      exact ⟨⟨hl, fun hb => by omega⟩, not_sq_lt_of_sq_lt h2⟩
  rw [regionSum_split q h _ (fun H r s => s ≤ r ^ 2 ∧ r ≤ s ^ 2),
    regionSum_split q h (fun H r s => lowerGate h H r s ∧ ¬ (s ≤ r ^ 2 ∧ r ≤ s ^ 2))
      (fun H r s => r ^ 2 < s), e1, e2, e3]
  ring

/-! ## Inactive decorations vanish from the balanced (and lower) region -/

lemma quarterParents_prod_gt {q h H : ℕ} {d e : Finset ℕ} {N : ℕ}
    (he : e ∈ quarterParents q h H d N) : originalZ h < primeSetProduct e ∧ 4 * primeSetProduct e ≤ H ^ 2 := by
  unfold quarterParents at he
  exact (Finset.mem_filter.1 he).2

/-- On the quarter mask, a lower-gated pair forces the decoration to be active. -/
lemma active_of_lowerGate {q h H : ℕ} {d e B : Finset ℕ} {N : ℕ}
    (he : e ∈ quarterParents q h H d N) (hB : B ⊆ e)
    (hg : lowerGate h H (primeSetProduct B) (primeSetProduct (e \ B))) : activeDecoration h H := by
  unfold lowerGate at hg
  unfold activeDecoration
  have hZ : (originalZ h : ℝ) < (primeSetProduct e : ℝ) := Nat.cast_lt.2 (quarterParents_prod_gt he).1
  have hprod : (primeSetProduct B : ℝ) * (primeSetProduct (e \ B) : ℝ) = (primeSetProduct e : ℝ) := by
    rw [← Nat.cast_mul, prod_B_mul_prod_sdiff hB]
  rw [hprod] at hg
  have hE := Real.exp_pos ((Real.log (h : ℝ)) ^ (1/4 : ℝ))
  have h1 := (le_div_iff₀ hE).1 hg
  exact lt_of_lt_of_le (mul_lt_mul_of_pos_right hZ hE) h1

/-- **The balanced region over all decorations is exactly `activeCentral`.** -/
theorem regionSum_central_eq_activeCentral (q a h : ℕ) :
    regionSum q h (centralGate h) (srcRow q a) = activeCentral q a h := by
  symm
  unfold activeCentral
  refine (Finset.sum_filter_of_ne ?_).trans ?_
  · intro d _ hne
    by_contra hact
    apply hne
    refine mul_eq_zero_of_right _ (Finset.sum_eq_zero fun e he => Finset.sum_eq_zero fun B hB => ?_)
    have hBe : B ⊆ e := by
      simp only [Finset.mem_erase, Finset.mem_powerset] at hB; exact hB.2.2
    have hng : ¬ centralGate h (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct (e \ B)) :=
      fun hg => hact (active_of_lowerGate he hBe hg.1)
    simp only [hng, ↓reduceIte]
  · rfl

/-- **Four-region identity** (transcription of Gate3's partition):
`quarterMiddle = activeCentral + Left + Right + Upper`. -/
theorem quarterMiddle_four_regions (q a h : ℕ) :
    quarterMiddle q a h = activeCentral q a h + regionSum q h (leftGate h) (srcRow q a) +
      regionSum q h (rightGate h) (srcRow q a) + regionSum q h (upperGate h) (srcRow q a) := by
  rw [quarterMiddle_eq_lower_add_upper, lower_eq_central_left_right,
    regionSum_central_eq_activeCentral]

/-! ## Region indices and their arithmetic facts -/

/-- `(d, e, B)` occurs in a region sum. -/
def RegionIndex (q h : ℕ) (d e B : Finset ℕ) : Prop :=
  d ∈ regionDecorations q h ∧
  e ∈ quarterParents q h (h / primeSetProduct d) d ((h / primeSetProduct d) ^ 2 + 1) ∧
  B ∈ ((e.powerset.erase e).erase ∅)

/-- Every region index satisfies the hypotheses of the rounding identity (`H ≥ 1` comes from the
quarter mask, not from activity). -/
theorem region_pair_facts {q h : ℕ} {d e B : Finset ℕ} (hidx : RegionIndex q h d e B) :
    1 ≤ h / primeSetProduct d ∧ 2 ≤ primeSetProduct B ∧ 2 ≤ primeSetProduct (e \ B) ∧
    (primeSetProduct B).Coprime (primeSetProduct (e \ B)) ∧
    (primeSetProduct B).Coprime (h / primeSetProduct d) ∧
    (primeSetProduct (e \ B)).Coprime (h / primeSetProduct d) := by
  obtain ⟨-, he, hB⟩ := hidx
  have hq4 := (quarterParents_prod_gt he).2
  have hZ := (quarterParents_prod_gt he).1
  set H := h / primeSetProduct d
  have heS : e ⊆ ordinaryFiniteSupport q H d (H ^ 2 + 1) :=
    Finset.mem_powerset.1 (Finset.mem_filter.1 he).1
  have hfac : ∀ p ∈ e, p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q ∧ ¬ p ∣ H ∧ p ∉ d :=
    fun p hp => prime_of_mem_support (heS hp)
  simp only [Finset.mem_erase, Finset.mem_powerset] at hB
  obtain ⟨hBne, hBe, hBsub⟩ := hB
  have hBn : B.Nonempty := Finset.nonempty_iff_ne_empty.2 hBne
  have hCn : (e \ B).Nonempty := by
    rw [Finset.sdiff_nonempty]
    intro hsub; exact hBe (le_antisymm hBsub hsub)
  have hH : 1 ≤ H := by
    rcases Nat.eq_zero_or_pos H with h0 | h0
    · rw [h0] at hq4; simp at hq4; omega
    · exact h0
  refine ⟨hH, ?_, ?_, ?_, ?_, ?_⟩
  · have := five_le_prod hBn fun p hp => (hfac p (hBsub hp)).2.1; omega
  · have := five_le_prod hCn fun p hp => (hfac p (Finset.sdiff_subset hp)).2.1; omega
  · exact coprime_prod_prod (fun p hp => (hfac p (hBsub hp)).1)
      (fun p hp => (hfac p (Finset.sdiff_subset hp)).1) Finset.disjoint_sdiff
  · exact coprime_prod_of_forall fun p hp => ⟨(hfac p (hBsub hp)).1, (hfac p (hBsub hp)).2.2.2.1⟩
  · exact coprime_prod_of_forall fun p hp =>
      ⟨(hfac p (Finset.sdiff_subset hp)).1, (hfac p (Finset.sdiff_subset hp)).2.2.2.1⟩

lemma region_n_coprime {q h H : ℕ} {d e B : Finset ℕ} {N : ℕ}
    (he : e ∈ quarterParents q h H d N) (hB : B ∈ ((e.powerset.erase e).erase ∅)) :
    (primeSetProduct B * primeSetProduct (e \ B)).Coprime (6 * q) := by
  have heS : e ⊆ ordinaryFiniteSupport q H d N :=
    Finset.mem_powerset.1 (Finset.mem_filter.1 he).1
  have hfac : ∀ p ∈ e, p.Prime ∧ ¬ p ∣ 6 * q := by
    intro p hp
    obtain ⟨hpp, hp5, hpq, -, -⟩ := prime_of_mem_support (heS hp)
    refine ⟨hpp, fun hdvd => ?_⟩
    rcases (Nat.Prime.dvd_mul hpp).1 hdvd with h6 | hq
    · have : p ≤ 6 := Nat.le_of_dvd (by norm_num) h6
      interval_cases p <;> revert hpp h6 <;> norm_num
    · exact hpq hq
  simp only [Finset.mem_erase, Finset.mem_powerset] at hB
  exact Nat.Coprime.mul_left (coprime_prod_of_forall fun p hp => hfac p (hB.2.2 hp))
    (coprime_prod_of_forall fun p hp => hfac p (Finset.sdiff_subset hp))

/-! ## Region-sum algebra -/

lemma regionSum_congr {q h : ℕ} {g : ℕ → ℕ → ℕ → Prop} {F G : ℕ → ℕ → ℕ → ℕ → ℝ}
    (hFG : ∀ d e B, RegionIndex q h d e B →
      F (primeSetProduct d) (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct (e \ B)) =
      G (primeSetProduct d) (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct (e \ B))) :
    regionSum q h g F = regionSum q h g G := by
  unfold regionSum regionPairSum
  refine Finset.sum_congr rfl fun d hd => ?_
  congr 1
  refine Finset.sum_congr rfl fun e he => Finset.sum_congr rfl fun B hB => ?_
  split_ifs
  · rw [hFG d e B ⟨hd, he, hB⟩]
  · rfl

lemma regionSum_add (q h : ℕ) (g : ℕ → ℕ → ℕ → Prop) (F G : ℕ → ℕ → ℕ → ℕ → ℝ) :
    regionSum q h g (fun D H r s => F D H r s + G D H r s) = regionSum q h g F + regionSum q h g G := by
  unfold regionSum regionPairSum
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun d _ => ?_
  rw [← mul_add, ← Finset.sum_add_distrib]
  congr 1
  refine Finset.sum_congr rfl fun e _ => ?_
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun B _ => ?_
  split_ifs <;> ring

/-- **Orientation fold for gates**: the relabelling `B ↦ e \ B` carries gate `g` to gate `g'`
whenever `g H r s ↔ g' H s r`. -/
theorem regionSum_swap (q h : ℕ) {g g' : ℕ → ℕ → ℕ → Prop} (hgg : ∀ H r s, g H r s ↔ g' H s r)
    (F : ℕ → ℕ → ℕ → ℕ → ℝ) :
    regionSum q h g F = regionSum q h g' (fun D H r s => F D H s r) := by
  unfold regionSum regionPairSum
  refine Finset.sum_congr rfl fun d _ => ?_
  congr 1
  refine Finset.sum_congr rfl fun e he => ?_
  have hmem : ∀ B ∈ ((e.powerset.erase e).erase ∅), e \ B ∈ ((e.powerset.erase e).erase ∅) ∧
      e \ (e \ B) = B := by
    intro B hB
    simp only [Finset.mem_erase, Finset.mem_powerset] at hB ⊢
    obtain ⟨hB0, hBe, hBsub⟩ := hB
    refine ⟨⟨?_, ?_, Finset.sdiff_subset⟩, Finset.sdiff_sdiff_eq_self hBsub⟩
    · intro h0
      apply hBe
      exact le_antisymm hBsub (Finset.sdiff_eq_empty_iff_subset.1 h0)
    · intro h1
      apply hB0
      have : e \ (e \ B) = e \ e := by rw [h1]
      rw [Finset.sdiff_sdiff_eq_self hBsub, Finset.sdiff_self] at this
      exact this
  refine Finset.sum_nbij' (fun B => e \ B) (fun B => e \ B) ?_ ?_ ?_ ?_ ?_
  · intro B hB; exact (hmem B hB).1
  · intro B hB; exact (hmem B hB).1
  · intro B hB; exact (hmem B hB).2
  · intro B hB; exact (hmem B hB).2
  · intro B hB
    have hinv := (hmem B hB).2
    simp only
    rw [hinv]
    by_cases hg : g (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct (e \ B))
    · have hg' := (hgg _ _ _).1 hg
      simp only [hg, hg', ↓reduceIte]
    · have hg' : ¬ g' (h / primeSetProduct d) (primeSetProduct (e \ B)) (primeSetProduct B) :=
        fun h' => hg ((hgg _ _ _).2 h')
      simp only [hg, hg', ↓reduceIte]

/-- Left and Right are exchanged by the orientation fold. -/
theorem left_eq_right_swap (q h : ℕ) (F : ℕ → ℕ → ℕ → ℕ → ℝ) :
    regionSum q h (leftGate h) F = regionSum q h (rightGate h) (fun D H r s => F D H s r) :=
  regionSum_swap q h (fun H r s => by
    unfold leftGate rightGate; rw [lowerGate_swap]) F

/-! ## Exact decomposition and generalized fold -/

noncomputable def invRow (q a : ℕ) (D H r s : ℕ) : ℝ :=
  meanWeight q (reducedAnchor q a D) H / ((r : ℝ) * s)

noncomputable def sawRow (q a : ℕ) (D H r s : ℕ) : ℝ :=
  -(meanWeight q (reducedAnchor q a D) H *
    (saw ((H : ℝ) * invMod r s / s) + saw ((H : ℝ) * invMod s r / r)))

noncomputable def digitAPRow (q a : ℕ) (D H r s : ℕ) : ℝ :=
  digitAP (occupiedWeight q (reducedAnchor q a D) H) (meanWeight q (reducedAnchor q a D) H) H r s

noncomputable def densRow (q a : ℕ) (D H r s : ℕ) : ℝ :=
  -((∑ y ∈ Finset.Ioo 0 H, (occupiedWeight q (reducedAnchor q a D) H y -
      meanWeight q (reducedAnchor q a D) H)) / ((r : ℝ) * (s : ℝ)))

/-- **Exact decomposition** of any gated region sum of the source row. -/
theorem regionSum_decomp (q a h : ℕ) (g : ℕ → ℕ → ℕ → Prop) :
    regionSum q h g (srcRow q a) = regionSum q h g (invRow q a) + regionSum q h g (sawRow q a) +
      regionSum q h g (digitAPRow q a) + regionSum q h g (densRow q a) := by
  rw [← regionSum_add, ← regionSum_add, ← regionSum_add]
  refine regionSum_congr fun d e B hidx => ?_
  obtain ⟨hH, hr, hs, hrs, hrH, hsH⟩ := region_pair_facts hidx
  simp only [srcRow, invRow, sawRow, digitAPRow, densRow]
  rw [rowDiscrepancy_decomp _ (meanWeight q (reducedAnchor q a (primeSetProduct d))
    (h / primeSetProduct d)) hH hr hs hrs hrH hsH, digitTerm_eq]
  ring

/-- **Generalized C2 fold**: exact for every swap-symmetric gate, over all decorations. -/
theorem regionSum_fold (q a h : ℕ) (hq : 0 < q) (g : ℕ → ℕ → ℕ → Prop)
    (hsym : ∀ H r s, g H r s ↔ g H s r) :
    regionSum q h g (sawRow q a) + regionSum q h g (digitAPRow q a) =
      regionSum q h g (foldRow q a) := by
  set A : ℕ → ℕ → ℕ → ℕ → ℝ := fun D H r s =>
    -(meanWeight q (reducedAnchor q a D) H * saw ((H : ℝ) * invMod r s / s)) -
      pot (srcG q (reducedAnchor q a D) H) (6 * q) (r * s) (crtResidue H r s) with hA
  set Bf : ℕ → ℕ → ℕ → ℕ → ℝ := fun D H r s =>
    -(meanWeight q (reducedAnchor q a D) H * saw ((H : ℝ) * invMod s r / r)) +
      pot (srcG q (reducedAnchor q a D) H) (6 * q) (r * s) (H + r * s - crtResidue H s r) with hBf
  have h1 : regionSum q h g (sawRow q a) + regionSum q h g (digitAPRow q a) =
      regionSum q h g A + regionSum q h g Bf := by
    rw [← regionSum_add, ← regionSum_add]
    refine regionSum_congr fun d e B hidx => ?_
    obtain ⟨hH, hr, hs, hrs, hrH, hsH⟩ := region_pair_facts hidx
    simp only [sawRow, digitAPRow]
    rw [digitAP_eq_pot q _ _ _ _ hq hH hr hs hrs hrH hsH (region_n_coprime hidx.2.1 hidx.2.2)]
    simp only [hA, hBf]
    ring
  rw [h1, regionSum_swap q h (g' := g) hsym Bf, ← regionSum_add]
  refine regionSum_congr fun d e B _ => ?_
  simp only [hA, hBf, foldRow]
  rw [mul_comm (primeSetProduct (e \ B)) (primeSetProduct B)]
  ring

theorem regionSum_foldRow_class (q a h : ℕ) (hq : 0 < q) (g : ℕ → ℕ → ℕ → Prop) :
    regionSum q h g (foldRow q a) = regionSum q h g (foldRowClass q a) := by
  refine regionSum_congr fun d e B hidx => ?_
  obtain ⟨-, hr, hs, -, -, -⟩ := region_pair_facts hidx
  unfold foldRow foldRowClass
  congr 1
  rw [pot_diff_eq_gammaClass _ _ _ _ _ _ hq (crtResidue_lt hs (by omega)),
    sum_sum_ite_eq _ _ _ (Nat.mod_lt _ (by omega)) (Nat.mod_lt _ (by omega))]

/-! ## Pair sums at a fixed decoration -/

lemma regionSum_eq_pairSum (q h : ℕ) (g : ℕ → ℕ → ℕ → Prop) (F : ℕ → ℕ → ℕ → ℕ → ℝ) :
    regionSum q h g F = ∑ d ∈ regionDecorations q h,
      decorationWeight h d * regionPairSum q h g d (F (primeSetProduct d)) := rfl

lemma regionPairSum_sum {ι : Type*} (q h : ℕ) (g : ℕ → ℕ → ℕ → Prop) (d : Finset ℕ) (I : Finset ι)
    (G : ι → ℕ → ℕ → ℕ → ℝ) :
    regionPairSum q h g d (fun H r s => ∑ i ∈ I, G i H r s) = ∑ i ∈ I, regionPairSum q h g d (G i) := by
  unfold regionPairSum
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun e _ => ?_
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun B _ => ?_
  split_ifs
  · rw [Finset.mul_sum]
  · simp

lemma regionPairSum_const_mul (q h : ℕ) (g : ℕ → ℕ → ℕ → Prop) (d : Finset ℕ) (c : ℝ)
    (G : ℕ → ℕ → ℕ → ℝ) :
    regionPairSum q h g d (fun H r s => c * G H r s) = c * regionPairSum q h g d G := by
  unfold regionPairSum
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun e _ => ?_
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun B _ => ?_
  split_ifs <;> ring

lemma regionPairSum_add (q h : ℕ) (g : ℕ → ℕ → ℕ → Prop) (d : Finset ℕ) (F G : ℕ → ℕ → ℕ → ℝ) :
    regionPairSum q h g d (fun H r s => F H r s + G H r s) =
      regionPairSum q h g d F + regionPairSum q h g d G := by
  unfold regionPairSum
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun e _ => ?_
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun B _ => ?_
  split_ifs <;> ring

lemma regionPairSum_fixH (q h : ℕ) (g : ℕ → ℕ → ℕ → Prop) (d : Finset ℕ) (G : ℕ → ℕ → ℕ → ℝ) :
    regionPairSum q h g d G = regionPairSum q h g d (fun _ r s => G (h / primeSetProduct d) r s) := by
  unfold regionPairSum; rfl

/-- Anchor-free sawtooth moment of a region at decoration `d`. -/
noncomputable def regionSawMoment (q h : ℕ) (g : ℕ → ℕ → ℕ → Prop) (d : Finset ℕ) : ℝ :=
  regionPairSum q h g d (fun H r s => saw ((H : ℝ) * invMod r s / s))

/-- Anchor-free class mass of a region: `ω`-mass of gated pairs with `c ≡ b`, `rs ≡ ν (mod 6q)`. -/
noncomputable def regionClassMass (q h : ℕ) (g : ℕ → ℕ → ℕ → Prop) (d : Finset ℕ) (b ν : ℕ) : ℝ :=
  regionPairSum q h g d (fun H r s =>
    if crtResidue H r s % (6 * q) = b ∧ (r * s) % (6 * q) = ν then 1 else 0)

lemma regionClassMass_eq (q h : ℕ) (g : ℕ → ℕ → ℕ → Prop) (d : Finset ℕ) (H b ν : ℕ)
    (hH : H = h / primeSetProduct d) :
    (regionPairSum q h g d fun _ r s =>
      if crtResidue H r s % (6 * q) = b ∧ r * s % (6 * q) = ν then (1 : ℝ) else 0) =
      regionClassMass q h g d b ν := by
  subst hH; rfl

lemma regionSawMoment_eq (q h : ℕ) (g : ℕ → ℕ → ℕ → Prop) (d : Finset ℕ) (H : ℕ)
    (hH : H = h / primeSetProduct d) :
    (regionPairSum q h g d fun _ r s => saw ((H : ℝ) * invMod r s / s)) = regionSawMoment q h g d := by
  subst hH; rfl

lemma regionPairSum_foldRowClass (q a h : ℕ) (g : ℕ → ℕ → ℕ → Prop) (d : Finset ℕ) :
    regionPairSum q h g d (foldRowClass q a (primeSetProduct d)) =
      -(2 * meanWeight q (reducedAnchor q a (primeSetProduct d)) (h / primeSetProduct d)) *
          regionSawMoment q h g d +
        ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
          gammaClass q a (primeSetProduct d) (h / primeSetProduct d) b ν *
            regionClassMass q h g d b ν := by
  rw [regionPairSum_fixH]
  unfold foldRowClass
  rw [regionPairSum_add, regionPairSum_const_mul, regionPairSum_sum]
  simp_rw [regionPairSum_sum, regionPairSum_const_mul]
  rw [regionSawMoment_eq q h g d _ rfl]
  congr 1

/-- Class masses vanish off the units: every source `rs` is coprime to `6q`. -/
lemma regionClassMass_eq_zero (q h : ℕ) (g : ℕ → ℕ → ℕ → Prop) (d : Finset ℕ) (b ν : ℕ)
    (hν : ¬ ν.Coprime (6 * q)) : regionClassMass q h g d b ν = 0 := by
  unfold regionClassMass regionPairSum
  refine Finset.sum_eq_zero fun e he => Finset.sum_eq_zero fun B hB => ?_
  have hc := region_n_coprime he hB
  have hne : ¬ (crtResidue (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct (e \ B)) %
      (6 * q) = b ∧ primeSetProduct B * primeSetProduct (e \ B) % (6 * q) = ν) := by
    rintro ⟨-, hν'⟩
    apply hν
    rw [← hν']
    unfold Nat.Coprime at hc ⊢
    rw [← Nat.gcd_rec, Nat.gcd_comm]
    exact hc
  simp only [hne, ↓reduceIte, mul_zero, ite_self]

/-! ## Reflection oddness of the class potential -/

/-- Two `M`-periodic solutions of the same step equation that agree at `0` agree everywhere. -/
lemma step_unique (M n : ℕ) (hM : 2 ≤ M) (hn : n.Coprime M) (f₁ f₂ g : ℕ → ℝ)
    (h₁ : ∀ x y, x ≡ y [MOD M] → f₁ x = f₁ y) (h₂ : ∀ x y, x ≡ y [MOD M] → f₂ x = f₂ y)
    (s₁ : ∀ y, f₁ (y + n) - f₁ y = g y) (s₂ : ∀ y, f₂ (y + n) - f₂ y = g y) (h0 : f₁ 0 = f₂ 0)
    (y : ℕ) : f₁ y = f₂ y := by
  have hk : ∀ k, f₁ (k * n) = f₂ (k * n) := by
    intro k
    induction k with
    | zero => simpa using h0
    | succ k ih =>
      have e1 := s₁ (k * n)
      have e2 := s₂ (k * n)
      rw [show (k + 1) * n = k * n + n by ring]
      linarith
  have hy : y ≡ ((y * invMod n M) % M) * n [MOD M] := by
    have hnu : n * invMod n M ≡ 1 [MOD M] := mul_invMod_modEq hM hn
    calc y = y * 1 := (mul_one y).symm
      _ ≡ y * (n * invMod n M) [MOD M] := Nat.ModEq.mul_left _ hnu.symm
      _ = (y * invMod n M) * n := by ring
      _ ≡ ((y * invMod n M) % M) * n [MOD M] := Nat.ModEq.mul_right _ (Nat.mod_modEq _ _).symm
  rw [h₁ _ _ hy, h₂ _ _ hy, hk]

lemma pot_zero (g : ℕ → ℝ) (M n : ℕ) : pot g M n 0 = 0 := by
  unfold pot; simp

/-- **Potential reflection**: `pot_{-ν}(y) = g(0) - pot_ν(y + ν)`. -/
lemma pot_reflect (g : ℕ → ℝ) (M ν : ℕ) (hM : 2 ≤ M) (hν : ν.Coprime M) (hνM : ν ≤ M)
    (hper : ∀ y, g (y + M) = g y)
    (hcyc : ∀ n, n.Coprime M → ∑ t ∈ Finset.range M, g (t * n) = 0) (y : ℕ) :
    pot g M (M - ν) y = g 0 - pot g M ν (y + ν) := by
  have hν' : (M - ν).Coprime M := (Nat.coprime_self_sub_left hνM).2 hν
  have hstep := pot_step g M ν hM hν hper (hcyc ν hν)
  refine step_unique M (M - ν) hM hν' (pot g M (M - ν)) (fun y => g 0 - pot g M ν (y + ν)) g
    (fun x y h => pot_congr _ _ _ h) (fun x y h => ?_)
    (pot_step g M (M - ν) hM hν' hper (hcyc _ hν')) (fun y => ?_) ?_ y
  · show g 0 - pot g M ν (x + ν) = g 0 - pot g M ν (y + ν)
    rw [pot_congr g M ν (Nat.ModEq.add_right ν h)]
  · show (g 0 - pot g M ν (y + (M - ν) + ν)) - (g 0 - pot g M ν (y + ν)) = g y
    have e : y + (M - ν) + ν = y + M := by omega
    rw [e, pot_congr g M ν (Nat.add_modEq_right : y + M ≡ y [MOD M])]
    have := hstep y
    linarith
  · show pot g M (M - ν) 0 = g 0 - pot g M ν (0 + ν)
    have := hstep 0
    rw [pot_zero, zero_add] at this ⊢
    linarith

lemma reflect_congr (M H b ν b' : ℕ) (hb : b < M) (hν : ν < M) (hb' : b' < M)
    (hcast : (b' : ZMod M) = b - ν) :
    b' + ν ≡ b [MOD M] ∧ H + (M - ν) + M - b' + ν ≡ H + ν + M - b [MOD M] := by
  constructor
  · rw [← ZMod.natCast_eq_natCast_iff]
    push_cast
    rw [hcast]; ring
  · rw [← ZMod.natCast_eq_natCast_iff]
    rw [Nat.cast_add, Nat.cast_sub (by omega : b' ≤ H + (M - ν) + M), Nat.cast_add, Nat.cast_add,
      Nat.cast_sub hν.le, Nat.cast_sub (by omega : b ≤ H + ν + M), Nat.cast_add, Nat.cast_add, hcast,
      ZMod.natCast_self]
    ring

/-- **Reflection oddness**: under `(b, ν) ↦ (b - ν, -ν) mod 6q` the class potential changes sign. -/
theorem gammaClass_reflect (q a D H b ν : ℕ) (hq : 0 < q) (hb : b < 6 * q) (hν : ν < 6 * q)
    (hcop : ν.Coprime (6 * q)) :
    gammaClass q a D H ((b + 6 * q - ν) % (6 * q)) ((6 * q - ν) % (6 * q)) =
      -gammaClass q a D H b ν := by
  have hM2 : 2 ≤ 6 * q := by omega
  have hν0 : 0 < ν := by
    rcases Nat.eq_zero_or_pos ν with h0 | h0
    · rw [h0, Nat.coprime_zero_left] at hcop; omega
    · exact h0
  have hν' : (6 * q - ν) % (6 * q) = 6 * q - ν := Nat.mod_eq_of_lt (by omega)
  have hb'lt : (b + 6 * q - ν) % (6 * q) < 6 * q := Nat.mod_lt _ (by omega)
  have hcast : (((b + 6 * q - ν) % (6 * q) : ℕ) : ZMod (6 * q)) = b - ν := by
    rw [ZMod.natCast_mod, Nat.cast_sub (by omega), Nat.cast_add, ZMod.natCast_self]; ring
  obtain ⟨c1, c2⟩ := reflect_congr (6 * q) H b ν _ hb hν hb'lt hcast
  have hper := srcG_periodic q (reducedAnchor q a D) H
  have hcyc : ∀ n, n.Coprime (6 * q) →
      ∑ t ∈ Finset.range (6 * q), srcG q (reducedAnchor q a D) H (t * n) = 0 :=
    fun n hn => srcG_cycle_zero q _ H n hq hn
  unfold gammaClass
  rw [hν', pot_reflect _ (6 * q) ν hM2 hcop hν.le hper hcyc,
    pot_reflect _ (6 * q) ν hM2 hcop hν.le hper hcyc,
    pot_congr _ (6 * q) ν c1, pot_congr _ (6 * q) ν c2]
  ring

/-! ## Odd reduction of the class sum -/

/-- The class involution `(b, ν) ↦ (b - ν, -ν) mod M`. -/
def reflPair (M : ℕ) (x : ℕ × ℕ) : ℕ × ℕ := ((x.1 + M - x.2) % M, (M - x.2) % M)

lemma reflPair_mem {M : ℕ} (hM : 0 < M) {x : ℕ × ℕ} (_hx : x ∈ Finset.range M ×ˢ Finset.range M) :
    reflPair M x ∈ Finset.range M ×ˢ Finset.range M := by
  simp only [reflPair, Finset.mem_product, Finset.mem_range]
  exact ⟨Nat.mod_lt _ hM, Nat.mod_lt _ hM⟩

lemma mod_eq_of_cast {M X y : ℕ} (hy : y < M) (h : (X : ZMod M) = y) : X % M = y := by
  have := (ZMod.natCast_eq_natCast_iff X y M).1 h
  rw [Nat.ModEq, Nat.mod_eq_of_lt hy] at this
  exact this

lemma reflPair_invol {M : ℕ} (hM : 0 < M) {x : ℕ × ℕ} (hx : x ∈ Finset.range M ×ˢ Finset.range M) :
    reflPair M (reflPair M x) = x := by
  obtain ⟨b, ν⟩ := x
  simp only [Finset.mem_product, Finset.mem_range] at hx
  obtain ⟨hb, hν⟩ := hx
  have h1 : (b + M - ν) % M < M := Nat.mod_lt _ hM
  have h2 : (M - ν) % M < M := Nat.mod_lt _ hM
  have c1 : (((b + M - ν) % M : ℕ) : ZMod M) = b - ν := by
    rw [ZMod.natCast_mod, Nat.cast_sub (by omega), Nat.cast_add, ZMod.natCast_self]; ring
  have c2 : (((M - ν) % M : ℕ) : ZMod M) = -ν := by
    rw [ZMod.natCast_mod, Nat.cast_sub (by omega), ZMod.natCast_self]; ring
  simp only [reflPair, Prod.mk.injEq]
  constructor
  · apply mod_eq_of_cast hb
    rw [Nat.cast_sub (by omega), Nat.cast_add, c1, c2, ZMod.natCast_self]; ring
  · apply mod_eq_of_cast hν
    rw [Nat.cast_sub (by omega), c2, ZMod.natCast_self]; ring

/-- If `Γ` is odd under the involution wherever the mass lives, only the odd part of the mass
enters: `Σ Γ m = ½ Σ Γ (m - m∘ι)`. -/
lemma sum_odd_reduce (M : ℕ) (hM : 0 < M) (Γ m : ℕ × ℕ → ℝ)
    (hodd : ∀ x ∈ Finset.range M ×ˢ Finset.range M, m x ≠ 0 → Γ (reflPair M x) = -Γ x) :
    ∑ x ∈ Finset.range M ×ˢ Finset.range M, Γ x * m x =
      (1 / 2) * ∑ x ∈ Finset.range M ×ˢ Finset.range M, Γ x * (m x - m (reflPair M x)) := by
  have hre : ∑ x ∈ Finset.range M ×ˢ Finset.range M, Γ x * m (reflPair M x) =
      ∑ x ∈ Finset.range M ×ˢ Finset.range M, Γ (reflPair M x) * m x := by
    refine Finset.sum_nbij' (reflPair M) (reflPair M) (fun x hx => reflPair_mem hM hx)
      (fun x hx => reflPair_mem hM hx) (fun x hx => reflPair_invol hM hx)
      (fun x hx => reflPair_invol hM hx) ?_
    intro x hx
    rw [reflPair_invol hM hx]
  have hneg : ∑ x ∈ Finset.range M ×ˢ Finset.range M, Γ (reflPair M x) * m x =
      -∑ x ∈ Finset.range M ×ˢ Finset.range M, Γ x * m x := by
    rw [← Finset.sum_neg_distrib]
    refine Finset.sum_congr rfl fun x hx => ?_
    by_cases h0 : m x = 0
    · simp [h0]
    · rw [hodd x hx h0]; ring
  simp only [mul_sub, Finset.sum_sub_distrib]
  rw [hre, hneg]
  ring

/-- Centred class discrepancy of a region: class mass minus its equidistributed share of the
`ν`-column (the region analogue of C2's `classDisc`). -/
noncomputable def regionClassDisc (q h : ℕ) (g : ℕ → ℕ → ℕ → Prop) (d : Finset ℕ) (b ν : ℕ) : ℝ :=
  regionClassMass q h g d b ν -
    (∑ b' ∈ Finset.range (6 * q), regionClassMass q h g d b' ν) / (6 * (q : ℝ))

/-- **Odd class discrepancy**: centred discrepancy at `(b, ν)` minus that at the reflection
`(b - ν, -ν)`. Weaker than per-class equidistribution (`oddDisc_abs_le`). -/
noncomputable def oddDisc (q h : ℕ) (g : ℕ → ℕ → ℕ → Prop) (d : Finset ℕ) (b ν : ℕ) : ℝ :=
  regionClassDisc q h g d b ν -
    regionClassDisc q h g d ((b + 6 * q - ν) % (6 * q)) ((6 * q - ν) % (6 * q))

lemma oddDisc_abs_le (q h : ℕ) (g : ℕ → ℕ → ℕ → Prop) (d : Finset ℕ) (b ν : ℕ) :
    |oddDisc q h g d b ν| ≤ |regionClassDisc q h g d b ν| +
      |regionClassDisc q h g d ((b + 6 * q - ν) % (6 * q)) ((6 * q - ν) % (6 * q))| :=
  abs_sub _ _

lemma regionClassDisc_eq_zero (q h : ℕ) (g : ℕ → ℕ → ℕ → Prop) (d : Finset ℕ) (b ν : ℕ)
    (hν : ¬ ν.Coprime (6 * q)) : regionClassDisc q h g d b ν = 0 := by
  unfold regionClassDisc
  rw [regionClassMass_eq_zero q h g d b ν hν,
    Finset.sum_eq_zero fun b' _ => regionClassMass_eq_zero q h g d b' ν hν]
  simp

/-- **Odd class form** of the class part at a fixed decoration (exact). -/
theorem class_sum_odd_form (q a h : ℕ) (hq : 0 < q) (g : ℕ → ℕ → ℕ → Prop) (d : Finset ℕ) :
    ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
        gammaClass q a (primeSetProduct d) (h / primeSetProduct d) b ν * regionClassMass q h g d b ν =
      (1 / 2) * ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
        gammaClass q a (primeSetProduct d) (h / primeSetProduct d) b ν * oddDisc q h g d b ν := by
  have hM : 0 < 6 * q := by omega
  have hc := centering_sum (6 * q) (gammaClass q a (primeSetProduct d) (h / primeSetProduct d))
    (regionClassMass q h g d) fun ν => sum_gammaClass_zero q a _ _ ν
  push_cast at hc
  rw [hc]
  have := sum_odd_reduce (6 * q) hM
    (fun x => gammaClass q a (primeSetProduct d) (h / primeSetProduct d) x.1 x.2)
    (fun x => regionClassDisc q h g d x.1 x.2) (fun x hx hm => ?_)
  · rw [Finset.sum_product, Finset.sum_product] at this
    exact this
  · simp only [Finset.mem_product, Finset.mem_range] at hx
    have hcop : x.2.Coprime (6 * q) := by
      by_contra hc'; exact hm (regionClassDisc_eq_zero q h g d _ _ hc')
    exact gammaClass_reflect q a _ _ x.1 x.2 hq hx.1 hx.2 hcop

/-! ## The folded debt in odd form and its bound -/

/-- **Exact odd-class form of the region debt** (swap-symmetric gate, all decorations). -/
theorem regionDebt_odd_form (q a h : ℕ) (hq : 0 < q) (g : ℕ → ℕ → ℕ → Prop)
    (hsym : ∀ H r s, g H r s ↔ g H s r) :
    regionSum q h g (sawRow q a) + regionSum q h g (digitAPRow q a) =
      ∑ d ∈ regionDecorations q h, decorationWeight h d *
        (-(2 * meanWeight q (reducedAnchor q a (primeSetProduct d)) (h / primeSetProduct d)) *
            regionSawMoment q h g d +
          (1 / 2) * ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
            gammaClass q a (primeSetProduct d) (h / primeSetProduct d) b ν * oddDisc q h g d b ν) := by
  rw [regionSum_fold q a h hq g hsym, regionSum_foldRow_class q a h hq g, regionSum_eq_pairSum]
  exact Finset.sum_congr rfl fun d _ => by
    rw [regionPairSum_foldRowClass, class_sum_odd_form q a h hq g d]

lemma decorationWeight_nonneg_region {q h : ℕ} {d : Finset ℕ} (hd : d ∈ regionDecorations q h) :
    0 ≤ decorationWeight h d :=
  decorationWeight_nonneg (Finset.mem_powerset.1 hd)

/-- Absolute values only after the exact reduction: constants `8` and `4·6q`. -/
theorem regionDebt_abs_le (q a h : ℕ) (hq : 0 < q) (g : ℕ → ℕ → ℕ → Prop)
    (hsym : ∀ H r s, g H r s ↔ g H s r) :
    |regionSum q h g (sawRow q a) + regionSum q h g (digitAPRow q a)| ≤
      8 * ∑ d ∈ regionDecorations q h, decorationWeight h d * |regionSawMoment q h g d| +
        4 * (6 * q) * ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
          ∑ d ∈ regionDecorations q h, decorationWeight h d * |oddDisc q h g d b ν| := by
  rw [regionDebt_odd_form q a h hq g hsym]
  have hterm : ∀ d ∈ regionDecorations q h,
      |decorationWeight h d *
        (-(2 * meanWeight q (reducedAnchor q a (primeSetProduct d)) (h / primeSetProduct d)) *
            regionSawMoment q h g d +
          (1 / 2) * ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
            gammaClass q a (primeSetProduct d) (h / primeSetProduct d) b ν * oddDisc q h g d b ν)| ≤
      8 * (decorationWeight h d * |regionSawMoment q h g d|) +
        4 * (6 * q) * ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
          decorationWeight h d * |oddDisc q h g d b ν| := by
    intro d hd
    have hV := decorationWeight_nonneg_region hd
    have hμ := meanWeight_bounds q (reducedAnchor q a (primeSetProduct d)) (h / primeSetProduct d)
    rw [abs_mul, abs_of_nonneg hV]
    have h1 : |-(2 * meanWeight q (reducedAnchor q a (primeSetProduct d)) (h / primeSetProduct d)) *
        regionSawMoment q h g d| ≤ 8 * |regionSawMoment q h g d| := by
      rw [abs_mul]
      have : |-(2 * meanWeight q (reducedAnchor q a (primeSetProduct d)) (h / primeSetProduct d))| ≤ 8 := by
        rw [abs_neg, abs_of_nonneg (by linarith)]; linarith
      exact mul_le_mul_of_nonneg_right this (abs_nonneg _)
    have h2 : |(1 / 2 : ℝ) * ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
        gammaClass q a (primeSetProduct d) (h / primeSetProduct d) b ν * oddDisc q h g d b ν| ≤
        ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
          4 * (6 * q) * |oddDisc q h g d b ν| := by
      rw [abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 1 / 2)]
      have hX : |∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
          gammaClass q a (primeSetProduct d) (h / primeSetProduct d) b ν * oddDisc q h g d b ν| ≤
          ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
            8 * (6 * q) * |oddDisc q h g d b ν| := by
        refine (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun b _ => ?_)
        refine (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun ν _ => ?_)
        rw [abs_mul]
        exact mul_le_mul_of_nonneg_right (abs_gammaClass_le q a _ _ b ν hq) (abs_nonneg _)
      have hhalf : (1 / 2 : ℝ) * ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
            8 * (6 * q) * |oddDisc q h g d b ν| =
          ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
            4 * (6 * q) * |oddDisc q h g d b ν| := by
        rw [Finset.mul_sum]
        refine Finset.sum_congr rfl fun b _ => ?_
        rw [Finset.mul_sum]
        refine Finset.sum_congr rfl fun ν _ => ?_
        ring
      rw [← hhalf]
      exact mul_le_mul_of_nonneg_left hX (by norm_num)
    calc decorationWeight h d * |_| ≤ decorationWeight h d *
          (8 * |regionSawMoment q h g d| + ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
            4 * (6 * q) * |oddDisc q h g d b ν|) :=
          mul_le_mul_of_nonneg_left ((abs_add_le _ _).trans (add_le_add h1 h2)) hV
      _ = _ := by
          rw [mul_add, Finset.mul_sum, Finset.mul_sum]
          simp_rw [Finset.mul_sum]
          congr 1
          · ring
          · refine Finset.sum_congr rfl fun b _ => Finset.sum_congr rfl fun ν _ => ?_
            ring
  refine (Finset.abs_sum_le_sum_abs _ _).trans ((Finset.sum_le_sum hterm).trans (le_of_eq ?_))
  rw [Finset.sum_add_distrib, ← Finset.mul_sum, ← Finset.mul_sum]
  congr 2
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun b _ => ?_
  rw [Finset.sum_comm]

/-! ## The density parts are paid on every gated region -/

lemma inner_abs_le_gate (q h D H : ℕ) (d : Finset ℕ) (g : ℕ → ℕ → ℕ → Prop)
    (F : ℕ → ℕ → ℕ → ℕ → ℝ) (C : ℝ) (hC : 0 ≤ C)
    (hF : ∀ e ∈ quarterParents q h H d (H ^ 2 + 1), ∀ B ∈ ((e.powerset.erase e).erase ∅),
      |F D H (primeSetProduct B) (primeSetProduct (e \ B))|
        ≤ C / ((primeSetProduct B : ℝ) * (primeSetProduct (e \ B) : ℝ))) :
    |∑ e ∈ quarterParents q h H d (H ^ 2 + 1), ∑ B ∈ ((e.powerset.erase e).erase ∅),
        (if g H (primeSetProduct B) (primeSetProduct (e \ B)) then
          omegaWeight e * F D H (primeSetProduct B) (primeSetProduct (e \ B)) else 0)|
      ≤ C * ((1 / Real.sqrt (originalZ h)) * Real.exp K0) := by
  have hZn : 0 < originalZ h := by unfold originalZ; exact pow_pos (by norm_num) _
  have hZ : (0 : ℝ) < originalZ h := by exact_mod_cast hZn
  have hS5 : ∀ p ∈ ordinaryFiniteSupport q H d (H ^ 2 + 1), 5 ≤ p :=
    fun p hp => (prime_of_mem_support hp).2.1
  have hE : ∀ e ∈ quarterParents q h H d (H ^ 2 + 1),
      e ⊆ ordinaryFiniteSupport q H d (H ^ 2 + 1) ∧
        (originalZ h : ℝ) < (primeSetProduct e : ℝ) := by
    intro e he
    unfold quarterParents at he
    rw [Finset.mem_filter, Finset.mem_powerset] at he
    exact ⟨he.1, by exact_mod_cast he.2.1⟩
  refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
  calc _ ≤ ∑ e ∈ quarterParents q h H d (H ^ 2 + 1),
        C * ((2 : ℝ) ^ e.card * omegaWeight e / (primeSetProduct e : ℝ)) := by
        refine Finset.sum_le_sum fun e he => ?_
        have he5 : ∀ p ∈ e, 5 ≤ p := fun p hp => hS5 p ((hE e he).1 hp)
        have hω := omegaWeight_nonneg he5
        have hnpos : (0 : ℝ) < (primeSetProduct e : ℝ) := lt_trans hZ (hE e he).2
        refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
        have hterm : ∀ B ∈ ((e.powerset.erase e).erase ∅),
            |(if g H (primeSetProduct B) (primeSetProduct (e \ B)) then
              omegaWeight e * F D H (primeSetProduct B) (primeSetProduct (e \ B))
              else 0)| ≤ omegaWeight e * C / (primeSetProduct e : ℝ) := by
          intro B hB
          have hBe : B ⊆ e := by
            simp only [Finset.mem_erase, Finset.mem_powerset] at hB; exact hB.2.2
          have hprod : (primeSetProduct B : ℝ) * (primeSetProduct (e \ B) : ℝ) =
              (primeSetProduct e : ℝ) := by exact_mod_cast prod_B_mul_prod_sdiff hBe
          have hFB := hF e he B hB
          rw [hprod] at hFB
          by_cases hg : g H (primeSetProduct B) (primeSetProduct (e \ B))
          · simp only [hg, ↓reduceIte]
            rw [abs_mul, abs_of_nonneg hω, mul_div_assoc]
            exact mul_le_mul_of_nonneg_left hFB hω
          · simp only [hg, ↓reduceIte, abs_zero]
            exact div_nonneg (mul_nonneg hω hC) hnpos.le
        calc _ ≤ ∑ B ∈ ((e.powerset.erase e).erase ∅), omegaWeight e * C / (primeSetProduct e : ℝ) :=
              Finset.sum_le_sum hterm
          _ = (((e.powerset.erase e).erase ∅).card : ℝ) *
                (omegaWeight e * C / (primeSetProduct e : ℝ)) := by
              rw [Finset.sum_const, nsmul_eq_mul]
          _ ≤ (2 : ℝ) ^ e.card * (omegaWeight e * C / (primeSetProduct e : ℝ)) := by
              apply mul_le_mul_of_nonneg_right _ (div_nonneg (mul_nonneg hω hC) hnpos.le)
              exact_mod_cast card_splits_le e
          _ = C * ((2 : ℝ) ^ e.card * omegaWeight e / (primeSetProduct e : ℝ)) := by ring
    _ = C * ∑ e ∈ quarterParents q h H d (H ^ 2 + 1),
          (2 : ℝ) ^ e.card * omegaWeight e / (primeSetProduct e : ℝ) := by rw [Finset.mul_sum]
    _ ≤ C * ((1 / Real.sqrt (originalZ h)) * Real.exp K0) :=
        mul_le_mul_of_nonneg_left (parents_bound hS5 hZ _ hE) hC

theorem regionSum_abs_le (q h : ℕ) (hh : 0 < h) (g : ℕ → ℕ → ℕ → Prop) (F : ℕ → ℕ → ℕ → ℕ → ℝ)
    (C : ℝ) (hC : 0 ≤ C)
    (hF : ∀ d e B, RegionIndex q h d e B →
      |F (primeSetProduct d) (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct (e \ B))|
        ≤ C / ((primeSetProduct B : ℝ) * (primeSetProduct (e \ B) : ℝ))) :
    |regionSum q h g F| ≤ C * (1 + Real.log h) ^ 3 * ((1 / Real.sqrt (originalZ h)) * Real.exp K0) := by
  have hK : (0 : ℝ) ≤ (1 / Real.sqrt (originalZ h)) * Real.exp K0 :=
    mul_nonneg (div_nonneg zero_le_one (Real.sqrt_nonneg _)) (Real.exp_pos _).le
  unfold regionSum regionPairSum
  refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
  refine (Finset.sum_le_sum (g := fun d => decorationWeight h d *
    (C * ((1 / Real.sqrt (originalZ h)) * Real.exp K0))) fun d hd => ?_).trans ?_
  · have hV := decorationWeight_nonneg_region hd
    rw [abs_mul, abs_of_nonneg hV]
    exact mul_le_mul_of_nonneg_left (inner_abs_le_gate q h _ _ d g F C hC
      fun e he B hB => hF d e B ⟨hd, he, hB⟩) hV
  · rw [← Finset.sum_mul]
    calc _ ≤ (1 + Real.log h) ^ 3 * (C * ((1 / Real.sqrt (originalZ h)) * Real.exp K0)) :=
          mul_le_mul_of_nonneg_right (decoration_mass_le q h hh _ (subset_refl _))
            (mul_nonneg hC hK)
      _ = C * (1 + Real.log h) ^ 3 * ((1 / Real.sqrt (originalZ h)) * Real.exp K0) := by ring

/-- The base rate `4 (1 + log h)³ Z(h)^{-1/2} e^{K₀}`. -/
noncomputable def baseRate (h : ℕ) : ℝ :=
  4 * (1 + Real.log h) ^ 3 * ((1 / Real.sqrt (originalZ h)) * Real.exp K0)

theorem regionInv_le (q a h : ℕ) (hh : 0 < h) (g : ℕ → ℕ → ℕ → Prop) :
    |regionSum q h g (invRow q a)| ≤ baseRate h := by
  refine regionSum_abs_le q h hh g _ 4 (by norm_num) fun d e B hidx => ?_
  obtain ⟨-, hr, hs, -, -, -⟩ := region_pair_facts hidx
  have hμ := meanWeight_bounds q (reducedAnchor q a (primeSetProduct d)) (h / primeSetProduct d)
  have hn : (0 : ℝ) < (primeSetProduct B : ℝ) * (primeSetProduct (e \ B) : ℝ) := by
    have : (0 : ℝ) < primeSetProduct B := by exact_mod_cast (by omega : 0 < primeSetProduct B)
    have : (0 : ℝ) < primeSetProduct (e \ B) := by
      exact_mod_cast (by omega : 0 < primeSetProduct (e \ B))
    positivity
  unfold invRow
  rw [abs_of_nonneg (div_nonneg hμ.1 hn.le)]
  exact div_le_div_of_nonneg_right hμ.2 hn.le

theorem regionDens_le (q a h : ℕ) (hq : 0 < q) (hh : 0 < h) (g : ℕ → ℕ → ℕ → Prop) :
    |regionSum q h g (densRow q a)| ≤ (6 * q + 1) * baseRate h := by
  refine (regionSum_abs_le q h hh g _ (4 * (6 * q + 1)) (by positivity) fun d e B hidx => ?_).trans
    (le_of_eq (by unfold baseRate; ring))
  obtain ⟨-, hr, hs, -, -, -⟩ := region_pair_facts hidx
  have hn : (0 : ℝ) < (primeSetProduct B : ℝ) * (primeSetProduct (e \ B) : ℝ) := by
    have : (0 : ℝ) < primeSetProduct B := by exact_mod_cast (by omega : 0 < primeSetProduct B)
    have : (0 : ℝ) < primeSetProduct (e \ B) := by
      exact_mod_cast (by omega : 0 < primeSetProduct (e \ B))
    positivity
  unfold densRow
  rw [abs_neg, abs_div, abs_of_pos hn]
  exact div_le_div_of_nonneg_right (occupied_partial_sum_le q _ _ hq) hn.le

lemma baseRate_le_majorant (h : ℕ) (hL : 1 ≤ Real.log h) :
    baseRate h ≤ 32 * Real.exp K0 *
      (((Real.log (h : ℝ)) ^ booleanSigma) ^ (3 / booleanSigma) *
        Real.exp (-(10 * Real.log 2) * (Real.log (h : ℝ)) ^ booleanSigma)) := by
  unfold baseRate
  set L := Real.log (h : ℝ)
  have hL0 : 0 ≤ L := by linarith
  have hpow : (L ^ booleanSigma) ^ (3 / booleanSigma) = L ^ 3 := by
    rw [← Real.rpow_mul hL0, mul_div_cancel₀ _ booleanSigma_pos.ne',
      show (3 : ℝ) = ((3 : ℕ) : ℝ) by norm_num, Real.rpow_natCast]
  rw [hpow]
  have hcube : (1 + L) ^ 3 ≤ 8 * L ^ 3 := by
    have : 1 + L ≤ 2 * L := by linarith
    calc (1 + L) ^ 3 ≤ (2 * L) ^ 3 := pow_le_pow_left₀ (by linarith) this 3
      _ = 8 * L ^ 3 := by ring
  have hz := inv_sqrt_originalZ_le h
  have hK := Real.exp_pos K0
  have hzz : 0 ≤ 1 / Real.sqrt (originalZ h) := div_nonneg zero_le_one (Real.sqrt_nonneg _)
  calc 4 * (1 + L) ^ 3 * ((1 / Real.sqrt (originalZ h)) * Real.exp K0)
      ≤ 4 * (8 * L ^ 3) * (Real.exp (-(10 * Real.log 2) * L ^ booleanSigma) * Real.exp K0) := by
        apply mul_le_mul (mul_le_mul_of_nonneg_left hcube (by norm_num))
          (mul_le_mul_of_nonneg_right hz hK.le) (mul_nonneg hzz hK.le) (by positivity)
    _ = 32 * Real.exp K0 * (L ^ 3 * Real.exp (-(10 * Real.log 2) * L ^ booleanSigma)) := by ring

/-- The base rate tends to `0`. -/
theorem baseRate_small (ε : ℝ) (hε : 0 < ε) :
    ∃ H0 : ℕ, ∀ h : ℕ, H0 ≤ h → 0 < h ∧ 1 ≤ Real.log (h : ℝ) ∧ baseRate h ≤ ε := by
  have hev := majorant_tendsto.eventually (gt_mem_nhds hε)
  have hev2 : ∀ᶠ h : ℕ in atTop, 1 ≤ Real.log (h : ℝ) :=
    (Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop).eventually (eventually_ge_atTop 1)
  obtain ⟨H0, hH0⟩ := eventually_atTop.1 ((hev.and hev2).and (eventually_ge_atTop 1))
  refine ⟨H0, fun h hh => ?_⟩
  obtain ⟨⟨h1, h2⟩, h3⟩ := hH0 h hh
  exact ⟨by omega, h2, (baseRate_le_majorant h h2).trans h1.le⟩

/-! ## Conditional theorem: odd-class equidistribution suffices on any symmetric region -/

/-- Anchor-free sawtooth equidistribution on a region family `G h`. -/
def RegionSawEquidist (G : ℕ → ℕ → ℕ → ℕ → Prop) : Prop :=
  ∀ q : ℕ, 0 < q → ∀ eps : ℝ, 0 < eps →
    ∃ H0 : ℕ, ∀ h : ℕ, 0 < h → (¬ 2 ∣ q → 2 ∣ h) → H0 ≤ h →
      ∑ d ∈ regionDecorations q h, decorationWeight h d * |regionSawMoment q h (G h) d| ≤
        eps * Real.log (h : ℝ)

/-- **Odd-class equidistribution** (weaker than per-class `ClassEquidist`): only the difference
of the class mass at `(b, ν)` and at its reflection `(b - ν, -ν)` must be `o(log h)`. -/
def RegionOddClassEquidist (G : ℕ → ℕ → ℕ → ℕ → Prop) : Prop :=
  ∀ q : ℕ, 0 < q → ∀ eps : ℝ, 0 < eps →
    ∃ H0 : ℕ, ∀ h : ℕ, 0 < h → (¬ 2 ∣ q → 2 ∣ h) → H0 ≤ h →
      ∀ b < 6 * q, ∀ ν < 6 * q,
        ∑ d ∈ regionDecorations q h, decorationWeight h d * |oddDisc q h (G h) d b ν| ≤
          eps * Real.log (h : ℝ)

/-- Per-class (centred) equidistribution on a region: the region analogue of C2's
`ClassEquidist`. Numerically FALSE on Left/Right (see `FAILED_CASES.md`). -/
def RegionClassEquidist (G : ℕ → ℕ → ℕ → ℕ → Prop) : Prop :=
  ∀ q : ℕ, 0 < q → ∀ eps : ℝ, 0 < eps →
    ∃ H0 : ℕ, ∀ h : ℕ, 0 < h → (¬ 2 ∣ q → 2 ∣ h) → H0 ≤ h →
      ∀ b < 6 * q, ∀ ν < 6 * q,
        ∑ d ∈ regionDecorations q h, decorationWeight h d * |regionClassDisc q h (G h) d b ν| ≤
          eps * Real.log (h : ℝ)

/-- The odd hypothesis is implied by the per-class one (so it is weaker). -/
theorem regionOddClassEquidist_of_classEquidist (G : ℕ → ℕ → ℕ → ℕ → Prop)
    (hC : RegionClassEquidist G) : RegionOddClassEquidist G := by
  intro q hq eps heps
  obtain ⟨H0, hH0⟩ := hC q hq (eps / 2) (by positivity)
  refine ⟨H0, fun h hh hpar hH b hb ν hν => ?_⟩
  have hM : 0 < 6 * q := by omega
  have e1 := hH0 h hh hpar hH b hb ν hν
  have e2 := hH0 h hh hpar hH ((b + 6 * q - ν) % (6 * q)) (Nat.mod_lt _ hM)
    ((6 * q - ν) % (6 * q)) (Nat.mod_lt _ hM)
  calc ∑ d ∈ regionDecorations q h, decorationWeight h d * |oddDisc q h (G h) d b ν|
      ≤ ∑ d ∈ regionDecorations q h, (decorationWeight h d * |regionClassDisc q h (G h) d b ν| +
          decorationWeight h d * |regionClassDisc q h (G h) d ((b + 6 * q - ν) % (6 * q))
            ((6 * q - ν) % (6 * q))|) := by
        refine Finset.sum_le_sum fun d hd => ?_
        rw [← mul_add]
        exact mul_le_mul_of_nonneg_left (oddDisc_abs_le _ _ _ _ _ _)
          (decorationWeight_nonneg_region hd)
    _ ≤ eps / 2 * Real.log (h : ℝ) + eps / 2 * Real.log (h : ℝ) := by
        rw [Finset.sum_add_distrib]; exact add_le_add e1 e2
    _ = eps * Real.log (h : ℝ) := by ring

/-- The signed region sum is `o(log h)`, uniformly in the anchor. -/
def RegionSublog (G : ℕ → ℕ → ℕ → ℕ → Prop) : Prop :=
  ∀ q : ℕ, 0 < q → ∀ eps : ℝ, 0 < eps →
    ∃ H0 : ℕ, ∀ a h : ℕ, q.Coprime a → 0 < h → (¬ 2 ∣ q → 2 ∣ h) → H0 ≤ h →
      |regionSum q h (G h) (srcRow q a)| ≤ eps * Real.log (h : ℝ)

/-- **Conditional theorem.** On every swap-symmetric region, sawtooth equidistribution plus
odd-class equidistribution give the signed sublog bound. The density parts are paid
unconditionally (`regionInv_le`, `regionDens_le`). -/
theorem regionSublog_of_equidist (G : ℕ → ℕ → ℕ → ℕ → Prop)
    (hsym : ∀ h H r s, G h H r s ↔ G h H s r)
    (hS : RegionSawEquidist G) (hO : RegionOddClassEquidist G) : RegionSublog G := by
  intro q hq eps heps
  have hM : (0 : ℝ) < 6 * q := by positivity
  have hq1 : (0 : ℝ) < 6 * q + 1 := by positivity
  obtain ⟨H1, hH1⟩ := baseRate_small (eps / 4 / (6 * q + 1)) (by positivity)
  obtain ⟨H2, hH2⟩ := hS q hq (eps / 4 / 8) (by positivity)
  obtain ⟨H3, hH3⟩ := hO q hq (eps / 4 / (4 * (6 * q) * ((6 * q) * (6 * q)))) (by positivity)
  refine ⟨max H1 (max H2 H3), fun a h _ hh hpar hH => ?_⟩
  obtain ⟨-, hL1, hbase⟩ := hH1 h (le_of_max_le_left hH)
  have hs := hH2 h hh hpar (le_trans (le_max_left _ _) (le_of_max_le_right hH))
  have hc := hH3 h hh hpar (le_trans (le_max_right _ _) (le_of_max_le_right hH))
  have hL : 0 ≤ Real.log (h : ℝ) := by linarith
  have hcsum : ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
      ∑ d ∈ regionDecorations q h, decorationWeight h d * |oddDisc q h (G h) d b ν| ≤
      ∑ b ∈ Finset.range (6 * q), ∑ ν ∈ Finset.range (6 * q),
        eps / 4 / (4 * (6 * q) * ((6 * q) * (6 * q))) * Real.log (h : ℝ) :=
    Finset.sum_le_sum fun b hb => Finset.sum_le_sum fun ν hν =>
      hc b (Finset.mem_range.1 hb) ν (Finset.mem_range.1 hν)
  simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul] at hcsum
  push_cast at hcsum
  have hinv := regionInv_le q a h hh (G h)
  have hdens := regionDens_le q a h hq hh (G h)
  have hdebt := regionDebt_abs_le q a h hq (G h) (hsym h)
  have hb0 : 0 ≤ baseRate h := (abs_nonneg _).trans hinv
  have hbase' : baseRate h ≤ eps / 4 := by
    refine hbase.trans (div_le_self (by positivity) ?_)
    have : (0 : ℝ) ≤ q := Nat.cast_nonneg q
    linarith
  have hb1 : |regionSum q h (G h) (invRow q a)| ≤ eps / 4 * Real.log (h : ℝ) := by
    calc _ ≤ eps / 4 := hinv.trans hbase'
      _ = eps / 4 * 1 := (mul_one _).symm
      _ ≤ eps / 4 * Real.log (h : ℝ) := mul_le_mul_of_nonneg_left hL1 (by positivity)
  have hb2 : |regionSum q h (G h) (densRow q a)| ≤ eps / 4 * Real.log (h : ℝ) := by
    calc _ ≤ (6 * q + 1) * baseRate h := hdens
      _ ≤ (6 * q + 1) * (eps / 4 / (6 * q + 1)) := mul_le_mul_of_nonneg_left hbase hq1.le
      _ = eps / 4 * 1 := by field_simp
      _ ≤ eps / 4 * Real.log (h : ℝ) := mul_le_mul_of_nonneg_left hL1 (by positivity)
  have hb3 : |regionSum q h (G h) (sawRow q a) + regionSum q h (G h) (digitAPRow q a)| ≤
      eps / 2 * Real.log (h : ℝ) := by
    refine hdebt.trans ?_
    calc _ ≤ 8 * (eps / 4 / 8 * Real.log (h : ℝ)) + 4 * (6 * q) * ((6 * q) * ((6 * q) *
          (eps / 4 / (4 * (6 * q) * ((6 * q) * (6 * q))) * Real.log (h : ℝ)))) := by
          gcongr
      _ = eps / 2 * Real.log (h : ℝ) := by field_simp; ring
  rw [regionSum_decomp]
  calc |regionSum q h (G h) (invRow q a) + regionSum q h (G h) (sawRow q a) +
        regionSum q h (G h) (digitAPRow q a) + regionSum q h (G h) (densRow q a)|
      = |regionSum q h (G h) (invRow q a) + regionSum q h (G h) (densRow q a) +
          (regionSum q h (G h) (sawRow q a) + regionSum q h (G h) (digitAPRow q a))| := by
        congr 1; ring
    _ ≤ |regionSum q h (G h) (invRow q a)| + |regionSum q h (G h) (densRow q a)| +
          |regionSum q h (G h) (sawRow q a) + regionSum q h (G h) (digitAPRow q a)| :=
        (abs_add_le _ _).trans (add_le_add (abs_add_le _ _) le_rfl)
    _ ≤ eps / 4 * Real.log (h : ℝ) + eps / 4 * Real.log (h : ℝ) + eps / 2 * Real.log (h : ℝ) :=
        add_le_add (add_le_add hb1 hb2) hb3
    _ = eps * Real.log (h : ℝ) := by ring

/-! ## Instances: the quarter-middle, the lower region, and the four-region (Gate3) route -/

/-- Transcription of `QuarterMiddleSublog` (no squarefree hypothesis, as in the exterior Prop). -/
def QuarterMiddleSublogT : Prop :=
  ∀ q : ℕ, 0 < q → ∀ eps : ℝ, 0 < eps →
    ∃ H0 : ℕ, ∀ a h : ℕ, q.Coprime a → 0 < h → (¬ 2 ∣ q → 2 ∣ h) → H0 ≤ h →
      |quarterMiddle q a h| ≤ eps * Real.log (h : ℝ)

/-- The whole quarter-middle is one swap-symmetric region: odd-class + sawtooth equidistribution
over the full quarter-middle give `QuarterMiddleSublogT` directly (no Gate3 split needed). -/
theorem quarterMiddleSublogT_of_equidist
    (hS : RegionSawEquidist (fun _ _ _ _ => True)) (hO : RegionOddClassEquidist (fun _ _ _ _ => True)) :
    QuarterMiddleSublogT :=
  regionSublog_of_equidist _ (fun _ _ _ _ => Iff.rfl) hS hO

/-- The lower region (`rs ≤ H/E`, all balances) is swap-symmetric. -/
theorem lowerSublog_of_equidist (hS : RegionSawEquidist lowerGate)
    (hO : RegionOddClassEquidist lowerGate) : RegionSublog lowerGate :=
  regionSublog_of_equidist _ (fun h H r s => lowerGate_swap h H r s) hS hO

/-- The balanced region over all decorations is `activeCentral`, so its sublog bound is the GoldC
target (with the squarefree hypothesis dropped). -/
theorem signedActiveCentralSublog_of_region (hC : RegionSublog centralGate) :
    SignedActiveCentralSublog := by
  intro q hq _ eps heps
  obtain ⟨H0, hH0⟩ := hC q hq eps heps
  exact ⟨H0, fun a h ha hh hpar hH => by
    rw [← regionSum_central_eq_activeCentral]; exact hH0 a h ha hh hpar hH⟩

/-- **Gate3 route (transcription)**: the four regional sublog bounds give the quarter-middle bound.
The converse is not claimed: the exterior needs only the signed total. -/
theorem quarterMiddleSublogT_of_regions (hC : RegionSublog centralGate) (hL : RegionSublog leftGate)
    (hR : RegionSublog rightGate) (hU : RegionSublog upperGate) : QuarterMiddleSublogT := by
  intro q hq eps heps
  obtain ⟨H1, h1⟩ := hC q hq (eps / 4) (by positivity)
  obtain ⟨H2, h2⟩ := hL q hq (eps / 4) (by positivity)
  obtain ⟨H3, h3⟩ := hR q hq (eps / 4) (by positivity)
  obtain ⟨H4, h4⟩ := hU q hq (eps / 4) (by positivity)
  refine ⟨max (max H1 H2) (max H3 H4), fun a h ha hh hpar hH => ?_⟩
  have e1 := h1 a h ha hh hpar (le_trans (le_trans (le_max_left _ _) (le_max_left _ _)) hH)
  have e2 := h2 a h ha hh hpar (le_trans (le_trans (le_max_right _ _) (le_max_left _ _)) hH)
  have e3 := h3 a h ha hh hpar (le_trans (le_trans (le_max_left _ _) (le_max_right _ _)) hH)
  have e4 := h4 a h ha hh hpar (le_trans (le_trans (le_max_right _ _) (le_max_right _ _)) hH)
  rw [regionSum_central_eq_activeCentral] at e1
  rw [quarterMiddle_four_regions]
  calc _ ≤ |activeCentral q a h| + |regionSum q h (leftGate h) (srcRow q a)| +
        |regionSum q h (rightGate h) (srcRow q a)| + |regionSum q h (upperGate h) (srcRow q a)| :=
        (abs_add_le _ _).trans (add_le_add ((abs_add_le _ _).trans
          (add_le_add (abs_add_le _ _) le_rfl)) le_rfl)
    _ ≤ eps / 4 * Real.log h + eps / 4 * Real.log h + eps / 4 * Real.log h +
          eps / 4 * Real.log h := by gcongr
    _ = eps * Real.log (h : ℝ) := by ring

/-- **Lower + Upper route**: the lower-region bound (from odd-class equidistribution) and an
upper-region bound give the quarter-middle bound. -/
theorem quarterMiddleSublogT_of_lower_upper (hLo : RegionSublog lowerGate)
    (hU : RegionSublog upperGate) : QuarterMiddleSublogT := by
  intro q hq eps heps
  obtain ⟨H1, h1⟩ := hLo q hq (eps / 2) (by positivity)
  obtain ⟨H2, h2⟩ := hU q hq (eps / 2) (by positivity)
  refine ⟨max H1 H2, fun a h ha hh hpar hH => ?_⟩
  have e1 := h1 a h ha hh hpar (le_of_max_le_left hH)
  have e2 := h2 a h ha hh hpar (le_of_max_le_right hH)
  rw [quarterMiddle_eq_lower_add_upper]
  calc _ ≤ _ := abs_add_le _ _
    _ ≤ eps / 2 * Real.log h + eps / 2 * Real.log h := add_le_add e1 e2
    _ = eps * Real.log (h : ℝ) := by ring

end GoldC
