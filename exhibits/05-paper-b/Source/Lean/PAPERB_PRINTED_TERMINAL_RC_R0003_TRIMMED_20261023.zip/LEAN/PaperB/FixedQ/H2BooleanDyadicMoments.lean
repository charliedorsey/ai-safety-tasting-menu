import PaperB.FixedQ.H2BooleanM3ActualBridge
import PaperB.FixedQ.H2BooleanSmoothRough
import PaperB.FixedQ.H2BooleanFourierBlock
import PaperB.FixedQ.H2BooleanParameters
import PaperB.FixedQ.OneDimensionalFamilyPartition

open scoped BigOperators

namespace PaperB.FixedQ

lemma h2BooleanFirstTiltLift_prime_div_eq
    {q p : ℕ} (hp : activeHighPrime q p) :
    h2BooleanTiltLift q h2BooleanFirstTilt p / (p : ℝ) =
      h2BooleanX0 / ((p : ℝ) - 3) := by
  have hpPrime : p.Prime := hp.1
  have hp5 : 5 ≤ p := hp.2.1
  have hcop : p.Coprime (6 * q) :=
    h2_activeHighPrime_coprime_six_mul hp
  rw [h2BooleanTiltLift_apply]
  unfold h2BooleanTiltLiftNat
  rw [fixedQShiuWeight_prime_eq hpPrime hcop]
  have hcard : p.primeFactors.card = 1 := by simp [hpPrime]
  rw [hcard, pow_one]
  unfold fixedQShiuPrimeFactor
  rw [if_pos hp5]
  rw [← two_mul_h2BooleanFirstTilt]
  have hp0 : (0 : ℝ) < p := by exact_mod_cast hpPrime.pos
  field_simp [hp0.ne']

lemma h2BooleanFirstTiltLocalFactor_div_eq
    {q p : ℕ} (hp : activeHighPrime q p) :
    h2BooleanTiltLocalFactor h2BooleanFirstTilt p / (p : ℝ) =
      h2BooleanX0 / ((p : ℝ) - 3) := by
  have hp5 : 5 ≤ p := hp.2.1
  have hp0 : (0 : ℝ) < p := by exact_mod_cast hp.1.pos
  unfold h2BooleanTiltLocalFactor fixedQShiuPrimeFactor
  rw [if_pos hp5]
  rw [← two_mul_h2BooleanFirstTilt]
  field_simp [hp0.ne']

lemma h2BooleanFirstTiltWeight_prod_eq
    {q : ℕ} {S : Finset ℕ}
    (hA : ∀ p ∈ S, activeHighPrime q p) :
    (∏ p ∈ S,
        h2BooleanTiltLocalFactor h2BooleanFirstTilt p / (p : ℝ)) =
      finiteOmegaWeightReal S * h2BooleanX0 ^ S.card := by
  calc
    (∏ p ∈ S,
        h2BooleanTiltLocalFactor h2BooleanFirstTilt p / (p : ℝ))
        = ∏ p ∈ S,
            ((1 / ((p : ℝ) - 3)) * h2BooleanX0) := by
              apply Finset.prod_congr rfl
              intro p hp
              rw [h2BooleanFirstTiltLocalFactor_div_eq (hA p hp)]
              ring
    _ = (∏ p ∈ S, 1 / ((p : ℝ) - 3)) *
          (∏ _p ∈ S, h2BooleanX0) := by
            rw [Finset.prod_mul_distrib]
    _ = finiteOmegaWeightReal S * h2BooleanX0 ^ S.card := by
          simp [finiteOmegaWeightReal]

lemma h2BooleanFirstTiltLift_primeSetProduct_div
    {q : ℕ} {S : Finset ℕ}
    (hA : ∀ p ∈ S, activeHighPrime q p) :
    h2BooleanTiltLift q h2BooleanFirstTilt (primeSetProduct S) /
        (primeSetProduct S : ℝ) =
      finiteOmegaWeightReal S * h2BooleanX0 ^ S.card := by
  have hPrime : ∀ p ∈ S, p.Prime := fun p hp => (hA p hp).1
  have hsq := primeSetProduct_squarefree hPrime
  have hcop := activePrimeSetProduct_coprime hA
  have hn0 : primeSetProduct S ≠ 0 :=
    (primeSetProduct_pos hPrime).ne'
  have hprod := h2BooleanTiltLift_eq_prod
    (c := h2BooleanFirstTilt) hn0 hsq hcop
  rw [hprod]
  have hpf : (primeSetProduct S).primeFactors = S := by
    unfold primeSetProduct
    exact Nat.primeFactors_prod hPrime
  rw [hpf]
  have hden :
      (primeSetProduct S : ℝ) =
        ∏ p ∈ S, (p : ℝ) := by
    unfold primeSetProduct
    push_cast
    rfl
  rw [hden]
  rw [← Finset.prod_div_distrib]
  exact h2BooleanFirstTiltWeight_prod_eq hA

#print axioms h2BooleanFirstTiltWeight_prod_eq
#print axioms h2BooleanFirstTiltLift_primeSetProduct_div


noncomputable def h2BooleanActivePrimesLE (q X : ℕ) : Finset ℕ :=
  X.primesLE.filter (activeHighPrime q)

noncomputable def h2BooleanDyadicSets (q M : ℕ) : Finset (Finset ℕ) :=
  (h2BooleanActivePrimesLE q (2 * M)).powerset.filter
    (fun S => M < primeSetProduct S ∧ primeSetProduct S ≤ 2 * M)

lemma h2BooleanDyadicSets_active
    {q M : ℕ} {S : Finset ℕ}
    (hS : S ∈ h2BooleanDyadicSets q M) :
    ∀ p ∈ S, activeHighPrime q p := by
  intro p hp
  have hpow :=
    Finset.mem_powerset.mp (Finset.mem_filter.mp hS).1
  have hpA := hpow hp
  exact (Finset.mem_filter.mp hpA).2

lemma h2BooleanDyadicSets_range
    {q M : ℕ} {S : Finset ℕ}
    (hS : S ∈ h2BooleanDyadicSets q M) :
    M < primeSetProduct S ∧ primeSetProduct S ≤ 2 * M :=
  (Finset.mem_filter.mp hS).2

lemma h2BooleanDyadicSets_product_injective
    {q M : ℕ} :
    Set.InjOn primeSetProduct
      {S | S ∈ h2BooleanDyadicSets q M} := by
  intro S hS T hT hEq
  change S ∈ h2BooleanDyadicSets q M at hS
  change T ∈ h2BooleanDyadicSets q M at hT
  have hPrimeS : ∀ p ∈ S, p.Prime := by
    intro p hp
    exact (h2BooleanDyadicSets_active hS p hp).1
  have hPrimeT : ∀ p ∈ T, p.Prime := by
    intro p hp
    exact (h2BooleanDyadicSets_active hT p hp).1
  have hpfS : (primeSetProduct S).primeFactors = S := by
    unfold primeSetProduct
    exact Nat.primeFactors_prod hPrimeS
  have hpfT : (primeSetProduct T).primeFactors = T := by
    unfold primeSetProduct
    exact Nat.primeFactors_prod hPrimeT
  rw [← hpfS, ← hpfT, hEq]

#print axioms h2BooleanDyadicSets_product_injective


lemma h2_sum_progressionSum_range_eq_interval
    (f : ArithmeticFunction ℝ) (x y k : ℕ) (hk : 0 < k) :
    (∑ a ∈ Finset.range k, PaperB.M4B.progressionSum f x y k a) =
      ∑ n ∈ Finset.Ioc (x - y) x, f n := by
  unfold PaperB.M4B.progressionSum
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro n hn
  have hmem : n % k ∈ Finset.range k := by
    simpa using Nat.mod_lt n hk
  rw [Finset.sum_eq_single (n % k)]
  · rw [if_pos]
    exact Nat.mod_modEq n k |>.symm
  · intro a ha hane
    rw [if_neg]
    intro hmod
    have ha_lt : a < k := Finset.mem_range.mp ha
    have heqmod : a = n % k := by
      have h := hmod
      rw [Nat.ModEq] at h
      have ha_mod : a % k = a := Nat.mod_eq_of_lt ha_lt
      rw [ha_mod] at h
      simpa using h.symm
    exact hane heqmod
  · intro hnot
    exact (hnot hmem).elim

#print axioms h2_sum_progressionSum_range_eq_interval


lemma h2BooleanFirstTilt_progression_zero
    (q x y : ℕ) (hq : 0 < q) :
    PaperB.M4B.progressionSum
      (h2BooleanTiltLift q h2BooleanFirstTilt) x y (6 * q) 0 = 0 := by
  unfold PaperB.M4B.progressionSum
  apply Finset.sum_eq_zero
  intro n hn
  by_cases hmod : n ≡ 0 [MOD 6 * q]
  · rw [if_pos hmod]
    have hdiv : 6 * q ∣ n := Nat.modEq_zero_iff_dvd.mp hmod
    apply h2BooleanTiltLift_eq_zero_of_not_coprime
    intro hcop
    have hk1 : 6 * q = 1 := hcop.symm.eq_one_of_dvd hdiv
    omega
  · rw [if_neg hmod]

#print axioms h2BooleanFirstTilt_progression_zero


lemma h2BooleanFirstTilt_progression_zero_of_not_coprime
    (q x y a : ℕ)
    (ha : ¬ a.Coprime (6 * q)) :
    PaperB.M4B.progressionSum
      (h2BooleanTiltLift q h2BooleanFirstTilt) x y (6 * q) a = 0 := by
  unfold PaperB.M4B.progressionSum
  apply Finset.sum_eq_zero
  intro n hn
  by_cases hmod : n ≡ a [MOD 6 * q]
  · rw [if_pos hmod]
    apply h2BooleanTiltLift_eq_zero_of_not_coprime
    intro hncop
    exact ha (PaperB.M4B.coprime_of_modEq_reduced hncop hmod.symm)
  · rw [if_neg hmod]

#print axioms h2BooleanFirstTilt_progression_zero_of_not_coprime

theorem h2BooleanFirstTilt_interval_shiu
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ X0 : ℕ, ∀ M : ℕ,
      X0 ≤ 2 * M →
      4 ≤ 2 * M →
      ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
      ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
      (∑ n ∈ Finset.Ioc M (2 * M),
        h2BooleanTiltLift q h2BooleanFirstTilt n) ≤
      C *
        ((M : ℝ) /
          (((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ))) *
        Real.exp
          (PaperB.M4B.primeMass
            (h2BooleanTiltLift q h2BooleanFirstTilt) (2 * M) (6 * q)) := by
  rcases h2BooleanFirstTiltLift_progression q with ⟨CS, X0, hS⟩
  refine ⟨(6 * q : ℝ) * |CS|, X0, ?_⟩
  intro M hX h4 hquarter hk
  have hkpos : 0 < 6 * q := by omega
  have hpart := h2_sum_progressionSum_range_eq_interval
    (h2BooleanTiltLift q h2BooleanFirstTilt) (2 * M) M (6 * q) hkpos
  have hsub : 2 * M - M = M := by omega
  rw [hsub] at hpart
  have hbase0 :
      0 ≤ (M : ℝ) /
        (((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ)) := by
    have hM2 : 2 ≤ M := by omega
    have hlog : 0 < Real.log ((2 * M : ℕ) : ℝ) := by
      apply Real.log_pos
      exact_mod_cast (show 1 < 2 * M by omega)
    have hphi : 0 < ((6 * q).totient : ℝ) := by
      exact_mod_cast Nat.totient_pos.mpr hkpos
    positivity
  have hexp0 :
      0 ≤ Real.exp
        (PaperB.M4B.primeMass
          (h2BooleanTiltLift q h2BooleanFirstTilt) (2 * M) (6 * q)) :=
    (Real.exp_pos _).le
  rw [← hpart]
  calc
    (∑ a ∈ Finset.range (6 * q),
      PaperB.M4B.progressionSum
        (h2BooleanTiltLift q h2BooleanFirstTilt)
        (2 * M) M (6 * q) a)
      ≤ ∑ _a ∈ Finset.range (6 * q),
        |CS| *
          ((M : ℝ) /
            (((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ))) *
          Real.exp
            (PaperB.M4B.primeMass
              (h2BooleanTiltLift q h2BooleanFirstTilt)
              (2 * M) (6 * q)) := by
        apply Finset.sum_le_sum
        intro a ha
        by_cases hcop : a.Coprime (6 * q)
        · have halt : a < 6 * q := Finset.mem_range.mp ha
          have ha0 : 0 < a := by
            by_contra hna
            have haeq : a = 0 := Nat.eq_zero_of_not_pos hna
            subst a
            have hk1 : 6 * q = 1 := hcop.symm.eq_one_of_dvd (dvd_zero _)
            omega
          have hrow := hS (2 * M) M (6 * q) a
            hX hquarter (by omega) hk ha0 halt hcop
          calc
            PaperB.M4B.progressionSum
                (h2BooleanTiltLift q h2BooleanFirstTilt)
                (2 * M) M (6 * q) a
                ≤ CS *
                    ((M : ℝ) /
                      (((6 * q).totient : ℝ) *
                        Real.log ((2 * M : ℕ) : ℝ))) *
                    Real.exp
                      (PaperB.M4B.primeMass
                        (h2BooleanTiltLift q h2BooleanFirstTilt)
                        (2 * M) (6 * q)) := hrow
            _ ≤ |CS| *
                    ((M : ℝ) /
                      (((6 * q).totient : ℝ) *
                        Real.log ((2 * M : ℕ) : ℝ))) *
                    Real.exp
                      (PaperB.M4B.primeMass
                        (h2BooleanTiltLift q h2BooleanFirstTilt)
                        (2 * M) (6 * q)) := by
                  gcongr
                  exact le_abs_self CS
        · rw [h2BooleanFirstTilt_progression_zero_of_not_coprime
              q (2 * M) M a hcop]
          positivity
    _ = (6 * q : ℝ) * |CS| *
          ((M : ℝ) /
            (((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ))) *
          Real.exp
            (PaperB.M4B.primeMass
              (h2BooleanTiltLift q h2BooleanFirstTilt)
              (2 * M) (6 * q)) := by
        simp
        ring


#print axioms h2BooleanFirstTilt_interval_shiu

theorem h2BooleanFirstTilt_interval_log_power
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ X0 : ℕ, ∀ M : ℕ,
      X0 ≤ M →
      ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
      ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
      (∑ n ∈ Finset.Ioc M (2 * M),
        h2BooleanTiltLift q h2BooleanFirstTilt n) ≤
      C * (M : ℝ) *
        (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) := by
  rcases h2BooleanFirstTilt_interval_shiu q hq with ⟨CS, XS, hS⟩
  let E : ℝ := Real.exp (10 * h2BooleanFirstTilt + 24)
  refine ⟨|CS| * E, max XS 2, ?_⟩
  intro M hM hquarter hk
  have hXS : XS ≤ 2 * M := by
    have : XS ≤ M := (le_max_left XS 2).trans hM
    omega
  have hM2 : 2 ≤ M := (le_max_right XS 2).trans hM
  have h4 : 4 ≤ 2 * M := by omega
  have hraw := hS M hXS h4 hquarter hk
  have hmass :=
    h2BooleanFirstTiltLift_exp_primeMass_le
      q (2 * M) (6 * q) h4
  have hlog : 0 < Real.log ((2 * M : ℕ) : ℝ) := by
    apply Real.log_pos
    exact_mod_cast (show 1 < 2 * M by omega)
  have hkpos : 0 < 6 * q := by omega
  have hphiNat : 0 < (6 * q).totient :=
    Nat.totient_pos.mpr hkpos
  have hphi : (1 : ℝ) ≤ ((6 * q).totient : ℝ) := by
    exact_mod_cast hphiNat
  have hbase :
      (M : ℝ) /
          (((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ))
        ≤ (M : ℝ) / Real.log ((2 * M : ℕ) : ℝ) := by
    have hden :
        Real.log ((2 * M : ℕ) : ℝ) ≤
          ((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ) := by
      nlinarith
    exact div_le_div_of_nonneg_left (by positivity) hlog hden
  have hpow0 :
      0 ≤ (Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanX0 :=
    Real.rpow_nonneg hlog.le _
  have hE0 : 0 ≤ E := (Real.exp_pos _).le
  calc
    (∑ n ∈ Finset.Ioc M (2 * M),
        h2BooleanTiltLift q h2BooleanFirstTilt n)
        ≤ CS *
          ((M : ℝ) /
            (((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ))) *
          Real.exp
            (PaperB.M4B.primeMass
              (h2BooleanTiltLift q h2BooleanFirstTilt) (2 * M) (6 * q)) := hraw
    _ ≤ |CS| *
          ((M : ℝ) /
            (((6 * q).totient : ℝ) * Real.log ((2 * M : ℕ) : ℝ))) *
          Real.exp
            (PaperB.M4B.primeMass
              (h2BooleanTiltLift q h2BooleanFirstTilt) (2 * M) (6 * q)) := by
          gcongr
          exact le_abs_self CS
    _ ≤ |CS| *
          ((M : ℝ) / Real.log ((2 * M : ℕ) : ℝ)) *
          Real.exp
            (PaperB.M4B.primeMass
              (h2BooleanTiltLift q h2BooleanFirstTilt) (2 * M) (6 * q)) := by
          gcongr
    _ ≤ |CS| *
          ((M : ℝ) / Real.log ((2 * M : ℕ) : ℝ)) *
          (E * (Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanX0) := by
          dsimp [E]
          gcongr
    _ = (|CS| * E) * (M : ℝ) *
          (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) := by
          rw [Real.rpow_sub_one hlog.ne' h2BooleanX0]
          field_simp [hlog.ne']


#print axioms h2BooleanFirstTilt_interval_log_power

theorem h2BooleanDyadicFirstMoment_le_interval
    {q M : ℕ} (hM : 0 < M) :
    (∑ S ∈ h2BooleanDyadicSets q M,
      finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) ≤
      (M : ℝ)⁻¹ *
        (∑ n ∈ Finset.Ioc M (2 * M),
          h2BooleanTiltLift q h2BooleanFirstTilt n) := by
  let F := h2BooleanDyadicSets q M
  let I := Finset.image primeSetProduct F
  have hinj : Set.InjOn primeSetProduct (↑F : Set (Finset ℕ)) := by
    dsimp [F]
    simpa using (h2BooleanDyadicSets_product_injective (q := q) (M := M))
  have himage :
      (∑ S ∈ F,
        finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) =
      ∑ n ∈ I,
        h2BooleanTiltLift q h2BooleanFirstTilt n / (n : ℝ) := by
    rw [Finset.sum_image hinj]
    apply Finset.sum_congr rfl
    intro S hS
    have hA := h2BooleanDyadicSets_active (q := q) (M := M) hS
    exact (h2BooleanFirstTiltLift_primeSetProduct_div hA).symm
  rw [himage]
  calc
    (∑ n ∈ I,
        h2BooleanTiltLift q h2BooleanFirstTilt n / (n : ℝ))
      ≤ ∑ n ∈ I,
          (M : ℝ)⁻¹ * h2BooleanTiltLift q h2BooleanFirstTilt n := by
        apply Finset.sum_le_sum
        intro n hn
        rcases Finset.mem_image.mp hn with ⟨S, hSF, rfl⟩
        have hr := h2BooleanDyadicSets_range (q := q) (M := M) hSF
        have hlift0 :
            0 ≤ h2BooleanTiltLift q h2BooleanFirstTilt (primeSetProduct S) :=
          h2BooleanTiltLift_nonneg q _ h2BooleanFirstTilt_nonneg
        have hMR : (0 : ℝ) < M := by exact_mod_cast hM
        have hnR : (M : ℝ) < primeSetProduct S := by exact_mod_cast hr.1
        rw [div_eq_mul_inv, mul_comm]
        exact mul_le_mul_of_nonneg_right
          (inv_anti₀ hMR hnR.le) hlift0
    _ = (M : ℝ)⁻¹ *
          (∑ n ∈ I, h2BooleanTiltLift q h2BooleanFirstTilt n) := by
        rw [Finset.mul_sum]
    _ ≤ (M : ℝ)⁻¹ *
          (∑ n ∈ Finset.Ioc M (2 * M),
            h2BooleanTiltLift q h2BooleanFirstTilt n) := by
        apply mul_le_mul_of_nonneg_left
        · apply Finset.sum_le_sum_of_subset_of_nonneg
          · intro n hn
            rcases Finset.mem_image.mp hn with ⟨S, hSF, rfl⟩
            exact Finset.mem_Ioc.mpr
              (h2BooleanDyadicSets_range (q := q) (M := M) hSF)
          · intro n hnI hnnot
            exact h2BooleanTiltLift_nonneg q _ h2BooleanFirstTilt_nonneg
        · positivity



#print axioms h2BooleanDyadicFirstMoment_le_interval

lemma h2BooleanSecondTiltLift_primeSetProduct_div
    {q : ℕ} {S : Finset ℕ}
    (hA : ∀ p ∈ S, activeHighPrime q p) :
    h2BooleanTiltLift q h2BooleanSecondTilt (primeSetProduct S) /
        (primeSetProduct S : ℝ) =
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card := by
  have hPrime : ∀ p ∈ S, p.Prime := fun p hp => (hA p hp).1
  have hsq := primeSetProduct_squarefree hPrime
  have hcop := activePrimeSetProduct_coprime hA
  have hn0 : primeSetProduct S ≠ 0 :=
    (primeSetProduct_pos hPrime).ne'
  have hprod := h2BooleanTiltLift_eq_prod
    (c := h2BooleanSecondTilt) hn0 hsq hcop
  rw [hprod]
  have hpf : (primeSetProduct S).primeFactors = S := by
    unfold primeSetProduct
    exact Nat.primeFactors_prod hPrime
  rw [hpf]
  have hden :
      (primeSetProduct S : ℝ) =
        ∏ p ∈ S, (p : ℝ) := by
    unfold primeSetProduct
    push_cast
    rfl
  rw [hden, ← Finset.prod_div_distrib]
  calc
    (∏ p ∈ S, h2BooleanTiltLocalFactor h2BooleanSecondTilt p / (p : ℝ)) =
        ∏ p ∈ S, h2BooleanTiltLift q h2BooleanSecondTilt p / (p : ℝ) := by
          apply Finset.prod_congr rfl
          intro p hpS
          have hp := hA p hpS
          have hp5 : 5 ≤ p := hp.2.1
          have hp0 : (0 : ℝ) < p := by exact_mod_cast hp.1.pos
          rw [h2BooleanSecondTiltLift_prime_div_eq hp]
          unfold h2BooleanTiltLocalFactor fixedQShiuPrimeFactor
          rw [if_pos hp5, h2BooleanSecondTilt_eq]
          unfold h2BooleanV0
          field_simp [hp0.ne']
    _ = finiteOmegaWeightReal S * h2BooleanV0 ^ S.card :=
      h2BooleanSecondTiltWeight_prod_eq hA

#print axioms h2BooleanSecondTiltLift_primeSetProduct_div

lemma h2BooleanBlockLeftFrequency_natCast
    (S R : Finset ℕ) (hdisj : Disjoint S R)
    (hPrimeS : ∀ p ∈ S, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (j : ℕ) :
    h2BooleanBlockLeftFrequency S R hdisj hPrimeS hPrimeR
      (j : ZMod (primeSetProduct (S ∪ R))) =
      ((crtLeftCoeff (primeSetProduct S) (primeSetProduct R) : ℤ) :
        ZMod (primeSetProduct S)) *
      (j : ZMod (primeSetProduct S)) := by
  unfold h2BooleanBlockLeftFrequency
  rw [h2BooleanBlockCRTEquiv_apply_natCast]

lemma h2BooleanBlockLeftMultiplier_isUnit
    (S R : Finset ℕ) (hdisj : Disjoint S R)
    (hPrimeS : ∀ p ∈ S, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime) :
    IsUnit
      (((crtLeftCoeff (primeSetProduct S) (primeSetProduct R) : ℤ) :
        ZMod (primeSetProduct S))) := by
  letI : NeZero (primeSetProduct S) :=
    ⟨(primeSetProduct_pos hPrimeS).ne'⟩
  exact crtLeftCoeff_isUnit
    (h2_primeSetProduct_coprime hdisj hPrimeS hPrimeR)

#print axioms h2BooleanBlockLeftFrequency_natCast
#print axioms h2BooleanBlockLeftMultiplier_isUnit

lemma h2_crtLeftCoeff_mul_eq_one
    {m n : ℕ} [NeZero m] (hcop : m.Coprime n) :
    (((crtLeftCoeff m n : ℤ) : ZMod m) * (n : ZMod m)) = 1 := by
  have hbez := crt_bezout hcop
  have hcast := congrArg (fun z : ℤ => (z : ZMod m)) hbez
  simpa [add_comm, mul_comm, mul_left_comm, mul_assoc] using hcast

lemma h2_crtLeftCoeff_eq_unit_inv
    {m n : ℕ} [NeZero m] (hcop : m.Coprime n) :
    ((crtLeftCoeff m n : ℤ) : ZMod m) =
      (((ZMod.unitOfCoprime n hcop.symm)⁻¹ : (ZMod m)ˣ) : ZMod m) := by
  let u : (ZMod m)ˣ := ZMod.unitOfCoprime n hcop.symm
  have hu : (u : ZMod m) = (n : ZMod m) := by
    exact ZMod.coe_unitOfCoprime n hcop.symm
  have hmul :
      (u : ZMod m) * ((crtLeftCoeff m n : ℤ) : ZMod m) = 1 := by
    rw [hu, mul_comm]
    exact h2_crtLeftCoeff_mul_eq_one hcop
  calc
    ((crtLeftCoeff m n : ℤ) : ZMod m)
        = 1 * ((crtLeftCoeff m n : ℤ) : ZMod m) := by simp
    _ = (((u⁻¹ : (ZMod m)ˣ) : ZMod m) * (u : ZMod m)) *
          ((crtLeftCoeff m n : ℤ) : ZMod m) := by simp
    _ = (((u⁻¹ : (ZMod m)ˣ) : ZMod m) *
          ((u : ZMod m) * ((crtLeftCoeff m n : ℤ) : ZMod m))) := by ring
    _ = (((u⁻¹ : (ZMod m)ˣ) : ZMod m) * 1) := by rw [hmul]
    _ = (((u⁻¹ : (ZMod m)ˣ) : ZMod m)) := by simp

lemma h2_sum_units_inv
    {m : ℕ} [NeZero m] (F : (ZMod m)ˣ → ℝ) :
    (∑ u : (ZMod m)ˣ, F u⁻¹) = ∑ u : (ZMod m)ˣ, F u := by
  exact Fintype.sum_equiv (Equiv.inv ((ZMod m)ˣ))
    (fun u : (ZMod m)ˣ => F u⁻¹)
    (fun u : (ZMod m)ˣ => F u)
    (fun u => by simp)

lemma h2_sum_units_fourier_inv_eq
    {S : Finset ℕ} (hPrime : ∀ p ∈ S, p.Prime)
    [NeZero (primeSetProduct S)] (j : ℤ) :
    (∑ u : (ZMod (primeSetProduct S))ˣ,
      ‖fixedProductBooleanFourierCoeff S hPrime
        ((j : ZMod (primeSetProduct S)) *
          ((u⁻¹ : (ZMod (primeSetProduct S))ˣ) :
            ZMod (primeSetProduct S)))‖ ^ 2) =
    ∑ u : (ZMod (primeSetProduct S))ˣ,
      ‖fixedProductBooleanFourierCoeff S hPrime
        ((j : ZMod (primeSetProduct S)) *
          (u : ZMod (primeSetProduct S)))‖ ^ 2 := by
  simpa using h2_sum_units_inv
    (m := primeSetProduct S)
    (fun u : (ZMod (primeSetProduct S))ˣ =>
      ‖fixedProductBooleanFourierCoeff S hPrime
        ((j : ZMod (primeSetProduct S)) * (u : ZMod (primeSetProduct S)))‖ ^ 2)

#print axioms h2_crtLeftCoeff_eq_unit_inv
#print axioms h2_sum_units_fourier_inv_eq

lemma h2BooleanSecondWeight_union
    (T R : Finset ℕ) (hdisj : Disjoint T R) :
    finiteOmegaWeightReal (T ∪ R) * h2BooleanV0 ^ (T ∪ R).card =
      (finiteOmegaWeightReal T * h2BooleanV0 ^ T.card) *
      (finiteOmegaWeightReal R * h2BooleanV0 ^ R.card) := by
  simp only [finiteOmegaWeightReal]
  rw [Finset.prod_union hdisj]
  rw [Finset.card_union_of_disjoint hdisj]
  rw [pow_add]
  ring

lemma h2BooleanBlockLeftFrequency_natCast_eq_mul_inv_unit
    (T R : Finset ℕ) (hdisj : Disjoint T R)
    (hPrimeT : ∀ p ∈ T, p.Prime)
    (hPrimeR : ∀ p ∈ R, p.Prime)
    (j : ℕ) :
    h2BooleanBlockLeftFrequency T R hdisj hPrimeT hPrimeR
      (j : ZMod (primeSetProduct (T ∪ R))) =
      (j : ZMod (primeSetProduct T)) *
        (((ZMod.unitOfCoprime (primeSetProduct R)
          (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR).symm)⁻¹ :
            (ZMod (primeSetProduct T))ˣ) : ZMod (primeSetProduct T)) := by
  letI : NeZero (primeSetProduct T) :=
    ⟨(primeSetProduct_pos hPrimeT).ne'⟩
  rw [h2BooleanBlockLeftFrequency_natCast]
  rw [h2_crtLeftCoeff_eq_unit_inv
    (h2_primeSetProduct_coprime hdisj hPrimeT hPrimeR)]
  ring

#print axioms h2BooleanSecondWeight_union
#print axioms h2BooleanBlockLeftFrequency_natCast_eq_mul_inv_unit

theorem h2_weightedCompleteUnitFourierSecondMoment_inv_eq_m3
    {q : ℕ} {S : Finset ℕ}
    (hA : ∀ p ∈ S, activeHighPrime q p)
    [NeZero (primeSetProduct S)]
    (j : ℤ) :
    finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
      (((Fintype.card (ZMod (primeSetProduct S))ˣ : ℝ)⁻¹) *
        (∑ u : (ZMod (primeSetProduct S))ˣ,
          ‖fixedProductBooleanFourierCoeff S
            (fun p hp => (hA p hp).1)
            ((j : ZMod (primeSetProduct S)) *
              ((u⁻¹ : (ZMod (primeSetProduct S))ˣ) :
                ZMod (primeSetProduct S)))‖ ^ 2)) =
      ∏ p ∈ S, h2BooleanM3LocalWeight q p j := by
  rw [h2_sum_units_fourier_inv_eq
    (hPrime := fun p hp => (hA p hp).1) j]
  exact h2_weightedCompleteUnitFourierSecondMoment_eq_m3 hA j

#print axioms h2_weightedCompleteUnitFourierSecondMoment_inv_eq_m3

lemma h2BooleanSmoothPrimeSet_primeSetProduct
    {Y : ℕ} {S : Finset ℕ} (hPrime : ∀ p ∈ S, p.Prime) :
    h2BooleanSmoothPrimeSet Y (primeSetProduct S) =
      S.filter (fun p => p ≤ Y) := by
  unfold h2BooleanSmoothPrimeSet
  rw [show (primeSetProduct S).primeFactors = S by
    unfold primeSetProduct
    exact Nat.primeFactors_prod hPrime]

lemma h2BooleanRoughPrimeSet_primeSetProduct
    {Y : ℕ} {S : Finset ℕ} (hPrime : ∀ p ∈ S, p.Prime) :
    h2BooleanRoughPrimeSet Y (primeSetProduct S) =
      S.filter (fun p => Y < p) := by
  unfold h2BooleanRoughPrimeSet
  rw [show (primeSetProduct S).primeFactors = S by
    unfold primeSetProduct
    exact Nat.primeFactors_prod hPrime]

lemma h2Boolean_filtered_partition
    (Y : ℕ) (S : Finset ℕ) :
    S = S.filter (fun p => p ≤ Y) ∪ S.filter (fun p => Y < p) := by
  ext p
  simp only [Finset.mem_union, Finset.mem_filter]
  constructor
  · intro hp
    by_cases h : p ≤ Y
    · exact Or.inl ⟨hp, h⟩
    · exact Or.inr ⟨hp, Nat.lt_of_not_ge h⟩
  · rintro (⟨hp, _⟩ | ⟨hp, _⟩) <;> exact hp

lemma h2Boolean_filtered_disjoint
    (Y : ℕ) (S : Finset ℕ) :
    Disjoint (S.filter (fun p => p ≤ Y))
      (S.filter (fun p => Y < p)) := by
  rw [Finset.disjoint_left]
  intro p hs hr
  have hsY := (Finset.mem_filter.mp hs).2
  have hrY := (Finset.mem_filter.mp hr).2
  omega

#print axioms h2BooleanSmoothPrimeSet_primeSetProduct
#print axioms h2BooleanRoughPrimeSet_primeSetProduct

end PaperB.FixedQ
