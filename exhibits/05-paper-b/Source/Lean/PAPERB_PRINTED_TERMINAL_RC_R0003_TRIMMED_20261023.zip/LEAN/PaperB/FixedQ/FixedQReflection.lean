import PaperB.FixedQ.LocalReflection
import PaperB.FixedQ.PairRowBridge

namespace PaperB.FixedQ

def admissibleInteriorOffsetSet (q a h : ℕ) : Finset ℕ :=
  (Finset.Ioo 0 h).filter fun y => q.Coprime (a + y)

theorem admissibleInteriorOffsetSet_card_eq
    (q a h : ℕ) :
    (admissibleInteriorOffsetSet q a h).card =
      admissibleInteriorCount q a h := by
  unfold admissibleInteriorOffsetSet admissibleInteriorCount
  apply Finset.card_bij'
    (fun y _ => a + y)
    (fun x _ => x - a)
  · intro y hy
    have hy' := Finset.mem_filter.mp hy
    have hyI := Finset.mem_Ioo.mp hy'.1
    apply Finset.mem_filter.mpr
    constructor
    · apply Finset.mem_Ioo.mpr
      omega
    · simpa using hy'.2
  · intro x hx
    have hx' := Finset.mem_filter.mp hx
    have hxI := Finset.mem_Ioo.mp hx'.1
    apply Finset.mem_filter.mpr
    constructor
    · apply Finset.mem_Ioo.mpr
      omega
    · have hax : a + (x - a) = x := Nat.add_sub_of_le hxI.1.le
      simpa [hax] using hx'.2
  · intro y hy
    have hyI := Finset.mem_Ioo.mp (Finset.mem_filter.mp hy).1
    omega
  · intro x hx
    have hxI := Finset.mem_Ioo.mp (Finset.mem_filter.mp hx).1
    omega

theorem admissibleInteriorCount_eq_offsetCard
    (q a h : ℕ) :
    admissibleInteriorCount q a h =
      (admissibleInteriorOffsetSet q a h).card := by
  exact (admissibleInteriorOffsetSet_card_eq q a h).symm

theorem admissibleInteriorCount_reflect_of_coprime
    {q a r h : ℕ}
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    admissibleInteriorCount q a h =
      admissibleInteriorCount q r h := by
  rw [admissibleInteriorCount_eq_offsetCard,
    admissibleInteriorCount_eq_offsetCard]
  unfold admissibleInteriorOffsetSet
  apply Finset.card_bij'
    (fun y _ => h - y)
    (fun z _ => h - z)
  · intro y hy
    have hy' := Finset.mem_filter.mp hy
    have hyI := Finset.mem_Ioo.mp hy'.1
    apply Finset.mem_filter.mpr
    constructor
    · apply Finset.mem_Ioo.mpr
      omega
    · have href := hreflect (h - y) (by
        apply Finset.mem_Ioo.mpr
        omega)
      have hsub : h - (h - y) = y := Nat.sub_sub_self hyI.2.le
      have ha : q.Coprime (a + (h - (h - y))) := by
        simpa [hsub] using hy'.2
      exact href.mp ha
  · intro z hz
    have hz' := Finset.mem_filter.mp hz
    have hzI := Finset.mem_Ioo.mp hz'.1
    apply Finset.mem_filter.mpr
    constructor
    · apply Finset.mem_Ioo.mpr
      omega
    · have href := hreflect z hz'.1
      exact href.mpr hz'.2
  · intro y hy
    have hyI := Finset.mem_Ioo.mp (Finset.mem_filter.mp hy).1
    omega
  · intro z hz
    have hzI := Finset.mem_Ioo.mp (Finset.mem_filter.mp hz).1
    omega

theorem fixedQLowWeight_reflect_of_coprime
    {q a r h z : ℕ} (hz : z ≤ h)
    (hc : q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    fixedQLowWeight q a h (h - z) =
      fixedQLowWeight q r h z := by
  unfold fixedQLowWeight
  rw [lowPrimeProduct_reflect q h z hz]
  by_cases ha : q.Coprime (a + (h - z))
  · have hr : q.Coprime (r + z) := hc.mp ha
    rw [if_pos ha, if_pos hr]
  · have hr : ¬ q.Coprime (r + z) := fun h => ha (hc.mpr h)
    rw [if_neg ha, if_neg hr]

theorem fixedQRowDelta_reflect_of_coprime
    {q a r h e1 e2 : ℕ}
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    fixedQRowDelta q a h e1 e2 =
      fixedQRowDelta q r h e2 e1 := by
  unfold fixedQRowDelta
  have hmass :
      rowConstrainedMass (fixedQLowWeight q a h) h e1 e2 =
        rowConstrainedMass (fixedQLowWeight q r h) h e2 e1 := by
    rw [rowConstrainedMass_reflect]
    unfold rowConstrainedMass
    apply Finset.sum_congr rfl
    intro z hz
    have hzI := Finset.mem_Ioo.mp hz
    by_cases hcond : e2 ∣ z ∧ e1 ∣ h - z
    · simp only [hcond, if_true]
      exact fixedQLowWeight_reflect_of_coprime
        (Nat.le_of_lt hzI.2) (hreflect z hz)
    · simp only [hcond, if_false]
  have hcount :=
    admissibleInteriorCount_reflect_of_coprime hreflect
  rw [hmass, hcount]
  ring

#print axioms admissibleInteriorOffsetSet_card_eq
#print axioms admissibleInteriorCount_reflect_of_coprime
#print axioms fixedQRowDelta_reflect_of_coprime

end PaperB.FixedQ
