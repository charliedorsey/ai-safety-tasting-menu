import Mathlib.Data.ZMod.Basic
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Tactic

/-!
# Quillon CSC3 seam 1: the exact sawtooth normal form of the selected CRT-digit class

This file is **exact algebra**: no analytic input, no axiom, no `sorry`.

The source summand is `GoldC.foldRowClass`, from `GoldC/C2Fold.lean`:

    -(2μ) saw(H·r̄/s) + Σ_{b<6q} Σ_{ν<6q} Γ(b,ν) · 1[crtResidue H r s % 6q = b ∧ rs % 6q = ν].

Here `Γ = gammaClass q a D H`, and `Σ_b Γ(b,ν) = 0` for every `ν` (`GoldC.sum_gammaClass_zero`).

We prove, for every modulus `M ≥ 2` with `(r,M) = (s,M) = 1` and `s ≥ 2`:

* `indicator_fract_lt`: `1[{x} < δ] = δ + saw(x - δ) - saw(x)` for `0 < δ ≤ 1`. This is exact for
  every real `x`.
* `crtClass_iff_fract`: `crtResidue H r s % M = b ↔ {x_b} < 1/M`, where
  `x_b = (t·M̄)/s + (β_b·s̄)/M`, with `t = (H·r̄) % s`, `M̄ = M⁻¹ mod s`, `s̄ = s⁻¹ mod M`, and
  `β_b = (b·r̄_M) % M`.
* `classPart_normal_form`: for **any** `Γ` with `Σ_b Γ(b,ν) = 0`,

      Σ_b Σ_ν Γ(b,ν)·1[c%M=b ∧ rs%M=ν] = Σ_b Γ(b, rs%M) · (saw(x_b - 1/M) - saw(x_b)).

  The class zero mode cancels exactly, using the full `b`-fiber.
* `phase_kloosterman`: `(t·M̄) % s = (H·(Mr)⁻¹) % s`. So the `s`-part of every `x_b` is the
  Kloosterman fraction `H·\overline{Mr}/s`, and the `M`-part `β_b s̄/M` depends only on
  `(b, r mod M, s mod M)`.

So the entire selected class summand (both `b` and `ν`) is a finite combination, with coefficients
`Γ`, of sawtooths at `H·\overline{Mr}/s + (rational with denominator M depending only on residues
mod M)`. W, VW and R therefore apply after fixing `(r mod M, s mod M)` (see `CLASS_SEAM.md`).

`saw`, `invMod` and `crtResidue` are **verbatim copies** of `GoldC/RowRounding.lean`
(namespace `GoldC.QuillonCopyC`). To replay in production, delete the copies and
`import GoldC.RowRounding`. Then instantiate `Γ := gammaClass q a D H` with
`sum_gammaClass_zero`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonCopyC

/-- verbatim copy of `GoldC.saw` -/
noncomputable def saw (x : ℝ) : ℝ := Int.fract x - 1 / 2

/-- verbatim copy of `GoldC.invMod` -/
noncomputable def invMod (r s : ℕ) : ℕ := ((r : ZMod s)⁻¹).val

/-- verbatim copy of `GoldC.crtResidue` -/
noncomputable def crtResidue (H r s : ℕ) : ℕ := r * ((H * invMod r s) % s)

lemma mul_invMod_modEq {r s : ℕ} (hs : 2 ≤ s) (h : r.Coprime s) :
    r * invMod r s ≡ 1 [MOD s] := by
  have : NeZero s := ⟨by omega⟩
  rw [← ZMod.natCast_eq_natCast_iff]
  push_cast
  unfold invMod
  rw [ZMod.natCast_val, ZMod.cast_id', id, ZMod.coe_mul_inv_eq_one _ h]

/-! ## 1. Indicator of a fractional-part interval as two sawtooths (exact) -/

theorem indicator_fract_lt (x δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ ≤ 1) :
    (if Int.fract x < δ then (1 : ℝ) else 0) = δ + saw (x - δ) - saw x := by
  unfold saw
  have h0 := Int.fract_nonneg x
  have h1 := Int.fract_lt_one x
  split_ifs with h
  · have : Int.fract (x - δ) = Int.fract x - δ + 1 := by
      rw [Int.fract_eq_iff]
      refine ⟨by linarith, by linarith, ⌊x⌋ - 1, ?_⟩
      rw [Int.fract] ; push_cast; ring
    rw [this]; ring
  · push Not at h
    have : Int.fract (x - δ) = Int.fract x - δ := by
      rw [Int.fract_eq_iff]
      refine ⟨by linarith, by linarith, ⌊x⌋, ?_⟩
      rw [Int.fract]; ring
    rw [this]; ring

/-! ## 2. The CRT lift of the selected digit class -/

lemma fract_natCast_div (N m : ℕ) (hm : 0 < m) :
    Int.fract ((N : ℝ) / m) = ((N % m : ℕ) : ℝ) / m := by
  have hmR : (0 : ℝ) < m := by exact_mod_cast hm
  rw [Int.fract_eq_iff]
  have h := Nat.div_add_mod N m
  have key : (N : ℝ) = (m : ℝ) * ((N / m : ℕ) : ℝ) + ((N % m : ℕ) : ℝ) := by
    exact_mod_cast h.symm
  refine ⟨by positivity, ?_, ((N / m : ℕ) : ℤ), ?_⟩
  · rw [div_lt_one hmR]; exact_mod_cast Nat.mod_lt _ hm
  · rw [Int.cast_natCast, key]
    field_simp
    ring

/-- The selected digit class `c % M = b` is the single CRT window `u < s`. -/
theorem crtClass_iff_fract {H r s M b : ℕ} (hM : 2 ≤ M) (hs : 2 ≤ s)
    (hrM : r.Coprime M) (hsM : s.Coprime M) (hb : b < M) :
    crtResidue H r s % M = b ↔
      Int.fract ((((H * invMod r s) % s * invMod M s : ℕ) : ℝ) / s +
        (((b * invMod r M) % M * invMod s M : ℕ) : ℝ) / M) < 1 / M := by
  set t := (H * invMod r s) % s with ht
  set β := (b * invMod r M) % M with hβ
  have hMs : 0 < M * s := by positivity
  have hMR : (0 : ℝ) < M := by exact_mod_cast (show 0 < M by omega)
  have hsR : (0 : ℝ) < s := by exact_mod_cast (show 0 < s by omega)
  set N := t * invMod M s * M + β * invMod s M * s with hN
  have hx : (((t * invMod M s : ℕ) : ℝ) / s + ((β * invMod s M : ℕ) : ℝ) / M) =
      (N : ℝ) / ((M * s : ℕ) : ℝ) := by
    rw [hN]; push_cast; field_simp; try ring
  rw [hx, fract_natCast_div N (M * s) hMs]
  set u := N % (M * s) with hu
  -- fract < 1/M ↔ u < s
  have hwin : ((u : ℝ) / ((M * s : ℕ) : ℝ) < 1 / M) ↔ u < s := by
    rw [show ((M * s : ℕ) : ℝ) = (M : ℝ) * s by push_cast; ring,
      div_lt_div_iff₀ (by positivity) hMR, one_mul]
    constructor
    · intro h
      have h' : (u : ℝ) < s := by
        by_contra hc; push Not at hc; nlinarith
      exact_mod_cast h'
    · intro h
      have h' : (u : ℝ) < s := by exact_mod_cast h
      nlinarith
  rw [hwin]
  -- u ≡ t (mod s), u ≡ β (mod M)
  have hMinv := mul_invMod_modEq hs hsM.symm   -- M * invMod M s ≡ 1 [MOD s]
  have hsinv := mul_invMod_modEq hM hsM         -- s * invMod s M ≡ 1 [MOD M]
  have hu_s : u ≡ t [MOD s] := by
    have h1 : u ≡ N [MOD s] := (Nat.mod_modEq N (M * s)).of_mul_left M
    have h2 : N ≡ t [MOD s] := by
      have e1 : t * invMod M s * M ≡ t * 1 [MOD s] := by
        rw [mul_assoc, mul_comm (invMod M s) M]; exact Nat.ModEq.mul_left t hMinv
      have e2 : β * invMod s M * s ≡ 0 [MOD s] := by
        rw [Nat.modEq_zero_iff_dvd]; exact Dvd.intro_left _ rfl
      have := Nat.ModEq.add e1 e2
      simpa [hN] using this
    exact h1.trans h2
  have hu_M : u ≡ β [MOD M] := by
    have h1 : u ≡ N [MOD M] := (Nat.mod_modEq N (M * s)).of_mul_right s
    have h2 : N ≡ β [MOD M] := by
      have e1 : t * invMod M s * M ≡ 0 [MOD M] := by
        rw [Nat.modEq_zero_iff_dvd]; exact Dvd.intro_left _ rfl
      have e2 : β * invMod s M * s ≡ β * 1 [MOD M] := by
        rw [mul_assoc, mul_comm (invMod s M) s]; exact Nat.ModEq.mul_left β hsinv
      have := Nat.ModEq.add e1 e2
      simpa [hN] using this
    exact h1.trans h2
  have hts : t < s := Nat.mod_lt _ (by omega)
  have hβM : β < M := Nat.mod_lt _ (by omega)
  have huMs : u < M * s := Nat.mod_lt _ hMs
  -- c % M = b ↔ t % M = β
  have hc : crtResidue H r s % M = b ↔ t % M = β := by
    have hrinv := mul_invMod_modEq hM hrM   -- r * invMod r M ≡ 1 [MOD M]
    unfold crtResidue
    rw [← ht]
    constructor
    · intro h
      -- t ≡ invMod r M * r * t ≡ invMod r M * b
      have h1 : r * t ≡ b [MOD M] := by
        unfold Nat.ModEq; rw [h, Nat.mod_eq_of_lt hb]
      have h2 : invMod r M * (r * t) ≡ invMod r M * b [MOD M] := Nat.ModEq.mul_left _ h1
      have h3 : invMod r M * (r * t) ≡ t [MOD M] := by
        have := Nat.ModEq.mul_right t (hrinv)
        rw [one_mul] at this
        calc invMod r M * (r * t) = r * invMod r M * t := by ring
          _ ≡ t [MOD M] := this
      have h4 : t ≡ b * invMod r M [MOD M] := by
        rw [mul_comm b]; exact h3.symm.trans h2
      unfold Nat.ModEq at h4; rw [h4, hβ]
    · intro h
      have h1 : t ≡ b * invMod r M [MOD M] := by
        unfold Nat.ModEq; rw [h, hβ]
      have h2 : r * t ≡ r * (b * invMod r M) [MOD M] := Nat.ModEq.mul_left r h1
      have h3 : r * (b * invMod r M) ≡ b [MOD M] := by
        have := Nat.ModEq.mul_left b hrinv
        rw [mul_one] at this
        calc r * (b * invMod r M) = b * (r * invMod r M) := by ring
          _ ≡ b [MOD M] := this
      have := h2.trans h3
      unfold Nat.ModEq at this; rw [this, Nat.mod_eq_of_lt hb]
  rw [hc]
  have hcop : M.Coprime s := hsM.symm
  constructor
  · intro h
    -- t ≡ u (mod s) and (mod M) ⇒ t ≡ u (mod M s) ⇒ t = u
    have hM' : t ≡ u [MOD M] := by
      have : t ≡ β [MOD M] := by unfold Nat.ModEq; rw [h, Nat.mod_eq_of_lt hβM]
      exact this.trans hu_M.symm
    have hMs' : t ≡ u [MOD M * s] :=
      (Nat.modEq_and_modEq_iff_modEq_mul hcop).1 ⟨hM', hu_s.symm⟩
    have : t = u := by
      unfold Nat.ModEq at hMs'
      rwa [Nat.mod_eq_of_lt (lt_of_lt_of_le hts (Nat.le_mul_of_pos_left s (by omega))),
        Nat.mod_eq_of_lt huMs] at hMs'
    omega
  · intro h
    have : u = t := by
      have := hu_s; unfold Nat.ModEq at this
      rwa [Nat.mod_eq_of_lt h, Nat.mod_eq_of_lt hts] at this
    have := hu_M; unfold Nat.ModEq at this
    rw [‹u = t›, Nat.mod_eq_of_lt hβM] at this
    exact this

/-! ## 3. Normal form of the selected class part (both `b` and `ν`), with exact zero-mode cancellation -/

/-- The CRT phase attached to digit `b`. -/
noncomputable def classPhase (H r s M b : ℕ) : ℝ :=
  (((H * invMod r s) % s * invMod M s : ℕ) : ℝ) / s +
    (((b * invMod r M) % M * invMod s M : ℕ) : ℝ) / M

theorem classPart_normal_form {H r s M : ℕ} (hM : 2 ≤ M) (hs : 2 ≤ s)
    (hrM : r.Coprime M) (hsM : s.Coprime M)
    (Γ : ℕ → ℕ → ℝ) (hΓ : ∀ ν, ∑ b ∈ range M, Γ b ν = 0) :
    ∑ b ∈ range M, ∑ ν ∈ range M,
        Γ b ν * (if crtResidue H r s % M = b ∧ (r * s) % M = ν then 1 else 0) =
      ∑ b ∈ range M, Γ b ((r * s) % M) *
        (saw (classPhase H r s M b - 1 / M) - saw (classPhase H r s M b)) := by
  set ν₀ := (r * s) % M
  have hν₀ : ν₀ ∈ range M := mem_range.2 (Nat.mod_lt _ (by omega))
  have hMR : (0 : ℝ) < M := by exact_mod_cast (show 0 < M by omega)
  -- collapse ν
  have hcol : ∀ b ∈ range M, ∑ ν ∈ range M,
      Γ b ν * (if crtResidue H r s % M = b ∧ (r * s) % M = ν then 1 else 0) =
      Γ b ν₀ * (if crtResidue H r s % M = b then 1 else 0) := by
    intro b _
    rw [Finset.sum_eq_single ν₀]
    · by_cases h : crtResidue H r s % M = b <;> simp [h, ν₀]
    · intro ν _ hne
      have : ¬ ((r * s) % M = ν) := fun h => hne (h ▸ rfl)
      simp [this]
    · intro h; exact absurd hν₀ h
  rw [Finset.sum_congr rfl hcol]
  -- indicator → 1/M + saw difference
  have hind : ∀ b ∈ range M, Γ b ν₀ * (if crtResidue H r s % M = b then (1 : ℝ) else 0) =
      Γ b ν₀ * (1 / M) + Γ b ν₀ *
        (saw (classPhase H r s M b - 1 / M) - saw (classPhase H r s M b)) := by
    intro b hb
    have hbM : b < M := mem_range.1 hb
    have hiff := crtClass_iff_fract (H := H) hM hs hrM hsM hbM
    have hδ1 : (1 : ℝ) / M ≤ 1 := by
      rw [div_le_one hMR]; exact_mod_cast (show 1 ≤ M by omega)
    have := indicator_fract_lt (classPhase H r s M b) (1 / M) (by positivity) hδ1
    have hite : (if crtResidue H r s % M = b then (1 : ℝ) else 0) =
        (if Int.fract (classPhase H r s M b) < 1 / M then (1 : ℝ) else 0) := by
      unfold classPhase; by_cases h : crtResidue H r s % M = b
      · simp only [h, hiff.1 h, ite_true]
      · have h2 : ¬ Int.fract ((((H * invMod r s) % s * invMod M s : ℕ) : ℝ) / s +
            (((b * invMod r M) % M * invMod s M : ℕ) : ℝ) / M) < 1 / M := fun h' => h (hiff.2 h')
        simp only [h, h2, ite_false]
    rw [hite, this]; ring
  rw [Finset.sum_congr rfl hind, Finset.sum_add_distrib, ← Finset.sum_mul, hΓ ν₀, zero_mul,
    zero_add]

/-! ## 4. The `s`-part of every class phase is the Kloosterman fraction `H·(Mr)⁻¹ / s` -/

theorem phase_kloosterman {H r s M : ℕ} (hs : 2 ≤ s) (hrs : r.Coprime s) (hMs : M.Coprime s) :
    ((H * invMod r s) % s * invMod M s) % s = (H * invMod (M * r) s) % s := by
  have : NeZero s := ⟨by omega⟩
  rw [← ZMod.natCast_eq_natCast_iff']
  simp only [Nat.cast_mul, ZMod.natCast_mod]
  unfold invMod
  simp only [ZMod.natCast_val, ZMod.cast_id', id]
  have hA := ZMod.coe_mul_inv_eq_one r hrs
  have hB := ZMod.coe_mul_inv_eq_one M hMs
  have hC := ZMod.coe_mul_inv_eq_one (M * r) (Nat.coprime_mul_iff_left.2 ⟨hMs, hrs⟩)
  push_cast at hC ⊢
  calc (H : ZMod s) * (r : ZMod s)⁻¹ * (M : ZMod s)⁻¹
      = H * (r : ZMod s)⁻¹ * (M : ZMod s)⁻¹ * ((M * r : ZMod s) * (M * r : ZMod s)⁻¹) := by
        rw [hC, mul_one]
    _ = H * (M * r : ZMod s)⁻¹ * ((r : ZMod s) * (r : ZMod s)⁻¹) *
          ((M : ZMod s) * (M : ZMod s)⁻¹) := by ring
    _ = H * (M * r : ZMod s)⁻¹ := by rw [hA, hB]; ring

end GoldC.QuillonCopyC

#print axioms GoldC.QuillonCopyC.indicator_fract_lt
#print axioms GoldC.QuillonCopyC.crtClass_iff_fract
#print axioms GoldC.QuillonCopyC.classPart_normal_form
#print axioms GoldC.QuillonCopyC.phase_kloosterman
