import PaperB.FixedQ.GlobalProperWalfiszBounds

namespace PaperB.FixedQ

lemma neris_log_42_mul_log_rpow_le
    {H : ℕ}
    (hL1 : 1 ≤ Real.log (H : ℝ))
    (hLL1 : 1 ≤ Real.log (Real.log (H : ℝ))) :
    Real.log
        (42 * (Real.log (H : ℝ)) ^ h2BooleanSigma) ≤
      42 * Real.log (Real.log (H : ℝ)) := by
  let L : ℝ := Real.log (H : ℝ)
  let LL : ℝ := Real.log L
  have hLpos : 0 < L := by dsimp [L]; linarith
  have hLL0 : 0 ≤ LL := by dsimp [LL]; linarith
  have hsigma1 : h2BooleanSigma ≤ 1 := h2BooleanSigma_le_one
  have hlogS :
      Real.log (L ^ h2BooleanSigma) = h2BooleanSigma * LL := by
    dsimp [LL]
    rw [Real.log_rpow hLpos]
  have hlog42 : Real.log (42 : ℝ) ≤ 41 := by
    calc
      Real.log (42 : ℝ) ≤ 42 - 1 :=
        Real.log_le_sub_one_of_pos (by norm_num)
      _ = 41 := by norm_num
  have hSpos : 0 < L ^ h2BooleanSigma := by positivity
  rw [Real.log_mul (by norm_num : (42 : ℝ) ≠ 0) hSpos.ne', hlogS]
  have hsLL : h2BooleanSigma * LL ≤ LL := by
    exact mul_le_of_le_one_left hLL0 hsigma1
  linarith

#print axioms neris_log_42_mul_log_rpow_le

end PaperB.FixedQ
