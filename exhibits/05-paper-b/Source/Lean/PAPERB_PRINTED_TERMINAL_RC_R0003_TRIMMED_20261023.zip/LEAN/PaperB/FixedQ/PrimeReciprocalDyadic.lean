import PaperB.FixedQ.FixedProductAverage
import Mathlib.NumberTheory.Chebyshev

open scoped BigOperators
open Finset Nat Real

namespace PaperB.FixedQ

noncomputable def primeReciprocalDyadicBlock (T : ℕ) : ℝ :=
  ∑ p ∈ (2 * T).primesLE.filter (fun p => T < p), (1 : ℝ) / p

theorem primeReciprocalDyadicBlock_le_card
    {T : ℕ} (hT : 0 < T) :
    primeReciprocalDyadicBlock T ≤
      (((2 * T).primesLE.filter (fun p => T < p)).card : ℝ) / T := by
  unfold primeReciprocalDyadicBlock
  calc
    (∑ p ∈ (2 * T).primesLE.filter (fun p => T < p), (1 : ℝ) / p)
        ≤ ∑ _p ∈ (2 * T).primesLE.filter (fun p => T < p),
            (1 : ℝ) / T := by
          apply Finset.sum_le_sum
          intro p hp
          have hpT : T < p := (Finset.mem_filter.mp hp).2
          have hTR : (0 : ℝ) < T := by exact_mod_cast hT
          have hpR : (0 : ℝ) < p := by exact_mod_cast (lt_trans hT hpT)
          exact (div_le_div_iff₀ hpR hTR).2 (by
            norm_num
            exact_mod_cast hpT.le)
    _ = (((2 * T).primesLE.filter (fun p => T < p)).card : ℝ) / T := by
          simp [div_eq_mul_inv, mul_comm]

theorem primeReciprocalDyadicBlock_le_primeCounting
    {T : ℕ} (hT : 0 < T) :
    primeReciprocalDyadicBlock T ≤
      ((Nat.primeCounting (2 * T) : ℝ) / T) := by
  have hbase := primeReciprocalDyadicBlock_le_card hT
  calc
    primeReciprocalDyadicBlock T ≤
        (((2 * T).primesLE.filter (fun p => T < p)).card : ℝ) / T := hbase
    _ ≤ (((2 * T).primesLE.card : ℕ) : ℝ) / T := by
      apply div_le_div_of_nonneg_right
      · exact_mod_cast
          (Finset.card_filter_le
            (s := (2 * T).primesLE) (p := fun p => T < p))
      · positivity
    _ = ((Nat.primeCounting (2 * T) : ℝ) / T) := by
      rw [Nat.primesLE_card_eq_primeCounting]

theorem log_nat_le_two_sqrt_nat {T : ℕ} (hT : 0 < T) :
    Real.log (T : ℝ) ≤ 2 * Real.sqrt T := by
  have h := Real.log_le_rpow_div
    (x := (T : ℝ)) (ε := (1 / 2 : ℝ)) (by positivity) (by norm_num)
  simpa [Real.sqrt_eq_rpow, mul_comm] using h

theorem primeReciprocalDyadicBlock_le
    {T : ℕ} (hT : 4 ≤ T) :
    primeReciprocalDyadicBlock T ≤ 16 / Real.log T := by
  have hTpos : 0 < T := by omega
  have hlogT : 0 < Real.log (T : ℝ) :=
    Real.log_pos (by exact_mod_cast (show 1 < T by omega))
  have h2T : (1 : ℝ) < (2 * T : ℕ) := by
    exact_mod_cast (show 1 < 2 * T by omega)
  have hpi := Chebyshev.pi_le_log4_mul_div (x := ((2 * T : ℕ) : ℝ)) h2T
  norm_num only [Nat.floor_natCast] at hpi
  have hcount := primeReciprocalDyadicBlock_le_primeCounting hTpos
  have hsqrt2T : Real.sqrt ((2 * T : ℕ) : ℝ) ≤
      2 * Real.sqrt (T : ℝ) := by
    have hsq : Real.sqrt ((2 : ℝ) * T) =
        Real.sqrt 2 * Real.sqrt T := by
      rw [Real.sqrt_mul (by norm_num : (0 : ℝ) ≤ 2)]
    rw [Nat.cast_mul, Nat.cast_ofNat, hsq]
    have hs2 : Real.sqrt 2 ≤ 2 := by nlinarith [Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)]
    exact mul_le_mul_of_nonneg_right hs2 (Real.sqrt_nonneg _)
  have hlogsqrt :
      Real.log (Real.sqrt ((2 * T : ℕ) : ℝ)) ≥
        (1 / 2 : ℝ) * Real.log (T : ℝ) := by
    rw [Real.log_sqrt (by positivity)]
    have hlogmono : Real.log (T : ℝ) ≤ Real.log ((2 * T : ℕ) : ℝ) := by
      apply Real.log_le_log
      · positivity
      · norm_num
        exact_mod_cast (show T ≤ 2 * T by omega)
    linarith
  have hlogsqrtpos : 0 < Real.log (Real.sqrt ((2 * T : ℕ) : ℝ)) := by
    linarith
  have hlog4 : Real.log 4 ≤ 3 := by
    have h := Real.log_le_sub_one_of_pos (show (0 : ℝ) < 4 by norm_num)
    norm_num at h ⊢
    exact h
  have hsqrtTerm :
      Real.sqrt ((2 * T : ℕ) : ℝ) / (T : ℝ) ≤
        4 / Real.log (T : ℝ) := by
    have hsqrtTpos : 0 < Real.sqrt (T : ℝ) := Real.sqrt_pos.2 (by positivity)
    have hsq : (Real.sqrt (T : ℝ)) ^ 2 = (T : ℝ) :=
      Real.sq_sqrt (by positivity)
    calc
      Real.sqrt ((2 * T : ℕ) : ℝ) / (T : ℝ)
          ≤ (2 * Real.sqrt (T : ℝ)) / (T : ℝ) := by
            exact div_le_div_of_nonneg_right hsqrt2T (by positivity)
      _ = (2 * Real.sqrt (T : ℝ)) / ((Real.sqrt (T : ℝ)) ^ 2) := by
            rw [hsq]
      _ = 2 / Real.sqrt (T : ℝ) := by
            field_simp [hsqrtTpos.ne']
      _ ≤ 4 / Real.log (T : ℝ) := by
            apply (div_le_div_iff₀ hsqrtTpos hlogT).2
            have hlogroot := log_nat_le_two_sqrt_nat hTpos
            nlinarith
  have hmainTerm :
      (Real.log 4 * (((2 * T : ℕ) : ℝ)) /
          Real.log (Real.sqrt ((2 * T : ℕ) : ℝ))) / (T : ℝ)
        ≤ 12 / Real.log (T : ℝ) := by
    have hTreal : (0 : ℝ) < T := by positivity
    calc
      (Real.log 4 * (((2 * T : ℕ) : ℝ)) /
          Real.log (Real.sqrt ((2 * T : ℕ) : ℝ))) / (T : ℝ)
          = (2 * Real.log 4) /
              Real.log (Real.sqrt ((2 * T : ℕ) : ℝ)) := by
                norm_num [Nat.cast_mul]
                field_simp [hTreal.ne']
      _ ≤ 6 / Real.log (Real.sqrt ((2 * T : ℕ) : ℝ)) := by
            exact div_le_div_of_nonneg_right (by linarith) hlogsqrtpos.le
      _ ≤ 12 / Real.log (T : ℝ) := by
            apply (div_le_div_iff₀ hlogsqrtpos hlogT).2
            nlinarith
  calc
    primeReciprocalDyadicBlock T
        ≤ (Nat.primeCounting (2 * T) : ℝ) / T := hcount
    _ ≤ (Real.log 4 * (((2 * T : ℕ) : ℝ)) /
            Real.log (Real.sqrt ((2 * T : ℕ) : ℝ)) +
          Real.sqrt ((2 * T : ℕ) : ℝ)) / T := by
            exact div_le_div_of_nonneg_right hpi (by positivity)
    _ = (Real.log 4 * (((2 * T : ℕ) : ℝ)) /
            Real.log (Real.sqrt ((2 * T : ℕ) : ℝ))) / T +
          Real.sqrt ((2 * T : ℕ) : ℝ) / T := by ring
    _ ≤ 12 / Real.log T + 4 / Real.log T :=
          add_le_add hmainTerm hsqrtTerm
    _ = 16 / Real.log T := by ring

#print axioms primeReciprocalDyadicBlock_le

end PaperB.FixedQ
