import GoldC.DigitSplit

/-!
# `GoldC.SignedSupplier` — what is paid, and the precise remaining debt

**Exact, source-native, hypothesis-free** (`activeCentral_split`):
`activeCentral = (InvPart + DigitDensityPart) + (SawPart + DigitAPPart)`.

**Paid (rate, no hypotheses)**: `paidPart_small`. For fixed `q > 0` and every `ε > 0` there is
`H₀` with `|InvPart + DigitDensityPart| ≤ ε` for all anchors `a` and all `h ≥ H₀`. The explicit
majorant is `4(6q + 2)(1 + log h)³ Z(h)^{-1/2} e^{K₀}`, which tends to `0` like
`exp(-c (log h)^{2/3 + 1/100})`.

**Remaining debt (not proved)**: `CentralRoundingDebt`. It says the signed sum of
* `SawPart`, the Kloosterman-fraction sawtooth `-μ (ψ(H r̄/s) + ψ(H s̄/r))`, and
* `DigitAPPart`, the mean-zero weight `λ - μ` summed on the progression `y ≡ c (mod rs)`,

is `o(log h)`, under the target's quantifiers.

`signedActiveCentralSublog_iff_debt` proves `SignedActiveCentralSublog ↔ CentralRoundingDebt` in
both directions, so the debt is exactly the remaining content of the target.
-/

open scoped BigOperators Classical

namespace GoldC

/-- **The remaining debt**: the signed sawtooth part plus the constrained digit part is
`o(log h)`, uniformly in the anchor, with the target's quantifiers. -/
def CentralRoundingDebt : Prop :=
  ∀ q : ℕ, 0 < q → Squarefree q →
    ∀ eps : ℝ, 0 < eps →
      ∃ H0 : ℕ, ∀ a h : ℕ,
        q.Coprime a → 0 < h →
        (¬ 2 ∣ q → 2 ∣ h) → H0 ≤ h →
        |SawPart q a h + DigitAPPart q a h| ≤ eps * Real.log (h : ℝ)

/-- Exact split of the active Central covariance into a paid part and the debt part. -/
theorem activeCentral_split (q a h : ℕ) :
    activeCentral q a h =
      (InvPart q a h + DigitDensityPart q a h) + (SawPart q a h + DigitAPPart q a h) := by
  rw [activeCentral_decomp, DigitPart_split]; ring

/-- **Paid**: the density-diagonal part and the density share of the digit part vanish. -/
theorem paidPart_small (q : ℕ) (hq : 0 < q) (ε : ℝ) (hε : 0 < ε) :
    ∃ H0 : ℕ, ∀ a h : ℕ, H0 ≤ h → |InvPart q a h + DigitDensityPart q a h| ≤ ε := by
  obtain ⟨H1, hH1⟩ := InvPart_small (ε / 2) (by positivity)
  obtain ⟨H2, hH2⟩ := DigitDensityPart_small q hq (ε / 2) (by positivity)
  refine ⟨max H1 H2, fun a h hh => ?_⟩
  calc |InvPart q a h + DigitDensityPart q a h| ≤ |InvPart q a h| + |DigitDensityPart q a h| :=
        abs_add_le _ _
    _ ≤ ε / 2 + ε / 2 := add_le_add (hH1 q a h (le_of_max_le_left hh)) (hH2 a h (le_of_max_le_right hh))
    _ = ε := by ring

lemma paidPart_sublog (q : ℕ) (hq : 0 < q) (ε : ℝ) (hε : 0 < ε) :
    ∃ H0 : ℕ, ∀ a h : ℕ, H0 ≤ h →
      |InvPart q a h + DigitDensityPart q a h| ≤ ε * Real.log (h : ℝ) := by
  obtain ⟨H1, hH1⟩ := paidPart_small q hq ε hε
  have hev : ∀ᶠ h : ℕ in Filter.atTop, 1 ≤ Real.log (h : ℝ) :=
    (Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop).eventually
      (Filter.eventually_ge_atTop 1)
  obtain ⟨H2, hH2⟩ := Filter.eventually_atTop.1 hev
  refine ⟨max H1 H2, fun a h hh => ?_⟩
  have h1 := hH1 a h (le_of_max_le_left hh)
  have h2 := hH2 h (le_of_max_le_right hh)
  nlinarith

/-- **Supplier theorem**: the debt implies the target. -/
theorem signedActiveCentralSublog_of_debt (hdebt : CentralRoundingDebt) :
    SignedActiveCentralSublog := by
  intro q hq hsq eps heps
  obtain ⟨H1, hH1⟩ := hdebt q hq hsq (eps / 2) (by positivity)
  obtain ⟨H2, hH2⟩ := paidPart_sublog q hq (eps / 2) (by positivity)
  refine ⟨max H1 H2, fun a h hqa hh hpar hH => ?_⟩
  rw [activeCentral_split]
  calc |InvPart q a h + DigitDensityPart q a h + (SawPart q a h + DigitAPPart q a h)|
      ≤ |InvPart q a h + DigitDensityPart q a h| + |SawPart q a h + DigitAPPart q a h| :=
        abs_add_le _ _
    _ ≤ eps / 2 * Real.log h + eps / 2 * Real.log h :=
        add_le_add (hH2 a h (le_of_max_le_right hH)) (hH1 a h hqa hh hpar (le_of_max_le_left hH))
    _ = eps * Real.log h := by ring

/-- The converse: the target implies the debt (the debt carries no extra content). -/
theorem debt_of_signedActiveCentralSublog (htarget : SignedActiveCentralSublog) :
    CentralRoundingDebt := by
  intro q hq hsq eps heps
  obtain ⟨H1, hH1⟩ := htarget q hq hsq (eps / 2) (by positivity)
  obtain ⟨H2, hH2⟩ := paidPart_sublog q hq (eps / 2) (by positivity)
  refine ⟨max H1 H2, fun a h hqa hh hpar hH => ?_⟩
  have e : SawPart q a h + DigitAPPart q a h =
      activeCentral q a h - (InvPart q a h + DigitDensityPart q a h) := by
    rw [activeCentral_split]; ring
  rw [e]
  calc |activeCentral q a h - (InvPart q a h + DigitDensityPart q a h)|
      ≤ |activeCentral q a h| + |InvPart q a h + DigitDensityPart q a h| := abs_sub _ _
    _ ≤ eps / 2 * Real.log h + eps / 2 * Real.log h :=
        add_le_add (hH1 a h hqa hh hpar (le_of_max_le_left hH)) (hH2 a h (le_of_max_le_right hH))
    _ = eps * Real.log h := by ring

theorem signedActiveCentralSublog_iff_debt : SignedActiveCentralSublog ↔ CentralRoundingDebt :=
  ⟨debt_of_signedActiveCentralSublog, signedActiveCentralSublog_of_debt⟩

end GoldC
