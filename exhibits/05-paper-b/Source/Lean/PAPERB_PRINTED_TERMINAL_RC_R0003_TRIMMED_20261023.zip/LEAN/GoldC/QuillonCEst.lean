import GoldC.QuillonCCellApp
import GoldC.QuillonWEst

/-!
# Quillon CSC3 F7.9d: the region-C terms in closed form

* `TIIx_le`: `TIIx ≤ B·[√2·Lb³·√(T(log₂B+1))·(√(2U/B + 4/(V+1) + s/B) + √G₀·(√(2/s) + 1/√U))
                       + Lb⁵(2/T + 2/U + 2U/B + 4/(V+1))]`,
  where `Lb = 1 + log(U + 2B)` and `G₀ = ∏_{p∈P, p|c} p`, so that `g'·G₀ = s`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonCEst

open GoldC.QuillonExplicit GoldC.QuillonWEst

variable {s : ℕ} [NeZero s]

lemma g_mul_G0 (P : Finset ℕ) (hsP : s = ∏ p ∈ P, p) (c : ZMod s) :
    ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ) *
      ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) = 0), p : ℕ) : ℝ) = s := by
  rw [← Nat.cast_mul, mul_comm, prod_filter_mul_prod_filter_not]
  exact_mod_cast hsP.symm

lemma sqrt_add5_le (a b c d e : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) (hd : 0 ≤ d) (he : 0 ≤ e) :
    Real.sqrt (a + b + c + d + e) ≤ Real.sqrt (b + c + e) + Real.sqrt a + Real.sqrt d := by
  calc Real.sqrt (a + b + c + d + e) = Real.sqrt ((b + c + e) + a + d) := by ring_nf
    _ ≤ _ := sqrt_add3_le _ _ _ (by positivity) ha hd

theorem TIIx_le (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p) (c : ZMod s)
    (U V T B : ℕ) (hU : 1 ≤ U) (hT : 1 ≤ T) (hB : 1 ≤ B) :
    TIIx P c U V T B ≤ B * (Real.sqrt 2 * (1 + Real.log ((U : ℝ) + 2 * B)) ^ 3 *
        Real.sqrt ((T : ℝ) * (Nat.log 2 B + 1)) *
        (Real.sqrt (2 * U / B + 4 / ((V : ℝ) + 1) + s / B) +
          Real.sqrt (((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) = 0), p : ℕ) : ℝ)) *
            (Real.sqrt (2 / s) + 1 / Real.sqrt U)) +
      (1 + Real.log ((U : ℝ) + 2 * B)) ^ 5 * (2 / T + 2 / U + 2 * U / B + 4 / ((V : ℝ) + 1))) := by
  unfold TIIx
  set g : ℝ := ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ) with hg
  set G₀ : ℝ := ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) = 0), p : ℕ) : ℝ) with hG₀
  have hgG : g * G₀ = s := g_mul_G0 P hsP c
  have hgpos : 0 < g := by
    have : 0 < ∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p :=
      prod_pos fun p hp => (hP p (filter_subset _ _ hp)).pos
    rw [hg]; exact_mod_cast this
  have hG0 : 0 ≤ G₀ := Nat.cast_nonneg _
  have hG0pos : 0 < G₀ := by
    have : 0 < ∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) = 0), p :=
      prod_pos fun p hp => (hP p (filter_subset _ _ hp)).pos
    rw [hG₀]; exact_mod_cast this
  have hsR : (0 : ℝ) < s := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne s)
  have hBR : (1 : ℝ) ≤ B := by exact_mod_cast hB
  have hUR : (1 : ℝ) ≤ U := by exact_mod_cast hU
  have hTR : (1 : ℝ) ≤ T := by exact_mod_cast hT
  set Lb := 1 + Real.log ((U : ℝ) + 2 * B) with hLb
  have hlog0 : 0 ≤ Real.log ((U : ℝ) + 2 * B) := Real.log_nonneg (by linarith)
  have hLb1 : 1 ≤ Lb := by linarith
  have hlogB : Real.log B ≤ Lb := by
    have : Real.log B ≤ Real.log ((U : ℝ) + 2 * B) := Real.log_le_log (by linarith) (by linarith)
    linarith
  have hlogB0 : 0 ≤ Real.log B := Real.log_nonneg hBR
  set N₂ : ℝ := (T : ℝ) * (Nat.log 2 B + 1) with hN₂
  have hN₂0 : 0 ≤ N₂ := by positivity
  -- the bracket
  set W := 2 * B / g + 2 * ((U : ℝ) + 2 * B / ((V : ℝ) + 1)) + s * B / (U * g) + s with hW
  have hWeq : (B : ℝ) * W = (B : ℝ) ^ 2 * (2 * G₀ / s + 2 * U / B + 4 / ((V : ℝ) + 1) + G₀ / U + s / B) := by
    rw [hW]
    have hV1 : (0 : ℝ) < (V : ℝ) + 1 := by positivity
    field_simp
    rw [← hgG]; ring
  have hW0 : 0 ≤ W := by positivity
  -- first summand
  have h1 : Real.sqrt (2 * Lb ^ 4) * Real.sqrt (Real.log B ^ 2 * B * N₂ * W) ≤
      B * (Real.sqrt 2 * Lb ^ 3 * Real.sqrt N₂ *
        (Real.sqrt (2 * U / B + 4 / ((V : ℝ) + 1) + s / B) + Real.sqrt G₀ * (Real.sqrt (2 / s) + 1 / Real.sqrt U))) := by
    have e1 : Real.sqrt (2 * Lb ^ 4) = Real.sqrt 2 * Lb ^ 2 := by
      rw [Real.sqrt_mul (by norm_num), show Lb ^ 4 = (Lb ^ 2) ^ 2 by ring, Real.sqrt_sq (by positivity)]
    have e2 : Real.log B ^ 2 * B * N₂ * W = Real.log B ^ 2 * N₂ * (B * W) := by ring
    set Z := 2 * G₀ / s + 2 * U / B + 4 / ((V : ℝ) + 1) + G₀ / U + s / B with hZ
    have hZ0 : 0 ≤ Z := by positivity
    have eA : Real.sqrt (Real.log B ^ 2 * N₂ * ((B : ℝ) ^ 2 * Z)) =
        Real.log B * Real.sqrt N₂ * (B * Real.sqrt Z) := by
      rw [show Real.log B ^ 2 * N₂ * ((B : ℝ) ^ 2 * Z) = (Real.log B * B) ^ 2 * (N₂ * Z) by ring,
        Real.sqrt_mul (sq_nonneg _), Real.sqrt_sq (by positivity), Real.sqrt_mul hN₂0]
      ring
    rw [e1, e2, hWeq, eA]
    have hsq : Real.sqrt (2 * G₀ / s + 2 * U / B + 4 / ((V : ℝ) + 1) + G₀ / U + s / B) ≤
        Real.sqrt (2 * U / B + 4 / ((V : ℝ) + 1) + s / B) + Real.sqrt G₀ * (Real.sqrt (2 / s) + 1 / Real.sqrt U) := by
      refine (sqrt_add5_le _ _ _ _ _ (by positivity) (by positivity) (by positivity) (by positivity)
        (by positivity)).trans (le_of_eq ?_)
      have q1 : Real.sqrt (2 * G₀ / s) = Real.sqrt G₀ * Real.sqrt (2 / s) := by
        rw [← Real.sqrt_mul hG0]; congr 1; ring
      have q2 : Real.sqrt (G₀ / U) = Real.sqrt G₀ * (1 / Real.sqrt U) := by
        rw [Real.sqrt_div' _ (by positivity : (0 : ℝ) ≤ U)]; ring
      rw [q1, q2]; ring
    have hS0 : 0 ≤ Real.sqrt Z := Real.sqrt_nonneg _
    calc Real.sqrt 2 * Lb ^ 2 * (Real.log B * Real.sqrt N₂ * (B * Real.sqrt Z))
        ≤ Real.sqrt 2 * Lb ^ 2 * (Lb * Real.sqrt N₂ * (B *
          (Real.sqrt (2 * U / B + 4 / ((V : ℝ) + 1) + s / B) +
            Real.sqrt G₀ * (Real.sqrt (2 / s) + 1 / Real.sqrt U)))) := by
          gcongr
      _ = _ := by ring
  -- second summand
  have h2 : Real.log B * Lb ^ 4 * (2 * B / T + 2 * B / U + 2 * ((U : ℝ) + 2 * B / ((V : ℝ) + 1))) ≤
      B * (Lb ^ 5 * (2 / T + 2 / U + 2 * U / B + 4 / ((V : ℝ) + 1))) := by
    have e : 2 * B / (T : ℝ) + 2 * B / U + 2 * ((U : ℝ) + 2 * B / ((V : ℝ) + 1)) =
        B * (2 / T + 2 / U + 2 * U / B + 4 / ((V : ℝ) + 1)) := by
      field_simp; ring
    rw [e]
    have h0 : 0 ≤ 2 / (T : ℝ) + 2 / U + 2 * U / B + 4 / ((V : ℝ) + 1) := by positivity
    calc Real.log B * Lb ^ 4 * (B * (2 / T + 2 / U + 2 * U / B + 4 / ((V : ℝ) + 1)))
        ≤ Lb * Lb ^ 4 * (B * (2 / T + 2 / U + 2 * U / B + 4 / ((V : ℝ) + 1))) := by gcongr
      _ = _ := by ring
  have e3 : Real.sqrt (2 * (1 + Real.log ((U : ℝ) + 2 * B)) ^ 4) = Real.sqrt (2 * Lb ^ 4) := rfl
  calc _ ≤ B * (Real.sqrt 2 * Lb ^ 3 * Real.sqrt N₂ *
        (Real.sqrt (2 * U / B + 4 / ((V : ℝ) + 1) + s / B) + Real.sqrt G₀ * (Real.sqrt (2 / s) + 1 / Real.sqrt U))) +
      B * (Lb ^ 5 * (2 / T + 2 / U + 2 * U / B + 4 / ((V : ℝ) + 1))) := add_le_add h1 h2
    _ = _ := by ring

section modes
variable {M : ℕ} [NeZero M]

/-- Mode sum for a per-mode bound of the form `α + β·√G₀(c_j)`. -/
theorem mode_sum_sqrt (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (Jm : ℕ) (A : ZMod M → ℕ → ℂ)
    (c : ℕ → ZMod s) (Ab : ℝ) (hAb : 0 ≤ Ab) (hA : ∀ ρ j, 1 ≤ j → ‖A ρ j‖ ≤ Ab / j)
    (hc : ∀ j, 1 ≤ j → P.filter (fun p => (ZMod.cast (c j) : ZMod p) = 0) = P.filter (fun p => p ∣ j))
    (f : ℕ → ℝ) (α β : ℝ) (hα : 0 ≤ α) (hβ : 0 ≤ β) (hf0 : ∀ j, 0 ≤ f j)
    (hf : ∀ j ∈ Icc 1 Jm, f j ≤ α + β *
      Real.sqrt (((∏ p ∈ P.filter (fun p => (ZMod.cast (c j) : ZMod p) = 0), p : ℕ) : ℝ))) :
    ∑ ρ : ZMod M, ∑ j ∈ Icc 1 Jm, ‖A ρ j‖ * f j ≤
      M * Ab * (1 + Real.log Jm) * (α + β * 2 ^ P.card) := by
  have hlJ : 0 ≤ 1 + Real.log Jm := GoldC.QuillonDivisorMoment.one_add_log_nonneg Jm
  have hinner : ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * f j ≤ (1 + Real.log Jm) * (α + β * 2 ^ P.card) := by
    calc ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * f j
        ≤ ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * (α + β *
            (((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 2))) := by
          refine sum_le_sum fun j hj => mul_le_mul_of_nonneg_left ?_ (by positivity)
          refine (hf j hj).trans (le_of_eq ?_)
          rw [hc j (mem_Icc.1 hj).1, Real.sqrt_eq_rpow]
      _ = α * ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) + β * ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) *
            (((∏ p ∈ P.filter (fun p => p ∣ j), p : ℕ) : ℝ) ^ ((1 : ℝ) / 2)) := by
          rw [mul_sum, mul_sum, ← sum_add_distrib]; exact sum_congr rfl fun j _ => by ring
      _ ≤ α * (1 + Real.log Jm) + β * ((1 + Real.log Jm) * 2 ^ P.card) := by
          gcongr
          · exact harm_Icc_le Jm
          · exact (GoldC.QuillonAsymp.gcd_mode_sum P hP Jm (1 / 2) (by norm_num) (by norm_num)).trans
              (mul_le_mul_of_nonneg_left (prod_one_add_rpow_le P hP _ (by norm_num)) hlJ)
      _ = _ := by ring
  calc ∑ ρ : ZMod M, ∑ j ∈ Icc 1 Jm, ‖A ρ j‖ * f j
      ≤ ∑ _ρ : ZMod M, Ab * ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * f j := by
        refine sum_le_sum fun ρ _ => ?_
        rw [mul_sum]
        refine sum_le_sum fun j hj => ?_
        calc ‖A ρ j‖ * f j ≤ Ab / j * f j := mul_le_mul_of_nonneg_right (hA ρ j (mem_Icc.1 hj).1) (hf0 j)
          _ = Ab * (1 / (j : ℝ) * f j) := by ring
    _ = M * (Ab * ∑ j ∈ Icc 1 Jm, (1 / (j : ℝ)) * f j) := by
        rw [sum_const, card_univ, ZMod.card, nsmul_eq_mul]
    _ ≤ M * (Ab * ((1 + Real.log Jm) * (α + β * 2 ^ P.card))) := by gcongr
    _ = _ := by ring

end modes

set_option maxHeartbeats 1000000 in
/-- The Parseval per-mode bound (one prime block `U = 2^kY ∈ [Y, b/X]`). -/
lemma P_mode_le (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p) (c : ZMod s)
    (X Y Tp a b k : ℕ) (hX : 1 ≤ X) (hY : 1 ≤ Y) (hTp : 1 ≤ Tp) (ha : 1 ≤ a) (hab : b ≤ 2 * a)
    (hb : 1 ≤ b) (hUY : Y ≤ 2 ^ k * Y) (hUb : 2 ^ k * Y ≤ b / X) (Aω : ℝ) (hAω : 0 ≤ Aω) :
    2 * Aω / a * TIIx P c (2 ^ k * Y) (X - 1) Tp b ≤
      4 * Aω * (Real.sqrt 2 * (1 + Real.log (3 * b)) ^ 3 * Real.sqrt ((Tp : ℝ) * (Nat.log 2 b + 1)) *
          Real.sqrt (6 / X + s / b) + (1 + Real.log (3 * b)) ^ 5 * (2 / Tp + 2 / Y + 6 / X)) +
        4 * Aω * (Real.sqrt 2 * (1 + Real.log (3 * b)) ^ 3 * Real.sqrt ((Tp : ℝ) * (Nat.log 2 b + 1)) *
          (Real.sqrt (2 / s) + 1 / Real.sqrt Y)) *
          Real.sqrt (((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) = 0), p : ℕ) : ℝ)) := by
  set U := 2 ^ k * Y with hU
  have hU1 : 1 ≤ U := le_trans hY hUY
  have h := TIIx_le P hP hsP c U (X - 1) Tp b hU1 hTp hb
  have hXR : (1 : ℝ) ≤ X := by exact_mod_cast hX
  have hV : (((X - 1 : ℕ) : ℝ) + 1) = X := by rw [Nat.cast_sub hX]; ring
  rw [hV] at h
  have haR : (1 : ℝ) ≤ a := by exact_mod_cast ha
  have hbR : (1 : ℝ) ≤ b := by exact_mod_cast hb
  have habR : (b : ℝ) ≤ 2 * a := by exact_mod_cast hab
  have hUR : (1 : ℝ) ≤ U := by exact_mod_cast hU1
  have hYR : (1 : ℝ) ≤ Y := by exact_mod_cast hY
  have hUYR : (Y : ℝ) ≤ U := by exact_mod_cast hUY
  have hUbX : (U : ℝ) * X ≤ b := by
    have : U * X ≤ b := (Nat.le_div_iff_mul_le (by omega)).1 hUb
    exact_mod_cast this
  have hUb' : (U : ℝ) ≤ b := by nlinarith
  have hsR : (0 : ℝ) < s := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne s)
  set Lb := 1 + Real.log (3 * (b : ℝ)) with hLb
  have hLu : 1 + Real.log ((U : ℝ) + 2 * b) ≤ Lb := by
    have : Real.log ((U : ℝ) + 2 * b) ≤ Real.log (3 * (b : ℝ)) := Real.log_le_log (by linarith) (by linarith)
    rw [hLb]; linarith
  have hLb0 : 0 ≤ Lb := by
    have := Real.log_nonneg (show (1 : ℝ) ≤ 3 * b by linarith); rw [hLb]; linarith
  have hLu0 : 0 ≤ 1 + Real.log ((U : ℝ) + 2 * b) := by
    have := Real.log_nonneg (show (1 : ℝ) ≤ (U : ℝ) + 2 * b by linarith); linarith
  set G₀ := ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) = 0), p : ℕ) : ℝ) with hG₀
  have hG0 : 0 ≤ G₀ := Nat.cast_nonneg _
  set N₂ := (Tp : ℝ) * (Nat.log 2 b + 1) with hN₂
  -- the inner brackets
  have hq1 : 2 * (U : ℝ) / b + 4 / (X : ℝ) + s / b ≤ 6 / X + s / b := by
    have : 2 * (U : ℝ) / b ≤ 2 / X := by
      rw [div_le_div_iff₀ (by linarith) (by linarith)]; nlinarith
    have e : (6 : ℝ) / X = 2 / X + 4 / X := by ring
    rw [e]; linarith
  have hq2 : 1 / Real.sqrt U ≤ 1 / Real.sqrt Y :=
    one_div_le_one_div_of_le (Real.sqrt_pos.2 (by linarith)) (Real.sqrt_le_sqrt hUYR)
  have hq3 : 2 / (Tp : ℝ) + 2 / U + 2 * U / b + 4 / (X : ℝ) ≤ 2 / Tp + 2 / Y + 6 / X := by
    have h1 : 2 / (U : ℝ) ≤ 2 / Y := div_le_div_of_nonneg_left (by norm_num) (by linarith) hUYR
    have h2 : 2 * (U : ℝ) / b ≤ 2 / X := by
      rw [div_le_div_iff₀ (by linarith) (by linarith)]; nlinarith
    have e : (6 : ℝ) / X = 2 / X + 4 / X := by ring
    rw [e]; linarith
  have hinner : Real.sqrt 2 * (1 + Real.log ((U : ℝ) + 2 * b)) ^ 3 * Real.sqrt N₂ *
        (Real.sqrt (2 * U / b + 4 / (X : ℝ) + s / b) + Real.sqrt G₀ * (Real.sqrt (2 / s) + 1 / Real.sqrt U)) +
      (1 + Real.log ((U : ℝ) + 2 * b)) ^ 5 * (2 / Tp + 2 / U + 2 * U / b + 4 / (X : ℝ)) ≤
      Real.sqrt 2 * Lb ^ 3 * Real.sqrt N₂ *
        (Real.sqrt (6 / X + s / b) + Real.sqrt G₀ * (Real.sqrt (2 / s) + 1 / Real.sqrt Y)) +
      Lb ^ 5 * (2 / Tp + 2 / Y + 6 / X) := by
    have hs1 := Real.sqrt_le_sqrt hq1
    have h0 : 0 ≤ Real.sqrt G₀ := Real.sqrt_nonneg _
    have hL3 : (1 + Real.log ((U : ℝ) + 2 * b)) ^ 3 ≤ Lb ^ 3 := pow_le_pow_left₀ hLu0 hLu 3
    have hL5 : (1 + Real.log ((U : ℝ) + 2 * b)) ^ 5 ≤ Lb ^ 5 := pow_le_pow_left₀ hLu0 hLu 5
    have hbr1 : Real.sqrt (2 * U / b + 4 / (X : ℝ) + s / b) + Real.sqrt G₀ * (Real.sqrt (2 / s) + 1 / Real.sqrt U) ≤
        Real.sqrt (6 / X + s / b) + Real.sqrt G₀ * (Real.sqrt (2 / s) + 1 / Real.sqrt Y) :=
      add_le_add hs1 (mul_le_mul_of_nonneg_left (add_le_add le_rfl hq2) h0)
    have hn1 : 0 ≤ Real.sqrt (2 * U / b + 4 / (X : ℝ) + s / b) + Real.sqrt G₀ * (Real.sqrt (2 / s) + 1 / Real.sqrt U) := by
      positivity
    have hq30 : 0 ≤ 2 / (Tp : ℝ) + 2 / U + 2 * U / b + 4 / (X : ℝ) := by positivity
    have hs2 : (0 : ℝ) ≤ Real.sqrt 2 := Real.sqrt_nonneg _
    have hsN : (0 : ℝ) ≤ Real.sqrt N₂ := Real.sqrt_nonneg _
    exact add_le_add
      (mul_le_mul (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hL3 hs2) hsN) hbr1 hn1
        (by positivity))
      (mul_le_mul hL5 hq3 hq30 (by positivity))
  have hb2a : 2 * Aω / a * b ≤ 4 * Aω := by
    have hba : (b : ℝ) / a ≤ 2 := by rw [div_le_iff₀ (by linarith)]; linarith
    calc 2 * Aω / a * b = 2 * Aω * ((b : ℝ) / a) := by ring
      _ ≤ 2 * Aω * 2 := mul_le_mul_of_nonneg_left hba (by positivity)
      _ = 4 * Aω := by ring
  calc 2 * Aω / a * TIIx P c U (X - 1) Tp b
      ≤ 2 * Aω / a * (b * (Real.sqrt 2 * (1 + Real.log ((U : ℝ) + 2 * b)) ^ 3 * Real.sqrt N₂ *
        (Real.sqrt (2 * U / b + 4 / (X : ℝ) + s / b) + Real.sqrt G₀ * (Real.sqrt (2 / s) + 1 / Real.sqrt U)) +
      (1 + Real.log ((U : ℝ) + 2 * b)) ^ 5 * (2 / Tp + 2 / U + 2 * U / b + 4 / (X : ℝ)))) :=
        mul_le_mul_of_nonneg_left h (by positivity)
    _ ≤ 2 * Aω / a * b * (Real.sqrt 2 * Lb ^ 3 * Real.sqrt N₂ *
        (Real.sqrt (6 / X + s / b) + Real.sqrt G₀ * (Real.sqrt (2 / s) + 1 / Real.sqrt Y)) +
      Lb ^ 5 * (2 / Tp + 2 / Y + 6 / X)) := by
        rw [mul_assoc (2 * Aω / a)]
        exact mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left hinner (by linarith)) (by positivity)
    _ ≤ 4 * Aω * (Real.sqrt 2 * Lb ^ 3 * Real.sqrt N₂ *
        (Real.sqrt (6 / X + s / b) + Real.sqrt G₀ * (Real.sqrt (2 / s) + 1 / Real.sqrt Y)) +
      Lb ^ 5 * (2 / Tp + 2 / Y + 6 / X)) := by
        apply mul_le_mul_of_nonneg_right hb2a
        have hL0 : 0 ≤ Lb := by
          have := Real.log_nonneg (show (1 : ℝ) ≤ 3 * b by linarith); linarith
        positivity
    _ = _ := by ring

lemma Kmax_le_sqrt (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (c : ZMod s) :
    GoldC.QuillonVWSum.Kmax P c ≤ (3 : ℝ) ^ ((P.card : ℝ) / 4) * (s : ℝ) ^ ((3 : ℝ) / 4) *
      Real.sqrt (((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) = 0), p : ℕ) : ℝ)) := by
  unfold GoldC.QuillonVWSum.Kmax
  set G := ∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) = 0), (p : ℝ) with hG
  have hG1 : 1 ≤ G := one_le_prod₀ fun p hp => by exact_mod_cast (hP p (filter_subset _ _ hp)).one_le
  rw [Nat.cast_prod, ← hG, Real.sqrt_eq_rpow]
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  exact Real.rpow_le_rpow_of_exponent_le hG1 (by norm_num)

set_option maxHeartbeats 1000000 in
/-- The VW per-mode bound. -/
lemma V_mode_le (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p) (c : ZMod s)
    (X Lw a b Uv Vv Tv Ec M : ℕ) (hX : 1 ≤ X) (hLw : 1 ≤ Lw / X) (hLa : Lw ≤ a) (hab : b ≤ 2 * a)
    (ha6 : 6 ≤ a / X) (hUv : 2 ≤ Uv) (hVv : 1 ≤ Vv) (hTv : 1 ≤ Tv) (hUvb : Uv ≤ b) (hM : 1 ≤ M) :
    GoldC.QuillonPrimeSum.wt (a / X + 1) * (GoldC.QuillonVWExplicit.VWB P c Uv Vv Tv M b +
        Real.log b * (Nat.sqrt b * Nat.log 2 b)) + 6 / (a / X : ℕ) + Ec * (2.5 / (a / X : ℕ)) ≤
      (4 * X * Real.log b * (Uv * Vv : ℕ) / b +
        2 * X * M * (Real.sqrt 2 * (1 + Real.log (3 * b)) ^ 3 * Real.sqrt ((Tv : ℝ) * (Nat.log 2 b + 1)) *
          Real.sqrt (2 * Uv / b + 4 / ((Vv : ℝ) + 1) + s / b) +
          (1 + Real.log (3 * b)) ^ 5 * (2 / Tv + 2 / Uv + 2 * Uv / b + 4 / ((Vv : ℝ) + 1))) +
        2 * X * Real.log b * Nat.log 2 b / Real.sqrt b + (6 + 2.5 * Ec) / (Lw / X : ℕ)) +
      (8 * X * Real.log b * (3 : ℝ) ^ ((P.card : ℝ) / 4) *
          ((s : ℝ) ^ ((3 : ℝ) / 4) / s * (1 + Real.log (Uv * Vv : ℕ)) / M +
            (s : ℝ) ^ ((3 : ℝ) / 4) * (Uv * Vv : ℕ) * (1 + Real.log s) / b) +
        2 * X * M * (Real.sqrt 2 * (1 + Real.log (3 * b)) ^ 3 * Real.sqrt ((Tv : ℝ) * (Nat.log 2 b + 1)) *
          (Real.sqrt (2 / s) + 1 / Real.sqrt Uv))) *
        Real.sqrt (((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) = 0), p : ℕ) : ℝ)) := by
  set G₀ := ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) = 0), p : ℕ) : ℝ) with hG₀
  have hG0 : 0 ≤ G₀ := Nat.cast_nonneg _
  have hsG : 0 ≤ Real.sqrt G₀ := Real.sqrt_nonneg _
  have hXR : (1 : ℝ) ≤ X := by exact_mod_cast hX
  have hsR : (0 : ℝ) < s := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne s)
  have hs1 : (1 : ℝ) ≤ s := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne s)
  have hMR : (1 : ℝ) ≤ M := by exact_mod_cast hM
  have hUvR : (2 : ℝ) ≤ Uv := by exact_mod_cast hUv
  have hVvR : (1 : ℝ) ≤ Vv := by exact_mod_cast hVv
  have haX : 6 ≤ a / X := ha6
  have ha1 : 1 ≤ a := by
    have := Nat.div_le_self a X; omega
  have hb1 : 2 ≤ b := le_trans hUv hUvb
  have hbR : (2 : ℝ) ≤ b := by exact_mod_cast hb1
  have haR : (1 : ℝ) ≤ a := by exact_mod_cast ha1
  have habR : (b : ℝ) ≤ 2 * a := by exact_mod_cast hab
  have hlogb : 0 ≤ Real.log b := Real.log_nonneg (by linarith)
  set Lb := 1 + Real.log (3 * (b : ℝ)) with hLb
  have hLb0 : 0 ≤ Lb := by
    have := Real.log_nonneg (show (1 : ℝ) ≤ 3 * b by linarith); rw [hLb]; linarith
  -- wt ≤ 2X/b
  have hwt : GoldC.QuillonPrimeSum.wt (a / X + 1) ≤ 2 * X / b := by
    unfold GoldC.QuillonPrimeSum.wt
    have hn : 2 ≤ a / X + 1 := by omega
    rw [max_eq_left hn]
    set n := a / X + 1 with hndef
    have hnR : (7 : ℝ) ≤ n := by exact_mod_cast (show 7 ≤ n by omega)
    have hlog1 : 1 ≤ Real.log n := by
      rw [← Real.log_exp 1]; apply Real.log_le_log (Real.exp_pos 1)
      have := Real.exp_one_lt_d9; linarith
    have hnX : (a : ℝ) / X ≤ n := by
      have h1 : a < (a / X + 1) * X := by
        have := Nat.lt_div_mul_add (a := a) (show 0 < X by omega)
        rw [add_mul, one_mul]; exact this
      have h2 : (a : ℝ) < (n : ℝ) * X := by exact_mod_cast h1
      rw [div_le_iff₀ (by linarith)]; linarith
    calc 1 / ((n : ℝ) * Real.log n) ≤ 1 / (n : ℝ) := by
          apply one_div_le_one_div_of_le (by linarith); nlinarith
      _ ≤ 1 / ((a : ℝ) / X) := one_div_le_one_div_of_le (by positivity) hnX
      _ = X / a := by field_simp
      _ ≤ 2 * X / b := by rw [div_le_div_iff₀ (by linarith) (by linarith)]; nlinarith
  -- VWB ≤ 2 log b (W2 + 2K(...)) + M·TIIx
  set W2 : ℕ := Uv * Vv with hW2
  have hW2R : (Uv : ℝ) ≤ W2 := by
    have : Uv ≤ W2 := Nat.le_mul_of_pos_right _ (by omega)
    exact_mod_cast this
  have hK := GoldC.QuillonVWSum.Kmax_nonneg P c
  have hKle := Kmax_le_sqrt P hP c
  have hlUv : Real.log Uv ≤ Real.log W2 := Real.log_le_log (by linarith) hW2R
  have hlUv0 : 0 ≤ Real.log Uv := Real.log_nonneg (by linarith)
  have hls : 0 ≤ Real.log s := Real.log_nonneg hs1
  have hTx := TIIx_le P hP hsP c Uv Vv Tv b (by omega) hTv (by omega)
  set K := GoldC.QuillonVWSum.Kmax P c with hKdef
  have hVWB : GoldC.QuillonVWExplicit.VWB P c Uv Vv Tv M b ≤
      2 * Real.log b * ((W2 : ℝ) + 2 * K * (b * (1 + Real.log W2) / (M * s) + W2 * (1 + Real.log s))) +
      M * TIIx P c Uv Vv Tv b := by
    unfold GoldC.QuillonVWExplicit.VWB
    have hMs : (0 : ℝ) < M * s := by positivity
    have h1 : Real.log b * (Uv + 2 * K * (b * (1 + Real.log Uv) / (M * s) + Uv * (1 + Real.log s))) ≤
        Real.log b * ((W2 : ℝ) + 2 * K * (b * (1 + Real.log W2) / (M * s) + W2 * (1 + Real.log s))) := by
      gcongr
    rw [← hW2] at *
    linarith
  -- TIIx with `Lv ≤ Lb`
  set N₂ := (Tv : ℝ) * (Nat.log 2 b + 1) with hN₂
  set q := 2 * (Uv : ℝ) / b + 4 / ((Vv : ℝ) + 1) + s / b with hq
  set R := 2 / (Tv : ℝ) + 2 / Uv + 2 * Uv / b + 4 / ((Vv : ℝ) + 1) with hR
  have hLv : 1 + Real.log ((Uv : ℝ) + 2 * b) ≤ Lb := by
    have : Real.log ((Uv : ℝ) + 2 * b) ≤ Real.log (3 * (b : ℝ)) := by
      apply Real.log_le_log (by linarith)
      have : (Uv : ℝ) ≤ b := by exact_mod_cast hUvb
      linarith
    rw [hLb]; linarith
  have hLv0 : 0 ≤ 1 + Real.log ((Uv : ℝ) + 2 * b) := by
    have := Real.log_nonneg (show (1 : ℝ) ≤ (Uv : ℝ) + 2 * b by linarith); linarith
  have hTx' : TIIx P c Uv Vv Tv b ≤ b * (Real.sqrt 2 * Lb ^ 3 * Real.sqrt N₂ *
      (Real.sqrt q + Real.sqrt G₀ * (Real.sqrt (2 / s) + 1 / Real.sqrt Uv)) + Lb ^ 5 * R) := by
    refine hTx.trans ?_
    have hq0 : 0 ≤ Real.sqrt q + Real.sqrt G₀ * (Real.sqrt (2 / s) + 1 / Real.sqrt Uv) := by positivity
    have hR0 : 0 ≤ R := by positivity
    apply mul_le_mul_of_nonneg_left _ (by linarith)
    exact add_le_add (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left
      (pow_le_pow_left₀ hLv0 hLv 3) (Real.sqrt_nonneg 2)) (Real.sqrt_nonneg _)) hq0)
      (mul_le_mul_of_nonneg_right (pow_le_pow_left₀ hLv0 hLv 5) hR0)
  -- the correction term
  have hsqb : (Nat.sqrt b : ℝ) ≤ Real.sqrt b := by
    rw [Real.le_sqrt (Nat.cast_nonneg _) (Nat.cast_nonneg _)]
    exact_mod_cast Nat.sqrt_le' b
  have hcorr : 2 * X / b * (Real.log b * (Nat.sqrt b * Nat.log 2 b)) ≤ 2 * X * Real.log b * Nat.log 2 b / Real.sqrt b := by
    have hsb : 0 < Real.sqrt b := Real.sqrt_pos.2 (by linarith)
    have e : (b : ℝ) = Real.sqrt b * Real.sqrt b := (Real.mul_self_sqrt (by linarith)).symm
    calc 2 * X / b * (Real.log b * (Nat.sqrt b * Nat.log 2 b))
        ≤ 2 * X / b * (Real.log b * (Real.sqrt b * Nat.log 2 b)) := by gcongr
      _ = 2 * X * Real.log b * Nat.log 2 b * (Real.sqrt b / b) := by ring
      _ = 2 * X * Real.log b * Nat.log 2 b / Real.sqrt b := by
          rw [Real.sqrt_div_self']; ring
  have hlast : 6 / ((a / X : ℕ) : ℝ) + Ec * (2.5 / ((a / X : ℕ) : ℝ)) ≤ (6 + 2.5 * Ec) / ((Lw / X : ℕ) : ℝ) := by
    have h1 : ((Lw / X : ℕ) : ℝ) ≤ ((a / X : ℕ) : ℝ) := by exact_mod_cast Nat.div_le_div_right hLa
    have h2 : (1 : ℝ) ≤ ((Lw / X : ℕ) : ℝ) := by exact_mod_cast hLw
    have : 6 / ((a / X : ℕ) : ℝ) + Ec * (2.5 / ((a / X : ℕ) : ℝ)) = (6 + 2.5 * Ec) / ((a / X : ℕ) : ℝ) := by ring
    rw [this]
    exact div_le_div_of_nonneg_left (by positivity) (by linarith) h1
  have hMs : (0 : ℝ) < M * s := by positivity
  have hVWB0 := GoldC.QuillonVWExplicit.VWB_nonneg P hP c Uv Vv Tv M b (by omega) hTv
  have hcorr0 : 0 ≤ Real.log b * (Nat.sqrt b * Nat.log 2 b) := by positivity
  have hstep1 : GoldC.QuillonPrimeSum.wt (a / X + 1) * (GoldC.QuillonVWExplicit.VWB P c Uv Vv Tv M b +
      Real.log b * (Nat.sqrt b * Nat.log 2 b)) ≤
      2 * X / b * (2 * Real.log b * ((W2 : ℝ) + 2 * K * (b * (1 + Real.log W2) / (M * s) + W2 * (1 + Real.log s))) +
        M * (b * (Real.sqrt 2 * Lb ^ 3 * Real.sqrt N₂ *
          (Real.sqrt q + Real.sqrt G₀ * (Real.sqrt (2 / s) + 1 / Real.sqrt Uv)) + Lb ^ 5 * R))) +
      2 * X * Real.log b * Nat.log 2 b / Real.sqrt b := by
    calc GoldC.QuillonPrimeSum.wt (a / X + 1) * (GoldC.QuillonVWExplicit.VWB P c Uv Vv Tv M b +
          Real.log b * (Nat.sqrt b * Nat.log 2 b))
        ≤ 2 * X / b * (GoldC.QuillonVWExplicit.VWB P c Uv Vv Tv M b + Real.log b * (Nat.sqrt b * Nat.log 2 b)) :=
          mul_le_mul_of_nonneg_right hwt (by positivity)
      _ = 2 * X / b * GoldC.QuillonVWExplicit.VWB P c Uv Vv Tv M b +
          2 * X / b * (Real.log b * (Nat.sqrt b * Nat.log 2 b)) := by ring
      _ ≤ _ := by
          apply add_le_add _ hcorr
          apply mul_le_mul_of_nonneg_left _ (by positivity)
          refine hVWB.trans (add_le_add le_rfl ?_)
          exact mul_le_mul_of_nonneg_left hTx' (by positivity)
  have hKs : K * ((1 + Real.log W2) / (M * s) * b + W2 * (1 + Real.log s)) ≤
      (3 : ℝ) ^ ((P.card : ℝ) / 4) * (s : ℝ) ^ ((3 : ℝ) / 4) * Real.sqrt G₀ *
        ((1 + Real.log W2) / (M * s) * b + W2 * (1 + Real.log s)) := by
    have hlW : 0 ≤ 1 + Real.log W2 := GoldC.QuillonDivisorMoment.one_add_log_nonneg W2
    apply mul_le_mul_of_nonneg_right hKle (by positivity)
  have hbpos : (0 : ℝ) < b := by linarith
  calc _ ≤ 2 * X / b * (2 * Real.log b * ((W2 : ℝ) + 2 * K * (b * (1 + Real.log W2) / (M * s) + W2 * (1 + Real.log s))) +
        M * (b * (Real.sqrt 2 * Lb ^ 3 * Real.sqrt N₂ *
          (Real.sqrt q + Real.sqrt G₀ * (Real.sqrt (2 / s) + 1 / Real.sqrt Uv)) + Lb ^ 5 * R))) +
      2 * X * Real.log b * Nat.log 2 b / Real.sqrt b + (6 + 2.5 * Ec) / ((Lw / X : ℕ) : ℝ) := by
        have := add_le_add hstep1 hlast
        linarith
    _ = 4 * X * Real.log b * W2 / b + 8 * X * Real.log b / b *
          (K * ((1 + Real.log W2) / (M * s) * b + W2 * (1 + Real.log s))) +
        2 * X * M * (Real.sqrt 2 * Lb ^ 3 * Real.sqrt N₂ *
          (Real.sqrt q + Real.sqrt G₀ * (Real.sqrt (2 / s) + 1 / Real.sqrt Uv)) + Lb ^ 5 * R) +
        2 * X * Real.log b * Nat.log 2 b / Real.sqrt b + (6 + 2.5 * Ec) / ((Lw / X : ℕ) : ℝ) := by
        field_simp; ring
    _ ≤ 4 * X * Real.log b * W2 / b + 8 * X * Real.log b / b *
          ((3 : ℝ) ^ ((P.card : ℝ) / 4) * (s : ℝ) ^ ((3 : ℝ) / 4) * Real.sqrt G₀ *
            ((1 + Real.log W2) / (M * s) * b + W2 * (1 + Real.log s))) +
        2 * X * M * (Real.sqrt 2 * Lb ^ 3 * Real.sqrt N₂ *
          (Real.sqrt q + Real.sqrt G₀ * (Real.sqrt (2 / s) + 1 / Real.sqrt Uv)) + Lb ^ 5 * R) +
        2 * X * Real.log b * Nat.log 2 b / Real.sqrt b + (6 + 2.5 * Ec) / ((Lw / X : ℕ) : ℝ) := by
        gcongr
    _ = _ := by
        rw [hW2]; push_cast
        field_simp
        ring

/-! ## The full region-C term -/

lemma TIIx_nonneg (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (c : ZMod s) (U V T B : ℕ) :
    0 ≤ TIIx P c U V T B := by
  unfold TIIx
  have h1 := Real.log_natCast_nonneg B
  have h2 : 0 ≤ Real.log ((U : ℝ) + 2 * B) := by
    have := Real.log_natCast_nonneg (U + 2 * B); push_cast at this; exact this
  have hg : (0 : ℝ) ≤ ((∏ p ∈ P.filter (fun p => (ZMod.cast c : ZMod p) ≠ 0), p : ℕ) : ℝ) := Nat.cast_nonneg _
  positivity

noncomputable def Pα (s X Y Tp b : ℕ) (Aω : ℝ) : ℝ :=
  4 * Aω * (Real.sqrt 2 * (1 + Real.log (3 * b)) ^ 3 * Real.sqrt ((Tp : ℝ) * (Nat.log 2 b + 1)) *
    Real.sqrt (6 / X + s / b) + (1 + Real.log (3 * b)) ^ 5 * (2 / Tp + 2 / Y + 6 / X))

noncomputable def Pβ (s Y Tp b : ℕ) (Aω : ℝ) : ℝ :=
  4 * Aω * (Real.sqrt 2 * (1 + Real.log (3 * b)) ^ 3 * Real.sqrt ((Tp : ℝ) * (Nat.log 2 b + 1)) *
    (Real.sqrt (2 / s) + 1 / Real.sqrt Y))

noncomputable def Vα (s X Lw b Uv Vv Tv Ec M : ℕ) : ℝ :=
  4 * X * Real.log b * (Uv * Vv : ℕ) / b +
    2 * X * M * (Real.sqrt 2 * (1 + Real.log (3 * b)) ^ 3 * Real.sqrt ((Tv : ℝ) * (Nat.log 2 b + 1)) *
      Real.sqrt (2 * Uv / b + 4 / ((Vv : ℝ) + 1) + s / b) +
      (1 + Real.log (3 * b)) ^ 5 * (2 / Tv + 2 / Uv + 2 * Uv / b + 4 / ((Vv : ℝ) + 1))) +
    2 * X * Real.log b * Nat.log 2 b / Real.sqrt b + (6 + 2.5 * Ec) / (Lw / X : ℕ)

noncomputable def Vβ (s X b Uv Vv Tv M n : ℕ) : ℝ :=
  8 * X * Real.log b * (3 : ℝ) ^ ((n : ℝ) / 4) *
      ((s : ℝ) ^ ((3 : ℝ) / 4) / s * (1 + Real.log (Uv * Vv : ℕ)) / M +
        (s : ℝ) ^ ((3 : ℝ) / 4) * (Uv * Vv : ℕ) * (1 + Real.log s) / b) +
    2 * X * M * (Real.sqrt 2 * (1 + Real.log (3 * b)) ^ 3 * Real.sqrt ((Tv : ℝ) * (Nat.log 2 b + 1)) *
      (Real.sqrt (2 / s) + 1 / Real.sqrt Uv))

section full
variable {M : ℕ} [NeZero M]

/-- **The region-C term in closed form** (one row type, one dyadic piece). -/
theorem CTerm_le (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p) (Jm : ℕ)
    (A : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s) (Ab : ℝ) (hAb : 0 ≤ Ab)
    (hA : ∀ ρ j, 1 ≤ j → ‖A ρ j‖ ≤ Ab / j)
    (hc : ∀ j, 1 ≤ j → P.filter (fun p => (ZMod.cast (c j) : ZMod p) = 0) = P.filter (fun p => p ∣ j))
    (U' JP : Finset ℕ) (hU' : ∀ p ∈ U', 5 ≤ p) (X Y Tp Uv Vv Tv Ec Lw a b : ℕ)
    (hX : 1 ≤ X) (hY : 1 ≤ Y) (hTp : 1 ≤ Tp) (hLw : 1 ≤ Lw / X) (hLa : Lw ≤ a) (hab : b ≤ 2 * a)
    (hab' : a ≤ b) (ha6 : 6 ≤ a / X) (hUv : 2 ≤ Uv) (hVv : 1 ≤ Vv) (hTv : 1 ≤ Tv) (hUvb : Uv ≤ b)
    (hXYb : X * Y ≤ b) :
    GoldC.QuillonCCellApp.CTerm P (Icc 1 Jm) A c U' JP X Y Tp Uv Vv Tv Ec a b ≤
      ((Nat.log 2 (b / (X * Y)) + 1 : ℕ) : ℝ) * M * (M * Ab * (1 + Real.log Jm) *
        (Pα s X Y Tp b ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30) ^ 2) +
          Pβ s Y Tp b ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30) ^ 2) * 2 ^ P.card)) +
      (∑ B' ∈ (U'.filter (fun p => p < X)).powerset, GoldC.QuillonWContext.ωR B') *
        (M * Ab * (1 + Real.log Jm) * (Vα s X Lw b Uv Vv Tv Ec M + Vβ s X b Uv Vv Tv M P.card * 2 ^ P.card)) +
      M * Ab * (1 + Real.log Jm) * (∏ p ∈ U', (1 + 1 / ((p : ℝ) - 3))) * ((12.5 : ℝ) / Y) := by
  unfold GoldC.QuillonCCellApp.CTerm
  set Aω := (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30) ^ 2 with hAω
  have hAω0 : 0 ≤ Aω := by positivity
  have hM0 : (0 : ℝ) ≤ M := Nat.cast_nonneg _
  have hlJ : 0 ≤ 1 + Real.log Jm := GoldC.QuillonDivisorMoment.one_add_log_nonneg Jm
  have ha1 : 1 ≤ a := by have := Nat.div_le_self a X; omega
  have hb1 : 1 ≤ b := le_trans ha1 hab'
  have hXY1 : 1 ≤ b / (X * Y) := (Nat.one_le_div_iff (by positivity)).2 hXYb
  have hsR : (0 : ℝ) < s := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne s)
  -- Parseval
  have hbR1 : (1 : ℝ) ≤ b := by exact_mod_cast hb1
  have hL3b : 0 ≤ 1 + Real.log (3 * (b : ℝ)) := by
    have := Real.log_nonneg (show (1 : ℝ) ≤ 3 * b by linarith); linarith
  have hPα0 : 0 ≤ Pα s X Y Tp b Aω := by unfold Pα; positivity
  have hPβ0 : 0 ≤ Pβ s Y Tp b Aω := by unfold Pβ; positivity
  have hpart1 : ∀ k ∈ range (Nat.log 2 (b / (X * Y)) + 1),
      (M : ℝ) * ∑ ρ : ZMod M, ∑ j ∈ Icc 1 Jm, ‖A ρ j‖ * (2 * Aω / a * TIIx P (c j) (2 ^ k * Y) (X - 1) Tp b) ≤
      M * (M * Ab * (1 + Real.log Jm) * (Pα s X Y Tp b Aω + Pβ s Y Tp b Aω * 2 ^ P.card)) := by
    intro k hk
    have hk' : k ≤ Nat.log 2 (b / (X * Y)) := Nat.lt_succ_iff.1 (mem_range.1 hk)
    have h2k : 2 ^ k ≤ b / (X * Y) :=
      (Nat.pow_le_pow_right (by norm_num) hk').trans (Nat.pow_log_le_self 2 (by omega))
    have hUb : 2 ^ k * Y ≤ b / X := by
      calc 2 ^ k * Y ≤ b / (X * Y) * Y := Nat.mul_le_mul_right _ h2k
        _ = b / X / Y * Y := by rw [Nat.div_div_eq_div_mul]
        _ ≤ b / X := Nat.div_mul_le_self _ _
    have hUY : Y ≤ 2 ^ k * Y := Nat.le_mul_of_pos_left Y (by positivity)
    apply mul_le_mul_of_nonneg_left _ hM0
    refine mode_sum_sqrt P hP Jm A c Ab hAb hA hc _ _ _ hPα0 hPβ0 (fun j => by
      have := TIIx_nonneg P hP (c j) (2 ^ k * Y) (X - 1) Tp b
      positivity) (fun j _ => ?_)
    have := P_mode_le P hP hsP (c j) X Y Tp a b k hX hY hTp ha1 hab hb1 hUY hUb Aω hAω0
    unfold Pα Pβ
    linarith
  -- VW
  have hM1 : 1 ≤ M := Nat.pos_of_ne_zero (NeZero.ne M)
  have hVα0 : 0 ≤ Vα s X Lw b Uv Vv Tv Ec M := by
    unfold Vα
    have := Real.log_natCast_nonneg b
    positivity
  have hVβ0 : 0 ≤ Vβ s X b Uv Vv Tv M P.card := by
    unfold Vβ
    have := Real.log_natCast_nonneg b
    have := Real.log_natCast_nonneg s
    have := Real.log_natCast_nonneg (Uv * Vv)
    positivity
  have hpart2 : ∑ ρ : ZMod M, ∑ j ∈ Icc 1 Jm, ‖A ρ j‖ *
      (GoldC.QuillonPrimeSum.wt (a / X + 1) * (GoldC.QuillonVWExplicit.VWB P (c j) Uv Vv Tv M b +
        Real.log b * (Nat.sqrt b * Nat.log 2 b)) + 6 / (a / X : ℕ) + Ec * (2.5 / (a / X : ℕ))) ≤
      M * Ab * (1 + Real.log Jm) * (Vα s X Lw b Uv Vv Tv Ec M + Vβ s X b Uv Vv Tv M P.card * 2 ^ P.card) := by
    refine mode_sum_sqrt P hP Jm A c Ab hAb hA hc _ _ _ hVα0 hVβ0 (fun j => ?_) (fun j _ => ?_)
    · have := GoldC.QuillonPrimeSum.wt_nonneg (a / X + 1)
      have := GoldC.QuillonVWExplicit.VWB_nonneg P hP (c j) Uv Vv Tv M b (by omega) hTv
      have := Real.log_natCast_nonneg b
      positivity
    · have := V_mode_le P hP hsP (c j) X Lw a b Uv Vv Tv Ec M hX hLw hLa hab ha6 hUv hVv hTv hUvb hM1
      unfold Vα Vβ
      linarith
  have hpart3 : ∑ ρ : ZMod M, ∑ j ∈ Icc 1 Jm, ‖A ρ j‖ ≤ M * Ab * (1 + Real.log Jm) := by
    have := mode_sum_sqrt P hP Jm A c Ab hAb hA hc (fun _ => 1) 1 0 (by norm_num) le_rfl
      (fun _ => by norm_num) (fun j _ => by
        have := Real.sqrt_nonneg (((∏ p ∈ P.filter (fun p => (ZMod.cast (c j) : ZMod p) = 0), p : ℕ) : ℝ))
        simp)
    simpa using this
  have hSm0 : 0 ≤ ∑ B' ∈ (U'.filter (fun p => p < X)).powerset, GoldC.QuillonWContext.ωR B' :=
    sum_nonneg fun B hB => GoldC.QuillonWContext.ωR_nonneg B fun p hp =>
      hU' p (filter_subset _ _ ((mem_powerset.1 hB) hp))
  have hWU0 : 0 ≤ ∏ p ∈ U', (1 + 1 / ((p : ℝ) - 3)) := prod_nonneg fun p hp => by
    have : (5 : ℝ) ≤ p := by exact_mod_cast hU' p hp
    have : 0 ≤ 1 / ((p : ℝ) - 3) := by apply div_nonneg zero_le_one; linarith
    linarith
  have hfirst : ∑ k ∈ range (Nat.log 2 (b / (X * Y)) + 1), (M : ℝ) * ∑ ρ : ZMod M, ∑ j ∈ Icc 1 Jm,
      ‖A ρ j‖ * (2 * Aω / a * TIIx P (c j) (2 ^ k * Y) (X - 1) Tp b) ≤
      ((Nat.log 2 (b / (X * Y)) + 1 : ℕ) : ℝ) * M * (M * Ab * (1 + Real.log Jm) *
        (Pα s X Y Tp b Aω + Pβ s Y Tp b Aω * 2 ^ P.card)) := by
    refine (sum_le_sum hpart1).trans (le_of_eq ?_)
    rw [sum_const, card_range, nsmul_eq_mul]; ring
  have e1 : ∀ k : ℕ, ∑ ρ : ZMod M, ∑ j ∈ Icc 1 Jm, ‖A ρ j‖ *
      (2 * (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 b) : ℝ) ^ 30) ^ 2 / a *
        TIIx P (c j) (2 ^ k * Y) (X - 1) Tp b) =
      ∑ ρ : ZMod M, ∑ j ∈ Icc 1 Jm, ‖A ρ j‖ * (2 * Aω / a * TIIx P (c j) (2 ^ k * Y) (X - 1) Tp b) := fun k => rfl
  exact add_le_add (add_le_add hfirst (mul_le_mul_of_nonneg_left hpart2 hSm0))
    (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hpart3 hWU0) (by positivity))

end full

end GoldC.QuillonCEst

#print axioms GoldC.QuillonCEst.TIIx_le
#print axioms GoldC.QuillonCEst.mode_sum_sqrt
#print axioms GoldC.QuillonCEst.P_mode_le
#print axioms GoldC.QuillonCEst.V_mode_le
#print axioms GoldC.QuillonCEst.CTerm_le
