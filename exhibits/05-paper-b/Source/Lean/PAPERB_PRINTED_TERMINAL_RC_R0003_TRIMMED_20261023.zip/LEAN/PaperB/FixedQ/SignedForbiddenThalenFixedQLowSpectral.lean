import PaperB.FixedQ.SignedForbiddenThalenWeightedFiniteSource

open scoped BigOperators

namespace PaperB.FixedQ

/-- Consumer-facing finite source spectral identity with the literal
fixed-q row weight, not an arbitrary packet weight or admissible count.
This theorem does not remove the outer e-support cutoff. -/
theorem thalen_fixedQLowWeight_finite_source_eq_spectral
    (q a H : ℕ) (S : Finset ℕ)
    (h5 : ∀ p ∈ S, 5 ≤ p)
    (hH : ∀ p ∈ S, ¬ p ∣ H) :
    (∑ y ∈ Finset.Ioo 0 H,
       fixedQLowWeight q a H y * thalenFiniteProperSourcePacket S H y) -
      rowWeightMass (fixedQLowWeight q a H) H *
        thalenFiniteProperSourceDensity S =
    (∑ y ∈ Finset.Ioo 0 H,
       fixedQLowWeight q a H y *
        (thalenFiniteCenteredPacket S (thalenFiniteA S) y *
         thalenFiniteCenteredPacket S (thalenFiniteA S) (H-y))) -
      rowWeightMass (fixedQLowWeight q a H) H *
        ((thalenFiniteA S - 1) ^ 2 +
         (thalenFiniteA S) ^ 2 *
           ((∏ p ∈ S, (1 - thalenPrimeDelta p ^ 2)) - 1)) := by
  exact thalen_weighted_finite_proper_source_eq_spectral
    S H (fixedQLowWeight q a H) h5 hH

#print axioms thalen_fixedQLowWeight_finite_source_eq_spectral

end PaperB.FixedQ
