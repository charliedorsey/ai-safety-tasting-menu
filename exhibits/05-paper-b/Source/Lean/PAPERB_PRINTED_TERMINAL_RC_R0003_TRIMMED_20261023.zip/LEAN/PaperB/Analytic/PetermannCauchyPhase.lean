import PaperB.Analytic.ReciprocalFiniteOrderInterval

namespace PaperB.Analytic

open Real Finset
open scoped ComplexConjugate

lemma petermann_cauchy_phase_difference
    (A xi : ℝ) (q q1 n : ℕ)
    (hq : q ≠ 0) (hq1 : q1 ≠ 0) (hn : n ≠ 0) :
    eR (A / ((q : ℝ) * (n : ℝ)) + xi * (q : ℝ) * (n : ℝ)) *
        conj
          (eR (A / ((q1 : ℝ) * (n : ℝ)) +
            xi * (q1 : ℝ) * (n : ℝ))) =
      eR (
        (A * (((q : ℝ)⁻¹) - ((q1 : ℝ)⁻¹))) / (n : ℝ) +
          (xi * ((q : ℝ) - (q1 : ℝ))) * (n : ℝ)) := by
  rw [eR_mul_conj]
  congr 1
  field_simp [hq, hq1, hn]
  ring

lemma petermann_cauchy_reciprocal_numerator
    (A : ℝ) (q q1 : ℕ) (hq : q ≠ 0) (hq1 : q1 ≠ 0) :
    A * (((q : ℝ)⁻¹) - ((q1 : ℝ)⁻¹)) =
      A * (((q1 : ℝ) - (q : ℝ)) / ((q : ℝ) * (q1 : ℝ))) := by
  field_simp [hq, hq1]

lemma petermann_cauchy_linear_twist
    (xi : ℝ) (q q1 : ℕ) :
    xi * (q : ℝ) - xi * (q1 : ℝ) =
      xi * ((q : ℝ) - (q1 : ℝ)) := by
  ring

#print axioms petermann_cauchy_phase_difference
#print axioms petermann_cauchy_reciprocal_numerator

end PaperB.Analytic
