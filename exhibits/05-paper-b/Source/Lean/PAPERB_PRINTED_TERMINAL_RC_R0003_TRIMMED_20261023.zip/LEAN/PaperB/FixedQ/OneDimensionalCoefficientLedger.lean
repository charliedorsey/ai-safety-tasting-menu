import PaperB.FixedQ.OneDimensionalFamilyPartition
import PaperB.FixedQ.PetermannCorrectionMoment
import PaperB.FixedQ.PetermannMovingTransfer
import PaperB.FixedQ.EtaLinearMean
import PaperB.FixedQ.EtaCharacterBound
import PaperB.FixedQ.EtaReciprocalTail
import Mathlib.NumberTheory.Harmonic.Bounds

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def coefficientPartialSum
    (u : ℕ → ℝ) (X : ℕ) : ℝ :=
  ∑ n ∈ Finset.Icc 1 X, u n

noncomputable def characterCoefficientPartialSum
    {L : ℕ} (chi : DirichletCharacter ℂ L)
    (u : ℕ → ℝ) (X : ℕ) : ℂ :=
  ∑ n ∈ Finset.Icc 1 X, (chi n) * (u n : ℂ)

def PrincipalLogMeanSpec
    (u : ℕ → ℝ) (F C : ℝ) : Prop :=
  0 ≤ C ∧ ∀ X : ℕ, 1 ≤ X →
    |coefficientPartialSum u X - F * Real.log X| ≤ C

def CharacterBoundSpec
    (q : ℕ) (u : ℕ → ℝ) (C : ℝ) : Prop :=
  0 ≤ C ∧
  ∀ (chi : DirichletCharacter ℂ (Nat.lcm 6 q)),
    chi ≠ 1 →
    ∀ X : ℕ, 1 ≤ X →
      ‖characterCoefficientPartialSum chi u X‖ ≤ C

noncomputable def correctionTotalMass (q h : ℕ) : ℝ :=
  ∑' s : ℕ, petermannCorrectionArithmetic q h s

theorem coefficientPartialSum_moving_eq_correction
    (q h X : ℕ) :
    coefficientPartialSum (movingVCoeff q h) X =
      ∑ s ∈ Finset.Icc 1 X,
        petermannCorrectionArithmetic q h s *
          coefficientPartialSum (omegaCoeff q) (X / s) := by
  classical
  unfold coefficientPartialSum
  calc
    (∑ e ∈ Finset.Icc 1 X, movingVCoeff q h e)
      = ∑ e ∈ Finset.Icc 1 X, movingVArithmetic q h e := by
          apply Finset.sum_congr rfl
          intro e he
          rw [movingVArithmetic_apply]
    _ = ∑ e ∈ Finset.Icc 1 X,
          ∑ ds ∈ e.divisorsAntidiagonal,
            omegaArithmetic q ds.1 *
              petermannCorrectionArithmetic q h ds.2 := by
          apply Finset.sum_congr rfl
          intro e he
          rw [movingVArithmetic_eq_omega_mul_petermannCorrection,
            ArithmeticFunction.mul_apply]
    _ = ∑ x ∈ petermannDivisorSigma X,
          omegaArithmetic q x.2.1 *
            petermannCorrectionArithmetic q h x.2.2 := by
          rw [petermannDivisorSigma, Finset.sum_sigma']
    _ = ∑ s ∈ Finset.Icc 1 X,
          ∑ d ∈ Finset.Icc 1 (X / s),
            omegaArithmetic q d *
              petermannCorrectionArithmetic q h s := by
          exact sum_petermannDivisorSigma_eq_nested X
            (fun s d =>
              omegaArithmetic q d *
                petermannCorrectionArithmetic q h s)
    _ = ∑ s ∈ Finset.Icc 1 X,
        petermannCorrectionArithmetic q h s *
          coefficientPartialSum (omegaCoeff q) (X / s) := by
          apply Finset.sum_congr rfl
          intro s hs
          calc
            (∑ d ∈ Finset.Icc 1 (X / s),
                omegaArithmetic q d *
                  petermannCorrectionArithmetic q h s)
              = ∑ d ∈ Finset.Icc 1 (X / s),
                  petermannCorrectionArithmetic q h s *
                    omegaArithmetic q d := by
                    apply Finset.sum_congr rfl
                    intro d hd
                    ring
            _ = petermannCorrectionArithmetic q h s *
                  (∑ d ∈ Finset.Icc 1 (X / s),
                    omegaArithmetic q d) := by
                    rw [Finset.mul_sum]
            _ = petermannCorrectionArithmetic q h s *
                  coefficientPartialSum (omegaCoeff q) (X / s) := by
                    unfold coefficientPartialSum
                    congr 1

theorem characterCoefficientPartialSum_moving_eq_correction
    (q h X : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q)) :
    characterCoefficientPartialSum chi (movingVCoeff q h) X =
      ∑ s ∈ Finset.Icc 1 X,
        (chi s) * (petermannCorrectionArithmetic q h s : ℂ) *
          characterCoefficientPartialSum chi (omegaCoeff q) (X / s) := by
  classical
  unfold characterCoefficientPartialSum
  calc
    (∑ e ∈ Finset.Icc 1 X,
      (chi e) * (movingVCoeff q h e : ℂ))
      = ∑ e ∈ Finset.Icc 1 X,
          (chi e) * ((movingVArithmetic q h e : ℝ) : ℂ) := by
          apply Finset.sum_congr rfl
          intro e he
          rw [movingVArithmetic_apply]
    _ = ∑ e ∈ Finset.Icc 1 X,
          ∑ ds ∈ e.divisorsAntidiagonal,
            (chi e) *
              (((omegaArithmetic q ds.1 : ℝ) *
                petermannCorrectionArithmetic q h ds.2 : ℝ) : ℂ) := by
          apply Finset.sum_congr rfl
          intro e he
          rw [movingVArithmetic_eq_omega_mul_petermannCorrection,
            ArithmeticFunction.mul_apply]
          push_cast
          rw [Finset.mul_sum]
    _ = ∑ x ∈ petermannDivisorSigma X,
          (chi x.1) *
            (((omegaArithmetic q x.2.1 : ℝ) *
              petermannCorrectionArithmetic q h x.2.2 : ℝ) : ℂ) := by
          rw [petermannDivisorSigma, Finset.sum_sigma']
    _ = ∑ x ∈ petermannDivisorSigma X,
          (chi (x.2.2 * x.2.1)) *
            (((omegaArithmetic q x.2.1 : ℝ) *
              petermannCorrectionArithmetic q h x.2.2 : ℝ) : ℂ) := by
          apply Finset.sum_congr rfl
          intro x hx
          rw [petermannDivisorSigma, Finset.mem_sigma] at hx
          have hmul : x.2.1 * x.2.2 = x.1 :=
            (Nat.prodMk_mem_divisorsAntidiag
              (by
                rw [Finset.mem_Icc] at hx
                omega)).mp hx.2
          have hmul' : x.2.2 * x.2.1 = x.1 := by
            simpa [mul_comm] using hmul
          have hcast :
              (x.2.2 : ZMod (Nat.lcm 6 q)) *
                  (x.2.1 : ZMod (Nat.lcm 6 q)) =
                (x.1 : ZMod (Nat.lcm 6 q)) := by
            simpa [Nat.cast_mul] using
              congrArg (fun n : ℕ => (n : ZMod (Nat.lcm 6 q))) hmul'
          rw [hcast]
    _ = ∑ s ∈ Finset.Icc 1 X,
          ∑ d ∈ Finset.Icc 1 (X / s),
            (chi (s * d)) *
              (((omegaArithmetic q d : ℝ) *
                petermannCorrectionArithmetic q h s : ℝ) : ℂ) := by
          exact sum_petermannDivisorSigma_eq_nested X
            (fun s d =>
              (chi (s * d)) *
                (((omegaArithmetic q d : ℝ) *
                  petermannCorrectionArithmetic q h s : ℝ) : ℂ))
    _ = ∑ s ∈ Finset.Icc 1 X,
        (chi s) * (petermannCorrectionArithmetic q h s : ℂ) *
          characterCoefficientPartialSum chi (omegaCoeff q) (X / s) := by
          apply Finset.sum_congr rfl
          intro s hs
          unfold characterCoefficientPartialSum
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro d hd
          rw [map_mul, omegaArithmetic_apply]
          push_cast
          ring

#print axioms coefficientPartialSum_moving_eq_correction
#print axioms characterCoefficientPartialSum_moving_eq_correction

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem etaPrincipalLogMeanSpec
    (q : ℕ) (hq : 0 < q) :
    PrincipalLogMeanSpec
      (etaCoeff q)
      (logarithmicEulerResidue (etaCoeff q))
      ((2 * (6 * q) + 9) * etaRankinBound) := by
  constructor
  · have hR0 : 0 ≤ etaRankinBound := by
      unfold etaRankinBound
      positivity
    positivity
  · intro X hX
    unfold coefficientPartialSum
    simpa [etaPartialSum] using etaPrincipalLogMean_bound q X hq hX

#print axioms etaPrincipalLogMeanSpec

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem etaNonprincipalCharacterBoundSpec
    (q : ℕ) (hq : 0 < q) :
    CharacterBoundSpec q (etaCoeff q)
      (2 * ((Nat.lcm 6 q : ℕ) + 1) * etaRankinBound) := by
  constructor
  · have hR0 : 0 ≤ etaRankinBound := by
      unfold etaRankinBound
      positivity
    positivity
  · intro chi hchi X hX
    unfold characterCoefficientPartialSum
    simpa [etaCharacterPartialSum] using
      norm_etaCharacterPartialSum_le q X hq chi hchi

#print axioms etaNonprincipalCharacterBoundSpec

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem etaReciprocalTailLedger
    (q H : ℕ) (hH : 2 ≤ H) :
    |((H - 1 : ℕ) : ℝ) * etaReciprocalTail q (H - 1)| ≤
      4 * etaRankinBound :=
  etaReciprocalTail_manuscript q H hH

#print axioms etaReciprocalTailLedger

end PaperB.FixedQ
