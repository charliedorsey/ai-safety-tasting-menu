import GoldC.QuillonRBilinear
import GoldC.QuillonRamareSplit

/-!
# Quillon CSC3 F7.5n: the R route at the finset level (fixed `r`)

For a universe `U` of primes `≥ 5` (the primes available to `s`), and the Ramaré set
`J ⊆ U ∩ (X, 2^{Kv}X]` (the primes of `s` in `[X, r^ε]`):

    S_R = Σ_{C⊆U, C∩J≠∅} ω(C)·1[∏C ∈ (S₀,S₁], |C| ∈ K]·rowR(∏C).

* `ramare_split`, then reindex `B' ↦ u = ∏B'`, then `R_bilinear_full`;
* the subtracted terms (`p ∈ B'`) via `ramare_err_le` and `sum_inv_sub3_sq`.

**`R_context`**:

    ‖S_R‖ ≤ Ku·Kv·Σ_m ‖coef_m‖·Aω²·√(2·RPsi_m) + (Σ_m‖coef_m‖)·∏_U(1+1/(p−3))·12.5/X,

with `Aω = e^{37.5}(1+log₂log₂S₁)^{30}`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonRContext

open GoldC.QuillonR GoldC.QuillonCot GoldC.QuillonRBilinear GoldC.QuillonRamareSplit
  GoldC.QuillonWContext GoldC.QuillonOmega

theorem R_context (c C : ℝ) (hc : 0 < c) (hC : 0 ≤ C)
    (hcab : ∀ (Q ρ N M : ℕ) (Y : ℝ) (A : ℕ → ℂ), 1 ≤ Q → ρ < Q → 1 ≤ N → N ≤ M → M ≤ 2 * N →
        2 * (Q : ℝ) ≤ |Y| →
        ‖∑ t ∈ Ioc N M, A t * eR (Y / ((ρ : ℝ) + Q * t))‖ ≤
          (‖A M‖ + ∑ n ∈ Ico (N + 1) M, ‖A (n + 1) - A n‖) *
            (C * ((N : ℝ) * Real.exp (-(c * Real.log (N : ℝ) ^ 3 / Real.log (|Y| / Q) ^ 2)) +
              (N : ℝ) ^ 2 / (|Y| / Q))))
    (𝒦 : Finset ℕ) (coef : ℕ → ℂ) (jm Lm : ℕ → ℕ) (Ym : ℕ → ℝ) (Γ : ℕ → ℕ → ℂ)
    (hjm : ∀ m ∈ 𝒦, 1 ≤ jm m) (hLm : ∀ m ∈ 𝒦, 1 ≤ Lm m) (hΓ : ∀ m ∈ 𝒦, ∀ x, ‖Γ m x‖ ≤ 1)
    (Q : ℕ) (hQ : 1 ≤ Q)
    (U J : Finset ℕ) (hJU : J ⊆ U) (hU : ∀ p ∈ U, p.Prime ∧ 5 ≤ p)
    (X Kv S₀ S₁ : ℕ) (hX : 2 ≤ X) (hJ : ∀ p ∈ J, X < p ∧ p ≤ 2 ^ Kv * X)
    (hUlo : 4 * Q + 2 ≤ S₀ / (2 ^ Kv * X))
    (hY : ∀ m ∈ 𝒦, 8 * (Q : ℝ) * ((2 ^ Kv * X : ℕ) : ℝ) ^ 2 ≤ |Ym m|)
    (Kset : Finset ℕ) :
    ‖∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty), (ωR B : ℂ) *
        (if (∏ p ∈ B, p) ∈ Ioc S₀ S₁ ∧ B.card ∈ Kset then
          rowR 𝒦 coef jm Lm Ym Γ Q (∏ p ∈ B, p) else 0)‖ ≤
      ((((Nat.log 2 S₁ + 1) * 2) * Kv : ℕ) : ℝ) * ∑ m ∈ 𝒦, ‖coef m‖ *
        ((Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 S₁) : ℝ) ^ 30) ^ 2 *
          Real.sqrt (2 * RPsi c C Q X (S₀ / (2 ^ Kv * X)) S₁ (Ym m))) +
      (∑ m ∈ 𝒦, ‖coef m‖) * (∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3))) * ((12.5 : ℝ) / X) := by
  classical
  set Aω : ℝ := Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 S₁) : ℝ) ^ 30 with hAω
  set Atot : ℝ := ∑ m ∈ 𝒦, ‖coef m‖ with hAtot
  set Φ : ℕ → ℕ → ℂ := fun s k =>
    if s ∈ Ioc S₀ S₁ ∧ k ∈ Kset then rowR 𝒦 coef jm Lm Ym Γ Q s else 0 with hΦ
  have hΦle : ∀ s k, ‖Φ s k‖ ≤ Atot := by
    intro s k; simp only [hΦ]; split_ifs with h
    · exact norm_rowR_le 𝒦 coef jm Lm Ym Γ Q s hjm hLm hΓ (by have := (mem_Ioc.1 h.1).1; omega)
    · rw [norm_zero]; exact sum_nonneg fun _ _ => norm_nonneg _
  have hAω0 : 0 ≤ Aω := by positivity
  have hUp : ∀ p ∈ U, p.Prime := fun p hp => (hU p hp).1
  have hrewrite : ∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty), (ωR B : ℂ) *
      (if (∏ p ∈ B, p) ∈ Ioc S₀ S₁ ∧ B.card ∈ Kset then
        rowR 𝒦 coef jm Lm Ym Γ Q (∏ p ∈ B, p) else 0) =
      ∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty), (ωR B : ℂ) * Φ (∏ p ∈ B, p) B.card := rfl
  rw [hrewrite, ramare_split U J hJU Φ]
  refine (norm_sub_le _ _).trans (add_le_add ?_ ?_)
  · -- main bilinear term
    set α : ℕ → ℂ := fun p => ((1 / ((p : ℝ) - 3) : ℝ) : ℂ) with hα
    set β' : Finset ℕ → ℂ := fun B' => ((ωR B' / (1 + ((B' ∩ J).card : ℝ)) : ℝ) : ℂ) *
      (if B'.card + 1 ∈ Kset then (1 : ℂ) else 0) with hβ'
    set β : ℕ → ℂ := fun n => β' n.primeFactors with hβ
    set G : ℕ → ℂ := fun u => ∑ p ∈ J, α p *
      (if p * u ∈ Ioc S₀ S₁ then rowR 𝒦 coef jm Lm Ym Γ Q (p * u) else 0) with hG
    have e1 : ∑ p ∈ J, ∑ B' ∈ U.powerset, gR J Φ p B' =
        ∑ B' ∈ U.powerset, β' B' * G (∏ q ∈ B', q) := by
      rw [sum_comm]
      refine sum_congr rfl fun B' _ => ?_
      rw [hG, mul_sum]
      refine sum_congr rfl fun p _ => ?_
      simp only [gR, hΦ, hβ', hα]
      by_cases h1 : p * ∏ q ∈ B', q ∈ Ioc S₀ S₁ <;> by_cases h2 : B'.card + 1 ∈ Kset <;>
        simp [h1, h2] <;> ring
    have e2 : ∑ B' ∈ U.powerset, β' B' * G (∏ q ∈ B', q) =
        ∑ n ∈ U.powerset.image (fun B => ∏ q ∈ B, q), β n * G n := by
      rw [sum_image (prod_injOn U hUp)]
      refine sum_congr rfl fun B' hB' => ?_
      simp only [hβ]
      rw [Nat.primeFactors_prod fun q hq => hUp q (mem_powerset.1 hB' hq)]
    rw [e1, e2]
    have hW := R_bilinear_full c C hc hC hcab 𝒦 coef jm Lm Ym Γ hjm hLm hΓ Q hQ
      (U.powerset.image (fun B => ∏ q ∈ B, q)) J X Kv S₀ S₁ (by omega)
      (fun p hp => mem_Ioc.2 ⟨(hJ p hp).1, (hJ p hp).2⟩) hUlo hY α β Aω hAω0
      (fun p hp => by
        have h5 : (5 : ℝ) ≤ p := by exact_mod_cast (hU p (hJU hp)).2
        simp only [hα]
        rw [Complex.norm_real, Real.norm_eq_abs,
          abs_of_nonneg (by apply div_nonneg zero_le_one; linarith)]
        rw [div_le_div_iff₀ (by linarith) (by linarith)]
        have hA1 : (2.5 : ℝ) ≤ Aω := by
          have : (2.5 : ℝ) ≤ Real.exp 37.5 := by
            have := Real.add_one_le_exp (37.5 : ℝ); linarith
          have : (1 : ℝ) ≤ (1 + Nat.log 2 (Nat.log 2 S₁) : ℝ) ^ 30 :=
            one_le_pow₀ (by linarith [(Nat.cast_nonneg _ : (0 : ℝ) ≤ Nat.log 2 (Nat.log 2 S₁))])
          nlinarith [Real.exp_pos 37.5]
        nlinarith)
      (fun n hn hnS => by
        obtain ⟨B', hB', rfl⟩ := mem_image.1 hn
        have hB'U := mem_powerset.1 hB'
        simp only [hβ]
        rw [Nat.primeFactors_prod fun q hq => hUp q (hB'U hq)]
        simp only [hβ']
        have hω0 := ωR_nonneg B' fun q hq => (hU q (hB'U hq)).2
        have hωle := omega_pointwise B' (fun q hq => hU q (hB'U hq)) S₁ hnS
        rw [norm_mul]
        calc ‖((ωR B' / (1 + ((B' ∩ J).card : ℝ)) : ℝ) : ℂ)‖ *
              ‖(if B'.card + 1 ∈ Kset then (1 : ℂ) else 0)‖
            ≤ ωR B' * 1 := by
              apply mul_le_mul _ (by split_ifs <;> simp) (norm_nonneg _) hω0
              rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (by positivity)]
              exact div_le_self hω0 (by linarith [(Nat.cast_nonneg _ : (0 : ℝ) ≤ (B' ∩ J).card)])
          _ ≤ Aω / ((∏ q ∈ B', q : ℕ) : ℝ) := by
              rw [mul_one, Nat.cast_prod]; exact hωle)
    refine le_trans (le_of_eq ?_) (hW.trans (le_of_eq ?_))
    · rfl
    · rfl
  · -- the subtracted terms
    refine (ramare_err_le U J hJU hU Φ Atot hΦle).trans ?_
    have hAt0 : 0 ≤ Atot := sum_nonneg fun _ _ => norm_nonneg _
    have hWU0 : 0 ≤ ∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3)) := prod_nonneg fun p hp => by
      have : (5 : ℝ) ≤ p := by exact_mod_cast (hU p hp).2
      have : 0 ≤ 1 / ((p : ℝ) - 3) := by apply div_nonneg zero_le_one; linarith
      linarith
    apply mul_le_mul_of_nonneg_left _ (mul_nonneg hAt0 hWU0)
    exact sum_inv_sub3_sq J X hX fun p hp => ⟨(hJ p hp).1.le, (hU p (hJU hp)).2⟩

end GoldC.QuillonRContext

#print axioms GoldC.QuillonRContext.R_context
