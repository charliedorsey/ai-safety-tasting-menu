import PaperB.FixedQ.PeriodicFloorDecomposition
import PaperB.FixedQ.RowReduction

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def freeLocalFactorRatio (p y : ℕ) : ℝ :=
  (1 - (endpointOccupiedCount p y : ℝ) / (p : ℝ)) /
    (1 - 1 / (p : ℝ)) ^ 2

noncomputable def freeFixedQLowWeight
    (q r y : ℕ) : ℝ :=
  (if q.Coprime (r + y) then 1 else 0) *
    ∏ p ∈ lowPrimeSet,
      if p ∣ q then 1 else freeLocalFactorRatio p y

noncomputable def freeReducedFixedQLowWeight
    (q r : ℕ) (z : ℕ) : ℝ :=
  freeFixedQLowWeight q r (2 * z)

theorem freeLocalFactorRatio_two_even
    {y : ℕ} (hy : 2 ∣ y) :
    freeLocalFactorRatio 2 y = 2 := by
  have hymod : y % 2 = 0 := Nat.mod_eq_zero_of_dvd hy
  norm_num [freeLocalFactorRatio, endpointOccupiedCount, hymod]

theorem freeLocalFactorRatio_two_odd
    {y : ℕ} (hy : ¬ 2 ∣ y) :
    freeLocalFactorRatio 2 y = 0 := by
  have hymod : y % 2 = 1 := by
    have hlt := Nat.mod_lt y (by norm_num : 0 < 2)
    have hne : y % 2 ≠ 0 := Nat.dvd_iff_mod_eq_zero.not.mp hy
    omega
  norm_num [freeLocalFactorRatio, endpointOccupiedCount, hymod]

theorem sum_freeLocalFactorRatio_three :
    (∑ y ∈ Finset.range 3, freeLocalFactorRatio 3 y) = 3 := by
  norm_num [Finset.sum_range_succ, freeLocalFactorRatio,
    endpointOccupiedCount]

noncomputable def freeLowPrimeFactor (q y : ℕ) : ℝ :=
  ∏ p ∈ lowPrimeSet,
    if p ∣ q then 1 else freeLocalFactorRatio p y

theorem freeFixedQLowWeight_eq_indicator_mul_factor
    (q r y : ℕ) :
    freeFixedQLowWeight q r y =
      (if q.Coprime (r + y) then 1 else 0) *
        freeLowPrimeFactor q y := by
  rfl

theorem freeLocalFactorRatio_add_period
    {p y P : ℕ} (hpP : p ∣ P) :
    freeLocalFactorRatio p (y + P) =
      freeLocalFactorRatio p y := by
  unfold freeLocalFactorRatio
  have hmod : (y + P) % p = y % p := by
    rw [Nat.add_mod, Nat.mod_eq_zero_of_dvd hpP]
    simp
  unfold endpointOccupiedCount
  rw [hmod]

theorem freeLowPrimeFactor_periodic
    (q : ℕ) :
    Function.Periodic (freeLowPrimeFactor q)
      (lowActiveModulus q) := by
  intro y
  unfold freeLowPrimeFactor lowPrimeSet
  by_cases h2 : 2 ∣ q
  · by_cases h3 : 3 ∣ q
    · simp [lowActiveModulus, h2, h3]
    · norm_num [Finset.prod_insert]
      simp [lowActiveModulus, h2, h3,
        freeLocalFactorRatio_add_period (show 3 ∣ 3 by norm_num)]
  · by_cases h3 : 3 ∣ q
    · norm_num [Finset.prod_insert]
      simp [lowActiveModulus, h2, h3,
        freeLocalFactorRatio_add_period (show 2 ∣ 2 by norm_num)]
    · norm_num [Finset.prod_insert]
      simp [lowActiveModulus, h2, h3,
        freeLocalFactorRatio_add_period (show 2 ∣ 6 by norm_num),
        freeLocalFactorRatio_add_period (show 3 ∣ 6 by norm_num)]

theorem freeFixedQLowWeight_add_period
    (q r y : ℕ) :
    freeFixedQLowWeight q r (y + fixedQPeriod q) =
      freeFixedQLowWeight q r y := by
  unfold freeFixedQLowWeight
  have hcop := coprime_add_fixedQPeriod_iff (q := q) (a := r) (y := y)
  have h2P : 2 ∣ fixedQPeriod q :=
    (show 2 ∣ 6 by norm_num).trans (Nat.dvd_lcm_left 6 q)
  have h3P : 3 ∣ fixedQPeriod q :=
    (show 3 ∣ 6 by norm_num).trans (Nat.dvd_lcm_left 6 q)
  unfold lowPrimeSet
  norm_num [Finset.prod_insert]
  simp only [hcop]
  by_cases h2q : 2 ∣ q
  · simp [h2q]
    by_cases h3q : 3 ∣ q
    · simp [h3q]
    · simp [h3q, freeLocalFactorRatio_add_period h3P]
  · simp [h2q, freeLocalFactorRatio_add_period h2P]
    by_cases h3q : 3 ∣ q
    · simp [h3q]
    · simp [h3q, freeLocalFactorRatio_add_period h3P]

theorem freeFixedQLowWeight_periodic
    (q r : ℕ) :
    Function.Periodic (freeFixedQLowWeight q r)
      (fixedQPeriod q) :=
  freeFixedQLowWeight_add_period q r

theorem freeFixedQLowWeight_odd_zero
    {q r y : ℕ}
    (hr : q.Coprime r) (hyOdd : ¬ 2 ∣ y) :
    freeFixedQLowWeight q r y = 0 := by
  by_cases h2q : 2 ∣ q
  · have h2r : ¬ 2 ∣ r := by
      exact Nat.prime_two.coprime_iff_not_dvd.mp
        (Nat.Coprime.of_dvd_left h2q hr)
    have hrOdd : Odd r := Nat.not_even_iff_odd.mp
      (fun h => h2r h.two_dvd)
    have hyOdd' : Odd y := Nat.not_even_iff_odd.mp
      (fun h => hyOdd h.two_dvd)
    have h2sum : 2 ∣ r + y := (hrOdd.add_odd hyOdd').two_dvd
    have hnot : ¬ q.Coprime (r + y) := by
      intro hc
      exact (Nat.prime_two.coprime_iff_not_dvd.mp
        (Nat.Coprime.of_dvd_left h2q hc)) h2sum
    simp [freeFixedQLowWeight, hnot]
  · have hfree2 : freeLocalFactorRatio 2 y = 0 :=
      freeLocalFactorRatio_two_odd hyOdd
    unfold freeFixedQLowWeight lowPrimeSet
    norm_num [Finset.prod_insert]
    simp [h2q, hfree2]

theorem rowPrefixMass_freeReduced_eq_double_period
    (q r : ℕ) (hr : q.Coprime r) :
    rowPrefixMass (freeReducedFixedQLowWeight q r)
        (fixedQPeriod q) =
      rowPrefixMass (freeFixedQLowWeight q r)
        (2 * fixedQPeriod q) := by
  unfold rowPrefixMass freeReducedFixedQLowWeight
  rw [sum_range_mul_blocks (freeFixedQLowWeight q r) 2 (fixedQPeriod q)]
  symm
  apply Finset.sum_congr rfl
  intro k hk
  norm_num [Finset.sum_range_succ]
  have hodd : ¬ 2 ∣ 2 * k + 1 := by omega
  rw [freeFixedQLowWeight_odd_zero hr hodd]

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem sum_freeLowPrimeFactor (q : ℕ) :
    (∑ y ∈ Finset.range (lowActiveModulus q),
      freeLowPrimeFactor q y) = (lowActiveModulus q : ℝ) := by
  by_cases h2 : 2 ∣ q
  · by_cases h3 : 3 ∣ q
    · simp [lowActiveModulus, freeLowPrimeFactor, lowPrimeSet, h2, h3]
    · simp [lowActiveModulus, freeLowPrimeFactor, lowPrimeSet, h2, h3]
      norm_num [Finset.sum_range_succ, freeLocalFactorRatio,
        endpointOccupiedCount]
  · by_cases h3 : 3 ∣ q
    · simp [lowActiveModulus, freeLowPrimeFactor, lowPrimeSet, h2, h3]
      norm_num [Finset.sum_range_succ, freeLocalFactorRatio,
        endpointOccupiedCount]
    · simp [lowActiveModulus, freeLowPrimeFactor, lowPrimeSet, h2, h3]
      norm_num [Finset.sum_range_succ, freeLocalFactorRatio,
        endpointOccupiedCount]

theorem rowPrefixMass_freeFixedQLowWeight_period
    (q r : ℕ) (hq : 0 < q) :
    rowPrefixMass (freeFixedQLowWeight q r) (fixedQPeriod q) =
      (Nat.totient q : ℝ) / (q : ℝ) * (fixedQPeriod q : ℝ) := by
  unfold rowPrefixMass
  rw [fixedQPeriod_eq_lowActiveModulus_mul]
  rw [sum_range_mul_blocks]
  rw [Finset.sum_comm]
  have hMcop : (lowActiveModulus q).Coprime q :=
    lowActiveModulus_coprime q
  have hMper :
      Function.Periodic (freeLowPrimeFactor q)
        (lowActiveModulus q) :=
    freeLowPrimeFactor_periodic q
  calc
    (∑ r0 ∈ Finset.range (lowActiveModulus q),
      ∑ k ∈ Finset.range q,
        freeFixedQLowWeight q r
          (lowActiveModulus q * k + r0)) =
      ∑ r0 ∈ Finset.range (lowActiveModulus q),
        (Nat.totient q : ℝ) * freeLowPrimeFactor q r0 := by
          apply Finset.sum_congr rfl
          intro r0 hr0
          calc
            (∑ k ∈ Finset.range q,
              freeFixedQLowWeight q r
                (lowActiveModulus q * k + r0)) =
              ∑ k ∈ Finset.range q,
                (if q.Coprime
                    ((r + r0) + lowActiveModulus q * k)
                  then (1 : ℝ) else 0) *
                  freeLowPrimeFactor q r0 := by
                    apply Finset.sum_congr rfl
                    intro k hk
                    rw [freeFixedQLowWeight_eq_indicator_mul_factor]
                    have hper := (hMper.nsmul k) r0
                    have hfactor :
                        freeLowPrimeFactor q
                            (lowActiveModulus q * k + r0) =
                          freeLowPrimeFactor q r0 := by
                      simpa [nsmul_eq_mul, Nat.add_comm, Nat.mul_comm] using hper
                    rw [hfactor]
                    have hadd :
                        r + (lowActiveModulus q * k + r0) =
                          (r + r0) + lowActiveModulus q * k := by
                      ac_rfl
                    rw [hadd]
            _ = (∑ k ∈ Finset.range q,
                  if q.Coprime
                      ((r + r0) + lowActiveModulus q * k)
                    then (1 : ℝ) else 0) *
                freeLowPrimeFactor q r0 := by
                  rw [Finset.sum_mul]
            _ = (Nat.totient q : ℝ) *
                freeLowPrimeFactor q r0 := by
                  rw [sum_coprime_indicator_affine
                    q (r + r0) (lowActiveModulus q) hq hMcop]
    _ = (Nat.totient q : ℝ) *
        (∑ r0 ∈ Finset.range (lowActiveModulus q),
          freeLowPrimeFactor q r0) := by
          rw [Finset.mul_sum]
    _ = (Nat.totient q : ℝ) * (lowActiveModulus q : ℝ) := by
          rw [sum_freeLowPrimeFactor q]
    _ = (Nat.totient q : ℝ) / (q : ℝ) *
        (↑(lowActiveModulus q * q) : ℝ) := by
          have hqR : (q : ℝ) ≠ 0 := by
            exact_mod_cast (Nat.ne_of_gt hq)
          push_cast
          field_simp [hqR]

theorem rowPrefixMass_freeReduced_period
    (q r : ℕ) (hq : 0 < q) (hr : q.Coprime r) :
    rowPrefixMass (freeReducedFixedQLowWeight q r)
        (fixedQPeriod q) =
      fixedQRowMean q * (fixedQPeriod q : ℝ) := by
  rw [rowPrefixMass_freeReduced_eq_double_period q r hr]
  have hper := freeFixedQLowWeight_periodic q r
  rw [rowPrefixMass_mul_period
    (freeFixedQLowWeight q r)
    (fixedQPeriod q) 2 hper]
  rw [rowPrefixMass_freeFixedQLowWeight_period q r hq]
  unfold fixedQRowMean
  ring

#print axioms rowPrefixMass_freeReduced_period

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma periodicAlpha_zero_class
    (L : ℕ) [NeZero L]
    (u : (ZMod L)ˣ) :
    periodicAlpha L u L = L := by
  apply positiveRepresentative_eq_of_cast_eq (L := L)
  · exact periodicAlpha_mem_Icc L u L
  · exact Finset.mem_Icc.mpr ⟨NeZero.pos L, le_rfl⟩
  rw [periodicAlpha_cast_eq]
  simp

lemma periodicAlpha_neg_sum
    (L : ℕ) [NeZero L]
    (u : (ZMod L)ˣ) {c : ℕ}
    (hc1 : 1 ≤ c) (hcL : c < L) :
    periodicAlpha L u c + periodicAlpha L (-u) c = L := by
  let a := periodicAlpha L u c
  let b := periodicAlpha L (-u) c
  have ha := periodicAlpha_mem_Icc L u c
  have hb := periodicAlpha_mem_Icc L (-u) c
  have hc0 : (c : ZMod L) ≠ 0 := by
    intro hz
    have hd : L ∣ c := (ZMod.natCast_eq_zero_iff c L).mp hz
    have hLpos := NeZero.pos L
    have : L ≤ c := Nat.le_of_dvd (by omega) hd
    omega
  have ha0 : (a : ZMod L) ≠ 0 := by
    rw [periodicAlpha_cast_eq]
    intro hz
    have hm := congrArg (fun z : ZMod L => (u : ZMod L) * z) hz
    simp [mul_assoc] at hm
    exact hc0 hm
  have haL : a ≠ L := by
    intro h
    apply ha0
    rw [h]
    simp
  have halt : a < L := lt_of_le_of_ne (Finset.mem_Icc.mp ha).2 haL
  have hsubmem : L - a ∈ Finset.Icc 1 L := by
    apply Finset.mem_Icc.mpr
    constructor <;> omega
  have hcastneg :
      (b : ZMod L) = -(a : ZMod L) := by
    rw [show b = periodicAlpha L (-u) c by rfl]
    rw [periodicAlpha_cast_eq, periodicAlpha_cast_eq]
    simp [inv_neg, Units.val_neg, mul_comm]
  have hcastsub :
      ((L - a : ℕ) : ZMod L) = -(a : ZMod L) := by
    dsimp [a]
    rw [Nat.cast_sub (Finset.mem_Icc.mp ha).2]
    simp
  have hbsub : b = L - a := by
    apply positiveRepresentative_eq_of_cast_eq (L := L) hb hsubmem
    exact hcastneg.trans hcastsub.symm
  change a + b = L
  rw [hbsub]
  omega

noncomputable def principalBoundaryAverage
    (L : ℕ) [NeZero L]
    (w : ℕ → ℝ) : ℝ :=
  (1 / (L.totient : ℝ)) *
    ∑ u : (ZMod L)ˣ, manuscriptBoundaryTerm L w u

theorem manuscriptBoundaryTerm_add_neg
    (L : ℕ) [NeZero L]
    (w : ℕ → ℝ) (u : (ZMod L)ˣ) :
    manuscriptBoundaryTerm L w u +
      manuscriptBoundaryTerm L w (-u) = - w L := by
  unfold manuscriptBoundaryTerm
  rw [← Finset.sum_add_distrib]
  calc
    (∑ c ∈ Finset.Icc 1 L,
      (w c * (1 / 2 - (periodicAlpha L u c : ℝ) / L) +
       w c * (1 / 2 - (periodicAlpha L (-u) c : ℝ) / L)))
      = ∑ c ∈ Finset.Icc 1 L,
          if c = L then -w L else 0 := by
            apply Finset.sum_congr rfl
            intro c hc
            by_cases hcL : c = L
            · subst c
              rw [periodicAlpha_zero_class, periodicAlpha_zero_class]
              rw [if_pos rfl]
              have hL0 : (L : ℝ) ≠ 0 := by exact_mod_cast (NeZero.ne L)
              field_simp [hL0]
              ring
            · rw [if_neg hcL]
              have hcR := Finset.mem_Icc.mp hc
              have hlt : c < L := lt_of_le_of_ne hcR.2 hcL
              have hsum := periodicAlpha_neg_sum L u hcR.1 hlt
              have hL0 : (L : ℝ) ≠ 0 := by exact_mod_cast (NeZero.ne L)
              have hsumR :
                  (periodicAlpha L u c : ℝ) +
                    (periodicAlpha L (-u) c : ℝ) = L := by
                exact_mod_cast hsum
              have hcoef :
                  (1 / 2 - (periodicAlpha L u c : ℝ) / L) +
                    (1 / 2 - (periodicAlpha L (-u) c : ℝ) / L) = 0 := by
                field_simp [hL0]
                nlinarith
              calc
                w c * (1 / 2 - (periodicAlpha L u c : ℝ) / L) +
                    w c * (1 / 2 - (periodicAlpha L (-u) c : ℝ) / L)
                  = w c * ((1 / 2 - (periodicAlpha L u c : ℝ) / L) +
                      (1 / 2 - (periodicAlpha L (-u) c : ℝ) / L)) := by ring
                _ = 0 := by rw [hcoef]; ring
    _ = -w L := by
          rw [Finset.sum_eq_single L]
          · simp [NeZero.pos L]
          · intro c hc hne
            simp [hne]
          · intro hnot
            exfalso
            exact hnot (Finset.mem_Icc.mpr ⟨NeZero.pos L, le_rfl⟩)

theorem principalBoundaryAverage_eq_zero_residue
    (L : ℕ) [NeZero L]
    (w : ℕ → ℝ) :
    principalBoundaryAverage L w = - (1 / 2 : ℝ) * w L := by
  have hphi : (L.totient : ℝ) ≠ 0 := by
    exact_mod_cast (Nat.ne_of_gt (Nat.totient_pos.mpr (NeZero.pos L)))
  have hneg :
      (∑ u : (ZMod L)ˣ, manuscriptBoundaryTerm L w (-u)) =
        ∑ u : (ZMod L)ˣ, manuscriptBoundaryTerm L w u := by
    exact Fintype.sum_equiv (Equiv.neg ((ZMod L)ˣ))
      (fun u => manuscriptBoundaryTerm L w (-u))
      (fun u => manuscriptBoundaryTerm L w u)
      (fun u => rfl)
  have hpair :
      2 * (∑ u : (ZMod L)ˣ, manuscriptBoundaryTerm L w u) =
        - (L.totient : ℝ) * w L := by
    calc
      2 * (∑ u : (ZMod L)ˣ, manuscriptBoundaryTerm L w u)
        = (∑ u : (ZMod L)ˣ, manuscriptBoundaryTerm L w u) +
          (∑ u : (ZMod L)ˣ, manuscriptBoundaryTerm L w (-u)) := by
            rw [hneg]
            ring
      _ = ∑ u : (ZMod L)ˣ,
          (manuscriptBoundaryTerm L w u +
            manuscriptBoundaryTerm L w (-u)) := by
            rw [Finset.sum_add_distrib]
      _ = ∑ u : (ZMod L)ˣ, (-w L) := by
            apply Finset.sum_congr rfl
            intro u hu
            rw [manuscriptBoundaryTerm_add_neg]
      _ = - (L.totient : ℝ) * w L := by
            simp [ZMod.card_units_eq_totient]
  unfold principalBoundaryAverage
  field_simp [hphi]
  nlinarith [hpair]

#print axioms principalBoundaryAverage_eq_zero_residue

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem freeReducedFixedQLowWeight_periodic
    (q r : ℕ) :
    Function.Periodic (freeReducedFixedQLowWeight q r)
      (fixedQPeriod q) := by
  intro x
  unfold freeReducedFixedQLowWeight
  let f := freeFixedQLowWeight q r
  have hp := freeFixedQLowWeight_periodic q r
  calc
    f (2 * (x + fixedQPeriod q)) =
        f ((2 * x + fixedQPeriod q) + fixedQPeriod q) := by
          congr 1
          omega
    _ = f (2 * x + fixedQPeriod q) := hp (2 * x + fixedQPeriod q)
    _ = f (2 * x) := hp (2 * x)

theorem occupiedAnchoredLocalFactorRatio_zero_two
    (H : ℕ) :
    occupiedAnchoredLocalFactorRatio 2 (2 * H) 0 = 2 := by
  have h2 : 2 ∣ 2 * H := dvd_mul_right 2 H
  norm_num [occupiedAnchoredLocalFactorRatio,
    tripleOccupiedCount, endpointOccupiedCount,
    Nat.mod_eq_zero_of_dvd h2]

theorem occupiedAnchoredLocalFactorRatio_zero_three
    (h : ℕ) :
    occupiedAnchoredLocalFactorRatio 3 h 0 = 3 / 2 := by
  have hh : h % 3 = 0 ∨ h % 3 = 1 ∨ h % 3 = 2 := by omega
  rcases hh with hh | hh | hh <;>
    norm_num [occupiedAnchoredLocalFactorRatio,
      tripleOccupiedCount, endpointOccupiedCount, hh]

theorem freeLocalFactorRatio_zero_two :
    freeLocalFactorRatio 2 0 = 2 := by
  norm_num [freeLocalFactorRatio, endpointOccupiedCount]

theorem freeLocalFactorRatio_zero_three :
    freeLocalFactorRatio 3 0 = 3 / 2 := by
  norm_num [freeLocalFactorRatio, endpointOccupiedCount]

theorem anchored_free_reduced_zero
    (q r H : ℕ) (hr : q.Coprime r) :
    occupiedReducedFixedQLowWeight q r H 0 =
      freeReducedFixedQLowWeight q r 0 := by
  unfold occupiedReducedFixedQLowWeight freeReducedFixedQLowWeight
  unfold occupiedFixedQLowWeight freeFixedQLowWeight lowPrimeSet
  norm_num [Finset.prod_insert, hr,
    occupiedAnchoredLocalFactorRatio_zero_two,
    occupiedAnchoredLocalFactorRatio_zero_three,
    freeLocalFactorRatio_zero_two,
    freeLocalFactorRatio_zero_three]

theorem anchored_free_reduced_zero_residue
    (q r H : ℕ) (hr : q.Coprime r) :
    occupiedReducedFixedQLowWeight q r H (fixedQPeriod q) =
      freeReducedFixedQLowWeight q r (fixedQPeriod q) := by
  have ha := (occupiedReducedFixedQLowWeight_periodic q r H) 0
  have hf := (freeReducedFixedQLowWeight_periodic q r) 0
  rw [show 0 + fixedQPeriod q = fixedQPeriod q by omega] at ha hf
  rw [ha, hf]
  exact anchored_free_reduced_zero q r H hr

theorem principalBoundaryAverage_anchored_eq_free
    (q r H : ℕ) [NeZero (fixedQPeriod q)]
    (hr : q.Coprime r) :
    principalBoundaryAverage (fixedQPeriod q)
        (occupiedReducedFixedQLowWeight q r H) =
      principalBoundaryAverage (fixedQPeriod q)
        (freeReducedFixedQLowWeight q r) := by
  rw [principalBoundaryAverage_eq_zero_residue,
    principalBoundaryAverage_eq_zero_residue]
  rw [anchored_free_reduced_zero_residue q r H hr]

#print axioms principalBoundaryAverage_anchored_eq_free

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def logarithmicEulerResidueLocal
    (u : ℕ → ℝ) (p : ℕ) : ℝ :=
  if p.Prime then
    (1 - 1 / (p : ℝ)) * (1 + u p)
  else 1

noncomputable def logarithmicEulerResidue
    (u : ℕ → ℝ) : ℝ :=
  ∏' p : ℕ, logarithmicEulerResidueLocal u p

noncomputable def freeHighBaseline (q : ℕ) : ℝ :=
  cStarReal q 0

noncomputable def lambdaResidualLocal (q p : ℕ) : ℝ :=
  if p.Prime ∧ p ∣ fixedQPeriod q then
    1 - 1 / (p : ℝ)
  else 1

lemma prime_dvd_fixedQPeriod_iff
    {q p : ℕ} (hp : p.Prime) :
    p ∣ fixedQPeriod q ↔ p ∣ 6 ∨ p ∣ q := by
  unfold fixedQPeriod
  constructor
  · intro h
    have hprod : p ∣ 6 * q := by
      exact h.trans (Nat.lcm_dvd_mul 6 q)
    exact (hp.dvd_mul).mp hprod
  · intro h
    rcases h with h6 | hq
    · exact h6.trans (Nat.dvd_lcm_left 6 q)
    · exact hq.trans (Nat.dvd_lcm_right 6 q)

lemma normalizationBaseline_ne_zero
    (q h p : ℕ) :
    normalizationBaseline q h p ≠ 0 := by
  by_cases ha : p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q
  · have hp5 := ha.2.1
    have hp0 : (p : ℝ) ≠ 0 := by
      exact_mod_cast (show p ≠ 0 by omega)
    have hp1 : (p : ℝ) - 1 ≠ 0 := by
      exact sub_ne_zero.mpr (by exact_mod_cast (show p ≠ 1 by omega))
    have hp2 : (p : ℝ) - 2 ≠ 0 := by
      exact sub_ne_zero.mpr (by exact_mod_cast (show p ≠ 2 by omega))
    have hp3 : (p : ℝ) - 3 ≠ 0 := by
      exact sub_ne_zero.mpr (by exact_mod_cast (show p ≠ 3 by omega))
    by_cases hph : p ∣ h
    · simp [normalizationBaseline, ha, hph, hp0, hp1, hp2]
    · simp [normalizationBaseline, ha, hph, hp0, hp1, hp2, hp3]
  · simp [normalizationBaseline, ha]

lemma movingVCoeff_prime_active
    {q h p : ℕ} (hp : p.Prime) (hcop : p.Coprime (6 * q)) :
    movingVCoeff q h p =
      if p ∣ h then 1 / ((p : ℝ) - 2)
      else 1 / ((p : ℝ) - 3) := by
  rw [movingVCoeff_eq_finiteVWeightReal hp.ne_zero hp.squarefree hcop]
  unfold finiteVWeightReal
  rw [hp.primeFactors]
  simp

lemma etaCoeff_prime_active
    {q p : ℕ} (hp : p.Prime) (hcop : p.Coprime (6 * q)) :
    etaCoeff q p = 1 / ((p : ℝ) - 2) := by
  unfold etaCoeff
  rw [if_neg hp.ne_zero]
  rw [if_pos ⟨hp.squarefree, hcop⟩]
  rw [hp.primeFactors]
  simp

theorem normalizationBaseline_mul_movingEulerLocal
    (q h p : ℕ) :
    normalizationBaseline q h p *
      logarithmicEulerResidueLocal (movingVCoeff q h) p =
        lambdaResidualLocal q p := by
  by_cases hp : p.Prime
  · by_cases hp5 : 5 ≤ p
    · by_cases hpq : p ∣ q
      · have hnotactive : ¬ (p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q) := by
          simp [hp, hp5, hpq]
        have hL : p ∣ fixedQPeriod q :=
          hpq.trans (Nat.dvd_lcm_right 6 q)
        have hnotcop : ¬ p.Coprime (6 * q) := by
          intro hc
          have hnd := hp.coprime_iff_not_dvd.mp hc
          exact hnd (dvd_mul_of_dvd_right hpq 6)
        simp [normalizationBaseline, logarithmicEulerResidueLocal,
          lambdaResidualLocal, movingVCoeff, hp, hp5, hpq,
          hnotactive, hL, hnotcop]
      · have hactive : p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q :=
          ⟨hp, hp5, hpq⟩
        have hpnot6 : ¬ p ∣ 6 := by
          intro h6
          have h23 : p ∣ 2 * 3 := by simpa using h6
          rcases hp.dvd_mul.mp h23 with h2 | h3
          · have hp2 : p ≤ 2 := Nat.le_of_dvd (by norm_num) h2
            omega
          · have hp3 : p ≤ 3 := Nat.le_of_dvd (by norm_num) h3
            omega
        have hnotL : ¬ p ∣ fixedQPeriod q := by
          rw [prime_dvd_fixedQPeriod_iff hp]
          intro h
          rcases h with h6 | hq
          · exact hpnot6 h6
          · exact hpq hq
        have hsq : Squarefree p := hp.squarefree
        have hcop : p.Coprime (6 * q) := by
          apply hp.coprime_iff_not_dvd.mpr
          intro hd
          rcases hp.dvd_mul.mp hd with h6 | hq
          · exact hpnot6 h6
          · exact hpq hq
        have hcop' : p.Coprime (q * 6) := by
          simpa [Nat.mul_comm] using hcop
        by_cases hph : p ∣ h
        · unfold logarithmicEulerResidueLocal
          rw [if_pos hp]
          rw [movingVCoeff_prime_active hp hcop]
          rw [if_pos hph]
          rw [lambdaResidualLocal, if_neg (by simp [hp, hnotL])]
          simp [normalizationBaseline, hactive, hph]
          have hp0 : (p : ℝ) ≠ 0 := by
            exact_mod_cast (show p ≠ 0 by omega)
          have hp1 : (p : ℝ) - 1 ≠ 0 := by
            exact sub_ne_zero.mpr (by exact_mod_cast (show p ≠ 1 by omega))
          have hp2 : (p : ℝ) - 2 ≠ 0 := by
            exact sub_ne_zero.mpr (by exact_mod_cast (show p ≠ 2 by omega))
          field_simp [hp0, hp1, hp2]
          ring
        · unfold logarithmicEulerResidueLocal
          rw [if_pos hp]
          rw [movingVCoeff_prime_active hp hcop]
          rw [if_neg hph]
          rw [lambdaResidualLocal, if_neg (by simp [hp, hnotL])]
          simp [normalizationBaseline, hactive, hph]
          have hp0 : (p : ℝ) ≠ 0 := by
            exact_mod_cast (show p ≠ 0 by omega)
          have hp1 : (p : ℝ) - 1 ≠ 0 := by
            exact sub_ne_zero.mpr (by exact_mod_cast (show p ≠ 1 by omega))
          have hp2 : (p : ℝ) - 2 ≠ 0 := by
            exact sub_ne_zero.mpr (by exact_mod_cast (show p ≠ 2 by omega))
          have hp3 : (p : ℝ) - 3 ≠ 0 := by
            exact sub_ne_zero.mpr (by exact_mod_cast (show p ≠ 3 by omega))
          field_simp [hp0, hp1, hp2, hp3]
          ring
    · have hp23 : p = 2 ∨ p = 3 := by
          rcases hp.eq_two_or_odd with h2 | hodd
          · exact Or.inl h2
          · right
            have hp2 := hp.two_le
            have hpLt : p < 5 := Nat.lt_of_not_ge hp5
            omega
      rcases hp23 with rfl | rfl
      · have hL : 2 ∣ fixedQPeriod q :=
          (show 2 ∣ 6 by norm_num).trans (Nat.dvd_lcm_left 6 q)
        have hnotcop : ¬ (2 : ℕ).Coprime (6 * q) := by
          intro hc
          have hnd := Nat.prime_two.coprime_iff_not_dvd.mp hc
          exact hnd (by
            refine ⟨3 * q, ?_⟩
            ring)
        rw [lambdaResidualLocal, if_pos ⟨hp, hL⟩]
        unfold logarithmicEulerResidueLocal
        rw [if_pos hp]
        have hcoeff : movingVCoeff q h 2 = 0 := by
          unfold movingVCoeff
          rw [if_neg (by norm_num : 2 ≠ 0)]
          rw [if_neg (by
            intro hs
            exact hnotcop hs.2)]
        rw [hcoeff]
        simp [normalizationBaseline]
      · have hL : 3 ∣ fixedQPeriod q :=
          (show 3 ∣ 6 by norm_num).trans (Nat.dvd_lcm_left 6 q)
        have hnotcop : ¬ (3 : ℕ).Coprime (6 * q) := by
          intro hc
          have hnd := hp.coprime_iff_not_dvd.mp hc
          exact hnd (by
            refine ⟨2 * q, ?_⟩
            ring)
        rw [lambdaResidualLocal, if_pos ⟨hp, hL⟩]
        unfold logarithmicEulerResidueLocal
        rw [if_pos hp]
        have hcoeff : movingVCoeff q h 3 = 0 := by
          unfold movingVCoeff
          rw [if_neg (by norm_num : 3 ≠ 0)]
          rw [if_neg (by
            intro hs
            exact hnotcop hs.2)]
        rw [hcoeff]
        simp [normalizationBaseline]
  · simp [normalizationBaseline, logarithmicEulerResidueLocal,
      lambdaResidualLocal, hp]

theorem normalizationBaseline_mul_etaEulerLocal
    (q p : ℕ) :
    normalizationBaseline q 0 p *
      logarithmicEulerResidueLocal (etaCoeff q) p =
        lambdaResidualLocal q p := by
  have hmove :=
    normalizationBaseline_mul_movingEulerLocal q 0 p
  have hcoeffFun : movingVCoeff q 0 = etaCoeff q := by
    funext e
    unfold movingVCoeff etaCoeff
    by_cases he0 : e = 0
    · simp [he0]
    · rw [if_neg he0, if_neg he0]
      by_cases hs : Squarefree e ∧ e.Coprime (6 * q)
      · rw [if_pos hs, if_pos hs]
        apply Finset.prod_congr rfl
        intro x hx
        simp
      · rw [if_neg hs, if_neg hs]
  rw [hcoeffFun] at hmove
  exact hmove

#print axioms normalizationBaseline_mul_movingEulerLocal
#print axioms normalizationBaseline_mul_etaEulerLocal

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem tprod_normalizationBaseline_ne_zero
    (q h : ℕ) :
    (∏' p : ℕ, normalizationBaseline q h p) ≠ 0 := by
  rw [tprod_normalizationBaseline_eq_inv q h]
  have hinv :
      (∏' p : ℕ, (1 + normalizationCorrection q h p)⁻¹) =
        (∏' p : ℕ, (1 + normalizationCorrection q h p))⁻¹ := by
    exact
      (multipliable_one_add_normalizationCorrection q h).tprod_inv₀
        (correction_tprod_ne_zero q h)
  rw [hinv]
  exact inv_ne_zero (correction_tprod_ne_zero q h)

lemma lambdaResidual_mulSupport_subset
    (q : ℕ) (hq : 0 < q) :
    Function.mulSupport (lambdaResidualLocal q) ⊆
      ↑(fixedQPeriod q).primeFactors := by
  intro p hp
  unfold Function.mulSupport at hp
  by_cases hc : p.Prime ∧ p ∣ fixedQPeriod q
  · exact Nat.mem_primeFactors.mpr
      ⟨hc.1, hc.2,
        Nat.ne_of_gt (Nat.lcm_pos (by norm_num) hq)⟩
  · exfalso
    apply hp
    simp [lambdaResidualLocal, hc]

lemma lambdaResidual_hasFiniteMulSupport
    (q : ℕ) (hq : 0 < q) :
    Function.HasFiniteMulSupport (lambdaResidualLocal q) := by
  exact (fixedQPeriod q).primeFactors.finite_toSet.subset
    (lambdaResidual_mulSupport_subset q hq)

theorem tprod_lambdaResidualLocal_eq_prod
    (q : ℕ) (hq : 0 < q) :
    (∏' p : ℕ, lambdaResidualLocal q p) =
      ∏ p ∈ (fixedQPeriod q).primeFactors,
        (1 - 1 / (p : ℝ)) := by
  rw [tprod_eq_prod' (lambdaResidual_mulSupport_subset q hq)]
  apply Finset.prod_congr rfl
  intro p hp
  have hm := Nat.mem_primeFactors.mp hp
  simp [lambdaResidualLocal, hm.1, hm.2]

theorem prod_fixedQPeriod_primeFactors_eq_totient_div
    (q : ℕ) (hq : 0 < q) :
    (∏ p ∈ (fixedQPeriod q).primeFactors,
      (1 - 1 / (p : ℝ))) =
      (Nat.totient (fixedQPeriod q) : ℝ) /
        (fixedQPeriod q : ℝ) := by
  let L := fixedQPeriod q
  have hL : 0 < L := Nat.lcm_pos (by norm_num) hq
  have htotQ := Nat.totient_eq_mul_prod_factors L
  have htotR := congrArg (fun x : ℚ => (x : ℝ)) htotQ
  push_cast at htotR
  have hL0 : (L : ℝ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hL)
  change
    (∏ p ∈ L.primeFactors, (1 - 1 / (p : ℝ))) =
      (Nat.totient L : ℝ) / (L : ℝ)
  apply (eq_div_iff hL0).2
  simpa [one_div, mul_comm] using htotR.symm

theorem tprod_lambdaResidualLocal_eq_totient_div
    (q : ℕ) (hq : 0 < q) :
    (∏' p : ℕ, lambdaResidualLocal q p) =
      (Nat.totient (fixedQPeriod q) : ℝ) /
        (fixedQPeriod q : ℝ) := by
  rw [tprod_lambdaResidualLocal_eq_prod q hq]
  exact prod_fixedQPeriod_primeFactors_eq_totient_div q hq

lemma movingEulerLocal_eq_invBaseline_mul_residual
    (q h p : ℕ) :
    logarithmicEulerResidueLocal (movingVCoeff q h) p =
      (normalizationBaseline q h p)⁻¹ *
        lambdaResidualLocal q p := by
  have hb := normalizationBaseline_ne_zero q h p
  have hlocal := normalizationBaseline_mul_movingEulerLocal q h p
  calc
    logarithmicEulerResidueLocal (movingVCoeff q h) p =
        (normalizationBaseline q h p)⁻¹ *
          (normalizationBaseline q h p *
            logarithmicEulerResidueLocal (movingVCoeff q h) p) := by
              rw [← mul_assoc, inv_mul_cancel₀ hb, one_mul]
    _ = (normalizationBaseline q h p)⁻¹ *
          lambdaResidualLocal q p := by rw [hlocal]

lemma etaEulerLocal_eq_invBaseline_mul_residual
    (q p : ℕ) :
    logarithmicEulerResidueLocal (etaCoeff q) p =
      (normalizationBaseline q 0 p)⁻¹ *
        lambdaResidualLocal q p := by
  have hb := normalizationBaseline_ne_zero q 0 p
  have hlocal := normalizationBaseline_mul_etaEulerLocal q p
  calc
    logarithmicEulerResidueLocal (etaCoeff q) p =
        (normalizationBaseline q 0 p)⁻¹ *
          (normalizationBaseline q 0 p *
            logarithmicEulerResidueLocal (etaCoeff q) p) := by
              rw [← mul_assoc, inv_mul_cancel₀ hb, one_mul]
    _ = (normalizationBaseline q 0 p)⁻¹ *
          lambdaResidualLocal q p := by rw [hlocal]

theorem multipliable_movingEulerLocal
    (q h : ℕ) (hq : 0 < q) :
    Multipliable (logarithmicEulerResidueLocal (movingVCoeff q h)) := by
  have hb := (multipliable_normalizationBaseline' q h).inv₀
    (tprod_normalizationBaseline_ne_zero q h)
  have hr : Multipliable (lambdaResidualLocal q) :=
    multipliable_of_hasFiniteMulSupport
      (lambdaResidual_hasFiniteMulSupport q hq)
  exact (hb.mul hr).congr
    (fun p => (movingEulerLocal_eq_invBaseline_mul_residual q h p).symm)

theorem multipliable_etaEulerLocal
    (q : ℕ) (hq : 0 < q) :
    Multipliable (logarithmicEulerResidueLocal (etaCoeff q)) := by
  have hb := (multipliable_normalizationBaseline' q 0).inv₀
    (tprod_normalizationBaseline_ne_zero q 0)
  have hr : Multipliable (lambdaResidualLocal q) :=
    multipliable_of_hasFiniteMulSupport
      (lambdaResidual_hasFiniteMulSupport q hq)
  exact (hb.mul hr).congr
    (fun p => (etaEulerLocal_eq_invBaseline_mul_residual q p).symm)

theorem cStar_mul_logarithmicEulerResidue_moving
    (q h : ℕ) (hq : 0 < q) :
    cStarReal q h *
      logarithmicEulerResidue (movingVCoeff q h) =
        (∏' p : ℕ, lambdaResidualLocal q p) := by
  unfold cStarReal logarithmicEulerResidue
  have hb := multipliable_normalizationBaseline' q h
  have hf := multipliable_movingEulerLocal q h hq
  rw [← hb.tprod_mul hf]
  apply tprod_congr
  intro p
  exact normalizationBaseline_mul_movingEulerLocal q h p

theorem freeHighBaseline_mul_logarithmicEulerResidue_eta
    (q : ℕ) (hq : 0 < q) :
    freeHighBaseline q *
      logarithmicEulerResidue (etaCoeff q) =
        (∏' p : ℕ, lambdaResidualLocal q p) := by
  unfold freeHighBaseline cStarReal logarithmicEulerResidue
  have hb := multipliable_normalizationBaseline' q 0
  have hf := multipliable_etaEulerLocal q hq
  rw [← hb.tprod_mul hf]
  apply tprod_congr
  intro p
  exact normalizationBaseline_mul_etaEulerLocal q p

theorem principalHighCoefficient_moving
    (q h : ℕ) (hq : 0 < q) :
    cStarReal q h *
      logarithmicEulerResidue (movingVCoeff q h) =
        (Nat.totient (fixedQPeriod q) : ℝ) /
          (fixedQPeriod q : ℝ) := by
  rw [cStar_mul_logarithmicEulerResidue_moving q h hq]
  exact tprod_lambdaResidualLocal_eq_totient_div q hq

theorem principalHighCoefficient_eta
    (q : ℕ) (hq : 0 < q) :
    freeHighBaseline q *
      logarithmicEulerResidue (etaCoeff q) =
        (Nat.totient (fixedQPeriod q) : ℝ) /
          (fixedQPeriod q : ℝ) := by
  rw [freeHighBaseline_mul_logarithmicEulerResidue_eta q hq]
  exact tprod_lambdaResidualLocal_eq_totient_div q hq

theorem principalHighCoefficient_anchored_eq_free
    (q h : ℕ) (hq : 0 < q) :
    cStarReal q h *
        logarithmicEulerResidue (movingVCoeff q h) =
      freeHighBaseline q *
        logarithmicEulerResidue (etaCoeff q) := by
  rw [principalHighCoefficient_moving q h hq,
    principalHighCoefficient_eta q hq]

#print axioms principalHighCoefficient_moving
#print axioms principalHighCoefficient_eta
#print axioms principalHighCoefficient_anchored_eq_free

end PaperB.FixedQ
