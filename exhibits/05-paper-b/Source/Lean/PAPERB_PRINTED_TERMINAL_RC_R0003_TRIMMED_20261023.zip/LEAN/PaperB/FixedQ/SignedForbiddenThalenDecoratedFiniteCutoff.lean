import PaperB.FixedQ.SignedForbiddenThalenCutoffFiniteLocalization
import PaperB.FixedQ.H3HeightForbiddenCore

open scoped BigOperators

namespace PaperB.FixedQ

/-- At active ordinary supports disjoint from the selected height
decoration, the literal Tavren reduced signed source term is exactly
Thalen's original weighted proper source term. -/
theorem thalen_dForbidden_eq_finiteOuterSourceTerm
    {q A H : ℕ} {d n : Finset ℕ}
    (hd : Disjoint d n)
    (hn : n ∈ activeOrdinaryTwoDimensionalSet q H) :
    dForbiddenReducedBooleanCoreTerm q A H d n =
      thalenFiniteOuterSourceTerm q A H n := by
  simp [dForbiddenReducedBooleanCoreTerm, hd,
    ordinaryBooleanCoreTerm, thalenFiniteOuterSourceTerm,
    Set.indicator_of_mem hn]

/-- Literal decorated, cutoff-filtered finite source, with an explicit
small-support remainder. Does not erase Z or claim an infinite limit. -/
theorem thalen_decorated_finite_exterior_eq_full_sub_small
    (q A H Z : ℕ) (d S : Finset ℕ)
    (hact : ∀ n ∈ S.powerset,
      n ∈ activeOrdinaryTwoDimensionalSet q H)
    (hdis : Disjoint d S) :
    (∑ n ∈ S.powerset.filter (fun n => Z < primeSetProduct n),
      dForbiddenReducedBooleanCoreTerm q A H d n) =
      (∑ n ∈ S.powerset, thalenFiniteOuterSourceTerm q A H n) -
      (∑ n ∈ S.powerset.filter
        (fun n => primeSetProduct n ≤ Z),
        thalenFiniteOuterSourceTerm q A H n) := by
  have hterm (n : Finset ℕ) (hn : n ∈ S.powerset) :
      dForbiddenReducedBooleanCoreTerm q A H d n =
        thalenFiniteOuterSourceTerm q A H n := by
    apply thalen_dForbidden_eq_finiteOuterSourceTerm
    · exact Finset.disjoint_of_subset_right
        (Finset.mem_powerset.mp hn) hdis
    · exact hact n hn
  have hleft :
      (∑ n ∈ S.powerset.filter (fun n => Z < primeSetProduct n),
        dForbiddenReducedBooleanCoreTerm q A H d n) =
      ∑ n ∈ S.powerset.filter (fun n => Z < primeSetProduct n),
        thalenFiniteOuterSourceTerm q A H n := by
    apply Finset.sum_congr rfl
    intro n hn
    exact hterm n (Finset.mem_filter.mp hn).1
  rw [hleft]
  exact thalen_finite_exterior_eq_full_sub_small q A H Z S

#print axioms thalen_decorated_finite_exterior_eq_full_sub_small

end PaperB.FixedQ
