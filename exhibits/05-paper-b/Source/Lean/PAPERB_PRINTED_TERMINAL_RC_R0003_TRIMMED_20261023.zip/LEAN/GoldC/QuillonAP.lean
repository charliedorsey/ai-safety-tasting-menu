import GoldC.QuillonVW

/-!
# Quillon CSC3 F7.4i: class-restricted incomplete sums (`m ≡ r mod Q`, `(Q,s)=1`)

* `ap_filter_eq`: `{m ∈ (X,Y] : m%Q = a} = {a + Qt : t ∈ [⌊(X+Q−a)/Q⌋, ⌊(Y+Q−a)/Q⌋)}`.
* `ap_kphase_bound_w`: for a monotone weight `g ≥ 0`,
  `‖Σ_{m∈(X,Y], m≡a} g(m) kphase(c,m)‖ ≤ g(Y)(1 + 2Kmax((Y−X)/(Qs) + 1 + log s))`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonAP

open GoldC.QuillonVW

lemma ap_filter_eq (Q a X Y : ℕ) (hQ : 1 ≤ Q) (ha : a < Q) :
    (Ioc X Y).filter (fun m => m % Q = a) =
      (Ico ((X + Q - a) / Q) ((Y + Q - a) / Q)).image (fun t => a + Q * t) := by
  ext m
  simp only [mem_filter, mem_Ioc, mem_image, mem_Ico]
  constructor
  · rintro ⟨⟨hXm, hmY⟩, hma⟩
    have hdm := Nat.div_add_mod m Q
    refine ⟨m / Q, ⟨?_, ?_⟩, ?_⟩
    · apply Nat.lt_succ_iff.1
      rw [Nat.div_lt_iff_lt_mul (by omega), Nat.succ_mul, Nat.mul_comm (m / Q) Q]
      omega
    · apply Nat.lt_of_succ_le
      rw [Nat.le_div_iff_mul_le (by omega), Nat.succ_mul, Nat.mul_comm (m / Q) Q]
      omega
    · omega
  · rintro ⟨t, ⟨hlo, hhi⟩, rfl⟩
    have h1 : (X + Q - a) / Q < t + 1 := Nat.lt_succ_of_le hlo
    rw [Nat.div_lt_iff_lt_mul (by omega), Nat.succ_mul, Nat.mul_comm t Q] at h1
    have h2 : t + 1 ≤ (Y + Q - a) / Q := hhi
    rw [Nat.le_div_iff_mul_le (by omega), Nat.succ_mul, Nat.mul_comm t Q] at h2
    refine ⟨⟨by omega, by omega⟩, ?_⟩
    rw [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt ha]

lemma sum_Ico_split (f : ℕ → ℂ) (lo hi : ℕ) (h : lo < hi) :
    ∑ t ∈ Ico lo hi, f t = f lo + ∑ t ∈ Ioc lo (hi - 1), f t := by
  have : Ico lo hi = insert lo (Ioc lo (hi - 1)) := by
    ext t; simp only [mem_Ico, mem_insert, mem_Ioc]; omega
  rw [this, sum_insert (by simp)]

lemma floor_sub_le (Q a X Y : ℕ) (hQ : 1 ≤ Q) (ha : a < Q) (hXY : X ≤ Y) :
    (((Y + Q - a) / Q - 1 - (X + Q - a) / Q : ℕ) : ℝ) ≤ ((Y - X : ℕ) : ℝ) / Q := by
  have hQR : (0 : ℝ) < Q := by exact_mod_cast hQ
  rw [le_div_iff₀ hQR]
  set u := (Y + Q - a) / Q with hu
  set v := (X + Q - a) / Q with hv
  have h1 : u * Q ≤ Y + Q - a := Nat.div_mul_le_self _ _
  have h2 : X + Q - a < (v + 1) * Q :=
    (Nat.div_lt_iff_lt_mul (by omega)).1 (by rw [← hv]; exact Nat.lt_succ_self v)
  have key : (u - 1 - v) * Q ≤ Y - X := by
    rcases Nat.lt_or_ge u (v + 1) with h | h
    · have : u - 1 - v = 0 := by omega
      rw [this, zero_mul]; exact Nat.zero_le _
    · obtain ⟨k, hk⟩ : ∃ k, u = v + 1 + k := ⟨u - (v + 1), by omega⟩
      have e : u - 1 - v = k := by omega
      rw [e]
      rw [hk, Nat.add_mul, Nat.add_mul, one_mul] at h1
      rw [Nat.add_mul, one_mul] at h2
      omega
  exact_mod_cast key

section
variable {s : ℕ} [NeZero s]

/-- **Class-restricted weighted incomplete sum.** -/
theorem ap_kphase_bound_w (hs : 2 ≤ s) (c : ZMod s) (Q a X Y : ℕ) (hQ : 1 ≤ Q) (ha : a < Q)
    (hcop : Nat.Coprime Q s) (hXY : X ≤ Y) (Kmax : ℝ)
    (hK : ∀ b : ZMod s, ‖GoldC.QuillonKl.K s b c‖ ≤ Kmax) (g : ℕ → ℝ) (hg0 : ∀ n, 0 ≤ g n)
    (hgm : Monotone g) :
    ‖∑ m ∈ (Ioc X Y).filter (fun m => m % Q = a), (g m : ℂ) * kphase c m‖ ≤
      g Y * (1 + 2 * Kmax * (((Y - X : ℕ) : ℝ) / (Q * s) + 1 + Real.log s)) := by
  have hK0 : 0 ≤ Kmax := (norm_nonneg _).trans (hK 0)
  have hlogs : 0 ≤ Real.log s := Real.log_nonneg (by exact_mod_cast (show 1 ≤ s by omega))
  have hsR : (0 : ℝ) < s := by exact_mod_cast (show 0 < s by omega)
  have hQR : (0 : ℝ) < Q := by exact_mod_cast hQ
  rw [ap_filter_eq Q a X Y hQ ha, sum_image (fun t₁ _ t₂ _ h => by
    have : Q * t₁ = Q * t₂ := by omega
    exact Nat.eq_of_mul_eq_mul_left (by omega) this)]
  set lo := (X + Q - a) / Q
  set hi := (Y + Q - a) / Q
  have hgY : 0 ≤ g Y := hg0 Y
  rcases Nat.lt_or_ge lo hi with hlh | hlh
  · rw [sum_Ico_split _ lo hi hlh]
    have hle : ∀ t, t < hi → a + Q * t ≤ Y := by
      intro t ht
      have h2 : t + 1 ≤ hi := ht
      rw [Nat.le_div_iff_mul_le (by omega), Nat.succ_mul, Nat.mul_comm t Q] at h2
      omega
    have hβ : ∀ j, lo ≤ j → j ≤ hi - 1 →
        ‖GoldC.QuillonAbel.psum (fun t => kphase c (a + Q * t)) lo j‖ ≤
          Kmax * (((hi - 1 - lo : ℕ) : ℝ) / s + 1 + Real.log s) := by
      intro j hj1 hj2
      have := GoldC.QuillonCompletion.incomplete_bound_AP hs c a Q lo j hcop hj1 Kmax hK
      refine this.trans ?_
      gcongr
    have hab := abel_inc (fun t => g (a + Q * t)) (fun t => hg0 _)
      (fun t₁ t₂ h => hgm (by nlinarith)) (fun t => kphase c (a + Q * t)) lo (hi - 1)
      (by omega) _ hβ
    have hfirst : ‖((g (a + Q * lo) : ℝ) : ℂ) * kphase c (a + Q * lo)‖ ≤ g Y := by
      rw [norm_mul, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (hg0 _)]
      calc g (a + Q * lo) * ‖kphase c (a + Q * lo)‖ ≤ g (a + Q * lo) * 1 :=
            mul_le_mul_of_nonneg_left (norm_kphase_le c _) (hg0 _)
        _ ≤ g Y := by rw [mul_one]; exact hgm (hle lo hlh)
    have hfl := floor_sub_le Q a X Y hQ ha hXY
    have hdiv : ((hi - 1 - lo : ℕ) : ℝ) / s ≤ ((Y - X : ℕ) : ℝ) / (Q * s) := by
      rw [div_le_div_iff₀ hsR (by positivity)]
      have := (le_div_iff₀ hQR).1 hfl
      nlinarith
    refine (norm_add_le _ _).trans ?_
    calc _ ≤ g Y + 2 * g (a + Q * (hi - 1)) * (Kmax * (((hi - 1 - lo : ℕ) : ℝ) / s + 1 + Real.log s)) :=
          add_le_add hfirst hab
      _ ≤ g Y + 2 * g Y * (Kmax * (((Y - X : ℕ) : ℝ) / (Q * s) + 1 + Real.log s)) := by
          have hgY' : g (a + Q * (hi - 1)) ≤ g Y := hgm (hle _ (Nat.sub_lt (lt_of_le_of_lt (Nat.zero_le _) hlh) Nat.one_pos))
          have hpos : 0 ≤ Kmax * (((hi - 1 - lo : ℕ) : ℝ) / s + 1 + Real.log s) := by positivity
          gcongr
      _ = _ := by ring
  · rw [Ico_eq_empty (by omega), sum_empty, norm_zero]
    have : 0 ≤ 1 + 2 * Kmax * (((Y - X : ℕ) : ℝ) / (Q * s) + 1 + Real.log s) := by positivity
    positivity

end

end GoldC.QuillonAP

#print axioms GoldC.QuillonAP.ap_filter_eq
#print axioms GoldC.QuillonAP.floor_sub_le
#print axioms GoldC.QuillonAP.ap_kphase_bound_w
