import PaperB.FixedQ.H2BooleanDyadicSecondMomentAssembly
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics

open scoped BigOperators
open Filter Real Asymptotics

namespace PaperB.FixedQ

private lemma h2BooleanX0_one_le : 1 ≤ h2BooleanX0 := by
  unfold h2BooleanX0 h2BooleanA0
  have hnon : 0 ≤ (101 / 200 : ℝ) := by norm_num
  have hs0 : 0 ≤ Real.sqrt (101 / 200 : ℝ) := Real.sqrt_nonneg _
  have hs2 : (Real.sqrt (101 / 200 : ℝ)) ^ 2 = (101 / 200 : ℝ) :=
    Real.sq_sqrt hnon
  nlinarith

private lemma h2Boolean_log_two_mul_add_one_le_two_log
    {M : ℕ} (hM : 3 ≤ M) :
    Real.log ((2 * M + 1 : ℕ) : ℝ) ≤ 2 * Real.log (M : ℝ) := by
  have hnat : 2 * M + 1 ≤ M ^ 2 := by nlinarith
  have hpos1 : (0 : ℝ) < ((2 * M + 1 : ℕ) : ℝ) := by positivity
  have hpos2 : (0 : ℝ) < ((M ^ 2 : ℕ) : ℝ) := by positivity
  have hcast : (((2 * M + 1 : ℕ) : ℝ)) ≤ (((M ^ 2 : ℕ) : ℝ)) := by
    exact_mod_cast hnat
  have hlog := Real.strictMonoOn_log.monotoneOn hpos1 hpos2 hcast
  calc
    Real.log ((2 * M + 1 : ℕ) : ℝ) ≤ Real.log (((M ^ 2 : ℕ) : ℝ)) := hlog
    _ = Real.log ((M : ℝ) ^ 2) := by norm_num
    _ = 2 * Real.log (M : ℝ) := by rw [Real.log_pow]; norm_num

private lemma h2Boolean_log_two_mul_le_two_log
    {M : ℕ} (hM : 2 ≤ M) :
    Real.log ((2 * M : ℕ) : ℝ) ≤ 2 * Real.log (M : ℝ) := by
  have hnat : 2 * M ≤ M ^ 2 := by nlinarith
  have hpos1 : (0 : ℝ) < ((2 * M : ℕ) : ℝ) := by positivity
  have hpos2 : (0 : ℝ) < ((M ^ 2 : ℕ) : ℝ) := by positivity
  have hcast : (((2 * M : ℕ) : ℝ)) ≤ (((M ^ 2 : ℕ) : ℝ)) := by
    exact_mod_cast hnat
  have hlog := Real.strictMonoOn_log.monotoneOn hpos1 hpos2 hcast
  calc
    Real.log ((2 * M : ℕ) : ℝ) ≤ Real.log (((M ^ 2 : ℕ) : ℝ)) := hlog
    _ = Real.log ((M : ℝ) ^ 2) := by norm_num
    _ = 2 * Real.log (M : ℝ) := by rw [Real.log_pow]; norm_num

private lemma h2Boolean_main_log_power_identity
    {t : ℝ} (ht : 0 < t) :
    (t ^ h2BooleanV0 / t) *
      t ^ (-h2BooleanTheta * h2BooleanV0) *
      t ^ (h2BooleanTheta * (h2BooleanV0 / 2)) =
    t ^ (h2BooleanX0 - 1) := by
  have hdiv : t ^ h2BooleanV0 / t = t ^ (h2BooleanV0 - 1) := by
    calc
      t ^ h2BooleanV0 / t = t ^ h2BooleanV0 / t ^ (1 : ℝ) := by
        rw [Real.rpow_one]
      _ = t ^ (h2BooleanV0 - 1) := by rw [Real.rpow_sub ht]
  rw [hdiv, ← Real.rpow_add ht, ← Real.rpow_add ht]
  congr 1
  rw [← h2Boolean_source_exponent_identity]
  ring

private lemma eventually_h2Boolean_bad_exp_decay :
    ∀ᶠ M : ℕ in Filter.atTop,
      Real.exp (-(1 / 8 : ℝ) *
        (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) ≤
      (Real.log (M : ℝ)) ^ (-4 : ℝ) := by
  have hsmall :
      ∀ᶠ x : ℝ in Filter.atTop,
        Real.exp (-(1 / 8 : ℝ) * x) ≤ x ^ (-400 : ℝ) := by
    have h := (isLittleO_exp_neg_mul_rpow_atTop
      (by norm_num : (0 : ℝ) < 1 / 8) (-400 : ℝ)).bound
      (by norm_num : (0 : ℝ) < 1)
    filter_upwards [h, Filter.eventually_ge_atTop (1 : ℝ)] with x hx hx1
    have hx0 : 0 ≤ x := le_trans (by norm_num) hx1
    rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _),
      Real.norm_eq_abs, abs_of_nonneg (Real.rpow_nonneg hx0 _)] at hx
    simpa using hx
  have hlogNat :
      Filter.Tendsto (fun M : ℕ => Real.log (M : ℝ))
        Filter.atTop Filter.atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hpowNat :
      Filter.Tendsto
        (fun M : ℕ => (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta))
        Filter.atTop Filter.atTop :=
    (tendsto_rpow_atTop h2Boolean_one_sub_theta_pos).comp hlogNat
  have hc := hpowNat.eventually hsmall
  have hlog1 := hlogNat.eventually (Filter.eventually_ge_atTop (1 : ℝ))
  filter_upwards [hc, hlog1] with M hdec hL
  have hL0 : 0 ≤ Real.log (M : ℝ) := le_trans (by norm_num) hL
  calc
    Real.exp (-(1 / 8 : ℝ) *
        (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta))
      ≤ ((Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) ^ (-400 : ℝ) := hdec
    _ = (Real.log (M : ℝ)) ^ (-4 : ℝ) := by
      rw [← Real.rpow_mul hL0]
      norm_num [h2BooleanTheta]

noncomputable def h2BooleanSecondMomentRateConstant (q : ℕ) : ℝ :=
  (2 : ℝ) ^ h2BooleanV0 *
    ((6 *
        PaperB.M4B.shiuFixedQuarterAssembleConstant
          8 ((8 : ℝ) ^ h2BooleanShiuGrowthThreshold) *
        Real.exp (6 * h2BooleanV0 + 24) *
        Real.exp (5 * h2BooleanV0 + 24)) +
      (6 *
        PaperB.M4B.shiuFixedQuarterAssembleConstant
          8 ((8 : ℝ) ^ h2BooleanShiuGrowthThreshold) *
        Real.exp (6 * h2BooleanV0 + 24) *
        Real.exp (5 * (h2BooleanV0 / 2) + 12)) +
      ((6 * q : ℝ) *
        PaperB.M4B.shiuFixedQuarterAssembleConstant
          8 ((8 : ℝ) ^ h2BooleanShiuGrowthThreshold) *
        Real.exp (6 * h2BooleanV0 + 24)) +
      (Real.exp (6 * h2BooleanV0 + 24) *
        Real.exp (10 * h2BooleanSecondTilt + 24)))

private lemma h2BooleanSecondMomentRateConstant_nonneg (q : ℕ) :
    0 ≤ h2BooleanSecondMomentRateConstant q := by
  unfold h2BooleanSecondMomentRateConstant
  unfold PaperB.M4B.shiuFixedQuarterAssembleConstant
  unfold PaperB.M4B.shiuClassIVConstant
  positivity

private lemma h2Boolean_log_two_mul_add_one_rpow_le
    {M : ℕ} (hM : 3 ≤ M) (hlog : 1 ≤ Real.log (M : ℝ)) :
    (Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 ≤
      (2 : ℝ) ^ h2BooleanV0 *
        (Real.log (M : ℝ)) ^ h2BooleanV0 := by
  have htop0 : 0 ≤ Real.log ((2 * M + 1 : ℕ) : ℝ) := by
    apply Real.log_nonneg
    exact_mod_cast (show 1 ≤ 2 * M + 1 by omega)
  have hle := h2Boolean_log_two_mul_add_one_le_two_log hM
  calc
    (Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0
      ≤ (2 * Real.log (M : ℝ)) ^ h2BooleanV0 :=
        Real.rpow_le_rpow htop0 hle h2BooleanV0_nonneg
    _ = (2 : ℝ) ^ h2BooleanV0 *
        (Real.log (M : ℝ)) ^ h2BooleanV0 := by
      rw [Real.mul_rpow (by norm_num) (le_trans (by norm_num) hlog)]

private lemma h2Boolean_log_two_mul_rpow_le
    {M : ℕ} (hM : 2 ≤ M) (hlog : 1 ≤ Real.log (M : ℝ)) :
    (Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0 ≤
      (2 : ℝ) ^ h2BooleanV0 *
        (Real.log (M : ℝ)) ^ h2BooleanV0 := by
  have htop0 : 0 ≤ Real.log ((2 * M : ℕ) : ℝ) := by
    apply Real.log_nonneg
    exact_mod_cast (show 1 ≤ 2 * M by omega)
  have hle := h2Boolean_log_two_mul_le_two_log hM
  calc
    (Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0
      ≤ (2 * Real.log (M : ℝ)) ^ h2BooleanV0 :=
        Real.rpow_le_rpow htop0 hle h2BooleanV0_nonneg
    _ = (2 : ℝ) ^ h2BooleanV0 *
        (Real.log (M : ℝ)) ^ h2BooleanV0 := by
      rw [Real.mul_rpow (by norm_num) (le_trans (by norm_num) hlog)]

private lemma h2Boolean_empty_log_power_le_main
    {t : ℝ} (ht : 1 ≤ t) :
    (t ^ h2BooleanV0 / t) *
        t ^ (-h2BooleanTheta * h2BooleanV0) ≤
      t ^ (h2BooleanX0 - 1) := by
  have ht0 : 0 < t := lt_of_lt_of_le zero_lt_one ht
  have hdiv : t ^ h2BooleanV0 / t = t ^ (h2BooleanV0 - 1) := by
    calc
      t ^ h2BooleanV0 / t = t ^ h2BooleanV0 / t ^ (1 : ℝ) := by
        rw [Real.rpow_one]
      _ = t ^ (h2BooleanV0 - 1) := by rw [Real.rpow_sub ht0]
  rw [hdiv, ← Real.rpow_add ht0]
  apply Real.rpow_le_rpow_of_exponent_le ht
  have hnon : 0 ≤ h2BooleanTheta * (h2BooleanV0 / 2) :=
    mul_nonneg h2BooleanTheta_pos.le (div_nonneg h2BooleanV0_nonneg (by norm_num))
  rw [← h2Boolean_source_exponent_identity]
  linarith

private lemma h2Boolean_bad_log_power_le_main
    {t : ℝ} (ht : 1 ≤ t) :
    t ^ h2BooleanV0 *
        t ^ (-h2BooleanTheta * h2BooleanV0) *
        t ^ (h2BooleanTheta * h2BooleanV0) *
        t ^ (-4 : ℝ) ≤
      t ^ (h2BooleanX0 - 1) := by
  have ht0 : 0 < t := lt_of_lt_of_le zero_lt_one ht
  rw [← Real.rpow_add ht0, ← Real.rpow_add ht0, ← Real.rpow_add ht0]
  apply Real.rpow_le_rpow_of_exponent_le ht
  have hx : 0 ≤ h2BooleanX0 - 1 := sub_nonneg.mpr h2BooleanX0_one_le
  have hv : h2BooleanV0 - 4 ≤ -1 := by linarith [h2BooleanV0_le_three]
  norm_num at hv ⊢
  linarith

theorem h2BooleanFrequencySecondMomentMajorantAll_le_rate_exact
    (q M j : ℕ)
    (hM : 3 ≤ M)
    (hlog : 1 ≤ Real.log (M : ℝ))
    (hj : 1 ≤ j)
    (hdec : Real.exp (-(1 / 8 : ℝ) *
        (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) ≤
      (Real.log (M : ℝ)) ^ (-4 : ℝ)) :
    h2BooleanFrequencySecondMomentMajorantAll q M j ≤
      h2BooleanSecondMomentRateConstant q *
        (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
        (1 + Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by
  let t : ℝ := Real.log (M : ℝ)
  let L : ℝ := 1 + Real.log (j : ℝ)
  let P : ℝ := (2 : ℝ) ^ h2BooleanV0
  let Cg : ℝ :=
    6 * PaperB.M4B.shiuFixedQuarterAssembleConstant
      8 ((8 : ℝ) ^ h2BooleanShiuGrowthThreshold) *
      Real.exp (6 * h2BooleanV0 + 24) *
      Real.exp (5 * h2BooleanV0 + 24)
  let Cs : ℝ :=
    6 * PaperB.M4B.shiuFixedQuarterAssembleConstant
      8 ((8 : ℝ) ^ h2BooleanShiuGrowthThreshold) *
      Real.exp (6 * h2BooleanV0 + 24) *
      Real.exp (5 * (h2BooleanV0 / 2) + 12)
  let Ce : ℝ :=
    (6 * q : ℝ) * PaperB.M4B.shiuFixedQuarterAssembleConstant
      8 ((8 : ℝ) ^ h2BooleanShiuGrowthThreshold) *
      Real.exp (6 * h2BooleanV0 + 24)
  let Cb : ℝ :=
    Real.exp (6 * h2BooleanV0 + 24) *
      Real.exp (10 * h2BooleanSecondTilt + 24)
  have ht : 1 ≤ t := by simpa [t] using hlog
  have ht0 : 0 < t := lt_of_lt_of_le zero_lt_one ht
  have ht_nonneg : 0 ≤ t := ht0.le
  have hlogj0 : 0 ≤ Real.log (j : ℝ) :=
    Real.log_nonneg (by exact_mod_cast hj)
  have hL1 : 1 ≤ L := by dsimp [L]; linarith
  have hL0 : 0 ≤ L := le_trans (by norm_num) hL1
  have hhalf0 : 0 ≤ h2BooleanV0 / 2 :=
    div_nonneg h2BooleanV0_nonneg (by norm_num)
  have hLpow1 : 1 ≤ L ^ (h2BooleanV0 / 2) :=
    Real.one_le_rpow hL1 hhalf0
  have hP0 : 0 ≤ P := by dsimp [P]; positivity
  have hCg0 : 0 ≤ Cg := by
    dsimp [Cg]
    unfold PaperB.M4B.shiuFixedQuarterAssembleConstant
    unfold PaperB.M4B.shiuClassIVConstant
    positivity
  have hCs0 : 0 ≤ Cs := by
    dsimp [Cs]
    unfold PaperB.M4B.shiuFixedQuarterAssembleConstant
    unfold PaperB.M4B.shiuClassIVConstant
    positivity
  have hCe0 : 0 ≤ Ce := by
    dsimp [Ce]
    unfold PaperB.M4B.shiuFixedQuarterAssembleConstant
    unfold PaperB.M4B.shiuClassIVConstant
    positivity
  have hCb0 : 0 ≤ Cb := by dsimp [Cb]; positivity
  have hmain0 : 0 ≤ t ^ (h2BooleanX0 - 1) := Real.rpow_nonneg ht_nonneg _
  have hcommon0 : 0 ≤ t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2) :=
    mul_nonneg hmain0 (Real.rpow_nonneg hL0 _)
  have htop := h2Boolean_log_two_mul_add_one_rpow_le hM hlog
  have htop2 := h2Boolean_log_two_mul_rpow_le (by omega : 2 ≤ M) hlog
  have hlog2pos : 0 < Real.log ((2 * M : ℕ) : ℝ) := by
    apply Real.log_pos
    exact_mod_cast (show 1 < 2 * M by omega)
  have hlogM_le_log2M : t ≤ Real.log ((2 * M : ℕ) : ℝ) := by
    dsimp [t]
    apply Real.strictMonoOn_log.monotoneOn
    · show (0 : ℝ) < (M : ℝ)
      exact_mod_cast (show 0 < M by omega)
    · show (0 : ℝ) < ((2 * M : ℕ) : ℝ)
      exact_mod_cast (show 0 < 2 * M by omega)
    · exact_mod_cast (show M ≤ 2 * M by omega)
  have hfrac2 :
      ((Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0) /
          Real.log ((2 * M : ℕ) : ℝ) ≤
        P * t ^ h2BooleanV0 / t := by
    calc
      ((Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0) /
          Real.log ((2 * M : ℕ) : ℝ)
        ≤ (P * t ^ h2BooleanV0) /
            Real.log ((2 * M : ℕ) : ℝ) := by
          exact div_le_div_of_nonneg_right (by simpa [P, t] using htop2)
            hlog2pos.le
      _ ≤ (P * t ^ h2BooleanV0) / t := by
          exact div_le_div_of_nonneg_left
            (mul_nonneg hP0 (Real.rpow_nonneg ht_nonneg _))
            ht0 hlogM_le_log2M
  have hlogYpow :
      (Real.log (h2BooleanRoughCutoff M : ℝ)) ^ h2BooleanV0 ≤
        t ^ (h2BooleanTheta * h2BooleanV0) := by
    have hM1 : 1 ≤ M := by omega
    have hY1 := h2BooleanRoughCutoff_one_le hM1
    have hlogY0 : 0 ≤ Real.log (h2BooleanRoughCutoff M : ℝ) :=
      Real.log_nonneg (by exact_mod_cast hY1)
    have hcut := h2BooleanRoughCutoff_log_le hM1
    have hp := Real.rpow_le_rpow hlogY0 hcut h2BooleanV0_nonneg
    calc
      (Real.log (h2BooleanRoughCutoff M : ℝ)) ^ h2BooleanV0
        ≤ (t ^ h2BooleanTheta) ^ h2BooleanV0 := by
          simpa [t] using hp
      _ = t ^ (h2BooleanTheta * h2BooleanV0) := by
          rw [← Real.rpow_mul ht_nonneg]
  have hLj :
      (Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) ≤
        L ^ (h2BooleanV0 / 2) :=
    Real.rpow_le_rpow hlogj0 (by dsimp [L]; linarith) hhalf0
  have hgoodLarge :
      h2BooleanGoodFrequencyMajorant M j ≤
        P * Cg * t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2) := by
    unfold h2BooleanGoodFrequencyMajorant
    calc
      Cg *
          ((Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 / t) *
          t ^ (-h2BooleanTheta * h2BooleanV0) *
          t ^ (h2BooleanTheta * (h2BooleanV0 / 2)) *
          (Real.log (j : ℝ)) ^ (h2BooleanV0 / 2)
        ≤ Cg * ((P * t ^ h2BooleanV0) / t) *
          t ^ (-h2BooleanTheta * h2BooleanV0) *
          t ^ (h2BooleanTheta * (h2BooleanV0 / 2)) *
          (Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by
            gcongr
      _ = P * Cg *
          ((t ^ h2BooleanV0 / t) *
            t ^ (-h2BooleanTheta * h2BooleanV0) *
            t ^ (h2BooleanTheta * (h2BooleanV0 / 2))) *
          (Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by ring
      _ = P * Cg * t ^ (h2BooleanX0 - 1) *
          (Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by
            rw [h2Boolean_main_log_power_identity ht0]
      _ ≤ P * Cg * t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2) := by
            exact mul_le_mul_of_nonneg_left hLj
              (mul_nonneg (mul_nonneg hP0 hCg0) hmain0)
  have hgoodSmall :
      h2BooleanGoodFrequencyMajorantSmall M ≤
        P * Cs * t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2) := by
    unfold h2BooleanGoodFrequencyMajorantSmall
    calc
      Cs *
          ((Real.log ((2 * M + 1 : ℕ) : ℝ)) ^ h2BooleanV0 / t) *
          t ^ (-h2BooleanTheta * h2BooleanV0) *
          t ^ (h2BooleanTheta * (h2BooleanV0 / 2))
        ≤ Cs * ((P * t ^ h2BooleanV0) / t) *
          t ^ (-h2BooleanTheta * h2BooleanV0) *
          t ^ (h2BooleanTheta * (h2BooleanV0 / 2)) := by
            gcongr
      _ = P * Cs *
          ((t ^ h2BooleanV0 / t) *
            t ^ (-h2BooleanTheta * h2BooleanV0) *
            t ^ (h2BooleanTheta * (h2BooleanV0 / 2))) := by ring
      _ = P * Cs * t ^ (h2BooleanX0 - 1) := by
            rw [h2Boolean_main_log_power_identity ht0]
      _ ≤ P * Cs * t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2) := by
            simpa using mul_le_mul_of_nonneg_left hLpow1
              (mul_nonneg (mul_nonneg hP0 hCs0) hmain0)
  have hempty :
      h2BooleanEmptyFrequencyMajorant q M ≤
        P * Ce * t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2) := by
    unfold h2BooleanEmptyFrequencyMajorant
    calc
      Ce *
          (((Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0) /
            Real.log ((2 * M : ℕ) : ℝ)) *
          t ^ (-h2BooleanTheta * h2BooleanV0)
        ≤ Ce * (P * t ^ h2BooleanV0 / t) *
          t ^ (-h2BooleanTheta * h2BooleanV0) := by
            gcongr
      _ = P * Ce *
          ((t ^ h2BooleanV0 / t) *
            t ^ (-h2BooleanTheta * h2BooleanV0)) := by ring
      _ ≤ P * Ce * t ^ (h2BooleanX0 - 1) := by
            gcongr
            exact h2Boolean_empty_log_power_le_main ht
      _ ≤ P * Ce * t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2) := by
            simpa using mul_le_mul_of_nonneg_left hLpow1
              (mul_nonneg (mul_nonneg hP0 hCe0) hmain0)
  have hbad :
      h2BooleanBadFrequencyMajorant q M ≤
        P * Cb * t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2) := by
    unfold h2BooleanBadFrequencyMajorant
    calc
      (Real.exp (6 * h2BooleanV0 + 24) *
          (Real.log ((2 * M : ℕ) : ℝ)) ^ h2BooleanV0 *
          t ^ (-h2BooleanTheta * h2BooleanV0)) *
        (Real.exp (10 * h2BooleanSecondTilt + 24) *
          (Real.log (h2BooleanRoughCutoff M : ℝ)) ^ h2BooleanV0 *
          Real.exp (-(1 / 8 : ℝ) * t ^ (1 - h2BooleanTheta)))
        ≤ (Real.exp (6 * h2BooleanV0 + 24) *
          (P * t ^ h2BooleanV0) *
          t ^ (-h2BooleanTheta * h2BooleanV0)) *
        (Real.exp (10 * h2BooleanSecondTilt + 24) *
          t ^ (h2BooleanTheta * h2BooleanV0) *
          t ^ (-4 : ℝ)) := by
            gcongr
      _ = P * Cb *
          (t ^ h2BooleanV0 *
            t ^ (-h2BooleanTheta * h2BooleanV0) *
            t ^ (h2BooleanTheta * h2BooleanV0) *
            t ^ (-4 : ℝ)) := by ring
      _ ≤ P * Cb * t ^ (h2BooleanX0 - 1) := by
            gcongr
            exact h2Boolean_bad_log_power_le_main ht
      _ ≤ P * Cb * t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2) := by
            simpa using mul_le_mul_of_nonneg_left hLpow1
              (mul_nonneg (mul_nonneg hP0 hCb0) hmain0)
  unfold h2BooleanFrequencySecondMomentMajorantAll
  by_cases hj4 : j < 4
  · rw [if_pos hj4]
    calc
      h2BooleanEmptyFrequencyMajorant q M +
          h2BooleanGoodFrequencyMajorantSmall M +
          h2BooleanBadFrequencyMajorant q M
        ≤ P * Ce * t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2) +
          P * Cs * t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2) +
          P * Cb * t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2) :=
            add_le_add (add_le_add hempty hgoodSmall) hbad
      _ = P * (Ce + Cs + Cb) *
          (t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2)) := by ring
      _ ≤ P * (Cg + Cs + Ce + Cb) *
          (t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2)) := by
            have hc : Ce + Cs + Cb ≤ Cg + Cs + Ce + Cb := by linarith
            exact mul_le_mul_of_nonneg_right
              (mul_le_mul_of_nonneg_left hc hP0) hcommon0
      _ = h2BooleanSecondMomentRateConstant q *
          t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2) := by
            dsimp [P, Cg, Cs, Ce, Cb, h2BooleanSecondMomentRateConstant]
            ring
      _ = _ := by rfl
  · rw [if_neg hj4]
    calc
      h2BooleanEmptyFrequencyMajorant q M +
          h2BooleanGoodFrequencyMajorant M j +
          h2BooleanBadFrequencyMajorant q M
        ≤ P * Ce * t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2) +
          P * Cg * t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2) +
          P * Cb * t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2) :=
            add_le_add (add_le_add hempty hgoodLarge) hbad
      _ = P * (Ce + Cg + Cb) *
          (t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2)) := by ring
      _ ≤ P * (Cg + Cs + Ce + Cb) *
          (t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2)) := by
            have hc : Ce + Cg + Cb ≤ Cg + Cs + Ce + Cb := by linarith
            exact mul_le_mul_of_nonneg_right
              (mul_le_mul_of_nonneg_left hc hP0) hcommon0
      _ = h2BooleanSecondMomentRateConstant q *
          t ^ (h2BooleanX0 - 1) * L ^ (h2BooleanV0 / 2) := by
            dsimp [P, Cg, Cs, Ce, Cb, h2BooleanSecondMomentRateConstant]
            ring
      _ = _ := by rfl

theorem h2BooleanETMomentMajorant_le_rate
    (q M J : ℕ)
    (hM : 3 ≤ M)
    (hlog : 1 ≤ Real.log (M : ℝ))
    (hJ : 1 ≤ J)
    (hdec : Real.exp (-(1 / 8 : ℝ) *
        (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) ≤
      (Real.log (M : ℝ)) ^ (-4 : ℝ)) :
    (1 + Real.log (J : ℝ)) *
        (∑ j ∈ Finset.Icc 1 J,
          h2BooleanFrequencySecondMomentMajorantAll q M j / (j : ℝ)) ≤
      h2BooleanSecondMomentRateConstant q *
        (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
        (1 + Real.log (J : ℝ)) ^ (h2BooleanV0 / 2 + 2) := by
  let A : ℝ := h2BooleanSecondMomentRateConstant q *
    (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1)
  let L : ℝ := 1 + Real.log (J : ℝ)
  have hA0 : 0 ≤ A := mul_nonneg
    (h2BooleanSecondMomentRateConstant_nonneg q)
    (Real.rpow_nonneg (Real.log_nonneg (by
      exact_mod_cast (show 1 ≤ M by omega))) _)
  have hlogJ0 : 0 ≤ Real.log (J : ℝ) :=
    Real.log_nonneg (by exact_mod_cast hJ)
  have hL1 : 1 ≤ L := by dsimp [L]; linarith
  have hL0 : 0 ≤ L := le_trans (by norm_num) hL1
  have hhalf0 : 0 ≤ h2BooleanV0 / 2 :=
    div_nonneg h2BooleanV0_nonneg (by norm_num)
  have hterm : ∀ j ∈ Finset.Icc 1 J,
      h2BooleanFrequencySecondMomentMajorantAll q M j / (j : ℝ) ≤
        A * L ^ (h2BooleanV0 / 2) * ((1 : ℝ) / (j : ℝ)) := by
    intro j hjmem
    have hjbounds := Finset.mem_Icc.mp hjmem
    have hj1 : 1 ≤ j := hjbounds.1
    have hjJ : j ≤ J := hjbounds.2
    have hjpos : (0 : ℝ) < (j : ℝ) := by exact_mod_cast (show 0 < j by omega)
    have hpoint := h2BooleanFrequencySecondMomentMajorantAll_le_rate_exact
      q M j hM hlog hj1 hdec
    have hlogmono : Real.log (j : ℝ) ≤ Real.log (J : ℝ) := by
      apply Real.strictMonoOn_log.monotoneOn
      · show (0 : ℝ) < (j : ℝ); exact_mod_cast (show 0 < j by omega)
      · show (0 : ℝ) < (J : ℝ); exact_mod_cast (show 0 < J by omega)
      · exact_mod_cast hjJ
    have hLj0 : 0 ≤ 1 + Real.log (j : ℝ) := by
      have : 0 ≤ Real.log (j : ℝ) := Real.log_nonneg (by exact_mod_cast hj1)
      linarith
    have hrpow :
        (1 + Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) ≤
          L ^ (h2BooleanV0 / 2) :=
      Real.rpow_le_rpow hLj0 (by dsimp [L]; linarith) hhalf0
    have hpoint' :
        h2BooleanFrequencySecondMomentMajorantAll q M j ≤
          A * L ^ (h2BooleanV0 / 2) := by
      calc
        h2BooleanFrequencySecondMomentMajorantAll q M j
          ≤ A * (1 + Real.log (j : ℝ)) ^ (h2BooleanV0 / 2) := by
              simpa [A] using hpoint
        _ ≤ A * L ^ (h2BooleanV0 / 2) :=
              mul_le_mul_of_nonneg_left hrpow hA0
    calc
      h2BooleanFrequencySecondMomentMajorantAll q M j / (j : ℝ)
        ≤ (A * L ^ (h2BooleanV0 / 2)) / (j : ℝ) :=
          div_le_div_of_nonneg_right hpoint' hjpos.le
      _ = A * L ^ (h2BooleanV0 / 2) * ((1 : ℝ) / (j : ℝ)) := by ring
  have hsum :
      (∑ j ∈ Finset.Icc 1 J,
        h2BooleanFrequencySecondMomentMajorantAll q M j / (j : ℝ)) ≤
      A * L ^ (h2BooleanV0 / 2 + 1) := by
    calc
      (∑ j ∈ Finset.Icc 1 J,
        h2BooleanFrequencySecondMomentMajorantAll q M j / (j : ℝ))
        ≤ ∑ j ∈ Finset.Icc 1 J,
            A * L ^ (h2BooleanV0 / 2) * ((1 : ℝ) / (j : ℝ)) := by
              apply Finset.sum_le_sum
              intro j hj
              exact hterm j hj
      _ = A * L ^ (h2BooleanV0 / 2) *
          (∑ j ∈ Finset.Icc 1 J, (1 : ℝ) / (j : ℝ)) := by
            rw [Finset.mul_sum]
      _ ≤ A * L ^ (h2BooleanV0 / 2) * L := by
            exact mul_le_mul_of_nonneg_left
              (by simpa [L] using frequency_harmonic_factor_le_log J)
              (mul_nonneg hA0 (Real.rpow_nonneg hL0 _))
      _ = A * L ^ (h2BooleanV0 / 2 + 1) := by
            rw [Real.rpow_add (lt_of_lt_of_le zero_lt_one hL1)]
            norm_num
            ring
  calc
    (1 + Real.log (J : ℝ)) *
        (∑ j ∈ Finset.Icc 1 J,
          h2BooleanFrequencySecondMomentMajorantAll q M j / (j : ℝ))
      = L * (∑ j ∈ Finset.Icc 1 J,
          h2BooleanFrequencySecondMomentMajorantAll q M j / (j : ℝ)) := by rfl
    _ ≤ L * (A * L ^ (h2BooleanV0 / 2 + 1)) :=
      mul_le_mul_of_nonneg_left hsum hL0
    _ = A * L ^ (h2BooleanV0 / 2 + 2) := by
      have hLpos : 0 < L := lt_of_lt_of_le zero_lt_one hL1
      have hpow :
          L * L ^ (h2BooleanV0 / 2 + 1) =
            L ^ (h2BooleanV0 / 2 + 2) := by
        calc
          L * L ^ (h2BooleanV0 / 2 + 1)
            = L ^ (1 : ℝ) * L ^ (h2BooleanV0 / 2 + 1) := by
                rw [Real.rpow_one]
          _ = L ^ ((1 : ℝ) + (h2BooleanV0 / 2 + 1)) := by
                rw [← Real.rpow_add hLpos]
          _ = L ^ (h2BooleanV0 / 2 + 2) := by
                congr 1
                ring
      calc
        L * (A * L ^ (h2BooleanV0 / 2 + 1))
          = A * (L * L ^ (h2BooleanV0 / 2 + 1)) := by ring
        _ = A * L ^ (h2BooleanV0 / 2 + 2) := by rw [hpow]
    _ = _ := by rfl

private lemma h2Boolean_sum_range_succ_rpow_le
    (N : ℕ) :
    (∑ i ∈ Finset.range N,
      ((i + 1 : ℕ) : ℝ) ^ (h2BooleanX0 - 1)) ≤
      (N : ℝ) ^ h2BooleanX0 := by
  by_cases hN : N = 0
  · subst N
    simp [Real.zero_rpow h2BooleanX0_pos.ne']
  have hN1 : 1 ≤ N := Nat.one_le_iff_ne_zero.mpr hN
  have hNreal : 1 ≤ (N : ℝ) := by exact_mod_cast hN1
  have hx0 : 0 ≤ h2BooleanX0 - 1 := sub_nonneg.mpr h2BooleanX0_one_le
  calc
    (∑ i ∈ Finset.range N,
      ((i + 1 : ℕ) : ℝ) ^ (h2BooleanX0 - 1))
      ≤ ∑ _i ∈ Finset.range N, (N : ℝ) ^ (h2BooleanX0 - 1) := by
        apply Finset.sum_le_sum
        intro i hi
        have hiN : i + 1 ≤ N := by
          have := Finset.mem_range.mp hi
          omega
        exact Real.rpow_le_rpow (by positivity) (by exact_mod_cast hiN) hx0
    _ = (N : ℝ) * (N : ℝ) ^ (h2BooleanX0 - 1) := by simp
    _ = (N : ℝ) ^ h2BooleanX0 := by
      have hNpos : (0 : ℝ) < (N : ℝ) := by positivity
      calc
        (N : ℝ) * (N : ℝ) ^ (h2BooleanX0 - 1)
          = (N : ℝ) ^ (1 : ℝ) * (N : ℝ) ^ (h2BooleanX0 - 1) := by
              rw [Real.rpow_one]
        _ = (N : ℝ) ^ ((1 : ℝ) + (h2BooleanX0 - 1)) := by
              rw [← Real.rpow_add hNpos]
        _ = (N : ℝ) ^ h2BooleanX0 := by
              congr 1
              ring

/-- Generic quantitative dyadic/logarithmic shell reaggregation.  `i+1`
is the logarithmic shell coordinate; the caller supplies the source-cutoff
relation `N ≤ (log H)^sigma`. -/

theorem h2Boolean_generic_dyadic_reaggregation_le_rate
    (H N : ℕ) (C K : ℝ) (shell : ℕ → ℝ)
    (hHlog : 1 ≤ Real.log (H : ℝ))
    (hNcut : (N : ℝ) ≤ (Real.log (H : ℝ)) ^ h2BooleanSigma)
    (hC : 0 ≤ C) (hK : 0 ≤ K)
    (hshell : ∀ i ∈ Finset.range N,
      shell i ≤
        C * ((i + 1 : ℕ) : ℝ) ^ (h2BooleanX0 - 1) * K) :
    (∑ i ∈ Finset.range N, shell i) ≤
      C * (Real.log (H : ℝ)) ^
          (h2BooleanSigma * h2BooleanX0) * K := by
  have hlogH0 : 0 ≤ Real.log (H : ℝ) := le_trans (by norm_num) hHlog
  have hx0 : 0 ≤ h2BooleanX0 := h2BooleanX0_nonneg
  have hcutpow :
      (N : ℝ) ^ h2BooleanX0 ≤
        ((Real.log (H : ℝ)) ^ h2BooleanSigma) ^ h2BooleanX0 :=
    Real.rpow_le_rpow (by positivity) hNcut hx0
  have hpowid :
      ((Real.log (H : ℝ)) ^ h2BooleanSigma) ^ h2BooleanX0 =
        (Real.log (H : ℝ)) ^ (h2BooleanSigma * h2BooleanX0) := by
    rw [← Real.rpow_mul hlogH0]
  calc
    (∑ i ∈ Finset.range N, shell i)
      ≤ ∑ i ∈ Finset.range N,
          C * ((i + 1 : ℕ) : ℝ) ^ (h2BooleanX0 - 1) * K := by
            apply Finset.sum_le_sum
            intro i hi
            exact hshell i hi
    _ = C * (∑ i ∈ Finset.range N,
          ((i + 1 : ℕ) : ℝ) ^ (h2BooleanX0 - 1)) * K := by
            calc
              (∑ i ∈ Finset.range N,
                C * ((i + 1 : ℕ) : ℝ) ^ (h2BooleanX0 - 1) * K)
                = ∑ i ∈ Finset.range N,
                    (C * K) *
                      ((i + 1 : ℕ) : ℝ) ^ (h2BooleanX0 - 1) := by
                        apply Finset.sum_congr rfl
                        intro i hi
                        ring
              _ = (C * K) * (∑ i ∈ Finset.range N,
                    ((i + 1 : ℕ) : ℝ) ^ (h2BooleanX0 - 1)) := by
                      rw [Finset.mul_sum]
              _ = C * (∑ i ∈ Finset.range N,
                    ((i + 1 : ℕ) : ℝ) ^ (h2BooleanX0 - 1)) * K := by ring
    _ ≤ C * (N : ℝ) ^ h2BooleanX0 * K := by
          exact mul_le_mul_of_nonneg_right
            (mul_le_mul_of_nonneg_left
              (h2Boolean_sum_range_succ_rpow_le N) hC) hK
    _ ≤ C * ((Real.log (H : ℝ)) ^ h2BooleanSigma) ^ h2BooleanX0 * K := by
          exact mul_le_mul_of_nonneg_right
            (mul_le_mul_of_nonneg_left hcutpow hC) hK
    _ = C * (Real.log (H : ℝ)) ^
          (h2BooleanSigma * h2BooleanX0) * K := by rw [hpowid]

#print axioms h2BooleanETMomentMajorant_le_rate
#print axioms h2Boolean_generic_dyadic_reaggregation_le_rate

end PaperB.FixedQ


namespace PaperB.FixedQ

/-- Public threshold form of the Rankin exponential decay used in the H2
rate package. -/
theorem exists_h2Boolean_bad_exp_decay_threshold :
    ∃ M0 : ℕ, ∀ M : ℕ, M0 ≤ M →
      Real.exp (-(1 / 8 : ℝ) *
        (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) ≤
      (Real.log (M : ℝ)) ^ (-4 : ℝ) := by
  simpa only [Filter.eventually_atTop] using
    eventually_h2Boolean_bad_exp_decay

#print axioms exists_h2Boolean_bad_exp_decay_threshold

end PaperB.FixedQ
