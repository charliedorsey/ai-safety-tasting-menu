import GoldB.StepMain

/-!
# GoldB.StepThm — the p-adic step inequality
-/

open Finset Complex

namespace GoldB

theorem vstep (k p N s : ℕ) [hp : Fact p.Prime] (hk2 : 2 ≤ k) (hk : k < p) (hN : 1 ≤ N)
    (hNp : N < p ^ k) :
    (Jc k (s + k) (Icc (1 : ℤ) N) : ℝ) ≤
      max (4 * ((p : ℝ) ^ (2 * s) * ((N : ℝ) ^ k * (k.factorial * (p : ℝ) ^ (k * (k - 1) / 2)) *
          Jc k s (Icc (1 : ℤ) ((N / p + 1 : ℕ) : ℤ)))))
        ((4 * ((k : ℝ) ^ 4 * p * p)) ^ (((s + k : ℕ) : ℝ) / 2) *
          Jc k (s + k) (Icc (1 : ℤ) ((N / p + 1 : ℕ) : ℤ))) := by
  classical
  have hp0 : 0 < p := hp.out.pos
  set T := s + k with hT
  have hT2 : 2 ≤ T := by omega
  set A := Icc (1 : ℤ) N
  set N1 : ℤ := ((N / p + 1 : ℕ) : ℤ)
  set M := T * N ^ k + 1
  have hM0 : 0 < M := Nat.succ_pos _
  have hMT : T * N ^ k < M := Nat.lt_succ_self _
  set f := fS k M A
  set fh : ℕ → (Fin k → Fin M) → ℂ := fun h => fS k M (resc A p h)
  set W := (tup k A).filter (wcd p)
  set I := (tup k A).filter fun x => ¬ wcd p x
  set gW := esum M W (psv k)
  set gI := esum M I (psv k)
  set J := (Jc k T A : ℝ)
  set J1 := (Jc k T (Icc (1 : ℤ) N1) : ℝ)
  set Js := (Jc k s (Icc (1 : ℤ) N1) : ℝ)
  set WC : ℝ := (N : ℝ) ^ k * (k.factorial * (p : ℝ) ^ (k * (k - 1) / 2)) * Js
  have hMk : (0 : ℝ) < (M : ℝ) ^ k := by positivity
  -- membership helpers
  have hA_mem : ∀ x ∈ A, x ∈ Icc (1 : ℤ) N := fun x hx => hx
  have hresc_sub : ∀ h, resc A p h ⊆ A := fun h => filter_subset _ _
  -- (1) J on the grid
  have hJgrid : ∑ a : Fin k → Fin M, ‖f a‖ ^ (2 * T) = (M : ℝ) ^ k * J := by
    apply Jc_eq_grid M hM0 T A
    apply grid_bound_aux hN M T hMT (tup T A) (psv k)
    intro x hx j
    have := psv_range hN x (fun i => Fintype.mem_piFinset.mp hx i) j
    exact ⟨this.1, by exact_mod_cast this.2⟩
  -- splitting f^k
  have hsplit : ∀ a, f a ^ k = gW a + gI a := by
    intro a
    simp only [f, fS, gW, gI]
    rw [← esum_tup]
    exact esum_filter_add M (tup k A) (wcd p) (psv k) a
  -- f as a sum over residue classes
  have hfsum : ∀ a, f a = ∑ h ∈ range p, fh h a := by
    intro a; simp only [f, fh, fS, esum]; exact sum_resc A p hp0 _
  have hfle : ∀ a, ‖f a‖ ≤ ∑ h ∈ range p, ‖fh h a‖ := by
    intro a; rw [hfsum a]; exact norm_sum_le _ _
  -- (2) well-conditioned part
  have hWgrid : ∀ h, ∑ a : Fin k → Fin M, ‖gW a‖ ^ 2 * ‖fh h a‖ ^ (2 * s) ≤ (M : ℝ) ^ k * WC := by
    intro h
    have hb : ∀ x ∈ W ×ˢ tup s (resc A p h), ∀ y ∈ W ×ˢ tup s (resc A p h), ∀ j : Fin k,
        |(fun q : (Fin k → ℤ) × (Fin s → ℤ) => psv k q.1 + psv k q.2) x j -
          (fun q : (Fin k → ℤ) × (Fin s → ℤ) => psv k q.1 + psv k q.2) y j| < M := by
      apply grid_bound_aux hN M T hMT
      intro q hq j
      have := phase_range (k := k) hN k s (W ×ˢ tup s (resc A p h)) (by
        intro q hq
        rw [mem_product] at hq
        exact ⟨fun i => Fintype.mem_piFinset.mp (mem_filter.mp hq.1).1 i,
          fun i => hresc_sub h (Fintype.mem_piFinset.mp hq.2 i)⟩) q hq j
      refine ⟨this.1, ?_⟩
      have e : ((s + k : ℕ) : ℤ) = (T : ℤ) := by simp [hT]
      rw [e] at this; exact this.2
    have hg := grid_count_sq M hM0 (W ×ˢ tup s (resc A p h))
      (fun q => psv k q.1 + psv k q.2) hb
    have hprod : ∀ a, ‖esum M (W ×ˢ tup s (resc A p h)) (fun q => psv k q.1 + psv k q.2) a‖ ^ 2
        = ‖gW a‖ ^ 2 * ‖fh h a‖ ^ (2 * s) := by
      intro a
      rw [esum_product, esum_tup, norm_mul, norm_pow, mul_pow, ← pow_mul, mul_comm s 2]
      rfl
    simp_rw [hprod] at hg
    rw [hg]
    apply mul_le_mul_of_nonneg_left _ hMk.le
    have := NW_le k p N s h hk hNp hN
    simp only at this
    have h2 : ((((W ×ˢ tup s (resc A p h)) ×ˢ (W ×ˢ tup s (resc A p h))).filter fun q =>
        psv k q.1.1 + psv k q.1.2 = psv k q.2.1 + psv k q.2.2).card : ℝ) ≤
        ((N ^ k * (k.factorial * p ^ (k * (k - 1) / 2)) *
          Jc k s (Icc (1 : ℤ) ((N / p + 1 : ℕ) : ℤ)) : ℕ) : ℝ) := by
      exact_mod_cast this
    simpa [WC, Js, N1] using h2
  have hWC : ∑ a : Fin k → Fin M, ‖gW a‖ ^ 2 * ‖f a‖ ^ (2 * s) ≤
      (p : ℝ) ^ (2 * s) * ((M : ℝ) ^ k * WC) := by
    have hcard : ((range p).card : ℝ) = p := by simp
    have hne : (range p).Nonempty := nonempty_range_iff.mpr hp0.ne'
    calc ∑ a : Fin k → Fin M, ‖gW a‖ ^ 2 * ‖f a‖ ^ (2 * s)
        ≤ ∑ a : Fin k → Fin M, ‖gW a‖ ^ 2 *
            (((p : ℝ) ^ (2 * s) / p) * ∑ h ∈ range p, ‖fh h a‖ ^ (2 * s)) := by
          apply sum_le_sum; intro a _
          apply mul_le_mul_of_nonneg_left _ (by positivity)
          calc ‖f a‖ ^ (2 * s) ≤ (∑ h ∈ range p, ‖fh h a‖) ^ (2 * s) :=
                pow_le_pow_left₀ (norm_nonneg _) (hfle a) _
            _ ≤ (((range p).card : ℝ) ^ (2 * s) / (range p).card) *
                  ∑ h ∈ range p, ‖fh h a‖ ^ (2 * s) :=
                pow_sum_le_card_pow_div _ _ (fun _ _ => norm_nonneg _) hne _
            _ = _ := by rw [hcard]
      _ = ((p : ℝ) ^ (2 * s) / p) * ∑ h ∈ range p,
            ∑ a : Fin k → Fin M, ‖gW a‖ ^ 2 * ‖fh h a‖ ^ (2 * s) := by
          simp only [mul_sum]
          rw [sum_comm]
          apply sum_congr rfl; intro h _
          apply sum_congr rfl; intro a _
          ring
      _ ≤ ((p : ℝ) ^ (2 * s) / p) * ∑ _h ∈ range p, (M : ℝ) ^ k * WC := by
          apply mul_le_mul_of_nonneg_left (sum_le_sum (fun h _ => hWgrid h)) (by positivity)
      _ = (p : ℝ) ^ (2 * s) * ((M : ℝ) ^ k * WC) := by
          rw [sum_const, card_range, nsmul_eq_mul]
          have : (p : ℝ) ≠ 0 := by exact_mod_cast hp0.ne'
          field_simp
  -- (3) ill-conditioned part
  have hIb : ∀ x ∈ I ×ˢ tup s A, ∀ y ∈ I ×ˢ tup s A, ∀ j : Fin k,
      |(fun q : (Fin k → ℤ) × (Fin s → ℤ) => psv k q.1 + psv k q.2) x j -
        (fun q : (Fin k → ℤ) × (Fin s → ℤ) => psv k q.1 + psv k q.2) y j| < M := by
    apply grid_bound_aux hN M T hMT
    intro q hq j
    have := phase_range (k := k) hN k s (I ×ˢ tup s A) (by
      intro q hq
      rw [mem_product] at hq
      exact ⟨fun i => Fintype.mem_piFinset.mp (mem_filter.mp hq.1).1 i,
        fun i => Fintype.mem_piFinset.mp hq.2 i⟩) q hq j
    refine ⟨this.1, ?_⟩
    have e : ((s + k : ℕ) : ℤ) = (T : ℤ) := by simp [hT]
    rw [e] at this; exact this.2
  have hIgrid := grid_count_sq M hM0 (I ×ˢ tup s A) (fun q => psv k q.1 + psv k q.2) hIb
  have hIprod : ∀ a, ‖esum M (I ×ˢ tup s A) (fun q => psv k q.1 + psv k q.2) a‖ ^ 2
      = ‖gI a‖ ^ 2 * ‖f a‖ ^ (2 * s) := by
    intro a
    rw [esum_product, esum_tup, norm_mul, norm_pow, mul_pow, ← pow_mul, mul_comm s 2]
    rfl
  simp_rw [hIprod] at hIgrid
  have hNI := NI_grid_le k p N s hk2 hN M (by simpa [hT] using hMT)
  simp only at hNI
  -- Hölder for each residue class
  have hJgrid_h : ∀ h, ∑ a : Fin k → Fin M, ‖fh h a‖ ^ (2 * T) ≤ (M : ℝ) ^ k * J1 := by
    intro h
    have e := Jc_eq_grid M hM0 T (resc A p h) (by
      apply grid_bound_aux hN M T hMT (tup T (resc A p h)) (psv k)
      intro x hx j
      have := psv_range hN x (fun i => hresc_sub h (Fintype.mem_piFinset.mp hx i)) j
      exact ⟨this.1, by exact_mod_cast this.2⟩)
    simp only [fh, fS]
    rw [e]
    apply mul_le_mul_of_nonneg_left _ hMk.le
    exact Nat.cast_le.mpr (Jc_resc_le k T p h N hp0)
  have hJ0 : 0 ≤ J := Nat.cast_nonneg _
  have hJ10 : 0 ≤ J1 := Nat.cast_nonneg _
  have hhold : ∀ h, ∑ a : Fin k → Fin M, ‖fh h a‖ ^ 4 * ‖f a‖ ^ (2 * T - 4) ≤
      (M : ℝ) ^ k * (J1 ^ ((2 : ℝ) / T) * J ^ (1 - (2 : ℝ) / T)) := by
    intro h
    have hh := holder_four (univ : Finset (Fin k → Fin M)) (fun a => ‖fh h a‖) (fun a => ‖f a‖)
      (fun _ => norm_nonneg _) (fun _ => norm_nonneg _) T hT2
    have hT0 : (0 : ℝ) < T := by
      have h2T : (2 : ℝ) ≤ T := by exact_mod_cast hT2
      linarith
    have e1 : (0 : ℝ) ≤ (2 : ℝ) / T := by positivity
    have e2 : (0 : ℝ) ≤ 1 - (2 : ℝ) / T := by
      rw [sub_nonneg, div_le_one hT0]; exact_mod_cast hT2
    calc ∑ a : Fin k → Fin M, ‖fh h a‖ ^ 4 * ‖f a‖ ^ (2 * T - 4)
        ≤ (∑ a : Fin k → Fin M, ‖fh h a‖ ^ (2 * T)) ^ ((2 : ℝ) / T) *
            (∑ a : Fin k → Fin M, ‖f a‖ ^ (2 * T)) ^ (1 - (2 : ℝ) / T) := hh
      _ ≤ ((M : ℝ) ^ k * J1) ^ ((2 : ℝ) / T) * ((M : ℝ) ^ k * J) ^ (1 - (2 : ℝ) / T) := by
          rw [hJgrid]
          apply mul_le_mul_of_nonneg_right _ (Real.rpow_nonneg (mul_nonneg hMk.le hJ0) _)
          exact Real.rpow_le_rpow (sum_nonneg (fun _ _ => by positivity)) (hJgrid_h h) e1
      _ = (M : ℝ) ^ k * (J1 ^ ((2 : ℝ) / T) * J ^ (1 - (2 : ℝ) / T)) := by
          rw [Real.mul_rpow hMk.le hJ10, Real.mul_rpow hMk.le hJ0]
          have : ((M : ℝ) ^ k) ^ ((2 : ℝ) / T) * ((M : ℝ) ^ k) ^ (1 - (2 : ℝ) / T) = (M : ℝ) ^ k := by
            rw [← Real.rpow_add hMk]; simp
          calc ((M : ℝ) ^ k) ^ ((2 : ℝ) / T) * J1 ^ ((2 : ℝ) / T) *
                (((M : ℝ) ^ k) ^ (1 - (2 : ℝ) / T) * J ^ (1 - (2 : ℝ) / T))
              = (((M : ℝ) ^ k) ^ ((2 : ℝ) / T) * ((M : ℝ) ^ k) ^ (1 - (2 : ℝ) / T)) *
                  (J1 ^ ((2 : ℝ) / T) * J ^ (1 - (2 : ℝ) / T)) := by ring
            _ = _ := by rw [this]
  have hIC : ∑ a : Fin k → Fin M, ‖gI a‖ ^ 2 * ‖f a‖ ^ (2 * s) ≤
      ((k : ℝ) ^ 4 * p * p) * ((M : ℝ) ^ k * (J1 ^ ((2 : ℝ) / T) * J ^ (1 - (2 : ℝ) / T))) := by
    rw [hIgrid]
    refine hNI.trans ?_
    calc ((k : ℝ) ^ 4 * p) * ∑ h ∈ range p, ∑ a : Fin k → Fin M,
          ‖fS k M (resc A p h) a‖ ^ 4 * ‖fS k M A a‖ ^ (2 * (s + k) - 4)
        ≤ ((k : ℝ) ^ 4 * p) * ∑ _h ∈ range p,
            (M : ℝ) ^ k * (J1 ^ ((2 : ℝ) / T) * J ^ (1 - (2 : ℝ) / T)) := by
          apply mul_le_mul_of_nonneg_left _ (by positivity)
          apply sum_le_sum; intro h _
          exact hhold h
      _ = _ := by rw [sum_const, card_range, nsmul_eq_mul]; ring
  -- combine
  have hmain : (M : ℝ) ^ k * J ≤ (M : ℝ) ^ k * (2 * ((p : ℝ) ^ (2 * s) * WC) +
      2 * ((k : ℝ) ^ 4 * p * p) * (J1 ^ ((2 : ℝ) / T) * J ^ (1 - (2 : ℝ) / T))) := by
    rw [← hJgrid]
    have hpt : ∀ a : Fin k → Fin M, ‖f a‖ ^ (2 * T) ≤
        2 * (‖gW a‖ ^ 2 * ‖f a‖ ^ (2 * s)) + 2 * (‖gI a‖ ^ 2 * ‖f a‖ ^ (2 * s)) := by
      intro a
      have e : ‖f a‖ ^ (2 * T) = ‖f a ^ k‖ ^ 2 * ‖f a‖ ^ (2 * s) := by
        rw [norm_pow, ← pow_mul, ← pow_add]; congr 1; rw [hT]; ring
      rw [e, hsplit a]
      have := norm_sq_add_le (gW a) (gI a)
      nlinarith [pow_nonneg (norm_nonneg (f a)) (2 * s)]
    calc ∑ a : Fin k → Fin M, ‖f a‖ ^ (2 * T)
        ≤ ∑ a : Fin k → Fin M, (2 * (‖gW a‖ ^ 2 * ‖f a‖ ^ (2 * s)) +
            2 * (‖gI a‖ ^ 2 * ‖f a‖ ^ (2 * s))) := sum_le_sum (fun a _ => hpt a)
      _ = 2 * ∑ a : Fin k → Fin M, ‖gW a‖ ^ 2 * ‖f a‖ ^ (2 * s) +
            2 * ∑ a : Fin k → Fin M, ‖gI a‖ ^ 2 * ‖f a‖ ^ (2 * s) := by
          rw [sum_add_distrib, mul_sum, mul_sum]
      _ ≤ 2 * ((p : ℝ) ^ (2 * s) * ((M : ℝ) ^ k * WC)) +
            2 * (((k : ℝ) ^ 4 * p * p) *
              ((M : ℝ) ^ k * (J1 ^ ((2 : ℝ) / T) * J ^ (1 - (2 : ℝ) / T)))) := by
          gcongr
      _ = _ := by ring
  have hmain' := le_of_mul_le_mul_left hmain hMk
  have hWC0 : 0 ≤ (p : ℝ) ^ (2 * s) * WC := by positivity
  have hab := absorb J ((p : ℝ) ^ (2 * s) * WC) J1 ((k : ℝ) ^ 4 * p * p) T hT2 hJ0 hWC0 hJ10
    (by positivity) (by linarith [hmain'])
  simpa [WC, Js, J, J1, N1, A, hT] using hab

end GoldB
