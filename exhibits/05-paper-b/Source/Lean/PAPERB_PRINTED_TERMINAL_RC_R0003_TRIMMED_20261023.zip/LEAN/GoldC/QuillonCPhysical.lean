import GoldC.QuillonCFinal
import GoldC.QuillonWPhysical

/-!
# Quillon CSC3 F8.10: the **physical region-C theorem** (Parseval-W + VW + Rankin, integrated)

* Rankin helpers:
  - `rankin_prod_le`: `∏_V (1 + p^σ/(p−3)) ≤ (∏_V (1 + 1/(p−3)))³` when `p^σ ≤ 3`;
  - `rankin_σ_ev`: `p^{σ_R} ≤ 3` for `p < X`;
  - `rankin_Lw_ev`: `Lw^{−σ_R} ≤ Λ^{−100}`.
* `C_final`: the C cell for fixed `C` is `≤ Λ^{−30}`.
* `C_physical`: the C part of the actual CORE pair sum at decoration `d` is `≤ Λ^{−15}`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonCPhysical

open GoldC.QuillonEv GoldC.QuillonSetup GoldC.QuillonLam GoldC.QuillonCEv GoldC.QuillonCFinal
  GoldC.QuillonWContext

lemma one_add_le_cube (x : ℝ) (hx : 0 ≤ x) (y : ℝ) (hy : y ≤ 3) (hy0 : 0 ≤ y) :
    1 + y * x ≤ (1 + x) ^ 3 := by
  nlinarith [sq_nonneg x, mul_nonneg hx (sq_nonneg x), mul_le_mul_of_nonneg_right hy hx]

lemma rankin_prod_le (V : Finset ℕ) (hV : ∀ p ∈ V, 5 ≤ p) (σ : ℝ) (hσ : ∀ p ∈ V, (p : ℝ) ^ σ ≤ 3) :
    ∏ p ∈ V, (1 + (p : ℝ) ^ σ / ((p : ℝ) - 3)) ≤ (∏ p ∈ V, (1 + 1 / ((p : ℝ) - 3))) ^ 3 := by
  rw [← prod_pow]
  refine prod_le_prod₀ (fun p hp => ?_) (fun p hp => ?_)
  · have : (5 : ℝ) ≤ p := by exact_mod_cast hV p hp
    have : 0 ≤ (p : ℝ) ^ σ / ((p : ℝ) - 3) := div_nonneg (by positivity) (by linarith)
    linarith
  · have h5 : (5 : ℝ) ≤ p := by exact_mod_cast hV p hp
    have hx : 0 ≤ 1 / ((p : ℝ) - 3) := div_nonneg zero_le_one (by linarith)
    have e : (p : ℝ) ^ σ / ((p : ℝ) - 3) = (p : ℝ) ^ σ * (1 / ((p : ℝ) - 3)) := by ring
    rw [e]
    exact one_add_le_cube _ hx _ (hσ p hp) (by positivity)

/-- `p^{σ_R} ≤ 3` for `p ≤ X`, eventually. -/
theorem rankin_σ_ev :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ h : ℕ, Λ₀ ≤ Real.log h → ∀ p : ℕ, 1 ≤ p → p ≤ Xp h →
      (p : ℝ) ^ σRk h ≤ 3 := by
  obtain ⟨Λ₁, hΛ₁, hpl⟩ := polylog_le 1 (1 / 20) (by norm_num)
  obtain ⟨Λ₂, hΛ₂, hc⟩ := const_le_rpow 400 (1 / 20) (by norm_num)
  refine ⟨max 2 (max Λ₁ Λ₂), le_max_left _ _, fun h hΛ p hp1 hpX => ?_⟩
  set Λ := Real.log h
  have hΛ2 : 2 ≤ Λ := le_trans (le_max_left _ _) hΛ
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  have h1 := hpl Λ (le_trans (le_trans (le_max_left _ _) (le_max_right _ _)) hΛ)
  have h2 := hc Λ (le_trans (le_trans (le_max_right _ _) (le_max_right _ _)) hΛ)
  rw [pow_one] at h1
  have hp0 : (0 : ℝ) < p := by exact_mod_cast hp1
  have hpX' : (p : ℝ) ≤ 2 * Λ ^ (200 : ℝ) := le_trans (by exact_mod_cast hpX) (Xp_le hΛ1)
  have hlogp : Real.log p ≤ 1 + 200 * Real.log Λ := by
    have := Real.log_le_log hp0 hpX'
    rw [Real.log_mul (by norm_num) (by positivity), Real.log_rpow hΛ0] at this
    have : Real.log 2 < 1 := by have := Real.log_two_lt_d9; linarith
    linarith
  have hlogΛ : 0 ≤ Real.log Λ := Real.log_nonneg hΛ1
  have hkey : σRk h * Real.log p ≤ 1 := by
    unfold σRk
    have hs : 0 < Λ ^ (-(1 / 10 : ℝ)) := by positivity
    have hb : 1 + 200 * Real.log Λ ≤ Λ ^ (1 / 10 : ℝ) := by
      have e : Λ ^ (1 / 10 : ℝ) = Λ ^ (1 / 20 : ℝ) * Λ ^ (1 / 20 : ℝ) := by rw [rp hΛ0]; norm_num
      rw [e]
      have h0 : 0 ≤ Λ ^ (1 / 20 : ℝ) := by positivity
      nlinarith
    have e2 : Λ ^ (-(1 / 10 : ℝ)) * Λ ^ (1 / 10 : ℝ) = 1 := by rw [rp hΛ0]; norm_num
    calc Λ ^ (-(1 / 10 : ℝ)) * Real.log p ≤ Λ ^ (-(1 / 10 : ℝ)) * Λ ^ (1 / 10 : ℝ) :=
          mul_le_mul_of_nonneg_left (le_trans hlogp hb) hs.le
      _ = 1 := e2
  calc (p : ℝ) ^ σRk h = Real.exp (Real.log p * σRk h) := Real.rpow_def_of_pos hp0 _
    _ ≤ Real.exp 1 := Real.exp_le_exp.2 (by linarith)
    _ ≤ 3 := by have := Real.exp_one_lt_d9; linarith

/-- `Lw^{−σ_R} ≤ Λ^{−100}` for `Lw ≥ √s`, `log s ≥ 5Λ^σ`. -/
theorem rankin_Lw_ev :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ h : ℕ, Λ₀ ≤ Real.log h → ∀ (s Lw : ℝ), 1 ≤ s →
      5 * (Real.log h) ^ σ₀ ≤ Real.log s → Real.sqrt s ≤ Lw →
      Lw ^ (-(σRk h)) ≤ (Real.log h) ^ (-(100 : ℝ)) := by
  have hτ : 0 < σ₀ - 1 / 10 := by unfold σ₀; norm_num
  obtain ⟨Λ₀, hΛ₀, hd⟩ := decay 0 100 (5 / 2) (σ₀ - 1 / 10) (by norm_num) (by norm_num) hτ
  refine ⟨max 2 Λ₀, le_max_left _ _, fun h hΛ s Lw hs1 hlog hLw => ?_⟩
  set Λ := Real.log h
  have hΛ2 : 2 ≤ Λ := le_trans (le_max_left _ _) hΛ
  have hΛ0 : 0 < Λ := by linarith
  have h1 := hd Λ (le_trans (le_max_right _ _) hΛ)
  rw [Real.rpow_zero, one_mul] at h1
  have hsq0 : 0 < Real.sqrt s := Real.sqrt_pos.2 (by linarith)
  have hLw0 : 0 < Lw := lt_of_lt_of_le hsq0 hLw
  have hlogLw : Real.log s / 2 ≤ Real.log Lw := by
    have := Real.log_le_log hsq0 hLw
    rw [Real.log_sqrt (by linarith)] at this; exact this
  have hσ0 : 0 ≤ σRk h := by unfold σRk; positivity
  have he : σRk h * (5 * Λ ^ σ₀ / 2) = 5 / 2 * Λ ^ (σ₀ - 1 / 10) := by
    unfold σRk
    have : Λ ^ (-(1 / 10 : ℝ)) * Λ ^ σ₀ = Λ ^ (σ₀ - 1 / 10) := by rw [rp hΛ0]; ring_nf
    rw [← this]; ring
  calc Lw ^ (-(σRk h)) = Real.exp (-(σRk h) * Real.log Lw) := by rw [Real.rpow_def_of_pos hLw0]; ring_nf
    _ ≤ Real.exp (-(5 / 2 * Λ ^ (σ₀ - 1 / 10))) := by
        apply Real.exp_le_exp.2
        rw [← he]
        have : 5 * Λ ^ σ₀ / 2 ≤ Real.log Lw := by linarith
        nlinarith [mul_le_mul_of_nonneg_left this hσ0]
    _ ≤ Λ ^ (-(100 : ℝ)) := h1


lemma εp_le_one {h : ℕ} (hΛ : 1 ≤ Real.log h) : 0 ≤ εp h ∧ εp h ≤ 1 := by
  unfold εp
  exact ⟨by positivity, Real.rpow_le_one_of_one_le_of_nonpos hΛ (by norm_num)⟩

/-- facts about `Lw_C = ⌊s^{1+ε}⌋ − 1`. -/
lemma LwC_facts (h s : ℕ) (hΛ : 1 ≤ Real.log h) (hs4 : (4 : ℝ) ≤ s) :
    (s : ℝ) ^ (1 + εp h) / 2 ≤ (LwC h s : ℝ) ∧ (LwC h s : ℝ) ≤ (s : ℝ) ^ 2 ∧
      Real.sqrt s ≤ (LwC h s : ℝ) := by
  obtain ⟨he0, he1⟩ := εp_le_one hΛ
  have hs1 : (1 : ℝ) ≤ s := by linarith
  have hsle : (s : ℝ) ≤ (s : ℝ) ^ (1 + εp h) := by
    calc (s : ℝ) = (s : ℝ) ^ (1 : ℝ) := (Real.rpow_one _).symm
      _ ≤ (s : ℝ) ^ (1 + εp h) := Real.rpow_le_rpow_of_exponent_le hs1 (by linarith)
  have hsup : (s : ℝ) ^ (1 + εp h) ≤ (s : ℝ) ^ 2 := by
    calc (s : ℝ) ^ (1 + εp h) ≤ (s : ℝ) ^ (2 : ℝ) := Real.rpow_le_rpow_of_exponent_le hs1 (by linarith)
      _ = (s : ℝ) ^ 2 := by norm_num
  have hfl := Nat.floor_le (show 0 ≤ (s : ℝ) ^ (1 + εp h) by positivity)
  have hfl2 := Nat.lt_floor_add_one ((s : ℝ) ^ (1 + εp h))
  have hge : (s : ℝ) ^ (1 + εp h) - 2 ≤ (LwC h s : ℝ) := by
    unfold LwC
    rcases Nat.eq_zero_or_pos ⌊(s : ℝ) ^ (1 + εp h)⌋₊ with h0 | hpos
    · rw [h0] at hfl2; push_cast at hfl2; linarith
    · rw [Nat.cast_sub hpos]; push_cast; linarith
  have hle : (LwC h s : ℝ) ≤ (s : ℝ) ^ (1 + εp h) := by
    unfold LwC
    have : ((⌊(s : ℝ) ^ (1 + εp h)⌋₊ - 1 : ℕ) : ℝ) ≤ (⌊(s : ℝ) ^ (1 + εp h)⌋₊ : ℝ) := by
      exact_mod_cast Nat.sub_le _ _
    linarith
  refine ⟨by linarith, le_trans hle hsup, ?_⟩
  have hsq : Real.sqrt s ≤ (s : ℝ) / 2 := by
    rw [Real.sqrt_le_left (by positivity)]
    nlinarith
  linarith

lemma LwC_lt {h H : ℕ} {δ : ℝ} {r s : ℕ} (hr : 1 ≤ r) (hG : (s : ℝ) ^ (1 + εp h) ≤ r) : LwC h s < r := by
  have : ⌊(s : ℝ) ^ (1 + εp h)⌋₊ ≤ r := Nat.floor_le_of_le hG
  unfold LwC; omega

lemma div8_facts (Λ s : ℝ) (q : ℕ) (hΛ : 200000 ≤ Λ) (hq : (6 * q + 7 : ℝ) ≤ Λ)
    (hsΛ : Λ ^ (3000 : ℝ) ≤ s) :
    (6 * q + 7 : ℝ) ≤ s / (8 * Λ ^ (200 : ℝ)) ∧ s ^ (1 / 8 : ℝ) ≤ s / (8 * Λ ^ (200 : ℝ)) := by
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  have hs0 : 0 < s := lt_of_lt_of_le (by positivity) hsΛ
  have hp : 0 < Λ ^ (200 : ℝ) := by positivity
  constructor
  · rw [le_div_iff₀ (by positivity)]
    have e3 : Λ ^ (3000 : ℝ) = Λ ^ (1 : ℝ) * Λ ^ (200 : ℝ) * Λ ^ (2799 : ℝ) := by
      rw [rp hΛ0, rp hΛ0]; norm_num
    have hb8 : (8 : ℝ) ≤ Λ ^ (2799 : ℝ) := le_trans (by linarith) (le_rpow_big Λ hΛ1 2799 (by norm_num))
    rw [e3, Real.rpow_one] at hsΛ
    calc (6 * q + 7 : ℝ) * (8 * Λ ^ (200 : ℝ)) ≤ Λ * (8 * Λ ^ (200 : ℝ)) :=
          mul_le_mul_of_nonneg_right hq (by positivity)
      _ ≤ Λ * (Λ ^ (2799 : ℝ) * Λ ^ (200 : ℝ)) :=
          mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right hb8 hp.le) hΛ0.le
      _ = Λ * Λ ^ (200 : ℝ) * Λ ^ (2799 : ℝ) := by ring
      _ ≤ s := hsΛ
  · rw [le_div_iff₀ (by positivity)]
    -- `8Λ^{200} ≤ s^{7/8}` since `s ≥ Λ^{3000}`
    have h1 : 8 * Λ ^ (200 : ℝ) ≤ s ^ (7 / 8 : ℝ) := by
      have h2 : (Λ ^ (3000 : ℝ)) ^ (7 / 8 : ℝ) ≤ s ^ (7 / 8 : ℝ) :=
        Real.rpow_le_rpow (by positivity) hsΛ (by norm_num)
      rw [← Real.rpow_mul hΛ0.le] at h2
      have e : Λ ^ ((3000 : ℝ) * (7 / 8)) = Λ ^ (200 : ℝ) * Λ ^ (2425 : ℝ) := by rw [rp hΛ0]; norm_num
      rw [e] at h2
      have hb8 : (8 : ℝ) ≤ Λ ^ (2425 : ℝ) := le_trans (by linarith) (le_rpow_big Λ hΛ1 2425 (by norm_num))
      nlinarith
    have e : s = s ^ (1 / 8 : ℝ) * s ^ (7 / 8 : ℝ) := by rw [rp hs0]; norm_num
    have : 0 ≤ s ^ (1 / 8 : ℝ) := by positivity
    calc s ^ (1 / 8 : ℝ) * (8 * Λ ^ (200 : ℝ)) ≤ s ^ (1 / 8 : ℝ) * s ^ (7 / 8 : ℝ) :=
          mul_le_mul_of_nonneg_left h1 this
      _ = s := e.symm


/-- the final real combination for `C_final`. -/
lemma Cfin_combine (Λ K1 Φ F L P E : ℝ) (hΛ2 : 2 ≤ Λ) (hK10 : 0 ≤ K1) (hK1 : K1 ≤ 5 * Λ)
    (hΦ : Φ = 4 * Λ ^ (-(40 : ℝ))) (hF0 : 0 ≤ F) (hL0 : 0 ≤ L) (hL : L ≤ Λ ^ (-(100 : ℝ)))
    (hP0 : 0 ≤ P) (hP : P ≤ (E * Λ ^ (10 : ℝ)) ^ 3) (hE : 0 ≤ E)
    (hK : 20 + F * E ^ 3 ≤ Λ) :
    K1 * Φ + F * (L * P) ≤ Λ ^ (-(30 : ℝ)) := by
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  have e1 : (E * Λ ^ (10 : ℝ)) ^ 3 = E ^ 3 * Λ ^ (30 : ℝ) := by
    rw [mul_pow, ← Real.rpow_natCast (Λ ^ (10 : ℝ)) 3, ← Real.rpow_mul hΛ0.le]; norm_num
  have t1 : K1 * Φ ≤ 20 * Λ ^ (-(39 : ℝ)) := by
    rw [hΦ]
    calc K1 * (4 * Λ ^ (-(40 : ℝ))) ≤ (5 * Λ) * (4 * Λ ^ (-(40 : ℝ))) :=
          mul_le_mul_of_nonneg_right hK1 (by positivity)
      _ = 20 * (Λ ^ (1 : ℝ) * Λ ^ (-(40 : ℝ))) := by rw [Real.rpow_one]; ring
      _ = 20 * Λ ^ (-(39 : ℝ)) := by rw [rp hΛ0]; norm_num
  have t2 : F * (L * P) ≤ F * E ^ 3 * Λ ^ (-(39 : ℝ)) := by
    calc F * (L * P) ≤ F * (Λ ^ (-(100 : ℝ)) * (E ^ 3 * Λ ^ (30 : ℝ))) := by
          gcongr; rw [← e1]; exact hP
      _ = F * E ^ 3 * (Λ ^ (-(100 : ℝ)) * Λ ^ (30 : ℝ)) := by ring
      _ = F * E ^ 3 * Λ ^ (-(70 : ℝ)) := by rw [rp hΛ0]; norm_num
      _ ≤ F * E ^ 3 * Λ ^ (-(39 : ℝ)) :=
          mul_le_mul_of_nonneg_left (Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)) (by positivity)
  have p39 : 0 ≤ Λ ^ (-(39 : ℝ)) := by positivity
  calc K1 * Φ + F * (L * P) ≤ (20 + F * E ^ 3) * Λ ^ (-(39 : ℝ)) := by linarith
    _ ≤ Λ * Λ ^ (-(39 : ℝ)) := mul_le_mul_of_nonneg_right hK p39
    _ = Λ ^ (-(38 : ℝ)) := by
        rw [show Λ * Λ ^ (-(39 : ℝ)) = Λ ^ (1 : ℝ) * Λ ^ (-(39 : ℝ)) by rw [Real.rpow_one], rp hΛ0]
        norm_num
    _ ≤ Λ ^ (-(30 : ℝ)) := Real.rpow_le_rpow_of_exponent_le hΛ1 (by norm_num)

open Classical in
set_option maxHeartbeats 8000000 in
/-- **The region-C cell for a fixed `C` is `≤ Λ^{−30}`**, eventually in `h`, uniformly. -/
theorem C_final (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (a h H D : ℕ) (T C E0 : Finset ℕ) (Kc : ℕ → Prop) [DecidablePred Kc],
      Λ₀ ≤ Real.log h → 2 ≤ h → H ≤ h →
      (∀ p ∈ T, p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q ∧ p.Coprime H ∧ p ≤ H ^ 2) →
      (∀ p, p.Prime → 5 ≤ p → p ≤ H ^ 2 → p ∉ T → p ∈ E0) →
      ((E0.card + C.card : ℕ) : ℝ) ≤ (Real.log h) ^ 2 → C ⊆ T →
      |∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
          (if (Kc B.card ∧ (Geo0 h H δ (∏ p ∈ B, p) (∏ p ∈ C, p) ∧
                ((∏ p ∈ C, p : ℕ) : ℝ) ^ (1 + εp h) ≤ ((∏ p ∈ B, p : ℕ) : ℝ))) ∧
              ¬ (B ∩ (T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ Yp δ (∏ p ∈ C, p))).Nonempty
            then ωR B * GoldC.QuillonCopyF.foldRow q a D H (∏ p ∈ B, p) (∏ p ∈ C, p) else 0)| ≤
        (Real.log h) ^ (-(30 : ℝ)) := by
  have ha0 := a0_pos hδ0 hδ1
  have ha0' := a0_le hδ0
  have hu0 : 0 < u0 δ := by unfold u0; linarith
  have hu1 : u0 δ ≤ 1 / 8 := by unfold u0; linarith
  set E : ℝ := Real.exp 10 * (2 * 2 + 1) ^ 10 with hE
  set Fm : ℝ := 4 + 48 * q with hFm
  obtain ⟨Λ₁, hΛ₁, hCT⟩ := CTerm_ev q hq δ hδ0 hδ1
  obtain ⟨Λ₂, hΛ₂, hτ⟩ := GoldC.QuillonEv.sdecay 2 (u0 δ / 8) 3000 (by positivity) (by norm_num)
  obtain ⟨Λ₃, hΛ₃, hsl⟩ := s_large (2 ^ (16 / u0 δ))
  obtain ⟨Λ₄, hΛ₄, hrσ⟩ := rankin_σ_ev
  obtain ⟨Λ₅, hΛ₅, hrL⟩ := rankin_Lw_ev
  obtain ⟨Λ₆, hΛ₆, hK⟩ := const_le_rpow (20 + Fm * E ^ 3 + 6 * q + 7 + 200000) 1 one_pos
  refine ⟨max Λ₁ (max Λ₂ (max Λ₃ (max Λ₄ (max Λ₅ Λ₆)))), le_trans hΛ₁ (le_max_left _ _), ?_⟩
  intro a h H D T C E0 Kc _ hΛ hh hHh hT hE0 hEc hCT'
  have L1 : Λ₁ ≤ Real.log h := le_trans (by simp) hΛ
  have L2 : Λ₂ ≤ Real.log h := le_trans (by simp) hΛ
  have L3 : Λ₃ ≤ Real.log h := le_trans (by simp) hΛ
  have L4 : Λ₄ ≤ Real.log h := le_trans (by simp) hΛ
  have L5 : Λ₅ ≤ Real.log h := le_trans (by simp) hΛ
  have L6 : Λ₆ ≤ Real.log h := le_trans (by simp) hΛ
  clear hΛ
  set Λ := Real.log h with hΛdef
  have hΛ2 : 2 ≤ Λ := le_trans hΛ₁ L1
  have hΛ0 : 0 < Λ := by linarith
  have hΛ1 : 1 ≤ Λ := by linarith
  have hKΛ := hK Λ L6
  rw [Real.rpow_one] at hKΛ
  have hFm0 : 0 ≤ Fm := by positivity
  have hE0' : 0 ≤ E := by positivity
  have hΛbig : 200000 ≤ Λ := by
    have : 0 ≤ 20 + Fm * E ^ 3 + 6 * q + 7 := by positivity
    linarith
  have hq7 : (6 * q + 7 : ℝ) ≤ Λ := by
    have : 0 ≤ 20 + Fm * E ^ 3 + 200000 := by positivity
    linarith
  have hKfin : 20 + Fm * E ^ 3 ≤ Λ := by
    have : (0 : ℝ) ≤ 6 * q + 7 + 200000 := by positivity
    linarith
  set s := ∏ p ∈ C, p with hs
  have hpos30 : 0 ≤ Λ ^ (-(30 : ℝ)) := by positivity
  by_cases hex : ∃ r, Geo0 h H δ r s ∧ (s : ℝ) ^ (1 + εp h) ≤ (r : ℝ)
  swap
  · push_neg at hex
    rw [sum_eq_zero fun B _ => by
      rw [if_neg]; rintro ⟨⟨-, hg1, hg2⟩, -⟩; exact absurd hg2 (not_le.2 (hex _ hg1)), abs_zero]
    exact hpos30
  obtain ⟨r₀, hr₀, -⟩ := hex
  obtain ⟨hlogs, -, hr1, hs1n, -, hsh, -, -, hrsH⟩ := adm h H r₀ s δ hδ0 hδ1 hh hHh hr₀
  have hCp : ∀ p ∈ C, p.Prime := fun p hp => (hT p (hCT' hp)).1
  have hspos : 0 < s := prod_pos fun p hp => (hCp p hp).pos
  have hs0 : (0 : ℝ) < s := by exact_mod_cast hspos
  have hτΛ := hτ Λ L2 s hs0 hlogs
  obtain ⟨hs65, hs1, hsu2, hsΛ⟩ := s_facts Λ s (u0 δ) (u0 δ / 8) hΛ2 hu0 hu1 (by linarith)
    (hsl Λ L3 s hs0 hlogs) hτΛ
  have hs2 : 2 ≤ s := by
    have : (2 : ℝ) ≤ s := by linarith
    exact_mod_cast this
  haveI : NeZero s := ⟨by omega⟩
  haveI : NeZero (6 * q) := ⟨by omega⟩
  -- `s ≤ H`
  have hsH : (s : ℝ) ≤ H := by
    have hE1 : 1 ≤ Real.exp (Λ ^ (1 / 4 : ℝ)) := Real.one_le_exp (by positivity)
    have hr1R : (1 : ℝ) ≤ r₀ := by exact_mod_cast hr1
    calc (s : ℝ) ≤ ((r₀ : ℝ) * s) * Real.exp (Λ ^ (1 / 4 : ℝ)) := by
          have : (s : ℝ) ≤ (r₀ : ℝ) * s := le_mul_of_one_le_left hs0.le hr1R
          exact le_trans this (le_mul_of_one_le_right (by positivity) hE1)
      _ ≤ H := hrsH
  have hH1 : (1 : ℝ) ≤ H := by linarith
  -- `Lw`
  obtain ⟨hLwlo, hLwhi, hLwsq⟩ := LwC_facts h s hΛ1 (by linarith)
  have hLwH : LwC h s ≤ H ^ 2 := by
    have : (LwC h s : ℝ) ≤ (H : ℝ) ^ 2 := le_trans hLwhi (pow_le_pow_left₀ hs0.le hsH 2)
    exact_mod_cast this
  have hmax : max (H ^ 2) (LwC h s) = H ^ 2 := max_eq_left hLwH
  -- `X`, `Y`
  have hXge := Xp_ge (h := h) hΛ1
  have hXle := Xp_le (h := h) hΛ1
  have hX2 : 2 ≤ Xp h := Xp_two hΛ2
  have hX1 : 1 ≤ Xp h := by omega
  have hY4 : 4 ≤ Yp δ s := by
    unfold Yp; apply Nat.le_floor; push_cast
    have h16 : (2 : ℝ) ^ (16 / u0 δ) ≤ s := hsl Λ L3 s hs0 hlogs
    calc (4 : ℝ) ≤ 2 ^ (16 : ℝ) := by norm_num
      _ = ((2 : ℝ) ^ (16 / u0 δ)) ^ u0 δ := by
          rw [← Real.rpow_mul (by norm_num), div_mul_cancel₀ _ hu0.ne']
      _ ≤ (s : ℝ) ^ u0 δ := Real.rpow_le_rpow (by positivity) h16 hu0.le
  have hYs : (Yp δ s : ℝ) ≤ (s : ℝ) ^ (1 / 8 : ℝ) :=
    le_trans (Yp_le δ s) (Real.rpow_le_rpow_of_exponent_le hs1 hu1)
  -- `Lw/X`
  have hLwX := aX_fact Λ s (LwC h s) (Xp h) hΛbig hX1 hXle (by
    have : (s : ℝ) ≤ (s : ℝ) ^ (1 + εp h) := by
      calc (s : ℝ) = (s : ℝ) ^ (1 : ℝ) := (Real.rpow_one _).symm
        _ ≤ _ := Real.rpow_le_rpow_of_exponent_le hs1 (by linarith [(εp_le_one hΛ1).1])
    linarith) hsΛ
  obtain ⟨hd1, hd2⟩ := div8_facts Λ s q hΛbig hq7 hsΛ
  have hUvs : (Uvp s : ℝ) ≤ (s : ℝ) ^ (1 / 8 : ℝ) := by
    have : (Uvp s : ℝ) ≤ (s : ℝ) ^ (1 / 16 : ℝ) := Nat.floor_le (by positivity)
    exact le_trans this (Real.rpow_le_rpow_of_exponent_le hs1 (by norm_num))
  have hLwM : 6 * q < LwC h s / Xp h := by
    have : (6 * q : ℝ) < ((LwC h s / Xp h : ℕ) : ℝ) := by linarith
    exact_mod_cast this
  have hLw6 : 6 ≤ LwC h s / Xp h := by
    have : (6 : ℝ) ≤ ((LwC h s / Xp h : ℕ) : ℝ) := by
      have : (0 : ℝ) ≤ q := by positivity
      linarith
    exact_mod_cast this
  have hLwV : Uvp s ≤ LwC h s / Xp h := by
    have : (Uvp s : ℝ) ≤ ((LwC h s / Xp h : ℕ) : ℝ) := by linarith
    exact_mod_cast this
  have hLwY : Yp δ s ≤ LwC h s / Xp h := by
    have : (Yp δ s : ℝ) ≤ ((LwC h s / Xp h : ℕ) : ℝ) := by linarith
    exact_mod_cast this
  -- source data
  have hTc : ∀ p ∈ T, p.Prime ∧ 5 ≤ p ∧ p.Coprime (6 * q) ∧ p.Coprime H := fun p hp =>
    ⟨(hT p hp).1, (hT p hp).2.1, GoldC.QuillonWFinal.coprime_6q (hT p hp).1 (hT p hp).2.1 (hT p hp).2.2.1,
      (hT p hp).2.2.2.1⟩
  have hsM : s.Coprime (6 * q) :=
    GoldC.QuillonWFinal.prod_coprime_of fun p hp => (hTc p (hCT' hp)).2.2.1
  set μ := GoldC.QuillonCopyF.meanWeight q (GoldC.QuillonCopyF.reducedAnchor q a D) H with hμ
  set Γ := GoldC.QuillonCopyF.gammaClass q a D H with hΓ
  have hμb : |μ| ≤ 4 := by
    have := GoldC.QuillonCopyF.meanWeight_bounds q (GoldC.QuillonCopyF.reducedAnchor q a D) H
    rw [abs_le]; constructor <;> linarith
  have hΓb : ∀ b ν, |Γ b ν| ≤ 48 * q := fun b ν => by
    have := GoldC.QuillonCopyF.abs_gammaClass_le q a D H b ν hq
    have e : (8 : ℝ) * (6 * q) = 48 * q := by ring
    linarith
  have hshn : s ≤ h := by exact_mod_cast hsh
  have hU' : ∀ p ∈ (T \ C).filter (fun p => ¬ (Xp h ≤ p ∧ p ≤ Yp δ s)), p.Prime ∧ 5 ≤ p ∧ p ≤ H ^ 2 :=
    fun p hp => have hpT := sdiff_subset (filter_subset _ _ hp)
      ⟨(hT p hpT).1, (hT p hpT).2.1, (hT p hpT).2.2.2.2⟩
  have hCH : ∀ p ∈ C, p.Prime ∧ p.Coprime H := fun p hp => ⟨hCp p hp, (hT p (hCT' hp)).2.2.2.1⟩
  have hs1' : 1 ≤ s := by omega
  have hEc' : ((E0.card + C.card : ℕ) : ℝ) ≤ Λ ^ 2 := hEc
  -- the cell
  have hcell := GoldC.QuillonCCellApp.C_cell (s := s) (M := 6 * q) (by omega) H μ Γ T C hTc hCT' rfl hs2
    (Xp h) (Yp δ s) hX2 (by omega) Kc (fun r => Geo0 h H δ r s ∧ (s : ℝ) ^ (1 + εp h) ≤ (r : ℝ))
    (H ^ 2) (LwC h s)
    (fun r hG => by
      have h4 := hG.1.2.1
      have : r ≤ r * s := Nat.le_mul_of_pos_right r hspos
      omega)
    (fun r hG => by
      have hr1 : 1 ≤ r := by
        have := hG.1.1
        rcases Nat.eq_zero_or_pos r with h0 | h0
        · rw [h0] at this; simp at this
        · exact h0
      exact LwC_lt (H := H) (δ := δ) hr1 hG.2)
    (fun x y z hxy hyz hx hz => ⟨geo0_convex_r h H δ hδ0.le s x y z hxy hyz hx.1 hz.1,
      le_trans hx.2 (by exact_mod_cast hxy)⟩)
    (fun r => GoldC.QuillonCopyF.foldRow q a D H r s)
    (fun B hB hne _ => by
      have hBp : ∀ p ∈ B, p.Prime ∧ 5 ≤ p := fun p hp =>
        ⟨(hT p (sdiff_subset (hB hp))).1, (hT p (sdiff_subset (hB hp))).2.1⟩
      obtain ⟨p, hp⟩ := nonempty_iff_ne_empty.2 hne
      have hr2 : 2 ≤ ∏ p ∈ B, p := by
        have h1 : p ∣ ∏ p ∈ B, p := dvd_prod_of_mem _ hp
        have h2 : 0 < ∏ p ∈ B, p := prod_pos fun p hp => (hBp p hp).1.pos
        have := Nat.le_of_dvd h2 h1
        have := (hBp p hp).2; omega
      exact GoldC.QuillonBridge.foldRow_eq_rowAbs q a D H _ s hq hr2 hs2
        (GoldC.QuillonWFinal.prod_coprime_of fun p hp => (hTc p (sdiff_subset (hB hp))).2.2.1) hsM)
    Fm hFm0 (fun B _ _ => GoldC.QuillonBridge.abs_foldRow_le q a D H _ s hq)
    (6 * q * h) (by nlinarith) (Tpp h) (Uvp s) (Uvp s) (Tvp h)
    (by have : (2 : ℝ) ≤ Tpp h := le_trans (le_trans hΛ2 (le_rpow_big Λ hΛ1 100 (by norm_num)))
          (Tpp_bounds hΛ1).1
        exact_mod_cast this)
    (Uv_b_facts s s hs65 (by linarith)).1
    (by have : (2 : ℝ) ≤ Tvp h := le_trans (le_trans hΛ2 (le_rpow_big Λ hΛ1 600 (by norm_num)))
          (Tvp_bounds hΛ1).1
        exact_mod_cast this)
    (E0 ∪ C) (E0.card + C.card) (card_union_le _ _)
    (fun p hp hYp hpN hpT => by
      rw [hmax] at hpN
      have hp5 : 5 ≤ p := by omega
      by_cases hpC : p ∈ C
      · exact mem_union_right _ hpC
      · apply mem_union_left
        apply hE0 p hp hp5 hpN
        intro hpT'
        exact hpT (mem_filter.2 ⟨mem_sdiff.2 ⟨hpT', hpC⟩, hYp⟩))
    hLwM hLw6 hLwV hLwY (σRk h) (by unfold σRk; positivity) (4 * Λ ^ (-(40 : ℝ))) (by positivity)
    (fun a' b' ha' hab' hb2' hbN => by
      rw [hmax] at hbN
      unfold GoldC.QuillonCCellApp.CSum4
      have ha'' : (s : ℝ) ^ (1 + εp h) / 2 ≤ a' := le_trans hLwlo (by exact_mod_cast ha')
      have c1 := hCT h H L1 hHh s (6 * q) C _ ((T \ C).filter (fun p => Yp δ s < p)) hCp rfl rfl hlogs hU'
        (fun (_ : ZMod (6 * q)) k => ((-(2 * μ) : ℝ) : ℂ) * GoldC.QuillonRowNF.αm k s)
        (fun k => ((((k : ℤ) * H : ℤ)) : ZMod s))
        (fun ρ j hj => GoldC.QuillonRowFacts.coef_main q hq μ hμb s hs1' (6 * q) ρ j hj)
        (GoldC.QuillonRowFacts.hc_gen C hCp rfl (H : ℤ) (GoldC.QuillonRowFacts.not_dvd_H hCH) 1
          (Or.inl rfl) _ (fun j => by congr 1; ring))
        (E0.card + C.card) a' b' hEc' ha'' hab' hb2' hbN
      have c2 := hCT h H L1 hHh s (6 * q) C _ ((T \ C).filter (fun p => Yp δ s < p)) hCp rfl rfl hlogs hU'
        (fun (_ : ZMod (6 * q)) k => -(((-(2 * μ) : ℝ) : ℂ) * GoldC.QuillonRowNF.αm k s))
        (fun k => ((((-(k : ℤ)) * H : ℤ)) : ZMod s))
        (fun ρ j hj => GoldC.QuillonRowFacts.coef_mainN q hq μ hμb s hs1' (6 * q) ρ j hj)
        (GoldC.QuillonRowFacts.hc_gen C hCp rfl (H : ℤ) (GoldC.QuillonRowFacts.not_dvd_H hCH) (-1)
          (Or.inr rfl) _ (fun j => by congr 1; ring))
        (E0.card + C.card) a' b' hEc' ha'' hab' hb2' hbN
      have c3 := hCT h H L1 hHh s (6 * q) C _ ((T \ C).filter (fun p => Yp δ s < p)) hCp rfl rfl hlogs hU'
        (fun (ρ : ZMod (6 * q)) k => GoldC.QuillonRowNF.αm k ((6 * q) * s) *
          GoldC.QuillonRowNF.BclS (6 * q) Γ s (k : ℤ) ρ)
        (fun k => ((((k : ℤ) * H * GoldC.QuillonCopyC.invMod (6 * q) s : ℤ)) : ZMod s))
        (fun ρ j hj => GoldC.QuillonRowFacts.coef_cls q hq Γ hΓb s hs1' (fun k => (k : ℤ)) ρ j hj)
        (GoldC.QuillonRowFacts.hc_gen C hCp rfl _
          (GoldC.QuillonRowFacts.not_dvd_HinvM hCH rfl hs2 hsM.symm) 1 (Or.inl rfl) _
          (fun j => by congr 1; ring))
        (E0.card + C.card) a' b' hEc' ha'' hab' hb2' hbN
      have c4 := hCT h H L1 hHh s (6 * q) C _ ((T \ C).filter (fun p => Yp δ s < p)) hCp rfl rfl hlogs hU'
        (fun (ρ : ZMod (6 * q)) k => -(GoldC.QuillonRowNF.αm k ((6 * q) * s) *
          GoldC.QuillonRowNF.BclS (6 * q) Γ s (-(k : ℤ)) ρ))
        (fun k => ((((-(k : ℤ)) * H * GoldC.QuillonCopyC.invMod (6 * q) s : ℤ)) : ZMod s))
        (fun ρ j hj => GoldC.QuillonRowFacts.coef_clsN q hq Γ hΓb s hs1' (fun k => -(k : ℤ)) ρ j hj)
        (GoldC.QuillonRowFacts.hc_gen C hCp rfl _
          (GoldC.QuillonRowFacts.not_dvd_HinvM hCH rfl hs2 hsM.symm) (-1) (Or.inr rfl) _
          (fun j => by congr 1; ring))
        (E0.card + C.card) a' b' hEc' ha'' hab' hb2' hbN
      linarith)
  refine le_trans hcell ?_
  rw [hmax]
  -- Rankin pieces
  have hσX : ∀ p ∈ (T \ C).filter (fun p => p < Xp h), (p : ℝ) ^ σRk h ≤ 3 := fun p hp =>
    hrσ h L4 p (by have := (hT p (sdiff_subset (filter_subset _ _ hp))).2.1; omega)
      (le_of_lt (mem_filter.1 hp).2)
  have hV5 : ∀ p ∈ (T \ C).filter (fun p => p < Xp h), 5 ≤ p := fun p hp =>
    (hT p (sdiff_subset (filter_subset _ _ hp))).2.1
  have hprod := rankin_prod_le _ hV5 (σRk h) hσX
  have hlogh2 : Real.log ((h ^ 2 : ℕ) : ℝ) ≤ 2 * Λ := by
    push_cast; rw [Real.log_pow]; push_cast; exact le_rfl
  have hprodU : ∏ p ∈ (T \ C).filter (fun p => p < Xp h), (1 + 1 / ((p : ℝ) - 3)) ≤ E * Λ ^ (10 : ℝ) :=
    prodU_le_pow _ (fun p hp => ⟨(hT p (sdiff_subset (filter_subset _ _ hp))).1, hV5 p hp⟩) (h ^ 2)
      (fun p hp => le_trans (hT p (sdiff_subset (filter_subset _ _ hp))).2.2.2.2
        (Nat.pow_le_pow_left hHh 2)) 2 Λ (by norm_num) hΛ1 hlogh2
  have hprodU0 : 0 ≤ ∏ p ∈ (T \ C).filter (fun p => p < Xp h), (1 + 1 / ((p : ℝ) - 3)) :=
    prod_nonneg fun p hp => by
      have : (5 : ℝ) ≤ p := by exact_mod_cast hV5 p hp
      have : 0 ≤ 1 / ((p : ℝ) - 3) := div_nonneg zero_le_one (by linarith)
      linarith
  have hP : ∏ p ∈ (T \ C).filter (fun p => p < Xp h), (1 + (p : ℝ) ^ σRk h / ((p : ℝ) - 3)) ≤
      (E * Λ ^ (10 : ℝ)) ^ 3 := le_trans hprod (pow_le_pow_left₀ hprodU0 hprodU 3)
  have hP0 : 0 ≤ ∏ p ∈ (T \ C).filter (fun p => p < Xp h), (1 + (p : ℝ) ^ σRk h / ((p : ℝ) - 3)) :=
    prod_nonneg fun p hp => by
      have : (5 : ℝ) ≤ p := by exact_mod_cast hV5 p hp
      have : 0 ≤ (p : ℝ) ^ σRk h / ((p : ℝ) - 3) := div_nonneg (by positivity) (by linarith)
      linarith
  have hL := hrL h L5 s (LwC h s) hs1 hlogs hLwsq
  have hK1 : (((Nat.log 2 (H ^ 2) + 1 : ℕ)) : ℝ) ≤ 5 * Λ := by
    have hH2 : Real.log ((H ^ 2 : ℕ) : ℝ) ≤ 2 * Λ := by
      have hHR : (H : ℝ) ≤ h := by exact_mod_cast hHh
      have h0 : (0 : ℝ) < ((H ^ 2 : ℕ) : ℝ) := by push_cast; positivity
      have := Real.log_le_log h0 (show ((H ^ 2 : ℕ) : ℝ) ≤ ((h ^ 2 : ℕ) : ℝ) by
        push_cast; exact pow_le_pow_left₀ (by positivity) hHR 2)
      linarith
    have := natlog_le_of (H ^ 2) (2 * Λ) hH2
    rw [max_eq_left (show (0 : ℝ) ≤ 2 * Λ by linarith)] at this
    push_cast; linarith
  exact Cfin_combine Λ _ _ Fm _ _ E hΛ2 (by positivity) hK1 rfl hFm0 (by positivity) hL hP0 hP hE0' hKfin


lemma card_le_of_prod_le (S : Finset ℕ) (hS : ∀ p ∈ S, 2 ≤ p) (N : ℕ) (hN : ∏ p ∈ S, p ≤ N) :
    (S.card : ℝ) ≤ 2 * Real.log N := by
  have h1 : 2 ^ S.card ≤ ∏ p ∈ S, p := by
    rw [← prod_const]; exact prod_le_prod' fun p hp => hS p hp
  have h2 : (2 : ℝ) ^ S.card ≤ N := by exact_mod_cast le_trans h1 hN
  have hN0 : (0 : ℝ) < N := lt_of_lt_of_le (by positivity) h2
  have h3 := Real.log_le_log (by positivity) h2
  rw [Real.log_pow] at h3
  have hl2 : (1 / 2 : ℝ) < Real.log 2 := GoldC.QuillonLam.log2_gt_half
  have : 0 ≤ (S.card : ℝ) := by positivity
  nlinarith

end GoldC.QuillonCPhysical

namespace GoldC.QuillonCPhysical

open Classical
open GoldC.QuillonEv GoldC.QuillonSetup GoldC.QuillonLam GoldC.QuillonCEv GoldC.QuillonCFinal
  GoldC.QuillonWContext
open GoldC.QuillonCopyS GoldC.QuillonCopyF GoldC.QuillonCopyM GoldC.QuillonWPhysical

/-- The region-C (`r ≥ s^{1+ε}`, not W′) part of the CORE pair sum at decoration `d`. -/
noncomputable def CPart (Jlow Jhigh q a h : ℕ) (δ : ℝ) (d : Finset ℕ) : ℝ :=
  ∑ B ∈ (Tsrc q h d).powerset, ∑ C ∈ (Tsrc q h d).powerset,
    if B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C ∧
        (Mk0 Jlow Jhigh h (h / primeSetProduct d) δ B C ∧ ¬ WMask h δ (Tsrc q h d) B C ∧
          ((primeSetProduct C : ℕ) : ℝ) ^ (1 + εp h) ≤ ((primeSetProduct B : ℕ) : ℝ)) then
      omegaWeight B * omegaWeight C *
        foldRow q a (primeSetProduct d) (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct C)
    else 0

lemma Tsrc_compl (q h : ℕ) (hq : 0 < q) (d : Finset ℕ) (p : ℕ) (hp : p.Prime) (h5 : 5 ≤ p)
    (hpH : p ≤ (h / primeSetProduct d) ^ 2) (hpT : p ∉ Tsrc q h d) :
    p ∈ q.primeFactors ∪ (h / primeSetProduct d).primeFactors ∪ d := by
  set H := h / primeSetProduct d
  have hH0 : H ≠ 0 := by
    intro h0
    have : p ≤ 0 := by rw [h0] at hpH; simpa using hpH
    omega
  unfold Tsrc ordinaryFiniteSupport activeHighPrime at hpT
  simp only [mem_filter, mem_range, not_and, not_not] at hpT
  by_cases hq' : p ∣ q
  · exact mem_union_left _ (mem_union_left _ (Nat.mem_primeFactors.2 ⟨hp, hq', hq.ne'⟩))
  by_cases hH : p ∣ H
  · exact mem_union_left _ (mem_union_right _ (Nat.mem_primeFactors.2 ⟨hp, hH, hH0⟩))
  · have := hpT (Nat.lt_succ_of_le hpH) ⟨hp, h5, hq'⟩ hH
    exact mem_union_right _ this

lemma card_primeFactors_le (n : ℕ) (hn : n ≠ 0) (S : Finset ℕ) (hS : S ⊆ n.primeFactors) :
    (S.card : ℝ) ≤ 2 * Real.log n := by
  apply card_le_of_prod_le S (fun p hp => (Nat.prime_of_mem_primeFactors (hS hp)).two_le) n
  calc ∏ p ∈ S, p ≤ ∏ p ∈ n.primeFactors, p :=
        prod_le_prod_of_subset_of_one_le' hS fun p hp _ => (Nat.prime_of_mem_primeFactors hp).one_lt.le
    _ ≤ n := Nat.le_of_dvd (Nat.pos_of_ne_zero hn) (Nat.prod_primeFactors_dvd n)

set_option maxHeartbeats 4000000 in
/-- **Physical region-C theorem.** For `d ⊆ primeFactors h` (every CORE decoration), the
region-C part of the CORE pair sum is `≤ Λ^{−15}`, eventually in `h`, uniformly in `a`, `d`, `Jlow`, `Jhigh`. -/
theorem C_physical (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (Jlow Jhigh a h : ℕ) (d : Finset ℕ), Λ₀ ≤ Real.log h → 2 ≤ h →
      d ⊆ h.primeFactors → |CPart Jlow Jhigh q a h δ d| ≤ (Real.log h) ^ (-(15 : ℝ)) := by
  obtain ⟨Λ₁, hΛ₁, hCf⟩ := C_final q hq δ hδ0 hδ1
  set E : ℝ := Real.exp 10 * (2 * 2 + 1) ^ 10 with hE
  obtain ⟨Λ₂, hΛ₂, hKΛ⟩ := const_le_rpow (E + 2 * q + 10) 1 one_pos
  refine ⟨max Λ₁ Λ₂, le_trans hΛ₁ (le_max_left _ _), ?_⟩
  intro Jlow Jhigh a h d hΛ hh hd
  have hΛa : Λ₁ ≤ Real.log h := le_trans (le_max_left _ _) hΛ
  have hΛb : Λ₂ ≤ Real.log h := le_trans (le_max_right _ _) hΛ
  set Λ := Real.log h with hΛdef
  have hΛ2 : 2 ≤ Λ := le_trans hΛ₁ hΛa
  have hΛ0 : 0 < Λ := by linarith
  have hK := hKΛ Λ hΛb
  rw [Real.rpow_one] at hK
  have hE0' : 0 ≤ E := by positivity
  set H := h / primeSetProduct d with hH
  set T := Tsrc q h d with hT
  have hTf := Tsrc_facts q h d
  have hHh : H ≤ h := Nat.div_le_self _ _
  have hh0' : h ≠ 0 := by omega
  -- the exceptional set
  set E0 := q.primeFactors ∪ H.primeFactors ∪ d with hE0
  have hE0c : (E0.card : ℝ) ≤ 2 * q + 2 * Λ + 2 * Λ := by
    have h1 : E0.card ≤ q.primeFactors.card + H.primeFactors.card + d.card :=
      le_trans (card_union_le _ _) (Nat.add_le_add_right (card_union_le _ _) _)
    have h1R : (E0.card : ℝ) ≤ q.primeFactors.card + H.primeFactors.card + d.card := by exact_mod_cast h1
    have hq1 : (q.primeFactors.card : ℝ) ≤ 2 * q := by
      have := card_primeFactors_le q hq.ne' _ subset_rfl
      have hl : Real.log q ≤ q := le_trans (Real.log_le_sub_one_of_pos (by exact_mod_cast hq)) (by linarith)
      linarith
    have hH1 : (H.primeFactors.card : ℝ) ≤ 2 * Λ := by
      rcases Nat.eq_zero_or_pos H with h0 | hpos
      · rw [h0]; simp; linarith
      · have := card_primeFactors_le H hpos.ne' _ subset_rfl
        have : Real.log H ≤ Λ := Real.log_le_log (by exact_mod_cast hpos) (by exact_mod_cast hHh)
        linarith
    have hd1 : (d.card : ℝ) ≤ 2 * Λ := card_primeFactors_le h hh0' d hd
    linarith
  have hE0T : ∀ p, p.Prime → 5 ≤ p → p ≤ H ^ 2 → p ∉ T → p ∈ E0 := fun p hp h5 hpH hpT =>
    Tsrc_compl q h hq d p hp h5 hpH hpT
  unfold CPart
  rw [GoldC.QuillonCells.double_sum_fixC]
  have hinner : ∀ C ∈ T.powerset.filter (fun C => C ≠ ∅),
      |∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
        (if Mk0 Jlow Jhigh h H δ B C ∧ ¬ WMask h δ T B C ∧
            ((primeSetProduct C : ℕ) : ℝ) ^ (1 + εp h) ≤ ((primeSetProduct B : ℕ) : ℝ) then
          omegaWeight B * omegaWeight C *
            foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0)| ≤
        ωR C * Λ ^ (-(30 : ℝ)) := by
    intro C hC
    have hCT : C ⊆ T := mem_powerset.1 (mem_filter.1 hC).1
    have hω0 : 0 ≤ ωR C := ωR_nonneg C fun p hp => (hTf p (hCT hp)).2.1
    have e : ∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
        (if Mk0 Jlow Jhigh h H δ B C ∧ ¬ WMask h δ T B C ∧
            ((primeSetProduct C : ℕ) : ℝ) ^ (1 + εp h) ≤ ((primeSetProduct B : ℕ) : ℝ) then
          omegaWeight B * omegaWeight C *
            foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0) =
        ωR C * ∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
          (if ((Jlow ≤ B.card + C.card ∧ B.card + C.card < Jhigh) ∧
              (Geo0 h H δ (∏ p ∈ B, p) (∏ p ∈ C, p) ∧
                ((∏ p ∈ C, p : ℕ) : ℝ) ^ (1 + εp h) ≤ ((∏ p ∈ B, p : ℕ) : ℝ))) ∧
              ¬ (B ∩ (T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ Yp δ (∏ p ∈ C, p))).Nonempty
            then ωR B * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p) else 0) := by
      rw [mul_sum]
      refine sum_congr rfl fun B _ => ?_
      have hiff : (Mk0 Jlow Jhigh h H δ B C ∧ ¬ WMask h δ T B C ∧
            ((primeSetProduct C : ℕ) : ℝ) ^ (1 + εp h) ≤ ((primeSetProduct B : ℕ) : ℝ)) ↔
          (((Jlow ≤ B.card + C.card ∧ B.card + C.card < Jhigh) ∧
              (Geo0 h H δ (∏ p ∈ B, p) (∏ p ∈ C, p) ∧
                ((∏ p ∈ C, p : ℕ) : ℝ) ^ (1 + εp h) ≤ ((∏ p ∈ B, p : ℕ) : ℝ))) ∧
              ¬ (B ∩ (T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ Yp δ (∏ p ∈ C, p))).Nonempty) := by
        constructor
        · rintro ⟨⟨h1, h2, h3, h4, h5, h6⟩, hw, hb⟩; exact ⟨⟨⟨h3, h4⟩, ⟨h1, h2, h5, h6⟩, hb⟩, hw⟩
        · rintro ⟨⟨⟨h3, h4⟩, ⟨h1, h2, h5, h6⟩, hb⟩, hw⟩; exact ⟨⟨h1, h2, h3, h4, h5, h6⟩, hw, hb⟩
      split_ifs with h1 h2 h2
      · show ωR B * ωR C * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p) =
          ωR C * (ωR B * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p))
        ring
      · exact absurd (hiff.1 h1) h2
      · exact absurd (hiff.2 h2) h1
      · rw [mul_zero]
    rw [e, abs_mul, abs_of_nonneg hω0]
    refine mul_le_mul_of_nonneg_left ?_ hω0
    -- case split on the size of `s`
    by_cases hsh : ((∏ p ∈ C, p : ℕ) : ℝ) ≤ h
    · have hCc : (C.card : ℝ) ≤ 2 * Λ := by
        have := card_le_of_prod_le C (fun p hp => (hTf p (hCT hp)).1.two_le) h (by exact_mod_cast hsh)
        exact this
      have hEc : ((E0.card + C.card : ℕ) : ℝ) ≤ Λ ^ 2 := by
        push_cast
        have hq' : (2 * q + 10 : ℝ) ≤ Λ := by linarith
        nlinarith
      exact hCf a h H (primeSetProduct d) T C E0 (fun k => Jlow ≤ k + C.card ∧ k + C.card < Jhigh) hΛa hh
        hHh hTf hE0T hEc hCT
    · -- no admissible `B`: every term vanishes
      have hzero : ∀ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
          (if ((Jlow ≤ B.card + C.card ∧ B.card + C.card < Jhigh) ∧
              (Geo0 h H δ (∏ p ∈ B, p) (∏ p ∈ C, p) ∧
                ((∏ p ∈ C, p : ℕ) : ℝ) ^ (1 + εp h) ≤ ((∏ p ∈ B, p : ℕ) : ℝ))) ∧
              ¬ (B ∩ (T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ Yp δ (∏ p ∈ C, p))).Nonempty
            then ωR B * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p) else 0) = 0 := by
        intro B _
        rw [if_neg]
        rintro ⟨⟨-, hg, -⟩, -⟩
        exact hsh (adm h H _ _ δ hδ0 hδ1 hh hHh hg).2.2.2.2.2.1
      rw [sum_eq_zero hzero, abs_zero]; positivity
  calc _ ≤ ∑ C ∈ T.powerset.filter (fun C => C ≠ ∅),
        |∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
          (if Mk0 Jlow Jhigh h H δ B C ∧ ¬ WMask h δ T B C ∧
              ((primeSetProduct C : ℕ) : ℝ) ^ (1 + εp h) ≤ ((primeSetProduct B : ℕ) : ℝ) then
            omegaWeight B * omegaWeight C *
              foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0)| :=
        abs_sum_le_sum_abs _ _
    _ ≤ ∑ C ∈ T.powerset.filter (fun C => C ≠ ∅), ωR C * Λ ^ (-(30 : ℝ)) := sum_le_sum hinner
    _ ≤ ∑ C ∈ T.powerset, ωR C * Λ ^ (-(30 : ℝ)) := by
        apply sum_le_sum_of_subset_of_nonneg (filter_subset _ _)
        intro C hC _
        have hCT : C ⊆ T := mem_powerset.1 hC
        have := ωR_nonneg C fun p hp => (hTf p (hCT hp)).2.1
        positivity
    _ = (∑ C ∈ T.powerset, ωR C) * Λ ^ (-(30 : ℝ)) := by rw [sum_mul]
    _ ≤ (E * Λ ^ (10 : ℝ)) * Λ ^ (-(30 : ℝ)) :=
        mul_le_mul_of_nonneg_right (outer_mass q h d (by linarith)) (by positivity)
    _ = E * Λ ^ (-(20 : ℝ)) := by rw [mul_assoc, rp hΛ0]; norm_num
    _ ≤ Λ * Λ ^ (-(20 : ℝ)) := by
        apply mul_le_mul_of_nonneg_right _ (by positivity)
        have : (0 : ℝ) ≤ 2 * q + 10 := by positivity
        linarith
    _ = Λ ^ (-(19 : ℝ)) := by
        rw [show Λ * Λ ^ (-(20 : ℝ)) = Λ ^ (1 : ℝ) * Λ ^ (-(20 : ℝ)) by rw [Real.rpow_one], rp hΛ0]
        norm_num
    _ ≤ Λ ^ (-(15 : ℝ)) := Real.rpow_le_rpow_of_exponent_le (by linarith) (by norm_num)

end GoldC.QuillonCPhysical


#print axioms GoldC.QuillonCPhysical.rankin_prod_le
#print axioms GoldC.QuillonCPhysical.rankin_σ_ev
#print axioms GoldC.QuillonCPhysical.rankin_Lw_ev

#print axioms GoldC.QuillonCPhysical.C_final
#print axioms GoldC.QuillonCPhysical.C_physical
