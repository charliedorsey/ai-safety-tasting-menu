import PaperB.FixedQ.PetermannConvolutionFinite
import PaperB.FixedQ.RowReduction

namespace PaperB.FixedQ

noncomputable def petermannGlobalCorrectionPrime
    (q h p : ℕ) : ℝ :=
  if activeHighPrime q p ∧ p ∣ h then
    petermannB p - petermannA p
  else 0

noncomputable def finitePetermannGlobalCorrection
    (q h : ℕ) (s : Finset ℕ) : ℝ :=
  ∏ p ∈ s, petermannGlobalCorrectionPrime q h p

theorem abs_petermannGlobalCorrectionPrime_le_normalization
    (q h p : ℕ) :
    |petermannGlobalCorrectionPrime q h p| ≤
      normalizationCorrection q 1 p := by
  by_cases hact : activeHighPrime q p
  · by_cases hph : p ∣ h
    · have hact' : p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q := by
        simpa [activeHighPrime] using hact
      have hpPrime : p.Prime := hact'.1
      have hp5 : 5 ≤ p := hact'.2.1
      have hp1 : ¬ p ∣ 1 := hpPrime.not_dvd_one
      have hpR : (5 : ℝ) ≤ (p : ℝ) := by exact_mod_cast hp5
      have hp2 : 0 < (p : ℝ) - 2 := by linarith
      have hp3 : 0 < (p : ℝ) - 3 := by linarith
      have hp0 : 0 < (p : ℝ) := by linarith
      simp only [petermannGlobalCorrectionPrime, hact, hph, and_self, if_true]
      rw [normalizationCorrection, if_pos hact', if_neg hp1]
      unfold petermannA petermannB
      have hdiff :
          1 / ((p : ℝ) - 2) - 1 / ((p : ℝ) - 3) ≤ 0 := by
        apply sub_nonpos.mpr
        exact one_div_le_one_div_of_le hp3 (by linarith)
      rw [abs_of_nonpos hdiff]
      have hden1 : 0 < ((p : ℝ) - 2) * ((p : ℝ) - 3) :=
        mul_pos hp2 hp3
      have hden2 : 0 < (p : ℝ) * ((p : ℝ) - 3) :=
        mul_pos hp0 hp3
      rw [show -(1 / ((p : ℝ) - 2) - 1 / ((p : ℝ) - 3)) =
          1 / (((p : ℝ) - 2) * ((p : ℝ) - 3)) by
            field_simp
            ring]
      rw [div_le_div_iff₀ hden1 hden2]
      nlinarith
    · rw [petermannGlobalCorrectionPrime, if_neg (by simp [hact, hph])]
      simpa using normalizationCorrection_nonneg q 1 p
  · have hact' : ¬(p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q) := by
      simpa [activeHighPrime] using hact
    rw [petermannGlobalCorrectionPrime, if_neg (by simp [hact])]
    rw [normalizationCorrection, if_neg hact']
    simp

theorem abs_finitePetermannGlobalCorrection_le_normalizationWeightMass
    (q h : ℕ) (s : Finset ℕ) :
    |finitePetermannGlobalCorrection q h s| ≤
      normalizationWeightMass q 1 s := by
  rw [normalizationWeightMass_eq_prod_correction]
  unfold finitePetermannGlobalCorrection
  induction s using Finset.induction_on with
  | empty => simp
  | @insert p s hp ih =>
      rw [Finset.prod_insert hp, Finset.prod_insert hp, abs_mul]
      have h1 := abs_petermannGlobalCorrectionPrime_le_normalization q h p
      have h2 : 0 ≤ normalizationCorrection q 1 p :=
        normalizationCorrection_nonneg q 1 p
      have h3 : 0 ≤ ∏ x ∈ s, normalizationCorrection q 1 x :=
        Finset.prod_nonneg fun x hx => normalizationCorrection_nonneg q 1 x
      exact mul_le_mul h1 ih (abs_nonneg _) h2

theorem summable_finitePetermannGlobalCorrection
    (q h : ℕ) :
    Summable (finitePetermannGlobalCorrection q h) := by
  exact summable_of_abs_le_normalizationWeightMass q 1 1 (by norm_num)
    (finitePetermannGlobalCorrection q h) (by
      intro s
      simpa using
        abs_finitePetermannGlobalCorrection_le_normalizationWeightMass q h s)

noncomputable def petermannCorrectionL1Bound (q : ℕ) : ℝ :=
  ∑' s : Finset ℕ, normalizationWeightMass q 1 s

theorem finitePetermannGlobalCorrection_tsum_abs_le
    (q h : ℕ) :
    (∑' s : Finset ℕ, |finitePetermannGlobalCorrection q h s|) ≤
      petermannCorrectionL1Bound q := by
  unfold petermannCorrectionL1Bound
  exact (summable_finitePetermannGlobalCorrection q h).abs.tsum_le_tsum
    (fun s => abs_finitePetermannGlobalCorrection_le_normalizationWeightMass q h s)
    (summable_normalizationWeightMass q 1)

#print axioms abs_petermannGlobalCorrectionPrime_le_normalization
#print axioms summable_finitePetermannGlobalCorrection
#print axioms finitePetermannGlobalCorrection_tsum_abs_le

end PaperB.FixedQ
