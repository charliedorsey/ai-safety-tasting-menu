import PaperB.FixedQ.SignedForbiddenThalenProperSourceRowSplit

open scoped BigOperators

namespace PaperB.FixedQ

/-- Algebraic reaggregation of a full oriented Boolean packet over every
outer support e ⊆ S. The outer coefficient is the source product of w_p. -/
theorem thalen_outer_support_full_euler
    (S : Finset ℕ) (w L R : ℕ → ℝ) :
    (∑ e ∈ S.powerset,
      (∏ p ∈ e, w p) *
        (∑ A ∈ e.powerset,
          (∏ p ∈ A, L p) * (∏ p ∈ e \ A, R p))) =
      ∏ p ∈ S, (1 + w p * (L p + R p)) := by
  have hinner (e : Finset ℕ) :
      (∑ A ∈ e.powerset,
          (∏ p ∈ A, L p) * (∏ p ∈ e \ A, R p)) =
      ∏ p ∈ e, (L p + R p) := by
    exact (Finset.prod_add L R e).symm
  simp_rw [hinner]
  have hmul (e : Finset ℕ) :
      (∏ p ∈ e, w p) * (∏ p ∈ e, (L p + R p)) =
        ∏ p ∈ e, w p * (L p + R p) := by
    rw [Finset.prod_mul_distrib]
  simp_rw [hmul]
  simpa [add_comm] using
    (Finset.prod_add (fun p => w p * (L p + R p))
      (fun _ => (1 : ℝ)) S).symm

#print axioms thalen_outer_support_full_euler

/-- Pure-left/pure-right subtraction after summing all outer supports.
The empty support is restored once, exactly. -/
theorem thalen_outer_support_proper_euler
    (S : Finset ℕ) (w L R : ℕ → ℝ) :
    (∑ e ∈ S.powerset,
      (∏ p ∈ e, w p) *
        (∑ A ∈ ((e.powerset.erase e).erase ∅),
          (∏ p ∈ A, L p) * (∏ p ∈ e \ A, R p))) =
    (∏ p ∈ S, (1 + w p * (L p + R p))) -
    (∏ p ∈ S, (1 + w p * L p)) -
    (∏ p ∈ S, (1 + w p * R p)) + 1 := by
  classical
  let P : Finset ℕ → ℝ := fun e =>
    ∑ A ∈ e.powerset,
      (∏ p ∈ A, L p) * (∏ p ∈ e \ A, R p)
  let PL : Finset ℕ → ℝ := fun e => ∏ p ∈ e, L p
  let PR : Finset ℕ → ℝ := fun e => ∏ p ∈ e, R p
  have hproper (e : Finset ℕ) :
      (∑ A ∈ ((e.powerset.erase e).erase ∅),
        (∏ p ∈ A, L p) * (∏ p ∈ e \ A, R p)) =
      P e - PL e - PR e + if e = ∅ then 1 else 0 := by
    by_cases he : e = ∅
    · subst e
      simp [P, PL, PR]
    · have hmem : e ∈ e.powerset := Finset.mem_powerset.mpr (by simp)
      have hmem0 : ∅ ∈ e.powerset.erase e := by
        exact Finset.mem_erase.mpr ⟨by simpa [eq_comm] using he,
          Finset.mem_powerset.mpr (by simp)⟩
      have h₁ := Finset.sum_erase_add e.powerset
        (fun A => (∏ p ∈ A, L p) * (∏ p ∈ e \ A, R p)) hmem
      have h₂ := Finset.sum_erase_add (e.powerset.erase e)
        (fun A => (∏ p ∈ A, L p) * (∏ p ∈ e \ A, R p)) hmem0
      simp only [if_neg he, add_zero]
      dsimp [P, PL, PR]
      simp only [Finset.sdiff_self, Finset.sdiff_empty,
        Finset.prod_empty, one_mul, mul_one] at h₁ h₂
      linarith
  simp_rw [hproper]
  have hsume :
      (∑ e ∈ S.powerset,
        (∏ p ∈ e, w p) *
          (P e - PL e - PR e + if e = ∅ then 1 else 0)) =
      (∑ e ∈ S.powerset, (∏ p ∈ e, w p) * P e) -
      (∑ e ∈ S.powerset, (∏ p ∈ e, w p) * PL e) -
      (∑ e ∈ S.powerset, (∏ p ∈ e, w p) * PR e) + 1 := by
    have hs :
      (∑ e ∈ S.powerset,
        (∏ p ∈ e, w p) * (if e = ∅ then 1 else 0)) = 1 := by
      rw [Finset.sum_eq_single ∅]
      · simp
      · intro e he hne
        simp [hne]
      · intro hnot
        exact (hnot (Finset.mem_powerset.mpr (by simp))).elim
    calc
      _ = ∑ e ∈ S.powerset,
          ((∏ p ∈ e, w p) * P e -
            (∏ p ∈ e, w p) * PL e -
            (∏ p ∈ e, w p) * PR e +
            (∏ p ∈ e, w p) * (if e = ∅ then 1 else 0)) := by
              apply Finset.sum_congr rfl
              intro e he
              ring
      _ = _ := by
        rw [Finset.sum_add_distrib, Finset.sum_sub_distrib,
          Finset.sum_sub_distrib, hs]
  rw [hsume]
  have hfull := thalen_outer_support_full_euler S w L R
  have hl :
      (∑ e ∈ S.powerset, (∏ p ∈ e, w p) * PL e) =
      ∏ p ∈ S, (1 + w p * L p) := by
    simp only [PL, ← Finset.prod_mul_distrib]
    simpa [add_comm] using
      (Finset.prod_add (fun p => w p * L p) (fun _ => (1 : ℝ)) S).symm
  have hr :
      (∑ e ∈ S.powerset, (∏ p ∈ e, w p) * PR e) =
      ∏ p ∈ S, (1 + w p * R p) := by
    simp only [PR, ← Finset.prod_mul_distrib]
    simpa [add_comm] using
      (Finset.prod_add (fun p => w p * R p) (fun _ => (1 : ℝ)) S).symm
  change (∑ e ∈ S.powerset, (∏ p ∈ e, w p) * P e) -
      (∑ e ∈ S.powerset, (∏ p ∈ e, w p) * PL e) -
      (∑ e ∈ S.powerset, (∏ p ∈ e, w p) * PR e) + 1 = _
  simp only [P] at *
  rw [hfull, hl, hr]

#print axioms thalen_outer_support_proper_euler

end PaperB.FixedQ
