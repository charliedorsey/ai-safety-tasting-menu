import OrielUpper.FixedVar3
import OrielUpper.RowIdentity
import OrielUpper.Pairs

/-!
# Oriel Upper — shell toolkit

Helpers for the per-shell sector decomposition: finset/ite bookkeeping, the
uniform bound on a single pair discrepancy, and the simplification of the
fixed-variable right-hand side.
-/

open Finset

namespace OrielUpper

lemma sum_ite_iff {s t : Finset ℕ} {p : ℕ → Prop} [DecidablePred p] (f : ℕ → ℝ)
    (h : ∀ x, (x ∈ s ∧ p x) ↔ x ∈ t) :
    ∑ x ∈ s, (if p x then f x else 0) = ∑ x ∈ t, f x := by
  rw [← sum_filter]
  congr 1
  ext x
  rw [mem_filter]
  exact h x

lemma ite_le_ite_of {p q : Prop} [Decidable p] [Decidable q] {f g : ℝ}
    (hpq : p → q) (hfg : p → f ≤ g) (hg : q → 0 ≤ g) :
    (if p then f else 0) ≤ (if q then g else 0) := by
  by_cases hp : p
  · rw [if_pos hp, if_pos (hpq hp)]; exact hfg hp
  · rw [if_neg hp]
    by_cases hq : q
    · rw [if_pos hq]; exact hg hq
    · rw [if_neg hq]

/-- `a ≤ 2 m (a / m)` once `m ≤ a`. -/
lemma two_mul_div_ge {a m : ℕ} (hm : 0 < m) (hma : m ≤ a) : a ≤ 2 * m * (a / m) := by
  have h1 := Nat.div_add_mod a m
  have h2 := Nat.mod_lt a hm
  have h3 : 1 ≤ a / m := (Nat.one_le_div_iff hm).mpr hma
  have : m ≤ m * (a / m) := Nat.le_mul_of_pos_right m h3
  nlinarith

/-- `b ≤ 2a` gives `b / m ≤ 3 * max (a / m) 1`. -/
lemma div_le_three_max {a b m : ℕ} (hm : 0 < m) (hb : b ≤ 2 * a) :
    b / m ≤ 3 * max (a / m) 1 := by
  have h1 : a < m * (a / m + 1) := by
    have := Nat.lt_div_mul_add (a := a) hm
    nlinarith [Nat.div_add_mod a m, Nat.mod_lt a hm]
  have h2 : b < m * (2 * (a / m) + 2) := by nlinarith
  have h3 : b / m < 2 * (a / m) + 2 := by
    rw [Nat.div_lt_iff_lt_mul hm]; linarith
  have : a / m ≤ max (a / m) 1 := le_max_left _ _
  have : 1 ≤ max (a / m) 1 := le_max_right _ _
  omega

lemma log_ratio_le {A Bn : ℕ} (hA : 1 ≤ A) (h : Bn ≤ 4 * A) :
    1 + Real.log ((Bn : ℝ) / A) ≤ 1 + Real.log 4 := by
  have hAr : (0 : ℝ) < A := by exact_mod_cast (show 0 < A by omega)
  rcases Nat.eq_zero_or_pos Bn with h0 | h0
  · subst h0; simp only [Nat.cast_zero, zero_div, Real.log_zero]
    have : 0 ≤ Real.log 4 := Real.log_nonneg (by norm_num)
    linarith
  · have hB : (0 : ℝ) < Bn := by exact_mod_cast h0
    have : Real.log ((Bn : ℝ) / A) ≤ Real.log 4 := by
      apply Real.log_le_log (by positivity)
      rw [div_le_iff₀ hAr]; exact_mod_cast h
    linarith

lemma log_ratio_nonneg {A Bn : ℕ} (hA : 1 ≤ A) (h : A ≤ Bn) :
    0 ≤ 1 + Real.log ((Bn : ℝ) / A) := by
  have hAr : (0 : ℝ) < A := by exact_mod_cast (show 0 < A by omega)
  have : 0 ≤ Real.log ((Bn : ℝ) / A) := Real.log_nonneg (by
    rw [le_div_iff₀ hAr, one_mul]; exact_mod_cast h)
  linarith

variable {P : ℕ} [NeZero P]

/-- Structural hypotheses on the row weight. -/
structure RowHyp (P : ℕ) [NeZero P] (F H : ℕ) (w : ℕ → ℝ) (Λ : ZMod P → ℝ) (B : ℝ) : Prop where
  hw : ∀ y, 0 < y → y < H → w y = Λ (y : ZMod P)
  hB : ∀ z, |Λ z| ≤ B
  hPF : ∀ p, p.Prime → p ∣ P → p < 5 ∨ p ∣ F
  hHF : H ∣ F

lemma RowHyp.B_nonneg {F H : ℕ} {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {B : ℝ}
    (hR : RowHyp P F H w Λ B) : 0 ≤ B := le_trans (abs_nonneg _) (hR.hB 0)

lemma RowHyp.coprime_P {F H : ℕ} {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {B : ℝ}
    (hR : RowHyp P F H w Λ B) {n : ℕ} (hn : bW F n ≠ 0) : Nat.Coprime n P :=
  bW_ne_zero_coprime hR.hPF hn

lemma RowHyp.coprime_H {F H : ℕ} {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {B : ℝ}
    (hR : RowHyp P F H w Λ B) {n : ℕ} (hn : bW F n ≠ 0) : Nat.Coprime H n := by
  obtain ⟨hn0, _, hall⟩ := bW_ne_zero_imp hn
  apply Nat.coprime_of_dvd
  intro k hk hkH hkn
  have hmem : k ∈ n.primeFactors := Nat.mem_primeFactors.mpr ⟨hk, hkn, hn0⟩
  exact (hall k hmem).2 (hkH.trans hR.hHF)

/-- The centering constant. -/
noncomputable def cZero (H : ℕ) (w : ℕ → ℝ) (Λ : ZMod P → ℝ) : ℝ :=
  muL Λ * ((H - 1 : ℕ) : ℝ) - rowW w H

/-- Uniform bound for one pair discrepancy (when both weights are live). -/
lemma abs_rowDisc_le {F H : ℕ} {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {B : ℝ}
    (hR : RowHyp P F H w Λ B) {r s : ℕ} (hr : bW F r ≠ 0) (hs : bW (F * r) s ≠ 0) :
    |rowDisc w H r s| ≤ (4 * P + 3) * B := by
  have hr0 : 0 < r := Nat.pos_of_ne_zero (bW_ne_zero_imp hr).1
  have hs0 : 0 < s := Nat.pos_of_ne_zero (bW_ne_zero_imp hs).1
  have hrP : Nat.Coprime r P := hR.coprime_P hr
  have hsP : Nat.Coprime s P := by
    have hs' : bW F s ≠ 0 := by
      intro h; apply hs; rw [bW_mul_left]; split_ifs <;> simp [h]
    exact hR.coprime_P hs'
  have hrs : Nat.Coprime r s := by
    by_contra hc; apply hs; rw [bW_mul_left, if_neg hc]
  rw [oriel_rowDisc_left hR.hw hr0 hs0]
  have hψ := oriel_psi_bound hr0 hR.hB (H := H) (α := (H : ZMod P))
    ((ZMod.isUnit_iff_coprime r P).mpr hrP) isUnit_one.neg
    ((ZMod.isUnit_iff_coprime s P).mpr hsP)
    ((ZMod.isUnit_iff_coprime s r).mpr hrs.symm) (x := ((H - 1 : ℕ) : ℝ) / s) (by positivity)
  have hc := oriel_centering hR.hw hR.hB
  have hB0 := hR.B_nonneg
  have hrs1 : (1 : ℝ) ≤ (r : ℝ) * s := by
    have : 1 ≤ r * s := Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero hr0.ne' hs0.ne')
    exact_mod_cast this
  have hdiv : |(muL Λ * ((H - 1 : ℕ) : ℝ) - rowW w H) / ((r : ℝ) * s)| ≤ (2 * P + 1) * B := by
    rw [abs_div, abs_of_pos (by linarith : (0 : ℝ) < (r : ℝ) * s)]
    rw [div_le_iff₀ (by linarith)]
    have : 0 ≤ (2 * (P : ℝ) + 1) * B := by positivity
    nlinarith
  calc _ ≤ |psiR r H Λ (H : ZMod P) (-1) (s : ZMod P) (s : ZMod r) (((H - 1 : ℕ) : ℝ) / s)| +
        |(muL Λ * ((H - 1 : ℕ) : ℝ) - rowW w H) / ((r : ℝ) * s)| := abs_add_le _ _
    _ ≤ (2 * P + 2) * B + (2 * P + 1) * B := add_le_add hψ hdiv
    _ = (4 * P + 3) * B := by ring

/-- The pair summand. -/
noncomputable def pairTerm (F H : ℕ) (w : ℕ → ℝ) (r s : ℕ) : ℝ :=
  bW F r * bW (F * r) s * rowDisc w H r s

lemma abs_pairTerm_le {F H : ℕ} {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {B : ℝ}
    (hR : RowHyp P F H w Λ B) (r s : ℕ) :
    |pairTerm F H w r s| ≤ bW F r * bW (F * r) s * ((4 * P + 3) * B) := by
  unfold pairTerm
  by_cases hr : bW F r = 0
  · rw [hr]; simp
  by_cases hs : bW (F * r) s = 0
  · rw [hs]; simp
  rw [abs_mul, abs_of_nonneg (mul_nonneg (bW_nonneg _ _) (bW_nonneg _ _))]
  exact mul_le_mul_of_nonneg_left (abs_rowDisc_le hR hr hs)
    (mul_nonneg (bW_nonneg _ _) (bW_nonneg _ _))

/-- Simplification of the fixed-variable right-hand side. -/
lemma fv_rhs_le {Pr B ℓ ℓ0 A1 E1 A34 E34 τ m A a X0 H M D : ℝ}
    (hP : 0 ≤ Pr) (hB : 0 ≤ B) (hℓ : 0 ≤ ℓ) (hℓ0 : ℓ ≤ ℓ0) (hA1 : 0 ≤ A1) (hE1 : A1 ≤ E1)
    (hA34 : 0 ≤ A34) (hE34 : A34 ≤ E34) (hτ : 0 ≤ τ) (hm : 1 ≤ m) (hA : 1 ≤ A)
    (ha : 0 < a) (hamA : a ≤ 2 * m * A) (hX0 : 0 ≤ X0) (hXH : X0 ≤ H) (hHM : H ≤ 2 * M * a)
    (hM : 0 ≤ M) (hD : 0 < D) :
    (2 * Pr + 1) * B * ℓ * (τ * A1 / m + A1 / (m * A)) +
        A34 * ((Pr * m) * (B / A * (2 * (X0 / A) / m + 4 * Pr + 5)) * D ^ (3 / 4 : ℝ) +
          (2 * Pr + 2) * B * ℓ * D ^ (-(1 / 4 : ℝ))) ≤
      (2 * Pr + 1) * B * ℓ0 * E1 * (τ / m + 2 / a) +
        E34 * (2 * Pr * B * (8 * M + 4 * Pr + 5) * (m ^ 2 / a) * D ^ (3 / 4 : ℝ) +
          (2 * Pr + 2) * B * ℓ0 * D ^ (-(1 / 4 : ℝ))) := by
  have hm0 : 0 < m := by linarith
  have hA0 : 0 < A := by linarith
  have hD1 : 0 < D ^ (3 / 4 : ℝ) := by positivity
  have hD2 : 0 < D ^ (-(1 / 4 : ℝ)) := by positivity
  -- 1/(mA) ≤ 2/a
  have hinv : 1 / (m * A) ≤ 2 / a := by
    rw [div_le_div_iff₀ (by positivity) ha]; linarith
  have hBA : B / A ≤ 2 * m * B / a := by
    rw [div_le_div_iff₀ hA0 ha]; nlinarith
  have hXA : 2 * (X0 / A) / m ≤ 8 * M := by
    rw [div_le_iff₀ hm0, div_eq_mul_inv, ← mul_assoc]
    have h1 : X0 / A ≤ 2 * m * H / a := by
      rw [div_le_div_iff₀ hA0 ha]; nlinarith
    have h2 : 2 * m * H / a ≤ 4 * m * M := by
      rw [div_le_iff₀ ha]; nlinarith
    have : X0 * A⁻¹ = X0 / A := by rw [div_eq_mul_inv]
    rw [mul_assoc, this]; nlinarith
  have hfirst : (2 * Pr + 1) * B * ℓ * (τ * A1 / m + A1 / (m * A)) ≤
      (2 * Pr + 1) * B * ℓ0 * E1 * (τ / m + 2 / a) := by
    have h1 : τ * A1 / m + A1 / (m * A) ≤ E1 * (τ / m + 2 / a) := by
      have e1 : τ * A1 / m = A1 * (τ / m) := by ring
      have e2 : A1 / (m * A) = A1 * (1 / (m * A)) := by ring
      rw [e1, e2, ← mul_add]
      apply mul_le_mul hE1 _ (by positivity) (by linarith)
      linarith
    have h2 : 0 ≤ τ * A1 / m + A1 / (m * A) := by positivity
    calc (2 * Pr + 1) * B * ℓ * (τ * A1 / m + A1 / (m * A))
        ≤ (2 * Pr + 1) * B * ℓ0 * (τ * A1 / m + A1 / (m * A)) := by
          apply mul_le_mul_of_nonneg_right _ h2
          apply mul_le_mul_of_nonneg_left hℓ0 (by positivity)
      _ ≤ (2 * Pr + 1) * B * ℓ0 * (E1 * (τ / m + 2 / a)) := by
          apply mul_le_mul_of_nonneg_left h1
          have : 0 ≤ ℓ0 := le_trans hℓ hℓ0
          positivity
      _ = _ := by ring
  have hmid : (Pr * m) * (B / A * (2 * (X0 / A) / m + 4 * Pr + 5)) ≤
      2 * Pr * B * (8 * M + 4 * Pr + 5) * (m ^ 2 / a) := by
    have hin : 0 ≤ 2 * (X0 / A) / m + 4 * Pr + 5 := by positivity
    calc (Pr * m) * (B / A * (2 * (X0 / A) / m + 4 * Pr + 5))
        ≤ (Pr * m) * (2 * m * B / a * (8 * M + 4 * Pr + 5)) := by
          apply mul_le_mul_of_nonneg_left _ (by positivity)
          apply mul_le_mul hBA (by linarith) hin (by positivity)
      _ = 2 * Pr * B * (8 * M + 4 * Pr + 5) * (m ^ 2 / a) := by ring
  have hsecond : A34 * ((Pr * m) * (B / A * (2 * (X0 / A) / m + 4 * Pr + 5)) * D ^ (3 / 4 : ℝ) +
          (2 * Pr + 2) * B * ℓ * D ^ (-(1 / 4 : ℝ))) ≤
      E34 * (2 * Pr * B * (8 * M + 4 * Pr + 5) * (m ^ 2 / a) * D ^ (3 / 4 : ℝ) +
          (2 * Pr + 2) * B * ℓ0 * D ^ (-(1 / 4 : ℝ))) := by
    apply mul_le_mul hE34 _ (by positivity) (le_trans hA34 hE34)
    apply add_le_add
    · exact mul_le_mul_of_nonneg_right hmid hD1.le
    · apply mul_le_mul_of_nonneg_right _ hD2.le
      apply mul_le_mul_of_nonneg_left hℓ0 (by positivity)
  linarith

end OrielUpper
