import GoldB.Grid

/-!
# GoldB.Invariance

Translation and dilation invariance of the Vinogradov system, monotonicity,
interval comparison, and the degree-one count.
-/

open Finset

namespace GoldB

variable {k : ℕ}

lemma psv_append {m n : ℕ} (x : Fin m → ℤ) (u : Fin n → ℤ) :
    psv k (Fin.append x u) = psv k x + psv k u := by
  ext j; simp [psv, Fin.sum_univ_add]

/-- binomial expansion of shifted power sums -/
lemma sum_shift_pow {n : ℕ} (z : Fin n → ℤ) (c : ℤ) (m : ℕ) :
    ∑ i, (z i + c) ^ m = ∑ t ∈ range (m + 1), (∑ i, z i ^ t) * c ^ (m - t) * (m.choose t) := by
  simp_rw [add_pow]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl; intro t _
  rw [Finset.sum_mul, Finset.sum_mul]

/-- **translation invariance** -/
lemma psv_shift {n : ℕ} (z w : Fin n → ℤ) (c : ℤ) (h : psv k z = psv k w) :
    psv k (fun i => z i + c) = psv k (fun i => w i + c) := by
  ext j
  simp only [psv]
  rw [sum_shift_pow, sum_shift_pow]
  apply Finset.sum_congr rfl; intro t ht
  congr 2
  rcases Nat.eq_zero_or_pos t with h0 | hpos
  · subst h0; simp
  · have htk : t - 1 < k := by
      have := mem_range.mp ht; have := j.isLt; omega
    have := congrFun h ⟨t - 1, htk⟩
    simp only [psv] at this
    rwa [show t - 1 + 1 = t by omega] at this

lemma psv_shift_iff {n : ℕ} (z w : Fin n → ℤ) (c : ℤ) :
    psv k (fun i => z i + c) = psv k (fun i => w i + c) ↔ psv k z = psv k w := by
  constructor
  · intro h
    have := psv_shift (k := k) _ _ (-c) h
    simpa using this
  · exact psv_shift z w c

lemma psv_smul {n : ℕ} (d : ℤ) (u : Fin n → ℤ) (j : Fin k) :
    psv k (fun i => d * u i) j = d ^ (j.val + 1) * psv k u j := by
  simp [psv, mul_pow, Finset.mul_sum]

lemma psv_smul_iff {n : ℕ} (d : ℤ) (hd : d ≠ 0) (u v : Fin n → ℤ) :
    psv k (fun i => d * u i) = psv k (fun i => d * v i) ↔ psv k u = psv k v := by
  constructor
  · intro h; ext j
    have := congrFun h j
    rw [psv_smul, psv_smul] at this
    exact mul_left_cancel₀ (pow_ne_zero _ hd) this
  · intro h; ext j; rw [psv_smul, psv_smul, h]

/-- affine maps preserve the system -/
lemma psv_affine_iff {n : ℕ} (c d : ℤ) (hd : d ≠ 0) (u v : Fin n → ℤ) :
    psv k (fun i => c + d * u i) = psv k (fun i => c + d * v i) ↔ psv k u = psv k v := by
  have e : ∀ w : Fin n → ℤ, (fun i => c + d * w i) = fun i => (fun i => d * w i) i + c := by
    intro w; ext i; ring
  rw [e u, e v, psv_shift_iff, psv_smul_iff d hd]

lemma Jc_mono (n : ℕ) {A B : Finset ℤ} (h : A ⊆ B) : Jc k n A ≤ Jc k n B := by
  unfold Jc
  apply card_le_card
  intro xy hxy
  simp only [mem_filter, mem_product] at hxy ⊢
  refine ⟨⟨?_, ?_⟩, hxy.2⟩
  · exact Fintype.piFinset_subset _ _ (fun _ => h) hxy.1.1
  · exact Fintype.piFinset_subset _ _ (fun _ => h) hxy.1.2

/-- affine invariance of `J` -/
lemma Jc_affine (n : ℕ) (A : Finset ℤ) (c d : ℤ) (hd : d ≠ 0) :
    Jc k n (A.image fun b => c + d * b) = Jc k n A := by
  classical
  unfold Jc
  symm
  apply Finset.card_nbij'
    (fun (xy : (Fin n → ℤ) × (Fin n → ℤ)) =>
      ((fun i : Fin n => c + d * xy.1 i), (fun i : Fin n => c + d * xy.2 i)))
    (fun (xy : (Fin n → ℤ) × (Fin n → ℤ)) =>
      ((fun i : Fin n => (xy.1 i - c) / d), (fun i : Fin n => (xy.2 i - c) / d)))
  · intro xy hxy
    simp only [coe_filter, mem_product, Fintype.mem_piFinset, Set.mem_setOf_eq] at hxy ⊢
    refine ⟨⟨fun i => mem_image_of_mem _ (hxy.1.1 i), fun i => mem_image_of_mem _ (hxy.1.2 i)⟩, ?_⟩
    exact (psv_affine_iff c d hd _ _).mpr hxy.2
  · intro xy hxy
    simp only [coe_filter, mem_product, Fintype.mem_piFinset, Set.mem_setOf_eq,
      mem_image] at hxy ⊢
    have h1 : ∀ i, ∃ b ∈ A, c + d * b = xy.1 i := hxy.1.1
    have h2 : ∀ i, ∃ b ∈ A, c + d * b = xy.2 i := hxy.1.2
    have inv1 : (fun i => c + d * ((xy.1 i - c) / d)) = xy.1 := by
      ext i; obtain ⟨b, -, hb⟩ := h1 i; rw [← hb]
      rw [show c + d * b - c = d * b by ring, Int.mul_ediv_cancel_left _ hd]
    have inv2 : (fun i => c + d * ((xy.2 i - c) / d)) = xy.2 := by
      ext i; obtain ⟨b, -, hb⟩ := h2 i; rw [← hb]
      rw [show c + d * b - c = d * b by ring, Int.mul_ediv_cancel_left _ hd]
    refine ⟨⟨fun i => ?_, fun i => ?_⟩, ?_⟩
    · obtain ⟨b, hb, hb'⟩ := h1 i; rw [← hb']
      rw [show c + d * b - c = d * b by ring, Int.mul_ediv_cancel_left _ hd]; exact hb
    · obtain ⟨b, hb, hb'⟩ := h2 i; rw [← hb']
      rw [show c + d * b - c = d * b by ring, Int.mul_ediv_cancel_left _ hd]; exact hb
    · rw [← psv_affine_iff c d hd, inv1, inv2]; exact hxy.2
  · intro xy _
    simp only
    ext i <;> simp [show ∀ b : ℤ, c + d * b - c = d * b by intro b; ring,
      Int.mul_ediv_cancel_left _ hd]
  · intro xy hxy
    simp only [coe_filter, mem_product, Fintype.mem_piFinset, Set.mem_setOf_eq,
      mem_image] at hxy
    ext i
    · obtain ⟨b, -, hb⟩ := hxy.1.1 i; simp only; rw [← hb]
      rw [show c + d * b - c = d * b by ring, Int.mul_ediv_cancel_left _ hd]
    · obtain ⟨b, -, hb⟩ := hxy.1.2 i; simp only; rw [← hb]
      rw [show c + d * b - c = d * b by ring, Int.mul_ediv_cancel_left _ hd]

/-- a set inside an interval of length `L` has at most the count of `[1, L]` -/
lemma Jc_le_of_subset_interval (n : ℕ) (A : Finset ℤ) (m : ℤ) (L : ℕ)
    (hA : ∀ a ∈ A, m ≤ a ∧ a < m + L) : Jc k n A ≤ Jc k n (Icc 1 (L : ℤ)) := by
  have hsub : A ⊆ (Icc 1 (L : ℤ)).image fun b => (m - 1) + 1 * b := by
    intro a ha
    obtain ⟨h1, h2⟩ := hA a ha
    rw [mem_image]
    exact ⟨a - (m - 1), by rw [mem_Icc]; omega, by ring⟩
  calc Jc k n A ≤ Jc k n ((Icc 1 (L : ℤ)).image fun b => (m - 1) + 1 * b) := Jc_mono n hsub
    _ = Jc k n (Icc 1 (L : ℤ)) := Jc_affine n _ _ _ one_ne_zero

lemma Jc_le_card_pow (n : ℕ) (A : Finset ℤ) : Jc k n A ≤ A.card ^ (2 * n) := by
  unfold Jc
  calc _ ≤ (tup n A ×ˢ tup n A).card := card_filter_le _ _
    _ = A.card ^ (2 * n) := by rw [card_product, card_tup, two_mul, pow_add]

lemma Jc_zero (A : Finset ℤ) : Jc k 0 A = 1 := by
  unfold Jc
  have : (tup 0 A ×ˢ tup 0 A).filter (fun xy => psv k xy.1 = psv k xy.2) =
      tup 0 A ×ˢ tup 0 A := by
    apply filter_true_of_mem
    intro xy _; ext j; simp [psv]
  rw [this, card_product, card_tup]; simp

/-- the count for `[1,N]` is at least... trivial nonnegativity is automatic; the degree-one
count: `J_{n,1}(A) ≤ |A|^{2n-1}` -/
lemma Jc_deg_one (n : ℕ) (hn : 1 ≤ n) (A : Finset ℤ) :
    Jc 1 n A ≤ A.card ^ (2 * n - 1) := by
  classical
  obtain ⟨m, rfl⟩ : ∃ m, n = m + 1 := ⟨n - 1, by omega⟩
  unfold Jc
  set S := (tup (m + 1) A ×ˢ tup (m + 1) A).filter fun xy => psv 1 xy.1 = psv 1 xy.2
  have hinj : Set.InjOn (fun xy : (Fin (m + 1) → ℤ) × (Fin (m + 1) → ℤ) =>
      (xy.1, (Fin.init xy.2 : Fin m → ℤ))) S := by
    intro a ha b hb hab
    simp only [Prod.mk.injEq] at hab
    obtain ⟨h1, h2⟩ := hab
    simp only [S, coe_filter, Set.mem_setOf_eq] at ha hb
    have ea := congrFun ha.2 0
    have eb := congrFun hb.2 0
    simp only [psv, Fin.val_zero, zero_add, pow_one] at ea eb
    simp only [Fin.sum_univ_castSucc] at ea eb
    have hlast : a.2 (Fin.last m) = b.2 (Fin.last m) := by
      have : ∑ i : Fin m, a.2 (Fin.castSucc i) = ∑ i : Fin m, b.2 (Fin.castSucc i) := by
        have := congrFun h2
        exact Finset.sum_congr rfl (fun i _ => this i)
      rw [h1] at ea
      linarith
    have : a.2 = b.2 := by
      ext i
      refine Fin.lastCases ?_ (fun j => ?_) i
      · exact hlast
      · exact congrFun h2 j
    exact Prod.ext h1 this
  calc S.card = (S.image fun xy => (xy.1, (Fin.init xy.2 : Fin m → ℤ))).card :=
        (card_image_of_injOn hinj).symm
    _ ≤ (tup (m + 1) A ×ˢ tup m A).card := by
        apply card_le_card
        intro z hz
        simp only [mem_image, S, mem_filter, mem_product] at hz
        obtain ⟨xy, ⟨⟨h1, h2⟩, _⟩, rfl⟩ := hz
        simp only [mem_product, Fintype.mem_piFinset] at h1 h2 ⊢
        exact ⟨h1, fun i => h2 _⟩
    _ = A.card ^ (2 * (m + 1) - 1) := by
        rw [card_product, card_tup, card_tup, ← pow_add]; congr 1; omega

end GoldB
