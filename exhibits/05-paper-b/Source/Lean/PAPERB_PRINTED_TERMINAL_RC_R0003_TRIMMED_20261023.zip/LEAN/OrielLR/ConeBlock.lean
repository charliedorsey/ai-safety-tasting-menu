import OrielLR.Cone

/-!
# Oriel L/R — the bound for one short variable in the cone
-/

open Finset
open OrielUpper.Mirror

namespace OrielUpper

variable {P : ℕ} [NeZero P]

lemma lowProd_iff {h H r s : ℕ} :
    elarinR0031VKLowProduct h H r s ↔ r * s ≤ ⌊(H : ℝ) / vkM h⌋₊ := by
  unfold elarinR0031VKLowProduct
  have hx : 0 ≤ (H : ℝ) / vkM h := by unfold vkM; positivity
  rw [Nat.le_floor_iff hx, Nat.cast_mul]
  rfl

/-- Top of the low-product window. -/
noncomputable def Wc (H h : ℕ) : ℕ := min (H ^ 2 / 4) ⌊(H : ℝ) / vkM h⌋₊

lemma Wc_le_H (H h : ℕ) : Wc H h ≤ H := by
  unfold Wc
  apply le_trans (min_le_right _ _)
  apply Nat.floor_le_of_le
  rw [div_le_iff₀ (by linarith [vkM_ge_one h])]
  have := vkM_ge_one h
  have : (0 : ℝ) ≤ H := Nat.cast_nonneg _
  nlinarith

lemma karE_mono {cK : ℝ} (hcK : 0 ≤ cK) {N : ℕ} (hN : 1 ≤ N) {X X' : ℝ} (hX : 2 ≤ X)
    (hXX : X ≤ X') : karE cK N X ≤ karE cK N X' := by
  unfold karE
  apply Real.exp_le_exp.mpr
  apply neg_le_neg
  have hlX : 0 < Real.log X := Real.log_pos (by linarith)
  have hlXX : Real.log X ≤ Real.log X' := Real.log_le_log (by linarith) hXX
  have hlN : 0 ≤ Real.log N := Real.log_nonneg (by exact_mod_cast hN)
  apply div_le_div_of_nonneg_left (by positivity) (by positivity)
  exact pow_le_pow_left₀ hlX.le hlXX 2

/-- The per-short-variable envelope. -/
noncomputable def phiLR (P : ℕ) (B E1 E34 Ck cK : ℝ) (D N0 Lb h : ℕ) : ℝ :=
  E34 * (2 * ((P : ℝ) + 1) * B / ((N0 : ℝ) + 1) +
      (D : ℝ) ^ (-(1 / 4 : ℝ)) * ((2 * P + 2) * B * (1 + Real.log h))) +
    E1 * (((P : ℝ) + 1) * B * Lb * Ck * (karE cK N0 h + 2 * P / vkM h))

lemma phiLR_nonneg {B E1 E34 Ck cK : ℝ} {D N0 Lb h : ℕ} (hB : 0 ≤ B) (hE1 : 0 ≤ E1)
    (hE34 : 0 ≤ E34) (hCk : 0 ≤ Ck) (hh : 1 ≤ h) :
    0 ≤ phiLR P B E1 E34 Ck cK D N0 Lb h := by
  unfold phiLR karE
  have : 0 ≤ Real.log h := Real.log_nonneg (by exact_mod_cast hh)
  have := vkM_ge_one h
  positivity

theorem cone_block {F H : ℕ} {w : ℕ → ℝ} {Λ : ZMod P → ℝ} {B : ℝ}
    (hR : RowHyp P F H w Λ B) {m : ℕ} (hm1 : 1 < m) (hmW : bW F m ≠ 0)
    {α β : ZMod P} (hβ : IsUnit β)
    {cK Ck : ℝ} (hcK : 0 < cK) (hCk : 0 ≤ Ck) (hK : KarBound cK Ck)
    {Zh Y D N0 Lb h : ℕ} (hHh : H ≤ h) (hY : Y ^ 3 ≤ Zh) (hYN : (N0 + 1) * P * D ≤ Y)
    (hYD : 2 * D * P ^ 2 + 1 ≤ Y) (hD : 1 ≤ D) (hN0 : 1 ≤ N0) (hLb : h ≤ 2 ^ Lb)
    (hh : 1 ≤ h) {E1 E34 Cτ : ℝ} (hE1 : ∀ N, Asig (F * m) N 1 ≤ E1) (hE34 : ∀ N, Asig (F * m) N (3 / 4) ≤ E34)
    (hτ : ∀ N, ∑ r ∈ Icc 1 N, bW F r * ((r.divisors.card : ℝ) / r) ≤ Cτ) :
    |∑ n ∈ Ioc (max (Zh / m) (m ^ 2)) (Wc H h / m), bW (F * m) n *
        (psiR m H Λ α β (n : ZMod P) (n : ZMod m) (((H - 1 : ℕ) : ℝ) / n) +
          cZero H w Λ / ((m : ℝ) * n))| ≤
      phiLR P B E1 E34 Ck cK D N0 Lb h + (2 * P + 1) * B * Cτ / m := by
  have hB0 := hR.B_nonneg
  have hE1n : 0 ≤ E1 := le_trans (Asig_nonneg _ _ _) (hE1 0)
  have hE34n : 0 ≤ E34 := le_trans (Asig_nonneg _ _ _) (hE34 0)
  have hτ0 : 0 ≤ Cτ := le_trans (by simp) (hτ 0)
  have hmr : (0 : ℝ) < m := by exact_mod_cast (show 0 < m by omega)
  have hrhs0 : 0 ≤ phiLR P B E1 E34 Ck cK D N0 Lb h + (2 * P + 1) * B * Cτ / m := by
    have := phiLR_nonneg (P := P) (D := D) (N0 := N0) (Lb := Lb) (cK := cK) hB0 hE1n hE34n hCk hh
    positivity
  set a := max (Zh / m) (m ^ 2)
  set b := Wc H h / m
  rcases le_or_gt b a with hba | hab
  · rw [Ioc_eq_empty (by omega), sum_empty, abs_zero]; exact hrhs0
  obtain ⟨hA, hX, ha1, hbH, hbm⟩ :=
    cone_conditions (Zh := Zh) (W := Wc H h) (H := H) hm1 (Wc_le_H H h) hY hYN hYD hab
  have hXr : 2 * (D : ℝ) * ((P * m : ℕ) : ℝ) ^ 2 ≤ ((H - 1 : ℕ) : ℝ) := by exact_mod_cast hX
  have hLb' : b ≤ 2 ^ Lb := le_trans hbH (le_trans hHh hLb)
  have hsl := short_long_bound hR hm1 hmW hβ hcK hCk hK ha1 hab.le hD hN0 hA hXr hLb'
    (hE1 b) (hE34 b) hτ (α := α)
  refine hsl.trans ?_
  -- simplify to the uniform envelope
  have hPr : (1 : ℝ) ≤ P := by exact_mod_cast (NeZero.pos P)
  have hDr : (1 : ℝ) ≤ D := by exact_mod_cast hD
  have har : (0 : ℝ) < a := by exact_mod_cast (show 0 < a by omega)
  have hAr : ((N0 : ℝ) + 1) * ((P * m : ℕ) : ℝ) * D ≤ a := by exact_mod_cast hA
  -- (i)
  have hi : (D : ℝ) ^ (3 / 4 : ℝ) * (2 * ((P * m : ℕ) : ℝ) * ((P : ℝ) + 1) * B / a) ≤
      2 * ((P : ℝ) + 1) * B / ((N0 : ℝ) + 1) := by
    have hD34 : (D : ℝ) ^ (3 / 4 : ℝ) ≤ D := by
      calc (D : ℝ) ^ (3 / 4 : ℝ) ≤ (D : ℝ) ^ (1 : ℝ) :=
            Real.rpow_le_rpow_of_exponent_le hDr (by norm_num)
        _ = D := Real.rpow_one _
    have hN1 : (0 : ℝ) < (N0 : ℝ) + 1 := by positivity
    have h0 : 0 ≤ 2 * ((P * m : ℕ) : ℝ) * ((P : ℝ) + 1) * B := by positivity
    calc (D : ℝ) ^ (3 / 4 : ℝ) * (2 * ((P * m : ℕ) : ℝ) * ((P : ℝ) + 1) * B / a)
        ≤ D * (2 * ((P * m : ℕ) : ℝ) * ((P : ℝ) + 1) * B / a) :=
          mul_le_mul_of_nonneg_right hD34 (by positivity)
      _ = 2 * ((P : ℝ) + 1) * B * (((P * m : ℕ) : ℝ) * D / a) := by ring
      _ ≤ 2 * ((P : ℝ) + 1) * B * (1 / ((N0 : ℝ) + 1)) := by
          apply mul_le_mul_of_nonneg_left _ (by positivity)
          rw [div_le_div_iff₀ har hN1]; nlinarith
      _ = 2 * ((P : ℝ) + 1) * B / ((N0 : ℝ) + 1) := by ring
  -- (ii)
  have hii : 1 + Real.log ((b : ℝ) / a) ≤ 1 + Real.log h := by
    have hbr : (0 : ℝ) < b := by exact_mod_cast (show 0 < b by omega)
    have : (b : ℝ) / a ≤ h := by
      rw [div_le_iff₀ har]
      have h1 : (b : ℝ) ≤ h := by exact_mod_cast le_trans hbH hHh
      have h2 : (1 : ℝ) ≤ a := by exact_mod_cast ha1
      nlinarith [(Nat.cast_nonneg h : (0 : ℝ) ≤ h)]
    have := Real.log_le_log (by positivity) this
    linarith
  -- (iii)
  have hH1 : (2 : ℝ) ≤ ((H - 1 : ℕ) : ℝ) := by
    have : 2 ≤ 2 * D * (P * m) ^ 2 := by
      have h1 : 1 ≤ D := hD
      have h2 : 1 ≤ (P * m) ^ 2 := Nat.one_le_pow _ _ (Nat.mul_pos (NeZero.pos P) (by omega))
      nlinarith
    exact_mod_cast le_trans this hX
  have hiii : karE cK N0 ((H - 1 : ℕ) : ℝ) ≤ karE cK N0 h :=
    karE_mono hcK.le hN0 hH1 (by exact_mod_cast le_trans (Nat.sub_le H 1) hHh)
  -- (iv)
  have hiv : (b : ℝ) * ((P * m : ℕ) : ℝ) / ((H - 1 : ℕ) : ℝ) ≤ 2 * P / vkM h := by
    have hM := vkM_ge_one h
    have hWfl : (Wc H h : ℝ) ≤ (H : ℝ) / vkM h := by
      have : Wc H h ≤ ⌊(H : ℝ) / vkM h⌋₊ := min_le_right _ _
      exact le_trans (by exact_mod_cast this) (Nat.floor_le (by positivity))
    have hbm' : (b : ℝ) * m ≤ Wc H h := by exact_mod_cast hbm
    have hH1' : (0 : ℝ) < ((H - 1 : ℕ) : ℝ) := by linarith
    have hHH : (H : ℝ) ≤ 2 * ((H - 1 : ℕ) : ℝ) := by
      have : 2 ≤ H - 1 := by exact_mod_cast hH1
      have : H ≤ 2 * (H - 1) := by omega
      exact_mod_cast this
    have hq : (H : ℝ) / ((H - 1 : ℕ) : ℝ) ≤ 2 := by rw [div_le_iff₀ hH1']; linarith
    have hM0 : 0 < vkM h := by linarith
    calc (b : ℝ) * ((P * m : ℕ) : ℝ) / ((H - 1 : ℕ) : ℝ)
        = (P : ℝ) * ((b : ℝ) * m) / ((H - 1 : ℕ) : ℝ) := by push_cast; ring
      _ ≤ (P : ℝ) * ((H : ℝ) / vkM h) / ((H - 1 : ℕ) : ℝ) := by
          apply div_le_div_of_nonneg_right _ hH1'.le
          exact mul_le_mul_of_nonneg_left (hbm'.trans hWfl) (by positivity)
      _ = ((P : ℝ) / vkM h) * ((H : ℝ) / ((H - 1 : ℕ) : ℝ)) := by ring
      _ ≤ ((P : ℝ) / vkM h) * 2 := mul_le_mul_of_nonneg_left hq (by positivity)
      _ = 2 * P / vkM h := by ring
  unfold phiLR
  have hDm : 0 ≤ (D : ℝ) ^ (-(1 / 4 : ℝ)) := by positivity
  have hLbr : (0 : ℝ) ≤ Lb := Nat.cast_nonneg _
  have k1 : E34 * ((D : ℝ) ^ (3 / 4 : ℝ) * (2 * ((P * m : ℕ) : ℝ) * ((P : ℝ) + 1) * B / a) +
        (D : ℝ) ^ (-(1 / 4 : ℝ)) * ((2 * P + 2) * B * (1 + Real.log ((b : ℝ) / a)))) ≤
      E34 * (2 * ((P : ℝ) + 1) * B / ((N0 : ℝ) + 1) +
        (D : ℝ) ^ (-(1 / 4 : ℝ)) * ((2 * P + 2) * B * (1 + Real.log h))) := by
    apply mul_le_mul_of_nonneg_left _ hE34n
    apply add_le_add hi
    apply mul_le_mul_of_nonneg_left _ hDm
    apply mul_le_mul_of_nonneg_left hii (by positivity)
  have k2 : E1 * (((P : ℝ) + 1) * B * Lb * Ck *
        (karE cK N0 ((H - 1 : ℕ) : ℝ) + b * ((P * m : ℕ) : ℝ) / ((H - 1 : ℕ) : ℝ))) ≤
      E1 * (((P : ℝ) + 1) * B * Lb * Ck * (karE cK N0 h + 2 * P / vkM h)) := by
    apply mul_le_mul_of_nonneg_left _ hE1n
    apply mul_le_mul_of_nonneg_left _ (by positivity)
    apply add_le_add hiii
    simpa [mul_div_assoc] using hiv
  linarith

end OrielUpper
