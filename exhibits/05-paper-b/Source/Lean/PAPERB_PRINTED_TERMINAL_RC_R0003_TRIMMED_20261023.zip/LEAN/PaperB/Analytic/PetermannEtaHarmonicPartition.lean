import PaperB.Analytic.PetermannEtaHarmonicPowerBand
import PaperB.Analytic.PetermannEtaHarmonicFourier
import PaperB.Analytic.PetermannDivisorMoment

open scoped BigOperators

namespace PaperB.Analytic

open Real Finset Nat


open Real Finset Nat

lemma eta_sum_Icc_eq_dyadic_Ico_from_base
    {M : Type} [AddCommMonoid M]
    (f : ℕ → M) {W U : ℕ}
    (hW : 1 ≤ W) (hWU : W ≤ U) :
    (∑ n ∈ Finset.Icc W U, f n) =
      ∑ i ∈ Finset.range (Nat.log 2 (U / W) + 1),
        ∑ n ∈ Finset.Ico (W * 2 ^ i)
            (min (U + 1) (W * 2 ^ (i + 1))),
          f n := by
  classical
  let F := Finset.Icc W U
  let J := Finset.range (Nat.log 2 (U / W) + 1)
  let g : ℕ → ℕ := fun n => Nat.log 2 (n / W)
  have hWpos : 0 < W := by omega
  have hmap : ∀ n ∈ F, g n ∈ J := by
    intro n hn
    rw [Finset.mem_Icc] at hn
    have hdiv : n / W ≤ U / W := Nat.div_le_div_right hn.2
    have hlog := Nat.log_mono_right (b := 2) hdiv
    rw [Finset.mem_range]
    dsimp [g, J]
    omega
  have hfiber := Finset.sum_fiberwise_of_maps_to hmap f
  rw [← hfiber]
  apply Finset.sum_congr rfl
  intro i hi
  rw [Finset.mem_range] at hi
  have hiLog : i ≤ Nat.log 2 (U / W) := by omega
  have hUdivPos : 0 < U / W := Nat.div_pos hWU hWpos
  have hpowU : 2 ^ i ≤ U / W := by
    have hpow := Nat.pow_le_pow_right (by norm_num : 0 < 2) hiLog
    exact hpow.trans (Nat.pow_log_le_self 2 (Nat.ne_of_gt hUdivPos))
  have hstartU : W * 2 ^ i ≤ U := by
    have hm := Nat.mul_le_mul_left W hpowU
    have hmuldiv : W * (U / W) ≤ U := by
      simpa [Nat.mul_comm] using Nat.mul_div_le U W
    exact hm.trans hmuldiv
  have hset :
      F.filter (fun n => g n = i) =
        Finset.Ico (W * 2 ^ i)
          (min (U + 1) (W * 2 ^ (i + 1))) := by
    ext n
    constructor
    · intro hn
      rw [Finset.mem_filter] at hn
      have hnI := Finset.mem_Icc.mp hn.1
      have hlogeq : Nat.log 2 (n / W) = i := hn.2
      have hqpos : 0 < n / W := Nat.div_pos hnI.1 hWpos
      have hlogchar := (Nat.log_eq_iff
        (b := 2) (m := i) (n := n / W)
        (Or.inr ⟨by norm_num, Nat.ne_of_gt hqpos⟩)).mp hlogeq
      rw [Finset.mem_Ico]
      constructor
      · have hlo := (Nat.le_div_iff_mul_le hWpos).mp hlogchar.1
        simpa [Nat.mul_comm] using hlo
      · rw [lt_min_iff]
        constructor
        · omega
        · have hqhi : n / W < 2 ^ (i + 1) := hlogchar.2
          have hlt : n < (2 ^ (i + 1)) * W :=
            (Nat.div_lt_iff_lt_mul hWpos).mp hqhi
          simpa [Nat.mul_comm] using hlt
    · intro hn
      rw [Finset.mem_Ico] at hn
      rw [Finset.mem_filter]
      constructor
      · rw [Finset.mem_Icc]
        constructor
        · have hpow1 : 1 ≤ 2 ^ i := Nat.one_le_pow i 2 (by norm_num)
          have hWstart : W ≤ W * 2 ^ i := by
            simpa using Nat.mul_le_mul_left W hpow1
          exact hWstart.trans hn.1
        · have hlt : n < U + 1 := hn.2.trans_le (min_le_left _ _)
          omega
      · dsimp [g]
        have hloN : W * 2 ^ i ≤ n := hn.1
        have hloQ : 2 ^ i ≤ n / W := by
          have := (Nat.le_div_iff_mul_le hWpos).2
            (by simpa [Nat.mul_comm] using hloN)
          exact this
        have hhiN : n < W * 2 ^ (i + 1) :=
          hn.2.trans_le (min_le_right _ _)
        have hhiQ : n / W < 2 ^ (i + 1) := by
          apply (Nat.div_lt_iff_lt_mul hWpos).2
          simpa [Nat.mul_comm] using hhiN
        exact Nat.log_eq_of_pow_le_of_lt_pow hloQ hhiQ
  rw [hset]

#print axioms eta_sum_Icc_eq_dyadic_Ico_from_base



open Real Finset Nat

private lemma eta_Ico_eq_Icc_pred
    {V E : ℕ} (hVE : V < E) :
    Finset.Ico V E = Finset.Icc V (E - 1) := by
  ext n
  simp only [Finset.mem_Ico, Finset.mem_Icc]
  omega

private lemma eta_actual_power_band_bound
    (k H j : ℕ) (hk : 2 ≤ k) (hj1 : 1 ≤ j) (hjH : j ≤ H)
    (A A' xi : ℝ) (hA : 0 < A) (hAbs : |A'| = (j : ℝ) * A)
    (W U : ℕ) (hW1 : 1 ≤ W) (hkW : k ≤ W) (hWU : W ≤ U)
    (hGeom :
      (∑ i ∈ Finset.range (Nat.log 2 (U / W) + 1),
        (2 / ((W : ℝ) * ((2 ^ i : ℕ) : ℝ)) +
          etaShellC1 k H * A ^ fixedBetaA k *
            ((W : ℝ) * ((2 ^ i : ℕ) : ℝ)) ^ (-(etaShellP k)) +
          etaShellC2 k * A ^ (-(fixedBetaA k)) *
            ((W : ℝ) * ((2 ^ i : ℕ) : ℝ)) ^ etaShellDelta k))
        ≤ etaPowerBandGeomConst k H) :
    ‖∑ n ∈ Finset.Icc W U,
        ((((n : ℝ)⁻¹ : ℝ) : ℂ) *
          eR (A' / (n : ℝ) + xi * (n : ℝ)))‖
      ≤ etaPowerBandGeomConst k H := by
  classical
  let f : ℕ → ℂ := fun n =>
    ((((n : ℝ)⁻¹ : ℝ) : ℂ) *
      eR (A' / (n : ℝ) + xi * (n : ℝ)))
  rw [eta_sum_Icc_eq_dyadic_Ico_from_base f hW1 hWU]
  calc
    ‖∑ i ∈ Finset.range (Nat.log 2 (U / W) + 1),
        ∑ n ∈ Finset.Ico (W * 2 ^ i)
          (min (U + 1) (W * 2 ^ (i + 1))), f n‖
      ≤ ∑ i ∈ Finset.range (Nat.log 2 (U / W) + 1),
          ‖∑ n ∈ Finset.Ico (W * 2 ^ i)
            (min (U + 1) (W * 2 ^ (i + 1))), f n‖ := norm_sum_le _ _
    _ ≤
      ∑ i ∈ Finset.range (Nat.log 2 (U / W) + 1),
        (2 / ((W : ℝ) * ((2 ^ i : ℕ) : ℝ)) +
          etaShellC1 k H * A ^ fixedBetaA k *
            ((W : ℝ) * ((2 ^ i : ℕ) : ℝ)) ^ (-(etaShellP k)) +
          etaShellC2 k * A ^ (-(fixedBetaA k)) *
            ((W : ℝ) * ((2 ^ i : ℕ) : ℝ)) ^ etaShellDelta k) := by
      apply Finset.sum_le_sum
      intro i hi
      rw [Finset.mem_range] at hi
      have hiLog : i ≤ Nat.log 2 (U / W) := by omega
      have hUdivPos : 0 < U / W := Nat.div_pos hWU (by omega)
      have hpowU : 2 ^ i ≤ U / W := by
        have hp := Nat.pow_le_pow_right (by norm_num : 0 < 2) hiLog
        exact hp.trans (Nat.pow_log_le_self 2 (Nat.ne_of_gt hUdivPos))
      let V := W * 2 ^ i
      let E := min (U + 1) (W * 2 ^ (i + 1))
      let B := E - 1
      have hVpos : 0 < V := by dsimp [V]; positivity
      have hVU : V ≤ U := by
        dsimp [V]
        have hm := Nat.mul_le_mul_left W hpowU
        have hmuldiv : W * (U / W) ≤ U := by
          simpa [Nat.mul_comm] using Nat.mul_div_le U W
        exact hm.trans hmuldiv
      have hdouble : W * 2 ^ (i + 1) = 2 * V := by
        dsimp [V]
        rw [pow_succ]
        ring
      have hVE : V < E := by
        dsimp [E]
        rw [lt_min_iff]
        constructor
        · omega
        · rw [hdouble]
          omega
      have hVB : V ≤ B := by
        dsimp [B]
        omega
      have hB2 : B ≤ 2 * V := by
        have hEle : E ≤ 2 * V := by
          have hr0 :
              E ≤ W * 2 ^ (i + 1) := by
            dsimp [E]
            exact min_le_right _ _
          rw [hdouble] at hr0
          exact hr0
        dsimp [B]
        omega
      have hkV : k ≤ V := by
        dsimp [V]
        have hp1 : 1 ≤ 2 ^ i := Nat.one_le_pow i 2 (by norm_num)
        have hm : W ≤ W * 2 ^ i := by
          simpa using Nat.mul_le_mul_left W hp1
        exact hkW.trans hm
      rw [eta_Ico_eq_Icc_pred hVE]
      dsimp [f]
      have hshell := eta_reciprocal_weighted_shell_power_majorant
        k H j hk hj1 hjH A A' xi hA hAbs V B hkV hVB hB2
      simpa [V, etaShellP, Nat.cast_mul, Nat.cast_pow] using hshell
    _ ≤ etaPowerBandGeomConst k H := hGeom

theorem eta_actual_power_band_bound_ge_three
    {k H j : ℕ} (hk : 3 ≤ k) (hj1 : 1 ≤ j) (hjH : j ≤ H)
    {A A' xi : ℝ} (hA1 : 1 ≤ A) (hAbs : |A'| = (j : ℝ) * A)
    {W U : ℕ} (hW1 : 1 ≤ W) (hkW : k ≤ W) (hWU : W ≤ U)
    (hLower : A ^ (1 / (k + 1 : ℝ)) ≤ (W : ℝ))
    (hUpper : (U : ℝ) ≤ A ^ (1 / (k : ℝ))) :
    ‖∑ n ∈ Finset.Icc W U,
        ((((n : ℝ)⁻¹ : ℝ) : ℂ) *
          eR (A' / (n : ℝ) + xi * (n : ℝ)))‖
      ≤ etaPowerBandGeomConst k H := by
  have hA : 0 < A := lt_of_lt_of_le (by norm_num) hA1
  let M := Nat.log 2 (U / W) + 1
  have hlastNat : W * 2 ^ (M - 1) ≤ U := by
    have hUdivPos : 0 < U / W := Nat.div_pos hWU (by omega)
    have hp := Nat.pow_log_le_self 2 (Nat.ne_of_gt hUdivPos)
    dsimp [M]
    have hm := Nat.mul_le_mul_left W hp
    have hmuldiv : W * (U / W) ≤ U := by
      simpa [Nat.mul_comm] using Nat.mul_div_le U W
    simpa using hm.trans hmuldiv
  have hlast :
      (W : ℝ) * ((2 ^ (M - 1) : ℕ) : ℝ) ≤
        A ^ (1 / (k : ℝ)) := by
    have hc : ((W * 2 ^ (M - 1) : ℕ) : ℝ) ≤ (U : ℝ) := by exact_mod_cast hlastNat
    simpa [Nat.cast_mul, Nat.cast_pow] using hc.trans hUpper
  have hGeom := eta_power_band_majorant_sum_ge_three
    (H := H) (M := M) hk hA1 (by exact_mod_cast hW1) hLower hlast
  exact eta_actual_power_band_bound
    k H j (by omega) hj1 hjH A A' xi hA hAbs
    W U hW1 hkW hWU (by simpa [M] using hGeom)

theorem eta_actual_power_band_bound_two
    {H j : ℕ} (hj1 : 1 ≤ j) (hjH : j ≤ H)
    {A A' xi : ℝ} (hA1 : 1 ≤ A) (hAbs : |A'| = (j : ℝ) * A)
    {W U : ℕ} (hW1 : 1 ≤ W) (hW2 : 2 ≤ W) (hWU : W ≤ U)
    (hLower : A ^ (1 / (3 : ℝ)) ≤ (W : ℝ))
    (hUpper : (U : ℝ) ≤ A) :
    ‖∑ n ∈ Finset.Icc W U,
        ((((n : ℝ)⁻¹ : ℝ) : ℂ) *
          eR (A' / (n : ℝ) + xi * (n : ℝ)))‖
      ≤ etaPowerBandGeomConst 2 H := by
  have hA : 0 < A := lt_of_lt_of_le (by norm_num) hA1
  let M := Nat.log 2 (U / W) + 1
  have hlastNat : W * 2 ^ (M - 1) ≤ U := by
    have hUdivPos : 0 < U / W := Nat.div_pos hWU (by omega)
    have hp := Nat.pow_log_le_self 2 (Nat.ne_of_gt hUdivPos)
    dsimp [M]
    have hm := Nat.mul_le_mul_left W hp
    have hmuldiv : W * (U / W) ≤ U := by
      simpa [Nat.mul_comm] using Nat.mul_div_le U W
    simpa using hm.trans hmuldiv
  have hlast :
      (W : ℝ) * ((2 ^ (M - 1) : ℕ) : ℝ) ≤ A := by
    have hc : ((W * 2 ^ (M - 1) : ℕ) : ℝ) ≤ (U : ℝ) := by exact_mod_cast hlastNat
    simpa [Nat.cast_mul, Nat.cast_pow] using hc.trans hUpper
  have hGeom := eta_power_band_majorant_sum_two
    (H := H) (M := M) hA1 (by exact_mod_cast hW1) hLower hlast
  exact eta_actual_power_band_bound
    2 H j (by norm_num) hj1 hjH A A' xi hA hAbs
    W U hW1 hW2 hWU (by simpa [M] using hGeom)

#print axioms eta_actual_power_band_bound_ge_three
#print axioms eta_actual_power_band_bound_two



open Real Finset Nat

noncomputable def etaPowerCutoffN (A : ℝ) (d : ℕ) : ℕ :=
  Nat.floor (A ^ (1 / (d : ℝ)))

lemma etaPowerCutoffN_one_le
    {A : ℝ} (hA1 : 1 ≤ A) {d : ℕ} (hd : 1 ≤ d) :
    1 ≤ etaPowerCutoffN A d := by
  unfold etaPowerCutoffN
  apply Nat.le_floor
  have hdpos : 0 < (d : ℝ) := by exact_mod_cast (show 0 < d by omega)
  have hExp : 0 ≤ 1 / (d : ℝ) := by positivity
  simpa using Real.one_le_rpow hA1 hExp

lemma etaPowerCutoffN_cast_le
    {A : ℝ} (hA0 : 0 ≤ A) (d : ℕ) :
    (etaPowerCutoffN A d : ℝ) ≤ A ^ (1 / (d : ℝ)) := by
  unfold etaPowerCutoffN
  exact Nat.floor_le (Real.rpow_nonneg hA0 _)

lemma eta_initial_harmonic_le
    {K : ℕ} (hK : 2 ≤ K)
    {A : ℝ} (hA1 : 1 ≤ A) :
    (∑ n ∈ Finset.Icc 1 (etaPowerCutoffN A (K + 1)),
        1 / (n : ℝ))
      ≤
    1 + (1 / ((K + 1 : ℕ) : ℝ)) * Real.log A := by
  have hA : 0 < A := lt_of_lt_of_le (by norm_num) hA1
  have hN1 : 1 ≤ etaPowerCutoffN A (K + 1) :=
    etaPowerCutoffN_one_le hA1 (by omega)
  have hsum :
      (∑ n ∈ Finset.Icc 1 (etaPowerCutoffN A (K + 1)),
        1 / (n : ℝ))
      =
      (harmonic (etaPowerCutoffN A (K + 1)) : ℝ) := by
    rw [harmonic_eq_sum_Icc]
    push_cast
    apply Finset.sum_congr rfl
    intro n hn
    norm_num [div_eq_mul_inv]
  rw [hsum]
  calc
    (harmonic (etaPowerCutoffN A (K + 1)) : ℝ)
      ≤ 1 + Real.log (etaPowerCutoffN A (K + 1) : ℝ) := by
        exact harmonic_le_one_add_log _
    _ ≤ 1 + Real.log (A ^ (1 / ((K + 1 : ℕ) : ℝ))) := by
      have hNposR : 0 < (etaPowerCutoffN A (K + 1) : ℝ) := by
        exact_mod_cast (show 0 < etaPowerCutoffN A (K + 1) by omega)
      have hcut := etaPowerCutoffN_cast_le hA.le (K + 1)
      simpa [add_comm] using add_le_add_left (Real.log_le_log hNposR hcut) 1
    _ = 1 + (1 / ((K + 1 : ℕ) : ℝ)) * Real.log A := by
      rw [Real.log_rpow hA]

#print axioms eta_initial_harmonic_le



open Real Finset Nat

lemma etaPowerCutoffN_antitone
    {A : Real} (hA1 : 1 <= A)
    {d e : Nat} (hd : 1 <= d) (hde : d <= e) :
    etaPowerCutoffN A e <= etaPowerCutoffN A d := by
  unfold etaPowerCutoffN
  apply Nat.floor_mono
  have hdr : 0 < (d : Real) := by exact_mod_cast (show 0 < d by omega)
  have her : 0 < (e : Real) := by exact_mod_cast (show 0 < e by omega)
  have hder : (d : Real) <= (e : Real) := by exact_mod_cast hde
  have hinv : (1 / (e : Real)) <= (1 / (d : Real)) := by
    rw [one_div, one_div]
    exact (inv_le_inv₀ her hdr).2 hder
  exact Real.rpow_le_rpow_of_exponent_le hA1 hinv

private lemma eta_sum_Icc_splitN
    {M : Type} [AddCommMonoid M] (f : Nat -> M)
    {a b c : Nat} (hab : a <= b) (hbc : b <= c) :
    (∑ n ∈ Icc a c, f n) =
      (∑ n ∈ Icc a b, f n) +
      (∑ n ∈ Icc (b + 1) c, f n) := by
  have hdis : Disjoint (Icc a b) (Icc (b + 1) c) := by
    rw [Finset.disjoint_left]
    intro x hx1 hx2
    simp only [mem_Icc] at hx1 hx2
    omega
  have hunion : Icc a b ∪ Icc (b + 1) c = Icc a c := by
    ext x
    simp only [mem_union, mem_Icc]
    constructor
    · intro hx
      rcases hx with hx | hx
      · exact ⟨hx.1, hx.2.trans hbc⟩
      · exact ⟨hab.trans (by omega), hx.2⟩
    · intro hx
      by_cases hxb : x <= b
      · exact Or.inl ⟨hx.1, hxb⟩
      · exact Or.inr ⟨by omega, hx.2⟩
  rw [← hunion, sum_union hdis]

private noncomputable def etaCutY (A : Real) (Y d : Nat) : Nat :=
  min Y (etaPowerCutoffN A d)

lemma etaCutY_antitone
    {A : Real} (hA1 : 1 <= A) (Y : Nat)
    {d e : Nat} (hd : 1 <= d) (hde : d <= e) :
    etaCutY A Y e <= etaCutY A Y d := by
  unfold etaCutY
  exact min_le_min_left Y (etaPowerCutoffN_antitone hA1 hd hde)

lemma eta_power_cutoff_nested_partition_prefix
    {M : Type} [AddCommMonoid M] (f : Nat -> M)
    {A : Real} (hA1 : 1 <= A) (Y K : Nat) (hY1 : 1 <= Y) (hK : 2 <= K) :
    (∑ n ∈ Icc 1 (etaCutY A Y 3), f n) =
      (∑ n ∈ Icc 1 (etaCutY A Y (K + 1)), f n) +
      ∑ k ∈ Icc 3 K,
        ∑ n ∈ Icc (etaCutY A Y (k + 1) + 1) (etaCutY A Y k), f n := by
  induction K, hK using Nat.le_induction with
  | base =>
      simp [etaCutY]
  | succ K hK ih =>
      have hK2 : 2 <= K := hK
      have hcut : etaCutY A Y (K + 2) <= etaCutY A Y (K + 1) := by
        apply etaCutY_antitone hA1 Y (d := K + 1) (e := K + 2)
        · omega
        · omega
      have hcut1 : 1 <= etaCutY A Y (K + 2) := by
        unfold etaCutY
        apply le_min hY1
        unfold etaPowerCutoffN
        apply Nat.le_floor
        have hexp : 0 <= 1 / ((K + 2 : Nat) : Real) := by positivity
        simpa using Real.one_le_rpow hA1 hexp
      have hsplit := eta_sum_Icc_splitN f hcut1 hcut
      have hsumlast := Finset.sum_Icc_succ_top
        (show 3 <= K + 1 by omega)
        (fun k => ∑ n ∈ Icc (etaCutY A Y (k + 1) + 1) (etaCutY A Y k), f n)
      rw [ih]
      rw [hsplit]
      rw [hsumlast]
      abel

lemma eta_power_cutoff_nested_partition
    {M : Type} [AddCommMonoid M] (f : Nat -> M)
    {A : Real} (hA1 : 1 <= A) (Y K : Nat) (hY1 : 1 <= Y) (hK : 2 <= K) :
    (∑ n ∈ Icc 1 Y, f n) =
      (∑ n ∈ Icc 1 (etaCutY A Y (K + 1)), f n) +
      (∑ k ∈ Icc 3 K,
        ∑ n ∈ Icc (etaCutY A Y (k + 1) + 1) (etaCutY A Y k), f n) +
      ∑ n ∈ Icc (etaCutY A Y 3 + 1) Y, f n := by
  have hCY : etaCutY A Y 3 <= Y := by
    unfold etaCutY
    exact min_le_left _ _
  have hC1 : 1 <= etaCutY A Y 3 := by
    unfold etaCutY
    apply le_min hY1
    unfold etaPowerCutoffN
    apply Nat.le_floor
    have hexp : 0 <= 1 / (3 : Real) := by norm_num
    simpa using Real.one_le_rpow hA1 hexp
  have hsplit := eta_sum_Icc_splitN f hC1 hCY
  rw [hsplit]
  rw [eta_power_cutoff_nested_partition_prefix f hA1 Y K hY1 hK]


lemma etaPowerBandGeomConst_nonneg {k H : Nat} (hk : 2 <= k) :
    0 <= etaPowerBandGeomConst k H := by
  have hq := etaShellQ_mem_Ioo hk
  have hr := etaShellR_gt_one hk
  have hCk0 : 0 <= reciprocalFiniteOrderConst k :=
    le_trans (by norm_num) (reciprocalFiniteOrderConst_ge_one k)
  have hC10 : 0 <= etaShellC1 k H := by
    unfold etaShellC1
    exact mul_nonneg
      (mul_nonneg (by norm_num) hCk0)
      (Real.rpow_nonneg
        (mul_nonneg (by positivity) (fixedBetaUpperConst_pos k).le) _)
  have hC20 : 0 <= etaShellC2 k := by
    unfold etaShellC2
    exact mul_nonneg
      (mul_nonneg (by norm_num) hCk0)
      (Real.rpow_nonneg (fixedBetaLowerConst_pos k).le _)
  unfold etaPowerBandGeomConst
  have hdq : 0 < 1 - etaShellQ k := sub_pos.mpr hq.2
  have hdr : 0 < etaShellR k - 1 := sub_pos.mpr hr
  have hr0 : 0 <= etaShellR k := le_trans (by norm_num) hr.le
  positivity

lemma etaCutY_eq_cutoff_of_succ_le
    {A : Real} {Y d : Nat}
    (h : etaCutY A Y d + 1 <= Y) :
    etaCutY A Y d = etaPowerCutoffN A d := by
  unfold etaCutY at h ⊢
  by_cases hNY : etaPowerCutoffN A d <= Y
  · exact min_eq_right hNY
  · have hYN : Y <= etaPowerCutoffN A d := by omega
    exfalso
    rw [min_eq_left hYN] at h
    omega

lemma etaCutY_succ_lower_root
    {A : Real} (hA0 : 0 <= A) {Y d : Nat}
    (h : etaCutY A Y d + 1 <= Y) :
    A ^ (1 / (d : Real)) <= (etaCutY A Y d + 1 : Nat) := by
  have heq := etaCutY_eq_cutoff_of_succ_le (A := A) (Y := Y) (d := d) h
  rw [heq]
  simpa [etaPowerCutoffN, Nat.cast_add, Nat.cast_one] using
    (Nat.lt_floor_add_one (A ^ (1 / (d : Real)))).le

lemma etaCutY_upper_root
    {A : Real} (hA0 : 0 <= A) (Y d : Nat) :
    (etaCutY A Y d : Real) <= A ^ (1 / (d : Real)) := by
  have hmin : etaCutY A Y d <= etaPowerCutoffN A d := by
    unfold etaCutY
    exact min_le_right _ _
  have hc : (etaCutY A Y d : Real) <= (etaPowerCutoffN A d : Real) := by
    exact_mod_cast hmin
  exact hc.trans (etaPowerCutoffN_cast_le hA0 d)

lemma eta_initial_harmonic_cut_le
    {K Y : Nat} (hK : 2 <= K) (hY1 : 1 <= Y)
    {A : Real} (hA1 : 1 <= A) :
    (∑ n ∈ Finset.Icc 1 (etaCutY A Y (K + 1)),
        1 / (n : Real))
      <=
    1 + (1 / ((K + 1 : Nat) : Real)) * Real.log A := by
  have hA : 0 < A := lt_of_lt_of_le (by norm_num) hA1
  have hN1 : 1 <= etaCutY A Y (K + 1) := by
    unfold etaCutY
    apply le_min hY1
    exact etaPowerCutoffN_one_le hA1 (by omega)
  have hsum :
      (∑ n ∈ Finset.Icc 1 (etaCutY A Y (K + 1)),
        1 / (n : Real))
      =
      (harmonic (etaCutY A Y (K + 1)) : Real) := by
    rw [harmonic_eq_sum_Icc]
    push_cast
    apply Finset.sum_congr rfl
    intro n hn
    norm_num [div_eq_mul_inv]
  rw [hsum]
  calc
    (harmonic (etaCutY A Y (K + 1)) : Real)
      <= 1 + Real.log (etaCutY A Y (K + 1) : Real) := by
        exact harmonic_le_one_add_log _
    _ <= 1 + Real.log (A ^ (1 / ((K + 1 : Nat) : Real))) := by
      have hNposR : 0 < (etaCutY A Y (K + 1) : Real) := by
        exact_mod_cast (show 0 < etaCutY A Y (K + 1) by omega)
      have hcut := etaCutY_upper_root hA.le Y (K + 1)
      simpa [add_comm] using
        add_le_add_left (Real.log_le_log hNposR hcut) 1
    _ = 1 + (1 / ((K + 1 : Nat) : Real)) * Real.log A := by
      rw [Real.log_rpow hA]


private lemma eta_initial_mode_norm_le
    {K Y : Nat} (hK : 2 <= K) (hY1 : 1 <= Y)
    {A A' xi : Real} (hA1 : 1 <= A) :
    ‖∑ n ∈ Icc 1 (etaCutY A Y (K + 1)),
        ((n : Complex)⁻¹) * eR (A' / (n : Real) + xi * (n : Real))‖
      <=
    1 + (1 / ((K + 1 : Nat) : Real)) * Real.log A := by
  calc
    ‖∑ n ∈ Icc 1 (etaCutY A Y (K + 1)),
        ((n : Complex)⁻¹) * eR (A' / (n : Real) + xi * (n : Real))‖
      <=
    ∑ n ∈ Icc 1 (etaCutY A Y (K + 1)),
      ‖((n : Complex)⁻¹) * eR (A' / (n : Real) + xi * (n : Real))‖ :=
        norm_sum_le _ _
    _ =
    ∑ n ∈ Icc 1 (etaCutY A Y (K + 1)), 1 / (n : Real) := by
      apply Finset.sum_congr rfl
      intro n hn
      rw [norm_mul, norm_inv, norm_eR]
      simp
    _ <=
    1 + (1 / ((K + 1 : Nat) : Real)) * Real.log A :=
      eta_initial_harmonic_cut_le hK hY1 hA1

set_option maxHeartbeats 800000 in
private lemma eta_middle_band_norm_le
    {K H j k Y : Nat} (hK : 2 <= K)
    (hk3 : 3 <= k) (hkK : k <= K)
    (hj1 : 1 <= j) (hjH : j <= H)
    {A A' xi : Real} (hA1 : 1 <= A)
    (hAbs : |A'| = (j : Real) * A)
    (hBase : K <= etaPowerCutoffN A (K + 1) + 1) :
    ‖∑ n ∈ Icc (etaCutY A Y (k + 1) + 1) (etaCutY A Y k),
        ((n : Complex)⁻¹) * eR (A' / (n : Real) + xi * (n : Real))‖
      <= etaPowerBandGeomConst k H := by
  let W := etaCutY A Y (k + 1) + 1
  let U := etaCutY A Y k
  by_cases hWU : W <= U
  · have hW1 : 1 <= W := by dsimp [W]; omega
    have hsuccY : etaCutY A Y (k + 1) + 1 <= Y := by
      have hUY : U <= Y := by
        dsimp [U, etaCutY]
        exact min_le_left _ _
      exact hWU.trans hUY
    have hcutEq : etaCutY A Y (k + 1) = etaPowerCutoffN A (k + 1) :=
      etaCutY_eq_cutoff_of_succ_le hsuccY
    have hmono : etaPowerCutoffN A (K + 1) <= etaPowerCutoffN A (k + 1) := by
      apply etaPowerCutoffN_antitone hA1 (d := k + 1) (e := K + 1)
      · omega
      · omega
    have hkW : k <= W := by
      dsimp [W]
      rw [hcutEq]
      omega
    have hLower :
        A ^ (1 / (k + 1 : Real)) <= (W : Real) := by
      dsimp [W]
      simpa [Nat.cast_add, Nat.cast_one] using
        (etaCutY_succ_lower_root (A := A) (Y := Y) (d := k + 1)
          (le_trans (by norm_num) hA1) hsuccY)
    have hUpper :
        (U : Real) <= A ^ (1 / (k : Real)) := by
      dsimp [U]
      exact etaCutY_upper_root (le_trans (by norm_num) hA1) Y k
    simpa [W, U] using
      (eta_actual_power_band_bound_ge_three
        (k := k) (H := H) (j := j) (xi := xi)
        hk3 hj1 hjH hA1 hAbs hW1 hkW hWU hLower hUpper)
  · have hempty : Icc W U = ∅ := Finset.Icc_eq_empty hWU
    rw [hempty]
    simp
    exact etaPowerBandGeomConst_nonneg (by omega)

set_option maxHeartbeats 800000 in
private lemma eta_terminal_band_norm_le
    {K H j Y : Nat} (hK : 2 <= K)
    (hj1 : 1 <= j) (hjH : j <= H)
    {A A' xi : Real} (hA1 : 1 <= A) (hYA : (Y : Real) <= A)
    (hAbs : |A'| = (j : Real) * A) :
    ‖∑ n ∈ Icc (etaCutY A Y 3 + 1) Y,
        ((n : Complex)⁻¹) * eR (A' / (n : Real) + xi * (n : Real))‖
      <= etaPowerBandGeomConst 2 H := by
  let W := etaCutY A Y 3 + 1
  by_cases hWY : W <= Y
  · have hW1 : 1 <= W := by dsimp [W]; omega
    have hY1 : 1 <= Y := by
      dsimp [W] at hWY
      omega
    have hcut1 : 1 <= etaCutY A Y 3 := by
      unfold etaCutY
      apply le_min hY1
      exact etaPowerCutoffN_one_le hA1 (by norm_num)
    have hW2 : 2 <= W := by
      dsimp [W]
      omega
    have hLower : A ^ (1 / (3 : Real)) <= (W : Real) := by
      dsimp [W]
      exact etaCutY_succ_lower_root (le_trans (by norm_num) hA1) hWY
    simpa [W] using
      (eta_actual_power_band_bound_two
        (H := H) (j := j) (xi := xi) hj1 hjH hA1 hAbs
        hW1 hW2 hWY hLower hYA)
  · have hempty : Icc W Y = ∅ := Finset.Icc_eq_empty hWY
    rw [hempty]
    simp
    exact etaPowerBandGeomConst_nonneg (by norm_num)


set_option maxHeartbeats 1000000 in
theorem eta_reciprocal_weighted_power_band_partition
    {K H j Y : Nat} (hK : 2 <= K) (hY1 : 1 <= Y)
    (hj1 : 1 <= j) (hjH : j <= H)
    {A A' xi : Real} (hA1 : 1 <= A) (hYA : (Y : Real) <= A)
    (hAbs : |A'| = (j : Real) * A)
    (hBase : K <= etaPowerCutoffN A (K + 1) + 1) :
    ‖etaHarmonicAdditiveMode Y A' xi‖
      <=
    1 + (1 / ((K + 1 : Nat) : Real)) * Real.log A +
      ∑ k ∈ Icc 2 K, etaPowerBandGeomConst k H := by
  let f : Nat -> Complex := fun n =>
    ((n : Complex)⁻¹) * eR (A' / (n : Real) + xi * (n : Real))
  have hpart := eta_power_cutoff_nested_partition f hA1 Y K hY1 hK
  have hinit := eta_initial_mode_norm_le
    (K := K) (Y := Y) hK hY1 (A := A) (A' := A') (xi := xi) hA1
  have hmid :
      ‖∑ k ∈ Icc 3 K,
          ∑ n ∈ Icc (etaCutY A Y (k + 1) + 1) (etaCutY A Y k), f n‖
        <=
      ∑ k ∈ Icc 3 K, etaPowerBandGeomConst k H := by
    calc
      ‖∑ k ∈ Icc 3 K,
          ∑ n ∈ Icc (etaCutY A Y (k + 1) + 1) (etaCutY A Y k), f n‖
        <=
      ∑ k ∈ Icc 3 K,
        ‖∑ n ∈ Icc (etaCutY A Y (k + 1) + 1) (etaCutY A Y k), f n‖ :=
          norm_sum_le _ _
      _ <= ∑ k ∈ Icc 3 K, etaPowerBandGeomConst k H := by
        apply Finset.sum_le_sum
        intro k hk
        rw [Finset.mem_Icc] at hk
        dsimp [f]
        exact eta_middle_band_norm_le
          (K := K) (H := H) (j := j) (k := k) (Y := Y)
          hK hk.1 hk.2 hj1 hjH hA1 hAbs hBase
  have hterm := eta_terminal_band_norm_le
    (K := K) (H := H) (j := j) (Y := Y) (xi := xi)
    hK hj1 hjH hA1 hYA hAbs
  have hbands :
      etaPowerBandGeomConst 2 H +
          (∑ k ∈ Icc 3 K, etaPowerBandGeomConst k H)
        = ∑ k ∈ Icc 2 K, etaPowerBandGeomConst k H := by
    have hs := eta_sum_Icc_splitN
      (fun k => etaPowerBandGeomConst k H)
      (a := 2) (b := 2) (c := K) (by norm_num) hK
    simpa using hs.symm
  unfold etaHarmonicAdditiveMode
  change ‖∑ n ∈ Icc 1 Y, f n‖ <= _
  rw [hpart]
  calc
    ‖(∑ n ∈ Icc 1 (etaCutY A Y (K + 1)), f n) +
        (∑ k ∈ Icc 3 K,
          ∑ n ∈ Icc (etaCutY A Y (k + 1) + 1) (etaCutY A Y k), f n) +
        ∑ n ∈ Icc (etaCutY A Y 3 + 1) Y, f n‖
      <=
    ‖∑ n ∈ Icc 1 (etaCutY A Y (K + 1)), f n‖ +
      ‖∑ k ∈ Icc 3 K,
          ∑ n ∈ Icc (etaCutY A Y (k + 1) + 1) (etaCutY A Y k), f n‖ +
      ‖∑ n ∈ Icc (etaCutY A Y 3 + 1) Y, f n‖ := by
        exact le_trans (norm_add_le _ _)
          (add_le_add (norm_add_le _ _) le_rfl)
    _ <=
    (1 + (1 / ((K + 1 : Nat) : Real)) * Real.log A) +
      (∑ k ∈ Icc 3 K, etaPowerBandGeomConst k H) +
      etaPowerBandGeomConst 2 H := by
        exact add_le_add (add_le_add hinit hmid) hterm
    _ =
    1 + (1 / ((K + 1 : Nat) : Real)) * Real.log A +
      ∑ k ∈ Icc 2 K, etaPowerBandGeomConst k H := by
        rw [← hbands]
        ring


lemma eta_base_cutoff_of_power_threshold
    {K : Nat} (hK : 2 <= K) {A : Real}
    (hA : ((K : Real) ^ (K + 1 : Nat)) <= A) :
    K <= etaPowerCutoffN A (K + 1) + 1 := by
  have hK0 : 0 <= (K : Real) := by positivity
  have hpow0 : 0 <= ((K : Real) ^ (K + 1 : Nat)) := by positivity
  have hA0 : 0 <= A := hpow0.trans hA
  have he : 0 <= 1 / ((K + 1 : Nat) : Real) := by positivity
  have hr := Real.rpow_le_rpow hpow0 hA he
  have hleft :
      (((K : Real) ^ (K + 1 : Nat)) ^ (1 / ((K + 1 : Nat) : Real))) =
        (K : Real) := by
    rw [← Real.rpow_natCast (K : Real) (K + 1)]
    rw [← Real.rpow_mul hK0]
    have hk1 : (0 : Real) < ((K + 1 : Nat) : Real) := by positivity
    field_simp [hk1.ne']
    simp
  rw [hleft] at hr
  have hfloor : K <= etaPowerCutoffN A (K + 1) := by
    unfold etaPowerCutoffN
    exact Nat.le_floor hr
  omega

set_option maxHeartbeats 1000000 in
theorem etaHarmonicAdditiveMode_scaled_uniform_sublog
    {eps : Real} (heps : 0 < eps) (H : Nat) :
    ∃ A0 : Nat, 1 <= A0 ∧
      ∀ {A A' xi : Real} {Y j : Nat},
        (A0 : Real) <= A ->
        1 <= Y -> (Y : Real) <= A ->
        1 <= j -> j <= H ->
        |A'| = (j : Real) * A ->
        ‖etaHarmonicAdditiveMode Y A' xi‖ <= eps * Real.log A := by
  obtain ⟨n, hn⟩ := exists_nat_one_div_lt (show 0 < eps / 2 by positivity)
  let K : Nat := n + 2
  have hK : 2 <= K := by dsimp [K]; omega
  let C : Real := 1 + ∑ k ∈ Icc 2 K, etaPowerBandGeomConst k H
  have hC0 : 0 <= C := by
    dsimp [C]
    have hs : 0 <= ∑ k ∈ Icc 2 K, etaPowerBandGeomConst k H := by
      apply Finset.sum_nonneg
      intro k hk
      rw [Finset.mem_Icc] at hk
      exact etaPowerBandGeomConst_nonneg hk.1
    linarith
  have heh : 0 < eps / 2 := by positivity
  let Tpow : Real := (K : Real) ^ (K + 1 : Nat)
  let Tlog : Real := Real.exp (C / (eps / 2))
  obtain ⟨A0, hA0⟩ := exists_nat_gt (max Tpow Tlog)
  have hA01 : 1 <= A0 := by
    have hTlogpos : 0 < Tlog := by dsimp [Tlog]; positivity
    have hpos : 0 < (A0 : Real) := lt_of_lt_of_le hTlogpos (le_trans (le_max_right _ _) hA0.le)
    have hA0pos : 0 < A0 := by exact_mod_cast hpos
    omega
  refine ⟨A0, hA01, ?_⟩
  intro A A' xi Y j hA0A hY1 hYA hj1 hjH hAbs
  have hpowA : Tpow <= A :=
    (le_trans (le_max_left _ _) hA0.le).trans hA0A
  have hlogA : Tlog <= A :=
    (le_trans (le_max_right _ _) hA0.le).trans hA0A
  have hA1 : 1 <= A := by
    have hKreal : (1 : Real) <= (K : Real) := by exact_mod_cast (show 1 <= K by omega)
    have hTpow1 : 1 <= Tpow := by
      dsimp [Tpow]
      exact one_le_pow₀ hKreal
    exact hTpow1.trans hpowA
  have hBase : K <= etaPowerCutoffN A (K + 1) + 1 := by
    apply eta_base_cutoff_of_power_threshold hK
    simpa [Tpow] using hpowA
  have hpart := eta_reciprocal_weighted_power_band_partition
    (K := K) (H := H) (j := j) (Y := Y) (xi := xi)
    hK hY1 hj1 hjH hA1 hYA hAbs hBase
  have hcoeff0 : 0 <= Real.log A := Real.log_nonneg hA1
  have hcoeff :
      1 / ((K + 1 : Nat) : Real) <= eps / 2 := by
    have hsmall := Nat.one_div_le_one_div (α := Real)
      (n := n) (m := n + 2) (by omega)
    dsimp [K]
    simpa [Nat.cast_add, Nat.cast_one] using hsmall.trans hn.le
  have hloglower : C / (eps / 2) <= Real.log A := by
    apply (Real.le_log_iff_exp_le (lt_of_lt_of_le (by norm_num) hA1)).2
    simpa [Tlog] using hlogA
  have hCabs : C <= (eps / 2) * Real.log A := by
    have hm := mul_le_mul_of_nonneg_left hloglower heh.le
    have hcancel : (eps / 2) * (C / (eps / 2)) = C := by
      field_simp [heh.ne']
    rw [hcancel] at hm
    exact hm
  have hlogpart :
      (1 / ((K + 1 : Nat) : Real)) * Real.log A
        <= (eps / 2) * Real.log A :=
    mul_le_mul_of_nonneg_right hcoeff hcoeff0
  dsimp [C] at hCabs
  calc
    ‖etaHarmonicAdditiveMode Y A' xi‖
      <= 1 + (1 / ((K + 1 : Nat) : Real)) * Real.log A +
          ∑ k ∈ Icc 2 K, etaPowerBandGeomConst k H := hpart
    _ <= (eps / 2) * Real.log A + (eps / 2) * Real.log A := by
      linarith
    _ = eps * Real.log A := by ring

#print axioms etaHarmonicAdditiveMode_scaled_uniform_sublog

#print axioms eta_reciprocal_weighted_power_band_partition

#print axioms eta_power_cutoff_nested_partition_prefix
#print axioms eta_power_cutoff_nested_partition


end PaperB.Analytic
