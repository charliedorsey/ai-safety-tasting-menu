import PaperB.FixedQ.FixedConductorCompletion
import PaperB.FixedQ.H2BooleanDyadicMoments

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def ramanujanResonantPrimeFactor (p : ℕ) : ℝ :=
  Real.sqrt (p : ℝ) / ((p : ℝ) - 3)

noncomputable def ramanujanNonresonantPrimeFactor (p : ℕ) : ℝ :=
  Real.sqrt (p : ℝ) / (((p : ℝ) - 3) * ((p : ℝ) - 1))

noncomputable def ramanujanRankinPrimeFactor (j p : ℕ) : ℝ :=
  if p ∣ j then ramanujanResonantPrimeFactor p
  else ramanujanNonresonantPrimeFactor p

noncomputable def ramanujanRankinSetWeight
    (j : ℕ) (S : Finset ℕ) : ℝ :=
  ∏ p ∈ S, ramanujanRankinPrimeFactor j p

noncomputable def ramanujanResonantSurcharge
    (j : ℕ) : ℝ :=
  ∏ p ∈ j.primeFactors.filter (fun p => 5 ≤ p),
    (1 + ramanujanResonantPrimeFactor p)

lemma ramanujanResonantPrimeFactor_nonneg
    {p : ℕ} (hp : 5 ≤ p) :
    0 ≤ ramanujanResonantPrimeFactor p := by
  unfold ramanujanResonantPrimeFactor
  have hpR : (5 : ℝ) ≤ p := by exact_mod_cast hp
  have hsqrt0 : 0 ≤ Real.sqrt (p : ℝ) := Real.sqrt_nonneg _
  have hden0 : 0 ≤ (p : ℝ) - 3 := by linarith
  exact div_nonneg hsqrt0 hden0

lemma ramanujanNonresonantPrimeFactor_nonneg
    {p : ℕ} (hp : 5 ≤ p) :
    0 ≤ ramanujanNonresonantPrimeFactor p := by
  unfold ramanujanNonresonantPrimeFactor
  have hpR : (5 : ℝ) ≤ p := by exact_mod_cast hp
  have hsqrt0 : 0 ≤ Real.sqrt (p : ℝ) := Real.sqrt_nonneg _
  have hsub3 : 0 ≤ (p : ℝ) - 3 := by linarith
  have hsub1 : 0 ≤ (p : ℝ) - 1 := by linarith
  have hden0 : 0 ≤ ((p : ℝ) - 3) * ((p : ℝ) - 1) :=
    mul_nonneg hsub3 hsub1
  exact div_nonneg hsqrt0 hden0

lemma ramanujanNonresonantPrimeFactor_le_gamma
    {p : ℕ} (hp : 5 ≤ p) :
    ramanujanNonresonantPrimeFactor p ≤ gammaPrimeTerm p := by
  unfold ramanujanNonresonantPrimeFactor gammaPrimeTerm
  rw [if_pos hp]
  have hpR : (5 : ℝ) ≤ p := by exact_mod_cast hp
  have hp0 : (0 : ℝ) < p := by positivity
  have hsqrt : 0 < Real.sqrt (p : ℝ) := Real.sqrt_pos.2 hp0
  have hsub3 : (0 : ℝ) < (p : ℝ) - 3 := by linarith
  have hsub1 : (0 : ℝ) < (p : ℝ) - 1 := by linarith
  have hsqrt_sq : Real.sqrt (p : ℝ) ^ 2 = (p : ℝ) := by
    rw [Real.sq_sqrt hp0.le]
  apply (div_le_div_iff₀
    (mul_pos hsub3 hsub1)
    (mul_pos hsub3 hsqrt)).2
  nlinarith

lemma ramanujanRankinPrimeFactor_nonneg
    {j p : ℕ} (hp : 5 ≤ p) :
    0 ≤ ramanujanRankinPrimeFactor j p := by
  unfold ramanujanRankinPrimeFactor
  split_ifs
  · exact ramanujanResonantPrimeFactor_nonneg hp
  · exact ramanujanNonresonantPrimeFactor_nonneg hp

lemma ramanujanRankinSetWeight_nonneg
    {j : ℕ} {S : Finset ℕ}
    (h5 : ∀ p ∈ S, 5 ≤ p) :
    0 ≤ ramanujanRankinSetWeight j S := by
  unfold ramanujanRankinSetWeight
  exact Finset.prod_nonneg (fun p hp =>
    ramanujanRankinPrimeFactor_nonneg (h5 p hp))

lemma ramanujanRankinSetWeight_split
    (j : ℕ) (S : Finset ℕ) :
    ramanujanRankinSetWeight j S =
      (∏ p ∈ S.filter (fun p => p ∣ j),
        ramanujanResonantPrimeFactor p) *
      (∏ p ∈ S.filter (fun p => ¬ p ∣ j),
        ramanujanNonresonantPrimeFactor p) := by
  classical
  unfold ramanujanRankinSetWeight
  rw [← Finset.prod_filter_mul_prod_filter_not
    (s := S) (p := fun p => p ∣ j)
    (f := fun p => ramanujanRankinPrimeFactor j p)]
  apply congrArg₂ (· * ·)
  · apply Finset.prod_congr rfl
    intro p hp
    simp only [Finset.mem_filter] at hp
    simp [ramanujanRankinPrimeFactor, hp.2]
  · apply Finset.prod_congr rfl
    intro p hp
    simp only [Finset.mem_filter] at hp
    simp [ramanujanRankinPrimeFactor, hp.2]

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem ramanujanRankinPowerset_sum_eq_eulerProduct
    (j : ℕ) (P : Finset ℕ) :
    (∑ S ∈ P.powerset, ramanujanRankinSetWeight j S) =
      ∏ p ∈ P, (1 + ramanujanRankinPrimeFactor j p) := by
  unfold ramanujanRankinSetWeight
  symm
  simpa [add_comm] using
    (Finset.prod_add
      (fun p : ℕ => ramanujanRankinPrimeFactor j p)
      (fun _p : ℕ => (1 : ℝ))
      P)

lemma h2Exterior_one_le_prod_real
    {s : Finset ℕ} {f : ℕ → ℝ}
    (h : ∀ i ∈ s, 1 ≤ f i) :
    1 ≤ ∏ i ∈ s, f i := by
  induction s using Finset.induction_on with
  | empty => simp
  | @insert a s ha ih =>
      rw [Finset.prod_insert ha]
      have ha1 : 1 ≤ f a := h a (Finset.mem_insert_self a s)
      have hs1 : 1 ≤ ∏ i ∈ s, f i :=
        ih (fun i hi => h i (Finset.mem_insert_of_mem hi))
      calc
        (1 : ℝ) = 1 * 1 := by ring
        _ ≤ f a * ∏ i ∈ s, f i :=
          mul_le_mul ha1 hs1 (by norm_num) (by linarith)

lemma h2Exterior_prod_le_prod_real
    {s : Finset ℕ} {f g : ℕ → ℝ}
    (hf : ∀ i ∈ s, 0 ≤ f i)
    (hg : ∀ i ∈ s, 0 ≤ g i)
    (hfg : ∀ i ∈ s, f i ≤ g i) :
    (∏ i ∈ s, f i) ≤ ∏ i ∈ s, g i := by
  induction s using Finset.induction_on with
  | empty => simp
  | @insert a s ha ih =>
      rw [Finset.prod_insert ha, Finset.prod_insert ha]
      exact mul_le_mul
        (hfg a (Finset.mem_insert_self a s))
        (ih
          (fun i hi => hf i (Finset.mem_insert_of_mem hi))
          (fun i hi => hg i (Finset.mem_insert_of_mem hi))
          (fun i hi => hfg i (Finset.mem_insert_of_mem hi)))
        (Finset.prod_nonneg
          (fun i hi => hf i (Finset.mem_insert_of_mem hi)))
        (hg a (Finset.mem_insert_self a s))

lemma ramanujan_resonant_filter_subset_primeFactors
    {j : ℕ} (hj : 0 < j)
    {P : Finset ℕ} (hPrime : ∀ p ∈ P, p.Prime)
    (h5 : ∀ p ∈ P, 5 ≤ p) :
    P.filter (fun p => p ∣ j) ⊆
      j.primeFactors.filter (fun p => 5 ≤ p) := by
  intro p hp
  have hpm := Finset.mem_filter.mp hp
  apply Finset.mem_filter.mpr
  constructor
  · exact Nat.mem_primeFactors.mpr
      ⟨hPrime p hpm.1, hpm.2, hj.ne'⟩
  · exact h5 p hpm.1

lemma ramanujan_resonant_euler_le_surcharge
    {j : ℕ} (hj : 0 < j)
    {P : Finset ℕ} (hPrime : ∀ p ∈ P, p.Prime)
    (h5 : ∀ p ∈ P, 5 ≤ p) :
    (∏ p ∈ P.filter (fun p => p ∣ j),
      (1 + ramanujanResonantPrimeFactor p)) ≤
      ramanujanResonantSurcharge j := by
  unfold ramanujanResonantSurcharge
  let R := P.filter (fun p => p ∣ j)
  let J := j.primeFactors.filter (fun p => 5 ≤ p)
  have hsub : R ⊆ J := by
    simpa [R, J] using
      ramanujan_resonant_filter_subset_primeFactors hj hPrime h5
  have hdiff1 :
      1 ≤ ∏ p ∈ J \ R, (1 + ramanujanResonantPrimeFactor p) := by
    apply h2Exterior_one_le_prod_real
    intro p hp
    have hpJ := (Finset.mem_sdiff.mp hp).1
    have hp5 := (Finset.mem_filter.mp hpJ).2
    linarith [ramanujanResonantPrimeFactor_nonneg hp5]
  have hR0 :
      0 ≤ ∏ p ∈ R, (1 + ramanujanResonantPrimeFactor p) := by
    apply Finset.prod_nonneg
    intro p hp
    have hpP := (Finset.mem_filter.mp hp).1
    linarith [ramanujanResonantPrimeFactor_nonneg (h5 p hpP)]
  have hfactor :=
    Finset.prod_sdiff hsub
      (f := fun p => (1 + ramanujanResonantPrimeFactor p))
  change (∏ p ∈ R, (1 + ramanujanResonantPrimeFactor p)) ≤
    ∏ p ∈ J, (1 + ramanujanResonantPrimeFactor p)
  rw [← hfactor]
  nlinarith [mul_le_mul_of_nonneg_right hdiff1 hR0]

lemma ramanujan_nonresonant_euler_le_gamma
    {j : ℕ} {P : Finset ℕ}
    (h5 : ∀ p ∈ P, 5 ≤ p) :
    (∏ p ∈ P.filter (fun p => ¬ p ∣ j),
      (1 + ramanujanNonresonantPrimeFactor p)) ≤
      Real.exp (∑' n : ℕ, gammaPrimeTerm n) := by
  let T := P.filter (fun p => ¬ p ∣ j)
  calc
    (∏ p ∈ T, (1 + ramanujanNonresonantPrimeFactor p))
      ≤ ∏ p ∈ T, (1 + gammaPrimeTerm p) := by
        apply h2Exterior_prod_le_prod_real
        · intro p hp
          have hpP := (Finset.mem_filter.mp hp).1
          linarith [ramanujanNonresonantPrimeFactor_nonneg (h5 p hpP)]
        · intro p hp
          linarith [gammaPrimeTerm_nonneg p]
        · intro p hp
          have hpP := (Finset.mem_filter.mp hp).1
          linarith [ramanujanNonresonantPrimeFactor_le_gamma (h5 p hpP)]
    _ ≤ Real.exp (∑' n : ℕ, gammaPrimeTerm n) :=
      gammaEulerProduct_uniform_bound T

theorem ramanujanRankinPowerset_sum_le
    {j : ℕ} (hj : 0 < j)
    {P : Finset ℕ} (hPrime : ∀ p ∈ P, p.Prime)
    (h5 : ∀ p ∈ P, 5 ≤ p) :
    (∑ S ∈ P.powerset, ramanujanRankinSetWeight j S) ≤
      ramanujanResonantSurcharge j *
        Real.exp (∑' n : ℕ, gammaPrimeTerm n) := by
  rw [ramanujanRankinPowerset_sum_eq_eulerProduct]
  have hsplit :
      (∏ p ∈ P, (1 + ramanujanRankinPrimeFactor j p)) =
        (∏ p ∈ P.filter (fun p => p ∣ j),
          (1 + ramanujanResonantPrimeFactor p)) *
        (∏ p ∈ P.filter (fun p => ¬ p ∣ j),
          (1 + ramanujanNonresonantPrimeFactor p)) := by
    rw [← Finset.prod_filter_mul_prod_filter_not
      (s := P) (p := fun p => p ∣ j)
      (f := fun p => 1 + ramanujanRankinPrimeFactor j p)]
    apply congrArg₂ (· * ·)
    · apply Finset.prod_congr rfl
      intro p hp
      have hpd := (Finset.mem_filter.mp hp).2
      simp [ramanujanRankinPrimeFactor, hpd]
    · apply Finset.prod_congr rfl
      intro p hp
      have hpd := (Finset.mem_filter.mp hp).2
      simp [ramanujanRankinPrimeFactor, hpd]
  rw [hsplit]
  exact mul_le_mul
    (ramanujan_resonant_euler_le_surcharge hj hPrime h5)
    (ramanujan_nonresonant_euler_le_gamma h5)
    (by
      apply Finset.prod_nonneg
      intro p hp
      have hpP := (Finset.mem_filter.mp hp).1
      linarith [ramanujanNonresonantPrimeFactor_nonneg (h5 p hpP)])
    (by
      unfold ramanujanResonantSurcharge
      apply Finset.prod_nonneg
      intro p hp
      have hp5 := (Finset.mem_filter.mp hp).2
      linarith [ramanujanResonantPrimeFactor_nonneg hp5])

#print axioms ramanujanRankinPowerset_sum_le

end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def ramanujanMeanPrimeFactor (j p : ℕ) : ℝ :=
  if p ∣ j then 1 / ((p : ℝ) - 3)
  else 1 / (((p : ℝ) - 3) * ((p : ℝ) - 1))

noncomputable def ramanujanMeanSetWeight
    (j : ℕ) (S : Finset ℕ) : ℝ :=
  ∏ p ∈ S, ramanujanMeanPrimeFactor j p

lemma ramanujanMeanPrimeFactor_nonneg
    {j p : ℕ} (hp : 5 ≤ p) :
    0 ≤ ramanujanMeanPrimeFactor j p := by
  unfold ramanujanMeanPrimeFactor
  have hpR : (5 : ℝ) ≤ p := by exact_mod_cast hp
  split_ifs
  · exact div_nonneg (by norm_num) (by linarith)
  · exact div_nonneg (by norm_num)
      (mul_nonneg (by linarith) (by linarith))

lemma ramanujanMeanSetWeight_nonneg
    {j : ℕ} {S : Finset ℕ}
    (h5 : ∀ p ∈ S, 5 ≤ p) :
    0 ≤ ramanujanMeanSetWeight j S := by
  unfold ramanujanMeanSetWeight
  apply Finset.prod_nonneg
  intro p hp
  exact ramanujanMeanPrimeFactor_nonneg (h5 p hp)

lemma sqrt_product_mul_ramanujanMeanSetWeight
    (j : ℕ) (S : Finset ℕ) :
    Real.sqrt (primeSetProduct S : ℝ) *
        ramanujanMeanSetWeight j S =
      ramanujanRankinSetWeight j S := by
  unfold primeSetProduct ramanujanMeanSetWeight ramanujanRankinSetWeight
  rw [Nat.cast_prod, Real.sqrt_prod]
  · rw [← Finset.prod_mul_distrib]
    apply Finset.prod_congr rfl
    intro p hp
    unfold ramanujanMeanPrimeFactor ramanujanRankinPrimeFactor
      ramanujanResonantPrimeFactor ramanujanNonresonantPrimeFactor
    by_cases hd : p ∣ j
    · simp [hd]
      ring
    · simp [hd, div_eq_mul_inv, mul_inv_rev, mul_comm, mul_left_comm,
        mul_assoc]
  · intro p hp
    positivity

lemma ramanujanMeanSetWeight_le_rankin_of_product_gt
    {j Y : ℕ} {S : Finset ℕ}
    (hY : 0 < Y)
    (hprod : Y < primeSetProduct S)
    (h5 : ∀ p ∈ S, 5 ≤ p) :
    ramanujanMeanSetWeight j S ≤
      (Real.sqrt (Y : ℝ))⁻¹ * ramanujanRankinSetWeight j S := by
  have hYR : (0 : ℝ) < Y := by exact_mod_cast hY
  have hmR : (Y : ℝ) < primeSetProduct S := by exact_mod_cast hprod
  have hsqrtY : 0 < Real.sqrt (Y : ℝ) := Real.sqrt_pos.2 hYR
  have hsqrt :
      Real.sqrt (Y : ℝ) ≤ Real.sqrt (primeSetProduct S : ℝ) :=
    Real.sqrt_le_sqrt hmR.le
  have hw0 : 0 ≤ ramanujanMeanSetWeight j S :=
    ramanujanMeanSetWeight_nonneg h5
  rw [inv_mul_eq_div]
  apply (le_div_iff₀ hsqrtY).2
  rw [mul_comm]
  calc
    Real.sqrt (Y : ℝ) * ramanujanMeanSetWeight j S
      ≤ Real.sqrt (primeSetProduct S : ℝ) *
          ramanujanMeanSetWeight j S :=
        mul_le_mul_of_nonneg_right hsqrt hw0
    _ = ramanujanRankinSetWeight j S :=
      sqrt_product_mul_ramanujanMeanSetWeight j S

theorem ramanujanMeanPowerset_tail_le
    {j Y : ℕ} (hj : 0 < j) (hY : 0 < Y)
    {P : Finset ℕ} (hPrime : ∀ p ∈ P, p.Prime)
    (h5 : ∀ p ∈ P, 5 ≤ p) :
    (∑ S ∈ P.powerset.filter
        (fun S => Y < primeSetProduct S),
        ramanujanMeanSetWeight j S) ≤
      (Real.sqrt (Y : ℝ))⁻¹ *
        ramanujanResonantSurcharge j *
        Real.exp (∑' n : ℕ, gammaPrimeTerm n) := by
  let T := P.powerset.filter (fun S => Y < primeSetProduct S)
  have hpoint :
      (∑ S ∈ T, ramanujanMeanSetWeight j S) ≤
        (Real.sqrt (Y : ℝ))⁻¹ *
          (∑ S ∈ T, ramanujanRankinSetWeight j S) := by
    rw [Finset.mul_sum]
    apply Finset.sum_le_sum
    intro S hS
    have hmem := Finset.mem_filter.mp hS
    exact ramanujanMeanSetWeight_le_rankin_of_product_gt
      hY hmem.2 (fun p hp => h5 p (Finset.mem_powerset.mp hmem.1 hp))
  have hsubset : T ⊆ P.powerset := Finset.filter_subset _ _
  have hrank0 :
      ∀ S ∈ P.powerset, 0 ≤ ramanujanRankinSetWeight j S := by
    intro S hS
    exact ramanujanRankinSetWeight_nonneg
      (fun p hp => h5 p (Finset.mem_powerset.mp hS hp))
  have hsubsum :
      (∑ S ∈ T, ramanujanRankinSetWeight j S) ≤
        ∑ S ∈ P.powerset, ramanujanRankinSetWeight j S := by
    apply Finset.sum_le_sum_of_subset_of_nonneg hsubset
    intro S hSP hnot
    exact hrank0 S hSP
  have hEuler :=
    ramanujanRankinPowerset_sum_le hj hPrime h5
  have hInv0 : 0 ≤ (Real.sqrt (Y : ℝ))⁻¹ := by positivity
  calc
    (∑ S ∈ T, ramanujanMeanSetWeight j S)
      ≤ (Real.sqrt (Y : ℝ))⁻¹ *
          (∑ S ∈ T, ramanujanRankinSetWeight j S) := hpoint
    _ ≤ (Real.sqrt (Y : ℝ))⁻¹ *
          (∑ S ∈ P.powerset, ramanujanRankinSetWeight j S) :=
      mul_le_mul_of_nonneg_left hsubsum hInv0
    _ ≤ (Real.sqrt (Y : ℝ))⁻¹ *
          (ramanujanResonantSurcharge j *
            Real.exp (∑' n : ℕ, gammaPrimeTerm n)) :=
      mul_le_mul_of_nonneg_left hEuler hInv0
    _ = (Real.sqrt (Y : ℝ))⁻¹ *
        ramanujanResonantSurcharge j *
        Real.exp (∑' n : ℕ, gammaPrimeTerm n) := by ring

#print axioms ramanujanMeanPowerset_tail_le

end PaperB.FixedQ
