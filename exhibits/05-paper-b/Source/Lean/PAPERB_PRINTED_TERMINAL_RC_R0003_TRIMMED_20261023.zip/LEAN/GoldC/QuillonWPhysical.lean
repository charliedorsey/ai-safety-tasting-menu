import GoldC.QuillonWFinal

/-!
# Quillon CSC3 F8.7: the **physical W′ theorem** (integrated, end-to-end for the W′ cell)

For every `d` (decoration), the W′ part of the actual CORE pair sum

    WPart_d = Σ_{B,C ⊆ T_d} 1[B,C ≠ ∅, B∩C = ∅, Mk₀(B,C), B ∩ J_W(C) ≠ ∅] · ω(B)ω(C) · foldRow(D,H,∏B,∏C)

satisfies `|WPart_d| ≤ Λ^{−80}` for `Λ = log h ≥ Λ₀(q, δ)`, uniformly in `a`, `d`, `Jlow`, `Jhigh`.
* `T_d = ordinaryFiniteSupport q H d (H²+1)` and `H = h/∏d`.
* `Mk₀` is the exact source pair mask from `pairTerm`: `Z < rs`, `4rs ≤ H²`,
  `Jlow ≤ |B|+|C| < Jhigh`, `¬longEither δ`, `centralGate h`.
* `J_W(C) = (T∖C) ∩ [X, ⌊s^{u₀}⌋]`, with `X = ⌈Λ^{200}⌉`.

All suppliers meet in this one theorem:
* the source copies;
* `pairSum`-shape double sum, `double_sum_fixC`;
* the bridge `foldRow = rowAbs`;
* `W_cell` (R0010: `W_context`, `W_bilinear_full`, `W_cell_coupled`, Ramaré);
* the explicit majorant `WTerm_le`;
* the eventual analysis `W_term_ev`;
* the outer mass `Σ_C ω(C) ≤ e^{10}5^{10}Λ^{10}`.

No axiom, no `sorry`.
-/

open scoped BigOperators Classical
open Finset

namespace GoldC.QuillonWPhysical

open GoldC.QuillonCopyS GoldC.QuillonCopyF GoldC.QuillonCopyM GoldC.QuillonSetup GoldC.QuillonEv
  GoldC.QuillonWContext

/-- The active prime universe of decoration `d`. -/
noncomputable def Tsrc (q h : ℕ) (d : Finset ℕ) : Finset ℕ :=
  ordinaryFiniteSupport q (h / primeSetProduct d) d ((h / primeSetProduct d) ^ 2 + 1)

/-- The exact CORE pair mask (the `pairTerm` condition after `B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C`). -/
def Mk0 (Jlow Jhigh h H : ℕ) (δ : ℝ) (B C : Finset ℕ) : Prop :=
  originalZ h < primeSetProduct B * primeSetProduct C ∧
    4 * (primeSetProduct B * primeSetProduct C) ≤ H ^ 2 ∧
    Jlow ≤ B.card + C.card ∧ B.card + C.card < Jhigh ∧
    ¬ longEither δ (primeSetProduct B) (primeSetProduct C) ∧
    centralGate h H (primeSetProduct B) (primeSetProduct C)

/-- The W′ cell: `B` has a prime in `[X, ⌊s^{u₀}⌋]`. -/
def WMask (h : ℕ) (δ : ℝ) (T B C : Finset ℕ) : Prop :=
  (B ∩ (T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ Yp δ (∏ p ∈ C, p))).Nonempty

/-- The W′ part of the CORE pair sum at decoration `d`. -/
noncomputable def WPart (Jlow Jhigh q a h : ℕ) (δ : ℝ) (d : Finset ℕ) : ℝ :=
  ∑ B ∈ (Tsrc q h d).powerset, ∑ C ∈ (Tsrc q h d).powerset,
    if B ≠ ∅ ∧ C ≠ ∅ ∧ Disjoint B C ∧
        (Mk0 Jlow Jhigh h (h / primeSetProduct d) δ B C ∧ WMask h δ (Tsrc q h d) B C) then
      omegaWeight B * omegaWeight C *
        foldRow q a (primeSetProduct d) (h / primeSetProduct d) (primeSetProduct B) (primeSetProduct C)
    else 0

lemma Tsrc_facts (q h : ℕ) (d : Finset ℕ) :
    ∀ p ∈ Tsrc q h d, p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q ∧ p.Coprime (h / primeSetProduct d) ∧
      p ≤ (h / primeSetProduct d) ^ 2 := by
  intro p hp
  simp only [Tsrc, ordinaryFiniteSupport, mem_filter, mem_range] at hp
  obtain ⟨hlt, hact, hH, -⟩ := hp
  obtain ⟨hpp, h5, hq⟩ := hact
  exact ⟨hpp, h5, hq, (Nat.Prime.coprime_iff_not_dvd hpp).2 hH, by omega⟩

/-- The outer mass `Σ_{C ⊆ T} ω(C) ≤ e^{10}5^{10}Λ^{10}`. -/
lemma outer_mass (q h : ℕ) (d : Finset ℕ) (hh : 1 ≤ Real.log h) :
    ∑ C ∈ (Tsrc q h d).powerset, ωR C ≤ Real.exp 10 * (2 * 2 + 1) ^ 10 * (Real.log h) ^ (10 : ℝ) := by
  rw [sum_ωR_powerset]
  have hT := Tsrc_facts q h d
  have hh0 : (0 : ℝ) < h := by
    by_contra hc; push_neg at hc
    have : (h : ℝ) = 0 := le_antisymm hc (by positivity)
    rw [this, Real.log_zero] at hh; linarith
  refine GoldC.QuillonLam.prodU_le_pow _ (fun p hp => ⟨(hT p hp).1, (hT p hp).2.1⟩) (h ^ 2)
    (fun p hp => le_trans (hT p hp).2.2.2.2 (Nat.pow_le_pow_left (Nat.div_le_self _ _) 2)) 2 _
    (by norm_num) hh ?_
  push_cast; rw [Real.log_pow]; push_cast; linarith

/-- **Physical W′ theorem.** -/
theorem W_physical (q : ℕ) (hq : 0 < q) (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 3) :
    ∃ Λ₀ : ℝ, 2 ≤ Λ₀ ∧ ∀ (Jlow Jhigh a h : ℕ) (d : Finset ℕ), Λ₀ ≤ Real.log h → 2 ≤ h →
      |WPart Jlow Jhigh q a h δ d| ≤ (Real.log h) ^ (-(80 : ℝ)) := by
  obtain ⟨Λ₁, hΛ₁, hW⟩ := GoldC.QuillonWFinal.W_final q hq δ hδ0 hδ1
  set K : ℝ := Real.exp 10 * (2 * 2 + 1) ^ 10 * 4 with hK
  obtain ⟨Λ₂, hΛ₂, hKΛ⟩ := GoldC.QuillonLam.const_le_rpow K 1 one_pos
  refine ⟨max Λ₁ Λ₂, le_trans hΛ₁ (le_max_left _ _), ?_⟩
  intro Jlow Jhigh a h d hΛ hh
  have hΛa : Λ₁ ≤ Real.log h := le_trans (le_max_left _ _) hΛ
  have hΛb : Λ₂ ≤ Real.log h := le_trans (le_max_right _ _) hΛ
  set Λ := Real.log h with hΛdef
  have hΛ2 : 2 ≤ Λ := le_trans hΛ₁ hΛa
  have hΛ0 : 0 < Λ := by linarith
  set H := h / primeSetProduct d with hH
  set T := Tsrc q h d with hT
  have hTf := Tsrc_facts q h d
  have hHh : H ≤ h := Nat.div_le_self _ _
  unfold WPart
  rw [GoldC.QuillonCells.double_sum_fixC]
  -- per-`C` bound
  have hinner : ∀ C ∈ T.powerset.filter (fun C => C ≠ ∅),
      |∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
        (if Mk0 Jlow Jhigh h H δ B C ∧ WMask h δ T B C then
          omegaWeight B * omegaWeight C *
            foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0)| ≤
        ωR C * (4 * Λ ^ (-(95 : ℝ))) := by
    intro C hC
    have hCT : C ⊆ T := mem_powerset.1 (mem_filter.1 hC).1
    have hω0 : 0 ≤ ωR C := ωR_nonneg C fun p hp => (hTf p (hCT hp)).2.1
    have key := hW a h H (primeSetProduct d) T C
      (fun k => Jlow ≤ k + C.card ∧ k + C.card < Jhigh) hΛa hh hHh hTf hCT
    have e : ∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
        (if Mk0 Jlow Jhigh h H δ B C ∧ WMask h δ T B C then
          omegaWeight B * omegaWeight C *
            foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0) =
        ωR C * ∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
          (if ((Jlow ≤ B.card + C.card ∧ B.card + C.card < Jhigh) ∧
              Geo0 h H δ (∏ p ∈ B, p) (∏ p ∈ C, p)) ∧
              (B ∩ (T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ Yp δ (∏ p ∈ C, p))).Nonempty
            then ωR B * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p) else 0) := by
      rw [mul_sum]
      refine sum_congr rfl fun B _ => ?_
      have hiff : (Mk0 Jlow Jhigh h H δ B C ∧ WMask h δ T B C) ↔
          (((Jlow ≤ B.card + C.card ∧ B.card + C.card < Jhigh) ∧
              Geo0 h H δ (∏ p ∈ B, p) (∏ p ∈ C, p)) ∧
              (B ∩ (T \ C).filter (fun p => Xp h ≤ p ∧ p ≤ Yp δ (∏ p ∈ C, p))).Nonempty) := by
        constructor
        · rintro ⟨⟨h1, h2, h3, h4, h5, h6⟩, hw⟩; exact ⟨⟨⟨h3, h4⟩, h1, h2, h5, h6⟩, hw⟩
        · rintro ⟨⟨⟨h3, h4⟩, h1, h2, h5, h6⟩, hw⟩; exact ⟨⟨h1, h2, h3, h4, h5, h6⟩, hw⟩
      split_ifs with h1 h2 h2
      · show ωR B * ωR C * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p) =
          ωR C * (ωR B * foldRow q a (primeSetProduct d) H (∏ p ∈ B, p) (∏ p ∈ C, p))
        ring
      · exact absurd (hiff.1 h1) h2
      · exact absurd (hiff.2 h2) h1
      · rw [mul_zero]
    rw [e, abs_mul, abs_of_nonneg hω0]
    exact mul_le_mul_of_nonneg_left key hω0
  calc _ ≤ ∑ C ∈ T.powerset.filter (fun C => C ≠ ∅),
        |∑ B ∈ (T \ C).powerset.filter (fun B => B ≠ ∅),
          (if Mk0 Jlow Jhigh h H δ B C ∧ WMask h δ T B C then
            omegaWeight B * omegaWeight C *
              foldRow q a (primeSetProduct d) H (primeSetProduct B) (primeSetProduct C) else 0)| :=
        abs_sum_le_sum_abs _ _
    _ ≤ ∑ C ∈ T.powerset.filter (fun C => C ≠ ∅), ωR C * (4 * Λ ^ (-(95 : ℝ))) := sum_le_sum hinner
    _ ≤ ∑ C ∈ T.powerset, ωR C * (4 * Λ ^ (-(95 : ℝ))) := by
        apply sum_le_sum_of_subset_of_nonneg (filter_subset _ _)
        intro C hC _
        have hCT : C ⊆ T := mem_powerset.1 hC
        have := ωR_nonneg C fun p hp => (hTf p (hCT hp)).2.1
        positivity
    _ = (∑ C ∈ T.powerset, ωR C) * (4 * Λ ^ (-(95 : ℝ))) := by rw [sum_mul]
    _ ≤ (Real.exp 10 * (2 * 2 + 1) ^ 10 * Λ ^ (10 : ℝ)) * (4 * Λ ^ (-(95 : ℝ))) :=
        mul_le_mul_of_nonneg_right (outer_mass q h d (by linarith)) (by positivity)
    _ = K * Λ ^ (-(85 : ℝ)) := by
        rw [hK, show Λ ^ (-(85 : ℝ)) = Λ ^ (10 : ℝ) * Λ ^ (-(95 : ℝ)) by
          rw [← Real.rpow_add hΛ0]; norm_num]
        ring
    _ ≤ Λ ^ (1 : ℝ) * Λ ^ (-(85 : ℝ)) := mul_le_mul_of_nonneg_right (hKΛ Λ hΛb) (by positivity)
    _ = Λ ^ (-(84 : ℝ)) := by rw [← Real.rpow_add hΛ0]; norm_num
    _ ≤ Λ ^ (-(80 : ℝ)) := Real.rpow_le_rpow_of_exponent_le (by linarith) (by norm_num)

end GoldC.QuillonWPhysical

#print axioms GoldC.QuillonWPhysical.W_physical
