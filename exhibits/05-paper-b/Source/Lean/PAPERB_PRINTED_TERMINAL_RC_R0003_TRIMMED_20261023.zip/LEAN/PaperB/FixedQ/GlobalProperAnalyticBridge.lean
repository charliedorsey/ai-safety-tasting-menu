import PaperB.FixedQ.H3SmallHeightL1
import PaperB.FixedQ.H3DecoratedAnalyticShell
import PaperB.FixedQ.DecoratedTerminalSpine

open scoped BigOperators

namespace PaperB.FixedQ

lemma decoratedReducedAnchor_one
    {q a : ℕ} (hq : 0 < q) :
    decoratedReducedAnchor q a 1 = a % q := by
  letI : NeZero q := ⟨Nat.ne_of_gt hq⟩
  unfold decoratedReducedAnchor
  rw [dif_pos (Nat.coprime_one_left q)]
  have hu :
      ZMod.unitOfCoprime 1 (Nat.coprime_one_left q) =
        (1 : (ZMod q)ˣ) := by
    ext
    rw [ZMod.coe_unitOfCoprime]
    simp
  rw [hu]
  simp [ZMod.val_natCast]

theorem decoratedAnalyticPerE_eq_ordinaryBooleanCoreTerm
    {q a h : ℕ} (hq : 0 < q) {e : Finset ℕ}
    (hact : e ∈ activeOrdinaryTwoDimensionalSet q h) :
    decoratedAnalyticPerE q a h e =
      ordinaryBooleanCoreTerm q a h e := by
  have hOrd : heightPrimePart h e = ∅ := hact.1
  have hA := hact.2
  have hmain :=
    decoratedAnalyticPerE_eq_height_weight_mul_boolean
      (q := q) (a := a) (h := h) (e := e) hA
  have ha1 := decoratedReducedAnchor_one (q := q) (a := a) hq
  simp only [decoratedHeightProduct, decoratedReducedHeight] at hmain
  rw [hOrd] at hmain
  simp [primeSetProduct, finiteVWeightReal] at hmain
  rw [ha1] at hmain
  have hw :
      fixedQLowWeight q (a % q) h =
        fixedQLowWeight q a h := by
    funext y
    symm
    exact fixedQLowWeight_anchor_mod q a h y
  rw [hw] at hmain
  rw [ordinaryBooleanCoreTerm, Set.indicator_of_mem hact]
  exact hmain

lemma decoratedAnalyticPerE_eq_zero_of_not_all_active
    {q a h : ℕ} {e : Finset ℕ}
    (hA : ¬ ∀ p ∈ e, activeHighPrime q p) :
    decoratedAnalyticPerE q a h e = 0 := by
  unfold decoratedAnalyticPerE
  apply Finset.sum_eq_zero
  intro e1 he1
  have hz :=
    pairCoefficient_eq_zero_of_not_all_active
      (q := q) (h := h) (e := e) (e1 := e1) hA
  simp [decoratedAnalyticPairTerm, hz]

theorem ordinary_indicator_decoratedAnalytic_eq_coreTerm
    {q a h : ℕ} (hq : 0 < q) (e : Finset ℕ) :
    (ordinaryTwoDimensionalSet h).indicator
        (decoratedAnalyticPerE q a h) e =
      ordinaryBooleanCoreTerm q a h e := by
  classical
  by_cases hOrd : e ∈ ordinaryTwoDimensionalSet h
  · rw [Set.indicator_of_mem hOrd]
    by_cases hA : ∀ p ∈ e, activeHighPrime q p
    · have hact : e ∈ activeOrdinaryTwoDimensionalSet q h :=
        ⟨hOrd, hA⟩
      exact decoratedAnalyticPerE_eq_ordinaryBooleanCoreTerm hq hact
    · rw [decoratedAnalyticPerE_eq_zero_of_not_all_active hA]
      simp [ordinaryBooleanCoreTerm, activeOrdinaryTwoDimensionalSet,
        Set.indicator, hA]
  · simp [Set.indicator, hOrd, ordinaryBooleanCoreTerm,
      activeOrdinaryTwoDimensionalSet]

theorem ordinary_indicator_decoratedAnalytic_tsum_eq_core
    {q a h : ℕ} (hq : 0 < q) :
    (∑' e : Finset ℕ,
      (ordinaryTwoDimensionalSet h).indicator
        (decoratedAnalyticPerE q a h) e) =
      ordinaryBooleanCore q a h := by
  unfold ordinaryBooleanCore
  apply tsum_congr
  intro e
  exact ordinary_indicator_decoratedAnalytic_eq_coreTerm hq e

theorem globalProperAnalytic_eq_indicator_partition
    {q a h : ℕ} (hq : 0 < q) :
    ordinaryBooleanCore q a h +
        decoratedAnalyticRemainder q a h =
      (∑' e : Finset ℕ,
        (ordinaryTwoDimensionalSet h).indicator
          (decoratedAnalyticPerE q a h) e) +
      (∑' e : Finset ℕ,
        (ordinaryTwoDimensionalSet h)ᶜ.indicator
          (decoratedAnalyticPerE q a h) e) := by
  rw [ordinary_indicator_decoratedAnalytic_tsum_eq_core hq]
  rfl


theorem summable_ordinary_indicator_decoratedAnalytic
    {q a r h : ℕ}
    (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    Summable ((ordinaryTwoDimensionalSet h).indicator
      (decoratedAnalyticPerE q a h)) := by
  exact (summable_ordinaryBooleanCoreTerm
    (q := q) (a := a) (h := h) hq hh h2).congr
      (fun e => (ordinary_indicator_decoratedAnalytic_eq_coreTerm hq e).symm)

theorem summable_global_decoratedAnalyticPerE
    {q a r h : ℕ}
    (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h)
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    Summable (decoratedAnalyticPerE q a h) := by
  have hOrd :=
    summable_ordinary_indicator_decoratedAnalytic
      (q := q) (a := a) (r := r) hq hh h2
  have hDec :=
    summable_decoratedAnalyticPerE_indicator
      (q := q) (a := a) (r := r) hq hh h2 hreflect
  have hsum := hOrd.add hDec
  exact hsum.congr (fun e => by
    by_cases he : e ∈ ordinaryTwoDimensionalSet h
    · simp [Set.indicator, he]
    · simp [Set.indicator, he])

theorem tsum_decoratedAnalyticPerE_eq_globalProperAnalytic
    {q a r h : ℕ}
    (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h)
    (hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z)) :
    (∑' e : Finset ℕ, decoratedAnalyticPerE q a h e) =
      ordinaryBooleanCore q a h +
        decoratedAnalyticRemainder q a h := by
  have hOrd :=
    summable_ordinary_indicator_decoratedAnalytic
      (q := q) (a := a) (r := r) hq hh h2
  have hDec :=
    summable_decoratedAnalyticPerE_indicator
      (q := q) (a := a) (r := r) hq hh h2 hreflect
  rw [globalProperAnalytic_eq_indicator_partition hq]
  rw [← hOrd.tsum_add hDec]
  apply tsum_congr
  intro e
  by_cases he : e ∈ ordinaryTwoDimensionalSet h
  · simp [Set.indicator, he]
  · simp [Set.indicator, he]

#print axioms decoratedReducedAnchor_one
#print axioms decoratedAnalyticPerE_eq_ordinaryBooleanCoreTerm
#print axioms ordinary_indicator_decoratedAnalytic_eq_coreTerm
#print axioms ordinary_indicator_decoratedAnalytic_tsum_eq_core
#print axioms globalProperAnalytic_eq_indicator_partition

end PaperB.FixedQ
