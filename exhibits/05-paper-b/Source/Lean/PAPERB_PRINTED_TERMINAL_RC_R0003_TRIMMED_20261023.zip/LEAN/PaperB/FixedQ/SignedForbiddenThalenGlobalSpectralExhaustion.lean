import PaperB.FixedQ.SignedForbiddenThalenExteriorSpectralLimit

open scoped BigOperators
open Filter

namespace PaperB.FixedQ

/-- The exact finite spectral approximation to Tavren's reduced
signed exterior, retaining original cutoff Z, actual fixed-q row
weight, corrected spectral diagonal and signed low-support term. -/
noncomputable def thalenReducedSpectralAt
    (q A H Z : ℕ) (d : Finset ℕ) (N : ℕ) : ℝ :=
  let S := thalenActiveOrdinaryFiniteSupport q H d N
  (∑ y ∈ Finset.Ioo 0 H,
    fixedQLowWeight q A H y *
      (thalenFiniteCenteredPacket S (thalenFiniteA S) y *
        thalenFiniteCenteredPacket S (thalenFiniteA S) (H-y))) -
    rowWeightMass (fixedQLowWeight q A H) H *
      ((thalenFiniteA S - 1) ^ 2 +
        (thalenFiniteA S) ^ 2 *
          ((∏ p ∈ S, (1 - thalenPrimeDelta p ^ 2)) - 1)) -
    (∑ n ∈ S.powerset.filter (fun n => primeSetProduct n ≤ Z),
      thalenFiniteOuterSourceTerm q A H n)

/-- The signed height-prime decoration sum of source-compatible finite
spectral approximations at the SAME original cutoff Z. -/
noncomputable def thalenGlobalSpectralAt
    (q a h Z N : ℕ) : ℝ :=
  ∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
    finiteVWeightReal h d *
      thalenReducedSpectralAt q
        (decoratedReducedAnchor q a (primeSetProduct d))
        (h / primeSetProduct d) Z d N

/-- Full global source-to-spectral exhaustion: no shortcut through an
unmasked Euler product, no absolute value before the signed d-sum,
and no replacement of the actual row density. This is an exact
limit theorem, not a sublog estimate. -/
theorem thalen_globalProperExterior_tendsto_signedSpectral
    {q a h Z : ℕ}
    (hq : 0 < q) (hh : 0 < h)
    (h2 : ¬ 2 ∣ q → 2 ∣ h) :
    Tendsto
      (fun N : ℕ => thalenGlobalSpectralAt q a h Z N)
      atTop (nhds (globalProperExteriorAnalytic q a h Z)) := by
  have hrow (d : Finset ℕ)
      (hd : d ∈ (decoratedHeightPrimeSet q h).powerset) :
      Tendsto
        (fun N : ℕ =>
          finiteVWeightReal h d *
            thalenReducedSpectralAt q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) Z d N)
        atTop
        (nhds (finiteVWeightReal h d *
          tavrenReducedExteriorSignedCore q
            (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d) Z d)) := by
    have hHpos := decoratedReducedHeight_pos_of_mem hh hd
    have hHpar := decoratedReducedHeight_parity_of_mem h2 hd
    have hlim := thalen_reducedExteriorSignedCore_tendsto_spectralFinite
      (q := q)
      (A := decoratedReducedAnchor q a (primeSetProduct d))
      (H := h / primeSetProduct d) (Z := Z)
      hq
      (by simpa [decoratedReducedHeight, decoratedHeightProduct] using hHpos)
      (by simpa [decoratedReducedHeight, decoratedHeightProduct] using hHpar)
      d
    have hlim' :
        Tendsto
          (fun N : ℕ => thalenReducedSpectralAt q
            (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d) Z d N)
          atTop
          (nhds (tavrenReducedExteriorSignedCore q
            (decoratedReducedAnchor q a (primeSetProduct d))
            (h / primeSetProduct d) Z d)) := by
      exact hlim
    exact tendsto_const_nhds.mul hlim'
  have hsum :
      Tendsto
        (fun N : ℕ =>
          ∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
            finiteVWeightReal h d *
              thalenReducedSpectralAt q
                (decoratedReducedAnchor q a (primeSetProduct d))
                (h / primeSetProduct d) Z d N)
        atTop
        (nhds (∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
          finiteVWeightReal h d *
            tavrenReducedExteriorSignedCore q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d) Z d)) := by
    apply tendsto_finsetSum
    intro d hd
    exact hrow d hd
  rw [tavren_globalProperExterior_eq_signedHeightSum hq hh h2]
  exact hsum

#print axioms thalen_globalProperExterior_tendsto_signedSpectral

end PaperB.FixedQ
