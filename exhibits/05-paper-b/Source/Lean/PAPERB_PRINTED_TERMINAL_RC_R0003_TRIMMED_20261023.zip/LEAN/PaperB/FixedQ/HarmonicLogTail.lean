import PaperB.FixedQ.PrimeReciprocalDyadic

open scoped BigOperators
open Finset Nat Real

namespace PaperB.FixedQ

lemma inv_succ_le_log_succ_sub_log
    {n : ℕ} (hn : 1 ≤ n) :
    (1 : ℝ) / ((n + 1 : ℕ) : ℝ) ≤
      Real.log ((n + 1 : ℕ) : ℝ) - Real.log (n : ℝ) := by
  have hnR : (0 : ℝ) < (n : ℝ) := by
    exact_mod_cast (lt_of_lt_of_le zero_lt_one hn)
  have hnpR : (0 : ℝ) < ((n + 1 : ℕ) : ℝ) := by positivity
  have hratio : (0 : ℝ) < (n : ℝ) / ((n + 1 : ℕ) : ℝ) := by positivity
  have hlog := Real.log_le_sub_one_of_pos hratio
  rw [Real.log_div hnR.ne' hnpR.ne'] at hlog
  have hfrac :
      (n : ℝ) / ((n + 1 : ℕ) : ℝ) - 1 =
        -(1 / ((n + 1 : ℕ) : ℝ)) := by
    push_cast
    field_simp [hnpR.ne']
    ring
  rw [hfrac] at hlog
  linarith

theorem shifted_harmonic_Icc_le_log
    {K N : ℕ} (hK : 1 ≤ K) :
    (∑ j ∈ Finset.Icc 1 N,
        (1 : ℝ) / ((K + j : ℕ) : ℝ)) ≤
      Real.log ((K + N : ℕ) : ℝ) - Real.log (K : ℝ) := by
  induction N with
  | zero =>
      simp
  | succ N ih =>
      rw [Finset.sum_Icc_succ_top (by omega)]
      have hstep := inv_succ_le_log_succ_sub_log
        (n := K + N) (by omega)
      have hadd := add_le_add ih hstep
      calc
        (∑ j ∈ Finset.Icc 1 N,
            (1 : ℝ) / ((K + j : ℕ) : ℝ)) +
              (1 : ℝ) / ((K + (N + 1) : ℕ) : ℝ)
            ≤ (Real.log ((K + N : ℕ) : ℝ) - Real.log (K : ℝ)) +
              (Real.log ((K + N + 1 : ℕ) : ℝ) -
                Real.log ((K + N : ℕ) : ℝ)) := by
                  simpa [Nat.add_assoc] using hadd
        _ = Real.log ((K + (N + 1) : ℕ) : ℝ) -
              Real.log (K : ℝ) := by
              have heq : K + N + 1 = K + (N + 1) := by omega
              rw [heq]
              ring

theorem shifted_harmonic_range_le
    {K N : ℕ} (hK : 1 ≤ K) :
    (∑ j ∈ Finset.range N,
        (1 : ℝ) / ((K + j : ℕ) : ℝ)) ≤
      (1 : ℝ) / (K : ℝ) +
        (Real.log ((K + N : ℕ) : ℝ) - Real.log (K : ℝ)) := by
  cases N with
  | zero =>
      simp
  | succ M =>
      have hrange :
          Finset.range (M + 1) = insert 0 (Finset.Icc 1 M) := by
        ext j
        simp
        omega
      rw [hrange, Finset.sum_insert (by simp)]
      simp only [Nat.add_zero]
      have htail := shifted_harmonic_Icc_le_log
        (K := K) (N := M) hK
      have hKMpos : (0 : ℝ) < ((K + M : ℕ) : ℝ) := by positivity
      have hlogmono :
          Real.log ((K + M : ℕ) : ℝ) ≤
            Real.log ((K + (M + 1) : ℕ) : ℝ) := by
        apply Real.log_le_log hKMpos
        exact_mod_cast (show K + M ≤ K + (M + 1) by omega)
      linarith

#print axioms shifted_harmonic_range_le

end PaperB.FixedQ
