import PaperB.FixedQ.H2BooleanRoughShiu
import PaperB.FixedQ.H2BooleanM3Grouping

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def h2BooleanSmoothPrimeSet (Y m : ℕ) : Finset ℕ :=
  m.primeFactors.filter fun p => p ≤ Y

noncomputable def h2BooleanRoughPrimeSet (Y m : ℕ) : Finset ℕ :=
  m.primeFactors.filter fun p => Y < p

noncomputable def h2BooleanSmoothPart (Y m : ℕ) : ℕ :=
  primeSetProduct (h2BooleanSmoothPrimeSet Y m)

noncomputable def h2BooleanRoughPart (Y m : ℕ) : ℕ :=
  primeSetProduct (h2BooleanRoughPrimeSet Y m)

lemma h2Boolean_primeSets_partition (Y m : ℕ) :
    m.primeFactors =
      h2BooleanSmoothPrimeSet Y m ∪ h2BooleanRoughPrimeSet Y m := by
  ext p
  simp only [h2BooleanSmoothPrimeSet, h2BooleanRoughPrimeSet,
    Finset.mem_union, Finset.mem_filter]
  constructor
  · intro hp
    by_cases h : p ≤ Y
    · exact Or.inl ⟨hp, h⟩
    · exact Or.inr ⟨hp, Nat.lt_of_not_ge h⟩
  · rintro (⟨hp, _⟩ | ⟨hp, _⟩) <;> exact hp

lemma h2Boolean_primeSets_disjoint (Y m : ℕ) :
    Disjoint (h2BooleanSmoothPrimeSet Y m)
      (h2BooleanRoughPrimeSet Y m) := by
  rw [Finset.disjoint_left]
  intro p hs hr
  have hsY := (Finset.mem_filter.mp hs).2
  have hrY := (Finset.mem_filter.mp hr).2
  omega

lemma h2BooleanSmoothPrimeSet_prime {Y m : ℕ} :
    ∀ p ∈ h2BooleanSmoothPrimeSet Y m, p.Prime := by
  intro p hp
  exact Nat.prime_of_mem_primeFactors (Finset.mem_filter.mp hp).1

lemma h2BooleanRoughPrimeSet_prime {Y m : ℕ} :
    ∀ p ∈ h2BooleanRoughPrimeSet Y m, p.Prime := by
  intro p hp
  exact Nat.prime_of_mem_primeFactors (Finset.mem_filter.mp hp).1
lemma h2BooleanSmoothPart_mul_roughPart
    {Y m : ℕ} (hsq : Squarefree m) :
    h2BooleanSmoothPart Y m * h2BooleanRoughPart Y m = m := by
  unfold h2BooleanSmoothPart h2BooleanRoughPart primeSetProduct
  rw [← Finset.prod_union (h2Boolean_primeSets_disjoint Y m)]
  rw [← h2Boolean_primeSets_partition Y m]
  exact Nat.prod_primeFactors_of_squarefree hsq

lemma h2BooleanSmoothPart_coprime_roughPart
    (Y m : ℕ) :
    (h2BooleanSmoothPart Y m).Coprime
      (h2BooleanRoughPart Y m) := by
  unfold h2BooleanSmoothPart h2BooleanRoughPart primeSetProduct
  apply Nat.Coprime.prod_left
  intro p hp
  apply Nat.Coprime.prod_right
  intro r hr
  have hpP := h2BooleanSmoothPrimeSet_prime (Y := Y) (m := m) p hp
  have hrP := h2BooleanRoughPrimeSet_prime (Y := Y) (m := m) r hr
  exact (Nat.coprime_primes hpP hrP).2 (fun hpr =>
    (Finset.disjoint_left.mp (h2Boolean_primeSets_disjoint Y m))
      hp (hpr ▸ hr))

lemma h2BooleanSmoothPart_primeFactors {Y m : ℕ} :
    (h2BooleanSmoothPart Y m).primeFactors =
      h2BooleanSmoothPrimeSet Y m := by
  unfold h2BooleanSmoothPart
  exact Nat.primeFactors_prod h2BooleanSmoothPrimeSet_prime

lemma h2BooleanRoughPart_primeFactors {Y m : ℕ} :
    (h2BooleanRoughPart Y m).primeFactors =
      h2BooleanRoughPrimeSet Y m := by
  unfold h2BooleanRoughPart
  exact Nat.primeFactors_prod h2BooleanRoughPrimeSet_prime

lemma h2BooleanRoughPart_support
    {Y m p : ℕ}
    (hp : p ∈ (h2BooleanRoughPart Y m).primeFactors) :
    Y < p := by
  rw [h2BooleanRoughPart_primeFactors] at hp
  exact (Finset.mem_filter.mp hp).2

lemma h2BooleanTiltLift_factor_smooth_rough
    {q Y m : ℕ} {c : ℝ} (hsq : Squarefree m) :
    h2BooleanTiltLift q c m =
      h2BooleanTiltLift q c (h2BooleanSmoothPart Y m) *
        h2BooleanTiltLift q c (h2BooleanRoughPart Y m) := by
  have hmul := h2BooleanSmoothPart_mul_roughPart (Y := Y) hsq
  have hcop := h2BooleanSmoothPart_coprime_roughPart Y m
  have hmult :=
    (h2BooleanTiltLift_multiplicative q c).map_mul_of_coprime hcop
  rw [hmul] at hmult
  exact hmult

lemma h2BooleanRoughTiltLift_roughPart
    {q Y m : ℕ} {c : ℝ} :
    h2BooleanRoughTiltLift q Y c (h2BooleanRoughPart Y m) =
      h2BooleanTiltLift q c (h2BooleanRoughPart Y m) := by
  rw [h2BooleanRoughTiltLift_apply]
  unfold h2BooleanRoughTiltLiftNat
  rw [if_pos]
  intro p hp
  exact h2BooleanRoughPart_support hp

#print axioms h2BooleanSmoothPart_mul_roughPart
#print axioms h2BooleanSmoothPart_coprime_roughPart
#print axioms h2BooleanTiltLift_factor_smooth_rough
#print axioms h2BooleanRoughTiltLift_roughPart

end PaperB.FixedQ
