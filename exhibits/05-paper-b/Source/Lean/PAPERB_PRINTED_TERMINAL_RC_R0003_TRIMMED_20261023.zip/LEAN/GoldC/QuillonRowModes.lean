import GoldC.QuillonCot
import GoldC.QuillonClassNormalFormCopyQ0001

/-!
# Quillon CSC3 F7.2: every source sawtooth as a uniform finite mode sum

* `saw_natCast_div`: for `s ≥ 2` and `s ∤ N`, `saw(N/s) = prof s (N % s)` (real part identity).
* `saw_modes`: for `s ≥ 2`, `s ∤ N` and any `J` with `s ≤ 2J`,

      (saw(N/s) : ℂ) = Σ_{k=1}^{J} (i·ampC(k,s)/(2πk))·(ζ_s^{kN} − ζ_s^{−kN}).

  The coefficients depend on `s` only through `ampC(k,s)` (monotone, in `[0,1]`, zero for `2k ≥ s`).
* `saw_shift_modes`: the same for `saw(N/m − 1/M)` with `m = M·s`, which is the shifted class saw.

Applied with `N = H·invMod r s` (main saw), and `N = N_b`, `N_b + (M−1)s` (class saws, `m = Ms`).
`(H,s)=1` excludes `s ∣ N`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonRowModes

open GoldC.QuillonCot GoldC.QuillonSawDFT

lemma saw_natCast_div (N s : ℕ) (hs : 2 ≤ s) :
    GoldC.QuillonCopyC.saw ((N : ℝ) / s) = ((N % s : ℕ) : ℝ) / s - 1 / 2 := by
  unfold GoldC.QuillonCopyC.saw
  rw [GoldC.QuillonCopyC.fract_natCast_div N s (by omega)]

theorem saw_modes (N s J : ℕ) (hs : 2 ≤ s) (hN : ¬ s ∣ N) (hJ : s ≤ 2 * J) :
    ((GoldC.QuillonCopyC.saw ((N : ℝ) / s) : ℝ) : ℂ) =
      ∑ k ∈ Icc 1 J, (Complex.I * ((ampC k s : ℝ) : ℂ) / (2 * Real.pi * k)) *
        (zeta s ^ ((k : ℤ) * N) - zeta s ^ (-((k : ℤ) * N))) := by
  have hc : N % s ∈ Ioo 0 s := by
    refine mem_Ioo.2 ⟨Nat.pos_of_ne_zero ?_, Nat.mod_lt _ (by omega)⟩
    intro h0; exact hN (Nat.dvd_of_mod_eq_zero h0)
  rw [saw_natCast_div N s hs]
  have := prof_signed s (N % s) J hs hc hJ
  unfold prof at this
  rw [this]
  refine Finset.sum_congr rfl fun k _ => ?_
  have hζ := zeta_prim s (by omega)
  have hred : ∀ e : ℤ, zeta s ^ e = zeta s ^ (e % (s : ℤ)) := by
    intro e
    have hdecomp : e = e % (s : ℤ) + (s : ℤ) * (e / (s : ℤ)) := (Int.emod_add_mul_ediv e s).symm
    conv_lhs => rw [hdecomp]
    rw [zpow_add₀ (zeta_ne_zero s), zpow_mul, zpow_natCast, hζ.pow_eq_one, one_zpow, mul_one]
  have e1 : (k : ℤ) * ((N % s : ℕ) : ℤ) % (s : ℤ) = (k : ℤ) * N % (s : ℤ) := by
    push_cast; rw [Int.mul_emod, Int.emod_emod_of_dvd _ (dvd_refl _), ← Int.mul_emod]
  have P : zeta s ^ ((k : ℤ) * ((N % s : ℕ) : ℤ)) = zeta s ^ ((k : ℤ) * N) := by
    rw [hred ((k : ℤ) * ((N % s : ℕ) : ℤ)), hred ((k : ℤ) * N), e1]
  rw [zpow_neg, zpow_neg, P]

/-- Shifted class saw: `saw(N/m − 1/M)` with `m = M·s`, written as an unshifted saw. -/
lemma saw_shift_eq (N M s : ℕ) (hM : 1 ≤ M) (hs : 1 ≤ s) :
    GoldC.QuillonCopyC.saw ((N : ℝ) / ((M * s : ℕ) : ℝ) - 1 / M) =
      GoldC.QuillonCopyC.saw (((N + (M - 1) * s : ℕ) : ℝ) / ((M * s : ℕ) : ℝ)) := by
  unfold GoldC.QuillonCopyC.saw
  congr 1
  have hMR : (0 : ℝ) < M := by exact_mod_cast hM
  have hsR : (0 : ℝ) < s := by exact_mod_cast hs
  rw [show ((N + (M - 1) * s : ℕ) : ℝ) / ((M * s : ℕ) : ℝ) =
      ((N : ℝ) / ((M * s : ℕ) : ℝ) - 1 / M) + 1 by
    push_cast [Nat.cast_sub hM]; field_simp; ring]
  rw [Int.fract_add_one]

end GoldC.QuillonRowModes

#print axioms GoldC.QuillonRowModes.saw_modes
#print axioms GoldC.QuillonRowModes.saw_shift_eq
