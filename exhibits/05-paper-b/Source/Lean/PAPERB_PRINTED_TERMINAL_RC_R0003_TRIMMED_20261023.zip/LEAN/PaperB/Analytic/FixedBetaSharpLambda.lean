import PaperB.Analytic.FixedBetaActualTerms

namespace PaperB.Analytic

open Real

lemma fixedBeta_actual_lambda_squeeze_sharp_nat
    {W k : ℕ} {beta : ℝ}
    (hW : 0 < W) (hkW : k ≤ W) :
    ((W : ℝ) ^ beta⁻¹) * (k.factorial : ℝ) *
        ((3 * (W : ℝ)) ^ (k + 1))⁻¹
      ≤
    ((W : ℝ) ^ beta⁻¹) * (k.factorial : ℝ) *
        ((((2 * W + k : ℕ) : ℝ)) ^ (k + 1))⁻¹
    ∧
    ((W : ℝ) ^ beta⁻¹) * (k.factorial : ℝ) *
        ((((2 * W + k : ℕ) : ℝ)) ^ (k + 1))⁻¹
      ≤
    ((W : ℝ) ^ beta⁻¹) * (k.factorial : ℝ) *
        (((2 : ℝ) * (W : ℝ)) ^ (k + 1))⁻¹ := by
  have hinv := fixedOrder_denominator_inv_squeeze hW hkW
  have hcoeff : 0 ≤ ((W : ℝ) ^ beta⁻¹) * (k.factorial : ℝ) := by
    positivity
  exact ⟨mul_le_mul_of_nonneg_left hinv.1 hcoeff,
    mul_le_mul_of_nonneg_left hinv.2 hcoeff⟩

lemma fixedBeta_two_endpoint_identity
    {W k : ℕ} {beta : ℝ} (hW : 0 < W) :
    ((W : ℝ) ^ beta⁻¹) * (k.factorial : ℝ) *
        (((2 : ℝ) * (W : ℝ)) ^ (k + 1))⁻¹
      =
    fixedBetaUpperConst k *
      (W : ℝ) ^ fixedBetaLambdaExponent beta k
    ∧
    ((W : ℝ) ^ beta⁻¹) * (k.factorial : ℝ) *
        ((3 * (W : ℝ)) ^ (k + 1))⁻¹
      =
    fixedBetaLowerConst k *
      (W : ℝ) ^ fixedBetaLambdaExponent beta k := by
  have hWr : 0 < (W : ℝ) := by exact_mod_cast hW
  have hideal := fixedBeta_ideal_lambda_identity
    (W := (W : ℝ)) (beta := beta) (k := k) hWr
  constructor
  · rw [fixedBetaUpperConst, mul_pow, mul_inv_rev]
    calc
      (W : ℝ) ^ beta⁻¹ * (k.factorial : ℝ) *
          (((W : ℝ) ^ (k + 1))⁻¹ * ((2 : ℝ) ^ (k + 1))⁻¹)
        =
      ((2 : ℝ) ^ (k + 1))⁻¹ *
        ((W : ℝ) ^ beta⁻¹ * (k.factorial : ℝ) *
          ((W : ℝ) ^ (k + 1))⁻¹) := by ring
      _ = ((2 : ℝ) ^ (k + 1))⁻¹ *
          ((k.factorial : ℝ) *
            (W : ℝ) ^ fixedBetaLambdaExponent beta k) := by
            rw [hideal]
      _ = (((2 : ℝ) ^ (k + 1))⁻¹ * (k.factorial : ℝ)) *
          (W : ℝ) ^ fixedBetaLambdaExponent beta k := by ring
  · rw [fixedBetaLowerConst, mul_pow, mul_inv_rev]
    calc
      (W : ℝ) ^ beta⁻¹ * (k.factorial : ℝ) *
          (((W : ℝ) ^ (k + 1))⁻¹ * ((3 : ℝ) ^ (k + 1))⁻¹)
        =
      ((3 : ℝ) ^ (k + 1))⁻¹ *
        ((W : ℝ) ^ beta⁻¹ * (k.factorial : ℝ) *
          ((W : ℝ) ^ (k + 1))⁻¹) := by ring
      _ = ((3 : ℝ) ^ (k + 1))⁻¹ *
          ((k.factorial : ℝ) *
            (W : ℝ) ^ fixedBetaLambdaExponent beta k) := by
            rw [hideal]
      _ = (((3 : ℝ) ^ (k + 1))⁻¹ * (k.factorial : ℝ)) *
          (W : ℝ) ^ fixedBetaLambdaExponent beta k := by ring

lemma fixedBeta_actual_lambda_squeeze
    {W k : ℕ} {beta : ℝ}
    (hW : 0 < W) (hkW : k ≤ W) :
    fixedBetaLowerConst k *
        (W : ℝ) ^ fixedBetaLambdaExponent beta k
      ≤
    ((W : ℝ) ^ beta⁻¹) * (k.factorial : ℝ) *
        ((((2 * W + k : ℕ) : ℝ)) ^ (k + 1))⁻¹
    ∧
    ((W : ℝ) ^ beta⁻¹) * (k.factorial : ℝ) *
        ((((2 * W + k : ℕ) : ℝ)) ^ (k + 1))⁻¹
      ≤
    fixedBetaUpperConst k *
      (W : ℝ) ^ fixedBetaLambdaExponent beta k := by
  have hs := fixedBeta_actual_lambda_squeeze_sharp_nat
    (W := W) (k := k) (beta := beta) hW hkW
  have hi := fixedBeta_two_endpoint_identity
    (W := W) (k := k) (beta := beta) hW
  exact ⟨hi.2 ▸ hs.1, hi.1 ▸ hs.2⟩

#print axioms fixedBeta_actual_lambda_squeeze_sharp_nat
#print axioms fixedBeta_two_endpoint_identity
#print axioms fixedBeta_actual_lambda_squeeze

end PaperB.Analytic
