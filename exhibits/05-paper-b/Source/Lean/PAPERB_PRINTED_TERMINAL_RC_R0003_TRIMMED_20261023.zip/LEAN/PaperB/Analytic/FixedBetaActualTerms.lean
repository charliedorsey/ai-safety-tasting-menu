import PaperB.Analytic.FixedBetaActualLambda
import PaperB.Analytic.ReciprocalFiniteOrderNatIcc

namespace PaperB.Analytic

open Real Finset

noncomputable def fixedBetaA (k : ℕ) : ℝ :=
  1 / ((2 : ℝ)^k - 2)

noncomputable def fixedBetaB (k : ℕ) : ℝ :=
  1 - 4 / (2 : ℝ)^k

noncomputable def fixedBetaUpperConst (k : ℕ) : ℝ :=
  ((2 : ℝ) ^ (k + 1))⁻¹ * (k.factorial : ℝ)

noncomputable def fixedBetaLowerConst (k : ℕ) : ℝ :=
  ((3 : ℝ) ^ (k + 1))⁻¹ * (k.factorial : ℝ)

lemma fixedBetaA_pos {k : ℕ} (hk : 2 ≤ k) :
    0 < fixedBetaA k := by
  rw [fixedBetaA]
  exact one_div_pos.mpr (fixedBeta_denominator_pos hk)

lemma fixedBetaB_nonneg {k : ℕ} (hk : 2 ≤ k) :
    0 ≤ fixedBetaB k := by
  rw [fixedBetaB]
  have hpow : (4 : ℝ) ≤ (2 : ℝ)^k := by
    have hmono := pow_le_pow_right₀ (a := (2 : ℝ)) (by norm_num) hk
    norm_num at hmono ⊢
    exact hmono
  have hpowpos : 0 < (2 : ℝ)^k := by positivity
  have hfrac : 4 / (2 : ℝ)^k ≤ 1 := by
    rw [div_le_one hpowpos]
    exact hpow
  linarith

lemma fixedBetaUpperConst_pos (k : ℕ) :
    0 < fixedBetaUpperConst k := by
  rw [fixedBetaUpperConst]
  positivity

lemma fixedBetaLowerConst_pos (k : ℕ) :
    0 < fixedBetaLowerConst k := by
  rw [fixedBetaLowerConst]
  positivity

lemma fixedBeta_first_model_identity
    {W beta : ℝ} {k : ℕ} (hW : 0 < W) (hk : 2 ≤ k) :
    W *
      (fixedBetaUpperConst k *
        W ^ fixedBetaLambdaExponent beta k) ^
          fixedBetaA k
      =
    (fixedBetaUpperConst k ^ fixedBetaA k) *
      W ^ fixedBetaFirstExponent beta k := by
  have hC : 0 ≤ fixedBetaUpperConst k := (fixedBetaUpperConst_pos k).le
  have hpow0 : 0 ≤ W ^ fixedBetaLambdaExponent beta k :=
    Real.rpow_nonneg hW.le _
  rw [Real.mul_rpow hC hpow0]
  rw [fixedBetaA]
  have hscale := fixedBeta_first_scale_identity
    (W := W) (beta := beta) (k := k) hW
  calc
    W * (fixedBetaUpperConst k ^ (1 / ((2 : ℝ)^k - 2)) *
        (W ^ fixedBetaLambdaExponent beta k) ^
          (1 / ((2 : ℝ)^k - 2)))
      = fixedBetaUpperConst k ^ (1 / ((2 : ℝ)^k - 2)) *
          (W * (W ^ fixedBetaLambdaExponent beta k) ^
            (1 / ((2 : ℝ)^k - 2))) := by ring
    _ = fixedBetaUpperConst k ^ (1 / ((2 : ℝ)^k - 2)) *
          W ^ fixedBetaFirstExponent beta k := by rw [hscale]

lemma fixedBeta_second_model_identity
    {W beta : ℝ} {k : ℕ} (hW : 0 < W) (hk : 2 ≤ k) :
    W ^ fixedBetaB k *
      (fixedBetaLowerConst k *
        W ^ fixedBetaLambdaExponent beta k) ^
          (-(fixedBetaA k))
      =
    (fixedBetaLowerConst k ^ (-(fixedBetaA k))) *
      W ^ fixedBetaSecondExponent beta k := by
  have hC : 0 ≤ fixedBetaLowerConst k := (fixedBetaLowerConst_pos k).le
  have hpow0 : 0 ≤ W ^ fixedBetaLambdaExponent beta k :=
    Real.rpow_nonneg hW.le _
  rw [Real.mul_rpow hC hpow0]
  rw [fixedBetaA, fixedBetaB]
  have hscale := fixedBeta_second_scale_identity
    (W := W) (beta := beta) (k := k) hW
  calc
    W ^ (1 - 4 / (2 : ℝ)^k) *
        (fixedBetaLowerConst k ^ (-(1 / ((2 : ℝ)^k - 2))) *
          (W ^ fixedBetaLambdaExponent beta k) ^
            (-(1 / ((2 : ℝ)^k - 2))))
      = fixedBetaLowerConst k ^ (-(1 / ((2 : ℝ)^k - 2))) *
          (W ^ (1 - 4 / (2 : ℝ)^k) *
            (W ^ fixedBetaLambdaExponent beta k) ^
              (-(1 / ((2 : ℝ)^k - 2)))) := by ring
    _ = fixedBetaLowerConst k ^ (-(1 / ((2 : ℝ)^k - 2))) *
          W ^ fixedBetaSecondExponent beta k := by rw [hscale]

#print axioms fixedBeta_first_model_identity
#print axioms fixedBeta_second_model_identity

end PaperB.Analytic
