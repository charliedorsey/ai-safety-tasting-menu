import PaperB.Analytic.PetermannOmegaR0002Support

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

lemma sawSmoothPair_omega_branch_phase
    (S A : ℝ) (L k m : ℕ) (r : ℤ) :
    sawSmoothPair S k
        ((A / (m : ℝ) + (r : ℝ) / (L : ℝ) : ℝ) :
          AddCircle (1 : ℝ)) =
      sawSmoothCoeff S (k + 1 : ℕ) *
        eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) / (L : ℝ)) *
        eR (((k + 1 : ℕ) : ℝ) * A / (m : ℝ)) +
      sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
        eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) / (L : ℝ)) *
        eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * A / (m : ℝ)) := by
  unfold sawSmoothPair
  rw [sawSmoothMode_coe_eq_coeff_mul_eR,
    sawSmoothMode_coe_eq_coeff_mul_eR]
  push_cast
  have hpos :
      (((k : ℝ) + 1) *
        (A / (m : ℝ) + (r : ℝ) / (L : ℝ))) =
      (((k : ℝ) + 1) * (r : ℝ) / (L : ℝ)) +
        (((k : ℝ) + 1) * A / (m : ℝ)) := by ring
  have hneg :
      (-((k : ℝ) + 1) *
        (A / (m : ℝ) + (r : ℝ) / (L : ℝ))) =
      (-((k : ℝ) + 1) * (r : ℝ) / (L : ℝ)) +
        (-((k : ℝ) + 1) * A / (m : ℝ)) := by ring
  rw [hpos, hneg, eR_add, eR_add]
  ring

#print axioms sawSmoothPair_omega_branch_phase

end PaperB.Analytic


namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

theorem omega_coprime_smoothed_tail_eq_modes
    {S : ℝ} (hS : 1 < S)
    (q : ℕ) (hq : 0 < q)
    (h : ZMod (Nat.lcm 6 q))
    (T : ℝ) (r : ℤ) (H d M N : ℕ) :
    let L := Nat.lcm 6 q
    let P := 6 * q
    let C := P / L
    let g : ZMod P := (h.val * C * d : ℕ)
    let A0 : ℝ := T / (L : ℝ) / (d : ℝ)
    (∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR ((((h.val : ℝ) / (L : ℝ)) * (d : ℝ)) * (m : ℝ)) *
          sawSmoothPartial S H
            ((A0 / (m : ℝ) + (r : ℝ) / (L : ℝ) : ℝ) :
              AddCircle (1 : ℝ))) =
      ∑ k ∈ Finset.range H,
        (sawSmoothCoeff S (k + 1 : ℕ) *
            eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) / (L : ℝ)) *
            (∑ m ∈ Finset.Icc M N,
              (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
                eR (((((k + 1 : ℕ) : ℝ) * T /
                    (L : ℝ) / (d : ℝ)) / (m : ℝ)) +
                  ((g.val : ℝ) / (P : ℝ)) * (m : ℝ)))) +
          sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
            eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) / (L : ℝ)) *
            (∑ m ∈ Finset.Icc M N,
              (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
                eR (((-((k + 1 : ℕ) : ℤ) : ℝ) * T /
                    (L : ℝ) / (d : ℝ) / (m : ℝ)) +
                  ((g.val : ℝ) / (P : ℝ)) * (m : ℝ)))))) := by
  dsimp only
  let L := Nat.lcm 6 q
  let P := 6 * q
  let C := P / L
  have hL : 0 < L := by
    dsimp [L]
    exact Nat.lcm_pos (by norm_num) hq
  have hP : 0 < P := by dsimp [P]; omega
  letI : NeZero P := ⟨Nat.ne_of_gt hP⟩
  have hfreq : ∀ m : ℕ,
      eR ((((h.val : ℝ) / (L : ℝ)) * (d : ℝ)) * (m : ℝ)) =
        eR (((((h.val * C * d : ℕ) : ZMod P).val : ℝ) /
          (P : ℝ)) * (m : ℝ)) := by
    intro m
    simpa [L, P, C] using
      lcm_frequency_mul_eq_sixq_frequency q hq h d m
  calc
    (∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR ((((h.val : ℝ) / (L : ℝ)) * (d : ℝ)) * (m : ℝ)) *
          sawSmoothPartial S H
            (((T / (L : ℝ) / (d : ℝ)) / (m : ℝ) +
              (r : ℝ) / (L : ℝ) : ℝ) : AddCircle (1 : ℝ))))
      =
      ∑ m ∈ Finset.Icc M N,
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR ((((h.val : ℝ) / (L : ℝ)) * (d : ℝ)) * (m : ℝ)) *
          ∑ k ∈ Finset.range H,
            sawSmoothPair S k
              (((T / (L : ℝ) / (d : ℝ)) / (m : ℝ) +
                (r : ℝ) / (L : ℝ) : ℝ) : AddCircle (1 : ℝ))) := by
        apply Finset.sum_congr rfl
        intro m hm
        rw [sawSmoothPartial_eq_pair_sum hS]
    _ =
      ∑ k ∈ Finset.range H,
        ∑ m ∈ Finset.Icc M N,
          (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
            eR ((((h.val : ℝ) / (L : ℝ)) * (d : ℝ)) * (m : ℝ)) *
            sawSmoothPair S k
              (((T / (L : ℝ) / (d : ℝ)) / (m : ℝ) +
                (r : ℝ) / (L : ℝ) : ℝ) : AddCircle (1 : ℝ))) := by
        simp_rw [Finset.mul_sum]
        rw [Finset.sum_comm]
    _ =
      ∑ k ∈ Finset.range H,
        (sawSmoothCoeff S (k + 1 : ℕ) *
            eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) / (L : ℝ)) *
            (∑ m ∈ Finset.Icc M N,
              (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
                eR (((((k + 1 : ℕ) : ℝ) * T /
                    (L : ℝ) / (d : ℝ)) / (m : ℝ)) +
                  (((h.val * C * d : ℕ) : ZMod P).val : ℝ) /
                    (P : ℝ) * (m : ℝ)))) +
          sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
            eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) / (L : ℝ)) *
            (∑ m ∈ Finset.Icc M N,
              (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
                eR (((-((k + 1 : ℕ) : ℤ) : ℝ) * T /
                    (L : ℝ) / (d : ℝ) / (m : ℝ)) +
                  (((h.val * C * d : ℕ) : ZMod P).val : ℝ) /
                    (P : ℝ) * (m : ℝ))))) := by
        apply Finset.sum_congr rfl
        intro k hk
        have hpair : ∀ m : ℕ,
            sawSmoothPair S k
              (((T / (L : ℝ) / (d : ℝ)) / (m : ℝ) +
                (r : ℝ) / (L : ℝ) : ℝ) : AddCircle (1 : ℝ)) =
            sawSmoothCoeff S (k + 1 : ℕ) *
              eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) / (L : ℝ)) *
              eR (((k + 1 : ℕ) : ℝ) *
                (T / (L : ℝ) / (d : ℝ)) / (m : ℝ)) +
            sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
              eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) / (L : ℝ)) *
              eR ((-((k + 1 : ℕ) : ℤ) : ℝ) *
                (T / (L : ℝ) / (d : ℝ)) / (m : ℝ)) := by
          intro m
          exact sawSmoothPair_omega_branch_phase
            S (T / (L : ℝ) / (d : ℝ)) L k m r
        simp_rw [hpair]
        simp_rw [mul_add]
        rw [Finset.sum_add_distrib]
        congr 1
        · rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro m hm
          rw [hfreq m, eR_add]
          ring
        · rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro m hm
          rw [hfreq m, eR_add]
          ring

#print axioms omega_coprime_smoothed_tail_eq_modes

end PaperB.Analytic


namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

noncomputable def omegaFourierCoeffPairMassBound (H : ℕ) : ℝ :=
  (1 / Real.pi) *
    (1 + (Real.log ((1 + H : ℕ) : ℝ) - Real.log (1 : ℝ)))

noncomputable def omegaSmallDivisorTailBound
    (q : ℕ) (beta : ℝ) (M H : ℕ) (T : ℝ) (D : ℕ) : ℝ :=
  omegaFourierCoeffPairMassBound H *
      (omegaMiddleTailBound q beta M +
        4 * ((6 * q : ℕ) : ℝ) * (1 + 2 * ((6 * q : ℕ) : ℝ)) /
          ((T / (((Nat.lcm 6 q : ℕ) : ℝ) * (D : ℝ))) ^
            (3 / 4 : ℝ))) +
    (1 / Real.pi) *
      (24 * ((6 * q : ℕ) : ℝ) * ((Nat.lcm 6 q : ℕ) : ℝ)) *
        omegaPSeriesTwo

lemma omegaFourierCoeffPairMassBound_nonneg (H : ℕ) :
    0 ≤ omegaFourierCoeffPairMassBound H := by
  unfold omegaFourierCoeffPairMassBound
  have hpi : 0 ≤ 1 / Real.pi := by positivity
  have hh := PaperB.FixedQ.shifted_harmonic_range_le
    (K := 1) (N := H) (by norm_num)
  have hsum0 :
      0 ≤ 1 + (Real.log ((1 + H : ℕ) : ℝ) - Real.log (1 : ℝ)) := by
    have hzero :
        0 ≤ ∑ k ∈ Finset.range H, (1 / ((k + 1 : ℕ) : ℝ)) := by
      positivity
    have hle :
        (∑ k ∈ Finset.range H, (1 / ((k + 1 : ℕ) : ℝ))) ≤
          1 + (Real.log ((1 + H : ℕ) : ℝ) - Real.log (1 : ℝ)) := by
      simpa [Nat.add_comm] using hh
    linarith
  positivity

theorem omega_coprime_smoothed_tail_norm_le
    {S : ℝ} (hS : 1 < S)
    (q : ℕ) (hq : 0 < q)
    (h : ZMod (Nat.lcm 6 q))
    {beta T : ℝ} (hb0 : 0 < beta) (hb1 : beta < 1)
    (r : ℤ) {H d D M X : ℕ}
    (hH : 1 ≤ H)
    (hd : 1 ≤ d) (hdD : d ≤ D) (hD : 1 ≤ D)
    (hM : 1 < M) (hKM : fixedBetaNaturalOrder beta ≤ M)
    (hMXd : M ≤ X / d)
    (hT : 0 < T) (hXT : (X : ℝ) ≤ T)
    (hsource :
      (((H : ℝ) * T) ^ beta) ≤ (M : ℝ))
    (hbase :
      (2 * ((6 * q : ℕ) : ℝ)) ^ 2 ≤
        T / (((Nat.lcm 6 q : ℕ) : ℝ) * (D : ℝ))) :
    let L := Nat.lcm 6 q
    let A0 : ℝ := T / (L : ℝ) / (d : ℝ)
    ‖∑ m ∈ Finset.Icc M (X / d),
        (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
          eR ((((h.val : ℝ) / (L : ℝ)) * (d : ℝ)) * (m : ℝ)) *
          sawSmoothPartial S H
            ((A0 / (m : ℝ) + (r : ℝ) / (L : ℝ) : ℝ) :
              AddCircle (1 : ℝ)))‖
      ≤ omegaSmallDivisorTailBound q beta M H T D := by
  dsimp only
  let L := Nat.lcm 6 q
  let P := 6 * q
  let C := P / L
  let g : ZMod P := (h.val * C * d : ℕ)
  have hLnat : 0 < L := by
    dsimp [L]
    exact Nat.lcm_pos (by norm_num) hq
  have hL : (0 : ℝ) < L := by exact_mod_cast hLnat
  have hPnat : 0 < P := by dsimp [P]; omega
  letI : NeZero P := ⟨Nat.ne_of_gt hPnat⟩
  have hdR : (0 : ℝ) < d := by positivity
  have hDR : (0 : ℝ) < D := by positivity
  have hbasepos :
      0 < T / ((L : ℝ) * (D : ℝ)) := by
    have hs : 0 < (2 * (P : ℝ)) ^ 2 := by
      have hPr : (0 : ℝ) < P := by exact_mod_cast hPnat
      positivity
    exact lt_of_lt_of_le hs hbase
  have hcoefMass :=
    sum_range_sawSmoothCoeff_pair_norm_le_log hS H
  have hcoefMass0 : 0 ≤ omegaFourierCoeffPairMassBound H :=
    omegaFourierCoeffPairMassBound_nonneg H
  rw [omega_coprime_smoothed_tail_eq_modes hS q hq h T r H d M (X / d)]
  calc
    ‖∑ k ∈ Finset.range H,
        (sawSmoothCoeff S (k + 1 : ℕ) *
            eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) / (L : ℝ)) *
            (∑ m ∈ Finset.Icc M (X / d),
              (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
                eR (((((k + 1 : ℕ) : ℝ) * T /
                    (L : ℝ) / (d : ℝ)) / (m : ℝ)) +
                  ((g.val : ℝ) / (P : ℝ)) * (m : ℝ)))) +
          sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
            eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) / (L : ℝ)) *
            (∑ m ∈ Finset.Icc M (X / d),
              (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
                eR (((-((k + 1 : ℕ) : ℤ) : ℝ) * T /
                    (L : ℝ) / (d : ℝ) / (m : ℝ)) +
                  ((g.val : ℝ) / (P : ℝ)) * (m : ℝ)))))‖
      ≤ ∑ k ∈ Finset.range H,
          ((‖sawSmoothCoeff S (k + 1 : ℕ)‖ +
              ‖sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ))‖) *
            (omegaMiddleTailBound q beta M +
              24 * (P : ℝ) * (L : ℝ) / ((k + 1 : ℕ) : ℝ) +
              4 * (P : ℝ) * (1 + 2 * (P : ℝ)) /
                ((T / ((L : ℝ) * (D : ℝ))) ^ (3 / 4 : ℝ)))) := by
        apply le_trans (norm_sum_le _ _)
        apply Finset.sum_le_sum
        intro k hk
        rw [Finset.mem_range] at hk
        let A : ℝ := ((k + 1 : ℕ) : ℝ) * T / (L : ℝ) / (d : ℝ)
        have hk1 : 1 ≤ k + 1 := by omega
        have hkH : k + 1 ≤ H := by omega
        have hkR : (0 : ℝ) < (k + 1 : ℕ) := by positivity
        have hA_lower :
            T / ((L : ℝ) * (D : ℝ)) ≤ A := by
          have hdDreal : (d : ℝ) ≤ (D : ℝ) := by exact_mod_cast hdD
          dsimp [A]
          rw [div_le_div_iff₀ (mul_pos hL hDR) hdR]
          field_simp [hL.ne']
          have hkR1 : (1 : ℝ) ≤ (k + 1 : ℕ) := by exact_mod_cast hk1
          nlinarith
        have hA1 : 1 < A := by
          have hs : (1 : ℝ) < (2 * (P : ℝ)) ^ 2 := by
            have hPr : (1 : ℝ) ≤ P := by exact_mod_cast (show 1 ≤ P by omega)
            nlinarith
          exact hs.trans_le (hbase.trans hA_lower)
        have hAthresh : (2 * (P : ℝ)) ^ 2 ≤ A :=
          hbase.trans hA_lower
        have hAupper : A ≤ (H : ℝ) * T := by
          have hkd : ((k + 1 : ℕ) : ℝ) ≤ (H : ℝ) := by exact_mod_cast hkH
          have hd1r : (1 : ℝ) ≤ (d : ℝ) := by exact_mod_cast hd
          have hL1 : (1 : ℝ) ≤ (L : ℝ) := by exact_mod_cast (show 1 ≤ L by omega)
          dsimp [A]
          have hden : (1 : ℝ) ≤ (L : ℝ) * (d : ℝ) := by
            nlinarith [mul_le_mul hL1 hd1r (by norm_num : (0 : ℝ) ≤ 1) (by positivity)]
          have hnum0 : 0 ≤ ((k + 1 : ℕ) : ℝ) * T := by positivity
          have hnum : ((k + 1 : ℕ) : ℝ) * T ≤ (H : ℝ) * T :=
            mul_le_mul_of_nonneg_right hkd hT.le
          calc
            ((k + 1 : ℕ) : ℝ) * T / (L : ℝ) / (d : ℝ)
                = (((k + 1 : ℕ) : ℝ) * T) /
                    ((L : ℝ) * (d : ℝ)) := by ring
            _ ≤ ((k + 1 : ℕ) : ℝ) * T := by
              rw [div_le_iff₀ (mul_pos hL hdR)]
              have hm := mul_le_mul_of_nonneg_left hden hnum0
              nlinarith
            _ ≤ (H : ℝ) * T := hnum
        have hsourceA : A ^ beta ≤ (M : ℝ) := by
          have hA0 : 0 ≤ A := le_of_lt (lt_trans zero_lt_one hA1)
          have hr := Real.rpow_le_rpow hA0 hAupper hb0.le
          exact hr.trans hsource
        have hpos :=
          omega_middle_high_coprime_reciprocal_weight_tail_bound
            q g hb0 hb1 hA1 hM hsourceA hKM hMXd hAthresh
        have hhighscale :=
          omegaHighTailSimpleBound_scaled_le q hq hT
            (X := X) (d := d) (k := k) (D := D)
            hd hdD hD hXT
        have hpos' :
            ‖∑ m ∈ Finset.Icc M (X / d),
                (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
                  eR (A / (m : ℝ) +
                    ((g.val : ℝ) / (P : ℝ)) * (m : ℝ)))‖
              ≤ omegaMiddleTailBound q beta M +
                24 * (P : ℝ) * (L : ℝ) / ((k + 1 : ℕ) : ℝ) +
                4 * (P : ℝ) * (1 + 2 * (P : ℝ)) /
                  ((T / ((L : ℝ) * (D : ℝ))) ^ (3 / 4 : ℝ)) := by
          calc
            _ ≤ omegaMiddleTailBound q beta M +
                omegaHighTailSimpleBound q A (X / d) := hpos
            _ ≤ omegaMiddleTailBound q beta M +
                (24 * (P : ℝ) * (L : ℝ) / ((k + 1 : ℕ) : ℝ) +
                  4 * (P : ℝ) * (1 + 2 * (P : ℝ)) /
                    ((T / ((L : ℝ) * (D : ℝ))) ^ (3 / 4 : ℝ))) :=
              add_le_add le_rfl (by simpa [A, P, L] using hhighscale)
            _ = _ := by ring
        have hnegRaw :=
          omega_middle_high_coprime_reciprocal_weight_tail_bound
            q (-g) hb0 hb1 hA1 hM hsourceA hKM hMXd hAthresh
        have hnegEq :=
          norm_coprime_reciprocal_phase_negA_zmod
            q g (A := A) (M := M) (N := X / d)
        have hneg' :
            ‖∑ m ∈ Finset.Icc M (X / d),
                (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
                  eR (-A / (m : ℝ) +
                    ((g.val : ℝ) / (P : ℝ)) * (m : ℝ)))‖
              ≤ omegaMiddleTailBound q beta M +
                24 * (P : ℝ) * (L : ℝ) / ((k + 1 : ℕ) : ℝ) +
                4 * (P : ℝ) * (1 + 2 * (P : ℝ)) /
                  ((T / ((L : ℝ) * (D : ℝ))) ^ (3 / 4 : ℝ)) := by
          rw [hnegEq]
          calc
            _ ≤ omegaMiddleTailBound q beta M +
                omegaHighTailSimpleBound q A (X / d) := hnegRaw
            _ ≤ omegaMiddleTailBound q beta M +
                (24 * (P : ℝ) * (L : ℝ) / ((k + 1 : ℕ) : ℝ) +
                  4 * (P : ℝ) * (1 + 2 * (P : ℝ)) /
                    ((T / ((L : ℝ) * (D : ℝ))) ^ (3 / 4 : ℝ))) :=
              add_le_add le_rfl (by simpa [A, P, L] using hhighscale)
            _ = _ := by ring
        have hposTerm :
            ‖sawSmoothCoeff S (k + 1 : ℕ) *
                eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) / (L : ℝ)) *
                (∑ m ∈ Finset.Icc M (X / d),
                  (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
                    eR (((((k + 1 : ℕ) : ℝ) * T /
                        (L : ℝ) / (d : ℝ)) / (m : ℝ)) +
                      ((g.val : ℝ) / (P : ℝ)) * (m : ℝ))))‖
              ≤ ‖sawSmoothCoeff S (k + 1 : ℕ)‖ *
                (omegaMiddleTailBound q beta M +
                  24 * (P : ℝ) * (L : ℝ) / ((k + 1 : ℕ) : ℝ) +
                  4 * (P : ℝ) * (1 + 2 * (P : ℝ)) /
                    ((T / ((L : ℝ) * (D : ℝ))) ^ (3 / 4 : ℝ))) := by
          rw [norm_mul, norm_mul, norm_eR, mul_one]
          apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
          simpa [A] using hpos'
        have hnegTerm :
            ‖sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
                eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) / (L : ℝ)) *
                (∑ m ∈ Finset.Icc M (X / d),
                  (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
                    eR (((-((k + 1 : ℕ) : ℤ) : ℝ) * T /
                        (L : ℝ) / (d : ℝ) / (m : ℝ)) +
                      ((g.val : ℝ) / (P : ℝ)) * (m : ℝ))))‖
              ≤ ‖sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ))‖ *
                (omegaMiddleTailBound q beta M +
                  24 * (P : ℝ) * (L : ℝ) / ((k + 1 : ℕ) : ℝ) +
                  4 * (P : ℝ) * (1 + 2 * (P : ℝ)) /
                    ((T / ((L : ℝ) * (D : ℝ))) ^ (3 / 4 : ℝ))) := by
          rw [norm_mul, norm_mul, norm_eR, mul_one]
          apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
          -- normalize the phase uniformly inside the finite sum
          have heq :
              (∑ m ∈ Finset.Icc M (X / d),
                (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
                  eR (((-((k + 1 : ℕ) : ℤ) : ℝ) * T /
                      (L : ℝ) / (d : ℝ) / (m : ℝ)) +
                    ((g.val : ℝ) / (P : ℝ)) * (m : ℝ)))) =
              ∑ m ∈ Finset.Icc M (X / d),
                (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
                  eR (-A / (m : ℝ) +
                    ((g.val : ℝ) / (P : ℝ)) * (m : ℝ))) := by
            apply Finset.sum_congr rfl
            intro m hm
            congr 2
            dsimp [A]
            push_cast
            ring
          rw [heq]
          exact hneg'
        calc
          ‖sawSmoothCoeff S (k + 1 : ℕ) *
                eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) / (L : ℝ)) *
                (∑ m ∈ Finset.Icc M (X / d),
                  (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
                    eR (((((k + 1 : ℕ) : ℝ) * T /
                        (L : ℝ) / (d : ℝ)) / (m : ℝ)) +
                      ((g.val : ℝ) / (P : ℝ)) * (m : ℝ)))) +
              sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
                eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) / (L : ℝ)) *
                (∑ m ∈ Finset.Icc M (X / d),
                  (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
                    eR (((-((k + 1 : ℕ) : ℤ) : ℝ) * T /
                        (L : ℝ) / (d : ℝ) / (m : ℝ)) +
                      ((g.val : ℝ) / (P : ℝ)) * (m : ℝ))))‖
            ≤
              ‖sawSmoothCoeff S (k + 1 : ℕ) *
                eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) / (L : ℝ)) *
                (∑ m ∈ Finset.Icc M (X / d),
                  (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
                    eR (((((k + 1 : ℕ) : ℝ) * T /
                        (L : ℝ) / (d : ℝ)) / (m : ℝ)) +
                      ((g.val : ℝ) / (P : ℝ)) * (m : ℝ))))‖ +
              ‖sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
                eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) / (L : ℝ)) *
                (∑ m ∈ Finset.Icc M (X / d),
                  (((coprimeIndicatorArithmetic q m / (m : ℝ) : ℝ) : ℂ) *
                    eR (((-((k + 1 : ℕ) : ℤ) : ℝ) * T /
                        (L : ℝ) / (d : ℝ) / (m : ℝ)) +
                      ((g.val : ℝ) / (P : ℝ)) * (m : ℝ))))‖ :=
                norm_add_le _ _
          _ ≤ (‖sawSmoothCoeff S (k + 1 : ℕ)‖ +
                ‖sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ))‖) *
              (omegaMiddleTailBound q beta M +
                24 * (P : ℝ) * (L : ℝ) / ((k + 1 : ℕ) : ℝ) +
                4 * (P : ℝ) * (1 + 2 * (P : ℝ)) /
                  ((T / ((L : ℝ) * (D : ℝ))) ^ (3 / 4 : ℝ))) := by
            nlinarith [hposTerm, hnegTerm]
    _ ≤ omegaSmallDivisorTailBound q beta M H T D := by
      let B0 : ℝ := omegaMiddleTailBound q beta M
      let B2 : ℝ :=
        4 * (P : ℝ) * (1 + 2 * (P : ℝ)) /
          ((T / ((L : ℝ) * (D : ℝ))) ^ (3 / 4 : ℝ))
      let B1 : ℝ := 24 * (P : ℝ) * (L : ℝ)
      have hB0 : 0 ≤ B0 :=
        omegaMiddleTailBound_nonneg q hb0 M (by omega)
      have hB2 : 0 ≤ B2 := by dsimp [B2]; positivity
      have hB1 : 0 ≤ B1 := by dsimp [B1]; positivity
      calc
        (∑ k ∈ Finset.range H,
          ((‖sawSmoothCoeff S (k + 1 : ℕ)‖ +
              ‖sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ))‖) *
            (B0 + B1 / ((k + 1 : ℕ) : ℝ) + B2)))
          =
          (B0 + B2) *
              (∑ k ∈ Finset.range H,
                (‖sawSmoothCoeff S (k + 1 : ℕ)‖ +
                  ‖sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ))‖)) +
            B1 *
              (∑ k ∈ Finset.range H,
                (‖sawSmoothCoeff S (k + 1 : ℕ)‖ +
                  ‖sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ))‖) /
                    ((k + 1 : ℕ) : ℝ)) := by
              rw [Finset.mul_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
              apply Finset.sum_congr rfl
              intro k hk
              ring
        _ ≤ (B0 + B2) * omegaFourierCoeffPairMassBound H +
              B1 * ((1 / Real.pi) * omegaPSeriesTwo) := by
          apply _root_.add_le_add
          · exact mul_le_mul_of_nonneg_left
              (by simpa [omegaFourierCoeffPairMassBound] using hcoefMass)
              (add_nonneg hB0 hB2)
          · apply mul_le_mul_of_nonneg_left _ hB1
            calc
              (∑ k ∈ Finset.range H,
                (‖sawSmoothCoeff S (k + 1 : ℕ)‖ +
                  ‖sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ))‖) /
                    ((k + 1 : ℕ) : ℝ))
                ≤ ∑ k ∈ Finset.range H,
                    (1 / Real.pi) *
                      (1 / (((k + 1 : ℕ) : ℝ) ^ (2 : ℝ))) := by
                  apply Finset.sum_le_sum
                  intro k hk
                  have hp := sawSmoothCoeff_pair_norm_le_reciprocal hS k
                  have hkR : (0 : ℝ) < (k + 1 : ℕ) := by positivity
                  have hdiv :=
                    div_le_div_of_nonneg_right hp hkR.le
                  have hsq :
                      (1 / Real.pi) *
                          (1 / ((k + 1 : ℕ) : ℝ)) /
                          ((k + 1 : ℕ) : ℝ) =
                        (1 / Real.pi) *
                          (1 / (((k + 1 : ℕ) : ℝ) ^ (2 : ℝ))) := by
                    rw [Real.rpow_two]
                    field_simp [ne_of_gt hkR]
                  calc
                    (‖sawSmoothCoeff S (k + 1 : ℕ)‖ +
                        ‖sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ))‖) /
                          ((k + 1 : ℕ) : ℝ)
                      ≤ (1 / Real.pi) *
                          (1 / ((k + 1 : ℕ) : ℝ)) /
                          ((k + 1 : ℕ) : ℝ) := by
                            simpa [one_div] using hdiv
                    _ = (1 / Real.pi) *
                          (1 / (((k + 1 : ℕ) : ℝ) ^ (2 : ℝ))) := hsq
              _ = (1 / Real.pi) *
                    ∑ k ∈ Finset.range H,
                      (1 / (((k + 1 : ℕ) : ℝ) ^ (2 : ℝ))) := by
                    rw [Finset.mul_sum]
              _ ≤ (1 / Real.pi) * omegaPSeriesTwo :=
                    mul_le_mul_of_nonneg_left
                      (sum_range_one_div_rpow_two_le H) (by positivity)
        _ = omegaSmallDivisorTailBound q beta M H T D := by
          dsimp [B0, B1, B2, P, L,
            omegaSmallDivisorTailBound,
            omegaFourierCoeffPairMassBound]
          ring

#print axioms omega_coprime_smoothed_tail_norm_le

end PaperB.Analytic
