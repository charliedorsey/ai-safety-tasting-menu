import OrielUpper.FixedVar2

/-!
# Oriel Upper — the fixed-variable estimate

For a fixed partner modulus `m` (coprime to `P` and to `H`), and the varying
variable `n` in `(A, B]`, with pair weight `b_F` vanishing off `(n, P m) = 1`:

`|∑_{A<n≤B} b_F(n) (ψ_{(n mod P, n mod m)}(X/n) + c₀/(m n))|`
`  ≤ (2P+1) B ℓ (τ(m) A₁/m + A₁/(m A)) + A_{3/4} (P m W' D^{3/4} + (2P+2) B ℓ D^{-1/4})`

for every `D > 0`, where `ℓ = 1 + log(B/A)`, `W' = B/A (2X/(A m) + 4P + 5)`,
`A₁ = A₁(F,B)`, `A_{3/4} = A_{3/4}(F,B)`, `|c₀| ≤ (2P+1)B`.
-/

open Finset
open scoped ArithmeticFunction.Moebius

namespace OrielUpper

variable {P : ℕ} [NeZero P]

lemma innerS_eq_zero_of_not_coprime {m H : ℕ} {Λ : ZMod P → ℝ} {α β : ZMod P} {X0 : ℝ}
    {A Bn e : ℕ} (he : ¬ Nat.Coprime e (P * m)) : innerS m H Λ α β X0 A Bn e = 0 := by
  unfold innerS
  apply sum_eq_zero
  intro k _
  rw [if_neg]
  intro h
  exact he (Nat.Coprime.coprime_mul_right h)

/-- Per-divisor envelope combining head and tail. -/
lemma innerS_envelope {m H : ℕ} [NeZero m] {Λ : ZMod P → ℝ} {B : ℝ}
    (hB : ∀ z, |Λ z| ≤ B) {α β : ZMod P} (hβ : IsUnit β) (hmP : Nat.Coprime m P)
    (hH : IsUnit (H : ZMod m)) {X0 : ℝ} (hX0 : 0 ≤ X0) {A Bn e : ℕ} (hA : 1 ≤ A)
    (hAB : A ≤ Bn) (he : 1 ≤ e) {D : ℝ} (hD : 0 < D) :
    |innerS m H Λ α β X0 A Bn e| ≤
      (m.divisors.card : ℝ) * (2 * P + 1) * B * (1 + Real.log ((Bn : ℝ) / A)) / (m * e) +
      (e : ℝ) ^ (-(3 / 4 : ℝ)) *
        ((P * m) * (B / A * (2 * (X0 / A) / m + 4 * P + 5)) * D ^ (3 / 4 : ℝ) +
          (2 * P + 2) * B * (1 + Real.log ((Bn : ℝ) / A)) * D ^ (-(1 / 4 : ℝ))) := by
  have hm0 : 0 < m := NeZero.pos m
  have hmr : (0 : ℝ) < m := by exact_mod_cast hm0
  have her : (0 : ℝ) < e := by exact_mod_cast (show 0 < e by omega)
  have hAr : (0 : ℝ) < A := by exact_mod_cast (show 0 < A by omega)
  have hB0 : 0 ≤ B := le_trans (abs_nonneg _) (hB 0)
  have hℓ0 : 0 ≤ 1 + Real.log ((Bn : ℝ) / A) := by
    have : 0 ≤ Real.log ((Bn : ℝ) / A) := Real.log_nonneg (by
      rw [le_div_iff₀ hAr, one_mul]; exact_mod_cast hAB)
    linarith
  set ℓ := 1 + Real.log ((Bn : ℝ) / A)
  set W' : ℝ := B / A * (2 * (X0 / A) / m + 4 * P + 5)
  have hW' : 0 ≤ W' := by positivity
  have hfirst : 0 ≤ (m.divisors.card : ℝ) * (2 * P + 1) * B * ℓ / (m * e) := by positivity
  have hpow : 0 < (e : ℝ) ^ (-(3 / 4 : ℝ)) := by positivity
  have hD34 : 0 < D ^ (3 / 4 : ℝ) := by positivity
  have hDm : 0 < D ^ (-(1 / 4 : ℝ)) := by positivity
  by_cases hcop : Nat.Coprime e (P * m)
  · by_cases heD : (e : ℝ) ≤ D
    · have h := oriel_inner_head (H := H) (α := α) hB hβ hmP hH hX0 hA hAB he hcop
      refine h.trans (add_le_add le_rfl ?_)
      -- 1 ≤ e^{-3/4} D^{3/4}
      have hge : 1 ≤ (e : ℝ) ^ (-(3 / 4 : ℝ)) * D ^ (3 / 4 : ℝ) := by
        rw [Real.rpow_neg her.le, inv_mul_eq_div, one_le_div (by positivity)]
        exact Real.rpow_le_rpow her.le heD (by norm_num)
      have hsecond : 0 ≤ (e : ℝ) ^ (-(3 / 4 : ℝ)) *
          ((2 * P + 2) * B * ℓ * D ^ (-(1 / 4 : ℝ))) := by positivity
      calc (P * m : ℝ) * W' = (P * m * W') * 1 := by ring
        _ ≤ (P * m * W') * ((e : ℝ) ^ (-(3 / 4 : ℝ)) * D ^ (3 / 4 : ℝ)) :=
            mul_le_mul_of_nonneg_left hge (by positivity)
        _ ≤ _ := by nlinarith
    · push_neg at heD
      have h := oriel_inner_tail hB hβ hmP (H := H) (α := α) hX0 hA hAB he
      refine h.trans ?_
      -- 1/e = e^{-3/4} e^{-1/4} ≤ e^{-3/4} D^{-1/4}
      have hsplit : (2 * P + 2) * B * ℓ / e =
          (e : ℝ) ^ (-(3 / 4 : ℝ)) * ((2 * P + 2) * B * ℓ * (e : ℝ) ^ (-(1 / 4 : ℝ))) := by
        have : (e : ℝ) ^ (-(3 / 4 : ℝ)) * (e : ℝ) ^ (-(1 / 4 : ℝ)) = 1 / e := by
          rw [← Real.rpow_add her]; norm_num; exact Real.rpow_neg_one _
        rw [show (e : ℝ) ^ (-(3 / 4 : ℝ)) * ((2 * P + 2) * B * ℓ * (e : ℝ) ^ (-(1 / 4 : ℝ))) =
          (2 * P + 2) * B * ℓ * ((e : ℝ) ^ (-(3 / 4 : ℝ)) * (e : ℝ) ^ (-(1 / 4 : ℝ))) by ring,
          this]
        ring
      have hcmp : (e : ℝ) ^ (-(1 / 4 : ℝ)) ≤ D ^ (-(1 / 4 : ℝ)) :=
        Real.rpow_le_rpow_of_nonpos hD heD.le (by norm_num)
      rw [hsplit]
      have hmid : 0 ≤ (e : ℝ) ^ (-(3 / 4 : ℝ)) *
          ((P * m) * W' * D ^ (3 / 4 : ℝ)) := by positivity
      have : (e : ℝ) ^ (-(3 / 4 : ℝ)) * ((2 * P + 2) * B * ℓ * (e : ℝ) ^ (-(1 / 4 : ℝ))) ≤
          (e : ℝ) ^ (-(3 / 4 : ℝ)) * ((2 * P + 2) * B * ℓ * D ^ (-(1 / 4 : ℝ))) := by
        apply mul_le_mul_of_nonneg_left _ hpow.le
        apply mul_le_mul_of_nonneg_left hcmp (by positivity)
      nlinarith
  · rw [innerS_eq_zero_of_not_coprime hcop, abs_zero]
    positivity

theorem oriel_fixed_var {m H F : ℕ} [NeZero m] {Λ : ZMod P → ℝ} {B : ℝ}
    (hB : ∀ z, |Λ z| ≤ B) {α β : ZMod P} (hβ : IsUnit β) (hmP : Nat.Coprime m P)
    (hH : IsUnit (H : ZMod m)) (hcopF : ∀ n, bW F n ≠ 0 → Nat.Coprime n (P * m))
    {A Bn : ℕ} (hA : 1 ≤ A) (hAB : A ≤ Bn) {X0 c0 : ℝ} (hX0 : 0 ≤ X0)
    (hc0 : |c0| ≤ (2 * P + 1) * B) {D : ℝ} (hD : 0 < D) :
    |∑ n ∈ Ioc A Bn, bW F n *
        (psiR m H Λ α β (n : ZMod P) (n : ZMod m) (X0 / n) + c0 / ((m : ℝ) * n))| ≤
      (2 * P + 1) * B * (1 + Real.log ((Bn : ℝ) / A)) *
          ((m.divisors.card : ℝ) * Asig F Bn 1 / m + Asig F Bn 1 / (m * A)) +
        Asig F Bn (3 / 4) *
          ((P * m) * (B / A * (2 * (X0 / A) / m + 4 * P + 5)) * D ^ (3 / 4 : ℝ) +
            (2 * P + 2) * B * (1 + Real.log ((Bn : ℝ) / A)) * D ^ (-(1 / 4 : ℝ))) := by
  have hm0 : 0 < m := NeZero.pos m
  have hmr : (0 : ℝ) < m := by exact_mod_cast hm0
  have hAr : (0 : ℝ) < A := by exact_mod_cast (show 0 < A by omega)
  have hB0 : 0 ≤ B := le_trans (abs_nonneg _) (hB 0)
  set ℓ := 1 + Real.log ((Bn : ℝ) / A)
  have hℓ0 : 0 ≤ ℓ := by
    have : 0 ≤ Real.log ((Bn : ℝ) / A) := Real.log_nonneg (by
      rw [le_div_iff₀ hAr, one_mul]; exact_mod_cast hAB)
    linarith
  set Q := P * m
  -- split ψ part and centering part
  rw [show ∑ n ∈ Ioc A Bn, bW F n *
      (psiR m H Λ α β (n : ZMod P) (n : ZMod m) (X0 / n) + c0 / ((m : ℝ) * n)) =
      ∑ n ∈ Ioc A Bn, bW F n * psiR m H Λ α β (n : ZMod P) (n : ZMod m) (X0 / n) +
      ∑ n ∈ Ioc A Bn, bW F n * (c0 / ((m : ℝ) * n)) by rw [← sum_add_distrib]; congr 1; ext; ring]
  -- centering part
  have hT2 : |∑ n ∈ Ioc A Bn, bW F n * (c0 / ((m : ℝ) * n))| ≤
      (2 * P + 1) * B * ℓ * (Asig F Bn 1 / (m * A)) := by
    refine (abs_sum_le_sum_abs _ _).trans ?_
    calc ∑ n ∈ Ioc A Bn, |bW F n * (c0 / ((m : ℝ) * n))|
        ≤ ∑ n ∈ Ioc A Bn, bW F n * ((2 * P + 1) * B / ((m : ℝ) * A)) := by
          apply sum_le_sum; intro n hn
          have hnA : A < n := (mem_Ioc.mp hn).1
          have hnr : (A : ℝ) < n := by exact_mod_cast hnA
          have hn0 : (0 : ℝ) < n := by linarith
          rw [abs_mul, abs_of_nonneg (bW_nonneg F n), abs_div,
            abs_of_pos (mul_pos hmr hn0)]
          apply mul_le_mul_of_nonneg_left _ (bW_nonneg F n)
          calc |c0| / ((m : ℝ) * n) ≤ (2 * P + 1) * B / ((m : ℝ) * n) :=
                div_le_div_of_nonneg_right hc0 (by positivity)
            _ ≤ (2 * P + 1) * B / ((m : ℝ) * A) := by
                apply div_le_div_of_nonneg_left (by positivity) (by positivity)
                exact mul_le_mul_of_nonneg_left hnr.le hmr.le
      _ = (∑ n ∈ Ioc A Bn, bW F n) * ((2 * P + 1) * B / ((m : ℝ) * A)) := by rw [sum_mul]
      _ ≤ (Asig F Bn 1 * ℓ) * ((2 * P + 1) * B / ((m : ℝ) * A)) :=
          mul_le_mul_of_nonneg_right (oriel_band_sum F hA hAB) (by positivity)
      _ = _ := by field_simp
  -- ψ part via κ-exchange
  have hT1eq : ∑ n ∈ Ioc A Bn, bW F n * psiR m H Λ α β (n : ZMod P) (n : ZMod m) (X0 / n) =
      ∑ e ∈ Icc 1 Bn, KW F e * innerS m H Λ α β X0 A Bn e := by
    have hpt : ∀ n, bW F n * psiR m H Λ α β (n : ZMod P) (n : ZMod m) (X0 / n) =
        ∑ e ∈ n.divisors, (if Nat.Coprime n Q then
          KW F e * (psiR m H Λ α β (n : ZMod P) (n : ZMod m) (X0 / n) / n) else 0) := by
      intro n
      by_cases hc : Nat.Coprime n Q
      · simp only [if_pos hc]
        rw [← sum_mul, sum_divisors_KW, bW]; ring
      · simp only [if_neg hc, sum_const_zero]
        have : bW F n = 0 := by
          by_contra h; exact hc (hcopF n h)
        rw [this, zero_mul]
    rw [sum_congr rfl (fun n _ => hpt n), oriel_divisor_exchange]
    apply sum_congr rfl
    intro e _
    unfold innerS
    rw [mul_sum]
    apply sum_congr rfl
    intro k _
    split_ifs <;> simp [mul_div_assoc]
  have hT1 : |∑ n ∈ Ioc A Bn, bW F n * psiR m H Λ α β (n : ZMod P) (n : ZMod m) (X0 / n)| ≤
      (2 * P + 1) * B * ℓ * ((m.divisors.card : ℝ) * Asig F Bn 1 / m) +
        Asig F Bn (3 / 4) *
          ((P * m) * (B / A * (2 * (X0 / A) / m + 4 * P + 5)) * D ^ (3 / 4 : ℝ) +
            (2 * P + 2) * B * ℓ * D ^ (-(1 / 4 : ℝ))) := by
    rw [hT1eq]
    refine (abs_sum_le_sum_abs _ _).trans ?_
    set C1 := (m.divisors.card : ℝ) * (2 * P + 1) * B * ℓ / m
    set C2 := (P * m) * (B / A * (2 * (X0 / A) / m + 4 * P + 5)) * D ^ (3 / 4 : ℝ) +
            (2 * P + 2) * B * ℓ * D ^ (-(1 / 4 : ℝ))
    calc ∑ e ∈ Icc 1 Bn, |KW F e * innerS m H Λ α β X0 A Bn e|
        ≤ ∑ e ∈ Icc 1 Bn, (|KW F e| * (e : ℝ) ^ (-(1 : ℝ)) * C1 +
            |KW F e| * (e : ℝ) ^ (-(3 / 4 : ℝ)) * C2) := by
          apply sum_le_sum; intro e he
          have he1 : 1 ≤ e := (mem_Icc.mp he).1
          have her : (0 : ℝ) < e := by exact_mod_cast (show 0 < e by omega)
          rw [abs_mul]
          have henv := innerS_envelope hB hβ hmP hH hX0 hA hAB he1 hD (H := H) (α := α)
          have e1 : (m.divisors.card : ℝ) * (2 * P + 1) * B * ℓ / (m * e) =
              (e : ℝ) ^ (-(1 : ℝ)) * C1 := by
            rw [Real.rpow_neg_one]; simp only [C1]; field_simp
          rw [e1] at henv
          calc |KW F e| * |innerS m H Λ α β X0 A Bn e|
              ≤ |KW F e| * ((e : ℝ) ^ (-(1 : ℝ)) * C1 + (e : ℝ) ^ (-(3 / 4 : ℝ)) * C2) :=
                mul_le_mul_of_nonneg_left henv (abs_nonneg _)
            _ = _ := by ring
      _ = Asig F Bn 1 * C1 + Asig F Bn (3 / 4) * C2 := by
          rw [sum_add_distrib, ← sum_mul, ← sum_mul]; rfl
      _ = _ := by simp only [C1]; ring
  calc |∑ n ∈ Ioc A Bn, bW F n * psiR m H Λ α β (n : ZMod P) (n : ZMod m) (X0 / n) +
        ∑ n ∈ Ioc A Bn, bW F n * (c0 / ((m : ℝ) * n))|
      ≤ _ + _ := abs_add_le _ _
    _ ≤ _ := add_le_add hT1 hT2
    _ = _ := by ring

end OrielUpper
