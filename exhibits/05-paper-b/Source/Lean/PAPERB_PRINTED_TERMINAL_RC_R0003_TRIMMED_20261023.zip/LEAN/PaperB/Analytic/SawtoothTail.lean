import PaperB.Analytic.SawtoothFourier

open scoped BigOperators

namespace PaperB.Analytic

open Real Finset

lemma one_div_sq_succ_le_telescoping
    {H k : ℕ} (hH : 1 ≤ H) :
    1 / (((H + k + 1 : ℕ) : ℝ) ^ 2)
      ≤ 1 / ((H + k : ℕ) : ℝ) - 1 / ((H + k + 1 : ℕ) : ℝ) := by
  have h0 : (0 : ℝ) < (H + k : ℕ) := by positivity
  have h1 : (0 : ℝ) < (H + k + 1 : ℕ) := by positivity
  rw [one_div, one_div, one_div]
  field_simp
  norm_num

/-- One-sided finite Fourier tail.  The bound is uniform in the terminal
frequency and therefore survives passage to the infinite tail. -/
theorem sawSmoothCoeff_positive_band_tail
    {T : ℝ} (hT : 1 < T) {H L : ℕ} (hH : 1 ≤ H) :
    (∑ k ∈ Finset.range L,
      ‖sawSmoothCoeff T (H + k + 1 : ℕ)‖)
      ≤ T / (2 * Real.pi ^ 2 * H) := by
  have hT0 : 0 < T := lt_trans zero_lt_one hT
  have hpi2 : 0 < 2 * Real.pi ^ 2 := by positivity
  calc
    (∑ k ∈ Finset.range L,
      ‖sawSmoothCoeff T (H + k + 1 : ℕ)‖)
      ≤ ∑ k ∈ Finset.range L,
          T / (2 * Real.pi ^ 2 * (((H + k + 1 : ℕ) : ℝ) ^ 2)) := by
        apply Finset.sum_le_sum
        intro k hk
        exact sawSmoothCoeff_le_quadratic hT (by
          exact_mod_cast (show (H + k + 1 : ℕ) ≠ 0 by omega))
    _ ≤ ∑ k ∈ Finset.range L,
          (T / (2 * Real.pi ^ 2)) *
            (1 / ((H + k : ℕ) : ℝ) -
             1 / ((H + k + 1 : ℕ) : ℝ)) := by
        apply Finset.sum_le_sum
        intro k hk
        have htel := one_div_sq_succ_le_telescoping (H := H) (k := k) hH
        have hc : 0 ≤ T / (2 * Real.pi ^ 2) := by positivity
        convert mul_le_mul_of_nonneg_left htel hc using 1 <;> ring
    _ = (T / (2 * Real.pi ^ 2)) *
          (1 / (H : ℝ) - 1 / ((H + L : ℕ) : ℝ)) := by
        rw [← Finset.mul_sum]
        have hsum := Finset.sum_range_sub'
          (fun k : ℕ => (1 : ℝ) / ((H + k : ℕ) : ℝ)) L
        congr 1
    _ ≤ (T / (2 * Real.pi ^ 2)) * (1 / (H : ℝ)) := by
        have hHL : (0 : ℝ) ≤ 1 / ((H + L : ℕ) : ℝ) := by positivity
        have hc : 0 ≤ T / (2 * Real.pi ^ 2) := by positivity
        nlinarith
    _ = T / (2 * Real.pi ^ 2 * H) := by
        have hHr : (H : ℝ) ≠ 0 := by exact_mod_cast (show H ≠ 0 by omega)
        field_simp [hHr]

/-- Two-sided finite high-frequency tail, with positive and negative
frequencies paired. -/
theorem sawSmoothCoeff_two_sided_band_tail
    {T : ℝ} (hT : 1 < T) {H L : ℕ} (hH : 1 ≤ H) :
    (∑ k ∈ Finset.range L,
      (‖sawSmoothCoeff T (H + k + 1 : ℕ)‖ +
       ‖sawSmoothCoeff T (-((H + k + 1 : ℕ) : ℤ))‖))
      ≤ T / (Real.pi ^ 2 * H) := by
  have hp := sawSmoothCoeff_positive_band_tail hT hH (L := L)
  have hn :
      (∑ k ∈ Finset.range L,
        ‖sawSmoothCoeff T (-((H + k + 1 : ℕ) : ℤ))‖)
        ≤ T / (2 * Real.pi ^ 2 * H) := by
    calc
      _ ≤ ∑ k ∈ Finset.range L,
          T / (2 * Real.pi ^ 2 * (((H + k + 1 : ℕ) : ℝ) ^ 2)) := by
        apply Finset.sum_le_sum
        intro k hk
        have hq := sawSmoothCoeff_le_quadratic hT
          (n := -((H + k + 1 : ℕ) : ℤ))
          (by exact neg_ne_zero.mpr (by exact_mod_cast
            (show (H + k + 1 : ℕ) ≠ 0 by omega)))
        convert hq using 1 <;> norm_num <;> ring
      _ ≤ T / (2 * Real.pi ^ 2 * H) := by
        exact le_trans
          (by
            apply Finset.sum_le_sum
            intro k hk
            have htel := one_div_sq_succ_le_telescoping (H := H) (k := k) hH
            have hc : 0 ≤ T / (2 * Real.pi ^ 2) := by positivity
            convert mul_le_mul_of_nonneg_left htel hc using 1 <;> ring)
          (by
            rw [← Finset.mul_sum]
            have hsum := Finset.sum_range_sub'
              (fun k : ℕ => (1 : ℝ) / ((H + k : ℕ) : ℝ)) L
            have hsum' :
                (∑ i ∈ Finset.range L,
                  (1 / ((H + i : ℕ) : ℝ) -
                   1 / ((H + i + 1 : ℕ) : ℝ))) =
                  1 / (H : ℝ) - 1 / ((H + L : ℕ) : ℝ) := by
              simpa [Nat.add_assoc] using hsum
            rw [hsum']
            have hHL : (0 : ℝ) ≤ 1 / ((H + L : ℕ) : ℝ) := by positivity
            have hc : 0 ≤ T / (2 * Real.pi ^ 2) := by positivity
            have hHr : (H : ℝ) ≠ 0 := by exact_mod_cast (show H ≠ 0 by omega)
            calc
              (T / (2 * Real.pi ^ 2)) *
                  (1 / (H : ℝ) - 1 / ((H + L : ℕ) : ℝ))
                ≤ (T / (2 * Real.pi ^ 2)) * (1 / (H : ℝ)) := by nlinarith
              _ = T / (2 * Real.pi ^ 2 * H) := by
                field_simp [Real.pi_ne_zero, hHr])
  rw [Finset.sum_add_distrib]
  calc
    _ ≤ T / (2 * Real.pi ^ 2 * H) +
          T / (2 * Real.pi ^ 2 * H) := add_le_add hp hn
    _ = T / (Real.pi ^ 2 * H) := by
      have hHr : (H : ℝ) ≠ 0 := by exact_mod_cast (show H ≠ 0 by omega)
      field_simp [Real.pi_ne_zero]
      ring

#print axioms sawSmoothCoeff_positive_band_tail
#print axioms sawSmoothCoeff_two_sided_band_tail

end PaperB.Analytic
