import PaperB.FixedQ.EtaLinearConvolution
import Mathlib.NumberTheory.EulerProduct.Basic
import Mathlib.Analysis.PSeries

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def etaCorrectionRankin (q n : ℕ) : ℝ :=
  if n = 0 then 0
  else |etaLinearCorrectionArithmetic q n| * (n : ℝ) ^ (-3 / 4 : ℝ)

@[simp] theorem etaCorrectionRankin_zero (q : ℕ) :
    etaCorrectionRankin q 0 = 0 := by
  simp [etaCorrectionRankin]

@[simp] theorem etaCorrectionRankin_one (q : ℕ) :
    etaCorrectionRankin q 1 = 1 := by
  simp [etaCorrectionRankin, etaLinearCorrectionArithmetic,
    etaLinearCorrectionCoeff]

theorem etaCorrectionRankin_nonneg (q n : ℕ) :
    0 ≤ etaCorrectionRankin q n := by
  by_cases hn : n = 0
  · simp [hn]
  · rw [etaCorrectionRankin, if_neg hn]
    exact mul_nonneg (abs_nonneg _) (Real.rpow_nonneg (by positivity) _)

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem etaCorrectionRankin_mul_of_coprime
    (q : ℕ) {m n : ℕ} (hcop : m.Coprime n) :
    etaCorrectionRankin q (m * n) =
      etaCorrectionRankin q m * etaCorrectionRankin q n := by
  by_cases hm0 : m = 0
  · subst m
    have hn1 : n = 1 := by simpa using hcop
    subst n
    simp
  · by_cases hn0 : n = 0
    · subst n
      have hm1 : m = 1 := by simpa using hcop
      subst m
      simp
    · have hmn0 : m * n ≠ 0 := mul_ne_zero hm0 hn0
      rw [etaCorrectionRankin, if_neg hmn0,
        etaCorrectionRankin, if_neg hm0,
        etaCorrectionRankin, if_neg hn0]
      rw [(etaLinearCorrectionArithmetic_multiplicative q).map_mul_of_coprime hcop,
        abs_mul, Nat.cast_mul, Real.mul_rpow (by positivity) (by positivity)]
      ring

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem summable_etaCorrectionRankin_prime_pow
    (q : ℕ) {p : ℕ} (hp : p.Prime) :
    Summable (fun nu : ℕ => etaCorrectionRankin q (p ^ nu)) := by
  apply summable_of_hasFiniteSupport
  refine ({0, 1, 2} : Finset ℕ).finite_toSet.subset ?_
  intro nu hsupport
  by_contra hmem
  have h0 : nu ≠ 0 := by
    intro h
    subst nu
    exact hmem (by simp)
  have h1 : nu ≠ 1 := by
    intro h
    subst nu
    exact hmem (by simp)
  have h2 : nu ≠ 2 := by
    intro h
    subst nu
    exact hmem (by simp)
  apply hsupport
  change etaCorrectionRankin q (p ^ nu) = 0
  rw [etaCorrectionRankin, if_neg (pow_ne_zero _ hp.ne_zero)]
  rw [etaLinearCorrectionArithmetic_prime_pow q hp]
  simp [etaLinearCorrectionLocal, hp, h0, h1, h2]

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem tsum_etaCorrectionRankin_prime_pow_eq_three
    (q : ℕ) {p : ℕ} (hp : p.Prime) :
    (∑' nu : ℕ, etaCorrectionRankin q (p ^ nu)) =
      etaCorrectionRankin q 1 +
      etaCorrectionRankin q p +
      etaCorrectionRankin q (p ^ 2) := by
  rw [tsum_eq_sum (s := ({0, 1, 2} : Finset ℕ))]
  · simp [add_assoc, add_comm, add_left_comm]
  · intro nu hmem
    have h0 : nu ≠ 0 := by
      intro h
      subst nu
      exact hmem (by simp)
    have h1 : nu ≠ 1 := by
      intro h
      subst nu
      exact hmem (by simp)
    have h2 : nu ≠ 2 := by
      intro h
      subst nu
      exact hmem (by simp)
    rw [etaCorrectionRankin, if_neg (pow_ne_zero _ hp.ne_zero)]
    rw [etaLinearCorrectionArithmetic_prime_pow q hp]
    simp [etaLinearCorrectionLocal, hp, h0, h1, h2]

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma two_div_sub_two_le_four_div
    {p : ℕ} (hp5 : 5 ≤ p) :
    (2 : ℝ) / ((p : ℝ) - 2) ≤ 4 / (p : ℝ) := by
  have hpR : (5 : ℝ) ≤ (p : ℝ) := by exact_mod_cast hp5
  have hp0 : (0 : ℝ) < (p : ℝ) := by positivity
  have hpm2 : (0 : ℝ) < (p : ℝ) - 2 := by linarith
  rw [div_le_div_iff₀ hpm2 hp0]
  nlinarith

lemma p_div_sub_two_le_two
    {p : ℕ} (hp5 : 5 ≤ p) :
    (p : ℝ) / ((p : ℝ) - 2) ≤ 2 := by
  have hpR : (5 : ℝ) ≤ (p : ℝ) := by exact_mod_cast hp5
  have hpm2 : (0 : ℝ) < (p : ℝ) - 2 := by linarith
  rw [div_le_iff₀ hpm2]
  linarith

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma eta_rankin_five_le_of_prime_coprime_six
    {q p : ℕ} (hp : p.Prime) (hcop : p.Coprime (6 * q)) :
    5 ≤ p := by
  have hnot2 : p ≠ 2 := by
    intro h
    subst p
    have hd : 2 ∣ 6 * q := dvd_mul_of_dvd_left (by norm_num : 2 ∣ 6) q
    exact (hp.coprime_iff_not_dvd.mp hcop) hd
  have hnot3 : p ≠ 3 := by
    intro h
    subst p
    have hd : 3 ∣ 6 * q := dvd_mul_of_dvd_left (by norm_num : 3 ∣ 6) q
    exact (hp.coprime_iff_not_dvd.mp hcop) hd
  have hp2 := hp.two_le
  have hp4 : p ≠ 4 := by
    intro h
    subst p
    exact (by decide : ¬ Nat.Prime 4) hp
  omega

lemma etaCorrectionRankin_prime_active
    (q : ℕ) {p : ℕ} (hp : p.Prime) (hcop : p.Coprime (6 * q)) :
    etaCorrectionRankin q p =
      (2 / ((p : ℝ) - 2)) * (p : ℝ) ^ (-3 / 4 : ℝ) := by
  have hp0 : p ≠ 0 := hp.ne_zero
  rw [etaCorrectionRankin, if_neg hp0]
  have hlocal :=
    etaLinearCorrectionArithmetic_prime_pow (q := q) (p := p) (i := 1) hp
  have hcoeff :
      etaLinearCorrectionArithmetic q p = 2 / ((p : ℝ) - 2) := by
    have hlocal' := hlocal
    simp [etaLinearCorrectionLocal, hp] at hlocal'
    rw [if_pos hcop] at hlocal'
    simpa using hlocal'
  rw [hcoeff]
  have hp5 : 5 ≤ p := eta_rankin_five_le_of_prime_coprime_six hp hcop
  have hden : 0 < (p : ℝ) - 2 := by
    have : (5 : ℝ) ≤ p := by exact_mod_cast hp5
    linarith
  rw [abs_of_nonneg (div_nonneg (by norm_num) hden.le)]

lemma etaCorrectionRankin_prime_sq_active
    (q : ℕ) {p : ℕ} (hp : p.Prime) (hcop : p.Coprime (6 * q)) :
    etaCorrectionRankin q (p ^ 2) =
      ((p : ℝ) / ((p : ℝ) - 2)) *
        (p : ℝ) ^ (-3 / 2 : ℝ) := by
  have hp0 : p ^ 2 ≠ 0 := pow_ne_zero _ hp.ne_zero
  rw [etaCorrectionRankin, if_neg hp0]
  have hlocal :=
    etaLinearCorrectionArithmetic_prime_pow (q := q) (p := p) (i := 2) hp
  have hcoeff :
      etaLinearCorrectionArithmetic q (p ^ 2) =
        -(p : ℝ) / ((p : ℝ) - 2) := by
    have hlocal' := hlocal
    simp [etaLinearCorrectionLocal, hp] at hlocal'
    rw [if_pos hcop] at hlocal'
    simpa using hlocal'
  rw [hcoeff]
  have hp5 : 5 ≤ p := eta_rankin_five_le_of_prime_coprime_six hp hcop
  have hden : 0 < (p : ℝ) - 2 := by
    have : (5 : ℝ) ≤ p := by exact_mod_cast hp5
    linarith
  rw [abs_div, abs_neg, abs_of_nonneg (by positivity : (0 : ℝ) ≤ p),
    abs_of_pos hden]
  rw [Nat.cast_pow]
  rw [← Real.rpow_natCast_mul (by positivity : (0 : ℝ) ≤ p) 2 (-3 / 4 : ℝ)]
  norm_num

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma etaCorrectionRankin_prime_active_le
    (q : ℕ) {p : ℕ} (hp : p.Prime) (hcop : p.Coprime (6 * q)) :
    etaCorrectionRankin q p ≤
      4 * (p : ℝ) ^ (-3 / 2 : ℝ) := by
  rw [etaCorrectionRankin_prime_active q hp hcop]
  have hp5 : 5 ≤ p := eta_rankin_five_le_of_prime_coprime_six hp hcop
  have hp1 : (1 : ℝ) ≤ (p : ℝ) := by
    exact_mod_cast (show 1 ≤ p by omega)
  have hcoef := two_div_sub_two_le_four_div hp5
  have hpow0 : 0 ≤ (p : ℝ) ^ (-3 / 4 : ℝ) :=
    Real.rpow_nonneg (by positivity) _
  calc
    (2 / ((p : ℝ) - 2)) * (p : ℝ) ^ (-3 / 4 : ℝ)
        ≤ (4 / (p : ℝ)) * (p : ℝ) ^ (-3 / 4 : ℝ) :=
      mul_le_mul_of_nonneg_right hcoef hpow0
    _ = 4 * (p : ℝ) ^ (-7 / 4 : ℝ) := by
      rw [div_eq_mul_inv, ← Real.rpow_neg_one]
      rw [mul_assoc, ← Real.rpow_add (by positivity : (0 : ℝ) < p)]
      norm_num
    _ ≤ 4 * (p : ℝ) ^ (-3 / 2 : ℝ) := by
      exact mul_le_mul_of_nonneg_left
        (Real.rpow_le_rpow_of_exponent_le hp1 (by norm_num))
        (by norm_num)

lemma etaCorrectionRankin_prime_sq_active_le
    (q : ℕ) {p : ℕ} (hp : p.Prime) (hcop : p.Coprime (6 * q)) :
    etaCorrectionRankin q (p ^ 2) ≤
      2 * (p : ℝ) ^ (-3 / 2 : ℝ) := by
  rw [etaCorrectionRankin_prime_sq_active q hp hcop]
  have hp5 : 5 ≤ p := eta_rankin_five_le_of_prime_coprime_six hp hcop
  have hcoef := p_div_sub_two_le_two hp5
  exact mul_le_mul_of_nonneg_right hcoef
    (Real.rpow_nonneg (by positivity) _)

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma etaCorrectionRankin_prime_inactive
    (q : ℕ) {p : ℕ} (hp : p.Prime) (hcop : ¬ p.Coprime (6 * q)) :
    etaCorrectionRankin q p = 0 := by
  have hp0 : p ≠ 0 := hp.ne_zero
  rw [etaCorrectionRankin, if_neg hp0]
  have hlocal :=
    etaLinearCorrectionArithmetic_prime_pow (q := q) (p := p) (i := 1) hp
  have hcoeff : etaLinearCorrectionArithmetic q p = 0 := by
    have hlocal' := hlocal
    simp [etaLinearCorrectionLocal, hp] at hlocal'
    rw [if_neg hcop] at hlocal'
    simpa using hlocal'
  rw [hcoeff]
  simp

lemma etaCorrectionRankin_prime_sq_inactive
    (q : ℕ) {p : ℕ} (hp : p.Prime) (hcop : ¬ p.Coprime (6 * q)) :
    etaCorrectionRankin q (p ^ 2) = 0 := by
  have hp0 : p ^ 2 ≠ 0 := pow_ne_zero _ hp.ne_zero
  rw [etaCorrectionRankin, if_neg hp0]
  have hlocal :=
    etaLinearCorrectionArithmetic_prime_pow (q := q) (p := p) (i := 2) hp
  have hcoeff : etaLinearCorrectionArithmetic q (p ^ 2) = 0 := by
    have hlocal' := hlocal
    simp [etaLinearCorrectionLocal, hp] at hlocal'
    rw [if_neg hcop] at hlocal'
    simpa using hlocal'
  rw [hcoeff]
  simp

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem tsum_etaCorrectionRankin_prime_pow_le
    (q : ℕ) {p : ℕ} (hp : p.Prime) :
    (∑' nu : ℕ, etaCorrectionRankin q (p ^ nu)) ≤
      1 + 10 * (p : ℝ) ^ (-3 / 2 : ℝ) := by
  rw [tsum_etaCorrectionRankin_prime_pow_eq_three q hp]
  by_cases hcop : p.Coprime (6 * q)
  · have h1 := etaCorrectionRankin_prime_active_le q hp hcop
    have h2 := etaCorrectionRankin_prime_sq_active_le q hp hcop
    simp only [etaCorrectionRankin_one]
    have hpow0 : 0 ≤ (p : ℝ) ^ (-3 / 2 : ℝ) :=
      Real.rpow_nonneg (by positivity) _
    nlinarith
  · rw [etaCorrectionRankin_prime_inactive q hp hcop,
      etaCorrectionRankin_prime_sq_inactive q hp hcop]
    simp
    positivity

#print axioms tsum_etaCorrectionRankin_prime_pow_le

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def etaRankinBound : ℝ :=
  Real.exp (∑' n : ℕ, 10 * (n : ℝ) ^ (-3 / 2 : ℝ))

lemma summable_etaRankinMajorant :
    Summable (fun n : ℕ => 10 * (n : ℝ) ^ (-3 / 2 : ℝ)) := by
  exact (Real.summable_nat_rpow.mpr (by norm_num : (-3 / 2 : ℝ) < -1)).mul_left 10

lemma etaRankin_prime_product_le_bound
    (q N : ℕ) :
    (∏ p ∈ N.primesBelow,
      ∑' nu : ℕ, etaCorrectionRankin q (p ^ nu)) ≤
      etaRankinBound := by
  have hlocal_nonneg :
      ∀ p ∈ N.primesBelow,
        0 ≤ ∑' nu : ℕ, etaCorrectionRankin q (p ^ nu) := by
    intro p hp
    exact tsum_nonneg (fun nu => etaCorrectionRankin_nonneg q (p ^ nu))
  have hmaj_nonneg :
      ∀ p ∈ N.primesBelow,
        0 ≤ 1 + 10 * (p : ℝ) ^ (-3 / 2 : ℝ) := by
    intro p hp
    positivity
  have hprod :
      ∀ s : Finset ℕ, (∀ p ∈ s, p.Prime) →
        (∏ p ∈ s, ∑' nu : ℕ, etaCorrectionRankin q (p ^ nu)) ≤
          ∏ p ∈ s, (1 + 10 * (p : ℝ) ^ (-3 / 2 : ℝ)) := by
    intro s hs
    induction s using Finset.induction_on with
    | empty =>
        simp
    | @insert a s ha ih =>
        rw [Finset.prod_insert ha, Finset.prod_insert ha]
        have haPrime : a.Prime := hs a (Finset.mem_insert_self a s)
        have hsPrime : ∀ p ∈ s, p.Prime := by
          intro p hp
          exact hs p (Finset.mem_insert_of_mem hp)
        have hAle :
            (∑' nu : ℕ, etaCorrectionRankin q (a ^ nu)) ≤
              1 + 10 * (a : ℝ) ^ (-3 / 2 : ℝ) :=
          tsum_etaCorrectionRankin_prime_pow_le q haPrime
        have htail := ih hsPrime
        have htail0 :
            0 ≤ ∏ p ∈ s, ∑' nu : ℕ, etaCorrectionRankin q (p ^ nu) := by
          apply Finset.prod_nonneg
          intro p hp
          exact tsum_nonneg (fun nu => etaCorrectionRankin_nonneg q (p ^ nu))
        have hhead0 :
            0 ≤ 1 + 10 * (a : ℝ) ^ (-3 / 2 : ℝ) := by
          positivity
        exact mul_le_mul hAle htail htail0 hhead0
  calc
    (∏ p ∈ N.primesBelow,
      ∑' nu : ℕ, etaCorrectionRankin q (p ^ nu))
        ≤ ∏ p ∈ N.primesBelow,
            (1 + 10 * (p : ℝ) ^ (-3 / 2 : ℝ)) := by
      exact hprod N.primesBelow
        (fun p hp => Nat.prime_of_mem_primesBelow hp)
    _ ≤ Real.exp
          (∑ p ∈ N.primesBelow,
            10 * (p : ℝ) ^ (-3 / 2 : ℝ)) := by
      exact Real.prod_one_add_le_exp_sum N.primesBelow
        (fun p => by positivity)
    _ ≤ etaRankinBound := by
      unfold etaRankinBound
      apply Real.exp_le_exp.mpr
      exact (summable_etaRankinMajorant.sum_le_tsum N.primesBelow
        (fun n hn => by positivity))

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem etaCorrectionRankin_sum_range_le_bound
    (q N : ℕ) :
    (∑ n ∈ Finset.range N, etaCorrectionRankin q n) ≤
      etaRankinBound := by
  let A : Finset ℕ := (Finset.range N).erase 0
  have hsumA :
      (∑ n ∈ Finset.range N, etaCorrectionRankin q n) =
        ∑ n ∈ A, etaCorrectionRankin q n := by
    by_cases h0 : 0 ∈ Finset.range N
    · rw [← Finset.sum_erase_add (Finset.range N)
        (fun n => etaCorrectionRankin q n) h0]
      simp [A]
    · have hN : N = 0 := by
        simpa using h0
      subst N
      simp [A]
  let e : {n // n ∈ A} ↪ N.smoothNumbers :=
    ⟨fun x =>
      ⟨x.1, Nat.mem_smoothNumbers_of_lt
        (Nat.pos_of_ne_zero (Finset.mem_erase.mp x.2).1)
        (Finset.mem_range.mp (Finset.mem_erase.mp x.2).2)⟩,
      by
        intro x y hxy
        apply Subtype.ext
        exact congrArg (fun z : N.smoothNumbers => (z : ℕ)) hxy⟩
  let S : Finset N.smoothNumbers := A.attach.map e
  have hsumS :
      (∑ n ∈ A, etaCorrectionRankin q n) =
        ∑ x ∈ S, etaCorrectionRankin q x := by
    refine Finset.sum_bij
      (fun n hn => e ⟨n, hn⟩)
      ?_ ?_ ?_ ?_
    · intro n hn
      simp [S]
    · intro n1 hn1 n2 hn2 hEq
      exact congrArg (fun z : N.smoothNumbers => (z : ℕ)) hEq
    · intro b hb
      simpa [S] using hb
    · intro n hn
      rfl
  have hsmooth :=
    EulerProduct.summable_and_hasSum_smoothNumbers_prod_primesBelow_tsum
      (f := etaCorrectionRankin q)
      (etaCorrectionRankin_one q)
      (fun {_m _n} hcop => etaCorrectionRankin_mul_of_coprime q hcop)
      (fun {_p} hp => by
        exact (summable_etaCorrectionRankin_prime_pow q hp).congr
          (fun nu => by
            rw [Real.norm_eq_abs,
              abs_of_nonneg (etaCorrectionRankin_nonneg q (_p ^ nu))]))
      N
  rw [hsumA, hsumS]
  calc
    (∑ x ∈ S, etaCorrectionRankin q x)
        ≤ ∑' x : N.smoothNumbers, etaCorrectionRankin q x := by
      exact hsmooth.1.of_norm.sum_le_tsum S
        (fun x hx => etaCorrectionRankin_nonneg q x)
    _ = ∏ p ∈ N.primesBelow,
          ∑' nu : ℕ, etaCorrectionRankin q (p ^ nu) :=
      hsmooth.2.tsum_eq
    _ ≤ etaRankinBound := etaRankin_prime_product_le_bound q N

#print axioms etaCorrectionRankin_sum_range_le_bound

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem summable_etaCorrectionRankin (q : ℕ) :
    Summable (etaCorrectionRankin q) := by
  exact summable_of_sum_range_le
    (etaCorrectionRankin_nonneg q)
    (etaCorrectionRankin_sum_range_le_bound q)

theorem tsum_etaCorrectionRankin_le_bound (q : ℕ) :
    (∑' n : ℕ, etaCorrectionRankin q n) ≤ etaRankinBound := by
  exact Real.tsum_le_of_sum_range_le
    (etaCorrectionRankin_nonneg q)
    (etaCorrectionRankin_sum_range_le_bound q)

#print axioms summable_etaCorrectionRankin
#print axioms tsum_etaCorrectionRankin_le_bound

end PaperB.FixedQ
