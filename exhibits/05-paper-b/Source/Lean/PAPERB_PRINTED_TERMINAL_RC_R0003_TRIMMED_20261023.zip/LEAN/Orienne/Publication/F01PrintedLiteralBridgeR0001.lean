import PaperB.FixedQ.SourceBridge
import PaperB.FixedQ.PrincipalOneDimensionalCancellation
import PaperB.Closure
import PaperB.FixedQ.EtaReciprocalTail
import Mathlib.NumberTheory.EulerProduct.Basic

/-! F-01 direct printed Euler factors; no reuse of printed A/B kernel names. -/
open scoped BigOperators
set_option maxHeartbeats 1500000
namespace Merivelle.F01
open PaperB.FixedQ

def occupiedResidues (p : ℕ) (H : Finset ℕ) : Finset ℕ :=
  H.image (fun x => x % p)

noncomputable def printedLocal (p : ℕ) (H : Finset ℕ) : ℝ :=
  (1 - (occupiedResidues p H).card / (p : ℝ)) /
    ((1 - 1 / (p : ℝ)) ^ H.card)

noncomputable def printedRestrictedSingularSeries (q : ℕ) (H : Finset ℕ) : ℝ :=
  ∏' p : ℕ, if Nat.Prime p ∧ ¬ p ∣ q then printedLocal p H else 1

theorem occupied_pair_card (p h : ℕ) :
    (occupiedResidues p ({0,h} : Finset ℕ)).card =
      endpointOccupiedCount p h := by
  simp [occupiedResidues, endpointOccupiedCount]

theorem occupied_triple_card (p h y : ℕ) :
    (occupiedResidues p ({0,y,h} : Finset ℕ)).card =
      tripleOccupiedCount p h y := by
  simp [occupiedResidues, tripleOccupiedCount]

theorem printedLocal_pair_eq_free (p h : ℕ) (hh : 0 < h) :
    printedLocal p ({0,h} : Finset ℕ) =
      freeLocalFactorRatio p h := by
  have hc : ({0,h} : Finset ℕ).card = 2 :=
    card_pair_zero_of_ne_zero (Nat.ne_of_gt hh)
  unfold printedLocal freeLocalFactorRatio
  rw [hc, occupied_pair_card]

theorem printedLocal_pair_eq_baseline
    (q h p : ℕ) (hh : 0 < h)
    (hp5 : 5 ≤ p) (hnh : ¬ p ∣ h) :
    (if Nat.Prime p ∧ ¬ p ∣ q then
      printedLocal p ({0,h} : Finset ℕ) else 1) =
      normalizationBaseline q 0 p := by
  have hc : endpointOccupiedCount p h = 2 := by
    unfold endpointOccupiedCount
    have hm : h % p ≠ 0 := Nat.dvd_iff_mod_eq_zero.not.mp hnh
    exact Finset.card_pair hm.symm
  by_cases ha : Nat.Prime p ∧ ¬ p ∣ q
  · have hacc : Nat.Prime p ∧ 5 ≤ p ∧ ¬ p ∣ q :=
      ⟨ha.1, hp5, ha.2⟩
    rw [if_pos ha, printedLocal_pair_eq_free p h hh]
    simp only [freeLocalFactorRatio, hc, normalizationBaseline,
      if_pos hacc, dvd_zero, if_pos]
    have hp0 : (p : ℝ) ≠ 0 := by
      exact_mod_cast (show p ≠ 0 by omega)
    have hp1 : (p : ℝ) - 1 ≠ 0 := by
      exact sub_ne_zero.mpr
        (by exact_mod_cast (show p ≠ 1 by omega))
    field_simp [hp0, hp1]
    ring
  · have hbad : ¬ (p.Prime ∧ 5 ≤ p ∧ ¬ p ∣ q) := by
      intro hx
      exact ha ⟨hx.1, hx.2.2⟩
    simp [ha, normalizationBaseline, hbad]

/-- The literal printed endpoint product converges: beyond p > max(4,h)
its factors coincide with the already certified c1 baseline. -/
theorem printed_pair_multipliable (q h : ℕ) (hh : 0 < h) :
    Multipliable (fun p : ℕ =>
      if Nat.Prime p ∧ ¬ p ∣ q then
        printedLocal p ({0,h} : Finset ℕ) else 1) := by
  have heq :
      (fun p : ℕ => normalizationBaseline q 0 p) =ᶠ[Filter.atTop]
      (fun p : ℕ => if Nat.Prime p ∧ ¬ p ∣ q then
        printedLocal p ({0,h} : Finset ℕ) else 1) := by
    filter_upwards [Filter.eventually_ge_atTop (max 5 (h + 1))] with p hp
    have hp5 : 5 ≤ p := (le_max_left _ _).trans hp
    have hhp : h < p := by omega
    have hnd : ¬ p ∣ h := by
      intro hd
      have hple : p ≤ h := Nat.le_of_dvd hh hd
      omega
    exact (printedLocal_pair_eq_baseline q h p hh hp5 hnd).symm
  have hs : Summable (fun p : ℕ =>
      ‖(if Nat.Prime p ∧ ¬ p ∣ q then
        printedLocal p ({0,h} : Finset ℕ) else 1) - 1‖) := by
    apply (summable_norm_normalizationBaseline_sub_one q 0).congr_atTop
    filter_upwards [heq] with p hp
    rw [hp]
  have hm : Multipliable (fun p : ℕ =>
      1 + ((if Nat.Prime p ∧ ¬ p ∣ q then
        printedLocal p ({0,h} : Finset ℕ) else 1) - 1)) :=
    multipliable_one_add_of_summable hs
  exact hm.congr (fun p => by ring)

/-- Convergence stated directly for the independent printed Euler-product
definition used by the F-01 literal bridge. -/
theorem printed_pair_singularSeries_multipliable (q h : ℕ) (hh : 0 < h) :
    Multipliable (fun p : ℕ =>
      if Nat.Prime p ∧ ¬ p ∣ q then printedLocal p ({0,h} : Finset ℕ) else 1) :=
  printed_pair_multipliable q h hh

/-- No Euler local obstruction at any p ≥ 3: an endpoint pair
occupies at most two residue classes. -/
theorem printed_pair_local_positive_high (p h : ℕ)
    (hp : 3 ≤ p) (hh : 0 < h) :
    0 < printedLocal p ({0,h} : Finset ℕ) := by
  have hcard : (occupiedResidues p ({0,h} : Finset ℕ)).card ≤ 2 := by
    unfold occupiedResidues
    calc
      (Finset.image (fun x : ℕ => x % p) ({0,h} : Finset ℕ)).card ≤
          ({0,h} : Finset ℕ).card := Finset.card_image_le
      _ = 2 := card_pair_zero_of_ne_zero (Nat.ne_of_gt hh)
  have hnum : 0 < (1 : ℝ) -
      (occupiedResidues p ({0,h} : Finset ℕ)).card / (p : ℝ) := by
    have hpR : (2 : ℝ) < (p : ℝ) := by exact_mod_cast (show 2 < p by omega)
    have hnR : ((occupiedResidues p ({0,h} : Finset ℕ)).card : ℝ) ≤ 2 := by
      exact_mod_cast hcard
    have hpR0 : (0 : ℝ) < (p : ℝ) := by positivity
    apply sub_pos.mpr
    apply (div_lt_one hpR0).mpr
    linarith
  have hbase : 0 < (1 : ℝ) - 1 / (p : ℝ) := by
    have hpR : (1 : ℝ) < (p : ℝ) := by exact_mod_cast (show 1 < p by omega)
    have hpR0 : (0 : ℝ) < (p : ℝ) := by positivity
    apply sub_pos.mpr
    exact (div_lt_one hpR0).mpr hpR
  unfold printedLocal
  exact div_pos hnum (pow_pos hbase _)

/-- The exceptional active prime 2 is positive precisely when the
endpoint gap is even, as in the frozen manuscript's admissible regime. -/
theorem printed_pair_local_positive_two (h : ℕ) (heven : 2 ∣ h) :
    0 < printedLocal 2 ({0,h} : Finset ℕ) := by
  have hm : h % 2 = 0 := Nat.mod_eq_zero_of_dvd heven
  have hc : (occupiedResidues 2 ({0,h} : Finset ℕ)).card = 1 := by
    simp [occupiedResidues, hm]
  unfold printedLocal
  rw [hc]
  norm_num

/-- Summability of deviations from 1 for the independently printed pair. -/
theorem printed_pair_summable_deviation (q h : ℕ) (hh : 0 < h) :
    Summable (fun p : ℕ =>
      ‖(if Nat.Prime p ∧ ¬ p ∣ q then
        printedLocal p ({0,h} : Finset ℕ) else 1) - 1‖) := by
  apply (summable_norm_normalizationBaseline_sub_one q 0).congr_atTop
  filter_upwards [Filter.eventually_ge_atTop (max 5 (h + 1))] with p hp
  have hp5 : 5 ≤ p := (le_max_left _ _).trans hp
  have hnd : ¬ p ∣ h := by
    intro hd
    have hple : p ≤ h := Nat.le_of_dvd hh hd
    omega
  rw [← printedLocal_pair_eq_baseline q h p hh hp5 hnd]

/-- Under the fixed-q admissible parity condition, all active printed
endpoint Euler factors are nonzero, including the exceptional prime 2. -/
theorem printed_pair_factor_ne_zero (q h p : ℕ)
    (hh : 0 < h) (hparity : 2 ∣ q ∨ 2 ∣ h) :
    (if Nat.Prime p ∧ ¬ p ∣ q then
      printedLocal p ({0,h} : Finset ℕ) else 1) ≠ 0 := by
  by_cases hp : Nat.Prime p ∧ ¬ p ∣ q
  · rw [if_pos hp]
    by_cases hp2 : p = 2
    · subst p
      have heven : 2 ∣ h := by
        rcases hparity with hq | hh
        · exact False.elim (hp.2 hq)
        · exact hh
      exact ne_of_gt (printed_pair_local_positive_two h heven)
    · have hp3 : 3 ≤ p := by
        have hpge : 2 ≤ p := hp.1.two_le
        omega
      exact ne_of_gt (printed_pair_local_positive_high p h hp3 hh)
  · simp [hp]

/-- The literal printed pair singular series has a nonzero Euler product,
not merely a convergent one. -/
theorem printed_pair_tprod_ne_zero (q h : ℕ)
    (hh : 0 < h) (hparity : 2 ∣ q ∨ 2 ∣ h) :
    (∏' p : ℕ, if Nat.Prime p ∧ ¬ p ∣ q then
      printedLocal p ({0,h} : Finset ℕ) else 1) ≠ 0 := by
  have hs := printed_pair_summable_deviation q h hh
  have hn := printed_pair_factor_ne_zero q h
  have ht : (∏' p : ℕ,
      (1 + ((if Nat.Prime p ∧ ¬ p ∣ q then
        printedLocal p ({0,h} : Finset ℕ) else 1) - 1))) ≠ 0 := by
    apply tprod_one_add_ne_zero_of_summable
    · intro p
      convert hn p hh hparity using 1 <;> ring
    · exact hs
  convert ht using 1 <;> congr 1 <;> funext p <;> ring

/-- A reusable ring-level normalization identity. -/
private theorem normalized_triple_factor
    (A B t : ℝ) (ht : t ≠ 0) (hB : B ≠ 0) :
    A / t ^ 3 = (B / t ^ 2) * ((A / B) / t) := by
  field_simp [ht, hB]

/-- All nonexceptional triple factors agree with the pair factor times
the native occupied anchored local ratio. The missing low primes are finite. -/
theorem printed_triple_local_quotient (p h y : ℕ)
    (hy0 : 0 < y) (hyh : y < h) (hp : 5 ≤ p) :
    printedLocal p ({0,y,h} : Finset ℕ) =
      printedLocal p ({0,h} : Finset ℕ) *
        occupiedAnchoredLocalFactorRatio p h y := by
  have hp0 : (p : ℝ) ≠ 0 := by exact_mod_cast (show p ≠ 0 by omega)
  have hp1 : (1 : ℝ) - 1 / (p : ℝ) ≠ 0 := by
    have : (1 : ℝ) < (p : ℝ) := by exact_mod_cast (show 1 < p by omega)
    exact ne_of_gt (sub_pos.mpr ((div_lt_one (by positivity)).mpr this))
  have hpair : ({0,h} : Finset ℕ).card = 2 :=
    card_pair_zero_of_ne_zero (Nat.ne_of_gt (by omega))
  have htriple : ({0,y,h} : Finset ℕ).card = 3 := by
    have h01 : (0 : ℕ) ≠ y := Nat.ne_of_lt hy0
    have h0h : (0 : ℕ) ≠ h := Nat.ne_of_lt (by omega)
    have hyh' : y ≠ h := Nat.ne_of_lt hyh
    simp [h01, h0h, hyh']
  have hden : (1 : ℝ) -
      (occupiedResidues p ({0,h} : Finset ℕ)).card / (p : ℝ) ≠ 0 := by
    have hc : (occupiedResidues p ({0,h} : Finset ℕ)).card ≤ 2 := by
      unfold occupiedResidues
      exact le_trans Finset.card_image_le (by simpa [hpair])
    have hr : ((occupiedResidues p ({0,h} : Finset ℕ)).card : ℝ) ≤ 2 := by
      exact_mod_cast hc
    have hpr : (2 : ℝ) < (p : ℝ) := by exact_mod_cast (show 2 < p by omega)
    exact ne_of_gt (sub_pos.mpr ((div_lt_one (by positivity)).mpr (by linarith)))
  unfold printedLocal occupiedAnchoredLocalFactorRatio
  rw [hpair, htriple, ← occupied_pair_card, ← occupied_triple_card]
  exact normalized_triple_factor _ _ _ hp1 hden

/-- For every high prime, the printed triple factor factors through the
independent printed endpoint factor and the production occupied ratio.
The excluded-prime case is also exact. -/
theorem printed_triple_active_factor_eq (q h y p : ℕ)
    (hy0 : 0 < y) (hyh : y < h) (hp5 : 5 ≤ p) :
    (if Nat.Prime p ∧ ¬ p ∣ q then
      printedLocal p ({0,y,h} : Finset ℕ) else 1) =
    (if Nat.Prime p ∧ ¬ p ∣ q then
      printedLocal p ({0,h} : Finset ℕ) else 1) *
      occupiedActiveHighLocalRatio q h y p := by
  by_cases ha : Nat.Prime p ∧ ¬ p ∣ q
  · have hactive : activeHighPrime q p := ⟨ha.1, hp5, ha.2⟩
    rw [if_pos ha, if_pos ha]
    simp only [occupiedActiveHighLocalRatio, if_pos hactive]
    exact printed_triple_local_quotient p h y hy0 hyh hp5
  · have hna : ¬ activeHighPrime q p := by
      intro hh
      exact ha ⟨hh.1, hh.2.2⟩
    simp [ha, occupiedActiveHighLocalRatio, hna]

#print axioms printed_triple_active_factor_eq

#print axioms printed_triple_local_quotient
#print axioms printed_pair_summable_deviation
#print axioms printed_pair_factor_ne_zero
#print axioms printed_pair_tprod_ne_zero
#print axioms printed_pair_local_positive_two
#print axioms printed_pair_local_positive_high
#print axioms printedLocal_pair_eq_free
#print axioms printedLocal_pair_eq_baseline
#print axioms printed_pair_multipliable
#print axioms printed_pair_singularSeries_multipliable
/-- The existing local-ratio selector factorization supplies convergence of
the actual high-prime occupied ratios, with no top-level printed identity assumed. -/
theorem occupied_high_ratio_multipliable
    (q h y : ℕ) (hy0 : 0 < y) (hyh : y < h) :
    Multipliable (fun p : ℕ => occupiedActiveHighLocalRatio q h y p) := by
  have hb := multipliable_activeHighBaseline q h
  have hs := multipliable_activeHighSelectorFactor q h y hy0 hyh
  have hm := hb.mul hs
  apply hm.congr
  intro p
  rw [occupiedActiveHighLocalRatio_eq (Nat.le_of_lt hyh)]
  exact (activeHighLocalRatio_factorization q h y p (Nat.le_of_lt hyh)).symm

#print axioms occupied_high_ratio_multipliable

/-- A finite exceptional-prime correction: only the factors below 5 occur. -/
noncomputable def printedSmallCorrection (q h y p : ℕ) : ℝ :=
  if p < 5 then
    (if Nat.Prime p ∧ ¬ p ∣ q then
      printedLocal p ({0,y,h} : Finset ℕ) else 1) /
    (if Nat.Prime p ∧ ¬ p ∣ q then
      printedLocal p ({0,h} : Finset ℕ) else 1)
  else 1

theorem printedSmallCorrection_multipliable (q h y : ℕ) :
    Multipliable (printedSmallCorrection q h y) := by
  apply multipliable_of_hasFiniteMulSupport
  apply (Set.finite_Iio 5).subset
  intro p hp
  change printedSmallCorrection q h y p ≠ 1 at hp
  by_contra h
  have h5 : 5 ≤ p := Nat.le_of_not_gt h
  exact hp (by simp [printedSmallCorrection, Nat.not_lt.mpr h5])

/-- A direct factorization of the whole independently printed triple
Euler integrand, including p=2 and p=3. -/
theorem printed_triple_factor_eq_full (q h y p : ℕ)
    (hh : 0 < h) (hy0 : 0 < y) (hyh : y < h)
    (hparity : 2 ∣ q ∨ 2 ∣ h) :
    (if Nat.Prime p ∧ ¬ p ∣ q then
      printedLocal p ({0,y,h} : Finset ℕ) else 1) =
    ((if Nat.Prime p ∧ ¬ p ∣ q then
      printedLocal p ({0,h} : Finset ℕ) else 1) *
        occupiedActiveHighLocalRatio q h y p) *
          printedSmallCorrection q h y p := by
  by_cases hp : p < 5
  · have hna : ¬ activeHighPrime q p := by
      intro ha
      exact (Nat.not_le.mpr hp) ha.2.1
    have hden := printed_pair_factor_ne_zero q h p hh hparity
    simp only [printedSmallCorrection, if_pos hp,
      occupiedActiveHighLocalRatio, if_neg hna, mul_one]
    exact (mul_div_cancel₀ _ hden).symm
  · have hp5 : 5 ≤ p := Nat.le_of_not_gt hp
    rw [printed_triple_active_factor_eq q h y p hy0 hyh hp5]
    simp [printedSmallCorrection, hp]

theorem printed_triple_multipliable (q h y : ℕ)
    (hh : 0 < h) (hy0 : 0 < y) (hyh : y < h)
    (hparity : 2 ∣ q ∨ 2 ∣ h) :
    Multipliable (fun p : ℕ =>
      if Nat.Prime p ∧ ¬ p ∣ q then
        printedLocal p ({0,y,h} : Finset ℕ) else 1) := by
  have hp := printed_pair_multipliable q h hh
  have hr := occupied_high_ratio_multipliable q h y hy0 hyh
  have hs := printedSmallCorrection_multipliable q h y
  apply (hp.mul hr |>.mul hs).congr
  intro p
  exact (printed_triple_factor_eq_full q h y p hh hy0 hyh hparity).symm

#print axioms printedSmallCorrection_multipliable
#print axioms printed_triple_factor_eq_full
#print axioms printed_triple_multipliable

/-- Fully discharged infinite-product quotient of the independently
printed triple and endpoint singular series. -/
theorem printed_triple_endpoint_quotient (q h y : ℕ)
    (hh : 0 < h) (hy0 : 0 < y) (hyh : y < h)
    (hparity : 2 ∣ q ∨ 2 ∣ h) :
    printedRestrictedSingularSeries q ({0,y,h} : Finset ℕ) /
      printedRestrictedSingularSeries q ({0,h} : Finset ℕ) =
    ∏' p : ℕ,
      (if Nat.Prime p ∧ ¬ p ∣ q then
        printedLocal p ({0,y,h} : Finset ℕ) else 1) /
      (if Nat.Prime p ∧ ¬ p ∣ q then
        printedLocal p ({0,h} : Finset ℕ) else 1) := by
  unfold printedRestrictedSingularSeries
  exact (Multipliable.tprod_div₀
      (printed_triple_multipliable q h y hh hy0 hyh hparity)
      (printed_pair_multipliable q h hh)
      (printed_pair_tprod_ne_zero q h hh hparity)).symm

#print axioms printed_triple_endpoint_quotient


/-- The printed triple/pair quotient agrees with the independent occupied
ratio at EVERY active prime, including the exceptional primes 2 and 3. -/
theorem printed_active_local_quotient_eq_occupied
    (q h y p : ℕ) (hh : 0 < h) (hy0 : 0 < y) (hyh : y < h)
    (hparity : 2 ∣ q ∨ 2 ∣ h) :
    (if Nat.Prime p ∧ ¬ p ∣ q then
      printedLocal p ({0,y,h} : Finset ℕ) else 1) /
    (if Nat.Prime p ∧ ¬ p ∣ q then
      printedLocal p ({0,h} : Finset ℕ) else 1) =
    if Nat.Prime p ∧ ¬ p ∣ q then
      occupiedAnchoredLocalFactorRatio p h y else 1 := by
  by_cases ha : Nat.Prime p ∧ ¬ p ∣ q
  · simp only [if_pos ha]
    have hp2 : 2 ≤ p := ha.1.two_le
    have hpair : ({0,h} : Finset ℕ).card = 2 :=
      card_pair_zero_of_ne_zero (Nat.ne_of_gt hh)
    have htriple : ({0,y,h} : Finset ℕ).card = 3 := by
      have h01 : (0 : ℕ) ≠ y := Nat.ne_of_lt hy0
      have h0h : (0 : ℕ) ≠ h := Nat.ne_of_lt hh
      have hyh' : y ≠ h := Nat.ne_of_lt hyh
      simp [h01, h0h, hyh']
    have hp0 : (p : ℝ) ≠ 0 := by
      exact_mod_cast (show p ≠ 0 by omega)
    have hp1 : (1 : ℝ) - 1 / (p : ℝ) ≠ 0 := by
      have hpR : (1 : ℝ) < (p : ℝ) := by exact_mod_cast hp2
      exact ne_of_gt (sub_pos.mpr ((div_lt_one (by positivity)).mpr hpR))
    have hden : (1 : ℝ) -
        (occupiedResidues p ({0,h} : Finset ℕ)).card / (p : ℝ) ≠ 0 := by
      by_cases hp3 : 3 ≤ p
      · have hc : (occupiedResidues p ({0,h} : Finset ℕ)).card ≤ 2 := by
          unfold occupiedResidues
          exact le_trans Finset.card_image_le (by simpa [hpair])
        have hr : ((occupiedResidues p ({0,h} : Finset ℕ)).card : ℝ) ≤ 2 := by
          exact_mod_cast hc
        have hpr : (2 : ℝ) < (p : ℝ) := by exact_mod_cast hp3
        exact ne_of_gt (sub_pos.mpr ((div_lt_one (by positivity)).mpr (by linarith)))
      · have hp : p = 2 := by omega
        subst p
        have heven : 2 ∣ h := by
          rcases hparity with hq | hh'
          · exact False.elim (ha.2 hq)
          · exact hh'
        have hc : (occupiedResidues 2 ({0,h} : Finset ℕ)).card = 1 := by
          simp [occupiedResidues, Nat.mod_eq_zero_of_dvd heven]
        rw [hc]
        norm_num
    unfold printedLocal occupiedAnchoredLocalFactorRatio
    rw [hpair, htriple, occupied_pair_card, occupied_triple_card]
    field_simp [hp1, hden]
  · simp [ha]

#print axioms printed_active_local_quotient_eq_occupied



/-- Only the literal exceptional active factors 2 and 3 remain here. -/
noncomputable def printedOccupiedLowRatio (q h y p : ℕ) : ℝ :=
  if p ∈ lowPrimeSet then
    if p ∣ q then 1 else occupiedAnchoredLocalFactorRatio p h y
  else 1

theorem printed_occupied_factor_split (q h y p : ℕ) :
    (if Nat.Prime p ∧ ¬ p ∣ q then
      occupiedAnchoredLocalFactorRatio p h y else 1) =
    printedOccupiedLowRatio q h y p * occupiedActiveHighLocalRatio q h y p := by
  by_cases hp5 : 5 ≤ p
  · have hnlow : p ∉ lowPrimeSet := by
      simp [lowPrimeSet]
      omega
    by_cases ha : Nat.Prime p ∧ ¬ p ∣ q
    · have hactive : activeHighPrime q p := ⟨ha.1, hp5, ha.2⟩
      simp [printedOccupiedLowRatio, hnlow, occupiedActiveHighLocalRatio, hactive, ha]
    · have hna : ¬ activeHighPrime q p := by
        intro hx
        exact ha ⟨hx.1, hx.2.2⟩
      simp [printedOccupiedLowRatio, hnlow, occupiedActiveHighLocalRatio, hna, ha]
  · have hp : p < 5 := by omega
    interval_cases p <;>
      simp [printedOccupiedLowRatio, lowPrimeSet, occupiedActiveHighLocalRatio,
        activeHighPrime, show ¬ Nat.Prime 0 from by decide,
        show ¬ Nat.Prime 1 from by decide,
        show Nat.Prime 2 from by decide,
        show Nat.Prime 3 from by decide,
        show ¬ Nat.Prime 4 from by decide] <;>
      (by_cases hq2 : 2 ∣ q <;> by_cases hq3 : 3 ∣ q <;> simp_all [Nat.dvd_iff_mod_eq_zero])

#print axioms printed_occupied_factor_split



/-- The literal quotient becomes precisely the low occupied Euler factor
and the already-native high occupied-ratio Euler product. -/
theorem printed_quotient_eq_occupied_euler (q h y : ℕ)
    (hh : 0 < h) (hy0 : 0 < y) (hyh : y < h)
    (hparity : 2 ∣ q ∨ 2 ∣ h) :
    printedRestrictedSingularSeries q ({0,y,h} : Finset ℕ) /
      printedRestrictedSingularSeries q ({0,h} : Finset ℕ) =
    (∏ p ∈ lowPrimeSet,
      if p ∣ q then 1 else occupiedAnchoredLocalFactorRatio p h y) *
      (∏' p : ℕ, occupiedActiveHighLocalRatio q h y p) := by
  rw [printed_triple_endpoint_quotient q h y hh hy0 hyh hparity]
  have hlow : Multipliable (printedOccupiedLowRatio q h y) := by
    apply multipliable_of_hasFiniteMulSupport
    apply (Set.finite_Iio 5).subset
    intro p hp
    change printedOccupiedLowRatio q h y p ≠ 1 at hp
    by_contra h
    have h5 : 5 ≤ p := Nat.le_of_not_gt h
    apply hp
    simp [printedOccupiedLowRatio, lowPrimeSet]
    omega
  have hhigh := occupied_high_ratio_multipliable q h y hy0 hyh
  have hprod : (∏' p : ℕ, printedOccupiedLowRatio q h y p) =
      ∏ p ∈ lowPrimeSet,
        if p ∣ q then 1 else occupiedAnchoredLocalFactorRatio p h y := by
    rw [tprod_eq_prod (s := lowPrimeSet) (fun p hp => by
      simp [printedOccupiedLowRatio, hp])]
    apply Finset.prod_congr rfl
    intro p hp
    simp [printedOccupiedLowRatio, hp]
  calc
    (∏' p : ℕ,
      (if Nat.Prime p ∧ ¬ p ∣ q then
        printedLocal p ({0,y,h} : Finset ℕ) else 1) /
      (if Nat.Prime p ∧ ¬ p ∣ q then
        printedLocal p ({0,h} : Finset ℕ) else 1)) =
      ∏' p : ℕ, (if Nat.Prime p ∧ ¬ p ∣ q then
        occupiedAnchoredLocalFactorRatio p h y else 1) := by
          apply tprod_congr
          intro p
          exact printed_active_local_quotient_eq_occupied q h y p hh hy0 hyh hparity
    _ = ∏' p : ℕ,
        printedOccupiedLowRatio q h y p * occupiedActiveHighLocalRatio q h y p := by
          apply tprod_congr
          intro p
          exact printed_occupied_factor_split q h y p
    _ = (∏ p ∈ lowPrimeSet,
          if p ∣ q then 1 else occupiedAnchoredLocalFactorRatio p h y) *
        (∏' p : ℕ, occupiedActiveHighLocalRatio q h y p) := by
          rw [hlow.tprod_mul hhigh, hprod]

#print axioms printed_quotient_eq_occupied_euler



/-- The independently printed Euler expression, summed with the exact
admissible interior count rather than an asymptotic density. -/
noncomputable def printedA1Weighted (q a h : ℕ) : ℝ :=
  (∑ y ∈ Finset.Ioo 0 h,
    (if q.Coprime (a + y) then (1 : ℝ) else 0) *
      (printedRestrictedSingularSeries q ({0,y,h} : Finset ℕ) /
        printedRestrictedSingularSeries q ({0,h} : Finset ℕ))) -
    (admissibleInteriorCount q a h : ℝ)

/-- Top-level independent printed A Euler-product bridge into the
manuscript's actual occupied-ratio kernel. -/
theorem printedA1Weighted_eq_manuscriptA1Kernel (q a h : ℕ)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    printedA1Weighted q a h = manuscriptA1Kernel q a h := by
  have hparity : 2 ∣ q ∨ 2 ∣ h := by
    by_cases hq : 2 ∣ q
    · exact Or.inl hq
    · exact Or.inr (h2admissible hq)
  unfold printedA1Weighted manuscriptA1Kernel
  apply congrArg (fun z : ℝ => z - (admissibleInteriorCount q a h : ℝ))
  apply Finset.sum_congr rfl
  intro y hy
  have hyI := Finset.mem_Ioo.mp hy
  have hh : 0 < h := by omega
  rw [printed_quotient_eq_occupied_euler q h y hh hyI.1 hyI.2 hparity]
  unfold manuscriptAnchoredSummand occupiedFixedQLowWeight
  ring

#print axioms printedA1Weighted_eq_manuscriptA1Kernel



/-- Translation by a gives the exact manuscript admissible-interior count. -/
theorem printed_admissible_count_eq (q a h : ℕ) :
    admissibleInteriorCount q a h =
      ((Finset.Ioo 0 h).filter (fun y => q.Coprime (a + y))).card := by
  unfold admissibleInteriorCount
  have hset :
      (Finset.Ioo a (a+h)).filter (fun x => q.Coprime x) =
        ((Finset.Ioo 0 h).filter (fun y => q.Coprime (a+y))).image
          (fun y => a+y) := by
    ext x
    constructor
    · intro hx
      have hx' := Finset.mem_filter.mp hx
      have hinterval := Finset.mem_Ioo.mp hx'.1
      have hxa : a + (x - a) = x := by omega
      apply Finset.mem_image.mpr
      refine ⟨x-a, ?_, hxa⟩
      apply Finset.mem_filter.mpr
      refine ⟨Finset.mem_Ioo.mpr ?_, ?_⟩
      · omega
      · simpa [hxa] using hx'.2
    · intro hx
      obtain ⟨y, hy, hxy⟩ := Finset.mem_image.mp hx
      have hy' := Finset.mem_filter.mp hy
      have hinterval := Finset.mem_Ioo.mp hy'.1
      subst x
      apply Finset.mem_filter.mpr
      refine ⟨Finset.mem_Ioo.mpr ?_, hy'.2⟩
      omega
  rw [hset]
  apply Finset.card_image_of_injOn
  intro x hx y hy hxy
  exact Nat.add_left_cancel hxy

/-- Exactly the manuscript's printed A_1,q finite sum, with the independently
defined printed singular series and the genuine admissible index predicate. -/
noncomputable def printedA1Literal (q a h : ℕ) : ℝ :=
  ∑ y ∈ Finset.Ioo 0 h,
    if q.Coprime (a+y) then
      printedRestrictedSingularSeries q ({0,y,h} : Finset ℕ) /
        printedRestrictedSingularSeries q ({0,h} : Finset ℕ) - 1
    else 0

theorem printedA1Literal_eq_weighted (q a h : ℕ) :
    printedA1Literal q a h = printedA1Weighted q a h := by
  have hc : (admissibleInteriorCount q a h : ℝ) =
      ∑ y ∈ Finset.Ioo 0 h,
        if q.Coprime (a+y) then (1 : ℝ) else 0 := by
    rw [printed_admissible_count_eq]
    exact (Finset.sum_boole (fun y => q.Coprime (a+y)) (Finset.Ioo 0 h)).symm
  unfold printedA1Literal
  calc
    (∑ y ∈ Finset.Ioo 0 h,
      if q.Coprime (a+y) then
        printedRestrictedSingularSeries q ({0,y,h} : Finset ℕ) /
          printedRestrictedSingularSeries q ({0,h} : Finset ℕ) - 1 else 0) =
      ∑ y ∈ Finset.Ioo 0 h,
        ((if q.Coprime (a+y) then (1 : ℝ) else 0) *
          (printedRestrictedSingularSeries q ({0,y,h} : Finset ℕ) /
            printedRestrictedSingularSeries q ({0,h} : Finset ℕ)) -
        (if q.Coprime (a+y) then (1 : ℝ) else 0)) := by
          apply Finset.sum_congr rfl
          intro y hy
          split_ifs <;> ring
    _ = (∑ y ∈ Finset.Ioo 0 h,
          (if q.Coprime (a+y) then (1 : ℝ) else 0) *
          (printedRestrictedSingularSeries q ({0,y,h} : Finset ℕ) /
           printedRestrictedSingularSeries q ({0,h} : Finset ℕ))) -
        (∑ y ∈ Finset.Ioo 0 h,
          if q.Coprime (a+y) then (1 : ℝ) else 0) := by
          rw [Finset.sum_sub_distrib]
    _ = printedA1Weighted q a h := by
      rw [← hc]
      rfl

theorem printedA1Literal_eq_manuscriptA1Kernel (q a h : ℕ)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    printedA1Literal q a h = manuscriptA1Kernel q a h := by
  rw [printedA1Literal_eq_weighted]
  exact printedA1Weighted_eq_manuscriptA1Kernel q a h h2admissible

#print axioms printed_admissible_count_eq
#print axioms printedA1Literal_eq_manuscriptA1Kernel



/-- The B-side high-prime squarefree-divisor selector is deliberately
separate from the independently printed two-point Euler local factor. -/
noncomputable def printedFreeHighSelector (q y p : ℕ) : ℝ :=
  if activeHighPrime q p ∧ p ∣ y then 1 + 1 / ((p : ℝ) - 2) else 1

/-- Literal printed pair local factor equals the native baseline multiplied
by its elementary divisor selector, for ALL p≥5 including excluded primes. -/
theorem printed_pair_high_eq_baseline_selector (q y p : ℕ)
    (hy : 0 < y) (hp5 : 5 ≤ p) :
    (if Nat.Prime p ∧ ¬ p ∣ q then
      printedLocal p ({0,y} : Finset ℕ) else 1) =
    normalizationBaseline q 0 p * printedFreeHighSelector q y p := by
  by_cases ha : Nat.Prime p ∧ ¬ p ∣ q
  · have hactive : activeHighPrime q p := ⟨ha.1, hp5, ha.2⟩
    by_cases hpy : p ∣ y
    · have hc : endpointOccupiedCount p y = 1 := by
        simp [endpointOccupiedCount, Nat.mod_eq_zero_of_dvd hpy]
      have hp0 : (p : ℝ) ≠ 0 := by
        exact_mod_cast (show p ≠ 0 by omega)
      have hp1 : (p : ℝ) - 1 ≠ 0 := by
        exact sub_ne_zero.mpr (by exact_mod_cast (show p ≠ 1 by omega))
      have hp2 : (p : ℝ) - 2 ≠ 0 := by
        exact sub_ne_zero.mpr (by exact_mod_cast (show p ≠ 2 by omega))
      rw [if_pos ha, printedLocal_pair_eq_free p y hy]
      simp only [freeLocalFactorRatio, hc]
      simp [normalizationBaseline, printedFreeHighSelector, ha, hp5,
        hactive, hpy, dvd_zero, hp0]
      field_simp [hp0, hp1, hp2]
      ring
    · have hna : ¬ (activeHighPrime q p ∧ p ∣ y) := by
        intro hx
        exact hpy hx.2
      simp only [printedFreeHighSelector, if_neg hna, mul_one]
      exact printedLocal_pair_eq_baseline q y p hy hp5 hpy
  · have hna : ¬ activeHighPrime q p := by
      intro hx
      exact ha ⟨hx.1, hx.2.2⟩
    have hbase : ¬ (Nat.Prime p ∧ 5 ≤ p ∧ ¬ p ∣ q) := by
      intro hx
      exact ha ⟨hx.1, hx.2.2⟩
    simp [ha, normalizationBaseline, hbase, printedFreeHighSelector, hna]

#print axioms printed_pair_high_eq_baseline_selector



/-- For fixed positive y, only finitely many active primes dividing y can
have a nontrivial B-side selector. -/
theorem printedFreeHighSelector_multipliable (q y : ℕ) (hy : 0 < y) :
    Multipliable (printedFreeHighSelector q y) := by
  apply multipliable_of_hasFiniteMulSupport
  apply (Set.finite_Iic y).subset
  intro p hp
  change printedFreeHighSelector q y p ≠ 1 at hp
  by_contra hle
  have hnd : ¬ p ∣ y := by
    intro hd
    exact hle (Nat.le_of_dvd hy hd)
  exact hp (by simp [printedFreeHighSelector, hnd])

#print axioms printedFreeHighSelector_multipliable


/-- Explicit low p=2,3 factor for a printed two-point singular series. -/
noncomputable def printedFreeLowLocal (q y p : ℕ) : ℝ :=
  if p ∈ lowPrimeSet then
    if p ∣ q then 1 else freeLocalFactorRatio p y
  else 1

theorem printed_pair_factor_split (q y p : ℕ) (hy : 0 < y) :
    (if Nat.Prime p ∧ ¬ p ∣ q then
      printedLocal p ({0,y} : Finset ℕ) else 1) =
      (printedFreeLowLocal q y p * normalizationBaseline q 0 p) *
        printedFreeHighSelector q y p := by
  by_cases hp5 : 5 ≤ p
  · rw [printed_pair_high_eq_baseline_selector q y p hy hp5]
    have hlow : p ∉ lowPrimeSet := by
      simp [lowPrimeSet]
      omega
    simp [printedFreeLowLocal, hlow]
  · have hp : p < 5 := by omega
    interval_cases p
    · simp [printedFreeLowLocal, lowPrimeSet, normalizationBaseline,
        printedFreeHighSelector, activeHighPrime, show ¬ Nat.Prime 0 from by decide]
    · simp [printedFreeLowLocal, lowPrimeSet, normalizationBaseline,
        printedFreeHighSelector, activeHighPrime, show ¬ Nat.Prime 1 from by decide]
    · by_cases hq : 2 ∣ q
      · simp [printedFreeLowLocal, lowPrimeSet, normalizationBaseline,
          printedFreeHighSelector, activeHighPrime, hq]
      · simp [printedFreeLowLocal, lowPrimeSet, normalizationBaseline,
          printedFreeHighSelector, activeHighPrime, hq, show Nat.Prime 2 from by decide,
          printedLocal_pair_eq_free 2 y hy]
    · by_cases hq : 3 ∣ q
      · simp [printedFreeLowLocal, lowPrimeSet, normalizationBaseline,
          printedFreeHighSelector, activeHighPrime, hq]
      · simp [printedFreeLowLocal, lowPrimeSet, normalizationBaseline,
          printedFreeHighSelector, activeHighPrime, hq, show Nat.Prime 3 from by decide,
          printedLocal_pair_eq_free 3 y hy]
    · simp [printedFreeLowLocal, lowPrimeSet, normalizationBaseline,
        printedFreeHighSelector, activeHighPrime, show ¬ Nat.Prime 4 from by decide]

theorem printedFreeLowLocal_multipliable (q y : ℕ) :
    Multipliable (printedFreeLowLocal q y) := by
  apply multipliable_of_hasFiniteMulSupport
  apply (Set.finite_Iio 5).subset
  intro p hp
  change printedFreeLowLocal q y p ≠ 1 at hp
  by_contra hn
  have hp5 : 5 ≤ p := Nat.le_of_not_gt hn
  exact hp (by
    simp [printedFreeLowLocal, lowPrimeSet]
    omega)

theorem printedFreeLowLocal_tprod (q y : ℕ) :
    (∏' p : ℕ, printedFreeLowLocal q y p) = freeLowPrimeFactor q y := by
  rw [tprod_eq_prod (s := lowPrimeSet) (fun p hp => by
    simp [printedFreeLowLocal, hp])]
  unfold freeLowPrimeFactor
  apply Finset.prod_congr rfl
  intro p hp
  simp [printedFreeLowLocal, hp]

/-- Printed two-point restricted singular series splits into exact low
factor, native positive high baseline, and FINITELY SUPPORTED selector. -/
theorem printed_pair_tprod_factorization (q y : ℕ) (hy : 0 < y) :
    printedRestrictedSingularSeries q ({0,y} : Finset ℕ) =
      (freeLowPrimeFactor q y * freeHighBaseline q) *
        (∏' p : ℕ, printedFreeHighSelector q y p) := by
  unfold printedRestrictedSingularSeries
  have hl := printedFreeLowLocal_multipliable q y
  have hb := multipliable_normalizationBaseline' q 0
  have hs := printedFreeHighSelector_multipliable q y hy
  calc
    (∏' p : ℕ, if Nat.Prime p ∧ ¬ p ∣ q then
      printedLocal p ({0,y} : Finset ℕ) else 1) =
        (∏' p : ℕ,
          (printedFreeLowLocal q y p * normalizationBaseline q 0 p) *
            printedFreeHighSelector q y p) := by
            apply tprod_congr
            intro p
            exact printed_pair_factor_split q y p hy
    _ = ((∏' p : ℕ, printedFreeLowLocal q y p) *
           (∏' p : ℕ, normalizationBaseline q 0 p)) *
          (∏' p : ℕ, printedFreeHighSelector q y p) := by
            rw [(hl.mul hb).tprod_mul hs, hl.tprod_mul hb]
    _ = (freeLowPrimeFactor q y * freeHighBaseline q) *
          (∏' p : ℕ, printedFreeHighSelector q y p) := by
            rw [printedFreeLowLocal_tprod]
            rfl

#print axioms printed_pair_factor_split
#print axioms printed_pair_tprod_factorization


/-- Local B divisor coefficient: zero outside active high primes. -/
noncomputable def printedEtaPrime (q p : ℕ) : ℝ :=
  if activeHighPrime q p then 1 / ((p : ℝ) - 2) else 0

/-- Finite Boolean Euler expansion of the printed B selector. The
conversion from prime subsets to exact etaCoeff divisors is the next seam. -/
theorem printedFreeHighSelector_powerset (q y : ℕ) (hy : 0 < y) :
    (∏' p : ℕ, printedFreeHighSelector q y p) =
    ∑ s ∈ y.primeFactors.powerset,
       ∏ p ∈ s, printedEtaPrime q p := by
  have heq :
      (∏' p : ℕ, printedFreeHighSelector q y p) =
      ∏ p ∈ y.primeFactors, (1 + printedEtaPrime q p) := by
    rw [tprod_eq_prod (s := y.primeFactors) (fun p hp => by
      unfold printedFreeHighSelector
      by_cases ha : activeHighPrime q p
      · have hnd : ¬ p ∣ y := by
          intro hd
          exact hp (Nat.mem_primeFactors.mpr ⟨ha.1, hd, Nat.ne_of_gt hy⟩)
        simp [ha, hnd]
      · simp [ha])]
    apply Finset.prod_congr rfl
    intro p hp
    have hd : p ∣ y := Nat.dvd_of_mem_primeFactors hp
    by_cases ha : activeHighPrime q p <;>
      simp [printedFreeHighSelector, printedEtaPrime, ha, hd]
  rw [heq]
  exact Finset.prod_one_add y.primeFactors

#print axioms printedFreeHighSelector_powerset

end Merivelle.F01

namespace Elarienne.F01B
open PaperB.FixedQ

noncomputable def printedEtaPrime (q p : ℕ) : ℝ :=
  if activeHighPrime q p then 1 / ((p : ℝ) - 2) else 0

theorem activePrime_iff_coprime_sixq (q p : ℕ)
    (hp : Nat.Prime p) :
    activeHighPrime q p ↔ p.Coprime (6 * q) := by
  constructor
  · intro ha
    apply hp.coprime_iff_not_dvd.mpr
    intro hd
    rcases hp.dvd_mul.mp hd with h6 | hq
    · have hp6 : p ∣ 2 * 3 := by simpa using h6
      rcases hp.dvd_mul.mp hp6 with h2 | h3
      · have : p ≤ 2 := Nat.le_of_dvd (by norm_num) h2
        exact (by have hp5 := ha.2.1; omega)
      · have : p ≤ 3 := Nat.le_of_dvd (by norm_num) h3
        exact (by have hp5 := ha.2.1; omega)
    · exact ha.2.2 hq
  · intro hcop
    have hp5 : 5 ≤ p := eta_rankin_five_le_of_prime_coprime_six hp hcop
    have hpq : ¬ p ∣ q := by
      intro hd
      exact (hp.coprime_iff_not_dvd.mp hcop)
        (dvd_mul_of_dvd_right hd 6)
    exact ⟨hp, hp5, hpq⟩

theorem printedEtaPrime_eq_coprime (q p : ℕ)
    (hp : Nat.Prime p) :
    printedEtaPrime q p =
      if p.Coprime (6 * q) then 1 / ((p : ℝ)-2) else 0 := by
  unfold printedEtaPrime
  by_cases ha : activeHighPrime q p
  · have hc := (activePrime_iff_coprime_sixq q p hp).mp ha
    simp [ha, hc]
  · have hnc : ¬ p.Coprime (6*q) :=
      fun hc => ha ((activePrime_iff_coprime_sixq q p hp).mpr hc)
    simp [ha, hnc]

theorem printedEtaCoeff_primeSubsetProduct (q : ℕ)
    (s : Finset ℕ) (hs : ∀ p ∈ s, Nat.Prime p) :
    etaCoeff q (primeSubsetProduct s) =
      ∏ p ∈ s, printedEtaPrime q p := by
  have hs0 : primeSubsetProduct s ≠ 0 := by
    unfold primeSubsetProduct
    exact Finset.prod_ne_zero_iff.mpr
      (fun p hp => (hs p hp).ne_zero)
  have hsSq : Squarefree (primeSubsetProduct s) := by
    unfold primeSubsetProduct
    apply Finset.squarefree_prod_of_pairwise_isCoprime
    · intro p hp r hr hne
      apply Nat.coprime_iff_isRelPrime.mp
      apply (hs p hp).coprime_iff_not_dvd.mpr
      intro hd
      have heq : r = p :=
        ((hs r hr).dvd_iff_eq (hs p hp).ne_one).mp hd
      exact hne heq.symm
    · intro p hp
      exact (hs p hp).squarefree
  have hcop : (primeSubsetProduct s).Coprime (6 * q) ↔
      ∀ p ∈ s, p.Coprime (6 * q) := by
    rw [primeSubsetProduct_coprime_iff s hs (6*q)]
    constructor
    · intro h p hp
      exact (hs p hp).coprime_iff_not_dvd.mpr (h p hp)
    · intro h p hp
      exact (hs p hp).coprime_iff_not_dvd.mp (h p hp)
  have hprod :
      (∏ p ∈ s, printedEtaPrime q p) =
      if ∀ p ∈ s, p.Coprime (6 * q) then
        ∏ p ∈ s, 1 / ((p : ℝ) - 2) else 0 := by
    calc
      (∏ p ∈ s, printedEtaPrime q p) =
        ∏ p ∈ s, (if p.Coprime (6 * q) then 1 / ((p : ℝ)-2) else 0) := by
          apply Finset.prod_congr rfl
          intro p hp
          exact printedEtaPrime_eq_coprime q p (hs p hp)
      _ = _ := by rw [Finset.prod_ite_zero]
  rw [hprod]
  by_cases h : ∀ p ∈ s, p.Coprime (6*q)
  · have hc : (primeSubsetProduct s).Coprime (6*q) := hcop.mpr h
    unfold etaCoeff
    rw [if_neg hs0, if_pos ⟨hsSq,hc⟩]
    rw [primeSubsetProduct_primeFactors s hs]
    rw [if_pos h]
  · have hnc : ¬ (primeSubsetProduct s).Coprime (6*q) :=
      fun hc => h (hcop.mp hc)
    unfold etaCoeff
    rw [if_neg hs0, if_neg (by intro hc; exact hnc hc.2)]
    rw [if_neg h]

/-- Exact finite divisor identity: the squarefree eta terms are the
prime-subset Euler coefficients, with all higher prime powers zero. -/
theorem printed_eta_divisors_eq_powerset (q y : ℕ) (hy : 0 < y) :
    (∑ e ∈ y.divisors, etaCoeff q e) =
    ∑ s ∈ y.primeFactors.powerset,
      ∏ p ∈ s, printedEtaPrime q p := by
  have hfilter :
      (∑ e ∈ y.divisors, etaCoeff q e) =
      (∑ e ∈ y.divisors with Squarefree e, etaCoeff q e) := by
    symm
    apply Finset.sum_subset (Finset.filter_subset _ _)
    intro e he hn
    have hnsq : ¬ Squarefree e := by
      intro hs
      exact hn (Finset.mem_filter.mpr ⟨he, hs⟩)
    simp [etaCoeff, hnsq]
  calc
    (∑ e ∈ y.divisors, etaCoeff q e) =
        (∑ e ∈ y.divisors with Squarefree e, etaCoeff q e) := hfilter
    _ = ∑ s ∈ y.primeFactors.powerset,
          etaCoeff q (primeSubsetProduct s) := by
          rw [Nat.sum_divisors_filter_squarefree (Nat.ne_of_gt hy), Nat.factors_eq]
          have hpf : (y.primeFactorsList : Multiset ℕ).toFinset = y.primeFactors := by
            ext p
            simpa using (Nat.mem_primeFactors_iff_mem_primeFactorsList (n := y) (p := p)).symm
          rw [hpf]
          simp [primeSubsetProduct]
    _ = ∑ s ∈ y.primeFactors.powerset,
          ∏ p ∈ s, printedEtaPrime q p := by
          apply Finset.sum_congr rfl
          intro s hs
          have hprime : ∀ p ∈ s, Nat.Prime p := by
            intro p hp
            exact Nat.prime_of_mem_primeFactors ((Finset.mem_powerset.mp hs) hp)
          exact printedEtaCoeff_primeSubsetProduct q s hprime

#print axioms printed_eta_divisors_eq_powerset

#print axioms activePrime_iff_coprime_sixq
#print axioms printedEtaCoeff_primeSubsetProduct
end Elarienne.F01B



namespace Elarienne.F01B
open PaperB.FixedQ
open Merivelle.F01

theorem printedFreeHighSelector_divisors (q y : ℕ) (hy : 0 < y) :
    (∏' p : ℕ, printedFreeHighSelector q y p) =
      ∑ e ∈ y.divisors, etaCoeff q e := by
  rw [printedFreeHighSelector_powerset q y hy,
    printed_eta_divisors_eq_powerset q y hy]
  apply Finset.sum_congr rfl
  intro s hs
  apply Finset.prod_congr rfl
  intro p hp
  rfl

/-- Full literal B two-point Euler-product / finite divisor expansion. -/
theorem printed_pair_divisorExpansion (q y : ℕ) (hy : 0 < y) :
    printedRestrictedSingularSeries q ({0,y} : Finset ℕ) =
      (freeLowPrimeFactor q y * freeHighBaseline q) *
        (∑ e ∈ y.divisors, etaCoeff q e) := by
  rw [printed_pair_tprod_factorization q y hy,
    printedFreeHighSelector_divisors q y hy]

#print axioms printedFreeHighSelector_divisors
#print axioms printed_pair_divisorExpansion
end Elarienne.F01B

namespace Elarienne.F01B
open PaperB.FixedQ

noncomputable def etaReciprocalArithmeticF01 (q : ℕ) : ArithmeticFunction ℝ :=
  ⟨etaReciprocalTerm q, etaReciprocalTerm_zero q⟩

theorem etaReciprocalArithmeticF01_multiplicative (q : ℕ) :
    (etaReciprocalArithmeticF01 q).IsMultiplicative := by
  constructor
  · exact etaReciprocalTerm_one q
  · intro m n hcop
    exact etaReciprocalTerm_mul_of_coprime q hcop

theorem etaReciprocalArithmeticF01_norm_summable (q : ℕ) :
    Summable (fun n : ℕ => ‖etaReciprocalArithmeticF01 q n‖) := by
  have heq : (fun n : ℕ => ‖etaReciprocalArithmeticF01 q n‖) =
      etaReciprocalTerm q := by
    funext n
    change ‖etaReciprocalTerm q n‖ = etaReciprocalTerm q n
    rw [Real.norm_eq_abs, abs_of_nonneg (etaReciprocalTerm_nonneg q n)]
  rw [heq]
  exact summable_etaReciprocalTerm q

theorem baseline_inv_eq_etaLocal (q p : ℕ) :
    (normalizationBaseline q 0 p)⁻¹ = 1 + normalizationCorrection q 0 p := by
  have hb := normalizationBaseline_ne_zero q 0 p
  have hlocal := normalizationBaseline_mul_one_add_correction q 0 p
  calc
    (normalizationBaseline q 0 p)⁻¹ =
        (normalizationBaseline q 0 p)⁻¹ * 1 := by ring
    _ = (normalizationBaseline q 0 p)⁻¹ *
          (normalizationBaseline q 0 p * (1 + normalizationCorrection q 0 p)) := by
        rw [hlocal]
    _ = 1 + normalizationCorrection q 0 p := by
        rw [← mul_assoc, inv_mul_cancel₀ hb, one_mul]

theorem etaReciprocal_tsum_eq_inv_baseline (q : ℕ) :
    (∑' n : ℕ, etaReciprocalTerm q n) =
    (∏' p : ℕ, (normalizationBaseline q 0 p)⁻¹) := by
  have heuler :=
    (etaReciprocalArithmeticF01_multiplicative q).eulerProduct_tprod
      (etaReciprocalArithmeticF01_norm_summable q)
  have hprime : (∏' p : Nat.Primes,
      ∑' k : ℕ, etaReciprocalTerm q ((p : ℕ) ^ k)) =
      (∏' p : Nat.Primes, (normalizationBaseline q 0 (p : ℕ))⁻¹) := by
    apply tprod_congr
    intro p
    rw [tsum_etaReciprocalTerm_prime_pow q p.2]
    exact (baseline_inv_eq_etaLocal q p).symm
  have hsub :
      (∏' p : Nat.Primes, (normalizationBaseline q 0 (p : ℕ))⁻¹) =
      (∏' p : ℕ, (normalizationBaseline q 0 p)⁻¹) := by
    change (∏' p : {p : ℕ // Nat.Prime p},
      (normalizationBaseline q 0 (p : ℕ))⁻¹) =
      (∏' p : ℕ, (normalizationBaseline q 0 p)⁻¹)
    apply tprod_subtype_eq_of_mulSupport_subset
      (s := {p : ℕ | Nat.Prime p})
      (f := fun p : ℕ => (normalizationBaseline q 0 p)⁻¹)
    intro p hp
    by_contra hn
    change ¬ Nat.Prime p at hn
    have hbase : normalizationBaseline q 0 p = 1 := by
      simp [normalizationBaseline, hn]
    exact hp (by simp [hbase])
  calc
    (∑' n : ℕ, etaReciprocalTerm q n) =
        (∏' p : Nat.Primes, ∑' k : ℕ, etaReciprocalTerm q ((p : ℕ)^k)) := by
      simpa [etaReciprocalArithmeticF01] using heuler.symm
    _ = (∏' p : Nat.Primes, (normalizationBaseline q 0 (p : ℕ))⁻¹) := hprime
    _ = (∏' p : ℕ, (normalizationBaseline q 0 p)⁻¹) := hsub

/-- F-01 B: the exact free high-prime baseline normalizes the *actual*
eta_q(e)/e divisor coefficient system, independently of a logarithmic residue. -/
theorem printed_free_eta_normalization (q : ℕ) :
    freeHighBaseline q *
      (∑' e : ℕ, etaCoeff q e / (e : ℝ)) = 1 := by
  have hsum : (∑' e : ℕ, etaCoeff q e / (e : ℝ)) =
      (∑' e : ℕ, etaReciprocalTerm q e) := by
    apply tsum_congr
    intro e
    exact (etaReciprocalTerm_eq_etaCoeff_div q e).symm
  rw [hsum, etaReciprocal_tsum_eq_inv_baseline q]
  change (∏' p : ℕ, normalizationBaseline q 0 p) *
    (∏' p : ℕ, (normalizationBaseline q 0 p)⁻¹) = 1
  rw [(multipliable_normalizationBaseline' q 0).tprod_inv₀
    (tprod_normalizationBaseline_ne_zero q 0)]
  exact mul_inv_cancel₀ (tprod_normalizationBaseline_ne_zero q 0)

#print axioms etaReciprocalArithmeticF01_multiplicative
#print axioms etaReciprocalArithmeticF01_norm_summable
#print axioms etaReciprocal_tsum_eq_inv_baseline
#print axioms printed_free_eta_normalization

end Elarienne.F01B


namespace Elarienne.F01B
open PaperB.FixedQ

theorem eta_divisors_eq_bounded (q y h : ℕ)
    (hy0 : 0 < y) (hyh : y < h) :
    (∑ e ∈ y.divisors, etaCoeff q e) =
      ∑ e ∈ Finset.Ioo 0 h,
        if e ∣ y then etaCoeff q e else 0 := by
  have hfin : y.divisors =
      (Finset.Ioo 0 h).filter (fun e => e ∣ y) := by
    ext e
    rw [Nat.mem_divisors, Finset.mem_filter, Finset.mem_Ioo]
    constructor
    · rintro ⟨hd, hyne⟩
      have he0 : 0 < e := by
        by_contra hz
        have he : e = 0 := by omega
        subst e
        simp at hd
        omega
      have hey : e ≤ y := Nat.le_of_dvd hy0 hd
      exact ⟨⟨he0, by omega⟩, hd⟩
    · rintro ⟨⟨he0, heh⟩, hd⟩
      exact ⟨hd, Nat.ne_of_gt hy0⟩
  rw [hfin, Finset.sum_filter]

/-- An exact Fubini identity. For fixed h, only e<h contribute:
there is no infinite-interchange question on this numerator side. -/
theorem printed_free_weighted_divisor_swap (q r h : ℕ) :
    (∑ y ∈ Finset.Ioo 0 h,
      freeFixedQLowWeight q r y *
        (∑ e ∈ y.divisors, etaCoeff q e)) =
    ∑ e ∈ Finset.Ioo 0 h,
      etaCoeff q e * rowConstrainedMass (freeFixedQLowWeight q r) h e 1 := by
  have hinner :
      (∑ y ∈ Finset.Ioo 0 h,
        freeFixedQLowWeight q r y *
          (∑ e ∈ y.divisors, etaCoeff q e)) =
      (∑ y ∈ Finset.Ioo 0 h,
        freeFixedQLowWeight q r y *
          (∑ e ∈ Finset.Ioo 0 h,
            if e ∣ y then etaCoeff q e else 0)) := by
    apply Finset.sum_congr rfl
    intro y hy
    have hyI := Finset.mem_Ioo.mp hy
    rw [eta_divisors_eq_bounded q y h hyI.1 hyI.2]
  rw [hinner]
  simp_rw [Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro e he
  unfold rowConstrainedMass
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro y hy
  by_cases hd : e ∣ y
  · simp [hd, mul_comm]
  · simp [hd]

theorem printed_free_row_tsum_eq_finite (q r h : ℕ) :
    (∑' e : ℕ,
      etaCoeff q e * rowConstrainedMass (freeFixedQLowWeight q r) h e 1) =
    ∑ e ∈ Finset.Ioo 0 h,
      etaCoeff q e * rowConstrainedMass (freeFixedQLowWeight q r) h e 1 := by
  apply tsum_eq_sum (s := Finset.Ioo 0 h)
  intro e he
  by_cases he0 : e = 0
  · subst e
    simp
  · have hege : h ≤ e := by
      simp only [Finset.mem_Ioo] at he
      omega
    have hr : rowConstrainedMass (freeFixedQLowWeight q r) h e 1 = 0 := by
      unfold rowConstrainedMass
      apply Finset.sum_eq_zero
      intro y hy
      have hyI := Finset.mem_Ioo.mp hy
      have hn : ¬e ∣ y := by
        intro hd
        have hey : e ≤ y := Nat.le_of_dvd hyI.1 hd
        omega
      simp [hn]
    simp [hr]

#print axioms eta_divisors_eq_bounded
#print axioms printed_free_weighted_divisor_swap
#print axioms printed_free_row_tsum_eq_finite
end Elarienne.F01B


namespace Elarienne.F01B
open PaperB.FixedQ

theorem printed_free_row_term_zero_outside
    (q r h e : ℕ) (he : e ∉ Finset.Ioo 0 h) :
    etaCoeff q e * rowConstrainedMass (freeFixedQLowWeight q r) h e 1 = 0 := by
  by_cases he0 : e = 0
  · subst e
    simp
  · have hege : h ≤ e := by
      simp only [Finset.mem_Ioo] at he
      omega
    have hr : rowConstrainedMass (freeFixedQLowWeight q r) h e 1 = 0 := by
      unfold rowConstrainedMass
      apply Finset.sum_eq_zero
      intro y hy
      have hyI := Finset.mem_Ioo.mp hy
      have hn : ¬ e ∣ y := by
        intro hd
        have hey : e ≤ y := Nat.le_of_dvd hyI.1 hd
        omega
      simp [hn]
    simp [hr]

theorem summable_printed_free_row_term (q r h : ℕ) :
    Summable (fun e : ℕ =>
      etaCoeff q e * rowConstrainedMass (freeFixedQLowWeight q r) h e 1) := by
  exact summable_of_ne_finset_zero (s := Finset.Ioo 0 h)
    (fun e he => printed_free_row_term_zero_outside q r h e he)

theorem summable_etaCoeff_div (q : ℕ) :
    Summable (fun e : ℕ => etaCoeff q e / (e : ℝ)) := by
  have h := summable_etaReciprocalTerm q
  convert h using 1
  funext e
  exact (etaReciprocalTerm_eq_etaCoeff_div q e).symm

theorem printed_free_centered_sum (q r h : ℕ)
    (hnorm : freeHighBaseline q *
      (∑' e : ℕ, etaCoeff q e / (e : ℝ)) = 1) :
    freeHighBaseline q *
        (∑' e : ℕ,
          etaCoeff q e * rowConstrainedMass (freeFixedQLowWeight q r) h e 1)
      - (admissibleInteriorCount q r h : ℝ) =
    freeHighBaseline q *
      (∑' e : ℕ,
        etaCoeff q e *
          (rowConstrainedMass (freeFixedQLowWeight q r) h e 1 -
            (admissibleInteriorCount q r h : ℝ) / (e : ℝ))) := by
  let N : ℝ := (admissibleInteriorCount q r h : ℝ)
  let C : ℝ := freeHighBaseline q
  have hf := summable_printed_free_row_term q r h
  have hg := summable_etaCoeff_div q
  have hgN : Summable (fun e : ℕ =>
      etaCoeff q e * (N / (e : ℝ))) := by
    convert hg.mul_left N using 1
    funext e
    ring
  have hsplit :
      (∑' e : ℕ, etaCoeff q e *
        (rowConstrainedMass (freeFixedQLowWeight q r) h e 1 - N / (e : ℝ))) =
      (∑' e : ℕ,
        etaCoeff q e * rowConstrainedMass (freeFixedQLowWeight q r) h e 1) -
      (∑' e : ℕ, etaCoeff q e * (N / (e : ℝ))) := by
    rw [← hf.tsum_sub hgN]
    apply tsum_congr
    intro e
    ring
  have hgNsum :
      (∑' e : ℕ, etaCoeff q e * (N / (e : ℝ))) =
      N * (∑' e : ℕ, etaCoeff q e / (e : ℝ)) := by
    rw [← tsum_mul_left]
    apply tsum_congr
    intro e
    ring
  change C *
      (∑' e : ℕ, etaCoeff q e *
        rowConstrainedMass (freeFixedQLowWeight q r) h e 1) - N =
      C * (∑' e : ℕ, etaCoeff q e *
        (rowConstrainedMass (freeFixedQLowWeight q r) h e 1 - N / (e : ℝ)))
  rw [hsplit, hgNsum]
  have hn : C * (∑' e : ℕ, etaCoeff q e / (e : ℝ)) = 1 := hnorm
  calc
    C * (∑' e : ℕ,
      etaCoeff q e * rowConstrainedMass (freeFixedQLowWeight q r) h e 1) - N =
      C * (∑' e : ℕ,
        etaCoeff q e * rowConstrainedMass (freeFixedQLowWeight q r) h e 1) -
        (C * (∑' e : ℕ, etaCoeff q e / (e : ℝ))) * N := by
        rw [hn]
        ring
    _ = C * ((∑' e : ℕ,
      etaCoeff q e * rowConstrainedMass (freeFixedQLowWeight q r) h e 1) -
      N * (∑' e : ℕ, etaCoeff q e / (e : ℝ))) := by ring

#print axioms summable_printed_free_row_term
#print axioms summable_etaCoeff_div
#print axioms printed_free_centered_sum
end Elarienne.F01B



namespace Elarienne.F01B
open PaperB.FixedQ
open Merivelle.F01

/-- The independently printed first anchor contribution for the
frozen B_{1,q} expression. -/
noncomputable def printedS1Literal (q r h : ℕ) : ℝ :=
  ∑ y ∈ Finset.Ioo 0 h,
    if q.Coprime (r + y) then
      printedRestrictedSingularSeries q ({0,y} : Finset ℕ) - 1
    else 0

/-- Literal single-anchor B sum equals the exact centered η-divisor
kernel, with no approximation of the admissible interior count. -/
theorem printedS1Literal_eq_manuscriptS1Kernel (q r h : ℕ) :
    printedS1Literal q r h =
      PaperB.Closure.manuscriptS1Kernel q r h := by
  have hterm : ∀ y ∈ Finset.Ioo 0 h,
      (if q.Coprime (r+y) then
        printedRestrictedSingularSeries q ({0,y} : Finset ℕ) - 1
       else 0) =
      freeHighBaseline q *
        (freeFixedQLowWeight q r y *
          (∑ e ∈ y.divisors, etaCoeff q e)) -
        (if q.Coprime (r+y) then (1 : ℝ) else 0) := by
    intro y hy
    have hy0 := (Finset.mem_Ioo.mp hy).1
    by_cases hc : q.Coprime (r+y)
    · rw [if_pos hc, printed_pair_divisorExpansion q y hy0]
      rw [freeFixedQLowWeight_eq_indicator_mul_factor]
      simp only [if_pos hc, one_mul]
      ring
    · rw [if_neg hc]
      rw [freeFixedQLowWeight_eq_indicator_mul_factor]
      simp [hc]
  have hN : (∑ y ∈ Finset.Ioo 0 h,
      if q.Coprime (r+y) then (1 : ℝ) else 0) =
      (admissibleInteriorCount q r h : ℝ) := by
    rw [printed_admissible_count_eq]
    exact Finset.sum_boole (fun y => q.Coprime (r+y)) (Finset.Ioo 0 h)
  calc
    printedS1Literal q r h =
        ∑ y ∈ Finset.Ioo 0 h,
          (freeHighBaseline q *
            (freeFixedQLowWeight q r y * (∑ e ∈ y.divisors, etaCoeff q e)) -
            (if q.Coprime (r+y) then (1 : ℝ) else 0)) := by
        unfold printedS1Literal
        exact Finset.sum_congr rfl hterm
    _ = freeHighBaseline q *
        (∑ y ∈ Finset.Ioo 0 h,
            freeFixedQLowWeight q r y * (∑ e ∈ y.divisors, etaCoeff q e)) -
        (admissibleInteriorCount q r h : ℝ) := by
        rw [Finset.sum_sub_distrib, ← Finset.mul_sum, hN]
    _ = freeHighBaseline q *
        (∑ e ∈ Finset.Ioo 0 h,
            etaCoeff q e * rowConstrainedMass (freeFixedQLowWeight q r) h e 1) -
        (admissibleInteriorCount q r h : ℝ) := by
        rw [printed_free_weighted_divisor_swap]
    _ = freeHighBaseline q *
        (∑' e : ℕ,
            etaCoeff q e * rowConstrainedMass (freeFixedQLowWeight q r) h e 1) -
        (admissibleInteriorCount q r h : ℝ) := by
        rw [printed_free_row_tsum_eq_finite]
    _ = freeHighBaseline q *
        (∑' e : ℕ, etaCoeff q e *
          (rowConstrainedMass (freeFixedQLowWeight q r) h e 1 -
            (admissibleInteriorCount q r h : ℝ) / (e : ℝ))) := by
        exact printed_free_centered_sum q r h (printed_free_eta_normalization q)
    _ = PaperB.Closure.manuscriptS1Kernel q r h := rfl

#print axioms printedS1Literal_eq_manuscriptS1Kernel
end Elarienne.F01B


namespace Elarienne.F01B
open PaperB.FixedQ
open Merivelle.F01

theorem printed_pair_occupied_translate (p h y : ℕ) (hy : y < h) :
    (occupiedResidues p ({h,y} : Finset ℕ)).card =
      (occupiedResidues p ({0,h-y} : Finset ℕ)).card := by
  have hleft : (occupiedResidues p ({h,y} : Finset ℕ)).card =
      ({h%p,y%p} : Finset ℕ).card := by simp [occupiedResidues]
  have hright : (occupiedResidues p ({0,h-y} : Finset ℕ)).card =
      ({0,(h-y)%p} : Finset ℕ).card := by simp [occupiedResidues]
  rw [hleft, hright]
  by_cases hd : p ∣ h-y
  · have hmod : y%p = h%p :=
        (Nat.modEq_iff_dvd' (Nat.le_of_lt hy)).mpr hd
    have hz : (h-y)%p = 0 := Nat.mod_eq_zero_of_dvd hd
    simp [hmod, hz]
  · have hmod : y%p ≠ h%p :=
        (Nat.modEq_iff_dvd' (Nat.le_of_lt hy)).not.mpr hd
    have hz : (h-y)%p ≠ 0 :=
        Nat.dvd_iff_mod_eq_zero.not.mp hd
    rw [Finset.card_pair hmod.symm, Finset.card_pair hz.symm]

theorem printed_pair_local_translate (p h y : ℕ) (hy : y < h) :
    printedLocal p ({h,y} : Finset ℕ) =
      printedLocal p ({0,h-y} : Finset ℕ) := by
  have hleft : ({h,y}:Finset ℕ).card = 2 :=
    Finset.card_pair (by omega)
  have hright : ({0,h-y}:Finset ℕ).card = 2 :=
    Finset.card_pair (by omega)
  unfold printedLocal
  rw [hleft, hright, printed_pair_occupied_translate p h y hy]

theorem printed_pair_singularSeries_translate (q h y : ℕ) (hy : y < h) :
    printedRestrictedSingularSeries q ({h,y} : Finset ℕ) =
      printedRestrictedSingularSeries q ({0,h-y} : Finset ℕ) := by
  unfold printedRestrictedSingularSeries
  apply tprod_congr
  intro p
  by_cases ha : Nat.Prime p ∧ ¬ p ∣ q
  · simp only [if_pos ha]
    exact printed_pair_local_translate p h y hy
  · simp [ha]

#print axioms printed_pair_occupied_translate
#print axioms printed_pair_local_translate
#print axioms printed_pair_singularSeries_translate
end Elarienne.F01B


namespace Elarienne.F01B
open PaperB.FixedQ
open Merivelle.F01

/-- The second printed boundary term is the free one-anchor term under
the exact endpoint congruence a+h=b (mod q). -/
theorem printed_reflected_anchor_eq_S1 (q a b h : ℕ)
    (hq : 0 < q) (hcompat : Nat.ModEq q (a+h) b) :
    (∑ y ∈ Finset.Ioo 0 h,
      if q.Coprime (a+y) then
        printedRestrictedSingularSeries q ({h,y} : Finset ℕ) - 1
      else 0) =
      printedS1Literal q (PaperB.Closure.reflectedResidue q b) h := by
  let lambda : ℕ → ℝ := fun y =>
    if q.Coprime (a+y) then
      printedRestrictedSingularSeries q ({h,y} : Finset ℕ) - 1
    else 0
  have hreflect :
      (∑ y ∈ Finset.Ioo 0 h, lambda y) =
      ∑ z ∈ Finset.Ioo 0 h, lambda (h-z) := by
    have hmass := rowConstrainedMass_reflect lambda h 1 1
    simpa [rowConstrainedMass] using hmass
  change (∑ y ∈ Finset.Ioo 0 h, lambda y) =
    printedS1Literal q (PaperB.Closure.reflectedResidue q b) h
  rw [hreflect]
  unfold printedS1Literal
  apply Finset.sum_congr rfl
  intro z hz
  have hzI := Finset.mem_Ioo.mp hz
  have hy : h-z < h := by omega
  have hseries :
      printedRestrictedSingularSeries q ({h,h-z} : Finset ℕ) =
      printedRestrictedSingularSeries q ({0,z} : Finset ℕ) := by
    rw [printed_pair_singularSeries_translate q h (h-z) hy]
    rw [Nat.sub_sub_self hzI.2.le]
  have hr := PaperB.Closure.reflected_coprime_equiv hq hcompat z hz
  by_cases ha : q.Coprime (a+(h-z))
  · have hb := hr.mp ha
    simp only [lambda, if_pos ha, if_pos hb]
    rw [hseries]
  · have hb : ¬ q.Coprime (PaperB.Closure.reflectedResidue q b + z) :=
      fun hb => ha (hr.mpr hb)
    simp [lambda, ha, hb]

/-- The frozen manuscript's actual two-anchor B_{1,q} definition,
written from the independently defined printed singular series. -/
noncomputable def printedB1Literal (q a b h : ℕ) : ℝ :=
  (∑ y ∈ Finset.Ioo 0 h,
    if q.Coprime (a+y) then
      printedRestrictedSingularSeries q ({0,y} : Finset ℕ) - 1
    else 0) +
  (∑ y ∈ Finset.Ioo 0 h,
    if q.Coprime (a+y) then
      printedRestrictedSingularSeries q ({h,y} : Finset ℕ) - 1
    else 0)

/-- Complete F-01 B certification: the exact printed two-anchor singular
series is the existing paper-facing one-dimensional boundary kernel. -/
theorem printedB1Literal_eq_manuscriptB1Kernel (q a b h : ℕ)
    (hq : 0 < q) (hcompat : Nat.ModEq q (a+h) b) :
    printedB1Literal q a b h = PaperB.Closure.manuscriptB1Kernel q a b h := by
  unfold printedB1Literal PaperB.Closure.manuscriptB1Kernel
  rw [← printedS1Literal_eq_manuscriptS1Kernel q a h,
    ← printedS1Literal_eq_manuscriptS1Kernel q
      (PaperB.Closure.reflectedResidue q b) h]
  have hfirst : (∑ y ∈ Finset.Ioo 0 h,
    if q.Coprime (a+y) then
      printedRestrictedSingularSeries q ({0,y} : Finset ℕ) - 1
    else 0) = printedS1Literal q a h := rfl
  rw [hfirst, printed_reflected_anchor_eq_S1 q a b h hq hcompat]

#print axioms printed_reflected_anchor_eq_S1
#print axioms printedB1Literal_eq_manuscriptB1Kernel
end Elarienne.F01B



namespace Elarienne.F01B
open PaperB.FixedQ
open Merivelle.F01

/-- Both exact independently printed quantities transport simultaneously
to their already-certified manuscript-facing Lean kernels. This is the
source-fidelity adapter; it is NOT a new proof of the analytic terminal. -/
theorem printedA_sub_printedB_eq_manuscriptKernels (q a b h : ℕ)
    (hq : 0 < q) (hcompat : Nat.ModEq q (a+h) b)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    printedA1Literal q a h - printedB1Literal q a b h =
      manuscriptA1Kernel q a h -
        PaperB.Closure.manuscriptB1Kernel q a b h := by
  rw [printedA1Literal_eq_manuscriptA1Kernel q a h h2admissible,
    printedB1Literal_eq_manuscriptB1Kernel q a b h hq hcompat]

#print axioms printedA_sub_printedB_eq_manuscriptKernels

end Elarienne.F01B
