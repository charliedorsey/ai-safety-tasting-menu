import PaperB.FixedQ.PairRowBridge
import PaperB.M3.BooleanCRTSecondMoment

open scoped BigOperators

namespace PaperB.FixedQ

/-- The natural-number modulus attached to a finite squarefree prime set. -/
def fixedProductModulus (S : Finset ℕ) : ℕ :=
  primeSetProduct S

/-- One ordered Boolean partition row for a fixed prime set S. -/
noncomputable def fixedProductPartitionDiscrepancy
    (lambda : ℕ → ℝ) (H : ℕ) (S A : Finset ℕ) : ℝ :=
  rowDiscrepancy lambda H
    (primeSetProduct A) (primeSetProduct (S \ A))

/-- Frozen-paper Dcal_{m,q}^{(lambda)}(H), represented by a finite set of
distinct prime factors rather than by a squarefree natural m. -/
noncomputable def fixedProductBooleanDiscrepancy
    (lambda : ℕ → ℝ) (H : ℕ) (S : Finset ℕ) : ℝ :=
  ((2 : ℝ) ^ S.card)⁻¹ *
    ∑ A ∈ S.powerset,
      fixedProductPartitionDiscrepancy lambda H S A

theorem fixedProductBooleanDiscrepancy_eq_average
    (lambda : ℕ → ℝ) (H : ℕ) (S : Finset ℕ) :
    (2 : ℝ) ^ S.card *
        fixedProductBooleanDiscrepancy lambda H S =
      ∑ A ∈ S.powerset,
        fixedProductPartitionDiscrepancy lambda H S A := by
  unfold fixedProductBooleanDiscrepancy
  have hpow : (2 : ℝ) ^ S.card ≠ 0 := by positivity
  field_simp [hpow]

theorem fixedProductPartitionDiscrepancy_empty_left
    (lambda : ℕ → ℝ) (H : ℕ) (S : Finset ℕ) :
    fixedProductPartitionDiscrepancy lambda H S ∅ =
      rowDiscrepancy lambda H 1 (primeSetProduct S) := by
  simp [fixedProductPartitionDiscrepancy, primeSetProduct]

theorem fixedProductPartitionDiscrepancy_full_left
    (lambda : ℕ → ℝ) (H : ℕ) (S : Finset ℕ) :
    fixedProductPartitionDiscrepancy lambda H S S =
      rowDiscrepancy lambda H (primeSetProduct S) 1 := by
  simp [fixedProductPartitionDiscrepancy, primeSetProduct]

theorem fixedProductBooleanDiscrepancy_empty
    (lambda : ℕ → ℝ) (H : ℕ) :
    fixedProductBooleanDiscrepancy lambda H ∅ =
      rowDiscrepancy lambda H 1 1 := by
  simp [fixedProductBooleanDiscrepancy,
    fixedProductPartitionDiscrepancy, primeSetProduct]

/-- Absolute-value triangle bound for the Boolean fixed-product average. -/
theorem abs_fixedProductBooleanDiscrepancy_le
    (lambda : ℕ → ℝ) (H : ℕ) (S : Finset ℕ) :
    |fixedProductBooleanDiscrepancy lambda H S| ≤
      ((2 : ℝ) ^ S.card)⁻¹ *
        ∑ A ∈ S.powerset,
          |fixedProductPartitionDiscrepancy lambda H S A| := by
  unfold fixedProductBooleanDiscrepancy
  rw [abs_mul]
  have hpow0 : 0 ≤ ((2 : ℝ) ^ S.card)⁻¹ := by positivity
  have hinvabs :
      |((2 : ℝ) ^ S.card)⁻¹| = ((2 : ℝ) ^ S.card)⁻¹ := by
    exact abs_of_nonneg hpow0
  rw [hinvabs]
  apply mul_le_mul_of_nonneg_left _ hpow0
  exact Finset.abs_sum_le_sum_abs
    (fun A => fixedProductPartitionDiscrepancy lambda H S A)
    S.powerset

/-- Every Boolean partition has the same product modulus. -/
theorem pair_moduli_product_eq_fixedProduct
    {S A : Finset ℕ} (hA : A ⊆ S)
    (hPrime : ∀ p ∈ S, p.Prime) :
    primeSetProduct A * primeSetProduct (S \ A) =
      fixedProductModulus S := by
  unfold fixedProductModulus primeSetProduct
  have hdisj : Disjoint A (S \ A) := by
    rw [Finset.disjoint_left]
    intro p hpA hpDiff
    exact (Finset.mem_sdiff.mp hpDiff).2 hpA
  have hunion : A ∪ (S \ A) = S := by
    exact Finset.union_sdiff_of_subset hA
  rw [← Finset.prod_union hdisj, hunion]

#print axioms fixedProductBooleanDiscrepancy_eq_average
#print axioms pair_moduli_product_eq_fixedProduct

end PaperB.FixedQ
