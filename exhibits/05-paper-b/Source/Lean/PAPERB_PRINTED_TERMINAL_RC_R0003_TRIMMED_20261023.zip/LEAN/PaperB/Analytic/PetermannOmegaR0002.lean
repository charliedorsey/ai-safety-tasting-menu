import PaperB.Analytic.PetermannOmegaR0002Outer
import PaperB.Analytic.PetermannOmegaR0002Remainder
import PaperB.Analytic.PetermannOmegaPartialSumLogBound
import PaperB.Analytic.PetermannOmegaNearJumpMass
import PaperB.FixedQ.PetermannMovingTransfer

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

lemma omegaCharacterDft_norm_le
    (q : ℕ) [NeZero (Nat.lcm 6 q)]
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (h : ZMod (Nat.lcm 6 q)) :
    ‖ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h‖
      ≤ (Nat.lcm 6 q : ℕ) := by
  rw [ZMod.dft_apply]
  calc
    ‖∑ x : ZMod (Nat.lcm 6 q),
        ZMod.stdAddChar (-(x * h)) • chi x‖
      ≤ ∑ x : ZMod (Nat.lcm 6 q),
          ‖ZMod.stdAddChar (-(x * h)) • chi x‖ := norm_sum_le _ _
    _ ≤ ∑ _x : ZMod (Nat.lcm 6 q), (1 : ℝ) := by
      apply Finset.sum_le_sum
      intro x hx
      rw [norm_smul]
      have hchar := chi.norm_le_one x
      have hadd : ‖ZMod.stdAddChar (-(x * h))‖ = 1 := by
        simp [ZMod.stdAddChar_apply]
      rw [hadd, one_mul]
      exact hchar
    _ = (Nat.lcm 6 q : ℕ) := by simp

theorem petermannOmegaSmoothedKernel_norm_le_majorant
    {S : ℝ} (hS : 1 < S)
    (q : ℕ) (hq : 0 < q)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    {beta T : ℝ} (hb0 : 0 < beta) (hb1 : beta < 1)
    (r : ℤ) {H D M X : ℕ}
    (hH : 1 ≤ H) (hD : 1 ≤ D) (hDX : D ≤ X)
    (hM : 1 < M) (hKM : fixedBetaNaturalOrder beta ≤ M)
    (hMDX : M * D ≤ X)
    (hT : 0 < T) (hXT : (X : ℝ) ≤ T)
    (hsource : (((H : ℝ) * T) ^ beta) ≤ (M : ℝ))
    (hbase :
      (2 * ((6 * q : ℕ) : ℝ)) ^ 2 ≤
        T / (((Nat.lcm 6 q : ℕ) : ℝ) * (D : ℝ))) :
    ‖petermannOmegaSmoothedKernel q chi r T X H S‖
      ≤ ((Nat.lcm 6 q : ℕ) : ℝ) *
          omegaR0002AdditiveMajorant q beta M H T D X := by
  let L := Nat.lcm 6 q
  have hLnat : 0 < L := Nat.lcm_pos (by norm_num) hq
  letI : NeZero L := ⟨Nat.ne_of_gt hLnat⟩
  have hA : ∀ h : ZMod L,
      ‖petermannOmegaSmoothedAdditiveKernel q H X S
          ((h.val : ℝ) / (L : ℝ)) T r‖
        ≤ omegaR0002AdditiveMajorant q beta M H T D X := by
    intro h
    simpa [L] using
      petermannOmegaSmoothedAdditiveKernel_norm_le_majorant
        hS q hq h hb0 hb1 r hH hD hDX hM hKM hMDX
          hT hXT hsource hbase
  rw [petermannOmegaSmoothedKernel_eq_additive_dft]
  rw [norm_mul, norm_inv, Complex.norm_natCast]
  have hLr : (0 : ℝ) < L := by exact_mod_cast hLnat
  calc
    ((L : ℝ))⁻¹ *
        ‖∑ h : ZMod L,
          ZMod.dft (fun x : ZMod L => chi x) h *
            petermannOmegaSmoothedAdditiveKernel q H X S
              ((h.val : ℝ) / (L : ℝ)) T r‖
      ≤ ((L : ℝ))⁻¹ *
          ∑ h : ZMod L,
            ‖ZMod.dft (fun x : ZMod L => chi x) h *
              petermannOmegaSmoothedAdditiveKernel q H X S
                ((h.val : ℝ) / (L : ℝ)) T r‖ := by
        gcongr
        exact norm_sum_le _ _
    _ ≤ ((L : ℝ))⁻¹ *
          ∑ _h : ZMod L,
            ((L : ℝ) * omegaR0002AdditiveMajorant q beta M H T D X) := by
        gcongr with h
        rw [norm_mul]
        exact mul_le_mul
          (by simpa [L] using omegaCharacterDft_norm_le q chi h)
          (hA h)
          (by positivity)
          (by positivity)
    _ = (L : ℝ) * omegaR0002AdditiveMajorant q beta M H T D X := by
        simp
        field_simp [hLr.ne']
    _ = ((Nat.lcm 6 q : ℕ) : ℝ) *
          omegaR0002AdditiveMajorant q beta M H T D X := by rfl

#print axioms omegaCharacterDft_norm_le
#print axioms petermannOmegaSmoothedKernel_norm_le_majorant

end PaperB.Analytic

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

theorem omegaPartialSum_le_rankin_log_add_const
    (q X : ℕ) (hq : 0 < q) (hX : 1 ≤ X) :
    omegaPartialSum q X ≤
      omegaRankinBound * Real.log X +
        ((2 * (6 * q) + 9 : ℕ) : ℝ) * omegaRankinBound := by
  have hmean := omegaPrincipalLogMean_bound q X hq hX
  let R : ℝ := logarithmicEulerResidue (omegaCoeff q)
  let C : ℝ := ((2 * (6 * q) + 9 : ℕ) : ℝ) * omegaRankinBound
  have hR := abs_logarithmicEulerResidue_omega_le_rankin q hq
  have hlogX0 : 0 ≤ Real.log (X : ℝ) :=
    Real.log_nonneg (by exact_mod_cast hX)
  have hupper : omegaPartialSum q X ≤ R * Real.log X + C := by
    have hs : omegaPartialSum q X - R * Real.log X ≤ C := by
      have := le_trans
        (le_abs_self (omegaPartialSum q X - R * Real.log X)) hmean
      simpa [R, C] using this
    linarith
  have hRterm :
      R * Real.log X ≤ omegaRankinBound * Real.log X := by
    calc
      R * Real.log X ≤ |R| * Real.log X :=
        mul_le_mul_of_nonneg_right (le_abs_self R) hlogX0
      _ ≤ omegaRankinBound * Real.log X :=
        mul_le_mul_of_nonneg_right (by simpa [R] using hR) hlogX0
  calc
    omegaPartialSum q X ≤ R * Real.log X + C := hupper
    _ ≤ omegaRankinBound * Real.log X + C :=
      _root_.add_le_add hRterm le_rfl
    _ = omegaRankinBound * Real.log X +
        ((2 * (6 * q) + 9 : ℕ) : ℝ) * omegaRankinBound := by rfl

theorem norm_petermannBaseKernelSum_omega_le_half_partial
    (q : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (T : ℝ) (X : ℕ) :
    ‖petermannBaseKernelSum q PetermannBase.omega chi r T X‖
      ≤ (1 / 2 : ℝ) * omegaPartialSum q X := by
  unfold petermannBaseKernelSum omegaPartialSum
  simp only [petermannBaseCoeff]
  calc
    ‖∑ e ∈ Finset.Icc 1 X,
        chi e * (omegaCoeff q e : ℂ) *
          (petermannSawtooth
            (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
              (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ)‖
      ≤ ∑ e ∈ Finset.Icc 1 X,
          ‖chi e * (omegaCoeff q e : ℂ) *
            (petermannSawtooth
              (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
                (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ)‖ :=
        norm_sum_le _ _
    _ ≤ ∑ e ∈ Finset.Icc 1 X, (1 / 2 : ℝ) * omegaCoeff q e := by
      apply Finset.sum_le_sum
      intro e he
      rw [norm_mul, norm_mul, Complex.norm_real,
        Complex.norm_real, Real.norm_eq_abs,
        abs_of_nonneg (omegaCoeff_nonneg q e)]
      have hchi := norm_dirichletCharacter_nat_le_one
        (q := q) (e := e) chi
      have hsaw := abs_petermannSawtooth_le_half
        (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
          (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))
      have homega := omegaCoeff_nonneg q e
      calc
        ‖chi (e : ZMod (Nat.lcm 6 q))‖ * omegaCoeff q e *
            |petermannSawtooth
              (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (e : ℝ) +
                (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))|
          ≤ 1 * omegaCoeff q e * (1 / 2) := by
            exact mul_le_mul
              (mul_le_mul hchi le_rfl homega (by positivity))
              hsaw (by positivity) (by positivity)
        _ = (1 / 2 : ℝ) * omegaCoeff q e := by ring
    _ = (1 / 2 : ℝ) *
        ∑ e ∈ Finset.Icc 1 X, omegaCoeff q e := by
      rw [Finset.mul_sum]
    _ = (1 / 2 : ℝ) * omegaPartialSum q X := rfl

#print axioms omegaPartialSum_le_rankin_log_add_const
#print axioms norm_petermannBaseKernelSum_omega_le_half_partial

end PaperB.Analytic

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

theorem omegaMiddleTailBound_eventually_le
    (q : ℕ) (hq : 0 < q)
    {beta eps : ℝ} (hb0 : 0 < beta) (heps : 0 < eps) :
    ∃ M0 : ℝ, ∀ M : ℕ, M0 ≤ (M : ℝ) → 1 ≤ M →
      omegaMiddleTailBound q beta M ≤ eps := by
  let P : ℝ := ((6 * q : ℕ) : ℝ)
  let theta := fixedBetaUniformExponent (fixedBetaNaturalOrder beta)
  let C : ℝ :=
    (2 * fixedBetaUniformMajorantConst beta) /
      (1 - (2 : ℝ) ^ (theta - 1))
  have hP : 0 < P := by
    dsimp [P]
    exact_mod_cast (show 0 < 6 * q by omega)
  have htheta : theta < 1 := by
    dsimp [theta]
    exact fixedBetaUniformExponent_lt_one _
  have hpowlt : (2 : ℝ) ^ (theta - 1) < 1 :=
    Real.rpow_lt_one_of_one_lt_of_neg (by norm_num) (by linarith)
  have hden : 0 < 1 - (2 : ℝ) ^ (theta - 1) := by linarith
  have hC : 0 ≤ C := by
    dsimp [C]
    have hc := fixedBetaUniformMajorantConst_nonneg beta
    positivity
  let delta : ℝ := eps / (2 * P)
  have hdelta : 0 < delta := by dsimp [delta]; positivity
  obtain ⟨W01, hW01⟩ :=
    const_mul_rpow_lt_one_is_sublinear
      (C := (4 : ℝ)) (theta := (0 : ℝ))
      (by norm_num) (by norm_num) hdelta
  obtain ⟨W02, hW02⟩ :=
    const_mul_rpow_lt_one_is_sublinear
      (C := C) (theta := theta) hC htheta hdelta
  refine ⟨max W01 W02, ?_⟩
  intro M hM0 hM1
  have hMr : (0 : ℝ) < M := by exact_mod_cast (show 0 < M by omega)
  have hM01 : W01 ≤ (M : ℝ) := (le_max_left _ _).trans hM0
  have hM02 : W02 ≤ (M : ℝ) := (le_max_right _ _).trans hM0
  have hfirst0 := hW01 (M : ℝ) hM01 (by exact_mod_cast hM1)
  have hsecond0 := hW02 (M : ℝ) hM02 (by exact_mod_cast hM1)
  have hfirst : 4 / (M : ℝ) ≤ delta := by
    rw [div_le_iff₀ hMr]
    simpa using hfirst0
  have hid :
      (M : ℝ) ^ theta =
        (M : ℝ) ^ (theta - 1) * (M : ℝ) := by
    calc
      (M : ℝ) ^ theta =
          (M : ℝ) ^ ((theta - 1) + 1) := by congr 1 <;> ring
      _ = (M : ℝ) ^ (theta - 1) * (M : ℝ) ^ (1 : ℝ) := by
        rw [Real.rpow_add hMr]
      _ = (M : ℝ) ^ (theta - 1) * (M : ℝ) := by
        rw [Real.rpow_one]
  have hsecond : C * (M : ℝ) ^ (theta - 1) ≤ delta := by
    rw [hid] at hsecond0
    have hpow0 : 0 ≤ (M : ℝ) ^ (theta - 1) :=
      Real.rpow_nonneg hMr.le _
    nlinarith
  unfold omegaMiddleTailBound
  change P * (4 / (M : ℝ) + C * (M : ℝ) ^ (theta - 1)) ≤ eps
  have hsum :
      4 / (M : ℝ) + C * (M : ℝ) ^ (theta - 1)
        ≤ 2 * delta := by
    have h := _root_.add_le_add hfirst hsecond
    nlinarith
  calc
    P * (4 / (M : ℝ) + C * (M : ℝ) ^ (theta - 1))
      ≤ P * (2 * delta) := mul_le_mul_of_nonneg_left hsum hP.le
    _ = eps := by
      dsimp [delta]
      field_simp [hP.ne']

#print axioms omegaMiddleTailBound_eventually_le

end PaperB.Analytic

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

theorem exists_nat_rpow_neg_quarter_le
    {eps : ℝ} (heps : 0 < eps) :
    ∃ D : ℕ, 1 ≤ D ∧
      (((D + 1 : ℕ) : ℝ) ^ (-1 / 4 : ℝ)) ≤ eps := by
  have hquarter : (0 : ℝ) < 1 / 4 := by norm_num
  have ht := tendsto_rpow_neg_atTop hquarter
  have hev : ∀ᶠ W : ℝ in Filter.atTop,
      W ^ (-((1 : ℝ) / 4)) < eps :=
    (tendsto_order.mp ht).2 eps heps
  rw [Filter.eventually_atTop] at hev
  rcases hev with ⟨W0, hW0⟩
  obtain ⟨D, hDgt⟩ := exists_nat_gt (max 1 W0)
  have hD1 : 1 ≤ D := by
    have h1 : (1 : ℝ) < D :=
      lt_of_le_of_lt (le_max_left (1 : ℝ) W0) hDgt
    exact_mod_cast h1.le
  have hW : W0 ≤ ((D + 1 : ℕ) : ℝ) := by
    have hWD : W0 < (D : ℝ) :=
      lt_of_le_of_lt (le_max_right (1 : ℝ) W0) hDgt
    exact hWD.le.trans (by exact_mod_cast (show D ≤ D + 1 by omega))
  have h := hW0 (((D + 1 : ℕ) : ℝ)) hW
  refine ⟨D, hD1, ?_⟩
  norm_num only at h ⊢
  exact h.le

#print axioms exists_nat_rpow_neg_quarter_le

end PaperB.Analytic

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

lemma omegaCanonicalS_le_four_mul_cube
    {T : ℝ} (hT1 : 1 ≤ T) :
    Real.sqrt T * (Real.log (2 * T)) ^ 2 ≤ 4 * T ^ 3 := by
  have hT0 : 0 < T := lt_of_lt_of_le zero_lt_one hT1
  have hsqrt : Real.sqrt T ≤ T := by
    exact Real.sqrt_le_self_iff.mpr (Or.inr hT1)
  have hsqrt0 : 0 ≤ Real.sqrt T := Real.sqrt_nonneg _
  have h2T : 0 < 2 * T := by positivity
  have hlog0 : 0 ≤ Real.log (2 * T) :=
    Real.log_nonneg (by nlinarith)
  have hlog : Real.log (2 * T) ≤ 2 * T := by
    have h := Real.log_le_sub_one_of_pos h2T
    linarith
  have hlogsq : (Real.log (2 * T)) ^ 2 ≤ 4 * T ^ 2 := by
    nlinarith [sq_nonneg (2 * T - Real.log (2 * T))]
  calc
    Real.sqrt T * (Real.log (2 * T)) ^ 2
      ≤ T * (4 * T ^ 2) :=
        mul_le_mul hsqrt hlogsq (sq_nonneg _)
          (le_trans zero_le_one hT1)
    _ = 4 * T ^ 3 := by ring

#print axioms omegaCanonicalS_le_four_mul_cube

end PaperB.Analytic

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

lemma omegaFourierCoeffPairMassBound_le_six_log
    {T : ℝ} (hTexp : Real.exp 1 ≤ T)
    {H : ℕ} (hHT : (H : ℝ) ≤ T ^ 4) :
    omegaFourierCoeffPairMassBound H ≤ 6 * Real.log T := by
  have hTpos : 0 < T := (Real.exp_pos 1).trans_le hTexp
  have hT1 : 1 ≤ T := by
    have he : (1 : ℝ) ≤ Real.exp 1 := by
      rw [← Real.exp_zero]
      exact Real.exp_le_exp.mpr (by norm_num)
    exact he.trans hTexp
  have hlogT1 : 1 ≤ Real.log T := by
    have h := Real.log_le_log (Real.exp_pos 1) hTexp
    simpa using h
  have hH1 :
      ((H + 1 : ℕ) : ℝ) ≤ 2 * T ^ 4 := by
    push_cast
    have hT4 : 1 ≤ T ^ 4 := one_le_pow₀ hT1
    linarith
  have hlogH :
      Real.log (((H + 1 : ℕ) : ℝ)) ≤ Real.log (2 * T ^ 4) := by
    apply Real.log_le_log (by positivity)
    exact hH1
  have hlog2 : Real.log 2 ≤ 1 := by
    have h := Real.log_le_sub_one_of_pos (show (0 : ℝ) < 2 by norm_num)
    norm_num at h ⊢
    linarith
  have hlogprod :
      Real.log (2 * T ^ 4) = Real.log 2 + 4 * Real.log T := by
    rw [Real.log_mul (by norm_num : (2 : ℝ) ≠ 0) (by positivity)]
    rw [Real.log_pow]
    norm_num
  have hinner :
      1 + Real.log (((H + 1 : ℕ) : ℝ)) ≤ 6 * Real.log T := by
    rw [hlogprod] at hlogH
    linarith
  unfold omegaFourierCoeffPairMassBound
  have hpi : 1 / Real.pi ≤ 1 := by
    have hp : (1 : ℝ) ≤ Real.pi := by
      linarith [Real.one_le_pi_div_two]
    exact (div_le_one Real.pi_pos).2 hp
  have hinner0 : 0 ≤
      1 + (Real.log (((1 + H : ℕ) : ℝ)) - Real.log (1 : ℝ)) := by
    norm_num
    exact add_nonneg zero_le_one
      (Real.log_nonneg (by
        exact_mod_cast (show 1 ≤ 1 + H by omega)))
  norm_num only [Real.log_one, sub_zero]
  have hEq : ((1 + H : ℕ) : ℝ) = ((H + 1 : ℕ) : ℝ) := by
    congr 1
    omega
  rw [hEq]
  calc
    (1 / Real.pi) * (1 + Real.log (((H + 1 : ℕ) : ℝ)))
      ≤ 1 * (1 + Real.log (((H + 1 : ℕ) : ℝ))) :=
        mul_le_mul_of_nonneg_right hpi (by
          have : (1 : ℝ) ≤ ((H + 1 : ℕ) : ℝ) := by
            exact_mod_cast (show 1 ≤ H + 1 by omega)
          exact add_nonneg zero_le_one (Real.log_nonneg this))
    _ ≤ 6 * Real.log T := by simpa using hinner

#print axioms omegaFourierCoeffPairMassBound_le_six_log

end PaperB.Analytic

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat Filter

theorem omegaHighResidual_eventually_le
    (q D : ℕ) (hq : 0 < q) (hD : 1 ≤ D)
    {eps : ℝ} (heps : 0 < eps) :
    ∃ T0 : ℝ, ∀ T : ℝ, T0 ≤ T →
      4 * ((6 * q : ℕ) : ℝ) * (1 + 2 * ((6 * q : ℕ) : ℝ)) /
          ((T / (((Nat.lcm 6 q : ℕ) : ℝ) * (D : ℝ))) ^
            (3 / 4 : ℝ))
        ≤ eps := by
  let L : ℝ := ((Nat.lcm 6 q : ℕ) : ℝ)
  let Q : ℝ := L * (D : ℝ)
  let C : ℝ := 4 * ((6 * q : ℕ) : ℝ) *
      (1 + 2 * ((6 * q : ℕ) : ℝ))
  have hL : 0 < L := by
    dsimp [L]
    exact_mod_cast Nat.lcm_pos (by norm_num) hq
  have hQ : 0 < Q := by dsimp [Q]; positivity
  have hC : 0 < C := by
    dsimp [C]
    positivity
  let delta : ℝ := eps / C
  have hdelta : 0 < delta := by dsimp [delta]; positivity
  have ht := tendsto_rpow_neg_atTop (show (0 : ℝ) < 3 / 4 by norm_num)
  have hev : ∀ᶠ W : ℝ in Filter.atTop,
      W ^ (-(3 / 4 : ℝ)) < delta :=
    (tendsto_order.mp ht).2 delta hdelta
  rw [Filter.eventually_atTop] at hev
  rcases hev with ⟨W0, hW0⟩
  let W1 : ℝ := max 1 W0
  refine ⟨Q * W1, ?_⟩
  intro T hT
  have hW1 : 1 ≤ W1 := le_max_left _ _
  have hW0' : W0 ≤ W1 := le_max_right _ _
  have hTpos : 0 < T := by
    have hQW : 0 < Q * W1 := mul_pos hQ (lt_of_lt_of_le zero_lt_one hW1)
    exact hQW.trans_le hT
  have hy : W1 ≤ T / Q := by
    exact (le_div_iff₀ hQ).2 (by simpa [mul_comm] using hT)
  have hy1 : 1 ≤ T / Q := hW1.trans hy
  have hy0 : 0 ≤ T / Q := le_trans zero_le_one hy1
  have hdec : (T / Q) ^ (-(3 / 4 : ℝ)) ≤ delta :=
    (hW0 (T / Q) (hW0'.trans hy)).le
  have heq :
      C / ((T / Q) ^ (3 / 4 : ℝ)) =
        C * (T / Q) ^ (-(3 / 4 : ℝ)) := by
    rw [div_eq_mul_inv, Real.rpow_neg hy0]
  change C / ((T / Q) ^ (3 / 4 : ℝ)) ≤ eps
  rw [heq]
  have hm := mul_le_mul_of_nonneg_left hdec hC.le
  calc
    C * (T / Q) ^ (-(3 / 4 : ℝ))
      ≤ C * delta := hm
    _ = eps := by
      dsimp [delta]
      field_simp [hC.ne']

#print axioms omegaHighResidual_eventually_le

end PaperB.Analytic

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

lemma omega_log_max_ceil_rpow_le
    {T beta : ℝ} (hT1 : 1 ≤ T) (hb0 : 0 ≤ beta)
    (Mfix : ℕ) (hMfix : 1 ≤ Mfix) :
    let M := max Mfix ⌈T ^ (5 * beta)⌉₊
    Real.log (M : ℝ) ≤
      Real.log ((Mfix + 2 : ℕ) : ℝ) + 5 * beta * Real.log T := by
  dsimp only
  let x : ℝ := T ^ (5 * beta)
  have hTpos : 0 < T := lt_of_lt_of_le zero_lt_one hT1
  have hexp : 0 ≤ 5 * beta := by positivity
  have hx1 : 1 ≤ x := by
    dsimp [x]
    exact Real.one_le_rpow hT1 hexp
  have hx0 : 0 ≤ x := le_trans zero_le_one hx1
  have hceil : ((⌈x⌉₊ : ℕ) : ℝ) ≤ x + 1 := by
    exact (Nat.ceil_lt_add_one hx0).le
  have hmaxNat :
      max Mfix ⌈x⌉₊ ≤ Mfix + ⌈x⌉₊ := by
    exact max_le (Nat.le_add_right _ _) (Nat.le_add_left _ _)
  have hmaxCast :
      ((max Mfix ⌈x⌉₊ : ℕ) : ℝ) ≤ (Mfix : ℝ) + x + 1 := by
    have hc : ((max Mfix ⌈x⌉₊ : ℕ) : ℝ) ≤
        ((Mfix + ⌈x⌉₊ : ℕ) : ℝ) := by exact_mod_cast hmaxNat
    calc
      ((max Mfix ⌈x⌉₊ : ℕ) : ℝ)
        ≤ ((Mfix + ⌈x⌉₊ : ℕ) : ℝ) := hc
      _ = (Mfix : ℝ) + ((⌈x⌉₊ : ℕ) : ℝ) := by push_cast; rfl
      _ ≤ (Mfix : ℝ) + (x + 1) := _root_.add_le_add le_rfl hceil
      _ = (Mfix : ℝ) + x + 1 := by ring
  have hprod :
      (Mfix : ℝ) + x + 1 ≤ ((Mfix + 2 : ℕ) : ℝ) * x := by
    have hm0 : 0 ≤ (Mfix : ℝ) := by positivity
    push_cast
    nlinarith
  have hupper :
      ((max Mfix ⌈x⌉₊ : ℕ) : ℝ) ≤
        ((Mfix + 2 : ℕ) : ℝ) * x :=
    hmaxCast.trans hprod
  have hmaxPos : (0 : ℝ) < (max Mfix ⌈x⌉₊ : ℕ) := by
    exact_mod_cast (show 0 < max Mfix ⌈x⌉₊ by
      exact lt_of_lt_of_le (lt_of_lt_of_le Nat.zero_lt_one hMfix)
        (le_max_left _ _))
  have hCpos : (0 : ℝ) < (Mfix + 2 : ℕ) := by positivity
  have hxpos : 0 < x := lt_of_lt_of_le zero_lt_one hx1
  calc
    Real.log ((max Mfix ⌈T ^ (5 * beta)⌉₊ : ℕ) : ℝ)
      = Real.log ((max Mfix ⌈x⌉₊ : ℕ) : ℝ) := by rfl
    _ ≤ Real.log (((Mfix + 2 : ℕ) : ℝ) * x) :=
      Real.log_le_log hmaxPos hupper
    _ = Real.log ((Mfix + 2 : ℕ) : ℝ) + Real.log x := by
      rw [Real.log_mul (ne_of_gt hCpos) (ne_of_gt hxpos)]
    _ = Real.log ((Mfix + 2 : ℕ) : ℝ) +
        5 * beta * Real.log T := by
      dsimp [x]
      rw [Real.log_rpow hTpos]

#print axioms omega_log_max_ceil_rpow_le

end PaperB.Analytic

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

lemma omegaCanonicalS_gt_one
    {T : ℝ} (hTexp2 : Real.exp 2 ≤ T) :
    1 < Real.sqrt T * (Real.log (2 * T)) ^ 2 := by
  have hT1 : 1 ≤ T := by
    have he : (1 : ℝ) ≤ Real.exp 2 := by
      rw [← Real.exp_zero]
      exact Real.exp_le_exp.mpr (by norm_num)
    exact he.trans hTexp2
  have hsqrt : 1 ≤ Real.sqrt T := Real.one_le_sqrt.mpr hT1
  have hlogT : 2 ≤ Real.log T := by
    have h := Real.log_le_log (Real.exp_pos 2) hTexp2
    simpa using h
  have hTpos : 0 < T := lt_of_lt_of_le zero_lt_one hT1
  have hlog2T : Real.log T ≤ Real.log (2 * T) := by
    apply Real.log_le_log hTpos
    nlinarith
  have hlog : 2 ≤ Real.log (2 * T) := hlogT.trans hlog2T
  have hsq : 4 ≤ (Real.log (2 * T)) ^ 2 := by nlinarith
  nlinarith [mul_le_mul hsqrt hsq (by norm_num : (0 : ℝ) ≤ 4)
    (Real.sqrt_nonneg T)]
lemma omegaCanonicalH_data
    {T K : ℝ}
    (hT1 : 1 ≤ T) (hK1 : 1 ≤ K)
    (hS : 1 < Real.sqrt T * (Real.log (2 * T)) ^ 2)
    (hTK : 4 * K + 1 ≤ T) :
    let S := Real.sqrt T * (Real.log (2 * T)) ^ 2
    let H : ℕ := ⌈K * S⌉₊
    1 ≤ H ∧
      (H : ℝ) ≤ T ^ 4 ∧
      S / (Real.pi ^ 2 * H) ≤ 1 / K := by
  dsimp only
  let S : ℝ := Real.sqrt T * (Real.log (2 * T)) ^ 2
  let H : ℕ := ⌈K * S⌉₊
  have hS0 : 0 < S := lt_trans zero_lt_one hS
  have hK0 : 0 < K := lt_of_lt_of_le zero_lt_one hK1
  have hKS0 : 0 < K * S := mul_pos hK0 hS0
  have hceilLower : K * S ≤ (H : ℝ) := by
    dsimp [H]
    exact Nat.le_ceil _
  have hH1 : 1 ≤ H := by
    have hHposR : (0 : ℝ) < (H : ℝ) := hKS0.trans_le hceilLower
    have hHpos : 0 < H := by exact_mod_cast hHposR
    omega
  have hSupper : S ≤ 4 * T ^ 3 := by
    dsimp [S]
    exact omegaCanonicalS_le_four_mul_cube hT1
  have hceilUpper : (H : ℝ) ≤ K * S + 1 := by
    dsimp [H]
    exact (Nat.ceil_lt_add_one (mul_nonneg hK0.le hS0.le)).le
  have hT3 : 1 ≤ T ^ 3 := one_le_pow₀ hT1
  have hHupper : (H : ℝ) ≤ T ^ 4 := by
    calc
      (H : ℝ) ≤ K * S + 1 := hceilUpper
      _ ≤ 4 * K * T ^ 3 + 1 := by
        have hm := mul_le_mul_of_nonneg_left hSupper hK0.le
        nlinarith
      _ ≤ (4 * K + 1) * T ^ 3 := by nlinarith
      _ ≤ T * T ^ 3 := mul_le_mul_of_nonneg_right hTK (by positivity)
      _ = T ^ 4 := by ring
  have hpi2 : 1 ≤ Real.pi ^ 2 := by
    have hp : (1 : ℝ) ≤ Real.pi := by
      linarith [Real.one_le_pi_div_two]
    nlinarith
  have hden :
      K * S ≤ Real.pi ^ 2 * (H : ℝ) := by
    calc
      K * S ≤ (H : ℝ) := hceilLower
      _ ≤ Real.pi ^ 2 * (H : ℝ) := by
        have hH0 : 0 ≤ (H : ℝ) := by positivity
        simpa only [one_mul] using mul_le_mul_of_nonneg_right hpi2 hH0
  have hdenpos : 0 < K * S := hKS0
  have hbigpos : 0 < Real.pi ^ 2 * (H : ℝ) :=
    lt_of_lt_of_le hdenpos hden
  have hratio :
      S / (Real.pi ^ 2 * (H : ℝ)) ≤ S / (K * S) :=
    div_le_div_of_nonneg_left hS0.le hdenpos hden
  have heq : S / (K * S) = 1 / K := by
    field_simp [hK0.ne', hS0.ne']
  refine ⟨hH1, hHupper, ?_⟩
  exact hratio.trans_eq heq

#print axioms omegaCanonicalS_gt_one
#print axioms omegaCanonicalH_data

end PaperB.Analytic

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

lemma omegaR0002LargeDivisorBranchBound_le_36_log
    {T : ℝ} (hTexp : Real.exp 1 ≤ T)
    {X : ℕ} (hXT : (X : ℝ) ≤ T) :
    omegaR0002LargeDivisorBranchBound X ≤ 36 * Real.log T := by
  have hTpos : 0 < T := (Real.exp_pos 1).trans_le hTexp
  have hT1 : (1 : ℝ) ≤ T := by
    have h : (1 : ℝ) ≤ Real.exp 1 := by
      rw [← Real.exp_zero]
      exact Real.exp_le_exp.mpr (by norm_num)
    exact h.trans hTexp
  have hlogT1 : 1 ≤ Real.log T := by
    have h := Real.log_le_log (Real.exp_pos 1) hTexp
    simpa using h
  have hX1 : ((X + 1 : ℕ) : ℝ) ≤ 2 * T := by
    push_cast
    linarith
  have hlogX :
      Real.log (((X + 1 : ℕ) : ℝ)) ≤ Real.log (2 * T) := by
    apply Real.log_le_log
    · positivity
    · exact hX1
  have hlog2 : Real.log 2 ≤ 1 := by
    have h := Real.log_le_sub_one_of_pos (show (0 : ℝ) < 2 by norm_num)
    norm_num at h ⊢
    linarith
  have hlogprod :
      Real.log (2 * T) = Real.log 2 + Real.log T := by
    rw [Real.log_mul (by norm_num : (2 : ℝ) ≠ 0) hTpos.ne']
  have hinner :
      1 + Real.log (((X + 1 : ℕ) : ℝ)) ≤ 3 * Real.log T := by
    rw [hlogprod] at hlogX
    linarith
  have hpi : 12 / Real.pi ≤ 12 := by
    have hp : (1 : ℝ) ≤ Real.pi := by
      linarith [Real.one_le_pi_div_two]
    rw [div_le_iff₀ Real.pi_pos]
    nlinarith
  unfold omegaR0002LargeDivisorBranchBound
  have hinner0 : 0 ≤ 1 + Real.log (((X + 1 : ℕ) : ℝ)) := by
    have : (1 : ℝ) ≤ ((X + 1 : ℕ) : ℝ) := by
      exact_mod_cast (show 1 ≤ X + 1 by omega)
    exact add_nonneg zero_le_one (Real.log_nonneg this)
  calc
    (12 / Real.pi) * (1 + Real.log (((X + 1 : ℕ) : ℝ)))
      ≤ 12 * (1 + Real.log (((X + 1 : ℕ) : ℝ))) :=
        mul_le_mul_of_nonneg_right hpi hinner0
    _ ≤ 12 * (3 * Real.log T) :=
        mul_le_mul_of_nonneg_left hinner (by norm_num)
    _ = 36 * Real.log T := by ring

#print axioms omegaR0002LargeDivisorBranchBound_le_36_log

end PaperB.Analytic

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat Filter

lemma omega_r0002_source_bound
    {T beta : ℝ} (hT1 : 1 ≤ T) (hb0 : 0 ≤ beta)
    {H Mfix : ℕ} (hHT : (H : ℝ) ≤ T ^ 4) :
    (((H : ℝ) * T) ^ beta) ≤
      ((max Mfix ⌈T ^ (5 * beta)⌉₊ : ℕ) : ℝ) := by
  have hT : 0 < T := lt_of_lt_of_le zero_lt_one hT1
  have hp : (H : ℝ) * T ≤ T ^ 5 := by
    calc
      (H : ℝ) * T ≤ T ^ 4 * T :=
        mul_le_mul_of_nonneg_right hHT hT.le
      _ = T ^ 5 := by ring
  have hr := Real.rpow_le_rpow
    (by positivity : 0 ≤ (H : ℝ) * T) hp hb0
  have heq : (T ^ (5 : ℕ)) ^ beta = T ^ (5 * beta) := by
    rw [← Real.rpow_natCast]
    rw [Real.rpow_mul hT.le]
    norm_num
  rw [heq] at hr
  have hceil :
      T ^ (5 * beta) ≤ ((⌈T ^ (5 * beta)⌉₊ : ℕ) : ℝ) :=
    Nat.le_ceil _
  have hmax :
      ((⌈T ^ (5 * beta)⌉₊ : ℕ) : ℝ) ≤
        ((max Mfix ⌈T ^ (5 * beta)⌉₊ : ℕ) : ℝ) := by
    exact_mod_cast (le_max_right Mfix ⌈T ^ (5 * beta)⌉₊)
  exact hr.trans (hceil.trans hmax)

lemma omega_r0002_log_short_X
    {T beta : ℝ} (hT1 : 1 ≤ T) (hb0 : 0 ≤ beta)
    (Mfix D X : ℕ) (hMfix : 1 ≤ Mfix) (hD : 1 ≤ D)
    (hX : 1 ≤ X)
    (hshort : X < (max Mfix ⌈T ^ (5 * beta)⌉₊) * D) :
    Real.log (X : ℝ) ≤
      Real.log ((Mfix + 2 : ℕ) : ℝ) +
        Real.log (D : ℝ) + 5 * beta * Real.log T := by
  let M := max Mfix ⌈T ^ (5 * beta)⌉₊
  have hM1 : 1 ≤ M := hMfix.trans (le_max_left _ _)
  have hXpos : (0 : ℝ) < X := by exact_mod_cast (show 0 < X by omega)
  have hMDpos : (0 : ℝ) < M * D := by positivity
  have hXMD : (X : ℝ) ≤ ((M * D : ℕ) : ℝ) := by
    exact_mod_cast (Nat.le_of_lt hshort)
  have hlog := Real.log_le_log hXpos hXMD
  have hlogM :=
    omega_log_max_ceil_rpow_le hT1 hb0 Mfix hMfix
  have hMr : (0 : ℝ) < M := by exact_mod_cast (show 0 < M by omega)
  have hDr : (0 : ℝ) < D := by exact_mod_cast (show 0 < D by omega)
  have hmul :
      Real.log (((M * D : ℕ) : ℝ)) =
        Real.log (M : ℝ) + Real.log (D : ℝ) := by
    push_cast
    rw [Real.log_mul hMr.ne' hDr.ne']
  rw [hmul] at hlog
  dsimp [M] at hlogM
  linarith

#print axioms omega_r0002_source_bound
#print axioms omega_r0002_log_short_X

end PaperB.Analytic

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat

lemma omegaR0002AdditiveMajorant_priced
    (q : ℕ) (hq : 0 < q)
    {eps beta z T Clog : ℝ} {M H D X : ℕ}
    (heps : 0 < eps) (hb0 : 0 < beta) (hz0 : 0 ≤ z)
    (hTexp : Real.exp 1 ≤ T) (hXT : (X : ℝ) ≤ T)
    (hM1 : 1 ≤ M) (hD1 : 1 ≤ D) (hHT : (H : ℝ) ≤ T ^ 4)
    (hlogM : Real.log (M : ℝ) ≤ Clog + 5 * beta * Real.log T)
    (hmid : omegaMiddleTailBound q beta M ≤ z)
    (hhigh :
      4 * ((6 * q : ℕ) : ℝ) * (1 + 2 * ((6 * q : ℕ) : ℝ)) /
          ((T / (((Nat.lcm 6 q : ℕ) : ℝ) * (D : ℝ))) ^
            (3 / 4 : ℝ)) ≤ z)
    (htailD : ((D + 1 : ℕ) : ℝ) ^ (-1 / 4 : ℝ) ≤ z)
    (hbetaBudget :
      60 * ((Nat.lcm 6 q : ℕ) : ℝ) * omegaRankinBound * beta ≤ eps / 20)
    (hzBudget :
      12 * ((Nat.lcm 6 q : ℕ) : ℝ) * omegaRankinBound * z ≤ eps / 20)
    (hDBudget :
      36 * ((Nat.lcm 6 q : ℕ) : ℝ) * omegaRankinBound * z ≤ eps / 20)
    (hfixed :
      ((Nat.lcm 6 q : ℕ) : ℝ) * omegaRankinBound *
        (12 * (1 + Clog) +
          (1 / Real.pi) *
            (24 * ((6 * q : ℕ) : ℝ) *
              ((Nat.lcm 6 q : ℕ) : ℝ)) * omegaPSeriesTwo)
        ≤ (eps / 20) * Real.log T) :
    ((Nat.lcm 6 q : ℕ) : ℝ) *
        omegaR0002AdditiveMajorant q beta M H T D X
      ≤ (eps / 5) * Real.log T := by
  let L : ℝ := ((Nat.lcm 6 q : ℕ) : ℝ)
  let R : ℝ := omegaRankinBound
  let Csc : ℝ :=
    (1 / Real.pi) *
      (24 * ((6 * q : ℕ) : ℝ) * L) * omegaPSeriesTwo
  have hTpos : 0 < T := (Real.exp_pos 1).trans_le hTexp
  have hlog1 : 1 ≤ Real.log T := by
    have h := Real.log_le_log (Real.exp_pos 1) hTexp
    simpa using h
  have hlog0 : 0 ≤ Real.log T := by linarith
  have hR0 : 0 ≤ R := by
    dsimp [R]
    unfold omegaRankinBound
    positivity
  have hL0 : 0 ≤ L := by dsimp [L]; positivity
  have hLR0 : 0 ≤ L * R := mul_nonneg hL0 hR0
  have hCsc0 : 0 ≤ Csc := by
    dsimp [Csc]
    have hp : 0 ≤ omegaPSeriesTwo := omegaPSeriesTwo_nonneg
    positivity
  have hpi12 : 12 / Real.pi ≤ 12 := by
    have hp : (1 : ℝ) ≤ Real.pi := by
      linarith [Real.one_le_pi_div_two]
    rw [div_le_iff₀ Real.pi_pos]
    nlinarith
  have hlogM0 : 0 ≤ Real.log (M : ℝ) :=
    Real.log_nonneg (by exact_mod_cast hM1)
  have hlow :
      omegaR0002LowBlockBound M ≤
        12 * (1 + Clog) + 60 * beta * Real.log T := by
    unfold omegaR0002LowBlockBound
    calc
      (12 / Real.pi) * (1 + Real.log (M : ℝ))
        ≤ 12 * (1 + Real.log (M : ℝ)) :=
          mul_le_mul_of_nonneg_right hpi12
            (add_nonneg zero_le_one hlogM0)
      _ ≤ 12 * (1 + (Clog + 5 * beta * Real.log T)) := by
          exact mul_le_mul_of_nonneg_left
            (_root_.add_le_add le_rfl hlogM) (by norm_num)
      _ = 12 * (1 + Clog) + 60 * beta * Real.log T := by ring
  have hfour :=
    omegaFourierCoeffPairMassBound_le_six_log hTexp hHT
  have hfour0 := omegaFourierCoeffPairMassBound_nonneg H
  have hsixlog0 : 0 ≤ 6 * Real.log T := by positivity
  have hmid0 := omegaMiddleTailBound_nonneg q hb0 M (by omega)
  have hLpos : 0 < L := by
    dsimp [L]
    exact_mod_cast Nat.lcm_pos (by norm_num) hq
  have hDpos : (0 : ℝ) < D := by exact_mod_cast (show 0 < D by omega)
  have hbasepos :
      0 < T / (L * (D : ℝ)) := by positivity
  have hhigh0 :
      0 ≤
        4 * ((6 * q : ℕ) : ℝ) * (1 + 2 * ((6 * q : ℕ) : ℝ)) /
          ((T / (L * (D : ℝ))) ^ (3 / 4 : ℝ)) := by
    positivity
  have hmidhigh :
      omegaMiddleTailBound q beta M +
          4 * ((6 * q : ℕ) : ℝ) * (1 + 2 * ((6 * q : ℕ) : ℝ)) /
            ((T / (L * (D : ℝ))) ^ (3 / 4 : ℝ))
        ≤ 2 * z := by
    dsimp [L] at hhigh0 ⊢
    have := _root_.add_le_add hmid hhigh
    linarith
  have hmidhigh0 :
      0 ≤ omegaMiddleTailBound q beta M +
          4 * ((6 * q : ℕ) : ℝ) * (1 + 2 * ((6 * q : ℕ) : ℝ)) /
            ((T / (L * (D : ℝ))) ^ (3 / 4 : ℝ)) := by
    exact add_nonneg hmid0 hhigh0
  have hsmall :
      omegaSmallDivisorTailBound q beta M H T D
        ≤ 12 * z * Real.log T + Csc := by
    unfold omegaSmallDivisorTailBound
    change
      omegaFourierCoeffPairMassBound H *
          (omegaMiddleTailBound q beta M +
            4 * ((6 * q : ℕ) : ℝ) * (1 + 2 * ((6 * q : ℕ) : ℝ)) /
              ((T / (L * (D : ℝ))) ^ (3 / 4 : ℝ))) +
        Csc
      ≤ 12 * z * Real.log T + Csc
    have hprod :
        omegaFourierCoeffPairMassBound H *
            (omegaMiddleTailBound q beta M +
              4 * ((6 * q : ℕ) : ℝ) * (1 + 2 * ((6 * q : ℕ) : ℝ)) /
                ((T / (L * (D : ℝ))) ^ (3 / 4 : ℝ)))
          ≤ (6 * Real.log T) * (2 * z) := by
      exact mul_le_mul hfour hmidhigh hmidhigh0 hsixlog0
    calc
      omegaFourierCoeffPairMassBound H *
            (omegaMiddleTailBound q beta M +
              4 * ((6 * q : ℕ) : ℝ) * (1 + 2 * ((6 * q : ℕ) : ℝ)) /
                ((T / (L * (D : ℝ))) ^ (3 / 4 : ℝ))) + Csc
        ≤ (6 * Real.log T) * (2 * z) + Csc :=
          _root_.add_le_add hprod le_rfl
      _ = 12 * z * Real.log T + Csc := by ring
  have hlarge :=
    omegaR0002LargeDivisorBranchBound_le_36_log hTexp hXT
  have hlarge0 := omegaR0002LargeDivisorBranchBound_nonneg X
  have htail0 :
      0 ≤ ((D + 1 : ℕ) : ℝ) ^ (-1 / 4 : ℝ) := by positivity
  have hsmall0 : 0 ≤ omegaSmallDivisorTailBound q beta M H T D := by
    unfold omegaSmallDivisorTailBound
    positivity
  have hlow0 := omegaR0002LowBlockBound_nonneg M hM1
  have hmain :
      L * omegaR0002AdditiveMajorant q beta M H T D X
        ≤
        L * R * (12 * (1 + Clog) + Csc) +
          (60 * L * R * beta) * Real.log T +
          (12 * L * R * z) * Real.log T +
          (36 * L * R * z) * Real.log T := by
    unfold omegaR0002AdditiveMajorant
    change
      L * (R * (omegaR0002LowBlockBound M +
          omegaSmallDivisorTailBound q beta M H T D) +
        ((D + 1 : ℕ) : ℝ) ^ (-1 / 4 : ℝ) * R *
          omegaR0002LargeDivisorBranchBound X) ≤ _
    have hls := _root_.add_le_add hlow hsmall
    have hls0 :
        0 ≤ omegaR0002LowBlockBound M +
          omegaSmallDivisorTailBound q beta M H T D :=
      add_nonneg hlow0 hsmall0
    have hsmallMain :
        L * R *
            (omegaR0002LowBlockBound M +
              omegaSmallDivisorTailBound q beta M H T D)
          ≤
        L * R *
          ((12 * (1 + Clog) + 60 * beta * Real.log T) +
            (12 * z * Real.log T + Csc)) :=
      mul_le_mul_of_nonneg_left hls hLR0
    have htailR :
        ((D + 1 : ℕ) : ℝ) ^ (-1 / 4 : ℝ) * R *
            omegaR0002LargeDivisorBranchBound X
          ≤ z * R * (36 * Real.log T) := by
      have hzr :
          ((D + 1 : ℕ) : ℝ) ^ (-1 / 4 : ℝ) * R ≤ z * R :=
        mul_le_mul_of_nonneg_right htailD hR0
      exact mul_le_mul hzr hlarge hlarge0
        (mul_nonneg hz0 hR0)
    have htailMain :
        L * (((D + 1 : ℕ) : ℝ) ^ (-1 / 4 : ℝ) * R *
            omegaR0002LargeDivisorBranchBound X)
          ≤ L * (z * R * (36 * Real.log T)) :=
      mul_le_mul_of_nonneg_left htailR hL0
    calc
      L * (R * (omegaR0002LowBlockBound M +
          omegaSmallDivisorTailBound q beta M H T D) +
        ((D + 1 : ℕ) : ℝ) ^ (-1 / 4 : ℝ) * R *
          omegaR0002LargeDivisorBranchBound X)
        =
        L * R *
            (omegaR0002LowBlockBound M +
              omegaSmallDivisorTailBound q beta M H T D) +
          L * (((D + 1 : ℕ) : ℝ) ^ (-1 / 4 : ℝ) * R *
            omegaR0002LargeDivisorBranchBound X) := by ring
      _ ≤
        L * R *
          ((12 * (1 + Clog) + 60 * beta * Real.log T) +
            (12 * z * Real.log T + Csc)) +
          L * (z * R * (36 * Real.log T)) :=
            _root_.add_le_add hsmallMain htailMain
      _ =
        L * R * (12 * (1 + Clog) + Csc) +
          (60 * L * R * beta) * Real.log T +
          (12 * L * R * z) * Real.log T +
          (36 * L * R * z) * Real.log T := by ring
  have hfix' :
      L * R * (12 * (1 + Clog) + Csc)
        ≤ (eps / 20) * Real.log T := by
    simpa [L, R, Csc, mul_assoc] using hfixed
  have hb' :
      (60 * L * R * beta) * Real.log T
        ≤ (eps / 20) * Real.log T :=
    mul_le_mul_of_nonneg_right
      (by simpa [L, R, mul_assoc] using hbetaBudget) hlog0
  have hz' :
      (12 * L * R * z) * Real.log T
        ≤ (eps / 20) * Real.log T :=
    mul_le_mul_of_nonneg_right
      (by simpa [L, R, mul_assoc] using hzBudget) hlog0
  have hD' :
      (36 * L * R * z) * Real.log T
        ≤ (eps / 20) * Real.log T :=
    mul_le_mul_of_nonneg_right
      (by simpa [L, R, mul_assoc] using hDBudget) hlog0
  calc
    L * omegaR0002AdditiveMajorant q beta M H T D X
      ≤
        L * R * (12 * (1 + Clog) + Csc) +
          (60 * L * R * beta) * Real.log T +
          (12 * L * R * z) * Real.log T +
          (36 * L * R * z) * Real.log T := hmain
    _ ≤
        (eps / 20) * Real.log T +
          (eps / 20) * Real.log T +
          (eps / 20) * Real.log T +
          (eps / 20) * Real.log T := by
      exact _root_.add_le_add
        (_root_.add_le_add (_root_.add_le_add hfix' hb') hz') hD'
    _ = (eps / 5) * Real.log T := by ring

#print axioms omegaR0002AdditiveMajorant_priced

end PaperB.Analytic


namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat Filter

lemma omega_const_le_eps_log_eventually
    (C eps : ℝ) (heps : 0 < eps) :
    ∃ T0 : ℝ, ∀ T : ℝ, T0 ≤ T → Real.exp 1 ≤ T →
      C ≤ eps * Real.log T := by
  let T0 := max (Real.exp 1) (Real.exp (C / eps))
  refine ⟨T0, ?_⟩
  intro T hT hTexp
  have hE : Real.exp (C / eps) ≤ T :=
    (le_max_right _ _).trans hT
  have hlog : C / eps ≤ Real.log T := by
    have := Real.log_le_log (Real.exp_pos (C / eps)) hE
    simpa using this
  have heps0 : 0 ≤ eps := heps.le
  have hm := mul_le_mul_of_nonneg_left hlog heps0
  field_simp [heps.ne'] at hm
  simpa [mul_comm] using hm

lemma omega_r0002_remainder_priced
    (q : ℕ) (hq : 0 < q)
    {eps delta K T : ℝ} {H X : ℕ}
    (heps : 0 < eps) (hdelta : 0 ≤ delta) (hK : 1 ≤ K)
    (hTexp : Real.exp 1 ≤ T) (hX : 1 ≤ X) (hXT : (X : ℝ) ≤ T)
    (hS : 1 < Real.sqrt T * (Real.log (2 * T)) ^ 2)
    (hH : 1 ≤ H)
    (haway :
      (Real.sqrt T * (Real.log (2 * T)) ^ 2) /
          (Real.pi ^ 2 * H) ≤ 1 / K)
    (hKbudget :
      (1 / K) *
        (((2 * (6 * q) + 10 : ℕ) : ℝ) * omegaRankinBound) ≤ eps / 2)
    (hdeltaBudget :
      (1 / 2 + 12 / Real.pi) * delta ≤ eps / 2)
    (hnear :
      petermannOmegaNearJumpMass q T (0 : ℤ) X
        (Real.sqrt T * (Real.log (2 * T)) ^ 2)
        ≤ delta * Real.log T)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ)
    (hnear_r :
      petermannOmegaNearJumpMass q T r X
        (Real.sqrt T * (Real.log (2 * T)) ^ 2)
        ≤ delta * Real.log T) :
    ‖petermannOmegaSmoothingRemainder q chi r T X H
        (Real.sqrt T * (Real.log (2 * T)) ^ 2)‖
      ≤ eps * Real.log T := by
  have hs :=
    petermannOmegaSmoothingRemainder_le_away_add_near_uniform
      hS hH q X chi r T
  have hmass := omegaPartialSum_le_const_mul_log q X hq hX T hXT hTexp
  have hlog0 : 0 ≤ Real.log T := by
    have h1 : (1 : ℝ) ≤ T := by
      have he : (1 : ℝ) ≤ Real.exp 1 := by
        rw [← Real.exp_zero]
        exact Real.exp_le_exp.mpr (by norm_num)
      exact he.trans hTexp
    exact Real.log_nonneg h1
  have hfac0 :
      0 ≤ (Real.sqrt T * (Real.log (2 * T)) ^ 2) /
        (Real.pi ^ 2 * H) := by positivity
  have hnearFac0 : 0 ≤ (1 / 2 + 12 / Real.pi) := by positivity
  calc
    ‖petermannOmegaSmoothingRemainder q chi r T X H
        (Real.sqrt T * (Real.log (2 * T)) ^ 2)‖
      ≤
      ((Real.sqrt T * (Real.log (2 * T)) ^ 2) /
          (Real.pi ^ 2 * H)) * omegaPartialSum q X +
        (1 / 2 + 12 / Real.pi) *
          petermannOmegaNearJumpMass q T r X
            (Real.sqrt T * (Real.log (2 * T)) ^ 2) := hs
    _ ≤
      ((1 / K) *
          (((2 * (6 * q) + 10 : ℕ) : ℝ) * omegaRankinBound) +
        (1 / 2 + 12 / Real.pi) * delta) * Real.log T := by
      have ha :
          ((Real.sqrt T * (Real.log (2 * T)) ^ 2) /
              (Real.pi ^ 2 * H)) * omegaPartialSum q X
          ≤
          ((1 / K) *
            (((2 * (6 * q) + 10 : ℕ) : ℝ) * omegaRankinBound)) *
              Real.log T := by
        calc
          _ ≤ ((Real.sqrt T * (Real.log (2 * T)) ^ 2) /
              (Real.pi ^ 2 * H)) *
              ((((2 * (6 * q) + 10 : ℕ) : ℝ) * omegaRankinBound) *
                Real.log T) :=
            mul_le_mul_of_nonneg_left hmass hfac0
          _ ≤ (1 / K) *
              ((((2 * (6 * q) + 10 : ℕ) : ℝ) * omegaRankinBound) *
                Real.log T) := by
            apply mul_le_mul_of_nonneg_right haway
            have hR0 : 0 ≤ omegaRankinBound := by
              unfold omegaRankinBound
              positivity
            positivity
          _ = ((1 / K) *
              (((2 * (6 * q) + 10 : ℕ) : ℝ) * omegaRankinBound)) *
                Real.log T := by ring
      have hn :
          (1 / 2 + 12 / Real.pi) *
              petermannOmegaNearJumpMass q T r X
                (Real.sqrt T * (Real.log (2 * T)) ^ 2)
          ≤ ((1 / 2 + 12 / Real.pi) * delta) * Real.log T := by
        calc
          _ ≤ (1 / 2 + 12 / Real.pi) * (delta * Real.log T) :=
            mul_le_mul_of_nonneg_left hnear_r hnearFac0
          _ = ((1 / 2 + 12 / Real.pi) * delta) * Real.log T := by ring
      calc
        _ ≤
          ((1 / K) *
              (((2 * (6 * q) + 10 : ℕ) : ℝ) * omegaRankinBound)) *
              Real.log T +
            ((1 / 2 + 12 / Real.pi) * delta) * Real.log T :=
          _root_.add_le_add ha hn
        _ = _ := by ring
    _ ≤ (eps / 2 + eps / 2) * Real.log T := by
      exact mul_le_mul_of_nonneg_right
        (_root_.add_le_add hKbudget hdeltaBudget) hlog0
    _ = eps * Real.log T := by ring

#print axioms omega_const_le_eps_log_eventually
#print axioms omega_r0002_remainder_priced

end PaperB.Analytic

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Nat

lemma omegaRankinBound_pos : 0 < omegaRankinBound := by
  unfold omegaRankinBound
  positivity

lemma omega_r0002_choose_beta
    (q : ℕ) (hq : 0 < q) (eps : ℝ) (heps : 0 < eps) :
    ∃ beta : ℝ,
      0 < beta ∧ beta < 1 ∧
      60 * ((Nat.lcm 6 q : ℕ) : ℝ) * omegaRankinBound * beta ≤ eps / 20 ∧
      (5 / 2 : ℝ) * omegaRankinBound * beta ≤ eps / 2 := by
  let L : ℝ := ((Nat.lcm 6 q : ℕ) : ℝ)
  let R : ℝ := omegaRankinBound
  let beta : ℝ := min (1 / 10) (eps / (4800 * L * R))
  have hL : 0 < L := by
    dsimp [L]
    exact_mod_cast Nat.lcm_pos (by norm_num) hq
  have hR : 0 < R := by simpa [R] using omegaRankinBound_pos
  have hb2 : 0 < eps / (4800 * L * R) := by positivity
  have hb : 0 < beta := by
    dsimp [beta]
    exact lt_min (by norm_num) hb2
  have hb1 : beta < 1 := by
    have : beta ≤ (1 / 10 : ℝ) := min_le_left _ _
    linarith
  have hcap : beta ≤ eps / (4800 * L * R) := by
    dsimp [beta]
    exact min_le_right _ _
  have hLR : 0 < 4800 * L * R := by positivity
  have hmul := mul_le_mul_of_nonneg_left hcap hLR.le
  have hcalc : (4800 * L * R) * beta ≤ eps := by
    calc
      (4800 * L * R) * beta
        ≤ (4800 * L * R) * (eps / (4800 * L * R)) := hmul
      _ = eps := by field_simp [hLR.ne']
  have hbudget1 :
      60 * L * R * beta ≤ eps / 20 := by
    linarith
  have hL1 : 1 ≤ L := by
    dsimp [L]
    exact_mod_cast (Nat.one_le_iff_ne_zero.mpr
      (Nat.ne_of_gt (Nat.lcm_pos (by norm_num) hq)))
  have hbudget2 :
      (5 / 2 : ℝ) * R * beta ≤ eps / 2 := by
    have hweak : 5 * R * beta ≤ eps := by
      have hpos : 0 ≤ R * beta := mul_nonneg hR.le hb.le
      have hbig : 5 * R * beta ≤ 4800 * L * R * beta := by
        nlinarith
      exact hbig.trans hcalc
    linarith
  exact ⟨beta, hb, hb1, by simpa [L, R, mul_assoc] using hbudget1,
    by simpa [R, mul_assoc] using hbudget2⟩

lemma omega_r0002_choose_z
    (q : ℕ) (hq : 0 < q) (eps : ℝ) (heps : 0 < eps) :
    ∃ z : ℝ,
      0 < z ∧
      12 * ((Nat.lcm 6 q : ℕ) : ℝ) * omegaRankinBound * z ≤ eps / 20 ∧
      36 * ((Nat.lcm 6 q : ℕ) : ℝ) * omegaRankinBound * z ≤ eps / 20 := by
  let L : ℝ := ((Nat.lcm 6 q : ℕ) : ℝ)
  let R : ℝ := omegaRankinBound
  let z : ℝ := eps / (1440 * L * R)
  have hL : 0 < L := by
    dsimp [L]
    exact_mod_cast Nat.lcm_pos (by norm_num) hq
  have hR : 0 < R := by simpa [R] using omegaRankinBound_pos
  have hden : 0 < 1440 * L * R := by positivity
  have hz : 0 < z := by dsimp [z]; positivity
  have heq : (1440 * L * R) * z = eps := by
    dsimp [z]
    field_simp [hden.ne']
  have h12 : 12 * L * R * z ≤ eps / 20 := by
    nlinarith
  have h36 : 36 * L * R * z ≤ eps / 20 := by
    nlinarith
  exact ⟨z, hz, by simpa [L, R, mul_assoc] using h12,
    by simpa [L, R, mul_assoc] using h36⟩

lemma omega_r0002_choose_K
    (q : ℕ) (eps : ℝ) (heps : 0 < eps) :
    ∃ K : ℝ, 1 ≤ K ∧
      (1 / K) *
        (((2 * (6 * q) + 10 : ℕ) : ℝ) * omegaRankinBound)
        ≤ (4 * eps / 5) / 2 := by
  let C : ℝ :=
    (((2 * (6 * q) + 10 : ℕ) : ℝ) * omegaRankinBound)
  let K : ℝ := 1 + 5 * C / (2 * eps)
  have hC : 0 ≤ C := by
    dsimp [C]
    exact mul_nonneg (by positivity) omegaRankinBound_pos.le
  have hfrac : 0 ≤ 5 * C / (2 * eps) := by
    exact div_nonneg (mul_nonneg (by norm_num) hC) (by positivity)
  have hK : 1 ≤ K := by
    dsimp [K]
    linarith
  have hKpos : 0 < K := lt_of_lt_of_le zero_lt_one hK
  refine ⟨K, hK, ?_⟩
  change (1 / K) * C ≤ (4 * eps / 5) / 2
  have hterm : 5 * C / (2 * eps) ≤ K := by
    dsimp [K]
    linarith
  have hscale : 0 ≤ 2 * eps / 5 := by positivity
  have hmul := mul_le_mul_of_nonneg_left hterm hscale
  have hCKmul : C ≤ (2 * eps / 5) * K := by
    calc
      C = (2 * eps / 5) * (5 * C / (2 * eps)) := by
        field_simp [heps.ne']
      _ ≤ (2 * eps / 5) * K := hmul
  have hCK : C / K ≤ 2 * eps / 5 := by
    exact (div_le_iff₀ hKpos).2 (by simpa [mul_comm] using hCKmul)
  calc
    (1 / K) * C = C / K := by ring
    _ ≤ 2 * eps / 5 := hCK
    _ = (4 * eps / 5) / 2 := by ring

#print axioms omegaRankinBound_pos
#print axioms omega_r0002_choose_beta
#print axioms omega_r0002_choose_z
#print axioms omega_r0002_choose_K

end PaperB.Analytic

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat Filter

lemma petermannOmega_short_branch_priced
    (q : ℕ) (hq : 0 < q)
    {eps beta T Clog : ℝ} {M D X : ℕ}
    (heps : 0 < eps) (hb0 : 0 ≤ beta)
    (hTexp : Real.exp 1 ≤ T)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ)
    (hX : 1 ≤ X)
    (hshort : X < M * D)
    (hM1 : 1 ≤ M) (hD1 : 1 ≤ D)
    (hlogM :
      Real.log (M : ℝ) ≤ Clog + 5 * beta * Real.log T)
    (hbeta :
      (5 / 2 : ℝ) * omegaRankinBound * beta ≤ eps / 2)
    (hconst :
      (1 / 2 : ℝ) *
        (omegaRankinBound * (Clog + Real.log (D : ℝ)) +
          ((2 * (6 * q) + 9 : ℕ) : ℝ) * omegaRankinBound)
        ≤ (eps / 2) * Real.log T) :
    ‖petermannBaseKernelSum
        q PetermannBase.omega chi r T X‖
      ≤ eps * Real.log T := by
  have hT1 : (1 : ℝ) ≤ T := by
    have he : (1 : ℝ) ≤ Real.exp 1 := by
      rw [← Real.exp_zero]
      exact Real.exp_le_exp.mpr (by norm_num)
    exact he.trans hTexp
  have hlog0 : 0 ≤ Real.log T := Real.log_nonneg hT1
  have hXpos : (0 : ℝ) < X := by exact_mod_cast (show 0 < X by omega)
  have hMpos : (0 : ℝ) < M := by exact_mod_cast (show 0 < M by omega)
  have hDpos : (0 : ℝ) < D := by exact_mod_cast (show 0 < D by omega)
  have hXMD : (X : ℝ) ≤ ((M * D : ℕ) : ℝ) := by
    exact_mod_cast (Nat.le_of_lt hshort)
  have hlogXMD :
      Real.log (X : ℝ) ≤
        Real.log (M : ℝ) + Real.log (D : ℝ) := by
    have h := Real.log_le_log hXpos hXMD
    have hmul :
        Real.log (((M * D : ℕ) : ℝ)) =
          Real.log (M : ℝ) + Real.log (D : ℝ) := by
      push_cast
      rw [Real.log_mul hMpos.ne' hDpos.ne']
    rw [hmul] at h
    exact h
  have hlogX :
      Real.log (X : ℝ) ≤
        Clog + Real.log (D : ℝ) + 5 * beta * Real.log T := by
    linarith
  have hR0 : 0 ≤ omegaRankinBound := omegaRankinBound_pos.le
  have hpartial := omegaPartialSum_le_rankin_log_add_const q X hq hX
  have hpartial' :
      omegaPartialSum q X ≤
        omegaRankinBound * (Clog + Real.log (D : ℝ)) +
          ((2 * (6 * q) + 9 : ℕ) : ℝ) * omegaRankinBound +
          (5 * omegaRankinBound * beta) * Real.log T := by
    calc
      omegaPartialSum q X
        ≤ omegaRankinBound * Real.log (X : ℝ) +
            ((2 * (6 * q) + 9 : ℕ) : ℝ) * omegaRankinBound := hpartial
      _ ≤ omegaRankinBound *
              (Clog + Real.log (D : ℝ) + 5 * beta * Real.log T) +
            ((2 * (6 * q) + 9 : ℕ) : ℝ) * omegaRankinBound := by
          exact _root_.add_le_add
            (mul_le_mul_of_nonneg_left hlogX hR0) le_rfl
      _ = omegaRankinBound * (Clog + Real.log (D : ℝ)) +
            ((2 * (6 * q) + 9 : ℕ) : ℝ) * omegaRankinBound +
            (5 * omegaRankinBound * beta) * Real.log T := by ring
  have hbase :=
    norm_petermannBaseKernelSum_omega_le_half_partial
      q chi r T X
  have hbetalog :
      ((5 / 2 : ℝ) * omegaRankinBound * beta) * Real.log T
        ≤ (eps / 2) * Real.log T :=
    mul_le_mul_of_nonneg_right hbeta hlog0
  calc
    ‖petermannBaseKernelSum q PetermannBase.omega chi r T X‖
      ≤ (1 / 2 : ℝ) * omegaPartialSum q X := hbase
    _ ≤ (1 / 2 : ℝ) *
        (omegaRankinBound * (Clog + Real.log (D : ℝ)) +
          ((2 * (6 * q) + 9 : ℕ) : ℝ) * omegaRankinBound +
          (5 * omegaRankinBound * beta) * Real.log T) :=
      mul_le_mul_of_nonneg_left hpartial' (by norm_num)
    _ =
      (1 / 2 : ℝ) *
        (omegaRankinBound * (Clog + Real.log (D : ℝ)) +
          ((2 * (6 * q) + 9 : ℕ) : ℝ) * omegaRankinBound) +
      ((5 / 2 : ℝ) * omegaRankinBound * beta) * Real.log T := by ring
    _ ≤ (eps / 2) * Real.log T + (eps / 2) * Real.log T :=
      _root_.add_le_add hconst hbetalog
    _ = eps * Real.log T := by ring

#print axioms petermannOmega_short_branch_priced

end PaperB.Analytic

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat Filter

lemma omega_eventually_log_sq_le_rpow_quarter :
    ∀ᶠ t : ℝ in atTop,
      (Real.log t) ^ 2 ≤ t ^ (1 / 4 : ℝ) := by
  have ho :=
    (isLittleO_log_rpow_rpow_atTop 2
      (show (0 : ℝ) < 1 / 4 by norm_num)).bound
      (show (0 : ℝ) < 1 by norm_num)
  filter_upwards [ho, eventually_ge_atTop (1 : ℝ)] with t ht ht1
  have hlog0 : 0 ≤ Real.log t := Real.log_nonneg ht1
  have hlogsq0 : 0 ≤ (Real.log t) ^ 2 := sq_nonneg _
  have hpow0 : 0 ≤ t ^ (1 / 4 : ℝ) := Real.rpow_nonneg (by linarith) _
  have hlogrpow0 : 0 ≤ (Real.log t) ^ (2 : ℝ) :=
    Real.rpow_nonneg hlog0 _
  have hleft : ‖(Real.log t) ^ (2 : ℝ)‖ = (Real.log t) ^ (2 : ℝ) :=
    Real.norm_of_nonneg hlogrpow0
  have hright : ‖t ^ (1 / 4 : ℝ)‖ = t ^ (1 / 4 : ℝ) :=
    Real.norm_of_nonneg hpow0
  have hrpow :
      (Real.log t) ^ (2 : ℝ) ≤ t ^ (1 / 4 : ℝ) := by
    calc
      (Real.log t) ^ (2 : ℝ) = ‖(Real.log t) ^ (2 : ℝ)‖ := hleft.symm
      _ ≤ 1 * ‖t ^ (1 / 4 : ℝ)‖ := ht
      _ = t ^ (1 / 4 : ℝ) := by rw [hright, one_mul]
  calc
    (Real.log t) ^ 2 = (Real.log t) ^ (2 : ℝ) := by
      exact (Real.rpow_natCast (Real.log t) 2).symm
    _ ≤ t ^ (1 / 4 : ℝ) := hrpow


lemma omegaCanonicalS_le_two_rpow_three_fourths_eventually :
    ∃ T0 : ℝ, ∀ T : ℝ, T0 ≤ T → 1 ≤ T →
      Real.sqrt T * (Real.log (2 * T)) ^ 2 ≤
        2 * T ^ (3 / 4 : ℝ) := by
  have hev := omega_eventually_log_sq_le_rpow_quarter
  rw [eventually_atTop] at hev
  obtain ⟨W0, hW0⟩ := hev
  refine ⟨max W0 1, ?_⟩
  intro T hT0 hT1
  have hT : 0 < T := lt_of_lt_of_le zero_lt_one hT1
  have hW : W0 ≤ 2 * T := by
    have hWT : W0 ≤ T := (le_max_left _ _).trans hT0
    nlinarith
  have hlog := hW0 (2 * T) hW
  have hmul :
      (2 * T) ^ (1 / 4 : ℝ) =
        (2 : ℝ) ^ (1 / 4 : ℝ) * T ^ (1 / 4 : ℝ) := by
    rw [Real.mul_rpow (by norm_num : (0 : ℝ) ≤ 2) hT.le]
  have hpow2 : (2 : ℝ) ^ (1 / 4 : ℝ) ≤ 2 := by
    simpa using
      (Real.rpow_le_rpow_of_exponent_le
        (by norm_num : (1 : ℝ) ≤ 2)
        (by norm_num : (1 / 4 : ℝ) ≤ 1))
  have hquarter0 : 0 ≤ T ^ (1 / 4 : ℝ) :=
    Real.rpow_nonneg hT.le _
  rw [hmul] at hlog
  have hlogsq :
      (Real.log (2 * T)) ^ 2 ≤
        2 * T ^ (1 / 4 : ℝ) :=
    hlog.trans (mul_le_mul_of_nonneg_right hpow2 hquarter0)
  rw [Real.sqrt_eq_rpow]
  calc
    T ^ (1 / 2 : ℝ) * (Real.log (2 * T)) ^ 2
      ≤ T ^ (1 / 2 : ℝ) * (2 * T ^ (1 / 4 : ℝ)) :=
        mul_le_mul_of_nonneg_left hlogsq (Real.rpow_nonneg hT.le _)
    _ = 2 * (T ^ (1 / 2 : ℝ) * T ^ (1 / 4 : ℝ)) := by ring
    _ = 2 * T ^ (3 / 4 : ℝ) := by
      rw [← Real.rpow_add hT]
      norm_num

lemma omegaCanonicalH_le_T_eventually
    (K : ℝ) (hK1 : 1 ≤ K) :
    ∃ T0 : ℝ, ∀ T : ℝ, T0 ≤ T → 1 ≤ T →
      let S := Real.sqrt T * (Real.log (2 * T)) ^ 2
      let H : ℕ := ⌈K * S⌉₊
      (H : ℝ) ≤ T := by
  obtain ⟨TS, hS⟩ :=
    omegaCanonicalS_le_two_rpow_three_fourths_eventually
  have hC : 0 ≤ 4 * K := by positivity
  obtain ⟨W0, hW0⟩ :=
    const_mul_rpow_lt_one_is_sublinear
      (C := 4 * K) (theta := (3 / 4 : ℝ)) (eps := 1)
      hC (by norm_num) (by norm_num)
  refine ⟨max TS (max W0 2), ?_⟩
  intro T hT0 hT1
  dsimp only
  let S : ℝ := Real.sqrt T * (Real.log (2 * T)) ^ 2
  let H : ℕ := ⌈K * S⌉₊
  have hTS : TS ≤ T :=
    (le_max_left TS (max W0 2)).trans hT0
  have hW : W0 ≤ T := by
    have : W0 ≤ max W0 2 := le_max_left _ _
    exact (this.trans (le_max_right TS (max W0 2))).trans hT0
  have hT2 : (2 : ℝ) ≤ T := by
    have : (2 : ℝ) ≤ max W0 2 := le_max_right _ _
    exact (this.trans (le_max_right TS (max W0 2))).trans hT0
  have hSbound : S ≤ 2 * T ^ (3 / 4 : ℝ) := by
    dsimp [S]
    exact hS T hTS hT1
  have hK0 : 0 ≤ K := le_trans zero_le_one hK1
  have hKS :
      K * S ≤ 2 * K * T ^ (3 / 4 : ℝ) := by
    have hm := mul_le_mul_of_nonneg_left hSbound hK0
    nlinarith
  have hsub := hW0 T hW hT1
  have hhalf :
      2 * K * T ^ (3 / 4 : ℝ) ≤ T / 2 := by
    have : 4 * K * T ^ (3 / 4 : ℝ) ≤ T := by
      simpa using hsub
    linarith
  have hceil :
      (H : ℝ) ≤ K * S + 1 := by
    dsimp [H]
    exact (Nat.ceil_lt_add_one
      (mul_nonneg hK0 (by dsimp [S]; positivity))).le
  calc
    (H : ℝ) ≤ K * S + 1 := hceil
    _ ≤ T / 2 + 1 :=
      _root_.add_le_add (hKS.trans hhalf) le_rfl
    _ ≤ T := by linarith

lemma omega_r0002_source_bound_two_beta
    {T beta : ℝ} (hT1 : 1 ≤ T) (hb0 : 0 ≤ beta)
    {H Mfix : ℕ} (hHT : (H : ℝ) ≤ T) :
    (((H : ℝ) * T) ^ beta) ≤
      ((max Mfix ⌈T ^ (2 * beta)⌉₊ : ℕ) : ℝ) := by
  have hT : 0 < T := lt_of_lt_of_le zero_lt_one hT1
  have hp : (H : ℝ) * T ≤ T ^ 2 := by
    nlinarith
  have hr := Real.rpow_le_rpow
    (by positivity : 0 ≤ (H : ℝ) * T) hp hb0
  have heq : (T ^ (2 : ℕ)) ^ beta = T ^ (2 * beta) := by
    rw [← Real.rpow_natCast]
    rw [Real.rpow_mul hT.le]
    norm_num
  rw [heq] at hr
  have hceil :
      T ^ (2 * beta) ≤ ((⌈T ^ (2 * beta)⌉₊ : ℕ) : ℝ) :=
    Nat.le_ceil _
  have hmax :
      ((⌈T ^ (2 * beta)⌉₊ : ℕ) : ℝ) ≤
        ((max Mfix ⌈T ^ (2 * beta)⌉₊ : ℕ) : ℝ) := by
    exact_mod_cast (le_max_right Mfix ⌈T ^ (2 * beta)⌉₊)
  exact hr.trans (hceil.trans hmax)

lemma omega_log_max_ceil_rpow_two_beta_le
    {T beta : ℝ} (hT1 : 1 ≤ T) (hb0 : 0 ≤ beta)
    (Mfix : ℕ) (hMfix : 1 ≤ Mfix) :
    let M := max Mfix ⌈T ^ (2 * beta)⌉₊
    Real.log (M : ℝ) ≤
      Real.log ((Mfix + 2 : ℕ) : ℝ) + 2 * beta * Real.log T := by
  dsimp only
  let x : ℝ := T ^ (2 * beta)
  have hTpos : 0 < T := lt_of_lt_of_le zero_lt_one hT1
  have hexp : 0 ≤ 2 * beta := by positivity
  have hx1 : 1 ≤ x := by
    dsimp [x]
    exact Real.one_le_rpow hT1 hexp
  have hx0 : 0 ≤ x := le_trans zero_le_one hx1
  have hceil : ((⌈x⌉₊ : ℕ) : ℝ) ≤ x + 1 :=
    (Nat.ceil_lt_add_one hx0).le
  have hmaxNat :
      max Mfix ⌈x⌉₊ ≤ Mfix + ⌈x⌉₊ :=
    max_le (Nat.le_add_right _ _) (Nat.le_add_left _ _)
  have hmaxCast :
      ((max Mfix ⌈x⌉₊ : ℕ) : ℝ) ≤ (Mfix : ℝ) + x + 1 := by
    have hc : ((max Mfix ⌈x⌉₊ : ℕ) : ℝ) ≤
        ((Mfix + ⌈x⌉₊ : ℕ) : ℝ) := by exact_mod_cast hmaxNat
    calc
      ((max Mfix ⌈x⌉₊ : ℕ) : ℝ)
        ≤ ((Mfix + ⌈x⌉₊ : ℕ) : ℝ) := hc
      _ = (Mfix : ℝ) + ((⌈x⌉₊ : ℕ) : ℝ) := by push_cast; rfl
      _ ≤ (Mfix : ℝ) + (x + 1) := _root_.add_le_add le_rfl hceil
      _ = (Mfix : ℝ) + x + 1 := by ring
  have hprod :
      (Mfix : ℝ) + x + 1 ≤ ((Mfix + 2 : ℕ) : ℝ) * x := by
    push_cast
    nlinarith
  have hupper :
      ((max Mfix ⌈x⌉₊ : ℕ) : ℝ) ≤
        ((Mfix + 2 : ℕ) : ℝ) * x :=
    hmaxCast.trans hprod
  have hmaxPos : (0 : ℝ) < (max Mfix ⌈x⌉₊ : ℕ) := by
    exact_mod_cast (show 0 < max Mfix ⌈x⌉₊ by
      exact lt_of_lt_of_le (lt_of_lt_of_le Nat.zero_lt_one hMfix)
        (le_max_left _ _))
  have hCpos : (0 : ℝ) < (Mfix + 2 : ℕ) := by positivity
  have hxpos : 0 < x := lt_of_lt_of_le zero_lt_one hx1
  calc
    Real.log ((max Mfix ⌈T ^ (2 * beta)⌉₊ : ℕ) : ℝ)
      = Real.log ((max Mfix ⌈x⌉₊ : ℕ) : ℝ) := by rfl
    _ ≤ Real.log (((Mfix + 2 : ℕ) : ℝ) * x) :=
      Real.log_le_log hmaxPos hupper
    _ = Real.log ((Mfix + 2 : ℕ) : ℝ) + Real.log x := by
      rw [Real.log_mul (ne_of_gt hCpos) (ne_of_gt hxpos)]
    _ = Real.log ((Mfix + 2 : ℕ) : ℝ) +
        2 * beta * Real.log T := by
      dsimp [x]
      rw [Real.log_rpow hTpos]

theorem omega_short_kernel_sublog_two_beta
    (q : ℕ) (hq : 0 < q)
    {eps beta : ℝ} (heps : 0 < eps) (hb0 : 0 ≤ beta)
    (Mfix D : ℕ) (hMfix : 1 ≤ Mfix) (hD : 1 ≤ D)
    (hbeta : omegaRankinBound * beta ≤ eps / 2) :
    ∃ T0 : ℝ, ∀
      (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
      (r : ℤ) (T : ℝ) (X : ℕ),
      T0 ≤ T →
      Real.exp 1 ≤ T →
      1 ≤ X →
      (X : ℝ) ≤ T →
      X < (max Mfix ⌈T ^ (2 * beta)⌉₊) * D →
      ‖petermannBaseKernelSum q PetermannBase.omega chi r T X‖
        ≤ eps * Real.log T := by
  let R : ℝ := omegaRankinBound
  let Clog : ℝ :=
    Real.log ((Mfix + 2 : ℕ) : ℝ) + Real.log (D : ℝ)
  let Cq : ℝ :=
    ((2 * (6 * q) + 9 : ℕ) : ℝ) * omegaRankinBound
  let Cfix : ℝ := (1 / 2 : ℝ) * (R * Clog + Cq)
  obtain ⟨T0, hT0⟩ :=
    omega_const_le_eps_log_eventually Cfix (eps / 2) (by positivity)
  refine ⟨T0, ?_⟩
  intro chi r T X hT hTexp hX hXT hshort
  have hT1 : (1 : ℝ) ≤ T := by
    have he : (1 : ℝ) ≤ Real.exp 1 := by
      rw [← Real.exp_zero]
      exact Real.exp_le_exp.mpr (by norm_num)
    exact he.trans hTexp
  have hlogT0 : 0 ≤ Real.log T := Real.log_nonneg hT1
  have hlogM :=
    omega_log_max_ceil_rpow_two_beta_le
      hT1 hb0 Mfix hMfix
  let M : ℕ := max Mfix ⌈T ^ (2 * beta)⌉₊
  have hM1 : 1 ≤ M := hMfix.trans (le_max_left _ _)
  have hXpos : (0 : ℝ) < X := by exact_mod_cast (show 0 < X by omega)
  have hMr : (0 : ℝ) < M := by exact_mod_cast (show 0 < M by omega)
  have hDr : (0 : ℝ) < D := by exact_mod_cast (show 0 < D by omega)
  have hXMD : (X : ℝ) ≤ ((M * D : ℕ) : ℝ) := by
    exact_mod_cast (Nat.le_of_lt hshort)
  have hlogXMD := Real.log_le_log hXpos hXMD
  have hmul :
      Real.log (((M * D : ℕ) : ℝ)) =
        Real.log (M : ℝ) + Real.log (D : ℝ) := by
    push_cast
    rw [Real.log_mul hMr.ne' hDr.ne']
  rw [hmul] at hlogXMD
  dsimp [M] at hlogM
  have hlogX :
      Real.log (X : ℝ) ≤ Clog + 2 * beta * Real.log T := by
    dsimp [Clog]
    linarith
  have hpartial := omegaPartialSum_le_rankin_log_add_const q X hq hX
  have hnorm :=
    norm_petermannBaseKernelSum_omega_le_half_partial q chi r T X
  have hR0 : 0 ≤ R := by
    dsimp [R]
    exact omegaRankinBound_pos.le
  have hpartial' :
      omegaPartialSum q X ≤
        R * (Clog + 2 * beta * Real.log T) + Cq := by
    dsimp [R, Cq]
    calc
      omegaPartialSum q X
        ≤ omegaRankinBound * Real.log X +
            ((2 * (6 * q) + 9 : ℕ) : ℝ) * omegaRankinBound := hpartial
      _ ≤ omegaRankinBound * (Clog + 2 * beta * Real.log T) +
            ((2 * (6 * q) + 9 : ℕ) : ℝ) * omegaRankinBound := by
          exact _root_.add_le_add
            (mul_le_mul_of_nonneg_left hlogX omegaRankinBound_pos.le) le_rfl
  have hconst : Cfix ≤ (eps / 2) * Real.log T :=
    hT0 T hT hTexp
  have hbeta' :
      R * beta * Real.log T ≤ (eps / 2) * Real.log T := by
    exact mul_le_mul_of_nonneg_right
      (by simpa [R] using hbeta) hlogT0
  calc
    ‖petermannBaseKernelSum q PetermannBase.omega chi r T X‖
      ≤ (1 / 2 : ℝ) * omegaPartialSum q X := hnorm
    _ ≤ (1 / 2 : ℝ) *
        (R * (Clog + 2 * beta * Real.log T) + Cq) := by
      exact mul_le_mul_of_nonneg_left hpartial' (by norm_num)
    _ = R * beta * Real.log T + Cfix := by
      dsimp [Cfix]
      ring
    _ ≤ (eps / 2) * Real.log T + (eps / 2) * Real.log T :=
      _root_.add_le_add hbeta' hconst
    _ = eps * Real.log T := by ring

#print axioms omegaCanonicalH_le_T_eventually
#print axioms omega_short_kernel_sublog_two_beta

end PaperB.Analytic

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset Nat Filter

set_option maxHeartbeats 2000000 in
theorem petermannOmegaR0002
    (q : ℕ) (hq : 0 < q) :
    PetermannMinimalConsumerR0002Spec q PetermannBase.omega := by
  intro eps heps
  obtain ⟨beta, hb0, hb1, hbetaOuter, hbetaShort⟩ :=
    omega_r0002_choose_beta q hq eps heps
  obtain ⟨z, hz0, hzOuter, hzD⟩ :=
    omega_r0002_choose_z q hq eps heps
  obtain ⟨D, hD1, htailD⟩ :=
    exists_nat_rpow_neg_quarter_le hz0
  obtain ⟨M0, hM0⟩ :=
    omegaMiddleTailBound_eventually_le q hq hb0 hz0
  obtain ⟨Mseed, hMseed⟩ := exists_nat_ge M0
  let Mfix : ℕ := max 2 (max (fixedBetaNaturalOrder beta) Mseed)
  have hMfix2 : 2 ≤ Mfix := by
    dsimp [Mfix]
    exact le_max_left _ _
  have hMfix1 : 1 ≤ Mfix := by omega
  have hKMfix : fixedBetaNaturalOrder beta ≤ Mfix := by
    dsimp [Mfix]
    exact (le_max_left _ _).trans (le_max_right _ _)
  have hMseedfix : Mseed ≤ Mfix := by
    dsimp [Mfix]
    exact (le_max_right _ _).trans (le_max_right _ _)
  have hbetaShort2 :
      omegaRankinBound * beta ≤ eps / 2 := by
    have hnon : 0 ≤ omegaRankinBound * beta :=
      mul_nonneg omegaRankinBound_pos.le hb0.le
    nlinarith [hbetaShort]
  obtain ⟨Tshort2, hshort2⟩ :=
    omega_short_kernel_sublog_two_beta
      q hq heps hb0.le Mfix D hMfix1 hD1 hbetaShort2
  let Clog : ℝ := Real.log ((Mfix + 2 : ℕ) : ℝ)
  obtain ⟨Thigh, hThigh⟩ :=
    omegaHighResidual_eventually_le q D hq hD1 hz0
  let epsRem : ℝ := 4 * eps / 5
  have hepsRem : 0 < epsRem := by dsimp [epsRem]; positivity
  obtain ⟨K, hK1, hKbudget⟩ :=
    omega_r0002_choose_K q eps heps
  obtain ⟨TH, hHle⟩ :=
    omegaCanonicalH_le_T_eventually K hK1
  let nearFac : ℝ := 1 / 2 + 12 / Real.pi
  have hnearFac : 0 < nearFac := by
    dsimp [nearFac]
    positivity
  let delta : ℝ := (2 * eps / 5) / nearFac
  have hdelta : 0 < delta := by
    dsimp [delta]
    positivity
  have hdeltaBudget :
      nearFac * delta ≤ epsRem / 2 := by
    have heq : nearFac * delta = 2 * eps / 5 := by
      dsimp [delta]
      field_simp [hnearFac.ne']
    dsimp [epsRem]
    rw [heq]
    ring_nf
    exact le_rfl
  obtain ⟨Tnear, hnear⟩ :=
    petermannOmegaNearJumpMass_le_delta_log q hq delta hdelta
  let L : ℝ := ((Nat.lcm 6 q : ℕ) : ℝ)
  let R : ℝ := omegaRankinBound
  let Csc : ℝ :=
    (1 / Real.pi) *
      (24 * ((6 * q : ℕ) : ℝ) * L) * omegaPSeriesTwo
  let Cfixed : ℝ :=
    L * R * (12 * (1 + Clog) + Csc)
  have heps20 : 0 < eps / 20 := by positivity
  obtain ⟨Tfixed, hTfixed⟩ :=
    omega_const_le_eps_log_eventually Cfixed (eps / 20) heps20
  let Cshort : ℝ :=
    (1 / 2 : ℝ) *
      (R * (Clog + Real.log (D : ℝ)) +
        ((2 * (6 * q) + 9 : ℕ) : ℝ) * R)
  have heps2 : 0 < eps / 2 := by positivity
  obtain ⟨Tshort, hTshort⟩ :=
    omega_const_le_eps_log_eventually Cshort (eps / 2) heps2
  let P : ℝ := ((6 * q : ℕ) : ℝ)
  let Tbase : ℝ := (2 * P) ^ 2 * (L * (D : ℝ))
  let Tcanon : ℝ := 4 * K + 1
  let T0 : ℝ :=
    max (Real.exp 2)
      (max Thigh
        (max Tnear
          (max Tfixed
            (max Tshort
              (max Tbase Tcanon)))))
  let Tfinal : ℝ := max T0 (max TH Tshort2)
  refine ⟨Tfinal, ?_⟩
  intro chi r T X hTfinal h2L hX hXT
  have hT0 : T0 ≤ T :=
    (le_max_left T0 (max TH Tshort2)).trans hTfinal
  have hTHT : TH ≤ T := by
    have h1 : TH ≤ max TH Tshort2 := le_max_left _ _
    have h2 : max TH Tshort2 ≤ Tfinal := le_max_right _ _
    exact (h1.trans h2).trans hTfinal
  have hTshort2T : Tshort2 ≤ T := by
    have h1 : Tshort2 ≤ max TH Tshort2 := le_max_right _ _
    have h2 : max TH Tshort2 ≤ Tfinal := le_max_right _ _
    exact (h1.trans h2).trans hTfinal
  have hExp2 : Real.exp 2 ≤ T := by
    exact (le_max_left (Real.exp 2)
      (max Thigh (max Tnear (max Tfixed (max Tshort (max Tbase Tcanon)))))).trans hT0
  have hExp1 : Real.exp 1 ≤ T := by
    have h12 : Real.exp 1 ≤ Real.exp 2 :=
      Real.exp_le_exp.mpr (by norm_num)
    exact h12.trans hExp2
  have hT1 : (1 : ℝ) ≤ T := by
    have he : (1 : ℝ) ≤ Real.exp 1 := by
      rw [← Real.exp_zero]
      exact Real.exp_le_exp.mpr (by norm_num)
    exact he.trans hExp1
  have hTpos : 0 < T := lt_of_lt_of_le zero_lt_one hT1
  have hThighT : Thigh ≤ T := by
    have h1 : Thigh ≤
        max Thigh
          (max Tnear (max Tfixed (max Tshort (max Tbase Tcanon)))) :=
      le_max_left _ _
    have h2 :
        max Thigh
          (max Tnear (max Tfixed (max Tshort (max Tbase Tcanon))))
        ≤ T0 := le_max_right _ _
    exact (h1.trans h2).trans hT0
  have hTnearT : Tnear ≤ T := by
    have h1 : Tnear ≤
        max Tnear (max Tfixed (max Tshort (max Tbase Tcanon))) :=
      le_max_left _ _
    have h2 : max Tnear (max Tfixed (max Tshort (max Tbase Tcanon))) ≤
        max Thigh (max Tnear (max Tfixed (max Tshort (max Tbase Tcanon)))) :=
      le_max_right _ _
    have h3 : max Thigh (max Tnear (max Tfixed (max Tshort (max Tbase Tcanon)))) ≤ T0 :=
      le_max_right _ _
    exact (h1.trans h2 |>.trans h3).trans hT0
  have hTfixedT : Tfixed ≤ T := by
    have h1 : Tfixed ≤ max Tfixed (max Tshort (max Tbase Tcanon)) :=
      le_max_left _ _
    have h2 := le_max_right Tnear (max Tfixed (max Tshort (max Tbase Tcanon)))
    have h3 := le_max_right Thigh
      (max Tnear (max Tfixed (max Tshort (max Tbase Tcanon))))
    have h4 := le_max_right (Real.exp 2)
      (max Thigh (max Tnear (max Tfixed (max Tshort (max Tbase Tcanon)))))
    exact (h1.trans h2 |>.trans h3 |>.trans h4).trans hT0
  have hTshortT : Tshort ≤ T := by
    have h1 : Tshort ≤ max Tshort (max Tbase Tcanon) := le_max_left _ _
    have h2 := le_max_right Tfixed (max Tshort (max Tbase Tcanon))
    have h3 := le_max_right Tnear (max Tfixed (max Tshort (max Tbase Tcanon)))
    have h4 := le_max_right Thigh
      (max Tnear (max Tfixed (max Tshort (max Tbase Tcanon))))
    have h5 := le_max_right (Real.exp 2)
      (max Thigh (max Tnear (max Tfixed (max Tshort (max Tbase Tcanon)))))
    exact (h1.trans h2 |>.trans h3 |>.trans h4 |>.trans h5).trans hT0
  have hTbaseT : Tbase ≤ T := by
    have h1 : Tbase ≤ max Tbase Tcanon := le_max_left _ _
    have h2 := le_max_right Tshort (max Tbase Tcanon)
    have h3 := le_max_right Tfixed (max Tshort (max Tbase Tcanon))
    have h4 := le_max_right Tnear (max Tfixed (max Tshort (max Tbase Tcanon)))
    have h5 := le_max_right Thigh
      (max Tnear (max Tfixed (max Tshort (max Tbase Tcanon))))
    have h6 := le_max_right (Real.exp 2)
      (max Thigh (max Tnear (max Tfixed (max Tshort (max Tbase Tcanon)))))
    exact (h1.trans h2 |>.trans h3 |>.trans h4 |>.trans h5 |>.trans h6).trans hT0
  have hTcanonT : Tcanon ≤ T := by
    have h1 : Tcanon ≤ max Tbase Tcanon := le_max_right _ _
    have h2 := le_max_right Tshort (max Tbase Tcanon)
    have h3 := le_max_right Tfixed (max Tshort (max Tbase Tcanon))
    have h4 := le_max_right Tnear (max Tfixed (max Tshort (max Tbase Tcanon)))
    have h5 := le_max_right Thigh
      (max Tnear (max Tfixed (max Tshort (max Tbase Tcanon))))
    have h6 := le_max_right (Real.exp 2)
      (max Thigh (max Tnear (max Tfixed (max Tshort (max Tbase Tcanon)))))
    exact (h1.trans h2 |>.trans h3 |>.trans h4 |>.trans h5 |>.trans h6).trans hT0
  have hS : 1 < Real.sqrt T * (Real.log (2 * T)) ^ 2 :=
    omegaCanonicalS_gt_one hExp2
  let S : ℝ := Real.sqrt T * (Real.log (2 * T)) ^ 2
  let H : ℕ := ⌈K * S⌉₊
  have hTK : 4 * K + 1 ≤ T := by simpa [Tcanon] using hTcanonT
  obtain ⟨hH1, hHT4, haway⟩ :=
    omegaCanonicalH_data hT1 hK1 (by simpa [S] using hS) hTK
  have hHT : (H : ℝ) ≤ T := by
    simpa [H, S] using hHle T hTHT hT1
  let M : ℕ := max Mfix ⌈T ^ (2 * beta)⌉₊
  have hMfixM : Mfix ≤ M := by
    dsimp [M]
    exact le_max_left _ _
  have hM1 : 1 ≤ M := hMfix1.trans hMfixM
  have hMgt1 : 1 < M := lt_of_lt_of_le (by omega : 1 < Mfix) hMfixM
  have hKM : fixedBetaNaturalOrder beta ≤ M :=
    hKMfix.trans hMfixM
  have hMseedM : Mseed ≤ M :=
    hMseedfix.trans hMfixM
  have hM0real : M0 ≤ (M : ℝ) := by
    exact hMseed.trans (by exact_mod_cast hMseedM)
  have hmid : omegaMiddleTailBound q beta M ≤ z :=
    hM0 M hM0real hM1
  have hlogM2 :
      Real.log (M : ℝ) ≤ Clog + 2 * beta * Real.log T := by
    simpa [M, Clog] using
      (omega_log_max_ceil_rpow_two_beta_le hT1 hb0.le Mfix hMfix1)
  have hlogT0 : 0 ≤ Real.log T := Real.log_nonneg hT1
  have hlogM :
      Real.log (M : ℝ) ≤ Clog + 5 * beta * Real.log T := by
    have hbl : 0 ≤ beta * Real.log T :=
      mul_nonneg hb0.le hlogT0
    nlinarith [hlogM2]
  have hsource :
      (((H : ℝ) * T) ^ beta) ≤ (M : ℝ) := by
    simpa [H, M, S] using
      (omega_r0002_source_bound_two_beta
        hT1 hb0.le hHT (Mfix := Mfix))
  have hhigh :
      4 * ((6 * q : ℕ) : ℝ) * (1 + 2 * ((6 * q : ℕ) : ℝ)) /
          ((T / (((Nat.lcm 6 q : ℕ) : ℝ) * (D : ℝ))) ^
            (3 / 4 : ℝ)) ≤ z :=
    hThigh T hThighT
  have hLpos : 0 < L := by
    dsimp [L]
    exact_mod_cast Nat.lcm_pos (by norm_num) hq
  have hDpos : (0 : ℝ) < D := by exact_mod_cast (show 0 < D by omega)
  have hbase :
      (2 * ((6 * q : ℕ) : ℝ)) ^ 2 ≤
        T / (((Nat.lcm 6 q : ℕ) : ℝ) * (D : ℝ)) := by
    have hden : 0 < L * (D : ℝ) := mul_pos hLpos hDpos
    rw [le_div_iff₀ (by simpa [L] using hden)]
    have : Tbase ≤ T := hTbaseT
    simpa [Tbase, P, L, mul_assoc] using this
  have hfixed :
      L * R * (12 * (1 + Clog) + Csc) ≤
        (eps / 20) * Real.log T := by
    simpa [Cfixed] using hTfixed T hTfixedT hExp1
  have hshortConst :
      (1 / 2 : ℝ) *
        (R * (Clog + Real.log (D : ℝ)) +
          ((2 * (6 * q) + 9 : ℕ) : ℝ) * R)
        ≤ (eps / 2) * Real.log T := by
    simpa [Cshort] using hTshort T hTshortT hExp1
  by_cases hlong : M * D ≤ X
  · have hDX : D ≤ X := by
      have hDM : D ≤ M * D := by
        have := Nat.mul_le_mul_right D hM1
        simpa [Nat.one_mul] using this
      exact hDM.trans hlong
    have hmaj :
        L * omegaR0002AdditiveMajorant q beta M H T D X
          ≤ (eps / 5) * Real.log T := by
      simpa [L, R, Csc] using
        (omegaR0002AdditiveMajorant_priced q hq
          heps hb0 hz0.le hExp1 hXT hM1 hD1 hHT4
          hlogM hmid hhigh htailD
          hbetaOuter hzOuter hzD hfixed)
    have hsmooth :
        ‖petermannOmegaSmoothedKernel q chi r T X H S‖
          ≤ (eps / 5) * Real.log T := by
      have h :=
        petermannOmegaSmoothedKernel_norm_le_majorant
          (by simpa [S] using hS) q hq chi hb0 hb1 r
          hH1 hD1 hDX hMgt1 hKM hlong
          hTpos hXT hsource hbase
      exact h.trans (by simpa [L] using hmaj)
    have hnear0 :=
      hnear (0 : ℤ) T X hTnearT hExp1 hX hXT
    have hnearr :=
      hnear r T X hTnearT hExp1 hX hXT
    have hrem :
        ‖petermannOmegaSmoothingRemainder q chi r T X H S‖
          ≤ epsRem * Real.log T := by
      simpa [S, nearFac] using
        (omega_r0002_remainder_priced q hq
          hepsRem hdelta.le hK1 hExp1 hX hXT
          (by simpa [S] using hS) hH1
          (by simpa [S, H] using haway)
          (by simpa [epsRem] using hKbudget)
          (by simpa [nearFac] using hdeltaBudget)
          hnear0 chi r hnearr)
    rw [petermannBaseKernelSum_omega_eq_smoothed_add_remainder
      q chi r T X H S]
    calc
      ‖petermannOmegaSmoothedKernel q chi r T X H S +
          petermannOmegaSmoothingRemainder q chi r T X H S‖
        ≤ ‖petermannOmegaSmoothedKernel q chi r T X H S‖ +
            ‖petermannOmegaSmoothingRemainder q chi r T X H S‖ :=
          norm_add_le _ _
      _ ≤ (eps / 5) * Real.log T + epsRem * Real.log T :=
        _root_.add_le_add hsmooth hrem
      _ = eps * Real.log T := by
        dsimp [epsRem]
        ring
  · have hshort : X < M * D := Nat.lt_of_not_ge hlong
    exact hshort2 chi r T X
      hTshort2T hExp1 hX hXT (by simpa [M] using hshort)

#print axioms petermannOmegaR0002

end PaperB.Analytic
