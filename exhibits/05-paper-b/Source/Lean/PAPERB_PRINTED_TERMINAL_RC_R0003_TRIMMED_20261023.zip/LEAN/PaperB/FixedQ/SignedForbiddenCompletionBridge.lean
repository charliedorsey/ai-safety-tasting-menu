import PaperB.FixedQ.SignedForbiddenNaturalBridge
import PaperB.FixedQ.FixedConductorCompletion
import PaperB.FixedQ.WeilPaid
import PaperB.FixedQ.OmegaLinearConvolution
import PaperB.FixedQ.OmegaLinearMean
import Mathlib.Data.Nat.Choose.Sum
import Mathlib.NumberTheory.ArithmeticFunction.Misc
import PaperB.Analytic.PetermannPrimeSieveReduction

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def sourceGammaFinsetWeight (s : Finset ℕ) : ℝ :=
  ∏ p ∈ s, 3 / ((p : ℝ) - 3)

lemma sourceGammaFinsetWeight_eq_prod_gammaPrime_mul_sqrt
    (s : Finset ℕ) (h5 : ∀ p ∈ s, 5 ≤ p) :
    sourceGammaFinsetWeight s =
      (∏ p ∈ s, gammaPrimeTerm p) *
        Real.sqrt (primeSetProduct s : ℝ) := by
  unfold sourceGammaFinsetWeight
  rw [show Real.sqrt (primeSetProduct s : ℝ) =
      ∏ p ∈ s, Real.sqrt (p : ℝ) by
    unfold primeSetProduct
    push_cast
    rw [Real.sqrt_prod]
    intro p hp
    positivity]
  rw [← Finset.prod_mul_distrib]
  apply Finset.prod_congr rfl
  intro p hp
  rw [gammaPrimeTerm, if_pos (h5 p hp)]
  have hp5N : 5 ≤ p := h5 p hp
  have hpPos : 0 < p := lt_of_lt_of_le (by norm_num) hp5N
  have hpR : (0 : ℝ) < p := by exact_mod_cast hpPos
  have hs : 0 < Real.sqrt (p : ℝ) := Real.sqrt_pos.2 hpR
  have hd : (0 : ℝ) < (p : ℝ) - 3 := by
    have hp5R : (5 : ℝ) ≤ p := by exact_mod_cast (h5 p hp)
    linarith
  field_simp [hs.ne', hd.ne']

noncomputable def sourceGammaNatWeight (d : ℕ) : ℝ :=
  sourceGammaFinsetWeight d.primeFactors

theorem sum_divisors_sourceGammaNatWeight_eq_powerset
    {m : ℕ} (hm0 : m ≠ 0) (hsq : Squarefree m) :
    (∑ d ∈ m.divisors, sourceGammaNatWeight d) =
      ∑ s ∈ m.primeFactors.powerset, sourceGammaFinsetWeight s := by
  have hsum :=
    Nat.sum_divisors_filter_squarefree
      (n := m) hm0 (f := sourceGammaNatWeight)
  have hall : ∀ d ∈ m.divisors, Squarefree d := by
    intro d hd
    exact hsq.squarefree_of_dvd (Nat.dvd_of_mem_divisors hd)
  have hleft :
      (∑ d ∈ m.divisors with Squarefree d, sourceGammaNatWeight d) =
        ∑ d ∈ m.divisors, sourceGammaNatWeight d := by
    rw [Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro d hd
    simp [hall d hd]
  rw [hleft] at hsum
  rw [Nat.factors_eq] at hsum
  have hfac :
      (↑m.primeFactorsList : Multiset ℕ).toFinset = m.primeFactors := by
    rfl
  rw [hfac] at hsum
  have hsum' :
      (∑ d ∈ m.divisors, sourceGammaNatWeight d) =
        ∑ s ∈ m.primeFactors.powerset,
          sourceGammaNatWeight (∏ p ∈ s, p) := by
    calc
      (∑ d ∈ m.divisors, sourceGammaNatWeight d) =
          ∑ s ∈ m.primeFactors.powerset,
            sourceGammaNatWeight s.val.prod := hsum
      _ = ∑ s ∈ m.primeFactors.powerset,
            sourceGammaNatWeight (∏ p ∈ s, p) := by
          apply Finset.sum_congr rfl
          intro s hs
          simp
  rw [hsum']
  apply Finset.sum_congr rfl
  intro s hs
  unfold sourceGammaNatWeight
  have hsub : s ⊆ m.primeFactors := Finset.mem_powerset.mp hs
  have hPrime : ∀ p ∈ s, p.Prime := by
    intro p hp
    exact (Nat.mem_primeFactors.mp (hsub hp)).1
  rw [Nat.primeFactors_prod hPrime]

theorem omegaCoeff_mul_nat_eq_sourceGamma_powerset
    {q m : ℕ}
    (hm0 : m ≠ 0)
    (hsq : Squarefree m)
    (hcop : m.Coprime (6 * q)) :
    (m : ℝ) * omegaCoeff q m =
      ∑ s ∈ m.primeFactors.powerset, sourceGammaFinsetWeight s := by
  have hPrime : ∀ p ∈ m.primeFactors, p.Prime := by
    intro p hp
    exact (Nat.mem_primeFactors.mp hp).1
  have hp5 : ∀ p ∈ m.primeFactors, 5 ≤ p := by
    intro p hp
    have hpPrime := hPrime p hp
    have hpDiv : p ∣ m := (Nat.mem_primeFactors.mp hp).2.1
    have hpCop : p.Coprime (6 * q) :=
      Nat.Coprime.of_dvd_left hpDiv hcop
    exact prime_ge_five_of_coprime_six hpPrime hpCop
  rw [omegaCoeff_eq_finiteOmegaWeightReal hm0 hsq hcop]
  have hmprod : primeSetProduct m.primeFactors = m :=
    Nat.prod_primeFactors_of_squarefree hsq
  have hfactor : ∀ p ∈ m.primeFactors,
      (p : ℝ) * (1 / ((p : ℝ) - 3)) =
        1 + 3 / ((p : ℝ) - 3) := by
    intro p hp
    have hd : (p : ℝ) - 3 ≠ 0 := by
      have hp5' := hp5 p hp
      have hpR : (5 : ℝ) ≤ p := by exact_mod_cast hp5'
      linarith
    field_simp [hd]
    ring
  have hmnat : (∏ p ∈ m.primeFactors, p) = m := by
    simpa [primeSetProduct] using hmprod
  have hmcast :
      (m : ℝ) = ∏ p ∈ m.primeFactors, (p : ℝ) := by
    calc
      (m : ℝ) = ((∏ p ∈ m.primeFactors, p : ℕ) : ℝ) := by
        exact_mod_cast hmnat.symm
      _ = ∏ p ∈ m.primeFactors, (p : ℝ) := by
        rw [Nat.cast_prod]
  calc
    (m : ℝ) * finiteOmegaWeightReal m.primeFactors =
        (∏ p ∈ m.primeFactors, (p : ℝ)) *
          (∏ p ∈ m.primeFactors, 1 / ((p : ℝ) - 3)) := by
            rw [hmcast]
            rfl
    _ = ∏ p ∈ m.primeFactors,
          ((p : ℝ) * (1 / ((p : ℝ) - 3))) := by
            rw [Finset.prod_mul_distrib]
    _ = ∏ p ∈ m.primeFactors,
          (1 + 3 / ((p : ℝ) - 3)) := by
            apply Finset.prod_congr rfl
            exact hfactor
    _ = ∏ p ∈ m.primeFactors,
          (3 / ((p : ℝ) - 3) + 1) := by
            apply Finset.prod_congr rfl
            intro p hp
            ring
    _ = ∑ s ∈ m.primeFactors.powerset,
          sourceGammaFinsetWeight s := by
            rw [Finset.prod_add]
            simp [sourceGammaFinsetWeight]

theorem omegaCoeff_mul_nat_eq_sourceGamma_divisor_sum
    {q m : ℕ}
    (hm0 : m ≠ 0)
    (hsq : Squarefree m)
    (hcop : m.Coprime (6 * q)) :
    (m : ℝ) * omegaCoeff q m =
      ∑ d ∈ m.divisors, sourceGammaNatWeight d := by
  rw [omegaCoeff_mul_nat_eq_sourceGamma_powerset hm0 hsq hcop]
  exact (sum_divisors_sourceGammaNatWeight_eq_powerset hm0 hsq).symm

#print axioms omegaCoeff_mul_nat_eq_sourceGamma_divisor_sum
#print axioms omegaCoeff_mul_nat_eq_sourceGamma_powerset

/-- Exact divisor convolution behind the frozen source coefficient γ(d):
    n * omega_q(n) = (gamma * 1_{(.,6q)=1})(n). -/
theorem omegaLinearArithmetic_divisor_expansion
    (q n : ℕ) :
    omegaLinearArithmetic q n =
      ∑ d ∈ n.divisors,
        omegaLinearCorrectionArithmetic q d *
          coprimeIndicatorArithmetic q (n / d) := by
  rw [omegaLinearArithmetic_eq_correction_mul_coprime]
  rw [ArithmeticFunction.mul_apply]
  exact Nat.sum_divisorsAntidiagonal
    (fun a b =>
      omegaLinearCorrectionArithmetic q a *
        coprimeIndicatorArithmetic q b)

/-- On a supported squarefree divisor, the correction coefficient is the
    companion γ(d)=∏_{p|d} 3/(p-3). -/
theorem omegaLinearCorrection_squarefree_eq_gammaProduct
    {q d : ℕ}
    (hd0 : d ≠ 0)
    (hdsq : Squarefree d)
    (hdcop : d.Coprime (6 * q)) :
    omegaLinearCorrectionArithmetic q d =
      ∏ p ∈ d.primeFactors, 3 / ((p : ℝ) - 3) := by
  rw [omegaLinearCorrectionArithmetic_apply,
    omegaLinearCorrectionCoeff, if_neg hd0]
  apply Finset.prod_congr rfl
  intro p hp
  have hpData := Nat.mem_primeFactors.mp hp
  have hpPrime : p.Prime := hpData.1
  have hpDvd : p ∣ d := hpData.2.1
  have hpCop : p.Coprime (6 * q) :=
    Nat.Coprime.of_dvd_left hpDvd hdcop
  have hfacPos : 0 < d.factorization p :=
    hpPrime.factorization_pos_of_dvd hd0 hpDvd
  have hfacLe : d.factorization p ≤ 1 :=
    (Nat.squarefree_iff_factorization_le_one hd0).mp hdsq p
  have hfac : d.factorization p = 1 := by omega
  rw [hfac]
  simp [omegaLinearCorrectionLocal, hpPrime, hpCop]

theorem fixedQShiuWeight_eq_card_mul_omegaLinear_div
    {q m : ℕ}
    (hm0 : m ≠ 0)
    (hsq : Squarefree m)
    (hcop : m.Coprime (6 * q)) :
    fixedQShiuWeight q m =
      (2 : ℝ) ^ m.primeFactors.card *
        (omegaLinearArithmetic q m / (m : ℝ)) := by
  have hPrime : ∀ p ∈ m.primeFactors, p.Prime := by
    intro p hp
    exact (Nat.mem_primeFactors.mp hp).1
  have hAct : ∀ p ∈ m.primeFactors, activeHighPrime q p := by
    intro p hp
    have hpPrime := hPrime p hp
    have hpDiv : p ∣ m := (Nat.mem_primeFactors.mp hp).2.1
    have hpCop6q : p.Coprime (6 * q) :=
      Nat.Coprime.of_dvd_left hpDiv hcop
    exact ⟨hpPrime,
      prime_ge_five_of_coprime_six hpPrime hpCop6q,
      fun hpq =>
        (hpPrime.coprime_iff_not_dvd.mp hpCop6q)
          (dvd_mul_of_dvd_right hpq 6)⟩
  have hprod : primeSetProduct m.primeFactors = m :=
    Nat.prod_primeFactors_of_squarefree hsq
  calc
    fixedQShiuWeight q m =
        fixedQShiuWeight q (primeSetProduct m.primeFactors) := by
          rw [hprod]
    _ = (2 : ℝ) ^ m.primeFactors.card *
          finiteOmegaWeightReal m.primeFactors :=
      fixedQShiuWeight_primeSetProduct_eq_card_mul_finiteOmegaWeightReal hAct
    _ = (2 : ℝ) ^ m.primeFactors.card * omegaCoeff q m := by
      rw [omegaCoeff_eq_finiteOmegaWeightReal hm0 hsq hcop]
    _ = (2 : ℝ) ^ m.primeFactors.card *
          (omegaLinearArithmetic q m / (m : ℝ)) := by
      rw [omegaCoeff_eq_omegaLinearArithmetic_div q m hm0]

theorem fixedQShiuWeight_eq_gamma_divisor_sum
    {q m : ℕ}
    (hm0 : m ≠ 0)
    (hsq : Squarefree m)
    (hcop : m.Coprime (6 * q)) :
    fixedQShiuWeight q m =
      (2 : ℝ) ^ m.primeFactors.card *
        ((∑ d ∈ m.divisors,
            omegaLinearCorrectionArithmetic q d *
              coprimeIndicatorArithmetic q (m / d)) /
          (m : ℝ)) := by
  rw [fixedQShiuWeight_eq_card_mul_omegaLinear_div hm0 hsq hcop]
  rw [omegaLinearArithmetic_divisor_expansion]

theorem sourceGammaDivisor_support
    {q H D m d : ℕ}
    (hsq : Squarefree m)
    (hcop : m.Coprime (H * (6 * q) * D))
    (hd : d ∈ m.divisors) :
    let n := m / d
    Squarefree d ∧
      d.Coprime (6 * q * D) ∧
      Squarefree n ∧
      n.Coprime (6 * q) ∧
      n.Coprime (d * D) := by
  dsimp
  have hm0 : m ≠ 0 := hsq.ne_zero
  have hdiv : d ∣ m := (Nat.mem_divisors.mp hd).1
  have hprod : d * (m / d) = m := Nat.mul_div_cancel' hdiv
  have hsqprod : Squarefree (d * (m / d)) := by
    simpa [hprod] using hsq
  have hsplit := Nat.squarefree_mul_iff.mp hsqprod
  have hmH6q : m.Coprime (H * (6 * q)) :=
    (Nat.coprime_mul_iff_right.mp hcop).1
  have hmD : m.Coprime D :=
    (Nat.coprime_mul_iff_right.mp hcop).2
  have hm6q : m.Coprime (6 * q) :=
    (Nat.coprime_mul_iff_right.mp hmH6q).2
  have hm6qD : m.Coprime (6 * q * D) :=
    Nat.Coprime.mul_right hm6q hmD
  have hd6qD : d.Coprime (6 * q * D) :=
    Nat.Coprime.of_dvd_left hdiv hm6qD
  have hnDiv : m / d ∣ m := Nat.div_dvd_of_dvd hdiv
  have hn6q : (m / d).Coprime (6 * q) :=
    Nat.Coprime.of_dvd_left hnDiv hm6q
  have hnD : (m / d).Coprime D :=
    Nat.Coprime.of_dvd_left hnDiv hmD
  have hnd : (m / d).Coprime d := hsplit.1.symm
  exact ⟨hsplit.2.1, hd6qD, hsplit.2.2, hn6q,
    Nat.Coprime.mul_right hnd hnD⟩

theorem sourceGammaDivisor_squarefreeRemoval
    {q H D m d : ℕ}
    (hsq : Squarefree m)
    (hcop : m.Coprime (H * (6 * q) * D))
    (hd : d ∈ m.divisors) :
    let n := m / d
    ArithmeticFunction.moebius (d * n) ^ 2 *
        intIndicator ((d * n).Coprime (6 * D)) *
        intIndicator ((d * n).Coprime q) =
      intIndicator (n.Coprime (6 * q)) *
        ArithmeticFunction.moebius n ^ 2 *
        intIndicator (n.Coprime (d * D)) := by
  dsimp
  have hs := sourceGammaDivisor_support hsq hcop hd
  exact fixedQ_squarefree_removal_exact hs.1 hs.2.1

def sourceSquarePrimeSet (n : ℕ) : Finset ℕ :=
  n.primeFactors.filter (fun p => p ^ 2 ∣ n)

lemma source_primeProd_sq_dvd_iff_subset_squarePrimeSet
    {n : ℕ} {s : Finset ℕ}
    (hs : s ⊆ n.primeFactors) :
    (∏ p ∈ s, p) ^ 2 ∣ n ↔ s ⊆ sourceSquarePrimeSet n := by
  constructor
  · intro h p hp
    have hpN : p ∈ n.primeFactors := hs hp
    have hpDivProd : p ∣ ∏ q ∈ s, q :=
      Finset.dvd_prod_of_mem (fun q => q) hp
    have hp2 : p ^ 2 ∣ (∏ q ∈ s, q) ^ 2 :=
      pow_dvd_pow_of_dvd hpDivProd 2
    simp only [sourceSquarePrimeSet, Finset.mem_filter]
    exact ⟨hpN, hp2.trans h⟩
  · intro hsub
    induction s using Finset.induction_on with
    | empty => simp
    | @insert p s hpnot ih =>
        have hpMem : p ∈ insert p s := Finset.mem_insert_self p s
        have hpN : p ∈ n.primeFactors := hs hpMem
        have hpPrime : p.Prime := Nat.prime_of_mem_primeFactors hpN
        have hsN : s ⊆ n.primeFactors := by
          intro q hq
          exact hs (Finset.mem_insert_of_mem hq)
        have hsSub : s ⊆ sourceSquarePrimeSet n := by
          intro q hq
          exact hsub (Finset.mem_insert_of_mem hq)
        have hpSq : p ^ 2 ∣ n := by
          have := hsub hpMem
          simpa [sourceSquarePrimeSet, hpN] using this
        have hsSq : (∏ q ∈ s, q) ^ 2 ∣ n := ih hsN hsSub
        have hpCopProd : p.Coprime (∏ q ∈ s, q) := by
          apply Nat.Coprime.prod_right
          intro q hq
          have hqPrime : q.Prime :=
            Nat.prime_of_mem_primeFactors (hsN hq)
          exact (Nat.coprime_primes hpPrime hqPrime).2
            (fun hpq => hpnot (hpq ▸ hq))
        have hcopSq :
            (p ^ 2).Coprime ((∏ q ∈ s, q) ^ 2) :=
          hpCopProd.pow 2 2
        rw [Finset.prod_insert hpnot, mul_pow]
        exact hcopSq.mul_dvd_of_dvd_of_dvd hpSq hsSq

lemma source_moebius_primeProd_eq_neg_one_pow_card
    {s : Finset ℕ} (hPrime : ∀ p ∈ s, p.Prime) :
    ArithmeticFunction.moebius (∏ p ∈ s, p) =
      (-1 : ℤ) ^ s.card := by
  have hsq : Squarefree (∏ p ∈ s, p) := by
    exact primeSetProduct_squarefree hPrime
  rw [ArithmeticFunction.moebius_apply_of_squarefree hsq]
  congr 1
  have h0 : (∏ p ∈ s, p) ≠ 0 := by
    exact Nat.ne_of_gt (Finset.prod_pos fun p hp => (hPrime p hp).pos)
  have hcf :=
    (ArithmeticFunction.cardDistinctFactors_eq_cardFactors_iff_squarefree h0).2 hsq
  rw [← hcf]
  rw [ArithmeticFunction.cardDistinctFactors_apply]
  rw [← List.card_toFinset]
  rw [Nat.toFinset_factors]
  rw [Nat.primeFactors_prod hPrime]

theorem source_sum_moebius_square_dvd_eq_indicator
    (n : ℕ) (hn0 : n ≠ 0) :
    (∑ f ∈ n.divisors,
      if f ^ 2 ∣ n then ArithmeticFunction.moebius f else 0) =
      intIndicator (Squarefree n) := by
  classical
  calc
    (∑ f ∈ n.divisors,
      if f ^ 2 ∣ n then ArithmeticFunction.moebius f else 0)
      = ∑ f ∈ n.divisors,
          if Squarefree f then
            (if f ^ 2 ∣ n then ArithmeticFunction.moebius f else 0)
          else 0 := by
          apply Finset.sum_congr rfl
          intro f hf
          by_cases hsq : Squarefree f
          · simp [hsq]
          · rw [ArithmeticFunction.moebius_eq_zero_of_not_squarefree hsq]
            simp [hsq]
    _ = ∑ f ∈ n.divisors with Squarefree f,
          (if f ^ 2 ∣ n then ArithmeticFunction.moebius f else 0) := by
          rw [Finset.sum_filter]
    _ = ∑ i ∈ n.primeFactors.powerset,
          (if (∏ p ∈ i, p) ^ 2 ∣ n then
            ArithmeticFunction.moebius (∏ p ∈ i, p) else 0) := by
          rw [Nat.sum_divisors_filter_squarefree hn0]
          have hfac :
              (UniqueFactorizationMonoid.normalizedFactors n).toFinset =
                n.primeFactors := by
            rw [Nat.factors_eq]
            exact Nat.toFinset_factors n
          rw [hfac]
          simp only [Finset.prod_eq_multiset_prod, Multiset.map_id']
    _ = ∑ i ∈ n.primeFactors.powerset,
          (if i ⊆ sourceSquarePrimeSet n then (-1 : ℤ) ^ i.card else 0) := by
          apply Finset.sum_congr rfl
          intro i hi
          have hisub : i ⊆ n.primeFactors :=
            Finset.mem_powerset.mp hi
          have hPrime : ∀ p ∈ i, p.Prime := by
            intro p hp
            exact Nat.prime_of_mem_primeFactors (hisub hp)
          simp only [
            source_primeProd_sq_dvd_iff_subset_squarePrimeSet hisub,
            source_moebius_primeProd_eq_neg_one_pow_card hPrime]
    _ = ∑ i ∈ (sourceSquarePrimeSet n).powerset, (-1 : ℤ) ^ i.card := by
          rw [← Finset.sum_filter]
          apply Finset.sum_congr
          · ext i
            simp only [Finset.mem_filter, Finset.mem_powerset]
            constructor
            · rintro ⟨_hisub, hsquare⟩
              exact hsquare
            · intro hsquare
              have hsquareBase : sourceSquarePrimeSet n ⊆ n.primeFactors := by
                intro p hp
                exact (Finset.mem_filter.mp hp).1
              exact ⟨hsquare.trans hsquareBase, hsquare⟩
          · intro i hi
            rfl
    _ = if sourceSquarePrimeSet n = ∅ then 1 else 0 := by
          exact Finset.sum_powerset_neg_one_pow_card
    _ = intIndicator (Squarefree n) := by
          unfold sourceSquarePrimeSet intIndicator
          by_cases hsq : Squarefree n
          · have hnone : n.primeFactors.filter (fun p => p ^ 2 ∣ n) = ∅ := by
              apply Finset.not_nonempty_iff_eq_empty.mp
              intro hne
              obtain ⟨p, hp⟩ := hne
              simp only [Finset.mem_filter] at hp
              have hpSq : p * p ∣ n := by
                simpa [pow_two] using hp.2
              exact (Nat.squarefree_iff_prime_squarefree.mp hsq p
                (Nat.prime_of_mem_primeFactors hp.1)) hpSq
            simp [hsq, hnone]
          · have hnonempty :
                (n.primeFactors.filter (fun p => p ^ 2 ∣ n)).Nonempty := by
              rw [Nat.squarefree_iff_prime_squarefree] at hsq
              push Not at hsq
              obtain ⟨p, hpPrime, hpSq⟩ := hsq
              have hpDvd : p ∣ n :=
                (dvd_mul_right p p).trans hpSq
              have hpPow : p ^ 2 ∣ n := by
                simpa [pow_two] using hpSq
              exact ⟨p, by
                simp [Nat.mem_primeFactors.mpr ⟨hpPrime, hpDvd, hn0⟩, hpPow]⟩
            simp [hsq, Finset.nonempty_iff_ne_empty.mp hnonempty]

lemma source_sum_moebius_divisor_indicator
    {n P : ℕ} (hP0 : P ≠ 0) :
    (∑ c ∈ P.divisors,
      if c ∣ n then ArithmeticFunction.moebius c else 0) =
      intIndicator (n.Coprime P) := by
  have h :=
    PaperB.Analytic.sum_moebius_divisors_gcd_eq_divisor_indicator
      (n := n) (P := P) hP0
  have hc :=
    PaperB.Analytic.sum_moebius_divisors_eq_coprime_indicator
      (n := n) (P := P) hP0
  rw [h] at hc
  simpa [intIndicator] using hc

theorem source_squarefree_coprime_channel_expansion
    {n P : ℕ} (hn0 : n ≠ 0) (hP0 : P ≠ 0) :
    intIndicator (Squarefree n) * intIndicator (n.Coprime P) =
      ∑ f ∈ n.divisors,
        if f ^ 2 ∣ n ∧ f.Coprime P then
          ArithmeticFunction.moebius f *
            (∑ c ∈ P.divisors,
              if c ∣ n then ArithmeticFunction.moebius c else 0)
        else 0 := by
  classical
  have hcSum := source_sum_moebius_divisor_indicator
    (n := n) (P := P) hP0
  by_cases hcop : n.Coprime P
  · have hfCop : ∀ f ∈ n.divisors, f.Coprime P := by
      intro f hf
      exact Nat.Coprime.of_dvd_left (Nat.dvd_of_mem_divisors hf) hcop
    rw [hcSum]
    have hcopInd : intIndicator (n.Coprime P) = 1 := by
      simp [intIndicator, hcop]
    rw [hcopInd, mul_one]
    rw [← source_sum_moebius_square_dvd_eq_indicator n hn0]
    apply Finset.sum_congr rfl
    intro f hf
    have hfc := hfCop f hf
    by_cases hsq : f ^ 2 ∣ n
    · simp [hsq, hfc]
    · simp [hsq]
  · rw [hcSum]
    simp [intIndicator, hcop]

lemma source_c_mul_f_sq_dvd_iff
    {c f n P : ℕ}
    (hcP : c ∣ P) (hfP : f.Coprime P) :
    (c ∣ n ∧ f ^ 2 ∣ n) ↔ c * f ^ 2 ∣ n := by
  have hfc : f.Coprime c := Nat.Coprime.of_dvd_right hcP hfP
  have hcf2 : c.Coprime (f ^ 2) := by
    simpa using (hfc.symm.pow 1 2)
  constructor
  · rintro ⟨hc, hf⟩
    exact hcf2.mul_dvd_of_dvd_of_dvd hc hf
  · intro h
    exact ⟨(dvd_mul_right c (f ^ 2)).trans h,
      (dvd_mul_left (f ^ 2) c).trans h⟩

lemma source_sum_Icc_cf2_reindex
    {M : Type*} [AddCommMonoid M]
    (F : ℕ → M) {c f P X : ℕ}
    (hcP : c ∣ P) (hfP : f.Coprime P)
    (hcpos : 0 < c) (hfpos : 0 < f) :
    (∑ n ∈ Finset.Icc 1 X,
      if c ∣ n ∧ f ^ 2 ∣ n then F n else 0) =
      ∑ ell ∈ Finset.Icc 1 (X / (c * f ^ 2)),
        F ((c * f ^ 2) * ell) := by
  classical
  rw [← Finset.sum_filter]
  have hfilter :
      (Finset.Icc 1 X).filter (fun n => c ∣ n ∧ f ^ 2 ∣ n) =
        (Finset.Icc 1 X).filter (fun n => c * f ^ 2 ∣ n) := by
    ext n
    simp only [Finset.mem_filter, Finset.mem_Icc, and_congr_right_iff]
    intro hn
    exact source_c_mul_f_sq_dvd_iff hcP hfP
  rw [hfilter]
  exact PaperB.Analytic.sum_Icc_dvd_reindex F
    (mul_pos hcpos (pow_pos hfpos 2))

theorem source_weightedCenteredCombinedIntervalSum_le
    (hWeil : PrimeNondegenerateWeil)
    {A B : ℤ} {r L Y len : ℕ}
    (hr : 0 < r) (hL : 0 < L)
    (hrsq : Squarefree r) (hLsq : Squarefree L)
    (hcop : r.Coprime L)
    (hY : 0 < Y)
    [NeZero
      (reducedModulus
        (combinedNumeratorInt A B r L).natAbs
        (combinedModulus r L))]
    (x : ZMod
      (reducedModulus
        (combinedNumeratorInt A B r L).natAbs
        (combinedModulus r L))) :
    let Cnat := (combinedNumeratorInt A B r L).natAbs
    let Q := combinedModulus r L
    let rho := reducedModulus Cnat Q
    ‖weightedCenteredIntervalSum
        rho
        (reducedNumerator Cnat Q : ZMod rho)
        x Y len‖ ≤
      2 * (((2 : ℝ) ^ rho.primeFactors.card * Real.sqrt rho) *
        (1 + Real.log rho)) / Y := by
  dsimp only
  have hQpos : 0 < combinedModulus r L := by
    unfold combinedModulus
    exact Nat.mul_pos hr hL
  have hQsq : Squarefree (combinedModulus r L) := by
    unfold combinedModulus
    exact (Nat.squarefree_mul hcop).2 ⟨hrsq, hLsq⟩
  exact weightedCenteredReducedIntervalSum_le
    hWeil hQpos hQsq
    (A := (combinedNumeratorInt A B r L).natAbs)
    (q := combinedModulus r L)
    (x := x) Y len hY

theorem source_reducedModulus_eq_reciprocalReducedModulusInt
    (A B : ℤ) (r L : ℕ) :
    reducedModulus
        (combinedNumeratorInt A B r L).natAbs
        (combinedModulus r L) =
      reciprocalReducedModulusInt A B r L := by
  rfl

#print axioms source_weightedCenteredCombinedIntervalSum_le
#print axioms source_reducedModulus_eq_reciprocalReducedModulusInt

lemma source_reciprocalReducedModulusInt_eq_reducedModulus
    (A B : ℤ) (r L : ℕ) :
    reciprocalReducedModulusInt A B r L =
      reducedModulus (combinedNumeratorInt A B r L).natAbs
        (combinedModulus r L) := by
  rfl

lemma source_combinedModulus_squarefree
    {r L : ℕ} (hrsq : Squarefree r) (hLsq : Squarefree L)
    (hcop : r.Coprime L) :
    Squarefree (combinedModulus r L) := by
  unfold combinedModulus
  exact (Nat.squarefree_mul hcop).2 ⟨hrsq, hLsq⟩

theorem source_fixed_dc_channel_estimate_from_f_split
    (S : Finset ℕ) (h5 : ∀ p ∈ S, 5 ≤ p)
    {c F M : ℕ} {U C s0 : ℝ}
    (hcpos : 0 < c)
    (hU : 0 < U) (hC : 0 < C) (hs0 : 0 < s0)
    (hsq :
      s0 ^ 2 =
        U / (((primeSetProduct S : ℕ) : ℝ) * (c : ℝ) * C))
    (hsF : s0 ≤ (F : ℝ)) (hF2 : (F : ℝ) ≤ 2 * s0)
    (smallTerm largeTerm : ℕ → ℝ)
    (hsmallTerm : ∀ f ∈ Finset.Icc 1 F,
      smallTerm f ≤ sourceGammaFinsetWeight S * C / U)
    (hlargeTerm : ∀ f ∈ Finset.Icc (F + 1) M,
      largeTerm f ≤
        (sourceGammaFinsetWeight S /
          (((primeSetProduct S : ℕ) : ℝ) * (c : ℝ))) *
            ((f : ℝ)⁻¹ ^ 2)) :
    (∑ f ∈ Finset.Icc 1 F, smallTerm f) +
        (∑ f ∈ Finset.Icc (F + 1) M, largeTerm f) ≤
      (3 * Real.sqrt C * (Real.sqrt U)⁻¹) *
        (∏ p ∈ S, gammaPrimeTerm p) * invSqrtNat c := by
  have hdposN : 0 < primeSetProduct S := by
    unfold primeSetProduct
    exact Finset.prod_pos fun p hp => lt_of_lt_of_le (by norm_num) (h5 p hp)
  have hdpos : (0 : ℝ) < primeSetProduct S := by
    exact_mod_cast hdposN
  have hcposR : (0 : ℝ) < c := by exact_mod_cast hcpos
  have hD :
      0 < ((primeSetProduct S : ℕ) : ℝ) * (c : ℝ) :=
    mul_pos hdpos hcposR
  have hG : 0 ≤ sourceGammaFinsetWeight S := by
    rw [sourceGammaFinsetWeight_eq_prod_gammaPrime_mul_sqrt S h5]
    exact mul_nonneg
      (Finset.prod_nonneg fun p hp => gammaPrimeTerm_nonneg p)
      (Real.sqrt_nonneg _)
  have hest := fixedChannel_estimate_from_f_split
    (G := sourceGammaFinsetWeight S)
    (U := U)
    (D := ((primeSetProduct S : ℕ) : ℝ) * (c : ℝ))
    (C := C) (s := s0) (F := F) (M := M)
    hG hU hD hC hs0 hsq hsF hF2
    smallTerm largeTerm hsmallTerm hlargeTerm
  calc
    (∑ f ∈ Finset.Icc 1 F, smallTerm f) +
        (∑ f ∈ Finset.Icc (F + 1) M, largeTerm f)
      ≤ 3 * sourceGammaFinsetWeight S *
          Real.sqrt
            (C / (U *
              (((primeSetProduct S : ℕ) : ℝ) * (c : ℝ)))) := hest
    _ = (3 * Real.sqrt C * (Real.sqrt U)⁻¹) *
        (∏ p ∈ S, gammaPrimeTerm p) * invSqrtNat c := by
      rw [sourceGammaFinsetWeight_eq_prod_gammaPrime_mul_sqrt S h5]
      rw [balancedScale_factor hC.le hU hD]
      have hdc :
          Real.sqrt
              (((primeSetProduct S : ℕ) : ℝ) * (c : ℝ)) =
            Real.sqrt (primeSetProduct S : ℝ) *
              Real.sqrt (c : ℝ) := by
        rw [Real.sqrt_mul hdpos.le]
      rw [hdc]
      unfold invSqrtNat
      have hsd :
          Real.sqrt (primeSetProduct S : ℝ) ≠ 0 :=
        (Real.sqrt_pos.2 hdpos).ne'
      have hsc : Real.sqrt (c : ℝ) ≠ 0 :=
        (Real.sqrt_pos.2 hcposR).ne'
      field_simp [hsd, hsc]

#print axioms source_fixed_dc_channel_estimate_from_f_split

lemma source_invSqrtNat_mul_one_add_le_one
    {p : ℕ} (hp5 : 5 ≤ p) :
    invSqrtNat p * (1 + invSqrtNat p) ≤ 1 := by
  unfold invSqrtNat
  have hp4 : (4 : ℝ) ≤ (p : ℝ) := by
    exact_mod_cast (show 4 ≤ p by omega)
  have hsqrt4 : Real.sqrt (4 : ℝ) = 2 := by
    rw [show (4 : ℝ) = (2 : ℝ) ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
  have hs : (2 : ℝ) ≤ Real.sqrt (p : ℝ) := by
    have h := Real.sqrt_le_sqrt hp4
    simpa [hsqrt4] using h
  have hspos : 0 < Real.sqrt (p : ℝ) :=
    lt_of_lt_of_le (by norm_num) hs
  have hinv : (Real.sqrt (p : ℝ))⁻¹ ≤ (1 / 2 : ℝ) := by
    simpa [one_div] using
      (one_div_le_one_div_of_le (by norm_num : (0 : ℝ) < 2) hs)
  have hinv0 : 0 ≤ (Real.sqrt (p : ℝ))⁻¹ := by positivity
  nlinarith

theorem source_invSqrtNat_primeSetProduct_mul_forbiddenSurcharge_le_one
    {q : ℕ} {S : Finset ℕ}
    (hact : ∀ p ∈ S, activeHighPrime q p) :
    invSqrtNat (primeSetProduct S) *
        forbiddenSurcharge (primeSetProduct S) ≤ 1 := by
  have hPrime : ∀ p ∈ S, p.Prime := by
    intro p hp
    exact (hact p hp).1
  have h5 : ∀ p ∈ S, 5 ≤ p := by
    intro p hp
    exact (hact p hp).2.1
  have hpf : (primeSetProduct S).primeFactors = S := by
    unfold primeSetProduct
    exact Nat.primeFactors_prod hPrime
  have hinvprod :
      invSqrtNat (primeSetProduct S) =
        ∏ p ∈ S, invSqrtNat p := by
    unfold primeSetProduct
    exact invSqrtNat_finset_prod S
  rw [hinvprod]
  unfold forbiddenSurcharge
  rw [hpf]
  rw [← Finset.prod_mul_distrib]
  apply Finset.prod_le_one₀
  · intro p hp
    have hinv : 0 ≤ invSqrtNat p := by
      unfold invSqrtNat
      positivity
    exact mul_nonneg hinv (by linarith)
  · intro p hp
    exact source_invSqrtNat_mul_one_add_le_one (h5 p hp)

#print axioms source_invSqrtNat_primeSetProduct_mul_forbiddenSurcharge_le_one


#print axioms source_reciprocalReducedModulusInt_eq_reducedModulus
#print axioms source_combinedModulus_squarefree

#print axioms source_c_mul_f_sq_dvd_iff
#print axioms source_sum_Icc_cf2_reindex

#print axioms source_sum_moebius_divisor_indicator
#print axioms source_squarefree_coprime_channel_expansion

#print axioms source_primeProd_sq_dvd_iff_subset_squarePrimeSet
#print axioms source_moebius_primeProd_eq_neg_one_pow_card
#print axioms source_sum_moebius_square_dvd_eq_indicator

#print axioms sourceGammaDivisor_support
#print axioms sourceGammaDivisor_squarefreeRemoval

#print axioms omegaLinearArithmetic_divisor_expansion
#print axioms omegaLinearCorrection_squarefree_eq_gammaProduct
#print axioms fixedQShiuWeight_eq_card_mul_omegaLinear_div
#print axioms fixedQShiuWeight_eq_gamma_divisor_sum

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma source_forbiddenSurcharge_mul_of_coprime
    {a b : ℕ} (hab : a.Coprime b) :
    forbiddenSurcharge (a * b) =
      forbiddenSurcharge a * forbiddenSurcharge b := by
  unfold forbiddenSurcharge
  rw [hab.primeFactors_mul]
  rw [Finset.prod_union hab.disjoint_primeFactors]

lemma source_one_add_invSqrtNat_le_two
    {p : ℕ} (hp5 : 5 ≤ p) :
    1 + invSqrtNat p ≤ 2 := by
  unfold invSqrtNat
  have hp4 : (4 : ℝ) ≤ (p : ℝ) := by
    exact_mod_cast (show 4 ≤ p by omega)
  have hsqrt4 : Real.sqrt (4 : ℝ) = 2 := by
    rw [show (4 : ℝ) = (2 : ℝ) ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
  have hs : (2 : ℝ) ≤ Real.sqrt (p : ℝ) := by
    have h := Real.sqrt_le_sqrt hp4
    simpa [hsqrt4] using h
  have hinv : (Real.sqrt (p : ℝ))⁻¹ ≤ (1 / 2 : ℝ) := by
    simpa [one_div] using
      (one_div_le_one_div_of_le (by norm_num : (0 : ℝ) < 2) hs)
  linarith

noncomputable def sourceEnhancedGammaPrimeTerm (n : ℕ) : ℝ :=
  gammaPrimeTerm n * (1 + invSqrtNat n)

lemma sourceEnhancedGammaPrimeTerm_nonneg (n : ℕ) :
    0 ≤ sourceEnhancedGammaPrimeTerm n := by
  unfold sourceEnhancedGammaPrimeTerm
  have hi : 0 ≤ invSqrtNat n := by
    unfold invSqrtNat
    positivity
  exact mul_nonneg (gammaPrimeTerm_nonneg n) (by linarith)

lemma sourceEnhancedGammaPrimeTerm_le_two_gamma (n : ℕ) :
    sourceEnhancedGammaPrimeTerm n ≤ 2 * gammaPrimeTerm n := by
  unfold sourceEnhancedGammaPrimeTerm
  by_cases hn : 5 ≤ n
  · simpa [mul_comm] using
      (mul_le_mul_of_nonneg_left
        (source_one_add_invSqrtNat_le_two hn)
        (gammaPrimeTerm_nonneg n))
  · have hg0 : gammaPrimeTerm n = 0 := by
      simp [gammaPrimeTerm, hn]
    rw [hg0]
    simp

theorem summable_sourceEnhancedGammaPrimeTerm :
    Summable sourceEnhancedGammaPrimeTerm := by
  have htwo : Summable (fun n : ℕ => 2 * gammaPrimeTerm n) :=
    summable_gammaPrimeTerm.mul_left 2
  exact Summable.of_nonneg_of_le
    sourceEnhancedGammaPrimeTerm_nonneg
    sourceEnhancedGammaPrimeTerm_le_two_gamma
    htwo

theorem sourceEnhancedGammaPowerset_sum_eq_eulerProduct (S : Finset ℕ) :
    (∑ s ∈ S.powerset, ∏ p ∈ s, sourceEnhancedGammaPrimeTerm p) =
      ∏ p ∈ S, (1 + sourceEnhancedGammaPrimeTerm p) := by
  symm
  simpa [add_comm] using
    (Finset.prod_add
      (fun p : ℕ => sourceEnhancedGammaPrimeTerm p)
      (fun _p : ℕ => (1 : ℝ)) S)

theorem sourceEnhancedGammaEulerProduct_uniform_bound (S : Finset ℕ) :
    (∏ p ∈ S, (1 + sourceEnhancedGammaPrimeTerm p)) ≤
      Real.exp (∑' n : ℕ, sourceEnhancedGammaPrimeTerm n) := by
  have hprod :
      (∏ p ∈ S, (1 + sourceEnhancedGammaPrimeTerm p)) ≤
        ∏ p ∈ S, Real.exp (sourceEnhancedGammaPrimeTerm p) := by
    induction S using Finset.induction_on with
    | empty => simp
    | @insert a S ha ih =>
        rw [Finset.prod_insert ha, Finset.prod_insert ha]
        have hlocal :
            1 + sourceEnhancedGammaPrimeTerm a ≤
              Real.exp (sourceEnhancedGammaPrimeTerm a) := by
          simpa [add_comm] using
            Real.add_one_le_exp (sourceEnhancedGammaPrimeTerm a)
        have hleft :
            0 ≤ ∏ p ∈ S, (1 + sourceEnhancedGammaPrimeTerm p) := by
          apply Finset.prod_nonneg
          intro p hp
          linarith [sourceEnhancedGammaPrimeTerm_nonneg p]
        exact mul_le_mul hlocal ih hleft (Real.exp_pos _).le
  calc
    (∏ p ∈ S, (1 + sourceEnhancedGammaPrimeTerm p))
      ≤ ∏ p ∈ S, Real.exp (sourceEnhancedGammaPrimeTerm p) := hprod
    _ = Real.exp (∑ p ∈ S, sourceEnhancedGammaPrimeTerm p) := by
      rw [Real.exp_sum]
    _ ≤ Real.exp (∑' n : ℕ, sourceEnhancedGammaPrimeTerm n) := by
      apply Real.exp_monotone
      exact summable_sourceEnhancedGammaPrimeTerm.sum_le_tsum S
        (fun n hn => sourceEnhancedGammaPrimeTerm_nonneg n)

theorem source_gamma_surcharge_powerset_uniform_bound
    (S : Finset ℕ) (hPrime : ∀ p ∈ S, p.Prime) :
    (∑ s ∈ S.powerset,
      (∏ p ∈ s, gammaPrimeTerm p) *
        forbiddenSurcharge (primeSetProduct s)) ≤
      Real.exp (∑' n : ℕ, sourceEnhancedGammaPrimeTerm n) := by
  calc
    (∑ s ∈ S.powerset,
      (∏ p ∈ s, gammaPrimeTerm p) *
        forbiddenSurcharge (primeSetProduct s))
      = ∑ s ∈ S.powerset,
          ∏ p ∈ s, sourceEnhancedGammaPrimeTerm p := by
        apply Finset.sum_congr rfl
        intro s hs
        have hsub : s ⊆ S := Finset.mem_powerset.mp hs
        have hsPrime : ∀ p ∈ s, p.Prime := by
          intro p hp
          exact hPrime p (hsub hp)
        have hpf : (primeSetProduct s).primeFactors = s := by
          unfold primeSetProduct
          exact Nat.primeFactors_prod hsPrime
        unfold sourceEnhancedGammaPrimeTerm forbiddenSurcharge
        rw [hpf]
        rw [Finset.prod_mul_distrib]
    _ = ∏ p ∈ S, (1 + sourceEnhancedGammaPrimeTerm p) :=
      sourceEnhancedGammaPowerset_sum_eq_eulerProduct S
    _ ≤ Real.exp (∑' n : ℕ, sourceEnhancedGammaPrimeTerm n) :=
      sourceEnhancedGammaEulerProduct_uniform_bound S



theorem source_sum_gammaChannels_uniform_forbidden
    {q : ℕ} (S Rset : Finset ℕ)
    (hSact : ∀ p ∈ S, activeHighPrime q p)
    (hRact : ∀ p ∈ Rset, activeHighPrime q p)
    (hdis : Disjoint S Rset)
    (channel : Finset ℕ → ℕ → ℝ)
    {K : ℝ} (hK : 0 ≤ K)
    (hchan : ∀ s ∈ S.powerset,
      ∀ c ∈ (primeSetProduct s * primeSetProduct Rset).divisors,
        channel s c ≤
          K * (∏ p ∈ s, gammaPrimeTerm p) *
            invSqrtNat (primeSetProduct Rset) * invSqrtNat c) :
    (∑ s ∈ S.powerset,
      ∑ c ∈ (primeSetProduct s * primeSetProduct Rset).divisors,
        channel s c) ≤
      K * Real.exp (∑' n : ℕ, sourceEnhancedGammaPrimeTerm n) := by
  have hPrimeS : ∀ p ∈ S, p.Prime := by
    intro p hp
    exact (hSact p hp).1
  have hPrimeR : ∀ p ∈ Rset, p.Prime := by
    intro p hp
    exact (hRact p hp).1
  have hRbound :=
    source_invSqrtNat_primeSetProduct_mul_forbiddenSurcharge_le_one hRact
  have hpoint : ∀ s ∈ S.powerset,
      (∑ c ∈ (primeSetProduct s * primeSetProduct Rset).divisors,
        channel s c) ≤
        K * (∏ p ∈ s, gammaPrimeTerm p) *
          forbiddenSurcharge (primeSetProduct s) := by
    intro s hs
    have hsub : s ⊆ S := Finset.mem_powerset.mp hs
    have hsAct : ∀ p ∈ s, activeHighPrime q p := by
      intro p hp
      exact hSact p (hsub hp)
    have hsPrime : ∀ p ∈ s, p.Prime := by
      intro p hp
      exact (hsAct p hp).1
    have hdisSR : Disjoint s Rset := hdis.mono_left hsub
    have hcop :
        (primeSetProduct s).Coprime (primeSetProduct Rset) :=
      (disjoint_iff_primeSetProduct_coprime hsPrime hPrimeR).1 hdisSR
    have hsqS : Squarefree (primeSetProduct s) :=
      primeSetProduct_squarefree hsPrime
    have hsqR : Squarefree (primeSetProduct Rset) :=
      primeSetProduct_squarefree hPrimeR
    have hsqP :
        Squarefree (primeSetProduct s * primeSetProduct Rset) :=
      (Nat.squarefree_mul hcop).2 ⟨hsqS, hsqR⟩
    have hP0 : primeSetProduct s * primeSetProduct Rset ≠ 0 :=
      hsqP.ne_zero
    have hcoef0 :
        0 ≤ K * (∏ p ∈ s, gammaPrimeTerm p) := by
      exact mul_nonneg hK
        (Finset.prod_nonneg fun p hp => gammaPrimeTerm_nonneg p)
    calc
      (∑ c ∈ (primeSetProduct s * primeSetProduct Rset).divisors,
        channel s c)
        ≤ ∑ c ∈ (primeSetProduct s * primeSetProduct Rset).divisors,
            K * (∏ p ∈ s, gammaPrimeTerm p) *
              invSqrtNat (primeSetProduct Rset) * invSqrtNat c := by
              apply Finset.sum_le_sum
              intro c hc
              exact hchan s hs c hc
      _ = K * (∏ p ∈ s, gammaPrimeTerm p) *
            invSqrtNat (primeSetProduct Rset) *
            (∑ c ∈ (primeSetProduct s * primeSetProduct Rset).divisors,
              invSqrtNat c) := by
              rw [Finset.mul_sum]
      _ = K * (∏ p ∈ s, gammaPrimeTerm p) *
            (invSqrtNat (primeSetProduct Rset) *
              forbiddenSurcharge
                (primeSetProduct s * primeSetProduct Rset)) := by
              rw [sum_divisors_invSqrt_eq_forbiddenSurcharge hP0 hsqP]
              ring
      _ ≤ K * (∏ p ∈ s, gammaPrimeTerm p) *
            forbiddenSurcharge (primeSetProduct s) := by
              have hsurMul :=
                source_forbiddenSurcharge_mul_of_coprime hcop
              rw [hsurMul]
              have hsurS0 :
                  0 ≤ forbiddenSurcharge (primeSetProduct s) := by
                unfold forbiddenSurcharge
                apply Finset.prod_nonneg
                intro p hp
                have hi : 0 ≤ invSqrtNat p := by
                  unfold invSqrtNat
                  positivity
                linarith
              have hmid :
                  invSqrtNat (primeSetProduct Rset) *
                    (forbiddenSurcharge (primeSetProduct s) *
                      forbiddenSurcharge (primeSetProduct Rset)) ≤
                    forbiddenSurcharge (primeSetProduct s) := by
                calc
                  _ = forbiddenSurcharge (primeSetProduct s) *
                      (invSqrtNat (primeSetProduct Rset) *
                        forbiddenSurcharge (primeSetProduct Rset)) := by ring
                  _ ≤ forbiddenSurcharge (primeSetProduct s) * 1 :=
                    mul_le_mul_of_nonneg_left hRbound hsurS0
                  _ = _ := by ring
              exact mul_le_mul_of_nonneg_left hmid hcoef0
  calc
    (∑ s ∈ S.powerset,
      ∑ c ∈ (primeSetProduct s * primeSetProduct Rset).divisors,
        channel s c)
      ≤ ∑ s ∈ S.powerset,
          K * (∏ p ∈ s, gammaPrimeTerm p) *
            forbiddenSurcharge (primeSetProduct s) := by
            apply Finset.sum_le_sum
            intro s hs
            exact hpoint s hs
    _ = K * (∑ s ∈ S.powerset,
          (∏ p ∈ s, gammaPrimeTerm p) *
            forbiddenSurcharge (primeSetProduct s)) := by
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro s hs
          ring
    _ ≤ K * Real.exp (∑' n : ℕ, sourceEnhancedGammaPrimeTerm n) := by
          exact mul_le_mul_of_nonneg_left
            (source_gamma_surcharge_powerset_uniform_bound S hPrimeS) hK

#print axioms source_sum_gammaChannels_uniform_forbidden

end PaperB.FixedQ
