import Mathlib.NumberTheory.Primorial
import Mathlib.NumberTheory.Harmonic.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Data.Nat.Factorization.Basic

/-!
# Oriel Upper — Mertens-lite

Elementary Chebyshev/Mertens-type bounds from `primorial_le_four_pow`:

* `oriel_band_recip_le`: `∑_{2^k < p ≤ 2^(k+1)} 1/p ≤ 4/k` for `k ≥ 1`;
* `oriel_mertens_pow2`: `∑_{p ≤ 2^N} 1/p ≤ 5 + 4 log (N+1)`;
* `oriel_mertens`: `∑_{p ≤ y} 1/p ≤ 5 + 4 log (log₂ y + 2)`;
* `oriel_primeFactors_recip`: `∑_{p ∣ F} 1/p ≤ 6 + 4 log (log₂ (log₂ F) + 2)`.
-/

open Finset Real

namespace OrielUpper

/-- Primes up to `n`. -/
def primesLe (n : ℕ) : Finset ℕ := (range (n + 1)).filter Nat.Prime

lemma mem_primesLe {n p : ℕ} : p ∈ primesLe n ↔ p ≤ n ∧ p.Prime := by
  simp [primesLe, Nat.lt_succ_iff]

/-- Chebyshev: `∑_{p ≤ n} log p ≤ n log 4`. -/
theorem oriel_sum_log_primes_le (n : ℕ) :
    ∑ p ∈ primesLe n, Real.log p ≤ n * Real.log 4 := by
  have hprod : ((primorial n : ℕ) : ℝ) = ∏ p ∈ primesLe n, (p : ℝ) := by
    simp [primorial, primesLe]
  have hpos : ∀ p ∈ primesLe n, (p : ℝ) ≠ 0 := by
    intro p hp
    have := (mem_primesLe.mp hp).2.pos
    exact_mod_cast this.ne'
  rw [← Real.log_prod hpos, ← hprod]
  have h4 : ((primorial n : ℕ) : ℝ) ≤ (4 : ℝ) ^ n := by
    exact_mod_cast primorial_le_four_pow n
  have hp0 : (0 : ℝ) < (primorial n : ℕ) := by
    exact_mod_cast primorial_pos n
  calc Real.log (primorial n : ℕ) ≤ Real.log ((4 : ℝ) ^ n) :=
        Real.log_le_log hp0 h4
    _ = n * Real.log 4 := by rw [Real.log_pow]

/-- Primes in the dyadic band `(2^k, 2^(k+1)]`. -/
def primeBand (k : ℕ) : Finset ℕ := (Ioc (2 ^ k) (2 ^ (k + 1))).filter Nat.Prime

theorem oriel_band_recip_le {k : ℕ} (hk : 1 ≤ k) :
    ∑ p ∈ primeBand k, (1 : ℝ) / p ≤ 4 / k := by
  set S := primeBand k
  have hk' : (0 : ℝ) < k := by exact_mod_cast hk
  have hlog2 : (0 : ℝ) < Real.log 2 := Real.log_pos (by norm_num)
  -- each prime in the band has log p ≥ k log 2
  have hlogp : ∀ p ∈ S, (k : ℝ) * Real.log 2 ≤ Real.log p := by
    intro p hp
    have hp' := (mem_filter.mp hp).1
    have hlt : 2 ^ k < p := (mem_Ioc.mp hp').1
    have : ((2 : ℝ) ^ k) ≤ p := by exact_mod_cast hlt.le
    calc (k : ℝ) * Real.log 2 = Real.log ((2 : ℝ) ^ k) := by rw [Real.log_pow]
      _ ≤ Real.log p := Real.log_le_log (by positivity) this
  have hsub : S ⊆ primesLe (2 ^ (k + 1)) := by
    intro p hp
    have hp' := mem_filter.mp hp
    exact mem_primesLe.mpr ⟨(mem_Ioc.mp hp'.1).2, hp'.2⟩
  have hsumlog : (S.card : ℝ) * ((k : ℝ) * Real.log 2) ≤ (2 ^ (k + 1) : ℕ) * Real.log 4 := by
    calc (S.card : ℝ) * ((k : ℝ) * Real.log 2) = ∑ p ∈ S, (k : ℝ) * Real.log 2 := by
          rw [sum_const, nsmul_eq_mul]
      _ ≤ ∑ p ∈ S, Real.log p := sum_le_sum hlogp
      _ ≤ ∑ p ∈ primesLe (2 ^ (k + 1)), Real.log p := by
          apply sum_le_sum_of_subset_of_nonneg hsub
          intro p hp _
          exact Real.log_nonneg (by exact_mod_cast (mem_primesLe.mp hp).2.one_lt.le)
      _ ≤ _ := oriel_sum_log_primes_le _
  have hlog4 : Real.log 4 = 2 * Real.log 2 := by
    rw [show (4 : ℝ) = 2 ^ 2 by norm_num, Real.log_pow]; norm_num
  -- card bound
  have hcard : (S.card : ℝ) ≤ 4 * 2 ^ k / k := by
    rw [hlog4] at hsumlog
    push_cast at hsumlog
    rw [le_div_iff₀ hk']
    have : (S.card : ℝ) * k * Real.log 2 ≤ (4 * 2 ^ k) * Real.log 2 := by
      nlinarith [pow_succ (2 : ℝ) k]
    exact le_of_mul_le_mul_right (by linarith) hlog2
  have hrecip : ∀ p ∈ S, (1 : ℝ) / p ≤ 1 / 2 ^ k := by
    intro p hp
    have hlt : 2 ^ k < p := (mem_Ioc.mp (mem_filter.mp hp).1).1
    apply one_div_le_one_div_of_le (by positivity)
    exact_mod_cast hlt.le
  calc ∑ p ∈ S, (1 : ℝ) / p ≤ ∑ p ∈ S, (1 : ℝ) / 2 ^ k := sum_le_sum hrecip
    _ = S.card * (1 / 2 ^ k) := by rw [sum_const, nsmul_eq_mul]
    _ ≤ (4 * 2 ^ k / k) * (1 / 2 ^ k) := by gcongr
    _ = 4 / k := by field_simp

lemma primesLe_pow_succ (N : ℕ) :
    primesLe (2 ^ (N + 1)) = primesLe (2 ^ N) ∪ primeBand N := by
  ext p
  simp only [mem_union, mem_primesLe, primeBand, mem_filter, mem_Ioc]
  constructor
  · rintro ⟨h1, hp⟩
    by_cases h : p ≤ 2 ^ N
    · exact Or.inl ⟨h, hp⟩
    · exact Or.inr ⟨⟨by omega, h1⟩, hp⟩
  · rintro (⟨h1, hp⟩ | ⟨⟨h1, h2⟩, hp⟩)
    · exact ⟨h1.trans (Nat.pow_le_pow_right (by norm_num) (Nat.le_succ N)), hp⟩
    · exact ⟨h2, hp⟩

lemma disjoint_primesLe_band (N : ℕ) : Disjoint (primesLe (2 ^ N)) (primeBand N) := by
  rw [disjoint_left]
  intro p h1 h2
  have := (mem_primesLe.mp h1).1
  have := (mem_Ioc.mp (mem_filter.mp h2).1).1
  omega

/-- Harmonic-type bookkeeping: `∑_{p ≤ 2^(N+1)} 1/p ≤ 1/2 + 4 H_N`. -/
theorem oriel_mertens_pow2_harmonic (N : ℕ) :
    ∑ p ∈ primesLe (2 ^ (N + 1)), (1 : ℝ) / p ≤ 1 / 2 + 4 * (harmonic N : ℝ) := by
  induction N with
  | zero =>
    have : primesLe (2 ^ (0 + 1)) = {2} := by
      ext p; simp only [mem_primesLe, mem_singleton]
      constructor
      · rintro ⟨h1, hp⟩
        have := hp.two_le
        omega
      · rintro rfl; exact ⟨by norm_num, Nat.prime_two⟩
    rw [this]; simp
  | succ n ih =>
    rw [primesLe_pow_succ (n + 1), sum_union (disjoint_primesLe_band _)]
    have hb := oriel_band_recip_le (k := n + 1) (by omega)
    have hh : (harmonic (n + 1) : ℝ) = harmonic n + 1 / (n + 1 : ℕ) := by
      rw [harmonic_succ]; push_cast; ring
    rw [hh]
    push_cast at hb ⊢
    have h4 : (4 : ℝ) / (n + 1) = 4 * (1 / (n + 1)) := by ring
    linarith

theorem oriel_mertens_pow2 (N : ℕ) :
    ∑ p ∈ primesLe (2 ^ N), (1 : ℝ) / p ≤ 5 + 4 * Real.log (N + 1) := by
  rcases N with _ | N
  · have : primesLe (2 ^ 0) = ∅ := by
      ext p; simp only [mem_primesLe, pow_zero, Finset.notMem_empty, iff_false, not_and]
      intro h hp; have := hp.two_le; omega
    rw [this]; simp only [sum_empty]
    have : (0 : ℝ) ≤ Real.log ((0 : ℕ) + 1 : ℝ) := by simp
    linarith
  · have h1 := oriel_mertens_pow2_harmonic N
    have h2 := harmonic_le_one_add_log N
    have h3 : Real.log N ≤ Real.log ((N + 1 : ℕ) + 1 : ℝ) := by
      rcases Nat.eq_zero_or_pos N with h | h
      · subst h; simp; positivity
      · apply Real.log_le_log (by exact_mod_cast h); push_cast; linarith
    push_cast at h3 ⊢
    linarith

theorem primesLe_mono {a b : ℕ} (h : a ≤ b) : primesLe a ⊆ primesLe b := by
  intro p hp
  have := mem_primesLe.mp hp
  exact mem_primesLe.mpr ⟨this.1.trans h, this.2⟩

/-- Mertens-lite for arbitrary `y`. -/
theorem oriel_mertens (y : ℕ) :
    ∑ p ∈ primesLe y, (1 : ℝ) / p ≤ 5 + 4 * Real.log (Nat.log 2 y + 2) := by
  have hy : y ≤ 2 ^ (Nat.log 2 y + 1) := (Nat.lt_pow_succ_log_self (by norm_num) y).le
  calc ∑ p ∈ primesLe y, (1 : ℝ) / p
      ≤ ∑ p ∈ primesLe (2 ^ (Nat.log 2 y + 1)), (1 : ℝ) / p := by
        apply sum_le_sum_of_subset_of_nonneg (primesLe_mono hy)
        intro p _ _; positivity
    _ ≤ 5 + 4 * Real.log ((Nat.log 2 y + 1 : ℕ) + 1) := oriel_mertens_pow2 _
    _ = 5 + 4 * Real.log (Nat.log 2 y + 2) := by push_cast; ring_nf

/-- The number of distinct prime factors is at most `log₂ F`. -/
theorem oriel_card_primeFactors_le (F : ℕ) : F.primeFactors.card ≤ Nat.log 2 F := by
  rcases Nat.eq_zero_or_pos F with h | hF
  · subst h; simp
  apply Nat.le_log_of_pow_le (by norm_num)
  calc 2 ^ F.primeFactors.card = ∏ _p ∈ F.primeFactors, 2 := by rw [prod_const]
    _ ≤ ∏ p ∈ F.primeFactors, p := by
        apply prod_le_prod' ; intro p hp
        exact (Nat.prime_of_mem_primeFactors hp).two_le
    _ ≤ F := Nat.le_of_dvd hF (Nat.prod_primeFactors_dvd F)

/-- Reciprocal sum over the prime factors of `F`. -/
theorem oriel_primeFactors_recip (F : ℕ) :
    ∑ p ∈ F.primeFactors, (1 : ℝ) / p ≤
      6 + 4 * Real.log (Nat.log 2 (Nat.log 2 F) + 2) := by
  set y := Nat.log 2 F
  have hsplit := sum_filter_add_sum_filter_not F.primeFactors (fun p => p ≤ y)
    (fun p => (1 : ℝ) / p)
  have hsmall : ∑ p ∈ F.primeFactors with p ≤ y, (1 : ℝ) / p ≤
      5 + 4 * Real.log (Nat.log 2 y + 2) := by
    refine le_trans ?_ (oriel_mertens y)
    apply sum_le_sum_of_subset_of_nonneg
    · intro p hp
      have := mem_filter.mp hp
      exact mem_primesLe.mpr ⟨this.2, Nat.prime_of_mem_primeFactors this.1⟩
    · intro p _ _; positivity
  have hlarge : ∑ p ∈ F.primeFactors with ¬ p ≤ y, (1 : ℝ) / p ≤ 1 := by
    have hc : ((F.primeFactors.filter (fun p => ¬ p ≤ y)).card : ℝ) ≤ y := by
      have := (card_filter_le F.primeFactors (fun p => ¬ p ≤ y)).trans
        (oriel_card_primeFactors_le F)
      exact_mod_cast this
    calc ∑ p ∈ F.primeFactors with ¬ p ≤ y, (1 : ℝ) / p
        ≤ ∑ p ∈ F.primeFactors with ¬ p ≤ y, (1 : ℝ) / (y + 1) := by
          apply sum_le_sum; intro p hp
          have := (mem_filter.mp hp).2
          apply one_div_le_one_div_of_le (by positivity)
          have : y + 1 ≤ p := by omega
          exact_mod_cast this
      _ = _ * (1 / (y + 1)) := by rw [sum_const, nsmul_eq_mul]
      _ ≤ (y : ℝ) * (1 / (y + 1)) := by gcongr
      _ ≤ 1 := by
          rw [mul_one_div, div_le_one (by positivity)]; linarith
  linarith

end OrielUpper
