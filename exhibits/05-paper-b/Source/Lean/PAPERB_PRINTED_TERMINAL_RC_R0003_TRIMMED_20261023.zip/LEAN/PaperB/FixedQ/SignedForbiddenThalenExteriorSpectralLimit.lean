import PaperB.FixedQ.SignedForbiddenThalenCutoffSpectralSource
import PaperB.FixedQ.SignedForbiddenThalenActiveExteriorFinite

open scoped BigOperators
open Filter

namespace PaperB.FixedQ

/-- Exact finite-support spectral exhaustion of the ACTUAL reduced signed
exterior. The finite support moves through the active ordinary primes
disjoint from d. The original Z cutoff remains an explicit signed
low-support subtraction; the shifted Ramanujan diagonal is unchanged.
This is an exact convergence theorem, NOT an analytic sublog estimate. -/
theorem thalen_reducedExteriorSignedCore_tendsto_spectralFinite
    {q A H Z : ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2 : ¬ 2 ∣ q → 2 ∣ H)
    (d : Finset ℕ) :
    Tendsto
      (fun N : ℕ =>
        let S := thalenActiveOrdinaryFiniteSupport q H d N
        (∑ y ∈ Finset.Ioo 0 H,
          fixedQLowWeight q A H y *
            (thalenFiniteCenteredPacket S (thalenFiniteA S) y *
              thalenFiniteCenteredPacket S (thalenFiniteA S) (H-y))) -
          rowWeightMass (fixedQLowWeight q A H) H *
            ((thalenFiniteA S - 1) ^ 2 +
              (thalenFiniteA S) ^ 2 *
                ((∏ p ∈ S, (1 - thalenPrimeDelta p ^ 2)) - 1)) -
          (∑ n ∈ S.powerset.filter (fun n => primeSetProduct n ≤ Z),
            thalenFiniteOuterSourceTerm q A H n))
      atTop (nhds (tavrenReducedExteriorSignedCore q A H Z d)) := by
  let S : ℕ → Finset ℕ :=
    fun N => thalenActiveOrdinaryFiniteSupport q H d N
  have hterm (N : ℕ) :
      (∑ n ∈ (Finset.range N).powerset,
        if Z < primeSetProduct n then
          dForbiddenReducedBooleanCoreTerm q A H d n
        else 0) =
      (∑ y ∈ Finset.Ioo 0 H,
        fixedQLowWeight q A H y *
          (thalenFiniteCenteredPacket (S N) (thalenFiniteA (S N)) y *
            thalenFiniteCenteredPacket (S N) (thalenFiniteA (S N)) (H-y))) -
        rowWeightMass (fixedQLowWeight q A H) H *
          ((thalenFiniteA (S N) - 1) ^ 2 +
            (thalenFiniteA (S N)) ^ 2 *
              ((∏ p ∈ S N, (1 - thalenPrimeDelta p ^ 2)) - 1)) -
        (∑ n ∈ (S N).powerset.filter
          (fun n => primeSetProduct n ≤ Z),
          thalenFiniteOuterSourceTerm q A H n) := by
    calc
      _ = (∑ n ∈ (S N).powerset.filter
            (fun n => Z < primeSetProduct n),
            dForbiddenReducedBooleanCoreTerm q A H d n) := by
              exact thalen_reducedExterior_range_eq_activeFinite q A H Z N d
      _ = _ := thalen_decorated_finite_exterior_eq_spectral_sub_small
        q A H Z d (S N)
        (fun n hn => thalen_activeFiniteSupport_is_active q H N d n hn)
        (thalen_activeFiniteSupport_disjoint q H N d)
  have hbase := thalen_reducedExteriorSignedCore_tendsto_rangePowerset
    (q := q) (A := A) (H := H) (Z := Z) hq hH h2 d
  have hfn :
      (fun N : ℕ =>
        (∑ y ∈ Finset.Ioo 0 H,
          fixedQLowWeight q A H y *
            (thalenFiniteCenteredPacket (S N) (thalenFiniteA (S N)) y *
              thalenFiniteCenteredPacket (S N) (thalenFiniteA (S N)) (H-y))) -
          rowWeightMass (fixedQLowWeight q A H) H *
            ((thalenFiniteA (S N) - 1) ^ 2 +
              (thalenFiniteA (S N)) ^ 2 *
                ((∏ p ∈ S N, (1 - thalenPrimeDelta p ^ 2)) - 1)) -
          (∑ n ∈ (S N).powerset.filter
            (fun n => primeSetProduct n ≤ Z),
            thalenFiniteOuterSourceTerm q A H n)) =
      (fun N : ℕ =>
        ∑ n ∈ (Finset.range N).powerset,
          if Z < primeSetProduct n then
            dForbiddenReducedBooleanCoreTerm q A H d n
          else 0) := by
    funext N
    exact (hterm N).symm
  change Tendsto
    (fun N : ℕ =>
      (∑ y ∈ Finset.Ioo 0 H,
        fixedQLowWeight q A H y *
          (thalenFiniteCenteredPacket (S N) (thalenFiniteA (S N)) y *
            thalenFiniteCenteredPacket (S N) (thalenFiniteA (S N)) (H-y))) -
        rowWeightMass (fixedQLowWeight q A H) H *
          ((thalenFiniteA (S N) - 1) ^ 2 +
            (thalenFiniteA (S N)) ^ 2 *
              ((∏ p ∈ S N, (1 - thalenPrimeDelta p ^ 2)) - 1)) -
        (∑ n ∈ (S N).powerset.filter
          (fun n => primeSetProduct n ≤ Z),
          thalenFiniteOuterSourceTerm q A H n))
    atTop (nhds (tavrenReducedExteriorSignedCore q A H Z d))
  rw [hfn]
  exact hbase

#print axioms thalen_reducedExteriorSignedCore_tendsto_spectralFinite

end PaperB.FixedQ
