import PaperB.FixedQ.H3DecoratedAnalyticShell

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def ordinaryBooleanFullAbsTerm
    (q a H : ℕ) (e : Finset ℕ) : ℝ :=
  (activeOrdinaryTwoDimensionalSet q H).indicator
    (fun e =>
      finiteOmegaWeightReal e *
        ((2 : ℝ) ^ e.card *
          |fixedProductBooleanDiscrepancy
            (fixedQLowWeight q a H) H e|)) e

noncomputable def ordinaryBooleanFullEndpointAbsTerm
    (q a H : ℕ) (e : Finset ℕ) : ℝ :=
  (activeOrdinaryTwoDimensionalSet q H).indicator
    (fun e =>
      finiteOmegaWeightReal e *
        |rowDiscrepancy (fixedQLowWeight q a H) H
          (primeSetProduct e) 1|) e

noncomputable def ordinaryBooleanEmptyEndpointAbsTerm
    (q a H : ℕ) (e : Finset ℕ) : ℝ :=
  (activeOrdinaryTwoDimensionalSet q H).indicator
    (fun e =>
      finiteOmegaWeightReal e *
        |rowDiscrepancy (fixedQLowWeight q a H) H
          1 (primeSetProduct e)|) e

noncomputable def ordinaryBooleanFullAbsFamily (q a H : ℕ) : ℝ :=
  ∑' e : Finset ℕ, ordinaryBooleanFullAbsTerm q a H e

noncomputable def ordinaryBooleanFullEndpointAbsFamily (q a H : ℕ) : ℝ :=
  ∑' e : Finset ℕ, ordinaryBooleanFullEndpointAbsTerm q a H e

noncomputable def ordinaryBooleanEmptyEndpointAbsFamily (q a H : ℕ) : ℝ :=
  ∑' e : Finset ℕ, ordinaryBooleanEmptyEndpointAbsTerm q a H e

theorem abs_ordinaryBooleanCoreTerm_le_full_add_endpoints
    (q a H : ℕ) (e : Finset ℕ) :
    |ordinaryBooleanCoreTerm q a H e| ≤
      ordinaryBooleanFullAbsTerm q a H e +
        ordinaryBooleanFullEndpointAbsTerm q a H e +
        ordinaryBooleanEmptyEndpointAbsTerm q a H e := by
  by_cases he : e ∈ activeOrdinaryTwoDimensionalSet q H
  · rw [ordinaryBooleanCoreTerm, Set.indicator_of_mem he]
    rw [ordinaryBooleanFullAbsTerm, Set.indicator_of_mem he]
    rw [ordinaryBooleanFullEndpointAbsTerm, Set.indicator_of_mem he]
    rw [ordinaryBooleanEmptyEndpointAbsTerm, Set.indicator_of_mem he]
    have hw0 : 0 ≤ finiteOmegaWeightReal e :=
      finiteOmegaWeightReal_nonneg_of_active he.2
    by_cases hne : e.Nonempty
    · rw [ordinaryBooleanInteriorDiscrepancy_eq_full_sub_endpoints
        (fixedQLowWeight q a H) H hne]
      rw [fixedProductPartitionDiscrepancy_full_left,
        fixedProductPartitionDiscrepancy_empty_left]
      rw [abs_mul, abs_of_nonneg hw0]
      have hp0 : 0 ≤ (2 : ℝ) ^ e.card := by positivity
      have htri :
          |(2 : ℝ) ^ e.card *
                fixedProductBooleanDiscrepancy
                  (fixedQLowWeight q a H) H e -
              rowDiscrepancy (fixedQLowWeight q a H) H
                (primeSetProduct e) 1 -
              rowDiscrepancy (fixedQLowWeight q a H) H
                1 (primeSetProduct e)|
            ≤ (2 : ℝ) ^ e.card *
                |fixedProductBooleanDiscrepancy
                  (fixedQLowWeight q a H) H e| +
              |rowDiscrepancy (fixedQLowWeight q a H) H
                (primeSetProduct e) 1| +
              |rowDiscrepancy (fixedQLowWeight q a H) H
                1 (primeSetProduct e)| := by
        calc
          |(2 : ℝ) ^ e.card *
                fixedProductBooleanDiscrepancy
                  (fixedQLowWeight q a H) H e -
              rowDiscrepancy (fixedQLowWeight q a H) H
                (primeSetProduct e) 1 -
              rowDiscrepancy (fixedQLowWeight q a H) H
                1 (primeSetProduct e)|
            ≤ |(2 : ℝ) ^ e.card *
                fixedProductBooleanDiscrepancy
                  (fixedQLowWeight q a H) H e| +
              |rowDiscrepancy (fixedQLowWeight q a H) H
                (primeSetProduct e) 1| +
              |rowDiscrepancy (fixedQLowWeight q a H) H
                1 (primeSetProduct e)| := by
                  exact (abs_sub _ _).trans
                    (add_le_add (abs_sub _ _) (le_refl _))
          _ = _ := by rw [abs_mul, abs_of_nonneg hp0]
      have hm := mul_le_mul_of_nonneg_left htri hw0
      simpa [mul_add, add_assoc] using hm
    · have he0 : e = ∅ := Finset.not_nonempty_iff_eq_empty.mp hne
      subst e
      simp [ordinaryBooleanInteriorDiscrepancy, finiteOmegaWeightReal]
      exact add_nonneg
        (add_nonneg (abs_nonneg _) (abs_nonneg _)) (abs_nonneg _)
  · simp [ordinaryBooleanCoreTerm, ordinaryBooleanFullAbsTerm,
      ordinaryBooleanFullEndpointAbsTerm,
      ordinaryBooleanEmptyEndpointAbsTerm, Set.indicator, he]

theorem ordinaryBooleanAbsFamily_le_full_add_endpoints
    {q a H : ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H)
    (hFull : Summable (ordinaryBooleanFullAbsTerm q a H))
    (hFullEnd : Summable (ordinaryBooleanFullEndpointAbsTerm q a H))
    (hEmptyEnd : Summable (ordinaryBooleanEmptyEndpointAbsTerm q a H)) :
    ordinaryBooleanAbsFamily q a H ≤
      ordinaryBooleanFullAbsFamily q a H +
        ordinaryBooleanFullEndpointAbsFamily q a H +
        ordinaryBooleanEmptyEndpointAbsFamily q a H := by
  have hAbs := summable_abs_ordinaryBooleanCoreTerm
    (q := q) (a := a) (h := H) hq hH h2admissible
  have hR : Summable (fun e : Finset ℕ =>
      ordinaryBooleanFullAbsTerm q a H e +
        ordinaryBooleanFullEndpointAbsTerm q a H e +
        ordinaryBooleanEmptyEndpointAbsTerm q a H e) :=
    (hFull.add hFullEnd).add hEmptyEnd
  unfold ordinaryBooleanAbsFamily
  unfold ordinaryBooleanFullAbsFamily
  unfold ordinaryBooleanFullEndpointAbsFamily
  unfold ordinaryBooleanEmptyEndpointAbsFamily
  calc
    (∑' e : Finset ℕ, |ordinaryBooleanCoreTerm q a H e|)
      ≤ ∑' e : Finset ℕ,
          (ordinaryBooleanFullAbsTerm q a H e +
            ordinaryBooleanFullEndpointAbsTerm q a H e +
            ordinaryBooleanEmptyEndpointAbsTerm q a H e) := by
          exact hAbs.tsum_le_tsum
            (fun e => abs_ordinaryBooleanCoreTerm_le_full_add_endpoints q a H e)
            hR
    _ = (∑' e : Finset ℕ, ordinaryBooleanFullAbsTerm q a H e) +
        (∑' e : Finset ℕ, ordinaryBooleanFullEndpointAbsTerm q a H e) +
        (∑' e : Finset ℕ, ordinaryBooleanEmptyEndpointAbsTerm q a H e) := by
          rw [(hFull.add hFullEnd).tsum_add hEmptyEnd,
            hFull.tsum_add hFullEnd]

#print axioms abs_ordinaryBooleanCoreTerm_le_full_add_endpoints
#print axioms ordinaryBooleanAbsFamily_le_full_add_endpoints

end PaperB.FixedQ
