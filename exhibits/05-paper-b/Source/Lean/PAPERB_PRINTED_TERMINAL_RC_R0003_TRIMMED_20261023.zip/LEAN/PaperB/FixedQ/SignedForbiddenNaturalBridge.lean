import PaperB.FixedQ.SignedForbiddenBridge
import PaperB.FixedQ.PureLeftTsumBridge

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def sourceForbiddenBooleanMainTerm
    (q a H : ℕ) (d n : Finset ℕ) : ℝ :=
  if (primeSetProduct n).Coprime
      (H * (6 * q) * primeSetProduct d) ∧ n.Nonempty then
    (activeOrdinaryTwoDimensionalSet q H).indicator
      (fun n => fixedQShiuWeight q (primeSetProduct n) *
        fixedProductBooleanDiscrepancy (fixedQLowWeight q a H) H n) n
  else 0

theorem dForbiddenBooleanShiuMainTerm_eq_source_signed
    {q a h H : ℕ} {d n : Finset ℕ}
    (hd : d ⊆ decoratedHeightPrimeSet q h) :
    dForbiddenBooleanShiuMainTerm q a H d n =
      sourceForbiddenBooleanMainTerm q a H d n := by
  classical
  by_cases hact : n ∈ activeOrdinaryTwoDimensionalSet q H
  · have hiff := dForbidden_source_coprime_iff hd hact
    by_cases hne : n.Nonempty
    · by_cases hdis : Disjoint d n
      · have hcop := hiff.mp hdis
        simp [dForbiddenBooleanShiuMainTerm,
          sourceForbiddenBooleanMainTerm, hdis, hcop, hne,
          Set.indicator_of_mem hact]
      · have hncop : ¬ (primeSetProduct n).Coprime
            (H * (6 * q) * primeSetProduct d) := by
          exact fun hc => hdis (hiff.mpr hc)
        simp [dForbiddenBooleanShiuMainTerm,
          sourceForbiddenBooleanMainTerm, hdis, hncop, hne]
    · have hn0 : n = ∅ := Finset.not_nonempty_iff_eq_empty.mp hne
      subst n
      simp [dForbiddenBooleanShiuMainTerm,
        sourceForbiddenBooleanMainTerm]
  · simp [dForbiddenBooleanShiuMainTerm,
      sourceForbiddenBooleanMainTerm, Set.indicator, hact]

theorem dForbiddenBooleanMainTerm_eq_source_signed
    {q a h H : ℕ} {d n : Finset ℕ}
    (hd : d ⊆ decoratedHeightPrimeSet q h) :
    dForbiddenBooleanMainTerm q a H d n =
      sourceForbiddenBooleanMainTerm q a H d n := by
  rw [dForbiddenBooleanMainTerm_eq_shiu]
  exact dForbiddenBooleanShiuMainTerm_eq_source_signed hd

noncomputable def sourceForbiddenBooleanNaturalTerm
    (q a H D m : ℕ) : ℝ :=
  if 1 < m ∧ Squarefree m ∧ m.Coprime (H * (6 * q) * D) then
    fixedQShiuWeight q m *
      fixedProductBooleanDiscrepancy
        (fixedQLowWeight q a H) H m.primeFactors
  else 0

theorem sourceForbiddenBooleanMainTerm_eq_natural_signed
    {q a H : ℕ} {d n : Finset ℕ}
    (hact : n ∈ activeOrdinaryTwoDimensionalSet q H) :
    sourceForbiddenBooleanMainTerm q a H d n =
      sourceForbiddenBooleanNaturalTerm
        q a H (primeSetProduct d) (primeSetProduct n) := by
  classical
  have hnPrime : ∀ p ∈ n, p.Prime := fun p hp => (hact.2 p hp).1
  have hsq : Squarefree (primeSetProduct n) :=
    primeSetProduct_squarefree hnPrime
  have hpf : (primeSetProduct n).primeFactors = n :=
    Nat.primeFactors_prod hnPrime
  by_cases hne : n.Nonempty
  · obtain ⟨p, hp⟩ := hne
    have hne' : n.Nonempty := ⟨p, hp⟩
    have hpPrime := hnPrime p hp
    have hpDiv : p ∣ primeSetProduct n := by
      unfold primeSetProduct
      exact Finset.dvd_prod_of_mem (fun x : ℕ => x) hp
    have hprodPos : 0 < primeSetProduct n := primeSetProduct_pos hnPrime
    have hpLe : p ≤ primeSetProduct n := Nat.le_of_dvd hprodPos hpDiv
    have hgt : 1 < primeSetProduct n := hpPrime.two_le.trans hpLe
    by_cases hcop : (primeSetProduct n).Coprime
        (H * (6 * q) * primeSetProduct d)
    · simp [sourceForbiddenBooleanMainTerm,
        sourceForbiddenBooleanNaturalTerm, hact, hne', hcop,
        hsq, hgt, hpf]
    · simp [sourceForbiddenBooleanMainTerm,
        sourceForbiddenBooleanNaturalTerm, hact, hne', hcop,
        hsq, hgt, hpf]
  · have hn0 : n = ∅ := Finset.not_nonempty_iff_eq_empty.mp hne
    subst n
    simp [sourceForbiddenBooleanMainTerm,
      sourceForbiddenBooleanNaturalTerm, primeSetProduct]

lemma sourceForbiddenBooleanMainTerm_eq_zero_of_not_all_prime
    {q a H : ℕ} {d n : Finset ℕ}
    (hn : ¬ ∀ p ∈ n, p.Prime) :
    sourceForbiddenBooleanMainTerm q a H d n = 0 := by
  classical
  by_cases hc :
      (primeSetProduct n).Coprime
        (H * (6 * q) * primeSetProduct d) ∧ n.Nonempty
  · rw [sourceForbiddenBooleanMainTerm, if_pos hc]
    have hnot : n ∉ activeOrdinaryTwoDimensionalSet q H := by
      intro hact
      exact hn (fun p hp => (hact.2 p hp).1)
    simp [Set.indicator, hnot]
  · simp [sourceForbiddenBooleanMainTerm, hc]


theorem sourceForbiddenBooleanMainTerm_eq_natural_signed_of_prime
    {q a H : ℕ} {d n : Finset ℕ}
    (hnPrime : ∀ p ∈ n, p.Prime) :
    sourceForbiddenBooleanMainTerm q a H d n =
      sourceForbiddenBooleanNaturalTerm
        q a H (primeSetProduct d) (primeSetProduct n) := by
  classical
  by_cases hne : n.Nonempty
  · by_cases hcop : (primeSetProduct n).Coprime
        (H * (6 * q) * primeSetProduct d)
    · have hnH : (primeSetProduct n).Coprime H := by
        exact (Nat.coprime_mul_iff_right.mp
          (Nat.coprime_mul_iff_right.mp hcop).1).1
      have hn6q : (primeSetProduct n).Coprime (6 * q) := by
        exact (Nat.coprime_mul_iff_right.mp
          (Nat.coprime_mul_iff_right.mp hcop).1).2
      have hOrd : n ∈ ordinaryTwoDimensionalSet H := by
        exact (ordinary_primeSetProduct_coprime_height_iff hnPrime).2 hnH
      have hAct : n ∈ activeOrdinaryTwoDimensionalSet q H := by
        refine ⟨hOrd, ?_⟩
        intro p hp
        have hpDiv : p ∣ primeSetProduct n := by
          unfold primeSetProduct
          exact Finset.dvd_prod_of_mem (fun x : ℕ => x) hp
        have hpCop6q : p.Coprime (6 * q) :=
          Nat.Coprime.of_dvd_left hpDiv hn6q
        have hp5 : 5 ≤ p :=
          prime_ge_five_of_coprime_six (hnPrime p hp) hpCop6q
        have hpq : ¬ p ∣ q := by
          intro hpq
          have hp6q : p ∣ 6 * q := dvd_mul_of_dvd_right hpq 6
          exact (hnPrime p hp).coprime_iff_not_dvd.mp hpCop6q hp6q
        exact ⟨hnPrime p hp, hp5, hpq⟩
      exact sourceForbiddenBooleanMainTerm_eq_natural_signed hAct
    · have hnat0 :
          sourceForbiddenBooleanNaturalTerm
            q a H (primeSetProduct d) (primeSetProduct n) = 0 := by
        simp [sourceForbiddenBooleanNaturalTerm, hcop]
      have hsrc0 : sourceForbiddenBooleanMainTerm q a H d n = 0 := by
        simp [sourceForbiddenBooleanMainTerm, hcop]
      rw [hsrc0, hnat0]
  · have hn0 : n = ∅ := Finset.not_nonempty_iff_eq_empty.mp hne
    subst n
    simp [sourceForbiddenBooleanMainTerm,
      sourceForbiddenBooleanNaturalTerm, primeSetProduct]

theorem tsum_sourceForbiddenBooleanMainTerm_eq_primeFinset
    (q a H : ℕ) (d : Finset ℕ) :
    (∑' n : Finset ℕ, sourceForbiddenBooleanMainTerm q a H d n) =
      ∑' s : PrimeFinset, sourceForbiddenBooleanMainTerm q a H d s.1 := by
  let P : Set (Finset ℕ) := {n | ∀ p ∈ n, p.Prime}
  have hind :
      (∑' n : Finset ℕ, sourceForbiddenBooleanMainTerm q a H d n) =
        ∑' n : Finset ℕ,
          P.indicator (sourceForbiddenBooleanMainTerm q a H d) n := by
    apply tsum_congr
    intro n
    by_cases hn : n ∈ P
    · simp [Set.indicator, hn]
    · have hz : sourceForbiddenBooleanMainTerm q a H d n = 0 := by
        apply sourceForbiddenBooleanMainTerm_eq_zero_of_not_all_prime
        simpa [P] using hn
      simp [Set.indicator, hn, hz]
  rw [hind]
  rw [← tsum_subtype]
  rfl

theorem tsum_sourceForbiddenBooleanMainTerm_eq_squarefreeNatural
    (q a H : ℕ) (d : Finset ℕ) :
    (∑' n : Finset ℕ, sourceForbiddenBooleanMainTerm q a H d n) =
      ∑' m : SquarefreeNat,
        sourceForbiddenBooleanNaturalTerm q a H
          (primeSetProduct d) m.1 := by
  rw [tsum_sourceForbiddenBooleanMainTerm_eq_primeFinset]
  have ht :=
    (Equiv.tsum_eq primeFinsetEquivSquarefreeNat
      (fun m : SquarefreeNat =>
        sourceForbiddenBooleanNaturalTerm q a H
          (primeSetProduct d) m.1)).symm
  calc
    (∑' s : PrimeFinset, sourceForbiddenBooleanMainTerm q a H d s.1) =
        ∑' s : PrimeFinset,
          sourceForbiddenBooleanNaturalTerm q a H
            (primeSetProduct d) (primeSetProduct s.1) := by
      apply tsum_congr
      intro s
      exact sourceForbiddenBooleanMainTerm_eq_natural_signed_of_prime s.2
    _ = ∑' m : SquarefreeNat,
          sourceForbiddenBooleanNaturalTerm q a H
            (primeSetProduct d) m.1 := by
      symm
      calc
        (∑' m : SquarefreeNat,
          sourceForbiddenBooleanNaturalTerm q a H
            (primeSetProduct d) m.1) =
          ∑' s : PrimeFinset,
            sourceForbiddenBooleanNaturalTerm q a H
              (primeSetProduct d)
              (primeFinsetEquivSquarefreeNat s).1 := ht
        _ = ∑' s : PrimeFinset,
            sourceForbiddenBooleanNaturalTerm q a H
              (primeSetProduct d) (primeSetProduct s.1) := by
          apply tsum_congr
          intro s
          rfl

lemma sourceForbiddenBooleanNaturalTerm_eq_zero_of_not_squarefree
    {q a H D m : ℕ} (hm : ¬ Squarefree m) :
    sourceForbiddenBooleanNaturalTerm q a H D m = 0 := by
  simp [sourceForbiddenBooleanNaturalTerm, hm]

theorem tsum_squarefree_sourceForbiddenNatural_eq_nat
    (q a H D : ℕ) :
    (∑' m : SquarefreeNat,
      sourceForbiddenBooleanNaturalTerm q a H D m.1) =
      ∑' m : ℕ, sourceForbiddenBooleanNaturalTerm q a H D m := by
  let S : Set ℕ := {m | Squarefree m}
  have hind :
      (∑' m : ℕ, S.indicator
        (sourceForbiddenBooleanNaturalTerm q a H D) m) =
        ∑' m : ℕ, sourceForbiddenBooleanNaturalTerm q a H D m := by
    apply tsum_congr
    intro m
    by_cases hm : m ∈ S
    · simp [Set.indicator, hm]
    · have hz : sourceForbiddenBooleanNaturalTerm q a H D m = 0 := by
        apply sourceForbiddenBooleanNaturalTerm_eq_zero_of_not_squarefree
        simpa [S] using hm
      simp [Set.indicator, hm, hz]
  rw [← hind]
  rw [← tsum_subtype]
  rfl

theorem tsum_sourceForbiddenBooleanMainTerm_eq_naturalNat
    (q a H : ℕ) (d : Finset ℕ) :
    (∑' n : Finset ℕ, sourceForbiddenBooleanMainTerm q a H d n) =
      ∑' m : ℕ,
        sourceForbiddenBooleanNaturalTerm q a H (primeSetProduct d) m := by
  rw [tsum_sourceForbiddenBooleanMainTerm_eq_squarefreeNatural]
  exact tsum_squarefree_sourceForbiddenNatural_eq_nat
    q a H (primeSetProduct d)


theorem sourceForbiddenBooleanNaturalTerm_eq_weighted_partition_sum
    {q a H D m : ℕ}
    (hgt : 1 < m)
    (hsq : Squarefree m)
    (hcop : m.Coprime (H * (6 * q) * D)) :
    sourceForbiddenBooleanNaturalTerm q a H D m =
      finiteOmegaWeightReal m.primeFactors *
        (∑ A ∈ m.primeFactors.powerset,
          fixedProductPartitionDiscrepancy
            (fixedQLowWeight q a H) H m.primeFactors A) := by
  classical
  have hpfProd : primeSetProduct m.primeFactors = m :=
    Nat.prod_primeFactors_of_squarefree hsq
  have hPrime : ∀ p ∈ m.primeFactors, p.Prime := by
    intro p hp
    exact (Nat.mem_primeFactors.mp hp).1
  have hm6q : m.Coprime (6 * q) := by
    exact (Nat.coprime_mul_iff_right.mp
      (Nat.coprime_mul_iff_right.mp hcop).1).2
  have hAct : ∀ p ∈ m.primeFactors, activeHighPrime q p := by
    intro p hp
    have hpPrime := hPrime p hp
    have hpDiv : p ∣ m := (Nat.mem_primeFactors.mp hp).2.1
    have hpCop6q : p.Coprime (6 * q) :=
      Nat.Coprime.of_dvd_left hpDiv hm6q
    exact ⟨hpPrime,
      prime_ge_five_of_coprime_six hpPrime hpCop6q,
      fun hpq =>
        (hpPrime.coprime_iff_not_dvd.mp hpCop6q)
          (dvd_mul_of_dvd_right hpq 6)⟩
  have hShiu :=
    fixedQShiuWeight_primeSetProduct_eq_card_mul_finiteOmegaWeightReal
      (q := q) (n := m.primeFactors) hAct
  have hShiuM :
      fixedQShiuWeight q m =
        (2 : ℝ) ^ m.primeFactors.card *
          finiteOmegaWeightReal m.primeFactors := by
    exact (congrArg (fixedQShiuWeight q) hpfProd).symm.trans hShiu
  have hAvg :=
    fixedProductBooleanDiscrepancy_eq_average
      (fixedQLowWeight q a H) H m.primeFactors
  rw [sourceForbiddenBooleanNaturalTerm, if_pos ⟨hgt, hsq, hcop⟩]
  rw [hShiuM]
  calc
    ((2 : ℝ) ^ m.primeFactors.card *
        finiteOmegaWeightReal m.primeFactors) *
        fixedProductBooleanDiscrepancy
          (fixedQLowWeight q a H) H m.primeFactors =
      finiteOmegaWeightReal m.primeFactors *
        ((2 : ℝ) ^ m.primeFactors.card *
          fixedProductBooleanDiscrepancy
            (fixedQLowWeight q a H) H m.primeFactors) := by ring
    _ = finiteOmegaWeightReal m.primeFactors *
        (∑ A ∈ m.primeFactors.powerset,
          fixedProductPartitionDiscrepancy
            (fixedQLowWeight q a H) H m.primeFactors A) := by rw [hAvg]

#print axioms sourceForbiddenBooleanNaturalTerm_eq_weighted_partition_sum

#print axioms sourceForbiddenBooleanMainTerm_eq_natural_signed_of_prime
#print axioms tsum_sourceForbiddenBooleanMainTerm_eq_naturalNat

#print axioms dForbiddenBooleanMainTerm_eq_source_signed
#print axioms sourceForbiddenBooleanMainTerm_eq_natural_signed
#print axioms sourceForbiddenBooleanMainTerm_eq_zero_of_not_all_prime

end PaperB.FixedQ
