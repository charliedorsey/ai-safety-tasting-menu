import PaperB.FixedQ.SignedForbiddenCompletedMainAggregateBridge
import PaperB.FixedQ.SignedForbiddenActiveTsumBridge

open scoped BigOperators

namespace PaperB.FixedQ

theorem signedForbiddenCompletedMainAggregate_eq_naturalAggregate
    (q a h : ℕ) :
    signedForbiddenCompletedMainAggregate q a h =
      (∑' m : ℕ,
        sourceForbiddenBooleanNaturalTerm q a h 1 m) +
      ∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
        finiteVWeightReal h d *
          (∑' m : ℕ,
            sourceForbiddenBooleanNaturalTerm q
              (decoratedReducedAnchor q a (primeSetProduct d))
              (h / primeSetProduct d)
              (primeSetProduct d) m) := by
  unfold signedForbiddenCompletedMainAggregate
  have h0 : (∀ p ∈ (∅ : Finset ℕ), activeHighPrime q p) := by simp
  rw [tsum_dForbiddenBooleanMainTerm_eq_naturalNat_of_active h0]
  apply congrArg (fun z : ℝ => (∑' m : ℕ,
      sourceForbiddenBooleanNaturalTerm q a h 1 m) + z)
  apply Finset.sum_congr rfl
  intro d hd
  have hdps :
      d ∈ (decoratedHeightPrimeSet q h).powerset :=
    (Finset.mem_erase.mp hd).2
  have hdsub : d ⊆ decoratedHeightPrimeSet q h :=
    Finset.mem_powerset.mp hdps
  have hdActive : ∀ p ∈ d, activeHighPrime q p :=
    decoratedHeightPrimeSet_active hdsub
  rw [tsum_dForbiddenBooleanMainTerm_eq_naturalNat_of_active hdActive]

#print axioms signedForbiddenCompletedMainAggregate_eq_naturalAggregate

end PaperB.FixedQ
