import PaperB.FixedQ.EtaCharacterBound
import PaperB.FixedQ.PetermannMovingTransfer

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ

theorem eta_character_weighted_sum_eq_correction_harmonic
    (q X : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (F : ℕ → ℂ) :
    (∑ n ∈ Finset.Icc 1 X,
      (chi n) * (etaCoeff q n : ℂ) * F n) =
      ∑ d ∈ Finset.Icc 1 X,
        (chi d) * (etaCorrectionInvTerm q d : ℂ) *
          ∑ m ∈ Finset.Icc 1 (X / d),
            ((chi m) / (m : ℂ)) * F (d * m) := by
  classical
  calc
    (∑ n ∈ Finset.Icc 1 X,
      (chi n) * (etaCoeff q n : ℂ) * F n)
      =
    ∑ n ∈ Finset.Icc 1 X,
      ∑ ds ∈ n.divisorsAntidiagonal,
        ((chi n) *
          ((etaCorrectionInvTerm q ds.2 : ℂ) *
            ((coprimeIndicatorArithmetic q ds.1 : ℝ) : ℂ) /
              (ds.1 : ℂ))) * F n := by
        apply Finset.sum_congr rfl
        intro n hn
        have hn0 : n ≠ 0 := by
          rw [Finset.mem_Icc] at hn
          omega
        rw [etaCoeff_eq_correction_divisor_sum q n hn0]
        push_cast
        simp_rw [Finset.mul_sum, Finset.sum_mul]
        apply Finset.sum_congr rfl
        intro ds hds
        ring
    _ =
    ∑ n ∈ Finset.Icc 1 X,
      ∑ ds ∈ n.divisorsAntidiagonal,
        ((chi ds.2) * (etaCorrectionInvTerm q ds.2 : ℂ) *
          ((chi ds.1) *
            ((coprimeIndicatorArithmetic q ds.1 : ℝ) : ℂ) /
              (ds.1 : ℂ))) * F n := by
        apply Finset.sum_congr rfl
        intro n hn
        apply Finset.sum_congr rfl
        intro ds hds
        have hprod : ds.1 * ds.2 = n :=
          (Nat.mem_divisorsAntidiagonal.mp hds).1
        have hcast0 :=
          congrArg (fun t : ℕ => (t : ZMod (Nat.lcm 6 q))) hprod
        have hcast :
            (ds.1 : ZMod (Nat.lcm 6 q)) *
                (ds.2 : ZMod (Nat.lcm 6 q)) =
              (n : ZMod (Nat.lcm 6 q)) := by
          simpa [Nat.cast_mul] using hcast0
        rw [← hcast, map_mul]
        ring
    _ =
    ∑ x ∈ petermannDivisorSigma X,
      ((chi x.2.2) * (etaCorrectionInvTerm q x.2.2 : ℂ) *
        ((chi x.2.1) *
          ((coprimeIndicatorArithmetic q x.2.1 : ℝ) : ℂ) /
            (x.2.1 : ℂ))) * F x.1 := by
        rw [petermannDivisorSigma, Finset.sum_sigma']
    _ =
    ∑ x ∈ petermannDivisorSigma X,
      ((chi x.2.2) * (etaCorrectionInvTerm q x.2.2 : ℂ) *
        ((chi x.2.1) *
          ((coprimeIndicatorArithmetic q x.2.1 : ℝ) : ℂ) /
            (x.2.1 : ℂ))) * F (x.2.2 * x.2.1) := by
        apply Finset.sum_congr rfl
        intro x hx
        rw [petermannDivisorSigma, Finset.mem_sigma] at hx
        have hmul : x.2.1 * x.2.2 = x.1 :=
          (Nat.prodMk_mem_divisorsAntidiag
            (by
              rw [Finset.mem_Icc] at hx
              omega)).mp hx.2
        have hmul' : x.2.2 * x.2.1 = x.1 := by
          simpa [mul_comm] using hmul
        rw [hmul']
    _ =
    ∑ d ∈ Finset.Icc 1 X,
      ∑ m ∈ Finset.Icc 1 (X / d),
        ((chi d) * (etaCorrectionInvTerm q d : ℂ) *
          ((chi m) *
            ((coprimeIndicatorArithmetic q m : ℝ) : ℂ) /
              (m : ℂ))) * F (d * m) := by
        exact sum_petermannDivisorSigma_eq_nested X
          (fun d m =>
            ((chi d) * (etaCorrectionInvTerm q d : ℂ) *
              ((chi m) *
                ((coprimeIndicatorArithmetic q m : ℝ) : ℂ) /
                  (m : ℂ))) * F (d * m))
    _ =
      ∑ d ∈ Finset.Icc 1 X,
        (chi d) * (etaCorrectionInvTerm q d : ℂ) *
          ∑ m ∈ Finset.Icc 1 (X / d),
            ((chi m) / (m : ℂ)) * F (d * m) := by
        apply Finset.sum_congr rfl
        intro d hd
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro m hm
        have hm0 : m ≠ 0 := by
          rw [Finset.mem_Icc] at hm
          omega
        rw [dirichletCharacter_mul_coprimeIndicator q m chi hm0]
        ring

theorem petermannBaseKernelSum_eta_eq_correction_harmonic
    (q : ℕ)
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (r : ℤ) (T : ℝ) (X : ℕ) :
    petermannBaseKernelSum q PetermannBase.eta chi r T X =
      ∑ d ∈ Finset.Icc 1 X,
        (chi d) * (etaCorrectionInvTerm q d : ℂ) *
          ∑ m ∈ Finset.Icc 1 (X / d),
            ((chi m) / (m : ℂ)) *
              (petermannSawtooth
                (T / ((Nat.lcm 6 q : ℕ) : ℝ) /
                    ((d * m : ℕ) : ℝ) +
                  (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ) := by
  unfold petermannBaseKernelSum
  simp only [petermannBaseCoeff]
  exact eta_character_weighted_sum_eq_correction_harmonic q X chi
    (fun n =>
      (petermannSawtooth
        (T / ((Nat.lcm 6 q : ℕ) : ℝ) / (n : ℝ) +
          (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) : ℂ))

#print axioms eta_character_weighted_sum_eq_correction_harmonic
#print axioms petermannBaseKernelSum_eta_eq_correction_harmonic

end PaperB.Analytic
