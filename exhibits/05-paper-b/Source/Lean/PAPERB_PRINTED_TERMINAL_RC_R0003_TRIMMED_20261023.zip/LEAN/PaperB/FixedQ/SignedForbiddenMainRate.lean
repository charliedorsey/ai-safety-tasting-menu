import PaperB.FixedQ.SignedForbiddenChannelBridge
import PaperB.FixedQ.SignedForbiddenCompletionBridge
import PaperB.FixedQ.H2CoreExteriorRamanujan
import PaperB.FixedQ.WeilPaid
import PaperB.FixedQ.H2BooleanAffineET
import PaperB.FixedQ.H2GlobalReaggregation
import PaperB.FixedQ.GlobalProperAnalyticBridge
import PaperB.FixedQ.H2BooleanGlobalSourceSplit
import PaperB.FixedQ.H2ProperSmallProductRate
import PaperB.FixedQ.GlobalProperSmallBoxTerminal

open scoped BigOperators

namespace PaperB.FixedQ

lemma source_quarterRootNat_finset_prod (S : Finset ℕ) :
    quarterRootNat (∏ p ∈ S, p) =
      ∏ p ∈ S, quarterRootNat p := by
  unfold quarterRootNat
  rw [Nat.cast_prod, Real.sqrt_prod]
  · rw [Real.sqrt_prod]
    intro p hp
    exact Real.sqrt_nonneg _
  · intro p hp
    positivity

lemma source_ramanujanResonantFactor_le_quarterRoot
    {p : ℕ} (hp11 : 11 ≤ p) :
    1 + ramanujanResonantPrimeFactor p ≤ quarterRootNat p := by
  unfold ramanujanResonantPrimeFactor quarterRootNat
  have hpR : (11 : ℝ) ≤ (p : ℝ) := by exact_mod_cast hp11
  have hp0 : (0 : ℝ) < (p : ℝ) := by positivity
  have hs0 : 0 ≤ Real.sqrt (p : ℝ) := Real.sqrt_nonneg _
  have hs2 : Real.sqrt (p : ℝ) ^ 2 = (p : ℝ) :=
    Real.sq_sqrt hp0.le
  have hden : (0 : ℝ) < (p : ℝ) - 3 := by linarith
  have hpoly :
      0 ≤ ((p : ℝ) - 1) * ((p : ℝ) - 9) :=
    mul_nonneg (by linarith) (by linarith)
  have hsq :
      (2 * Real.sqrt (p : ℝ)) ^ 2 ≤ ((p : ℝ) - 3) ^ 2 := by
    rw [mul_pow, hs2]
    nlinarith
  have htwosqrt :
      2 * Real.sqrt (p : ℝ) ≤ (p : ℝ) - 3 :=
    (sq_le_sq₀ (by positivity) hden.le).mp hsq
  have hfrac :
      Real.sqrt (p : ℝ) / ((p : ℝ) - 3) ≤ (1 / 2 : ℝ) := by
    apply (div_le_iff₀ hden).2
    nlinarith
  have h9 : (9 : ℝ) ≤ (p : ℝ) := by linarith
  have hsqrt9 : Real.sqrt (9 : ℝ) = 3 := by
    rw [show (9 : ℝ) = (3 : ℝ) ^ 2 by norm_num,
      Real.sqrt_sq (by norm_num)]
  have hsqrt3 : (3 : ℝ) ≤ Real.sqrt (p : ℝ) := by
    have h := Real.sqrt_le_sqrt h9
    simpa [hsqrt9] using h
  have hquarter :
      (3 / 2 : ℝ) ≤ Real.sqrt (Real.sqrt (p : ℝ)) := by
    apply (Real.le_sqrt (by norm_num) hs0).2
    nlinarith
  linarith

lemma source_ramanujanResonantFactor_le_three
    {p : ℕ} (hp5 : 5 ≤ p) :
    1 + ramanujanResonantPrimeFactor p ≤ 3 := by
  unfold ramanujanResonantPrimeFactor
  have hpR : (5 : ℝ) ≤ (p : ℝ) := by exact_mod_cast hp5
  have hp0 : (0 : ℝ) < (p : ℝ) := by positivity
  have hs0 : 0 ≤ Real.sqrt (p : ℝ) := Real.sqrt_nonneg _
  have hs2 : Real.sqrt (p : ℝ) ^ 2 = (p : ℝ) :=
    Real.sq_sqrt hp0.le
  have hden : (0 : ℝ) < (p : ℝ) - 3 := by linarith
  have hpoly :
      0 ≤ (2 * ((p : ℝ) - 3)) ^ 2 -
        (Real.sqrt (p : ℝ)) ^ 2 := by
    rw [hs2]
    nlinarith
  have hle : Real.sqrt (p : ℝ) ≤ 2 * ((p : ℝ) - 3) := by
    apply (sq_le_sq₀ hs0 (by linarith)).mp
    nlinarith
  have hfrac :
      Real.sqrt (p : ℝ) / ((p : ℝ) - 3) ≤ 2 := by
    exact (div_le_iff₀ hden).2 hle
  linarith

lemma source_quarterRootNat_mono {a b : ℕ} (hab : a ≤ b) :
    quarterRootNat a ≤ quarterRootNat b := by
  unfold quarterRootNat
  apply Real.sqrt_le_sqrt
  apply Real.sqrt_le_sqrt
  exact_mod_cast hab

theorem source_ramanujanResonantSurcharge_le_const_quarterRoot
    {j : ℕ} (hj : 0 < j) :
    ramanujanResonantSurcharge j ≤
      (3 : ℝ) ^ 11 * quarterRootNat j := by
  let J := j.primeFactors.filter (fun p => 5 ≤ p)
  let Hi := J.filter (fun p => 11 ≤ p)
  let Lo := J.filter (fun p => ¬ 11 ≤ p)
  have hsplit :
      (∏ p ∈ Lo, (1 + ramanujanResonantPrimeFactor p)) *
        (∏ p ∈ Hi, (1 + ramanujanResonantPrimeFactor p)) =
      ramanujanResonantSurcharge j := by
    unfold ramanujanResonantSurcharge
    dsimp [J, Hi, Lo]
    rw [← Finset.prod_filter_mul_prod_filter_not
      (j.primeFactors.filter (fun p => 5 ≤ p))
      (fun p => 11 ≤ p)
      (fun p => 1 + ramanujanResonantPrimeFactor p)]
    ring
  have hLoSubRange : Lo ⊆ Finset.range 11 := by
    intro p hp
    have hp' := Finset.mem_filter.mp hp
    have hlt : p < 11 := Nat.lt_of_not_ge hp'.2
    exact Finset.mem_range.mpr hlt
  have hLoNonneg :
      ∀ p ∈ Lo, 0 ≤ 1 + ramanujanResonantPrimeFactor p := by
    intro p hp
    have hpJ := Finset.mem_filter.mp (Finset.mem_filter.mp hp).1
    linarith [ramanujanResonantPrimeFactor_nonneg hpJ.2]
  have hLoThree :
      ∏ p ∈ Lo, (1 + ramanujanResonantPrimeFactor p) ≤
        ∏ _p ∈ Lo, (3 : ℝ) := by
    apply Finset.prod_le_prod₀ hLoNonneg
    intro p hp
    have hpJ := Finset.mem_filter.mp (Finset.mem_filter.mp hp).1
    exact source_ramanujanResonantFactor_le_three hpJ.2
  have hLoConst :
      (∏ _p ∈ Lo, (3 : ℝ)) ≤
        ∏ _p ∈ Finset.range 11, (3 : ℝ) := by
    exact Finset.prod_le_prod_of_subset_of_one_le₀
      hLoSubRange (fun _p _hp => by norm_num)
        (fun _p _hp _hnot => by norm_num)
  have hLo :
      ∏ p ∈ Lo, (1 + ramanujanResonantPrimeFactor p) ≤
        (3 : ℝ) ^ 11 := by
    calc
      _ ≤ ∏ _p ∈ Lo, (3 : ℝ) := hLoThree
      _ ≤ ∏ _p ∈ Finset.range 11, (3 : ℝ) := hLoConst
      _ = (3 : ℝ) ^ 11 := by simp
  have hHiSub : Hi ⊆ j.primeFactors := by
    intro p hp
    exact (Finset.mem_filter.mp (Finset.mem_filter.mp hp).1).1
  have hHiPrime : ∀ p ∈ Hi, p.Prime := by
    intro p hp
    exact Nat.prime_of_mem_primeFactors (hHiSub hp)
  have hHiNonneg :
      ∀ p ∈ Hi, 0 ≤ 1 + ramanujanResonantPrimeFactor p := by
    intro p hp
    have hpJ := Finset.mem_filter.mp (Finset.mem_filter.mp hp).1
    linarith [ramanujanResonantPrimeFactor_nonneg hpJ.2]
  have hHiQuarter :
      ∏ p ∈ Hi, (1 + ramanujanResonantPrimeFactor p) ≤
        ∏ p ∈ Hi, quarterRootNat p := by
    apply Finset.prod_le_prod₀ hHiNonneg
    intro p hp
    exact source_ramanujanResonantFactor_le_quarterRoot
      (Finset.mem_filter.mp hp).2
  have hHiDvd : (∏ p ∈ Hi, p) ∣ j := by
    exact (Finset.prod_dvd_prod_of_subset Hi j.primeFactors
      (fun p => p) hHiSub).trans (Nat.prod_primeFactors_dvd j)
  have hHiNatLe : (∏ p ∈ Hi, p) ≤ j :=
    Nat.le_of_dvd hj hHiDvd
  have hHi :
      ∏ p ∈ Hi, (1 + ramanujanResonantPrimeFactor p) ≤
        quarterRootNat j := by
    calc
      _ ≤ ∏ p ∈ Hi, quarterRootNat p := hHiQuarter
      _ = quarterRootNat (∏ p ∈ Hi, p) :=
        (source_quarterRootNat_finset_prod Hi).symm
      _ ≤ quarterRootNat j := source_quarterRootNat_mono hHiNatLe
  rw [← hsplit]
  have hHi0 :
      0 ≤ ∏ p ∈ Hi, (1 + ramanujanResonantPrimeFactor p) :=
    Finset.prod_nonneg hHiNonneg
  exact mul_le_mul hLo hHi hHi0 (by positivity)

theorem source_ramanujanMeanPowerset_tail_le_explicit
    {j Y K : ℕ}
    (hj : 0 < j) (hY : 0 < Y) (hjK : j ≤ K)
    {P : Finset ℕ} (hPrime : ∀ p ∈ P, p.Prime)
    (h5 : ∀ p ∈ P, 5 ≤ p) :
    (∑ S ∈ P.powerset.filter
        (fun S => Y < primeSetProduct S),
        ramanujanMeanSetWeight j S) ≤
      (Real.sqrt (Y : ℝ))⁻¹ *
        ((3 : ℝ) ^ 11 * quarterRootNat K) *
        Real.exp (∑' n : ℕ, gammaPrimeTerm n) := by
  have htail :=
    ramanujanMeanPowerset_tail_le
      hj hY hPrime h5
  have hsurcharge :=
    source_ramanujanResonantSurcharge_le_const_quarterRoot hj
  have hquarter := source_quarterRootNat_mono hjK
  have hs :
      ramanujanResonantSurcharge j ≤
        (3 : ℝ)^11 * quarterRootNat K := by
    exact hsurcharge.trans
      (mul_le_mul_of_nonneg_left hquarter (by positivity))
  have hinv0 : 0 ≤ (Real.sqrt (Y : ℝ))⁻¹ := by positivity
  have hexp0 : 0 ≤ Real.exp (∑' n : ℕ, gammaPrimeTerm n) :=
    (Real.exp_pos _).le
  calc
    _ ≤ (Real.sqrt (Y : ℝ))⁻¹ *
        ramanujanResonantSurcharge j *
        Real.exp (∑' n : ℕ, gammaPrimeTerm n) := htail
    _ ≤ (Real.sqrt (Y : ℝ))⁻¹ *
        ((3 : ℝ)^11 * quarterRootNat K) *
        Real.exp (∑' n : ℕ, gammaPrimeTerm n) := by
      exact mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_left hs hinv0) hexp0



lemma source_small_channel_rescale
    {G C U D Y F : ℝ}
    (hG : 0 ≤ G) (hC : 0 ≤ C)
    (hU : 0 < U) (hD : 0 < D) (hY : 0 < Y) (hF : 0 < F)
    (hscale : U ≤ D * F ^ 2 * Y)
    {Z : ℝ} (hZ : Z ≤ C / Y) :
    (G / (D * F ^ 2)) * Z ≤ G * C / U := by
  have hDF : 0 < D * F ^ 2 := by positivity
  have hden : 0 < D * F ^ 2 * Y := mul_pos hDF hY
  have hleft :
      (G / (D * F ^ 2)) * Z ≤
        (G / (D * F ^ 2)) * (C / Y) := by
    exact mul_le_mul_of_nonneg_left hZ (by positivity)
  have hratio :
      (G / (D * F ^ 2)) * (C / Y) =
        G * C / (D * F ^ 2 * Y) := by
    field_simp [hDF.ne', hY.ne']
  have hinv :
      (D * F ^ 2 * Y)⁻¹ ≤ U⁻¹ := by
    simpa [one_div] using
      (one_div_le_one_div_of_le hU hscale)
  have hGC : 0 ≤ G * C := mul_nonneg hG hC
  calc
    (G / (D * F ^ 2)) * Z
      ≤ (G / (D * F ^ 2)) * (C / Y) := hleft
    _ = G * C / (D * F ^ 2 * Y) := hratio
    _ ≤ G * C / U := by
      simp only [div_eq_mul_inv]
      exact mul_le_mul_of_nonneg_left hinv hGC

lemma source_large_channel_of_unit_mass
    {G D F Z : ℝ}
    (hG : 0 ≤ G) (hD : 0 < D) (hF : 0 < F)
    (hZ : Z ≤ 1) :
    (G / (D * F ^ 2)) * Z ≤
      (G / D) * F⁻¹ ^ 2 := by
  have hcoef : 0 ≤ G / (D * F ^ 2) := by positivity
  calc
    (G / (D * F ^ 2)) * Z
      ≤ (G / (D * F ^ 2)) * 1 :=
        mul_le_mul_of_nonneg_left hZ hcoef
    _ = (G / D) * F⁻¹ ^ 2 := by
      field_simp [hD.ne', hF.ne']

#print axioms source_small_channel_rescale
#print axioms source_large_channel_of_unit_mass

theorem completedBooleanMainTerm_eq_sourceMain_of_active_ordinary
    {q a H : ℕ} (hq : 0 < q) {n : Finset ℕ}
    (hact : n ∈ activeOrdinaryTwoDimensionalSet q H)
    (hne : n.Nonempty) :
    completedBooleanMainTerm q a H n =
      fixedQShiuWeight q (primeSetProduct n) *
        fixedProductBooleanDiscrepancy (fixedQLowWeight q a H) H n := by
  have hheight : heightPrimePart H n = ∅ := hact.1
  have hcomp : n ∈ completedBooleanSupport q H := by
    refine ⟨hact.2, ?_⟩
    rw [hheight]
    exact Ne.symm (Finset.nonempty_iff_ne_empty.mp hne)
  rw [completedBooleanMainTerm, Set.indicator_of_mem hcomp]
  simp only [hheight, decoratedHeightProduct, primeSetProduct,
    Finset.prod_empty, decoratedReducedHeight, Nat.div_one,
    Finset.sdiff_empty, finiteVWeightReal, Finset.prod_empty, one_mul]
  have ha1 := decoratedReducedAnchor_one (q := q) (a := a) hq
  rw [ha1]
  have hw :
      fixedQLowWeight q (a % q) H =
        fixedQLowWeight q a H := by
    funext y
    exact (fixedQLowWeight_anchor_mod q a H y).symm
  rw [hw]
  have hshiu :=
    fixedQShiuWeight_primeSetProduct_eq_card_mul_finiteOmegaWeightReal
      (q := q) (n := n) hact.2
  change
    finiteOmegaWeightReal n *
        ((2 : ℝ) ^ n.card *
          fixedProductBooleanDiscrepancy (fixedQLowWeight q a H) H n) =
      fixedQShiuWeight q (primeSetProduct n) *
        fixedProductBooleanDiscrepancy (fixedQLowWeight q a H) H n
  rw [hshiu]
  ring

theorem abs_sourceForbiddenBooleanMainTerm_le_abs_completed
    {q a H : ℕ} (hq : 0 < q) (d n : Finset ℕ) :
    |sourceForbiddenBooleanMainTerm q a H d n| ≤
      |completedBooleanMainTerm q a H n| := by
  classical
  by_cases hact : n ∈ activeOrdinaryTwoDimensionalSet q H
  · by_cases hne : n.Nonempty
    · have hcomp :=
        completedBooleanMainTerm_eq_sourceMain_of_active_ordinary
          (q := q) (a := a) (H := H) hq hact hne
      rw [sourceForbiddenBooleanMainTerm]
      by_cases hcop :
          (primeSetProduct n).Coprime
            (H * (6 * q) * primeSetProduct d)
      · rw [if_pos ⟨hcop, hne⟩, Set.indicator_of_mem hact, hcomp]
      · rw [if_neg (by simp [hcop])]
        simpa using (abs_nonneg (completedBooleanMainTerm q a H n))
    · have hn0 : n = ∅ := Finset.not_nonempty_iff_eq_empty.mp hne
      subst n
      simp [sourceForbiddenBooleanMainTerm, completedBooleanMainTerm,
        completedBooleanSupport, heightPrimePart]
  · have hsrc0 : sourceForbiddenBooleanMainTerm q a H d n = 0 := by
      simp [sourceForbiddenBooleanMainTerm, Set.indicator, hact]
    rw [hsrc0, abs_zero]
    exact abs_nonneg (completedBooleanMainTerm q a H n)

theorem summable_sourceForbiddenBooleanMainTerm
    {q a H : ℕ} (hq : 0 < q) (hH : 0 < H)
    (h2 : ¬ 2 ∣ q → 2 ∣ H)
    (d : Finset ℕ) :
    Summable (sourceForbiddenBooleanMainTerm q a H d) := by
  let r := PaperB.Closure.reflectedResidue q (a + H)
  have hreflect :
      ∀ z ∈ Finset.Ioo 0 H,
        q.Coprime (a + (H - z)) ↔ q.Coprime (r + z) := by
    dsimp [r]
    exact PaperB.Closure.reflected_coprime_equiv hq (Nat.ModEq.refl (a + H))
  have hmain :=
    summable_completedBooleanMainTerm
      (q := q) (a := a) (r := r) (h := H)
      hq hH h2 hreflect
  exact hmain.norm.of_norm_bounded (fun n => by
    simpa [Real.norm_eq_abs] using
      abs_sourceForbiddenBooleanMainTerm_le_abs_completed
        (q := q) (a := a) (H := H) hq d n)

theorem summable_sourceForbiddenBooleanNaturalTerm
    {q a H : ℕ} (hq : 0 < q) (hH : 0 < H)
    (h2 : ¬ 2 ∣ q → 2 ∣ H)
    (d : Finset ℕ) :
    Summable (sourceForbiddenBooleanNaturalTerm q a H (primeSetProduct d)) := by
  have hsrc :=
    summable_sourceForbiddenBooleanMainTerm
      (q := q) (a := a) (H := H) hq hH h2 d
  have hprime0 :
      Summable ((sourceForbiddenBooleanMainTerm q a H d) ∘
        (fun s : PrimeFinset => s.1)) := by
    exact hsrc.comp_injective (fun x y hxy => Subtype.ext hxy)
  have hprime :
      Summable (fun s : PrimeFinset =>
        sourceForbiddenBooleanNaturalTerm q a H
          (primeSetProduct d) (primeSetProduct s.1)) := by
    exact hprime0.congr (fun s =>
      sourceForbiddenBooleanMainTerm_eq_natural_signed_of_prime s.2)
  let f : SquarefreeNat → ℝ := fun m =>
    sourceForbiddenBooleanNaturalTerm q a H (primeSetProduct d) m.1
  have heq :
      (fun s : PrimeFinset =>
        sourceForbiddenBooleanNaturalTerm q a H
          (primeSetProduct d) (primeSetProduct s.1)) =
        f ∘ primeFinsetEquivSquarefreeNat := by
    funext s
    rfl
  have hsq : Summable f := by
    apply (Equiv.summable_iff primeFinsetEquivSquarefreeNat).mp
    simpa [heq] using hprime
  let S : Set ℕ := {m | Squarefree m}
  have hsub :
      Summable ((sourceForbiddenBooleanNaturalTerm q a H
        (primeSetProduct d)) ∘ (fun m : SquarefreeNat => m.1)) := by
    exact hsq.congr (fun m => rfl)
  have hind :
      Summable (S.indicator
        (sourceForbiddenBooleanNaturalTerm q a H (primeSetProduct d))) := by
    exact (summable_subtype_iff_indicator).mp hsub
  exact hind.congr (fun m => by
    by_cases hm : Squarefree m
    · simp [S, hm]
    · simp [S, hm, sourceForbiddenBooleanNaturalTerm_eq_zero_of_not_squarefree hm])

#print axioms summable_sourceForbiddenBooleanNaturalTerm

lemma ordinaryBooleanFullAbsTerm_nonneg'
    (q a H : ℕ) (n : Finset ℕ) :
    0 ≤ ordinaryBooleanFullAbsTerm q a H n := by
  unfold ordinaryBooleanFullAbsTerm
  by_cases hact : n ∈ activeOrdinaryTwoDimensionalSet q H
  · rw [Set.indicator_of_mem hact]
    have hω : 0 ≤ finiteOmegaWeightReal n :=
      finiteOmegaWeightReal_nonneg_of_active hact.2
    have hp : 0 ≤ (2 : ℝ) ^ n.card := pow_nonneg (by norm_num) _
    exact mul_nonneg hω (mul_nonneg hp (abs_nonneg _))
  · simp [Set.indicator, hact]

lemma ordinaryBooleanFullEndpointAbsTerm_nonneg'
    (q a H : ℕ) (n : Finset ℕ) :
    0 ≤ ordinaryBooleanFullEndpointAbsTerm q a H n := by
  unfold ordinaryBooleanFullEndpointAbsTerm
  by_cases hact : n ∈ activeOrdinaryTwoDimensionalSet q H
  · rw [Set.indicator_of_mem hact]
    exact mul_nonneg
      (finiteOmegaWeightReal_nonneg_of_active hact.2)
      (abs_nonneg _)
  · simp [Set.indicator, hact]

lemma ordinaryBooleanEmptyEndpointAbsTerm_nonneg'
    (q a H : ℕ) (n : Finset ℕ) :
    0 ≤ ordinaryBooleanEmptyEndpointAbsTerm q a H n := by
  unfold ordinaryBooleanEmptyEndpointAbsTerm
  by_cases hact : n ∈ activeOrdinaryTwoDimensionalSet q H
  · rw [Set.indicator_of_mem hact]
    exact mul_nonneg
      (finiteOmegaWeightReal_nonneg_of_active hact.2)
      (abs_nonneg _)
  · simp [Set.indicator, hact]

theorem abs_sourceForbiddenBooleanMainTerm_le_fullAbs
    {q a H : ℕ} (d n : Finset ℕ) :
    |sourceForbiddenBooleanMainTerm q a H d n| ≤
      ordinaryBooleanFullAbsTerm q a H n := by
  classical
  by_cases hact : n ∈ activeOrdinaryTwoDimensionalSet q H
  · by_cases hne : n.Nonempty
    · by_cases hcop :
          (primeSetProduct n).Coprime
            (H * (6 * q) * primeSetProduct d)
      · rw [sourceForbiddenBooleanMainTerm, if_pos ⟨hcop, hne⟩,
          Set.indicator_of_mem hact]
        rw [ordinaryBooleanFullAbsTerm, Set.indicator_of_mem hact]
        have hshiu :=
          fixedQShiuWeight_primeSetProduct_eq_card_mul_finiteOmegaWeightReal
            (q := q) (n := n) hact.2
        rw [abs_mul,
          abs_of_nonneg (fixedQShiuWeight_nonneg q (primeSetProduct n))]
        rw [hshiu]
        ring_nf
        exact le_rfl
      · have hzero :
            sourceForbiddenBooleanMainTerm q a H d n = 0 := by
          simp [sourceForbiddenBooleanMainTerm, hcop]
        rw [hzero, abs_zero]
        exact ordinaryBooleanFullAbsTerm_nonneg' q a H n
    · have hzero :
          sourceForbiddenBooleanMainTerm q a H d n = 0 := by
        simp [sourceForbiddenBooleanMainTerm, hne]
      rw [hzero, abs_zero]
      exact ordinaryBooleanFullAbsTerm_nonneg' q a H n
  · have hsrc0 : sourceForbiddenBooleanMainTerm q a H d n = 0 := by
      simp [sourceForbiddenBooleanMainTerm, Set.indicator, hact]
    rw [hsrc0, abs_zero]
    exact ordinaryBooleanFullAbsTerm_nonneg' q a H n

noncomputable def signedForbiddenMainSmall
    (q a H : ℕ) (d : Finset ℕ) (Z : ℕ) : ℝ :=
  ∑ n ∈ h2BooleanGlobalSmallSets q H Z,
    sourceForbiddenBooleanMainTerm q a H d n

noncomputable def signedForbiddenMainExterior
    (q a H : ℕ) (d : Finset ℕ) (Z : ℕ) : ℝ :=
  ∑' n : ↥((↑(h2BooleanGlobalSmallSets q H Z) : Set (Finset ℕ))ᶜ),
    sourceForbiddenBooleanMainTerm q a H d n.1

theorem abs_signedForbiddenMainSmall_le_globalSmallMajorant
    {q a H Z : ℕ} (d : Finset ℕ) :
    |signedForbiddenMainSmall q a H d Z| ≤
      h2BooleanGlobalSmallMajorant q a H Z := by
  unfold signedForbiddenMainSmall h2BooleanGlobalSmallMajorant
  calc
    |∑ n ∈ h2BooleanGlobalSmallSets q H Z,
        sourceForbiddenBooleanMainTerm q a H d n|
      ≤ ∑ n ∈ h2BooleanGlobalSmallSets q H Z,
          |sourceForbiddenBooleanMainTerm q a H d n| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ n ∈ h2BooleanGlobalSmallSets q H Z,
          ordinaryBooleanFullAbsTerm q a H n := by
        apply Finset.sum_le_sum
        intro n hn
        exact abs_sourceForbiddenBooleanMainTerm_le_fullAbs d n
    _ ≤ ∑ n ∈ h2BooleanGlobalSmallSets q H Z,
          (ordinaryBooleanFullAbsTerm q a H n +
            ordinaryBooleanFullEndpointAbsTerm q a H n +
            ordinaryBooleanEmptyEndpointAbsTerm q a H n) := by
        apply Finset.sum_le_sum
        intro n hn
        have h1 := ordinaryBooleanFullEndpointAbsTerm_nonneg' q a H n
        have h2 := ordinaryBooleanEmptyEndpointAbsTerm_nonneg' q a H n
        linarith

theorem sourceForbiddenBooleanMain_tsum_eq_small_add_exterior
    {q a H : ℕ} (hq : 0 < q) (hH : 0 < H)
    (h2 : ¬ 2 ∣ q → 2 ∣ H)
    (d : Finset ℕ) (Z : ℕ) :
    (∑' n : Finset ℕ, sourceForbiddenBooleanMainTerm q a H d n) =
      signedForbiddenMainSmall q a H d Z +
        signedForbiddenMainExterior q a H d Z := by
  have hs :=
    summable_sourceForbiddenBooleanMainTerm
      (q := q) (a := a) (H := H) hq hH h2 d
  symm
  simpa [signedForbiddenMainSmall, signedForbiddenMainExterior] using
    (hs.sum_add_tsum_compl
      (s := h2BooleanGlobalSmallSets q H Z))

#print axioms abs_sourceForbiddenBooleanMainTerm_le_fullAbs
#print axioms abs_signedForbiddenMainSmall_le_globalSmallMajorant
#print axioms sourceForbiddenBooleanMain_tsum_eq_small_add_exterior

theorem ordinaryBooleanFullAbsTerm_le_core_add_endpoints'
    (q A H : ℕ) (S : Finset ℕ) :
    ordinaryBooleanFullAbsTerm q A H S ≤
      |ordinaryBooleanCoreTerm q A H S| +
        ordinaryBooleanFullEndpointAbsTerm q A H S +
        ordinaryBooleanEmptyEndpointAbsTerm q A H S := by
  classical
  by_cases hAct : S ∈ activeOrdinaryTwoDimensionalSet q H
  · rw [ordinaryBooleanFullAbsTerm, Set.indicator_of_mem hAct]
    rw [ordinaryBooleanCoreTerm, Set.indicator_of_mem hAct]
    rw [ordinaryBooleanFullEndpointAbsTerm, Set.indicator_of_mem hAct]
    rw [ordinaryBooleanEmptyEndpointAbsTerm, Set.indicator_of_mem hAct]
    have hw0 : 0 ≤ finiteOmegaWeightReal S :=
      finiteOmegaWeightReal_nonneg_of_active hAct.2
    by_cases hne : S.Nonempty
    · rw [ordinaryBooleanInteriorDiscrepancy_eq_full_sub_endpoints
        (fixedQLowWeight q A H) H hne]
      rw [fixedProductPartitionDiscrepancy_full_left,
        fixedProductPartitionDiscrepancy_empty_left]
      rw [abs_mul, abs_of_nonneg hw0]
      have htri :
          |(2 : ℝ) ^ S.card *
              fixedProductBooleanDiscrepancy
                (fixedQLowWeight q A H) H S| ≤
            |(2 : ℝ) ^ S.card *
                  fixedProductBooleanDiscrepancy
                    (fixedQLowWeight q A H) H S -
                rowDiscrepancy (fixedQLowWeight q A H) H
                  (primeSetProduct S) 1 -
                rowDiscrepancy (fixedQLowWeight q A H) H
                  1 (primeSetProduct S)| +
              |rowDiscrepancy (fixedQLowWeight q A H) H
                (primeSetProduct S) 1| +
              |rowDiscrepancy (fixedQLowWeight q A H) H
                1 (primeSetProduct S)| := by
        have h :=
          abs_add_three
            ((2 : ℝ) ^ S.card *
                fixedProductBooleanDiscrepancy
                  (fixedQLowWeight q A H) H S -
              rowDiscrepancy (fixedQLowWeight q A H) H
                (primeSetProduct S) 1 -
              rowDiscrepancy (fixedQLowWeight q A H) H
                1 (primeSetProduct S))
            (rowDiscrepancy (fixedQLowWeight q A H) H
              (primeSetProduct S) 1)
            (rowDiscrepancy (fixedQLowWeight q A H) H
              1 (primeSetProduct S))
        have heq :
            ((2 : ℝ) ^ S.card *
                fixedProductBooleanDiscrepancy
                  (fixedQLowWeight q A H) H S -
              rowDiscrepancy (fixedQLowWeight q A H) H
                (primeSetProduct S) 1 -
              rowDiscrepancy (fixedQLowWeight q A H) H
                1 (primeSetProduct S)) +
            rowDiscrepancy (fixedQLowWeight q A H) H
              (primeSetProduct S) 1 +
            rowDiscrepancy (fixedQLowWeight q A H) H
              1 (primeSetProduct S) =
            (2 : ℝ) ^ S.card *
              fixedProductBooleanDiscrepancy
                (fixedQLowWeight q A H) H S := by ring
        rwa [heq] at h
      have hpow0 : 0 ≤ (2 : ℝ) ^ S.card := by positivity
      rw [abs_mul, abs_of_nonneg hpow0] at htri
      have hm := mul_le_mul_of_nonneg_left htri hw0
      simpa [mul_add, add_assoc] using hm
    · have hS0 : S = ∅ := Finset.not_nonempty_iff_eq_empty.mp hne
      subst S
      rw [fixedProductBooleanDiscrepancy_empty,
        rowDiscrepancy_one_one_zero]
      simp [ordinaryBooleanInteriorDiscrepancy,
        fixedProductPartitionDiscrepancy, primeSetProduct]
      positivity
  · simp [ordinaryBooleanFullAbsTerm, ordinaryBooleanCoreTerm,
      ordinaryBooleanFullEndpointAbsTerm,
      ordinaryBooleanEmptyEndpointAbsTerm, Set.indicator, hAct]

theorem abs_signedForbiddenMainSmall_le_properCore_add_endpoints
    {q a H Z : ℕ} (d : Finset ℕ) :
    |signedForbiddenMainSmall q a H d Z| ≤
      h2BooleanProperCoreSmallMajorant q a H Z +
        2 * h2EndpointSmallProductFamily q a H Z := by
  have h0 := abs_signedForbiddenMainSmall_le_globalSmallMajorant
    (q := q) (a := a) (H := H) (Z := Z) d
  unfold h2BooleanGlobalSmallMajorant at h0
  unfold h2BooleanProperCoreSmallMajorant
  unfold h2EndpointSmallProductFamily
  calc
    |signedForbiddenMainSmall q a H d Z|
      ≤ ∑ S ∈ h2BooleanGlobalSmallSets q H Z,
          (ordinaryBooleanFullAbsTerm q a H S +
            ordinaryBooleanFullEndpointAbsTerm q a H S +
            ordinaryBooleanEmptyEndpointAbsTerm q a H S) := h0
    _ ≤ ∑ S ∈ h2BooleanGlobalSmallSets q H Z,
          (|ordinaryBooleanCoreTerm q a H S| +
            2 * (ordinaryBooleanFullEndpointAbsTerm q a H S +
              ordinaryBooleanEmptyEndpointAbsTerm q a H S)) := by
        apply Finset.sum_le_sum
        intro S hS
        have ht := ordinaryBooleanFullAbsTerm_le_core_add_endpoints'
          q a H S
        have h1 := ordinaryBooleanFullEndpointAbsTerm_nonneg' q a H S
        have h2 := ordinaryBooleanEmptyEndpointAbsTerm_nonneg' q a H S
        linarith
    _ = (∑ S ∈ h2BooleanGlobalSmallSets q H Z,
          |ordinaryBooleanCoreTerm q a H S|) +
        2 * (∑ S ∈ h2BooleanGlobalSmallSets q H Z,
          (ordinaryBooleanFullEndpointAbsTerm q a H S +
            ordinaryBooleanEmptyEndpointAbsTerm q a H S)) := by
        rw [Finset.sum_add_distrib, ← Finset.mul_sum]
    _ ≤ (∑ S ∈ h2BooleanGlobalSmallSets q H Z,
          |ordinaryBooleanCoreTerm q a H S|) +
        2 * (∑ S ∈ h2EndpointSmallProductSets q Z,
          (ordinaryBooleanFullEndpointAbsTerm q a H S +
            ordinaryBooleanEmptyEndpointAbsTerm q a H S)) := by
        have hend :
            2 * (∑ S ∈ h2BooleanGlobalSmallSets q H Z,
              (ordinaryBooleanFullEndpointAbsTerm q a H S +
                ordinaryBooleanEmptyEndpointAbsTerm q a H S)) ≤
            2 * (∑ S ∈ h2EndpointSmallProductSets q Z,
              (ordinaryBooleanFullEndpointAbsTerm q a H S +
                ordinaryBooleanEmptyEndpointAbsTerm q a H S)) := by
          apply mul_le_mul_of_nonneg_left
          · apply Finset.sum_le_sum_of_subset_of_nonneg
            · intro S hS
              exact h2BooleanGlobalSmallSets_mem_endpoint hS
            · intro S hS hnot
              exact add_nonneg
                (ordinaryBooleanFullEndpointAbsTerm_nonneg' q a H S)
                (ordinaryBooleanEmptyEndpointAbsTerm_nonneg' q a H S)
          · norm_num
        exact add_le_add (le_refl _) hend

#print axioms ordinaryBooleanFullAbsTerm_le_core_add_endpoints'
#print axioms abs_signedForbiddenMainSmall_le_properCore_add_endpoints

lemma sourceMain_sourceCutoff_le_globalProperBooleanProductCutoff
    (H : ℕ) :
    h2BooleanSourceCutoff H ≤ globalProperBooleanProductCutoff H := by
  let N := h2BooleanSourceCutoff H
  have hsucc : N + 1 ≤ 2 ^ (N + 1) :=
    Nat.le_of_lt (N + 1).lt_two_pow_self
  have hexp : N + 1 ≤ globalProperBooleanBlockCount H := by
    dsimp [N]
    unfold globalProperBooleanBlockCount
    omega
  have hpow :
      2 ^ (N + 1) ≤ 2 ^ globalProperBooleanBlockCount H :=
    Nat.pow_le_pow_right (by norm_num) hexp
  unfold globalProperBooleanProductCutoff
  exact (Nat.le_succ N).trans (hsucc.trans hpow)

theorem sourceMain_properCoreSmallMajorant_mono
    {q A H Z1 Z2 : ℕ} (hZ : Z1 ≤ Z2) :
    h2BooleanProperCoreSmallMajorant q A H Z1 ≤
      h2BooleanProperCoreSmallMajorant q A H Z2 := by
  classical
  unfold h2BooleanProperCoreSmallMajorant
  apply Finset.sum_le_sum_of_subset_of_nonneg
  · intro S hS
    have hE := h2BooleanGlobalSmallSets_mem_endpoint hS
    have hAct : S ∈ activeOrdinaryTwoDimensionalSet q H :=
      ⟨h2BooleanGlobalSmallSets_ordinary hS,
        h2EndpointSmallProductSets_active hE⟩
    have hne := h2EndpointSmallProductSets_nonempty hE
    have hle := (h2EndpointSmallProductSets_product_le hE).trans hZ
    exact h2BooleanGlobalSmallSets_of_active_le hAct hne hle
  · intro S hS hnot
    exact abs_nonneg _

theorem sourceMain_properCoreSmallMajorant_source_rate
    (q : ℕ) (hq : 0 < q) :
    ∃ Csmall : ℝ, ∃ H0 : ℕ,
      0 ≤ Csmall ∧
      ∀ A H : ℕ,
        0 < H →
        (¬ 2 ∣ q → 2 ∣ H) →
        H0 ≤ H →
        h2BooleanProperCoreSmallMajorant
            q A H (h2BooleanSourceCutoff H) ≤
          Csmall *
            (Real.log (H : ℝ)) ^
              (h2BooleanSigma * h2BooleanX0) *
            (Real.log (Real.log (H : ℝ))) ^ 2 := by
  rcases h2BooleanProperCoreSmallMajorant_le_geometric_rate q hq with
    ⟨C, N0, hC, hN0, hRate⟩
  obtain ⟨H0, hW⟩ := globalProperWalfiszBounds N0 hN0
  let Csmall : ℝ :=
    (12 * (fixedQPeriod q : ℝ)) *
        h2BooleanInitialProperWeightMass q N0 +
      41 * C * (42 : ℝ) ^ (h2BooleanX0 - 1) * (42 : ℝ)^2
  have hCsmall : 0 ≤ Csmall := by
    dsimp [Csmall]
    have hi := h2BooleanInitialProperWeightMass_nonneg q N0
    positivity
  refine ⟨Csmall, H0, hCsmall, ?_⟩
  intro A H hH h2 hH0
  rcases hW H hH0 with
    ⟨hh16, hL, hLL, hS1, hJ, hU, hLLU⟩
  have hmono :=
    sourceMain_properCoreSmallMajorant_mono
      (q := q) (A := A) (H := H)
      (sourceMain_sourceCutoff_le_globalProperBooleanProductCutoff H)
  have hgeo0 :=
    hRate A H (globalProperBooleanProductCutoff H) h2
  have hgeo :
      h2BooleanProperCoreSmallMajorant
          q A H (globalProperBooleanProductCutoff H) ≤
        globalProperOrdinaryGeometricRate
          q N0 C (globalProperBooleanProductCutoff H) := by
    change h2BooleanProperCoreSmallMajorant
        q A H (globalProperBooleanProductCutoff H) ≤
      globalProperOrdinaryGeometricRate
        q N0 C (globalProperBooleanProductCutoff H) at hgeo0
    exact hgeo0
  have hwal :=
    globalProperOrdinaryGeometricRate_le_walfisz
      (q := q) (N0 := N0) (h := H) (C := C)
      hC hN0 hL hLL hJ hU hLLU
  calc
    h2BooleanProperCoreSmallMajorant
        q A H (h2BooleanSourceCutoff H)
      ≤ h2BooleanProperCoreSmallMajorant
          q A H (globalProperBooleanProductCutoff H) := hmono
    _ ≤ globalProperOrdinaryGeometricRate
          q N0 C (globalProperBooleanProductCutoff H) := hgeo
    _ ≤ Csmall *
          (Real.log (H : ℝ)) ^
            (h2BooleanSigma * h2BooleanX0) *
          (Real.log (Real.log (H : ℝ))) ^ 2 := by
      simpa [Csmall] using hwal

theorem signedForbiddenMainSmall_source_rate
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ H0 : ℕ,
      0 ≤ C ∧
      ∀ A H : ℕ, ∀ d : Finset ℕ,
        0 < H →
        (¬ 2 ∣ q → 2 ∣ H) →
        H0 ≤ H →
        |signedForbiddenMainSmall
            q A H d (h2BooleanSourceCutoff H)| ≤
          C *
            (Real.log (H : ℝ)) ^
              (h2BooleanSigma * h2BooleanX0) *
            (Real.log (Real.log (H : ℝ))) ^ 2 := by
  rcases sourceMain_properCoreSmallMajorant_source_rate q hq with
    ⟨Ccore, Hcore, hCcore, hcore⟩
  rcases h2EndpointSmallProductFamily_rate q hq with
    ⟨Cend, hCend, hend⟩
  obtain ⟨Hlog, hW⟩ := globalProperWalfiszBounds 1 (by norm_num)
  let C : ℝ := Ccore + 2 * Cend
  let H0 : ℕ := max Hcore Hlog
  have hC : 0 ≤ C := by
    dsimp [C]
    positivity
  refine ⟨C, H0, hC, ?_⟩
  intro A H d hH h2 hH0
  have hHcore : Hcore ≤ H :=
    (le_max_left Hcore Hlog).trans hH0
  have hHlog : Hlog ≤ H :=
    (le_max_right Hcore Hlog).trans hH0
  rcases hW H hHlog with
    ⟨hh16, hL1, hLL1, hS1, hJ, hU, hLLU⟩
  have htri :=
    abs_signedForbiddenMainSmall_le_properCore_add_endpoints
      (q := q) (a := A) (H := H)
      (Z := h2BooleanSourceCutoff H) d
  have hc := hcore A H hH h2 hHcore
  have hcut := h2BooleanSourceCutoff_cast_le (H := H) hH
  have he := hend A H (h2BooleanSourceCutoff H) hH h2 hL1 hcut
  let Lpow : ℝ :=
    (Real.log (H : ℝ)) ^ (h2BooleanSigma * h2BooleanX0)
  let LLsq : ℝ := (Real.log (Real.log (H : ℝ))) ^ 2
  have hLpow0 : 0 ≤ Lpow := by
    dsimp [Lpow]
    exact Real.rpow_nonneg (Real.log_nonneg (by exact_mod_cast hH)) _
  have hLLsq1 : 1 ≤ LLsq := by
    dsimp [LLsq]
    nlinarith
  have hendLift :
      2 * h2EndpointSmallProductFamily
          q A H (h2BooleanSourceCutoff H) ≤
        (2 * Cend) * Lpow * LLsq := by
    have he2 :
        2 * h2EndpointSmallProductFamily
            q A H (h2BooleanSourceCutoff H) ≤
          (2 * Cend) * Lpow := by
      dsimp [Lpow]
      nlinarith [he]
    have hbase0 : 0 ≤ (2 * Cend) * Lpow := by positivity
    calc
      2 * h2EndpointSmallProductFamily
          q A H (h2BooleanSourceCutoff H)
        ≤ (2 * Cend) * Lpow := he2
      _ ≤ (2 * Cend) * Lpow * LLsq := by
        nlinarith
  calc
    |signedForbiddenMainSmall
        q A H d (h2BooleanSourceCutoff H)|
      ≤ h2BooleanProperCoreSmallMajorant
          q A H (h2BooleanSourceCutoff H) +
        2 * h2EndpointSmallProductFamily
          q A H (h2BooleanSourceCutoff H) := htri
    _ ≤ Ccore * Lpow * LLsq +
        (2 * Cend) * Lpow * LLsq := by
      have hc' :
          h2BooleanProperCoreSmallMajorant
              q A H (h2BooleanSourceCutoff H) ≤
            Ccore * Lpow * LLsq := by
        simpa [Lpow, LLsq] using hc
      exact add_le_add hc' hendLift
    _ = C * Lpow * LLsq := by
      dsimp [C]
      ring
    _ = C *
        (Real.log (H : ℝ)) ^
          (h2BooleanSigma * h2BooleanX0) *
        (Real.log (Real.log (H : ℝ))) ^ 2 := by
      rfl

#print axioms signedForbiddenMainSmall_source_rate

lemma sourceForbiddenMain_eq_zero_of_compl_product_le
    {q a H Z : ℕ} {d n : Finset ℕ}
    (hnot : n ∉ h2BooleanGlobalSmallSets q H Z)
    (hle : primeSetProduct n ≤ Z) :
    sourceForbiddenBooleanMainTerm q a H d n = 0 := by
  by_cases hne : n.Nonempty
  · by_cases hAct : n ∈ activeOrdinaryTwoDimensionalSet q H
    · have hsmall :=
        h2BooleanGlobalSmallSets_of_active_le hAct hne hle
      exact (hnot hsmall).elim
    · simp [sourceForbiddenBooleanMainTerm, Set.indicator, hAct]
  · simp [sourceForbiddenBooleanMainTerm, hne]

theorem signedForbiddenMainExterior_eq_product_tail
    {q a H : ℕ} (d : Finset ℕ) (Z : ℕ) :
    signedForbiddenMainExterior q a H d Z =
      ∑' n : Finset ℕ,
        if Z < primeSetProduct n then
          sourceForbiddenBooleanMainTerm q a H d n
        else 0 := by
  classical
  let F : Set (Finset ℕ) :=
    (↑(h2BooleanGlobalSmallSets q H Z) : Set (Finset ℕ))ᶜ
  let tail : Finset ℕ → ℝ := fun n =>
    if Z < primeSetProduct n then
      sourceForbiddenBooleanMainTerm q a H d n
    else 0
  have hsupp : Function.support tail ⊆ F := by
    intro n hn
    have hgt : Z < primeSetProduct n := by
      by_contra hngt
      simp [tail, hngt] at hn
    simp [F]
    intro hsmall
    have hE := h2BooleanGlobalSmallSets_mem_endpoint hsmall
    have hp := h2EndpointSmallProductSets_product_le hE
    omega
  have hsub :
      (∑' n : F, tail n.1) = signedForbiddenMainExterior q a H d Z := by
    unfold signedForbiddenMainExterior
    apply tsum_congr
    intro n
    have hnot : n.1 ∉ h2BooleanGlobalSmallSets q H Z := by
      have hnprop := n.property
      change n.1 ∉ h2BooleanGlobalSmallSets q H Z at hnprop
      exact hnprop
    by_cases hgt : Z < primeSetProduct n.1
    · simp [tail, hgt]
    · have hle : primeSetProduct n.1 ≤ Z := Nat.le_of_not_gt hgt
      have hz :=
        sourceForbiddenMain_eq_zero_of_compl_product_le
          (q := q) (a := a) (H := H) (Z := Z)
          (d := d) (n := n.1) hnot hle
      simp [tail, hgt, hz]
  symm
  calc
    (∑' n : Finset ℕ, tail n) =
        ∑' n : F, tail n.1 := by
          exact (tsum_subtype_eq_of_support_subset hsupp).symm
    _ = signedForbiddenMainExterior q a H d Z := hsub

theorem sourceForbiddenMain_product_tail_eq_natural_tail
    (q a H : ℕ) (d : Finset ℕ) (Z : ℕ) :
    (∑' n : Finset ℕ,
      if Z < primeSetProduct n then
        sourceForbiddenBooleanMainTerm q a H d n
      else 0) =
    ∑' m : ℕ,
      if Z < m then
        sourceForbiddenBooleanNaturalTerm
          q a H (primeSetProduct d) m
      else 0 := by
  classical
  let P : Set (Finset ℕ) := {n | ∀ p ∈ n, p.Prime}
  let f : Finset ℕ → ℝ := fun n =>
    if Z < primeSetProduct n then
      sourceForbiddenBooleanMainTerm q a H d n
    else 0
  have hind :
      (∑' n : Finset ℕ, f n) =
        ∑' n : Finset ℕ, P.indicator f n := by
    apply tsum_congr
    intro n
    by_cases hn : n ∈ P
    · simp [Set.indicator, hn]
    · have hz : sourceForbiddenBooleanMainTerm q a H d n = 0 := by
        apply sourceForbiddenBooleanMainTerm_eq_zero_of_not_all_prime
        simpa [P] using hn
      simp [f, Set.indicator, hn, hz]
  rw [hind]
  rw [← tsum_subtype]
  have hprime :
      (∑' s : PrimeFinset,
        if Z < primeSetProduct s.1 then
          sourceForbiddenBooleanMainTerm q a H d s.1
        else 0) =
      ∑' s : PrimeFinset,
        if Z < primeSetProduct s.1 then
          sourceForbiddenBooleanNaturalTerm q a H
            (primeSetProduct d) (primeSetProduct s.1)
        else 0 := by
    apply tsum_congr
    intro s
    by_cases hgt : Z < primeSetProduct s.1
    · simp [hgt,
        sourceForbiddenBooleanMainTerm_eq_natural_signed_of_prime s.2]
    · simp [hgt]
  change (∑' s : PrimeFinset,
    if Z < primeSetProduct s.1 then
      sourceForbiddenBooleanMainTerm q a H d s.1
    else 0) = _
  rw [hprime]
  let g : SquarefreeNat → ℝ := fun m =>
    if Z < m.1 then
      sourceForbiddenBooleanNaturalTerm q a H
        (primeSetProduct d) m.1
    else 0
  have hval : ∀ s : PrimeFinset,
      (primeFinsetEquivSquarefreeNat s).1 = primeSetProduct s.1 := by
    intro s
    rfl
  have hsf :
      (∑' s : PrimeFinset,
        if Z < primeSetProduct s.1 then
          sourceForbiddenBooleanNaturalTerm q a H
            (primeSetProduct d) (primeSetProduct s.1)
        else 0) =
      ∑' m : SquarefreeNat,
        if Z < m.1 then
          sourceForbiddenBooleanNaturalTerm q a H
            (primeSetProduct d) m.1
        else 0 := by
    calc
      (∑' s : PrimeFinset,
        if Z < primeSetProduct s.1 then
          sourceForbiddenBooleanNaturalTerm q a H
            (primeSetProduct d) (primeSetProduct s.1)
        else 0) =
          ∑' s : PrimeFinset, g (primeFinsetEquivSquarefreeNat s) := by
            apply tsum_congr
            intro s
            simp [g, hval s]
      _ = ∑' m : SquarefreeNat, g m :=
        Equiv.tsum_eq primeFinsetEquivSquarefreeNat g
      _ = ∑' m : SquarefreeNat,
          if Z < m.1 then
            sourceForbiddenBooleanNaturalTerm q a H
              (primeSetProduct d) m.1
          else 0 := by rfl
  rw [hsf]
  let S : Set ℕ := {m | Squarefree m}
  have hnat :
      (∑' m : ℕ, S.indicator
        (fun m =>
          if Z < m then
            sourceForbiddenBooleanNaturalTerm q a H
              (primeSetProduct d) m
          else 0) m) =
      ∑' m : ℕ,
        if Z < m then
          sourceForbiddenBooleanNaturalTerm q a H
            (primeSetProduct d) m
        else 0 := by
    apply tsum_congr
    intro m
    by_cases hm : m ∈ S
    · simp [Set.indicator, hm]
    · have hz :
          sourceForbiddenBooleanNaturalTerm q a H
            (primeSetProduct d) m = 0 := by
        apply sourceForbiddenBooleanNaturalTerm_eq_zero_of_not_squarefree
        simpa [S] using hm
      simp [Set.indicator, hm, hz]
  rw [← hnat]
  rw [← tsum_subtype]
  rfl

theorem signedForbiddenMainExterior_eq_natural_tail
    {q a H : ℕ} (d : Finset ℕ) (Z : ℕ) :
    signedForbiddenMainExterior q a H d Z =
      ∑' m : ℕ,
        if Z < m then
          sourceForbiddenBooleanNaturalTerm
            q a H (primeSetProduct d) m
        else 0 := by
  rw [signedForbiddenMainExterior_eq_product_tail]
  exact sourceForbiddenMain_product_tail_eq_natural_tail q a H d Z

#print axioms signedForbiddenMainExterior_eq_natural_tail


#print axioms completedBooleanMainTerm_eq_sourceMain_of_active_ordinary
#print axioms abs_sourceForbiddenBooleanMainTerm_le_abs_completed
#print axioms summable_sourceForbiddenBooleanMainTerm

#print axioms source_ramanujanResonantSurcharge_le_const_quarterRoot
#print axioms source_ramanujanMeanPowerset_tail_le_explicit

end PaperB.FixedQ
