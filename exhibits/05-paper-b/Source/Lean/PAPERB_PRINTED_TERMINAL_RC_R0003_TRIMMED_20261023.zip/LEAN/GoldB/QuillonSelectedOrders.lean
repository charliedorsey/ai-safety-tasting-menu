import Mathlib.Analysis.Calculus.Deriv.ZPow
import Mathlib.Analysis.Calculus.IteratedDeriv.Lemmas
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic

/-!
# Interface reconstruction (Quillon, Hunt B R0001) for the missing module
# `GoldB.QuillonSelectedOrders`

**Provenance.** The archived `GoldB/Suzuki.lean` imports this module, but the module was not in
the packet. This file is a **from-scratch reconstruction by Quillon** of the interface facts that
`GoldB/Suzuki.lean` uses. It is not the original scratch source. The names are kept only so that the
unmodified `GoldB/Suzuki.lean` source text elaborates against them. The selected-order set and its
window constants are Quillon's own choices, written out below.

No axiom, no `sorry`.

## Construction
* `t = log Y / log P`, and the Karatsuba order is `k = ⌊26 t⌋`, as in Suzuki §3 with
  `c1 = 25/26`.
* The selected orders are the integers `j` with `4(t-1)/3 ≤ j ≤ (t - 157/144)·468/61`.
  - The **upper** window `|f^{(j)}|/j! ≤ P^{-j/4}` needs only `x + ϑ ≥ P` and `j ≥ 4(t-1)/3`.
  - The **lower** window `P^{-(599/624) j} ≤ |f^{(j)}|/j!` uses `x + ϑ ≤ 2P + 1 ≤ P^{157/144}`
    (valid for `P ≥ 4096`) and `j ≤ (t - 157/144)·468/61`, because `157/144 - 599/624 = 61/468`.
  - The count is `≥ (2/3) t ≥ k/39` for every `t ≥ 3/2`.
-/

open Finset

namespace OrielUpper

/-- Karatsuba order `k = ⌊26 t⌋`. -/
noncomputable def veylanSuzukiOrder (t : ℝ) : ℕ := ⌊26 * t⌋₊

/-- Lower end of the selected orders. -/
noncomputable def quillonSelLo (t : ℝ) : ℕ := ⌈4 * (t - 1) / 3⌉₊

/-- Upper end of the selected orders. -/
noncomputable def quillonSelHi (t : ℝ) : ℕ := ⌊(t - 157 / 144) * (468 / 61)⌋₊

/-- The selected orders. -/
noncomputable def veylanSuzukiSelected (t : ℝ) : Finset ℕ :=
  Finset.Icc (quillonSelLo t) (quillonSelHi t)

lemma quillon_sel_lo_pos (t : ℝ) (ht : 3 / 2 ≤ t) : 1 ≤ quillonSelLo t := by
  unfold quillonSelLo
  rw [Nat.one_le_ceil_iff]; linarith

lemma quillon_sel_lo_lt (t : ℝ) (ht : 3 / 2 ≤ t) : (quillonSelLo t : ℝ) < 4 * (t - 1) / 3 + 1 := by
  unfold quillonSelLo
  exact Nat.ceil_lt_add_one (by linarith)

lemma quillon_sel_hi_gt (t : ℝ) (ht : 3 / 2 ≤ t) :
    (t - 157 / 144) * (468 / 61) - 1 < (quillonSelHi t : ℝ) := by
  unfold quillonSelHi
  have := Nat.lt_floor_add_one ((t - 157 / 144) * (468 / 61))
  linarith

/-- Order facts for every selected `j`. -/
theorem veylan_suzuki_selected_order (t : ℝ) (ht : 3 / 2 ≤ t) (j : ℕ)
    (hj : j ∈ veylanSuzukiSelected t) :
    1 ≤ j ∧ 4 * (t - 1) / 3 ≤ (j : ℝ) ∧ (j : ℝ) ≤ (t - 157 / 144) * (468 / 61) ∧
      j ≤ veylanSuzukiOrder t := by
  unfold veylanSuzukiSelected at hj
  obtain ⟨hlo, hhi⟩ := Finset.mem_Icc.mp hj
  have hpos : 0 ≤ (t - 157 / 144) * (468 / 61) := by
    apply mul_nonneg _ (by norm_num); linarith
  refine ⟨(quillon_sel_lo_pos t ht).trans hlo, ?_, ?_, ?_⟩
  · have : 4 * (t - 1) / 3 ≤ (quillonSelLo t : ℝ) := by unfold quillonSelLo; exact Nat.le_ceil _
    exact this.trans (by exact_mod_cast hlo)
  · have : (quillonSelHi t : ℝ) ≤ (t - 157 / 144) * (468 / 61) := by
      unfold quillonSelHi; exact Nat.floor_le hpos
    exact (by exact_mod_cast hhi : (j : ℝ) ≤ quillonSelHi t).trans this
  · refine hhi.trans ?_
    unfold quillonSelHi veylanSuzukiOrder
    apply Nat.floor_le_floor
    nlinarith

/-- Count of the selected orders: `≥ k/39`. -/
theorem veylan_suzuki_selected_count (t : ℝ) (ht : 3 / 2 ≤ t) :
    1 ≤ (veylanSuzukiSelected t).card ∧
      (1 / 39 : ℝ) * (veylanSuzukiOrder t : ℝ) ≤ ((veylanSuzukiSelected t).card : ℝ) ∧
      (veylanSuzukiSelected t).card ≤ veylanSuzukiOrder t := by
  have hlo := quillon_sel_lo_lt t ht
  have hhi := quillon_sel_hi_gt t ht
  have hlohi : quillonSelLo t ≤ quillonSelHi t := by
    have : (quillonSelLo t : ℝ) < (quillonSelHi t : ℝ) + 1 := by nlinarith
    exact Nat.lt_add_one_iff.mp (by exact_mod_cast this)
  have hcard : (veylanSuzukiSelected t).card = quillonSelHi t + 1 - quillonSelLo t := by
    unfold veylanSuzukiSelected; exact Nat.card_Icc _ _
  have hcardr : ((veylanSuzukiSelected t).card : ℝ) =
      (quillonSelHi t : ℝ) + 1 - (quillonSelLo t : ℝ) := by
    rw [hcard, Nat.cast_sub (by omega)]; push_cast; ring
  have hk : (veylanSuzukiOrder t : ℝ) ≤ 26 * t := by
    unfold veylanSuzukiOrder; exact Nat.floor_le (by linarith)
  refine ⟨by rw [hcard]; omega, ?_, ?_⟩
  · rw [hcardr]; nlinarith
  · have hsub : veylanSuzukiSelected t ⊆ Finset.Icc 1 (veylanSuzukiOrder t) := by
      intro j hj
      obtain ⟨h1, _, _, h4⟩ := veylan_suzuki_selected_order t ht j hj
      exact Finset.mem_Icc.mpr ⟨h1, h4⟩
    have := Finset.card_le_card hsub
    simpa using this

/-- Normalized derivatives of the shifted reciprocal phase. -/
theorem veylan_suzuki_normalized_derivative (Y ϑ x : ℝ) (j : ℕ) (hY : 0 ≤ Y)
    (hx : 0 < x + ϑ) :
    ‖iteratedDeriv j (fun z : ℝ => Y / (z + ϑ)) x / (j.factorial : ℝ)‖ =
      Y / (x + ϑ) ^ (j + 1) := by
  have h : (fun z : ℝ => Y / (z + ϑ)) = fun z => Y * (1 * z + ϑ)⁻¹ := by
    funext z; rw [one_mul, div_eq_mul_inv]
  rw [h, iteratedDeriv_const_mul_field, iteratedDeriv_eq_iterate, iter_deriv_inv_linear]
  have hz : ((x + ϑ) ^ (-1 - (j : ℤ)) : ℝ) = ((x + ϑ) ^ (j + 1))⁻¹ := by
    rw [show (-1 - (j : ℤ)) = -((j + 1 : ℕ) : ℤ) by push_cast; ring, zpow_neg, zpow_natCast]
  simp only [one_mul, one_pow, mul_one]
  rw [hz]
  have hf : (0 : ℝ) < j.factorial := by exact_mod_cast Nat.factorial_pos j
  have hp : (0 : ℝ) < (x + ϑ) ^ (j + 1) := by positivity
  rw [Real.norm_eq_abs]
  have e : Y * ((-1) ^ j * (j.factorial : ℝ) * ((x + ϑ) ^ (j + 1))⁻¹) / (j.factorial : ℝ) =
      (-1) ^ j * (Y / (x + ϑ) ^ (j + 1)) := by
    field_simp
  rw [e, abs_mul, abs_pow, abs_neg, abs_one, one_pow, one_mul,
    abs_of_nonneg (div_nonneg hY hp.le)]

/-- Top-derivative upper bound: `Y/(x+ϑ)^{k+2} ≤ P^{-(25/26)(k+1)}` for `k = ⌊26 log Y/log P⌋`. -/
theorem veylan_suzuki_top_derivative_upper (P x ϑ Y : ℝ) (k : ℕ) (hP1 : 1 < P) (hx : P ≤ x)
    (hϑ : 0 ≤ ϑ) (hY : 0 < Y) (hk : k = veylanSuzukiOrder (Real.log Y / Real.log P)) :
    Y / (x + ϑ) ^ (k + 1 + 1) ≤ P ^ (-((25 / 26 : ℝ) * ((k : ℝ) + 1))) := by
  have hP0 : 0 < P := by linarith
  have hL : 0 < Real.log P := Real.log_pos hP1
  have hxϑ : P ≤ x + ϑ := by linarith
  set t := Real.log Y / Real.log P
  have hkt : 26 * t < (k : ℝ) + 1 := by
    rw [hk]; unfold veylanSuzukiOrder; exact Nat.lt_floor_add_one _
  have hY' : Real.log Y = t * Real.log P := by simp only [t]; field_simp
  calc Y / (x + ϑ) ^ (k + 1 + 1) ≤ Y / P ^ (k + 1 + 1) := by
        apply div_le_div_of_nonneg_left hY.le (by positivity)
        exact pow_le_pow_left₀ hP0.le hxϑ _
    _ = Real.exp (Real.log Y - ((k : ℝ) + 2) * Real.log P) := by
        rw [Real.exp_sub, Real.exp_log hY, ← Real.rpow_natCast, Real.rpow_def_of_pos hP0]
        push_cast; ring_nf
    _ ≤ Real.exp (Real.log P * (-((25 / 26 : ℝ) * ((k : ℝ) + 1)))) := by
        apply Real.exp_le_exp.mpr
        rw [hY']
        nlinarith
    _ = P ^ (-((25 / 26 : ℝ) * ((k : ℝ) + 1))) := (Real.rpow_def_of_pos hP0 _).symm

end OrielUpper

#print axioms OrielUpper.veylan_suzuki_selected_order
#print axioms OrielUpper.veylan_suzuki_selected_count
#print axioms OrielUpper.veylan_suzuki_normalized_derivative
#print axioms OrielUpper.veylan_suzuki_top_derivative_upper
