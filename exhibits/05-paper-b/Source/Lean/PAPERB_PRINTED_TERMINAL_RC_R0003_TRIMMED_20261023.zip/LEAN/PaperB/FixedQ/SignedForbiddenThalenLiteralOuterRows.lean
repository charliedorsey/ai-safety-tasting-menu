import PaperB.FixedQ.SignedForbiddenThalenDecoratedFiniteCutoff

open scoped BigOperators

namespace PaperB.FixedQ

/-- Literal unmasked finite source outer sum, unfolded down to the
actual row discrepancies and finite omega coefficient, with neither
density correction nor source row weight replaced. -/
theorem thalen_finite_outer_eq_literal_weighted_rows
    (q A H : ℕ) (S : Finset ℕ) :
    (∑ e ∈ S.powerset, thalenFiniteOuterSourceTerm q A H e) =
      ∑ e ∈ S.powerset,
        (∏ p ∈ e, 1 / ((p : ℝ) - 3)) *
          (∑ B ∈ ((e.powerset.erase e).erase ∅),
            rowDiscrepancy (fixedQLowWeight q A H) H
              (primeSetProduct B) (primeSetProduct (e \ B))) := by
  apply Finset.sum_congr rfl
  intro e he
  rfl

/-- The row-density subtraction in the literal source, still indexed
by the original supported outer sets and proper Boolean partitions. -/
theorem thalen_finite_outer_eq_constrained_sub_density
    (q A H : ℕ) (S : Finset ℕ) :
    (∑ e ∈ S.powerset, thalenFiniteOuterSourceTerm q A H e) =
      (∑ e ∈ S.powerset,
        finiteOmegaWeightReal e *
          (∑ B ∈ ((e.powerset.erase e).erase ∅),
            rowConstrainedMass (fixedQLowWeight q A H) H
              (primeSetProduct B) (primeSetProduct (e \ B)))) -
      rowWeightMass (fixedQLowWeight q A H) H *
        (∑ e ∈ S.powerset,
          finiteOmegaWeightReal e *
            (∑ B ∈ ((e.powerset.erase e).erase ∅),
              1 / ((primeSetProduct B : ℝ) *
                (primeSetProduct (e \ B) : ℝ)))) := by
  unfold thalenFiniteOuterSourceTerm ordinaryBooleanInteriorDiscrepancy
    fixedProductPartitionDiscrepancy rowDiscrepancy
  simp_rw [Finset.mul_sum]
  simp_rw [mul_sub]
  rw [← Finset.sum_sub_distrib]
  congr 1
  funext e
  rw [Finset.sum_sub_distrib]
  congr 1
  apply Finset.sum_congr rfl
  intro B hB
  ring

#print axioms thalen_finite_outer_eq_constrained_sub_density

end PaperB.FixedQ
