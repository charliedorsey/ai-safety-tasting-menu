import PaperB.FixedQ.H2BooleanCoreSourceSplit
import PaperB.FixedQ.H2ProperWeightedFinalAssembly
import Mathlib.Data.Nat.Log
import Mathlib.Analysis.SpecificLimits.Basic

set_option maxHeartbeats 800000

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def h2BooleanGeometricExteriorScale (N k : ℕ) : ℕ :=
  N * 2 ^ k

noncomputable def h2BooleanGeometricExteriorBand
    (q H N k : ℕ) : Finset (Finset ℕ) :=
  h2BooleanOrdinaryDyadicSets q H (h2BooleanGeometricExteriorScale N k)

noncomputable def h2BooleanGeometricExteriorBandIndex
    (N : ℕ) (S : Finset ℕ) : ℕ :=
  Nat.log 2 ((primeSetProduct S - 1) / N)

noncomputable def h2BooleanGeometricCoreBandMass
    (q A H N k : ℕ) : ℝ :=
  ∑ S ∈ h2BooleanGeometricExteriorBand q H N k,
    |ordinaryBooleanCoreTerm q A H S|

lemma h2BooleanGeometricExteriorScale_succ
    (N k : ℕ) :
    h2BooleanGeometricExteriorScale N (k + 1) =
      2 * h2BooleanGeometricExteriorScale N k := by
  unfold h2BooleanGeometricExteriorScale
  rw [pow_succ]
  ring

lemma h2BooleanGeometricExterior_range
    {N m : ℕ} (hN : 0 < N) (hNm : N < m) :
    let k := Nat.log 2 ((m - 1) / N)
    h2BooleanGeometricExteriorScale N k < m ∧
      m ≤ 2 * h2BooleanGeometricExteriorScale N k := by
  dsimp
  let t := (m - 1) / N
  let k := Nat.log 2 t
  have hNle : N ≤ m - 1 := by omega
  have ht1 : 1 ≤ t := by
    dsimp [t]
    rw [Nat.le_div_iff_mul_le hN]
    simpa using hNle
  have ht0 : t ≠ 0 := by omega
  have hpowle : 2 ^ k ≤ t := by
    dsimp [k]
    exact Nat.pow_log_le_self 2 ht0
  have hpowhi : t < 2 ^ (k + 1) := by
    dsimp [k]
    simpa [Nat.succ_eq_add_one] using
      (Nat.lt_pow_succ_log_self (by omega : 1 < 2) t)
  have hlower : N * 2 ^ k ≤ m - 1 := by
    calc
      N * 2 ^ k ≤ N * t := Nat.mul_le_mul_left N hpowle
      _ ≤ m - 1 := by
        simpa [Nat.mul_comm] using Nat.div_mul_le_self (m - 1) N
  have hupper0 : m - 1 < N * (t + 1) := by
    have hdiv : (m - 1) / N < t + 1 := by
      dsimp [t]
      exact Nat.lt_succ_self _
    have := (Nat.div_lt_iff_lt_mul hN).mp hdiv
    simpa [Nat.mul_comm] using this
  have hupper1 : m ≤ N * (t + 1) := by omega
  have htplus : t + 1 ≤ 2 ^ (k + 1) := by omega
  have hupper2 : m ≤ N * 2 ^ (k + 1) := by
    exact hupper1.trans (Nat.mul_le_mul_left N htplus)
  constructor
  · change N * 2 ^ k < m
    omega
  · change m ≤ 2 * (N * 2 ^ k)
    rw [pow_succ] at hupper2
    simpa [Nat.mul_assoc, Nat.mul_comm, Nat.mul_left_comm] using hupper2

lemma h2BooleanGeometricExteriorBand_index_eq
    {q H N k : ℕ} {S : Finset ℕ}
    (hN : 0 < N)
    (hS : S ∈ h2BooleanGeometricExteriorBand q H N k) :
    h2BooleanGeometricExteriorBandIndex N S = k := by
  have hr := h2BooleanDyadicSets_range
    (h2BooleanOrdinaryDyadicSets_mem hS).1
  have hlower :
      (h2BooleanGeometricExteriorScale N k) <
        primeSetProduct S := hr.1
  have hupper :
      primeSetProduct S ≤
        2 * h2BooleanGeometricExteriorScale N k := hr.2
  unfold h2BooleanGeometricExteriorBandIndex
  have hpowle :
      2 ^ k ≤ (primeSetProduct S - 1) / N := by
    rw [Nat.le_div_iff_mul_le hN]
    have hle : N * 2 ^ k ≤ primeSetProduct S - 1 := by
      unfold h2BooleanGeometricExteriorScale at hlower
      omega
    simpa [Nat.mul_comm] using hle
  have hpowhi :
      (primeSetProduct S - 1) / N < 2 ^ (k + 1) := by
    rw [Nat.div_lt_iff_lt_mul hN]
    have hlt :
        primeSetProduct S - 1 <
          (2 ^ (k + 1)) * N := by
      have hltprod :
          primeSetProduct S - 1 < primeSetProduct S := by
        have hpos : 0 < primeSetProduct S := by
          unfold h2BooleanGeometricExteriorScale at hlower
          omega
        omega
      calc
        primeSetProduct S - 1 < primeSetProduct S := hltprod
        _ ≤ 2 * h2BooleanGeometricExteriorScale N k := hupper
        _ = (2 ^ (k + 1)) * N := by
          unfold h2BooleanGeometricExteriorScale
          rw [pow_succ]
          ring
    exact hlt
  exact Nat.log_eq_of_pow_le_of_lt_pow hpowle hpowhi

lemma h2BooleanActiveOrdinary_mem_geometricExteriorBand
    {q H N : ℕ} {S : Finset ℕ}
    (hN : 0 < N)
    (hAct : S ∈ activeOrdinaryTwoDimensionalSet q H)
    (hne : S.Nonempty)
    (hgt : N < primeSetProduct S) :
    S ∈ h2BooleanGeometricExteriorBand q H N
      (h2BooleanGeometricExteriorBandIndex N S) := by
  classical
  let k := h2BooleanGeometricExteriorBandIndex N S
  have hr := h2BooleanGeometricExterior_range hN hgt
  change
    h2BooleanGeometricExteriorScale N k < primeSetProduct S ∧
      primeSetProduct S ≤ 2 * h2BooleanGeometricExteriorScale N k at hr
  unfold h2BooleanGeometricExteriorBand
  unfold h2BooleanOrdinaryDyadicSets
  apply Finset.mem_filter.mpr
  constructor
  · unfold h2BooleanDyadicSets
    apply Finset.mem_filter.mpr
    constructor
    · apply Finset.mem_powerset.mpr
      intro p hp
      apply Finset.mem_filter.mpr
      constructor
      · apply Nat.mem_primesLE.mpr
        constructor
        · have hPrime : ∀ r ∈ S, r.Prime :=
            fun r hrS => (hAct.2 r hrS).1
          have hmpos : 0 < primeSetProduct S :=
            primeSetProduct_pos hPrime
          have hpdiv : p ∣ primeSetProduct S := by
            unfold primeSetProduct
            exact Finset.dvd_prod_of_mem (fun x : ℕ => x) hp
          have hple : p ≤ primeSetProduct S :=
            Nat.le_of_dvd hmpos hpdiv
          exact hple.trans hr.2
        · exact (hAct.2 p hp).1
      · exact hAct.2 p hp
    · exact hr
  · exact hAct.1

lemma h2BooleanGeometricExteriorBand_sigma_val_injective
    {q H N : ℕ} (hN : 0 < N) :
    Function.Injective
      (fun x : Σ k : ℕ,
        {S // S ∈ h2BooleanGeometricExteriorBand q H N k} =>
          x.2.1) := by
  intro x y hxy
  rcases x with ⟨k, S⟩
  rcases y with ⟨l, T⟩
  have hST : S.1 = T.1 := hxy
  have hk :=
    h2BooleanGeometricExteriorBand_index_eq
      (q := q) (H := H) (N := N) hN S.2
  have hl :=
    h2BooleanGeometricExteriorBand_index_eq
      (q := q) (H := H) (N := N) hN T.2
  have hkl : k = l := by
    rw [← hk, ← hl, hST]
  subst l
  have hsub : S = T := Subtype.ext hST
  subst T
  rfl

lemma h2BooleanGeometricCoreBandMass_nonneg
    (q A H N k : ℕ) :
    0 ≤ h2BooleanGeometricCoreBandMass q A H N k := by
  unfold h2BooleanGeometricCoreBandMass
  positivity

theorem summable_h2BooleanGeometricCoreBandMass
    {q A H N : ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H)
    (hN : 0 < N) :
    Summable (fun k : ℕ =>
      h2BooleanGeometricCoreBandMass q A H N k) := by
  let sigmaVal :
      (Σ k : ℕ, {S // S ∈ h2BooleanGeometricExteriorBand q H N k}) →
        Finset ℕ :=
    fun x => x.2.1
  have hAbs := summable_abs_ordinaryBooleanCoreTerm
    (q := q) (a := A) (h := H) hq hH h2admissible
  have hSigma :
      Summable
        (fun x : Σ k : ℕ,
          {S // S ∈ h2BooleanGeometricExteriorBand q H N k} =>
          |ordinaryBooleanCoreTerm q A H x.2.1|) := by
    simpa [sigmaVal, Function.comp_def] using
      hAbs.comp_injective
        (h2BooleanGeometricExteriorBand_sigma_val_injective
          (q := q) (H := H) (N := N) hN)
  have hOuter :
      Summable
        (fun k : ℕ =>
          ∑' S : {S // S ∈ h2BooleanGeometricExteriorBand q H N k},
            |ordinaryBooleanCoreTerm q A H S.1|) :=
    hSigma.sigma
  have hfun :
      (fun k : ℕ =>
        ∑' S : {S // S ∈ h2BooleanGeometricExteriorBand q H N k},
          |ordinaryBooleanCoreTerm q A H S.1|) =
      (fun k : ℕ =>
        h2BooleanGeometricCoreBandMass q A H N k) := by
    funext k
    unfold h2BooleanGeometricCoreBandMass
    exact Finset.tsum_subtype
      (h2BooleanGeometricExteriorBand q H N k)
      (fun S => |ordinaryBooleanCoreTerm q A H S|)
  rw [hfun] at hOuter
  exact hOuter

theorem h2BooleanCoreExteriorMajorant_le_geometricBand_tsum
    {q A H N : ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H)
    (hN : 0 < N) :
    h2BooleanCoreExteriorMajorant q A H N ≤
      ∑' k : ℕ, h2BooleanGeometricCoreBandMass q A H N k := by
  classical
  let E : Set (Finset ℕ) :=
    {S | S.Nonempty ∧ N < primeSetProduct S ∧
      S ∈ activeOrdinaryTwoDimensionalSet q H}
  let f : E → ℝ := fun S =>
    h2BooleanCoreExteriorTerm q A H N S.1
  let target :=
    Σ k : ℕ, {S // S ∈ h2BooleanGeometricExteriorBand q H N k}
  let e : E → target := fun S =>
    ⟨h2BooleanGeometricExteriorBandIndex N S.1,
      ⟨S.1,
        h2BooleanActiveOrdinary_mem_geometricExteriorBand
          hN S.property.2.2 S.property.1 S.property.2.1⟩⟩
  let g : target → ℝ := fun x =>
    |ordinaryBooleanCoreTerm q A H x.2.1|
  have hExtSum := summable_h2BooleanCoreExteriorTerm
    (q := q) (A := A) (H := H) (N := N) hq hH h2admissible
  have hf : Summable f := by
    dsimp [f]
    exact hExtSum.subtype (fun S => S ∈ E)
  have hsupp :
      Function.support (h2BooleanCoreExteriorTerm q A H N) ⊆ E := by
    intro S hSupp
    have hnegt : S.Nonempty ∧ N < primeSetProduct S := by
      by_contra h
      have hz : h2BooleanCoreExteriorTerm q A H N S = 0 := by
        simp [h2BooleanCoreExteriorTerm, h]
      exact hSupp hz
    have hAct : S ∈ activeOrdinaryTwoDimensionalSet q H := by
      by_contra h
      have hcore : ordinaryBooleanCoreTerm q A H S = 0 := by
        simp [ordinaryBooleanCoreTerm, Set.indicator, h]
      have hz : h2BooleanCoreExteriorTerm q A H N S = 0 := by
        simp [h2BooleanCoreExteriorTerm, hnegt, hcore]
      exact hSupp hz
    exact ⟨hnegt.1, hnegt.2, hAct⟩
  have hmajorant :
      (∑' S : E, f S) =
        h2BooleanCoreExteriorMajorant q A H N := by
    unfold h2BooleanCoreExteriorMajorant
    rw [← tsum_subtype_eq_of_support_subset hsupp]
  have heinj : Function.Injective e := by
    intro S T hEq
    have hval : S.1 = T.1 := by
      have := congrArg
        (fun x : target => x.2.1) hEq
      exact this
    exact Subtype.ext hval
  have hg : Summable g := by
    dsimp [g, target]
    have hAbs := summable_abs_ordinaryBooleanCoreTerm
      (q := q) (a := A) (h := H) hq hH h2admissible
    simpa [Function.comp_def] using
      hAbs.comp_injective
        (h2BooleanGeometricExteriorBand_sigma_val_injective
          (q := q) (H := H) (N := N) hN)
  have hpoint : ∀ S : E, f S ≤ g (e S) := by
    intro S
    rcases S.property with ⟨hne, hgt, hAct⟩
    dsimp [f, g, e]
    simp [h2BooleanCoreExteriorTerm, hne, hgt]
  have hnonrange : ∀ x ∉ Set.range e, 0 ≤ g x := by
    intro x hx
    exact abs_nonneg _
  have hsum :
      (∑' S : E, f S) ≤ ∑' x : target, g x :=
    Summable.tsum_le_tsum_of_inj
      e heinj hnonrange hpoint hf hg
  rw [hmajorant] at hsum
  calc
    h2BooleanCoreExteriorMajorant q A H N
      ≤ ∑' x : target, g x := hsum
    _ = ∑' k : ℕ, h2BooleanGeometricCoreBandMass q A H N k := by
      dsimp [target, g]
      rw [Summable.tsum_sigma' (fun k => hg.sigma_factor k) hg]
      apply tsum_congr
      intro k
      exact Finset.tsum_subtype
        (h2BooleanGeometricExteriorBand q H N k)
        (fun S => |ordinaryBooleanCoreTerm q A H S|)

#print axioms h2BooleanGeometricExterior_range
#print axioms h2BooleanActiveOrdinary_mem_geometricExteriorBand
#print axioms summable_h2BooleanGeometricCoreBandMass
#print axioms h2BooleanCoreExteriorMajorant_le_geometricBand_tsum

end PaperB.FixedQ

namespace PaperB.FixedQ

lemma h2BooleanGeometricExteriorScale_cast_rpow_neg
    {N k : ℕ} (hN : 0 < N) (δ : ℝ) :
    (((h2BooleanGeometricExteriorScale N k : ℕ) : ℝ) ^ (-δ)) =
      (N : ℝ) ^ (-δ) * ((2 : ℝ) ^ (-δ)) ^ k := by
  unfold h2BooleanGeometricExteriorScale
  rw [Nat.cast_mul, Nat.cast_pow]
  rw [Real.mul_rpow (by positivity) (by positivity)]
  congr 1
  calc
    (((2 : ℝ) ^ k) : ℝ) ^ (-δ) =
        (2 : ℝ) ^ ((k : ℝ) * (-δ)) := by
      rw [← Real.rpow_natCast]
      exact (Real.rpow_mul (by norm_num : (0 : ℝ) ≤ 2)
        (k : ℝ) (-δ)).symm
    _ = (2 : ℝ) ^ ((-δ) * (k : ℝ)) := by
      congr 1
      ring
    _ = ((2 : ℝ) ^ (-δ)) ^ (k : ℝ) := by
      exact Real.rpow_mul (by norm_num : (0 : ℝ) ≤ 2)
        (-δ) (k : ℝ)
    _ = ((2 : ℝ) ^ (-δ)) ^ k := by
      exact Real.rpow_natCast _ _

#print axioms h2BooleanGeometricExteriorScale_cast_rpow_neg

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem h2BooleanCoreExteriorMajorant_le_geometric_decay
    {q A H N : ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H)
    (hN : 0 < N)
    (Shell : ℕ → ℝ)
    (δ C K : ℝ)
    (hδ : 0 < δ)
    (hC : 0 ≤ C)
    (hK : 0 ≤ K)
    (hBand : ∀ k : ℕ,
      h2BooleanGeometricCoreBandMass q A H N k ≤
        Shell (h2BooleanGeometricExteriorScale N k))
    (hDecay : ∀ k : ℕ,
      Shell (h2BooleanGeometricExteriorScale N k) ≤
        C *
          (((h2BooleanGeometricExteriorScale N k : ℕ) : ℝ) ^ (-δ)) *
          K) :
    h2BooleanCoreExteriorMajorant q A H N ≤
      (C * (N : ℝ) ^ (-δ) * K) *
        (1 - (2 : ℝ) ^ (-δ))⁻¹ := by
  let r : ℝ := (2 : ℝ) ^ (-δ)
  let B : ℝ := C * (N : ℝ) ^ (-δ) * K
  have hr0 : 0 ≤ r := by
    dsimp [r]
    exact Real.rpow_nonneg (by norm_num) _
  have hr1 : r < 1 := by
    dsimp [r]
    exact Real.rpow_lt_one_of_one_lt_of_neg
      (by norm_num) (by linarith)
  have hgeom : Summable (fun k : ℕ => B * r ^ k) :=
    (summable_geometric_of_lt_one hr0 hr1).mul_left B
  have hBandSum := summable_h2BooleanGeometricCoreBandMass
    (q := q) (A := A) (H := H) (N := N)
    hq hH h2admissible hN
  have hpoint : ∀ k : ℕ,
      h2BooleanGeometricCoreBandMass q A H N k ≤
        B * r ^ k := by
    intro k
    calc
      h2BooleanGeometricCoreBandMass q A H N k
        ≤ Shell (h2BooleanGeometricExteriorScale N k) := hBand k
      _ ≤ C *
          (((h2BooleanGeometricExteriorScale N k : ℕ) : ℝ) ^ (-δ)) *
          K := hDecay k
      _ = B * r ^ k := by
        rw [h2BooleanGeometricExteriorScale_cast_rpow_neg hN δ]
        dsimp [B, r]
        ring
  have hsum :
      (∑' k : ℕ, h2BooleanGeometricCoreBandMass q A H N k) ≤
        ∑' k : ℕ, B * r ^ k :=
    Summable.tsum_le_tsum hpoint hBandSum hgeom
  have hcover :=
    h2BooleanCoreExteriorMajorant_le_geometricBand_tsum
      (q := q) (A := A) (H := H) (N := N)
      hq hH h2admissible hN
  calc
    h2BooleanCoreExteriorMajorant q A H N
      ≤ ∑' k : ℕ, h2BooleanGeometricCoreBandMass q A H N k := hcover
    _ ≤ ∑' k : ℕ, B * r ^ k := hsum
    _ = B * ∑' k : ℕ, r ^ k := by
      rw [tsum_mul_left]
    _ = B * (1 - r)⁻¹ := by
      rw [tsum_geometric_of_lt_one hr0 hr1]
    _ = (C * (N : ℝ) ^ (-δ) * K) *
        (1 - (2 : ℝ) ^ (-δ))⁻¹ := by
      rfl

#print axioms h2BooleanCoreExteriorMajorant_le_geometric_decay

end PaperB.FixedQ

namespace PaperB.FixedQ

theorem abs_ordinaryBooleanCoreTerm_eq_fixedQProperWeighted
    {q A H : ℕ} {S : Finset ℕ}
    (hAct : S ∈ activeOrdinaryTwoDimensionalSet q H) :
    |ordinaryBooleanCoreTerm q A H S| =
      finiteOmegaWeightReal S * (2 : ℝ) ^ S.card *
        |fixedQProperWeightedDiscrepancy q A H S| := by
  exact
    abs_ordinaryBooleanCoreTerm_eq_weighted_of_interior_normalization
      hAct
      (fun T => fixedQProperWeightedDiscrepancy q A H T)
      (ordinaryBooleanInteriorDiscrepancy_eq_pow_mul_properWeighted
        q A H S)

theorem h2BooleanGeometricCoreBandMass_eq_properWeightedShell
    (q A H N k : ℕ) :
    h2BooleanGeometricCoreBandMass q A H N k =
      h2BooleanProperWeightedDyadicShell
        q A H (h2BooleanGeometricExteriorScale N k) := by
  unfold h2BooleanGeometricCoreBandMass
    h2BooleanGeometricExteriorBand
    h2BooleanProperWeightedDyadicShell
  apply Finset.sum_congr rfl
  intro S hS
  have hm := h2BooleanOrdinaryDyadicSets_mem hS
  have hAct : S ∈ activeOrdinaryTwoDimensionalSet q H :=
    ⟨hm.2, h2BooleanDyadicSets_active hm.1⟩
  exact abs_ordinaryBooleanCoreTerm_eq_fixedQProperWeighted hAct

theorem h2BooleanCoreExteriorMajorant_le_properWeighted_geometric_tsum
    {q A H N : ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H)
    (hN : 0 < N) :
    h2BooleanCoreExteriorMajorant q A H N ≤
      ∑' k : ℕ,
        h2BooleanProperWeightedDyadicShell
          q A H (h2BooleanGeometricExteriorScale N k) := by
  have hcover :=
    h2BooleanCoreExteriorMajorant_le_geometricBand_tsum
      (q := q) (A := A) (H := H) (N := N)
      hq hH h2admissible hN
  refine hcover.trans_eq ?_
  apply tsum_congr
  intro k
  exact h2BooleanGeometricCoreBandMass_eq_properWeightedShell
    q A H N k

theorem h2BooleanCoreExteriorMajorant_le_properWeighted_geometric_decay
    {q A H N : ℕ}
    (hq : 0 < q) (hH : 0 < H)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H)
    (hN : 0 < N)
    (δ C K : ℝ)
    (hδ : 0 < δ)
    (hC : 0 ≤ C)
    (hK : 0 ≤ K)
    (hDecay : ∀ k : ℕ,
      h2BooleanProperWeightedDyadicShell
          q A H (h2BooleanGeometricExteriorScale N k) ≤
        C *
          (((h2BooleanGeometricExteriorScale N k : ℕ) : ℝ) ^ (-δ)) *
          K) :
    h2BooleanCoreExteriorMajorant q A H N ≤
      (C * (N : ℝ) ^ (-δ) * K) *
        (1 - (2 : ℝ) ^ (-δ))⁻¹ := by
  apply h2BooleanCoreExteriorMajorant_le_geometric_decay
    (q := q) (A := A) (H := H) (N := N)
    hq hH h2admissible hN
    (fun M => h2BooleanProperWeightedDyadicShell q A H M)
    δ C K hδ hC hK
  · intro k
    exact le_of_eq
      (h2BooleanGeometricCoreBandMass_eq_properWeightedShell
        q A H N k)
  · exact hDecay

#print axioms abs_ordinaryBooleanCoreTerm_eq_fixedQProperWeighted
#print axioms h2BooleanGeometricCoreBandMass_eq_properWeightedShell
#print axioms h2BooleanCoreExteriorMajorant_le_properWeighted_geometric_tsum
#print axioms h2BooleanCoreExteriorMajorant_le_properWeighted_geometric_decay

end PaperB.FixedQ
