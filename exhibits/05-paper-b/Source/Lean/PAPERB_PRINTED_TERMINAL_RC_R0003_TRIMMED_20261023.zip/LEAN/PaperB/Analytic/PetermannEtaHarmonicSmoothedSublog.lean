import PaperB.Analytic.PetermannEtaHarmonicPartition
import PaperB.Analytic.PetermannEtaHarmonicSmoothing

open scoped BigOperators

namespace PaperB.Analytic

open PaperB.FixedQ
open Real Finset


open PaperB.FixedQ
open Real Finset

lemma etaCharacterDft_norm_le
    (q : ℕ) [NeZero (Nat.lcm 6 q)]
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (h : ZMod (Nat.lcm 6 q)) :
    ‖ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h‖
      ≤ (Nat.lcm 6 q : ℕ) := by
  rw [ZMod.dft_apply]
  calc
    ‖∑ x : ZMod (Nat.lcm 6 q),
        ZMod.stdAddChar (-(x * h)) • chi x‖
      ≤ ∑ x : ZMod (Nat.lcm 6 q),
          ‖ZMod.stdAddChar (-(x * h)) • chi x‖ := norm_sum_le _ _
    _ ≤ ∑ _x : ZMod (Nat.lcm 6 q), (1 : ℝ) := by
      apply Finset.sum_le_sum
      intro x hx
      rw [norm_smul]
      have hchar := chi.norm_le_one x
      have hadd : ‖ZMod.stdAddChar (-(x * h))‖ = 1 := by
        simp [ZMod.stdAddChar_apply]
      rw [hadd, one_mul]
      exact hchar
    _ = (Nat.lcm 6 q : ℕ) := by simp

lemma etaSawSmoothCoeff_pair_le_one
    {S : ℝ} (hS : 1 < S) {j : ℕ} (hj : 1 ≤ j) :
    ‖sawSmoothCoeff S (j : ℤ)‖ +
        ‖sawSmoothCoeff S (-(j : ℤ))‖ ≤ 1 := by
  have hjr : 0 < (j : ℝ) := by exact_mod_cast (show 0 < j by omega)
  have hp := sawSmoothCoeff_le_linear hS
    (n := (j : ℤ)) (by exact_mod_cast (show j ≠ 0 by omega))
  have hn := sawSmoothCoeff_le_linear hS
    (n := -(j : ℤ)) (by
      simp only [neg_ne_zero]
      exact_mod_cast (show j ≠ 0 by omega))
  have hp' :
      ‖sawSmoothCoeff S (j : ℤ)‖
        ≤ 1 / (2 * Real.pi * (j : ℝ)) := by
    simpa [abs_of_pos hjr] using hp
  have hn' :
      ‖sawSmoothCoeff S (-(j : ℤ))‖
        ≤ 1 / (2 * Real.pi * (j : ℝ)) := by
    simpa [abs_of_pos hjr] using hn
  have hpi : 3 < Real.pi := Real.pi_gt_three
  have hpi1 : (1 : ℝ) ≤ Real.pi := by linarith
  have hj1r : (1 : ℝ) ≤ (j : ℝ) := by exact_mod_cast hj
  have hden : 1 ≤ Real.pi * (j : ℝ) := by
    calc
      (1 : ℝ) = 1 * 1 := by norm_num
      _ ≤ Real.pi * (j : ℝ) :=
        mul_le_mul hpi1 hj1r (by norm_num) (by linarith)
  calc
    ‖sawSmoothCoeff S (j : ℤ)‖ +
        ‖sawSmoothCoeff S (-(j : ℤ))‖
      ≤ 1 / (2 * Real.pi * (j : ℝ)) +
          1 / (2 * Real.pi * (j : ℝ)) := add_le_add hp' hn'
    _ = 1 / (Real.pi * (j : ℝ)) := by
      field_simp [Real.pi_ne_zero, ne_of_gt hjr]
      ring
    _ ≤ 1 := by
      exact (div_le_one (by positivity : 0 < Real.pi * (j : ℝ))).2 hden

#print axioms etaCharacterDft_norm_le
#print axioms etaSawSmoothCoeff_pair_le_one


open PaperB.FixedQ
open Real Finset

lemma etaNormalizedDftModeSum_le
    (q : ℕ) [NeZero (Nat.lcm 6 q)]
    (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
    (mode : ZMod (Nat.lcm 6 q) → ℂ)
    {B : ℝ} (hB0 : 0 ≤ B)
    (hmode : ∀ h, ‖mode h‖ ≤ B) :
    ‖(((Nat.lcm 6 q : ℕ) : ℂ)⁻¹ *
        ∑ h : ZMod (Nat.lcm 6 q),
          ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h * mode h)‖
      ≤ ((Nat.lcm 6 q : ℕ) : ℝ)^2 * B := by
  let L := Nat.lcm 6 q
  have hLpos : 0 < L := Nat.pos_of_ne_zero (NeZero.ne L)
  have hL1 : (1 : ℝ) ≤ (L : ℝ) := by exact_mod_cast (show 1 ≤ L by omega)
  have hinv :
      ‖(((L : ℕ) : ℂ)⁻¹)‖ ≤ 1 := by
    rw [norm_inv, Complex.norm_natCast]
    exact (inv_le_one₀ (by exact_mod_cast hLpos)).2 hL1
  rw [norm_mul]
  calc
    ‖(((L : ℕ) : ℂ)⁻¹)‖ *
        ‖∑ h : ZMod L,
          ZMod.dft (fun x : ZMod L => chi x) h * mode h‖
      ≤ 1 *
        ‖∑ h : ZMod L,
          ZMod.dft (fun x : ZMod L => chi x) h * mode h‖ := by
          gcongr
    _ ≤ ∑ h : ZMod L,
          ‖ZMod.dft (fun x : ZMod L => chi x) h * mode h‖ := by
          simpa using norm_sum_le Finset.univ (fun h : ZMod L =>
            ZMod.dft (fun x : ZMod L => chi x) h * mode h)
    _ ≤ ∑ _h : ZMod L, (L : ℝ) * B := by
          apply Finset.sum_le_sum
          intro h hh
          rw [norm_mul]
          exact mul_le_mul
            (etaCharacterDft_norm_le q chi h)
            (hmode h) (norm_nonneg _) (by positivity)
    _ = (L : ℝ)^2 * B := by
          simp [pow_two]
          ring
    _ = ((Nat.lcm 6 q : ℕ) : ℝ)^2 * B := by rfl

#print axioms etaNormalizedDftModeSum_le


set_option maxHeartbeats 1000000 in
theorem etaHarmonicSmoothedSum_scaled_uniform_sublog
    {eps : ℝ} (heps : 0 < eps)
    (q H : ℕ) {S : ℝ} (hS : 1 < S)
    [NeZero (Nat.lcm 6 q)] :
    ∃ A0 : ℝ, 0 < A0 ∧
      ∀ (chi : DirichletCharacter ℂ (Nat.lcm 6 q))
        (r : ℤ) (A : ℝ) (Y : ℕ),
        A0 ≤ A →
        1 ≤ Y →
        (Y : ℝ) ≤ A →
        ‖etaHarmonicSmoothedSum q chi r A Y H S‖
          ≤ eps * Real.log A := by
  by_cases hH0 : H = 0
  · subst H
    refine ⟨1, by norm_num, ?_⟩
    intro chi r A Y hA hY hYA
    rw [etaHarmonicSmoothedSum_expansion hS]
    simp
    have hlog0 : 0 ≤ Real.log A := Real.log_nonneg hA
    positivity
  · have hHpos : 0 < H := Nat.pos_of_ne_zero hH0
    let L := Nat.lcm 6 q
    have hLpos : 0 < L := Nat.pos_of_ne_zero (NeZero.ne L)
    let D : ℝ := (H : ℝ) * (L : ℝ)^2
    have hD : 0 < D := by
      dsimp [D]
      positivity
    let delta : ℝ := eps / D
    have hdelta : 0 < delta := by
      dsimp [delta]
      positivity
    obtain ⟨A0n, hA0n1, hprod⟩ :=
      etaHarmonicAdditiveMode_scaled_uniform_sublog hdelta H
    refine ⟨(A0n : ℝ), by exact_mod_cast hA0n1, ?_⟩
    intro chi r A Y hA0A hY1 hYA
    have hA1 : (1 : ℝ) ≤ A := by
      have hA0r : (1 : ℝ) ≤ (A0n : ℝ) := by exact_mod_cast hA0n1
      exact hA0r.trans hA0A
    have hApos : 0 < A := lt_of_lt_of_le (by norm_num) hA1
    have hlog0 : 0 ≤ Real.log A := Real.log_nonneg hA1
    have hdeltaLog0 : 0 ≤ delta * Real.log A :=
      mul_nonneg hdelta.le hlog0
    have hblock0 : 0 ≤ (L : ℝ)^2 * (delta * Real.log A) := by
      positivity
    rw [etaHarmonicSmoothedSum_expansion hS]
    calc
      ‖∑ k ∈ Finset.range H,
        (sawSmoothCoeff S (k + 1 : ℕ) *
            eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) /
              ((Nat.lcm 6 q : ℕ) : ℝ)) *
            (((Nat.lcm 6 q : ℕ) : ℂ)⁻¹ *
              ∑ h : ZMod (Nat.lcm 6 q),
                ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h *
                  etaHarmonicAdditiveMode Y
                    (((k + 1 : ℕ) : ℝ) * A)
                    ((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))) +
          sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
            eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) /
              ((Nat.lcm 6 q : ℕ) : ℝ)) *
            (((Nat.lcm 6 q : ℕ) : ℂ)⁻¹ *
              ∑ h : ZMod (Nat.lcm 6 q),
                ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h *
                  etaHarmonicAdditiveMode Y
                    ((-((k + 1 : ℕ) : ℤ) : ℝ) * A)
                    ((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))))‖
        ≤ ∑ k ∈ Finset.range H,
            ‖(sawSmoothCoeff S (k + 1 : ℕ) *
                eR (((k + 1 : ℕ) : ℝ) * (r : ℝ) /
                  ((Nat.lcm 6 q : ℕ) : ℝ)) *
                (((Nat.lcm 6 q : ℕ) : ℂ)⁻¹ *
                  ∑ h : ZMod (Nat.lcm 6 q),
                    ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h *
                      etaHarmonicAdditiveMode Y
                        (((k + 1 : ℕ) : ℝ) * A)
                        ((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))) +
              sawSmoothCoeff S (-((k + 1 : ℕ) : ℤ)) *
                eR ((-((k + 1 : ℕ) : ℤ) : ℝ) * (r : ℝ) /
                  ((Nat.lcm 6 q : ℕ) : ℝ)) *
                (((Nat.lcm 6 q : ℕ) : ℂ)⁻¹ *
                  ∑ h : ZMod (Nat.lcm 6 q),
                    ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h *
                      etaHarmonicAdditiveMode Y
                        ((-((k + 1 : ℕ) : ℤ) : ℝ) * A)
                        ((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))))‖ :=
          norm_sum_le _ _
      _ ≤ ∑ _k ∈ Finset.range H,
            (L : ℝ)^2 * (delta * Real.log A) := by
        apply Finset.sum_le_sum
        intro k hk
        rw [Finset.mem_range] at hk
        let j : ℕ := k + 1
        have hj1 : 1 ≤ j := by dsimp [j]; omega
        have hjH : j ≤ H := by dsimp [j]; omega
        have hjr : 0 < (j : ℝ) := by exact_mod_cast (show 0 < j by omega)
        have hposAbs :
            |(j : ℝ) * A| = (j : ℝ) * A := by
          rw [abs_of_pos]
          exact mul_pos hjr hApos
        have hnegAbs :
            |(-(j : ℝ)) * A| = (j : ℝ) * A := by
          rw [abs_mul, abs_neg, abs_of_pos hjr, abs_of_pos hApos]
        have hposMode :
            ∀ h : ZMod (Nat.lcm 6 q),
              ‖etaHarmonicAdditiveMode Y
                  ((j : ℝ) * A)
                  ((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))‖
                ≤ delta * Real.log A := by
          intro h
          exact hprod hA0A hY1 hYA hj1 hjH hposAbs
        have hnegMode :
            ∀ h : ZMod (Nat.lcm 6 q),
              ‖etaHarmonicAdditiveMode Y
                  ((-(j : ℝ)) * A)
                  ((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))‖
                ≤ delta * Real.log A := by
          intro h
          exact hprod hA0A hY1 hYA hj1 hjH hnegAbs
        have hposBlock :=
          etaNormalizedDftModeSum_le q chi
            (fun h : ZMod (Nat.lcm 6 q) =>
              etaHarmonicAdditiveMode Y
                ((j : ℝ) * A)
                ((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)))
            hdeltaLog0 hposMode
        have hnegBlock :=
          etaNormalizedDftModeSum_le q chi
            (fun h : ZMod (Nat.lcm 6 q) =>
              etaHarmonicAdditiveMode Y
                ((-(j : ℝ)) * A)
                ((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)))
            hdeltaLog0 hnegMode
        have hpair := etaSawSmoothCoeff_pair_le_one hS hj1
        have hposTerm :
            ‖sawSmoothCoeff S (j : ℤ) *
                eR ((j : ℝ) * (r : ℝ) /
                  ((Nat.lcm 6 q : ℕ) : ℝ)) *
                (((Nat.lcm 6 q : ℕ) : ℂ)⁻¹ *
                  ∑ h : ZMod (Nat.lcm 6 q),
                    ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h *
                      etaHarmonicAdditiveMode Y
                        ((j : ℝ) * A)
                        ((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)))‖
              ≤ ‖sawSmoothCoeff S (j : ℤ)‖ *
                  ((L : ℝ)^2 * (delta * Real.log A)) := by
          rw [norm_mul, norm_mul, norm_eR, mul_one]
          exact mul_le_mul_of_nonneg_left hposBlock (norm_nonneg _)
        have hnegTerm :
            ‖sawSmoothCoeff S (-(j : ℤ)) *
                eR ((-(j : ℝ)) * (r : ℝ) /
                  ((Nat.lcm 6 q : ℕ) : ℝ)) *
                (((Nat.lcm 6 q : ℕ) : ℂ)⁻¹ *
                  ∑ h : ZMod (Nat.lcm 6 q),
                    ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h *
                      etaHarmonicAdditiveMode Y
                        ((-(j : ℝ)) * A)
                        ((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)))‖
              ≤ ‖sawSmoothCoeff S (-(j : ℤ))‖ *
                  ((L : ℝ)^2 * (delta * Real.log A)) := by
          rw [norm_mul, norm_mul, norm_eR, mul_one]
          exact mul_le_mul_of_nonneg_left hnegBlock (norm_nonneg _)
        let P : ℂ :=
          sawSmoothCoeff S (j : ℤ) *
            eR ((j : ℝ) * (r : ℝ) /
              ((Nat.lcm 6 q : ℕ) : ℝ)) *
            (((Nat.lcm 6 q : ℕ) : ℂ)⁻¹ *
              ∑ h : ZMod (Nat.lcm 6 q),
                ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h *
                  etaHarmonicAdditiveMode Y
                    ((j : ℝ) * A)
                    ((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)))
        let N : ℂ :=
          sawSmoothCoeff S (-(j : ℤ)) *
            eR ((-(j : ℝ)) * (r : ℝ) /
              ((Nat.lcm 6 q : ℕ) : ℝ)) *
            (((Nat.lcm 6 q : ℕ) : ℂ)⁻¹ *
              ∑ h : ZMod (Nat.lcm 6 q),
                ZMod.dft (fun x : ZMod (Nat.lcm 6 q) => chi x) h *
                  etaHarmonicAdditiveMode Y
                    ((-(j : ℝ)) * A)
                    ((h.val : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)))
        have hP : ‖P‖ ≤ ‖sawSmoothCoeff S (j : ℤ)‖ *
            ((L : ℝ)^2 * (delta * Real.log A)) := by
          simpa [P] using hposTerm
        have hN : ‖N‖ ≤ ‖sawSmoothCoeff S (-(j : ℤ))‖ *
            ((L : ℝ)^2 * (delta * Real.log A)) := by
          simpa [N] using hnegTerm
        have hpairTerm : ‖P + N‖ ≤ (L : ℝ)^2 * (delta * Real.log A) := by
          calc
            ‖P + N‖ ≤ ‖P‖ + ‖N‖ := norm_add_le _ _
            _ ≤ ‖sawSmoothCoeff S (j : ℤ)‖ *
                  ((L : ℝ)^2 * (delta * Real.log A)) +
                ‖sawSmoothCoeff S (-(j : ℤ))‖ *
                  ((L : ℝ)^2 * (delta * Real.log A)) := add_le_add hP hN
            _ = (‖sawSmoothCoeff S (j : ℤ)‖ +
                  ‖sawSmoothCoeff S (-(j : ℤ))‖) *
                  ((L : ℝ)^2 * (delta * Real.log A)) := by ring
            _ ≤ (L : ℝ)^2 * (delta * Real.log A) := by
                  simpa [one_mul] using
                    mul_le_mul_of_nonneg_right hpair hblock0
        simpa [P, N, j] using hpairTerm
      _ = (H : ℝ) * ((L : ℝ)^2 * (delta * Real.log A)) := by simp
      _ = eps * Real.log A := by
        dsimp [delta, D]
        field_simp [hD.ne']

#print axioms etaHarmonicSmoothedSum_scaled_uniform_sublog

end PaperB.Analytic
