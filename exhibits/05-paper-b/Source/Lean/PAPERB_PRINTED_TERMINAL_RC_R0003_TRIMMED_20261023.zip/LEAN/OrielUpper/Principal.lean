import OrielUpper.Row
import Mathlib.Algebra.Order.Floor.Semifield

/-!
# Oriel Upper — principal cancellation

`oriel_principal_cancellation`:
`|∑_{v ∈ (ZMod P)ˣ} ∑_{t ∈ (ZMod m)ˣ} ψ v t x| ≤ τ(m) (2P+1) φ(P) B`,
uniformly in real `x ≥ 0`.  The principal mean cancels EXACTLY (via
`φ(m) = ∑ μ(d) m/d`) before any absolute value is taken.
-/

open Finset ArithmeticFunction
open scoped ArithmeticFunction.Moebius

namespace OrielUpper

variable {P : ℕ} [NeZero P]

/-- Exactly one unit `t` solves `H = t u` when `u` is a unit (and none otherwise). -/
lemma sum_units_indicator {m : ℕ} [NeZero m] {H : ℕ} (hH : IsUnit (H : ZMod m)) (u : ℕ) :
    ∑ t : (ZMod m)ˣ, (if (H : ZMod m) = (t : ZMod m) * u then (1 : ℝ) else 0) =
      if Nat.Coprime u m then 1 else 0 := by
  by_cases hu : Nat.Coprime u m
  · rw [if_pos hu]
    have huU : IsUnit (u : ZMod m) := (ZMod.isUnit_iff_coprime u m).mpr hu
    obtain ⟨uU, huU'⟩ := huU
    obtain ⟨HU, hHU⟩ := hH
    have key : ∀ t : (ZMod m)ˣ, ((H : ZMod m) = (t : ZMod m) * u) ↔ t = HU * uU⁻¹ := by
      intro t
      rw [← huU', ← hHU]
      constructor
      · intro h
        apply Units.ext
        rw [Units.val_mul, h, mul_assoc, ← Units.val_mul, mul_inv_cancel, Units.val_one, mul_one]
      · rintro rfl
        rw [Units.val_mul, mul_assoc, ← Units.val_mul, inv_mul_cancel, Units.val_one, mul_one]
    simp_rw [key]
    simp
  · rw [if_neg hu]
    apply sum_eq_zero
    intro t _
    rw [if_neg]
    intro h
    apply hu
    rw [← ZMod.isUnit_iff_coprime]
    have : (u : ZMod m) = ((t⁻¹ : (ZMod m)ˣ) : ZMod m) * (H : ZMod m) := by
      rw [h, ← mul_assoc, ← Units.val_mul, inv_mul_cancel, Units.val_one, one_mul]
    rw [this]
    exact (Units.isUnit _).mul hH

/-- The divisor-restricted sum reindexed by `u = d u'`. -/
lemma sum_Icc_dvd {d : ℕ} (hd : 0 < d) (N : ℕ) (G : ℕ → ℝ) :
    ∑ u ∈ (Icc 1 N).filter (d ∣ ·), G u = ∑ k ∈ Icc 1 (N / d), G (d * k) := by
  symm
  apply Finset.sum_nbij' (fun k => d * k) (fun u => u / d)
  · intro k hk
    rw [mem_Icc] at hk
    rw [mem_filter, mem_Icc]
    refine ⟨⟨?_, ?_⟩, dvd_mul_right d k⟩
    · exact Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero hd.ne' (by omega))
    · have := (Nat.le_div_iff_mul_le hd).mp hk.2
      rw [Nat.mul_comm]; exact this
  · intro u hu
    rw [mem_filter, mem_Icc] at hu
    rw [mem_Icc]
    obtain ⟨k, rfl⟩ := hu.2
    rw [Nat.mul_div_cancel_left _ hd]
    refine ⟨?_, ?_⟩
    · rcases Nat.eq_zero_or_pos k with h | h
      · subst h; simp at hu
      · exact h
    · apply (Nat.le_div_iff_mul_le hd).mpr; rw [Nat.mul_comm]; exact hu.1.2
  · intro k _; exact Nat.mul_div_cancel_left k hd
  · intro u hu
    rw [mem_filter] at hu
    exact Nat.mul_div_cancel' hu.2
  · intro k _; rfl

theorem oriel_principal_cancellation {m H : ℕ} [NeZero m] {Λ : ZMod P → ℝ} {B : ℝ}
    (hB : ∀ z, |Λ z| ≤ B) {α β : ZMod P}
    (hmP : Nat.Coprime m P) (hβ : IsUnit β) (hH : IsUnit (H : ZMod m)) {x : ℝ} (hx : 0 ≤ x) :
    |∑ v : (ZMod P)ˣ, ∑ t : (ZMod m)ˣ, psiR m H Λ α β (v : ZMod P) (t : ZMod m) x| ≤
      (m.divisors.card : ℝ) * ((2 * P + 1) * (Nat.totient P * B)) := by
  have hm : 0 < m := NeZero.pos m
  have hP0 : 0 < P := NeZero.pos P
  have hPr : (0 : ℝ) < P := by exact_mod_cast hP0
  have hmr : (0 : ℝ) < m := by exact_mod_cast hm
  have hB0 : 0 ≤ B := le_trans (abs_nonneg _) (hB 0)
  set N := ⌊x⌋₊
  set G : ℕ → ℝ := fun u => ∑ v : (ZMod P)ˣ, Λ (α + β * (v : ZMod P) * u) with hG
  -- 1. collapse the `t` sum
  have hrow : ∀ u, ∑ v : (ZMod P)ˣ, ∑ t : (ZMod m)ˣ, rowF m H Λ α β (v : ZMod P) (t : ZMod m) u =
      if Nat.Coprime u m then G u else 0 := by
    intro u
    unfold rowF
    simp_rw [← mul_sum, sum_units_indicator hH u]
    by_cases h : Nat.Coprime u m
    · simp [h, hG]
    · simp [h]
  have hcollapse : ∑ v : (ZMod P)ˣ, ∑ t : (ZMod m)ˣ,
      psiR m H Λ α β (v : ZMod P) (t : ZMod m) x =
      ∑ u ∈ Icc 1 N, (if Nat.Coprime u m then G u else 0) -
        (Nat.totient P : ℝ) * Nat.totient m * (muL Λ * x / m) := by
    unfold psiR
    have e1 : ∑ v : (ZMod P)ˣ, ∑ t : (ZMod m)ˣ,
        (∑ u ∈ Icc 1 N, rowF m H Λ α β (v : ZMod P) (t : ZMod m) u - muL Λ * x / m) =
        ∑ v : (ZMod P)ˣ, ∑ t : (ZMod m)ˣ, ∑ u ∈ Icc 1 N, rowF m H Λ α β (v : ZMod P) (t : ZMod m) u
          - ∑ _v : (ZMod P)ˣ, ∑ _t : (ZMod m)ˣ, muL Λ * x / m := by
      simp only [sum_sub_distrib]
    have e2 : ∑ v : (ZMod P)ˣ, ∑ t : (ZMod m)ˣ, ∑ u ∈ Icc 1 N,
        rowF m H Λ α β (v : ZMod P) (t : ZMod m) u =
        ∑ u ∈ Icc 1 N, ∑ v : (ZMod P)ˣ, ∑ t : (ZMod m)ˣ,
          rowF m H Λ α β (v : ZMod P) (t : ZMod m) u := by
      calc ∑ v : (ZMod P)ˣ, ∑ t : (ZMod m)ˣ, ∑ u ∈ Icc 1 N,
            rowF m H Λ α β (v : ZMod P) (t : ZMod m) u
          = ∑ v : (ZMod P)ˣ, ∑ u ∈ Icc 1 N, ∑ t : (ZMod m)ˣ,
            rowF m H Λ α β (v : ZMod P) (t : ZMod m) u :=
            sum_congr rfl (fun v _ => sum_comm)
        _ = _ := sum_comm
    rw [e1, e2, sum_congr rfl (fun u _ => hrow u)]
    congr 1
    simp only [sum_const, card_univ, ZMod.card_units_eq_totient, nsmul_eq_mul]
    ring
  -- 2. Möbius expansion
  have hmob : ∑ u ∈ Icc 1 N, (if Nat.Coprime u m then G u else 0) =
      ∑ d ∈ m.divisors, (μ d : ℝ) * ∑ k ∈ Icc 1 (N / d), G (d * k) := by
    have : ∀ u, (if Nat.Coprime u m then G u else 0) =
        (∑ d ∈ m.divisors with d ∣ u, (μ d : ℝ)) * G u := by
      intro u; rw [← oriel_coprime_indicator hm.ne' u]; split_ifs <;> simp
    simp_rw [this, sum_mul]
    rw [sum_comm' (t' := m.divisors) (s' := fun d => (Icc 1 N).filter (d ∣ ·))]
    · apply sum_congr rfl
      intro d hd
      rw [← mul_sum, sum_Icc_dvd (Nat.pos_of_mem_divisors hd)]
    · intro u d; simp only [mem_filter]; tauto
  -- 3. periodic estimate for each divisor
  have hper_d : ∀ d ∈ m.divisors,
      |∑ k ∈ Icc 1 (N / d), G (d * k) - (Nat.totient P : ℝ) * muL Λ * (x / d)| ≤
        (2 * P + 1) * (Nat.totient P * B) := by
    intro d hd
    have hd0 : 0 < d := Nat.pos_of_mem_divisors hd
    have hdr : (0 : ℝ) < d := by exact_mod_cast hd0
    have hdP : IsUnit (d : ZMod P) := by
      rw [ZMod.isUnit_iff_coprime]
      exact Nat.Coprime.coprime_dvd_left (Nat.dvd_of_mem_divisors hd) hmP
    set g : ℕ → ℝ := fun k => G (d * k) with hg
    have hgper : ∀ k, g (k + P) = g k := by
      intro k; simp only [hg, hG]
      apply sum_congr rfl; intro v _
      congr 1; push_cast; rw [ZMod.natCast_self]; ring
    have hgbd : ∀ k, |g k| ≤ Nat.totient P * B := by
      intro k
      calc |g k| ≤ ∑ v : (ZMod P)ˣ, |Λ (α + β * (v : ZMod P) * ((d * k : ℕ) : ZMod P))| :=
            abs_sum_le_sum_abs _ _
        _ ≤ ∑ _v : (ZMod P)ˣ, B := sum_le_sum (fun v _ => hB _)
        _ = Nat.totient P * B := by
            rw [sum_const, card_univ, ZMod.card_units_eq_totient, nsmul_eq_mul]
    have hgfull : ∑ k ∈ range P, g k = Nat.totient P * ∑ z, Λ z := by
      simp only [hg, hG]
      rw [sum_comm]
      have : ∀ v : (ZMod P)ˣ, ∑ k ∈ range P, Λ (α + β * (v : ZMod P) * ((d * k : ℕ) : ZMod P)) =
          ∑ z, Λ z := by
        intro v
        obtain ⟨γ, hγ⟩ : ∃ γ : (ZMod P)ˣ, (γ : ZMod P) = β * v * (d : ZMod P) :=
          ⟨(hβ.mul v.isUnit).mul hdP |>.unit, rfl⟩
        rw [← sum_range_affine Λ α γ]
        apply sum_congr rfl; intro k _
        rw [hγ]; push_cast; ring_nf
      rw [sum_congr rfl (fun v _ => this v), sum_const, card_univ,
        ZMod.card_units_eq_totient, nsmul_eq_mul]
    have hy : 0 ≤ x / d := div_nonneg hx hdr.le
    have := oriel_periodic_partial_sum hP0 hgper hgbd hy
    rw [hgfull, Nat.floor_div_natCast] at this
    have e : ((Nat.totient P : ℝ) * ∑ z, Λ z) / P * (x / d) =
        (Nat.totient P : ℝ) * muL Λ * (x / d) := by unfold muL; ring
    rw [e] at this
    exact this
  -- 4. exact principal cancellation
  have hmain : ∑ d ∈ m.divisors, (μ d : ℝ) * ((Nat.totient P : ℝ) * muL Λ * (x / d)) =
      (Nat.totient P : ℝ) * Nat.totient m * (muL Λ * x / m) := by
    have htot := oriel_totient_moebius hm.ne'
    have : ∀ d ∈ m.divisors, (μ d : ℝ) * ((Nat.totient P : ℝ) * muL Λ * (x / d)) =
        ((μ d : ℝ) * ((m / d : ℕ) : ℝ)) * ((Nat.totient P : ℝ) * muL Λ * (x / m)) := by
      intro d hd
      have hd0 : (d : ℝ) ≠ 0 := by exact_mod_cast (Nat.pos_of_mem_divisors hd).ne'
      rw [Nat.cast_div (Nat.dvd_of_mem_divisors hd) hd0]
      field_simp
    rw [sum_congr rfl this, ← sum_mul, ← htot]
    ring
  rw [hcollapse, hmob, ← hmain, ← sum_sub_distrib]
  simp_rw [← mul_sub]
  calc |∑ d ∈ m.divisors, (μ d : ℝ) * (∑ k ∈ Icc 1 (N / d), G (d * k) -
          (Nat.totient P : ℝ) * muL Λ * (x / d))|
      ≤ ∑ d ∈ m.divisors, |(μ d : ℝ)| * |∑ k ∈ Icc 1 (N / d), G (d * k) -
          (Nat.totient P : ℝ) * muL Λ * (x / d)| := by
        refine (abs_sum_le_sum_abs _ _).trans ?_
        simp_rw [abs_mul]; rfl
    _ ≤ ∑ _d ∈ m.divisors, 1 * ((2 * P + 1) * (Nat.totient P * B)) := by
        apply sum_le_sum; intro d hd
        apply mul_le_mul _ (hper_d d hd) (abs_nonneg _) zero_le_one
        have := abs_moebius_le_one (n := d)
        exact_mod_cast this
    _ = _ := by rw [sum_const, nsmul_eq_mul, one_mul]

end OrielUpper
