import PaperB.FixedQ.SignedForbiddenB1Principal
import PaperB.FixedQ.SignedForbiddenS1PrincipalCoefficient
import PaperB.FixedQ.SignedForbiddenMeanNormalization

namespace PaperB.FixedQ

noncomputable def signedMainPrincipalCoefficient (q : ℕ) : ℝ :=
  - (1 / 2 : ℝ) *
    ((Nat.totient (fixedQPeriod q) : ℝ) / (fixedQPeriod q : ℝ)) *
    freeLowPrimeFactor q 0

noncomputable def signedMainB1Principal (q H : ℕ) : ℝ :=
  2 * signedMainPrincipalCoefficient q * Real.log ((H - 1 : ℕ) : ℝ)

theorem manuscriptS1Principal_eq_signedMainPrincipal
    {q r H : ℕ} (hq : 0 < q) [NeZero (fixedQPeriod q)]
    (hr : q.Coprime r) :
    manuscriptS1Principal q r H =
      signedMainPrincipalCoefficient q *
        Real.log ((H - 1 : ℕ) : ℝ) := by
  unfold manuscriptS1Principal signedMainPrincipalCoefficient
  rw [s1PrincipalCoefficient_eq_fixedQ hq hr]

theorem manuscriptS1Principal_add_eq_signedMainB1Principal
    {q r₁ r₂ H : ℕ} (hq : 0 < q) [NeZero (fixedQPeriod q)]
    (hr₁ : q.Coprime r₁) (hr₂ : q.Coprime r₂) :
    manuscriptS1Principal q r₁ H + manuscriptS1Principal q r₂ H =
      signedMainB1Principal q H := by
  rw [manuscriptS1Principal_eq_signedMainPrincipal hq hr₁,
    manuscriptS1Principal_eq_signedMainPrincipal hq hr₂]
  unfold signedMainB1Principal
  ring

theorem cStar_mul_pairBaseline_signedMainPrincipal
    (q h H : ℕ) :
    cStarReal q h *
        (∑' e : Finset ℕ,
          (∑ e1 ∈ e.powerset,
            pairCoefficient q h e e1 / pairDenominator e e1) *
            (signedMainPrincipalCoefficient q *
              Real.log ((H - 1 : ℕ) : ℝ))) =
      signedMainPrincipalCoefficient q *
        Real.log ((H - 1 : ℕ) : ℝ) := by
  exact cStar_mul_pairBaseline_principal q h _

#print axioms manuscriptS1Principal_eq_signedMainPrincipal
#print axioms manuscriptS1Principal_add_eq_signedMainB1Principal
#print axioms cStar_mul_pairBaseline_signedMainPrincipal

end PaperB.FixedQ
