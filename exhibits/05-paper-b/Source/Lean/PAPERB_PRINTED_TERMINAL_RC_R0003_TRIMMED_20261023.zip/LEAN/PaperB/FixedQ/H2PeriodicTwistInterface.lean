import PaperB.FixedQ.H2BooleanPeriodicWeightedET
import PaperB.FixedQ.H2BooleanDyadicSecondMoment

namespace PaperB.FixedQ

lemma primeSetProduct_dvd_of_subset
    {T S : Finset ℕ} (hTS : T ⊆ S) :
    primeSetProduct T ∣ primeSetProduct S := by
  unfold primeSetProduct
  exact Finset.prod_dvd_prod_of_subset T S (fun p : ℕ => p) hTS

noncomputable def zmodUnitProject
    {m n : ℕ} (hmn : m ∣ n) :
    (ZMod n)ˣ →* (ZMod m)ˣ :=
  Units.map (ZMod.castHom hmn (ZMod m)).toMonoidHom

lemma zmodUnitProject_unitOfCoprime
    {m n P : ℕ} (hmn : m ∣ n) (hPn : P.Coprime n) :
    zmodUnitProject hmn (ZMod.unitOfCoprime P hPn) =
      ZMod.unitOfCoprime P (hPn.of_dvd_right hmn) := by
  apply Units.ext
  simp [zmodUnitProject, ZMod.coe_unitOfCoprime]

lemma fixedProductBooleanPeriodicTwist_project
    {P H : ℕ} {T S : Finset ℕ}
    (hTS : T ⊆ S)
    (hPS : P.Coprime (primeSetProduct S))
    (hHS : H.Coprime (primeSetProduct S)) :
    zmodUnitProject (primeSetProduct_dvd_of_subset hTS)
      (fixedProductBooleanPeriodicTwist P H S hPS hHS) =
    fixedProductBooleanPeriodicTwist P H T
      (hPS.of_dvd_right (primeSetProduct_dvd_of_subset hTS))
      (hHS.of_dvd_right (primeSetProduct_dvd_of_subset hTS)) := by
  unfold fixedProductBooleanPeriodicTwist
  rw [map_mul, map_inv]
  rw [zmodUnitProject_unitOfCoprime, zmodUnitProject_unitOfCoprime]

lemma h2BooleanDyadicSmoothFiber_subset
    {q Y M : ℕ} {T S : Finset ℕ}
    (hS : S ∈ h2BooleanDyadicSmoothFiber q Y M T) :
    T ⊆ S := by
  rw [h2BooleanDyadicSmoothFiber_partition hS]
  exact Finset.subset_union_left

#print axioms fixedProductBooleanPeriodicTwist_project
#print axioms h2BooleanDyadicSmoothFiber_subset

end PaperB.FixedQ
