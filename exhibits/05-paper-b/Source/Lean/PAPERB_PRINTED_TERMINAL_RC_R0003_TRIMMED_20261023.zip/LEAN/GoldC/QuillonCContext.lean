import GoldC.QuillonRamareSplit
import GoldC.QuillonExplicit

/-!
# Quillon CSC3 F7.5j: region C remainder at the finset level (Parseval-W + VW)

For `r` with a big prime (Ramaré set `J ⊆ U ∩ (P₀, 2^{Kp}P₀]`) and one dyadic `r`-range
`(I₀,I₁]`, split `n = ∏B'` as follows:
- `n ≥ X` → `P_bilinear_full`;
- `n < X` → a prime sum for each `m₀ = n`, bounded by the hypothesis `hVW`.
  `hVW` is discharged separately from `vw_lambda_class` and `prime_sum_omega`.

No axiom, no `sorry`.
-/

open scoped BigOperators
open Finset

namespace GoldC.QuillonCContext

open GoldC.QuillonWContext GoldC.QuillonRamareSplit GoldC.QuillonPContext GoldC.QuillonWBilinear
  GoldC.QuillonVW GoldC.QuillonOmega

variable {s : ℕ} [NeZero s] {M : ℕ} [NeZero M]

theorem C_context (P : Finset ℕ) (hP : ∀ p ∈ P, p.Prime) (hsP : s = ∏ p ∈ P, p)
    (𝒥 : Finset ℕ) (Acoef : ZMod M → ℕ → ℂ) (c : ℕ → ZMod s)
    (U J : Finset ℕ) (hJU : J ⊆ U) (hU : ∀ p ∈ U, p.Prime ∧ 5 ≤ p)
    (hUM : ∀ p ∈ U, Nat.Coprime p M)
    (P₀ Kp X T I₀ I₁ : ℕ) (hP₀ : 2 ≤ P₀) (hT : 2 ≤ T) (hX : 2 ≤ X)
    (hI : I₀ ≤ I₁) (hI0 : 1 ≤ I₀) (hI₁3 : 3 ≤ I₁) (hJ : J ⊆ Ioc P₀ (2 ^ Kp * P₀))
    (Kset : Finset ℕ) (Vbound : ℝ)
    (hVW : ∀ B' ∈ U.powerset, (∏ q ∈ B', q) < X →
      ‖∑ p ∈ J, ((1 / ((p : ℝ) - 3) : ℝ) : ℂ) *
        (if p * ∏ q ∈ B', q ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (p * ∏ q ∈ B', q) else 0)‖ ≤ Vbound) :
    ‖∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty), (ωR B : ℂ) *
        (if (∏ p ∈ B, p) ∈ Ioc I₀ I₁ ∧ B.card ∈ Kset then rowW 𝒥 Acoef c (∏ p ∈ B, p) else 0)‖ ≤
      ∑ k ∈ range Kp, (M : ℝ) * ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ *
        (2 * (Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 I₁) : ℝ) ^ 30) ^ 2 / I₀ *
          TIIb P (c j) (2 ^ k * P₀) (X - 1) T I₁) +
      (∑ B' ∈ (U.filter (fun p => p < X)).powerset, ωR B') * Vbound +
      (∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖) * (∏ p ∈ U, (1 + 1 / ((p : ℝ) - 3))) *
        ∑ p ∈ J, (1 / ((p : ℝ) - 3)) ^ 2 := by
  classical
  set Atot : ℝ := ∑ ρ : ZMod M, ∑ j ∈ 𝒥, ‖Acoef ρ j‖ with hAtot
  set Aω : ℝ := Real.exp 37.5 * (1 + Nat.log 2 (Nat.log 2 I₁) : ℝ) ^ 30 with hAω
  set Φ : ℕ → ℕ → ℂ := fun r k => if r ∈ Ioc I₀ I₁ ∧ k ∈ Kset then rowW 𝒥 Acoef c r else 0 with hΦ
  have hΦle : ∀ r k, ‖Φ r k‖ ≤ Atot := by
    intro r k; simp only [hΦ]; split_ifs
    · exact norm_rowW_le 𝒥 Acoef c r
    · rw [norm_zero]; exact sum_nonneg fun _ _ => sum_nonneg fun _ _ => norm_nonneg _
  have hrw : ∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty), (ωR B : ℂ) *
      (if (∏ p ∈ B, p) ∈ Ioc I₀ I₁ ∧ B.card ∈ Kset then rowW 𝒥 Acoef c (∏ p ∈ B, p) else 0) =
      ∑ B ∈ U.powerset.filter (fun B => (B ∩ J).Nonempty), (ωR B : ℂ) * Φ (∏ p ∈ B, p) B.card := rfl
  rw [hrw, ramare_split U J hJU Φ]
  refine (norm_sub_le _ _).trans ?_
  refine add_le_add ?_ (ramare_err_le U J hJU hU Φ Atot hΦle)
  -- split the main term by `∏B' ≥ X`
  have hUp : ∀ p ∈ U, p.Prime := fun p hp => (hU p hp).1
  set α : ℕ → ℂ := fun p => ((1 / ((p : ℝ) - 3) : ℝ) : ℂ) with hα
  set β' : Finset ℕ → ℂ := fun B' => ((ωR B' / (1 + ((B' ∩ J).card : ℝ)) : ℝ) : ℂ) *
    (if B'.card + 1 ∈ Kset then (1 : ℂ) else 0) with hβ'
  set G : ℕ → ℂ := fun n => ∑ p ∈ J, α p *
    (if p * n ∈ Ioc I₀ I₁ then rowW 𝒥 Acoef c (p * n) else 0) with hG
  have e1 : ∑ p ∈ J, ∑ B' ∈ U.powerset, gR J Φ p B' = ∑ B' ∈ U.powerset, β' B' * G (∏ q ∈ B', q) := by
    rw [sum_comm]
    refine sum_congr rfl fun B' _ => ?_
    rw [hG, mul_sum]
    refine sum_congr rfl fun p _ => ?_
    simp only [gR, hΦ, hβ', hα]
    by_cases h1 : p * ∏ q ∈ B', q ∈ Ioc I₀ I₁ <;> by_cases h2 : B'.card + 1 ∈ Kset <;>
      simp [h1, h2] <;> ring
  rw [e1, ← sum_filter_add_sum_filter_not U.powerset (fun B' => X ≤ ∏ q ∈ B', q)]
  refine (norm_add_le _ _).trans (add_le_add ?_ ?_)
  · -- Parseval part
    set β : ℕ → ℂ := fun n => β' n.primeFactors with hβ
    have e2 : ∑ B' ∈ U.powerset.filter (fun B' => X ≤ ∏ q ∈ B', q), β' B' * G (∏ q ∈ B', q) =
        ∑ n ∈ (U.powerset.filter (fun B' => X ≤ ∏ q ∈ B', q)).image (fun B => ∏ q ∈ B, q),
          β n * G n := by
      rw [sum_image (fun B₁ h₁ B₂ h₂ heq => prod_injOn U hUp (mem_filter.1 h₁).1
        (mem_filter.1 h₂).1 heq)]
      refine sum_congr rfl fun B' hB' => ?_
      simp only [hβ]
      rw [Nat.primeFactors_prod fun q hq => hUp q (mem_powerset.1 (mem_filter.1 hB').1 hq)]
    set 𝒩 := ((U.powerset.filter (fun B' => X ≤ ∏ q ∈ B', q)).image
      (fun B => ∏ q ∈ B, q)).filter (fun n => n ≤ I₁) with h𝒩def
    have e3 : ∑ n ∈ (U.powerset.filter (fun B' => X ≤ ∏ q ∈ B', q)).image (fun B => ∏ q ∈ B, q),
        β n * G n = ∑ n ∈ 𝒩, β n * G n := by
      rw [h𝒩def, sum_filter]
      refine sum_congr rfl fun n _ => ?_
      split_ifs with hn
      · rfl
      · have : G n = 0 := by
          simp only [hG]
          refine sum_eq_zero fun p hp => ?_
          have hp1 : 1 ≤ p := by have := (mem_Ioc.1 (hJ hp)).1; omega
          rw [if_neg, mul_zero]
          intro hI'
          have := (mem_Ioc.1 hI').2
          have : n ≤ p * n := Nat.le_mul_of_pos_left n (by omega)
          omega
        rw [this, mul_zero]
    rw [e2, e3]
    have hAω0 : 0 < Aω := by positivity
    have hP := P_bilinear_full P hP hsP 𝒥 Acoef c J 𝒩 P₀ Kp X T I₀ I₁ hP₀ hT (by omega) hI hI0 hI₁3
      hJ (fun p hp => (ZMod.isUnit_iff_coprime p M).2 (hUM p (hJU hp)))
      (fun n hn => by
        obtain ⟨B', hB', rfl⟩ := mem_image.1 (mem_filter.1 hn).1
        exact (mem_filter.1 hB').2)
      α β Aω hAω0
      (fun p hp => by
        have h5 : (5 : ℝ) ≤ p := by exact_mod_cast (hU p (hJU hp)).2
        simp only [hα]
        rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (by apply div_nonneg zero_le_one; linarith)]
        rw [div_le_div_iff₀ (by linarith) (by linarith)]
        have hA1 : (2.5 : ℝ) ≤ Aω := by
          have : (2.5 : ℝ) ≤ Real.exp 37.5 := by
            have := Real.add_one_le_exp (37.5 : ℝ); linarith
          have : (1 : ℝ) ≤ (1 + Nat.log 2 (Nat.log 2 I₁) : ℝ) ^ 30 :=
            one_le_pow₀ (by linarith [(Nat.cast_nonneg _ : (0 : ℝ) ≤ Nat.log 2 (Nat.log 2 I₁))])
          nlinarith [Real.exp_pos 37.5]
        nlinarith)
      (fun n hn => by
        have hn' := mem_filter.1 hn
        obtain ⟨B', hB', rfl⟩ := mem_image.1 hn'.1
        have hB'U := mem_powerset.1 (mem_filter.1 hB').1
        simp only [hβ]
        rw [Nat.primeFactors_prod fun q hq => hUp q (hB'U hq)]
        simp only [hβ']
        have hω0 := ωR_nonneg B' fun q hq => (hU q (hB'U hq)).2
        have hωle := omega_pointwise B' (fun q hq => hU q (hB'U hq)) I₁ hn'.2
        rw [norm_mul]
        calc ‖((ωR B' / (1 + ((B' ∩ J).card : ℝ)) : ℝ) : ℂ)‖ *
              ‖(if B'.card + 1 ∈ Kset then (1 : ℂ) else 0)‖
            ≤ ωR B' * 1 := by
              apply mul_le_mul _ (by split_ifs <;> simp) (norm_nonneg _) hω0
              rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (by positivity)]
              exact div_le_self hω0 (by linarith [(Nat.cast_nonneg _ : (0 : ℝ) ≤ (B' ∩ J).card)])
          _ ≤ Aω / ((∏ q ∈ B', q : ℕ) : ℝ) := by
              rw [mul_one, Nat.cast_prod]; exact hωle)
    refine hP.trans (le_of_eq ?_)
    refine sum_congr rfl fun k _ => ?_
    congr 1
  · -- VW part
    have hVsub : ∀ B' ∈ U.powerset.filter (fun B' => ¬ X ≤ ∏ q ∈ B', q),
        B' ∈ (U.filter (fun p => p < X)).powerset := by
      intro B' hB'
      have h := mem_filter.1 hB'
      rw [mem_powerset]
      intro q hq
      rw [mem_filter]
      refine ⟨mem_powerset.1 h.1 hq, ?_⟩
      have hqp := (hU q (mem_powerset.1 h.1 hq)).1
      have hle : q ≤ ∏ q ∈ B', q := Nat.le_of_dvd
        (Finset.prod_pos fun x hx => (hU x (mem_powerset.1 h.1 hx)).1.pos)
        (Finset.dvd_prod_of_mem _ hq)
      push Not at h; omega
    have hV0 : 0 ≤ Vbound := (norm_nonneg _).trans (hVW ∅ (empty_mem_powerset U) (by simp; omega))
    calc _ ≤ ∑ B' ∈ U.powerset.filter (fun B' => ¬ X ≤ ∏ q ∈ B', q), ‖β' B' * G (∏ q ∈ B', q)‖ :=
          norm_sum_le _ _
      _ ≤ ∑ B' ∈ U.powerset.filter (fun B' => ¬ X ≤ ∏ q ∈ B', q), ωR B' * Vbound := by
          refine sum_le_sum fun B' hB' => ?_
          have h := mem_filter.1 hB'
          have hB'U := mem_powerset.1 h.1
          have hω0 := ωR_nonneg B' fun q hq => (hU q (hB'U hq)).2
          rw [norm_mul]
          apply mul_le_mul _ _ (norm_nonneg _) hω0
          · simp only [hβ']
            rw [norm_mul]
            calc _ ≤ ωR B' * 1 := by
                  apply mul_le_mul _ (by split_ifs <;> simp) (norm_nonneg _) hω0
                  rw [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (by positivity)]
                  exact div_le_self hω0 (by linarith [(Nat.cast_nonneg _ : (0 : ℝ) ≤ (B' ∩ J).card)])
              _ = ωR B' := mul_one _
          · exact hVW B' h.1 (by push Not at h; exact h.2)
      _ ≤ ∑ B' ∈ (U.filter (fun p => p < X)).powerset, ωR B' * Vbound :=
          sum_le_sum_of_subset_of_nonneg hVsub fun B' hB' _ =>
            mul_nonneg (ωR_nonneg B' fun q hq => (hU q (mem_filter.1 (mem_powerset.1 hB' hq)).1).2) hV0
      _ = _ := by rw [sum_mul]

end GoldC.QuillonCContext
#print axioms GoldC.QuillonCContext.C_context
