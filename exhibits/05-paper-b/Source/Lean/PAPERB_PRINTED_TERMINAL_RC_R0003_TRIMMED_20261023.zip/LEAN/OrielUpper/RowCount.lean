import OrielUpper.Periodic

/-!
# Oriel Upper — residue-class sums in `[1, N]`

* `oriel_sum_filter_mod`: reparametrise `{u ∈ [1,N] : u % m = u0}` as `u = u0 + m k`.
* `oriel_count_mod_close`: the number of such `k` is within `1` of `N/m`.
* `oriel_periodic_Ico_sum`: periodic partial sums over any `Ico a b`.
-/

open Finset

namespace OrielUpper

/-- Lower index of the reparametrisation. -/
def kLo (u0 : ℕ) : ℕ := if u0 = 0 then 1 else 0

/-- Upper (exclusive) index of the reparametrisation. -/
def kHi (N m u0 : ℕ) : ℕ := (N + m - u0) / m

theorem oriel_sum_filter_mod {m u0 : ℕ} (hm : 0 < m) (hu0 : u0 < m) (N : ℕ) (G : ℕ → ℝ) :
    ∑ u ∈ (Icc 1 N).filter (fun u => u % m = u0), G u =
      ∑ k ∈ Ico (kLo u0) (kHi N m u0), G (u0 + m * k) := by
  symm
  apply Finset.sum_nbij' (fun k => u0 + m * k) (fun u => u / m)
  · intro k hk
    rw [mem_Ico] at hk
    rw [mem_filter, mem_Icc]
    have hk2 : (k + 1) * m ≤ N + m - u0 := by
      have := (Nat.le_div_iff_mul_le hm).mp (Nat.succ_le_of_lt hk.2)
      simpa [kHi] using this
    refine ⟨⟨?_, ?_⟩, ?_⟩
    · unfold kLo at hk
      split_ifs at hk with h0
      · subst h0
        have : 1 ≤ m * k := Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero hm.ne' (by omega))
        omega
      · omega
    · have h3 : (k + 1) * m + u0 ≤ N + m := by
        have := (Nat.le_sub_iff_add_le (by omega : u0 ≤ N + m)).mp hk2
        exact this
      have h4 : (k + 1) * m = k * m + m := Nat.succ_mul k m
      rw [h4] at h3
      have h5 : m * k = k * m := Nat.mul_comm m k
      omega
    · rw [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt hu0]
  · intro u hu
    rw [mem_filter, mem_Icc] at hu
    rw [mem_Ico]
    have hdm := Nat.mod_add_div u m
    rw [hu.2] at hdm
    constructor
    · unfold kLo
      split_ifs with h0
      · subst h0
        by_contra hc
        push_neg at hc
        have : u / m = 0 := Nat.lt_one_iff.mp hc
        rw [this, Nat.mul_zero] at hdm
        omega
      · exact Nat.zero_le _
    · unfold kHi
      apply Nat.lt_of_succ_le
      apply (Nat.le_div_iff_mul_le hm).mpr
      have h1 : m * (u / m) + u0 ≤ N := by omega
      have h2 : (u / m).succ * m = m * (u / m) + m := by rw [Nat.succ_mul, Nat.mul_comm]
      rw [h2]
      omega
  · intro k _
    rw [Nat.add_mul_div_left _ _ hm, Nat.div_eq_of_lt hu0, zero_add]
  · intro u hu
    rw [mem_filter] at hu
    have := Nat.mod_add_div u m
    rw [hu.2] at this
    exact this
  · intro k _; rfl

theorem oriel_count_mod_close {m u0 : ℕ} (hm : 0 < m) (hu0 : u0 < m) (N : ℕ) :
    |((kHi N m u0 - kLo u0 : ℕ) : ℝ) - (N : ℝ) / m| ≤ 1 := by
  have hmr : (0 : ℝ) < m := by exact_mod_cast hm
  set K := kHi N m u0 with hK
  have h1 : K * m ≤ N + m - u0 := Nat.div_mul_le_self _ _
  have h2 : N + m - u0 < K * m + m := by
    have := Nat.lt_div_mul_add (a := N + m - u0) hm
    simpa [hK, kHi] using this
  set t : ℝ := (N : ℝ) / m with ht
  have htm : t * m = N := by rw [ht]; field_simp
  rw [abs_le]
  unfold kLo
  split_ifs with h0
  · subst h0
    have hK1 : 1 ≤ K := by
      by_contra hc; push_neg at hc
      have : K = 0 := Nat.lt_one_iff.mp hc
      rw [this, Nat.zero_mul, Nat.zero_add] at h2
      omega
    have e : ((K - 1 : ℕ) : ℝ) = (K : ℝ) - 1 := by rw [Nat.cast_sub hK1]; simp
    rw [e]
    have r1 : (K : ℝ) * m ≤ N + m := by exact_mod_cast (show K * m ≤ N + m by omega)
    have r2 : (N : ℝ) < K * m := by exact_mod_cast (show N < K * m by omega)
    have a1 : (K : ℝ) ≤ t + 1 := by
      have : (K : ℝ) ≤ (N + m) / m := (le_div_iff₀ hmr).mpr r1
      rw [add_div, div_self hmr.ne'] at this; linarith
    have a2 : t < K := (div_lt_iff₀ hmr).mpr r2
    constructor <;> linarith
  · simp only [Nat.sub_zero]
    have r1 : (K : ℝ) * m ≤ N + m := by exact_mod_cast (show K * m ≤ N + m by omega)
    have r2 : (N : ℝ) < K * m + m := by exact_mod_cast (show N < K * m + m by omega)
    have a1 : (K : ℝ) ≤ t + 1 := by
      have : (K : ℝ) ≤ (N + m) / m := (le_div_iff₀ hmr).mpr r1
      rw [add_div, div_self hmr.ne'] at this; linarith
    have a2 : t < K + 1 := by
      have : (N : ℝ) / m < (K * m + m) / m := div_lt_div_of_pos_right r2 hmr
      rw [add_div, div_self hmr.ne', mul_div_assoc, div_self hmr.ne', mul_one] at this
      linarith
    constructor <;> linarith

/-- Periodic partial sums over a range. -/
theorem oriel_periodic_range_sum {P : ℕ} (hP : 0 < P) {h : ℕ → ℝ}
    (hper : ∀ n, h (n + P) = h n) {M : ℝ} (hM : ∀ n, |h n| ≤ M) (K : ℕ) :
    |∑ k ∈ range K, h k - (∑ z ∈ range P, h z) / P * K| ≤ 2 * P * M := by
  have hPr : (0 : ℝ) < P := by exact_mod_cast hP
  have hM0 : 0 ≤ M := le_trans (abs_nonneg _) (hM 0)
  set S := ∑ z ∈ range P, h z
  obtain ⟨q, ρ, hρ, hK⟩ : ∃ q ρ, ρ < P ∧ K = q * P + ρ :=
    ⟨K / P, K % P, Nat.mod_lt _ hP, by rw [Nat.div_add_mod' K P]⟩
  have hsplit : ∑ k ∈ range K, h k = q * S + ∑ k ∈ Ico (q * P) K, h k := by
    rw [range_eq_Ico, ← sum_Ico_consecutive _ (Nat.zero_le (q * P)) (by omega : q * P ≤ K)]
    have := oriel_sum_Ico_mul_period hper 0 q
    simp only [zero_add] at this
    rw [this]
  have hrem : |∑ k ∈ Ico (q * P) K, h k| ≤ ρ * M := by
    calc |∑ k ∈ Ico (q * P) K, h k| ≤ ∑ k ∈ Ico (q * P) K, |h k| := abs_sum_le_sum_abs _ _
      _ ≤ ∑ k ∈ Ico (q * P) K, M := sum_le_sum (fun k _ => hM k)
      _ = ρ * M := by
          have hc : K - q * P = ρ := by omega
          rw [sum_const, Nat.card_Ico, nsmul_eq_mul, hc]
  have hS : |S| ≤ P * M := by
    calc |S| ≤ ∑ z ∈ range P, |h z| := abs_sum_le_sum_abs _ _
      _ ≤ ∑ z ∈ range P, M := sum_le_sum (fun z _ => hM z)
      _ = P * M := by rw [sum_const, card_range, nsmul_eq_mul]
  have hKr : (K : ℝ) = q * P + ρ := by rw [hK]; push_cast; ring
  have hρr : (ρ : ℝ) ≤ P := by exact_mod_cast hρ.le
  rw [hsplit, hKr]
  have e : (q : ℝ) * S + ∑ k ∈ Ico (q * P) K, h k - S / P * (q * P + ρ) =
      ∑ k ∈ Ico (q * P) K, h k - S / P * ρ := by field_simp; ring
  rw [e]
  have h3 : |S / P * ρ| ≤ M * ρ := by
    rw [abs_mul, abs_div, abs_of_pos hPr, abs_of_nonneg (by positivity : (0 : ℝ) ≤ ρ)]
    have : |S| / P ≤ M := by rw [div_le_iff₀ hPr]; linarith
    exact mul_le_mul_of_nonneg_right this (Nat.cast_nonneg ρ)
  calc |∑ k ∈ Ico (q * P) K, h k - S / P * ρ|
      ≤ |∑ k ∈ Ico (q * P) K, h k| + |S / P * ρ| := abs_sub _ _
    _ ≤ ρ * M + M * ρ := add_le_add hrem h3
    _ ≤ 2 * P * M := by nlinarith

/-- Periodic partial sums over any `Ico a b`. -/
theorem oriel_periodic_Ico_sum {P : ℕ} (hP : 0 < P) {h : ℕ → ℝ}
    (hper : ∀ n, h (n + P) = h n) {M : ℝ} (hM : ∀ n, |h n| ≤ M) {a b : ℕ} (hab : a ≤ b) :
    |∑ k ∈ Ico a b, h k - (∑ z ∈ range P, h z) / P * ((b - a : ℕ) : ℝ)| ≤ 2 * P * M := by
  have hper' : ∀ n, h (a + (n + P)) = h (a + n) := by
    intro n; rw [show a + (n + P) = (a + n) + P by ring]; exact hper _
  have hS : ∑ z ∈ range P, h (a + z) = ∑ z ∈ range P, h z := by
    rw [← oriel_sum_Ico_period hper a, sum_Ico_eq_sum_range]
    simp
  have := oriel_periodic_range_sum hP (h := fun n => h (a + n)) hper' (fun n => hM _) (b - a)
  rw [hS] at this
  rw [sum_Ico_eq_sum_range]
  exact this

end OrielUpper
