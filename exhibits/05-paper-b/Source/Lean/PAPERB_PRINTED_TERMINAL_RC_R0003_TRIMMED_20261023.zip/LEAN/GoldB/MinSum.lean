import GoldB.Basic
import Mathlib.NumberTheory.Harmonic.Bounds

/-!
# GoldB.MinSum

For `0 < β ≤ 1/2`, `L ∈ ℕ`, `U ≥ 0`:
`∑_{|m| ≤ L} min(U, 1/(2‖βm‖)) ≤ (2Lβ + 2) (2U + (1 + log(1/β))/β)`.
-/

open Finset

namespace GoldB

/-- the bound attached to a bucket index -/
noncomputable def hb (U β : ℝ) (i : ℕ) : ℝ := if i = 0 then U else 1 / (2 * i * β)

lemma hb_nonneg {U β : ℝ} (hU : 0 ≤ U) (hβ : 0 < β) (i : ℕ) : 0 ≤ hb U β i := by
  unfold hb; split_ifs <;> positivity

lemma sum_hb (U β : ℝ) (hβ : 0 < β) (I : ℕ) :
    ∑ i ∈ range (I + 1), hb U β i = U + harmonic I / (2 * β) := by
  rw [sum_range_succ']
  simp only [hb, if_pos rfl, Nat.succ_ne_zero, if_false]
  rw [harmonic_eq_sum_Icc, add_comm]
  congr 1
  rw [Rat.cast_sum, sum_div]
  rw [← Finset.Ico_add_one_right_eq_Icc, sum_Ico_eq_sum_range]
  apply sum_congr rfl; intro i _
  push_cast; field_simp; ring

/-- per-fibre bound -/
lemma fibre_bound (U β : ℝ) (hU : 0 ≤ U) (hβ : 0 < β) (hβ2 : β ≤ 1 / 2) (n : ℤ) (F : Finset ℤ)
    (hF : ∀ m ∈ F, round (β * m) = n) :
    ∑ m ∈ F, gmin U (β * m) ≤ 2 * U + (1 + Real.log (1 / β)) / β := by
  classical
  set I := ⌊1 / (2 * β)⌋₊
  let ι : ℤ → ℕ × Bool := fun m => (⌊|β * m - n| / β⌋₊, decide (0 ≤ β * m - n))
  have hd : ∀ m ∈ F, |β * m - n| ≤ 1 / 2 := by
    intro m hm; have := abs_sub_round (β * m); rwa [hF m hm] at this
  have hdz : ∀ m ∈ F, dz (β * m) = |β * m - n| := by
    intro m hm; unfold dz; rw [hF m hm]
  have hinj : Set.InjOn ι F := by
    intro m hm m' hm' he
    simp only [ι, Prod.mk.injEq] at he
    obtain ⟨h1, h2⟩ := he
    have hm1 := Nat.floor_le (div_nonneg (abs_nonneg (β * m - n)) hβ.le)
    have hm2 := Nat.lt_floor_add_one (|β * m - n| / β)
    have hm1' := Nat.floor_le (div_nonneg (abs_nonneg (β * m' - n)) hβ.le)
    have hm2' := Nat.lt_floor_add_one (|β * m' - n| / β)
    rw [h1] at hm1 hm2
    have hlt : |(|β * m - n| / β) - (|β * m' - n| / β)| < 1 := by
      rw [abs_lt]; constructor <;> linarith
    have hsgn : (0 ≤ β * m - n) ↔ (0 ≤ β * m' - n) := by
      simpa using h2
    have hdiff : |(β * m - n) - (β * m' - n)| < β := by
      have : |(|β * m - n| - |β * m' - n|)| < β := by
        rw [← sub_div, abs_div, abs_of_pos hβ, div_lt_one hβ] at hlt; exact hlt
      by_cases hs : 0 ≤ β * m - n
      · have hs' := hsgn.mp hs
        rwa [abs_of_nonneg hs, abs_of_nonneg hs'] at this
      · have hs' : ¬ (0 ≤ β * m' - n) := fun h => hs (hsgn.mpr h)
        push_neg at hs hs'
        rw [abs_of_neg hs, abs_of_neg hs'] at this
        rw [show (β * m - n) - (β * m' - n) = -(-(β * m - n) - -(β * m' - n)) by ring, abs_neg]
        exact this
    have : |(m : ℝ) - m'| < 1 := by
      rw [show (β * m - n) - (β * m' - n) = β * ((m : ℝ) - m') by ring, abs_mul,
        abs_of_pos hβ] at hdiff
      nlinarith [abs_nonneg ((m : ℝ) - m')]
    have : |m - m'| < 1 := by exact_mod_cast this
    rw [abs_lt] at this
    omega
  have hbound : ∀ m ∈ F, gmin U (β * m) ≤ hb U β (ι m).1 := by
    intro m hm
    simp only [ι, hb]
    split_ifs with h0
    · exact gmin_le_U U _
    · have hi : (1 : ℝ) ≤ ⌊|β * m - n| / β⌋₊ := by exact_mod_cast Nat.one_le_iff_ne_zero.mpr h0
      have hfl := Nat.floor_le (div_nonneg (abs_nonneg (β * m - n)) hβ.le)
      have hge : (⌊|β * m - n| / β⌋₊ : ℝ) * β ≤ |β * m - n| := by
        rwa [le_div_iff₀ hβ] at hfl
      have hpos : 0 < dz (β * m) := by rw [hdz m hm]; nlinarith
      unfold gmin
      rw [if_neg hpos.ne']
      refine (min_le_right _ _).trans ?_
      rw [hdz m hm]
      apply one_div_le_one_div_of_le (by positivity)
      nlinarith
  have hrange : ∀ m ∈ F, ι m ∈ range (I + 1) ×ˢ (univ : Finset Bool) := by
    intro m hm
    simp only [ι, mem_product, mem_range, mem_univ, and_true]
    apply Nat.lt_succ_of_le
    apply Nat.floor_le_floor
    rw [div_le_div_iff₀ hβ (by positivity)]
    nlinarith [hd m hm]
  calc ∑ m ∈ F, gmin U (β * m) ≤ ∑ m ∈ F, hb U β (ι m).1 := sum_le_sum hbound
    _ = ∑ t ∈ F.image ι, hb U β t.1 := (sum_image (f := fun t => hb U β t.1) hinj).symm
    _ ≤ ∑ t ∈ range (I + 1) ×ˢ (univ : Finset Bool), hb U β t.1 := by
        apply sum_le_sum_of_subset_of_nonneg
        · intro t ht; obtain ⟨m, hm, rfl⟩ := mem_image.mp ht; exact hrange m hm
        · intro t _ _; exact hb_nonneg hU hβ _
    _ = 2 * ∑ i ∈ range (I + 1), hb U β i := by
        rw [sum_product]; simp [mul_comm]
        rw [← Finset.sum_mul, mul_comm]
    _ = 2 * U + harmonic I / β := by
        rw [sum_hb U β hβ I]; field_simp
    _ ≤ 2 * U + (1 + Real.log (1 / β)) / β := by
        gcongr
        refine (harmonic_le_one_add_log I).trans ?_
        suffices hlog : Real.log ↑I ≤ Real.log (1 / β) by linarith
        rcases Nat.eq_zero_or_pos I with h0 | hpos
        · rw [h0, Nat.cast_zero, Real.log_zero]
          apply Real.log_nonneg; rw [le_div_iff₀ hβ]; linarith
        · apply Real.log_le_log (by exact_mod_cast hpos : (0 : ℝ) < I)
          calc (I : ℝ) ≤ 1 / (2 * β) := Nat.floor_le (by positivity)
            _ ≤ 1 / β := by
                apply one_div_le_one_div_of_le hβ; linarith

theorem min_sum (U β : ℝ) (hU : 0 ≤ U) (hβ : 0 < β) (hβ2 : β ≤ 1 / 2) (L : ℕ) :
    ∑ m ∈ Icc (-(L : ℤ)) L, gmin U (β * m) ≤
      (2 * L * β + 2) * (2 * U + (1 + Real.log (1 / β)) / β) := by
  classical
  set R := Icc (-(L : ℤ)) L
  set K : ℤ := ⌊(L : ℝ) * β + 1 / 2⌋
  have himg : R.image (fun m : ℤ => round (β * (m : ℝ))) ⊆ Icc (-K) K := by
    intro n hn
    obtain ⟨m, hm, rfl⟩ := mem_image.mp hn
    rw [mem_Icc] at hm ⊢
    have h1 := abs_sub_round (β * (m : ℝ))
    have hmL : |(m : ℝ)| ≤ L := by
      rw [abs_le]; constructor <;> exact_mod_cast (by omega : _)
    have hbm : |β * (m : ℝ)| ≤ L * β := by
      rw [abs_mul, abs_of_pos hβ]; nlinarith [abs_nonneg (m : ℝ)]
    have hr : |(round (β * (m : ℝ)) : ℝ)| ≤ L * β + 1 / 2 := by
      have := abs_sub_abs_le_abs_sub (round (β * (m : ℝ)) : ℝ) (β * m)
      rw [abs_sub_comm] at h1
      linarith
    rw [abs_le] at hr
    constructor
    · have : (-(L : ℝ) * β - 1 / 2) ≤ (round (β * (m : ℝ)) : ℝ) := by linarith
      have h2 : -K ≤ round (β * (m : ℝ)) := by
        rw [neg_le]
        apply Int.le_floor.mpr
        push_cast; linarith
      exact h2
    · exact Int.le_floor.mpr (by push_cast; linarith)
  have hcard : ((R.image fun m : ℤ => round (β * (m : ℝ))).card : ℝ) ≤ 2 * L * β + 2 := by
    have h1 := card_le_card himg
    have hK0 : 0 ≤ K := Int.floor_nonneg.mpr (by positivity)
    have h2 : ((Icc (-K) K).card : ℝ) = 2 * K + 1 := by
      rw [Int.card_Icc]
      have : (K + 1 - -K).toNat = (2 * K + 1).toNat := by ring_nf
      rw [this]
      have e : (((2 * K + 1).toNat : ℕ) : ℝ) = ((2 * K + 1 : ℤ) : ℝ) := by
        exact_mod_cast Int.toNat_of_nonneg (by omega : (0 : ℤ) ≤ 2 * K + 1)
      rw [e]; push_cast; ring
    have hK : (K : ℝ) ≤ L * β + 1 / 2 := Int.floor_le _
    calc ((R.image fun m : ℤ => round (β * (m : ℝ))).card : ℝ) ≤ ((Icc (-K) K).card : ℝ) := by
          exact_mod_cast h1
      _ = 2 * K + 1 := h2
      _ ≤ 2 * L * β + 2 := by linarith
  rw [← sum_fiberwise_of_maps_to (g := fun m : ℤ => round (β * (m : ℝ)))
    (t := R.image fun m : ℤ => round (β * (m : ℝ))) (fun m hm => mem_image_of_mem _ hm)]
  calc ∑ n ∈ R.image (fun m : ℤ => round (β * (m : ℝ))),
        ∑ m ∈ R.filter (fun m : ℤ => round (β * (m : ℝ)) = n), gmin U (β * m)
      ≤ ∑ _n ∈ R.image (fun m : ℤ => round (β * (m : ℝ))),
          (2 * U + (1 + Real.log (1 / β)) / β) := by
        apply sum_le_sum; intro n _
        exact fibre_bound U β hU hβ hβ2 n _ (fun m hm => (mem_filter.mp hm).2)
    _ = ((R.image fun m : ℤ => round (β * (m : ℝ))).card : ℝ) *
          (2 * U + (1 + Real.log (1 / β)) / β) := by rw [sum_const, nsmul_eq_mul]
    _ ≤ (2 * L * β + 2) * (2 * U + (1 + Real.log (1 / β)) / β) := by
        apply mul_le_mul_of_nonneg_right hcard
        have : 0 ≤ Real.log (1 / β) := Real.log_nonneg (by rw [le_div_iff₀ hβ]; linarith)
        positivity

end GoldB
