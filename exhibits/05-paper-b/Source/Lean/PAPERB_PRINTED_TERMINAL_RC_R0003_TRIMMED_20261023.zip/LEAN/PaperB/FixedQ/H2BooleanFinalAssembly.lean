import PaperB.FixedQ.H2PeriodicTwistCoherence
import PaperB.FixedQ.H2BooleanCauchy
import PaperB.FixedQ.H2BooleanDyadicSecondMomentAssembly
import PaperB.FixedQ.H2BooleanRateNormalization
import PaperB.FixedQ.H2EndpointDyadic

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def h2BooleanOrdinaryDyadicSets
    (q H M : ℕ) : Finset (Finset ℕ) := by
  classical
  exact (h2BooleanDyadicSets q M).filter
    (fun S => S ∈ ordinaryTwoDimensionalSet H)

lemma h2BooleanOrdinaryDyadicSets_mem
    {q H M : ℕ} {S : Finset ℕ}
    (hS : S ∈ h2BooleanOrdinaryDyadicSets q H M) :
    S ∈ h2BooleanDyadicSets q M ∧
      S ∈ ordinaryTwoDimensionalSet H := by
  classical
  unfold h2BooleanOrdinaryDyadicSets at hS
  exact Finset.mem_filter.mp hS

theorem h2BooleanOrdinaryDyadicWeightedDiscrepancyL2_le_ET
    {q A H M J : ℕ}
    (hq : 0 < q)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ H)
    (hJ : 1 ≤ J) :
    (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
        |fixedProductBooleanDiscrepancy
          (fixedQLowWeight q A H) H S| ^ 2) ≤
      (6 * (fixedQPeriod q : ℝ)) ^ 2 *
        ((32 / ((J : ℝ) ^ 2)) *
          (∑ S ∈ h2BooleanDyadicSets q M,
            finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) +
        32 * (1 + Real.log (J : ℝ)) *
          (∑ j ∈ Finset.Icc 1 J,
            h2BooleanDyadicFrequencySecondMomentTwisted q M j
              (fixedQPeriodicTotalTwist q H) / (j : ℝ))) := by
  let F := h2BooleanOrdinaryDyadicSets q H M
  let G := h2BooleanDyadicSets q M
  let C : ℝ := (6 * (fixedQPeriod q : ℝ)) ^ 2
  let a0 : ℝ := 32 / ((J : ℝ) ^ 2)
  let b0 : ℝ := 32 * (1 + Real.log (J : ℝ))
  let Q : Finset ℕ → ℝ := fun S =>
    ∑ j ∈ Finset.Icc 1 J,
      h2BooleanFourierNormSqTwisted q S j
        (fixedQPeriodicTotalTwist q H S) / (j : ℝ)
  have hpoint : ∀ S ∈ F,
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
          |fixedProductBooleanDiscrepancy
            (fixedQLowWeight q A H) H S| ^ 2
        ≤
      (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) *
        (C * (a0 + b0 * Q S)) := by
    intro S hSF
    have hm := h2BooleanOrdinaryDyadicSets_mem hSF
    have hActive := h2BooleanDyadicSets_active hm.1
    have hPrime : ∀ p ∈ S, p.Prime := fun p hp => (hActive p hp).1
    have hD :=
      fixedProductBooleanDiscrepancy_eq_fixedQWeightedBooleanIntervalDiscrepancy
        (q := q) (a := A) (H := H) (S := S) hPrime
    have hET :=
      fixedQWeightedBooleanIntervalDiscrepancy_erdosTuran_sq
        (q := q) (a := A) (H := H) (S := S)
        hq hActive hm.2 h2admissible J hJ
    have htw :=
      fixedQPeriodicTotalTwist_eq_periodic
        (q := q) (H := H) hActive hm.2
    have hfreq :
        (∑ j ∈ Finset.Icc 1 J,
          ‖fixedProductBooleanFourierCoeff S hPrime
            ((j : ZMod (primeSetProduct S)) *
              ((fixedProductBooleanPeriodicTwist
                (fixedQPeriod q) H S
                (activePrimeSetProduct_coprime_fixedQPeriod hActive).symm
                ((ordinary_primeSetProduct_coprime_height_iff hPrime).mp hm.2).symm :
                  (ZMod (primeSetProduct S))ˣ) :
                ZMod (primeSetProduct S)))‖ ^ 2 / (j : ℝ)) =
          Q S := by
      unfold Q
      apply Finset.sum_congr rfl
      intro j hj
      unfold h2BooleanFourierNormSqTwisted
      rw [dif_pos hActive]
      rw [htw]
    have hET' :
        |fixedProductBooleanDiscrepancy
            (fixedQLowWeight q A H) H S| ^ 2 ≤
          C * (a0 + b0 * Q S) := by
      rw [hD]
      rw [hfreq] at hET
      simpa [C, a0, b0] using hET
    have hw0 :
        0 ≤ finiteOmegaWeightReal S * h2BooleanV0 ^ S.card :=
      mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hActive)
        (pow_nonneg h2BooleanV0_nonneg _)
    exact mul_le_mul_of_nonneg_left hET' hw0
  have hsumPoint :
      (∑ S ∈ F,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
          |fixedProductBooleanDiscrepancy
            (fixedQLowWeight q A H) H S| ^ 2) ≤
      ∑ S ∈ F,
        (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) *
          (C * (a0 + b0 * Q S)) := by
    apply Finset.sum_le_sum
    intro S hS
    exact hpoint S hS
  have hsub : F ⊆ G := by
    intro S hS
    exact (h2BooleanOrdinaryDyadicSets_mem hS).1
  have hconst :
      (∑ S ∈ F,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) ≤
      ∑ S ∈ G,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card := by
    apply Finset.sum_le_sum_of_subset_of_nonneg hsub
    intro S hSG hnot
    have hActive := h2BooleanDyadicSets_active hSG
    exact mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hActive)
      (pow_nonneg h2BooleanV0_nonneg _)
  have hfreqsum :
      (∑ S ∈ F,
        (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) * Q S) ≤
      ∑ j ∈ Finset.Icc 1 J,
        h2BooleanDyadicFrequencySecondMomentTwisted q M j
          (fixedQPeriodicTotalTwist q H) / (j : ℝ) := by
    calc
      (∑ S ∈ F,
        (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) * Q S)
        = ∑ j ∈ Finset.Icc 1 J, ∑ S ∈ F,
            (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
              h2BooleanFourierNormSqTwisted q S j
                (fixedQPeriodicTotalTwist q H S)) / (j : ℝ) := by
          unfold Q
          rw [Finset.sum_comm]
          apply Finset.sum_congr rfl
          intro S hSF
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro j hj
          ring
      _ ≤ ∑ j ∈ Finset.Icc 1 J, ∑ S ∈ G,
            (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
              h2BooleanFourierNormSqTwisted q S j
                (fixedQPeriodicTotalTwist q H S)) / (j : ℝ) := by
          apply Finset.sum_le_sum
          intro j hj
          apply Finset.sum_le_sum_of_subset_of_nonneg hsub
          intro S hSG hnot
          have hActive := h2BooleanDyadicSets_active hSG
          exact div_nonneg
            (mul_nonneg
              (mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hActive)
                (pow_nonneg h2BooleanV0_nonneg _))
              (h2BooleanFourierNormSqTwisted_nonneg q S j
                (fixedQPeriodicTotalTwist q H S)))
            (by positivity)
      _ = _ := by
          apply Finset.sum_congr rfl
          intro j hj
          rw [← Finset.sum_div]
          unfold h2BooleanDyadicFrequencySecondMomentTwisted
          rfl
  have hlogJ0 : 0 ≤ 1 + Real.log (J : ℝ) := by
    have hJR : (1 : ℝ) ≤ (J : ℝ) := by exact_mod_cast hJ
    exact add_nonneg (by norm_num) (Real.log_nonneg hJR)
  calc
    (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
        |fixedProductBooleanDiscrepancy
          (fixedQLowWeight q A H) H S| ^ 2)
      ≤ ∑ S ∈ F,
        (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) *
          (C * (a0 + b0 * Q S)) := hsumPoint
    _ = C * (a0 * (∑ S ∈ F,
          finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) +
        b0 * (∑ S ∈ F,
          (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) * Q S)) := by
      calc
        (∑ S ∈ F,
          (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) *
            (C * (a0 + b0 * Q S))) =
            (∑ S ∈ F,
              (C * a0) *
                (finiteOmegaWeightReal S * h2BooleanV0 ^ S.card)) +
            (∑ S ∈ F,
              (C * b0) *
                ((finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) * Q S)) := by
              rw [← Finset.sum_add_distrib]
              apply Finset.sum_congr rfl
              intro S hS
              ring
        _ = _ := by
              rw [← Finset.mul_sum, ← Finset.mul_sum]
              ring
    _ ≤ C * (a0 * (∑ S ∈ G,
          finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) +
        b0 * (∑ j ∈ Finset.Icc 1 J,
          h2BooleanDyadicFrequencySecondMomentTwisted q M j
            (fixedQPeriodicTotalTwist q H) / (j : ℝ))) := by
      have hC0 : 0 ≤ C := by dsimp [C]; positivity
      have ha0 : 0 ≤ a0 := by dsimp [a0]; positivity
      have hb0 : 0 ≤ b0 := by dsimp [b0]; positivity
      gcongr
    _ = _ := by
      rfl

#print axioms h2BooleanOrdinaryDyadicWeightedDiscrepancyL2_le_ET

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem h2BooleanOrdinaryDyadicWeightedDiscrepancyL2_le_majorants
    (q : ℕ) (hq : 0 < q) :
    ∃ M0 : ℕ, ∀ A H M J : ℕ,
      (¬ 2 ∣ q → 2 ∣ H) →
      1 ≤ J →
      M0 ≤ M →
      2 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      3 ≤ Nat.nthRoot 4 M →
      (h2BooleanRoughCutoff M) ^ 2 ≤ M →
      ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
      ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
      1 ≤ Real.log (M : ℝ) →
      h2BooleanTailCorrectionConst ≤
        (1 / 8 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) →
      (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
          |fixedProductBooleanDiscrepancy
            (fixedQLowWeight q A H) H S| ^ 2) ≤
        (6 * (fixedQPeriod q : ℝ)) ^ 2 *
          ((32 / ((J : ℝ) ^ 2)) *
            (∑ S ∈ h2BooleanDyadicSets q M,
              finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) +
          32 * (1 + Real.log (J : ℝ)) *
            (∑ j ∈ Finset.Icc 1 J,
              h2BooleanFrequencySecondMomentMajorantAll q M j /
                (j : ℝ))) := by
  rcases h2BooleanDyadicFrequencySecondMomentTwisted_le_quantitative_all q hq with
    ⟨M0, hMoment⟩
  refine ⟨M0, ?_⟩
  intro A H M J h2admissible hJ hM0 hM hY4 hroot hYsq hquarter hk hlog hC
  have hET :=
    h2BooleanOrdinaryDyadicWeightedDiscrepancyL2_le_ET
      (q := q) (A := A) (H := H) (M := M) (J := J)
      hq h2admissible hJ
  have hsum :
      (∑ j ∈ Finset.Icc 1 J,
        h2BooleanDyadicFrequencySecondMomentTwisted q M j
          (fixedQPeriodicTotalTwist q H) / (j : ℝ)) ≤
      ∑ j ∈ Finset.Icc 1 J,
        h2BooleanFrequencySecondMomentMajorantAll q M j / (j : ℝ) := by
    apply Finset.sum_le_sum
    intro j hj
    have hj1 : 1 ≤ j := (Finset.mem_Icc.mp hj).1
    have hmom :=
      hMoment M j (fixedQPeriodicTotalTwist q H)
        (fixedQPeriodicTotalTwist_familyCompatible
          q H (h2BooleanRoughCutoff M) M j)
        hM0 hM hY4 hj1 hroot hYsq hquarter hk hlog hC
    exact div_le_div_of_nonneg_right hmom (by positivity)
  have hlogJ0 : 0 ≤ 1 + Real.log (J : ℝ) := by
    have hJR : (1 : ℝ) ≤ (J : ℝ) := by exact_mod_cast hJ
    exact add_nonneg (by norm_num) (Real.log_nonneg hJR)
  calc
    (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
      finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
        |fixedProductBooleanDiscrepancy
          (fixedQLowWeight q A H) H S| ^ 2)
      ≤ (6 * (fixedQPeriod q : ℝ)) ^ 2 *
          ((32 / ((J : ℝ) ^ 2)) *
            (∑ S ∈ h2BooleanDyadicSets q M,
              finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) +
          32 * (1 + Real.log (J : ℝ)) *
            (∑ j ∈ Finset.Icc 1 J,
              h2BooleanDyadicFrequencySecondMomentTwisted q M j
                (fixedQPeriodicTotalTwist q H) / (j : ℝ))) := hET
    _ ≤ (6 * (fixedQPeriod q : ℝ)) ^ 2 *
          ((32 / ((J : ℝ) ^ 2)) *
            (∑ S ∈ h2BooleanDyadicSets q M,
              finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) +
          32 * (1 + Real.log (J : ℝ)) *
            (∑ j ∈ Finset.Icc 1 J,
              h2BooleanFrequencySecondMomentMajorantAll q M j /
                (j : ℝ))) := by
      gcongr

#print axioms h2BooleanOrdinaryDyadicWeightedDiscrepancyL2_le_majorants

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem h2BooleanOrdinaryDyadicFullShell_cauchy_sq
    {q A H M : ℕ} :
    (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
      finiteOmegaWeightReal S * (2 : ℝ) ^ S.card *
        |fixedProductBooleanDiscrepancy
          (fixedQLowWeight q A H) H S|) ^ 2 ≤
      (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
        finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) *
      (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
          |fixedProductBooleanDiscrepancy
            (fixedQLowWeight q A H) H S| ^ 2) := by
  apply ordinaryBooleanWeightedCauchy_source_tilts
  intro S hS
  have hm := h2BooleanOrdinaryDyadicSets_mem hS
  have hA := h2BooleanDyadicSets_active hm.1
  exact finiteOmegaWeightReal_nonneg_of_active hA

theorem h2BooleanOrdinaryDyadicFullShell_sq_le_majorants
    (q : ℕ) (hq : 0 < q) :
    ∃ M0 : ℕ, ∀ A H M J : ℕ,
      (¬ 2 ∣ q → 2 ∣ H) →
      1 ≤ J →
      M0 ≤ M →
      2 ≤ M →
      4 ≤ h2BooleanRoughCutoff M →
      3 ≤ Nat.nthRoot 4 M →
      (h2BooleanRoughCutoff M) ^ 2 ≤ M →
      ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
      ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
      1 ≤ Real.log (M : ℝ) →
      h2BooleanTailCorrectionConst ≤
        (1 / 8 : ℝ) *
          (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) →
      (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
        finiteOmegaWeightReal S * (2 : ℝ) ^ S.card *
          |fixedProductBooleanDiscrepancy
            (fixedQLowWeight q A H) H S|) ^ 2 ≤
        (∑ S ∈ h2BooleanDyadicSets q M,
          finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) *
        ((6 * (fixedQPeriod q : ℝ)) ^ 2 *
          ((32 / ((J : ℝ) ^ 2)) *
            (∑ S ∈ h2BooleanDyadicSets q M,
              finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) +
          32 * (1 + Real.log (J : ℝ)) *
            (∑ j ∈ Finset.Icc 1 J,
              h2BooleanFrequencySecondMomentMajorantAll q M j /
                (j : ℝ)))) := by
  rcases h2BooleanOrdinaryDyadicWeightedDiscrepancyL2_le_majorants q hq with
    ⟨M0, hL2⟩
  refine ⟨M0, ?_⟩
  intro A H M J h2admissible hJ hM0 hM hY4 hroot hYsq hquarter hk hlog hC
  let F := h2BooleanOrdinaryDyadicSets q H M
  let G := h2BooleanDyadicSets q M
  let D : Finset ℕ → ℝ :=
    fun S => fixedProductBooleanDiscrepancy (fixedQLowWeight q A H) H S
  let R : ℝ :=
    (6 * (fixedQPeriod q : ℝ)) ^ 2 *
      ((32 / ((J : ℝ) ^ 2)) *
        (∑ S ∈ G,
          finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) +
      32 * (1 + Real.log (J : ℝ)) *
        (∑ j ∈ Finset.Icc 1 J,
          h2BooleanFrequencySecondMomentMajorantAll q M j / (j : ℝ)))
  have hCauchy :=
    h2BooleanOrdinaryDyadicFullShell_cauchy_sq
      (q := q) (A := A) (H := H) (M := M)
  have hL2' :
      (∑ S ∈ F,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
          |D S| ^ 2) ≤ R := by
    simpa [F, G, D, R] using
      hL2 A H M J h2admissible hJ hM0 hM hY4 hroot hYsq
        hquarter hk hlog hC
  have hsub : F ⊆ G := by
    intro S hS
    exact (h2BooleanOrdinaryDyadicSets_mem hS).1
  have hFirst :
      (∑ S ∈ F,
        finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) ≤
      ∑ S ∈ G,
        finiteOmegaWeightReal S * h2BooleanX0 ^ S.card := by
    apply Finset.sum_le_sum_of_subset_of_nonneg hsub
    intro S hSG hnot
    have hActive := h2BooleanDyadicSets_active hSG
    exact mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hActive)
      (pow_nonneg h2BooleanX0_nonneg _)
  have hFirst0 :
      0 ≤ ∑ S ∈ F,
        finiteOmegaWeightReal S * h2BooleanX0 ^ S.card := by
    apply Finset.sum_nonneg
    intro S hSF
    have hm := h2BooleanOrdinaryDyadicSets_mem hSF
    have hActive := h2BooleanDyadicSets_active hm.1
    exact mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hActive)
      (pow_nonneg h2BooleanX0_nonneg _)
  have hFirstG0 :
      0 ≤ ∑ S ∈ G,
        finiteOmegaWeightReal S * h2BooleanX0 ^ S.card := by
    apply Finset.sum_nonneg
    intro S hSG
    have hActive := h2BooleanDyadicSets_active hSG
    exact mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hActive)
      (pow_nonneg h2BooleanX0_nonneg _)
  have hL20 :
      0 ≤ ∑ S ∈ F,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
          |D S| ^ 2 := by
    apply Finset.sum_nonneg
    intro S hSF
    have hm := h2BooleanOrdinaryDyadicSets_mem hSF
    have hActive := h2BooleanDyadicSets_active hm.1
    exact mul_nonneg
      (mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hActive)
        (pow_nonneg h2BooleanV0_nonneg _))
      (sq_nonneg _)
  have hR0 : 0 ≤ R := hL20.trans hL2'
  calc
    (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
      finiteOmegaWeightReal S * (2 : ℝ) ^ S.card *
        |fixedProductBooleanDiscrepancy
          (fixedQLowWeight q A H) H S|) ^ 2
      ≤ (∑ S ∈ F,
          finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) *
        (∑ S ∈ F,
          finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
            |D S| ^ 2) := by
        simpa [F, D] using hCauchy
    _ ≤ (∑ S ∈ G,
          finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) * R := by
        exact mul_le_mul hFirst hL2' hL20 hFirstG0
    _ = _ := by
        rfl

#print axioms h2BooleanOrdinaryDyadicFullShell_cauchy_sq
#print axioms h2BooleanOrdinaryDyadicFullShell_sq_le_majorants

end PaperB.FixedQ


namespace PaperB.FixedQ

noncomputable def h2BooleanETCutoff (M : ℕ) : ℕ :=
  ⌊Real.log (M : ℝ)⌋₊

lemma h2BooleanETCutoff_one_le
    {M : ℕ} (hlog : 1 ≤ Real.log (M : ℝ)) :
    1 ≤ h2BooleanETCutoff M := by
  unfold h2BooleanETCutoff
  exact (Nat.one_le_floor_iff _).2 hlog

lemma h2BooleanETCutoff_cast_le_log
    {M : ℕ} (hlog0 : 0 ≤ Real.log (M : ℝ)) :
    (h2BooleanETCutoff M : ℝ) ≤ Real.log (M : ℝ) := by
  unfold h2BooleanETCutoff
  exact Nat.floor_le hlog0

lemma h2BooleanETCutoff_half_log_le
    {M : ℕ} (hlog2 : 2 ≤ Real.log (M : ℝ)) :
    Real.log (M : ℝ) / 2 ≤ (h2BooleanETCutoff M : ℝ) := by
  unfold h2BooleanETCutoff
  have hsub : Real.log (M : ℝ) - 1 < (⌊Real.log (M : ℝ)⌋₊ : ℝ) := by
    exact_mod_cast Nat.sub_one_lt_floor (Real.log (M : ℝ))
  linarith

lemma h2BooleanETCutoff_log_le_loglog
    {M : ℕ}
    (hlog : 1 ≤ Real.log (M : ℝ)) :
    Real.log (h2BooleanETCutoff M : ℝ) ≤
      Real.log (Real.log (M : ℝ)) := by
  have hJ1 := h2BooleanETCutoff_one_le hlog
  have hJpos : (0 : ℝ) < h2BooleanETCutoff M := by
    exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hJ1)
  have hLpos : 0 < Real.log (M : ℝ) := lt_of_lt_of_le zero_lt_one hlog
  exact Real.strictMonoOn_log.monotoneOn hJpos hLpos
    (h2BooleanETCutoff_cast_le_log (le_trans (by norm_num) hlog))

lemma h2BooleanETCutoff_one_add_log_le_two_loglog
    {M : ℕ}
    (hlog : 1 ≤ Real.log (M : ℝ))
    (hll : 1 ≤ Real.log (Real.log (M : ℝ))) :
    1 + Real.log (h2BooleanETCutoff M : ℝ) ≤
      2 * Real.log (Real.log (M : ℝ)) := by
  have hcut := h2BooleanETCutoff_log_le_loglog hlog
  linarith

lemma h2BooleanX0_one_le_public : 1 ≤ h2BooleanX0 := by
  unfold h2BooleanX0 h2BooleanA0
  have hnon : 0 ≤ (101 / 200 : ℝ) := by norm_num
  have hs0 : 0 ≤ Real.sqrt (101 / 200 : ℝ) := Real.sqrt_nonneg _
  have hs2 : (Real.sqrt (101 / 200 : ℝ)) ^ 2 = (101 / 200 : ℝ) :=
    Real.sq_sqrt hnon
  nlinarith

lemma h2BooleanV0_sub_one_nonneg : 0 ≤ h2BooleanV0 - 1 := by
  have hvpos : 0 < h2BooleanV0 := by
    unfold h2BooleanV0
    exact div_pos (by norm_num) (Real.sqrt_pos.2 h2BooleanA0_pos)
  have hv3 := h2BooleanV0_le_three
  unfold h2BooleanV0 h2BooleanA0 at hvpos ⊢
  have hnon : 0 ≤ (101 / 200 : ℝ) := by norm_num
  have hs0 : 0 ≤ Real.sqrt (101 / 200 : ℝ) := Real.sqrt_nonneg _
  have hs2 : (Real.sqrt (101 / 200 : ℝ)) ^ 2 = (101 / 200 : ℝ) :=
    Real.sq_sqrt hnon
  have hspos : 0 < Real.sqrt (101 / 200 : ℝ) := Real.sqrt_pos.2 (by norm_num)
  field_simp [hspos.ne']
  nlinarith

lemma h2BooleanV0_half_add_two_le_four :
    h2BooleanV0 / 2 + 2 ≤ 4 := by
  linarith [h2BooleanV0_le_three]

lemma h2BooleanET_loglog_power_le_four
    {M : ℕ}
    (hlog : 1 ≤ Real.log (M : ℝ))
    (hll : 1 ≤ Real.log (Real.log (M : ℝ))) :
    (1 + Real.log (h2BooleanETCutoff M : ℝ)) ^
        (h2BooleanV0 / 2 + 2) ≤
      (2 : ℝ) ^ (h2BooleanV0 / 2 + 2) *
        (Real.log (Real.log (M : ℝ))) ^ (4 : ℝ) := by
  let L := Real.log (Real.log (M : ℝ))
  have hL0 : 0 ≤ L := le_trans (by norm_num) hll
  have hleft0 :
      0 ≤ 1 + Real.log (h2BooleanETCutoff M : ℝ) := by
    have hJ1 := h2BooleanETCutoff_one_le hlog
    have hJ1R : (1 : ℝ) ≤ (h2BooleanETCutoff M : ℝ) := by
      exact_mod_cast hJ1
    have hlogJ0 := Real.log_nonneg hJ1R
    linarith
  have hbase := h2BooleanETCutoff_one_add_log_le_two_loglog hlog hll
  have hexp0 : 0 ≤ h2BooleanV0 / 2 + 2 := by
    have := h2BooleanV0_nonneg
    linarith
  calc
    (1 + Real.log (h2BooleanETCutoff M : ℝ)) ^
        (h2BooleanV0 / 2 + 2)
      ≤ (2 * L) ^ (h2BooleanV0 / 2 + 2) :=
        Real.rpow_le_rpow hleft0 hbase hexp0
    _ = (2 : ℝ) ^ (h2BooleanV0 / 2 + 2) *
        L ^ (h2BooleanV0 / 2 + 2) := by
          rw [Real.mul_rpow (by norm_num) hL0]
    _ ≤ (2 : ℝ) ^ (h2BooleanV0 / 2 + 2) * L ^ (4 : ℝ) := by
          apply mul_le_mul_of_nonneg_left
          · exact Real.rpow_le_rpow_of_exponent_le hll
              h2BooleanV0_half_add_two_le_four
          · positivity
    _ = _ := by rfl

#print axioms h2BooleanETCutoff_one_le
#print axioms h2BooleanETCutoff_half_log_le
#print axioms h2BooleanETCutoff_log_le_loglog
#print axioms h2BooleanET_loglog_power_le_four

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma h2Boolean_log_two_mul_le_two_log_public
    {M : ℕ} (hM : 2 ≤ M) :
    Real.log ((2 * M : ℕ) : ℝ) ≤ 2 * Real.log (M : ℝ) := by
  have hnat : 2 * M ≤ M ^ 2 := by nlinarith
  have hpos1 : (0 : ℝ) < ((2 * M : ℕ) : ℝ) := by positivity
  have hpos2 : (0 : ℝ) < ((M ^ 2 : ℕ) : ℝ) := by positivity
  have hcast : (((2 * M : ℕ) : ℝ)) ≤ (((M ^ 2 : ℕ) : ℝ)) := by
    exact_mod_cast hnat
  have hlog := Real.strictMonoOn_log.monotoneOn hpos1 hpos2 hcast
  calc
    Real.log ((2 * M : ℕ) : ℝ) ≤ Real.log (((M ^ 2 : ℕ) : ℝ)) := hlog
    _ = Real.log ((M : ℝ) ^ 2) := by norm_num
    _ = 2 * Real.log (M : ℝ) := by rw [Real.log_pow]; norm_num

theorem h2BooleanDyadicSecondWeightMoment_le_log_rate
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ M0 : ℕ,
      0 ≤ C ∧
      ∀ M : ℕ,
        M0 ≤ M →
        2 ≤ M →
        ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
        ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
        1 ≤ Real.log (M : ℝ) →
        (∑ S ∈ h2BooleanDyadicSets q M,
          finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) ≤
          C * (Real.log (M : ℝ)) ^ (h2BooleanV0 - 1) := by
  rcases h2BooleanSecondTilt_interval_log_power q hq with ⟨C0, M0, hI⟩
  let C : ℝ := |C0| * (2 : ℝ) ^ (h2BooleanV0 - 1)
  refine ⟨C, M0, ?_, ?_⟩
  · dsimp [C]
    positivity
  · intro M hM0 hM2 hquarter hk hlog
    have hMpos : 0 < M := by omega
    have hraw := h2BooleanDyadicSecondWeightMoment_le_interval
      (q := q) (M := M) hMpos
    have hI0 := hI M hM0 hquarter hk
    have hIabs :
        (∑ n ∈ Finset.Ioc M (2 * M),
          h2BooleanTiltLift q h2BooleanSecondTilt n) ≤
          |C0| * (M : ℝ) *
            (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanV0 - 1) := by
      calc
        (∑ n ∈ Finset.Ioc M (2 * M),
          h2BooleanTiltLift q h2BooleanSecondTilt n)
          ≤ C0 * (M : ℝ) *
            (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanV0 - 1) := hI0
        _ ≤ |C0| * (M : ℝ) *
            (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanV0 - 1) := by
          gcongr
          exact le_abs_self C0
    have hlog2M0 : 0 ≤ Real.log ((2 * M : ℕ) : ℝ) := by
      apply Real.log_nonneg
      exact_mod_cast (show 1 ≤ 2 * M by omega)
    have hlogM0 : 0 ≤ Real.log (M : ℝ) := le_trans (by norm_num) hlog
    have hpow :
        (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanV0 - 1) ≤
          (2 : ℝ) ^ (h2BooleanV0 - 1) *
            (Real.log (M : ℝ)) ^ (h2BooleanV0 - 1) := by
      have hbase := h2Boolean_log_two_mul_le_two_log_public hM2
      calc
        (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanV0 - 1)
          ≤ (2 * Real.log (M : ℝ)) ^ (h2BooleanV0 - 1) :=
            Real.rpow_le_rpow hlog2M0 hbase h2BooleanV0_sub_one_nonneg
        _ = (2 : ℝ) ^ (h2BooleanV0 - 1) *
            (Real.log (M : ℝ)) ^ (h2BooleanV0 - 1) := by
              rw [Real.mul_rpow (by norm_num) hlogM0]
    calc
      (∑ S ∈ h2BooleanDyadicSets q M,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card)
        ≤ (M : ℝ)⁻¹ *
          (∑ n ∈ Finset.Ioc M (2 * M),
            h2BooleanTiltLift q h2BooleanSecondTilt n) := hraw
      _ ≤ (M : ℝ)⁻¹ *
          (|C0| * (M : ℝ) *
            (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanV0 - 1)) := by
              gcongr
      _ = |C0| *
          (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanV0 - 1) := by
              have hMR : (M : ℝ) ≠ 0 := by exact_mod_cast hMpos.ne'
              field_simp [hMR]
      _ ≤ |C0| * ((2 : ℝ) ^ (h2BooleanV0 - 1) *
            (Real.log (M : ℝ)) ^ (h2BooleanV0 - 1)) := by
              exact mul_le_mul_of_nonneg_left hpow (abs_nonneg C0)
      _ = C * (Real.log (M : ℝ)) ^ (h2BooleanV0 - 1) := by
              dsimp [C]
              ring

lemma h2BooleanV0_sub_one_le_X0_add_one :
    h2BooleanV0 - 1 ≤ h2BooleanX0 + 1 := by
  have hv := h2BooleanV0_le_three
  have hx := h2BooleanX0_one_le_public
  linarith

theorem h2BooleanETTruncation_le_main_rate
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ M0 : ℕ,
      0 ≤ C ∧
      ∀ M : ℕ,
        M0 ≤ M →
        2 ≤ M →
        ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
        ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
        2 ≤ Real.log (M : ℝ) →
        (32 / ((h2BooleanETCutoff M : ℝ) ^ 2)) *
          (∑ S ∈ h2BooleanDyadicSets q M,
            finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) ≤
          C * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) := by
  rcases h2BooleanDyadicSecondWeightMoment_le_log_rate q hq with
    ⟨C0, M0, hC0, hW⟩
  refine ⟨128 * C0, M0, by positivity, ?_⟩
  intro M hM0 hM2 hquarter hk hlog2
  have hlog1 : 1 ≤ Real.log (M : ℝ) := by linarith
  have hW0 := hW M hM0 hM2 hquarter hk hlog1
  let L : ℝ := Real.log (M : ℝ)
  let J : ℝ := h2BooleanETCutoff M
  have hLpos : 0 < L := lt_of_lt_of_le zero_lt_one hlog1
  have hJhalf : L / 2 ≤ J := by
    simpa [L, J] using h2BooleanETCutoff_half_log_le hlog2
  have hJpos : 0 < J := lt_of_lt_of_le (half_pos hLpos) hJhalf
  have hsquares : L ^ 2 / 4 ≤ J ^ 2 := by
    nlinarith [sq_nonneg (J - L / 2)]
  have hinv :
      1 / J ^ 2 ≤ 4 / L ^ 2 := by
    have hLspos : 0 < L ^ 2 / 4 := by positivity
    have hi := one_div_le_one_div_of_le hLspos hsquares
    convert hi using 1 <;> field_simp <;> ring
  have hL1 : 1 ≤ L := by simpa [L] using hlog1
  have hpowexp :
      L ^ (h2BooleanV0 - 1) ≤ L ^ (h2BooleanX0 + 1) :=
    Real.rpow_le_rpow_of_exponent_le hL1 h2BooleanV0_sub_one_le_X0_add_one
  have hmainid :
      (4 / L ^ 2) * L ^ (h2BooleanX0 + 1) =
        4 * L ^ (h2BooleanX0 - 1) := by
    have hL0 : L ≠ 0 := ne_of_gt hLpos
    rw [show L ^ (h2BooleanX0 + 1) =
      L ^ (h2BooleanX0 - 1) * L ^ (2 : ℝ) by
        rw [← Real.rpow_add hLpos]
        congr 1
        ring]
    rw [Real.rpow_two]
    field_simp [hL0]
  calc
    (32 / ((h2BooleanETCutoff M : ℝ) ^ 2)) *
        (∑ S ∈ h2BooleanDyadicSets q M,
          finiteOmegaWeightReal S * h2BooleanV0 ^ S.card)
      ≤ (32 / J ^ 2) * (C0 * L ^ (h2BooleanV0 - 1)) := by
          dsimp [J, L]
          gcongr
    _ ≤ (32 * (4 / L ^ 2)) *
          (C0 * L ^ (h2BooleanV0 - 1)) := by
          have : 32 / J ^ 2 = 32 * (1 / J ^ 2) := by ring
          rw [this]
          gcongr
    _ ≤ (32 * (4 / L ^ 2)) *
          (C0 * L ^ (h2BooleanX0 + 1)) := by
          gcongr
    _ = (128 * C0) * L ^ (h2BooleanX0 - 1) := by
          calc
            (32 * (4 / L ^ 2)) * (C0 * L ^ (h2BooleanX0 + 1))
              = 32 * C0 * ((4 / L ^ 2) * L ^ (h2BooleanX0 + 1)) := by ring
            _ = 32 * C0 * (4 * L ^ (h2BooleanX0 - 1)) := by rw [hmainid]
            _ = (128 * C0) * L ^ (h2BooleanX0 - 1) := by ring
    _ = _ := by rfl

#print axioms h2BooleanDyadicSecondWeightMoment_le_log_rate
#print axioms h2BooleanETTruncation_le_main_rate

end PaperB.FixedQ


namespace PaperB.FixedQ

lemma h2BooleanSecondMomentRateConstant_nonneg_public (q : ℕ) :
    0 ≤ h2BooleanSecondMomentRateConstant q := by
  unfold h2BooleanSecondMomentRateConstant
  unfold PaperB.M4B.shiuFixedQuarterAssembleConstant
  unfold PaperB.M4B.shiuClassIVConstant
  positivity

theorem h2BooleanOrdinaryDyadicWeightedDiscrepancyL2_le_rate
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ M0 : ℕ,
      0 ≤ C ∧
      ∀ A H M : ℕ,
        (¬ 2 ∣ q → 2 ∣ H) →
        M0 ≤ M →
        3 ≤ M →
        4 ≤ h2BooleanRoughCutoff M →
        3 ≤ Nat.nthRoot 4 M →
        (h2BooleanRoughCutoff M) ^ 2 ≤ M →
        ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
        ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
        2 ≤ Real.log (M : ℝ) →
        1 ≤ Real.log (Real.log (M : ℝ)) →
        h2BooleanTailCorrectionConst ≤
          (1 / 8 : ℝ) *
            (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) →
        Real.exp (-(1 / 8 : ℝ) *
            (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) ≤
          (Real.log (M : ℝ)) ^ (-4 : ℝ) →
        (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
          finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
            |fixedProductBooleanDiscrepancy
              (fixedQLowWeight q A H) H S| ^ 2) ≤
          C * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
            (Real.log (Real.log (M : ℝ))) ^ (4 : ℝ) := by
  rcases h2BooleanOrdinaryDyadicWeightedDiscrepancyL2_le_majorants q hq with
    ⟨MM, hMajor⟩
  rcases h2BooleanETTruncation_le_main_rate q hq with
    ⟨CT, MT, hCT0, hTrunc⟩
  let α : ℝ := h2BooleanV0 / 2 + 2
  let CM : ℝ :=
    32 * h2BooleanSecondMomentRateConstant q * (2 : ℝ) ^ α
  let C : ℝ :=
    (6 * (fixedQPeriod q : ℝ)) ^ 2 * (CT + CM)
  refine ⟨C, max MM MT, ?_, ?_⟩
  · dsimp [C, CM, α]
    have hrate0 := h2BooleanSecondMomentRateConstant_nonneg_public q
    positivity
  · intro A H M h2admissible hM0 hM3 hY4 hroot hYsq hquarter hk
      hlog2 hll hTail hdec
    have hM2 : 2 ≤ M := by omega
    have hMM : MM ≤ M := (le_max_left MM MT).trans hM0
    have hMT : MT ≤ M := (le_max_right MM MT).trans hM0
    have hlog1 : 1 ≤ Real.log (M : ℝ) := by linarith
    let J := h2BooleanETCutoff M
    have hJ : 1 ≤ J := by
      dsimp [J]
      exact h2BooleanETCutoff_one_le hlog1
    have hraw :=
      hMajor A H M J h2admissible hJ hMM hM2 hY4 hroot hYsq
        hquarter hk hlog1 hTail
    have htr :=
      hTrunc M hMT hM2 hquarter hk hlog2
    have hmoment :=
      h2BooleanETMomentMajorant_le_rate
        q M J hM3 hlog1 hJ hdec
    have hloglogpow :=
      h2BooleanET_loglog_power_le_four
        (M := M) hlog1 hll
    let LM : ℝ := Real.log (M : ℝ)
    let LL : ℝ := Real.log (Real.log (M : ℝ))
    have hLM0 : 0 ≤ LM := le_trans (by norm_num) hlog1
    have hLL1 : 1 ≤ LL := by simpa [LL] using hll
    have hLL0 : 0 ≤ LL := le_trans (by norm_num) hLL1
    have hmain0 : 0 ≤ LM ^ (h2BooleanX0 - 1) :=
      Real.rpow_nonneg hLM0 _
    have hLL4one : 1 ≤ LL ^ (4 : ℝ) := by
      exact Real.one_le_rpow hLL1 (by norm_num)
    have htr' :
        (32 / ((J : ℝ) ^ 2)) *
            (∑ S ∈ h2BooleanDyadicSets q M,
              finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) ≤
          CT * LM ^ (h2BooleanX0 - 1) * LL ^ (4 : ℝ) := by
      calc
        (32 / ((J : ℝ) ^ 2)) *
            (∑ S ∈ h2BooleanDyadicSets q M,
              finiteOmegaWeightReal S * h2BooleanV0 ^ S.card)
          ≤ CT * LM ^ (h2BooleanX0 - 1) := by
              simpa [J, LM] using htr
        _ ≤ CT * LM ^ (h2BooleanX0 - 1) * LL ^ (4 : ℝ) := by
              have hbase0 := mul_nonneg hCT0 hmain0
              nlinarith [mul_le_mul_of_nonneg_left hLL4one hbase0]
    have hmoment' :
        32 * (1 + Real.log (J : ℝ)) *
            (∑ j ∈ Finset.Icc 1 J,
              h2BooleanFrequencySecondMomentMajorantAll q M j /
                (j : ℝ)) ≤
          CM * LM ^ (h2BooleanX0 - 1) * LL ^ (4 : ℝ) := by
      have hnorm :
          (1 + Real.log (J : ℝ)) *
              (∑ j ∈ Finset.Icc 1 J,
                h2BooleanFrequencySecondMomentMajorantAll q M j /
                  (j : ℝ)) ≤
            h2BooleanSecondMomentRateConstant q *
              LM ^ (h2BooleanX0 - 1) *
              (1 + Real.log (J : ℝ)) ^ α := by
        simpa [J, LM, α] using hmoment
      have hrate0 := h2BooleanSecondMomentRateConstant_nonneg_public q
      have hαpow0 : 0 ≤ (2 : ℝ) ^ α := Real.rpow_nonneg (by norm_num) _
      calc
        32 * (1 + Real.log (J : ℝ)) *
            (∑ j ∈ Finset.Icc 1 J,
              h2BooleanFrequencySecondMomentMajorantAll q M j /
                (j : ℝ))
          = 32 * ((1 + Real.log (J : ℝ)) *
            (∑ j ∈ Finset.Icc 1 J,
              h2BooleanFrequencySecondMomentMajorantAll q M j /
                (j : ℝ))) := by ring
        _ ≤ 32 * (h2BooleanSecondMomentRateConstant q *
              LM ^ (h2BooleanX0 - 1) *
              (1 + Real.log (J : ℝ)) ^ α) := by
              gcongr
        _ ≤ 32 * (h2BooleanSecondMomentRateConstant q *
              LM ^ (h2BooleanX0 - 1) *
              ((2 : ℝ) ^ α * LL ^ (4 : ℝ))) := by
              gcongr
        _ = CM * LM ^ (h2BooleanX0 - 1) * LL ^ (4 : ℝ) := by
              dsimp [CM]
              ring
    calc
      (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
        finiteOmegaWeightReal S * h2BooleanV0 ^ S.card *
          |fixedProductBooleanDiscrepancy
            (fixedQLowWeight q A H) H S| ^ 2)
        ≤ (6 * (fixedQPeriod q : ℝ)) ^ 2 *
          ((32 / ((J : ℝ) ^ 2)) *
            (∑ S ∈ h2BooleanDyadicSets q M,
              finiteOmegaWeightReal S * h2BooleanV0 ^ S.card) +
          32 * (1 + Real.log (J : ℝ)) *
            (∑ j ∈ Finset.Icc 1 J,
              h2BooleanFrequencySecondMomentMajorantAll q M j /
                (j : ℝ))) := hraw
      _ ≤ (6 * (fixedQPeriod q : ℝ)) ^ 2 *
          ((CT * LM ^ (h2BooleanX0 - 1) * LL ^ (4 : ℝ)) +
           (CM * LM ^ (h2BooleanX0 - 1) * LL ^ (4 : ℝ))) := by
            gcongr
      _ = C * LM ^ (h2BooleanX0 - 1) * LL ^ (4 : ℝ) := by
            dsimp [C]
            ring
      _ = _ := by rfl

#print axioms h2BooleanSecondMomentRateConstant_nonneg_public
#print axioms h2BooleanOrdinaryDyadicWeightedDiscrepancyL2_le_rate

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem h2BooleanDyadicFirstWeightMoment_le_log_rate
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ M0 : ℕ,
      0 ≤ C ∧
      ∀ M : ℕ,
        M0 ≤ M →
        2 ≤ M →
        ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
        ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
        1 ≤ Real.log (M : ℝ) →
        (∑ S ∈ h2BooleanDyadicSets q M,
          finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) ≤
          C * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) := by
  rcases h2BooleanFirstTilt_interval_log_power q hq with ⟨C0, M0, hI⟩
  let C : ℝ := |C0| * (2 : ℝ) ^ (h2BooleanX0 - 1)
  refine ⟨C, M0, ?_, ?_⟩
  · dsimp [C]
    positivity
  · intro M hM0 hM2 hquarter hk hlog
    have hMpos : 0 < M := by omega
    have hraw := h2BooleanDyadicFirstMoment_le_interval
      (q := q) (M := M) hMpos
    have hI0 := hI M hM0 hquarter hk
    have hIabs :
        (∑ n ∈ Finset.Ioc M (2 * M),
          h2BooleanTiltLift q h2BooleanFirstTilt n) ≤
          |C0| * (M : ℝ) *
            (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) := by
      calc
        (∑ n ∈ Finset.Ioc M (2 * M),
          h2BooleanTiltLift q h2BooleanFirstTilt n)
          ≤ C0 * (M : ℝ) *
            (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) := hI0
        _ ≤ |C0| * (M : ℝ) *
            (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) := by
              gcongr
              exact le_abs_self C0
    have hlog2M0 : 0 ≤ Real.log ((2 * M : ℕ) : ℝ) := by
      apply Real.log_nonneg
      exact_mod_cast (show 1 ≤ 2 * M by omega)
    have hlogM0 : 0 ≤ Real.log (M : ℝ) := le_trans (by norm_num) hlog
    have hxexp0 : 0 ≤ h2BooleanX0 - 1 :=
      sub_nonneg.mpr h2BooleanX0_one_le_public
    have hpow :
        (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) ≤
          (2 : ℝ) ^ (h2BooleanX0 - 1) *
            (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) := by
      have hbase := h2Boolean_log_two_mul_le_two_log_public hM2
      calc
        (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1)
          ≤ (2 * Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) :=
            Real.rpow_le_rpow hlog2M0 hbase hxexp0
        _ = (2 : ℝ) ^ (h2BooleanX0 - 1) *
            (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) := by
              rw [Real.mul_rpow (by norm_num) hlogM0]
    calc
      (∑ S ∈ h2BooleanDyadicSets q M,
        finiteOmegaWeightReal S * h2BooleanX0 ^ S.card)
        ≤ (M : ℝ)⁻¹ *
          (∑ n ∈ Finset.Ioc M (2 * M),
            h2BooleanTiltLift q h2BooleanFirstTilt n) := hraw
      _ ≤ (M : ℝ)⁻¹ *
          (|C0| * (M : ℝ) *
            (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1)) := by
              gcongr
      _ = |C0| *
          (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) := by
              have hMR : (M : ℝ) ≠ 0 := by exact_mod_cast hMpos.ne'
              field_simp [hMR]
      _ ≤ |C0| * ((2 : ℝ) ^ (h2BooleanX0 - 1) *
            (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1)) := by
              exact mul_le_mul_of_nonneg_left hpow (abs_nonneg C0)
      _ = C * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) := by
              dsimp [C]
              ring

#print axioms h2BooleanDyadicFirstWeightMoment_le_log_rate

end PaperB.FixedQ


namespace PaperB.FixedQ

theorem h2BooleanOrdinaryDyadicFullShell_le_rate_of_conditions
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ M0 : ℕ,
      0 ≤ C ∧
      ∀ A H M : ℕ,
        (¬ 2 ∣ q → 2 ∣ H) →
        M0 ≤ M →
        3 ≤ M →
        4 ≤ h2BooleanRoughCutoff M →
        3 ≤ Nat.nthRoot 4 M →
        (h2BooleanRoughCutoff M) ^ 2 ≤ M →
        ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
        ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
        2 ≤ Real.log (M : ℝ) →
        1 ≤ Real.log (Real.log (M : ℝ)) →
        h2BooleanTailCorrectionConst ≤
          (1 / 8 : ℝ) *
            (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta) →
        Real.exp (-(1 / 8 : ℝ) *
            (Real.log (M : ℝ)) ^ (1 - h2BooleanTheta)) ≤
          (Real.log (M : ℝ)) ^ (-4 : ℝ) →
        (∑ S ∈ h2BooleanOrdinaryDyadicSets q H M,
          finiteOmegaWeightReal S * (2 : ℝ) ^ S.card *
            |fixedProductBooleanDiscrepancy
              (fixedQLowWeight q A H) H S|) ≤
          C * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) *
            (Real.log (Real.log (M : ℝ))) ^ 2 := by
  rcases h2BooleanDyadicFirstWeightMoment_le_log_rate q hq with
    ⟨C1, M1, hC1, hFirst⟩
  rcases h2BooleanOrdinaryDyadicWeightedDiscrepancyL2_le_rate q hq with
    ⟨C2, M2, hC2, hL2⟩
  let C : ℝ := C1 * C2 + 1
  refine ⟨C, max M1 M2, ?_, ?_⟩
  · dsimp [C]
    nlinarith [mul_nonneg hC1 hC2]
  · intro A H M h2admissible hM0 hM3 hY4 hroot hYsq hquarter hk
      hlog2 hll hTail hdec
    have hM2 : 2 ≤ M := by omega
    have hM1 : M1 ≤ M := (le_max_left M1 M2).trans hM0
    have hM2' : M2 ≤ M := (le_max_right M1 M2).trans hM0
    have hlog1 : 1 ≤ Real.log (M : ℝ) := by linarith
    let F := h2BooleanOrdinaryDyadicSets q H M
    let G := h2BooleanDyadicSets q M
    let D : Finset ℕ → ℝ :=
      fun S => fixedProductBooleanDiscrepancy (fixedQLowWeight q A H) H S
    let X : ℝ := (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1)
    let LL : ℝ := Real.log (Real.log (M : ℝ))
    let Shell : ℝ :=
      ∑ S ∈ F,
        finiteOmegaWeightReal S * (2 : ℝ) ^ S.card * |D S|
    have hFirstRate :
        (∑ S ∈ G,
          finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) ≤ C1 * X := by
      simpa [G, X] using hFirst M hM1 hM2 hquarter hk hlog1
    have hL2Rate :
        (∑ S ∈ F,
          finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * |D S| ^ 2) ≤
          C2 * X * LL ^ (4 : ℝ) := by
      simpa [F, D, X, LL] using
        hL2 A H M h2admissible hM2' hM3 hY4 hroot hYsq hquarter hk
          hlog2 hll hTail hdec
    have hCauchy :
        Shell ^ 2 ≤
          (∑ S ∈ F,
            finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) *
          (∑ S ∈ F,
            finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * |D S| ^ 2) := by
      simpa [Shell, F, D] using
        h2BooleanOrdinaryDyadicFullShell_cauchy_sq
          (q := q) (A := A) (H := H) (M := M)
    have hsub : F ⊆ G := by
      intro S hS
      exact (h2BooleanOrdinaryDyadicSets_mem hS).1
    have hFirstSub :
        (∑ S ∈ F,
          finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) ≤
        ∑ S ∈ G,
          finiteOmegaWeightReal S * h2BooleanX0 ^ S.card := by
      apply Finset.sum_le_sum_of_subset_of_nonneg hsub
      intro S hSG hnot
      have hActive := h2BooleanDyadicSets_active hSG
      exact mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hActive)
        (pow_nonneg h2BooleanX0_nonneg _)
    have hF2nonneg :
        0 ≤ ∑ S ∈ F,
          finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * |D S| ^ 2 := by
      apply Finset.sum_nonneg
      intro S hSF
      have hm := h2BooleanOrdinaryDyadicSets_mem hSF
      have hActive := h2BooleanDyadicSets_active hm.1
      exact mul_nonneg
        (mul_nonneg (finiteOmegaWeightReal_nonneg_of_active hActive)
          (pow_nonneg h2BooleanV0_nonneg _))
        (sq_nonneg _)
    have hX0 : 0 ≤ X := by
      dsimp [X]
      exact Real.rpow_nonneg (le_trans (by norm_num) hlog1) _
    have hLL1 : 1 ≤ LL := by simpa [LL] using hll
    have hLL0 : 0 ≤ LL := le_trans (by norm_num) hLL1
    have hC1X0 : 0 ≤ C1 * X := mul_nonneg hC1 hX0
    have hSq :
        Shell ^ 2 ≤ (C1 * X) * (C2 * X * LL ^ (4 : ℝ)) := by
      calc
        Shell ^ 2
          ≤ (∑ S ∈ F,
              finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) *
            (∑ S ∈ F,
              finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * |D S| ^ 2) :=
                hCauchy
        _ ≤ (∑ S ∈ G,
              finiteOmegaWeightReal S * h2BooleanX0 ^ S.card) *
            (∑ S ∈ F,
              finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * |D S| ^ 2) :=
                mul_le_mul_of_nonneg_right hFirstSub hF2nonneg
        _ ≤ (C1 * X) *
            (∑ S ∈ F,
              finiteOmegaWeightReal S * h2BooleanV0 ^ S.card * |D S| ^ 2) :=
                mul_le_mul_of_nonneg_right hFirstRate hF2nonneg
        _ ≤ (C1 * X) * (C2 * X * LL ^ (4 : ℝ)) :=
                mul_le_mul_of_nonneg_left hL2Rate hC1X0
    let K : ℝ := C1 * C2
    let Z : ℝ := X ^ 2 * LL ^ (4 : ℕ)
    have hLL4 : LL ^ (4 : ℝ) = LL ^ (4 : ℕ) := by
      exact Real.rpow_natCast LL 4
    have hK0 : 0 ≤ K := by dsimp [K]; exact mul_nonneg hC1 hC2
    have hZ0 : 0 ≤ Z := by
      dsimp [Z]
      positivity
    have hKle : K ≤ (K + 1) ^ 2 := by
      nlinarith [sq_nonneg K]
    have hProd :
        (C1 * X) * (C2 * X * LL ^ (4 : ℝ)) ≤
          (C * X * LL ^ 2) ^ 2 := by
      have hleft :
          (C1 * X) * (C2 * X * LL ^ (4 : ℝ)) = K * Z := by
        rw [hLL4]
        dsimp [K, Z]
        ring
      have hright :
          (C * X * LL ^ 2) ^ 2 = (K + 1) ^ 2 * Z := by
        dsimp [C, K, Z]
        ring
      rw [hleft, hright]
      exact mul_le_mul_of_nonneg_right hKle hZ0
    have hC0 : 0 ≤ C := by
      dsimp [C]
      exact add_nonneg (mul_nonneg hC1 hC2) (by norm_num)
    have hTarget0 : 0 ≤ C * X * LL ^ 2 :=
      mul_nonneg (mul_nonneg hC0 hX0) (sq_nonneg LL)
    have hSqTarget : Shell ^ 2 ≤ (C * X * LL ^ 2) ^ 2 :=
      hSq.trans hProd
    have hShell : Shell ≤ C * X * LL ^ 2 :=
      le_of_sq_le_sq hSqTarget hTarget0
    simpa [Shell, F, D, C, X, LL] using hShell

#print axioms h2BooleanOrdinaryDyadicFullShell_le_rate_of_conditions

end PaperB.FixedQ
namespace PaperB.FixedQ

theorem h2EndpointDyadicShell_le_log_rate
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ M0 : ℕ, 0 ≤ C ∧
      ∀ A H M : ℕ,
        0 < H →
        (¬ 2 ∣ q → 2 ∣ H) →
        M0 ≤ M →
        2 ≤ M →
        ((2 * M : ℕ) : ℝ) ^ (1 / 4 : ℝ) < (M : ℝ) →
        ((6 * q : ℕ) : ℝ) < (M : ℝ) ^ (3 / 4 : ℝ) →
        1 ≤ Real.log (M : ℝ) →
        h2EndpointDyadicShell q A H M ≤
          C * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) := by
  rcases h2EndpointDyadicShell_log_power q hq with ⟨C0, M0, h0⟩
  let C : ℝ := |C0| * (2 : ℝ) ^ (h2BooleanX0 - 1)
  refine ⟨C, M0, by dsimp [C]; positivity, ?_⟩
  intro A H M hH h2 hM hM2 hquarter hqM hlog
  have hs := h0 A H M hH h2 hM hquarter hqM
  have hlog2M0 : 0 ≤ Real.log ((2 * M : ℕ) : ℝ) := by
    apply Real.log_nonneg
    exact_mod_cast (show 1 ≤ 2 * M by omega)
  have hlogM0 : 0 ≤ Real.log (M : ℝ) := le_trans (by norm_num) hlog
  have hxexp0 : 0 ≤ h2BooleanX0 - 1 :=
    sub_nonneg.mpr h2BooleanX0_one_le
  have hpow :
      (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) ≤
        (2 : ℝ) ^ (h2BooleanX0 - 1) *
          (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) := by
    have hbase := h2Boolean_log_two_mul_le_two_log_public hM2
    calc
      _ ≤ (2 * Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) :=
        Real.rpow_le_rpow hlog2M0 hbase hxexp0
      _ = _ := by rw [Real.mul_rpow (by norm_num) hlogM0]
  calc
    h2EndpointDyadicShell q A H M
      ≤ C0 * (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) := hs
    _ ≤ |C0| * (Real.log ((2 * M : ℕ) : ℝ)) ^ (h2BooleanX0 - 1) := by
      gcongr
      exact le_abs_self C0
    _ ≤ |C0| * ((2 : ℝ) ^ (h2BooleanX0 - 1) *
        (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1)) :=
      mul_le_mul_of_nonneg_left hpow (abs_nonneg C0)
    _ = C * (Real.log (M : ℝ)) ^ (h2BooleanX0 - 1) := by
      dsimp [C]
      ring

#print axioms h2EndpointDyadicShell_le_log_rate

end PaperB.FixedQ
