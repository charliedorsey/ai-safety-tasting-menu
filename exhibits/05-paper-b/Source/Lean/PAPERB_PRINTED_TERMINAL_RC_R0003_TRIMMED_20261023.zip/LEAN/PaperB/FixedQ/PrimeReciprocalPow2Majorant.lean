import PaperB.FixedQ.HarmonicLogTail

open scoped BigOperators
open Finset Nat Real

namespace PaperB.FixedQ

noncomputable def primeReciprocalPow2Majorant (K N : ℕ) : ℝ :=
  ∑ j ∈ Finset.range N, primeReciprocalDyadicBlock (2 ^ (K + j))

lemma log_two_ge_half :
    (1 / 2 : ℝ) ≤ Real.log 2 := by
  have h := inv_succ_le_log_succ_sub_log (n := 1) (by norm_num)
  norm_num at h
  simpa using h

lemma pow_two_ge_four
    {K j : ℕ} (hK : 2 ≤ K) :
    4 ≤ 2 ^ (K + j) := by
  have hpow : 2 ^ 2 ≤ 2 ^ (K + j) := by
    exact Nat.pow_le_pow_right (by norm_num) (by omega)
  norm_num at hpow ⊢
  exact hpow

lemma dyadicBlock_pow_two_le_harmonic
    {K j : ℕ} (hK : 2 ≤ K) :
    primeReciprocalDyadicBlock (2 ^ (K + j)) ≤
      32 / ((K + j : ℕ) : ℝ) := by
  have hblock := primeReciprocalDyadicBlock_le
    (T := 2 ^ (K + j)) (pow_two_ge_four hK)
  have hkj : 0 < K + j := by omega
  have hlog2pos : 0 < Real.log 2 :=
    lt_of_lt_of_le (by norm_num : (0 : ℝ) < 1 / 2) log_two_ge_half
  have hlogpow :
      Real.log ((2 ^ (K + j) : ℕ) : ℝ) =
        ((K + j : ℕ) : ℝ) * Real.log 2 := by
    norm_num only [Nat.cast_pow, Nat.cast_ofNat]
    rw [Real.log_pow]
  rw [hlogpow] at hblock
  have hden :
      0 < ((K + j : ℕ) : ℝ) * Real.log 2 := by
    positivity
  calc
    primeReciprocalDyadicBlock (2 ^ (K + j))
        ≤ 16 / (((K + j : ℕ) : ℝ) * Real.log 2) := hblock
    _ ≤ 32 / ((K + j : ℕ) : ℝ) := by
      apply (div_le_div_iff₀ hden (by positivity : (0 : ℝ) < ((K + j : ℕ) : ℝ))).2
      have hkjR : (0 : ℝ) < ((K + j : ℕ) : ℝ) := by positivity
      have hmul :
          ((K + j : ℕ) : ℝ) * (1 / 2 : ℝ) ≤
            ((K + j : ℕ) : ℝ) * Real.log 2 :=
        mul_le_mul_of_nonneg_left log_two_ge_half hkjR.le
      nlinarith

theorem primeReciprocalPow2Majorant_le
    {K N : ℕ} (hK : 2 ≤ K) :
    primeReciprocalPow2Majorant K N ≤
      32 * ((1 : ℝ) / K +
        (Real.log ((K + N : ℕ) : ℝ) - Real.log (K : ℝ))) := by
  unfold primeReciprocalPow2Majorant
  calc
    (∑ j ∈ Finset.range N,
        primeReciprocalDyadicBlock (2 ^ (K + j)))
        ≤ ∑ j ∈ Finset.range N,
            32 / ((K + j : ℕ) : ℝ) := by
          apply Finset.sum_le_sum
          intro j hj
          exact dyadicBlock_pow_two_le_harmonic hK
    _ = 32 * (∑ j ∈ Finset.range N,
        (1 : ℝ) / ((K + j : ℕ) : ℝ)) := by
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro j hj
          ring
    _ ≤ 32 * ((1 : ℝ) / K +
        (Real.log ((K + N : ℕ) : ℝ) - Real.log (K : ℝ))) := by
          exact mul_le_mul_of_nonneg_left
            (shifted_harmonic_range_le (K := K) (N := N) (by omega))
            (by norm_num)

#print axioms primeReciprocalPow2Majorant_le

end PaperB.FixedQ
