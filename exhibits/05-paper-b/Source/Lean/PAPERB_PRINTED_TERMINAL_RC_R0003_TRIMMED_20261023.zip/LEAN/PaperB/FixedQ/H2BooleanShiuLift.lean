import PaperB.FixedQ.H2BooleanCauchy
import PaperB.FixedQ.ShiuMass
import Mathlib.Algebra.Order.BigOperators.Ring.Finset
import Mathlib.Analysis.SpecialFunctions.Pow.NNReal

open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def h2BooleanFirstTilt : ℝ := h2BooleanX0 / 2
noncomputable def h2BooleanSecondTilt : ℝ := h2BooleanV0 / 2

lemma h2BooleanFirstTilt_eq :
    h2BooleanFirstTilt = Real.sqrt h2BooleanA0 := by
  unfold h2BooleanFirstTilt h2BooleanX0
  ring

lemma h2BooleanSecondTilt_eq :
    h2BooleanSecondTilt = 1 / Real.sqrt h2BooleanA0 := by
  unfold h2BooleanSecondTilt h2BooleanV0
  ring

lemma h2BooleanFirstTilt_nonneg : 0 ≤ h2BooleanFirstTilt := by
  rw [h2BooleanFirstTilt_eq]
  positivity

lemma h2BooleanSecondTilt_nonneg : 0 ≤ h2BooleanSecondTilt := by
  rw [h2BooleanSecondTilt_eq]
  positivity
lemma h2BooleanFirstTilt_le_three_fourths :
    h2BooleanFirstTilt ≤ (3 / 4 : ℝ) := by
  rw [h2BooleanFirstTilt_eq]
  have hs0 : 0 ≤ Real.sqrt h2BooleanA0 := Real.sqrt_nonneg _
  have hs2 : (Real.sqrt h2BooleanA0) ^ 2 = h2BooleanA0 := by
    rw [Real.sq_sqrt]
    exact le_of_lt h2BooleanA0_pos
  nlinarith [show h2BooleanA0 = (101 / 200 : ℝ) by rfl]

lemma h2BooleanSecondTilt_le_three_halves :
    h2BooleanSecondTilt ≤ (3 / 2 : ℝ) := by
  rw [h2BooleanSecondTilt_eq]
  have hspos : 0 < Real.sqrt h2BooleanA0 := Real.sqrt_pos.2 h2BooleanA0_pos
  have hs2 : (Real.sqrt h2BooleanA0) ^ 2 = h2BooleanA0 := by
    rw [Real.sq_sqrt]
    exact le_of_lt h2BooleanA0_pos
  apply (div_le_iff₀ hspos).2
  nlinarith [show h2BooleanA0 = (101 / 200 : ℝ) by rfl]

noncomputable def h2BooleanTiltLiftNat (q : ℕ) (c : ℝ) (n : ℕ) : ℝ :=
  (n : ℝ) * fixedQShiuWeight q n * c ^ n.primeFactors.card

noncomputable def h2BooleanTiltLift (q : ℕ) (c : ℝ) : ArithmeticFunction ℝ :=
  ⟨h2BooleanTiltLiftNat q c, by
    simp [h2BooleanTiltLiftNat, fixedQShiuWeightNat]⟩

@[simp] theorem h2BooleanTiltLift_apply (q : ℕ) (c : ℝ) (n : ℕ) :
    h2BooleanTiltLift q c n = h2BooleanTiltLiftNat q c n := rfl
lemma h2_primeFactors_card_mul_of_coprime
    {m n : ℕ} (hm0 : m ≠ 0) (hn0 : n ≠ 0) (hcop : m.Coprime n) :
    (m * n).primeFactors.card =
      m.primeFactors.card + n.primeFactors.card := by
  rw [Nat.primeFactors_mul hm0 hn0]
  rw [Finset.card_union_of_disjoint]
  rw [Finset.disjoint_left]
  intro p hpm hpn
  have hpd : p ∣ m.gcd n :=
    Nat.dvd_gcd (Nat.dvd_of_mem_primeFactors hpm)
      (Nat.dvd_of_mem_primeFactors hpn)
  rw [hcop.gcd_eq_one] at hpd
  exact (Nat.prime_of_mem_primeFactors hpm).not_dvd_one hpd

theorem h2BooleanTiltLift_multiplicative (q : ℕ) (c : ℝ) :
    (h2BooleanTiltLift q c).IsMultiplicative := by
  constructor
  · simp [h2BooleanTiltLift_apply, h2BooleanTiltLiftNat,
      fixedQShiuWeightNat]
  · intro m n hcop
    by_cases hm0 : m = 0
    · subst m
      have hn1 : n = 1 := by simpa using hcop
      subst n
      simp [h2BooleanTiltLift_apply, h2BooleanTiltLiftNat,
        fixedQShiuWeightNat]
    · by_cases hn0 : n = 0
      · subst n
        have hm1 : m = 1 := by simpa using hcop
        subst m
        simp [h2BooleanTiltLift_apply, h2BooleanTiltLiftNat,
          fixedQShiuWeightNat]
      · rw [h2BooleanTiltLift_apply, h2BooleanTiltLift_apply,
          h2BooleanTiltLift_apply]
        unfold h2BooleanTiltLiftNat
        have hw0 :=
          (fixedQShiuWeight_multiplicative q).map_mul_of_coprime hcop
        have hw : fixedQShiuWeightNat q (m * n) =
            fixedQShiuWeightNat q m * fixedQShiuWeightNat q n := by
          simpa [fixedQShiuWeight_apply] using hw0
        rw [hw0, h2_primeFactors_card_mul_of_coprime hm0 hn0 hcop, pow_add]
        push_cast
        ring
lemma h2BooleanTiltLift_nonneg
    (q n : ℕ) {c : ℝ} (hc : 0 ≤ c) :
    0 ≤ h2BooleanTiltLift q c n := by
  rw [h2BooleanTiltLift_apply]
  unfold h2BooleanTiltLiftNat
  exact mul_nonneg
    (mul_nonneg (by positivity) (fixedQShiuWeight_nonneg q n))
    (pow_nonneg hc _)

lemma h2BooleanTiltLift_squarefree_support
    (q n : ℕ) (c : ℝ) (hn : ¬ Squarefree n) :
    h2BooleanTiltLift q c n = 0 := by
  rw [h2BooleanTiltLift_apply]
  unfold h2BooleanTiltLiftNat
  rw [fixedQShiuWeight_squarefree_support q n hn]
  ring

lemma h2BooleanTiltLift_eq_zero_of_not_coprime
    (q n : ℕ) (c : ℝ) (hc : ¬ n.Coprime (6 * q)) :
    h2BooleanTiltLift q c n = 0 := by
  rw [h2BooleanTiltLift_apply]
  unfold h2BooleanTiltLiftNat
  rw [fixedQShiuWeight_apply, fixedQShiuWeightNat]
  by_cases hn0 : n = 0
  · rw [if_pos hn0]
    ring
  · rw [if_neg hn0]
    have hz : ¬ (Squarefree n ∧ n.Coprime (6 * q)) := fun h => hc h.2
    rw [if_neg hz]
    ring

noncomputable def h2BooleanTiltLocalFactor (c : ℝ) (p : ℕ) : ℝ :=
  (p : ℝ) * fixedQShiuPrimeFactor p * c

lemma h2BooleanTiltLocalFactor_nonneg
    {c : ℝ} (hc : 0 ≤ c) (p : ℕ) :
    0 ≤ h2BooleanTiltLocalFactor c p := by
  unfold h2BooleanTiltLocalFactor
  exact mul_nonneg
    (mul_nonneg (by positivity) (fixedQShiuPrimeFactor_nonneg p)) hc

lemma h2BooleanTiltLift_eq_prod
    {q n : ℕ} {c : ℝ} (hn0 : n ≠ 0)
    (hsq : Squarefree n) (hcop : n.Coprime (6 * q)) :
    h2BooleanTiltLift q c n =
      ∏ p ∈ n.primeFactors, h2BooleanTiltLocalFactor c p := by
  rw [h2BooleanTiltLift_apply]
  unfold h2BooleanTiltLiftNat
  rw [fixedQShiuWeight_apply, fixedQShiuWeightNat,
    if_neg hn0, if_pos ⟨hsq, hcop⟩]
  have hnprod := Nat.prod_primeFactors_of_squarefree hsq
  have hnprodR0 := congrArg (fun z : ℕ => (z : ℝ)) hnprod.symm
  have hnprodR : (n : ℝ) =
      ∏ p ∈ n.primeFactors, (p : ℝ) := by
    simpa using hnprodR0
  rw [hnprodR]
  unfold h2BooleanTiltLocalFactor
  rw [Finset.prod_mul_distrib, Finset.prod_mul_distrib]
  rw [Finset.prod_const]

lemma h2BooleanTiltLocalFactor_le_eight
    {c : ℝ} (hc0 : 0 ≤ c) (hc : c ≤ 3 / 2)
    {p : ℕ} (hp : p.Prime) :
    h2BooleanTiltLocalFactor c p ≤ 8 := by
  unfold h2BooleanTiltLocalFactor fixedQShiuPrimeFactor
  by_cases hp5 : 5 ≤ p
  · rw [if_pos hp5]
    have hpR : (5 : ℝ) ≤ p := by exact_mod_cast hp5
    have hden : (0 : ℝ) < (p : ℝ) - 3 := by linarith
    calc
      (p : ℝ) * (2 / ((p : ℝ) - 3)) * c ≤
          (p : ℝ) * (2 / ((p : ℝ) - 3)) * (3 / 2 : ℝ) := by
            exact mul_le_mul_of_nonneg_left hc
              (mul_nonneg (by positivity)
                (div_nonneg (by norm_num) hden.le))
      _ = (3 * (p : ℝ)) / ((p : ℝ) - 3) := by ring
      _ ≤ 8 := by
        apply (div_le_iff₀ hden).2
        nlinarith
  · rw [if_neg hp5]
    simp

lemma h2BooleanTiltLift_prime_le_eight
    (q p : ℕ) {c : ℝ} (hc0 : 0 ≤ c) (hc : c ≤ 3 / 2)
    (hp : p.Prime) :
    h2BooleanTiltLift q c p ≤ 8 := by
  by_cases hcop : p.Coprime (6 * q)
  · rw [h2BooleanTiltLift_eq_prod hp.ne_zero
      (prime_squarefree_local hp) hcop]
    simp [hp, h2BooleanTiltLocalFactor_le_eight hc0 hc hp]
  · rw [h2BooleanTiltLift_eq_zero_of_not_coprime q p c hcop]
    norm_num
noncomputable def h2BooleanShiuGrowthThreshold : ℕ :=
  Classical.choose (exists_nat_gt ((8 : ℝ) ^ (1280 : ℝ)))

lemma h2BooleanShiuGrowthThreshold_spec :
    ((8 : ℝ) ^ (1280 : ℝ)) <
      (h2BooleanShiuGrowthThreshold : ℝ) :=
  Classical.choose_spec (exists_nat_gt ((8 : ℝ) ^ (1280 : ℝ)))

lemma eight_le_rpow_one_div_1280_of_threshold
    {p : ℕ} (hp : h2BooleanShiuGrowthThreshold ≤ p) :
    (8 : ℝ) ≤ (p : ℝ) ^ (1 / 1280 : ℝ) := by
  have h8pos : (0 : ℝ) < 8 := by norm_num
  have hTp :
      (h2BooleanShiuGrowthThreshold : ℝ) ≤ (p : ℝ) := by
    exact_mod_cast hp
  have hbase : (8 : ℝ) ^ (1280 : ℝ) ≤ (p : ℝ) :=
    (le_of_lt h2BooleanShiuGrowthThreshold_spec).trans hTp
  have hr := Real.rpow_le_rpow
    (Real.rpow_nonneg (by norm_num : (0 : ℝ) ≤ 8) _)
    hbase (by norm_num : (0 : ℝ) ≤ 1 / 1280)
  have hroot :
      (((8 : ℝ) ^ (1280 : ℝ)) ^ (1 / 1280 : ℝ)) = 8 := by
    rw [← Real.rpow_mul h8pos.le]
    norm_num
  rw [hroot] at hr
  exact hr

noncomputable def h2BooleanShiuSmallCoeff (p : ℕ) : ℝ :=
  if p < h2BooleanShiuGrowthThreshold then 8 else 1
lemma h2BooleanShiuSmallCoeff_nonneg (p : ℕ) :
    0 ≤ h2BooleanShiuSmallCoeff p := by
  unfold h2BooleanShiuSmallCoeff
  split_ifs <;> norm_num

lemma h2BooleanTiltLocalFactor_le_rpow_of_large
    {c : ℝ} (hc0 : 0 ≤ c) (hc : c ≤ 3 / 2)
    {p : ℕ} (hpPrime : p.Prime)
    (hp : h2BooleanShiuGrowthThreshold ≤ p) :
    h2BooleanTiltLocalFactor c p ≤
      (p : ℝ) ^ (1 / 1280 : ℝ) := by
  exact (h2BooleanTiltLocalFactor_le_eight hc0 hc hpPrime).trans
    (eight_le_rpow_one_div_1280_of_threshold hp)

lemma h2BooleanTiltLocalFactor_le_smallCoeff_mul_rpow
    {c : ℝ} (hc0 : 0 ≤ c) (hc : c ≤ 3 / 2)
    {p : ℕ} (hp : p.Prime) :
    h2BooleanTiltLocalFactor c p ≤
      h2BooleanShiuSmallCoeff p *
        (p : ℝ) ^ (1 / 1280 : ℝ) := by
  by_cases hsmall : p < h2BooleanShiuGrowthThreshold
  · rw [h2BooleanShiuSmallCoeff, if_pos hsmall]
    have hp1 : (1 : ℝ) ≤ (p : ℝ) := by exact_mod_cast hp.one_le
    have hr1 : (1 : ℝ) ≤
        (p : ℝ) ^ (1 / 1280 : ℝ) :=
      Real.one_le_rpow hp1 (by norm_num)
    calc
      h2BooleanTiltLocalFactor c p ≤ 8 :=
        h2BooleanTiltLocalFactor_le_eight hc0 hc hp
      _ ≤ 8 * (p : ℝ) ^ (1 / 1280 : ℝ) := by nlinarith
  · have hlarge : h2BooleanShiuGrowthThreshold ≤ p := by omega
    rw [h2BooleanShiuSmallCoeff, if_neg hsmall, one_mul]
    exact h2BooleanTiltLocalFactor_le_rpow_of_large
      hc0 hc hp hlarge
lemma prod_h2BooleanShiuSmallCoeff_eq_pow (s : Finset ℕ) :
    (∏ p ∈ s, h2BooleanShiuSmallCoeff p) =
      (8 : ℝ) ^
        (s.filter (fun p => p < h2BooleanShiuGrowthThreshold)).card := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [h2BooleanShiuSmallCoeff]
  | @insert a s ha ih =>
      rw [Finset.prod_insert ha]
      by_cases hlt : a < h2BooleanShiuGrowthThreshold
      · have haF :
            a ∉ s.filter (fun p => p < h2BooleanShiuGrowthThreshold) := by
          simp [ha]
        rw [show h2BooleanShiuSmallCoeff a = 8 by
          simp [h2BooleanShiuSmallCoeff, hlt]]
        rw [ih, Finset.filter_insert, if_pos hlt]
        simp [haF, pow_succ']
      · rw [show h2BooleanShiuSmallCoeff a = 1 by
          simp [h2BooleanShiuSmallCoeff, hlt]]
        rw [one_mul, ih, Finset.filter_insert, if_neg hlt]

lemma prod_h2BooleanShiuSmallCoeff_le (s : Finset ℕ) :
    (∏ p ∈ s, h2BooleanShiuSmallCoeff p) ≤
      (8 : ℝ) ^ h2BooleanShiuGrowthThreshold := by
  let t := s.filter (fun p => p < h2BooleanShiuGrowthThreshold)
  have htSub : t ⊆ Finset.range h2BooleanShiuGrowthThreshold := by
    intro p hp
    exact Finset.mem_range.mpr (Finset.mem_filter.mp hp).2
  have hcard : t.card ≤ h2BooleanShiuGrowthThreshold := by
    exact (Finset.card_le_card htSub).trans (by simp)
  rw [prod_h2BooleanShiuSmallCoeff_eq_pow]
  change (8 : ℝ) ^ t.card ≤ (8 : ℝ) ^ h2BooleanShiuGrowthThreshold
  exact pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 8) hcard
lemma h2BooleanTiltLift_growth
    (q n : ℕ) {c : ℝ} (hc0 : 0 ≤ c) (hc : c ≤ 3 / 2) :
    h2BooleanTiltLift q c n ≤
      (8 : ℝ) ^ h2BooleanShiuGrowthThreshold *
        (n : ℝ) ^ (1 / 1280 : ℝ) := by
  by_cases hn0 : n = 0
  · subst n
    simp [h2BooleanTiltLiftNat]
  · by_cases hsq : Squarefree n
    · by_cases hcop : n.Coprime (6 * q)
      · rw [h2BooleanTiltLift_eq_prod hn0 hsq hcop]
        have hprod :
            (∏ p ∈ n.primeFactors, h2BooleanTiltLocalFactor c p) ≤
              ∏ p ∈ n.primeFactors,
                (h2BooleanShiuSmallCoeff p *
                  (p : ℝ) ^ (1 / 1280 : ℝ)) := by
          apply Finset.prod_le_prod₀
          · intro p hp
            exact h2BooleanTiltLocalFactor_nonneg hc0 p
          · intro p hp
            exact h2BooleanTiltLocalFactor_le_smallCoeff_mul_rpow
              hc0 hc (Nat.prime_of_mem_primeFactors hp)
        calc
          (∏ p ∈ n.primeFactors, h2BooleanTiltLocalFactor c p)
              ≤ ∏ p ∈ n.primeFactors,
                  (h2BooleanShiuSmallCoeff p *
                    (p : ℝ) ^ (1 / 1280 : ℝ)) := hprod
          _ = (∏ p ∈ n.primeFactors, h2BooleanShiuSmallCoeff p) *
              (∏ p ∈ n.primeFactors,
                (p : ℝ) ^ (1 / 1280 : ℝ)) := by
                rw [Finset.prod_mul_distrib]
          _ ≤ (8 : ℝ) ^ h2BooleanShiuGrowthThreshold *
              (∏ p ∈ n.primeFactors,
                (p : ℝ) ^ (1 / 1280 : ℝ)) := by
                exact mul_le_mul_of_nonneg_right
                  (prod_h2BooleanShiuSmallCoeff_le n.primeFactors)
                  (Finset.prod_nonneg fun p hp =>
                    Real.rpow_nonneg (by positivity) _)
          _ = (8 : ℝ) ^ h2BooleanShiuGrowthThreshold *
              ((∏ p ∈ n.primeFactors, (p : ℝ)) ^
                (1 / 1280 : ℝ)) := by
                rw [Real.finsetProd_rpow n.primeFactors
                  (fun p => (p : ℝ)) (fun p hp => by positivity)]
          _ = (8 : ℝ) ^ h2BooleanShiuGrowthThreshold *
              (n : ℝ) ^ (1 / 1280 : ℝ) := by
                have hnprod := Nat.prod_primeFactors_of_squarefree hsq
                have hnprodR :
                    (∏ p ∈ n.primeFactors, (p : ℝ)) = (n : ℝ) := by
                  have h := congrArg (fun z : ℕ => (z : ℝ)) hnprod
                  simpa using h
                rw [hnprodR]
      · rw [h2BooleanTiltLift_eq_zero_of_not_coprime q n c hcop]
        exact mul_nonneg (pow_nonneg (by norm_num) _)
          (Real.rpow_nonneg (by positivity) _)
    · rw [h2BooleanTiltLift_squarefree_support q n c hsq]
      exact mul_nonneg (pow_nonneg (by norm_num) _)
        (Real.rpow_nonneg (by positivity) _)

theorem h2BooleanTiltLift_envelope
    (q : ℕ) {c : ℝ} (hc0 : 0 ≤ c) (hc : c ≤ 3 / 2) :
    PaperB.M4B.FixedQuarterEnvelope
      (h2BooleanTiltLift q c) 8
      ((8 : ℝ) ^ h2BooleanShiuGrowthThreshold) := by
  refine ⟨h2BooleanTiltLift_multiplicative q c,
    (fun n => h2BooleanTiltLift_nonneg q n hc0),
    (fun n hn => h2BooleanTiltLift_squarefree_support q n c hn),
    (fun p hp => h2BooleanTiltLift_prime_le_eight q p hc0 hc hp),
    by norm_num, pow_nonneg (by norm_num) _, ?_⟩
  intro n
  simpa using h2BooleanTiltLift_growth q n hc0 hc
theorem h2BooleanTiltLift_progression
    (q : ℕ) {c : ℝ} (hc0 : 0 ≤ c) (hc : c ≤ 3 / 2) :
    ∃ C : ℝ, ∃ X0 : ℕ, ∀ x y k a : ℕ,
      X0 ≤ x →
      (x : ℝ) ^ (1 / 4 : ℝ) < (y : ℝ) →
      y ≤ x →
      (k : ℝ) < (y : ℝ) ^ (3 / 4 : ℝ) →
      0 < a → a < k → a.Coprime k →
      PaperB.M4B.progressionSum (h2BooleanTiltLift q c) x y k a ≤
        C * ((y : ℝ) / ((k.totient : ℝ) * Real.log (x : ℝ))) *
          Real.exp
            (PaperB.M4B.primeMass (h2BooleanTiltLift q c) x k) :=
  PaperB.M4B.shiuFixedQuarter_progression
    (h2BooleanTiltLift_envelope q hc0 hc)

theorem h2BooleanFirstTiltLift_progression (q : ℕ) :
    ∃ C : ℝ, ∃ X0 : ℕ, ∀ x y k a : ℕ,
      X0 ≤ x →
      (x : ℝ) ^ (1 / 4 : ℝ) < (y : ℝ) →
      y ≤ x →
      (k : ℝ) < (y : ℝ) ^ (3 / 4 : ℝ) →
      0 < a → a < k → a.Coprime k →
      PaperB.M4B.progressionSum
          (h2BooleanTiltLift q h2BooleanFirstTilt) x y k a ≤
        C * ((y : ℝ) / ((k.totient : ℝ) * Real.log (x : ℝ))) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanTiltLift q h2BooleanFirstTilt) x k) :=
  h2BooleanTiltLift_progression q h2BooleanFirstTilt_nonneg
    (h2BooleanFirstTilt_le_three_fourths.trans
      (by norm_num : (3 / 4 : ℝ) ≤ 3 / 2))
theorem h2BooleanSecondTiltLift_progression (q : ℕ) :
    ∃ C : ℝ, ∃ X0 : ℕ, ∀ x y k a : ℕ,
      X0 ≤ x →
      (x : ℝ) ^ (1 / 4 : ℝ) < (y : ℝ) →
      y ≤ x →
      (k : ℝ) < (y : ℝ) ^ (3 / 4 : ℝ) →
      0 < a → a < k → a.Coprime k →
      PaperB.M4B.progressionSum
          (h2BooleanTiltLift q h2BooleanSecondTilt) x y k a ≤
        C * ((y : ℝ) / ((k.totient : ℝ) * Real.log (x : ℝ))) *
          Real.exp (PaperB.M4B.primeMass
            (h2BooleanTiltLift q h2BooleanSecondTilt) x k) :=
  h2BooleanTiltLift_progression q h2BooleanSecondTilt_nonneg
    h2BooleanSecondTilt_le_three_halves

lemma h2BooleanTiltLift_prime_term_le
    {q p : ℕ} {c : ℝ} (hc0 : 0 ≤ c) (hc : c ≤ 3 / 2)
    (hp : p.Prime) :
    h2BooleanTiltLift q c p / (p : ℝ) ≤
      (2 * c) * ((p : ℝ)⁻¹) + 24 * ((p : ℝ)⁻¹ ^ 2) := by
  by_cases hcop : p.Coprime (6 * q)
  · have hp5 := prime_ge_five_of_coprime_six hp hcop
    rw [h2BooleanTiltLift_apply]
    unfold h2BooleanTiltLiftNat
    rw [fixedQShiuWeight_prime_eq hp hcop]
    have hcard : p.primeFactors.card = 1 := by simp [hp]
    rw [hcard, pow_one]
    unfold fixedQShiuPrimeFactor
    rw [if_pos hp5]
    have hpR : (5 : ℝ) ≤ p := by exact_mod_cast hp5
    have hp0 : (0 : ℝ) < (p : ℝ) := by positivity
    have hpm3 : (0 : ℝ) < (p : ℝ) - 3 := by linarith
    field_simp [hp0.ne', hpm3.ne']
    nlinarith
  · rw [h2BooleanTiltLift_eq_zero_of_not_coprime q p c hcop]
    simp only [zero_div]
    have hinv0 : 0 ≤ ((p : ℝ)⁻¹) := inv_nonneg.mpr (by positivity)
    have hc2 : 0 ≤ 2 * c := mul_nonneg (by norm_num) hc0
    exact add_nonneg
      (mul_nonneg hc2 hinv0)
      (mul_nonneg (by norm_num) (sq_nonneg ((p : ℝ)⁻¹)))

lemma h2BooleanTiltLift_primeMass_le
    (q X k : ℕ) {c : ℝ} (hc0 : 0 ≤ c) (hc : c ≤ 3 / 2)
    (hX : 4 ≤ X) :
    PaperB.M4B.primeMass (h2BooleanTiltLift q c) X k ≤
      (2 * c) * (Real.log (Real.log (X : ℝ)) + 5) + 24 := by
  classical
  let P : Finset ℕ := X.primesLE.filter fun p => ¬ p ∣ k
  let T : Finset ℕ := Finset.Icc 2 X
  have hterm :
      (∑ p ∈ P, h2BooleanTiltLift q c p / (p : ℝ)) ≤
        ∑ p ∈ P,
          ((2 * c) * ((p : ℝ)⁻¹) + 24 * ((p : ℝ)⁻¹ ^ 2)) := by
    apply Finset.sum_le_sum
    intro p hpP
    have hpPrime : p.Prime :=
      (Nat.mem_primesLE.mp (Finset.mem_filter.mp hpP).1).2
    exact h2BooleanTiltLift_prime_term_le hc0 hc hpPrime
  have hsubset : P ⊆ X.primesLE := by
    intro p hp
    exact (Finset.mem_filter.mp hp).1
  have hrecip :
      (∑ p ∈ P, (1 : ℝ) / p) ≤
        Real.log (Real.log (X : ℝ)) + 5 := by
    calc
      (∑ p ∈ P, (1 : ℝ) / p) ≤
          ∑ p ∈ X.primesLE, (1 : ℝ) / p := by
            exact Finset.sum_le_sum_of_subset_of_nonneg hsubset
              (fun p hp hnot => by positivity)
      _ ≤ Real.log (Real.log (X : ℝ)) + 5 :=
        sum_prime_recip_le_loglog_add_five hX

  have hsubsetT : P ⊆ T := by
    intro p hpP
    have hpLE := Nat.mem_primesLE.mp (Finset.mem_filter.mp hpP).1
    exact Finset.mem_Icc.mpr ⟨hpLE.2.two_le, hpLE.1⟩
  have hsq :
      (∑ p ∈ P, ((p : ℝ)⁻¹ ^ 2)) ≤ 1 := by
    calc
      (∑ p ∈ P, ((p : ℝ)⁻¹ ^ 2)) ≤
          ∑ n ∈ T, ((n : ℝ)⁻¹ ^ 2) := by
            exact Finset.sum_le_sum_of_subset_of_nonneg hsubsetT
              (fun n hn hnot => by positivity)
      _ ≤ 1 := by
        simpa [T] using
          (finite_square_tail_le_inv (F := 1) (M := X) (by norm_num))
  unfold PaperB.M4B.primeMass
  change (∑ p ∈ P, h2BooleanTiltLift q c p / (p : ℝ)) ≤ _
  calc
    (∑ p ∈ P, h2BooleanTiltLift q c p / (p : ℝ))
        ≤ ∑ p ∈ P,
            ((2 * c) * ((p : ℝ)⁻¹) +
              24 * ((p : ℝ)⁻¹ ^ 2)) := hterm
    _ = (2 * c) * (∑ p ∈ P, (1 : ℝ) / p) +
          24 * (∑ p ∈ P, ((p : ℝ)⁻¹ ^ 2)) := by
            simp_rw [one_div]
            rw [Finset.sum_add_distrib, Finset.mul_sum, Finset.mul_sum]
    _ ≤ (2 * c) * (Real.log (Real.log (X : ℝ)) + 5) +
          24 * 1 := by
      exact add_le_add
        (mul_le_mul_of_nonneg_left hrecip
          (mul_nonneg (by norm_num) hc0))
        (mul_le_mul_of_nonneg_left hsq (by norm_num))
    _ = (2 * c) * (Real.log (Real.log (X : ℝ)) + 5) + 24 := by
      ring
lemma h2BooleanTiltLift_exp_primeMass_le
    (q X k : ℕ) {c : ℝ} (hc0 : 0 ≤ c) (hc : c ≤ 3 / 2)
    (hX : 4 ≤ X) :
    Real.exp (PaperB.M4B.primeMass (h2BooleanTiltLift q c) X k) ≤
      Real.exp (10 * c + 24) *
        (Real.log (X : ℝ)) ^ (2 * c) := by
  have hpm := h2BooleanTiltLift_primeMass_le q X k hc0 hc hX
  have hXgt1 : (1 : ℝ) < (X : ℝ) := by
    exact_mod_cast (lt_of_lt_of_le (by norm_num : 1 < 4) hX)
  have hlogpos : 0 < Real.log (X : ℝ) := Real.log_pos hXgt1
  calc
    Real.exp (PaperB.M4B.primeMass (h2BooleanTiltLift q c) X k)
        ≤ Real.exp
            ((2 * c) * (Real.log (Real.log (X : ℝ)) + 5) + 24) :=
          Real.exp_le_exp.mpr hpm
    _ = Real.exp (10 * c + 24) *
          Real.exp (Real.log (Real.log (X : ℝ)) * (2 * c)) := by
            rw [show
              (2 * c) * (Real.log (Real.log (X : ℝ)) + 5) + 24 =
                (10 * c + 24) +
                  Real.log (Real.log (X : ℝ)) * (2 * c) by ring,
              Real.exp_add]
    _ = Real.exp (10 * c + 24) *
          (Real.log (X : ℝ)) ^ (2 * c) := by
            rw [Real.rpow_def_of_pos hlogpos]

lemma two_mul_h2BooleanFirstTilt :
    2 * h2BooleanFirstTilt = h2BooleanX0 := by
  unfold h2BooleanFirstTilt
  ring

lemma two_mul_h2BooleanSecondTilt :
    2 * h2BooleanSecondTilt = h2BooleanV0 := by
  unfold h2BooleanSecondTilt
  ring
lemma h2BooleanSecondTiltLift_exp_primeMass_le
    (q X k : ℕ) (hX : 4 ≤ X) :
    Real.exp
        (PaperB.M4B.primeMass
          (h2BooleanTiltLift q h2BooleanSecondTilt) X k) ≤
      Real.exp (10 * h2BooleanSecondTilt + 24) *
        (Real.log (X : ℝ)) ^ h2BooleanV0 := by
  have h := h2BooleanTiltLift_exp_primeMass_le
    q X k h2BooleanSecondTilt_nonneg
      h2BooleanSecondTilt_le_three_halves hX
  rwa [two_mul_h2BooleanSecondTilt] at h

lemma h2BooleanFirstTiltLift_exp_primeMass_le
    (q X k : ℕ) (hX : 4 ≤ X) :
    Real.exp
        (PaperB.M4B.primeMass
          (h2BooleanTiltLift q h2BooleanFirstTilt) X k) ≤
      Real.exp (10 * h2BooleanFirstTilt + 24) *
        (Real.log (X : ℝ)) ^ h2BooleanX0 := by
  have hc :
      h2BooleanFirstTilt ≤ (3 / 2 : ℝ) :=
    h2BooleanFirstTilt_le_three_fourths.trans (by norm_num)
  have h := h2BooleanTiltLift_exp_primeMass_le
    q X k h2BooleanFirstTilt_nonneg hc hX
  rwa [two_mul_h2BooleanFirstTilt] at h

#print axioms h2BooleanTiltLift_envelope
#print axioms h2BooleanFirstTiltLift_progression
#print axioms h2BooleanSecondTiltLift_progression
#print axioms h2BooleanTiltLift_primeMass_le
#print axioms h2BooleanTiltLift_exp_primeMass_le
#print axioms h2BooleanSecondTiltLift_exp_primeMass_le

end PaperB.FixedQ
