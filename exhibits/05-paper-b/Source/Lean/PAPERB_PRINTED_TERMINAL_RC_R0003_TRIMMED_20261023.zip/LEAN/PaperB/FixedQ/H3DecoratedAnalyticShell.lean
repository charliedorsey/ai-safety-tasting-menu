import PaperB.FixedQ.H3DecoratedBooleanClosureBridge
import PaperB.FixedQ.H3SmallHeightL1
import PaperB.Closure

open scoped BigOperators

namespace PaperB.FixedQ

theorem summable_ordinaryBooleanCoreTerm
    {q a h : ℕ}
    (hq : 0 < q)
    (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    Summable (ordinaryBooleanCoreTerm q a h) := by
  let b := a + h
  let r := PaperB.Closure.reflectedResidue q b
  have hcompat : Nat.ModEq q (a + h) b := Nat.ModEq.refl _
  have hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z) := by
    dsimp [r]
    exact PaperB.Closure.reflected_coprime_equiv hq hcompat
  have hsR := summable_twoDimensionalPerE hreflect
  have hsO := hsR.indicator (ordinaryTwoDimensionalSet h)
  have hsD := summable_ordinaryDensityCoreTerm
    (q := q) (a := a) (h := h) hq hh h2admissible
  have hterm :
      ∀ e : Finset ℕ,
        (ordinaryTwoDimensionalSet h).indicator
            (twoDimensionalPerE q a h) e =
          ordinaryBooleanCoreTerm q a h e +
            ordinaryDensityCoreTerm q a h e := by
    intro e
    by_cases hOrd : e ∈ ordinaryTwoDimensionalSet h
    · by_cases hA : ∀ p ∈ e, activeHighPrime q p
      · have hAct : e ∈ activeOrdinaryTwoDimensionalSet q h := ⟨hOrd, hA⟩
        rw [Set.indicator_of_mem hOrd]
        rw [twoDimensionalPerE_ordinary_decompose hOrd hA]
        simp [ordinaryBooleanCoreTerm, ordinaryDensityCoreTerm,
          Set.indicator, hAct]
        ring
      · have hnot : ¬ ∀ p ∈ e, activeHighPrime q p := hA
        rw [Set.indicator_of_mem hOrd]
        rw [twoDimensionalPerE_eq_zero_of_not_all_active hnot]
        have hActNot : e ∉ activeOrdinaryTwoDimensionalSet q h := by
          intro he
          exact hA he.2
        simp [ordinaryBooleanCoreTerm, ordinaryDensityCoreTerm,
          Set.indicator, hActNot]
    · have hActNot : e ∉ activeOrdinaryTwoDimensionalSet q h := by
        intro he
        exact hOrd he.1
      simp [Set.indicator, hOrd, ordinaryBooleanCoreTerm,
        ordinaryDensityCoreTerm, hActNot]
  have hsSum :
      Summable (fun e : Finset ℕ =>
        ordinaryBooleanCoreTerm q a h e +
          ordinaryDensityCoreTerm q a h e) :=
    hsO.congr hterm
  exact (hsSum.sub hsD).congr (fun e => by ring)

theorem summable_abs_ordinaryBooleanCoreTerm
    {q a h : ℕ}
    (hq : 0 < q)
    (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h) :
    Summable (fun n : Finset ℕ => |ordinaryBooleanCoreTerm q a h n|) := by
  simpa [Real.norm_eq_abs] using
    (summable_ordinaryBooleanCoreTerm hq hh h2admissible).norm

lemma decoratedHeightPowerset_active_height
    {q h : ℕ} {d : Finset ℕ}
    (hd : d ∈ (decoratedHeightPrimeSet q h).powerset) :
    (∀ p ∈ d, activeHighPrime q p) ∧
      (∀ p ∈ d, p ∣ h) := by
  have hsub : d ⊆ decoratedHeightPrimeSet q h :=
    Finset.mem_powerset.mp hd
  refine ⟨decoratedHeightPrimeSet_active hsub, ?_⟩
  intro p hp
  have hmem := Finset.mem_filter.mp (hsub hp)
  exact Nat.dvd_of_mem_primeFactors hmem.1

lemma heightPrimePart_eq_self_of_mem_decoratedHeightPowerset
    {q h : ℕ} {d : Finset ℕ}
    (hd : d ∈ (decoratedHeightPrimeSet q h).powerset) :
    heightPrimePart h d = d := by
  have hH := (decoratedHeightPowerset_active_height hd).2
  ext p
  simp only [heightPrimePart, Finset.mem_filter]
  constructor
  · exact fun hp => hp.1
  · intro hp
    exact ⟨hp, hH p hp⟩

lemma decoratedReducedHeight_pos_of_mem
    {q h : ℕ} {d : Finset ℕ}
    (hh : 0 < h)
    (hd : d ∈ (decoratedHeightPrimeSet q h).powerset) :
    0 < h / primeSetProduct d := by
  have hA := (decoratedHeightPowerset_active_height hd).1
  have hall := heightPrimePart_eq_self_of_mem_decoratedHeightPowerset hd
  have hfact0 := decoratedHeightProduct_mul_reducedHeight
    (q := q) (h := h) (e := d) hA
  have hfact :
      primeSetProduct d * (h / primeSetProduct d) = h := by
    simpa [decoratedHeightProduct, decoratedReducedHeight, hall] using hfact0
  by_contra hzero
  have hHz : h / primeSetProduct d = 0 := Nat.eq_zero_of_not_pos hzero
  rw [hHz, mul_zero] at hfact
  exact (Nat.ne_of_gt hh) hfact.symm

lemma decoratedReducedHeight_parity_of_mem
    {q h : ℕ} {d : Finset ℕ}
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h)
    (hd : d ∈ (decoratedHeightPrimeSet q h).powerset) :
    ¬ 2 ∣ q → 2 ∣ h / primeSetProduct d := by
  have hA := (decoratedHeightPowerset_active_height hd).1
  have hall := heightPrimePart_eq_self_of_mem_decoratedHeightPowerset hd
  simpa [decoratedReducedHeight, decoratedHeightProduct, hall] using
    (decoratedReducedHeight_parity_admissible
      (q := q) (h := h) (e := d) hA h2admissible)

lemma decoratedReducedAnchor_coprime_of_mem
    {q a h : ℕ} {d : Finset ℕ}
    (hq : 0 < q)
    (ha : q.Coprime a)
    (hd : d ∈ (decoratedHeightPrimeSet q h).powerset) :
    q.Coprime (decoratedReducedAnchor q a (primeSetProduct d)) := by
  have hA := (decoratedHeightPowerset_active_height hd).1
  have hall := heightPrimePart_eq_self_of_mem_decoratedHeightPowerset hd
  have hDq0 := decoratedHeightProduct_coprime_q
    (q := q) (h := h) (e := d) hA
  have hDq : (primeSetProduct d).Coprime q := by
    simpa [decoratedHeightProduct, hall] using hDq0
  exact fixedQReducedAnchor_coprime ha
    (decoratedReducedAnchor_modEq
      (q := q) (a := a) (d := primeSetProduct d) hq hDq)

lemma decoratedReducedHeight_le_outer
    (h : ℕ) (d : Finset ℕ) :
    h / primeSetProduct d ≤ h :=
  Nat.div_le_self _ _

theorem decoratedReducedOrdinaryParameters
    {q a h : ℕ} {d : Finset ℕ}
    (hq : 0 < q)
    (ha : q.Coprime a)
    (hh : 0 < h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h)
    (hd : d ∈ (decoratedHeightPrimeSet q h).powerset) :
    0 < h / primeSetProduct d ∧
    q.Coprime (decoratedReducedAnchor q a (primeSetProduct d)) ∧
    (¬ 2 ∣ q → 2 ∣ h / primeSetProduct d) ∧
    h / primeSetProduct d ≤ h := by
  exact ⟨decoratedReducedHeight_pos_of_mem hh hd,
    decoratedReducedAnchor_coprime_of_mem hq ha hd,
    decoratedReducedHeight_parity_of_mem h2admissible hd,
    decoratedReducedHeight_le_outer h d⟩

theorem abs_cStar_mul_decoratedAnalyticRemainder_le_height_mass_of_boolean_l1_split
    {q a h H0 : ℕ} {Q B : ℝ}
    (hq : 0 < q)
    (ha : q.Coprime a)
    (hh : 16 ≤ h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h)
    (hQ : 0 ≤ Q) (hB0 : 0 ≤ B)
    (hLarge :
      ∀ A H : ℕ,
        q.Coprime A →
        0 < H →
        (¬ 2 ∣ q → 2 ∣ H) →
        H ≤ h →
        H0 ≤ H →
        ordinaryBooleanAbsFamily q A H ≤ Q)
    (hSmall :
      ∀ A H : ℕ,
        q.Coprime A →
        0 < H →
        (¬ 2 ∣ q → 2 ∣ H) →
        H < H0 →
        ordinaryBooleanAbsFamily q A H ≤ B) :
    |cStarReal q h * decoratedAnalyticRemainder q a h| ≤
      (weakDecoratedMertensC * Real.log (Real.log (h : ℝ))) * (Q + B) := by
  have hhpos : 0 < h := lt_of_lt_of_le (by norm_num) hh
  let r := PaperB.Closure.reflectedResidue q (a + h)
  have hreflect : ∀ z ∈ Finset.Ioo 0 h,
      q.Coprime (a + (h - z)) ↔ q.Coprime (r + z) := by
    dsimp [r]
    exact PaperB.Closure.reflected_coprime_equiv hq (Nat.ModEq.refl _)
  have hAbs : ∀ d ∈ (decoratedHeightPrimeSet q h).powerset,
      Summable (fun n : Finset ℕ =>
        |ordinaryBooleanCoreTerm q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) n|) := by
    intro d hd
    have hp := decoratedReducedOrdinaryParameters
      hq ha hhpos h2admissible hd
    exact summable_abs_ordinaryBooleanCoreTerm hq hp.1 hp.2.2.1
  let bound : Finset ℕ → ℝ := fun d =>
    if H0 ≤ h / primeSetProduct d then Q else B
  have hBound :
      ∀ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
        ordinaryBooleanAbsFamily q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) ≤ bound d := by
    intro d hdErase
    have hd : d ∈ (decoratedHeightPrimeSet q h).powerset :=
      (Finset.mem_erase.mp hdErase).2
    have hp := decoratedReducedOrdinaryParameters
      hq ha hhpos h2admissible hd
    dsimp [bound]
    by_cases hLH : H0 ≤ h / primeSetProduct d
    · rw [if_pos hLH]
      exact hLarge _ _ hp.2.1 hp.1 hp.2.2.1 hp.2.2.2 hLH
    · rw [if_neg hLH]
      exact hSmall _ _ hp.2.1 hp.1 hp.2.2.1 (Nat.lt_of_not_ge hLH)
  have hlive :
      |cStarReal q h * decoratedAnalyticRemainder q a h| ≤
        ∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
          finiteVWeightReal h d * bound d := by
    exact abs_cStar_mul_decoratedAnalyticRemainder_le_of_boolean_bounds
      hq hhpos h2admissible hreflect bound hAbs hBound
  have hQB : 0 ≤ Q + B := add_nonneg hQ hB0
  have hterm :
      ∀ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
        finiteVWeightReal h d * bound d ≤
          finiteVWeightReal h d * (Q + B) := by
    intro d hdErase
    have hd : d ∈ (decoratedHeightPrimeSet q h).powerset :=
      (Finset.mem_erase.mp hdErase).2
    have hv0 : 0 ≤ finiteVWeightReal h d := by
      apply finiteVWeightReal_nonneg_of_active
      exact decoratedHeightPrimeSet_active (Finset.mem_powerset.mp hd)
    dsimp [bound]
    by_cases hLH : H0 ≤ h / primeSetProduct d
    · rw [if_pos hLH]
      exact mul_le_mul_of_nonneg_left (le_add_of_nonneg_right hB0) hv0
    · rw [if_neg hLH]
      exact mul_le_mul_of_nonneg_left (le_add_of_nonneg_left hQ) hv0
  have hsum :
      (∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
          finiteVWeightReal h d * bound d) ≤
        (∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
          finiteVWeightReal h d * (Q + B)) := by
    exact Finset.sum_le_sum hterm
  have hmassSubset :
      (∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
        finiteVWeightReal h d) ≤
      ∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
        finiteVWeightReal h d := by
    apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.erase_subset _ _)
    intro d hdFull hdNot
    apply finiteVWeightReal_nonneg_of_active
    exact decoratedHeightPrimeSet_active (Finset.mem_powerset.mp hdFull)
  have hmass :
      (∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
        finiteVWeightReal h d) ≤
          weakDecoratedMertensC * Real.log (Real.log (h : ℝ)) :=
    (sum_decorated_finiteVWeightReal_lt_weakMertens
      (q := q) hh).le
  calc
    |cStarReal q h * decoratedAnalyticRemainder q a h|
      ≤ ∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
          finiteVWeightReal h d * bound d := hlive
    _ ≤ ∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
          finiteVWeightReal h d * (Q + B) := hsum
    _ = (∑ d ∈ (decoratedHeightPrimeSet q h).powerset.erase ∅,
          finiteVWeightReal h d) * (Q + B) := by
          rw [Finset.sum_mul]
    _ ≤ (∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
          finiteVWeightReal h d) * (Q + B) := by
          exact mul_le_mul_of_nonneg_right hmassSubset hQB
    _ ≤ (weakDecoratedMertensC * Real.log (Real.log (h : ℝ))) *
          (Q + B) := by
          exact mul_le_mul_of_nonneg_right hmass hQB

/-- Decorated analytic shell with the bounded reduced-height Boolean L1 input
paid internally by the fixed-q finite small-height envelope.  The only
remaining analytic hypothesis is the large-height quantitative Boolean L1
bound. -/
theorem abs_cStar_mul_decoratedAnalyticRemainder_le_height_mass_of_large_boolean_l1
    {q a h H0 : ℕ} {Q : ℝ}
    (hq : 0 < q)
    (ha : q.Coprime a)
    (hh : 16 ≤ h)
    (h2admissible : ¬ 2 ∣ q → 2 ∣ h)
    (hQ : 0 ≤ Q)
    (hLarge :
      ∀ A H : ℕ,
        q.Coprime A →
        0 < H →
        (¬ 2 ∣ q → 2 ∣ H) →
        H ≤ h →
        H0 ≤ H →
        ordinaryBooleanAbsFamily q A H ≤ Q) :
    ∃ B : ℝ, 0 ≤ B ∧
      |cStarReal q h * decoratedAnalyticRemainder q a h| ≤
        (weakDecoratedMertensC * Real.log (Real.log (h : ℝ))) * (Q + B) := by
  rcases ordinaryBooleanCore_abs_l1_smallHeight_uniform q H0 hq with
    ⟨B, hB0, hSmall0⟩
  refine ⟨B, hB0, ?_⟩
  apply abs_cStar_mul_decoratedAnalyticRemainder_le_height_mass_of_boolean_l1_split
    hq ha hh h2admissible hQ hB0 hLarge
  intro A H hA hH h2H hlt
  simpa [ordinaryBooleanAbsFamily] using hSmall0 A H hA h2H hH hlt

#print axioms summable_ordinaryBooleanCoreTerm
#print axioms summable_abs_ordinaryBooleanCoreTerm
#print axioms decoratedReducedOrdinaryParameters
#print axioms abs_cStar_mul_decoratedAnalyticRemainder_le_height_mass_of_boolean_l1_split
#print axioms abs_cStar_mul_decoratedAnalyticRemainder_le_height_mass_of_large_boolean_l1

end PaperB.FixedQ
