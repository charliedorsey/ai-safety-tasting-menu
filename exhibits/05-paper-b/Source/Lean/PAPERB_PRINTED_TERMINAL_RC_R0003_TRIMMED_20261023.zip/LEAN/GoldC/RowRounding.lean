import GoldC.SourceCore
import Mathlib.Data.Int.CardIntervalMod

/-!
# `GoldC.RowRounding` — the exact rounding mechanism of the Central row discrepancy

Source-native, hypothesis-free facts about the packet's `rowDiscrepancy`:

* `occupiedWeight_periodic`: the source weight `λ = occupiedWeight q a H` is periodic with period
  `6q` in `y`.
* `rowCount_eq_saw` (**rounding identity**): for coprime `r, s ≥ 2` both coprime to `H`,
  `#{0 < y < H : r ∣ y, s ∣ H - y} = H/(rs) - ψ(H·r̄/s) - ψ(H·s̄/r)`,
  where `ψ(x) = {x} - 1/2`, `r̄ = r⁻¹ mod s`, `s̄ = s⁻¹ mod r`.
* `rowCount_swap`: the identity is symmetric in `(r, s)`, so the two oriented pairs `B` and `e \ B`
  carry *equal* main terms (no antisymmetry).
-/

open scoped BigOperators Classical
open Finset

namespace GoldC

/-- The sawtooth `ψ(x) = {x} - 1/2`. -/
noncomputable def saw (x : ℝ) : ℝ := Int.fract x - 1 / 2

/-- `r⁻¹ mod s`, as a natural number in `[0, s)`. -/
noncomputable def invMod (r s : ℕ) : ℕ := ((r : ZMod s)⁻¹).val

/-- The number of `y ∈ (0, H)` with `r ∣ y` and `s ∣ H - y`. -/
noncomputable def rowCount (H r s : ℕ) : ℕ :=
  ((Finset.Ioo 0 H).filter (fun y => r ∣ y ∧ s ∣ H - y)).card

/-! ## Periodicity of the source weight -/

lemma tripleOccupiedCount_add (p H y k : ℕ) (hp : p ∣ k) :
    tripleOccupiedCount p H (y + k) = tripleOccupiedCount p H y := by
  unfold tripleOccupiedCount
  have : (y + k) % p = y % p := by
    obtain ⟨m, rfl⟩ := hp; simp [Nat.add_mul_mod_self_left]
  rw [this]

/-- **The source weight is `6q`-periodic.** -/
theorem occupiedWeight_periodic (q a H y : ℕ) :
    occupiedWeight q a H (y + 6 * q) = occupiedWeight q a H y := by
  unfold occupiedWeight
  congr 1
  · congr 1
    have : a + (y + 6 * q) = a + y + q * 6 := by ring
    rw [this]
    exact propext (Nat.coprime_add_mul_left_right _ _ _)
  · refine Finset.prod_congr rfl fun p hp => ?_
    have hp' : p = 2 ∨ p = 3 := by simpa [lowPrimeSet] using hp
    have hdvd : p ∣ 6 * q := by
      rcases hp' with rfl | rfl
      · exact Dvd.dvd.mul_right (by norm_num) _
      · exact Dvd.dvd.mul_right (by norm_num) _
    unfold occupiedLocalRatio
    rw [tripleOccupiedCount_add p H y _ hdvd]

/-! ## Modular inverses and reciprocity -/

lemma mul_invMod_modEq {r s : ℕ} (hs : 2 ≤ s) (h : r.Coprime s) :
    r * invMod r s ≡ 1 [MOD s] := by
  have : NeZero s := ⟨by omega⟩
  rw [← ZMod.natCast_eq_natCast_iff]
  push_cast
  unfold invMod
  rw [ZMod.natCast_val, ZMod.cast_id', id, ZMod.coe_mul_inv_eq_one _ h]

lemma invMod_lt {r s : ℕ} (hs : 2 ≤ s) : invMod r s < s := by
  have : NeZero s := ⟨by omega⟩
  exact ZMod.val_lt _

lemma invMod_pos {r s : ℕ} (hs : 2 ≤ s) (h : r.Coprime s) : 0 < invMod r s := by
  rcases Nat.eq_zero_or_pos (invMod r s) with h0 | h0
  · have := mul_invMod_modEq hs h
    rw [h0, mul_zero] at this
    have h1 : 1 % s = 0 := this.symm
    rw [Nat.one_mod_eq_zero_iff] at h1
    omega
  · exact h0

/-- **Reciprocity**: `r·(r⁻¹ mod s) + s·(s⁻¹ mod r) = rs + 1`. -/
theorem reciprocity {r s : ℕ} (hr : 2 ≤ r) (hs : 2 ≤ s) (h : r.Coprime s) :
    r * invMod r s + s * invMod s r = r * s + 1 := by
  set u := invMod r s
  set v := invMod s r
  have hu := mul_invMod_modEq hs h
  have hv := mul_invMod_modEq hr h.symm
  have hu1 := invMod_lt (r := r) hs
  have hv1 := invMod_lt (r := s) hr
  have hu0 := invMod_pos hs h
  have hv0 := invMod_pos hr h.symm
  -- `X ≡ 1` modulo `s` and modulo `r`
  have h1 : r * u + s * v ≡ 1 [MOD s] := by
    have : s * v ≡ 0 [MOD s] := Nat.modEq_zero_iff_dvd.2 (dvd_mul_right _ _)
    simpa using hu.add this
  have h2 : r * u + s * v ≡ 1 [MOD r] := by
    have : r * u ≡ 0 [MOD r] := Nat.modEq_zero_iff_dvd.2 (dvd_mul_right _ _)
    simpa using this.add hv
  have h3 : r * u + s * v ≡ 1 [MOD r * s] :=
    (Nat.modEq_and_modEq_iff_modEq_mul h).1 ⟨h2, h1⟩
  have hrs : 4 ≤ r * s := by nlinarith
  have hmod : (r * u + s * v) % (r * s) = 1 := by
    rw [h3]; exact Nat.one_mod_eq_one.2 (by omega)
  have hb1 : r * u + r ≤ r * s := by
    have := Nat.mul_le_mul_left r (show u + 1 ≤ s by omega)
    rw [Nat.mul_add, mul_one] at this; exact this
  have hb2 : s * v + s ≤ r * s := by
    have := Nat.mul_le_mul_left s (show v + 1 ≤ r by omega)
    rw [Nat.mul_add, mul_one, mul_comm s r] at this; exact this
  have hl1 : r ≤ r * u := Nat.le_mul_of_pos_right r hu0
  have hl2 : s ≤ s * v := Nat.le_mul_of_pos_right s hv0
  have hdiv := Nat.div_add_mod (r * u + s * v) (r * s)
  rw [hmod] at hdiv
  have hXlt : r * u + s * v < r * s * 2 := by omega
  have hXge : 2 ≤ r * u + s * v := by omega
  generalize hk : (r * u + s * v) / (r * s) = k at hdiv
  have hk2 : k < 2 := by
    by_contra hk'; push Not at hk'
    have : r * s * 2 ≤ r * s * k := Nat.mul_le_mul_left _ hk'
    omega
  have hk1 : k ≠ 0 := by
    rintro rfl; rw [mul_zero] at hdiv; omega
  have : k = 1 := by omega
  rw [this, mul_one] at hdiv
  omega

/-! ## The rounding identity -/

section Rounding

variable {H r s : ℕ}

/-- The CRT residue `c ≡ 0 (mod r)`, `c ≡ H (mod s)` of the constrained progression. -/
noncomputable def crtResidue (H r s : ℕ) : ℕ := r * ((H * invMod r s) % s)

lemma crtResidue_modEq_s (hs : 2 ≤ s) (h : r.Coprime s) :
    crtResidue H r s ≡ H [MOD s] := by
  unfold crtResidue
  have hu := mul_invMod_modEq hs h
  calc r * ((H * invMod r s) % s) ≡ r * (H * invMod r s) [MOD s] :=
        Nat.ModEq.mul_left _ (Nat.mod_modEq _ _)
    _ = H * (r * invMod r s) := by ring
    _ ≡ H * 1 [MOD s] := Nat.ModEq.mul_left _ hu
    _ = H := mul_one H

lemma crtResidue_dvd_r : r ∣ crtResidue H r s := dvd_mul_right _ _

lemma crtResidue_pos (hs : 2 ≤ s) (h : r.Coprime s) (hsH : s.Coprime H) (hr : 1 ≤ r) :
    0 < crtResidue H r s := by
  unfold crtResidue
  apply Nat.mul_pos (by omega)
  apply Nat.pos_of_ne_zero
  intro h0
  have hd : s ∣ H * invMod r s := Nat.dvd_of_mod_eq_zero h0
  have hcu : s.Coprime (invMod r s) := by
    have hu := mul_invMod_modEq hs h
    unfold Nat.ModEq at hu
    rw [Nat.one_mod_eq_one.2 (by omega)] at hu
    have hg1 : Nat.gcd s (invMod r s) ∣ (r * invMod r s) % s :=
      (Nat.dvd_mod_iff (Nat.gcd_dvd_left _ _)).2
        (Dvd.dvd.mul_left (Nat.gcd_dvd_right _ _) r)
    rw [hu] at hg1
    exact Nat.eq_one_of_dvd_one hg1
  have hsH' : s ∣ H := hcu.dvd_of_dvd_mul_right hd
  have : s ∣ 1 := by
    have := Nat.Coprime.eq_one_of_dvd hsH hsH'
    omega
  have := Nat.le_of_dvd one_pos this
  omega

lemma crtResidue_lt (hs : 2 ≤ s) (hr : 1 ≤ r) : crtResidue H r s < r * s := by
  unfold crtResidue
  exact Nat.mul_lt_mul_of_pos_left (Nat.mod_lt _ (by omega)) (by omega)

/-- The constraint `r ∣ y ∧ s ∣ H - y` (with `y < H`) is the single class `y ≡ c (mod rs)`. -/
lemma constraint_iff (hs : 2 ≤ s) (h : r.Coprime s) {y : ℕ} (hy : y ≤ H) :
    (r ∣ y ∧ s ∣ H - y) ↔ y ≡ crtResidue H r s [MOD r * s] := by
  have hcr : crtResidue H r s ≡ 0 [MOD r] := Nat.modEq_zero_iff_dvd.2 crtResidue_dvd_r
  have hcs := crtResidue_modEq_s (H := H) hs h
  constructor
  · rintro ⟨h1, h2⟩
    have e1 : y ≡ crtResidue H r s [MOD r] := (Nat.modEq_zero_iff_dvd.2 h1).trans hcr.symm
    have e2 : y ≡ crtResidue H r s [MOD s] := ((Nat.modEq_iff_dvd' hy).2 h2).trans hcs.symm
    exact (Nat.modEq_and_modEq_iff_modEq_mul h).1 ⟨e1, e2⟩
  · intro he
    have e := (Nat.modEq_and_modEq_iff_modEq_mul h).2 he
    refine ⟨Nat.modEq_zero_iff_dvd.1 (e.1.trans hcr), ?_⟩
    exact (Nat.modEq_iff_dvd' hy).1 (e.2.trans hcs)

end Rounding

section Count

variable {H r s : ℕ}

/-- `rowCount` as a ceiling: `#{0 < y < H : y ≡ c (rs)} = max ⌈(H - c)/(rs)⌉ 0`. -/
lemma rowCount_eq_ceil (hr : 2 ≤ r) (hs : 2 ≤ s) (h : r.Coprime s) (hsH : s.Coprime H) :
    (rowCount H r s : ℤ) =
      max ⌈((H : ℚ) - crtResidue H r s) / ((r * s : ℕ) : ℚ)⌉ 0 := by
  have hn : 0 < r * s := by positivity
  have hc0 := crtResidue_pos (H := H) hs h hsH (by omega)
  have hc1 := crtResidue_lt (H := H) hs (by omega : 1 ≤ r)
  have hset : (Finset.Ioo 0 H).filter (fun y => r ∣ y ∧ s ∣ H - y) =
      (Finset.Ico 1 H).filter (fun y => y ≡ crtResidue H r s [MOD r * s]) := by
    ext y
    simp only [Finset.mem_filter, Finset.mem_Ioo, Finset.mem_Ico]
    constructor
    · rintro ⟨⟨h1, h2⟩, h3⟩
      exact ⟨⟨h1, h2⟩, (constraint_iff hs h h2.le).1 h3⟩
    · rintro ⟨⟨h1, h2⟩, h3⟩
      exact ⟨⟨h1, h2⟩, (constraint_iff hs h h2.le).2 h3⟩
  unfold rowCount
  rw [hset, Nat.Ico_filter_modEq_card _ _ hn]
  have hzero : ⌈((1 : ℕ) - (crtResidue H r s : ℚ)) / ((r * s : ℕ) : ℚ)⌉ = 0 := by
    rw [Int.ceil_eq_iff]
    have hnq : (0 : ℚ) < ((r * s : ℕ) : ℚ) := by exact_mod_cast hn
    have hc0' : (1 : ℚ) ≤ crtResidue H r s := by exact_mod_cast hc0
    have hc1' : (crtResidue H r s : ℚ) < ((r * s : ℕ) : ℚ) := by exact_mod_cast hc1
    constructor
    · rw [lt_div_iff₀ hnq]; push_cast at hc1' ⊢; linarith
    · rw [div_le_iff₀ hnq]; push_cast; linarith
  rw [hzero, sub_zero]

/-- **The rounding identity.** For coprime `r, s ≥ 2`, both coprime to `H`,
`#{0 < y < H : r ∣ y, s ∣ H - y} = H/(rs) - ψ(H r̄/s) - ψ(H s̄/r)`. -/
theorem rowCount_eq_saw (hr : 2 ≤ r) (hs : 2 ≤ s) (h : r.Coprime s) (hrH : r.Coprime H)
    (hsH : s.Coprime H) :
    (rowCount H r s : ℝ) = (H : ℝ) / ((r : ℝ) * s) -
      saw ((H : ℝ) * invMod r s / s) - saw ((H : ℝ) * invMod s r / r) := by
  have hn : 0 < r * s := by positivity
  have hnR : (0 : ℝ) < (r : ℝ) * s := by exact_mod_cast hn
  have hrR : (0 : ℝ) < r := by exact_mod_cast (by omega : 0 < r)
  have hsR : (0 : ℝ) < s := by exact_mod_cast (by omega : 0 < s)
  set c := crtResidue H r s with hcdef
  have hc0 := crtResidue_pos (H := H) hs h hsH (by omega)
  have hc1 := crtResidue_lt (H := H) hs (by omega : 1 ≤ r)
  set x : ℝ := ((H : ℝ) - c) / ((r : ℝ) * s) with hx
  -- the ceiling over `ℚ` is the ceiling over `ℝ`
  have hceil : (rowCount H r s : ℤ) = max ⌈x⌉ 0 := by
    rw [rowCount_eq_ceil hr hs h hsH, ← Rat.ceil_cast (α := ℝ)]
    congr 2
    rw [hx]; push_cast; rfl
  -- `x` is not an integer
  have hfr : Int.fract x ≠ 0 := by
    intro h0
    have hfl := Int.floor_add_fract x
    rw [h0, add_zero] at hfl
    set m := ⌊x⌋
    have hm' : (H : ℝ) - c = (r : ℝ) * s * m := by
      rw [hfl, hx]; field_simp
    have hmz : (H : ℤ) - c = (r * s : ℤ) * m := by exact_mod_cast hm'
    have hrc : (r : ℤ) ∣ (c : ℤ) := by exact_mod_cast crtResidue_dvd_r
    have hrH' : (r : ℤ) ∣ (H : ℤ) := by
      have : (H : ℤ) = c + (r * s : ℤ) * m := by linarith
      rw [this]; exact dvd_add hrc (Dvd.dvd.mul_right (dvd_mul_right _ _) _)
    have : r ∣ H := by exact_mod_cast hrH'
    have := Nat.Coprime.eq_one_of_dvd hrH this
    omega
  have hxgt : -1 < x := by
    rw [hx, lt_div_iff₀ hnR]
    have : (c : ℝ) < (r : ℝ) * s := by exact_mod_cast hc1
    have : (0 : ℝ) ≤ H := Nat.cast_nonneg _
    linarith
  have hceil_eq : ⌈x⌉ = ⌊x⌋ + 1 := by
    rw [Int.ceil_eq_iff]
    push_cast
    have h1 := Int.floor_le x
    have h2 := Int.lt_floor_add_one x
    have h3 : (⌊x⌋ : ℝ) ≠ x := by
      intro he; apply hfr; unfold Int.fract; linarith
    constructor
    · have := lt_of_le_of_ne h1 h3; linarith
    · linarith
  have hfl : (0 : ℤ) ≤ ⌊x⌋ + 1 := by
    have : (-1 : ℤ) ≤ ⌊x⌋ := by
      rw [Int.le_floor]; push_cast; linarith
    omega
  have hcount : (rowCount H r s : ℝ) = x - Int.fract x + 1 := by
    have : (rowCount H r s : ℤ) = ⌊x⌋ + 1 := by
      rw [hceil, hceil_eq, max_eq_left hfl]
    have : (rowCount H r s : ℝ) = ((⌊x⌋ + 1 : ℤ) : ℝ) := by exact_mod_cast this
    rw [this, Int.fract]; push_cast; ring
  -- `c/(rs) = {H r̄/s}`
  have hcs : (c : ℝ) / ((r : ℝ) * s) = Int.fract ((H : ℝ) * invMod r s / s) := by
    have : ((H : ℝ) * invMod r s / s) = (((H * invMod r s : ℕ) : ℝ) / (s : ℕ)) := by push_cast; rfl
    rw [this, Int.fract_div_natCast_eq_div_natCast_mod, hcdef, crtResidue]
    push_cast
    field_simp
  -- `{x} = {H s̄/r}` by reciprocity
  have hrec := reciprocity hr hs h
  have hrecR : (r : ℝ) * invMod r s + s * invMod s r = r * s + 1 := by exact_mod_cast hrec
  have hsum : (H : ℝ) * invMod r s / s + (H : ℝ) * invMod s r / r = H + H / ((r : ℝ) * s) := by
    field_simp
    linear_combination (H : ℝ) * hrecR
  have hxeq : x = (H : ℝ) * invMod s r / r +
      ((⌊(H : ℝ) * invMod r s / s⌋ : ℝ) - (H : ℤ)) := by
    rw [hx, sub_div, hcs]
    have := Int.floor_add_fract ((H : ℝ) * invMod r s / s)
    push_cast
    linarith
  have hfx : Int.fract x = Int.fract ((H : ℝ) * invMod s r / r) := by
    rw [hxeq, show ((⌊(H : ℝ) * invMod r s / s⌋ : ℝ) - (H : ℤ)) =
      ((⌊(H : ℝ) * invMod r s / s⌋ - H : ℤ) : ℝ) by push_cast; ring, Int.fract_add_intCast]
  rw [hcount, hfx, hx, sub_div, hcs]
  unfold saw
  ring

/-- The rounding identity is symmetric: the oriented pairs `(r, s)` and `(s, r)` have equal
counts (and equal main terms). -/
theorem rowCount_swap_eq (hr : 2 ≤ r) (hs : 2 ≤ s) (h : r.Coprime s) (hrH : r.Coprime H)
    (hsH : s.Coprime H) : (rowCount H r s : ℝ) = rowCount H s r := by
  rw [rowCount_eq_saw hr hs h hrH hsH, rowCount_eq_saw hs hr h.symm hsH hrH, mul_comm (s : ℝ)]
  ring

end Count

/-! ## Exact decomposition of the row discrepancy -/

section Decomp

variable {H r s : ℕ}

/-- The "digit" remainder: the mean-zero part `λ - μ` summed on the constrained progression,
minus its density share. -/
noncomputable def digitTerm (lam : ℕ → ℝ) (μ : ℝ) (H r s : ℕ) : ℝ :=
  (∑ y ∈ Finset.Ioo 0 H, if r ∣ y ∧ s ∣ H - y then (lam y - μ) else 0) -
    (∑ y ∈ Finset.Ioo 0 H, (lam y - μ)) / ((r : ℝ) * (s : ℝ))

/-- Exact for every constant `μ`: `Δ = μ·(count - (H-1)/(rs)) + digit`. -/
lemma rowDiscrepancy_eq_count (lam : ℕ → ℝ) (μ : ℝ) (H r s : ℕ) (hH : 1 ≤ H) :
    rowDiscrepancy lam H r s =
      μ * ((rowCount H r s : ℝ) - ((H : ℝ) - 1) / ((r : ℝ) * s)) + digitTerm lam μ H r s := by
  unfold rowDiscrepancy rowConstrainedMass rowWeightMass digitTerm rowCount
  have hcard : ((Finset.Ioo 0 H).card : ℝ) = (H : ℝ) - 1 := by
    rw [Nat.card_Ioo, Nat.cast_sub (by omega)]; simp
  have e1 : (∑ y ∈ Finset.Ioo 0 H, if r ∣ y ∧ s ∣ H - y then lam y else 0) =
      (∑ y ∈ Finset.Ioo 0 H, if r ∣ y ∧ s ∣ H - y then (lam y - μ) else 0) +
        μ * (((Finset.Ioo 0 H).filter (fun y => r ∣ y ∧ s ∣ H - y)).card : ℝ) := by
    rw [Finset.card_filter, Nat.cast_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl fun y _ => ?_
    split_ifs <;> push_cast <;> ring
  have e2 : (∑ y ∈ Finset.Ioo 0 H, lam y) =
      (∑ y ∈ Finset.Ioo 0 H, (lam y - μ)) + μ * ((Finset.Ioo 0 H).card : ℝ) := by
    rw [Finset.sum_sub_distrib, Finset.sum_const, nsmul_eq_mul]; ring
  rw [e1, e2, hcard]
  ring

/-- **Row decomposition.** For coprime `r, s ≥ 2` coprime to `H ≥ 1` and any constant `μ`:
`Δ(r,s) = μ/(rs) - μ·(ψ(H r̄/s) + ψ(H s̄/r)) + digit(r,s)`. -/
theorem rowDiscrepancy_decomp (lam : ℕ → ℝ) (μ : ℝ) (hH : 1 ≤ H) (hr : 2 ≤ r) (hs : 2 ≤ s)
    (h : r.Coprime s) (hrH : r.Coprime H) (hsH : s.Coprime H) :
    rowDiscrepancy lam H r s =
      μ / ((r : ℝ) * s) - μ * (saw ((H : ℝ) * invMod r s / s) + saw ((H : ℝ) * invMod s r / r)) +
        digitTerm lam μ H r s := by
  rw [rowDiscrepancy_eq_count lam μ H r s hH, rowCount_eq_saw hr hs h hrH hsH]
  have hn : (0 : ℝ) < (r : ℝ) * s := by
    have : (0 : ℝ) < r := by exact_mod_cast (by omega : 0 < r)
    have : (0 : ℝ) < s := by exact_mod_cast (by omega : 0 < s)
    positivity
  field_simp
  ring

end Decomp

end GoldC
