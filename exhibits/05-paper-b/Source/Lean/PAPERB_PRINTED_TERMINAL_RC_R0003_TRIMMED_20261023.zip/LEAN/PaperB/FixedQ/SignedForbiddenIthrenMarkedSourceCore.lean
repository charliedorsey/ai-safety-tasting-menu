import PaperB.FixedQ.SignedForbiddenThalenGlobalSpectralExhaustion

import PaperB.FixedQ.SignedForbiddenThalenCutoffSpectralSource
import Mathlib.Algebra.BigOperators.Group.Finset.Piecewise

open scoped BigOperators Classical

namespace PaperB.FixedQ

/-- The original support family E is already marked by the source cutoff.
This coefficient retains all oriented, including one-sided, Ramanujan modes. -/
noncomputable def ithrenMarkedCoefficient
    (E : Finset (Finset ℕ)) (w : Finset ℕ → ℝ)
    (L R : Finset ℕ) : ℝ :=
  ∑ e ∈ E, ∑ A ∈ ((e.powerset.erase e).erase ∅),
    if L ⊆ A ∧ R ⊆ e \ A then w e else 0

private theorem ithren_subset_uniformize
    (S T : Finset ℕ) (hTS : T ⊆ S)
    (F : Finset ℕ → ℝ) :
    (∑ L ∈ S.powerset, if L ⊆ T then F L else 0) =
      ∑ L ∈ T.powerset, F L := by
  rw [← Finset.sum_filter]
  congr 1
  ext L
  simp only [Finset.mem_filter, Finset.mem_powerset]
  constructor
  · rintro ⟨_, hLT⟩
    exact hLT
  · intro hLT
    exact ⟨hLT.trans hTS, hLT⟩

private theorem ithren_uniform_two_factor
    (S e A : Finset ℕ) (he : e ⊆ S) (hA : A ⊆ e)
    (f g : ℕ → ℝ) :
    (∏ p ∈ A, (1 + f p)) * (∏ p ∈ e \ A, (1 + g p)) =
    ∑ L ∈ S.powerset, ∑ R ∈ S.powerset,
      if L ⊆ A ∧ R ⊆ e \ A then
        (∏ p ∈ L, f p) * (∏ p ∈ R, g p) else 0 := by
  let F : Finset ℕ → ℝ := fun L => ∏ p ∈ L, f p
  let G : Finset ℕ → ℝ := fun R => ∏ p ∈ R, g p
  have hleft := ithren_subset_uniformize S A (hA.trans he) F
  have hright := ithren_subset_uniformize S (e \ A)
    ((Finset.sdiff_subset).trans he) G
  have hprodF : (∏ p ∈ A, (1 + f p)) = ∑ L ∈ A.powerset, F L := by
    simpa [F] using (Finset.prod_one_add (s := A) (f := f))
  have hprodG : (∏ p ∈ e \ A, (1 + g p)) =
      ∑ R ∈ (e \ A).powerset, G R := by
    simpa [G] using (Finset.prod_one_add (s := e \ A) (f := g))
  rw [hprodF, hprodG, ← hleft, ← hright]
  rw [Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro L hL
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro R hR
  by_cases hLA : L ⊆ A <;> by_cases hRB : R ⊆ e \ A <;>
    simp [hLA, hRB, F, G]

private theorem ithren_dependent_four_sum_comm
    (E : Finset (Finset ℕ)) (T : Finset (Finset ℕ))
    (F : Finset ℕ → Finset ℕ → Finset ℕ → Finset ℕ → ℝ) :
    (∑ e ∈ E, ∑ A ∈ ((e.powerset.erase e).erase ∅),
      ∑ L ∈ T, ∑ R ∈ T, F e A L R) =
    ∑ L ∈ T, ∑ R ∈ T,
      ∑ e ∈ E, ∑ A ∈ ((e.powerset.erase e).erase ∅), F e A L R := by
  calc
    _ = ∑ e ∈ E, ∑ L ∈ T, ∑ R ∈ T,
        ∑ A ∈ ((e.powerset.erase e).erase ∅), F e A L R := by
      apply Finset.sum_congr rfl
      intro e he
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro L hL
      rw [Finset.sum_comm]
    _ = ∑ L ∈ T, ∑ e ∈ E, ∑ R ∈ T,
        ∑ A ∈ ((e.powerset.erase e).erase ∅), F e A L R := by
      rw [Finset.sum_comm]
    _ = _ := by
      apply Finset.sum_congr rfl
      intro L hL
      rw [Finset.sum_comm]

theorem ithren_marked_proper_packet_eq_modes
    (S : Finset ℕ) (E : Finset (Finset ℕ))
    (hE : ∀ e ∈ E, e ⊆ S)
    (w : Finset ℕ → ℝ) (f g : ℕ → ℝ) :
    (∑ e ∈ E, w e *
      (∑ A ∈ ((e.powerset.erase e).erase ∅),
        (∏ p ∈ A, (1 + f p)) *
        (∏ p ∈ e \ A, (1 + g p)))) =
    ∑ L ∈ S.powerset, ∑ R ∈ S.powerset,
      ithrenMarkedCoefficient E w L R *
        ((∏ p ∈ L, f p) * (∏ p ∈ R, g p)) := by
  classical
  let F : Finset ℕ → ℝ := fun L => ∏ p ∈ L, f p
  let G : Finset ℕ → ℝ := fun R => ∏ p ∈ R, g p
  have hpoint (e A : Finset ℕ) (he : e ∈ E)
      (hA : A ∈ ((e.powerset.erase e).erase ∅)) :
      (∏ p ∈ A, (1 + f p)) * (∏ p ∈ e \ A, (1 + g p)) =
        ∑ L ∈ S.powerset, ∑ R ∈ S.powerset,
          if L ⊆ A ∧ R ⊆ e \ A then F L * G R else 0 := by
    simpa [F, G] using ithren_uniform_two_factor S e A
      (hE e he) ((Finset.mem_powerset.mp
        (Finset.mem_of_mem_erase (Finset.mem_of_mem_erase hA))))
      f g
  calc
    _ = ∑ e ∈ E, ∑ A ∈ ((e.powerset.erase e).erase ∅),
        ∑ L ∈ S.powerset, ∑ R ∈ S.powerset,
          (if L ⊆ A ∧ R ⊆ e \ A then w e else 0) * (F L * G R) := by
      apply Finset.sum_congr rfl
      intro e he
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro A hA
      rw [hpoint e A he hA, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro L hL
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro R hR
      split_ifs <;> simp
    _ = ∑ L ∈ S.powerset, ∑ R ∈ S.powerset,
        ∑ e ∈ E, ∑ A ∈ ((e.powerset.erase e).erase ∅),
          (if L ⊆ A ∧ R ⊆ e \ A then w e else 0) * (F L * G R) := by
      exact ithren_dependent_four_sum_comm E S.powerset _
    _ = _ := by
      apply Finset.sum_congr rfl
      intro L hL
      apply Finset.sum_congr rfl
      intro R hR
      dsimp [ithrenMarkedCoefficient, F, G]
      rw [Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro e he
      rw [Finset.sum_mul]

#print axioms ithren_marked_proper_packet_eq_modes
end PaperB.FixedQ

namespace PaperB.FixedQ

/-- Original-support cutoff is imposed on e before the Ramanujan-mode expansion.
No cutoff on the output supports L and R is introduced. -/
theorem ithren_source_cutoff_marked_modes
    (S : Finset ℕ) (Z H y : ℕ) :
    (∑ e ∈ S.powerset.filter (fun e => Z < primeSetProduct e),
      (∏ p ∈ e, (1 : ℝ) / ((p : ℝ) * ((p : ℝ) - 3))) *
        (∑ A ∈ ((e.powerset.erase e).erase ∅),
          (∏ p ∈ A, (1 + thalenPrimeRamanujan p y)) *
          (∏ p ∈ e \ A, (1 + thalenPrimeRamanujan p (H-y))))) =
    ∑ L ∈ S.powerset, ∑ R ∈ S.powerset,
      ithrenMarkedCoefficient
        (S.powerset.filter (fun e => Z < primeSetProduct e))
        (fun e => ∏ p ∈ e,
          (1 : ℝ) / ((p : ℝ) * ((p : ℝ) - 3))) L R *
        ((∏ p ∈ L, thalenPrimeRamanujan p y) *
          (∏ p ∈ R, thalenPrimeRamanujan p (H-y))) := by
  apply ithren_marked_proper_packet_eq_modes
  intro e he
  exact (Finset.mem_powerset.mp (Finset.mem_filter.mp he).1)

#print axioms ithren_source_cutoff_marked_modes
end PaperB.FixedQ

namespace PaperB.FixedQ

/-- The empty/empty spectral mode records exactly the total weight of
proper partitions of the ORIGINAL marked source supports. -/
theorem ithren_marked_empty_mode_eq_proper_density
    (E : Finset (Finset ℕ)) (w : Finset ℕ → ℝ) :
    ithrenMarkedCoefficient E w ∅ ∅ =
      ∑ e ∈ E, ∑ A ∈ ((e.powerset.erase e).erase ∅), w e := by
  unfold ithrenMarkedCoefficient
  simp

/-- A single oriented Ramanujan mode cannot overlap its left and right
prime supports. This is independent of the original marked cutoff. -/
theorem ithren_marked_overlap_zero
    (E : Finset (Finset ℕ)) (w : Finset ℕ → ℝ)
    (L R : Finset ℕ) (h : ¬ Disjoint L R) :
    ithrenMarkedCoefficient E w L R = 0 := by
  unfold ithrenMarkedCoefficient
  apply Finset.sum_eq_zero
  intro e he
  apply Finset.sum_eq_zero
  intro A hA
  have hnot : ¬(L ⊆ A ∧ R ⊆ e \ A) := by
    intro hpair
    apply h
    apply Finset.disjoint_left.mpr
    intro p hpL hpR
    have hpA := hpair.1 hpL
    have hpD := hpair.2 hpR
    exact (Finset.mem_sdiff.mp hpD).2 hpA
  simp [hnot]

#print axioms ithren_marked_empty_mode_eq_proper_density
#print axioms ithren_marked_overlap_zero

end PaperB.FixedQ

namespace PaperB.FixedQ

/-- Exact source-weight normalization used by the marked coefficient:
the original omega weight and the two-oriented prime denominators
combine to the same coefficient, independently of a source cutoff. -/
theorem ithren_source_mark_weight_eq_omega_div_product (e : Finset ℕ) :
    (∏ p ∈ e, (1 : ℝ) / ((p : ℝ) * ((p : ℝ) - 3))) =
      finiteOmegaWeightReal e / (primeSetProduct e : ℝ) := by
  unfold finiteOmegaWeightReal primeSetProduct
  simp only [Nat.cast_prod, div_eq_mul_inv, mul_inv_rev]
  simp [Finset.prod_mul_distrib, Finset.prod_inv_distrib, mul_comm, mul_left_comm, mul_assoc]

#print axioms ithren_source_mark_weight_eq_omega_div_product
end PaperB.FixedQ

namespace PaperB.FixedQ

theorem ithren_primeSetProduct_partition
    (e A : Finset ℕ) (hA : A ⊆ e) :
    primeSetProduct A * primeSetProduct (e \ A) = primeSetProduct e := by
  unfold primeSetProduct
  have hdis : Disjoint A (e \ A) := by
    apply Finset.disjoint_left.mpr
    intro x hxA hxD
    exact (Finset.mem_sdiff.mp hxD).2 hxA
  rw [← Finset.prod_union hdis]
  congr 1
  exact Finset.union_sdiff_of_subset hA

/-- Density at the literal original marked source support equals
the empty-empty Ramanujan-mode coefficient exactly. -/
theorem ithren_marked_empty_eq_literal_density
    (E : Finset (Finset ℕ)) :
    ithrenMarkedCoefficient E
        (fun e => ∏ p ∈ e, (1 : ℝ) / ((p : ℝ) * ((p : ℝ) - 3)))
        ∅ ∅ =
      ∑ e ∈ E, finiteOmegaWeightReal e *
        (∑ A ∈ ((e.powerset.erase e).erase ∅),
          1 / ((primeSetProduct A : ℝ) *
              (primeSetProduct (e \ A) : ℝ))) := by
  rw [ithren_marked_empty_mode_eq_proper_density]
  apply Finset.sum_congr rfl
  intro e he
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro A hA
  have hsubset : A ⊆ e := Finset.mem_powerset.mp
    (Finset.mem_of_mem_erase (Finset.mem_of_mem_erase hA))
  rw [ithren_source_mark_weight_eq_omega_div_product]
  rw [← Nat.cast_mul, ithren_primeSetProduct_partition e A hsubset]
  ring

#print axioms ithren_primeSetProduct_partition
#print axioms ithren_marked_empty_eq_literal_density
end PaperB.FixedQ

open scoped BigOperators Classical

namespace PaperB.FixedQ

/-- The exact disjoint, nonconstant marked-mode packet. -/
noncomputable def ithrenMarkedNonconstantModes
    (S : Finset ℕ) (Z H y : ℕ) : ℝ :=
  ∑ L ∈ S.powerset, ∑ R ∈ S.powerset,
    if L = ∅ ∧ R = ∅ then 0 else
      ithrenMarkedCoefficient
        (S.powerset.filter (fun e => Z < primeSetProduct e))
        (fun e => ∏ p ∈ e, (1 : ℝ) / ((p : ℝ) * ((p : ℝ) - 3))) L R *
        ((∏ p ∈ L, thalenPrimeRamanujan p y) *
         (∏ p ∈ R, thalenPrimeRamanujan p (H-y)))

/-- A finite double sum minus its unique selected pair is exactly the
sum over all other pairs. This is the checked generic deletion bridge. -/
private theorem ithren_marked_finite_pair_remove
    {α β : Type*} [DecidableEq α] [DecidableEq β]
    (E : Finset α) (F : Finset β) (a : α) (b : β)
    (ha : a ∈ E) (hb : b ∈ F) (w : α → β → ℝ) :
    (∑ x ∈ E, ∑ y ∈ F, w x y) - w a b =
      ∑ x ∈ E, ∑ y ∈ F,
        if x = a ∧ y = b then 0 else w x y := by
  classical
  have hsingle :
      (∑ x ∈ E, ∑ y ∈ F,
        if x = a ∧ y = b then w x y else 0) = w a b := by
    calc
      _ = ∑ x ∈ E, if x = a then w x b else 0 := by
        apply Finset.sum_congr rfl
        intro x hx
        by_cases h : x = a
        · subst x
          simp [hb]
        · simp [h]
      _ = w a b := by simp [ha]
  calc
    _ = (∑ x ∈ E, ∑ y ∈ F, w x y) -
        (∑ x ∈ E, ∑ y ∈ F,
          if x = a ∧ y = b then w x y else 0) := by
      rw [hsingle]
    _ = ∑ x ∈ E, ∑ y ∈ F,
        (w x y - if x = a ∧ y = b then w x y else 0) := by
      rw [← Finset.sum_sub_distrib]
      apply Finset.sum_congr rfl
      intro x hx
      rw [← Finset.sum_sub_distrib]
    _ = _ := by
      apply Finset.sum_congr rfl
      intro x hx
      apply Finset.sum_congr rfl
      intro y hy
      by_cases h : x = a ∧ y = b <;> simp [h]

/-- This is exact at the source sharp cutoff, including the empty
mode subtraction. The absence of overlapping modes is already GREEN. -/
theorem ithren_marked_pointwise_centered_eq_nonconstant
    (S : Finset ℕ) (Z H y : ℕ) :
    (∑ e ∈ S.powerset.filter (fun e => Z < primeSetProduct e),
      (∏ p ∈ e, (1 : ℝ) / ((p : ℝ) * ((p : ℝ) - 3))) *
        (∑ A ∈ ((e.powerset.erase e).erase ∅),
          (∏ p ∈ A, (1 + thalenPrimeRamanujan p y)) *
          (∏ p ∈ e \ A, (1 + thalenPrimeRamanujan p (H-y))))) -
      ithrenMarkedCoefficient
        (S.powerset.filter (fun e => Z < primeSetProduct e))
        (fun e => ∏ p ∈ e, (1 : ℝ) / ((p : ℝ) * ((p : ℝ) - 3))) ∅ ∅ =
      ithrenMarkedNonconstantModes S Z H y := by
  rw [ithren_source_cutoff_marked_modes]
  unfold ithrenMarkedNonconstantModes
  let C : Finset ℕ → Finset ℕ → ℝ := fun L R =>
    ithrenMarkedCoefficient
      (S.powerset.filter (fun e => Z < primeSetProduct e))
      (fun e => ∏ p ∈ e, (1 : ℝ) / ((p : ℝ) * ((p : ℝ) - 3))) L R *
      ((∏ p ∈ L, thalenPrimeRamanujan p y) *
       (∏ p ∈ R, thalenPrimeRamanujan p (H-y)))
  have hempty : ∅ ∈ S.powerset :=
    Finset.mem_powerset.mpr (Finset.empty_subset S)
  simpa only [C, Finset.prod_empty, one_mul, mul_one] using
    (ithren_marked_finite_pair_remove
      S.powerset S.powerset ∅ ∅ hempty hempty C)

#print axioms ithren_marked_pointwise_centered_eq_nonconstant
end PaperB.FixedQ


open scoped BigOperators
namespace PaperB.FixedQ

/-- The actual Boolean divisor indicator, including zero mode, in the
source Ramanujan normalization. -/
private theorem ithren_prime_weighted_indicator
    (p y : ℕ) (hp : 5 ≤ p) :
    (1 / ((p : ℝ) - 3)) * (if p ∣ y then (1 : ℝ) else 0) =
      (1 / ((p : ℝ) * ((p : ℝ) - 3))) *
        (1 + thalenPrimeRamanujan p y) := by
  have hp0 : (p : ℝ) ≠ 0 := by exact_mod_cast (by omega : p ≠ 0)
  have hp3 : (p : ℝ) - 3 ≠ 0 := by
    have h : (3 : ℝ) < (p : ℝ) := by exact_mod_cast (by omega : 3 < p)
    linarith
  by_cases hd : p ∣ y
  · simp only [thalenPrimeRamanujan, if_pos hd, mul_one]
    field_simp
    <;> ring
  · simp [thalenPrimeRamanujan, hd]

/-- Preserve the literal source weight at every original support and
proper partition, BEFORE imposing the outer product cutoff. -/
theorem ithren_source_partition_indicators_eq_modes
    (e A : Finset ℕ) (H y : ℕ)
    (hA : A ⊆ e)
    (h5 : ∀ p ∈ e, 5 ≤ p) :
    finiteOmegaWeightReal e *
      ((∏ p ∈ A, if p ∣ y then (1 : ℝ) else 0) *
       (∏ p ∈ e \ A, if p ∣ H-y then (1 : ℝ) else 0)) =
      (∏ p ∈ e, (1 : ℝ) / ((p : ℝ) * ((p : ℝ) - 3))) *
        ((∏ p ∈ A, (1 + thalenPrimeRamanujan p y)) *
         (∏ p ∈ e \ A, (1 + thalenPrimeRamanujan p (H-y)))) := by
  classical
  let B := e \ A
  let v : ℕ → ℝ := fun p => 1 / ((p : ℝ) - 3)
  let w : ℕ → ℝ := fun p => 1 / ((p : ℝ) * ((p : ℝ) - 3))
  let f : ℕ → ℝ := fun p => if p ∣ y then 1 else 0
  let g : ℕ → ℝ := fun p => if p ∣ H-y then 1 else 0
  let F : ℕ → ℝ := fun p => 1 + thalenPrimeRamanujan p y
  let G : ℕ → ℝ := fun p => 1 + thalenPrimeRamanujan p (H-y)
  have hd : Disjoint A B := by
    apply Finset.disjoint_left.mpr
    intro x hxA hxB
    exact (Finset.mem_sdiff.mp hxB).2 hxA
  have hu : A ∪ B = e := Finset.union_sdiff_of_subset hA
  have hv : (∏ p ∈ e, v p) =
      (∏ p ∈ A, v p) * (∏ p ∈ B, v p) := by
    rw [← Finset.prod_union hd, hu]
  have hw : (∏ p ∈ e, w p) =
      (∏ p ∈ A, w p) * (∏ p ∈ B, w p) := by
    rw [← Finset.prod_union hd, hu]
  have hf : (∏ p ∈ A, v p * f p) =
      (∏ p ∈ A, w p * F p) := by
    apply Finset.prod_congr rfl
    intro p hp
    exact ithren_prime_weighted_indicator p y
      (h5 p (hA hp))
  have hg : (∏ p ∈ B, v p * g p) =
      (∏ p ∈ B, w p * G p) := by
    apply Finset.prod_congr rfl
    intro p hp
    exact ithren_prime_weighted_indicator p (H-y)
      (h5 p ((Finset.mem_sdiff.mp hp).1))
  change (∏ p ∈ e, v p) * ((∏ p ∈ A, f p) * (∏ p ∈ B, g p)) =
    (∏ p ∈ e, w p) * ((∏ p ∈ A, F p) * (∏ p ∈ B, G p))
  rw [hv, hw]
  calc
    _ = ((∏ p ∈ A, v p) * (∏ p ∈ A, f p)) *
          ((∏ p ∈ B, v p) * (∏ p ∈ B, g p)) := by ring
    _ = (∏ p ∈ A, v p * f p) * (∏ p ∈ B, v p * g p) := by
      rw [Finset.prod_mul_distrib, Finset.prod_mul_distrib]
    _ = (∏ p ∈ A, w p * F p) * (∏ p ∈ B, w p * G p) := by
      rw [hf, hg]
    _ = _ := by
      rw [Finset.prod_mul_distrib, Finset.prod_mul_distrib]
      ring

#print axioms ithren_source_partition_indicators_eq_modes
end PaperB.FixedQ

namespace PaperB.FixedQ

/-- Finite y-sum of the exact centered source-marked packet,
retaining any literal low weight and any outer height decoration. -/
theorem ithren_weighted_decorated_marked_centered
    (S : Finset ℕ) (Z H : ℕ) (lambda : ℕ → ℝ)
    (decoration : ℝ) :
    decoration *
      (∑ y ∈ Finset.Ioo 0 H, lambda y *
        ((∑ e ∈ S.powerset.filter (fun e => Z < primeSetProduct e),
          (∏ p ∈ e, (1 : ℝ) / ((p : ℝ) * ((p : ℝ) - 3))) *
            (∑ A ∈ ((e.powerset.erase e).erase ∅),
              (∏ p ∈ A, (1 + thalenPrimeRamanujan p y)) *
              (∏ p ∈ e \ A, (1 + thalenPrimeRamanujan p (H-y))))) -
          ithrenMarkedCoefficient
            (S.powerset.filter (fun e => Z < primeSetProduct e))
            (fun e => ∏ p ∈ e, (1 : ℝ) / ((p : ℝ) * ((p : ℝ) - 3))) ∅ ∅)) =
    decoration * ∑ y ∈ Finset.Ioo 0 H,
      lambda y * ithrenMarkedNonconstantModes S Z H y := by
  congr 1
  apply Finset.sum_congr rfl
  intro y hy
  rw [ithren_marked_pointwise_centered_eq_nonconstant]

theorem ithren_actual_fixedQ_decorated_marked_centered
    (S : Finset ℕ) (q a Z H : ℕ) (decoration : ℝ) :
    decoration *
      (∑ y ∈ Finset.Ioo 0 H, fixedQLowWeight q a H y *
        ((∑ e ∈ S.powerset.filter (fun e => Z < primeSetProduct e),
          (∏ p ∈ e, (1 : ℝ) / ((p : ℝ) * ((p : ℝ) - 3))) *
            (∑ A ∈ ((e.powerset.erase e).erase ∅),
              (∏ p ∈ A, (1 + thalenPrimeRamanujan p y)) *
              (∏ p ∈ e \ A, (1 + thalenPrimeRamanujan p (H-y))))) -
          ithrenMarkedCoefficient
            (S.powerset.filter (fun e => Z < primeSetProduct e))
            (fun e => ∏ p ∈ e, (1 : ℝ) / ((p : ℝ) * ((p : ℝ) - 3))) ∅ ∅)) =
    decoration * ∑ y ∈ Finset.Ioo 0 H,
      fixedQLowWeight q a H y * ithrenMarkedNonconstantModes S Z H y := by
  exact ithren_weighted_decorated_marked_centered
    S Z H (fixedQLowWeight q a H) decoration

#print axioms ithren_weighted_decorated_marked_centered
#print axioms ithren_actual_fixedQ_decorated_marked_centered

end PaperB.FixedQ


namespace PaperB.FixedQ

/-- A weighted finite sum with dependent proper-partition fibers can
be exchanged with the actual finite interior y-row. -/
private theorem ithren_literal_three_sum_comm
    {α β γ : Type*} [DecidableEq α] [DecidableEq β] [DecidableEq γ]
    (E : Finset α) (B : α → Finset β) (Y : Finset γ)
    (w : α → ℝ) (lambda : γ → ℝ) (f : α → β → γ → ℝ) :
    (∑ e ∈ E, w e * (∑ b ∈ B e, ∑ y ∈ Y, lambda y * f e b y)) =
      ∑ y ∈ Y, lambda y * (∑ e ∈ E, w e * (∑ b ∈ B e, f e b y)) := by
  classical
  calc
    _ = ∑ e ∈ E, ∑ b ∈ B e, ∑ y ∈ Y, w e * (lambda y * f e b y) := by
      simp_rw [Finset.mul_sum]
    _ = ∑ e ∈ E, ∑ y ∈ Y, ∑ b ∈ B e, w e * (lambda y * f e b y) := by
      apply Finset.sum_congr rfl
      intro e he
      rw [Finset.sum_comm]
    _ = ∑ y ∈ Y, ∑ e ∈ E, ∑ b ∈ B e, w e * (lambda y * f e b y) := by
      rw [Finset.sum_comm]
    _ = ∑ y ∈ Y, lambda y * (∑ e ∈ E, w e * (∑ b ∈ B e, f e b y)) := by
      apply Finset.sum_congr rfl
      intro y hy
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro e he
      calc
        _ = w e * (lambda y * (∑ b ∈ B e, f e b y)) := by
          rw [Finset.mul_sum, Finset.mul_sum]
        _ = lambda y * (w e * (∑ b ∈ B e, f e b y)) := by ring

/-- Literal cutoff-restricted outer source, with arbitrary true row weight,
equals the weighted NONCONSTANT sharp-marked Ramanujan modes. -/
theorem thalen_literal_marked_rows_eq_nonconstant
    (S : Finset ℕ) (Z H : ℕ) (lambda : ℕ → ℝ)
    (hprime : ∀ p ∈ S, p.Prime)
    (h5 : ∀ p ∈ S, 5 ≤ p) :
    (∑ e ∈ S.powerset.filter (fun e => Z < primeSetProduct e),
      finiteOmegaWeightReal e *
        ordinaryBooleanInteriorDiscrepancy lambda H e) =
      ∑ y ∈ Finset.Ioo 0 H,
        lambda y * ithrenMarkedNonconstantModes S Z H y := by
  let E := S.powerset.filter (fun e => Z < primeSetProduct e)
  have hrow :
      (∑ e ∈ E, finiteOmegaWeightReal e *
        ordinaryBooleanInteriorDiscrepancy lambda H e) =
      (∑ y ∈ Finset.Ioo 0 H, lambda y *
        (∑ e ∈ E, finiteOmegaWeightReal e *
          (∑ A ∈ ((e.powerset.erase e).erase ∅),
            (∏ p ∈ A, if p ∣ y then (1 : ℝ) else 0) *
            (∏ p ∈ e \ A, if p ∣ H-y then (1 : ℝ) else 0)))) -
      rowWeightMass lambda H *
        (∑ e ∈ E, finiteOmegaWeightReal e *
          (∑ A ∈ ((e.powerset.erase e).erase ∅),
            1 / ((primeSetProduct A : ℝ) *
              (primeSetProduct (e \ A) : ℝ)))) := by
    have hconstrained :
        (∑ e ∈ E, finiteOmegaWeightReal e *
          (∑ A ∈ ((e.powerset.erase e).erase ∅),
            rowConstrainedMass lambda H (primeSetProduct A)
              (primeSetProduct (e \ A)))) =
        ∑ y ∈ Finset.Ioo 0 H, lambda y *
          (∑ e ∈ E, finiteOmegaWeightReal e *
            (∑ A ∈ ((e.powerset.erase e).erase ∅),
              (∏ p ∈ A, if p ∣ y then (1 : ℝ) else 0) *
              (∏ p ∈ e \ A, if p ∣ H-y then (1 : ℝ) else 0))) := by
      calc
        _ = (∑ e ∈ E, finiteOmegaWeightReal e *
          (∑ A ∈ ((e.powerset.erase e).erase ∅),
            ∑ y ∈ Finset.Ioo 0 H, lambda y *
              ((∏ p ∈ A, if p ∣ y then (1 : ℝ) else 0) *
               (∏ p ∈ e \ A, if p ∣ H-y then (1 : ℝ) else 0)))) := by
          apply Finset.sum_congr rfl
          intro e he
          congr 1
          apply Finset.sum_congr rfl
          intro A hA
          have hsub : A ⊆ e :=
            Finset.mem_powerset.mp
              (Finset.mem_of_mem_erase (Finset.mem_of_mem_erase hA))
          have hpe : ∀ p ∈ e, p.Prime := by
            intro p hp
            exact hprime p ((Finset.mem_powerset.mp
              (Finset.mem_filter.mp he).1) hp)
          exact thalen_rowConstrainedMass_eq_local_indicators
            lambda H A (e \ A)
            (fun p hp => hpe p (hsub hp))
            (fun p hp => hpe p (Finset.mem_sdiff.mp hp).1)
        _ = _ := ithren_literal_three_sum_comm E
          (fun e => ((e.powerset.erase e).erase ∅))
          (Finset.Ioo 0 H) finiteOmegaWeightReal lambda
          (fun e A y =>
            (∏ p ∈ A, if p ∣ y then (1 : ℝ) else 0) *
            (∏ p ∈ e \ A, if p ∣ H-y then (1 : ℝ) else 0))
    unfold ordinaryBooleanInteriorDiscrepancy
      fixedProductPartitionDiscrepancy rowDiscrepancy
    calc
      _ = ∑ e ∈ E, (
        (finiteOmegaWeightReal e *
          (∑ A ∈ ((e.powerset.erase e).erase ∅),
            rowConstrainedMass lambda H (primeSetProduct A)
              (primeSetProduct (e \ A)))) -
        rowWeightMass lambda H *
          (finiteOmegaWeightReal e *
            (∑ A ∈ ((e.powerset.erase e).erase ∅),
              1 / ((primeSetProduct A : ℝ) *
                (primeSetProduct (e \ A) : ℝ))))) := by
          apply Finset.sum_congr rfl
          intro e he
          rw [Finset.sum_sub_distrib, mul_sub]
          simp only [Finset.mul_sum, div_eq_mul_inv]
          ring
      _ = (∑ e ∈ E, finiteOmegaWeightReal e *
          (∑ A ∈ ((e.powerset.erase e).erase ∅),
            rowConstrainedMass lambda H (primeSetProduct A)
              (primeSetProduct (e \ A)))) -
        rowWeightMass lambda H *
          (∑ e ∈ E, finiteOmegaWeightReal e *
            (∑ A ∈ ((e.powerset.erase e).erase ∅),
              1 / ((primeSetProduct A : ℝ) *
                (primeSetProduct (e \ A) : ℝ)))) := by
          rw [Finset.sum_sub_distrib, Finset.mul_sum]
      _ = _ := by rw [hconstrained]
  rw [hrow]
  have hmass :
      (∑ y ∈ Finset.Ioo 0 H, lambda y *
        (∑ e ∈ E, finiteOmegaWeightReal e *
          (∑ A ∈ ((e.powerset.erase e).erase ∅),
            (∏ p ∈ A, if p ∣ y then (1 : ℝ) else 0) *
            (∏ p ∈ e \ A, if p ∣ H-y then (1 : ℝ) else 0)))) =
      ∑ y ∈ Finset.Ioo 0 H, lambda y *
        (∑ e ∈ E,
          (∏ p ∈ e, (1 : ℝ) / ((p : ℝ) * ((p : ℝ) - 3))) *
            (∑ A ∈ ((e.powerset.erase e).erase ∅),
              (∏ p ∈ A, (1 + thalenPrimeRamanujan p y)) *
              (∏ p ∈ e \ A, (1 + thalenPrimeRamanujan p (H-y))))) := by
    apply Finset.sum_congr rfl
    intro y hy
    congr 1
    apply Finset.sum_congr rfl
    intro e he
    rw [Finset.mul_sum, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro A hA
    exact ithren_source_partition_indicators_eq_modes
      e A H y
      (Finset.mem_powerset.mp
        (Finset.mem_of_mem_erase (Finset.mem_of_mem_erase hA)))
      (fun p hp => h5 p
        ((Finset.mem_powerset.mp (Finset.mem_filter.mp he).1) hp))
  rw [hmass, ← ithren_marked_empty_eq_literal_density E]
  have hc := ithren_weighted_decorated_marked_centered
    S Z H lambda (1 : ℝ)
  simp only [one_mul] at hc
  simpa [E, rowWeightMass, mul_sub, Finset.sum_sub_distrib,
    Finset.mul_sum, Finset.sum_mul] using hc

#print axioms thalen_literal_marked_rows_eq_nonconstant
end PaperB.FixedQ

namespace PaperB.FixedQ

noncomputable def ithrenLiteralDisjointModes (S : Finset ℕ) (Z H y : ℕ) : ℝ :=
  ∑ L ∈ S.powerset, ∑ R ∈ S.powerset,
    if (L = ∅ ∧ R = ∅) ∨ ¬ Disjoint L R then 0 else
      ithrenMarkedCoefficient
        (S.powerset.filter (fun e => Z < primeSetProduct e))
        (fun e => ∏ p ∈ e, (1 : ℝ) / ((p : ℝ) * ((p : ℝ) - 3))) L R *
        ((∏ p ∈ L, thalenPrimeRamanujan p y) *
         (∏ p ∈ R, thalenPrimeRamanujan p (H-y)))

private theorem ithren_literal_nonconstant_eq_disjoint
    (S : Finset ℕ) (Z H y : ℕ) :
    ithrenMarkedNonconstantModes S Z H y =
      ithrenLiteralDisjointModes S Z H y := by
  classical
  unfold ithrenMarkedNonconstantModes ithrenLiteralDisjointModes
  apply Finset.sum_congr rfl
  intro L hL
  apply Finset.sum_congr rfl
  intro R hR
  by_cases h0 : L = ∅ ∧ R = ∅
  · simp [h0]
  · by_cases hd : Disjoint L R
    · simp [h0, hd]
    · have hz :
        ithrenMarkedCoefficient
          (S.powerset.filter (fun e => Z < primeSetProduct e))
          (fun e => ∏ p ∈ e, (1 : ℝ) / ((p : ℝ) * ((p : ℝ) - 3))) L R = 0 :=
          ithren_marked_overlap_zero
            (S.powerset.filter (fun e => Z < primeSetProduct e))
            (fun e => ∏ p ∈ e, (1 : ℝ) / ((p : ℝ) * ((p : ℝ) - 3))) L R hd
      simp only [h0, hd, not_false_eq_true, or_true, ite_true, ite_false, hz, zero_mul]

theorem ithren_literal_fixedQ_height_decorated_disjoint
    (q a h Z : ℕ) (S d : Finset ℕ)
    (hprime : ∀ p ∈ S, p.Prime)
    (h5 : ∀ p ∈ S, 5 ≤ p) :
    finiteVWeightReal h d *
      (∑ e ∈ S.powerset.filter (fun e => Z < primeSetProduct e),
        finiteOmegaWeightReal e *
          ordinaryBooleanInteriorDiscrepancy
            (fixedQLowWeight q a (h / primeSetProduct d))
            (h / primeSetProduct d) e) =
    finiteVWeightReal h d *
      (∑ y ∈ Finset.Ioo 0 (h / primeSetProduct d),
        fixedQLowWeight q a (h / primeSetProduct d) y *
          ithrenLiteralDisjointModes S Z (h / primeSetProduct d) y) := by
  congr 1
  rw [thalen_literal_marked_rows_eq_nonconstant S Z
      (h / primeSetProduct d) (fixedQLowWeight q a (h / primeSetProduct d))
      hprime h5]
  apply Finset.sum_congr rfl
  intro y hy
  rw [ithren_literal_nonconstant_eq_disjoint]

#print axioms ithren_literal_fixedQ_height_decorated_disjoint
end PaperB.FixedQ
