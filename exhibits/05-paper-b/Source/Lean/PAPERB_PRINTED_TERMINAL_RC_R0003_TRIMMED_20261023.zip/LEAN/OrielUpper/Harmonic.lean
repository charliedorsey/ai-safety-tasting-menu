import OrielUpper.Euler
import Mathlib.NumberTheory.Harmonic.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.Complex.ExponentialBounds

/-!
# Oriel Upper — harmonic interval sums, divisor exchange, band sums

* `oriel_harmonic_Ioc`: `∑_{k<j≤K} 1/j ≤ log(K/k)` for `1 ≤ k ≤ K`.
* `oriel_harmonic_div`: `∑_{A/e < j ≤ B/e} 1/j ≤ 1 + log(B/A)`.
* `oriel_divisor_exchange`: `∑_{A<n≤B} ∑_{e∣n} φ e n = ∑_{e ≤ B} ∑_{A/e<k≤B/e} φ e (e k)`.
* `oriel_band_sum`: `∑_{A<n≤B} b_F(n) ≤ A₁(F,B) (1 + log(B/A))`.
-/

open Finset Real

namespace OrielUpper

lemma inv_le_log_sub {j : ℕ} (hj : 2 ≤ j) :
    (1 : ℝ) / j ≤ Real.log j - Real.log (j - 1 : ℕ) := by
  have hj0 : (0 : ℝ) < j := by exact_mod_cast (show 0 < j by omega)
  have hj1 : (0 : ℝ) < (j - 1 : ℕ) := by exact_mod_cast (show 0 < j - 1 by omega)
  rw [← Real.log_div hj0.ne' hj1.ne']
  have hcast : ((j - 1 : ℕ) : ℝ) = (j : ℝ) - 1 := by rw [Nat.cast_sub (by omega)]; simp
  rw [hcast]
  -- log(j/(j-1)) ≥ 1 - (j-1)/j = 1/j
  have hpos : 0 < (j : ℝ) / ((j : ℝ) - 1) := by rw [← hcast]; positivity
  have := Real.one_sub_inv_le_log_of_pos hpos
  rw [inv_div] at this
  have e : 1 - ((j : ℝ) - 1) / j = 1 / j := by field_simp; ring
  linarith

theorem oriel_harmonic_Ioc {k K : ℕ} (hk : 1 ≤ k) (hkK : k ≤ K) :
    ∑ j ∈ Ioc k K, (1 : ℝ) / j ≤ Real.log K - Real.log k := by
  induction K, hkK using Nat.le_induction with
  | base => simp
  | succ K hK ih =>
    rw [← Finset.Ioc_union_Ioc_eq_Ioc hK (Nat.le_succ K), sum_union
      (Finset.Ioc_disjoint_Ioc_of_le le_rfl)]
    rw [Nat.Ioc_succ_singleton, sum_singleton]
    have := inv_le_log_sub (j := K + 1) (by omega)
    simp only [Nat.add_sub_cancel] at this
    linarith

theorem oriel_harmonic_div {A B e : ℕ} (hA : 1 ≤ A) (hAB : A ≤ B) (he : 1 ≤ e) :
    ∑ j ∈ Ioc (A / e) (B / e), (1 : ℝ) / j ≤ 1 + Real.log ((B : ℝ) / A) := by
  have hAr : (0 : ℝ) < A := by exact_mod_cast (show 0 < A by omega)
  have hBr : (0 : ℝ) < B := by exact_mod_cast (show 0 < B by omega)
  have her : (0 : ℝ) < e := by exact_mod_cast (show 0 < e by omega)
  have hlogBA : 0 ≤ Real.log ((B : ℝ) / A) := Real.log_nonneg (by
    rw [le_div_iff₀ hAr]; simp; exact_mod_cast hAB)
  rcases Nat.eq_zero_or_pos (A / e) with h0 | h0
  · -- harmonic from 1
    rw [h0]
    have hIoc : Ioc 0 (B / e) = Icc 1 (B / e) := by ext; simp; omega
    rw [hIoc]
    have hh := harmonic_le_one_add_log (B / e)
    rw [harmonic_eq_sum_Icc] at hh
    push_cast at hh
    simp only [one_div]
    rcases Nat.eq_zero_or_pos (B / e) with hb | hb
    · rw [hb]; simp; linarith
    -- B/e < B/A since e > A
    have heA : A < e := by
      by_contra hc; push_neg at hc
      have := Nat.div_pos hc (by omega : 0 < e); omega
    have hlog : Real.log ((B / e : ℕ) : ℝ) ≤ Real.log ((B : ℝ) / A) := by
      apply Real.log_le_log (by exact_mod_cast hb)
      calc ((B / e : ℕ) : ℝ) ≤ (B : ℝ) / e := Nat.cast_div_le
        _ ≤ (B : ℝ) / A := by
          apply div_le_div_of_nonneg_left hBr.le hAr; exact_mod_cast heA.le
    linarith
  · have hle : A / e ≤ B / e := Nat.div_le_div_right hAB
    have h1 := oriel_harmonic_Ioc h0 hle
    rcases Nat.eq_zero_or_pos (B / e) with hb | hb
    · omega
    have hkpos : (0 : ℝ) < (A / e : ℕ) := by exact_mod_cast h0
    have hKpos : (0 : ℝ) < (B / e : ℕ) := by exact_mod_cast hb
    rw [← Real.log_div hKpos.ne' hkpos.ne'] at h1
    -- (B/e)/(A/e) ≤ 2 B / A since A/e ≥ (A/e real)/2
    have hK : ((B / e : ℕ) : ℝ) ≤ (B : ℝ) / e := Nat.cast_div_le
    have hk : (A : ℝ) / e / 2 ≤ ((A / e : ℕ) : ℝ) := by
      have h2 : (A : ℝ) / e < ((A / e : ℕ) : ℝ) + 1 := by
        have := Nat.lt_div_mul_add (a := A) (show 0 < e by omega)
        rw [div_lt_iff₀ her]
        have : (A : ℝ) < ((A / e : ℕ) : ℝ) * e + e := by exact_mod_cast this
        linarith
      have h3 : (1 : ℝ) ≤ ((A / e : ℕ) : ℝ) := by exact_mod_cast h0
      linarith
    have hratio : ((B / e : ℕ) : ℝ) / ((A / e : ℕ) : ℝ) ≤ 2 * ((B : ℝ) / A) := by
      rw [div_le_iff₀ hkpos]
      calc ((B / e : ℕ) : ℝ) ≤ (B : ℝ) / e := hK
        _ = 2 * ((B : ℝ) / A) * ((A : ℝ) / e / 2) := by field_simp
        _ ≤ 2 * ((B : ℝ) / A) * ((A / e : ℕ) : ℝ) := by
          apply mul_le_mul_of_nonneg_left hk; positivity
    have hlog : Real.log (((B / e : ℕ) : ℝ) / ((A / e : ℕ) : ℝ)) ≤
        Real.log 2 + Real.log ((B : ℝ) / A) := by
      rw [← Real.log_mul (by norm_num) (by positivity)]
      exact Real.log_le_log (by positivity) hratio
    have hl2 : Real.log 2 < 1 := by
      have := Real.log_two_lt_d9; norm_num at this; linarith
    linarith

/-- Divisor exchange on an interval. -/
theorem oriel_divisor_exchange (A B : ℕ) (φ : ℕ → ℕ → ℝ) :
    ∑ n ∈ Ioc A B, ∑ e ∈ n.divisors, φ e n =
      ∑ e ∈ Icc 1 B, ∑ k ∈ Ioc (A / e) (B / e), φ e (e * k) := by
  rw [sum_sigma', sum_sigma']
  apply Finset.sum_nbij' (fun x => ⟨x.2, x.1 / x.2⟩) (fun y => ⟨y.1 * y.2, y.1⟩)
  · rintro ⟨n, e⟩ h
    simp only [mem_sigma, mem_Ioc, Nat.mem_divisors] at h
    simp only [mem_sigma, mem_Icc, mem_Ioc]
    obtain ⟨⟨hA, hB⟩, ⟨k, rfl⟩, hn⟩ := h
    have he : 0 < e := Nat.pos_of_ne_zero (fun h => by simp [h] at hn)
    rw [Nat.mul_div_cancel_left _ he]
    refine ⟨⟨he, ?_⟩, ?_, ?_⟩
    · exact (Nat.le_of_dvd (by omega) (dvd_mul_right e k)).trans hB
    · exact (Nat.div_lt_iff_lt_mul he).mpr (by rw [Nat.mul_comm]; exact hA)
    · exact (Nat.le_div_iff_mul_le he).mpr (by rw [Nat.mul_comm]; exact hB)
  · rintro ⟨e, k⟩ h
    simp only [mem_sigma, mem_Icc, mem_Ioc] at h
    simp only [mem_sigma, mem_Ioc, Nat.mem_divisors]
    obtain ⟨⟨he, _⟩, hk1, hk2⟩ := h
    have hA := (Nat.div_lt_iff_lt_mul (show 0 < e by omega)).mp hk1
    have hB := (Nat.le_div_iff_mul_le (show 0 < e by omega)).mp hk2
    refine ⟨⟨by rw [Nat.mul_comm] at hA; exact hA, by rw [Nat.mul_comm] at hB; exact hB⟩,
      dvd_mul_right e k, ?_⟩
    have : 0 < A / e + 1 := Nat.succ_pos _
    exact Nat.mul_ne_zero (by omega) (by omega)
  · rintro ⟨n, e⟩ h
    simp only [mem_sigma, Nat.mem_divisors] at h
    simp only [Sigma.mk.injEq, heq_eq_eq]
    refine ⟨Nat.mul_div_cancel' h.2.1, trivial⟩
  · rintro ⟨e, k⟩ h
    simp only [mem_sigma, mem_Icc] at h
    simp only [Sigma.mk.injEq, heq_eq_eq]
    refine ⟨trivial, Nat.mul_div_cancel_left k (by omega)⟩
  · rintro ⟨n, e⟩ h
    simp only [mem_sigma, Nat.mem_divisors] at h
    simp only
    rw [Nat.mul_div_cancel' h.2.1]

/-- Band sum of the pair weight. -/
theorem oriel_band_sum (F : ℕ) {A B : ℕ} (hA : 1 ≤ A) (hAB : A ≤ B) :
    ∑ n ∈ Ioc A B, bW F n ≤ Asig F B 1 * (1 + Real.log ((B : ℝ) / A)) := by
  have hb : ∀ n, bW F n = ∑ e ∈ n.divisors, KW F e / n := by
    intro n; rw [bW, ← sum_divisors_KW, sum_div]
  simp_rw [hb]
  rw [oriel_divisor_exchange A B (fun e n => KW F e / n)]
  unfold Asig
  rw [sum_mul]
  apply sum_le_sum
  intro e he
  have he1 : 1 ≤ e := (mem_Icc.mp he).1
  have her : (0 : ℝ) < e := by exact_mod_cast (show 0 < e by omega)
  calc ∑ k ∈ Ioc (A / e) (B / e), KW F e / ((e * k : ℕ) : ℝ)
      ≤ ∑ k ∈ Ioc (A / e) (B / e), |KW F e| / e * (1 / k) := by
        apply sum_le_sum; intro k hk
        push_cast
        rcases Nat.eq_zero_or_pos k with h | h
        · subst h; simp
        have : KW F e / ((e : ℝ) * k) = (KW F e / e) * (1 / k) := by field_simp
        rw [this]
        apply mul_le_mul_of_nonneg_right _ (by positivity)
        exact div_le_div_of_nonneg_right (le_abs_self _) her.le
    _ = |KW F e| / e * ∑ k ∈ Ioc (A / e) (B / e), (1 : ℝ) / k := by rw [mul_sum]
    _ ≤ |KW F e| / e * (1 + Real.log ((B : ℝ) / A)) := by
        apply mul_le_mul_of_nonneg_left (oriel_harmonic_div hA hAB he1) (by positivity)
    _ = |KW F e| * (e : ℝ) ^ (-(1 : ℝ)) * (1 + Real.log ((B : ℝ) / A)) := by
        rw [Real.rpow_neg_one]; field_simp

end OrielUpper
