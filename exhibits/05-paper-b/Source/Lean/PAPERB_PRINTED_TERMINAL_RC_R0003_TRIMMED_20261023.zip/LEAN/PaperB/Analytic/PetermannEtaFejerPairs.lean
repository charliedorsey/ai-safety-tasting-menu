import PaperB.Analytic.PetermannEtaNearJumpFejer
import PaperB.Analytic.PetermannEtaHarmonicPartition
import PaperB.Analytic.PetermannPhaseSquare
import PaperB.Analytic.PetermannDivisorMoment

open scoped BigOperators

namespace PaperB.Analytic

open Real Finset Nat

noncomputable def etaFejerPairSum
    (q Y a b : ℕ) (A : ℝ) (r : ℤ) : ℂ :=
  ∑ m ∈ Finset.Icc 1 Y,
    ((m : ℂ)⁻¹) *
      eR (((a : ℝ) - (b : ℝ)) *
        (A / (m : ℝ) +
          (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)))

lemma etaFejerPairSum_eq_phase_mul_mode
    (q Y a b : ℕ) (A : ℝ) (r : ℤ) :
    etaFejerPairSum q Y a b A r =
      eR (((a : ℝ) - (b : ℝ)) *
          (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) *
        etaHarmonicAdditiveMode Y
          (((a : ℝ) - (b : ℝ)) * A) 0 := by
  unfold etaFejerPairSum etaHarmonicAdditiveMode
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro m hm
  have hphase :
      ((a : ℝ) - (b : ℝ)) *
          (A / (m : ℝ) +
            (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))
        =
      (((a : ℝ) - (b : ℝ)) *
          (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)) +
      ((((a : ℝ) - (b : ℝ)) * A) / (m : ℝ) + 0 * (m : ℝ)) := by
    ring
  rw [hphase, eR_add]
  ring

lemma etaFejerPairSum_diag
    (q Y a : ℕ) (A : ℝ) (r : ℤ) :
    etaFejerPairSum q Y a a A r =
      ∑ m ∈ Finset.Icc 1 Y, ((m : ℂ)⁻¹) := by
  unfold etaFejerPairSum
  apply Finset.sum_congr rfl
  intro m hm
  simp [eR]

lemma etaFejerWeightedSq_complex_eq_pairs
    (q Y J : ℕ) (A : ℝ) (r : ℤ) :
    (((∑ m ∈ Finset.Icc 1 Y,
          (1 / (m : ℝ)) *
            ‖etaFejerPhaseSumCore J
              (A / (m : ℝ) +
                (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))‖^2 : ℝ) : ℂ))
      =
    ∑ a ∈ Finset.range J, ∑ b ∈ Finset.range J,
      etaFejerPairSum q Y a b A r := by
  let phase : ℕ → ℝ := fun m =>
    A / (m : ℝ) +
      (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ)
  have hsq : ∀ m : ℕ,
      (((‖etaFejerPhaseSumCore J (phase m)‖^2 : ℝ) : ℂ)) =
        ∑ a ∈ Finset.range J, ∑ b ∈ Finset.range J,
          eR (((a : ℝ) - (b : ℝ)) * phase m) := by
    intro m
    have h := phase_sum_norm_sq_complex
      (Q := Finset.range J)
      (phi := fun k : ℕ => (k : ℝ) * phase m)
    unfold etaFejerPhaseSumCore
    rw [h]
    apply Finset.sum_congr rfl
    intro a ha
    apply Finset.sum_congr rfl
    intro b hb
    congr 1
    ring
  have hcast :
      (((∑ m ∈ Finset.Icc 1 Y,
          (1 / (m : ℝ)) *
            ‖etaFejerPhaseSumCore J
              (A / (m : ℝ) +
                (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))‖^2 : ℝ) : ℂ))
        =
      ∑ m ∈ Finset.Icc 1 Y,
        (((1 / (m : ℝ) : ℝ) : ℂ)) *
          (((‖etaFejerPhaseSumCore J
            (A / (m : ℝ) +
              (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))‖^2 : ℝ) : ℂ)) := by
    push_cast
    rfl
  rw [hcast]
  dsimp [phase] at hsq
  simp_rw [hsq]
  simp_rw [Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro a ha
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro b hb
  simp [etaFejerPairSum, div_eq_mul_inv]


lemma etaFejerPairSum_offdiag_le
    {q Y J a b : ℕ} {A B : ℝ} {r : ℤ}
    (hA : 0 ≤ A)
    (ha : a < J) (hb : b < J) (hne : a ≠ b)
    (hmode :
      ∀ {A' : ℝ} {j : ℕ},
        1 ≤ j → j ≤ J →
        |A'| = (j : ℝ) * A →
        ‖etaHarmonicAdditiveMode Y A' 0‖ ≤ B) :
    ‖etaFejerPairSum q Y a b A r‖ ≤ B := by
  rw [etaFejerPairSum_eq_phase_mul_mode, norm_mul, norm_eR, one_mul]
  by_cases hba : b ≤ a
  · let j : ℕ := a - b
    have hj1 : 1 ≤ j := by
      dsimp [j]
      omega
    have hjJ : j ≤ J := by
      dsimp [j]
      omega
    apply hmode hj1 hjJ
    have hbaR : (b : ℝ) ≤ (a : ℝ) := by exact_mod_cast hba
    dsimp [j]
    rw [abs_mul, abs_of_nonneg (sub_nonneg.mpr hbaR), abs_of_nonneg hA]
    rw [Nat.cast_sub hba]
  · have hab : a ≤ b := by omega
    let j : ℕ := b - a
    have hj1 : 1 ≤ j := by
      dsimp [j]
      omega
    have hjJ : j ≤ J := by
      dsimp [j]
      omega
    apply hmode hj1 hjJ
    have habR : (a : ℝ) ≤ (b : ℝ) := by exact_mod_cast hab
    dsimp [j]
    rw [abs_mul, abs_of_nonpos (sub_nonpos.mpr habR), abs_of_nonneg hA]
    rw [Nat.cast_sub hab]
    ring


lemma etaFejerPairSum_diag_norm_le
    {q Y a : ℕ} {A : ℝ} {r : ℤ}
    (hY1 : 1 ≤ Y) (hA1 : 1 ≤ A) (hYA : (Y : ℝ) ≤ A) :
    ‖etaFejerPairSum q Y a a A r‖ ≤ 1 + Real.log A := by
  rw [etaFejerPairSum_diag]
  calc
    ‖∑ m ∈ Finset.Icc 1 Y, ((m : ℂ)⁻¹)‖
      ≤ ∑ m ∈ Finset.Icc 1 Y, ‖((m : ℂ)⁻¹)‖ := norm_sum_le _ _
    _ = ∑ m ∈ Finset.Icc 1 Y, 1 / (m : ℝ) := by
      apply Finset.sum_congr rfl
      intro m hm
      rw [norm_inv, Complex.norm_natCast]
      simp [div_eq_mul_inv]
    _ = (harmonic Y : ℝ) := by
      rw [harmonic_eq_sum_Icc]
      push_cast
      apply Finset.sum_congr rfl
      intro m hm
      norm_num [div_eq_mul_inv]
    _ ≤ 1 + Real.log (Y : ℝ) := harmonic_le_one_add_log Y
    _ ≤ 1 + Real.log A := by
      have hYr : 0 < (Y : ℝ) := by exact_mod_cast (show 0 < Y by omega)
      simpa [add_comm] using
        add_le_add_left (Real.log_le_log hYr hYA) 1

lemma etaFejerPairNormSum_le
    {q Y J : ℕ} {A B : ℝ} {r : ℤ}
    (hJ : 1 ≤ J) (hY1 : 1 ≤ Y)
    (hA1 : 1 ≤ A) (hYA : (Y : ℝ) ≤ A)
    (hB : 0 ≤ B)
    (hmode :
      ∀ {A' : ℝ} {j : ℕ},
        1 ≤ j → j ≤ J →
        |A'| = (j : ℝ) * A →
        ‖etaHarmonicAdditiveMode Y A' 0‖ ≤ B) :
    (∑ a ∈ Finset.range J, ∑ b ∈ Finset.range J,
        ‖etaFejerPairSum q Y a b A r‖)
      ≤ (J : ℝ) * (1 + Real.log A) + (J : ℝ)^2 * B := by
  classical
  calc
    (∑ a ∈ Finset.range J, ∑ b ∈ Finset.range J,
        ‖etaFejerPairSum q Y a b A r‖)
      ≤ ∑ a ∈ Finset.range J, ∑ b ∈ Finset.range J,
          ((if a = b then 1 + Real.log A else 0) + B) := by
        apply Finset.sum_le_sum
        intro a ha
        apply Finset.sum_le_sum
        intro b hb
        by_cases hab : a = b
        · subst b
          simp
          have hd := etaFejerPairSum_diag_norm_le
            (q := q) (Y := Y) (a := a) (A := A) (r := r)
            hY1 hA1 hYA
          linarith
        · simp [hab]
          exact etaFejerPairSum_offdiag_le
            (q := q) (Y := Y) (J := J) (a := a) (b := b)
            (A := A) (B := B) (r := r)
            (le_trans (by norm_num) hA1)
            (by simpa using ha) (by simpa using hb) hab hmode
    _ = (J : ℝ) * (1 + Real.log A) + (J : ℝ)^2 * B := by
      have hdiag :
          (∑ a ∈ Finset.range J, ∑ b ∈ Finset.range J,
            (if a = b then 1 + Real.log A else 0)) =
            (J : ℝ) * (1 + Real.log A) := by
        calc
          (∑ a ∈ Finset.range J, ∑ b ∈ Finset.range J,
            (if a = b then 1 + Real.log A else 0))
            = ∑ a ∈ Finset.range J, (1 + Real.log A) := by
                apply Finset.sum_congr rfl
                intro a ha
                rw [Finset.mem_range] at ha
                simp [ha]
          _ = (J : ℝ) * (1 + Real.log A) := by
                simp
                ring
      simp_rw [Finset.sum_add_distrib]
      rw [hdiag]
      simp
      ring

noncomputable def etaFejerWeightedSq
    (q Y J : ℕ) (A : ℝ) (r : ℤ) : ℝ :=
  ∑ m ∈ Finset.Icc 1 Y,
    (1 / (m : ℝ)) *
      ‖etaFejerPhaseSumCore J
        (A / (m : ℝ) +
          (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))‖^2

lemma etaFejerWeightedSq_le
    {q Y J : ℕ} {A B : ℝ} {r : ℤ}
    (hJ : 1 ≤ J) (hY1 : 1 ≤ Y)
    (hA1 : 1 ≤ A) (hYA : (Y : ℝ) ≤ A)
    (hB : 0 ≤ B)
    (hmode :
      ∀ {A' : ℝ} {j : ℕ},
        1 ≤ j → j ≤ J →
        |A'| = (j : ℝ) * A →
        ‖etaHarmonicAdditiveMode Y A' 0‖ ≤ B) :
    etaFejerWeightedSq q Y J A r
      ≤ (J : ℝ) * (1 + Real.log A) + (J : ℝ)^2 * B := by
  have hW0 : 0 ≤ etaFejerWeightedSq q Y J A r := by
    unfold etaFejerWeightedSq
    apply Finset.sum_nonneg
    intro m hm
    rw [Finset.mem_Icc] at hm
    have hmR : 0 < (m : ℝ) := by exact_mod_cast (show 0 < m by omega)
    positivity
  have hEq :
      (((etaFejerWeightedSq q Y J A r : ℝ) : ℂ)) =
        ∑ a ∈ Finset.range J, ∑ b ∈ Finset.range J,
          etaFejerPairSum q Y a b A r := by
    simpa [etaFejerWeightedSq] using
      (etaFejerWeightedSq_complex_eq_pairs q Y J A r)
  have hWnorm :
      ‖((etaFejerWeightedSq q Y J A r : ℝ) : ℂ)‖ =
        etaFejerWeightedSq q Y J A r := by
    simp [abs_of_nonneg hW0]
  calc
    etaFejerWeightedSq q Y J A r
      = ‖((etaFejerWeightedSq q Y J A r : ℝ) : ℂ)‖ := hWnorm.symm
    _ = ‖∑ a ∈ Finset.range J, ∑ b ∈ Finset.range J,
          etaFejerPairSum q Y a b A r‖ := by rw [hEq]
    _ ≤ ∑ a ∈ Finset.range J,
          ‖∑ b ∈ Finset.range J, etaFejerPairSum q Y a b A r‖ :=
        norm_sum_le _ _
    _ ≤ ∑ a ∈ Finset.range J, ∑ b ∈ Finset.range J,
          ‖etaFejerPairSum q Y a b A r‖ := by
        apply Finset.sum_le_sum
        intro a ha
        exact norm_sum_le _ _
    _ ≤ (J : ℝ) * (1 + Real.log A) + (J : ℝ)^2 * B :=
      etaFejerPairNormSum_le hJ hY1 hA1 hYA hB hmode

#print axioms etaFejerPairSum_offdiag_le
#print axioms etaFejerPairSum_diag_norm_le
#print axioms etaFejerPairNormSum_le
#print axioms etaFejerWeightedSq_le


lemma etaHarmonicNearJumpMass_le_fejerWeightedSq
    {q Y J : ℕ} (hJ : 1 ≤ J) {A : ℝ} {r : ℤ} :
    etaHarmonicNearJumpMass q A r Y (8 * (J : ℝ))
      ≤ (4 / (J : ℝ)^2) * etaFejerWeightedSq q Y J A r := by
  classical
  unfold etaHarmonicNearJumpMass
  let c : ℝ := 4 / (J : ℝ)^2
  have hJr : 0 < (J : ℝ) := by exact_mod_cast (show 0 < J by omega)
  have hc0 : 0 ≤ c := by dsimp [c]; positivity
  calc
    (∑ m ∈ (Finset.Icc 1 Y).filter
        (fun m => ¬ etaHarmonicAwayFromJump q A r (8 * (J : ℝ)) m),
        1 / (m : ℝ))
      ≤ ∑ m ∈ (Finset.Icc 1 Y).filter
        (fun m => ¬ etaHarmonicAwayFromJump q A r (8 * (J : ℝ)) m),
        (1 / (m : ℝ)) *
          (c * ‖etaFejerPhaseSumCore J
            (A / (m : ℝ) +
              (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))‖^2) := by
          apply Finset.sum_le_sum
          intro m hm
          have hm' := Finset.mem_filter.mp hm
          have hmI := Finset.mem_Icc.mp hm'.1
          have hmR : 0 < (m : ℝ) := by exact_mod_cast (show 0 < m by omega)
          have hmaj := eta_near_jump_fejer_majorant
            (q := q) (J := J) (m := m) hJ
            (A := A) (r := r) hm'.2
          have hinv : 0 ≤ 1 / (m : ℝ) := by positivity
          dsimp [c]
          simpa [mul_one] using
            (mul_le_mul_of_nonneg_left hmaj hinv)
    _ ≤ ∑ m ∈ Finset.Icc 1 Y,
        (1 / (m : ℝ)) *
          (c * ‖etaFejerPhaseSumCore J
            (A / (m : ℝ) +
              (r : ℝ) / ((Nat.lcm 6 q : ℕ) : ℝ))‖^2) := by
          apply Finset.sum_le_sum_of_subset_of_nonneg
            (Finset.filter_subset _ _)
          intro m hmI hmnot
          rw [Finset.mem_Icc] at hmI
          have hmR : 0 < (m : ℝ) := by exact_mod_cast (show 0 < m by omega)
          positivity
    _ = (4 / (J : ℝ)^2) * etaFejerWeightedSq q Y J A r := by
          unfold etaFejerWeightedSq
          dsimp [c]
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro m hm
          ring

lemma etaHarmonicNearJumpMass_fejer_budget
    {q Y J : ℕ} (hJ : 1 ≤ J)
    {A beta : ℝ} {r : ℤ}
    (hY1 : 1 ≤ Y) (hA1 : 1 ≤ A) (hYA : (Y : ℝ) ≤ A)
    (hbeta : 0 ≤ beta) (hlog1 : 1 ≤ Real.log A)
    (hmode :
      ∀ {A' : ℝ} {j : ℕ},
        1 ≤ j → j ≤ J →
        |A'| = (j : ℝ) * A →
        ‖etaHarmonicAdditiveMode Y A' 0‖ ≤ beta * Real.log A) :
    etaHarmonicNearJumpMass q A r Y (8 * (J : ℝ))
      ≤ (8 / (J : ℝ) + 4 * beta) * Real.log A := by
  have hJr : 0 < (J : ℝ) := by exact_mod_cast (show 0 < J by omega)
  have hB0 : 0 ≤ beta * Real.log A :=
    mul_nonneg hbeta (le_trans (by norm_num) hlog1)
  have hW := etaFejerWeightedSq_le
    (q := q) (Y := Y) (J := J) (A := A)
    (B := beta * Real.log A) (r := r)
    hJ hY1 hA1 hYA hB0 hmode
  have hM := etaHarmonicNearJumpMass_le_fejerWeightedSq
    (q := q) (Y := Y) (J := J) hJ (A := A) (r := r)
  calc
    etaHarmonicNearJumpMass q A r Y (8 * (J : ℝ))
      ≤ (4 / (J : ℝ)^2) * etaFejerWeightedSq q Y J A r := hM
    _ ≤ (4 / (J : ℝ)^2) *
        ((J : ℝ) * (1 + Real.log A) +
          (J : ℝ)^2 * (beta * Real.log A)) := by
          exact mul_le_mul_of_nonneg_left hW (by positivity)
    _ = (4 / (J : ℝ)) * (1 + Real.log A) +
          4 * beta * Real.log A := by
          field_simp [ne_of_gt hJr]
    _ ≤ (8 / (J : ℝ)) * Real.log A +
          4 * beta * Real.log A := by
          have hlog0 : 0 ≤ Real.log A := le_trans (by norm_num) hlog1
          have hsum : 1 + Real.log A ≤ 2 * Real.log A := by linarith
          have hc : 0 ≤ 4 / (J : ℝ) := by positivity
          have hmain :
              (4 / (J : ℝ)) * (1 + Real.log A) ≤
                (8 / (J : ℝ)) * Real.log A := by
            calc
              (4 / (J : ℝ)) * (1 + Real.log A)
                ≤ (4 / (J : ℝ)) * (2 * Real.log A) :=
                  mul_le_mul_of_nonneg_left hsum hc
              _ = (8 / (J : ℝ)) * Real.log A := by ring
          linarith
    _ = (8 / (J : ℝ) + 4 * beta) * Real.log A := by ring

set_option maxHeartbeats 1000000 in
theorem etaHarmonicNearJumpMass_scaled_uniform_sublog
    {delta : ℝ} (hdelta : 0 < delta) (q : ℕ) :
    ∃ S : ℝ, 1 < S ∧
      ∃ A0 : ℕ, 1 ≤ A0 ∧
        ∀ {A : ℝ} {Y : ℕ} {r : ℤ},
          (A0 : ℝ) ≤ A →
          Real.exp 1 ≤ A →
          1 ≤ Y → (Y : ℝ) ≤ A →
          etaHarmonicNearJumpMass q A r Y S
            ≤ delta * Real.log A := by
  obtain ⟨J, hJgt⟩ := exists_nat_gt (16 / delta)
  have hJpos : 0 < J := by
    have h16d : 0 < 16 / delta := by positivity
    exact_mod_cast (lt_trans h16d hJgt)
  have hJ : 1 ≤ J := by omega
  have hJr : 0 < (J : ℝ) := by exact_mod_cast hJpos
  have hJbudget : 8 / (J : ℝ) ≤ delta / 2 := by
    have hJgt' : 16 / delta < (J : ℝ) := hJgt
    have hdelta0 : delta ≠ 0 := ne_of_gt hdelta
    have hJ0 : (J : ℝ) ≠ 0 := ne_of_gt hJr
    have hmul : 16 < delta * (J : ℝ) := by
      have := (div_lt_iff₀ hdelta).mp hJgt'
      simpa [mul_comm] using this
    have hmul' : 16 ≤ delta * (J : ℝ) := le_of_lt hmul
    rw [div_le_iff₀ hJr]
    nlinarith
  let beta : ℝ := delta / 8
  have hbeta : 0 < beta := by dsimp [beta]; positivity
  obtain ⟨A0, hA01, hprod⟩ :=
    etaHarmonicAdditiveMode_scaled_uniform_sublog hbeta J
  refine ⟨8 * (J : ℝ), ?_, A0, hA01, ?_⟩
  · have hJ1r : (1 : ℝ) ≤ (J : ℝ) := by exact_mod_cast hJ
    nlinarith
  · intro A Y r hA0A hExpA hY1 hYA
    have hexp1 : (1 : ℝ) < Real.exp 1 := by
      simpa using (Real.one_lt_exp_iff.mpr (by norm_num : (0 : ℝ) < 1))
    have hA1 : (1 : ℝ) ≤ A := le_trans (le_of_lt hexp1) hExpA
    have hlog1 : 1 ≤ Real.log A := by
      have hlog := Real.log_le_log (Real.exp_pos 1) hExpA
      simpa using hlog
    have hmode :
        ∀ {A' : ℝ} {j : ℕ},
          1 ≤ j → j ≤ J →
          |A'| = (j : ℝ) * A →
          ‖etaHarmonicAdditiveMode Y A' 0‖ ≤ beta * Real.log A := by
      intro A' j hj1 hjJ hAbs
      exact hprod hA0A hY1 hYA hj1 hjJ hAbs
    have hM := etaHarmonicNearJumpMass_fejer_budget
      (q := q) (Y := Y) (J := J) hJ
      (A := A) (beta := beta) (r := r)
      hY1 hA1 hYA hbeta.le hlog1 hmode
    have hcoef : 8 / (J : ℝ) + 4 * beta ≤ delta := by
      dsimp [beta]
      linarith
    exact hM.trans
      (mul_le_mul_of_nonneg_right hcoef (le_trans (by norm_num) hlog1))


theorem etaHarmonicNearJumpMass_le_delta_log_of_large_S
    {delta : ℝ} (hdelta : 0 < delta) (q : ℕ) :
    ∃ S : ℝ, 1 < S ∧
      ∃ A0 : ℕ, 1 ≤ A0 ∧
        ∀ (r : ℤ) (A : ℝ) (Y : ℕ),
          (A0 : ℝ) ≤ A →
          Real.exp 1 ≤ A →
          1 ≤ Y →
          (Y : ℝ) ≤ A →
          etaHarmonicNearJumpMass q A r Y S
            ≤ delta * Real.log A := by
  obtain ⟨S, hS, A0, hA0, hmain⟩ :=
    etaHarmonicNearJumpMass_scaled_uniform_sublog hdelta q
  refine ⟨S, hS, A0, hA0, ?_⟩
  intro r A Y hA0A hAexp hY1 hYA
  exact hmain hA0A hAexp hY1 hYA