import PaperB.FixedQ.GlobalProperSmallBoxBridge
import PaperB.FixedQ.H2BooleanParameters

open Filter Real Asymptotics
open scoped BigOperators

namespace PaperB.FixedQ

noncomputable def globalProperOrdinaryGeometricRate
    (q N0 : ℕ) (C : ℝ) (Z : ℕ) : ℝ :=
  (12 * (fixedQPeriod q : ℝ)) *
      h2BooleanInitialProperWeightMass q N0 +
    ((Nat.log 2 Z + 1 : ℕ) : ℝ) * C *
      (Real.log ((N0 * 2 ^ (Nat.log 2 Z + 1) : ℕ) : ℝ)) ^
        (h2BooleanX0 - 1) *
      (Real.log
        (Real.log ((N0 * 2 ^ (Nat.log 2 Z + 1) : ℕ) : ℝ))) ^ 2

lemma globalProperOrdinaryGeometricRate_nonneg
    {q N0 : ℕ} {C : ℝ}
    (hC : 0 ≤ C) (hN0 : 0 < N0) (Z : ℕ) :
    0 ≤ globalProperOrdinaryGeometricRate q N0 C Z := by
  unfold globalProperOrdinaryGeometricRate
  have hinit : 0 ≤ h2BooleanInitialProperWeightMass q N0 :=
    h2BooleanInitialProperWeightMass_nonneg q N0
  have hUpos : 0 < N0 * 2 ^ (Nat.log 2 Z + 1) := by positivity
  have hUtwo : 2 ≤ N0 * 2 ^ (Nat.log 2 Z + 1) := by
    have hN1 : 1 ≤ N0 := Nat.one_le_iff_ne_zero.mpr hN0.ne'
    have hpow : 2 ≤ 2 ^ (Nat.log 2 Z + 1) := by
      have h1 : 1 ≤ Nat.log 2 Z + 1 := by omega
      simpa using (Nat.pow_le_pow_right (n := 2) (by norm_num) h1)
    nlinarith
  have hlog0 : 0 ≤ Real.log
      ((N0 * 2 ^ (Nat.log 2 Z + 1) : ℕ) : ℝ) := by
    apply Real.log_nonneg
    exact_mod_cast (show 1 ≤ N0 * 2 ^ (Nat.log 2 Z + 1) by omega)
  have hllsq : 0 ≤
      (Real.log
        (Real.log ((N0 * 2 ^ (Nat.log 2 Z + 1) : ℕ) : ℝ))) ^ 2 :=
    sq_nonneg _
  have hx0 : 0 ≤ h2BooleanX0 - 1 := by
    linarith [h2BooleanX0_one_le_public]
  have hp0 : 0 ≤
      (Real.log ((N0 * 2 ^ (Nat.log 2 Z + 1) : ℕ) : ℝ)) ^
        (h2BooleanX0 - 1) :=
    Real.rpow_nonneg hlog0 _
  positivity

theorem globalProperDecoratedSmallMajorant_le_geometric_rate
    (q : ℕ) (hq : 0 < q) :
    ∃ C : ℝ, ∃ N0 : ℕ,
      0 ≤ C ∧ 0 < N0 ∧
      ∀ a h Z : ℕ,
        16 ≤ h →
        (¬ 2 ∣ q → 2 ∣ h) →
        globalProperDecoratedSmallMajorant q a h Z ≤
          (weakDecoratedMertensC * Real.log (Real.log (h : ℝ))) *
            globalProperOrdinaryGeometricRate q N0 C Z := by
  rcases h2BooleanProperCoreSmallMajorant_le_geometric_rate q hq with
    ⟨C, N0, hC, hN0, hrate⟩
  refine ⟨C, N0, hC, hN0, ?_⟩
  intro a h Z hh16 h2
  let Q := globalProperOrdinaryGeometricRate q N0 C Z
  have hQ0 : 0 ≤ Q :=
    globalProperOrdinaryGeometricRate_nonneg hC hN0 Z
  have hsum :
      globalProperDecoratedSmallMajorant q a h Z ≤
        (∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
          finiteVWeightReal h d) * Q := by
    unfold globalProperDecoratedSmallMajorant
    rw [Finset.sum_mul]
    apply Finset.sum_le_sum
    intro d hd
    have hv0 : 0 ≤ finiteVWeightReal h d := by
      apply finiteVWeightReal_nonneg_of_active
      exact decoratedHeightPrimeSet_active (Finset.mem_powerset.mp hd)
    have hHpar := decoratedReducedHeight_parity_of_mem h2 hd
    have hr := hrate
      (decoratedReducedAnchor q a (primeSetProduct d))
      (h / primeSetProduct d) Z hHpar
    change finiteVWeightReal h d *
        h2BooleanProperCoreSmallMajorant q
          (decoratedReducedAnchor q a (primeSetProduct d))
          (h / primeSetProduct d) Z ≤
      finiteVWeightReal h d * Q
    exact mul_le_mul_of_nonneg_left hr hv0
  have hmass :
      (∑ d ∈ (decoratedHeightPrimeSet q h).powerset,
        finiteVWeightReal h d) ≤
        weakDecoratedMertensC * Real.log (Real.log (h : ℝ)) :=
    (sum_decorated_finiteVWeightReal_lt_weakMertens
      (q := q) hh16).le
  exact hsum.trans (mul_le_mul_of_nonneg_right hmass hQ0)

#print axioms globalProperDecoratedSmallMajorant_le_geometric_rate

end PaperB.FixedQ
